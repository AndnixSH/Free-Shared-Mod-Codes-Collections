local DateFormatUtil = require "Common.Util.DateFormatUtil"
local GuildDef = require "Modules.Guild.GuildDef"
local ClistRender = require "Core.Implement.UI.Class.ClistRender"
local ClistItem = require "Core.Implement.UI.Class.ClistItem"
local GuildProxy = require "Modules.Guild.GuildProxy"

local GuildRecordViewItem = GuildRecordViewItem or BaseClass(ClistItem)

function GuildRecordViewItem:Load(obj)
	self.contentLab = self:GetChildComponent(self.go, "CLabel1", "CLabel")
	self.timeLab = self:GetChildComponent(self.go, "CLabel2", "CLabel")
end


function GuildRecordViewItem:SetData(data)
	self.data = data
	local logCfg = GuildDef.GuildLogInfos[self.data.logType]
	if logCfg then
		local tab
		local contentStr = ""--self:GetWord(logCfg[1], table.unpack(tab))
		if logCfg[2] == 1 then
			contentStr = self:GetWord(logCfg[1], self.data.from_name)
		elseif logCfg[2] == 2 then
			contentStr = self:GetWord(logCfg[1], self.data.to_name)
		elseif logCfg[2] == 3 then
			contentStr = self:GetWord(logCfg[1], self.data.from_name, self.data.to_name)
		elseif logCfg[2] == 4 then
			contentStr = self:GetWord(logCfg[1])
		end
		
		self.contentLab.text = contentStr
		
		local timeStr = DateFormatUtil.formatYMDAndHM(self.data.logTime)
		self.timeLab.text = timeStr
	end
end

local GuildRecordView = GuildRecordView or LuaWidgetClass()

function GuildRecordView:__init()
	self.tweenOption = {bScale = true}
end

function GuildRecordView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Guild.GuildRecordView", self.LoadEnd)
end

function GuildRecordView:LoadEnd(obj)
	self:SetGo(obj)
	self:InitUI()
	self:SetStep(0)
end

function GuildRecordView:InitUI()
	self.rootObj = self:GetChild(self.go, "Record/root")
	self.closeBtn = self:GetChildComponent(self.rootObj, "content/close", "CButton")
	self.closeBtn:AddClick(function()
		self:CloseView()
	end)
	self.emptyObj = self:GetChild(self.rootObj, "content/NoRecord")
	self.clist = self:GetChildComponent(self.rootObj, "CList", "CList")
	self.clistRender = ClistRender.New()
	self.clistRender:Load(self.clist, GuildRecordViewItem)
end

function GuildRecordView:OnClose()
	self:AutoUnRegister()
end

function GuildRecordView:OnDestroy()
	self:AutoUnRegister()
end

function GuildRecordView:OnOpen()
	self:AutoRegister()
	-- self:SetNetStep(1)
	GuildProxy.Instance:Send70015()
end

function GuildRecordView:OnNetOpen()
	self:UpdateView()
end

function GuildRecordView:UpdateView()
	self.emptyObj:SetActive(#self.logInfos == 0 and true or false)
	self.clistRender:ClearData()
	self.clistRender:AppendDataList(self.logInfos)
end

function GuildRecordView.EvtNotify.Guild.data:UpdateLogInfos(data, args)
	self.logInfos = args.logInfos
	self:UpdateView()
	-- self:NetStep(1)
end

return GuildRecordView