local BattleProto = require "Core.Implement.Net.BattleProto"
local HexMapProxy = HexMapProxy or BaseClass(BaseProxy, BattleProto)
local HexMapDef = require "Modules.HexMap.HexMapDef"
local hexmap = require "Modules.HexMap.hexmap"
local hexmapbuild = require "Modules.HexMap.hexmapbuild"
local BattleProxy = require "Modules.Battle.BattleProxy"

function HexMapProxy:__init()
    HexMapProxy.Instance = self
    self.data = {}
    self.donequeue = {}
end

function HexMapProxy:__delete()
    self:ClearProxy()
    self.cellproxy = nil
    self.donequeue = nil
    HexMapProxy.Instance = nil
end

function HexMapProxy:SetCellProxy(activityid, proxy, hexproto)
    self.activityid = activityid
    self.cellproxy = proxy

    self.proto = {}

    for name, protoid in pairs(hexproto) do
        self.proto[name] = protoid
        self:RemoveProto(protoid)
        local recvfunc = "onhexproto_"..name
        self:AddProto(protoid, self[recvfunc])
    end

    self:AddPreBattle(activityid, self.OnPreBattle) --准备战斗回调
    self:AddSetBattle(activityid, self.OnSetBattle) --战斗结算回调	
    self:AddStartBattle(activityid, self.OnStartBattle) --战斗开始回调	

    self._follow_result = true
end

function HexMapProxy:SetBattleState(inbattle)
    self._inbattle = inbattle
end

function HexMapProxy:SetBattleCell(cellid)
    self._battle_cell_id = cellid
end

function HexMapProxy:SetBattleRestartCell(cellid)
    self._battle_restart_cell_id = cellid
end

function HexMapProxy:GetBattleRestartCell()
    return self._battle_restart_cell_id
end

function HexMapProxy:GetBattleCell()
    return self._battle_cell_id
end

function HexMapProxy:GetMapStep()
    return hexmap:getmapstep()
end

function HexMapProxy:GetBuildShare(key)
    return hexmap:getbuildshare(key)
end

function HexMapProxy:GetActivityid()
    return self.activityid
end

function HexMapProxy:ClearProxy()
    self.activityid = nil
    self.cellproxy = nil
    self.proto = {}
    self.donequeue = {}
end


function HexMapProxy:PosToCell(position)
    return hexmap:pos_to_cell(position)
end

function HexMapProxy:IntMap(map_config, cell_config, map_data)
    self.data.map_config = map_config
    self.donequeue = {}
    self:ToNotify(self.data, HexMapDef.NotifyDef.OnMapPreInit)
    hexmap:init(map_config, cell_config, map_data, self)
end

function HexMapProxy:RefreshMap()
	hexmap:clear_follower()
    hexmap:refresh()
    for _, donedecoder in ipairs(self.donequeue) do
        self:_onhexproto_done(donedecoder)
    end
    self.donequeue = {}
end

function HexMapProxy:CheckBattle()
    local lastRestartCell = self:GetBattleRestartCell()
    if lastRestartCell then
        self:OpenCell(lastRestartCell, 2)
        self:SetBattleRestartCell(nil)
    end
end

function HexMapProxy:GetMapConfig()
    return self.data.map_config
end

function HexMapProxy:DecodeCellInfos(buffer, cell_config)

    local decoder = NetDecoder.New(buffer, 1)
    local count = decoder:Decode("I2")
    local cellinfos = {}
    for i = 1, count do
        local cellid, buildid, status = decoder:Decode("I2I2I1")
        cellinfos[cellid] = {id = cellid, build = buildid, status = status }
        -- print(string.format("cellinfo cellid:%s buildid:%s status:%s", cellid, buildid, status))
    end
    return cellinfos, decoder
end

function HexMapProxy:SetFollower(cellid)
    hexmap:setfollower(cellid)
end

function HexMapProxy:GetFollower()
    return hexmap:getfollower()
end


function HexMapProxy:Operate(cellid)
    hexmap:operatecell(cellid)
    if self.cellproxy and self.cellproxy.OnOperateCell then
        self.cellproxy:OnOperateCell(cellid)
    end
end

function HexMapProxy:PathTo(from, to)
    return hexmap:pathto(from, to)
end

function HexMapProxy:GetCell(cellid)
    return hexmap:getcell(cellid)
end

function HexMapProxy:GetCellPos(cellid)
    local cell = self:GetCell(cellid)
    if cell then
        return cell.top_position
    end
end

function HexMapProxy:UpdateFollower(cellid_list, cbreach, cbnode)

    local pos = {}

    for i, cellid in ipairs(cellid_list) do
        local cell = self:GetCell(cellid)
        if cell then
            table.insert(pos, cell.top_position)
        end
    end

    self:ToNotify(self.data, HexMapDef.NotifyDef.UpdateFollower, {position_list = pos, cbreach = cbreach, cbnode = cbnode})

    return self._follow_result
    
end

function HexMapProxy:BlinkFollower(cellid)
    local pos = {}
    local cell = self:GetCell(cellid)
    if cell then
        table.insert(pos, cell.top_position)
    end
    self:ToNotify(self.data, HexMapDef.NotifyDef.UpdateFollower, {position_list = pos, blink = true })
end

function HexMapProxy:SetUpdateFollowerResult(result)
    self._follow_result = result
end

function HexMapProxy:StopFollower(args)
	self:ToNotify(self.data, HexMapDef.NotifyDef.StopFollower, args)
end

function HexMapProxy:UpdateCell(cellvo)
    self:ToNotify(self.data, HexMapDef.NotifyDef.UpdateCellView, cellvo)
end

function HexMapProxy:UpdateBuild(cellvo)
    self:ToNotify(self.data, HexMapDef.NotifyDef.UpdateBuildView, cellvo)
end

function HexMapProxy:CreateCells()
    self:ToNotify(self.data, HexMapDef.NotifyDef.CreateCells)
end

-- 上阵
function HexMapProxy:HeroToBattle(hero_infos, enemy_infos)
    if self.proto.hero_to_battle then
        local encoder = NetEncoder.New()
        self:_EncodeHeroInfo(hero_infos, encoder)
        self:_EncodeEnemyInfo(enemy_infos, encoder)
        encoder:Encode("s2", "")
        self:SendMessage(self.proto.hero_to_battle, encoder)
    else
        print("proto.hero_to_battle不存在")
    end
end

function HexMapProxy:RequireHeroList()
    if self.proto.hero then
        self:SendMessage(self.proto.hero)
    else
        print("proto.hero不存在")
    end
end

function HexMapProxy:onhexproto_hero(decoder)
    local count = decoder:Decode("I2")
    local heroList = {}
    for i = 1, count do
        local hero = {}
        hero.herouid, hero.fromuid, hero.fromtype, hero.roleid, hero.level, hero.rank, hero.curskin, hero.crystal, hero.hire_hero_type = decoder:Decode("I4I4I2I2I2I2I2I2I2")
        hero.prop = decoder:DecodeList("I2I2", true)
        hero.equips = decoder:DecodeList("I4I1", true)
        table.insert(heroList, hero)
        --print("hero", table.dump(hero))
    end
    self:ToNotify(self.data, HexMapDef.NotifyDef.Update_Hero_List, {heroInfos = heroList})
end


-- 获取符文列表
function HexMapProxy:RequireRuneList()
    if self.proto.rune then
        self:SendMessage(self.proto.rune)
    else
        print("proto.rune不存在")
    end
end

function HexMapProxy:GetOneRuneItemDataById(runeId)
    local LanguageManager = require "Common.Mgr.Language.LanguageManager"     
    local cfg =ConfigManager.GetConfig("data_rune")
    if cfg then
        
        local item={}
        local config=cfg[runeId]
        if config then 
            item.name= LanguageManager.Instance:GetWord(config.name)
            item.info=LanguageManager.Instance:GetWord(config.info)
            item.dec=LanguageManager.Instance:GetWord(config.dec)
            item.id=config.id
            item.quality =config.quality
            item.icon=config.big_icon --tostring(config.id)
            item.qulitySprname="baoshi_"..tostring(config.quality)
            item.typename=config.small_icon and config.small_icon or ""
            item.show_type = config.show_type
            return item,config.power_rate
        end
    end
end

function HexMapProxy:onhexproto_rune(decoder)
    local runeList = decoder:DecodeList("I4")
    -- print("runeList", table.dump(runeList))

    local data={}
    local infos={} --蓝 紫 橙
    for i = 1 ,3 do
        local item={}
        item.num=0
        item.fight=0
        table.insert(infos,item)
    end
    local fun=function(id)
        
        local HexMapUI = require "Modules.HexMap.HexMapUI"
        HexMapUI.OpenWidget(UIWidgetNameDef.RuneListChooseView,id)
    end
    for k,v in ipairs(runeList) do
        local item,power_rate=self:GetOneRuneItemDataById(v)
        if item then
            if not item.show_type or item.show_type ~= 2 then
                item.index=k
                if item.quality == 3 then

                    infos[3].num= infos[3].num + 1
                    infos[3].fight= infos[3].fight + (power_rate or 0)

                elseif item.quality == 5 then

                    infos[2].num= infos[2].num + 1
                    infos[2].fight= infos[2].fight + ( power_rate or 0)

                elseif item.quality == 7 then

                    infos[1].num= infos[1].num + 1
                    infos[1].fight= infos[1].fight + ( power_rate or 0)
                end
                item.fun=fun
                table.insert(data,item)
            end
        end
    end
    table.sort(data, function(a,b) --排序
        if a.quality == b.quality then
            return a.id < b.id
        end
        return a.quality > b.quality
    end)
    self:ToNotify(self.data,HexMapDef.NotifyDef.Update_Rune_List,{data=data,infos=infos})
end

function HexMapProxy:MoveTo(cellid)
    if self.proto.move then
        local encoder = NetEncoder.New()
        encoder:Encode("I2", cellid)
        self:SendMessage(self.proto.move, encoder)
    else
        print("proto.move不存在")
    end
end

function HexMapProxy:onhexproto_move(decoder)
    
end

function HexMapProxy:OpenCell(cellid, step, buffer)
    if self.proto.open then
        local encoder = NetEncoder.New()
        encoder:Encode("I2I2", cellid, step)
        if buffer then
            encoder:Encode(buffer.fmt, table.unpack(buffer.data))
        end
        -- print("HexMapProxy.OpenCell", self.proto.open, cellid)
        self:SendMessage(self.proto.open, encoder)
    else
        print("proto.open不存在")
    end
end

function HexMapProxy:onhexproto_open(decoder)
    local status, cellid, step, openbuffer = decoder:Decode("I1I2I2s2")
    -- print("HexMapProxy.OnCellOpen", status, cellid)

    if status == 0 then
        local cell = self:GetCell(cellid)
        if cell and cell.build then
            cell.build:open(step, NetDecoder.New(openbuffer, 1))
        end
    end

end

function HexMapProxy:DoneCell(cellid, buffer)
    if self.proto.done then
        local encoder = NetEncoder.New()
        encoder:Encode("I2", cellid)
        if buffer then
            encoder:Encode(buffer.fmt, table.unpack(buffer.data))
        end
        -- print("HexMapProxy.DoneCell", self.proto.done, cellid)
        self:SendMessage(self.proto.done, encoder)
    else
        print("proto.done不存在")
    end
end

function HexMapProxy:onhexproto_done(decoder)
    if self._inbattle then
        table.insert(self.donequeue, decoder)
    else
        self:_onhexproto_done(decoder)
    end
end

function HexMapProxy:_onhexproto_done(decoder)
    local status, cellid, result, nextbuild, donebuffer = decoder:Decode("I1I2I1I2s2")
    if status == 0 then
        local cell = self:GetCell(cellid)
        -- print("HexMapProxy.OnCellDone", cellid, result, nextbuild, cell, cell and cell.build)
        if cell then
            if cell.build then
                cell.build:done(result == 0, nextbuild, NetDecoder.New(donebuffer, 1))
            else
                hexmapbuild.add_build(cell, nextbuild)
            end
        end
    end
end

--dir为最后方向
function HexMapProxy:MoveBuild(cellid, dir, to_cell_id)
	if self.proto.move_build then
		--print("send_move_guild", cellid, dir, to_cell_id)
		local encoder = NetEncoder.New()
		encoder:Encode("I2I1I2", cellid, dir, to_cell_id)
		self:SendMessage(self.proto.move_build, encoder)
	else
		print("proto.move_build不存在")
	end
end

function HexMapProxy:onhexproto_move_build(decoder)
	local status, cellid, dir, buffer = decoder:Decode("I1I2I1s2")
	local paths = decoder:DecodeList("I2")
	local dirs= decoder:DecodeList("I1")
	if status == 0 then
		local cell = self:GetCell(cellid)
		if cell and cell.build then
			--print("do_move_guild", cellid, dir, table.dump(paths))
			hexmapbuild.move_build(cell.hexmap, cellid, paths, dirs, false)
		end
	end

end

function HexMapProxy:Proxy_Notify(key, args)
    if self.cellproxy then
        self.cellproxy:ToNotify(self.cellproxy.data, key, args)
    end
end

function HexMapProxy:Proxy_Call(call, ...)
    if self.cellproxy and self.cellproxy[call] then
        self.cellproxy[call](self.cellproxy, ...)
    end
end

function HexMapProxy:OnPreBattle(decoder)
    local heroinfos = self:_DecodeHeroInfo(decoder)
    local enemyinfos = self:_DecodeEnemyInfo(decoder)
    local bufferstr = decoder:Decode("s2")

    local _decoder = NetDecoder.New(bufferstr, 1)
    local cellid, enemyid, sceneid = _decoder:Decode("I2I2I2")
    local rune_list = _decoder:DecodeList("I4")
    local record = _decoder:DecodeList("I2")
    local rune_flags = _decoder:DecodeList("I2I4I2", true)
    -- print('cellid:', cellid, 'rune_list:', table.dump(rune_list), 'record:', table.dump(record), 'rune_flags:', table.dump(rune_flags))
    local cell = HexMapProxy.Instance:GetCell(cellid)

    if cell and cell.build then
        local config_key = BattleProxy.Instance:GetConfigKey(sceneid, enemyid)
        self:_UpdateEnemyInfo(enemyinfos, enemyid)
        local activity_info = {}
        if self.cellproxy and self.cellproxy.OnGetActivityInfo then
            activity_info = self.cellproxy:OnGetActivityInfo()
        end
        self.data.battle_info = { enemyid = enemyid, sceneid = sceneid, config_key = config_key, cellid = cell.id, rune_list = rune_list, record = record, rune_flags = rune_flags, activity_info = activity_info }
    end

    UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 10, self.activityid, heroinfos, enemyinfos, "BattleHexMapPanel",{self.activityid})
end

function HexMapProxy:GetEnemeyId()
    if self.data.battle_info then
        return self.data.battle_info.enemyid
    end
end

function HexMapProxy:OnStartBattle(decoder, seed)
    local heroinfos = self:_DecodeHeroInfoDetail(decoder)
    local enemyinfos = self:_DecodeEnemyInfoDetail(decoder)
    local battle_info = self.data.battle_info
    self:GenerateBattleInfo_2(self.activityid, seed, heroinfos, enemyinfos, battle_info.enemyid, battle_info)
end

function HexMapProxy:OnSetBattle(decoder)
end

function HexMapProxy:GetBattleEnemyID()
	if self.data and self.data.battle_info then
		return self.data.battle_info.enemyid
	end
end

return HexMapProxy
