local timer = class({})

local tinsert = table.insert
local tunpack = table.unpack
local floor = tsmath.floor

function timer:constructor(context, source)
    self._timelist = {}
    self._removelist = {}
    self._context = context
    self._owner = source
    self._curspd = 1
    assert(context)
end

function timer:delay(delay, cb, ...)
    return self:add(delay, 0, 1, cb, ...)
end

function timer:loop(delay, interval, cb, ...)
    return self:add(delay, interval, nil, cb, ...)
end

function timer:add(delay, interval, count, cb, ...)
    return self:_internal_add(delay, interval, count, cb, { ... })
end

function timer:addtable(timertable, cb, ...)
    local delay, interval, count = tunpack(timertable)
    return self:_internal_add(delay, interval, count, cb, { ... })
end

function timer:_internal_add(delay, interval, count, cb, args)
    assert(cb, "cb is nil in timer")
    local _timer = { interval = interval, count = count, cb = cb, args = args, _cur = delay or 0, speed = self._curspd }
    tinsert(self._timelist, _timer)
    return _timer
end

function timer:setcontext(instance, context)
    instance.context = context
end

-- 设置timer实例速度
function timer:setspdrate(instance, spdrate)
    if spdrate then
        instance.speed = spdrate / 1000
    end
end

-- 设置timer总速度
function timer:setspeed(spdrate)
    if spdrate then
        self._curspd = spdrate / 1000
    end
end

function timer:remove(_timer)
    self._removelist = self._removelist or {}
    self._removelist[_timer] = true
end

local rmfunc = function (value, remove)
    return remove[value]
end

function timer:_isactive(t)

    if self._bdirty then return false end
    if self._owner and self._owner:ispause() then return false end
    if self._removelist and self._removelist[t] then return false end
    return true
    -- local bactive = (not self._owner or not self._owner:ispause()) and (not self._removelist or not self._removelist[t]) and (not self._bdirty)
    -- return bactive and t
end

function timer:process(time, tick)
    local timelist = self._timelist
    for i = 1, #timelist do
        local t = timelist[i]
        if t and self:_isactive(t) then
            t._cur = t._cur - floor(tick * t.speed)
            if t._cur <= 0 then
                local context = t.context or self._context
                if t.args then
                    t.cb(context, tunpack(t.args))
                else
                    t.cb(context, time, t.interval)
                end
                if not t.interval then -- 没有间隔 视为单次直接结束
                    self:remove(t)
                else
                    t._cur = t.interval
                    if t.count then    -- 没有次数 视为循环不结束
                        t.count = t.count - 1
                        if t.count <= 0 then   --有次数则检测为0结束
                            self:remove(t)
                        end
                    end
                end
            end
        end
    end

    local removelist = self._removelist
    if removelist and next(removelist) then
        global.array.removeby_fast(timelist, rmfunc, removelist)
        for k in pairs(removelist) do
            removelist[k] = nil
        end
    end
    -- self._removelist = nil
end

function timer:dispose()
    self._timelist = {}
    self._removelist = nil
    self._bdirty = true
end

local timer_service = {  _timerlist = {}, _removelist = {}, _timerindex = {}, _removecnt = 0 }

local function getsortkeys(tableunsort, filter)
    local keylist = {}
    for k, _ in pairs(tableunsort) do
        if not filter or filter(k) then
            table.insert(keylist, k)
        end
    end
    table.sort(keylist)
    return keylist
end

local function filter(key)
    if #key >= 2 then 
        local pr =  string.sub(key, 1, 1)
        return pr == "f" or pr == "t"
    end
end

function timer_service:load(tb, context, soruce)
    local newtimer = self:createtimer(context, soruce)
    if next(tb) then
        local keys = getsortkeys(tb, filter)
        for _, key in ipairs(keys) do
            local pr = string.sub(key, 1, 1)
            local n = tonumber(string.sub(key, 2))
            local interval = 0
            if pr == "f" then
                n = n * global.service.time.tick --self._service_time.tick
            end
            newtimer:_internal_add(0, n, nil, tb[key], nil)
        end
    end
    return newtimer
end


function timer_service:unload(tb, context, soruce)
    self:destroytimer(tb)
end

function timer_service:createtimer(context, source)
    local newtimer = timer(context, source)
    table.insert(self._timerlist,  newtimer)
    -- self._timerindex[newtimer] = #self._timerlist
    return newtimer
end

function timer_service:destroytimer(tb)
    tb:dispose()
    self._removelist = self._removelist or {}
    self._removelist[tb] = true
    self._removecnt = self._removecnt + 1
    -- self._timerlist[self._timerindex[tb]] = nil
end

local rmfunc = function (value, remove)
    return remove[value]
end


function timer_service:process(time, tick)
    local timerlist = self._timerlist
    for i = 1, #timerlist do
        local t = timerlist[i]
        if t and not t._bdirty then
            t:process(time, tick)
        end
    end

    if self._removelist and self._removecnt >= 1000 then
        -- print("remove", global.service.time.frame, #self._timerlist, table.count(self._removelist))
        global.array.removeby_fast(timerlist, rmfunc, self._removelist)
        self._removelist = nil
        self._removecnt = 0
    end

end

function timer_service:dump()
    global.debug.info("timer_service._timerlist", #self._timerlist)
    global.debug.info("timer_service._removelist", self._removelist and #self._removelist)
end

function timer_service:dispose()
    self._timerlist = {}
    self._removelist = {}
    self._timerindex = {}
    self._removecnt = 0
end

return timer_service