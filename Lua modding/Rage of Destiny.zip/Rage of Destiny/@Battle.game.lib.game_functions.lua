local _keymark = {}

function keyselect(cfg)
    return { _keymark, cfg }
end

function keyconfig(key, value)
    if key and type(value) == 'table' and value[1] and value[1] == _keymark then
        return value[2][key]
    end
    return value
end

gamefunc = {}

function gamefunc.mergetbl(src, kvp)

    if not kvp then return src end

    local dest = {}
    for k, v in pairs(src) do
        dest[k] = kvp[k] or v
    end
    return dest
end