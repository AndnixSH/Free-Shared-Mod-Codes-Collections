local ChatDef = {}

ChatDef.NotifyDef = {
   
  Chat_Request="Chat_Request",
  Chat_UpdateTitleList="Chat_UpdateTitleList", 
  Chat_UpdateCurContentList="Chat_UpdateCurContentList",
  Chat_UpdateSelectTitle="Chat_UpdateSelectTitle",
  Chat_UpdateFullTitleRedDot="Chat_UpdateFullTitleRedDot",
  Chat_UpdateNewEffect="Chat_UpdateNewEffect", --查看新消息后，特效隐藏
  Chat_TranslateEnd = "Chat_TranslateEnd", --翻译结束
}

ChatDef.CommonDef={
  Chat_World="ChatView_1002",
  Chat_Local="ChatView_1003",
  Chat_Guild="ChatView_1004",
  Chat_Army="ChatView_1005",
  YesterDay="ChatView_1006",
  NewsTip="ChatView_1007",
  Wait="ChatView_1008",
  Little="ChatView_1009",
  Many="ChatView_1010",
  TooMany="ChatView_1011",
  ChangeSuccess="ChatView_1012",
  Expression="ChatView_1013",
  TooManyPeopleInRoom="ChatView_1014",
  Iam="",
  Count="ChatView_1015",
  CannotSendMsgToSelf="ChatView_1016",
  AddGuildTips="ChatView_1026",
  ExistGuildTips="ChatView_1027", --agree_friend_tips!
  AgreeFriendTips="ChatView_1025", --enter_guild_tips! --"exist_guild_tips!"  --ChatView_1025

  Translating = "Translation_1001",
  TranslateFinish= "Translation_1002",
  TranslateOriginal= "Translation_1003",--原文

}

ChatDef.WeekDay =
{
  "Common_1057",
  "Common_1058",
  "Common_1059",
  "Common_1060",
  "Common_1061",
  "Common_1062",
  "Common_1063",
}

ChatDef.Chat_Inputips = 
{
	[1]="ChatView_1017",--世界聊天
	[2]="ChatView_1018",--本地聊天
	[3]="ChatView_1044",--公会聊天
}

ChatDef.ChatBtn={
  Chat_World="ChatView_1024",
  Chat_Local="ChatView_1003",
  Chat_Guild="ChatView_1004",
  Chat_Army="ChatView_1005",
}
ChatDef.ChatType={
  chat_World=1,
  chat_Local=2,
  chat_Guild=3,
  chat_Army=4,
  chat_Private=5,--5后面都是私聊
}

ChatDef.expressTitleIconName={
  [1] = "normalex_4",
  [2] = "Emoji_1008",
}

ChatDef.Chat_Setting = 
{
	WorldChat="Chat_WorldChat",--世界聊天
	LocalChat="Chat_LocalChat",--本地聊天
	GuilChat="Chat_GuilChat",--公会聊天
	ArmyChat="Chat_ArmyChat",--军团聊天
	PrivateChatList="Chat_PrivateChatList",--私聊列表
	PrivateChat="Chat_PrivateChat_",--私聊_uin

	SelectKey="Chat_SelectKey",
}

ChatDef.Chat_Key = 
{
	[1]=ChatDef.Chat_Setting.WorldChat,--世界聊天
	[2]=ChatDef.Chat_Setting.LocalChat,--本地聊天
	[3]=ChatDef.Chat_Setting.GuilChat,--公会聊天
	[4]=ChatDef.Chat_Setting.ArmyChat,--军团聊天
}

ChatDef.Chat_Key_Index = 
{
	[ChatDef.Chat_Setting.WorldChat]=1,--世界聊天
	[ChatDef.Chat_Setting.LocalChat]=2,--本地聊天
	[ChatDef.Chat_Setting.GuilChat]=3,--公会聊天
	[ChatDef.Chat_Setting.ArmyChat]=4,--军团聊天
}
ChatDef.Language =
{
    ["zh-CN"] = "Translation_Language_1001" ,
    ["zh-TW"] = "Translation_Language_1002" ,
    ["en"] = "Translation_Language_1003",
    ["de"] = "Translation_Language_1004",
    ["fr"] = "Translation_Language_1005",
    ["ru"] = "Translation_Language_1006",
    ["it"] = "Translation_Language_1007",
    ["es"] = "Translation_Language_1008",
    ["pt"] = "Translation_Language_1009",
    ["tr"] = "Translation_Language_1010",
    ["th"] = "Translation_Language_1011",
    ["id"] = "Translation_Language_1012",
-- Translation_Language_1013	越南语
-- Translation_Language_1014	韩语
-- Translation_Language_1015	日语
}

return ChatDef