local BasicSceneStrategy = require "Modules.Scene.Strategy.BasicSceneStrategy"
local DramaStrategy = BaseClass(BasicSceneStrategy)
local render_camera = require "Battle.render.camera.render_camera"

function DramaStrategy:OnLoad()
    --LuaLayout.Instance:OpenWidget(UIWidgetNameDef.NetworkDelayView)
    local scenename = "20016"
    self:LoadScene(nil, scenename)
end

function DramaStrategy:Destroy()
    self:UnloadScene()
end

function DramaStrategy:OnStartEntry()
    self:DefaultOpenWidgets()
end

function DramaStrategy:OnLoadSceneEnd()
    render_camera.free_trunk_strategy()
    render_camera.set_camera_field_of_view(65.2)
    render_camera.set_drama_trunk_strategy("cameraPos", 53, function()
        self:OnEnterMainScene()
    end)
end

function DramaStrategy:OnEnterMainScene()
    local SceneManager = require "Modules.Scene.SceneManager"
    local SceneDef = require "Modules.Scene.SceneDef"

    SceneManager.Instance:EnterScene(SceneDef.SceneType.Main)
    --local ScreenShotter = require "Common.Util.ScreenShotter"
    --ScreenShotter.Enable()
end

function DramaStrategy:DefaultOpenWidgets()
    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.NewbieDramaView)
end

return DramaStrategy