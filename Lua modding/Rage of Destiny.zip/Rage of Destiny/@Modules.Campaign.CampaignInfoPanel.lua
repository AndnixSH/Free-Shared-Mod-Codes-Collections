local CampaignProxy = require "Modules.Campaign.CampaignProxy"
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"
local TweenTools =  require "Common.Util.TweenTools"
local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"
local _curmainlineid = nil
local CampaignInfoPanel = CampaignInfoPanel or BaseClass(GameObjFactor)
function CampaignInfoPanel:__init(go)
	self.go = go
	self:Load(go)	
end
function CampaignInfoPanel:Load(obj)
	self.rect = self:GetComponent(obj, "RectTransform")
	self.rectPosition = self.rect.anchoredPosition

	-- self.btn = self:GetChildComponent(obj, "CHorizontalItem", "CButton")
	-- self.btn:AddClick(function ()
	-- 	GameLogicTools.ShowLabelTips("unity_tips_1004", self.btn.transform.position)
	-- end)

	-- self.coinLbl = self:GetChildComponent(obj, "CHorizontalItem/item1/CLabel_num", "CLabel")
	-- self.gemLbl = self:GetChildComponent(obj, "CHorizontalItem/item2/CLabel_num", "CLabel")
	-- self.expLbl = self:GetChildComponent(obj, "CHorizontalItem/item3/CLabel_num", "CLabel")
	self.chapterLbl = self:GetChildComponent(obj, "area/group/CLabel_name", "CLabel")
	self.chapterDesLbl = self:GetChildComponent(obj, "area/CLabel_dec", "CLabel")
	
	self.changeObj = self:GetChild(obj, "change")
	self.changeitemList = {}
	for i=1, 2 do
		local item = {}
		item.obj = self:GetChild(self.changeObj, "item"..i)
		item.label_1 = self:GetChildComponent(item.obj, "back/content/CLabel_num1", "CLabel")
		item.label_2 = self:GetChildComponent(item.obj, "back/content/CLabel_num2", "CLabel")
		self.changeitemList[i] = item
	end

	self.openbtn = self:GetChildComponent(obj, "area/CButton_open", "CButton")
	self.openbtn:AddClick(function ()
		LuaLayout.Instance:OpenWidget(UIWidgetNameDef.CampaignProgressView)
	end)

	-- self.mapBtn = self:GetChildComponent(obj, "world", "CButton")
	-- self.mapBtn:AddClick(function ()		
	-- 	--GameLogicTools.ShowMsgTips(self:GetWord("Common_1033"))
	-- 	SceneManager.Instance:EnterScene(SceneDef.SceneType.WorldMap)
	-- end)

	self.areaObj = self:GetChild(obj, "area")
	self.scaneffect = UIEffectItem.New("UI_Campaign_scan", self.areaObj)
end

function CampaignInfoPanel:Open()
	self:StartOpenTween()
	self:UpdateInfo()
end	
function CampaignInfoPanel:SetActive(active)
	self.go:SetActive(active)
end

function CampaignInfoPanel:Close()
	if self.opensequence then
		self.opensequence:Kill()
		self.opensequence = nil
	end	

	if self.showtipssequence then
		self.showtipssequence:Kill()
		self.showtipssequence = nil
	end	

	if self.newsequence then
		self.newsequence:Kill()
		self.newsequence = nil
	end

	if self.scaneffect then
		self.scaneffect:Close()
		self.scaneffect = nil
	end	
end	

function CampaignInfoPanel:Destroy()

	if self.newsequence then
		self.newsequence:Kill()
		self.newsequence = nil
	end
	
	if self.scaneffect then
		self.scaneffect:Destroy()
		self.scaneffect = nil
	end
end

function CampaignInfoPanel:StartOpenTween()	
	self.rect.anchoredPosition = Vector2.New(self.rectPosition.x, self.rectPosition.y + 100)
	local tween1 = self.rect:DOAnchorPosY(self.rectPosition.y - 10, 0.2)
	local tween2 = self.rect:DOAnchorPosY(self.rectPosition.y, 0.2)

	local sequence = DOTween.Sequence()
	sequence:Append(tween1)
	sequence:Append(tween2)
	self.opensequence = sequence
end

function CampaignInfoPanel:UpdateInfo()		
	self.mainlinecfg = CampaignProxy.Instance:GetCurMainLine()
	-- self.coinLbl.text = self:GetWord("Common_1003", GameLogicTools.GetNumStr(self.mainlinecfg.coin * 60))
	-- self.gemLbl.text = self:GetWord("Common_1003", GameLogicTools.GetNumStr(self.mainlinecfg.hero_exp * 60))
	-- self.expLbl.text = self:GetWord("Common_1003", GameLogicTools.GetNumStr(self.mainlinecfg.play_exp * 60))

	self.chaptercfg = ConfigManager.GetConfig("data_chapter")[self.mainlinecfg.chapter]
	self.chapterLbl.text = string.format("%s", self:GetWord(self.chaptercfg.name))
	self.chapterDesLbl.text = self:GetWord("CampaignView_1003", self.mainlinecfg.chapter, self.mainlinecfg.section, self.mainlinecfg.section, self.chaptercfg.total_section)	

	if not _curmainlineid then
		_curmainlineid = RoleInfoModel.mainlineid
	elseif _curmainlineid ~= RoleInfoModel.mainlineid then		
		self:ShowTips(_curmainlineid, RoleInfoModel.mainlineid)
		_curmainlineid = RoleInfoModel.mainlineid
	end		
end

function CampaignInfoPanel:ShowTips(lastmainlineid, curmainlineid)
	self.changeObj:SetActive(true)
	local lastmainlinecfg = CampaignProxy.Instance:GetMainLineCfgById(lastmainlineid)
	local curmainlinecfg = CampaignProxy.Instance:GetMainLineCfgById(curmainlineid)
	if not lastmainlinecfg or not curmainlinecfg then return end
	
	local sequence = DOTween.Sequence()
	for i,item in ipairs(self.changeitemList) do
		local movehight = 160
		if i == 1 then
			item.label_1.text = self:GetWord("Common_1003", GameLogicTools.GetNumStr(lastmainlinecfg.coin * 60))
			item.label_2.text = self:GetWord("Common_1003", GameLogicTools.GetNumStr(curmainlinecfg.coin * 60))
		elseif i == 2 then
			item.label_1.text = self:GetWord("Common_1003", GameLogicTools.GetNumStr(lastmainlinecfg.hero_exp * 60))
			item.label_2.text = self:GetWord("Common_1003", GameLogicTools.GetNumStr(curmainlinecfg.hero_exp * 60))
		end

		item.obj:SetActive(false)
		sequence:AppendCallback(function ()
			item.obj.transform.localPosition = Vector2.zero
			item.obj:SetActive(true)
		end)
		
		sequence:AppendCallback(function ()
			local tween = item.obj.transform:DOLocalMoveY(movehight, 1.8)
			tween:OnComplete(function ()
				item.obj:SetActive(false)
			end)
		end)
		sequence:AppendInterval(0.6)
	end
	-- sequence:AppendInterval(0.5)
	-- sequence:AppendCallback(function ()
	-- 	self.changeObj:SetActive(false)
	-- end)	
	self.showtipssequence = sequence
	
	local newsequence = TweenTools.SimpleScaleTween(self.areaObj, 1.5, 0.2, 0.2)
	local sequence = DOTween.Sequence()
	sequence:AppendCallback(function ()
		if self.scaneffect then
			self.scaneffect:SetOrderLayer(self.canvasDepth)
			self.scaneffect:Play()
		end
	end)
	sequence:AppendInterval(1)
	sequence:Append(newsequence)

	self.newsequence = newsequence
end

return CampaignInfoPanel