local BattleProxy = require "Modules.Battle.BattleProxy"
local BasicSceneStrategy = require "Modules.Scene.Strategy.BasicSceneStrategy"
local ActivityStrategy = ActivityStrategy or BaseClass(BasicSceneStrategy)
local isEditor = CS.UnityEngine.Application.isEditor

--迷宫
function ActivityStrategy:OnLoad()
    self.parama=self.args[1]
    self:LoadScene(nil, self.parama.map_config.scene or 24101)
end

function ActivityStrategy:Destroy()
    self:UnloadScene()
end

function ActivityStrategy:OnScenePreload(loader)
    
    if isEditor then return end

    local map_config = self.parama.map_config
    local data_build = ConfigManager.GetConfig("data_cell_build")
    local data_cell = ConfigManager.GetConfig("data_realm_cell_"..map_config.id)
    local cellinfos = self.parama.celldata.cellinfos
    for cellid, celldata in pairs(cellinfos) do
        if celldata.build ~= 0 then
            local buildcfg = data_build[celldata.build]
            if buildcfg and buildcfg.prefab_id and buildcfg.prefab_type == 1 then
                loader.AddLoad({key=buildcfg.prefab_id, type = AssetType.BUILD})
            end
        end

        if data_cell[cellid] and data_cell[cellid].prefab_id then
            loader.AddLoad({key=data_cell[cellid].prefab_id, type = AssetType.CELL})
        end
    end

end

function ActivityStrategy:OnStartEntry()
    self:DefaultOpenWidgets()
end

function ActivityStrategy:DefaultOpenWidgets()
    BattleProxy.Instance:StopGame()
    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.ItemDropView)
    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.HexMapFlyIconTitleView)
    local vv=LuaLayout.Instance:GetWidget(UIWidgetNameDef.HexMapView)
    if vv then
        vv.bShowDirection=true
        vv:OpenView()
    end
    --LuaLayout.Instance:OpenWidget(UIWidgetNameDef.HexMapView)
    local view =LuaLayout.Instance:GetWidget(UIWidgetNameDef.RealmView)
    if view then
        view.parama=self.parama
        view:OpenView()
    end
    
    --LuaLayout.Instance:OpenWidget(UIWidgetNameDef.StoryLineView)
end

return ActivityStrategy