-- 黑潮司祭·拉波尔
local conf = { skill = {}, buff = {}, bullet = {} }

-- 污水（普攻）发射一道水流
conf.skill[330201] = script.composite{
    main = {
        action = {
            default = {
                {trigger.time, {0},     caller.view.active_random,  {"attack01", "attack02"} },
                {trigger.time, {993},   action.addchild, {typeid = 330201}, "bullet_single"},
                -- {trigger.time, {933}, caller.body.addchild, {typeid = 330201}, scriptcommon.bullet_through, {speed = 8000, duration = 5000, castid = 330201} },
                {trigger.time, {567} },
            },
        },
    },
    bullet_single = {
        event = {
            {scriptevent.onstart, onfire = function(self)
                self.caller.body:addscript(scriptcommon.bullet_through, {speed = 8000, duration = 5000, castid = 330201})
            end},
            {scriptevent.ondestroy, onfire = function(self)
                self.action:addchild({typeid = 999999}, "burn")
            end},
        }
    },
    burn = {
        action = {
            default = {
                {trigger.time, {0},     action.active, "330202"},
                {trigger.time, {2000},  caller.body.destroy },
            }
        }
    }
}

-- 酸雨（必杀技）——拉波儿缓慢的双手举起法杖召唤一片酸雨，对地方阵容最密集处造成圆形半径4000的敌人造成AOE伤害 
conf.skill[330211] = script.composite{
    main = {
        action = {
            default = {
                {trigger.time, {0},     caller.view.active, "spell_01_start", caller.skill.pause, 1000},
                {trigger.time, {1000},  action.addstartbuff, action.range, script.static("id"), scriptcommon.bullet_single },
                {trigger.time, {0},     caller.view.active, "spell_01_loop",},
                {trigger.time, {4000},},
                {trigger.time, {633},   caller.view.active, "spell_01_end",},
                {trigger.time, {933}},
            },
        },
        event = {
            { scriptevent.onstart, onfire = function (self)
                self.prop.bullet_castid = self.static.id + 20
            end},
        },
    },
    bullet_single = { -- 子弹
        action = {
            default = {
                {trigger.time, {0},     caller.view.active, "330211_start"},
                {trigger.time, {1500,500,8}, caller.view.active, "330211_loop", action.cast, script.prop("bullet_castid"),},
                {trigger.time, {0},     caller.view.active, "330211_end"},
                {trigger.time, {2000},  caller.body.destroy},
            },
        },
    }
}
-- 污水喷泉（常规技能1）——召唤5次污水喷泉在敌人脚下升起并小幅度击退敌人。
conf.skill[330221] = {
    action = {
        default = {
            {trigger.time, {0},     caller.view.active , "spell_02" },
            {trigger.time, {1500},  action.cast, },
            {trigger.time, {200},   action.cast, },
            {trigger.time, {200},   action.cast, },
            {trigger.time, {200},   action.cast, },
            {trigger.time, {200},   action.cast, },
            {trigger.time, {50} },
        },
    }
}

return conf