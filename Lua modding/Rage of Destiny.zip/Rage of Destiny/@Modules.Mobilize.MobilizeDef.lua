local MobilizeDef = {}
local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
MobilizeDef.NotifyDef = {
   
    Request_Basic_Info = "Request_Basic_Info",
    Update_Mobilize_Btn = "Update_Mobilize_Btn",
    Update_Reward_State = "Update_Reward_State",
    Update_Rank_List = "Update_Rank_List",
    Update_Task_List = "Update_Task_List",
    Update_Formation = "Update_Formation",
}

MobilizeDef.CommonDef={
    CountTimeTip1 = "Mobilize_Tips_1001",
    CountTimeTip2 = "Mobilize_Tips_1002",
    Day = "Mobilize_Tips_1001_1",
    GetRewardTips = "Mobilize_Tips_1004",
    NoReward = "Mobilize_Tips_1005",
}

MobilizeDef.State={
  UnOpen = 0,
  Ready = 1,
  Duration = 2,
  End = 3,
}


MobilizeDef.RewardType ={
  Normal = 1,
  Advance = 2,
}

MobilizeDef.Reward_State ={
  UnGet = 0,
  CannotGet = 1,
  HasGet= 2,
}

MobilizeDef.Task_State = 
{
    InActive = 0, --未激活（悬赏任务初始状态）
    In_Progress = 1, --进行中
    Get_Award = 2, --可领取
    ComPlete = 3, --已领取
}

MobilizeDef.TaskType = 
{
  CollectHero = 1,--累计收集%s名精英英雄
  MainlinePassChapter = 2,--主线关卡累计通过%s关
  TowerPassLayer = 3,--赎罪之塔累计通关%层(包括种族塔)
  WinBossInDragon = 4,--击败巨龙巢穴boss%s次（通关巨龙6，16层）
  Win_Arena_Times = 5,--挑战竞技场累计胜利%s场
  Get_HighArena_Coin = 6,--高阶竞技场累计获得竞技币%s
  Chao_Reach_Diamond = 7,--混沌裂隙结算钻石及以上%s次
  Chao_Reach_Yellow = 8,--混沌裂隙结算黄金及以上%s次
  Chao_Reach_Silver = 9,--混沌裂隙结算白银及以上%s次
  Finish_Trade_Order = 10,--完成贸易航线团队订单%s个
  SendFriendLoves = 11,-- 收获%s点友情点
  LoginIn = 12,--登录%s天
}

MobilizeDef.OpenViews = {
  [MobilizeDef.TaskType.CollectHero] = {AppFacade.CardPortal},
  [MobilizeDef.TaskType.TowerPassLayer] = {AppFacade.Tower,2},
  [MobilizeDef.TaskType.WinBossInDragon] = {AppFacade.Maze},
  [MobilizeDef.TaskType.Win_Arena_Times] = {AppFacade.Arena},
  [MobilizeDef.TaskType.Get_HighArena_Coin] = {AppFacade.Arena,2},
  [MobilizeDef.TaskType.Finish_Trade_Order] = {AppFacade.SupplyDepot},
  [MobilizeDef.TaskType.SendFriendLoves] = {AppFacade.Friend},
}

MobilizeDef.OpenCondition = {
  [MobilizeDef.TaskType.CollectHero] = ModuleOpenDef.SystemOpenType.CardPortView,
  [MobilizeDef.TaskType.TowerPassLayer] = ModuleOpenDef.SystemOpenType.TowerEntranceView_0,
  [MobilizeDef.TaskType.WinBossInDragon] = ModuleOpenDef.SystemOpenType.MazeView,
  [MobilizeDef.TaskType.Win_Arena_Times] = ModuleOpenDef.SystemOpenType.ArenaEntranceView,
  [MobilizeDef.TaskType.Get_HighArena_Coin] = ModuleOpenDef.SystemOpenType.ProArenaEntranceView,
  [MobilizeDef.TaskType.Chao_Reach_Diamond] = ModuleOpenDef.SystemOpenType.GuildChaosView,
  [MobilizeDef.TaskType.Chao_Reach_Yellow] = ModuleOpenDef.SystemOpenType.GuildChaosView,
  [MobilizeDef.TaskType.Chao_Reach_Silver] = ModuleOpenDef.SystemOpenType.GuildChaosView,
  [MobilizeDef.TaskType.Finish_Trade_Order] = ModuleOpenDef.SystemOpenType.SupplyDepotView,
  [MobilizeDef.TaskType.SendFriendLoves] = ModuleOpenDef.SystemOpenType.FriendlListView,
}

return MobilizeDef