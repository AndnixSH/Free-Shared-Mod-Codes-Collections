local AudioManager = require "Common.Mgr.Audio.AudioManager"
local TweenTools =  require "Common.Util.TweenTools"
local MainDef = require "Modules.Main.MainDef"
local AudioManager = require "Common.Mgr.Audio.AudioManager"
local MainChatPanel = require "Modules.Main.MainChatPanel"
local BattleProxy = require "Modules.Battle.BattleProxy"
local CampaignProxy =require "Modules.Campaign.CampaignProxy"
local EquipProxy = require "Modules.Equip.EquipProxy"

local CampaignInfoPanel = require "Modules.Campaign.CampaignInfoPanel"
local CampaignGamePanel = require "Modules.Campaign.CampaignGamePanel"
local CampaignSystemPanel = require "Modules.Campaign.CampaignSystemPanel"
local CampaignBottomPanel = require "Modules.Campaign.CampaignBottomPanel"

local NewbieManager = require "Modules.Newbie.NewbieManager"
local TouchRender = require "Core.Implement.UI.Class.TouchRender"
local Timer = require "Common.Util.Timer"
local CampaignDef = require "Modules.Campaign.CampaignDef"

local CampaignView = CampaignView or LuaWidgetClass()
function CampaignView:__init()
end

function CampaignView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Campaign.CampaignView",self.LoadEnd)
end

function CampaignView:LoadEnd(obj)
	self:SetGo(obj)

	self.campaignInfoPanel = CampaignInfoPanel.New(self:GetChild(obj, "left"))
	self.campaignGamePanel = CampaignGamePanel.New(self:GetChild(obj, "middle"))
	-- self.campaignSystemPanel = CampaignSystemPanel.New(self:GetChild(obj, "right"))
	self.campaignBottomPanel = CampaignBottomPanel.New(self:GetChild(obj, "bottom"))

	self.fastColiderObj = self:GetChild(obj, "colider")
   	self.itemboxcollider = self:GetChildComponent(obj, "colider", "CBoxCollider")
   	self.itemboxcollider:AddClick(function(go)
   	    self:OnClickFast()
   	end)	


   	self.posObj = self:GetChild(obj, "EmptyObjPos")
   	self.rootPos = self.posObj.transform.localPosition
   	
   	--temp
	local btn = self:GetChildComponent(obj, "CButton_test", "CButton")
	btn:AddClick(function ()
		local SceneManager = require "Modules.Scene.SceneManager"
		local SceneDef = require "Modules.Scene.SceneDef"        
        SceneManager.Instance:EnterScene(SceneDef.SceneType.Temple)		
	end)

	local towerBtn = self:GetChildComponent(obj, "CButton_test2", "CButton")
	towerBtn:AddClick(function()
		LuaLayout.Instance:OpenWidget(UIWidgetNameDef.TowerEntranceView)
	end)

	local cardportalBtn = self:GetChildComponent(obj, "CButton_test3", "CButton")
	cardportalBtn:AddClick(function()
		UIOperateManager.Instance:OpenWidget(AppFacade.CardPortal, 1)
	end)

	local copybtn = self:GetChildComponent(obj, "CButton_test4", "CButton")
	copybtn:AddClick(function()
		LuaLayout.Instance:OpenWidget(UIWidgetNameDef.StoryLineRootView)
	end)
	self.mainChatPanel = MainChatPanel.New(self:GetChild(obj, "Talk"))
	
	self.touchRender = TouchRender.New()
	self.touchRender:SetClickCallback(function (position)
			self:OnTouchClick(position)
		end)
	
	self:SetStep(0)
end

function CampaignView:_CheckNewbieTrigger()
	NewbieManager.Instance:TriggerNewbie()
end

function CampaignView:OnOpen()
	self:AutoRegister()
	self.campaignInfoPanel:Open()
	self.campaignGamePanel:Open()

	self:SetMainViewChatObjDepth()
	
	-- self.campaignSystemPanel:Open()
	self.campaignBottomPanel:Open()

	self:_CheckNewbieTrigger()

	-- local heroRedDot = EquipProxy.Instance:GetHeroTabRedDot()
	-- self.campaignBottomPanel:ShowRedDot(MainDef.MainRedDotType.Hero, heroRedDot)
	self:CheckRedDot()
	if self.showstate then
		self:SetMiddleAndLeftObjShowState(self.showstate.show ,self.showstate.widgetname)
		self.showstate = false
	end
	self.mainChatPanel:Open()
	
	if self:CheckShowBattleClickGuide() then
		self.touchRender:Start()
	end
end

--设置聊天小窗层级， 被自动挂机相应区间
function CampaignView:SetMainViewChatObjDepth()
	-- local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MainView)
	-- if view and view:IsOpen() then
	-- 	view:SetChatObjDepth()
	-- end

	self.mainChatPanel:SetChatObjDepth()
end

function CampaignView:OnClose()
	self:AutoUnRegister()
	self.campaignInfoPanel:Close()
	self.campaignGamePanel:Close()
	self.campaignBottomPanel:Close()
	-- self.campaignSystemPanel:Close()
	self:ClickFastCallBack()
	self.mainChatPanel:Close()
	
	self:CloseClickTimer()
	self.touchRender:Stop()
end

function CampaignView:UpdateDepth(depth)
	local nextdepth=depth
	GameObjTools.SetDepth(self.go,nextdepth)
	nextdepth=nextdepth+1
	-- self.campaignSystemPanel:UpdateDepth(nextdepth)
	self:SetMainViewChatObjDepth()
end

function CampaignView:OnDestroy()
	self:AutoUnRegister()
	self.campaignInfoPanel:Destroy()
	self.campaignGamePanel:Destroy()
	self.campaignBottomPanel:Destroy()
	-- self.campaignSystemPanel:Destroy()
	self:ClickFastCallBack()
	self:ClearDropSequence()
	self.mainChatPanel:Destroy()
	
	self:CloseClickTimer()
	self.touchRender:Stop()
end

function CampaignView:ClickFastCallBack()
	if self.fastTimer then
		self:RemoveTimer(self.fastTimer)
		self.fastTimer = nil
	end		
	if self.fastcallback then
		self.fastcallback = nil
	end
end

function CampaignView:ShowOpenTween()	
	self.campaignInfoPanel:StartOpenTween()
	self.campaignGamePanel:StartOpenTween()
	-- self.campaignSystemPanel:StartOpenTween()
	self.campaignBottomPanel:StartOpenTween()
	self.mainChatPanel:StartOpenTween()
	
	if self:CheckShowBattleClickGuide() then
		self:StartClickTimer()
	end
end

function CampaignView:CheckRedDot()
	CampaignProxy.Instance:Send51002()
end

function CampaignView:ShowRedDot(redtype, rednum)
	if redtype == MainDef.MainRedDotType.FreeFastReward then
		self.campaignGamePanel:ShowRedDot(redtype, rednum)
	-- elseif redtype == MainDef.MainRedDotType.Hero then
	-- 	-- self.campaignSystemPanel:ShowRedDot(redtype, rednum)
	-- 	self.campaignBottomPanel:ShowRedDot(redtype, rednum)
	end	
end	

--快速挂机表现
function CampaignView:FastRewardGetStart(rewards)	
	self.fastTime = os.time()	
    BattleProxy.Instance:SpeedGame(1)
    AudioManager.SetBGMPitch(1)
    self.fastcallback = function ()
    	self:FastRewardGetEnd(rewards)
    end
    self.fastTimer = self:AddTimer(function ()
    	if self.fastcallback then
    		self.fastcallback()
    		self.fastcallback = nil
    	end
    end, 0.5, 1)
    self.fastColiderObj:SetActive(true)
end

function CampaignView:FastRewardGetEnd(rewards)
	GameLogicTools.ShowGetItemView(rewards)
    BattleProxy.Instance:SpeedGame(1)
    AudioManager.SetBGMPitch(1)
    self.fastColiderObj:SetActive(false)
end

--end

--onclick
function CampaignView:OnClickFast()
	if os.time() - self.fastTime < 0 then
		GameLogicTools.ShowMsgTips("msgtips_Campaign_1001")
	else
		if self.fastTimer then
			self:RemoveTimer(self.fastTimer)
			self.fastTimer = nil
		end	
		if self.fastcallback then
    		self.fastcallback()
    	end
    	self.fastcallback = nil		
	end	
end

--notify
--更新红点
function CampaignView.EvtNotify.Main.data:UpdateRedDot(data, args)
    self:ShowRedDot(args.type, args.rednum)
end

function CampaignView.EvtNotify.Campaign.data:GetFastHangUpReward(data,args)
	self:FastRewardGetStart(args)    
end

function CampaignView.EvtNotify.Campaign.data:GetHangUpReward(data,args)
	self.coinCount = 0
	self.gemCount = 0
	self.expCount = 0
	self.goodsList = {}
	if args and args.rewards then
		for i,v in ipairs(args.rewards) do
			self:ShowGoodsList(v.goodsid, v.goodsnum)
		end
		self:ShowDropItem()
	end
end

function CampaignView.EvtNotify.Guild.data:UpdateBossSweepReward(data, args)
	self.campaignBottomPanel:SetTerritoryRedDot()
end

function CampaignView.EvtNotify.Newbie.data:Newbie_Notify(data, args)
	--print("CampaignView Newbie_Notify===========", table.dump(args))
end

function CampaignView.EvtNotify.RoleInfo.data:RoleInfo_Update(data, args)
    local CrystalProxy = require "Modules.Crystal.CrystalProxy"
    CrystalProxy.Instance:UpdateCrystalRedDot()
	
	self.campaignBottomPanel:UpdateBtnState()
end


function CampaignView:ShowGoodsList(goodsid, goodsnum)
	-- print("goodsid, goodsnum==", goodsid, goodsnum)
	if goodsid == 702001 then
		--金币
		self.coinCount = self.coinCount + goodsnum
	elseif goodsid == 701001 then
		--钻石
		self.gemCount = self.gemCount + goodsnum
	elseif goodsid == 703001 then
		--账号经验
		self.expCount = self.expCount + goodsnum
	else
		table.insert(self.goodsList, {goodsid, goodsnum})
	end	
end

--飞货币排列 循序
function CampaignView:ShowDropSequence(seqDatas)
	self:ClearDropSequence()
	local _interval = 0.35
	self.dropSeq = DOTween.Sequence()
	for i,_data in ipairs(seqDatas) do
		self.dropSeq:AppendCallback(function()
			if _data[1] == 0 then
				GameLogicTools.ShowExpDrop(_data[2], _data[3])
			elseif _data[1] == 1 then
				GameLogicTools.ShowCoinDrop(_data[2], _data[3])
			elseif _data[1] == 2 then
				GameLogicTools.ShowGemDrop(_data[2], _data[3])
			end
		end)
		self.dropSeq:AppendInterval(_interval)
	end
end

function CampaignView:ShowDropItem()
	local BagProxy = require "Modules.Bag.BagProxy"
	self.seqDatas = {}  --{fromPos, toPos, targetObj, count}
	--金币
	if self.coinCount and self.coinCount > 0 then
		local offsetPos = Vector3.New(170, -150, 0)
		self.posObj.transform.localPosition = self.rootPos + offsetPos
		local fromPos = self.posObj.transform.position
		table.insert(self.seqDatas, {1, fromPos, self.coinCount})
	end

	--钻石
	if self.gemCount and self.gemCount > 0 then
		local offsetPos = Vector3.New(235, -100, 0)
		self.posObj.transform.localPosition = self.rootPos + offsetPos
		local fromPos = self.posObj.transform.position
		table.insert(self.seqDatas, {2, fromPos, self.gemCount})
	end

	--英雄经验
	if self.expCount and self.expCount > 0 then
		local offsetPos = Vector3.New(150, -190, 0)
		self.posObj.transform.localPosition = self.rootPos + offsetPos
		local fromPos = self.posObj.transform.position
		table.insert(self.seqDatas, {0, fromPos, self.expCount})	
	end

	self:ShowDropSequence(self.seqDatas)

	--进背包物品
	if self.goodsList and #self.goodsList > 0 then
		local _pos = self.go.transform.position
		local pos = Vector3.New(_pos.x, _pos.y, 0)
		self:ShowBagItemDrop(self.goodsList, pos, nil, func)
	end
end

--飞背包图标 飞向主界面背包图标或者itemdropview 里的bagitem
function CampaignView:ShowBagItemDrop(goodsList, pos, to, func)
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MainView)
	if view and view:IsOpen() then
		GameLogicTools.ShowGoodsDrop(goodsList, pos, to, func)
	else
		GameLogicTools.ShowAwardGoodsDrop(goodsList, pos, to, func)
	end
end


function CampaignView:ClearDropSequence()
	if self.dropSeq then
		self.dropSeq:Kill()
		self.dropSeq = nil
	end
end

function CampaignView:SetMiddleAndLeftObjShowState(show,widgetname)

	-- self.campaignInfoPanel:SetActive(show)
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.CampaignView)
	if view and view:IsOpen()  then
		self.campaignGamePanel:SetActive(show)
		local index = 1
		if widgetname and widgetname == UIWidgetNameDef.FieldView then
			index=2
		end
		self.campaignBottomPanel:SceneToMainSceneSelectItem(show == true and 4 or index )
		if show then
			self:_CheckNewbieTrigger()
		end
	else
		self.showstate={show =show,widgetname = widgetname}
	end
	
end

--选中底部栏第几个
function CampaignView:SelectBottomItem(index)
	self.campaignBottomPanel:OnClickBtn(index)
end

function CampaignView:OpenMazeCompleteNewbie()
	self.campaignBottomPanel:OpenMazeCompleteNewbie()
end

function CampaignView:OnTouchClick(position)
	self.lastClickTime = os.time()
	self.campaignGamePanel:CloseNextChapterGuideEffect()
	
	self:CloseClickTimer()
end

function CampaignView:StartClickTimer()
	self.lastClickTime = os.time()
	self:CloseClickTimer()
	local check = function()
		local heroTipsView = LuaLayout.Instance:GetWidget(UIWidgetNameDef.HeroTipsView)
		if (heroTipsView and heroTipsView:IsOpen()) or (not self.campaignGamePanel:IsActive()) then
			self:CloseClickTimer()
			return
		end
		
		local num = os.difftime(os.time(), self.lastClickTime)
		local show = (num >= CampaignDef.Const.BattleClickGuideTime) and (not NewbieManager.Instance:IsNewbieViewOnOpen())
		if show then
			self:CloseClickTimer()
			self.campaignGamePanel:DoShowNextChapterGuideEffect()
		end
	end
	self.clickTimer = Timer.New(check, 1, math.maxinteger)
	self.clickTimer:Start()
end

function CampaignView:CheckShowBattleClickGuide()
	local cfg = CampaignProxy.Instance:GetCurMainLine()
	return cfg and (CampaignDef.Const.BattleClickGuideChapter[cfg.chapter])
end

function CampaignView:CloseClickTimer()
	if self.clickTimer then
		self.clickTimer:Stop()
		self.clickTimer = nil
	end
end

function CampaignView.EvtNotify.Guild.data:UpdateGuildInfos(data, args)
	-- 公会信息拉取后再去请求聊天信息 否则获取不到公会聊天信息
	--print("--------------MainView.EvtNotify.Guild.data:UpdateGuildInfos-----------------")
	local ChatProxy = require "Modules.Chat.ChatProxy"
	self.mainChatPanel:Chat_UpdateSelectTitle()
	ChatProxy.Instance:Send31003()
end

function CampaignView.EvtNotify.Guild.data:UpdateKickOutGuild(data, args)
	-- 公会信息拉取后再去请求聊天信息 否则获取不到公会聊天信息
	--print("--------------MainView.EvtNotify.Guild.data:UpdateGuildInfos-----------------")
	local ChatProxy = require "Modules.Chat.ChatProxy"
	self.mainChatPanel:Chat_UpdateSelectTitle()
	ChatProxy.Instance:Send31003()
end


function CampaignView.EvtNotify.Chat.data:Chat_UpdateTitleList(data,info)
	self.mainChatPanel:Chat_UpdateTitleList(info)
end

function CampaignView.EvtNotify.Chat.data:Chat_UpdateTitleList(data,info)
	self.mainChatPanel:Chat_UpdateTitleList(info)
end

function CampaignView.EvtNotify.Chat.data:Chat_UpdateNewEffect(data,args)
	self.mainChatPanel:UpdateNewEffect(args)
end

function CampaignView.EvtNotify.Chat.data:Chat_UpdateSelectTitle(data,args)
	self.mainChatPanel:Chat_UpdateSelectTitle()
end

function CampaignView.EvtNotify.Campaign.data:NotifyBoxRewardViewClose(data,args)
	if self:CheckShowBattleClickGuide() then
		self:StartClickTimer()
	end
end

return CampaignView