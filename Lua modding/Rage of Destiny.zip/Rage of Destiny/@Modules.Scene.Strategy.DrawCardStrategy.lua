local BattleProxy = require "Modules.Battle.BattleProxy"
local BasicSceneStrategy = require "Modules.Scene.Strategy.BasicSceneStrategy"
local DrawCardStrategy = DrawCardStrategy or BaseClass(BasicSceneStrategy)

--抽卡
function DrawCardStrategy:OnLoad()
    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.NetworkDelayView)
    local sceneId = 5041
    self.selectIdx = self.args[1] or 1
    self:LoadScene(sceneId)
end

function DrawCardStrategy:Destroy()
    self:UnloadScene()
    BattleProxy.Instance:StopGame()
end

function DrawCardStrategy:OnLoadSceneEnd()
    local args = {}
    args.bone = "20009/chouka_camerapoint/chouka_camerapoint"
    local render_camera = require "Battle.render.camera.render_camera"
    render_camera.set_camera_field_of_view(65)

    local rootObj = AssetManager.GetActiveSceneRootObject()
    local camera_position_obj = GameObjTools.GetChild(rootObj, "chouka_camerapoint/chouka_camerapoint")

    render_camera.set_bone_trunk_strategy(camera_position_obj, args)
end

function DrawCardStrategy:OnStartEntry()
    self:DefaultOpenWidgets()
end

function DrawCardStrategy:OnScenePreload(loader)
    local CardPortalProxy = require "Modules.CardPortal.CardPortalProxy"
    local res_list = CardPortalProxy.Instance:GetCardPortal_PreLoaderRes()
    -- print("res_list========", table.dump(res_list))
    for i,_res in ipairs(res_list) do
        loader.AddLoad({key=_res[1], type = AssetType.EFFECT, count= _res[2]})
    end

end

function DrawCardStrategy:DefaultOpenWidgets()
    BattleProxy.Instance:StopGame()
    local CardPortalView = require "Modules.CardPortal.CardPortalView"
    CardPortalView.SelectIdx = self.selectIdx
    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.ItemDropView)
    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.CardPortalView)
    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.NetworkDelayView)
end

return DrawCardStrategy