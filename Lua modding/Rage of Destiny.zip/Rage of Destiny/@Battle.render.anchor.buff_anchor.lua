local buff_anchor = buff_anchor or BaseClass()

local CBuffAnchor = CS.LJY.NX.BuffAnchor

function buff_anchor:__init(model, header_type, bone)
    self.canchor = CBuffAnchor(model, header_type, bone or "")
end

function buff_anchor:__delete()
    self.canchor = nil
end

return buff_anchor