local MallDef = require "Modules.Mall.MallDef"
local MallProxy = require "Modules.Mall.MallProxy"
local ObjPoolRender = require "Core.Implement.UI.Class.ObjPoolRender"
local ObjPoolItem = require "Core.Implement.UI.Class.ObjPoolItem"
local GoodsItem = require "Core.Implement.UI.Class.GoodsItem"
local DateFormatUtil = require "Common.Util.DateFormatUtil"
local UISpineView = require "Core.Implement.UI.Class.UISpineView"
local GameUIUtil = CS.GameUIUtil
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"

local discountConfig = {
	[700] = "tuisong_700",
	[999] = "tuisong_999",
}

local moveConfig = {
	pos1 = Vector2.New(0,-50), pos2 = Vector2.New(0,-20),
	pos3 = Vector2.New(0,-151), pos4 = Vector2.New(0,-121),
	pos5 = Vector2.New(0,-242), pos6 = Vector2.New(0,-212),
}
local scale1 = Vector3.New(1.2, 1.2, 1.2)
local scale2 = Vector3.New(1, 1, 1)

local GoodsPoolItem = GoodsPoolItem or BaseClass(ObjPoolItem)
function GoodsPoolItem:Load(obj)
	self.goodsItem = GoodsItem.New(self:GetChild(obj, "GoodsItem"))
	self.goodsItem:SetClickOpenInfo()
end

function GoodsPoolItem:SetData(data)
	self.data = data
	self.goodsItem:SetData(data[1], data[2])
end

function GoodsPoolItem:ShowEffect()
	--紫色英雄显示转圈特效,参考GetItemView
   	local BagProxy = require "Modules.Bag.BagProxy"
	local BagDef = require "Modules.Bag.BagDef"
	local cfg = BagProxy.Instance:GetGoodsCfgById(self.data[1])

	if cfg and cfg.quality and cfg.subtype then
		if (cfg.subtype == BagDef.SubType.Elite_Hero_Card or cfg.subtype == BagDef.SubType.Rare_Hero_Card) then
			self.goodsItem:ShowQualityCircleEffectLoop(cfg.quality)
			self:GetNextDepth()
		end
	end
end

function GoodsPoolItem:HideEffect()
	self.goodsItem:HideNormalEffect()
end

local PagePoolItem = PagePoolItem or BaseClass(ObjPoolItem)
function PagePoolItem:Load(obj)
	self.pageObj = self:GetChild(obj, "CSprite_page")
	self.pageSp = self:GetChildComponent(self.pageObj, "CSprite_point", "CSprite")

	local btn = self:GetComponent(self.pageObj, "CButton")
	btn:AddClick(function ()
		-- print(self.view.selectIndex, self.index)
		if self.view.selectIndex ~= self.index then
			self.view.selectIndex = self.index
			self.view:UpdateInfo()
			
			self.view:ShowAniBefore()
			self.view:ShowAni()
		end
	end)
end

function PagePoolItem:SetData(data)
	self.index = data

	local isSel = self.view.selectIndex == data
	-- print(self.view.selectIndex)

	self.pageSp.SpriteName = isSel and "page1" or "page0"
end

-------------------------
local MallPushView = MallPushView or LuaWidgetClass()

function MallPushView:__init()
	self.selectIndex = nil
	self.leftTime = 0
end

function MallPushView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Mall.MallPushView", self.LoadEnd)
end

function MallPushView:LoadEnd(obj)
	self:SetGo(obj)
	self:Init(obj)
    self:SetStep(0)
end

function MallPushView:Init(obj)
	self.blackObj = self:GetChild(obj, "black")
	self.backTra = self:GetChildComponent(obj, "back", "Transform")
	self.descLb = self:GetChildComponent(obj, "back/condiction/CLabel_condition", "CLabel")
	self.descSp = self:GetChildComponent(obj, "back/dec/CSprite_num", "CSprite")
	self.timeLb = self:GetChildComponent(obj, "back/CLabel_time", "CLabel")
	self.priceLb = self:GetChildComponent(obj, "back/buy/CButton_buy/label", "CLabel")

	self.conTra = self:GetChildComponent(self.backTra, "condiction", "Transform")
	self.descRectTra = self:GetChildComponent(self.backTra, "dec", "RectTransform")
	self.rewardRectTra = self:GetChildComponent(self.backTra, "CHorizontalItem", "RectTransform")
	self.timeRectTra = self:GetChildComponent(self.backTra, "CLabel_time", "RectTransform")
	self.buyBtnTra = self:GetChildComponent(self.backTra, "buy", "Transform")

	local goodsObj = self:GetChild(obj, "back/CHorizontalItem/item1")
	self.goodsPoolRender = ObjPoolRender.New()
	self.goodsPoolRender:Load(goodsObj, goodsObj.transform.parent, GoodsPoolItem)

	local pageObj = self:GetChild(obj, "back/CHorizontalItemPage/item1")
	self.pagePoolRender = ObjPoolRender.New()
	self.pagePoolRender:Load(pageObj, pageObj.transform.parent, PagePoolItem)
	PagePoolItem.view = self

	self.spineView = UISpineView.New(self:GetChild(obj, "back/spineRoot"))

	--滑动
	local listener = CS.EventTriggerListener.Get(self:GetChild(obj, "back/CTexture_area"))
	
	listener:onBeginDragPara("+", function (eventData)
		self.beginDragPosX = eventData.position.x
		-- print("onBeginDragPara", self.beginDragPosX)
	end)

	listener:onEndDragPara("+", function (eventData)
		-- print("onEndDragPara")
		local offset = 0
		if eventData.position.x > self.beginDragPosX then --向右划
			offset = -1
		else
			offset = 1
		end
		self:ChangePage(offset)
	end)
	
	--按钮
	local btn

	btn = self:GetChildComponent(obj, "black", "CButton")
	btn:AddClick(function ()
		LuaLayout.Instance:CloseWidget(UIWidgetNameDef.MallPushView)
	end)

	btn = self:GetChildComponent(obj, "back/buy/CButton_buy", "CButton")
	btn:AddClick(function ()
		MallProxy.Instance:Buy(self.pushGift.id)
	end)
	self.buyBtnObj = btn.gameObject

	--特效
	self.boxEffect = UIEffectItem.New("UI_tuisong_box1", self.blackObj)
	self.boxEffect2 = UIEffectItem.New("UI_tuisong_box2", self.backTra.gameObject)
	self.buyBtnEffect = UIEffectItem.New("UI_mall_button", self.buyBtnObj)
end

function MallPushView:OnOpen()
	self:AutoRegister()

	local nextDepth = self:GetNextDepth()
	-- self.nextDepth = nextDepth

	MallProxy.Instance:SortPush()
	self.mall = MallProxy.Instance:GetMall(MallDef.Type.Push)

	if self.selectGiftId then
		for i,v in ipairs(self.mall) do
			if v.giftId == self.selectGiftId then
				self.selectIndex = i
				break
			end
		end
		self.selectGiftId = nil
	end

	self.selectIndex = self.selectIndex or 1

	self:UpdateInfo()

	local timeFunc = function ()
		-- self.leftTime = self.leftTime - 1
		self:UpdateLeftTime()
		self:UpdateLeftTimeText()
		if self.leftTime <= 0 then
			LuaLayout.Instance:CloseWidget(UIWidgetNameDef.MallPushView)
		end
	end
	self.timer = self:AddTimer(timeFunc)

	local spineParama = {position = {-69,-356, 0}, scale = 0.62, rotation = 0, active = "animation"}
	self.spineView:SetModel("UI_1113031_push", spineParama, "animation")

	--动画
	self:ShowAniBefore()
	self.backTra.localScale = Vector3.zero
	if self.backTween then
		self.backTween:Kill()
	end
	self.backTween = self.backTra:DOScale(1, 0.2)
	self.backTween:OnComplete(function ()
		self:ShowAni()
	end)

	self.boxEffect:Open()
	self.boxEffect2:Open()
	self.buyBtnEffect:Open()

	GameObjTools.SetDepth(self.blackObj, nextDepth)
	GameObjTools.SetDepth(self.backTra.gameObject, nextDepth + 2)

	self:GetNextDepth(10)
end

function MallPushView:AddScaleAni(tra)
	local tween1 = tra:DOScale(scale1, 0.2):SetEase(Ease.InBack)
	local tween2 = tra:DOScale(scale2, 0.2):SetEase(Ease.OutBack)
	return tween1, tween2
end

function MallPushView:AddMoveAni(rectTra, startPos, endPos)
	rectTra.anchoredPosition = startPos
	local tween1 = rectTra:DOAnchorPos(endPos, 0.1, false)
	tween1:OnStart(function ()
		GameUIUtil.SetGroupAlphaInTime(rectTra.gameObject, 1, 0.2)
	end)
	return tween1
end

function MallPushView:ShowAniBefore()
	self.conTra.localScale = Vector3.zero
	self.buyBtnTra.localScale = Vector3.zero
	GameUIUtil.SetGroupAlpha(self.descRectTra.gameObject, 0)
	GameUIUtil.SetGroupAlpha(self.rewardRectTra.gameObject, 0)
	GameUIUtil.SetGroupAlpha(self.timeRectTra.gameObject, 0)
	self.goodsPoolRender:ExecuteMethod("HideEffect")
end

function MallPushView:ShowAni()
	if self.seq then
		self.seq:Kill()
	end
	
	local tween1, tween2 = self:AddScaleAni(self.conTra)

	local moveTween1 = self:AddMoveAni(self.descRectTra, moveConfig.pos1, moveConfig.pos2)
	local moveTween2 = self:AddMoveAni(self.rewardRectTra, moveConfig.pos3, moveConfig.pos4)
	local moveTween3 = self:AddMoveAni(self.timeRectTra, moveConfig.pos5, moveConfig.pos6)
	moveTween2:OnComplete(function ()
		self.goodsPoolRender:ExecuteMethod("ShowEffect")
	end)

	local tween3, tween4 = self:AddScaleAni(self.buyBtnTra)

	local sequence = DOTween.Sequence()
	
	sequence:Append(tween1)
	sequence:Append(tween2)

	sequence:Append(moveTween1)
	sequence:Append(moveTween2)
	sequence:Append(moveTween3)

	sequence:Append(tween3)
	sequence:Append(tween4)

	self.seq = sequence
end

function MallPushView:OnClose()
	self:AutoUnRegister()

	if self.spineView then
		self.spineView:Close()
		self.spineView:Release()
	end

	if self.timer then
		self:RemoveTimer(self.timer)
		self.timer = nil
	end

	-- print("MallPushView:OnClose", debug.traceback())

	self.boxEffect:Close()
	self.boxEffect2:Close()
	self.buyBtnEffect:Close()
end

function MallPushView:OnDestroy()
	if self.spineView then
		self.spineView:Destroy()
		self.spineView = nil
	end

	self:AutoUnRegister()

	self.boxEffect:Destroy()
	self.boxEffect2:Destroy()
	self.buyBtnEffect:Destroy()
end

--更新剩余时间
function MallPushView:UpdateLeftTime()
	if self.pushGift then
		self.leftTime = MallProxy.Instance:GetPushLeftTime(self.pushGift.id)
	end
end

function MallPushView:UpdateLeftTimeText()
	local str = DateFormatUtil.formatTickTime(self.leftTime or 0)
	self.timeLb.text = self:GetWord(MallDef.LanguageKey.MallPushView1, str)
end

function MallPushView:UpdateInfo()
	local mallItem = self.mall[self.selectIndex]

	if mallItem then
		local id = mallItem.id
		local giftId = mallItem.giftId
		local pushGift = MallProxy.Instance:GetPushGift(giftId)

		if pushGift and id then
			local reward = pushGift.reward

			local config = MallProxy.Instance:GetConfigById(MallDef.Type.Push, id)
			local giftConfig = MallProxy.Instance:GetGiftConfigById(giftId)
			local price = MallProxy.Instance:GetProductPrice(giftId)

			self.pushGift = pushGift

			self:UpdateLeftTime()
			self:UpdateLeftTimeText()

			self.descLb.text = self:GetWord(config.desc)
			self.descSp.SpriteName = discountConfig[giftConfig.discount]
			self.priceLb.text = price
			
			--奖励
			self.goodsPoolRender:ReleaseAll()
			for i=1,#reward do
				self.goodsPoolRender:Get(reward[i])
			end

			--页签
			self.pagePoolRender:ReleaseAll()
			if #self.mall > 1 then
				for i=1,#self.mall do
					self.pagePoolRender:Get(i)
				end
			end
		end
	end
end

function MallPushView:ChangePage(offset)
	local count = #self.mall
	if count > 1 then
		local index = self.selectIndex + offset
		if index > count then
			index = 1
		elseif index == 0 then
			index = count
		end
		self.selectIndex = index
		self:UpdateInfo()
	
		self:ShowAniBefore()
		self:ShowAni()
	end
end

return MallPushView