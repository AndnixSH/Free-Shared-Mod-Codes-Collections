local UISpineBase = require "Core.Implement.UI.Class.UISpineBase"
local UISpineView = BaseClass(UISpineBase)

function UISpineView:OnOpen()
    -- print("OnOpen")

end

function UISpineView:OnClose()
    -- print("OnClose")
end

function UISpineView:OnDestroy()
    -- print("OnDestroy")
end

return UISpineView