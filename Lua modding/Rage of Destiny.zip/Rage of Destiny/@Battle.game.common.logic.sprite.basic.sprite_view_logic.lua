local logic = {call = service.call(calldef.view), timer = {}}
local viewcmd = {}
local tunpack = table.unpack

function logic:oncreate()
    self._replace = {}
    self._viewkeylist = {}
    self._viewstartqueue = {}
    self._viewendqueue = {}
    self._key = 0
end

function logic:genkey()
    self._key = self._key + 1
    return self._key
end

function logic.call:start_active(activename, speed, tag)
    activename = self._replace[activename] or activename
    if not speed and self.caller.skill and self.caller.skill.getcurslotspeed then
        speed = self.caller.skill:getcurslotspeed()
    end
    -- print(self.owner, activename, debug.traceback())
    if not self.caller.state or not self.caller.state:isdead() then --todo有问题
        tag = tag or self.service.area:gettag(self.owner.prop.camp)
        self:sendmessage(eventdef.start_active, activename, speed, tag or 0)
    end
    return true
end

-- 战斗sct飘字
function logic.call:battlesct(fromobj, toobj, state, ...)
    local sct_args = { fromid = fromobj.uid, fromcamp = fromobj.prop.camp, 
                       toid = toobj.uid, tocamp = toobj.prop.camp, 
                       state = state  }
    self:sendmessage(eventdef.damagesct, sct_args, ...)
end

-- 播放一个active
function logic.call:active(activename, speed, tag)
    return self.call.start_active(self, activename, speed, tag)
end

-- 随机播放一个active
function logic.call:active_random(activelist, speed, tag)
    local activename = activelist[tsmath.random(#activelist)]
    return self.call.start_active(self, activename, speed, tag)
end

-- 替换active
function logic.call:replace_active(activename, replacename)
    self._replace[activename] = replacename
end

function logic.call:start_view(viewkey, viewtables, level)
    level = level or 1
    -- print('startview', viewkey, level)
    if self._viewkeylist[viewkey] then
        self.call.stop_view(self, viewkey)
    end
    self._viewkeylist[viewkey] = self._viewkeylist[viewkey] or {}
    local lesslv = nil
    for _, value in ipairs(viewtables) do
        local configlv = value[5] -- 配置的等级
        
        if not configlv or configlv == level then
            self:_start_view(viewkey, value)
            lesslv = nil
        elseif configlv < level then
            lesslv = configlv
        end
    end

    if lesslv then
        for _, value in ipairs(viewtables) do
            local configlv = value[5] -- 配置的等级
            if lesslv == configlv then
                self:_start_view(viewkey, value)
            end
        end
    end
    
end

function logic:_start_view(viewkey, viewconfig)
    local cmdid, time, stoptime, viewtable, level = tunpack(viewconfig)
    -- print("_start_view", level)
    if viewcmd[cmdid] then
        if time > 0 then
            table.insert(self._viewstartqueue, {viewkey = viewkey, cur = 0, time = time, cmdid = cmdid, viewtable = viewtable, stoptime = stoptime})
        else
            self:_startviewcmd(viewkey, cmdid, viewtable, stoptime)
        end
    else
        global.debug.warning("不支持的viewid", cmdid)
    end
end

function logic:_startviewcmd(viewkey, cmdid, viewtable, stoptime)
    local keylist = self._viewkeylist[viewkey]
    if keylist then
        local key = viewcmd[cmdid].start(self, viewtable)
        -- gamelog.debug('startviewcmd', cmdid, key)
        local view = {viewkey = viewkey, cur = 0, time = stoptime, cmdid = cmdid, key = key}
        table.insert(keylist, view)
        if stoptime then
            table.insert(self._viewendqueue, view)
        end
    end
end

function logic:_stopviewcmd(viewkey, cmdid, key)
    local keylist = self._viewkeylist[viewkey]
    if keylist then
        local cmd = assert(viewcmd[cmdid])
        if key and cmd.stop then
            -- gamelog.debug('stopviewcmd', cmdid, key)
            cmd.stop(self, key)
        end
    end
end

function logic.call:stop_view(viewkey)
    -- gamelog.debug('stopview', viewkey)
    local keylist = self._viewkeylist[viewkey]
    if keylist then
        for _, value in ipairs(keylist) do
            if not value.time or value.cur < value.time then
                self:_stopviewcmd(viewkey, value.cmdid, value.key)
            end
        end
    end
    self._viewkeylist[viewkey] = nil
end

function logic.timer:f1(time, tick)
    for i = #self._viewstartqueue, 1, -1 do
        local view = self._viewstartqueue[i]
        view.cur = view.cur + tick
        if view.cur >= view.time then
            self:_startviewcmd(view.viewkey, view.cmdid, view.viewtable, view.stoptime)
            table.remove(self._viewstartqueue, i)
        end
    end

    for i = #self._viewendqueue, 1, -1 do
        local view = self._viewendqueue[i]
        view.cur = view.cur + tick
        if view.cur >= view.time then
            self:_stopviewcmd(view.viewkey, view.cmdid, view.key)
            table.remove(self._viewendqueue, i)
        end
    end
end

viewcmd = {
    [1] = {
        start = function(self, viewtable)
            local modelname, header_type, bone, has_tail = tunpack(viewtable)
            local key = self:genkey()
            self:sendmessage(eventdef.add_model, key, modelname, {header_type = header_type, bone = bone, has_tail = has_tail})
            return key
        end,
        stop = function(self, key)
            self:sendmessage(eventdef.remove_model, key)
        end
    },
    [2] = {
        start = function(self, viewtable)
            local colortable = viewtable
            local key = self:genkey()
            self:sendmessage(eventdef.add_color, key, colortable)
            return key
        end,
        stop = function(self, key)
            self:sendmessage(eventdef.remove_color, key)
        end
    },
    [3] = {
        start = function(self, viewtable)
            local colortable = viewtable
            local key = self:genkey()
            self:sendmessage(eventdef.add_rim_color, key, colortable)
            return key
        end,
        stop = function(self, key)
            self:sendmessage(eventdef.remove_rim_color, key)
        end
    },
    [4] = {
        start = function(self, viewtable)
            local icon_name, time = tunpack(viewtable)
            self:sendmessage(eventdef.add_icon, icon_name, time)
            return icon_name
        end,
        stop = function (self, key)
            self:sendmessage(eventdef.remove_icon, key)
        end
    },
    [5] = {
        start = function(self, viewtable)
            local modelname, header_type, bone = tunpack(viewtable)
            self:sendmessage(eventdef.add_active_model, modelname, {header_type = header_type, bone = bone}, {})
        end
    },
    [6] = {
        start = function (self, viewtable)

            if self.owner.prop.camp == CAMP.RED and global.game.gameid ~= GAMEPLAYID.HANGUP then
                local soundname = tunpack(viewtable)
                self:sendmessage(eventdef.add_sound, soundname)
                return soundname
            end
        end,
        stop = function (self, key)
            self:sendmessage(eventdef.remove_sound, key)
        end
    },
    [7] = {
        start = function (self, viewtable)
            local activename = tunpack(viewtable)
            self:sendmessage(eventdef.start_active, activename)
        end
    },
    [8] = {
        start = function(self, viewtable)
            local state = tunpack(viewtable)
            local key = self:genkey()
            self:sendmessage(eventdef.add_special_state, key, state)
            return key
        end,
        stop = function (self, key)
            self:sendmessage(eventdef.remove_special_state, key)
        end
    },
    [9] = {
        start = function(self, viewtable)
            local modelname = tunpack(viewtable)
            local key = self:genkey()
            self:sendmessage(eventdef.start_replace_model, key, modelname)
            return key
        end,
        stop = function (self, key)
            self:sendmessage(eventdef.stop_replace_model, key)
        end
    }
}

return logic
