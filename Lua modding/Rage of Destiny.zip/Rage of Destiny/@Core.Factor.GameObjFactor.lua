GameObjFactor = GameObjFactor or BaseClass()

function GameObjFactor:HideObj(obj)
	obj.transform.localPosition = Vector3.New(-10000, 0, 0)
end

function GameObjFactor:GetChild(obj, path)
	local child = obj.transform:Find(path)
	if child ~= nil then
		return child.gameObject
	end	
end

function GameObjFactor:GetChildByIndex(obj, index)
	local child = obj.transform:GetChild(index)
	if child ~= nil then
		return child.gameObject
	end
end

function GameObjFactor:AddChild(parent, obj)
	if obj and parent then
		local child = GameObject.Instantiate(obj)
		self:SetParent(child , parent)
		return child
	end	
end

function GameObjFactor:SetParent(child, parent)
	child.transform:SetParent(parent.transform)
	child.transform.localPosition = Vector3.zero
    child.transform.localRotation = Quaternion.identity
    child.transform.localScale = Vector3.one
    child.layer = parent.layer
end

function GameObjFactor:SetLocalPosition(obj, position)
	if not obj then return end
	obj.transform.localPosition = position
end

function GameObjFactor:GetChildComponent(obj, path, typeName)
	local childObj = GameObjTools.GetChild(obj,path)
	if childObj ~= nil then
		return self:GetComponent(childObj,typeName)
	end
	return nil
end

function GameObjFactor:GetChildComponentByIndex(obj, index, typeName)
	local childObj = GameObjTools.GetChildByIndex(obj, index)
	if childObj ~= nil then
		return self:GetComponent(childObj,typeName)
	end
	return nil
end

function GameObjFactor:GetComponent(obj, typeName)
	if (nil ~= obj) then
		return obj:GetComponent(GameObjTools.typeof(typeName))
	end
	return nil
end

function GameObjFactor:AddComponent(obj, typeName)
	if (nil ~= obj) then
		return obj:AddComponent(GameObjTools.typeof(typeName))
	end
	return nil
end

function GameObjFactor:TryGetComponent(obj, typeName)
	return GameObjTools.TryGetComponent(obj, typeName)
end

-- canvas sortingOrder 深度
function GameObjFactor:GetNextDepth(addnext)
	return UILayerTool.GetNextDepth(addnext)
end

function GameObjFactor:GetCurrentDepth()
	return UILayerTool.GetCurrentDepth()
end

function GameObjFactor:SetDepth(obj , depth, bsetLayer)
	if obj == self.go then
		self.canvasDepth = depth
	end	
	GameObjTools.SetDepth(obj, depth, bsetLayer)
end

function GameObjFactor:SetOverrideSorting(obj, value)
	local canvas = self:TryGetComponent(obj, "Canvas")
	if canvas and canvas.overrideSorting ~= value then
		canvas.overrideSorting = value
	end	
end

function GameObjFactor:SetChildDepth(obj, depth, includeself)
	local canvas = GameObjTools.GetComponentsInChildren(obj, "Canvas", includeself)
	-- print(table.dump(canvas))
	for _,var in pairs(canvas) do
		if var.overrideSorting == true then
			var.sortingOrder = depth	
		end	
	end
end

--用于model 的z轴的深度

function GameObjFactor:GetNextZDepth()
	return UILayerTool.GetNextZDepth()
end

function GameObjFactor:GetCurrentZDepth()
	return UILayerTool.GetCurrentZDepth()
end

function GameObjFactor:SetModelDepth(obj, depth)
	if obj == self.go then
		self.modelDepth = depth
	end	

	GameObjTools.SetModelDepth(obj, depth)
end	

function GameObjFactor:GetWord(key, ...)
	local LanguageManager = require "Common.Mgr.Language.LanguageManager"
	return LanguageManager.Instance:GetWord(key, ...)
end