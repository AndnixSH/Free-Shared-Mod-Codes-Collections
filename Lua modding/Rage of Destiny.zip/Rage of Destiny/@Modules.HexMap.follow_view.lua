local follow_view = follow_view or BaseClass()
local mapobj_model = require "Modules.HexMap.mapobj_model"
local mapobj_ui_model = require "Modules.HexMap.mapobj_ui_model"
local cell_center_anchor = require "Modules.HexMap.cell_center_anchor"
local synchronous_anchor = require "Modules.HexMap.synchronous_anchor"
local hexmapcamera = require "Modules.HexMap.hexmapcamera"

follow_view.cmd = {}

function follow_view:__init(args)
    local prefab_id = args.prefab_id
    local prefab_type = args.prefab_type or 1
    local asset_type = args.asset_type or AssetType.BUILD
    local position = args.position_list[1]
    position = position or Vector3.zero
    self._bactive = args.bactive
    self._position = position

    local rotx, roty, rotz = table.unpack(args.header or {})
    self.anchor = cell_center_anchor.New(position, rotx, roty, rotz)
    if prefab_type == 1 then
        self.model = mapobj_model.New(self.anchor, prefab_id, asset_type)
    else
        self.model = mapobj_ui_model.New(self.anchor, prefab_id, "HexMap.BuildTitleView")
    end
    hexmapcamera.start(position)
    self:play_active("stand")
end

function follow_view:play_active(active_name)
    if self._bactive then
        self.model.prop.active = active_name
    end
end

function follow_view.cmd:add_title(prefab_id)
    self:release_title()
    self.title_anchor = synchronous_anchor.New(self.anchor)
    self.title_model = mapobj_model.New(self.title_anchor, prefab_id, AssetType.EFFECT)
end

function follow_view.cmd:remove_title()
    self:release_title()
end

function follow_view:move_follow_path(position_list, cbreach, cbnode, keepheader)
    local function _cbreach()
        self:play_active("stand")
        hexmapcamera.stop_face_follower()
        self._position = position_list[#position_list]
        if cbreach then cbreach() end
    end
    hexmapcamera.start_face_follower(self.anchor.canchor)
    self:play_active("run")
    local speed = self.follow_spd or 2
    return self.anchor:move_follow_path(position_list, speed, _cbreach, cbnode, keepheader)
end

function follow_view:set_follow_speed(speed)
    self.follow_spd = speed
end

function follow_view.cmd:move_y(value, duration)
    self._position.y = value
    self.anchor:move_y(value, duration)
    -- self.model.prop.shadow = value + 0.1
    hexmapcamera.set_target_position(self._position, 8)
end

function follow_view.cmd:update_shadow(value)
    self.model.prop.shadow = value + 0.1
end

function follow_view.cmd:set_moving(bmoving)
    self.anchor:set_moving(bmoving)
end

function follow_view:set_position(position)
    self:play_active("stand")
    self.anchor:set_position(position)
    follow_view.cmd.focus(self, 1)
end

function follow_view:stop_at_position(position)
	hexmapcamera.stop_face_follower()
	self._position = position
	self:set_position(position)
end

function follow_view.cmd:focus(duration)
    hexmapcamera.start_face_follower(self.anchor.canchor)
    local Timer =  require "Common.Util.Timer"
    local t = Timer.New(function ()  hexmapcamera.stop_face_follower() end, duration, 1)
    t:Start()
end


function follow_view:getcanchor() 
     
    return self.anchor:getcanchor()
end


function follow_view:release()
    self:release_title()
    if self.model then
        self.model:release()
        self.model = nil
    end
    self.anchor = nil
    hexmapcamera.stop_face_follower()
end

function follow_view:release_title()
    if self.title_model then
        self.title_model:release()
        self.title_model = nil
    end
    self.title_anchor = nil
end

function follow_view:__delete()
    self:release()
end

return follow_view
