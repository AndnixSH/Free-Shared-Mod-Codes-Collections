local logic = template({}, "sprite.buff.buff_timemerge")

function logic:oncreate()
    self.amendment_list = {}
end

function logic:ontstart(level)
    local slot_list = self.static.args_script[1]
    if slot_list then
        for _, slotid in ipairs(slot_list) do
            local amendment_table = {amendment_cond = self.static.amendment_cond, amendment = self.static.amendment }
            table.insert(self.amendment_list, {slotid = slotid, amendment_table = amendment_table})
            if self.caller.skill then
                self.caller.skill:add_amendment(slotid, amendment_table)
            end
        end
    else
        global.debug.warning("没有配置要修正的槽位列表", self.static.id)
    end
end

function logic:ontstop(level)
    for i, value in ipairs(self.amendment_list) do
        if self.caller.skill then
            self.caller.skill:remove_amendment(value.slotid, value.amendment_table)
        end
    end
end



return logic