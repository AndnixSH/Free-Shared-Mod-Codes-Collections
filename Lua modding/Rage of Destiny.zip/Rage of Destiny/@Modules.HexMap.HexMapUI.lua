local HexMapUI = { opencb = nil , closecb = nil}

function HexMapUI.OpenWidget(widgetname, parama)
   --是否可抵达
    if type(parama) == "table" and parama.clickable ~= nil then
        local nameStr = ""
        if parama.clickable == false then
            local LanguageUtil = require "First.Util.LanguageUtil"      
            local languageKey = "StorylineView_1011"
            nameStr = LanguageUtil.GetWord(languageKey)
        end
        parama.clickableName = nameStr
    end
    
    local view = LuaLayout.Instance:GetWidget(widgetname)
    local status = false
    if view then
        view.parama = parama
        status = view:OpenView()
    end

    if status and HexMapUI.opencb then
        HexMapUI.opencb()
    end
end

function HexMapUI.CloseWidget()
    if HexMapUI.closecb then
        HexMapUI.closecb()
    end
end

function HexMapUI.SetOpenCallBack(opencb)
    HexMapUI.opencb = opencb
end

function HexMapUI.SetCloseCallBack(closecb)
    HexMapUI.closecb = closecb
end

function HexMapUI.Clear()
    HexMapUI.opencb = nil
    HexMapUI.closecb = nil
end

return HexMapUI