-- 乱匠天才·勒芙蕾丝（商人）
local conf = { skill = {}, buff = {}, bullet = {} }

-- 投掷（普攻）抛出一只毒药瓶，每次造成n%攻击力的伤害
conf.skill[130201] = script.composite {
    main = {
        action = {
            one = {
                {trigger.time, {0}, caller.view.active_random, { "attack01"}, },
                {trigger.time, {350}, action.addchild, {typeid = 130201}, "bullet" },
                {trigger.time, {900}},
            },
            three = {
                {trigger.time, {0}, caller.view.active_random, { "attack01"}, },
                {trigger.time, {330}, action.addchild, {typeid = 130201}, "bullet" },
                {trigger.time, {330}, action.addchild, {typeid = 130201}, "bullet" },
                {trigger.time, {330}, action.addchild, {typeid = 130201}, "bullet" },
                {trigger.time, {600}, }
            }
        },
        event = {
            { scriptevent.onstart, onfire = function (self)
                self.prop.hasthreebuff = self.caller.buff:contains_state("normalatk_three")
                self.prop.bullet_burn = self.caller.buff:contains_state("normalatk_burn")
                if self.prop.hasthreebuff then
                    self.prop.bullet_args = { height = 3000, duration = 1000, rangeid = 130221, castid = 130201}
                else
                    self.prop.bullet_args = { height = 3000, duration = 1000, rangeid = 130201, castid = 130201}
                end
                self.action:run(self.prop.hasthreebuff and "three" or "one")
                self.caller.buff:remove_state("normalatk_three")
                self.caller.buff:remove_state("normalatk_burn")
                -- self.caller.buff:remove(130225)
                -- self.caller.buff:remove()
            end},
            { scriptevent.onend, onfire = function (self)
                self.caller.buff:remove(130225)
                self.caller.buff:remove(130227)
            end},
        },
    },
    bullet = {
        event = {
            { scriptevent.onstart, onfire = function (self)
                self.caller.body:addscript(scriptcommon.bullet_parabola, self.prop.bullet_args)
            end },

            {eventdef.bullet_move_end, onfire = function(self, collideobj)
                if self.prop.bullet_burn and  self.prop.hasthreebuff then
                    self.action:addchild({ typeid = 999999}, "burn")
                end
            end },
        }
    },
    burn = {
        action = {
            default = {
                {trigger.time, {0}, caller.view.active, "130221"},
                {trigger.time, script.prop("time_args"), action.cast, script.prop("burnid"),},
                {trigger.time, {2000}, caller.body.destroy },
            }
        },
        event = {
            {scriptevent.onstart,  onfire = function(self)
                local burn_lv = self.owner.body.parent.caller.skill:getslotlevel(SKILL.SLOT.SKILL3)
                local burn_time = burn_lv >= 4 and 4 or 2
                self.prop.burnid = burn_lv >= 4 and 130282 or 130281
                self.prop.time_args = {0, 1000, 4}
            end}
        }
    }
}

-- 疯狂实验（必杀技）持续向周围抛掷各种包里的各种道具，每0.5秒对周围随机3名单位造成效果。友军会拾取到“能量药水”受到激励，回复50点能量值并提升30%攻击力，持续8秒。敌人会被扳手砸到眩晕4秒
conf.skill[130211] = {
    action = {
        default = {
            {trigger.time, {0}, caller.view.active, "spell_01_start", caller.skill.pause, 800 },
            {trigger.time, {833}, caller.view.active, "spell_01_loop", },
            {trigger.time, {0,500,5}, action.message, "130211_cast"},
            {trigger.time, {0}, caller.view.active, "spell_01_end", },
            {trigger.time, {1370} },
        },
    },
    event = {
        {scriptevent.onstart, onfire = function (self)
            local friendid = 130211 + self.action.info.level - 1
            self.prop.buffid = 130215
            self.prop.fri_bufflist = {friendid ,130214}
        end},

        { "130211_cast", onfire = function (self)
            local targets = self.action:range(130274) 
            for _, target in ipairs(targets) do
                if target.prop.camp == self.owner.prop.camp then
                    target.caller.buff:addlist(self.prop.fri_bufflist, self.owner)
                else 
                    target.caller.buff:add(130215, self.owner)
                end
            end
        end }
    }
}
-- 友军回复能量值提升至60点
conf.skill[130212] = conf.skill[130211]
-- 友军回复能量值提升至70点
conf.skill[130213] = conf.skill[130211]

-- 能量药水（常规技能1）自己喝掉能量药水，回复80点能量值，并使下一次普攻朝当前选中目标周围快速连续丢出3个毒药瓶，且毒药瓶伤害额外提升n%
conf.skill[130221] = {
    action = {
        default = {
            {trigger.time, {0}, caller.view.active, "spell_02", action.addstartbuff},
            {trigger.time, {1400},}
        },
    },
    event = {
        { scriptevent.onstart, onfire = function (self)
            self.caller.buff:add_state("normalatk_three")
            if self.action.info.level >= 2 then
                self.caller.buff:add_state("normalatk_burn")
            end
        end },
    }
}
-- 毒药瓶伤害额外提升n%
conf.skill[130222] = conf.skill[130221]
-- 能量药水回复的能量值提升至120点
conf.skill[130223] = conf.skill[130221]
-- 每个毒药瓶破碎后会在地表残留2秒，每0.5s对目标造成25%的本次普攻伤害
conf.skill[130224] = conf.skill[130221]


-- 紧急治疗（常规技能2）当友军生命值低于50%时，会朝其投掷生命药水，回复其最大生命值30%的生命。每个英雄5秒内只能享受到一次该效果
conf.skill[130231] = script.composite {
    main = {
        action = {
            default = {
                -- {trigger.time, {0}, action.active,  "empty", },
                {trigger.time, {0}, action.active,  "attack01", },
                {trigger.time, {300}, action.addchild, {typeid = 130231}, "bullet" }, 
                -- {trigger.time, {500}, action.addstartbuff },
                {trigger.time, {800} },
            },
        },
        event = {
            {scriptevent.onstart, onfire = function(self)
                local castid = self.static.id
                local targets = self.caller.buff:get_state("120231_heal_target")
                if #targets < 0 then 
                    self.action:stop() 
                end
                self.prop.bullet_args = { height = 3000, duration = 500, target = targets[1], castid = castid, samecamp = true}
                self.prop.burnid = castid + 30
            end}
        },
        check = function(self) -- 动态监测
            if self.caller.skill and not self.caller.state:isdead() then
                local targets = self.action:range(130231)
                if #targets > 0 then
                    local targetlist = {}
                    for _, target in ipairs(targets) do
                        if not target.caller.buff:contains(130231) then
                            table.insert(targetlist, target)
                        end
                    end
                    self.caller.buff:add_state("120231_heal_target", targetlist)

                    return #self.caller.buff:get_state("120231_heal_target") > 0 -- 启动条件
                    and not self.caller.skill:getactiveslot()
                    and self.caller.state:canattack()
                end
            end
            return false
        end
        -- check = {  -- 血量变化时才会发动
        --     event = {
        --         { eventdef.hp_change, modifer = eventmdf.public, onfire = function (self, fromobj, value)
        --                 if fromobj.prop.camp == self.owner.prop.camp and 
        --                 fromobj.attr.hp < tsmath.rate(fromobj.attr.hp_max, 500) and 
        --                 (not fromobj.caller.buff:contains(130231)) and 
        --                 self.caller.state:canattack() then
        --                     self.action:checksucc()
        --                 end
        --         end }
        --     }
        -- }
    },
    bullet = {
        event = {
            { scriptevent.onstart, onfire = function (self)
                if self.prop.bullet_args and self.prop.bullet_args.target then
                    self.caller.body:addscript(scriptcommon.bullet_parabola, self.prop.bullet_args)
                else
                    self.caller.body:destroy()
                end
            end },
            { eventdef.bullet_move_end, onfire = function(self, collideobj)
                if self.action.info.level >= 2 then
                    self.action:addchild({typeid = 999999}, "heal")
                end
            end }
        }
    },
    heal = {
        action = {
            default = {
                {trigger.time, {0}, caller.view.active, "130231"},
                {trigger.time, {200, 1000, 4}, action.cast, script.prop("burnid"),},
                {trigger.time, {500}, caller.body.destroy },
            }
        }
    }

}

-- 在生效目标脚底产生残留，每0.5s回复自己n%攻击力的生命，持续m秒
conf.skill[130232] = conf.skill[130231]
-- 回复生命提升至40%最大生命值
conf.skill[130233] = conf.skill[130232]


-- 化学反应（被动技能）服用了各种药剂，使自己在战斗中产生匪夷所思的效果。战斗中，受到超过10%最大生命值伤害时，消耗能量值完全抵消本次伤害，该效果每3秒发动一次，消耗的怒气取决于抵消伤害的量，最多消耗80点能量值
conf.skill[130241] = {
    action = {
        default = {
            {trigger.time, {0}, action.addstartbuff }
        }
    },
}

conf.buff[1302410] = {
    event = {
        { eventdef.hp_change, onfire = function (self, value, original_hp)
            local curtime = self.time.time
            if value < 0 and tsmath.abs(value) > tsmath.rate(self.owner.attr.hp_max, 100) and (not self.prop.record or curtime - self.prop.record > 3000)  then
                local amount = -50 -- self.caller.skill:getslotlevel(SKILL.SLOT.SKILL5)>= 2 and -50 or -80
                self.owner.attr.hp = original_hp
                self.prop.record = curtime
                self.caller.mp:cast_change(amount)
                self.caller.view:battlesct(self.owner,self.owner,DAMAGE_STATE.IMMUNE)
            end
        end },

        {eventdef.before_suffer_start, onfire = function(self,suffer_table)
            local rate = 600  --- 50%概率免除控制          
            if self.caller.skill:getslotlevel(SKILL.SLOT.SKILL5) >= 3 and tsmath.random_match(rate) then
               self.owner.attr.immune_suffer = self.owner.attr.immune_suffer + 1
                if suffer_table.buffid then
                    -- print("==================1302 buff immune", suffer_table.buffid)
                    self.caller.buff:remove(suffer_table.buffid)
                end
                self.caller.buff:add_state("immune_suffer")
            end 
        end},

        {eventdef.suffer_immune, onfire = function(self,suffer_table)
            if self.caller.buff:contains_state("immune_suffer") then
                self.caller.buff:remove_state("immune_suffer")
                self.owner.attr.immune_suffer = self.owner.attr.immune_suffer - 1
            end
        end},

        {scriptevent.ontimer, time = {2000,100,1}, onfire = function(self)
            self.owner.attr.immune_suffer = self.owner.attr.immune_suffer + 1
        end}
    }
}
-- 战斗中，自身每秒回复20点能量值
-- 最多消耗能量值降低至50点
conf.skill[130242] = conf.skill[130241]
conf.skill[130243] = conf.skill[130241]

--专属武器技能
conf.skill[130251] = script.composite {
    main = {
        action = {
            default = {
                {trigger.time, {0}, action.active, "attack01" },
                {trigger.time, {300}, action.addchild, {typeid = 130251}, "bullet" }, --todo修改typeid
                {trigger.time, {500}, },
            }
        },
        event = {
            {scriptevent.onstart, onfire= function (self)
                local exbufflv = self.caller.buff:get_state("exbuff")
                local mpamount = ({60, 120, 200, 400})[exbufflv]

                local targets = self.action:range()
                local target = self.owner
                if targets and #targets > 0 then
                    target = targets[1]
                end
                self.prop.mpchange = mpamount
                self.prop.bulletid = { height = 3000, duration = 500, target = target, castid = 130251, samecamp = true }
            end},
            {scriptevent.onend, onfire= function (self)
            end},
        },
        check = function (self)
            return self.caller.buff:contains_state("exbuff") and #self.action:range(130251) > 0 
            and not self.caller.skill:getactiveslot()
            and self.caller.state:canattack()
        end
    },
    bullet = {
        event = {
            { scriptevent.onstart, onfire = function (self)
                self.caller.body:addscript(scriptcommon.bullet_parabola, self.prop.bulletid)
            end },
            
            { eventdef.bullet_move_end, onfire = function(self)
                local target = self.prop.bulletid.target
                if target and target.caller.mp then
                    target.caller.mp:cast_change(self.prop.mpchange, self.owner, 1)
                end
            end }
        }
    },
}
-- =================================================
-- 专属武器模板
conf.buff[9130210] = {
    event = {
        {scriptevent.onstart, onfire = function (self)
            --------------------------------------------------------- 按队列加入buff
            local exbufflist = {913024,913023,913022,913021}
            local bufflist =  {913025,913026,913027,913028}
            local exbuff = self.caller.buff:any(exbufflist)
            local exbufflv = exbuff and exbuff % 10 or 0
            if #self.action:range(SKILL.RANGEID.FRIENDS_MENTALITY) >= 3 then -- 友方智力英雄 2 + 1 就塞buff
                self.caller.buff:add(bufflist[exbufflv])
            end
            self.caller.buff:add_state("exbuff", exbufflv)
        end}
    }
}
conf.buff[9130220] = conf.buff[9130210]
conf.buff[9130230] = conf.buff[9130210]
conf.buff[9130240] = conf.buff[9130210]

return conf