ConfigManager.InitConfig('data_maze', {
[0]={id=0,class=2,type=1,start=2,width=8,height=5,cell_radius=0.5,cell_level={{0,0.45}}, cell_normal_color=1,cell_fog_color=0.6,scence=23100,goods_way=1140},
[98]={id=98,class=2,type=3,start=19,width=8,height=5,cell_radius=0.5,cell_level={{0,0.45}}, cell_normal_color=1,cell_fog_color=0.6,win_condition={10,5}, scence=23200,goods_way=1140},
[1]={id=1,class=1,type=1,start=1,width=8,height=5,cell_radius=0.5,cell_level={{0,0.45}}, cell_normal_color=1,cell_fog_color=0.6,scence=23100,goods_way=1141,rewards_per=70},
[2]={id=2,class=1,type=1,start=5,width=8,height=5,cell_radius=0.5,cell_level={{0,0.45}}, cell_normal_color=1,cell_fog_color=0.6,scence=23100,goods_way=1142,rewards_per=60},
[3]={id=3,class=1,type=1,start=3,width=8,height=5,cell_radius=0.5,cell_level={{0,0.45}}, cell_normal_color=1,cell_fog_color=0.6,scence=23100,goods_way=1143,rewards_per=45},
[4]={id=4,class=1,type=1,start=1,width=8,height=5,cell_radius=0.5,cell_level={{0,0.45}}, cell_normal_color=1,cell_fog_color=0.6,scence=23100,goods_way=1144,rewards_per=30},
[5]={id=5,class=1,type=1,start=5,width=8,height=5,cell_radius=0.5,cell_level={{0,0.45}}, cell_normal_color=1,cell_fog_color=0.6,scence=23100,goods_way=1145,rewards_per=15},
[6]={id=6,class=1,type=1,start=1,width=8,height=5,cell_radius=0.5,cell_level={{0,0.45}}, cell_normal_color=1,cell_fog_color=0.6,win_condition={11,2}, scence=23300,goods_way=1146},
[15]={id=15,class=1,type=2,start=5,width=8,height=5,cell_radius=0.5,cell_level={{0,0.45}}, cell_normal_color=1,cell_fog_color=0.6,scence=23400,goods_way=1147,rewards_per=15},
[16]={id=16,class=1,type=2,start=1,width=8,height=5,cell_radius=0.5,cell_level={{0,0.45}}, cell_normal_color=1,cell_fog_color=0.6,win_condition={11,2}, scence=23300,goods_way=1148},
[99]={id=99,class=1,type=3,start=19,width=8,height=5,cell_radius=0.5,cell_level={{0,0.45}}, cell_normal_color=1,cell_fog_color=0.6,scence=23200,goods_way=1149,rewards_per=30},
})