--LuaLayout.ins = LuaLayout.New()
Singleton = Singleton or BaseClass()

function Singleton:__init()
    Singleton.ins = self

	--Singleton.ins = Singleton:instance()
end

function Singleton:__delete()
    Singleton.ins = nil
end




