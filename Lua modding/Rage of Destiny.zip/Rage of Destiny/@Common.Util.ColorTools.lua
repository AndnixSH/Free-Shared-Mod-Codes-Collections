local ColorTools = {}

--16进制转10进制
local function CovertHex2Dig(ch)
    ch = string.lower(ch)
    if ("0" == ch) then
        return 0
    elseif ("1" == ch) then
        return 1
    elseif ("2" == ch) then
        return 2
    elseif ("3" == ch) then
        return 3
    elseif ("4" == ch) then
        return 4
    elseif ("5" == ch) then
        return 5
    elseif ("6" == ch) then
        return 6
    elseif ("7" == ch) then
        return 7
    elseif ("8" == ch) then
        return 8
    elseif ("9" == ch) then
        return 9
    elseif ("a" == ch) then
        return 10
    elseif ("b" == ch) then
        return 11
    elseif ("c" == ch) then
        return 12
    elseif ("d" == ch) then
        return 13
    elseif ("e" == ch) then
        return 14
    elseif ("f" == ch) then
        return 15
    end
    return 0
end

--转化富文本颜色到Color类
function ColorTools.RichText2Color(str)
	local num1 = CovertHex2Dig(string.sub(str,1,1))
	local num2 = CovertHex2Dig(string.sub(str,2,2))
	local r = num1 * 16 + num2
	local num1 = CovertHex2Dig(string.sub(str,3,3))
	local num2 = CovertHex2Dig(string.sub(str,4,4))
	local g = num1 * 16 + num2
	local num1 = CovertHex2Dig(string.sub(str,5,5))
	local num2 = CovertHex2Dig(string.sub(str,6,6))
	local b = num1 * 16 + num2
    
    local a = 255
    if not string.isEmpty(string.sub(str,7,7)) and 
        not string.isEmpty(string.sub(str,8,8)) then
            num1 = CovertHex2Dig(string.sub(str,7,7))
            num2 = CovertHex2Dig(string.sub(str,8,8))
            a = num1 * 16 + num2
    end
	return Color.New(r / 255, g / 255, b / 255, a/255)
end

--取得品质颜色
function ColorTools.GetColorByQuality(quality)
    if quality == 1 then
        return ColorTools.RichText2Color("449823")    
    elseif quality == 2 then
        return ColorTools.RichText2Color("3061ff")    
    elseif quality == 3 then
        return ColorTools.RichText2Color("b534ff")    
    elseif quality == 4 then
        return ColorTools.RichText2Color("ff6600")    
    elseif quality == 5 then
        return ColorTools.RichText2Color("ff3434")    
    end                            
end

return ColorTools