
local RankListDef = require "Modules.RankList.RankListDef"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local CampaignProxy = require "Modules.Campaign.CampaignProxy"
local TowerProxy = require "Modules.Tower.TowerProxy"
local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
local RedPointDef = require "Modules.RedPoint.RedPointDef"
local RankListProxy = RankListProxy or BaseClass(BaseProxy)


function RankListProxy:__init()
    RankListProxy.Instance = self
    self:AddProto(61000, self.On61000) 
    self:AddProto(61001, self.On61001) 
    self:AddProto(61002, self.On61002) 
    self:AddProto(61003, self.On61003) 
    self.data = {}
    self.data.rankList = {}
end

function RankListProxy:__delete()
    RankListProxy.Instance = nil
end

function RankListProxy:Send61000()

    self:SendMessage(61000)
end
function RankListProxy:On61000(decoder)
    local count= decoder:Decode("I1")
    local player_list= {}
    for i =1 , count do
        local item = {}
        local ranktype_id = decoder:Decode("I2")
        local players = decoder:DecodeList("I4I8I1s2I2I2I2I4I4",true) -- uin time
        item.ranktypeId = ranktype_id
        for _ ,v in ipairs(players) do -- 只有第一名玩家
            item.uin = v[1]
            item.guserid = v[2]
            local head = {}
            head.sex = v[3]
            head.nickname = v[4]
            head.level = v[5]
            head.headicon = v[6]
            head.frameicon = v[7]
            head.uin = v[1]
            head.guserid = v[2]
            item.head = head
            item.value = tostring(v[8])
            if  ranktype_id >=  RankListDef.RankTypeID[RankListDef.RankType.tower_progression_ladder] and ranktype_id <=  RankListDef.RankTypeID[RankListDef.RankType.tower_progression_ladder_4] then
                    
                item.value = v[8] == 0 and  LanguageManager.Instance:GetWord(RankListDef.CommonDef.NoChallage) or string.format(LanguageManager.Instance:GetWord(RankListDef.CommonDef.Tower_Layer),v[8])

            elseif ranktype_id == RankListDef.RankTypeID[RankListDef.RankType.stage_progression_ladder] then
                local cfg = CampaignProxy.Instance:GetMainLineCfgById(v[8])
                if cfg then
                    item.value = string.format("%s-%s",cfg.chapter,cfg.section)
                else
                    item.value =   LanguageManager.Instance:GetWord(RankListDef.CommonDef.NoChallage)
                end
                
            end
            item.time = v[9]
        end
        
        table.insert(player_list,item)
    end

    for i =1 , RankListDef.RankType.tower_progression_ladder do
        local find=false
        for _ ,v in ipairs(player_list) do
            if v.ranktypeId == RankListDef.RankTypeID[i] then
                find =true
                break
            end
        end
        if not find then
            local item = {}
            local head = {}
            head.nickname = LanguageManager.Instance:GetWord(RankListDef.CommonDef.EmptyHead_NickName)
            head.headicon = 9999
            item.head = head
            item.ranktypeId = RankListDef.RankTypeID[i]
            table.insert(player_list,item)
        end
    end
    self:ToNotify(self.data,RankListDef.NotifyDef.Update_RankEntrance,player_list)
    --print("-------------------On61000-------------------",table.dump(player_list))
end

function RankListProxy:Send61001(typeid)
    local encoder=NetEncoder.New()
    encoder:Encode("I2",typeid)
    self:SendMessage(61001,encoder)
end

function RankListProxy:On61001(decoder)
    self.data.rankList = {}
    self.data.reward_list = {}
    local result , typeid ,time = decoder:Decode("I1I2I4")
    if result == 0 then

        local my_rank = 0
        local rankList={}
        local rank_list=decoder:DecodeList("I4I8I1s2I2I2I2I4I4",true)
        table.sort(
            rankList,
        function(a, b) --排序
            return a[8] > b[8] 
        end)
        for k , v in ipairs(rank_list) do
            if v then
                local item = {}
                item.uin = v[1]
                item.guserid = v[2]
                local head = {}
                head.sex = v[3]
                head.nickname = v[4]
                head.level = v[5]
                head.headicon = v[6]
                head.frameicon = v[7]
                head.uin = v[1]
                head.guserid = v[2]
                item.head = head
                item.value = v[8]
                item.flag = 0
                if  typeid >=  RankListDef.RankTypeID[RankListDef.RankType.tower_progression_ladder] and typeid <=  RankListDef.RankTypeID[RankListDef.RankType.tower_progression_ladder_4] then
                    
                    item.value = v[8] == 0 and  LanguageManager.Instance:GetWord(RankListDef.CommonDef.NoChallage) or string.format(LanguageManager.Instance:GetWord(RankListDef.CommonDef.Tower_Layer),v[8])

                elseif typeid == RankListDef.RankTypeID[RankListDef.RankType.stage_progression_ladder] then
                    local cfg = CampaignProxy.Instance:GetMainLineCfgById(v[8])
                    if cfg then
                        item.value = string.format("%s-%s",cfg.chapter,cfg.section)
                    else
                        item.value =  LanguageManager.Instance:GetWord(RankListDef.CommonDef.NoChallage)
                    end
                elseif typeid >= RankListDef.RankTypeID[RankListDef.RankType.lightbearers_ladder] and typeid <=  RankListDef.RankTypeID[RankListDef.RankType.graveborn_ladder] then
                    item.flag = typeid - RankListDef.RankTypeID[RankListDef.RankType.lightbearers_ladder ] + 1
                end
                item.time = v[9]
                item.rank = k
                if item.uin == RoleInfoModel.uid then
                    my_rank = k
                end
                table.insert(rankList , item)
            end
        end
       
        self.data.my_rank = my_rank
        self.data.time = time
        self.data.rankList = rankList
        if not self.data.my_value  then
            self.data.my_value  = {}
        end
        --print("-------------------On61001-------------------",table.dump(rankList))
        if typeid ==  RankListDef.RankTypeID[RankListDef.RankType.lightbearers_ladder] or typeid == RankListDef.RankTypeID[RankListDef.RankType.graveborn_ladder]  or 
        typeid ==  RankListDef.RankTypeID[RankListDef.RankType.maulers_ladder]  or typeid ==  RankListDef.RankTypeID[RankListDef.RankType.wilders_laddder]  or
        typeid ==  RankListDef.RankTypeID[RankListDef.RankType.tower_progression_ladder]  or typeid == RankListDef.RankTypeID[RankListDef.RankType.stage_progression_ladder]   then
            --只有这6个排行榜有奖励
            self:DeCoderRewardInfo(decoder,typeid)
        end

        if typeid ==  RankListDef.RankTypeID[RankListDef.RankType.lightbearers_ladder] or typeid == RankListDef.RankTypeID[RankListDef.RankType.graveborn_ladder]  or 
        typeid ==  RankListDef.RankTypeID[RankListDef.RankType.maulers_ladder]  or typeid ==  RankListDef.RankTypeID[RankListDef.RankType.wilders_laddder] then
            
            local value = decoder:Decode("I4")
            self.data.my_value[typeid] = GameLogicTools.GetNumStr(value)
        
        elseif  typeid >=  RankListDef.RankTypeID[RankListDef.RankType.tower_progression_ladder] and typeid <=  RankListDef.RankTypeID[RankListDef.RankType.tower_progression_ladder_4] then
           
            local layer =  TowerProxy.Instance:GetCurTowerLayer(typeid - RankListDef.RankType.tower_progression_ladder) - 1
            self.data.my_value[typeid] = layer == 0 and LanguageManager.Instance:GetWord(RankListDef.CommonDef.NoChallage) or string.format( LanguageManager.Instance:GetWord(RankListDef.CommonDef.Tower_Layer),tostring(layer))
       
        elseif typeid == RankListDef.RankTypeID[RankListDef.RankType.stage_progression_ladder] then
            local cfg = CampaignProxy.Instance:GetMainLineCfgById(RoleInfoModel.mainlineid - 1)
            if cfg then
                self.data.my_value[typeid] = string.format("%s-%s",cfg.chapter,cfg.section) 
            else
                self.data.my_value[typeid] = LanguageManager.Instance:GetWord(RankListDef.CommonDef.NoChallage)
            end
            
        end
       
        self:ToNotify(self.data,RankListDef.NotifyDef.Update_RankList,rankList)
        self:ToNotify(self.data,RankListDef.NotifyDef.UpdateTitleName,LanguageManager.Instance:GetWord(RankListDef.TitleName[typeid]))
    else
        GameLogicTools.ShowErrorCode(61001,result)
    end
end

-- 领取奖励
function RankListProxy:Send61002(get_reward_idlist)
    local encoder=NetEncoder.New()
    encoder:EncodeList("I4",get_reward_idlist)
    self:SendMessage(61002,encoder)
end

function RankListProxy:GetRankCfg()

    return ConfigManager.GetConfig("data_ranklist")
end

function RankListProxy:On61002(decoder)
    local result  = decoder:Decode("I1")
    if result == 0 then

        local reward_Id_list = decoder:DecodeList("I4",true)
        local goods_list = {}
        local cfg = self:GetRankCfg()
        for _ , id in ipairs(reward_Id_list) do
            if id  and cfg[id[1]] then
                local reward = cfg[id[1]].rewards
                --print("-----------reward---------",table.dump(reward))
                if reward then
                    local find = false
                    for _ , good in ipairs(goods_list) do
                        if good then
                            if reward[1] == good.goodsid then
                                find = true
                                good.goodsnum = good.goodsnum + reward[2]
                                break
                            end
                        end
                    end
                    if not find then
                        local item={}
                        item.goodsid=reward[1]
                        item.goodsnum=reward[2]
                        table.insert(goods_list,item)
                    end
                end
                if self.data.reward_list then
                    for _ , _reward in ipairs(self.data.reward_list) do
                        if _reward.id == id[1] then
                            _reward.state = RankListDef.Reward_State.HasGet
                            break
                        end
                    end
                end
            end
            
            for k, ungetid in ipairs(self.data.un_get_reward_list) do
                if  id[1] == ungetid then
                    table.remove( self.data.un_get_reward_list,k)
                end
            end
        end
        GameLogicTools.ShowGetItemView(goods_list,1,function (  )

        end)
        self:ToNotify(self.data,RankListDef.NotifyDef.Update_RewardList,{})
        local id="Rank_Award"
        for i = RankListDef.RankType.lightbearers_ladder, RankListDef.RankType.tower_progression_ladder do
            local result = self:IsUnGetRewardByType(i)
            RedPointProxy.Instance:SetNodeNum(id..tostring(i),result and 1 or 0)
        end
    else
        GameLogicTools.ShowErrorCode(61002,result)
    end
end

function RankListProxy:Send61003()
    --请求红点信息
    self:SendMessage(61003)
end
function RankListProxy:On61003(decoder)

    local can_get_reward_idlist = decoder:DecodeList("I4",true) --包含已经领取的
    local has_get_reward_Id_list = decoder:DecodeList("I4",true)

    local un_get_reward_list = {}
    for _, id in ipairs(can_get_reward_idlist) do
        local find = false
        for _, _id in ipairs(has_get_reward_Id_list) do
            if id[1] == _id[1] then
                find =true
                break
            end
        end
        if not find then
            table.insert(un_get_reward_list,id[1])
        end
    end
    self.data.un_get_reward_list = un_get_reward_list
    local id="Rank_Award"
    for i = RankListDef.RankType.lightbearers_ladder, RankListDef.RankType.tower_progression_ladder do
        local result = self:IsUnGetRewardByType(i)
        RedPointProxy.Instance:SetNodeNum(id..tostring(i),result and 1 or 0)
    end
    --print("---------On61003---------",table.dump(self.data.un_get_reward_list))
end
function RankListProxy:DeCoderRewardInfo(decoder,typeid)
    local count= decoder:Decode("I1")
    local player_list= {}
    for i =1 , count do
        local item = {}
        local id = decoder:Decode("I4")
        local players = decoder:DecodeList("I4I8I1s2I2I2I2I4I4",true) -- uin time
        local playerList = {}
        item.id = id
        table.sort(players, function(a,b) --排序
            return a[9] < b[9]
        end)
        for k, v in ipairs(players) do
            local player = {}
            player.uin = v[1]
            player.guserid = v[2]
            local head = {}
            head.sex = v[3]
            head.nickname = v[4]
            head.level = v[5]
            head.headicon = v[6]
            head.frameicon = v[7]
            head.uin = v[1]
            head.guserid = v[2]
            player.head = head
            player.value = v[8]
            player.time = v[9]
            player.rank = k
            table.insert(playerList,player)
        end
        item.players = playerList
        table.insert(player_list,item)
    end
    local has_get_reward_idlist  = decoder:DecodeList("I4")

    local has_get_id_list = {}
    local cfg = self:GetRankCfg()
    for i,v in ipairs(has_get_reward_idlist) do
        if v and cfg[v] then
            if cfg[v].type == typeid then
                table.insert(has_get_id_list,v)
            end
        end
    end

    local reward_list = {}
    for i,_cfg in pairs(cfg) do
        if _cfg   then
            if _cfg.type == typeid  then
                local find =false
                local item ={}
                for _, id in ipairs(has_get_id_list) do
                    if id == _cfg.id then
                        find = true
                        break
                    end
                end
                item.state = find and RankListDef.Reward_State.HasGet or RankListDef.Reward_State.CanNotGet
                for _, _player in ipairs(player_list) do
                    if _player.id == _cfg.id then
                        if #_player.players > 0 then
                            if item.state == RankListDef.Reward_State.CanNotGet then
                                item.state = RankListDef.Reward_State.UnGet
                            end
                            item.players = _player.players
                        end
                        break
                    end
                end
                if item.state == RankListDef.Reward_State.CanNotGet then
                    item.players ={}
                    local player = {}
                    local head = {}
                    head.nickname = LanguageManager.Instance:GetWord(RankListDef.CommonDef.EmptyHead_NickName)
                    head.headicon = 9999
                    player.head = head
                    table.insert(item.players,player)
                end
                
                item.id =_cfg.id
                local _value = _cfg.value
                if typeid == RankListDef.RankTypeID[RankListDef.RankType.stage_progression_ladder] then
                    local _config = CampaignProxy.Instance:GetMainLineCfgById(_cfg.value)
                    if _config then
                        _value = _config.chapter
                    end
                end
                item.dec = string.format(LanguageManager.Instance:GetWord(RankListDef.RewardTips[typeid]),_value)
            
                item.reward = _cfg.rewards
                table.insert(reward_list,item)
            end 
        end
    end
    table.sort(
        reward_list,
        function(a, b) --排序
            return a.id < b.id
        end)
    self.data.reward_list = reward_list
    --self:ToNotify(self.data,RankListDef.NotifyDef.Update_RewardList,reward_list)
end

function RankListProxy:GetRewardList()
    if self.data then
        return self.data.reward_list
    end
end

function RankListProxy:GetRewardListPlayersById(id)
    if self.data then
        for _ ,v in ipairs(self.data.reward_list) do
            if v.id == id  then
                return v.players
            end
        end
    end
end

function RankListProxy:GetRankList()
    if self.data then
        return self.data.rankList
    end
end

function RankListProxy:GetUnGetRewardList()
    if self.data then
        return self.data.un_get_reward_list
    end
end

function RankListProxy:IsUnGetRewardByType(type)
    local cfg = self:GetRankCfg()
    if self.data and self.data.un_get_reward_list and cfg then
        for _, id in ipairs(self.data.un_get_reward_list) do
            if  cfg[id] then
                if cfg[id].type == RankListDef.RankTypeID[type] then
                    return true
                end
            end
        end
    end
    return false
end

function RankListProxy:GetMyRankInfo(type)
    local item = {}

    item.uin = RoleInfoModel.uid
    item.guserid = RoleInfoModel.guserid
    local head = {}
    head.headicon=RoleInfoModel.headicon 
    head.frameicon=RoleInfoModel.frameicon
    head.nickname=RoleInfoModel.nickname
    head.sex = RoleInfoModel.sex
    head.level=RoleInfoModel.level
    head.uin = RoleInfoModel.uid
    head.guserid = RoleInfoModel.guserid
    item.head = head 
    item.value = tostring(self.data.my_value[RankListDef.RankTypeID[type]])
    item.time = self.data.time or 0
    item.flag = 0
    if type >= RankListDef.RankType.tower_progression_ladder then

        local layer =  TowerProxy.Instance:GetCurTowerLayer(type - RankListDef.RankType.tower_progression_ladder) - 1
        item.value = layer == 0 and LanguageManager.Instance:GetWord(RankListDef.CommonDef.NoChallage) or string.format( LanguageManager.Instance:GetWord(RankListDef.CommonDef.Tower_Layer),tostring(layer))
    elseif type >= RankListDef.RankType.lightbearers_ladder and type <= RankListDef.RankType.graveborn_ladder then
        item.flag = type
    end
    item.rank = self.data.my_rank or 0
    return item
end


return RankListProxy