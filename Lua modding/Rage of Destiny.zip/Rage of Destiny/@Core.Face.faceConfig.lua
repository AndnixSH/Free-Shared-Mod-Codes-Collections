faceConfig = faceConfig or {}

setmetatable(
    faceConfig,
    {
        __index = function(t, k)
            return ConfigManager.GetConfig(k)
        end,
        __newindex = function(t, k, v)
            ConfigManager.InitConfig(k, v)
        end
    }
)
