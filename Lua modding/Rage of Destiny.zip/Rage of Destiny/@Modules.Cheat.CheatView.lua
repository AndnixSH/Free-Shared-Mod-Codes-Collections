local CheatPoolPanel = require "Modules.Cheat.CheatPoolPanel"

local CheatView = CheatView or BaseClass(LuaBasicWidget)
function CheatView:OnLoad()
    AssetManager.LoadUIPrefab(self, "Cheat.CheatView", self.LoadEnd)
end

function CheatView:LoadEnd(obj)
    self:SetGo(obj)

    self.cheatPoolPanel = CheatPoolPanel.New(obj)

    self.closeBtn = self:GetChildComponent(obj, "CButton_close", "CButton")
    self.closeBtn:AddClick(
        function()
            self:CloseView()
        end
    )

    self:SetStep(0)
end

function CheatView:OnOpen()
    self.cheatPoolPanel:Open(self.cheatType)
end

function CheatView:SetCheatType(type)
    self.cheatType = type
end

function CheatView:OnClose()
    self.cheatType = nil
end

--
local KeyCode = CS.UnityEngine.KeyCode
local Input = CS.UnityEngine.Input
function CheatView.OnKeyBoardClick()
    if Input.GetKeyUp(KeyCode.F1) then
        LuaLayout.Instance:OpenWidget("NetworkDelayView")
    elseif (Input.GetKeyUp(KeyCode.F2)) then
        --local HeroTipsView = require "Modules.Common.Msg.HeroTipsView"
        --HeroTipsView.ShowHeroTipsView(3301)
        print("---------------------------------F4 Click")
        --LuaMain.ReBoot()
        local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
        local IGGSdkDef = require "Modules.IGGSdk.IGGSdkDef"
        IGGSdkProxy.Instance:show_relogin(IGGSdkDef.ReloginType.Expire)
        IGGSdkCallback.OnSessionInvalidated()
    elseif (Input.GetKeyUp(KeyCode.F3)) then

    elseif (Input.GetKeyUp(KeyCode.F4)) then
    elseif (Input.GetKeyUp(KeyCode.F5)) then

    end
end

return CheatView
