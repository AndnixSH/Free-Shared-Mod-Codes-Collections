local logic = {timer = {}}

function logic:oncreate()

    if self.static.startborn then
        self:_bornat(self.static.startborn)
    end

    local refresh_timer = self.static.refresh_timer
    self._curwave = 0
    self._waveindex = 0
    self.timer:addtable(refresh_timer, self._refresh)
end

function logic:_refresh()
    if self._curwave == self._waveindex then
        local list = self.service.area:getactors(CAMP.BLUE)
        if not list or #list <= self.static.max then
            if self._waveindex >= #self.static.wave then
                self._waveindex = 0
            end
            self._waveindex = self._waveindex + 1
            local waveconfig = self.static.wave[self._waveindex]
            local delay = waveconfig[1]

            if delay and delay > 0 then
                self.timer:delay(delay, self._born, waveconfig)
            else
                self:_born(waveconfig)
            end
        end
    end
end

function logic:_born(waveconfig)
    for i = 2, #waveconfig do
        local groupid, min, max = table.unpack(waveconfig[i])
        local poslist = tsmath.random_select(self.static.group[groupid], tsmath.random(min, max))
        for _, position in ipairs(poslist) do
            self:_bornat(position)
        end
    end
    self._curwave = self._waveindex
end

function logic:_bornat(position)
    local seatid, x, y = table.unpack(position)
    local pos = tsvector.new(x, y)
    self.caller.born:queueborn(seatid, pos, (self.static.center - pos).normalized)
end

return logic
