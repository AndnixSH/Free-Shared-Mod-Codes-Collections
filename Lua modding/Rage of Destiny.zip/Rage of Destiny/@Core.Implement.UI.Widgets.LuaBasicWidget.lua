---@class LuaBasicWidget : GameObjFactor, NxFaceProxyDataEvt, LuaWidgetFactor
LuaBasicWidget = LuaBasicWidget or BaseClass(GameObjFactor, NxFaceProxyDataEvt , LuaWidgetFactor, TimerFactor, FrameUpdateFactor)

-- local RoleInfoView = RoleInfoView or BaseClass(LuaBasicWidget)
-- function RoleInfoView:__init()
-- 	self.fullScreenOption = { viewName = "xx"}
-- end

-- function RoleInfoView:OnLoad()
-- 	AssetManager.LoadUIPrefab(self, "Role.RoleInfoView",self.LoadEnd)
-- end

-- function RoleInfoView:LoadEnd(obj)
-- 	self:SetGo(obj)
-- 	self:SetStep(0)
-- end

-- function RoleInfoView:OnOpen()
-- end

-- function RoleInfoView:OnClose()
-- end

-- function RoleInfoView:OnDestroy()
-- end

--return RoleInfoView

-- local BountyTaskPanel = BountyTaskPanel or BaseClass(GameObjFactor)
-- function BountyTaskPanel:__init(go)
-- 	self.go = go
-- 	self:Load(go)	
-- end
-- function BountyTaskPanel:Load(obj)

-- end
-- function BountyTaskPanel:Open()
-- end	

-- function BountyTaskPanel:Close()
-- end	

-- function BountyTaskPanel:Destroy()
-- end

-- return BountyTaskPanel

-- local CrystalProxy = CrystalProxy or BaseClass(BaseProxy)
-- function CrystalProxy:__init()
-- 	CrystalProxy.Instance = self
-- end	

-- function CrystalProxy:__delete(self)
--     CrystalProxy.Instance = nil
-- end

-- return CrystalProxy