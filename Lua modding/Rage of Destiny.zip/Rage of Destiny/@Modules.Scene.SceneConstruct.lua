local SceneDef = require "Modules.Scene.SceneDef"
local SceneManager = require "Modules.Scene.SceneManager"
local AudioManager = require "Common.Mgr.Audio.AudioManager"

local LoginStrategy = require "Modules.Scene.Strategy.LoginStrategy"
local MainStrategy = require "Modules.Scene.Strategy.MainStrategy"
local HeroStrategy = require "Modules.Scene.Strategy.HeroStrategy"
local MainLineStrategy = require "Modules.Scene.Strategy.MainLineStrategy"
local TowerStrategy = require "Modules.Scene.Strategy.TowerStrategy"
local MazeStrategy = require "Modules.Scene.Strategy.MazeStrategy"
local HexMapBattleStrategy = require "Modules.Scene.Strategy.HexMapBattleStrategy"
local TempleStrategy = require "Modules.Scene.Strategy.TempleStrategy"
local StoryLineStrategy = require "Modules.Scene.Strategy.StoryLineStrategy"
local WorldMapStrategy = require "Modules.Scene.Strategy.WorldMapStrategy"
local DrawCardStrategy = require "Modules.Scene.Strategy.DrawCardStrategy"
local CrystalStrategy = require "Modules.Scene.Strategy.CrystalStrategy"
local ArenaStrategy = require "Modules.Scene.Strategy.ArenaStrategy"
local HighArenaStrategy = require "Modules.Scene.Strategy.HighArenaStrategy"
local TrainingStrategy = require "Modules.Scene.Strategy.TrainingStrategy"
local TrialStrategy = require "Modules.Scene.Strategy.TrialStrategy"
local FriendVersusStrategy = require "Modules.Scene.Strategy.FriendVersusStrategy"
local GuildBossStrategy = require "Modules.Scene.Strategy.GuildBossStrategy"
local SupplyDepotStrategy = require "Modules.Scene.Strategy.SupplyDepotStrategy"
local TestAllHeroStrategy = require "Modules.Scene.Strategy.TestAllHeroStrategy"
local CardStarStrategy = require "Modules.Scene.Strategy.CardStarStrategy"
local GuildStrategy = require "Modules.Scene.Strategy.GuildStrategy"
local DramaStrategy = require "Modules.Scene.Strategy.DramaStrategy"
local ActivityStrategy = require "Modules.Scene.Strategy.ActivityStrategy"
local GuildChaosStrategy = require "Modules.Scene.Strategy.GuildChaosStrategy"
local MobilizeStrategy = require "Modules.Scene.Strategy.MobilizeStrategy"

SceneConstruct = {}
--场景切换配置: strategy:每个场景单独一个策略, enterLoading:是否需要loading图, destroyStrategy:--是否清除其他Strategy(场景共存依据), destroyAsset:进入是否清除资源(目前只有UI)
--strategycfg = {loadSceneType(加载场景必带), activityid(活动id,加载战斗必带), gameid(玩法di,加载战斗必带), delaytime(战斗结束延迟打开结算界面) } 代入到strategy的参数, 选填
local _dicSceneTypeCofig = {
    [SceneDef.SceneType.Login] = { strategy = LoginStrategy, enterLoading = false, destroyStrategy = true, destroyAsset = true },
    [SceneDef.SceneType.Main] = { strategy = MainStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = true,
                                  strategycfg = { loadSceneType = AssetManager.LoadSceneType.Always, gameid = GAMEPLAYID.HANGUP, activityid = 0 } },

    [SceneDef.SceneType.Hero] = { strategy = HeroStrategy, enterLoading = false, destroyStrategy = true, destroyAsset = true,
                                  strategycfg = { loadSceneType = AssetManager.LoadSceneType.Temp } },

    [SceneDef.SceneType.HeroSwitch] = { strategy = HeroStrategy, enterLoading = false, destroyStrategy = true, destroyAsset = false,
                                  strategycfg = { loadSceneType = AssetManager.LoadSceneType.Temp } },

    [SceneDef.SceneType.MainLineBattle] = { strategy = MainLineStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = true,
                                            strategycfg = { loadSceneType = AssetManager.LoadSceneType.Always, activityid = ACTIVITYID.MAINLINE, gameid = GAMEPLAYID.MAINLINE } },

    [SceneDef.SceneType.TowerBattle] = { strategy = TowerStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = true,
                                         strategycfg = { loadSceneType = AssetManager.LoadSceneType.Temp, activityid = ACTIVITYID.TOWER, gameid = GAMEPLAYID.MAINLINE } },

    [SceneDef.SceneType.Maze] = { strategy = MazeStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = false,
                                  strategycfg = { loadSceneType = AssetManager.LoadSceneType.Temp } },

    [SceneDef.SceneType.MazeBattle] = { strategy = HexMapBattleStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = true,
                                        strategycfg = { loadSceneType = AssetManager.LoadSceneType.Temp, activityid = ACTIVITYID.MAZE, gameid = GAMEPLAYID.MAINLINE, delaytime = 1 } },

    [SceneDef.SceneType.Temple] = { strategy = TempleStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = false,
                                    strategycfg = { loadSceneType = AssetManager.LoadSceneType.Never } },

    [SceneDef.SceneType.StoryLine] = { strategy = StoryLineStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = true,
                                       strategycfg = { loadSceneType = AssetManager.LoadSceneType.Never } },

    [SceneDef.SceneType.StoryLineBattle] = { strategy = HexMapBattleStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = true,
                                             strategycfg = { loadSceneType = AssetManager.LoadSceneType.Temp, activityid = ACTIVITYID.STORYLINE, gameid = GAMEPLAYID.MAINLINE } },
    
    [SceneDef.SceneType.Activity] = { strategy = ActivityStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = true,
                                             strategycfg = { loadSceneType = AssetManager.LoadSceneType.Never } },
    
    [SceneDef.SceneType.ActivityBattle] = { strategy = HexMapBattleStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = true,
                                             strategycfg = { loadSceneType = AssetManager.LoadSceneType.Temp, activityid = ACTIVITYID.ACTIVITY, gameid = GAMEPLAYID.MAINLINE } },
    
    [SceneDef.SceneType.WorldMap] = { strategy = WorldMapStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = false,
                                      strategycfg = { loadSceneType = AssetManager.LoadSceneType.Never } },

    [SceneDef.SceneType.DrawCard] = { strategy = DrawCardStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = false,
                                      strategycfg = { loadSceneType = AssetManager.LoadSceneType.Never } },

    [SceneDef.SceneType.Crystal] = { strategy = CrystalStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = false,
                                     strategycfg = { loadSceneType = AssetManager.LoadSceneType.Never } },

    [SceneDef.SceneType.ArenaBattle] = { strategy = ArenaStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = true,
                                         strategycfg = { loadSceneType = AssetManager.LoadSceneType.Temp, activityid = ACTIVITYID.ARENA, gameid = GAMEPLAYID.MAINLINE } },

    [SceneDef.SceneType.HighArenaBattle] = { strategy = HighArenaStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = true,
                                             strategycfg = { loadSceneType = AssetManager.LoadSceneType.Temp, activityid = ACTIVITYID.HIGHARENA, gameid = GAMEPLAYID.MAINLINE } },

    [SceneDef.SceneType.TrainingBattle] = { strategy = TrainingStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = true,
                                            strategycfg = { loadSceneType = AssetManager.LoadSceneType.Temp, activityid = ACTIVITYID.TRAINING, gameid = GAMEPLAYID.TRAINING } },

    [SceneDef.SceneType.TrialBattle] = { strategy = TrialStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = true,
                                         strategycfg = { loadSceneType = AssetManager.LoadSceneType.Temp, activityid = ACTIVITYID.TRIAL, gameid = GAMEPLAYID.TRAINING } },

    [SceneDef.SceneType.FriendVersusBattle] = { strategy = FriendVersusStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = true,
                                                strategycfg = { loadSceneType = AssetManager.LoadSceneType.Temp, activityid = ACTIVITYID.FRIEND_VERSUS, gameid = GAMEPLAYID.MAINLINE } },

    [SceneDef.SceneType.GuildVersusBattle] = { strategy = GuildStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = true,
                                               strategycfg = { loadSceneType = AssetManager.LoadSceneType.Temp, activityid = ACTIVITYID.GUILD_VERSUS, gameid = GAMEPLAYID.MAINLINE } },

    [SceneDef.SceneType.GuildBossBattle] = { strategy = GuildBossStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = true,
                                             strategycfg = { loadSceneType = AssetManager.LoadSceneType.Temp, activityid = ACTIVITYID.GUILD_BOSS, gameid = GAMEPLAYID.MAINLINE } },

    [SceneDef.SceneType.GuildChaosBattle] = { strategy = GuildChaosStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = true,
                                             strategycfg = { loadSceneType = AssetManager.LoadSceneType.Temp, activityid = ACTIVITYID.GUILD_CHAOS, gameid = GAMEPLAYID.MAINLINE } },

    [SceneDef.SceneType.SupplyDepotBattle] = { strategy = SupplyDepotStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = true,
                                               strategycfg = { loadSceneType = AssetManager.LoadSceneType.Temp, activityid = ACTIVITYID.SUPPLY_DEPOT, gameid = GAMEPLAYID.MAINLINE } },

    [SceneDef.SceneType.TEST_ALL_HERO] = { strategy = TestAllHeroStrategy, enterLoading = false, destroyStrategy = true, destroyAsset = true,
                                           strategycfg = { loadSceneType = AssetManager.LoadSceneType.Temp, activityid = ACTIVITYID.TEST_ALL_HERO, gameid = 1004 } },

    [SceneDef.SceneType.CardStar] = { strategy = CardStarStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = true,
                                      strategycfg = { loadSceneType = AssetManager.LoadSceneType.Temp }},

    [SceneDef.SceneType.Drama] = { strategy = DramaStrategy, enterLoading = false, destroyStrategy = true, destroyAsset = true,
                                    strategycfg = {loadSceneType = AssetManager.LoadSceneType.Never}},

    [SceneDef.SceneType.MobilizeBattle] = { strategy = MobilizeStrategy, enterLoading = true, destroyStrategy = true, destroyAsset = true,
                                    strategycfg = { loadSceneType = AssetManager.LoadSceneType.Temp, activityid = ACTIVITYID.MOBILIZE, gameid = GAMEPLAYID.MAINLINE } },
}

local _scenesStrategyList = {} --多场景共存
local _sceneConfig = nil
local _sceneStrategy = nil
local _bload = true

function SceneConstruct.InitScene(sceneType, ...)
    --场景初始化 
    _sceneConfig = _dicSceneTypeCofig[sceneType]
    if not _sceneConfig then
        print('scenes no init congfig :', sceneType)
        return
    end

    _sceneConfig.sceneType = sceneType
    SceneConstruct.enterLoading = _sceneConfig.enterLoading

    if _scenesStrategyList[sceneType] then
        -- SceneConstruct.enterLoading = false
        _sceneStrategy = _scenesStrategyList[sceneType]
        _sceneStrategy.args = { ... }
        _bload = true
    else
        _sceneStrategy = _sceneConfig.strategy.New(...)
        _sceneStrategy:SetStrategyCfg(_sceneConfig.strategycfg)
        _bload = true
    end

    SceneManager.Instance:SceneEventInit()
    _sceneStrategy:Inspection()
end

function SceneConstruct.StartLoadScene()
    local sceneType = _sceneConfig.sceneType
    SceneConstruct.CleanScene()

    if _sceneConfig.destroyAsset then
        SceneConstruct.DestroyAsset()
    end

    --是否清除其他Strategy
    if _sceneConfig.destroyStrategy then
        for curtype, strategy in pairs(_scenesStrategyList) do
            if curtype ~= sceneType then
                strategy:Destroy()
                _scenesStrategyList[curtype] = nil
            end
        end

    elseif _scenesStrategyList[sceneType] then
        _scenesStrategyList[sceneType]:Destroy()
        _scenesStrategyList[sceneType] = nil
    end

    --开始进入场景
    if _bload then
        _sceneStrategy:OnLoad()
        _scenesStrategyList[sceneType] = _sceneStrategy
    else
        _sceneStrategy:OnStartEntry()
        SceneManager.Instance:SceneEventEnd()
    end

    _sceneConfig = nil
    _sceneStrategy = nil
end

function SceneConstruct.CleanScene()
    UILayerTool.InitDepth()
    AudioManager.StopAllAudio()
    LuaLayout.Instance:CloseAllWidget()
end

function SceneConstruct.CleanSceneByType(sceneType)
    SceneConstruct.CleanScene()

    if _scenesStrategyList[sceneType] then
        _scenesStrategyList[sceneType]:Destroy()
        _scenesStrategyList[sceneType] = nil
    end
end

function SceneConstruct.CleanAllScene()
    _sceneConfig = nil
    _sceneStrategy = nil
    for _, strategy in pairs(_scenesStrategyList) do
        strategy:Destroy()
    end
    _scenesStrategyList = {}
end

function SceneConstruct.DestroyAsset()
    UILayerTool.InitDepth()
    SceneManager.Instance:SceneEventFree()
    AudioManager.DestroyAllAudio()
    LuaLayout.Instance:DestroyAllWidget()
    AssetManager.ClearUITexture()

    local render_area = require "Battle.render.render_area"
    render_area.destroy()

    print(string.format("begin count: %.2fM", collectgarbage("count") / 1024))
    collectgarbage('collect')
    print(string.format("after count: %.2fM", collectgarbage("count") / 1024))
end