local NewbieProxy = require "Modules.Newbie.NewbieProxy"
local NewbieDef = require "Modules.Newbie.NewbieDef"
local NewbieManager = require "Modules.Newbie.NewbieManager"
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"

local NewbieWeakGuildView = NewbieWeakGuildView or LuaWidgetClass()

function NewbieWeakGuildView.ShowView(parama)
	NewbieWeakGuildView.selectObj = parama.selectObj
	NewbieWeakGuildView.cfg = parama.cfg
	NewbieWeakGuildView.newbie_id = parama.newbieid
	LuaLayout.Instance:OpenWidget(UIWidgetNameDef.NewbieWeakGuildView)
	
end

function NewbieWeakGuildView:__init()
	self.data = nil
	self.selectObj = nil
end

function NewbieWeakGuildView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Newbie.NewbieDialogView", self.LoadEnd)
end

function NewbieWeakGuildView:LoadEnd(obj)
	self:SetGo(obj)
	self:InitUI()
	self:SetStep(0)
end

function NewbieWeakGuildView:InitUI()
	self.backObj = self:GetChild(self.go, "mask")
	self.backObj:SetActive(true)
	self.backBtn = self:GetChildComponent(self.go, "mask/Black", "CButton")
	self.backBtn.gameObject:SetActive(false)
	self.weakBtn = self:GetChildComponent(self.go, "mask/BlackWeak", "CButton")
	self.weakBtn.gameObject:SetActive(true)
	self.weakBtn:AddClick(function()
		self:CloseView()
		self:OnClickBack()
	end)

	self.contentObj = self:GetChild(self.go, "CSprite_Root")
	
	-- self.contentLab = self:GetChildComponent(self.contentObj, "CSprite_DialogBox/CLabel_New", "CLabel")
	self.effectRoot = self:GetChild(self.go, "Effect_Root")
	self.effectObj1 = self:GetChild(self.effectRoot, "Effect_1")
	self.effectObj2 = self:GetChild(self.effectRoot, "Effect_2")

	self.boxObjs = {}
	for i=1,4 do
		local item = {}
		local obj = self:GetChild(self.contentObj, string.format("CSprite_DialogBox%d", i))
		item.obj = obj
		item.contentLab = self:GetChildComponent(obj, "CLabel_New", "CLabel")
		table.insert(self.boxObjs, item)
	end
	
	--跳过引导
	self.notNewbieObj = self:GetChild(self.contentObj, "CSprite_New")
	self.notNewbieObj:SetActive(false)
	self.notNewbieBtn = self:GetChildComponent(self.contentObj, "CSprite_New", "CButton")
	self.notNewbieBtn:AddClick(function()
		NewbieManager.Instance:NextStep()
		NewbieProxy.Instance:Send18001(NewbieDef.NewbieConst.NotNewbie, NewbieDef.State.Complete)
		self:CloseView()
	end)
end

function NewbieWeakGuildView:ClearEffect()
	if self.effect1 then
		self.effect1:Destroy()
	end
	if self.effect2 then
		self.effect2:Destroy()
	end
	if self.figer_effect then
		self.figer_effect:Destroy()
	end
end

function NewbieWeakGuildView:CreateEffect()
	self.effect1 = UIEffectItem.New("UI_Common_FingerClick2_m", self.effectObj1)
	self.effect1:SetScale(2,2,2)
	self.effect2 = UIEffectItem.New("UI_newbie_1", self.effectObj1)
	
	self.figer_effect = UIEffectItem.New("UI_Common_FingerClick1_m", self.effectObj2)
	self.figer_effect:SetScale(2,2,2)
end

function NewbieWeakGuildView:ShowContentObj()
	self:ClearTween()
	for i,item in ipairs(self.boxObjs) do
		local bActive = false
		if self.cfg and self.cfg.npcSp then
			if i == self.cfg.npcSp then
				bActive = true
			end
		end
		if bActive and self.cfg.content then
			item.obj:SetActive(true)
			item.contentLab.text = self:GetWord(self.cfg.content)
			--self:ShowSpineAnim(self.cfg, item.spine_view)
			self.scaleSeq = self:PlayAnim(item.obj)
		else
			item.obj:SetActive(false)
		end
	end
end

function NewbieWeakGuildView:ClearTween()
	if self.scaleSeq then
		self.scaleSeq:Kill()
		self.scaleSeq = nil
	end
end

function NewbieWeakGuildView:PlayAnim(obj)
	obj:SetActive(true)
	obj.transform.localScale = Vector3.New(0,0,0)
	local sequence = DOTween.Sequence()
	local tween = obj.transform:DOScale(Vector3.New(1,1,1), 0.3)
	tween:SetEase(Ease.OutBack)
	sequence:Append(tween)
	return sequence
end

function NewbieWeakGuildView:OnOpen()
	self:CreateEffect()
	self.notNewbieObj:SetActive(SystemConfig.is_gm)
	self.effect1:Close()
	self.effect2:Close()
	self.figer_effect:Close()

	local depth = self:GetNextDepth()
	self.go:SetActive(true)
	self:SetDepth(self.go, NewbieDef.NewbieDepths.NewbieView)
	self.selectObj = NewbieWeakGuildView.selectObj
	self.cfg = NewbieWeakGuildView.cfg
	self.newbieid = NewbieWeakGuildView.newbie_id

	NewbieWeakGuildView.selectObj = nil
	NewbieWeakGuildView.cfg = nil
	NewbieWeakGuildView.newbie_id = nil

	if self.selectObj and self.cfg then
		self:UpdateView()
	else
		self:CloseView()
	end
	self:StartFrame()
	NewbieProxy.Instance:EnableNewbieMaskView(false)
end

function NewbieWeakGuildView:CloseSpines()
	for i,item in ipairs(self.boxObjs) do
		item.spine_view:Close()
	end
end

function NewbieWeakGuildView:ReleaseSpines()
	for i,item in ipairs(self.boxObjs) do
		item.spine_view:Release()
	end
end

function NewbieWeakGuildView:DestroySpines()
	for i,item in ipairs(self.boxObjs) do
		item.spine_view:Destroy()
	end
end

function NewbieWeakGuildView:OnClose()
	if self.selectObj then
		if self.cfg and not self.cfg.bnewObj then
			self:SetDepth(self.selectObj, 0)
			if self.selectLayer then
				self.selectObj.layer = self.selectLayer
				self.selectLayer = nil
			end
		end
	end
	self.selectObj = nil

	self.effect1:Close()
	self.effect2:Close()
	self.figer_effect:Close()
	NewbieWeakGuildView.selectObj = nil
	NewbieWeakGuildView.cfg = nil
	NewbieWeakGuildView.newbie_id = nil
	self:ClearEffect()
	self:ClearTween()
	self:EndFrame()
end

function NewbieWeakGuildView:OnDestroy()
	if self.selectObj then
		if self.cfg and not self.cfg.bnewObj then
			self:SetDepth(self.selectObj, 0)
			if self.selectLayer then
				self.selectObj.layer = self.selectLayer
				self.selectLayer = nil
			end
		end
	end
	self.selectObj = nil
	self.spine_name = nil
	self.spine_active = nil

	NewbieWeakGuildView.selectObj = nil
	NewbieWeakGuildView.cfg = nil
	NewbieWeakGuildView.newbie_id = nil
	self:ClearEffect()
	self:ClearTween()
	self:EndFrame()
end

function NewbieWeakGuildView:UpdateView()
	if self.cfg.view then
		local view = LuaLayout.Instance:GetWidget(self.cfg.view)
		if (not view:IsOpen() and not view:IsLoading()) or (view:IsOpen() and view.fullhide) then
			self.selectObj = nil
			self:CloseView()
			return
		end
	end

	if self.newbieid then
		NewbieProxy.Instance:Send18002(self.newbieid)
	end
	
	self:ShowContentObj()

	local contentObj_Offset = Vector3.New(0,0,0)
	if self.cfg and self.cfg.dialog_offset then
		contentObj_Offset = contentObj_Offset + Vector3.New(self.cfg.dialog_offset[1], self.cfg.dialog_offset[2], 0)
	end
	self.contentObj.transform.localPosition = contentObj_Offset
	self:SetDepth(self.contentObj, NewbieDef.NewbieDepths.NewbieBtn+5)	
	if self.selectObj then

		self:SetDepth(self.effectRoot, NewbieDef.NewbieDepths.NewbieEffect)
		local position = self.selectObj.transform.position
		self.effectRoot.transform.position = position
		local localPosition = self.effectRoot.transform.localPosition
		local offsetVec3 = Vector3.New(self.cfg.effect_offset[1]+localPosition.x, self.cfg.effect_offset[2]+localPosition.y, 0)
		self.effectRoot.transform.localPosition = offsetVec3

		self.contentObj.transform.position = position
		localPosition = self.contentObj.transform.localPosition
		offsetVec3 = Vector3.New(contentObj_Offset.x+localPosition.x, contentObj_Offset.y+localPosition.y, 0)
		self.contentObj.transform.localPosition = offsetVec3

		if self.cfg.bnewObj then
			local obj = GameObjTools.AddChild(self.go, self.selectObj)		
			local btn = self:GetComponent(obj, "CButton")
			self:SetChildDepth(obj, self:GetNextDepth(), true)
			btn:AddClick(function ()
				obj:SetActive(false)
				GameUIUtil.ApplayClickEvent(self.selectObj)
				self:CloseView()
				NewbieManager.Instance:NextStep()			
			end)
			obj.transform.localPosition = localPosition
		else
			self.selectLayer = self.selectObj.layer
			self:SetDepth(self.selectObj, NewbieDef.NewbieDepths.NewbieBtn, true)
		end
	end

	if self.cfg.effectType then
		local depth1 = NewbieDef.NewbieDepths.NewbieEffect+6
		local depth2 = NewbieDef.NewbieDepths.NewbieEffect+7
		if self.cfg.effectType == 1 then

			self:SetDepth(self.effectObj1, depth1)
			self:SetDepth(self.effectObj2, depth2)
			self.effect1:SetOrderLayer(depth1)
			self.effect1:Open()
			self.effect1:SetScale(2,2,2)
			self.figer_effect:SetOrderLayer(depth2)
			self.figer_effect:Open()
			self.figer_effect:SetScale(2,2,2)
		elseif self.cfg.effectType == 2 then
			self:SetDepth(self.effectObj1, depth1)
			self:SetDepth(self.effectObj2, depth2)
			self.effect2:SetOrderLayer(depth1)
			self.effect2:Open()
		end

	end

	-- self.contentLab.text = self:GetWord(self.cfg.content)
end

function NewbieWeakGuildView:OnClickBack()
	if self.newbieid then
		NewbieManager.Instance:CompleteNewbie(self.newbieid)
	end
end

function NewbieWeakGuildView:FrameUpdate()
	if self.selectObj and self.cfg then
		local position = self.selectObj.transform.position
		self.effectRoot.transform.position = position
		local localPosition = self.effectRoot.transform.localPosition
		local offsetVec3 = Vector3.New(self.cfg.effect_offset[1]+localPosition.x, self.cfg.effect_offset[2]+localPosition.y, 0)
		self.effectRoot.transform.localPosition = offsetVec3

		self.contentObj.transform.position = position
		localPosition = self.contentObj.transform.localPosition
		offsetVec3 = Vector3.New(self.cfg.dialog_offset[1]+localPosition.x, self.cfg.dialog_offset[2]+localPosition.y, 0)
		self.contentObj.transform.localPosition = offsetVec3	
		
		if not self.cfg.bnewObj then
			if not self.selectObj.gameObject.activeInHierarchy then
				local obj = self.selectObj
				while obj do
					if not obj.activeSelf then
						obj.gameObject:SetActive(true)
					end
					obj = obj.transform.parent
				end
			end
			
			local canvas = GameObjTools.TryGetComponent(self.selectObj, "Canvas")
			if canvas then
				if not canvas.overrideSorting then
					canvas.overrideSorting = true
				end
				if canvas.sortingOrder < NewbieDef.NewbieDepths.NewbieBtn then
					self:SetDepth(self.selectObj, NewbieDef.NewbieDepths.NewbieBtn, true)
				end
			end
		end	
	end
end


return NewbieWeakGuildView