ConfigManager.InitConfig('data_goodsrank', {
[1]={id=1,frame="daojukuang_1",raceback="87858a"},
[2]={id=2,frame="daojukuang_2",raceback="5d8167"},
[3]={id=3,frame="daojukuang_3",raceback="88b3e8"},
[4]={id=4,frame="daojukuang_3",frameangle="daojukuang_plus1",raceback="88b3e8"},
[5]={id=5,frame="daojukuang_5",raceback="ae85cc"},
[6]={id=6,frame="daojukuang_5",frameangle="daojukuang_plus2",raceback="ae85cc"},
[7]={id=7,frame="daojukuang_7",raceback="f0dd8f"},
[8]={id=8,frame="daojukuang_7",frameangle="daojukuang_plus3",raceback="f0dd8f"},
[9]={id=9,frame="daojukuang_9",raceback="f5aa98"},
[10]={id=10,frame="daojukuang_9",frameangle="daojukuang_plus4",raceback="f5aa98"},
[11]={id=11,frame="daojukuang_9",frameangle="daojukuang_plus5",raceback="f5aa98"},
[12]={id=12,frame="daojukuang_12",raceback="cad1f6"},
})