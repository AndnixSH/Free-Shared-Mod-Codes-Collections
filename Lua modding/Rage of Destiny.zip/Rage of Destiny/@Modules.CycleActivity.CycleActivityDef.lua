local CycleActivityDef = {}
local RedPointDef = require "Modules.RedPoint.RedPointDef"
local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
CycleActivityDef.NotifyDef = {
   
   Update_Seven_Login = "Update_Seven_Login",

   CycleActivityEnd = "CycleActivityEnd"
}

CycleActivityDef.CommonDef={
  
    Days = "Activityinfo_1009",
    CountTime = "Activityinfo_1008",
    Nine_Grid_Type1 = "ActivitySquareNine_1001",--在单场战斗(仅巨龙巢穴，主线推关，赎罪之塔)使用%s个及以上%s型英雄获得战斗胜利%s次
    Nine_Grid_Type2 = "ActivitySquareNine_1002",--累计收集%s名%s精英(紫色)英雄
    Nine_Grid_Type3 = "ActivitySquareNine_1003",--扫荡%s次矮人宝库
    Nine_Grid_Type4 = "ActivitySquareNine_1004",--使用快速挂机%s次
    Nine_Grid_Type5 = "ActivitySquareNine_1005",--击败巨龙巢穴首领%s次
    Nine_Grid_Type6 = "ActivitySquareNine_1006",--赠送友情点%s点
    Nine_Grid_Type7 = "ActivitySquareNine_1007",--获得竞技场胜利%s场
    Nine_Grid_Type8 = "ActivitySquareNine_1008",--完成贸易航线团队订单%s个
    Nine_Grid_Tips3 = "ActivitySquareNine_1009", --活动临时维护中请稍后
    Nine_Grid_Tips = "ActivitySquareNine_1015", --完成全部任务获得一个英雄自选宝箱（%s/%s）
    Nine_Box_Tips = "ActivitySquareNine_1010",--寻宝任务%s
    Nine_Grid_Tips2 = "ActivitySquareNine_1011",--任务%s
    Nine_Box_Tips2 = "ActivitySquareNine_1012",--完成任务%s可获得奖励
    Get = "TaskView_1007",--领取
    Go = "TaskView_1006",--前往
}

CycleActivityDef.Events_Type={
  
    Seven_Login_One = 1,
    Seven_Login_Two = 2,
    Nine_Grid_One = 3,
    Private_Make = 4,--商城私人定制
    MobilizeActivity = 5,--命运总动员
}

CycleActivityDef.NineGridIdList={

    [1] = CycleActivityDef.Events_Type.Nine_Grid_One,
}

CycleActivityDef.BGName={
  [ CycleActivityDef.Events_Type.Seven_Login_Two] = "Tex_Bg_7dayscheckinEvents",
  [CycleActivityDef.Events_Type.Nine_Grid_One] = "Tex_Bg_party",
}

CycleActivityDef.TexName={
    [CycleActivityDef.Events_Type.Nine_Grid_One] = "partyback",
}
  
CycleActivityDef.SloganSprName={
    [CycleActivityDef.Events_Type.Nine_Grid_One] = "sloganparty",
}

CycleActivityDef.SevenLoginIdList =
{
    [1] = CycleActivityDef.Events_Type.Seven_Login_One,
    [2] = CycleActivityDef.Events_Type.Seven_Login_Two,
    [3] = CycleActivityDef.Events_Type.Nine_Grid_One,
}

CycleActivityDef.RedPointIdList =
{
    [1] = RedPointDef.Id.Events_Seven_Login,
    [2] = RedPointDef.Id.Events_Seven_Login_Two,
    [3] = RedPointDef.Id.Nine_Grid,
}

CycleActivityDef.SystemOpen =
{
    [1] = ModuleOpenDef.SystemOpenType.CycleActivityRoot,
    [2] = ModuleOpenDef.SystemOpenType.CycleSevenLoginTypeTwoView,
    [3] = ModuleOpenDef.SystemOpenType.EventsNineBoxView, 
}

CycleActivityDef.Reward_State ={
    UnGet = 0,
    CannotGet = 1,
    HasGet= 2,
 }

 CycleActivityDef.NineGridRewardType = 
 {
     Grid = 1,
     Box = 2,
 }

 CycleActivityDef.HeroPos=
 {
     --roleid，hero_tex pos ,spine pos,sloganSpr name, spine rotation
     [CycleActivityDef.Events_Type.Seven_Login_Two] = {4205,Vector3.New(0,0,0),Vector3.New(250, -550),"Activity_Login_Clown_1002",180}
 }


--九宫格
CycleActivityDef.Nine_Grid_Task_Type = {
    ChallengeInSingleBattle = 1, --在单场战斗(仅巨龙巢穴，主线推关，赎罪之塔)使用%d(2)个及以上%d(辅助)获得战斗胜利%d(20)次
    CollectHero = 2,--累计收集%d(2)名(%d)(蛮荒)精英紫色英雄
    ChallengeGuildBoss = 3,--扫荡20次矮人宝库
    UseQuickHangUp = 4,--使用快速挂机10次
    WinBossInDragon = 5,--击败巨龙巢穴boss10次
    SendFriendLoves = 6,-- 赠送友情点100点
    Win_Arena_Times = 7,--取得30场竞技场胜利
    Finish_Trade_Order = 8,--贸易航线完成订单12个
  }

  CycleActivityDef.NineGridTaskOpenViews={
    [CycleActivityDef.Nine_Grid_Task_Type.ChallengeInSingleBattle] = {AppFacade.Tower,2},
    [CycleActivityDef.Nine_Grid_Task_Type.CollectHero] ={AppFacade.CardPortal},
    [CycleActivityDef.Nine_Grid_Task_Type.ChallengeGuildBoss] = "",
    [CycleActivityDef.Nine_Grid_Task_Type.UseQuickHangUp] = "",
    [CycleActivityDef.Nine_Grid_Task_Type.WinBossInDragon] ={AppFacade.Maze},
    [CycleActivityDef.Nine_Grid_Task_Type.SendFriendLoves] ={AppFacade.Friend},
    [CycleActivityDef.Nine_Grid_Task_Type.Win_Arena_Times] ={AppFacade.Arena,1},
    [CycleActivityDef.Nine_Grid_Task_Type.Finish_Trade_Order] = {AppFacade.SupplyDepot},
  }
return CycleActivityDef