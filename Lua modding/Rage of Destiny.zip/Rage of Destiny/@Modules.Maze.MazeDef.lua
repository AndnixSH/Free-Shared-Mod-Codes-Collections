local MazeDef = {}
MazeDef.NotifyDef = 
{
	Update_Maze_Map = "Update_Maze_Map",
	Update_Maze_Info = "Update_Maze_Info",
	Update_Hero_List = "Update_Hero_List",
	Update_Dragon_Level = "Update_Dragon_Level",
	Update_Set_HeroList_Result = "Update_Set_HeroList_Result",
	Maze_Complete = "Maze_Complete",
	Maze_Select_Index = "Maze_Select_Index",
	Update_Maze_Level = "Update_Maze_Level",
	Update_Maze_Battle_Count = "Update_Maze_Battle_Count",
	Update_Maze_Rainbow_Egg = "Update_Maze_Rainbow_Egg",
	OnCurrentRewards = "OnCurrentRewards",
}

--[[ 关卡类型
	1 普通 2 困难 3 彩蛋 ]]
MazeDef.LevelType =
{
	Normal = 1,
	Difficulty = 2,
	Easter = 3,
}

--[[ 副本类型
	1 普通 2 新手
]]
MazeDef.CopyClass = 
{
	Normal = 1, -- 普通
	Newbie = 2, -- 新手
}

MazeDef.HP_ZERO_TIPS_NUM = 5

return MazeDef