local BattleProxy = require "Modules.Battle.BattleProxy"
local BasicSceneStrategy = require "Modules.Scene.Strategy.BasicSceneStrategy"
local HeroStrategy = HeroStrategy or BaseClass(BasicSceneStrategy)
local max_hero_cache = 10
local hero_cache = {}

local function update_hero_cache(newid)

    for i, cacheid in ipairs(hero_cache) do
        if cacheid == newid then
            return
        end
    end

    table.insert(hero_cache, newid)
    if #hero_cache > max_hero_cache then
        table.remove(hero_cache, 1)
    end
end

function HeroStrategy.ClearCache()
    hero_cache = {}
end

--英雄展示
function HeroStrategy:OnLoad()
    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.NetworkDelayView)

    local config = ConfigManager.GetConfig("data_common")["hero_scenes_background"]
    self.selectid = self.args[1]
    self.herolist = self.args[2]
    self.raceid = self.args[3] or 1
    self.tabIndex = self.args[4] or 1
    self.mercenaryInfo = self.args[5]
    local sceneId = config.value1[self.raceid]

    update_hero_cache(self.selectid)

    self:LoadScene(sceneId)
end

function HeroStrategy:OnScenePreload(loader)

    -- 加这个是为了销毁特效active，要不然ResetAll会报错
    local render_area = require "Battle.render.render_area"
    render_area.destroy()

    local HeroProxy = require "Modules.Hero.HeroProxy"
    local active_config = faceConfig["data_active"]

    for i, herouid in ipairs(hero_cache) do
        local herocfg = HeroProxy.Instance:GetHeroCfgByUid(herouid)
        if herocfg then
            local spritecfg = HeroProxy.Instance:GetSpriteConfigeById(herocfg.id)
            if spritecfg and spritecfg.prefab_ex_id and spritecfg.prefab_ex_id[1] then
                loader.AddLoad({key=spritecfg.prefab_ex_id[1], type = AssetType.ACTOR})

                local active_name = spritecfg.id .. "_ex"
                local current_active_info = active_config[active_name]
                if current_active_info and current_active_info["appearance"] then
                    local appearance_active_info = current_active_info["appearance"]
                    for _, active_item_info in ipairs(appearance_active_info) do
                        if active_item_info.type == "effect" then
                            loader.AddLoad({key = active_item_info.name, type = AssetType.EFFECT })
                        end
                    end
                end
            end
        end
    end


end

function HeroStrategy:Destroy()
    self:UnloadScene()
    BattleProxy.Instance:StopGame()
end

function HeroStrategy:OnStartEntry()
    self:DefaultOpenWidgets()
end

function HeroStrategy:DefaultOpenWidgets()
    BattleProxy.Instance:StopGame()
    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.ItemDropView)
    UIOperateManager.Instance:OpenWidget(AppFacade.Hero, 1, self.selectid, self.herolist, self.tabIndex, self.mercenaryInfo)
end

return HeroStrategy