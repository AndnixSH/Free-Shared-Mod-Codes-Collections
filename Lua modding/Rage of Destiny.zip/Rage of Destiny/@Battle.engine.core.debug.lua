local debug = { _enable = true }

function debug.init(benable)
    debug._enable = benable
end

function debug.info(...)
    if debug._enable then
        print(...)
    end
end

function debug.info2(para)
    if type(para) == 'table' then
        debug.printtable(para)
    else
        debug.info(para)
    end
end

function debug.warning(...)
    if debug._enable then
        print("<b><color=yellow>【warning】</color></b>", ...)
    end
end

function debug.error(...)
    if debug._enable then
        print("<b><color=red>【error】</color></b>", ...)
    end
end

function debug.table(tb)
    if debug._enable then
        return global.array.tostring(tb)
    end
end

function debug.pause()
end

function debug.printtable(tb, depth)
    if debug._enable then
        depth = depth or 5
        local function gettablestr(_tb, _depth)
            local str = {}
            _depth = _depth + 1
            for k, v in pairs(_tb) do

                local vs = tostring(v)
                if type(v) == 'table' then
                    local mt = getmetatable(v)
                    if (not mt or not mt.__tostring) and _depth <= depth then
                        vs = gettablestr(v, _depth)
                    end
                end

                table.insert(str, string.format("%s = %s", k, vs))
            end
            return "{ " .. table.concat(str, ", ") .. " }"
        end
        
        print(gettablestr(tb, 1))
    end
end



return debug