local RelationItem = require "Core.Implement.UI.Class.RelationItem"
local BattleRelationItem = require "Core.Implement.UI.Class.BattleRelationItem"
local BattleProxy = require "Modules.Battle.BattleProxy"
local DateFormatUtil = require "Common.Util.DateFormatUtil"
local TweenTools =  require "Common.Util.TweenTools"
local CampaignProxy = require "Modules.Campaign.CampaignProxy"
local TowerProxy = require "Modules.Tower.TowerProxy"

local TopHandle = TopHandle or BaseClass(GameObjFactor)
function TopHandle:__init(obj, title)
	self.go = obj
	self:InitObj(obj)
	self:InitTitleObj(title) --主线和爬塔提示第几关，其他战斗暂时为空
end

function TopHandle:InitObj(obj)
	self.rect = self:GetComponent(obj, "RectTransform")
	self.rectPosition = self.rect.anchoredPosition

	self.tipsInfoObj = self:GetChild(obj, "info/tips")

	self.boxcollider = self:GetChildComponent(self.tipsInfoObj, "Black", "CBoxCollider")
	self.boxcollider:AddClick(function(go)
			self.tipsInfoObj:SetActive(false)
		end)
	self.tipsBtn = self:GetChildComponent(obj, "info/CButton_info", "CButton")
	self.tipsBtn:AddClick(function ()
			self:OnClickTips()
		end)

	self.coinBtn = self:GetChildComponent(obj, "money/coin", "CButton")
	self.coinBtn:AddClick(function ()
			GameLogicTools.ShowLabelTips("unity_tips_1001", self.coinBtn.transform.position)
		end)

	self.boxBtn = self:GetChildComponent(obj, "money/box", "CButton")
	self.boxBtn:AddClick(function ()
			GameLogicTools.ShowLabelTips("unity_tips_1002", self.boxBtn.transform.position)
		end)

	self.timeBtn = self:GetChildComponent(obj, "time", "CButton")
	self.timeBtn:AddClick(function ()
			GameLogicTools.ShowLabelTips("unity_tips_1003", self.timeBtn.transform.position)
		end)

	self.cameraBtn = self:GetChildComponent(obj, "CButton_Camera", "CButton")
	self.cameraBtn:AddClick(function ()
			self:OnClickCamera()
		end)

	self.leftRelationItem = BattleRelationItem.New(self:GetChild(obj, "jiban1/fill"), CAMP.BLUE, 2)
	self.rightRelationItem = BattleRelationItem.New(self:GetChild(obj, "jiban2/fill"), CAMP.RED, 2)

	self.relationBtn_1 = self:GetChildComponent(obj, "jiban1/CSprite_back", "CButton")
	self.relationBtn_1:AddClick(function ()
			self:OnClickRelation(CAMP.RED)
		end)
	self.relationBtn_2 = self:GetChildComponent(obj, "jiban2/CSprite_back", "CButton")
	self.relationBtn_2:AddClick(function ()
			self:OnClickRelation(CAMP.BLUE)
		end)

	self.timeLbl = self:GetChildComponent(obj, "time/CLabel_time", "CLabel")
	
	self.record = self:GetChild(obj, "record")
end

function TopHandle:InitTitleObj(title)
	if title then
		self.title = title
		self.titleLabel = self:GetChildComponent(self.title, "CLabel_num", "CLabel")
	end
end

function TopHandle:Open(data)
	self:StartOpenTween()
	self:StartTitleTween()
	self:ShowRelationItem()
	self.timeLbl.color = Color.white
	if data and data.activityid then
		if data.activityid == ACTIVITYID.TRIAL then
			self.timeBtn.gameObject:SetActive(false)
		else
			self.timeBtn.gameObject:SetActive(true)
		end
	else
		self.timeBtn.gameObject:SetActive(true)
	end
	
	self.record:SetActive(BattleProxy.Instance:IsReportBattle())
end

function TopHandle:Close()
	if self.opensequence then
		self.opensequence:Kill()
		self.opensequence = nil
	end

	if self.titlesequence then
		self.titlesequence:Kill()
		self.titlesequence = nil
	end

	if self.timesequence then
		self.timesequence:Kill()
		self.timesequence = nil
	end
	self.leftRelationItem:Close()
	self.rightRelationItem:Close()
end

function TopHandle:Destroy()
	self.leftRelationItem:Destroy()
	self.rightRelationItem:Destroy()
end

function TopHandle:StartOpenTween()
	self.rect.anchoredPosition = Vector2.New(self.rectPosition.x, self.rectPosition.y + 100)
	local tween1 = self.rect:DOAnchorPosY(self.rectPosition.y - 10, 0.2)
	local tween2 = self.rect:DOAnchorPosY(self.rectPosition.y, 0.2)

	local sequence = DOTween.Sequence()
	sequence:Append(tween1)
	sequence:Append(tween2)
	self.opensequence = sequence
end

function TopHandle:StartTitleTween()
	if self.title and (not BattleProxy.Instance:IsReportBattle()) then
		if BattleProxy.Instance:IsInMainlineBattle() then
			local mainlinecfg = CampaignProxy.Instance:GetMainLineCfgById(RoleInfoModel.mainlineid)
			self.titleLabel.text = self:GetWord("MainLineCommon_1001", string.format("%s-%s", mainlinecfg.chapter, mainlinecfg.section))
		elseif BattleProxy.Instance:IsInTowerBattle() then
			local towerid = TowerProxy.Instance:GetBattleTowerID()
			local towerCfg = TowerProxy.Instance:GetTowerCfgById(towerid)
			if towerCfg then
				self.titleLabel.text = self:GetWord("TowerCommon_1001", towerCfg.layer)
			end
		else
			return
		end

		self.title:SetActive(true)
		local rect = self:GetComponent(self.title, "RectTransform")
		local y = rect.localPosition.y + 200

		local tween = rect:DOLocalMoveY(y, 1)
		local tween1 = rect:DOLocalMoveY(y, 0.3):OnComplete(function (tw)
				self.title:SetActive(false)
			end)

		local sequence = DOTween.Sequence()
		sequence:Append(tween)
		sequence:Append(tween1)
		self.titlesequence = sequence
	end
end

function TopHandle:ShowRelationItem()
	local playerlist = BattleProxy.Instance:GetPlayerList()
	local redlist = {}
	local bluelist = {}
	for _, player in pairs(playerlist) do
		if player.prop.camp == CAMP.RED then
			table.insert(redlist, player.roleid)
		else
			table.insert(bluelist, player.roleid)
		end
	end
	self.leftRelationItem:SetData(redlist)
	self.rightRelationItem:SetData(bluelist)
end

function TopHandle:ShowCountDown(time)
	local curtime = time / 1000
	self.timeLbl.text = DateFormatUtil.formatMS(curtime)

	if curtime <= 15 and not self.timesequence then
		self.timeLbl.color = Color.red
		self.timesequence = TweenTools.TransparentAlpha(self.timeLbl.gameObject, 1)
	end
end

--onclick
function TopHandle:OnClickTips()
	self.tipsInfoObj:SetActive(true)
	self:SetDepth(self.tipsInfoObj, self:GetNextDepth())
end

function TopHandle:OnClickRelation(camp)
	local playerlist = BattleProxy.Instance:GetPlayerList()
	local list = {}
	for _, player in pairs(playerlist) do
		if player.prop.camp == camp then
			table.insert(list, player.roleid)
		end
	end
	UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 3, list, (camp == CAMP.RED) and CAMP.BLUE or CAMP.RED)
end

function TopHandle:OnClickCamera()
	LuaLayout.Instance:OpenWidget(UIWidgetNameDef.CheatCameraAdjustView)
end

return TopHandle