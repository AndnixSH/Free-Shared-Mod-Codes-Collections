local GuildMediator = GuildMediator or BaseClass(StdMediator)

function GuildMediator:OnEnterScenceFirst()
	local GuildProxy = require "Modules.Guild.GuildProxy"
	GuildProxy.Instance:Send70000()
	GuildProxy.Instance:Send70100()
end

return GuildMediator