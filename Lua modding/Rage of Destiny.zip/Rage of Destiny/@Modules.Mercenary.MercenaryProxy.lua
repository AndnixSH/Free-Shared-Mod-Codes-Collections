local MercenaryDef = require "Modules.Mercenary.MercenaryDef"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local MercenaryProxy = MercenaryProxy or BaseClass(BaseProxy)

function MercenaryProxy:__init()
	MercenaryProxy.Instance = self
	self.data = {}
	self:AddProto(20500, self.On20500)--获得所有雇佣相关基本信息
	self:AddProto(20501, self.On20501)--获取某个英雄的可申请列表
	self:AddProto(20502, self.On20502)--申请雇佣
	self:AddProto(20503, self.On20503)--撤销申请
	self:AddProto(20504, self.On20504)--获得别人申请列表
	self:AddProto(20505, self.On20505)--获得出借列表
	self:AddProto(20506, self.On20506)--同意雇佣申请
	self:AddProto(20507, self.On20507)--拒绝雇佣申请
	self:AddProto(20508, self.On20508)--一键处理同意或拒绝
	self:AddProto(20509, self.On20509)--获得雇佣英雄的使用情况(是否用于各种活动玩法中并取得胜利)
	self:AddProto(20510, self.On20510)--申请数量红点数量
	self:AddProto(20511, self.On20511)--归还雇佣英雄
	self:AddProto(20512, self.On20512)--雇佣成功红点
	self:AddProto(20513, self.On20513)--通知申请被拒绝
end

function MercenaryProxy:__delete()
	self.data = {}
end

function MercenaryProxy:Send20500()
	--print("Send20500=========")
	self:SendMessage(20500)
end

function MercenaryProxy:On20500(decoder)

	local had_apply_hero_infos = {}
	local hero_infos = {}
	local activity_pass_infos = {}
	local had_hire_hero_infos = {}
	local HeroProxy = require "Modules.Hero.HeroProxy"

	local count = decoder:Decode("I2")
	for i=1,count do
		local item = {}
		item.owner_guser = decoder:Decode("I8")
		item.roleid = decoder:Decode("I4")
		local role_cfg = HeroProxy.Instance:GetRoleCfgByConfigId(item.roleid) 
		item.race = role_cfg.race
		item.herouid = decoder:Decode("I4")
		item.rank = decoder:Decode("I2")

		item.exclusive_rank = decoder:Decode("I2")
		item.bapply = decoder:Decode("I2")
		item.other_apply_suc = decoder:Decode("I2")  --该roleid已经被他人雇佣了，自己没有该英雄可雇佣 0：有该英雄可雇佣 1：没有该英雄可雇佣
		table.insert(hero_infos, item)
	end


		--sort
	table.sort(hero_infos, function (a,b)
		-- local level_1 = a.crystalLevel and a.crystalLevel or a.level
		-- local level_2 = b.crystalLevel and b.crystalLevel or b.level
		local rank_1 = a.rank
		local rank_2 = b.rank
		local fight_1 = HeroProxy.Instance:GetHeroBaseFight(a.roleid)
		local fight_2 = HeroProxy.Instance:GetHeroBaseFight(b.roleid)

		if rank_1 == rank_2 then
			if fight_1 == fight_2 then
				return a.roleid < b.roleid
			else
				return 	fight_1 > fight_2
			end
		else
			return rank_1 > rank_2	
		end	
	end)


	count = decoder:Decode("I2")
	for i=1,count do
		local item = {}
		item.owner_guser = decoder:Decode("I8")
		item.owner_name = decoder:Decode("s2")
		item.sex = decoder:Decode("I2")
		item.owner_level = decoder:Decode("I2")
		item.owner_headicon = decoder:Decode("I4")
		item.owner_frameicon = decoder:Decode("I4")
		item.roleid = decoder:Decode("I4")
		item.herouid = decoder:Decode("I4")------------ 这在服务端是herouinkey
		item.level = decoder:Decode("I2")
		item.rank = decoder:Decode("I2")
		item.equips = decoder:DecodeList("I1I4I2", true)
		table.insert(had_hire_hero_infos, item)
	end

	local apply_red_count = decoder:Decode("I1")
	local apply_hero_success_red = decoder:Decode("I1")

	self.data.had_hire_hero_infos = had_hire_hero_infos

	self:ToNotify(self.data, MercenaryDef.Notify.UpdateMercenaryInfo, {
		hero_infos=hero_infos, had_apply_hero_infos=had_apply_hero_infos,
		had_hire_hero_infos=had_hire_hero_infos,
		activity_pass_infos=activity_pass_infos,
	})

	local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
	local RedPointDef = require "Modules.RedPoint.RedPointDef"
	RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.HireHeroApply, apply_red_count)
	RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.HireHeroSuccess, apply_hero_success_red)
	
	--print("On20500===============", table.dump(hero_infos), table.dump(had_apply_hero_infos), table.dump(had_hire_hero_infos), table.dump(activity_pass_infos))
end

function MercenaryProxy:Send20501(roleid)
	-- print("Send20501==", roleid)
	local encoder = NetEncoder.New()
	encoder:Encode("I4", roleid)
	self:SendMessage(20501, encoder)
end

function MercenaryProxy:On20501(decoder)
	local apply_hero_infos = {}
	local cur_apply_count = decoder:Decode("I2")

	local count = decoder:Decode("I2")
	for i=1,count do
		local item = {}
		item.owner_guser = decoder:Decode("I8")
		item.owner_name = decoder:Decode("s2")
		item.owner_sex = decoder:Decode("I2")
		item.roleid = decoder:Decode("I4")
		item.herouid = decoder:Decode("I4")
		item.rank = decoder:Decode("I2")
		item.level = decoder:Decode("I2")

		item.exclusive_rank = decoder:Decode("I2")
		-- item.fight = decoder:Decode("I4")
		item.apply_count = decoder:Decode("I2")
		item.bapply = decoder:Decode("I2")
		item.other_apply_suc = decoder:Decode("I2")  --该roleid已经被他人雇佣了，自己没有该英雄可雇佣 0：有该英雄可雇佣 1：没有该英雄可雇佣
		item.nickname = decoder:Decode("s2") --正在协助x执行任务
		
		item.equips = {}
		local equips = {}
		local equip_count = decoder:Decode("I2")
		for i=1,equip_count do
			local pos, equip_typeid, grade = decoder:Decode("I1"), decoder:Decode("I4"), decoder:Decode("I2")
			table.insert(equips, {equip_typeid, grade})
			table.insert(item.equips, {pos, equip_typeid, grade})
		end
		local HeroProxy = require "Modules.Hero.HeroProxy"
		local fight = HeroProxy.Instance:GetHeroBaseFight(item.roleid, item.rank, item.level, nil, equips)
		item.fight = fight
		table.insert(apply_hero_infos, item)
	end
	table.sort(apply_hero_infos, function(a, b)
		if a.fight == b.fight then
			return a.rank > b.rank
		else
			return a.fight > b.fight
		end
	end)
	-- print("On20501==", table.dump(apply_hero_infos))
	self:ToNotify(self.data, MercenaryDef.Notify.UpdateApplyHeroInfo, {cur_apply_count = cur_apply_count, apply_hero_infos=apply_hero_infos})
end

function MercenaryProxy:Send20502(guser, herouid)
	-- print("Send20502=====", guser, herouid)
	local encoder = NetEncoder.New()
	encoder:Encode("I8I4", guser, herouid)
	self:SendMessage(20502, encoder)	
end

function MercenaryProxy:On20502(decoder)
	local result = decoder:Decode("I2")
	-- print("On20502=====", result)
	if result == 0 then
		local guser, herouid, roleid, apply_count = decoder:Decode("I8I4I4I2")
		self:ToNotify(self.data, MercenaryDef.Notify.UpdateApplyOperateInfo, {guser=guser, herouid=herouid, roleid=roleid, apply_count=apply_count})
	end
	GameLogicTools.ShowErrorCode(20502, result)
end

function MercenaryProxy:Send20503(guser, herouid)
	-- print("Send20503=====", guser, herouid)
	local encoder = NetEncoder.New()
	encoder:Encode("I8I4", guser, herouid)
	self:SendMessage(20503, encoder)
end

function MercenaryProxy:On20503(decoder)
	local result = decoder:Decode("I2")
	-- print("On20503=====", result)
	if result == 0 then
		local guser, herouid, roleid, had_apply, apply_count = decoder:Decode("I8I4I4I2I2")
		self:ToNotify(self.data, MercenaryDef.Notify.UpdateApplyUnOperateInfo, {guser=guser, herouid=herouid, roleid=roleid, had_apply = had_apply, apply_count=apply_count})
	end
	GameLogicTools.ShowErrorCode(20503, result)
end

function MercenaryProxy:Send20504()
	-- print("Send20504=========")
	self:SendMessage(20504)
end

function MercenaryProxy:On20504(decoder)
	local other_apply_infos = {}
	local intimacy = decoder:Decode("I2")
	local count = decoder:Decode("I2")
	for i=1,count do
		local item = {}
		item.roleid = decoder:Decode("I4")
		item.herouid = decoder:Decode("I4")
		item.rank = decoder:Decode("I2")
		item.level = decoder:Decode("I2")
		item.exclusive_rank = decoder:Decode("I2")
		item.fight = decoder:Decode("I4")
		local role_infos = {}
		local role_count = decoder:Decode("I2")
		for i=1,role_count do
			local info = {}
			info.guser = decoder:Decode("I8")
			info.nickname = decoder:Decode("s2")
			info.sex = decoder:Decode("I2")
			info.headIcon = decoder:Decode("I4")
			info.frameIcon = decoder:Decode("I4")
			info.level = decoder:Decode("I2")
			table.insert(role_infos, info)
		end
		item.role_infos = table.reverse(role_infos)
		table.insert(other_apply_infos, item)
	end
	-- print("On20504=========", intimacy, table.dump(other_apply_infos))
	self:ToNotify(self.data, MercenaryDef.Notify.UpdateOtherApplyInfo, {intimacy=intimacy, other_apply_infos=other_apply_infos})
end

function MercenaryProxy:Send20505()
	-- print("Send20505=========")
	self:SendMessage(20505)
end

function MercenaryProxy:On20505(decoder)
	local lend_hero_list = {}
	local count = decoder:Decode("I2")
	for i=1,count do
		local item = {}
		item.roleid = decoder:Decode("I4")
		item.herouid = decoder:Decode("I4")
		item.rank = decoder:Decode("I2")
		item.level = decoder:Decode("I2")
		item.exclusive_rank = decoder:Decode("I2")
		item.fight = decoder:Decode("I4")
		item.nickname = decoder:Decode("s2")
		table.insert(lend_hero_list, item)
	end
	lend_hero_list = table.reverse(lend_hero_list)
	-- print("On20505=========", table.dump(lend_hero_list))
	self:ToNotify(self.data, MercenaryDef.Notify.UpdateLendHeroInfo, {lend_hero_list=lend_hero_list})
end

function MercenaryProxy:Send20506(herouid, guser)
	-- print("Send20506=========", herouid, guser)
	local encoder = NetEncoder.New()
	encoder:Encode("I4I8", herouid, guser)
	self:SendMessage(20506, encoder)
end

function MercenaryProxy:On20506(decoder)
	local result = decoder:Decode("I2")
	if result == 0 then
		local herouid = decoder:Decode("I4")
		local intimacy = decoder:Decode("I2")

		self:ToNotify(self.data, MercenaryDef.Notify.UpdateAgreeApplyInfo, {herouid=herouid, intimacy=intimacy})
	elseif result == 1 then
		GameLogicTools.ShowMsgTips("MercenaryView_1008")
	else
		GameLogicTools.ShowErrorCode(20506, result)
	end
end

function MercenaryProxy:Send20507(herouid, guser)
	-- print("Send20507=========", herouid, guser)
	local encoder = NetEncoder.New()
	encoder:Encode("I4I8", herouid, guser)
	self:SendMessage(20507, encoder)
end

function MercenaryProxy:On20507(decoder)
	local result = decoder:Decode("I2")
	-- print("On20507=====", result)
	if result == 0 then
		local herouid, guser = decoder:Decode("I4I8")
		self:ToNotify(self.data, MercenaryDef.Notify.UpdateRefuseApplyInfo, {herouid=herouid, guser=guser})
	elseif result == 1 then
		GameLogicTools.ShowMsgTips("MercenaryView_1008")
	else
		GameLogicTools.ShowErrorCode(20507, result)
	end
end

--type 1:一键拒绝  2:一键同意
function MercenaryProxy:Send20508(type)
	-- print("Send20508=========", type)
	local encoder = NetEncoder.New()
	encoder:Encode("I2", type)
	self:SendMessage(20508, encoder)
end

function MercenaryProxy:On20508(decoder)
	local result = decoder:Decode("I2")
	-- print("On20508=====", result)
	if result == 0 or result == 3 then
		local intimacy = decoder:Decode("I2")
		self:ToNotify(self.data, MercenaryDef.Notify.UpdateDealAllApplyInfo, {intimacy=intimacy})
	end
	GameLogicTools.ShowErrorCode(20508, result)
end

function MercenaryProxy:Send20509()
	self:SendMessage(20509)
end

function MercenaryProxy:On20509(decoder)
	local activity_pass_infos = {}
	local count = decoder:Decode("I2")
	for i=1,count do
		local item = {decoder:Decode("I4"), decoder:Decode("I2"), decoder:Decode("I2")}
		table.insert(activity_pass_infos, item)
	end
	self.data.activity_pass_infos = activity_pass_infos
	-- print("On20509==========", count, table.dump(self.data.activity_pass_infos))
	self:ToNotify(self.data, MercenaryDef.Notify.UpdateHireHeroActivityInfo, {activity_pass_infos=activity_pass_infos})
end

--雇佣兵申请红点
function MercenaryProxy:Send20510()
	self:SendMessage(20510)
end

function MercenaryProxy:On20510(decoder)
	local redDotCount = decoder:Decode("I1")

	local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
	local RedPointDef = require "Modules.RedPoint.RedPointDef"
	RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.HireHeroApply, redDotCount)
end

function MercenaryProxy:Send20511(guser, roleid, herouid)
	local encoder = NetEncoder.New()
	encoder:Encode("I8I4I4", guser, roleid, herouid)
	self:SendMessage(20511, encoder)
end

function MercenaryProxy:On20511(decoder)
	local result = decoder:Decode("I2")
	local guser , herouid
	if result == 0 then
		self:Send20500()
		-- guser = decoder:Decode("I8")
		-- herouid = decoder:Decode("I4")
		-- for i,info in ipairs(self.data.had_hire_hero_infos) do
		-- 	if info.owner_guser == guser and info.herouid == herouid then
		-- 		table.remove(self.data.had_hire_hero_infos , i)
		-- 	end
		-- end
		self:ToNotify(self.data, MercenaryDef.Notify.UpdateHireListInfo, {}) --had_hire_hero_infos = self.data.had_hire_hero_infos
	end
end

function MercenaryProxy:Send20512()
	local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
	local RedPointDef = require "Modules.RedPoint.RedPointDef"
	local red_count = RedPointProxy.Instance:GetNodeNum(RedPointDef.Id.HireHeroSuccess, 0)
	if red_count > 0 then
		self:SendMessage(20512)
	end
end

function MercenaryProxy:On20512(decoder)
	local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
	local RedPointDef = require "Modules.RedPoint.RedPointDef"
	RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.HireHeroSuccess, 0)
end

function MercenaryProxy:On20513()
	GameLogicTools.ShowMsgTips("MercenaryView_1009")
end

function MercenaryProxy:CheckUseHireHeroBattle(heroInfos, activityId, subtype)
	local result = 0 

	local hire_hero_count = 0
	for i,info in ipairs(heroInfos) do
		local herouid = info.fromuid or info.herouid
		if self:CheckIsHireHero(herouid) then
			hire_hero_count = hire_hero_count + 1
		end
	end

	-- 上阵雇佣英雄数量
	if hire_hero_count > self:GetHireHeroCanBattleNum(activityId, subtype) then
		result = 1
	end
	-- print("CheckUseHireHeroBattle==", result,activityId,subtype, table.dump(heroInfos))
	return result
end

function MercenaryProxy:CheckIsHireHero(herouid)
	local bhire_hero = false
	local had_hire_hero_infos = self.data.had_hire_hero_infos or {}
	for i,info in ipairs(had_hire_hero_infos) do
		if info.herouid == herouid then
			bhire_hero = true
			break
		end
	end
	return bhire_hero
end

--activityId玩法是否还可以上阵佣兵 subtype:爬塔类型
function MercenaryProxy:CheckHireHeroBattle(activityId, subtype)
	local bbattle = true
	local activity_pass_infos = self.data.activity_pass_infos or {}
	for i,info in ipairs(activity_pass_infos) do
		if info[1] == activityId and info[2] == subtype then
			if MercenaryDef.ActivityUseHireHeroCount[activityId] then
				if info[3] >= MercenaryDef.ActivityUseHireHeroCount[activityId] then
					bbattle = false
					break
				end
			end
		end
	end
	return bbattle
end

--activityId玩法可以上阵佣兵数量 subtype:爬塔类型
function MercenaryProxy:GetHireHeroCanBattleNum(activityId, subtype)
	local bbattle = self:CheckHireHeroBattle(activityId, subtype)
	return bbattle and MercenaryDef.Config.HireFriendHeroMaxCount or 0
end

--本周剩余时间文本
function MercenaryProxy:Update_Reflesh_HireHero_Time()
	local DateFormatUtil = require "Common.Util.DateFormatUtil"
	local leftTime = DateFormatUtil.get_next_week_start_leftTime(RoleInfoModel.servertime)
	local timeStr = DateFormatUtil.formatDHorHMS(leftTime)
	local str = LanguageManager.Instance:GetWord(MercenaryDef.LanguageKey.MercenaryKey6, timeStr)
	return str
end



return MercenaryProxy