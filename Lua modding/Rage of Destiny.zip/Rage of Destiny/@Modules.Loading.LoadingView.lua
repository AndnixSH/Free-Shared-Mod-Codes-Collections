local LoadingView = LoadingView or BaseClass(LuaBasicWidget)

LoadingView.percentage = 0
LoadingView.speed = 50

function LoadingView.ShowLoading(percentage)
    --防止进度错乱
    if percentage == 0 then
        LoadingView.percentage = 0
    elseif percentage > LoadingView.percentage then
        LoadingView.percentage = percentage
    end

    if percentage == 100 then
        LoadingView.speed = 100
    else
        LoadingView.speed = 50
    end
    local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.LoadingView)
    if not view:IsOpen() then
        view:OpenView()
    end
end

function LoadingView.CloseLoading()
    local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.LoadingView)
    if view:IsOpen() then
        view:CloseView()
    end
end
-----------------
function LoadingView:OnLoad()
    AssetManager.LoadUIPrefab(self, "Loading.LoadingView", self.LoadEnd)
end

function LoadingView:LoadEnd(obj)
    self:SetGo(obj)

    -- self.loadingSld = self:GetChildComponent(obj, "loading", "CSlider")
    self.backTex = self:GetChildComponent(obj, "background", "CTexture")
    self.percentageLbl = self:GetChildComponent(obj, "label/COutline_New2", "CLabel")
    self.tipsLbl = self:GetChildComponent(obj, "label/COutline_New1", "CLabel")
    self.iconSpr = self:GetChildComponent(obj, "CSlider_New/icon", "CSprite")

    self.tshBtn = self:GetChildComponent(obj, "CButton_New", "CButton")
    self.tshBtn.gameObject:SetActive(false)
    self.tshBtn:AddClick(function()
        local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
        IGGSdkProxy.Instance:OpenTSH()
    end)
    self:Step(0)
end

function LoadingView:ShowTSHButtonActive(bActive)
    if SystemConfig.isIGGPlatform() then
        local SdkManager = require "First.Sdk.SdkManager"
        if SdkManager.IsSdkInitSus() then
            self.tshBtn.gameObject:SetActive(bActive)
        end
    end
end

function LoadingView:OnOpen()
    GameObjTools.SetDepth(self.go, 10000)
    GameObjTools.SetModelDepth(self.go, 10000)
    self:ShowTSHButtonActive(true)
    self.value = 0
    self.percentageLbl.text = math.floor(self.value) .. '%'
    self.iconSpr.fillAmount = self.value
    self.tipscfg = ConfigManager.GetConfig("data_tips")["loading_tips"]
    self.texcfg = ConfigManager.GetConfig("data_tips")["loading_tex"]

    self:ShowTips()

    --self:AddTimer(function ()
    --	self:FrameRender_Timer()
    --end,0.05)

    self:StartFrame()
    local AudioManager = require "Common.Mgr.Audio.AudioManager"
    AudioManager.PlayBGM("loading_bg")
end

function LoadingView:OnClose()
    local SceneManager = require "Modules.Scene.SceneManager"
    SceneManager.Instance:SceneLoadingEnd()
    self:EndFrame()
    self.value = 0
    LoadingView.percentage = 0
end

function LoadingView:ShowTips()
    self.tipsLbl.text = self:GetWord(self.tipscfg[math.random(1, #self.tipscfg)])
    self:AddTimer(function()
        self.tipsLbl.text = self:GetWord(self.tipscfg[math.random(1, #self.tipscfg)])
    end, 1.5)

    local texTab = self.texcfg[math.random(1, #self.texcfg)]
    local str = texTab.background
    AssetManager.LoadUITexture(AssetManager.UITexture.Background, str, self.backTex)
end

function LoadingView:FrameRender_Timer()
    if self.value < LoadingView.percentage and self.value < 100 then
        self.percentageLbl.text = math.floor(self.value) .. '%'
        self.value = self.value + Time.time * LoadingView.speed
        self.iconSpr.fillAmount = self.value / 100
    elseif self.value >= 100 then
        self.percentageLbl.text = "100%"
        self.iconSpr.fillAmount = 1
        self:CloseView()
    end
end

function LoadingView:FrameUpdate()
    if self.value < LoadingView.percentage and self.value < 100 then
        self.value = math.min(self.value + Time.deltaTime * LoadingView.speed, LoadingView.percentage)
        self.percentageLbl.text = math.floor(self.value) .. '%'
        self.iconSpr.fillAmount = self.value / 100
    elseif self.value >= 100 then
        self.percentageLbl.text = "100%"
        self.iconSpr.fillAmount = 1
        self:CloseView()
    end
end

return LoadingView