local MainMediator = MainMediator or BaseClass(StdMediator)
local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"
function MainMediator:OnEnterLoadingEnd()		
	if SceneManager.Instance.sceneType == SceneDef.SceneType.Main then
		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MainView)
		if view:IsOpen() then
			view:ShowOpenTween()
		end	
	end	
end
function MainMediator:OnEnterScenceEnd()
	if SceneManager.Instance.sceneType == SceneDef.SceneType.Main then
		--需放在 strategy ，否则有可能层级低于其他页面
		-- local data =RoleInfoProxy.Instance:GetAccountUpgradeData()
		-- if data  then
		-- 	local NewbieProxy = require "Modules.Newbie.NewbieProxy"
        --     local bopen = NewbieProxy.Instance:CheckShowAccountUpgradeView()
        --     if bopen then
		-- 		LuaLayout.Instance:OpenWidget(UIWidgetNameDef.AccountUpgradeView)
		-- 	else
		-- 		RoleInfoProxy.Instance:ClearAccountUpgradeData()
		-- 	end
		-- end
	end	
end
function MainMediator:OnEnterScenceFirst()
end

return MainMediator