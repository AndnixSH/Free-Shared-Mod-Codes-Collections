local CampaignProxy = require "Modules.Campaign.CampaignProxy"

local HeroItem = require "Core.Implement.UI.Class.HeroItem"
local GoodsItem = require "Core.Implement.UI.Class.GoodsItem"
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"

local ObjPoolRender = require "Core.Implement.UI.Class.ObjPoolRender"
local ObjPoolItem = require "Core.Implement.UI.Class.ObjPoolItem"
local NewbieWidget = require "Core.Implement.UI.Widgets.NewbieWidget"

local CToggleRender = require "Core.Implement.UI.Class.CToggleRender"
local CampaignDef = require "Modules.Campaign.CampaignDef"

-----
local HeroPoolItem = PoolItem or BaseClass(ObjPoolItem)
function HeroPoolItem:Load(obj)
	self.heroItem = HeroItem.New(self:GetChild(obj, "Heroitem"))
    self.bossbtn = self:GetChildComponent(obj, "Heroitem", "CButton")
    self.bossbtn:AddClick(function()
		local strContent = self:GetWord(self.heroItem.cfg.tips, self.heroItem.data.level)
		GameLogicTools.ShowLabelTips(strContent, self.bossbtn.transform.position)        
    end)	
end

function HeroPoolItem:SetData(herodata)
	self.heroItem:SetData(herodata)
end

----------
local GoodsPoolItem = PoolItem or BaseClass(ObjPoolItem)
function GoodsPoolItem:Load(obj)
	self.goodsItem = GoodsItem.New(self:GetChild(obj, "GoodsItem"))
	self.goodsItem:SetClickOpenInfo()
end

function GoodsPoolItem:SetData(data)
	local goodsid = data[1]
	local goodsnum = data[2]
	self.goodsItem:SetData(goodsid, goodsnum)
end

------
local BossInfoView = BossInfoView or BaseClass(LuaBasicWidget, NewbieWidget)
function BossInfoView:__init()
	self.tweenOption = {bScale = true, closeCallback = function()
		self:AutoNextNewbie()
		self:CloseView()
	end}
	self.mainlineid = 1
	self.bshowRecord = true
	self.enemy_list = {}
	self.enemy_index = 1
end

function BossInfoView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Campaign.BossInfoView",self.LoadEnd)
end
	
function BossInfoView:LoadEnd(obj)
	self:SetGo(obj)

	local path = "root/content"
	local content = self:GetChild(obj, path)
	content:SetActive(true)
	
	if self:IsMultiEnemy() then
		content:SetActive(false)
		
		path = "root/content2"
		self:GetChild(obj, path):SetActive(true)
	end
	
	self:InitContent(obj, path)

	self:SetStep(0)
end

function BossInfoView:InitContent(obj, path)
	self.titleLbl = self:GetChildComponent(obj, path .. "/Hint/CLabel_hint", "CLabel")
	self.decLbl = self:GetChildComponent(obj, path .. "/Hint/CLabel_dec", "CLabel")

	self.infoObj = self:GetChild(obj, path .. "/info")
	
	self.bossHeroItem = HeroItem.New(self:GetChild(self.infoObj, "Heroitem"))

	self.heroItem = self:GetChild(self.infoObj, "CHorizontalItem_hero/item1")
	self.heroPoolRender = ObjPoolRender.New()
	self.heroPoolRender:Load(self.heroItem, self.heroItem.transform.parent, HeroPoolItem)

	self.goodsItem = self:GetChild(self.infoObj, "CHorizontalItem_goods/item1")
	self.goodsPoolRender = ObjPoolRender.New()
	self.goodsPoolRender:Load(self.goodsItem, self.goodsItem.transform.parent, GoodsPoolItem)

	self.closebtn = self:GetChildComponent(obj, path .. "/close", "CButton")
	self.closebtn:AddClick(function()
			self:AutoNextNewbie()
			self:CloseView()
		end)

	self.startbtn = self:GetChildComponent(obj, path .. "/CButton_begin", "CButton")
	self.startbtn:AddClick(function()
			self:OnStartGame()
			self:OnTriggerClickBtn(self.startbtn)
		end)
	self.battleBtnEffect = UIEffectItem.New("UI_Campaign_begin2", self.startbtn.gameObject)

	self.bossbtn = self:GetChildComponent(self.infoObj, "Heroitem", "CButton")
	self.bossbtn:AddClick(function()
			local strContent = self:GetWord(self.bossHeroItem.cfg.tips, self.bossHeroItem.data.level)
			GameLogicTools.ShowLabelTips(strContent, self.bossbtn.transform.position)
		end)

	self.recordBtn = self:GetChildComponent(obj, path .. "/CButton_record", "CButton")
	self.recordBtn:AddClick(function()
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.WinFormationView)
			if view then
				view.activityId = ACTIVITYID.MAINLINE
				view.levelId = self.mainlineid
				view:OpenView()
			end
		end)
	
	
	if self:IsMultiEnemy() then
		self:InitSelectEnemyContent(self.infoObj)
	end
end


function BossInfoView:InitSelectEnemyContent(obj)
	local togObj = self:GetChild(obj, "CHorizontalItem_team")
	local togGroup = self:GetComponent(togObj, "CToggleGroup")

	self.togRender = CToggleRender.New()
	self.togRender:Load(togGroup)
	self.togRender:AddSelect(function(index)
			self:OnTogChange(index)
		end)
	
	local MAX = CampaignDef.Const.MAX_ENEMY_NUM
	for i = 1, MAX do
		self.togRender:Add()
		self.togRender:UpdateLabel(i, tostring(i))
	end
end

function BossInfoView:OnTogChange(index)
	self.enemy_index = index
	self:UpdateInfo()
end

function BossInfoView:InitToggle()
	if self.togRender then
		local num = #self.enemy_list
		local list = {}
		for i = 1, num do
			table.insert(list, i)
		end
		self.togRender:ShowToggleItemLists(list)
	end
end

--注册引导数据
function BossInfoView:RegisterNewbieData()
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	local NewbieManager = require "Modules.Newbie.NewbieManager"
	local cur_newbie_id, cur_newbie_step = self:CheckOnNewbie()
	if cur_newbie_id and cur_newbie_step then
		self:RegisterButton(self.startbtn, cur_newbie_id, cur_newbie_step)
	end

end

function BossInfoView:CheckOnNewbie()
	local newbie_id, step
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	local NewbieManager = require "Modules.Newbie.NewbieManager"
	local cur_newbie_id, cur_newbie_step = NewbieManager.Instance:GetCurNewbieId()
	for _newbie_id, _step in pairs(NewbieDef.BossInfoTrigger) do
		if _newbie_id == cur_newbie_id and cur_newbie_step == _step then
			newbie_id, step = cur_newbie_id, cur_newbie_step
			break
		end
	end
	return newbie_id, step
end

function BossInfoView:OnOpen()
	CampaignProxy.Instance:ClearPassState(RoleInfoModel.mainlineid)
	self.enemy_list = CampaignProxy.Instance:GetAllEnemy(self.mainlineid)
	self:InitToggle()
	
	if self.delaytimer then
		self:RemoveTimer(self.delaytimer)
		self.delaytimer = nil
	end
	self:UpdateInfo()
	if self.togRender then
		self.togRender:SelectIndex(self.enemy_index)
	end
	self.battleBtnEffect:Open()
	local depth = self:GetNextDepth()
	self.battleBtnEffect:SetOrderLayer(depth)
	
	self.delaytimer = self:AddTimer(function()
		self:RegisterNewbieData()
	end, 0.2, 1)
end

--关闭就算完成
function BossInfoView:AutoNextNewbie()
	local newbie_id, newbie_step = self:CheckOnNewbie()
	if newbie_id and newbie_step then
		local NewbieManager = require "Modules.Newbie.NewbieManager"
		NewbieManager.Instance:NextStep()
	end

end

function BossInfoView:OnClose()
	self:AutoNextNewbie()

	self.heroPoolRender:ReleaseAll()
	self.goodsPoolRender:ReleaseAll()
	self.battleBtnEffect:Close()
	if self.delaytimer then
		self:RemoveTimer(self.delaytimer)
		self.delaytimer = nil
	end
	self.enemy_index = 1
	if self.togRender then
		self.togRender:SelectIndex(1)
	end
	self:UnRegisterNewbie()
end

function BossInfoView:OnDestroy()
	self:AutoNextNewbie()

	self.battleBtnEffect:Destroy()
	if self.delaytimer then
		self:RemoveTimer(self.delaytimer)
		self.delaytimer = nil
	end
	self:UnRegisterNewbie()
end

function BossInfoView:UpdateInfo()
	local mainlinecfg = CampaignProxy.Instance:GetMainLineCfgById(self.mainlineid)
	local enemy_id = self:GetEnemyID()
	local enemylist, boss = GameLogicTools.GetEnemyList(enemy_id)
	self.recordBtn.gameObject:SetActive(self.bshowRecord == true and true or false)

	self.heroPoolRender:ReleaseAll()
	self.goodsPoolRender:ReleaseAll()
	
	self.bossHeroItem:Hide()
	if boss then
		self.bossHeroItem:SetData(boss)
		self.bossHeroItem:Show()
	end
	for _, info in pairs(enemylist) do
		if next(info) and not info.boss and info.role > 0 then
			self.heroPoolRender:Get(info)
		end
	end

	self.titleLbl.text = self:GetWord("MainLineCommon_1001", string.format("%s-%s", mainlinecfg.chapter, mainlinecfg.section))
	self.decLbl.text = self:GetWord(mainlinecfg.info)
	local rewards = mainlinecfg.rewards_show
	for _,reward in pairs(rewards) do
		self.goodsPoolRender:Get(reward)
	end	

	self.startbtn.gameObject:SetActive(self.mainlineid == RoleInfoModel.mainlineid)
end

--onclick
function BossInfoView:OnStartGame()
	local enemy_id = self:GetEnemyID()
	local enemylist = GameLogicTools.GetEnemyList(enemy_id)
	UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 1, ACTIVITYID.MAINLINE, enemylist, enemy_id)	
end

function BossInfoView:IsMultiEnemy()
	return CampaignProxy.Instance:HasExtraEnemy(self.mainlineid)
end

function BossInfoView:GetEnemyID()
	return self.enemy_list[self.enemy_index]
end

return BossInfoView