
GameConfig = {
    HASAI = { [1] = true, [2] = true, },  -- 阵营ID:是否有AI
    LOG = 0,   --0:无日志 1:输出到控制台 2:输出到gamelog.txt
    DEBUGDRAW = { sprite = true, range = false, camera = false }, -- gizmos显示，精灵，技能范围
    ISEDITOR = false,
    HEXMAP = { super = false },  -- super = true 剧情忽略所有阻挡，迷宫忽略所有锁定
    RENDER_ENABLE = true,
}  