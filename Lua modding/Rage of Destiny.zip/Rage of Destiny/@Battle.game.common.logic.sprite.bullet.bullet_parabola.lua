local bullet = { timer = {}, sprite = {} }

-- speed distance duration position height
function bullet:oncreate()

    self.curcollide = nil
    self.prop.height = self.prop.height or 2000
    self.prop.duration = self.prop.duration or 1000

    local speed = self.prop.speed
    local duration = self.prop.duration
    local header = self.owner.body.header

    if not speed then
        local distance = self.prop.distance

        if not distance and self.prop.position then
            distance = tsvector.distance(self.prop.position, self.owner.body.position)
        end

        if not distance then

            local target = self.prop.target

            if not target and self.prop.rangeid then
                local targets = self.owner.body.parent.caller.skill:range(self.prop.rangeid)
                if #targets > 0 then
                    target = targets[1]
                end
            end

            if target then
                distance =  tsvector.distance(target.body.position, self.owner.body.position)
                header = (target.body.position - self.owner.body.position).normalized
            end
        end

        if distance then
            speed = tsmath.ndiv(distance, duration)
        end
    end

    if speed then
        self.owner.body:setvelocity(header:fmul(speed))
        self.timer:delay(duration, self.onmoveend)
        self.owner.body:moveup(self.prop.height, math.floor(duration / 2), self.prop.land)
    else
        global.debug.warning("抛物线子弹speed为空,rangeid：", self.prop.rangeid)
        self.owner:destroy()
    end
end

function bullet:onmoveend()
    self:sendmessage(eventdef.bullet_move_end)
end

function bullet:ondestroy()
    self.owner:destroy()
end

function bullet.sprite:onhitblock()
    self:destroy()
end

-- function bullet.sprite:onhitsprite(spritobj)
--     if spritobj == self.owner.body.parent or spritobj.body.spritetype == self.owner.body.spritetype or self._dirty then return end

--     local campmatch = true
--     if self.prop.samecamp then
--         campmatch = spritobj.prop.camp == self.owner.prop.camp
--     else
--         campmatch = spritobj.prop.camp ~= self.owner.prop.camp
--     end

--     if campmatch and spritobj ~= self.curcollide then
--         self.curcollide = spritobj
--         self:sendmessage(eventdef.sprite_collide, spritobj)
--     end
-- end

return bullet