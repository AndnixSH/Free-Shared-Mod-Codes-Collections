local OutdoorsProxy = OutdoorsProxy or BaseClass(BaseProxy)
function OutdoorsProxy:__init(name)
	OutdoorsProxy.Instance = self
	self.data = {}
end

function OutdoorsProxy:__delete()
	self.data = nil
end

return OutdoorsProxy
