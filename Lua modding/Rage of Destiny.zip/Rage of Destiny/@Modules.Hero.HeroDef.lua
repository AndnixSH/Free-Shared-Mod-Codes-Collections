local HeroDef = {}

HeroDef.TabType = {
    [1] = {title = "HeroNew_1001"},
    [2] = {title = "HeroNew_1002"},
}

HeroDef.NotifyDef =
{
	UpdateHero = "UpdateHero",
	LevelUpHero = "LevelUpHero",
	HeroContainer = "HeroContainer",
	UpdateHeroEquip = "UpdateHeroEquip",
	ActiveHeroExclusiveEquip = "ActiveHeroExclusiveEquip",
    UpdateFountain = "UpdateFountain",
    UpdateFountainAuto = "UpdateFountainAuto",
    GetNewHeroInfos = "GetNewHeroInfos",
    GetHeroBookList = "GetHeroBookList",
    UpdateHeroBookRedDot = "UpdateHeroBookRedDot",
    UpdateHeroResetFreeCount = "UpdateHeroResetFreeCount",
}

HeroDef.RaceType =
{
	Race1 = 1,	--耀光
	Race2 = 2,	--蛮族
	Race3 = 3,	--绿意
	Race4 = 4,	--亡灵
	Race5 = 5,	--半神
	Race6 = 6,	--恶魔
	Race7 = 7,	--虚空
}

HeroDef.Hero_Rank_Enum = {
    green = 2,
    blue = 3,
    blue_plus = 4,
    purple = 5,
    purple_plus = 6,
    yellow = 7,
    yellow_plus = 8,
    red = 9,
    red_plus = 10,
    white = 11,
    white1 = 12,
    white2 = 13,
    white3 = 14,
    white4 = 15,
    white5 = 16,
}

HeroDef.ShowRaceWord =
{
    [1] = { tips = "Common_1007", nohero = "Common_1014"},
    [2] = { tips = "Common_1008", nohero = "Common_1015"},
    [3] = { tips = "Common_1009", nohero = "Common_1016"},
    [4] = { tips = "Common_1010", nohero = "Common_1017"},
    [5] = { tips = "Common_1011", nohero = "Common_1018"},
    [6] = { tips = "Common_1012", nohero = "Common_1019"},
    [7] = { tips = "Common_1013", nohero = "Common_1020"},
}

HeroDef.LanguageKeys = {
    LanguageKey1 = "FountainView_1007"
}

HeroDef.Profession = {
    [1] = "Tree_view_1014",
    [2] = "Tree_view_1015",
    [3] = "Tree_view_1016",
    [4] = "Tree_view_1017",
    [5] = "Tree_view_1018",
}

return HeroDef