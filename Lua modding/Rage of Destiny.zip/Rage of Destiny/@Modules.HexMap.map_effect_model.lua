local map_effect_model = BaseClass()
local prop_refresher = require "Modules.HexMap.prop_refresher"

local cMapEffectModel = CS.LJY.NX.MapEffectModel

function map_effect_model:__init(anchor, prefab_id)
    self.prop = prop_refresher.new(self)
    self.anchor = anchor
    self._prefab_id = prefab_id
    self.cmodel = cMapEffectModel(self.anchor.canchor)
    self.cmodel:LoadModel(prefab_id, function () self:_loadend() end)
end

function map_effect_model:_loadend()
    prop_refresher.refresh(self.prop)
end

function map_effect_model:_prop_bactive(bactive)
    if self.cmodel then
        if bactive then
            self.cmodel:ShowModel()
        else
            self.cmodel:HideModel()
        end
    end
end

function map_effect_model:_prop_active(active_name)
    if self.cmodel then
        self.cmodel:StartActive(string.format( "%s_%s",self._prefab_id, active_name))
    end
end

function map_effect_model:__delete()
    self:release()
end

function map_effect_model:release()
    if self.cmodel then
        self.cmodel:Release()
        self.cmodel = nil
    end

    if self.anchor then
        self.anchor:DeleteMe()
        self.anchor = nil
    end
end

return map_effect_model