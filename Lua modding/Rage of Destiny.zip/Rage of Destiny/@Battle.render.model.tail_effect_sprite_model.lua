local base_sprite_model = require "Battle.render.model.base_sprite_model"
local tail_effect_sprite_model = BaseClass(base_sprite_model)

local cTailEffectSpriteModel = CS.LJY.NX.TailEffectSpriteModel

function tail_effect_sprite_model:__init(anchor, model_name, layer, callback)
    self.anchor = anchor
    if not layer then
        self.cmodel = cTailEffectSpriteModel(anchor.canchor, model_name)
    else
        if not callback then
            self.cmodel = cTailEffectSpriteModel(anchor.canchor, model_name, layer)
        else
            self.cmodel = cTailEffectSpriteModel(anchor.canchor, model_name, layer, callback)
        end
    end

end

return tail_effect_sprite_model