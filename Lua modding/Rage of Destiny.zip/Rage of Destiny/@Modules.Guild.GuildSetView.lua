local ObjPoolRender = require "Core.Implement.UI.Class.ObjPoolRender"
local ObjPoolItem = require "Core.Implement.UI.Class.ObjPoolItem"

local ClistRender = require "Core.Implement.UI.Class.ClistRender"
local ClistItem = require "Core.Implement.UI.Class.ClistItem"

local GuildProxy = require "Modules.Guild.GuildProxy"
local GuildDef = require "Modules.Guild.GuildDef"

local WordFilter=require "Common.Util.WordFilter"


local GuildSetViewConditionItem = GuildSetViewConditionItem or BaseClass(ClistItem)
function GuildSetViewConditionItem:Load(obj)
	self.contentLab = self:GetChildComponent(obj, "Label", "CLabel")
end

function GuildSetViewConditionItem:SetData(data)
	local str = GuildDef.ConditionTypeStr[data]
	self.contentLab.text = self:GetWord(str)
end



local GuildSetViewLevelItem = GuildSetViewLevelItem or BaseClass(ClistItem)
function GuildSetViewLevelItem:Load(obj)
	self.contentLab = self:GetChildComponent(obj, "Label", "CLabel")
end

function GuildSetViewLevelItem:SetData(data)
	local str = self:GetWord(GuildDef.LanguageKey.GuildSetView4, data)
	self.contentLab.text = str
end


local GuildSetView = GuildSetView or LuaWidgetClass()

function GuildSetView:__init()
	self.tweenOption = {bScale = true}
	self.conditionWidth = 280  --相隔间距
	self.levelWidth = 280
end

function GuildSetView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Guild.GuildSetView", self.LoadEnd)
end

function GuildSetView:LoadEnd(obj)
	self:SetGo(obj)
	self:InitUI()
	self:SetStep(0)
end

function GuildSetView:InitUI()
	self.rightObj = self:GetChild(self.go, "root/Right")
	self.closeBtn = self:GetChildComponent(self.go, "root/content/close", "CButton")
	self.closeBtn:AddClick(function()
		self:CloseView()
	end)

	self.guildIconTex = self:GetChildComponent(self.go, "root/CTexture_Logo", "CTexture")
	self.updateIconBtn = self:GetChildComponent(self.go, "root/CButton_genghuan", "CButton")
	self.updateIconBtn:AddClick(function()
		if self.guildInfos then
			local GuildLogoView = require "Modules.Guild.GuildLogoView"
			GuildLogoView.guildLevel = self.guildInfos.level
			GuildLogoView.cur_icon_id = self.guildInfos.icon_id
			GuildLogoView.callBack = function(select_id)
				if select_id ~= self.select_icon_id then
					GuildProxy.Instance:Send70013(select_id)
				end
			end
			LuaLayout.Instance:OpenWidget(UIWidgetNameDef.GuildLogoView)
		end
	end)

	self.labelObj1 = self:GetChild(self.rightObj, "RightContent/Info_titledi1/CLabel1")
	self.labelObj2 = self:GetChild(self.rightObj, "RightContent/Info_titledi1/CLabel2")
	self.labelObj3 = self:GetChild(self.rightObj, "RightContent/Info_titledi1/CLabel3")

	self.nameBtn = self:GetChildComponent(self.labelObj1, "CSprite", "CButton")
	self.nameBtn:AddClick(function()
		LuaLayout.Instance:OpenWidget(UIWidgetNameDef.GuildNameView)
	end)

	self.guildNameLab = self:GetChildComponent(self.labelObj1, "CSprite_New/CLabel_name", "CLabel")

	self.conditionBtn1 = self:GetChildComponent(self.labelObj2, "CSprite_back/CSprite_anniu1", "CButton")
	self.conditionBtn2 = self:GetChildComponent(self.labelObj2, "CSprite_back/CSprite_anniu2", "CButton")
	self.conditionSp1 = self:GetChildComponent(self.labelObj2, "CSprite_back/CSprite_anniu1", "CSprite")
	self.conditionSp2 = self:GetChildComponent(self.labelObj2, "CSprite_back/CSprite_anniu2", "CSprite")
	self.conditionBtn1:AddClick(function()
		self:OnClickConditionBtn(-1)
	end)
	self.conditionBtn2:AddClick(function()
		self:OnClickConditionBtn(1)
	end)

	-- self.conditionRoot = self:GetChild(self.labelObj2, "CSprite_back/CCanvas_New/Mask/Content/root")
	-- self.conditionItem = self:GetChild(self.conditionRoot, "CHorizontalItem/item1")
	-- self.conditionRender = ObjPoolRender.New()
	-- self.conditionRender:Load(self.conditionItem, self.conditionItem.transform.parent, GuildSetViewConditionItem)

	self.clist = self:GetChildComponent(self.labelObj2, "CSprite_back/CList_New", "CList")
	self.clistRender = ClistRender.New()
	self.clistRender:Load(self.clist, GuildSetViewConditionItem)
	self.conditionRoot = self:GetChild(self.labelObj2, "CSprite_back/CList_New/Viewport/Content")

	self.levelBtn1 = self:GetChildComponent(self.labelObj3, "CSprite_back/CSprite_anniu1", "CButton")
	self.levelBtn2 = self:GetChildComponent(self.labelObj3, "CSprite_back/CSprite_anniu2", "CButton")
	self.levelSp1 = self:GetChildComponent(self.labelObj3, "CSprite_back/CSprite_anniu1", "CSprite")
	self.levelSp2 = self:GetChildComponent(self.labelObj3, "CSprite_back/CSprite_anniu2", "CSprite")
	self.levelBtn1:AddClick(function()
		self:OnClickLevelBtn(-1)
	end)
	self.levelBtn2:AddClick(function()
		self:OnClickLevelBtn(1)
	end)

	-- self.levelRoot = self:GetChild(self.labelObj3, "CSprite_back/CCanvas_New/Mask/Content/root")
	-- self.levelItem = self:GetChild(self.levelRoot, "CHorizontalItem/item1")
	-- self.levelRender = ObjPoolRender.New()
	-- self.levelRender:Load(self.levelItem, self.levelItem.transform.parent, GuildSetViewLevelItem)
	self.clist2 = self:GetChildComponent(self.labelObj3, "CSprite_back/CList_New", "CList")
	self.clistRender2 = ClistRender.New()
	self.clistRender2:Load(self.clist2, GuildSetViewLevelItem)	
	self.levelRoot = self:GetChild(self.labelObj3, "CSprite_back/CList_New/Viewport/Content")

	self.announcemendInput = self:GetChildComponent(self.rightObj, "RightContent/CSprite_back/CInput", "CTextInput")
	self.announcemendInput:AddChange(function(value)
		local str = value
		local bmask, replace_str = WordFilter.checkContainAccurateMaskWords(value)
		if bmask then
			str = replace_str
		end
		local lenth, content = GameLogicTools.CheckContentLength(str, GuildDef.Parama.Guild_Announcement_Max_Char)
		self.announcemendInput.text = content
		self.select_announce = content
	end)

	self.announcemendInput:AddEndEdit(function(value)
	end)

	self.originPos = self.go.transform.localPosition
	self.offsetHeigh = -220 --距離屏幕中点的距离，不抬太高
	self.highestY = self.originPos.y
	self.bResetPox = false

end

function GuildSetView:OnClose()
	self:SendChangeInfos()
	self:ClearConditionTween()
	self:ClearLevelTween()
	if self.delayTimer then
		self:RemoveTimer(self.delayTimer)
		self.delayTimer = nil
	end
	self:AutoUnRegister()
	self:EndFrame()
end

function GuildSetView:OnDestroy()
	self:SendChangeInfos()
	self:ClearConditionTween()
	self:ClearLevelTween()
	if self.delayTimer then
		self:RemoveTimer(self.delayTimer)
		self.delayTimer = nil
	end
	self:AutoUnRegister()
	self:EndFrame()
end

function GuildSetView:OnOpen()
	self.highestY = self.originPos.y
	self.bResetPox = false
	self:AutoRegister()
	self:UpdateView()
	self:StartFrame()

	self:UpdateConditionSp()
	self:UpdateLevelSp()
end

function GuildSetView:OnNameChange(value)
	local lenth, str = GameLogicTools.CheckContentLength(value, GuildDef.Parama.Guild_Name_Max_Char)
	self.nameInput.text = str
end

function GuildSetView:OnClickConditionBtn(direction)
	local posx
	if direction == 1 then
		if self.conditinIdx < self:GetConditionMaxCount() then
			self.conditinIdx = self.conditinIdx + 1
			-- self.clistRender:GotoIndex(self.conditinIdx)
			posx = self:GetPosByIdx(self.conditinIdx, self.conditionWidth)
		end
	elseif direction == -1 then
		if self.conditinIdx > 1 then
			self.conditinIdx = self.conditinIdx - 1
			-- self.clistRender2:GotoIndex(self.levelIdx)
			posx = self:GetPosByIdx(self.conditinIdx, self.conditionWidth)
		end
	end
	if posx then
		self:MoveToPos(posx, 1, self.conditionRoot)
		self.select_conditionType = self.conditions[self.conditinIdx]--当前选中的
	end
	self:UpdateConditionSp()
end

function GuildSetView:UpdateConditionSp()
	self.conditionSp1.Gray = self.conditinIdx == 1
	self.conditionSp2.Gray = self.conditinIdx == self:GetConditionMaxCount()
end

function GuildSetView:OnClickLevelBtn(direction)
	local posx
	if direction == 1 then
		if self.levelIdx < self:GetLevelMaxCount() then
			self.levelIdx = self.levelIdx + 1
			posx = self:GetPosByIdx(self.levelIdx, self.levelWidth)
		end
	elseif direction == -1 then
		if self.levelIdx > 1 then
			self.levelIdx = self.levelIdx - 1
			posx = self:GetPosByIdx(self.levelIdx, self.levelWidth)
		end
	end
	if posx then
		self:MoveToPos(posx, 2, self.levelRoot)
		self.select_levelType = self.levelIdx--当前选中的
	end
	self:UpdateLevelSp()
end

function GuildSetView:UpdateLevelSp()
	self.levelSp1.Gray = self.levelIdx == 1
	self.levelSp2.Gray = self.levelIdx == self:GetLevelMaxCount()
end

function GuildSetView:MoveToPos(posX, _type, obj)
	if _type == 1 then
		self:ClearConditionTween()
	elseif _type == 2 then
		self:ClearLevelTween()
	end
	local time = 0.2
	local tween = obj.transform:DOLocalMoveX(posX, time)
	tween:SetEase(Ease.Linear)

	self.conditionTween = _type == 1 and tween or nil
	self.levelTween = _type == 2 and tween or nil
end

function GuildSetView:ClearConditionTween()
	if self.conditionTween then
		self.conditionTween:Kill()
		self.conditionTween = nil
	end
end

function GuildSetView:ClearLevelTween()
	if self.levelTween then
		self.levelTween:Kill()
		self.levelTween = nil
	end
end

function GuildSetView:UpdateView()
	self.guildInfos = GuildProxy.Instance:GetGuildInfos()
	self.icon_id = self.guildInfos.icon_id
	self.guildName = self.guildInfos.name
	self.conditionType = self.guildInfos.condition_limit
	self.levelType = self.guildInfos.level_limit
	self.announcement = self.guildInfos.announcement

	self.conditions = {}
	for key, value in pairs(GuildDef.ConditionType) do
		table.insert(self.conditions, value)
	end
	table.sort(self.conditions, function(a, b)
		return a < b
	end)

	self.clistRender:ClearData()
	self.clistRender:AppendDataList(self.conditions, false)

	self.levelTypes = {}
	for key,value in pairs(GuildDef.LevelType) do
		table.insert(self.levelTypes, value)
	end
	table.sort(self.levelTypes, function(a, b)
		return a < b
	end)

	self.clistRender2:ClearData()
	self.clistRender2:AppendDataList(self.levelTypes, false)

	self:SetGuildIcon(self.icon_id)
	self:SetGuildName(self.guildName)
	self.conditionRoot:SetActive(false)
	self.levelRoot:SetActive(false)
	if self.delayTimer then
		self:RemoveTimer(self.delayTimer)
		self.delayTimer = nil
	end
	self:SetGuildCondition(self.conditionType, self.levelType)

	self.delayTimer = self:AddTimer(function()
		self:SetGuildCondition(self.conditionType, self.levelType)
		UILayerTool.UpdateCanvases()
		self.conditionRoot:SetActive(true)
		self.levelRoot:SetActive(true)
	end, 0.3, 1)
	
	self:SetGuildAnnouncement(self.announcement)
end

--设置图标
function GuildSetView:SetGuildIcon(icon_id)
	local cfg = GuildProxy.Instance:GetGuildIconById(icon_id)
	if cfg then
		AssetManager.LoadUITexture(AssetManager.UITexture.Guild, cfg.icon, self.guildIconTex)
	end

	self.select_icon_id = icon_id --当前选中的
end

--设置公会名
function GuildSetView:SetGuildName(guildName)
	self.guildNameLab.text = guildName
	self.select_guildName = guildName --当前选中的
end

--获取入会条件最大条数
function GuildSetView:GetConditionMaxCount()
	return #self.conditions
end

--获取等级最大条数
function GuildSetView:GetLevelMaxCount()
	return #self.levelTypes
end

function GuildSetView:GetPosByIdx(idx, width)
	local posX = -(idx-1) * width
	return posX
end

--设置公会条件
function GuildSetView:SetGuildCondition(conditionType, levelType)
	self.conditinIdx = 1  --索引
	for i,value in ipairs(self.conditions) do
		if conditionType == value then
			self.conditinIdx = i
			break
		end
	end

	self.levelIdx = levelType
	-- for i,value in ipairs(self.levelTypes) do
	-- 	if levelType == value then
	-- 		self.levelIdx = i
	-- 		break
	-- 	end
	-- end
	
	local posX = self:GetPosByIdx(self.conditinIdx, self.conditionWidth)
	self.conditionRoot.transform.localPosition = Vector3.New(posX, 0, 0)
	
	posX = self:GetPosByIdx(self.levelIdx, self.levelWidth)
	self.levelRoot.transform.localPosition = Vector3.New(posX, 0, 0)

	self.select_conditionType = self.conditions[self.conditinIdx]--当前选中的
	self.select_levelType = self.levelIdx --self.levelTypes[self.levelIdx]--当前选中的
	-- UILayerTool.UpdateCanvases()

end

--设置公会宣言
function GuildSetView:SetGuildAnnouncement(announcement)
	self.announcemendInput.text = announcement

	self.select_announce = announcement --当前选中的
end

--关闭界面时判断
function GuildSetView:SendChangeInfos()
	if self.select_conditionType ~= self.conditionType or self.select_levelType ~= self.levelType then
		GuildProxy.Instance:Send70012(self.conditinIdx, self.levelIdx)
	end

	if self.select_announce ~= self.announcement then
		GuildProxy.Instance:Send70020(self.select_announce)
	end

end

--入会条件刷新
function GuildSetView.EvtNotify.Guild.data:UpdateLimit(data, args)
	self.conditionType = args.conditionType
	self.levelType = args.levelType
end

--公会名刷新
function GuildSetView.EvtNotify.Guild.data:UpdateGuildName(data, args)
	self.guildInfos.name = args.guild_name
	self:SetGuildName(args.guild_name)
end

--公会图标刷新
function GuildSetView.EvtNotify.Guild.data:UpdateGuildIcon(data, args)
	self.guildInfos.icon_id = args.icon_id
	self:SetGuildIcon(args.icon_id)
end

--公会宣言刷新
function GuildSetView.EvtNotify.Guild.data:UpdateAnnouncement(data, args)
end

function GuildSetView:FrameUpdate()
    local isEditor = Application.isEditor
    if not isEditor then
        local curPosY = GameLogicTools.AdjustObjPosY(self.go, self.originPos, self.offsetHeigh, self.announcemendInput.isFocused, self.bResetPox)
    	if curPosY > self.highestY then
    		self.highestY = curPosY
    	end
    	self.bResetPox = (curPosY < self.highestY) and true or false    
    end
end

return GuildSetView