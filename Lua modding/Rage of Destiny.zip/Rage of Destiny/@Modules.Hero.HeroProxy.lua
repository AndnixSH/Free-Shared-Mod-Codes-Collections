local HeroDef = require "Modules.Hero.HeroDef"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
local RedPointDef = require "Modules.RedPoint.RedPointDef"
local HeroProxy = HeroProxy or BaseClass(BaseProxy)
function HeroProxy:__init(name)
    HeroProxy.Instance = self

    self:AddProto(20000, self.On20000) --英雄列表
    self:AddProto(20001, self.On20001) --英雄升级
    self:AddProto(20002, self.On20002) --英雄扩容
    self:AddProto(20003, self.On20003) --英雄激活专属装备
    self:AddProto(20004, self.On20004) --英雄装备刷新
    self:AddProto(20005, self.On20005) --英雄重置
    self:AddProto(20006, self.On20006) --英雄遣散
    self:AddProto(20007, self.On20007) --英雄回退
    self:AddProto(20008, self.On20008) --英雄自动遣散
    self:AddProto(20009, self.On20009) --请求遣散状态
    self:AddProto(20010, self.On20010) --英雄信息更新 1添加英雄 2删除英雄 3英雄数据更新
    self:AddProto(20011, self.On20011) --获得新英雄
    self:AddProto(20012, self.On20012) --请求已获得的英雄列表 --图鉴
    self:AddProto(20013, self.On20013) --请求已获得的英雄列表 --图鉴
    self:AddProto(20014, self.On20014) --重置英雄免费次数
    self:AddProto(20015, self.On20015) --记录SDK日志

    self.data = {}
    self.data.herocontainer = 0    --英雄最大数量
    self.data.buycontainercount = 0 --英雄扩容次数
    self.data.herolist = {} --英雄列表
    --self.data.cacheHeroAttrFightDic = {}

    self.data.bCheckHeroRed = false
    self.benterfromherobook = false
    self.select_race = 0
    self.progress = 1
end

function HeroProxy:__delete()
    self.data.bCheckHeroRed = false
    self.data = nil
end

--protp
function HeroProxy:Send20000()
    self:SendMessage(20000)
end

function HeroProxy:On20000(decoder)
    self.data.herocontainer = decoder:Decode("I2")
    self.data.buycontainercount = decoder:Decode("I2")

    local herolist = {}
    local count = decoder:Decode("I2")
    --print("On20000=========")
    for _ = 1, count do
        local info = {}
        info.herouid, info.roleid, info.level, info.rank, info.curskin = decoder:Decode("I4I4I2I2I4")
        info.heroskins = decoder:DecodeList("I4")
        local equips = {}
        local equipcount = decoder:Decode("I2")
        for _ = 1, equipcount do
            local equip_info = {}
            equip_info[1], equip_info[2] = decoder:Decode("I1I4")
            table.insert(equips, equip_info)
        end
        info.equips = equips
        table.insert(herolist, info)
    end
    self.data.herolist = herolist
    self:UpdateHeroCrystalLevel(true)
    self:UpdateHeroConnectLevel()
    --self:UpdateHeroFight()

    self:ToNotify(self.data, HeroDef.NotifyDef.UpdateHero, {})

    if not self.data.bCheckHeroRed then
        local EquipProxy = require "Modules.Equip.EquipProxy"
        EquipProxy.Instance:GetHeroTabRedDot(true)
        self.data.bCheckHeroRed = true
    end

    local TempleProxy = require "Modules.Temple.TempleProxy"
    TempleProxy.Instance:UpdateTempleRedDot()

    local TowerProxy = require "Modules.Tower.TowerProxy"
    TowerProxy.Instance:UpdateTowerRedDot()

    --print("= =On20000 ===>", table.dump(herolist))
end

function HeroProxy:Send20001(herouid, level, isDust)
    local CrystalProxy = require "Modules.Crystal.CrystalProxy"
    CrystalProxy.Instance:CacheCrystalMaxLevel()
    local encoder = NetEncoder.New()
    encoder:Encode("I4I2I2", herouid, level or 0, isDust and 1 or 0)
    self:SendMessage(20001, encoder)
end

function HeroProxy:On20001(decoder)
    local herouid, level, bquick, formerLv
    local result = decoder:Decode("I2")
    if result == 0 then
        herouid, level = decoder:Decode("I4I2")
        local herodata = self:GetHeroDataByUid(herouid)
        bquick = (herodata.level + 1 < level)
        formerLv = herodata.level
        herodata.level = level
        local upgrade = self:GetUpgradeCfgBylevel(formerLv)
        if upgrade.dust > 0 or bquick then
            UIOperateManager.Instance:OpenWidget(AppFacade.Hero, 5, herouid, bquick, formerLv)
        end
        if SystemConfig.isIGGPlatform() then
            self:CheckHeroLvUpIGGSdkEventInfo(herouid, formerLv, level)
        end
    elseif result ~= 7 then
        GameLogicTools.ShowErrorCode(20001, result)
    end
    self:ToNotify(self.data, HeroDef.NotifyDef.LevelUpHero, { herouid = herouid, level = level, bquick = bquick, formerLv = formerLv, result = result })

end

function HeroProxy:Send20002()
    self:SendMessage(20002)
end

function HeroProxy:On20002(decoder)
    local result = decoder:Decode("I2")
    if result == 0 then
        self.data.herocontainer, self.data.buycontainercount = decoder:Decode("I2I2")
        self:ToNotify(self.data, HeroDef.NotifyDef.HeroContainer, { herocontainer = self.data.herocontainer, buycontainercount = self.data.buycontainercount })
    end
    GameLogicTools.ShowErrorCode(20002, result)
end

function HeroProxy:Send20003(herouid)
    local encoder = NetEncoder.New()
    encoder:Encode("I4", herouid)
    self:SendMessage(20003, encoder)
end

function HeroProxy:On20003(decoder)
    local result = decoder:Decode("I1")
    if result == 0 then
        self:ToNotify(self.data, HeroDef.NotifyDef.ActiveHeroExclusiveEquip)
    end
    GameLogicTools.ShowErrorCode(20003, result)
end

function HeroProxy:On20004(decoder)
    local herouid = decoder:Decode("I4")
    local equipcount = decoder:Decode("I2")
    local equips = {}
    for _ = 1, equipcount do
        local info = {}
        info[1], info[2] = decoder:Decode("I1I4")
        table.insert(equips, info)
    end

    for _, info in ipairs(self.data.herolist) do
        if info.herouid == herouid then
            info.equips = equips
            break
        end
    end
    local EquipProxy = require "Modules.Equip.EquipProxy"
    EquipProxy.Instance:GetHeroTabRedDot(true)
    --print("20004====", herouid, table.dump(equips), table.dump(self.data.herolist))
    self:ToNotify(self.data, HeroDef.NotifyDef.UpdateHeroEquip, { herouid = herouid, equips = equips })
end

-- 英雄重置
function HeroProxy:Send20005(herouid)
    local encoder = NetEncoder.New()
    encoder:Encode("I4", herouid)
    self:SendMessage(20005, encoder)
end

function HeroProxy:CombineGoodsItem(roleid, rank, level, count)
    local cfg = self:GetRoleCfgByConfigId(roleid)
    if cfg then
        local goodsId = cfg.goods_id
        return { goodsid = goodsId, goodsnum = count, roleid = roleid, rank = rank, level = level }
    end
end

function HeroProxy:On20005(decoder)
    local result = decoder:Decode("I1")
    self.data.hero_reset_count = decoder:Decode("I2")
    self:ToNotify(self.data, HeroDef.NotifyDef.UpdateHeroResetFreeCount, { count = self.data.hero_reset_count })
    if result == 0 then
        local BagProxy = require "Modules.Bag.BagProxy"
        local EquipProxy = require "Modules.Equip.EquipProxy"
        local goods_list = {}
        goods_list.hero = decoder:DecodeList("I4I2I2", true)
        goods_list.goods = decoder:DecodeList("I4I4", true)
        goods_list.equips = decoder:DecodeList("I4I2I4", true)
        -- print("On20005===", table.dump(goods_list))
        self:ToNotify(self.data, HeroDef.NotifyDef.UpdateFountain)

        local show_goods = {}
        for _, v in ipairs(goods_list.hero) do
            local reward = self:CombineGoodsItem(v[1], v[2], v[3], 1)
            if reward then
                table.insert(show_goods, reward)
            end
        end

        table.sort(goods_list.goods, function(a, b)
            return a[1] > b[1]
        end)
        for _, v in ipairs(goods_list.goods) do
            table.insert(show_goods, { goodsid = v[1], goodsnum = v[2] })
        end

        for _, equip_infos in ipairs(goods_list.equips) do
            local equipInfo = EquipProxy.Instance:ConstructionEquipItemInfo(equip_infos[1], nil, equip_infos[2], 0)
            table.insert(show_goods, { goodsid = equip_infos[1], goodsnum = 1, equipInfos = equipInfo })
        end
        -- print("On20005 goods_list==", table.dump(goods_list), table.dump(show_goods))
        GameLogicTools.ShowGetItemView(show_goods, 3)
    else
    end
end

-- 英雄遣散
function HeroProxy:Send20006(herouid_list)
    local encoder = NetEncoder.New()
    encoder:EncodeList("I4", herouid_list)
    self:SendMessage(20006, encoder)
end

function HeroProxy:On20006(decoder)
    local result = decoder:Decode("I1")
    if result == 0 then
        local BagProxy = require "Modules.Bag.BagProxy"
        local EquipProxy = require "Modules.Equip.EquipProxy"
        local goods_list = {}
        goods_list = decoder:DecodeList("I4I4", true)
        local goods_equips = decoder:DecodeList("I4I2I4", true)
        self:ToNotify(self.data, HeroDef.NotifyDef.UpdateFountain)
        local show_goods = {}
        for _, v in ipairs(goods_list) do
            table.insert(show_goods, { goodsid = v[1], goodsnum = v[2] })
        end

        for _, equip_info in ipairs(goods_equips) do
            local equipInfo = EquipProxy.Instance:ConstructionEquipItemInfo(equip_info[1], nil, equip_info[2], 0)
            table.insert(show_goods, { goodsid = equip_info[1], goodsnum = 1, equipInfos = equipInfo })
        end
        -- print("On20006 goods_list==", table.dump(goods_list), table.dump(goods_equips), table.dump(show_goods))
        table.sort(show_goods, function(a, b)
            return a.goodsid > b.goodsid
        end)
        GameLogicTools.ShowGetItemView(show_goods, 3)
    else

    end
end

-- 英雄回退
function HeroProxy:Send20007(herouid)
    local encoder = NetEncoder.New()
    encoder:Encode("I4", herouid)
    self:SendMessage(20007, encoder)
end

function HeroProxy:On20007(decoder)
    local result = decoder:Decode("I1")
    if result == 0 then
        local goods_list = {}
        goods_list.hero = decoder:DecodeList("I4I2I2", true)
        goods_list.goods = decoder:DecodeList("I4I4", true)

        self:ToNotify(self.data, HeroDef.NotifyDef.UpdateFountain)

        local show_goods = {}
        for _, v in ipairs(goods_list.hero) do
            local reward = self:CombineGoodsItem(v[1], v[2], v[3], 1)
            if reward then
                table.insert(show_goods, reward)
            end
        end
        table.sort(goods_list.goods, function(a, b)
            return a[1] > b[1]
        end)
        for _, v in ipairs(goods_list.goods) do
            table.insert(show_goods, { goodsid = v[1], goodsnum = v[2] })
        end
        GameLogicTools.ShowGetItemView(show_goods, 3)

    else

    end
end

function HeroProxy:Send20008(is_auto_select)
    local encoder = NetEncoder.New()
    encoder:Encode("I1", is_auto_select and 0 or 1)
    self:SendMessage(20008, encoder)
end

function HeroProxy:On20008(decoder)
    local result = decoder:Decode("I1")
end

function HeroProxy:Send20009()
    self:SendMessage(20009)
end

function HeroProxy:On20009(decoder)
    local is_auto_retire = decoder:Decode("I1")
    self:ToNotify(self.data, HeroDef.NotifyDef.UpdateFountainAuto, is_auto_retire)
end

function HeroProxy:On20010(decoder)
    local _type, result = decoder:Decode("I1I1")
    --print("On20010=======", _type, result)
    if _type == 1 then
        if result == 1 then
            --英雄背包格子已满，多余英雄邮件发放
        end
        local add_hero_infos = decoder:DecodeList("I4I4I2I2", true)
        --print("add_hero_infos -->", table.dump(add_hero_infos))
        for _, add_hero_info in ipairs(add_hero_infos) do
            local hero_info = {}
            hero_info.herouid = add_hero_info[1]
            hero_info.roleid = add_hero_info[2]
            hero_info.rank = add_hero_info[3]
            hero_info.level = add_hero_info[4]

            hero_info.curskin = 0
            hero_info.heroskins = {}
            hero_info.equips = {}
            table.insert(self.data.herolist, hero_info)
        end
    elseif _type == 2 then
        local remove_hero_list = decoder:DecodeList("I4")
        local remove_dict = {}
        for _, hero_uid in ipairs(remove_hero_list) do
            remove_dict[hero_uid] = true
        end
        --print("remove_hero_list -->", table.dump(remove_hero_list), table.dump(self.data.herolist))
        -- for _, hero_uid in ipairs(remove_hero_list) do
        --     for i, hero_info in ipairs(self.data.herolist) do
        --         if hero_uid == hero_info.herouid then
        --             table.remove(self.data.herolist, i)
        --             break
        --         end
        --     end
        -- end

        local remove_count = 0
        for i = #self.data.herolist, 1, -1 do
            local hero_info = self.data.herolist[i]
            if hero_info and remove_dict[hero_info.herouid] then
                table.remove(self.data.herolist, i)
                remove_count = remove_count + 1
                if remove_count == #remove_hero_list then
                    break
                end
            end
        end

    elseif _type == 3 then
        local info = {}
        info.herouid, info.roleid, info.level, info.rank, info.curskin = decoder:Decode("I4I4I2I2I4")
        info.heroskins = decoder:DecodeList("I4")
        info.equips = {}
        local equipcount = decoder:Decode("I2")
        for _ = 1, equipcount do
            local equip_info = {}
            equip_info[1], equip_info[2] = decoder:Decode("I1I4")
            table.insert(info.equips, equip_info)
        end
        -- print("update_hero_info", info)

        for i, hero_info in ipairs(self.data.herolist) do
            if info.herouid == hero_info.herouid then
                self.data.herolist[i] = info
                break
            end
        end
    end

    self:UpdateHeroCrystalLevel(true)
    self:UpdateHeroConnectLevel()
    self:ToNotify(self.data, HeroDef.NotifyDef.UpdateHero, { type = _type, result = result })

    local EquipProxy = require "Modules.Equip.EquipProxy"
    EquipProxy.Instance:GetHeroTabRedDot(true)

    --更新光明圣堂一键合成红点
    local TempleProxy = require "Modules.Temple.TempleProxy"
    TempleProxy.Instance:UpdateTempleRedDot()

    local TowerProxy = require "Modules.Tower.TowerProxy"
    TowerProxy.Instance:UpdateTowerRedDot()
end

function HeroProxy:On20011(decoder)
    local hero_portraits_count = decoder:Decode("I2")  --图鉴个数
    local new_hero_infos = decoder:DecodeList("I4I4I2I2", true)
    self:ToNotify(self.data, HeroDef.NotifyDef.GetNewHeroInfos, { newheros = new_hero_infos })

    if SystemConfig.isIGGPlatform() then
        self:AFEventGetHeroComplete(hero_portraits_count, new_hero_infos)
    else
        for i, info in ipairs(new_hero_infos) do
            local bfind = false
            for _, v in ipairs(self.data.roleid_List) do
                if v[1] == info[2] then
                    bfind = true
                    break
                end
            end
            if not bfind then
                table.insert(self.data.roleid_List, { info[2] })
            end
        end
    end
    --print("On20011 new_hero_infos -->", table.dump(new_hero_infos))
end

function HeroProxy:Send20012()
    self:SendMessage(20012)
end
function HeroProxy:IsNewHero(roleid)
    --尽量不要用这个接口，roleid_List只有切换场景后数据才刷新
    if self.data.roleid_List then
        for _, v in ipairs(self.data.roleid_List) do
            if v then
                if v[1] == roleid then
                    return false
                end
            end
        end
        return true
    end
    return false
end

function HeroProxy:UpdateRoleIdList(roleid)

    if self.data.roleid_List then
        local find = false
        for _, v in ipairs(self.data.roleid_List) do
            if v then
                if v[1] == roleid then
                    find = true
                    break
                end
            end
        end
        if not find then
            table.insert(self.data.roleid_List, { roleid })
        end
    end
    --print("---UpdateRoleIdList------",table.dump(self.data.roleid_List))
end

function HeroProxy:On20012(decoder)
    --图鉴
    local roleid_List = decoder:DecodeList("I4", true)
    self.data.roleid_List = roleid_List
    local no_award_List = decoder:DecodeList("I4", true)
    --print("------------------------On20012---no_award_List-----------------",table.dump(no_award_List))
    local herodataList = {}
    local haslist = {}
    local herodata = self:GetHeroConfige()
    for i = 1, 3 do
        table.insert(herodataList, {})
        table.insert(haslist, 0)
    end
    for _, _cfg in pairs(herodata) do
        if _cfg.type ~= 2 then
            local item = {}
            item.id = _cfg.id
            item.name = LanguageManager.Instance:GetWord(_cfg.name)
            item.race = _cfg.race
            item.sort_race = _cfg.race
            if _cfg.race == 6 then
                item.sort_race = 0
            elseif _cfg.race == 5 then
                item.sort_race = -1
            end
            item.has = false
            for _, v in ipairs(roleid_List) do
                if v[1] == _cfg.id then
                    item.has = true
                    break
                end
            end
            local ii = 1
            if _cfg.rank_min == 2 then
                ii = 3
                table.insert(herodataList[3], item)
            elseif _cfg.rank_min == 3 then
                ii = 2
                table.insert(herodataList[2], item)
            elseif _cfg.rank_min == 5 then
                ii = 1
                table.insert(herodataList[1], item)
            end
            if item.has then
                haslist[ii] = haslist[ii] + 1
                item.hasgetaward = true
                for _, v in ipairs(no_award_List) do
                    if v[1] == _cfg.id then
                        item.hasgetaward = false
                        break
                    end
                end
            end
        end
    end

    for i = 1, 3 do

        table.sort(
                herodataList[i],
                function(a, b)
                    --排序
                    if a.race == b.race then
                        return a.id < b.id
                    end
                    return a.sort_race < b.sort_race
                end)

    end
    local progress = 1
    local select_race = 0
    if self.data.hero_book_list then
        progress = self.progress or 1
        select_race = self.select_race or 0
    end
    self.data.hero_book_list = { herodataList = herodataList, haslist = haslist }
    self:ToNotify(self.data, HeroDef.NotifyDef.UpdateHeroBookRedDot, {})
    self:ToNotify(self.data, HeroDef.NotifyDef.GetHeroBookList, { herodataList = herodataList, haslist = haslist, progress = progress or 1, select_race = select_race })
    local show = self:IsShowHeroBookRedDot()
    local ModuleManager = require "Common.Mgr.UI.ModuleManager"
    local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
    local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.HeroRootView, false)
    if bopen then
        RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.HeroBook, show and 1 or 0)
    end
    self:UpdateNewHeroDot()
end
function HeroProxy:UpdateNewHeroDot()
    local new = false
    local new2 = false
    local CardPortalProxy = require "Modules.CardPortal.CardPortalProxy"
    local config = ConfigManager.GetConfig("data_common").cardportal_new
    if config.value1 then
        for k, value in pairs(config.value1) do
            if self:IsNewHero(value) then
                --新英雄
                local hasshow = CardPortalProxy.Instance:CheckHasShowNewHeroRed(value)
                if hasshow == 0 then
                    --红点未显示过
                    local cfg = self:GetRoleCfgByConfigId(value)
                    if cfg then
                        if cfg.race >= 1 and cfg.race <= 4 then
                            if not new then
                                new = true
                            end
                        elseif cfg.race == 5 or cfg.race == 6 then
                            if not new2 then
                                new2 = true
                            end
                        end
                    end
                end
            end
        end
    end
    RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.CardPortNewHero, new and 1 or 0)
    RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.CardPortNewHero_2, new2 and 1 or 0)
    CardPortalProxy.Instance:UpdateCardRedPoint()
end
function HeroProxy:ShowTheHighestHeroFromHeroBook()
    if self.data.hero_book_list and self.data.hero_book_list.herodataList then
        local heroinfo = false
        for i = 1, #self.data.hero_book_list.herodataList do
            local list = self.data.hero_book_list.herodataList[i]
            if list then
                for _, v in ipairs(list) do
                    if v.has then
                        heroinfo = v
                        break
                    end
                end
            end
            if heroinfo then
                break
            end
        end
        if heroinfo then
            local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.HeroStoryView)
            if view then
                local data = {}
                data.roleid = heroinfo.id
                data.isnew = self:IsShowOneHeroBookRedDot(data.roleid)
                view.data = data
                view:OpenView()
            end
        end
    end
end
function HeroProxy:SetCurBooKListPos(progress, selectindex)
    self.progress = progress
    self.select_race = selectindex
    self:SetEnterPage(true)
end
function HeroProxy:SetEnterPage(enterfromherobook)
    self.benterfromherobook = enterfromherobook
    if not enterfromherobook then
        self.progress = 1
        self.select_race = 0
    end
end

function HeroProxy:IsFromBookListPagesEnter()
    return self.benterfromherobook
end

function HeroProxy:Send20013(roleid)
    local encoder = NetEncoder.New()
    encoder:Encode("I4", roleid)
    self:SendMessage(20013, encoder)
end
function HeroProxy:On20013(decoder)
    local result, roleid = decoder:Decode("I1I4")
    if result == 0 then
        if self.data and self.data.hero_book_list then
            for i = 1, #self.data.hero_book_list.herodataList do
                for _, v in ipairs(self.data.hero_book_list.herodataList[i]) do
                    if v.id == roleid then
                        v.hasgetaward = true
                        break
                    end
                end
            end
        end
        local rewardlist = {}
        local item = {}
        item.goodsid = CURRENCY_TYPE_GOODID[CURRENCY_TYPE.diamond]
        item.goodsnum = 100
        table.insert(rewardlist, item)
        GameLogicTools.ShowGetItemView(rewardlist, 1, function(type)
            local screen = UILayerTool.CurrentScreen()
            local uiScreenPos = {}
            uiScreenPos.x = 0
            uiScreenPos.y = 0
            local pos = UILayerTool.GetCameraScreenPosByUIScreenPos(uiScreenPos)
            local position = UILayerTool.GetUICameraWorldPosByCameraScreenPos(pos)

            local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MainView)
            if view then
                if not view:IsOpen() then
                    GameLogicTools.ShowGemDrop(position)
                end
            end

        end)
        self:ToNotify(self.data, HeroDef.NotifyDef.UpdateHeroBookRedDot, { roleid = roleid })
        local show = self:IsShowHeroBookRedDot()
        RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.HeroBook, show and 1 or 0)
    else
        GameLogicTools.ShowErrorCode(20013, result)
    end
end

--英雄免费重置次数
function HeroProxy:Send20014()
    self:SendMessage(20014)
end

function HeroProxy:On20014(decoder)
    local free_count = decoder:Decode("I2")
    self.data.hero_reset_count = free_count
    self:ToNotify(self.data, HeroDef.NotifyDef.UpdateHeroResetFreeCount, { count = free_count })
end

--发送记录英雄相关IGGSDK事件日志
function HeroProxy:Send20015(sdk_key)
    local encoder = NetEncoder.New()
    encoder:Encode("s2", sdk_key)
    self:SendMessage(20015, encoder)
end

function HeroProxy:On20015(decoder)
    local sdk_key = decoder:Decode("s2")
    local hero_igg_sdk_info = decoder:DecodeList("s2")
    if sdk_key ~= 0 then
        --local IGGSdkDef = require "Modules.IGGSdk.IGGSdkDef"
        local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
        IGGSdkProxy.Instance:Track(sdk_key)
    end
    self.hero_igg_sdk_info = {}
    for _, sdk_id in ipairs(hero_igg_sdk_info) do
        self.hero_igg_sdk_info[sdk_id] = true
    end
end

function HeroProxy:IsShowHeroBookRedDot()
    for i = 1, #self.data.hero_book_list.herodataList do
        for _, v in ipairs(self.data.hero_book_list.herodataList[i]) do
            if v.hasgetaward ~= nil then
                if not v.hasgetaward then
                    return true
                end
            end
        end
    end
    return false
end
function HeroProxy:IsShowOneHeroBookRedDot(roleid)
    if not self.data.hero_book_list then
        return false
    end
    for i = 1, #self.data.hero_book_list.herodataList do
        for _, v in ipairs(self.data.hero_book_list.herodataList[i]) do
            if v.id == roleid then
                if v.has then
                    if v.hasgetaward then
                        return false
                    end
                    return true
                else
                    return false
                end

            end
        end
    end
    return false
end
function HeroProxy:GetHeroBookDataByRace(race)
    --图鉴
    if race == 0 then
        return self.data.hero_book_list.herodataList, self.data.hero_book_list.haslist
    end
    local herodataList = {}
    local haslist = {}
    for i = 1, #self.data.hero_book_list.herodataList do
        table.insert(herodataList, {})
        table.insert(haslist, 0)
    end
    for i = 1, #self.data.hero_book_list.herodataList do
        for _, v in ipairs(self.data.hero_book_list.herodataList[i]) do
            if v.race == race then
                table.insert(herodataList[i], v)
                if v.has then
                    haslist[i] = haslist[i] + 1
                end
            end
        end
    end
    return herodataList, haslist
end
function HeroProxy:IsHero(goodsid)
    local cfg = self:GetHeroConfige()
    if cfg then
        for _, v in pairs(cfg) do
            if v and v.goods_id then
                if goodsid == v.goods_id then
                    return true
                end
            end
        end
    end
    local BagProxy = require "Modules.Bag.BagProxy"
    local BagDef = require "Modules.Bag.BagDef"
    local goodscfg = BagProxy.Instance:GetGoodsCfgById(goodsid)
    if goodscfg then
        if goodscfg.subtype == BagDef.SubType.Elite_Hero_Card or goodscfg.subtype == BagDef.SubType.Rare_Hero_Card then
            return true
        end
    end
    return false
end
--cfg
function HeroProxy:GetHeroConfige()
    local config = ConfigManager.GetConfig("hero_static")
    return config
end

function HeroProxy:GetMonsterConfige()
    local config = ConfigManager.GetConfig("monster_static")
    return config
end

function HeroProxy:GetSpriteConfige()
    local config = ConfigManager.GetConfig("sprite_body")
    return config
end

--技能前缀(缺一位等级)列表
function HeroProxy:GetSkillidList(herocfgid)
    local herocfg = self:GetRoleCfgByConfigId(herocfgid)
    local list = {}
    for _, skillid in ipairs(herocfg.skill_list) do
        table.insert(list, tonumber(string.sub(skillid, 1, 5)))
    end
    return list
end

--获取英雄技能數組byskill前缀
function HeroProxy:GetSkillList(skillid)
    local level = 5--默认写死最大五级
    local skilllist = {}
    for i = 1, level do
        local skill = self:GetSkillBySkilLevel(skillid, i)
        if skill then
            table.insert(skilllist, skill)
        else
            break
        end
    end
    return skilllist
end

--根据等级, 获取当前技能和等级, 未解锁返回第一个技能
function HeroProxy:GetCurSkill(skillid, herolevel)
    local skilllist = self:GetSkillList(skillid)
    for i = #skilllist, 1, -1 do
        local skill = skilllist[i]
        if skill.level_up <= herolevel then
            return skill, i
        end
    end
    return skilllist[1], nil
end

function HeroProxy:GetSkillBySkilLevel(skillid, skilllevel)
    local config = ConfigManager.GetConfig("skill_static")
    local parentid = tonumber(string.sub(skillid, 1, 5))
    local skill = config[tonumber(parentid .. skilllevel)]
    if skill then
        skill.parentid = parentid
        return skill
    end
end

--取的英雄等级对应的技能配置
function HeroProxy:GetSkillByHeroLevel(herocfgid, herolevel)
    local list = self:GetSkillidList(herocfgid)
    for _, skillid in ipairs(list) do
        local skilllist = self:GetSkillList(skillid)
        for _, skillcfg in pairs(skilllist) do
            if skillcfg.level_up == herolevel then
                return skillcfg
            end
        end
    end
end

--取的英雄等级对应的技能配置(列表)
function HeroProxy:GetSkillListByHeroLevel(herocfgid, herolevel)
    local result = {}
    local list = self:GetSkillidList(herocfgid)
    for _, skillid in ipairs(list) do
        local skilllist = self:GetSkillList(skillid)
        for _, skillcfg in pairs(skilllist) do
            if skillcfg.level_up == herolevel then
                table.insert(result, skillcfg)
            end
        end
    end
    return result
end

function HeroProxy:GetSkillListByHeroLevelRange(herocfgid, startLv, endLv)
    local result = {} -- 等级区间内技能List,技能ID重复的取最大等级的
    local newSkillTb = {} --新解锁技能 true;老技能升级 false  {[id] = true}  
    local list = self:GetSkillidList(herocfgid)
    for _, skillid in ipairs(list) do
        local skilllist = self:GetSkillList(skillid)
        local temp_lv
        for _, skillcfg in pairs(skilllist) do
            if skillcfg.level_up > startLv and skillcfg.level_up <= endLv then
                if not temp_lv then
                    temp_lv = skillcfg.level
                    table.insert(result, skillcfg)
                elseif temp_lv < skillcfg.level then
                    result[#result] = skillcfg
                end
                print("newSkillTb", table.dump(newSkillTb))
                if skillcfg.level == 1 then
                    newSkillTb[skillid] = true
                    print("Set true", skillid, table.dump(skillcfg))
                elseif skillcfg.level > 1 and not newSkillTb[skillid] then
                    newSkillTb[skillid] = false
                    print("Set false", skillid, table.dump(skillcfg))
                end

            end
        end
    end
    return result, newSkillTb
end


--判断是否是大招
function HeroProxy:IsEXSkill(herocfgid, skillid)
    skillid = tonumber(string.sub(skillid, 1, 5))
    local list = self:GetSkillidList(herocfgid)
    return list[SKILL.SLOT.ULTIMATE] == skillid
end

---

--英雄配置表id
function HeroProxy:GetSpriteConfigeById(id)
    local cfg = self:GetSpriteConfige()
    if cfg[id] then
        return cfg[id]
    else
        if id > 0 then
            print("not find sprite ,roleid:", id)
        end
    end
end

--后端id
function HeroProxy:GetHeroCfgByUid(id)
    local herodata = self:GetHeroDataByUid(id)
    if herodata then
        return self:GetRoleCfgByConfigId(herodata.roleid)
    end
end

--配置表id
function HeroProxy:GetRoleCfgByConfigId(id)
    local cfg = self:GetHeroConfige()
    if cfg[id] then
        return cfg[id]
    else
        -- print("not find RoleCfg ,roleid:",id)
    end

    cfg = self:GetMonsterConfige()
    if cfg[id] then
        return cfg[id]
    else
        -- print("not find RoleCfg ,roleid:",id)
    end
    if id > 0 then
        print("not find RoleCfg ,roleid:", id)
    end
end

--英雄列表by种族类型
function HeroProxy:GetHeroCfgByRace(race)
    local list = {}
    local cfgs = self:GetHeroConfige()
    for _, cfg in pairs(cfgs) do
        if (not race or cfg.race == race) and cfg.type == 1 then
            table.insert(list, cfg)
        end
    end
    return list
end

function HeroProxy:GetHeroNameGradientColorByHeroId(rank)
    --local cfg = self:GetRoleCfgByConfigId(id)
    --local rank = cfg.rank_min
    local GradientColor = {}
    if rank == 2 then
        GradientColor.TopColor = Color.New(202 / 255, 255 / 255, 202 / 255, 255 / 255)
        GradientColor.BottomColor = Color.New(149 / 255, 239 / 255, 147 / 255, 255 / 255)
    elseif rank == 3 or rank == 4 then
        GradientColor.TopColor = Color.New(202 / 255, 244 / 255, 255 / 255, 255 / 255)
        GradientColor.BottomColor = Color.New(139 / 255, 240 / 255, 255 / 255, 255 / 255)
    else
        GradientColor.TopColor = Color.New(234 / 255, 202 / 255, 255 / 255, 255 / 255)
        GradientColor.BottomColor = Color.New(216 / 255, 155 / 255, 255 / 255, 255 / 255)
    end
    return GradientColor
end

function HeroProxy:GetVocationCfgById(id)
    local cfg = ConfigManager.GetConfig("data_vocation")
    if cfg[id] then
        return cfg[id]
    else
        print("not find data_vocation ,id:", id)
    end
end

function HeroProxy:GetRankInfoCfgById(id)
    local cfg = ConfigManager.GetConfig("data_rankinfo")
    if cfg[id] then
        return cfg[id]
    else
        print("not find data_rankinfo ,id:", id)
    end
end

--品质描边
function HeroProxy:GetRankInfoOutLineColorById(id)
    local cfg = self:GetRankInfoCfgById(id)
    if cfg and cfg.outline then
        return cfg.outline
    end
end

--品质渐变
function HeroProxy:GetRankInfoGradientColorById(id)
    local cfg = self:GetRankInfoCfgById(id)
    if cfg and cfg.gradient then
        local colors = string.split(cfg.gradient, ",")
        return colors
    end
end

function HeroProxy:GetRankColorCfgById(id, text)
    local cfg = self:GetRankInfoCfgById(id)
    if cfg then
        text = string.format("<color=%s>%s</color>", cfg.color, text)
        return text
    else
        return text
    end
end

function HeroProxy:GetAttrValueCfgById(id)
    local cfg = ConfigManager.GetConfig("data_attrvalue")
    if cfg[id] then
        return cfg[id]
    else
        print("not find data_attrvalue ,id:", id)
    end
end

function HeroProxy:GetAttrValueCfgByType(type)
    local cfg = ConfigManager.GetConfig("data_attrvalue")
    for _, v in pairs(cfg) do
        if type == v.type then
            return v
        end
    end
    print("not find data_attrvalue ,type:", type)
end

function HeroProxy:GetUpgradeCfgBylevel(level)
    local cfg = ConfigManager.GetConfig("data_upgrade")
    if cfg[level] then
        return cfg[level]
    else
        print("not find data_upgrade ,level:", level)
    end
end

function HeroProxy:GetUpgradeCfgByUid(id)
    local herodata = self:GetHeroDataByUid(id)
    local cfg = self:GetUpgradeCfgBylevel(herodata.level)
    return cfg
end

--logic
function HeroProxy:UpdateHeroCrystalLevel(notSendEvent)
    local CrystalProxy = require "Modules.Crystal.CrystalProxy"
    local herolist = self:GetHeroDataList()
    for _, data in pairs(herolist) do
        local level = CrystalProxy.Instance:HeroInCrystal(data.herouid)
        if level then
            data.crystalLevel = self:GetHeroMaxLevelByRoleId(level, data.roleid)
        else
            data.crystalLevel = nil
        end
    end
    if not notSendEvent then
        self:ToNotify(self.data, HeroDef.NotifyDef.UpdateHero, {})
    end
    -- print("== UpdateHeroCrystalLevel ==", table.dump(herolist))
end

--暂时废弃,原想在获得英雄列表的时候缓存 英雄战力(需同时修改不要去频繁拿英雄列表)
-- function HeroProxy:UpdateHeroFight(herouid)
--     for _,info in ipairs(self.data.herolist) do
--         if not herouid then
--             self.data.cacheHeroAttrFightDic[info.herouid] = self:GetHeroBaseFight(info.roleid, info.rank, info.crystalLevel or info.level, info.herouid)    
--         elseif herouid and herouid == info.heroUid then
--             self.data.cacheHeroAttrFightDic[info.herouid] = self:GetHeroBaseFight(info.roleid, info.rank, info.crystalLevel or info.level, info.herouid)
--             break
--         end
--     end
--     print("==========UpdateHeroFight------------------>",table.dump(self.data.cacheHeroAttrFightDic))
-- end

--品质所能达到的最大等级  废弃 英雄等级与品质无关
function HeroProxy:GetHeroMaxLevelByRank(level, rank)
    local _level = level
    if rank and rank >= HeroDef.Hero_Rank_Enum.white then
    else
        local rank_cfg = self:GetRankInfoCfgById(rank)
        if rank_cfg and _level > rank_cfg.lvmax then
            _level = rank_cfg.lvmax
        end
    end
    return _level
end

--英雄所能达到的最大等级
function HeroProxy:GetHeroMaxLevelByRoleId(level, roleid)
    local _level = level
    local cfg = self:GetRoleCfgByConfigId(roleid)
    local hero_maxlv = cfg.level_max
    _level = level > hero_maxlv and hero_maxlv or level
    return _level
end

function HeroProxy:UpdateHeroConnectLevel()
    local TempleProxy = require "Modules.Temple.TempleProxy"
    local herolist = self:GetHeroCfgByRace(7)
    for _, herodata in pairs(herolist) do
        local connectinfo = TempleProxy.Instance:GetConnectInfo(herodata.herouid)
        if connectinfo then
            local herodata1 = self:GetHeroDataByUid(connectinfo[1])
            local herodata2 = self:GetHeroDataByUid(connectinfo[2])
            herodata1.level = herodata2.crystalLevel or herodata2.level
            herodata1.rank = herodata2.rank
        end
    end
end

function HeroProxy:GetHeroDataList()
    if AppConfig.ISALONE then
        local cfgs = self:GetHeroConfige()
        local list = {}
        for _, cfg in pairs(cfgs) do
            if cfg.type == 1 then
                table.insert(list, { herouid = cfg.id, roleid = cfg.id, level = 240, rank = cfg.rank_min, bselect = false, bcant = true })
            end
        end
        self.data.herolist = list
    end
    return self.data.herolist or {}
end

function HeroProxy:GetHeroDataDict()
    local ret = {}
    local target_list = self.data.herolist or {}
    for index, v in ipairs(target_list) do
        ret[v.herouid] = v
    end
    return ret
end

function HeroProxy:GetHeroDataByUid(herouid)
    local list = self:GetHeroDataList()
    for _, data in pairs(list) do
        if data.herouid == herouid then
            return data
        end
    end
end

function HeroProxy:GetHeroDataListByRace(race)
    local list = self:GetHeroDataList()
    local newlist = {}
    for _, info in pairs(list) do
        local cfg = HeroProxy.Instance:GetHeroCfgByUid(info.herouid)
        if cfg and (not race or cfg.race == race) then
            table.insert(newlist, info)
        end
    end
    --sort
    local cacheHeroAttrFightDic = {}
    table.sort(newlist, function(a, b)
        local level_1 = a.crystalLevel and a.crystalLevel or a.level
        local level_2 = b.crystalLevel and b.crystalLevel or b.level
        local rank_1 = a.rank
        local rank_2 = b.rank

        local attrFight_1 = cacheHeroAttrFightDic[a.herouid] or self:GetAttrFight(self:GetHeroAttr(a.roleid, rank_1, level_1, a.herouid))
        local attrFight_2 = cacheHeroAttrFightDic[b.herouid] or self:GetAttrFight(self:GetHeroAttr(b.roleid, rank_2, level_2, b.herouid))

        if not cacheHeroAttrFightDic[a.herouid] then
            cacheHeroAttrFightDic[a.herouid] = attrFight_1
        end
        if not cacheHeroAttrFightDic[b.herouid] then
            cacheHeroAttrFightDic[b.herouid] = attrFight_2
        end

        if level_1 == level_2 then
            if rank_1 == rank_2 then
                if attrFight_1 == attrFight_2 then
                    return a.roleid < b.roleid
                else
                    return attrFight_1 > attrFight_2
                end
            else
                return rank_1 > rank_2
            end
        else
            return level_1 > level_2
        end
    end)

    return newlist
end

function HeroProxy:GetHeroConfigListByRace(race)
    local heroInfos = {}
    local cfg = self:GetHeroConfige()
    for _, v in pairs(cfg) do
        if v.race == race then
            table.insert(heroInfos, v)
        end
    end
    table.sort(heroInfos, function(a, b)
        return a.id > b.id
    end)
    return heroInfos
end

function HeroProxy:GetHighestPowerHeroByRoleid(roleid)
    local list = self:GetHeroListByRoleid(roleid)
    return (#list > 0) and list[1] or nil
end

function HeroProxy:GetHeroListByRoleid(roleid)
    local heroList = {}
    local list = self:GetHeroDataList()
    for _, data in pairs(list) do
        if data.roleid == roleid then
            table.insert(heroList, data)
        end
    end
    return heroList
end

--return 关系加成等级, 独立加成等级
function HeroProxy:GetRelation(herocfglist)
    local relationlist = {}
    local total_count = 0
    for _, heroconfigid in pairs(herocfglist) do
        local cfg = self:GetRoleCfgByConfigId(heroconfigid)
        if cfg then
            if not relationlist[cfg.race] then
                relationlist[cfg.race] = 0
            end
            relationlist[cfg.race] = relationlist[cfg.race] + 1
        end
        total_count = total_count + 1
    end

    local speciallevel = relationlist[6] or 0
    local relationAdd = relationlist[5] or 0

    local numList = {}
    for i = 1, 4 do
        if relationlist[i] then
            table.insert(numList, relationlist[i])
        end
    end
    table.sort(numList)

    local relationlevel = 0
    local relationnum = (#numList > 0) and table.remove(numList) or 0

    if (relationnum + relationAdd) == 5 then
        relationlevel = 4
    elseif (relationnum + relationAdd) == 4 then
        relationlevel = 3
    elseif (relationnum + relationAdd) == 3 then
        local nextNum = (#numList > 0) and table.remove(numList) or 0
        if nextNum == 2 then
            relationlevel = 2
        else
            relationlevel = 1
        end
    end

    return relationlevel, speciallevel
end

function HeroProxy:GetFormationRelationAttr(hero_role_id_list)
	local new_attr_list = {}

	if hero_role_id_list then
		local relation_level, special_level = self:GetRelation(hero_role_id_list)
		local relation_attr_cfg = ConfigManager.GetConfig("data_common")["relation1" .. relation_level]
		local special_attr_cfg = ConfigManager.GetConfig("data_common")["relation2" .. special_level]

		local attr = {}
		if relation_attr_cfg and relation_attr_cfg.value3 then
			for k,v in ipairs(relation_attr_cfg.value3) do
				table.insert(attr, v)
			end
		end

		if special_attr_cfg and special_attr_cfg.value3 then
			for k,v in ipairs(special_attr_cfg.value3) do
				table.insert(attr, v)
			end
		end

		for _,v in pairs(attr) do
			local key = v[1]
			local value = v[2] or 0
			if CONST.ATTR[key] and (value > 0) then
				key = CONST.ATTR[key]
				if new_attr_list[key] then
					new_attr_list[key] = new_attr_list[key] + value
				else
					new_attr_list[key] = value
				end
			end
		end
	end
	return new_attr_list
end

-- attr 对应 CONST.ATTR
function HeroProxy:GetAttrFight(attr)
    local attr_value = ConfigManager.GetConfig("data_attrvalue")
    local fight = 0
    for _, info in pairs(attr_value) do
        if attr[info.note] then
            fight = fight + attr[info.note] * info.value
        end
    end
    fight = math.ceil(fight)
    return fight
end

function HeroProxy:GetAttrNames()
    local attr_value_config = faceConfig["data_attrvalue"]

    local attr_names = {}
    for _, info in ipairs(attr_value_config) do
        attr_names[info.type] = info.note
    end

    return attr_names
end

function HeroProxy:GetAttrTypes()
    local attr_value_config = faceConfig["data_attrvalue"]
    local attr_types = {}
    for _, info in ipairs(attr_value_config) do
        attr_types[info.note] = info.type
    end

    return attr_types
end

--我的所有英雄战斗力
function HeroProxy:GetMyAllHeroFight()
    local herolist = self:GetHeroDataList()
    return self:GetHeroFight(herolist)
    -- local fight = 0
    -- for _, herodata in pairs(herolist) do
    --     local heroattr = self:GetHeroAttr(herodata.roleid, herodata.rank, herodata.crystalLevel or herodata.level, herodata.herouid)
    --     fight = fight + self:GetAttrFight(heroattr)
    -- end
    -- fight = math.ceil(fight)
    -- return GameLogicTools.GetNumStr(fight), fight
end

function HeroProxy:GetHeroFight(herolist, is_battle)
    local fight = 0
    for _, herodata in pairs(herolist) do
        local herouid = is_battle and herodata.fromuid or herodata.herouid
        local heroattr = self:GetHeroAttr(herodata.roleid, herodata.rank, herodata.crystalLevel or herodata.level, herouid, herodata.equips, nil, herodata.tree_info)
        local heroFight = self:GetAttrFight(heroattr)
        fight = fight + heroFight
    end
    return GameLogicTools.GetNumStr(fight), fight
end

function HeroProxy:GetHeroFightWithPrint(herolist)
    local fight = 0
    local fightList = {}
    for _, herodata in pairs(herolist) do
        local heroattr = self:GetHeroAttr(herodata.roleid, herodata.rank, herodata.crystalLevel or herodata.level, herodata.herouid, herodata.equips)
        local heroFight = self:GetAttrFight(heroattr)
        fight = fight + heroFight

        local attr = {}
        for k, v in pairs(heroattr) do
            if v > 0 then
                table.insert(attr, { name = k, value = v })
            end
        end
        table.sort(attr, function(a, b)
            return a.name < b.name
        end)
        table.insert(fightList, { herodata.level, herodata.herouid, heroFight, herodata.roleid, attr })
    end
    table.sort(fightList, function(a, b)
        if a[1] == b[1] then
            return a[3] > b[3]
        else
            return a[1] > b[1]
        end
    end)
    print(table.dump(fightList))
    fight = math.ceil(fight)
    return GameLogicTools.GetNumStr(fight), fight
end

--获取共鸣水晶等级全英雄战力
function HeroProxy:GetCrystalNextLevelAllFight(crystalLevel, crystal_sublevel)
    local herolist = self:GetHeroDataList()
    return self:GetCrystalNextFight(herolist, crystalLevel, crystal_sublevel)
end
function HeroProxy:GetCrystalNextFight(herolist, crystalLevel, crystal_sublevel)
    local fight = 0

    for _, herodata in pairs(herolist) do
        local level = herodata.level
        local maxlevel = self:GetHeroMaxLevelByRoleId(crystalLevel, herodata.roleid)
        local heroattr = {}
        if herodata.crystalLevel then
            level = maxlevel
            if crystalLevel > maxlevel then
                heroattr = self:GetHeroAttr(herodata.roleid, herodata.rank, level, herodata.herouid, nil, 9)
            else
                heroattr = self:GetHeroAttr(herodata.roleid, herodata.rank, level, herodata.herouid, nil, crystal_sublevel)
            end
        else
            heroattr = self:GetHeroAttr(herodata.roleid, herodata.rank, level, herodata.herouid, nil, 0)
        end

        fight = fight + self:GetAttrFight(heroattr)
    end
    fight = math.ceil(fight)
    return GameLogicTools.GetNumStr(fight), fight
end


--获取英雄基础战力
function HeroProxy:GetHeroBaseFight(heroconfigid, rank, level, herouid, equips)
    local heroattr = self:GetHeroAttr(heroconfigid, rank, level, herouid, equips)
    local fight = self:GetAttrFight(heroattr)
    return math.ceil(fight)
end

function HeroProxy:_GetLevelFactor(level, sublevel)
    local cfgs = ConfigManager.GetConfig("data_levelfactor")
    local sublevelidx = 240

    sublevel = sublevel or 0
    if level < sublevelidx then
        return cfgs[level]
    else
        for i = sublevelidx, #cfgs do
            local cfg = cfgs[i]
            if cfg.level == level and cfg.sub_level == sublevel then
                return cfg
            end
        end
    end
end

function HeroProxy:GetHeroEquipsAttr(hero_type_id, hero_equips, otherattr)
    local equip_list = {}
    for _, hero_equip_info in ipairs(hero_equips) do
        -- local position = hero_equip_info[1]
        local equip_id = hero_equip_info[2]
        table.insert(equip_list, equip_id)
    end

    if #equip_list > 0 then
        local EquipProxy = require "Modules.Equip.EquipProxy"
        local equip_attr = EquipProxy.Instance:GetEquipAttr(hero_type_id, equip_list)
        -- local equip_attr = game.selfapi(uin, "get_equip_attr", {hero_type_id = hero_type_id, equip_list = equip_list})
        -- print("------->>equip_attr", libdebug.dump(equip_attr))
        for k, v in pairs(equip_attr) do
            if otherattr[k] then
                otherattr[k] = otherattr[k] + v
            else
                otherattr[k] = v
            end
        end
    end
    return otherattr
end

--敌方配置 属性
function HeroProxy:GetEnemyHeroEquipsAttr(hero_type_id, equips_cfg, otherattr)
    local EquipProxy = require "Modules.Equip.EquipProxy"
    local equip_attr = EquipProxy.Instance:GetEnemyEquipAttr(hero_type_id, equips_cfg)
    for k, v in pairs(equip_attr) do
        if otherattr[k] then
            otherattr[k] = otherattr[k] + v
        else
            otherattr[k] = v
        end
    end
    return otherattr
end

--crystal_sub_level:共鸣水晶子等级 equips = {{goods_type_id, goods_grade}} ;  tree_info = {0,0} --主树等级 和 自己职业分支树等级, 阵营加成
function HeroProxy:GetHeroAttr(heroconfigid, rank, level, herouid, equips, crystal_sub_level, tree_info, activityid, relation_add_attr)
    local sublevel = crystal_sub_level or 0
    local heroattr = {} --英雄身上的属性
    local otherattr = {} --其他属性
    local unionattr = {} --羁绊属性
    local tree_attrs = {} --树属性

    if herouid then
        --水晶阶段等级
        local CrystalProxy = require "Modules.Crystal.CrystalProxy"
        local crystaldata = CrystalProxy.Instance:GetCrystalData()
        local crystalLevel = crystaldata.level --解决水晶升级前后等级战力显示异常
        local herodata = self:GetHeroDataByUid(herouid)

        sublevel = crystal_sub_level or crystaldata.sublevelup

        local maxlevel = self:GetHeroMaxLevelByRoleId(level, heroconfigid)

        if herodata and herodata.crystalLevel then
            if level == maxlevel and crystalLevel > maxlevel then
                sublevel = 9
            end
        else
            sublevel = 0
        end
    end

    if activityid == ACTIVITYID.GUILD_CHAOS then
        sublevel = 0
    end

    --玩家基础属性
    -- print("rank, level, sublevel ==", heroconfigid, rank, level, sublevel)
    heroattr = self:GetBaseHeroAttr(heroconfigid, rank, level, sublevel)
    --print("heroattr -->", table.dump(heroattr))
    --其他基础属性
    ---装备属性
    if herouid then
        local herodata = self:GetHeroDataByUid(herouid)
        if herodata and herodata.equips then
            otherattr = self:GetHeroEquipsAttr(heroconfigid, herodata.equips, otherattr)
        elseif equips then
            --配置裝備 equips = {{equiptypeid, lv}, ...}
            otherattr = self:GetEnemyHeroEquipsAttr(heroconfigid, equips, otherattr)
        end
    elseif equips then
        --配置裝備 equips = {{equiptypeid, lv}, ...}
        otherattr = self:GetEnemyHeroEquipsAttr(heroconfigid, equips, otherattr)
    end

    --羁绊两个基础属性累加
    if herouid then
        --自己的
        unionattr = self:GetUnionAttr(heroconfigid, herouid, unionattr)
        for key, value in pairs(unionattr) do
            if value > 0 then
                if otherattr[key] then
                    otherattr[key] = otherattr[key] + value
                else
                    otherattr[key] = value
                end
            end
        end
    else
        --敌方的羁绊属性，特别是pvp 敌方是真实玩家英雄的羁绊属性
    end

    local TreeProxy = require "Modules.Tree.TreeProxy"
    if herouid then
        local herodata = self:GetHeroDataByUid(herouid)
        if herodata then
            tree_attrs = TreeProxy.Instance:GetTreeAttr(heroconfigid)
            for k, v in pairs(tree_attrs) do
                otherattr[k] = (otherattr[k] or 0) + v
            end
        end
    end

    --不是自己的英雄 ，用主动传生命树的数据
    if not next(tree_attrs) and tree_info then
        tree_attrs = TreeProxy.Instance:GetTreeAttr(heroconfigid, tree_info[1], tree_info[2])
        for k, v in pairs(tree_attrs) do
            otherattr[k] = (otherattr[k] or 0) + v
        end
    end

	if relation_add_attr then
		self:CombineHeroAttr(otherattr, relation_add_attr)
	end

    --百分比属性处理
    if otherattr.hp_max_rate then
        heroattr.hp = math.ceil(heroattr.hp * otherattr.hp_max_rate / 1000) + heroattr.hp
        heroattr.hp_max = heroattr.hp
    end
    if otherattr.atk_rate then
        heroattr.atk = math.ceil(heroattr.atk * otherattr.atk_rate / 1000) + heroattr.atk
    end
    if otherattr.def_rate then
        heroattr.def = math.ceil(heroattr.def * otherattr.def_rate / 1000) + heroattr.def
    end

    --两个基础属性累加
    for key, value in pairs(otherattr) do
        if value > 0 then
            if heroattr[key] then
                heroattr[key] = heroattr[key] + value
            else
                heroattr[key] = value
            end
        end
    end

    return heroattr
end

--new_attr_list(name,value)(["hp"] = 30)
function HeroProxy:CombineHeroAttr(attr, new_attr_list)
	if attr and new_attr_list then
		for key,value in pairs(new_attr_list) do
			if CONST.ATTR_NAME[key] and (value > 0) then
				if attr[key] then
					attr[key] = attr[key] + value
				else
					attr[key] = value
				end
			end
		end
	end
	return attr
end

function HeroProxy:GetUnionAttr(heroconfigid, herouid, unionattr)

    local roleid
    local RelationProxy = require "Modules.Relation.RelationProxy"
    if herouid then
        local herodata = self:GetHeroDataByUid(herouid)
        if herodata then
            roleid = herodata.roleid
        else
            -- 图鉴显示 不需要算羁绊属性
            return {}
        end
    end
    roleid = roleid or heroconfigid
    if roleid then
        unionattr = RelationProxy.Instance:GetAttr(roleid)
    end
    return unionattr
end

function HeroProxy:GetBaseHeroAttr(heroconfigid, rank, level, sublevel)
    rank = rank or 1
    level = level or 1
    local attr_value = ConfigManager.GetConfig("role_attr")
    local rankfactor = ConfigManager.GetConfig("data_rankfactor")[rank]
    local levelfactor = self:_GetLevelFactor(level, sublevel)
    local tab = attr_value[heroconfigid]
    if tab and rankfactor and levelfactor then
        local heroattr = table.deepcopy(tab)
        heroattr.level = level
        heroattr.rank_level = rank
        heroattr.def = math.ceil(tab.def * rankfactor.basics_factor / 1000 + tab.def * levelfactor.factor / 1000 * rankfactor.level_factor / 1000)
        heroattr.hp_max = math.ceil(tab.hp_max * rankfactor.basics_factor / 1000 + tab.hp_max * levelfactor.factor / 1000 * rankfactor.level_factor / 1000)
        heroattr.hp = math.ceil(tab.hp * rankfactor.basics_factor / 1000 + tab.hp * levelfactor.factor / 1000 * rankfactor.level_factor / 1000)
        heroattr.atk = math.ceil(tab.atk * rankfactor.basics_factor / 1000 + tab.atk * levelfactor.factor / 1000 * rankfactor.level_factor / 1000)
		--print(heroconfigid, level, sublevel, rankfactor.basics_factor, rankfactor.level_factor, levelfactor.factor)
        return heroattr
    else
        local heroattr = {}
        if tab then
            heroattr = table.deepcopy(tab)
        end
        return heroattr
    end
end

function HeroProxy:GetMaxRank()
    return 16
end

function HeroProxy:GetHeroMaxRankByRoleId(roleid)
    local cfg = self:GetRoleCfgByConfigId(roleid)
    return cfg.rank_max
end

--获取扩容钻石 return Diamond, opennum
function HeroProxy:GetHeroContainerDiamond()
    local config = ConfigManager.GetConfig("data_common").herocontainer.value1
    return math.floor(config[1] + self.data.buycontainercount * config[2]), config[4]
end

--获取背包槽位
function HeroProxy:GetHeroSurplusCount()
    local count = self.data.herocontainer - #self.data.herolist
    return count
end

--是否可以快速升级 retrun level
function HeroProxy:IsQuickLevelUp(uid)
    local BagProxy = require "Modules.Bag.BagProxy"
    local herodata = self:GetHeroDataByUid(uid)

    local list = self:GetHeroDataList()
    table.sort(list, function(a, b)
        return a.level > b.level
    end)
    local fourherodata = list[4]
    if not fourherodata or herodata.level >= fourherodata.level then
        return nil
    end
    local rankinfo = self:GetRankInfoCfgById(herodata.rank)

    local startlevel
    local needgold
    local needexp
    local needdust

    function statistics_consume(startlv, endlv, max_lv)
        needgold = 0
        needexp = 0
        needdust = 0
        for i = startlv, endlv do
            local upgradecfg = self:GetUpgradeCfgBylevel(i)
            if i < max_lv then
                needgold = needgold + upgradecfg.gold
                needexp = needexp + upgradecfg.exp
                needdust = needdust + upgradecfg.dust
            end
        end
        local num = BagProxy.Instance:GetItemCountByID(690001)
        if RoleInfoModel.coin >= needgold and RoleInfoModel.hero_exp >= needexp and num >= needdust then

            return true
        end
    end

    for i = fourherodata.level, herodata.level, -1 do
        local upgradecfg = self:GetUpgradeCfgBylevel(i)
        if not startlevel then
            if upgradecfg.dust > 0 then
                if (i - herodata.level) < 60 then
                    return nil
                elseif i <= rankinfo.lvmax and (i <= 220 and i >= 80) then
                    local is_enough = statistics_consume(herodata.level, i, fourherodata.level)
                    if is_enough then
                        startlevel = i
                        break
                    end
                end
            end
        end
    end
    -- print(string.format("===IsQuickLevelUp=== level:%s, need %s, %s ,%s , cur: %s, %s, %s",
    --         startlevel, needgold, needexp, needdust, RoleInfoModel.coin, RoleInfoModel.hero_exp, num))
    if startlevel then
        return startlevel, needgold, needexp, needdust
    end
    return nil
end

function HeroProxy:GetHeroLevelString(herouid, herodata, level, activityId)
    herodata = herodata or self:GetHeroDataByUid(herouid)
    local LanguageManager = require "Common.Mgr.Language.LanguageManager"

    if activityId == ACTIVITYID.GUILD_CHAOS then
        return string.format("<color=#5bd494>%s</color>", LanguageManager.Instance:GetWord("Common_1001", level))
    elseif herodata and herodata.crystalLevel then
        local CrystalProxy = require "Modules.Crystal.CrystalProxy"
        local str = LanguageManager.Instance:GetWord("Common_1001", herodata.crystalLevel)
        if CrystalProxy.Instance:IsUnLock() then
            return string.format("<color=yellow>%s</color>", str), herodata.crystalLevel
        else
            return string.format("<color=#80cded>%s</color>", str), herodata.crystalLevel
        end
    else
        if herodata then
            return LanguageManager.Instance:GetWord("Common_1001", herodata.level), herodata.level
        else
            return LanguageManager.Instance:GetWord("Common_1001", level or 1), level
        end
    end
end

function HeroProxy:NeedLevel()
    local CrystalProxy = require "Modules.Crystal.CrystalProxy"
    local crystaldata = CrystalProxy.Instance:GetCrystalData()
    local cfg = ConfigManager.GetConfig("data_common").hero_lv_limit.value1
    for _, info in ipairs(cfg) do
        if info[3] > crystaldata.maxlevel then
            return info[1]
        end
    end
    return 240
end

function HeroProxy:GetHeroCount()
    return #self.data.herolist
end

--获取英雄等级以及子等级(共鸣水晶)
function HeroProxy:GetHeroLevelAndSubLevel(heroUid, heroTypeId, rank, level, crystal_sub_level)
    local _sub_level = crystal_sub_level or 0
    local _level = level or 1
    local _rank = rank or 1
    if heroUid then
        local herodata = self:GetHeroDataByUid(heroUid)
        if herodata then
            --水晶阶段等级
            _level = herodata.level
            _rank = herodata.rank
            local CrystalProxy = require "Modules.Crystal.CrystalProxy"
            local crystaldata = CrystalProxy.Instance:GetCrystalData()
            _sub_level = crystaldata.sublevelup
            if herodata.crystalLevel then
                _level = herodata.crystalLevel
            end
            heroTypeId = herodata.roleid
        end
    end

    local herocfg = self:GetRankInfoCfgById(_rank)
    if heroCfg then
        _level = math.min(herocfg.lvmax, _level or 1)
    end
    return _rank, _level, _sub_level
end

--是否有可遣散英雄
function HeroProxy:IsRetireHero()
    local bRetire = false
    local list = HeroProxy.Instance:GetHeroDataListByRace(nil)
    for k, data in pairs(list) do
        if data.rank <= HeroDef.Hero_Rank_Enum.green then
            bRetire = true
            break
        end
    end
    return bRetire
end

function HeroProxy:GetHeroAnimTime(heroTypeId)
    local delay = 5
    local data_active = faceConfig["data_active"]
    local hero_active_config = data_active[tostring(heroTypeId) .. "_ex"]
    if hero_active_config and hero_active_config["appearance"] then
        for i, active_info in ipairs(hero_active_config["appearance"]) do
            if active_info.type == "anim" and active_info.name == "Appearance" then
                delay = active_info.duration
                break
            end
        end
    end
    return delay
end

function HeroProxy:AFEventGetHeroComplete(count, new_hero_list)

    local last_herocount = #self.data.roleid_List or {}

    for i, info in ipairs(new_hero_list) do
        local bfind = false
        for _, v in ipairs(self.data.roleid_List) do
            if v[1] == info[2] then
                bfind = true
                break
            end
        end
        if not bfind then
            table.insert(self.data.roleid_List, { info[2] })
        end
    end

    local IGGSdkDef = require "Modules.IGGSdk.IGGSdkDef"
    local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"

    local _key
    for k, event in pairs(IGGSdkDef.AFEventHero) do
        if k > last_herocount and k <= count then
            _key = event
        end
    end

    if _key then
        IGGSdkProxy.Instance:Track(_key)
    end

end
function HeroProxy:GetTheFightHighestHero()
    local herolist = self:GetHeroDataList()
    local _fight = 0
    local hero = false
    for _, herodata in pairs(herolist) do
        local heroattr = self:GetHeroAttr(herodata.roleid, herodata.rank, herodata.crystalLevel or herodata.level, herodata.herouid)
        local fight = self:GetAttrFight(heroattr)
        if _fight < fight then
            _fight = fight
            hero = table.deepcopy(herodata)
        end
    end
    return hero
end

function HeroProxy:SetHeroInputEnable(enable)
    local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.HeroNewView)
    if view and view:IsOpen() then
        view:SetHeroInputEnable(enable)
    end
end

--获取前五名战力最高的英雄战力
function HeroProxy:GetTopFiveHeroFight()
    local top_five_hero_fight = 0
    local top_five_hero_list = {}
    local herolist = self:GetHeroDataList()
    for k, herodata in pairs(herolist) do
        local heroattr = self:GetHeroAttr(herodata.roleid, herodata.rank, herodata.crystalLevel or herodata.level, herodata.herouid)
        local fight = self:GetAttrFight(heroattr)

        if #top_five_hero_list < 5 then
            table.insert(top_five_hero_list, { herouid = herodata.herouid, hero_fight = fight })
            table.sort(top_five_hero_list, function(a, b)
                return a.hero_fight > b.hero_fight
            end)
        else
            local insert_index = 0
            for i = #top_five_hero_list, 1, -1 do
                if fight <= top_five_hero_list[i].hero_fight then
                    insert_index = i
                    break
                end
            end

            if insert_index < 5 then
                table.insert(top_five_hero_list, insert_index + 1, { herouid = herodata.herouid, hero_fight = fight })
            end
            top_five_hero_list[#top_five_hero_list] = nil
        end
    end

    for i, v in ipairs(top_five_hero_list) do
        top_five_hero_fight = top_five_hero_fight + v.hero_fight
    end

    return top_five_hero_fight
end

function HeroProxy:IsFiveHeroCountTo240Lv()
    local bFit = false
    local count = 0
    local list = self:GetHeroDataList()
    for k, herodata in pairs(list) do
        if herodata.level >= 240 then
            count = count + 1
            if count >= 5 then
                bFit = true
                break
            end
        end
    end
    return bFit
end

function HeroProxy:GetOffsetLevelUpAttrTb(herouid, rank, roleid, level)
    local ret = {}
    local herodata = self:GetHeroDataByUid(herouid)
    local rank = rank or (herodata and herodata.rank)
    local level = level or (herodata and herodata.level)
    local roleid = roleid or (herodata and herodata.roleid)

    local attrtab = HeroProxy.Instance:GetHeroAttr(roleid, rank, level)
    local lastattrtab = HeroProxy.Instance:GetHeroAttr(roleid, rank, level - 1)
    table.insert(ret, { ["key"] = "atk", ["type"] = 7, ["value"] = attrtab.atk - lastattrtab.atk })
    table.insert(ret, { ["key"] = "hp_max", ["type"] = 2, ["value"] = attrtab.hp_max - lastattrtab.hp_max })
    table.insert(ret, { ["key"] = "def", ["type"] = 8, ["value"] = attrtab.def - lastattrtab.def })
    return ret
end

--
function HeroProxy:GetHeroTypeIdListByProfession(profession)
    local ret = {}
    local temp_dict = {}
    local cfg = self:GetHeroConfige()
    for k, v in pairs(cfg) do
        if v.profession == profession and v.rank_max >= 16 then
            temp_dict[k] = 1
            --table.insert(ret,{k})
        end
    end
    for k, v in pairs(self.data.herolist) do
        if v.roleid and temp_dict[v.roleid] and v.rank > temp_dict[v.roleid] then
            temp_dict[v.roleid] = v.rank
        end
    end
    for k, v in pairs(temp_dict) do
        table.insert(ret, { roleid = k, rank = v })
    end
    table.sort(ret, function(a, b)
        if b.rank ~= a.rank then
            return b.rank < a.rank
        else
            return b.roleid > a.roleid
        end
    end)
    return ret
end

--检查是否触发英雄类SDK广告事件日志
function HeroProxy:CheckHeroLvUpIGGSdkEventInfo(herouid, formerLv, level)
    local IGGSdkDef = require "Modules.IGGSdk.IGGSdkDef"
    for lv, info in pairs(IGGSdkDef.AFEventHeroLv) do
        if formerLv < lv and level >= lv then
            local hero_list = self:GetHeroListByLv(lv)
            local temp_num = #hero_list
            local sdk_key = info[temp_num]
            if sdk_key and not self:GetHeroLvUpSdkEventInfoByKey(sdk_key) then
                self:Send20015(sdk_key)
            end
        end
    end
end

function HeroProxy:GetHeroLvUpSdkEventInfoByKey(sdk_key)
    if self.hero_igg_sdk_info and self.hero_igg_sdk_info[sdk_key] then
        return true
    end
    return false
end

--获得大于等于X级的英雄列表
function HeroProxy:GetHeroListByLv(lv)
    local ret = {}
    local hero_list = self:GetHeroDataList()
    if not lv or lv <= 1 then
        return hero_list
    end

    for _, hero_data in ipairs(hero_list) do
        if hero_data.level >= lv then
            table.insert(ret, hero_data)
        end
    end

    return ret
end

return HeroProxy