local build_view = build_view or BaseClass()
local mapobj_model = require "Modules.HexMap.mapobj_model"
local cell_center_anchor = require "Modules.HexMap.cell_center_anchor"

build_view.cmd = {}

function build_view:__init(args)
    local prefab_id = args.prefab_id
    local asset_type = AssetType.BUILD
    local position = args.position

    local rotx, roty, rotz = table.unpack(args.header or {})
    self.anchor = cell_center_anchor.New(position, rotx, roty, rotz)
    self.model = mapobj_model.New(self.anchor, prefab_id, asset_type)
    
end

function build_view:move_to(position, speed, cbreach)
    return self.anchor:move_follow_path({position}, speed, cbreach, nil, true)
end

function build_view:release()
    if self.model then
        self.model:release()
        self.model = nil
    end
    self.anchor = nil
end

function build_view:__delete()
    self:release()
end

return build_view
