local MallMediator = MallMediator or BaseClass(StdMediator)

function MallMediator:OnEnterScenceFirst()
	-- self:DelayExecute(function ()
		--推送礼包需要登录时立即出现，因此不延迟处理
		local MallProxy = require "Modules.Mall.MallProxy"
		MallProxy.Instance:Send72000()
	-- end)
	
	local ModuleManager = require "Common.Mgr.UI.ModuleManager"
	local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
	local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.MallRootView,false)
	if bopen then
		local VipProxy = require "Modules.Vip.VipProxy"
		VipProxy.Instance:Send72005()
		-- local MallPassProxy = require "Modules.Mall.MallPassProxy"
		-- MallPassProxy.Instance:Send20800()
	end

	self:DelayExecute(function ()
		local MallPassProxy = require "Modules.Mall.MallPassProxy"
		MallPassProxy.Instance:Send20800()
	end)

	self:DelayExecute(function ()
		local MallCustomProxy = require "Modules.Mall.MallCustomProxy"
		MallCustomProxy.Instance:Send20900()
	end)
end

return MallMediator