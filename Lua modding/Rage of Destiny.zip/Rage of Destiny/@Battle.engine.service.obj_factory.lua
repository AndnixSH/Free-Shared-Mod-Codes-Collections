local factory = {}

local objmt = {}

function objmt:createlogic(typeid, prop)
    local logic = self:getlogic(typeid)
    if logic then 
        global.debug.warning(self, "已经存在logic", typeid, debug.traceback())
        logic:destroy() 
    end

    local template = global.service.requirer:require(typeid)
    local logic = factory._service.logic_factory:createlogic(self, typeid, nil, prop, template)
    return logic
end

function objmt:destroylogic(typeid)
    local logic = self:getlogic(typeid)
    if logic then logic:destroy() end
end

function objmt:getlogic(typeid)
    return factory._service.pool:getlogic(self, typeid)
end

function objmt:checklogic(typeid, prop)
    local logic = self:getlogic(typeid)
    if not logic then
        logic = self:createlogic(typeid, prop)
    elseif prop then
        logic:setprop(prop)
    end
    return logic
end

function objmt:getalllogic()
    return factory._service.pool:get_all_logic(self)
end

function objmt:valid()
    return not self._dirty
end

function objmt:settype(type)
    self.type = type
end

function objmt:sendmessage(eventkey, ...)
    local msgtype = self.type
    local slot = factory._service.eventslots:getslot(msgtype)
    if slot then
        slot:broadcastfrom(eventkey, self, ...)
    else
        global.debug.warning("send message fail, not find slot", msgtype)
    end
end

function objmt:callmessage(eventkey, ...)
    local msgtype = self.type
    local slot = factory._service.eventslots:getslot(msgtype)
    if slot then
        return slot:callfrom(eventkey, self, ...)
    else
        global.debug.warning("call message fail, not find slot", msgtype)
    end
    return true
end

function objmt:pause()
    self._bpause = true
end

function objmt:ispause()
    return self._bpause
end

function objmt:resume()
    self._bpause = false
end

function objmt:destroy(immediate)
    if self._dirty or self._idirty then return end
    self._idirty = true -- 正在销毁
    if immediate then
        factory:_destroyobj(self)
    else
        factory:destroyobj(self)
    end
end

local function debugtostring(self)
    local temp = getmetatable(self)
    setmetatable(self, nil)
    local ret = string.format("uid: %d %s", self.uid, self)
    setmetatable(self, temp)
    return ret
end

function objmt:__tostring()
    return self.tostring and self:tostring() or self.uid
end

objmt.__index = objmt

function factory:init()
    self._service = global.service
    self._config = {}
    self.destroylistener = listener()
end

function factory:createobj(typeid, prop, type)
    return self:addobj(nil, typeid, prop, type)
end

function factory:addobj(uid, typeid, prop, type)
    local instance = { prop = {}, typeid = typeid, type = type, caller = {} }
    if prop then
        for k, v in pairs(prop) do
            instance.prop[k] = v
        end
    end
    self._service.pool:add_obj(instance, uid)
    setmetatable(instance, objmt)
    return instance
end

function factory:destroyobj(obj)
    self._service.frame:afterframe(self._destroyobj, self, obj)
end

function factory:_destroyobj(obj)
    local logics = obj:getalllogic()
    for i = #logics, 1, -1 do
        local _logic = logics[i]
        _logic:destroy(true)
    end
    self.destroylistener:invoke(obj)
    -- obj.prop = nil
    self._service.pool:remove_obj(obj)
    obj._dirty = true
end

function factory:dispose()
    self._config = nil
    self._service = nil
    self.destroylistener = nil
end

return factory