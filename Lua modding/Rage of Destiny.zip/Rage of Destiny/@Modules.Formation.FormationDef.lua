local FormationDef = {}
FormationDef.Notify = {
	Fromations_Info = "Fromations_Info",
	FormationName_Change = "FormationName_Change",
	Formation_Top_Change = "Formation_Top_Change",
	Formation_Delete_Change = "Formation_Delete_Change",
	Formation_GetHeroInfos = "Formation_GetHeroInfos",
	Formation_Add_Formation = "Formation_Add_Formation",
	Formation_Info_Change = "Formation_Info_Change",
}

FormationDef.FormationParama = {
	Max_Count = 64, --最大编队数量 
} 

FormationDef.Formation_State = {
	Exist = 1, --有编队
	CanEditor = 2,--没编队，可编辑 
	NotEditor = 3, --没编队，不可被编辑
}

FormationDef.LanguageKey = {
	FormationKey1 = "FormationKey1",
	FormationKey2 = "FormationKey2",
	FormationKey3 = "FormationKey3",
	FormationKey4 = "FormationKey4",
	FormationKey5 = "FormationKey5",
	FormationKey6 = "FormationKey6",
	FormationKey7 = "FormationKey7",
	FormationKey8 = "FormationKey8",  --此队伍不可修改
	FormationKey9 = "FormationKey9",  --无法将佣兵加入到预设阵容种
	FormationInputCheck_1 = "FormationInputCheck_1",
	FormationInputCheck_2 = "FormationInputCheck_2",
	FormationInputCheck_3 = "FormationInputCheck_3",

}

FormationDef.FormationType = {
	NormalType = 1,  --普通编队
	SpecialType = 2, --战报特殊编队
}




return FormationDef