local FormationMediator = FormationMediator or BaseClass(StdMediator)

function FormationMediator:OnEnterScenceFirst()
	local FormationProxy = require "Modules.Formation.FormationProxy"
	FormationProxy.Instance:Send20400()
end




return FormationMediator