local GuildDef = require "Modules.Guild.GuildDef"
local ClistRender = require "Core.Implement.UI.Class.ClistRender"
local ClistItem = require "Core.Implement.UI.Class.ClistItem"
local GuildProxy = require "Modules.Guild.GuildProxy"
local HeadItem = require "Core.Implement.UI.Class.HeadItem"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"

local GuildApplyViewItem = GuildApplyViewItem or BaseClass(ClistItem)

function GuildApplyViewItem:Load(obj)
	self.headObj = self:GetChild(self.go, "Headitem")
	self.headClass = HeadItem.New(self.headObj)
	self.headClass:SetHeadOnClickCallBack(function()
		if self.data then
			local view=LuaLayout.Instance:GetWidget(UIWidgetNameDef.OtherPlayerInfolView)
		    if view then
		        view.playerUid = self.data.guser
		        view.selectTab = 1
		        view.openTabs = {1}
		        view:OpenView()
		    end
		end
	end)

	self.refuseBtn = self:GetChildComponent(self.go, "CButton_refuse", "CButton")
	self.receiveBtn = self:GetChildComponent(self.go, "CButton_agree", "CButton")
	self.refuseBtn:AddClick(function()
		if self.data then
			GuildProxy.Instance:Send70005(1, self.data.guser)
		end
	end)

	self.receiveBtn:AddClick(function()
		if self.data then
			GuildProxy.Instance:Send70005(2, self.data.guser)
		end
	end)

end

function GuildApplyViewItem:SetData(data)
	self.data = data
	self.headClass:SetData(data.headItem)
end



local GuildApplyView = GuildApplyView or LuaWidgetClass()

function GuildApplyView:__init()
	self.tweenOption = {bScale = true}
end

function GuildApplyView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Guild.GuildApplyView", self.LoadEnd)
end

function GuildApplyView:LoadEnd(obj)
	self:SetGo(obj)
	self:InitUI()
	self:SetStep(0)
end

function GuildApplyView:InitUI()
	self.closeBtn = self:GetChildComponent(self.go, "root/root/content/close", "CButton")
	self.closeBtn:AddClick(function( ... )
		self:CloseView()
	end)
	self.emptyObj = self:GetChild(self.go, "root/root/content/NoRecord")
	self.memberLab = self:GetChildComponent(self.go, "root/CLabel/CLabel_num", "CLabel")  --string.format("<color=#ffffff>%d</color>/%d")
	
	self.clist = self:GetChildComponent(self.go, "root/CList", "CList")
	self.clistRender = ClistRender.New()
	self.clistRender:Load(self.clist, GuildApplyViewItem)
	self.refuseBtn = self:GetChildComponent(self.go, "root/Button/CButton_refuseall", "CButton")
	self.agrreBtn = self:GetChildComponent(self.go, "root/Button/CButton_agreeall", "CButton")
	self.refuseBtn:AddClick(function()
		if self.applyInfos then
			if #self.applyInfos == 0 then
				GameLogicTools.ShowMsgTips(GuildDef.LanguageKey.GuildApplyView1)
			else
				GuildProxy.Instance:Send70006(1)
			end
		end
	end)
	self.agrreBtn:AddClick(function()
		if self.applyInfos then
			if #self.applyInfos == 0 then
				GameLogicTools.ShowMsgTips(GuildDef.LanguageKey.GuildApplyView1)
			else
				GuildProxy.Instance:Send70006(2)
			end
		end
	end)
end

function GuildApplyView:OnClose()
	self:AutoUnRegister()
end

function GuildApplyView:OnDestroy()
	self:AutoUnRegister()
end

function GuildApplyView:OnOpen()
	self:AutoRegister()
	GuildProxy.Instance:Send70004()
end

function GuildApplyView.EvtNotify.Guild.data:UpdateApplyInfos(data, args)
	self.applyInfos = args.applyInfos
	self.emptyObj:SetActive(#self.applyInfos == 0 and true or false)
	self.clistRender:ClearData()
	self.clistRender:AppendDataList(self.applyInfos)
	local curCount = GuildProxy.Instance:GetGuildMemberCount()
	local guildInfos = GuildProxy.Instance:GetGuildInfos()
	local level = guildInfos.level
	local cfg = GuildProxy.Instance:GetLevelConfigByLevel(level)
	local maxcount = cfg.population
	self.memberLab.text = self:GetWord(GuildDef.LanguageKey.GuildHallView1, curCount, maxcount)

end

function GuildApplyView.EvtNotify.Guild.data:UpdateMemberInfosCount(data, args)
	local curCount = GuildProxy.Instance:GetGuildMemberCount()
	local guildInfos = GuildProxy.Instance:GetGuildInfos()
	local level = guildInfos.level
	local cfg = GuildProxy.Instance:GetLevelConfigByLevel(level)
	local maxcount = cfg.population
	self.memberLab.text = self:GetWord(GuildDef.LanguageKey.GuildHallView1, curCount, maxcount)
end

return GuildApplyView