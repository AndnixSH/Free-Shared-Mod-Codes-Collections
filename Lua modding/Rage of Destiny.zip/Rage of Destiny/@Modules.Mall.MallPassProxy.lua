local MallDef = require "Modules.Mall.MallDef"
local MallPassProxy = MallPassProxy or BaseClass(BaseProxy)
local RedPointDef = require "Modules.RedPoint.RedPointDef"
function MallPassProxy:__init()
	MallPassProxy.Instance = self

	self:AddProto(20800, self.On20800) --所有赏金社相关信息
	self:AddProto(20801, self.On20801) --更新赏金社信息(进度)
	self:AddProto(20802, self.On20802) --检查购买赏金社VIp
	self:AddProto(20803, self.On20803) --领取奖励(不传ID就是一键领取)
	self:AddProto(20804, self.On20804) --购买点数(购买赏金点数)
	self:AddProto(20805, self.On20805) --第一次购买日志
	self:AddProto(20806, self.On20806) --赏金重置 后第一次进入界面的公告 通知服务端 已阅

	self.data = {}
end

function MallPassProxy:__delete(self)
    MallPassProxy.Instance = nil
end

function MallPassProxy:Send20800()
	self:SendMessage(20800)
end

function MallPassProxy:On20800(decoder)
	-- self.data.pass_open_info = decoder:DecodeList("I2") --{[赏金类型] = bool}
	self.data.pass_unlock_info = decoder:DecodeList("I2") -- {[赏金类型] = bool}
	self.data.pass_cycle_info = decoder:DecodeList("I4") -- {[赏金类型] = 开启时间}
	self.data.pass_progress_info = decoder:DecodeList("I4") -- {[赏金类型] = 进度数值}
	self.data.pass_reward_info = self.data.pass_reward_info or {}
	self.data.pass_level_info = decoder:DecodeList("I2")
	self.data.pass_new_tips_info = decoder:DecodeList("I2")
	self.data.pass_open_info = decoder:DecodeList("I1")

	--self.data.pass_reward_info = decoder:DecodeList("I2I2",true) -- {[赏金类型] = {[普通奖励] = 领取状态 , [额外奖励] = 领取状态}}
	for index in ipairs(MallDef.PassTabType) do
		local rewards_info = decoder:DecodeList("I2I2",true)
		local configs = self:GetPassConfigs(index)
		for id,info in ipairs(configs) do
			if not rewards_info[id] then
				rewards_info[id] = {MallDef.CommonRewardState.CantGet,MallDef.CommonRewardState.CantGet}
			end 
		end
		self.data.pass_reward_info[index] = rewards_info
	end
	-- print("-------On20800----->",table.dump(self.data))
	self:CheckPassRed()
	self:ToNotify(self.data, MallDef.Notify.UpdateAllPassInfo)
end

function MallPassProxy:Send20801()
	self:SendMessage(20801)
end

function MallPassProxy:On20801(decoder)
	local pass_type = decoder:Decode("I2") --赏金类型
	self.data.pass_progress_info[pass_type] = decoder:Decode("I4") -- 进度数值
	self.data.pass_unlock_info[pass_type] = decoder:Decode("I2")
	local rewards_info = decoder:DecodeList("I2I2",true)
	
	--print("MallPassProxy:On20801---------->",pass_type , self.data.pass_progress_info[pass_type] , rewards_info and table.dump(rewards_info))

	if rewards_info then
		for k,v in ipairs(rewards_info) do
			self.data.pass_reward_info[pass_type][k] = v	
		end
	end
	self:CheckPassRed(pass_type)
	self:ToNotify(self.data, MallDef.Notify.UpdatePassInfo)
end

function MallPassProxy:Send20802(pass_type)
    if pass_type then
    	local encoder = NetEncoder.New()
	    encoder:Encode("I2", pass_type)
		self:SendMessage(20802,encoder)
	end
end

function MallPassProxy:On20802(decoder)
	local result = decoder:Decode("I1")
    if result == 0 then
    	local pass_type = decoder:Decode("I2")
    	local pass_base_id = MallDef.MallPassType2PassBaseId[pass_type]
		local pass_base_cfg = self:GetPassBaseCfgById(pass_base_id)
		local MallProxy = require "Modules.Mall.MallProxy"
		 --print("On20802------------>",pass_base_cfg.gift)
		 MallProxy.Instance:SDKBuy(pass_base_cfg.gift)
	else
		GameLogicTools.ShowMsgTips("MallSdk6")
	end
end

function MallPassProxy:Send20803(pass_type,reward_id)
    --print("MallPassProxy:Send20803", pass_type,reward_id)
    if pass_type then
    	local encoder = NetEncoder.New()
	    encoder:Encode("I2", pass_type)
	    encoder:Encode("I2", reward_id or 0)
		self:SendMessage(20803,encoder)
	end
end

function MallPassProxy:On20803(decoder)
	local result = decoder:Decode("I1")
	--print("MallPassProxy:On20803" , result)
    if result == 0 then
    	local pass_type = decoder:Decode("I2")
    	local reward_id = decoder:Decode("I2")
    	local add_goods_list = decoder:DecodeList("I4I4",true)
    	--print("  On20803     add_goods_list--------->",table.dump(add_goods_list))
    	local temp_list = {}
    	for k,info in ipairs(add_goods_list) do
    		table.insert(temp_list,{goodsid = info[1] , goodsnum = info[2]})
    	end
		local rewards_info = decoder:DecodeList("I2I2",true)
		if rewards_info then
			for k,v in ipairs(rewards_info) do
				self.data.pass_reward_info[pass_type][k] = v	
			end
		end
    	self:ToNotify(self.data, MallDef.Notify.UpdatePassRewardInfo , {reward_id = reward_id , pass_type = pass_type})
		self:CheckPassRed(pass_type)
		GameLogicTools.ShowGetItemView(temp_list, 1)
	end
end

function MallPassProxy:Send20804(pass_type,reward_id)
    --print("MallPassProxy:Send20804",pass_type,reward_id)
    if pass_type and reward_id then
    	local encoder = NetEncoder.New()
	    encoder:Encode("I2", pass_type)
	    encoder:Encode("I2", reward_id)
		self:SendMessage(20804,encoder)
	end
end

function MallPassProxy:On20804(decoder)
	local result = decoder:Decode("I1")
	--print("MallPassProxy:On20804",result)
    if result == 0 then
    	local pass_type = decoder:Decode("I2")
    	local num = decoder:Decode("I4")
    	local goodsid = MallDef.MallPassType2GoodsId[pass_type]
    	--print("On20804----->",pass_type,goodsid,num)
    	GameLogicTools.ShowGetItemView({{goodsid = goodsid ,goodsnum = num}}, 1)
	end
end

function MallPassProxy:On20805(decoder)
	if SystemConfig.isIGGPlatform() then
		local IGGSdkDef = require "Modules.IGGSdk.IGGSdkDef"
		local pass_type = decoder:Decode("I2")
		local sdk_key = IGGSdkDef.AFEventMallPass[pass_type]

		if sdk_key then
	        local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
	        IGGSdkProxy.Instance:Track(sdk_key)
		end
	end
end

function MallPassProxy:Send20806(pass_type)
    print("MallPassProxy:Send20806",pass_type)
    if pass_type then
    	local encoder = NetEncoder.New()
	    encoder:Encode("I2", pass_type)
		self:SendMessage(20806,encoder)
	end
end

function MallPassProxy:On20806(decoder)
	local result = decoder:Decode("I1")
	print("MallPassProxy:On20806--1",result)
	if result == 0 then
		local pass_type = decoder:Decode("I2")
		print("MallPassProxy:On20806--2",pass_type)
		self.data.pass_new_tips_info[pass_type] = 0
	end
end

-- pass_index 是 MallPassDef 表中的类型
function MallPassProxy:GetPassCfgByTypeAndID(pass_type,cfg_id)
	local ret
	local configs = self:GetPassConfigs(pass_type)
	if  configs and cfg_id then
		ret = configs[cfg_id]
	end
	return ret
end

function MallPassProxy:GetPassConfigs(pass_type)
	local configs
	if pass_type == MallDef.MallPassType.Task then
		configs = ConfigManager.GetConfig("data_pass_task")
	elseif pass_type == MallDef.MallPassType.Maze then
		configs = ConfigManager.GetConfig("data_pass_dragon")
	elseif pass_type == MallDef.MallPassType.GuildChaos then
		configs = ConfigManager.GetConfig("data_pass_chaos")
	end
	return configs
end

function MallPassProxy:GetPassBaseCfgById(cfg_id)
	local configs = ConfigManager.GetConfig("data_pass_base")
	if configs then
		return cfg_id and configs[cfg_id] or configs
	end
end

function MallPassProxy:GetPassRewardsInfo(pass_type)
	local rewards_info = self.data.pass_reward_info[pass_type]
	return rewards_info
end

function MallPassProxy:GetPassRewardStatusByTypeAndID(pass_type,cfg_id)
	local rewards_info = self.data.pass_reward_info[pass_type]
	local status = rewards_info and rewards_info[cfg_id] or {}
	return status
end

function MallPassProxy:GetPassProgressValue(pass_type)
	return self.data.pass_progress_info and self.data.pass_progress_info[pass_type] or 0
end

function MallPassProxy:GetPassLevel(pass_type)
	return self.data.pass_level_info and self.data.pass_level_info[pass_type] or 1
end

-- 0: 不提示， 1提示犒赏令升级， 2提示已满级
function MallPassProxy:GetPassTipsStatus(pass_type)
	return self.data.pass_new_tips_info and self.data.pass_new_tips_info[pass_type] or 0 
end

function MallPassProxy:CheckPassShowNewTips(pass_type)
	local status = self:GetPassTipsStatus(pass_type)
	return status ~= 0
end

function MallPassProxy:GetPassRewardsGoodsInfo(pass_type,reward_id,is_pay)
	local rewards_cfgs = self:GetPassConfigs(pass_type)
	local rewards_cfg = rewards_cfgs[reward_id]
	local pass_level = self:GetPassLevel(pass_type)
	local noraml_reward_key = is_pay and "rewards_pay" or "rewards_normal"
	if pass_level > 1 then
		noraml_reward_key = noraml_reward_key .. "_" .. pass_level
	end
	local goods_list_data = rewards_cfg[noraml_reward_key] 
	return goods_list_data
end

--RoleInfoModel.servertime
function MallPassProxy:CheckPassOpenBytype(pass_type)
	local cycle_time = self.data.pass_cycle_info and self.data.pass_cycle_info[pass_type]
	local is_open_server = self.data.pass_open_info and self.data.pass_open_info[pass_type] == 1
	--这里 用了 客户端自己写了逻辑开启判断 or 服务端传过来的开启判断，因为 客户端的判断用到了RoleInfoModel.servertime 这个时间 游戏开始初始化时可能拿不到
	-- 客户端和服务端双用 这样随着时间流逝而开启 后 服务端不会也不需要实时传开启过来
	return ((cycle_time and cycle_time > 0 and cycle_time <= RoleInfoModel.servertime) or is_open_server) and true or false
end

function MallPassProxy:GetPassStartTime(pass_type)
	return self.data.pass_cycle_info and self.data.pass_cycle_info[pass_type] or 0
end

function MallPassProxy:GetPassEndTime(pass_type)
	local start_time = self:GetPassStartTime(pass_type)
	local base_cfg = self:GetPassBaseCfgByType(pass_type)
	local end_time = start_time + (base_cfg.day * 24 * 3600)
	return end_time
end

function MallPassProxy:CheckPassUnlock(pass_type)
	return self.data.pass_unlock_info and self.data.pass_unlock_info[pass_type] == 2 or false
end

function MallPassProxy:GetPassBaseCfgByType(pass_type)
	local cfg_id = MallDef.MallPassType2PassBaseId[pass_type]
	local cfg = self:GetPassBaseCfgById(cfg_id)
	return cfg
end

--是否有赏金社解锁了
function MallPassProxy:CheckAllPassOpen()
	local is_unlock = false
	if self.data.pass_cycle_info and next(self.data.pass_cycle_info) then
		for k,time in pairs(self.data.pass_cycle_info) do
			if time and time > 0 and time <= RoleInfoModel.servertime then
				is_unlock = true
			end
		end
	end
	return is_unlock
end

function MallPassProxy:GetCurRewardId(pass_type)
	local cfg = self:GetPassConfigs(pass_type)
	local cur_progress = self:GetPassProgressValue(pass_type)
	for id,info in ipairs(cfg) do
		if cur_progress < info.exp then
			return (id - 1)
		end
		if id == #cfg then
			return id
		end
	end
end

function MallPassProxy:CheckPassProgressCanBuy(pass_type)
	--没解锁高级犒赏令
	if not self:CheckPassUnlock(pass_type) then
		return false
	end
	local pass_base_cfg = self:GetPassBaseCfgByType(pass_type)
	local end_time = self:GetPassEndTime(pass_type) --self.data.pass_cycle_info[pass_type] + (pass_base_cfg.day * 24 * 3600)
	local dis_day = self:GetDisDay(end_time)
	if dis_day > 4 then
		--结束时间 需小于4天
		return false
	end
	local pass_cfgs = self:GetPassConfigs(pass_type)
	local cur_pass_id = self:GetCurRewardId(pass_type)
	if cur_pass_id == #pass_cfgs then
		--需还有未达目标阶段
		return false 
	end

	return true
end

function MallPassProxy:GetDisDay(time)
    local pass_day = 0

    local cur_time = RoleInfoModel.servertime

    local offset_time = time - cur_time
    pass_day = math.floor(offset_time/(3600 * 24))

    return pass_day
end

--检查需要延迟，因为不能再 服务器时间初始化之前，需要用服务器时间判断是否开启(是否改成 服务器 给开启与否字段？)
function MallPassProxy:CheckPassRed(pass_type)
	local pass_type_2_red_def = {
		RedPointDef.Id.MallPassTask,
		RedPointDef.Id.MallPassMaze,
		RedPointDef.Id.MallPassGuildChaos
	}
	local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
	if pass_type then
		local rewards_info = self.data.pass_reward_info[pass_type]
		local have_red = false
		if self:CheckPassOpenBytype(pass_type) then
			for id,rewards_status in ipairs(rewards_info) do
				if rewards_status[1] == MallDef.CommonRewardState.CanGet or rewards_status[2] == MallDef.CommonRewardState.CanGet then
					have_red = true
				end
			end
		end
		RedPointProxy.Instance:SetNodeNum(pass_type_2_red_def[pass_type], have_red and 1 or 0)
	else
		for pass_type,rewards_info in ipairs(self.data.pass_reward_info) do
			if rewards_info and next(rewards_info) then
				local have_red = false
				if self:CheckPassOpenBytype(pass_type) then
					for id,rewards_status in ipairs(rewards_info) do
						if rewards_status[1] == MallDef.CommonRewardState.CanGet or rewards_status[2] == MallDef.CommonRewardState.CanGet then
							have_red = true
						end
					end
				end
				RedPointProxy.Instance:SetNodeNum(pass_type_2_red_def[pass_type], have_red and 1 or 0)
			end

		end
	end
end

--获取打开界面时跳转到指定位置的索引
function MallPassProxy:GetSkipPassIndex(pass_type)
	local rewards_info = self.data.pass_reward_info[pass_type]
	local target_index
	if rewards_info then
		local first_target_index
		local second_target_index
		local thrid_target_index
		for index,rewards_status in ipairs(rewards_info) do
			if rewards_status[1] == MallDef.CommonRewardState.CanGet or rewards_status[2] == MallDef.CommonRewardState.CanGet then
				first_target_index = index
				break
			end
			if rewards_status[1] == MallDef.CommonRewardState.HadGet and rewards_status[2] == MallDef.CommonRewardState.CantGet and not second_target_index then
				second_target_index = index
			end
			if rewards_status[1] == MallDef.CommonRewardState.CantGet and not thrid_target_index then
				thrid_target_index = index
			end
		end
		target_index = first_target_index or second_target_index or thrid_target_index or 1
	end
	return target_index
end

return MallPassProxy