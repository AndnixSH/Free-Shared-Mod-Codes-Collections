-- 有update 跟 fixupdate两个更新事件的类，继承此类即可
FrameUpdateFactor = FrameUpdateFactor or BaseClass()

local FrameUpdateMgr = require "First.Util.FrameUpdateMgr"


function FrameUpdateFactor:__init()
end

function FrameUpdateFactor:__delete()
	self:EndFrame()
end

-------------
-------------
--子类需要重写的方法
-------------
------------
function FrameUpdateFactor:FixedUpdate()
	
end


function FrameUpdateFactor:FrameUpdate()
	
end


--开启的接口
function FrameUpdateFactor:StartFrame()
	FrameUpdateMgr.Add(self)
end

--关闭的接口
function FrameUpdateFactor:EndFrame()
	FrameUpdateMgr.Remove(self)
end
