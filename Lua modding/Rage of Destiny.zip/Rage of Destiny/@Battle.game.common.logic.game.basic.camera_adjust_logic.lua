local logic = {timer = {},event = service.event()}

function logic:oncreate()
    local interval = self.static.interval or 1000
    local delay = self.static.delay or 0
    self.timer:add(delay, interval, nil, self.adjust)
    self.lastcenter = nil
    self.bstartadjust = false

    local battleside = { x = 0, y = 0, size = 0 }
    battleside.x, battleside.y = self.area:getbattlecenter()
    battleside.size = self.area:getbattldiagonal()
    self.battleside = battleside

end

function logic:adjust()

    if not self.bstartadjust then
        self.bstartadjust = true
        self:sendmessage(eventdef.camera_adjust_start)
    end

    local allactors = self.area:getallactors()
    if not allactors or #allactors == 0 then return end

    local minx, maxx, miny, maxy
    for _, actor in ipairs(allactors) do
        local pos = actor.body.position
        local x, y = pos.x, pos.y
        minx = minx and tsmath.min(minx, x) or x
        maxx = maxx and tsmath.max(maxx, x) or x
        miny = miny and tsmath.min(miny, y) or y
        maxy = maxy and tsmath.max(maxy, y) or y
    end
    local center = tsvector.new((minx + maxx) / 2, (miny + maxy) / 2)

    if center ~= self.lastcenter then
        self.lastcenter = center

        local distance = tsvector.distance(tsvector.new(minx, miny), tsvector.new(maxx, maxy))

        if GameConfig.DEBUGDRAW.camera then
            global.gamer.bmessage("AddDraw", 1, center.x, center.y - tsmath.floor((maxy - miny) / 2), 0, 1000, maxy - miny, maxx - minx)
            global.gamer.bmessage("AddDraw", 3, center.x, center.y, 0, 1000, 300, 300)
        end

        -- print(center, distance)
        self:sendmessage(eventdef.camera_adjust, 
            tsmath.clamp(center.x - self.battleside.x, self.static.clampx[1], self.static.clampx[2]),
            tsmath.clamp(center.y - self.battleside.y, self.static.clampy[1], self.static.clampy[2]),
            distance / self.battleside.size)
    end
end

function logic.event.sprite.public:suffer_add()
    self:sendmessage(eventdef.camera_lift, self.static.lift)
end

return logic
