local tinsert = table.insert
local tremove = global.array.removeby

local function calacc(distance, duration)
    local acc = tsmath.ndiv(distance * 2, tsmath.nmul(duration, duration))
    local spd = tsmath.nmul(duration, acc)
    return acc, spd
end

local function error_readonly_handler(t, k, v)
    error(string.format("attempt to update a read-only table [ key = %s, value = %s ]", k, v))
end

-- local _bodygetter = {
--     position = function(self)
--         self._pos = self._pos or tsvector.new(self._csbody.posx, self._csbody.posy)
--         return self._pos
--     end,

--     height = function(self)
--         return self._csbody.height
--     end
-- }

local zero_vector = tsvector.zero

local bodymt = {}
bodymt = {
    -- __index = function(t, k)
    --     local var = rawget(bodymt, k)
    --     if var ~= nil then return var end
    
    --     var = rawget(_bodygetter, k)
    --     if var ~= nil then return var(t) end
    -- end,

    setheader = function (self, header)
        if header and header ~= self.header and header ~= zero_vector  then
            self.header = header
            self._owner:sendmessage("SyncHeader", header.x, header.y)
            -- SpriteInterface.SetHeader(self._csspriteid, header.x, header.y)
        end
    end,

    setparent = function (self, parent)
        self.parent = parent
    end,

    setvelocity = function(self, velocity, header)
        if velocity ~= self.velocity then
            self.velocity = velocity
            if not header and velocity ~= zero_vector then
                header = velocity.normalized
            end
            if header then
                self:setheader(header)
            end
            -- SpriteInterface.SetVelocity(self._csspriteid, self.velocity.x, self.velocity.y)
        end
    end,

    setupspeed = function (self, speed)
        if self.upspeed ~= speed then
            self.upspeed = speed
            -- SpriteInterface.SetUpSpeed(self._csspriteid, speed)
        end
    end,

    moveup = function(self, dis, duration, land)
        -- SpriteInterface.MoveUp(self._csspriteid, dis, duration, land or false)
        local acc, vspd = calacc(dis, duration)
        self.upacc = -acc
        self.upspeed = vspd
    end,

    moveforward = function(self, header, dis, duration)
        -- print('move forward', header, dis, duration)
        local speed = tsmath.ndiv(dis, duration)
        self.velocity = tsmath.vmul(header, speed)
        -- SpriteInterface.MoveForward(self._csspriteid, header.x, header.y, dis, duration)
    end,

    accverticle = function (self, distance, duration)
        local acc, vspd = calacc(distance, duration)
        if distance > 0 then -- 上
            self.upacc = -acc
            self.upspeed = vspd
        else                 -- 下
            self.upacc = acc
            self.upspeed = 0
        end
        -- print('accverticle', distance, duration, acc, vspd)
        -- SpriteInterface.AccVerticle(self._csspriteid, distance, duration)
    end,

    setvmotion = function (self, upacc, upspeed)
        self.upacc = upacc
        self.upspeed = upspeed
    end,

    setposition = function(self, pos)
        if pos ~= self.position then
            if global.service.area:isvalidpos(pos, self.radius) then
                self.position = pos
                self._owner:sendmessage("SyncPosition", self.position.x, self.position.y)
            else
                global.service.sprite:onhitblock(self._owner.uid)
            end
            -- return SpriteInterface.SetPosition(self._csspriteid, pos.x, pos.y)
        end
    end,

    setpushmask = function(self, pushmask)
        self.pushmask = pushmask
        -- SpriteInterface.SetPushMask(self._csspriteid, pushmask)
    end,

    setdebuginfo = function(self, debuginfo)
        -- SpriteInterface.SetDebugInfo(self._csspriteid, debuginfo)
    end,

    setweight = function (self, weight)
        self.weight = weight
        -- SpriteInterface.SetWeight(self._csspriteid, weight)
    end,

    setheight = function (self, height)
        if height ~= self.height then
            self.height = height
            if self.height <= 0 then
                self.height = 0
                self.upspeed = 0
                self.upacc = 0
            end
            self._owner:sendmessage("SyncHeight", height)
            -- SpriteInterface.SetHeight(self._csspriteid, height)
        end
    end,

    clearpositon = function(self)
        self._pos = nil
    end,

    update = function (self, tick)
        self:setposition(self.position + tsmath.vmul(self.velocity, tick))
        self.upspeed = self.upspeed + tsmath.nmul(self.upacc, tick)
        self:setheight(self.height + tsmath.nmul(self.upspeed, tick))
    end
}

local sprite_server = { _sprite_list = {} }

function sprite_server:init()

end

function sprite_server:setcallback(game)
    -- GameInterface.SetSpriteBlockCallBack(sprite_server._onspriteblock)
    -- GameInterface.SetSpriteHitCallBack(sprite_server._onspritehit)
    global.service.obj_factory.destroylistener:add(sprite_server._onremovesprite)
end

function sprite_server:createsprite(spritetype, pushmask, typeid, position, header, height, radius, weight, top, prefab_id, static, prop)
    height = height or 0
    radius = radius or 500
    weight = weight or 0
    top = top or 0
    global.gamer.bmessage("CreateSprite", spritetype, pushmask, position.x, position.y, header.x, header.y, height, radius, weight)
    local body = { spritetype = spritetype, pushmask = pushmask, position = position, header = header, height = height, radius = radius, weight = weight, top = top, prefab_id = prefab_id, velocity = tsvector(0, 0), upspeed = 0, upacc = 0, parent = nil }
    local spriteobj = global.service.obj_factory:createobj(typeid, prop, "sprite")
    body._owner = spriteobj
    if static then
        spriteobj.static = setmetatable({}, { __index = static, __newindex = error_readonly_handler, __metatable = false })
    end
    -- spriteobj.body = setmetatable(body, bodymt)
    spriteobj.body = setmetatable(body, {__index = bodymt})
    return spriteobj
end

function sprite_server:addsprite(csspriteid, spritetype)
    global.gamer.bmessage("AddSprite", csspriteid, spritetype)
end

function sprite_server:pause_sprite(spriteobj)
    spriteobj:pause()
    global.gamer.bmessage("PauseSprite", spriteobj.uid)
end

function sprite_server:resume_sprite(spriteobj)
    spriteobj:resume()
    global.gamer.bmessage("ResumeSprite", spriteobj.uid)
end

function sprite_server._onremovesprite(obj)
    if obj.body then
        global.gamer.bmessage("RemoveSprite", obj.uid)
    end
end

function sprite_server._onspriteblock(csspriteid)
    global.service.sprite:onhitblock(csspriteid)
end

function sprite_server._onspritehit(fromid, toid)
    global.service.sprite:onhitsprite(fromid, toid)
end


function sprite_server:load(tb, context, source)
    tinsert(self._sprite_list, { tb = tb, context = context, uid = source.uid })
    return tb
end

function sprite_server:unload(tb, context, source)
    tremove(self._sprite_list, function(value)
        return value.tb == tb and value.context == context and value.uid == source.uid
    end)
end

function sprite_server:onhitsprite(fromid, toid)

    local _pool = global.service.pool
    local fromobj = _pool:get_obj(fromid)
    local toobj = _pool:get_obj(toid)

    if not fromobj or not toobj then return end

    for _, value in ipairs(self._sprite_list) do

        local tb = value.context.sprite

        if tb.onhitsprite then

            if value.uid == fromid then
                tb.onhitsprite(value.context, toobj)
            end

            if value.uid == toid then
                tb.onhitsprite(value.context, fromobj)
            end

        end
    end
end

function sprite_server:onhitblock(uid)
    -- local _pool = global.service.pool
    -- local obj = _pool:get_obj(uid)

    for _, value in ipairs(self._sprite_list) do

        local tb = value.context.sprite

        if value.uid == uid and tb.onhitblock then
            tb.onhitblock(value.context)
        end
    end

end

function sprite_server:dispose()
    self._sprite_list = {}
end

return sprite_server