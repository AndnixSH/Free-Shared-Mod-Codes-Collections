local init = {
    --_G
    libpaths = {
        "Battle.game.lib.game_define",      -- 全局定义
        "Battle.game.lib.event_define",     -- 事件定义
        "Battle.game.lib.call_define",      -- call定义
        "Battle.game.lib.game_functions",   -- 全局方法
        "Battle.game.lib.gamelog",          -- 游戏日志
        "Battle.game.lib.trigger_v2",
        "Battle.game.lib.range_lib",
    },
    -- global.service
    servicelist = {
        {name = "readonly", path = "Battle.game.service.readonly"},
        {name = "config",   path = "Battle.game.service.config",  args = ConfigManager.GetConfig },
        {name = "skill",    path = "Battle.game.service.skill"},
        {name = "buff",     path = "Battle.game.service.buff"},
        {name = "sprite",   path = "Battle.game.service.sprite"},
        {name = "area",     path = "Battle.game.service.area"},
    },
    -- logic internal service
    loaderlist = {
        {name = "skill",  service = "skill"},
        {name = "buff",   service = "buff"},
        {name = "sprite", service = "sprite"},
        {name = "area",   service = "area", isassign = true},
    }
}

return init