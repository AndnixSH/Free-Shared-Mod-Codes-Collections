ConfigManager.InitConfig("data_newbie", {
	--强引导 npcSp:dialog npc , effectType:特效类型 effect_offset:特效偏移量  dialog_offset:引导框偏移量  roleid:英雄id spine_parama:spine动画参数  idle01
	forceguide = {
		--学习战斗基础引导（包括引导大招） 10001
		[1001] = {npcSp = 1, content = "Newbie_guide_info_202", bnewObj = false, effectType = 1,  parama = {mainlineid = 1}, effect_offset = {0,13}, dialog_offset = {0,115}, view = UIWidgetNameDef.CampaignView},  --点击 挑战首领 1-1
		[1002] = {npcSp = 3, content = "Newbie_guide_info_203", bnewObj = false, effectType = 1,  parama = {roleid = 1103}, effect_offset = {0,13}, dialog_offset = {0,-115}, view = UIWidgetNameDef.BattleNetSelectView},  --上阵1103鲍德维克
		[1021] = {npcSp = 3, content = "Newbie_guide_info_204", bnewObj = false, effectType = 1,  parama = {roleid = 3103}, effect_offset = {0,13}, dialog_offset = {0,-115}, view = UIWidgetNameDef.BattleNetSelectView},  --上阵3103兰黛
		[1003] = {npcSp = 1, content = "Newbie_guide_info_205", bnewObj = false, effectType = 1,  parama = {mainlineid = 1}, effect_offset = {0,13}, dialog_offset = {0,100},view = UIWidgetNameDef.BattleNetSelectView},  --开始战斗
        
        --获得杰西卡引导上阵，开启自动战斗
		[1015] = {npcSp = 1, content = "Newbie_guide_info_301", bnewObj = false, effectType = 1, parama = {mainlineid = 2}, effect_offset = {0,13}, dialog_offset = {0,115}, view = UIWidgetNameDef.CampaignView},  --点击 挑战首领 1-2
		[1016] = {npcSp = 3, content = "Newbie_guide_info_302", bnewObj = false, effectType = 1, parama = {roleid = 1303}, effect_offset = {0,13}, dialog_offset = {0,-115}, view = UIWidgetNameDef.BattleNetSelectView},  --上阵英雄 杰西卡
		[1017] = {npcSp = 2, content = "Newbie_guide_info_303", bnewObj = false, effectType = 2, parama = {roleid = 1303}, effect_offset = {0,-20}, dialog_offset = {115,0},view = UIWidgetNameDef.BattleNetSelectView},  --引导英雄 杰西卡 站位
		[1022] = {npcSp = 1, content = "Newbie_guide_info_205", bnewObj = false, effectType = 1, parama = {mainlineid = 2}, effect_offset = {0,13}, dialog_offset = {0,100},view = UIWidgetNameDef.BattleNetSelectView},  --开始战斗
		[1045] = {npcSp = 2, content = "Newbie_guide_info_304", bnewObj = false, effectType = 1, parama = {mainlineid = 2}, effect_offset = {0,13}, dialog_offset = {115,0},view = UIWidgetNameDef.BattleView}, --引导自动战斗


		--引导法林英雄升级
		[1006] = {npcSp = 1, content = "Newbie_guide_info_501", bnewObj = false, effectType = 1, parama = {mainlineid = 4}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.CampaignView}, --英雄图标
		[1007] = {npcSp = 1, content = "Newbie_guide_info_502", bnewObj = false, effectType = 1, parama = {roleid = 1303}, effect_offset = {0,13}, dialog_offset = {0,115}, view = UIWidgetNameDef.HeroListView}, --选中英雄列表 矮人射手英雄图标
		[1008] = {npcSp = 1, content = "Newbie_guide_info_503", bnewObj = false, effectType = 1, parama = {mainlineid = 4}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.HeroNewView}, --提升等级
		[1018] = {npcSp = 1, content = "Newbie_guide_info_504", bnewObj = false, effectType = 1, parama = {roleid = 3203}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.HeroNewView},  --英雄展示界面 装备tab
        [1009] = {npcSp = 4, content = "Newbie_guide_info_505", bnewObj = false, effectType = 1, parama = {mainlineid = 4}, effect_offset = {0,13}, dialog_offset = {-135,0}, view = UIWidgetNameDef.HeroNewView}, --一键穿戴
		[1023] = {npcSp = 2, content = "Newbie_guide_info_401", bnewObj = false, effectType = 1, parama = {mainlineid = 4}, effect_offset = {3,13}, dialog_offset = {135,0}, view = UIWidgetNameDef.FullScreenView}, --全屏界面关闭按钮
		[1010] = {npcSp = 2, content = "Newbie_guide_info_401", bnewObj = false, effectType = 1, parama = {mainlineid = 4}, effect_offset = {23,18}, dialog_offset = {135,0},view = UIWidgetNameDef.FullScreenView}, --全屏界面关闭按钮

		--引导进入领地进行抽卡
		[1011] = {npcSp = 1, content = "Newbie_guide_info_1101", bnewObj = false, effectType = 1, parama = {mainlineid = 12}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.CampaignView}, -- 主线id 1-13 引导领地按钮	
		[1012] = {npcSp = 1, content = "Newbie_guide_info_1102", bnewObj = false, effectType = 1, parama = {mainlineid = 12}, effect_offset = {-50,0}, dialog_offset = {-50,110}, view = UIWidgetNameDef.TerritoryView}, --领地 传送门
		[1013] = {npcSp = 1, content = "Newbie_guide_info_1103", bnewObj = false, effectType = 1, parama = {mainlineid = 12}, effect_offset = {4,12}, dialog_offset = {0,90}, view = UIWidgetNameDef.CardPortalView}, --抽卡 单抽
		[1059] = {npcSp = 0, content = "", bnewObj = false, effectType = 1, parama = {mainlineid = 1}, effect_offset = {0,20}, dialog_offset = {0,0}, view = UIWidgetNameDef.FullScreenView}, --全屏界面关闭按钮
		
		
		--引导新英雄法林上阵
		[1025] = {npcSp = 1, content = "Newbie_guide_info_601", bnewObj = false, effectType = 1, parama = {mainlineid = 4}, effect_offset = {0,4}, dialog_offset = {0,115}, view = UIWidgetNameDef.CampaignView},  --点击 挑战首领 1-4
		[1026] = {npcSp = 3, content = "Newbie_guide_info_602", bnewObj = false, effectType = 1, parama = {roleid = 3203}, effect_offset = {0,4}, dialog_offset = {0,-115}, view = UIWidgetNameDef.BattleNetSelectView},  --上阵英雄 法林
		[1027] = {npcSp = 0, content = "", bnewObj = false, effectType = 1, parama = {mainlineid = 4}, effect_offset = {0,4}, dialog_offset = {0,0}, view = UIWidgetNameDef.BattleNetSelectView},  --开始战斗
		[1046] = {npcSp = 1, content = "Newbie_guide_info_603", bnewObj = false, effectType = 1, parama = {mainlineid = 4}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.BattleView}, --引导点击二倍速
		
        --引导姿维雅上阵
		[1047] = {npcSp = 1, content = "Newbie_guide_info_901", bnewObj = false, effectType = 1, parama = {mainlineid = 7}, effect_offset = {0,4}, dialog_offset = {0,115}, view = UIWidgetNameDef.CampaignView},  --点击 挑战首领 1-7
		[1048] = {npcSp = 0, content = "Newbie_guide_info_902", bnewObj = false, effectType = 1, parama = {roleid = 1306}, effect_offset = {0,4}, dialog_offset = {-630,-350}, view = UIWidgetNameDef.BattleNetSelectView},  --上阵英雄矮人射手
		[1049] = {npcSp = 0, content = "", bnewObj = false, effectType = 1,  parama = {mainlineid = 7}, effect_offset = {0,4}, dialog_offset = {-180,-200}, view = UIWidgetNameDef.BattleNetSelectView},  --开始战斗

		[1050] = {npcSp = 0, content = "Newbie_guide_info_1301", bnewObj = false, effectType = 1, parama = {mainlineid = 17}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.CampaignView}, -- 远征图标 2-5
		[1051] = {npcSp = 0, content = "Newbie_guide_info_1302", bnewObj = false, effectType = 1, parama = {mainlineid = 17}, effect_offset = {120,150}, dialog_offset = {120,220}, view = UIWidgetNameDef.FieldView}, --引导点击巨龙巢穴

		[1052] = {npcSp = 2, content = "Newbie_guide_info_1501", bnewObj = false, effectType = 1, parama = {mainlineid = 14}, effect_offset = {0,4}, dialog_offset = {115,0}, view = UIWidgetNameDef.MainView},  --3-1 点击活动按钮
		[1053] = {npcSp = 1, content = "Newbie_guide_info_1502", bnewObj = false, effectType = 1, parama = {mainlineid = 14}, effect_offset = {0,4}, dialog_offset = {0,90}, view = UIWidgetNameDef.StageClearChargeView},  --3-1 活动 章节第1个奖励
		[1054] = {npcSp = 1, content = "Newbie_guide_info_1502", bnewObj = false, effectType = 1, parama = {mainlineid = 14}, effect_offset = {0,4}, dialog_offset = {0,90}, view = UIWidgetNameDef.StageClearChargeView},  --3-1 活动 章节第2个奖励
		[1055] = {npcSp = 0, content = "", bnewObj = false, effectType = 1, parama = {mainlineid = 14}, effect_offset = {0,15}, dialog_offset = {0,0}, view = UIWidgetNameDef.FullScreenView}, --全屏界面关闭按钮	
		
		--领地引导抽卡
		[1056] = {npcSp = 1, content = "Newbie_guide_info_1601", bnewObj = false, effectType = 1, parama = {mainlineid = 14}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.CampaignView}, -- 主线id 1-10 引导领地按钮		
		[1057] = {npcSp = 1, content = "Newbie_guide_info_1602", bnewObj = false, effectType = 1, parama = {mainlineid = 14}, effect_offset = {-50,0}, dialog_offset = {-50,110}, view = UIWidgetNameDef.TerritoryView}, --领地 传送门
		[1058] = {npcSp = 1, content = "Newbie_guide_info_1603", bnewObj = false, effectType = 1, parama = {mainlineid = 14}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.CardPortalView}, --抽卡 10抽
		[1061] = {npcSp = 0, content = "", bnewObj = false, effectType = 1, parama = {mainlineid = 14}, effect_offset = {0,13}, dialog_offset = {0,0}, view = UIWidgetNameDef.FullScreenView}, --全屏界面关闭按钮
		
		[1060] = {npcSp = 1, content = "Newbie_guide_info_206", bnewObj = true, effectType = 1,  parama = {mainlineid = 1}, effect_offset = {0,13}, dialog_offset = {0,160}, view = UIWidgetNameDef.BattleView},  --大招

        [1062] = {npcSp = 2, content = "Newbie_guide_info_801", effectType = 1, parama = {mainlineid = 7}, effect_offset = {0,13}, dialog_offset = {115,0}, view = UIWidgetNameDef.BattleView}, --1-5自动推图


        [1063] = {npcSp = 1, content = "Newbie_guide_info_501", bnewObj = false, effectType = 1, parama = {mainlineid = 5}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.CampaignView}, --英雄图标
		[1064] = {npcSp = 1, content = "Newbie_guide_info_502", bnewObj = false, effectType = 1, parama = {roleid = 1303}, effect_offset = {0,13}, dialog_offset = {0,115}, view = UIWidgetNameDef.HeroListView}, --选中英雄列表 杰西卡英雄图标
		[1065] = {npcSp = 1, content = "Newbie_guide_info_504", bnewObj = false, effectType = 1, parama = {roleid = 1303}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.HeroNewView},  --英雄展示界面 装备tab
        [1066] = {npcSp = 4, content = "Newbie_guide_info_505", bnewObj = false, effectType = 1, parama = {mainlineid = 5}, effect_offset = {0,13}, dialog_offset = {-135,0}, view = UIWidgetNameDef.HeroNewView}, --一键穿戴
		[1067] = {npcSp = 2, content = "Newbie_guide_info_401", bnewObj = false, effectType = 1, parama = {mainlineid = 5}, effect_offset = {3,13}, dialog_offset = {135,0}, view = UIWidgetNameDef.FullScreenView}, --全屏界面关闭按钮
		[1068] = {npcSp = 2, content = "Newbie_guide_info_401", bnewObj = false, effectType = 1, parama = {mainlineid = 5}, effect_offset = {23,18}, dialog_offset = {135,0}, view = UIWidgetNameDef.FullScreenView}, --全屏界面关闭按钮

        [1090] = {npcSp = 0, content = "Newbie_guide_info_1001", effectType = 1, spine_parama = {position = {-106,-30,0}, scale = 0.14, rotation = 0, active = "idle02"}, parama = {mainlineid = 12}, effect_offset = {0,13}, dialog_offset = {0,115}, view = UIWidgetNameDef.CampaignView},  --点击 前往下一章节

        --引导点击圣堂
        [1101] = {npcSp = 1, content = "Newbie_guide_info_1101_9", bnewObj = false, effectType = 1, parama = {mainlineid = 14}, effect_offset = {-50,0}, dialog_offset = {-700,-215}, view = UIWidgetNameDef.TerritoryView},
        --引导点击指定英雄-罗珊1
        [1102] = {npcSp = 1, content = "Newbie_guide_info_1102_9", bnewObj = false, effectType = 1, parama = {roleid = 1306}, effect_offset = {0,4}, dialog_offset = {-530,-265}, view = UIWidgetNameDef.Templeview},
        --引导玩家指定升阶材料，罗珊2
        [1103] = {npcSp = 1, content = "Newbie_guide_info_1103_9", bnewObj = false, effectType = 1, parama = {roleid = 1306}, effect_offset = {0,4}, dialog_offset = {-530,-265}, view = UIWidgetNameDef.Templeview}, 
        --引导玩家指定升阶材料，罗珊3
        [1104] = {npcSp = 1, content = "Newbie_guide_info_1104_1", bnewObj = false, effectType = 1, parama = {roleid = 1201}, effect_offset = {0,4}, dialog_offset = {-560,-265}, view = UIWidgetNameDef.Templeview},
        --点击升阶按钮
        [1105] = {npcSp = 0, content = "Newbie_guide_info_1603", bnewObj = false, effectType = 1, parama = {mainlineid = 14}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.Templeview}, 
        --引导退出按钮返回领地界面
        [1106] = {npcSp = 0, content = "Newbie_guide_info_401", bnewObj = false, effectType = 1, parama = {mainlineid = 14}, effect_offset = {3,13}, dialog_offset = {135,0}, view = UIWidgetNameDef.FullScreenView}, --全屏界面关闭按钮

        --10029 引导玩家上阵碧伦丝
        --引导点击挑战首领
        [1107] = {npcSp = 0, content = "Newbie_guide_info_1107", bnewObj = false, effectType = 1, parama = {mainlineid = 13}, effect_offset = {0,4}, dialog_offset = {-650,115},  view = UIWidgetNameDef.CampaignView},  
        --引导点击兰黛，下阵兰黛
        [1108] = {npcSp = 0, content = "Newbie_guide_info_1108", bnewObj = false, effectType = 1, parama = {roleid = 3203}, effect_offset = {0,-20}, dialog_offset = {115,0}, view = UIWidgetNameDef.BattleNetSelectView}, 
        --引导点击上阵碧伦丝
		[1109] = {npcSp = 0, content = "Newbie_guide_info_1109", bnewObj = false, effectType = 1, parama = {roleids = {1202,1204,3303,4202}}, effect_offset = {0,13}, dialog_offset = {-530,-280}, view = UIWidgetNameDef.BattleNetSelectView}, 
		--引导点击开始战斗
		[1110] = {npcSp = 0, content = "Newbie_guide_info_1110", bnewObj = false, effectType = 1, parama = {mainlineid = 13}, effect_offset = {0,13}, dialog_offset = {0,100}, view = UIWidgetNameDef.BattleNetSelectView}, 

		        --10030 引导玩家上阵卡马尔
        --引导点击挑战首领
        [1111] = {npcSp = 1, content = "Newbie_guide_info_1111", bnewObj = false, effectType = 1, parama = {mainlineid = 14}, effect_offset = {0,4}, dialog_offset = {-650,115}, view = UIWidgetNameDef.CampaignView},  
        --引导点击鲍德维克
        [1112] = {npcSp = 2, content = "Newbie_guide_info_1112", bnewObj = false, effectType = 1, parama = {roleid = 1103}, effect_offset = {0,-20}, dialog_offset = {115,-115}, view = UIWidgetNameDef.BattleNetSelectView}, 
        --引导点击上阵卡马尔
		[1113] = {npcSp = 1, content = "Newbie_guide_info_1113", bnewObj = false, effectType = 1, parama = {roleid = 1102}, effect_offset = {0,13}, dialog_offset = {-530,-280}, view = UIWidgetNameDef.BattleNetSelectView}, 
		--引导点击开始战斗
		[1114] = {npcSp = 0, content = "Newbie_guide_info_205", bnewObj = false, effectType = 1, parama = {mainlineid = 2}, effect_offset = {0,13}, dialog_offset = {0,100}, view = UIWidgetNameDef.BattleNetSelectView}, 

        
        --	单抽返回战役引导
        [1115] = {npcSp = 0, content = "Newbie_guide_info_1201", effectType = 1, parama = {mainlineid = 13}, effect_offset = {30,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.TerritoryView}, --1-10从抽卡回来领地点击战役

        	    --升阶结束后引导点击战役界面
	    [1116] = {npcSp = 0, content = "Newbie_guide_info_1201", effectType = 1, parama = {mainlineid = 14}, effect_offset = {30,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.TerritoryView}, 


	},



	--弱引导
	weakguide = {
		[2001] = {npcSp = 0, content = "Newbie_tips_info_1010", effectType = 1, parama = {mainlineid = 3}, effect_offset = {0,13}, dialog_offset = {0,115}, view = UIWidgetNameDef.CampaignView},  --点击 挑战首领 1-3
		[2002] = {npcSp = 0, content = "Newbie_tips_info_1011", effectType = 1,  parama = {}, effect_offset = {0,13}, dialog_offset = {25,150}, view = UIWidgetNameDef.BossInfoView}, --挑战boss首领弹窗
		[2003] = {npcSp = 0, content = "Newbie_guide_info_1001", effectType = 1,  parama = {mainlineid = 12}, effect_offset = {0,13}, dialog_offset = {0,115}, view = UIWidgetNameDef.CampaignView},  --点击 前往下一章节
         --弱引导 引导1-5挑战首领
		[2004] = {npcSp = 0, content = "Newbie_guide_info_701", effectType = 1, parama = {mainlineid = 5}, effect_offset = {0,13}, dialog_offset = {0,115}, view = UIWidgetNameDef.CampaignView},  --点击 挑战首领 1-5
		-- [2005] = {npcSp = 0, content = "", effectType = 1, parama = {mainlineid = 5}, effect_offset = {0,13}, dialog_offset = {445,-250}, view = UIWidgetNameDef.BossInfoView}, --挑战boss首领弹窗
		[2005] = {npcSp = 0, content = "Newbie_guide_info_205", bnewObj = false, effectType = 1, parama = {}, effect_offset = {0,13}, dialog_offset = {0,100}, view = UIWidgetNameDef.BattleNetSelectView},



		[2006] = {npcSp = 0, content = "Newbie_guide_info_801", effectType = 1, parama = {mainlineid = 7}, effect_offset = {0,13}, dialog_offset = {115,0}, view = UIWidgetNameDef.BattleView}, --1-7自动推图

		[2007] = {npcSp = 0, content = "Newbie_guide_info_1201", effectType = 1, parama = {mainlineid = 13}, effect_offset = {30,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.TerritoryView}, --1-10从抽卡回来领地点击战役
		[2008] = {npcSp = 0, content = "Newbie_guide_info_1202", effectType = 1, parama = {mainlineid = 14}, effect_offset = {0,13}, dialog_offset = {0,115}, view = UIWidgetNameDef.CampaignView},  --点击 挑战首领 1-10

		[2009] = {npcSp = 0, content = "Newbie_guide_info_1401", effectType = 1, parama = {mainlineid = 20}, effect_offset = {0,13}, dialog_offset = {-90,0}, view = UIWidgetNameDef.BattleNetSelectView},  --2-8主线英雄上阵界面阵营克制弱引导
	
		--引导普通种族塔
		[2010] = {npcSp = 0, content = "Newbie_guide_info_2101", bnewObj = false, effectType = 1, parama = {mainlineid = 29}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.CampaignView}, -- 远征图标 3-5
		[2011] = {npcSp = 0, content = "Newbie_guide_info_1702", bnewObj = false, effectType = 1, parama = {mainlineid = 29}, effect_offset = {57,13}, dialog_offset = {60,115}, view = UIWidgetNameDef.FieldView}, -- 赎罪之塔图标
		[2012] = {npcSp = 0, content = "Newbie_guide_info_1703", bnewObj = false, effectType = 1, parama = {mainlineid = 29}, effect_offset = {0,13}, dialog_offset = {0,95}, view = UIWidgetNameDef.TowerEntranceView}, -- 赎罪之塔普通塔
		[2013] = {npcSp = 0, content = "Newbie_guide_info_1704", bnewObj = false, effectType = 1, parama = {mainlineid = 29}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.TowerChallengeView}, -- 赎罪之塔普通塔挑战按钮
	
		
        --引导公会
		[2014] = {npcSp = 0, content = "Newbie_guide_info_1901", bnewObj = false, effectType = 1, parama = {mainlineid = 33}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.CampaignView}, --通关2-20引导点击领地 
		[2015] = {npcSp = 0, content = "Newbie_guide_info_1902", bnewObj = false, effectType = 1, parama = {mainlineid = 33}, effect_offset = {0,13}, dialog_offset = {0,115}, view = UIWidgetNameDef.TerritoryView}, --引导点击公会图标
	
		--引导命运古树
		[2016] = {npcSp = 0, content = "Newbie_guide_info_2001", bnewObj = false, effectType = 1, parama = {mainlineid = 37}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.CampaignView}, --通关2-20引导点击领地 
		[2017] = {npcSp = 0, content = "Newbie_guide_info_2002", bnewObj = false, effectType = 1, parama = {mainlineid = 37}, effect_offset = {0,13}, dialog_offset = {0,115}, view = UIWidgetNameDef.TerritoryView}, --引导点击羁绊图标	

		--引导普通竞技场
		[2018] = {npcSp = 0, content = "Newbie_guide_info_2101", bnewObj = false, effectType = 1, parama = {mainlineid = 41}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.CampaignView}, -- 远征图标 3-5
		[2019] = {npcSp = 0, content = "Newbie_guide_info_2102", bnewObj = false, effectType = 1, parama = {mainlineid = 41}, effect_offset = {-13,13}, dialog_offset = {-15,115}, view = UIWidgetNameDef.FieldView}, -- 远征界面竞技场图标
		[2020] = {npcSp = 0, content = "Newbie_guide_info_2103", bnewObj = false, effectType = 1, parama = {mainlineid = 41}, effect_offset = {0,13}, dialog_offset = {0,95}, view = UIWidgetNameDef.ArenaEntranceView}, -- 普通竞技场
		[2021] = {npcSp = 0, content = "Newbie_guide_info_2104", bnewObj = false, effectType = 1, parama = {mainlineid = 41}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.ArenaView}, -- 普通竞技场 挑战按钮
	
		
        -- 贸易航线引导
		[2022] = {npcSp = 0, content = "Newbie_guide_info_2201", bnewObj = false, effectType = 1, parama = {mainlineid = 53}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.CampaignView}, -- 远征图标 3-5
		[2023] = {npcSp = 0, content = "Newbie_guide_info_2202", bnewObj = false, effectType = 1, parama = {mainlineid = 53}, effect_offset = {0,13}, dialog_offset = {0,115}, view = UIWidgetNameDef.FieldView}, -- 远征界面贸易航线图标
		[2024] = {npcSp = 0, content = "Newbie_guide_info_2203", bnewObj = false, effectType = 1, parama = {mainlineid = 53}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.SupplyDepotView}, -- 远征界面贸易航线第一个
		[2025] = {npcSp = 0, content = "Newbie_guide_info_2204", bnewObj = false, effectType = 1, parama = {mainlineid = 53}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.SupplyDepotDispatchView}, -- 贸易航线 点加号 派遣
		[2026] = {npcSp = 0, content = "Newbie_guide_info_2205", bnewObj = false, effectType = 1, parama = {mainlineid = 53}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.SupplyDepotDispatchView}, -- 贸易航线 一键派遣
		[2027] = {npcSp = 0, content = "Newbie_guide_info_2206", bnewObj = false, effectType = 1, parama = {mainlineid = 53}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.SupplyDepotDispatchView}, -- 贸易航线 点击派遣按钮
		[2040] = {npcSp = 0, content = "Newbie_guide_info_2207", bnewObj = false, effectType = 1, parama = {mainlineid = 53}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.SupplyDepotView}, -- 贸易航线 点击领取奖励
		[2044] = {npcSp = 0, content = "Newbie_guide_info_2207", bnewObj = false, effectType = 1, parama = {mainlineid = 53}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.SupplyDepotView}, -- 贸易航线 点击领取奖励
		[2045] = {npcSp = 0, content = "Newbie_guide_info_2207", bnewObj = false, effectType = 1, parama = {mainlineid = 53}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.SupplyDepotView}, -- 贸易航线 点击领取奖励
		--贸易航线最后一步id 是 2040


		[2028] = {npcSp = 0, content = "Newbie_guide_info_2301", bnewObj = false, effectType = 1, parama = {mainlineid = 157}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.CampaignView}, -- 远征图标 3-5
		[2029] = {npcSp = 0, content = "Newbie_guide_info_2302", bnewObj = false, effectType = 1, parama = {mainlineid = 157}, effect_offset = {190,13}, dialog_offset = {190,95}, view = UIWidgetNameDef.FieldView}, -- 远征界面剧情副本图标
		[2030] = {npcSp = 0, content = "Newbie_guide_info_2303", bnewObj = false, effectType = 1, parama = {mainlineid = 157}, effect_offset = {0,13}, dialog_offset = {0,115}, view = UIWidgetNameDef.StoryLineEntranceView}, -- 剧情副本 开始探索图标
        
		--引导高阶竞技场
		[2031] = {npcSp = 0, content = "Newbie_guide_info_2401", bnewObj = false, effectType = 1, parama = {mainlineid = 293}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.CampaignView}, -- 远征图标 3-5
		[2032] = {npcSp = 0, content = "Newbie_guide_info_2402", bnewObj = false, effectType = 1, parama = {mainlineid = 293}, effect_offset = {-13,13}, dialog_offset = {-15,115}, view = UIWidgetNameDef.FieldView}, -- 远征界面竞技场图标
		[2033] = {npcSp = 0, content = "Newbie_guide_info_2403", bnewObj = false, effectType = 1, parama = {mainlineid = 293}, effect_offset = {0,13}, dialog_offset = {0,95}, view = UIWidgetNameDef.ArenaEntranceView}, -- 高阶竞技场
		[2034] = {npcSp = 0, content = "Newbie_guide_info_2404", bnewObj = false, effectType = 1, parama = {mainlineid = 293}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.ProArenaView}, -- 高阶竞技场 挑战按钮

		--引导高级种族塔
		[2035] = {npcSp = 0, content = "Newbie_guide_info_2501", bnewObj = false, effectType = 1, parama = {mainlineid = 513}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.CampaignView}, -- 远征图标 3-5 开启种族塔
		[2036] = {npcSp = 0, content = "Newbie_guide_info_2502", bnewObj = false, effectType = 1, parama = {mainlineid = 513}, effect_offset = {57,13}, dialog_offset = {60,115}, view = UIWidgetNameDef.FieldView}, -- 赎罪之塔图标

		[2037] = {npcSp = 0, content = "Newbie_guide_info_2037", bnewObj = false, effectType = 1, parama = {mainlineid = 3}, effect_offset = {0,13}, dialog_offset = {0,115}, view = UIWidgetNameDef.CampaignView}, --自动挂机按钮
		[2038] = {npcSp = 0, content = "Newbie_guide_info_2038", bnewObj = false, effectType = 1, parama = {mainlineid = 3}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.BoxRewardView}, --自动挂机领取奖励按钮
		[2039] = {npcSp = 0, content = "Newbie_guide_info_2039", bnewObj = false, effectType = 1, parama = {mainlineid = 3}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.CampaignView}, --英雄图标

		
		[2041] = {npcSp = 0, content = "", bnewObj = false, effectType = 1, spine_parama = {position = {-106,-30,0}, scale = 0.14, rotation = 0, active = "idle02"}, parama = {mainlineid = 552}, effect_offset = {0,13}, dialog_offset = {0,0}, view = UIWidgetNameDef.CardPortalView}, -- 占星按钮
	    [2042] = {npcSp = 0, content = "", bnewObj = false, effectType = 1, spine_parama = {position = {-106,-30,0}, scale = 0.14, rotation = 0, active = "idle02"}, parama = {mainlineid = 552}, effect_offset = {0,13}, dialog_offset = {0,0}, view = UIWidgetNameDef.CardPortalView}, -- 占星内引导选择英雄

	    [2043] = {npcSp = 0, content = "Newbie_guide_info_1201", bnewObj = false, effectType = 1, parama = {mainlineid = 13}, effect_offset = {30,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.TerritoryView}, --从巨龙回来领地点击战役

	    [2050] = {npcSp = 0, content = "Newbie_guide_info_1201", effectType = 1, parama = {mainlineid = 14}, effect_offset = {30,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.TerritoryView}, --1-12从抽卡回来领地点击战役
	    [2051] = {npcSp = 0, content = "Newbie_guide_info_1202", effectType = 1, parama = {mainlineid = 14}, effect_offset = {0,13}, dialog_offset = {0,115}, view = UIWidgetNameDef.CampaignView},  --点击 挑战首领 1-10

	    [2052] = {npcSp = 0, content = "Newbie_guide_info_1202", effectType = 1, parama = {mainlineid = 41}, effect_offset = {0,13}, dialog_offset = {0,115}, view = UIWidgetNameDef.CardPortalView},  --引导点击心愿单
	    [2053] = {npcSp = 0, content = "Newbie_guide_info_1202", effectType = 1, parama = {mainlineid = 41}, effect_offset = {0,13}, dialog_offset = {0,115}, view = UIWidgetNameDef.CardPortalWishView},  --引导点击心愿单第一条目录

	    --升阶结束后引导点击战役界面
	    [2054] = {npcSp = 0, content = "Newbie_guide_info_1201", effectType = 1, parama = {mainlineid = 14}, effect_offset = {30,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.TerritoryView}, 
	    -- 1-3 引导增加挑战按钮步骤
	    [2055] = {npcSp = 0, content = "Newbie_guide_info_205", bnewObj = false, effectType = 1, parama = {}, effect_offset = {0,13}, dialog_offset = {0,100}, view = UIWidgetNameDef.BattleNetSelectView},
	
 --引导点击圣堂
        [2056] = {npcSp = 1, content = "Newbie_guide_info_1101_9", bnewObj = false, effectType = 1, parama = {mainlineid = 14}, effect_offset = {-50,0}, dialog_offset = {-50,99}, view = UIWidgetNameDef.TerritoryView},
        --引导点击指定英雄-鲍德维克
        [2057] = {npcSp = 3, content = "Newbie_guide_info_1102_9", bnewObj = false, effectType = 1, parama = {roleid = 1103}, effect_offset = {0,4}, dialog_offset = {0,-120}, view = UIWidgetNameDef.Templeview},
        --引导玩家指定升阶材料，鲍德维克
        [2058] = {npcSp = 3, content = "Newbie_guide_info_1103_9", bnewObj = false, effectType = 1, parama = {roleid = 1103}, effect_offset = {0,4}, dialog_offset = {0,-120}, view = UIWidgetNameDef.Templeview}, 
        --引导玩家指定升阶材料，鲍德维克
        [2059] = {npcSp = 0, content = "Newbie_guide_info_1104_1", bnewObj = false, effectType = 1, parama = {roleid = 1103}, effect_offset = {0,4}, dialog_offset = {0,-120}, view = UIWidgetNameDef.Templeview},
        --点击升阶按钮
        [2060] = {npcSp = 0, content = "", bnewObj = false, effectType = 1, parama = {mainlineid = 14}, effect_offset = {0,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.Templeview}, 
        --引导退出按钮返回领地界面
        [2061] = {npcSp = 0, content = "Newbie_guide_info_401", bnewObj = false, effectType = 1, parama = {mainlineid = 14}, effect_offset = {3,13}, dialog_offset = {135,0}, view = UIWidgetNameDef.FullScreenView}, --全屏界面关闭按钮

        [2062] = {npcSp = 0, content = "Newbie_guide_info_1201", effectType = 1, parama = {mainlineid = 14}, effect_offset = {30,13}, dialog_offset = {0,90}, view = UIWidgetNameDef.TerritoryView},
 
         --弱引导 引导1-6挑战首领
		[2063] = {npcSp = 0, content = "Newbie_guide_info_701", effectType = 1, parama = {mainlineid = 6}, effect_offset = {0,13}, dialog_offset = {0,115}, view = UIWidgetNameDef.CampaignView},  --点击 挑战首领 1-6
		[2064] = {npcSp = 0, content = "", effectType = 1, parama = {mainlineid = 6}, effect_offset = {0,13}, dialog_offset = {445,-250}, view = UIWidgetNameDef.BossInfoView}, --挑战boss首领弹窗
		[2065] = {npcSp = 0, content = "Newbie_guide_info_205", bnewObj = false, effectType = 1, parama = {mainlineid = 6}, effect_offset = {0,13}, dialog_offset = {0,100}, view = UIWidgetNameDef.BattleNetSelectView},
 



        --10030 引导玩家上阵卡马尔
        --引导点击挑战首领
        [2603] = {npcSp = 1, content = "Newbie_guide_info_1111", bnewObj = false, effectType = 1, parama = {mainlineid = 14}, effect_offset = {0,4}, dialog_offset = {-650,115}, view = UIWidgetNameDef.CampaignView},  
        --引导点击鲍德维克
        [2604] = {npcSp = 2, content = "Newbie_guide_info_1112", bnewObj = false, effectType = 1, parama = {roleid = 1103}, effect_offset = {0,-20}, dialog_offset = {115,-115}, view = UIWidgetNameDef.BattleNetSelectView}, 
        --引导点击上阵卡马尔
		[2605] = {npcSp = 1, content = "Newbie_guide_info_1113", bnewObj = false, effectType = 1, parama = {roleid = 1102}, effect_offset = {0,13}, dialog_offset = {-530,-280}, view = UIWidgetNameDef.BattleNetSelectView}, 
		--引导点击开始战斗
		[2606] = {npcSp = 0, content = "Newbie_guide_info_205", bnewObj = false, effectType = 1, parama = {mainlineid = 2}, effect_offset = {0,13}, dialog_offset = {0,100}, view = UIWidgetNameDef.BattleNetSelectView}, 





	},

	--获得新英雄
	newhero = {
		--获得新英雄杰西卡
		[3001] = {npcSp = 0, content = "Newbie_tips_info_1023", effectType = 1, spine_parama = {position = {-106,-30,0}, scale = 0.14, rotation = 0, active = "idle01"}, parama = {roleid = 1303}, effect_offset = {0,13}, dialog_offset = {0,0}, view = UIWidgetNameDef.CampaignView},  --获得新英雄 杰西卡
		[3002] = {npcSp = 0, content = "Newbie_tips_info_1023", effectType = 1, spine_parama = {position = {-106,-30,0}, scale = 0.14, rotation = 0, active = "idle01"}, parama = {roleid = 3203}, effect_offset = {0,13}, dialog_offset = {0,0}, view = UIWidgetNameDef.CampaignView},  --获得新英雄 法林
		[3003] = {npcSp = 0, content = "Newbie_tips_info_1023", effectType = 1, spine_parama = {position = {-106,-30,0}, scale = 0.14, rotation = 0, active = "idle01"}, parama = {roleid = 1306}, effect_offset = {0,13}, dialog_offset = {0,0}, view = UIWidgetNameDef.CampaignView},  --获得新英雄 罗珊
	},

	--普通新手对话框  1= 鲍德维克 2=因娜拉
	normal_dialog = {
		--光明圣堂引导
		[4001] = {
			{bForceGuide = true, npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbie_chat_info_201", spine_res = "UI_1113011", parama = {mainlineid = 1}, spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
			{bForceGuide = true, npcSp=1, npcName = "Newbiemazenewbie_1001", content = "Newbie_chat_info_202", spine_res = "UI_1111031", parama = {mainlineid = 2}, spine_parama = {position = {15,-610}, scale = 0.45, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
		},
		[4002] = {
			{bForceGuide = true, npcSp=1, npcName = "Newbiemazenewbie_1004", content = "Newbie_chat_info_301", spine_res = "UI_1113031", parama = {mainlineid = 2}, spine_parama = {position = {-110,-350}, scale = 0.65, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
			{bForceGuide = true, npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbie_chat_info_302", spine_res = "UI_1113011", parama = {mainlineid = 2}, spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
		},
		[4003] = {
			{bForceGuide = false, npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbie_chat_info_401", spine_res = "UI_1113011", parama = {mainlineid = 3}, spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
		},
		[4004] = {
			{bForceGuide = true, npcSp=2, npcName = "Newbiemazenewbie_1003", content = "Newbie_chat_info_501", spine_res = "UI_1132031", parama = {mainlineid = 4}, spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
		    {bForceGuide = true, npcSp=1, npcName = "Newbiemazenewbie_1001", content = "Newbie_chat_info_1101", spine_res = "UI_1111031", parama = {mainlineid = 4}, spine_parama = {position = {15,-610}, scale = 0.45, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
		},
		[4005] = {
			{bForceGuide = true, npcSp=1, npcName = "Newbiemazenewbie_1007", content = "Newbie_chat_info_10005_40041", spine_res = "UI_1113061", parama = {mainlineid = 7}, spine_parama = {position = {-180,-400}, scale = 0.28, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
			{bForceGuide = true, npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbie_chat_info_10005_40042", spine_res = "UI_1113011", parama = {mainlineid = 7}, spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
			{bForceGuide = true, npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbie_chat_info_10005_40043", spine_res = "UI_1113011", parama = {mainlineid = 7}, spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
		},
		[4006] = {
			{bForceGuide = true, npcSp=1, npcName = "Newbiemazenewbie_1001", content = "Newbie_chat_info_1001", spine_res = "UI_1111031", parama = {mainlineid = 12}, spine_parama = {position = {15,-610}, scale = 0.45, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
		},
		[4007] = {
			{bForceGuide = false, npcSp=1, npcName = "Newbiemazenewbie_1001", content = "Newbie_chat_info_10029", spine_res = "UI_1111031", parama = {mainlineid = 14}, spine_parama = {position = {15,-610}, scale = 0.45, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.BattleNetSelectView},
		},
		[4008] = {
			{bForceGuide = true, npcSp=2, npcName = "Newbiemazenewbie_1003", content = "Newbie_chat_info_10015", spine_res = "UI_1132031", parama = {mainlineid = 17}, spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.FieldView},
		},
		[4009] = {
			{bForceGuide = false, npcSp=1, npcName = "Newbiemazenewbie_1001", content = "Newbie_chat_info_1901", spine_res = "UI_1111031", parama = {mainlineid = 33}, spine_parama = {position = {15,-610}, scale = 0.45, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.ApplyGuildView},
		},
		[4010] = {
			{bForceGuide = false, npcSp=1, npcName = "Newbiemazenewbie_1001", content = "Newbie_chat_info_2001", spine_res = "UI_1111031", parama = {mainlineid = 37}, spine_parama = {position = {15,-610}, scale = 0.45, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.RelationMenuView},
		},
		[4011] = {
			{bForceGuide = false, npcSp=1, npcName = "Newbiemazenewbie_1001", content = "Newbie_chat_info_10026_1", spine_res = "UI_1111031", parama = {mainlineid = 513}, spine_parama = {position = {15,-610}, scale = 0.45, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.TowerEntranceView},
			{bForceGuide = false, npcSp=1, npcName = "Newbiemazenewbie_1001", content = "Newbie_chat_info_10026_2", spine_res = "UI_1111031", parama = {mainlineid = 513}, spine_parama = {position = {15,-610}, scale = 0.45, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.TowerEntranceView},
		},
		[4012] = {
			{bForceGuide = false, npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbie_chat_info_502", spine_res = "UI_1113011", parama = {mainlineid = 3}, spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.HeroListView},
		},
		[4013] = {
			{bForceGuide = false, npcSp=1, npcName = "Newbiemazenewbie_1002", content = "Newbie_chat_info_503", spine_res = "UI_1111031", parama = {mainlineid = 3}, spine_parama = {position = {15,-610}, scale = 0.45, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.HeroListView},
		},
		[4014] = {
			{bForceGuide = false, npcSp=1, npcName = "Newbiemazenewbie_1002", content = "Newbie_chat_info_504", spine_res = "UI_1111031", parama = {mainlineid = 3}, spine_parama = {position = {15,-610}, scale = 0.45, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.HeroListView},
		},

        [4015] = {
			{bForceGuide = false, npcSp=1, npcName = "Newbiemazenewbie_1001", content = "Newbie_chat_info_10004", spine_res = "UI_1111031", parama = {mainlineid = 14}, spine_parama = {position = {15,-610}, scale = 0.45, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.BattleNetSelectView},
		},

		[4901] = {
			{bForceGuide = true, npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbie_chat_info_20001_1", spine_res = "UI_1113011", parama = {mainlineid = 999}, spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
			{bForceGuide = true, npcSp=1, npcName = "Newbiemazenewbie_1001", content = "Newbie_chat_info_20001_2", spine_res = "UI_1111031", parama = {mainlineid = 999}, spine_parama = {position = {15,-610}, scale = 0.45, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
		},
		[4902] = {
			{bForceGuide = true, npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbie_chat_info_20002_1", spine_res = "UI_1113011", parama = {mainlineid = 3}, spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
			{bForceGuide = true, npcSp=1, npcName = "Newbiemazenewbie_1001", content = "Newbie_chat_info_20002_2", spine_res = "UI_1111031", parama = {mainlineid = 3}, spine_parama = {position = {15,-610}, scale = 0.45, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
		},		
		[4903] = {
			{bForceGuide = true, npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbie_chat_info_20003_1", spine_res = "UI_1113011", parama = {mainlineid = 3}, spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
			{bForceGuide = true, npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbie_chat_info_20003_2", spine_res = "UI_1113011", parama = {mainlineid = 3}, spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
		},
		[4904] = {
			{bForceGuide = true, npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbie_chat_info_20004_1", spine_res = "UI_1113011", parama = {mainlineid = 3}, spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
			{bForceGuide = true, npcSp=1, npcName = "Newbiemazenewbie_1001", content = "Newbie_chat_info_20004_2", spine_res = "UI_1111031", parama = {mainlineid = 3}, spine_parama = {position = {15,-610}, scale = 0.45, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
		},	
		[4905] = {
			{bForceGuide = true, npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbie_chat_info_20005_1", spine_res = "UI_1113011", parama = {mainlineid = 552}, spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
		},
		[4906] = {
			{bForceGuide = true, npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbie_chat_info_20005_1", spine_res = "UI_1113011", parama = {mainlineid = 41}, spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CardPortalView},
		},	
		--引导升阶后弹出对应聊天对话
		[4910] = {
			{bForceGuide = true, npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbie_chat_info_20005_1", spine_res = "UI_1113011", parama = {mainlineid = 14}, spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
		},

		--获得碧伦丝的文本对话
		[4911] = {
			{bForceGuide = true, npcSp=1, npcName = "Newbiemazenewbie_1001", content = "Newbie_chat_info_10030_1", spine_res = "UI_1111031", parama = {mainlineid = 13}, spine_parama = {position = {15,-610}, scale = 0.45, rotation = 0, active = "idle02"},  view = UIWidgetNameDef.CampaignView},
			{bForceGuide = true, npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbie_chat_info_10030_2", spine_res = "UI_1113011", parama = {mainlineid = 13}, spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
			{bForceGuide = true, npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbie_chat_info_10030_3", spine_res = "UI_1113011", parama = {mainlineid = 13}, spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
		},

		--获得卡马尔的文本对话
		[4912] = {
			{bForceGuide = true, npcSp=2, npcName = "Newbiemazenewbie_1009", content = "Newbie_chat_info_10031_1", spine_res = "UI_1111021", parama = {mainlineid = 14}, spine_parama = {position = {30,-120}, scale = 0.21, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
			{bForceGuide = true, npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbie_chat_info_10031_2", spine_res = "UI_1113011", parama = {mainlineid = 14}, spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
			-- {bForceGuide = true, npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbie_chat_info_10010_2", spine_res = "UI_1113011", parama = {mainlineid = 9}, spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}, view = UIWidgetNameDef.CampaignView},
		},


	},

	--巨龙巢穴副本对话框tips新手配置
	--npcSp:1左边  2右边 npcName:npc名字 content：内容 spine_parama：spine参数
	mazenewbie_tips = {
		[1] = {npcSp=1, npcName = "Newbiemazenewbie_1001", content = "Newbiemazenewbie_2001", spine_res = "UI_1111031", spine_parama = {position = {15,-610}, scale = 0.45, rotation = 0, active = "idle02"}},
		[2] = {npcSp=1, npcName = "Newbiemazenewbie_1001", content = "Newbiemazenewbie_2002", spine_res = "UI_1111031", spine_parama = {position = {15,-610}, scale = 0.45, rotation = 0, active = "idle02"}},
		[3] = {npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbiemazenewbie_2003", spine_res = "UI_1113011", spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}},
		[4] = {npcSp=1, npcName = "Newbiemazenewbie_1001", content = "Newbiemazenewbie_2004", spine_res = "UI_1111031", spine_parama = {position = {15,-610}, scale = 0.45, rotation = 0, active = "idle02"}},
		[5] = {npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbiemazenewbie_2005", spine_res = "UI_1113011", spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}},
		[6] = {npcSp=1, npcName = "Newbiemazenewbie_1001", content = "Newbiemazenewbie_2001_1", spine_res = "UI_1111031", spine_parama = {position = {15,-610}, scale = 0.45, rotation = 0, active = "idle02"}},
		
		[7] = {npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbiemazenewbie_2006", spine_res = "UI_1113011", spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}},
        [8] = {npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbiemazenewbie_2007", spine_res = "UI_1113011", spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}},
        [9] = {npcSp=2, npcName = "Newbiemazenewbie_1002", content = "Newbiemazenewbie_2008", spine_res = "UI_1113011", spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}},

        [10] = {npcSp=2, npcName = "Newbiemazenewbie_1003", content = "Newbiemazenewbie_2009", spine_res = "UI_1132031", spine_parama = {position = {105,-200}, scale = 0.23, rotation = 0, active = "idle02"}},
        [11] = {npcSp=1, npcName = "Newbiemazenewbie_1001", content = "Newbiemazenewbie_2010", spine_res = "UI_1111031", spine_parama = {position = {15,-610}, scale = 0.45, rotation = 0, active = "idle02"}},


	},

	--巨龙副本手指气泡 content内容 direction：0不显示气泡 1显示左边气泡 2显示右边气泡 effect_offset手指偏移  dialog_offset气泡偏移 mask_offset遮罩偏移
	--mask_rect 遮罩区大小 bForceGuide:true强引导 false弱引导
	mazenewbie_finger = {
		[1] = {content = "eeee", direction = 0, effect_offset = {0,0}, dialog_offset = {0,0}, mask_offset = {0,0}, mask_rect = {100, 100}, bForceGuide = false},
		[2] = {content = "eeee", direction = 0, effect_offset = {0,0}, dialog_offset = {0,0}, mask_offset = {0,0}, mask_rect = {100, 100}, bForceGuide = false},
		[3] = {content = "NewbiefingerView_1001", direction = 1, effect_offset = {0,0}, dialog_offset = {0,60}, mask_offset = {0,0}, mask_rect = {100, 100}, bForceGuide = false},
		[4] = {content = "NewbiefingerView_1002", direction = 1, effect_offset = {0,0}, dialog_offset = {0,140}, mask_offset = {0,0}, mask_rect = {100, 100}, bForceGuide = false},
		[5] = {content = "NewbiefingerView_1003", direction = 1, effect_offset = {0,0}, dialog_offset = {0,140}, mask_offset = {0,0}, mask_rect = {100, 100}, bForceGuide = false},
		[6] = {content = "NewbiefingerView_1004", direction = 1, effect_offset = {0,0}, dialog_offset = {0,120}, mask_offset = {0,0}, mask_rect = {100, 100}, bForceGuide = false},
        [7] = {content = "NewbiefingerView_1005", direction = 1, effect_offset = {0,0}, dialog_offset = {20,190}, mask_offset = {0,0}, mask_rect = {100, 100}, bForceGuide = false},
		[8] = {content = "NewbiefingerView_1006", direction = 1, effect_offset = {0,0}, dialog_offset = {0,120}, mask_offset = {0,0}, mask_rect = {100, 100}, bForceGuide = false},
		[9] = {content = "NewbiefingerView_1007", direction = 1, effect_offset = {0,0}, dialog_offset = {0,120}, mask_offset = {0,0}, mask_rect = {100, 100}, bForceGuide = false},

		[10] = {content = "NewbiefingerView_1008", direction = 1, effect_offset = {0,0}, dialog_offset = {0,120}, mask_offset = {0,0}, mask_rect = {100, 100}, bForceGuide = false},
		[11] = {content = "NewbiefingerView_1008", direction = 1, effect_offset = {0,0}, dialog_offset = {0,120}, mask_offset = {0,0}, mask_rect = {100, 100}, bForceGuide = false},

	},

	--针对某些强引导，做特殊处理，就算是强引导，只要触发到某一步，就算完成(bComplete)
	newbie = {
		--2 上阵1103鲍德维克 和 3103兰黛
		[10001] = {
			[1] = {type = 4, id = 4001},  --对话框
			[2] = {type = 1, id = 1001},  --点击 挑战首领 1-1
			[3] = {type = 1, id = 1002},  --上阵1103鲍德维克
			[4] = {type = 1, id = 1021},  --上阵3103兰黛
			[5] = {type = 1, id = 1003},  --开始战斗
		},


		--3 获得新英雄杰西卡
		[10002] = {
			[1] = {type = 3, id = 3001}, --获得新英雄 杰西卡
		},

		-- 获得杰西卡新英雄界面关闭后 引导上阵杰西卡，引导站位
		[10003] = {
			[1] = {type = 4, id = 4002},  --对话框
			[2] = {type = 1, id = 1015},  --挑战首领1-2
			[3] = {type = 1, id = 1016},  --上阵英雄1303杰西卡
			[4] = {type = 1, id = 1017},  --杰西卡站位
			[5] = {type = 1, id = 1022},  --开始战斗
			[6] = {type = 1, id = 1045},  --自动战斗
		},

		--弱引导 1-3挑战首领
		[10004] = {
			[1] = {type = 4, id = 4003},  --弱引导 对话框
			[2] = {type = 2, id = 2001},  --挑战首领1-3
			[3] = {type = 2, id = 2002},  --挑战boss首领弹窗
			[4] = {type = 2, id = 2055},  --开始战斗

		},

		--获得新英雄法林
		[10005] = {
			[1] = {type = 3, id = 3002}, --获得新英雄 法林
		},

		--引导杰西卡 英雄升级 
		[10006] = {
			[1] = {type = 4, id = 4004},  --强引导 对话框
			[2] = {type = 1, id = 1006},  --点击英雄图标
			[3] = {type = 1, id = 1007},  --点击杰西卡
			[4] = {type = 1, id = 1008},  --点击升级按钮
			[5] = {type = 1, id = 1023},  --点击关闭全屏界面按钮
			[6] = {type = 1, id = 1010},  --点击关闭全屏界面按钮
		},

		--引导新英雄法林上阵
		[10007] = {
			[1] = {type = 1, id = 1025}, --挑战首领1-4
			[2] = {type = 1, id = 1026}, --上阵法林
			[3] = {type = 1, id = 1027}, --开始战斗
			[4] = {type = 1, id = 1046}, --引导点击二倍速
		},

		--弱引导 1-5挑战首领
		[10008] = {
			[1] = {type = 2, id = 2004}, --弱引导 挑战首领 1-5
			[2] = {type = 2, id = 2005}, --挑战boss首领弹窗
		},

		--自动推图引导
		[10009] = {
			[1] = {type = 1, id = 1062},  -- 自动推图
		},

		--获得新英雄罗珊
		[10010] = {
			[1] = {type = 3, id = 3003}, --获得新英雄 罗珊
		},

		--获得罗珊新英雄界面展示后 在主界面开始引导
		[10011] = {
			[1] = {type = 4, id = 4005},  --强引导 对话框
			[2] = {type = 1, id = 1047}, --挑战关卡1-7
			[3] = {type = 1, id = 1048}, --上阵罗珊
			[4] = {type = 1, id = 1049}, --开始战斗
		},

		--下一章引导
		[10012] = {
			[1] = {type = 4, id = 4006},  --强引导 对话框
			[2] = {type = 1, id = 1090},  --下一章节 12
		},

		--传送门单抽引导
		--bComplete
		--针对某些强引导，做特殊处理，就算是强引导，只要触发到某一步，就算完成(bComplete)
		[10013] = {
			[1] = {type = 1, id = 1011}, --主线1-13引导点击领地 按钮
			[2] = {type = 1, id = 1012}, --在领地界面 引导传送门按钮
			[3] = {type = 1, id = 1013, bComplete = true}, --抽卡界面 引导普通单抽按钮-防止在抽卡动画卡掉线，导致引导卡死的情况
			[4] = {type = 0, id = 0, bComplete = true}, --添加一个空引导，等抽卡流程跑完 再触发下一步
			[5] = {type = 1, id = 1059},  --点击关闭全屏界面按钮
			[6] = {type = 1, id = 1115},  --从抽卡回来点击战役	
			
		},

		--12 单抽抽卡回来到 主界面
		[10014] = {
			[1] = {type = 2, id = 2008}, --挑战首领
			[2] = {type = 4, id = 4007},  --引导 对话框
		},

		--住界面点击远征按钮 引导点击巨龙巢穴
		[10015] = {
			[1] = {type = 1, id = 1050}, --主界面点击远征按钮
			[2] = {type = 4, id = 4008},  --远征界面 对话框
			[3] = {type = 1, id = 1051}, --巨龙巢穴
		},

		--英雄上阵界面 阵容克制
		[10016] = {
			[1] = {type = 2, id = 2009}, --2-8阵容克制弱引导
		},

		--引导主界面活动按钮
		[10017] = {
			[1] = {type = 1, id = 1052}, --活动按钮
			[2] = {type = 1, id = 1053}, --活动章节第一个奖励
			-- [3] = {type = 1, id = 1054}, --活动章节第二个奖励
			[3] = {type = 1, id = 1055, bComplete = true}, --关闭活动全屏界面
		

		},

		--传送门10抽bComplete
		--针对某些强引导，做特殊处理，就算是强引导，只要触发到某一步，就算完成(bComplete)
		[10018] = {
			[1] = {type = 1, id = 1056}, --主线1-10引导点击领地 按钮
			[2] = {type = 1, id = 1057}, --在领地界面 引导传送门按钮
			[3] = {type = 1, id = 1058, bComplete = true}, --抽卡界面 引导普通10抽按钮-防止在抽卡动画卡掉线，导致引导卡死的情况
			[4] = {type = 0, id = 0, bComplete = true}, --  添加一个空引导，等抽卡流程跑完 再触发下一步
			[5] = {type = 1, id = 1061},  --点击关闭全屏界面按钮
			-- [6] = {type = 2, id = 2050},
			-- [7] = {type = 2, id = 2051},
			-- [8] = {type = 4, id = 4015},
			
		},

		--引导普通种族塔
		[10019] = {
			[1] = {type = 2, id = 2010}, ---- 远征图标 3-5
			[2] = {type = 2, id = 2011}, -- 赎罪之塔图标
			[3] = {type = 2, id = 2013}, --赎罪之塔普通塔挑战按钮
		},

		--引导公会
		[10020] = {
			[1] = {type = 2, id = 2014}, ---- 通关2-20引导点击领地 
			[2] = {type = 2, id = 2015}, -- 在领地点击公会
			[3] = {type = 4, id = 4009}, --在公会界面里打开对话
		},

		--引导羁绊树
		[10021] = {
			[1] = {type = 2, id = 2016}, ---- 通关2-20引导点击领地 
			[2] = {type = 2, id = 2017}, -- 在领地点击羁绊树
			[3] = {type = 4, id = 4010}, --在羁绊界面里打开对话
		},

		--普通竞技场
		[10022] = {
			[1] = {type = 2, id = 2018}, --远征图标 3-5
			[2] = {type = 2, id = 2019}, --远征界面竞技场图标
			[3] = {type = 2, id = 2020}, ---- 普通竞技场
			[4] = {type = 2, id = 2021}, -- 普通竞技场 挑战按钮
		},

		--贸易航线
		[10023] = {
			[1] = {type = 2, id = 2022}, -- 远征图标 3-5
			[2] = {type = 2, id = 2023}, -- 远征界面贸易航线图标
			[3] = {type = 2, id = 2024},-- 远征界面贸易航线第一个
			[4] = {type = 2, id = 2025}, -- 贸易航线 点加号 派遣
			[5] = {type = 2, id = 2026}, -- 贸易航线 派遣第一个英雄
			[6] = {type = 2, id = 2027}, -- 贸易航线 点击派遣按钮
			[7] = {type = 2, id = 2040}, -- 贸易航线 点击派遣按钮
			[8] = {type = 0, id = 0, bComplete = true}, --添加一个空引导，等抽卡流程跑完 再触发下一步
			[9] = {type = 2, id = 2044}, -- 贸易航线 点击升级按钮，打开升级界面
			[10] = {type = 2, id = 2045}, -- 贸易航线 点击升级
			[11] = {type = 0, id = 0, bComplete = true}, --添加一个空引导，等抽卡流程跑完 再触发下一步			
			-- [12] = {type = 4, id = 4013}, -- 聊天对话，说明引导升级可以获得更多的任务奖励

		},

		--劇情副本
		[10024] = {
			[1] = {type = 2, id = 2028}, -- 远征图标 3-5
			[2] = {type = 2, id = 2029}, -- 远征界面剧情副本图标
			[3] = {type = 2, id = 2030}, -- 剧情副本 开始探索图标
		},

		--高阶竞技场
		[10025] = {
			[1] = {type = 2, id = 2031}, --远征图标 3-5
			[2] = {type = 2, id = 2032}, --远征界面竞技场图标
			[3] = {type = 2, id = 2033}, ---- 高阶竞技场
			[4] = {type = 2, id = 2034},-- 高阶竞技场 挑战按钮
		},

		--种族塔
		[10026] = {
			[1] = {type = 2, id = 2035}, -- 远征图标 3-5 开启种族塔
			[2] = {type = 2, id = 2036}, --赎罪之塔图标
			[3] = {type = 4, id = 4011}, --TowerEntranceView爬塔界面对话
		},

		--引导杰西卡穿戴装备
		[10027] = {
			[1] = {type = 1, id = 1063},  --点击英雄图标
			[2] = {type = 1, id = 1064},  --点击杰西卡头像
			[3] = {type = 1, id = 1065},  --点击装备toggle
			[4] = {type = 1, id = 1066},  --点击一键穿戴按钮
			[5] = {type = 1, id = 1067},  --点击关闭全屏界面按钮
			[6] = {type = 1, id = 1068},  --点击关闭全屏界面按钮
		},

		--引导玩家进行升阶
		[10028] = {
			[1] = {type = 2, id = 2056},  --引导玩家点击升阶场所——圣堂
			[2] = {type = 2, id = 2057},  --引导玩家点击指定英雄，鲍德维克（英雄ID：1306），（此时玩家有三个罗珊，选择排位靠前的那个）
			[3] = {type = 2, id = 2058},  --引导玩家点击指定升阶材料，（英雄ID：1306），引导玩家选择排位靠中的那个
			[4] = {type = 2, id = 2059},  --引导玩家点击指定升阶材料，鲍德维克（英雄ID：1201），引导玩家选择排位靠后的那个
			[5] = {type = 2, id = 2060},  --引导玩家点击升阶按钮
			[6] = {type = 0, id = 0, bComplete = true}, --添加一个空引导，等抽卡流程跑完 再触发下一步
			[7] = {type = 2, id = 2061},  --引导返回领地界面
			[8] = {type = 2, id = 2062},  --引导点击返回战役按钮
		},

		--升阶结束后聊天对话
		[10029] = {
			[1] = {type = 4, id = 4910}, -- 升阶结束后对文本进行说明
		},		

		--引导玩家上阵碧伦丝
		[10030] = {
			[1] = {type = 4, id = 4911},  --对话碧伦丝-因娜拉
			[2] = {type = 1, id = 1107},  --引导点击挑战首领
			[3] = {type = 1, id = 1108},  --引导玩家点击兰黛，下阵兰黛
			[4] = {type = 1, id = 1109},  --引导点击引导玩家上阵碧伦丝
			[5] = {type = 1, id = 1110},  --引导玩家点击开战
		},

		-- --引导玩家上阵卡马尔
		-- [10031] = {
		-- 	[1] = {type = 4, id = 4912},  --对话卡马尔
		-- 	[2] = {type = 2, id = 2603},  --引导点击挑战首领
		-- 	[3] = {type = 2, id = 2604},  --引导玩家点击鲍德维克，下阵鲍德维克
		-- 	[4] = {type = 2, id = 2605},  --引导点击引导玩家上阵卡马尔
		-- 	[5] = {type = 2, id = 2606},  --引导玩家点击开战
		-- },


				--弱引导 1-6挑战首领
		[10032] = {
			[1] = {type = 2, id = 2063}, --弱引导 挑战首领 1-6
			[2] = {type = 2, id = 2064}, --弱引导 挑战首领 1-6
			[3] = {type = 2, id = 2065}, --挑战boss首领弹窗
		},

	
		--特殊引导1 前两章失败后回到主界面就触发，重复触发,不能当作正常引导处理， 这个引导不能完成
		[30001] = {
			[1] = {type = 2, id = 2037}, --自动挂机按钮
			[2] = {type = 2, id = 2038}, --自动挂机领取奖励按钮
			[3] = {type = 2, id = 2039},--英雄图标
			[4] = {type = 4, id = 4012}, --英雄列表界面
		},

		[90001] = {
			[1] = {type = 1, id = 1060}, --大招
		},


		---特殊引导
		--光明圣堂
		[20001] = {
			[1] = {type = 4, id = 4901}, 
		},
		--英雄重置
		[20002] = {
			[1] = {type = 4, id = 4902}, 
		},
		--英雄遣散
		[20003] = {
			[1] = {type = 4, id = 4903}, 
		},
		--共鸣水晶
		[20004] = {
			[1] = {type = 4, id = 4904}, 
		},
		--占星
		[20005] = {
			[1] = {type = 4, id = 4905}, 
			
		},

		--心愿单引导
		[20006] = {
			[1] = {type = 4, id = 4906, bComplete = true},
			[2] = {type = 2, id = 2052},
			[3] = {type = 2, id = 2053}, 
			
		},

	},

	
})