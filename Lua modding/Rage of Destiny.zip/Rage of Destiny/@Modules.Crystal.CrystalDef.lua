local CrystalDef = {}
CrystalDef.NotifyDef =
{
	UpdateCrystal = "UpdateCrystal",
	UpdateCrystalInfo = "UpdateCrystalInfo",
	UpdateCrystalLevelUp = "UpdateCrystalLevelUp",
	UpdateCrystalUnLock = "UpdateCrystalUnLock",
	UpdateCrystalSort = "UpdateCrystalSort",
	UpdateCrystalOpen = "UpdateCrystalOpen",
}

CrystalDef.MaxListCount = 90	--最多存在的水晶列表
CrystalDef.HeroMaxRank = 11		--英雄扩张容量的 最大品质单位
CrystalDef.MaxRankLevel = 5		--每 最大品质 提升的等级
CrystalDef.HeroMaxLevel = 240	--英雄提升的最大等级

return CrystalDef