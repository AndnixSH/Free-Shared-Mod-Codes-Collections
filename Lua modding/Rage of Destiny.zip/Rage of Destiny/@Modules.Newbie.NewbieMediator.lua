local NewbieMediator = NewbieMediator or BaseClass(StdMediator)

function NewbieMediator:OnEnterScenceFirst()
	if not AppConfig.ISALONE then
		local NewbieManager = require "Modules.Newbie.NewbieManager"
		NewbieManager.Instance:ClearAllData()
		NewbieManager.Instance:ClearNewbie()
		
		local NewbieProxy = require "Modules.Newbie.NewbieProxy"
		NewbieProxy.Instance:SetInitData(false)
		NewbieProxy.Instance:Send18000()
	end		
end

return NewbieMediator