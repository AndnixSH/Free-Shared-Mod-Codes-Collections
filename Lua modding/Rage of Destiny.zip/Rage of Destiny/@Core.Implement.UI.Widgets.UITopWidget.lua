local UITopWidget = UITopWidget or BaseClass(LuaBasicWidget)
function UITopWidget:OnLoad()
	local obj = GameObject(UIWidgetNameDef.Root_top)
	GameObjTools.AddComponent(obj,"RectTransform")
	self:LoadEnd(obj)
end

function UITopWidget:LoadEnd(obj)
	self:SetGo(obj)
	self:AddPanel(UIWidgetNameDef.TopPanel)

	self:Step(0)
end

function UITopWidget:OnOpen()
	self:SetDepth(self.go ,1000)
	self:SetModelDepth(self.go, 20000)
end

return UITopWidget