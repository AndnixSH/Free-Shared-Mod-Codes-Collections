-- 定义全局方法

function template(t, path)
    local class = global.service.requirer:require(path)
    return setmetatable(t or {}, {__index = class})
end

function dynamic(t)

    return setmetatable(
        t or {},
        {
            __index = function(t, k)
                if not rawget(t, k) then
                    rawset(t, k, dynamic())
                    return rawget(t, k)
                end
                return rawget(t, k)
            end
        }
    )
end

metafunc = {}
local _class = {}
function metafunc.classify(name, func)
    _class[func] = name
end

function metafunc.getclass(func)
    return _class[func]
end

function metafunc.isclass(func, name)
    return _class[func] == name
end