local logic = { timer = {}, event = service.event(), call = service.call(calldef.born) }

function logic:oncreate()
    self.call.startborn(self, self.owner.prop.rawplayers)
end

function logic.call:startborn(rawplayers)

    -- print("gameborn", table.dump(self.owner.prop))
    self.bornbeforeprepare = {}
    self.bornqueue = {}
    self.rawplayers = rawplayers
    local camp_index = {}
    local bornstatic = self.static.born
    self.currentborn = 0
    self.camplive = {}
    self.bornset = {}
    self.maxborn = 0
    self.bprepare = false
    for k, v in pairs(rawplayers) do
        self.maxborn = self.maxborn + 1
    end

    for i, _config in ipairs(self.static.players) do
        local seatid = _config.seat
        local rawinfo = rawplayers[seatid]
        if rawinfo then
            local camp = rawinfo.prop.camp
            camp_index[camp] = camp_index[camp] or 0
            camp_index[camp] = camp_index[camp] + 1

            local delay = 0
            local campborn = bornstatic[camp]
            if campborn then
                delay = (campborn.delay or 0) + (campborn.interval or 0) * (camp_index[camp] - 1)
            end
            if self.call.get_activity_info(self, "fast_start") then
                delay = 0
            end

            if delay > 0 then
                self.timer:delay(delay, function ()
                    self:bornplayer(seatid, tsvector.make(_config.position), tsvector.make(_config.header))
                end)
            else
                self:bornplayer(seatid, tsvector.make(_config.position), tsvector.make(_config.header))
            end
        end
    end

    local prepare_time = self.static.prepare_time
    if prepare_time and self.call.get_activity_info(self, "fast_start") then
        prepare_time = tsmath.rate(prepare_time, 750)
    end
    if not prepare_time then
        self:_prepared()
    else
        self.timer:delay(prepare_time, self._prepared)
    end

end

function logic:bornplayer(seatid, position, header)

    local rawinfo = self.rawplayers[seatid]
    if rawinfo then
        local roleid = rawinfo.roleid
        local sprite_pos = rawinfo.position and tsvector.make(rawinfo.position) or position
        local spriteobj = self:_bornplayer(roleid, sprite_pos, header, rawinfo.prop, rawinfo.attr)
        local camp = spriteobj.prop.camp
        local campborn = self.static.born[camp]

        spriteobj:createlogic("sprite.player_life_logic")
        spriteobj.caller.life:born({ active = campborn and campborn.active})

        self.currentborn = self.currentborn + 1
        self.camplive[camp] = self.camplive[camp] or 0
        self.camplive[camp] = self.camplive[camp] + 1
        self.bornset[spriteobj] = true

        -- if self.currentborn <= self.maxborn then
        --     table.insert(self.bornbeforeprepare, spriteobj)
        --     if self.currentborn == self.maxborn then
        --         local prepare = campborn and campborn.prepare
        --         if prepare and prepare > 0 then
        --             self.timer:delay(prepare, self._prepared)
        --         else
        --             self:_prepared()
        --         end
        --     end
        -- else
        --     self:prepare_sprite(spriteobj)
        -- end
        if self.bprepare then
            self:prepare_sprite(spriteobj)
        end

        return spriteobj
    else
        global.debug.warning("not found player in seat", seatid)
    end
end

function logic.event.sprite.public:sprite_dead(spriteobj)
    local camp = spriteobj.prop.camp
    if self.camplive[camp] and self.bornset[spriteobj] then
        self.camplive[camp] = self.camplive[camp] - 1
        if  self.camplive[camp] == 0 then
            self:sendmessage(eventdef.gameclear, camp)
        end
    end
end

function logic.event.sprite.public:fake_dead_start(spriteobj)
    local camp = spriteobj.prop.camp
    if self.camplive[camp] and self.bornset[spriteobj] then
        self.camplive[camp] = self.camplive[camp] - 1
        if  self.camplive[camp] == 0 then
            self:sendmessage(eventdef.gameclear, camp)
        end
    end
end

function logic.event.sprite.public:fake_dead_end(spriteobj)
    local camp = spriteobj.prop.camp
    if self.camplive[camp] and self.bornset[spriteobj] then
        self.camplive[camp] = self.camplive[camp] + 1
    end
end

function logic:_prepared()
    -- if self.bornbeforeprepare and #self.bornbeforeprepare > 0 then
    --     for _, sprite in ipairs(self.bornbeforeprepare) do
    --         self:prepare_sprite(sprite)
    --     end
    --     self.bornbeforeprepare = {}
    -- end
    self.bprepare = true
    local actors = self.service.area:getallactors()
    if actors then
        for _, actor in ipairs(actors) do
            self:prepare_sprite(actor)
        end
    end
    local extra = self.owner.prop.extra
    self:sendmessage(eventdef.gameprepared, { breport = extra.report ~= nil })

    local rune_list = self.owner.prop.rune_list
    if rune_list and #rune_list > 0 then
        self:_check_add_rune_list(rune_list)
    end
end

-- 根据质量获取符文数量
function logic.call:getrunecount(quality)

    local count = 0
    local rune_list = self.owner.prop.rune_list
    if rune_list and #rune_list > 0 then
        local data_rune = self.service.config:get("data_rune")
        for _, runeid in ipairs(rune_list) do
            local runeconf = data_rune[runeid]
            if runeconf and runeconf.quality == quality then
                count = count + 1
            end
        end
    end
    return count
end

-- 根据buffid返回符文id
function logic.call:get_runeid(buffid)
    local rune_list = self.owner.prop.rune_list
    if rune_list then
        local data_rune = self.service.config:get("data_rune")
        for _, runeid in ipairs(rune_list) do
            local runeconf = data_rune[runeid]
            if runeconf and runeconf.add_buff == buffid then
                return runeid
            end
        end
    end
end

-- 返回符文标志次数
function logic.call:get_runeflag_count(flag, runeid)
    local rune_flags = self.owner.prop.rune_flags
    if rune_flags then
        for _, value in ipairs(rune_flags) do
            local _flag, _runeid, count = table.unpack(value)
            if _flag == flag and _runeid == runeid then
                return count
            end
        end
    end
    return 0
end

-- 获取玩法记录数值，默认为0
function logic.call:getrecord(key)
    local record = self.owner.prop.record
    if record then
        return record[key]
    end
    return 0
end

-- 获取玩法信息，默认为空
function logic.call:get_activity_info(key)
    local activity_info = self.owner.prop.activity_info
    if activity_info then
        return activity_info[key]
    end
end

function logic:_check_add_rune_list(rune_list)

    local caster = nil
    local reds = self.service.area:getactors(CAMP.RED)
    if reds and #reds > 0 then
        caster = reds[1]
    else
        return
    end
    
    -- print("_check_add_rune_list", caster, table.dump(rune_list))
    local data_rune = self.service.config:get("data_rune")
    for _, runeid in ipairs(rune_list) do
        local runeconf = data_rune[runeid]
        if runeconf then
            if runeconf.target and runeconf.add_buff then
                local targetid, filter = table.unpack(runeconf.target)
                local results = self.service.area:simple_find_targets(caster, targetid, filter, runeconf.num)
                self:_add_buff(runeconf.add_buff, results)
            else
                -- global.debug.warning("data_run没有配置target", runeid)
            end
        else
            global.debug.warning("data_rune找不到"..runeid)
        end
    end

end

function logic.call:addrune(rune_list)
    self:_check_add_rune_list(rune_list)
end

function logic:_add_buff(buffid, spritelist)

    for i, sprite in ipairs(spritelist) do
        if sprite.buff then
            sprite.caller.buff:add(buffid)
        else
            global.debug.warning("sprite.buff is nil", sprite)
        end
    end
end

function logic:_bornplayer(roleid, position, header, prop, attr)
    local sprite = self.area:create_configsprite(roleid, position, header, prop)
    if attr then
        sprite.attr_raw = {}
        for k, v in pairs(attr) do
            v = tsmath.floor(v)
            sprite.attr[k] = v
            sprite.attr_raw[k] = v
        end
    end
    return sprite
end

function logic:prepare_sprite(sprite)
    local bufflist = self.static.buff and self.static.buff[sprite.prop.camp]
    sprite.caller.life:prepared({ bufflist = bufflist, ai = GameConfig.HASAI and GameConfig.HASAI[sprite.prop.camp] })
end

function logic.call:queueborn(seatid, position, header)
    table.insert(self.bornqueue, { seatid, position, header })
end

function logic.timer:t300()
    if #self.bornqueue > 0 then
        -- print(#self.bornqueue)
        local temp = {}
        for i = 1, #self.bornqueue do
            local born = self.bornqueue[i]
            if i <= 3 then
                self:bornplayer(table.unpack(born))
            else
                table.insert(temp, born)
            end
        end
        self.bornqueue = temp
    end
end

return logic