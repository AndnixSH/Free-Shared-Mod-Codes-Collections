local state = { timer = {} }

function state:onbreak()
end

function state:onenter()
    -- self.timer:loop(0, 1000, self._set_velocity)
end

function state:_set_velocity()
    local speed = 1000
    local velocity = tsvector.new(tsmath.random(-speed, speed), tsmath.random(-speed, speed))
    self.owner.body:setvelocity(velocity)
    return tsmath.random(2000, 5000)
end

return state