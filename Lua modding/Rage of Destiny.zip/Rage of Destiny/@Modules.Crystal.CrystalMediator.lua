local CrystalMediator = CrystalMediator or BaseClass(StdMediator)
local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"

function CrystalMediator:OnEnterLoadingEnd()
	if SceneManager.Instance.sceneType == SceneDef.SceneType.Main then
		self:DelayExecute(function()
			local CrystalProxy = require "Modules.Crystal.CrystalProxy"
			local TreeProxy = require "Modules.Tree.TreeProxy"
			CrystalProxy.Instance:Send20100()
			TreeProxy.Instance:Send20700()
		end)
	end		
end

function CrystalMediator:OnEnterScenceFirst()
end

return CrystalMediator