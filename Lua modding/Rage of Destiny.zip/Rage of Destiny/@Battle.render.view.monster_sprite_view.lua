local sprite_view_class = require "Battle.render.view.base_sprite_view"

local monster_sprite_model = require "Battle.render.model.monster_sprite_model"
--local sprite_center_anchor = require "Battle.render.anchor.sprite_center_anchor"
local sprite_frame_anchor = require "Battle.render.anchor.sprite_frame_anchor"
local player_title_view = require "Modules.Battle.Title.MonsterTitleView"

local monster_sprite_view = sprite_view_class()
local active_config = faceConfig["data_active"]

function monster_sprite_view:__init()
end

function monster_sprite_view:create()
    local data = global.service.readonly:reader(self.sprite_id)
    if not data or not data.body then
        print("the sprite_id data is nil", self.sprite_id)
        return
    end

    local body_anchor = sprite_frame_anchor.New(self.sprite_id)
    self.body = monster_sprite_model.New(body_anchor, data.body.prefab_id[1])

    if data.static.hp_show == 1 then
        self.title_view = player_title_view.New(self.sprite_id)
    end

    self.is_show = true
end

function monster_sprite_view:release()
    if self.body then
        self.body:release()
        self.body = nil
    end

    if self.title_view then
        self.title_view:release()
        self.title_view = nil
    end

    if self.model_view then
        self.color_list = {}
        self.rim_color_list = {}

        for key, _ in pairs(self.model_view) do
            self.model_view[key]:release()
            self.model_view[key]:DeleteMe()
            self.model_view[key] = nil
        end
    end
    self.is_show = false
end

function monster_sprite_view:show()
    if self.is_show then
        return
    end

    if self.body then
        self.body:show_model()
    end

    if self.title_view then
        self.title_view:setactive(true)
    end

    if self.model_view then
        for key, _ in pairs(self.model_view) do
            self.model_view[key]:show_model()
        end
    end

    self.is_show = true
end

function monster_sprite_view:hide()
    if not self.is_show then
        return
    end

    if self.body then
        self.body:hide_model()
    end

    if self.title_view then
        self.title_view:setactive(false)
    end

    if self.model_view then
        for key, _ in pairs(self.model_view) do
            self.model_view[key]:hide_model()
        end
    end
    self.is_show = false
end

function monster_sprite_view.event.sprite:start_active(active_name, speed, tag)
    local view_manager = require "Battle.render.view_manager"
    if not view_manager.show_active then
        return
    end

    local monster_active_info = active_config[tostring(self.config_id)]
    if not monster_active_info then
        return
    end

    if not monster_active_info[active_name] then
        return
    end

    speed = speed and speed / 1000 or 1
    tag = tag or 0

    if not self.body or self.is_pause then
        return
    end

    if self.active_name ~= active_name then
        self.body:start_active(string.format("%s_%s", self.config_id, active_name), speed * self.global_speed, tag)
        self.active_name = active_name
        self.active_speed = speed
    end
end

function monster_sprite_view.event.sprite:sprite_dead()
    self.body:start_active(string.format("%s_%s", self.config_id, "dead"), self.global_speed, 0, function()
        local view_manager = require "Battle.render.view_manager"
        view_manager.remove_sprite(self.sprite_id, SPRITE_TYPE.MONSTER)
    end)

    if self.title_view then
        self.title_view:setactive(false)
    end

    --if self.buff_view then
    --    for buff_id, _ in pairs(self.buff_view) do
    --        self.buff_view[buff_id]:release()
    --        self.buff_view[buff_id] = nil
    --    end
    --end

    if self.model_view then
        for key, _ in pairs(self.model_view) do
            self.model_view[key]:release()
            self.model_view[key]:DeleteMe()
            self.model_view[key] = nil
        end
    end
end

function monster_sprite_view.event.sprite:show_view()
    self:show()
end

function monster_sprite_view.event.sprite:hide_view()
    self:hide()
end


-- anchor_table: {header_type, bone}
function monster_sprite_view.event.sprite:add_model(key, model_name, anchor_table)
    local view_manager = require "Battle.render.view_manager"
    if not view_manager.show_active then
        return
    end
    self:add_model({ key = key, prefab_name = model_name, anchor = anchor_table })
end

function monster_sprite_view.event.sprite:remove_model(model_name)
    self:remove_model({ key = model_name })
end

-- anchor_table: {header_type, bone}
-- active_table: {active, tag}
function monster_sprite_view.event.sprite:add_active_model(model_name, anchor_table, active_table)
    local view_manager = require "Battle.render.view_manager"
    if not view_manager.show_active then
        return
    end
    self:add_active_model({ prefab_name = model_name, anchor = anchor_table, active = active_table })
end

function monster_sprite_view.event.sprite:add_color(key, color_table)
    self:add_color({ key = key, color = color_table })
end

function monster_sprite_view.event.sprite:remove_color(key)
    self:remove_color({ key = key })
end

function monster_sprite_view.event.sprite:add_rim_color(key, color_table)
    self:add_rim_color({ key = key, rim_color = color_table })
end

function monster_sprite_view.event.sprite:remove_rim_color(key)
    self:remove_rim_color({ key = key })
end

function monster_sprite_view.event.sprite:add_sound(soundname)
    self:add_sound(soundname)
end

function monster_sprite_view.event.sprite:remove_sound(soundname)
    self:remove_sound(soundname)
end

function monster_sprite_view.event.sprite:add_special_state(key, state)
    self:add_special_state({key = key, state = state})
end

function monster_sprite_view.event.sprite:remove_special_state(key)
    self:remove_special_state({key = key})
end

function monster_sprite_view:speed_active()
    if self.body and self.active_name then
        --self.body:set_active_speed(self.global_speed * self.active_speed)
    end
end

function monster_sprite_view:set_layer(layer)
    if self.body then
        self.body:set_layer(layer)
    end
end

function monster_sprite_view:reset_layer()
    if self.body then
        self.body:reset_layer()
    end
end

function monster_sprite_view:remove_title_view()
    if self.title_view then
        self.title_view:release()
        self.title_view = nil
    end
end

return monster_sprite_view