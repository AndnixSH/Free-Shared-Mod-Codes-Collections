tsrandom = {}
local _seed = 64654541

-- 设置种子
function tsrandom.seed(seed)
    _seed = seed
end

-- 返回[min,max]的概率，不传max则为[1,min]
function tsrandom.range(min, max)
    local tn = min
    local tm = max
    if max == nil then
        tn = 1
        tm = min
    end

    _seed = _seed * 1103515245 + 12345
    return _seed % (tm + 1 - tn) + tn -- 返回区间 [n,m) ，如果要返回[n,m]这里要修改一下
end

-- 是否满足概率 probability 0 - 1000
function tsrandom.match(probability)
    if not probability or probability <= 0 then return false end
    if probability >= 1000 then return true end
    local v = tsrandom.range(1, 1000)
    if v <= probability then
        return true
    else
        return false
    end
end

-- 返回1..n的随机数组
function tsrandom.shuffle(n)
    local a = {}
    for i = 1, n do
       a[i] = i
    end
    for i = n, 1, -1 do
        local ridx = tsrandom.range(n)
        local temp = a[ridx]
        a[ridx] = a[i]
        a[i] = temp
    end
    return a
end

-- 从table t中随机选中n个
function tsrandom.select(t, n)
    assert(n <= #t, string.format( "n %s t %s", n, #t))
    local s = tsrandom.shuffle(#t)
    local r = {}
    for i = 1, n do
       table.insert(r, t[s[i]]) 
    end
    return r
end

-- 带权随机 weight_list权重列表，返回weight_list索引，不存在返回-1
function tsrandom.select_weight(weight_list)

    local sum = 0
    local selectidx = -1

    for _, weight in ipairs(weight_list) do
        sum = sum + weight
    end

    local rnd = tsrandom.range(sum)

    local _weight = 0

    for i, weight in ipairs(weight_list) do
        _weight = _weight + weight
        if rnd <= _weight then
            selectidx = i
            break
        end
    end

    return selectidx
end

return tsrandom