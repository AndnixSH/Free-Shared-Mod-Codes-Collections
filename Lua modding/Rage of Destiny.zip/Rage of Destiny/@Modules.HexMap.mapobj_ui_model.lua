
local mapobj_ui_model = mapobj_ui_model or BaseClass(GameObjFactor)
local ui_normal_model = require "Battle.render.model.ui_normal_model"
local prop_refresher = require "Modules.HexMap.prop_refresher"

function mapobj_ui_model:__init(anchor, prefab_id, viewname, bfloat)

    self.anchor = anchor
    self.prop = prop_refresher.new(self)
    self.prefab_id = prefab_id
    self.widget = {}
    self.bfloat = bfloat

    self.model = ui_normal_model.New(anchor, viewname, AssetType.UI, function (gameItemModel)
        gameItemModel:ModelScale(2.5)
        self:loadend(gameItemModel.gameItem)
    end)

end

function mapobj_ui_model:__delete()
    self:release()
end

function mapobj_ui_model:release()
    if self.model then
        self.model:release()
        self.model = nil
    end

    self.anchor = nil
end

function mapobj_ui_model:loadend(obj)
    self.gameobj = obj
    
    local iconspr = self:GetChildComponent(obj, "icon", "CSprite")
    iconspr.SpriteName = self.prefab_id
    self.widget.iconspr = iconspr

    if self.bfloat then
        local rect = self:GetComponent(iconspr, "RectTransform")
        local cury = rect.anchoredPosition.y
        local tween = rect:DOAnchorPosY(cury + 6, 2)
        tween:SetLoops(-1, LoopType.Yoyo)
    end

    prop_refresher.refresh(self.prop)

end

function mapobj_ui_model:_prop_color(color)
    if self.widget.iconspr then
        self.widget.iconspr.color = color
    end
end

function mapobj_ui_model:_prop_alpha(alpha)
end

function mapobj_ui_model:_prop_active(active_name)
end

function mapobj_ui_model:_prop_scale(scaletable)
    if self.gameobj then
        self.gameobj.transform.localScale = Vector3.New(table.unpack(scaletable))
    end 
end


function mapobj_ui_model:_prop_bactive(bactive)
    if self.model then
        if bactive then
            self.model:showmodel()
        else
            self.model:hidemodel()
        end
    end
end

function mapobj_ui_model:_prop_shadow(value)
end

return mapobj_ui_model
