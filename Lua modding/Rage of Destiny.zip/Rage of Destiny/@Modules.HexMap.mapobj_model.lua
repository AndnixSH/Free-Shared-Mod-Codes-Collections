local mapobj_model = BaseClass()

local cMapObjModel = CS.LJY.NX.MapObjModel
local cMaterialPropertyBlock = CS.UnityEngine.MaterialPropertyBlock
local prop_refresher = require "Modules.HexMap.prop_refresher"


function mapobj_model:__init(anchor, prefab_id, asset_type)
    self.prop = prop_refresher.new(self)
    self.anchor = anchor
    self._renderers = {}
    self._block = nil
    self._prefab_id = prefab_id
    self.cmodel = cMapObjModel(self.anchor.canchor)
    self.cmodel:LoadModel(prefab_id, asset_type, function () self:_loadend() end)
end

function mapobj_model:_loadend()
    prop_refresher.refresh(self.prop)
end

function mapobj_model:__delete()
    self:release()
end

function mapobj_model:release()
    if self.cmodel then
        self.cmodel:Release()
        self.cmodel = nil
    end

    if self.anchor then
        self.anchor:DeleteMe()
        self.anchor = nil
    end

    self._renderers = {}

    if self._block then
        self._block:Clear()
    end
    self._block = nil
end

function mapobj_model:_prop_bactive(bactive)
    if bactive then
        self:showmodel()
    else
        self:hidemodel()
    end
end

function mapobj_model:_prop_active(active_name)
    if self.cmodel then
        self.cmodel:StartActive(string.format( "%s_%s",self._prefab_id, active_name))
    end
end

function mapobj_model:_prop_scale(scaletable)
    if self.cmodel and self.cmodel.gameItem then
        self.cmodel.gameItem.transform.localScale = Vector3.New(table.unpack(scaletable))
    end 
end

function mapobj_model:showmodel()
    if self.cmodel then
        self.cmodel:ShowModel()
    end
end

function mapobj_model:hidemodel()
    if self.cmodel then
        self.cmodel:HideModel()
    end
end

function mapobj_model:get_game_object()
    if self.cmodel then
        return self.cmodel.gameItem
    end
end

function mapobj_model:_get_model_renderer(comtype)
    local game_object = self:get_game_object()
    if game_object then
		local renders = GameObjTools.GetComponentsInChildren(game_object, comtype or "MeshRenderer", true)
        self._renderers = renders
		return renders
    end
end

function mapobj_model:_prop_shadow(value)
    local _block = self:_getblock("SkinnedMeshRenderer")

    for _, render in ipairs(self._renderers) do
        _block:Clear()
        render:GetPropertyBlock(_block)
        _block:SetFloat("_ShadowHigh", value)
        render:SetPropertyBlock(_block)
    end
end

function mapobj_model:_getblock(comtype)
    if next(self._renderers) == nil then
        self:_get_model_renderer(comtype)
    end
    if not mapobj_model._block then
        mapobj_model._block = cMaterialPropertyBlock()
    end
    return mapobj_model._block
end

function mapobj_model:_prop_color(color)

    local _block = self:_getblock()

    for _, render in ipairs(self._renderers) do
        _block:Clear()
        render:GetPropertyBlock(_block)
        
        -- _block:SetColor("TintColor", color)
        _block:SetColor("_ColorTint", color)
        -- _block:SetColor("_Color", color)
        render:SetPropertyBlock(_block)
    end
end

function mapobj_model:_prop_alpha(alpha)

    local _block = self:_getblock()

    for _, render in ipairs(self._renderers) do
        _block:Clear()
        render:GetPropertyBlock(_block)
        _block:SetFloat("_MasterAlpha", alpha)
        render:SetPropertyBlock(_block)
    end
end

function mapobj_model:_prop_weight(weight)

    local _block = self:_getblock()

    for _, render in ipairs(self._renderers) do
        _block:Clear()
        render:GetPropertyBlock(_block)
        _block:SetFloat("_2MainTexLerp", weight)
        render:SetPropertyBlock(_block)
    end
end

function mapobj_model:_prop_laser_line(line_infos)

	local renders = self:_get_model_renderer("LineRenderer") or {}
    
    for i = #renders, 1 , -1 do
        local render = renders[i]
        local index = tonumber(render.gameObject.name)
        if index and line_infos[index] and line_infos[index].laser_color_type then
            if tonumber(render.transform.parent.name) ~= line_infos[index].laser_color_type then
                table.remove(renders,i)
                render.enabled = false
            end
        end
    end

	for i, render in ipairs(renders) do
		render.enabled = false
		
		local line_info = line_infos[i]
		if line_info then
			local enabled = line_info.enabled
			render.enabled = enabled
			if enabled then
				local init_position = render:GetPosition(0)
				local position = render:GetPosition(1)
				position.z = math.max(line_info.pixel_distance, init_position.z)
				render:SetPosition(1, position)
			end
            if line_info.custom_dir then
                local target_value = 30 + (line_info.custom_dir - 1) * 60
                local euler_angles = render.gameObject.transform.localEulerAngles
                render.gameObject.transform.localEulerAngles = Vector3.New(euler_angles.x,target_value,euler_angles.z)
            end
		end
	end
end

return mapobj_model