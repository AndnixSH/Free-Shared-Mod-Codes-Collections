local AssetPreloader = {}
local csSeedModel = CS.LJY.NX.SeedModel

local AssetLoaderAdapter = CS.LJY.NX.AssetLoaderAdapter

local load_set = {}
local load_count = 0

-- load:{key,type,count}
function AssetPreloader.AddLoad(load)
    local key = assert(load.key)
    if not load_set[key] then
        load_set[key] = { key = key, type = load.type, count = 0 }
        load_count = load_count + 1
    end
    load_set[key].count = load_set[key].count + (load.count or 1)
end

function AssetPreloader.AddLoadList(load_list)
    for k, v in pairs(load_list) do
        AssetPreloader.AddLoad(v)
    end
end

function AssetPreloader.ClearLoadList()
    load_set = {}
    load_count = 0
end

-- 不会卸载池子其他资源
function AssetPreloader.LoadAppend(callback)
    assert(callback)
    local ScreenShotter = require "Common.Util.ScreenShotter"
    ScreenShotter.Capture(function()
        LuaLayout.Instance:OpenWidget(UIWidgetNameDef.LoadingCommonView)
        local seedList = {}
        for k, load in pairs(load_set) do
            table.insert(seedList, csSeedModel(load.key, load.type, load.count))
        end
        AssetLoaderAdapter.SeedAndReset(seedList, function()
            -- print('load done!')
            LuaLayout.Instance:CloseWidget(UIWidgetNameDef.LoadingCommonView)
            callback()
        end)
        AssetPreloader.ClearLoadList()
    end)
end

function AssetPreloader.Load(callback)
    assert(callback)
    -- print('load->', load_count, table.dump(load_set))
    for k, load in pairs(load_set) do
        AssetLoaderAdapter.SeedModel(load.key, load.type, load.count)
    end
    AssetLoaderAdapter.ResetAll(function()
        -- print('load done!')
        callback()
    end)
    AssetPreloader.ClearLoadList()
end


return AssetPreloader