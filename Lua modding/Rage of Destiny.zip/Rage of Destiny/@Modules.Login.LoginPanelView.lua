local cGameNetWork = CS.LJY.NX.GameNetWork.Instance
local LoginPanelView = BaseClass(GameObjFactor, TimerFactor)
local SdkProxy = require "Modules.Sdk.SdkProxy"
local LoginDef = require "Modules.Login.LoginDef"
local LoginProxy = require "Modules.Login.LoginProxy"
local Application = CS.UnityEngine.Application
local Timer = require "Common.Util.Timer"
local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"

function LoginPanelView:__init(go)
    self.go = go
    self.isshow = false
    self:Init()
end

function LoginPanelView:__delete()
    self.go = nil
end

function LoginPanelView:Init()
    local bg2obj = self:GetChild(self.go, "Bg2")

    self.start1Btn = self:GetChildComponent(bg2obj, "ButtonLayout/startBtn", "CButton")
    self.start1Btn:AddClick(function()
        self:OnClickStartGame()
    end)

    self.start2Btn = self:GetChildComponent(bg2obj, "ButtonLayout/startBtn2", "CButton")
    self.start2Btn:AddClick(function()
        self:OnClickStartAlone()
    end)

    self.gmBtn = self:GetChildComponent(bg2obj, "ButtonLayout/gmBtn", "CButton")
    self.gmBtn:AddClick(function()
         self:OnClickGMGame()
    end)
    
    self.start2Btn.gameObject:SetActive(SystemConfig.is_gm)
    self.gmBtn.gameObject:SetActive(SystemConfig.is_gm)

    local close = self:GetChildComponent(bg2obj, "Close", "CButton")
    close:AddClick(function ()
        self:Close()
    end)

    self.accountInp = self:GetChildComponent(bg2obj, "AcountInp", "CTextInput")
    self.passwordInp = self:GetChildComponent(bg2obj, "PasswordInp", "CTextInput")

    self.isshow = false
    self.go:SetActive(false)    
end

function LoginPanelView:OnClickStartGame()
    AppConfig.ISALONE = false

    if self:CheckAcount() then
        -- LoginProxy.Instance:start_login(self.accountInp.text, self.passwordInp.text)
        
        local part_id = self:GetSocketPartId()
        self:Login(self.accountInp.text, self.passwordInp.text, part_id)
    end
end

function LoginPanelView:OnClickGMGame()
    AppConfig.ISALONE = false
    local uid  = tonumber(self.accountInp.text)
    if uid then
        LoginProxy.Instance:GMLogin(uid)
        --LuaLayout.Instance:GetWidget(UIWidgetNameDef.LoginView):LoginServer()
    else
        GameLogicTools.ShowMsgTips("UID必须为合法数字")
    end
end

function LoginPanelView:OnClickStartAlone()
    AppConfig.ISALONE = true
    
    local SceneManager = require "Modules.Scene.SceneManager"
    local SceneDef = require "Modules.Scene.SceneDef"
    SceneManager.Instance:EnterScene(SceneDef.SceneType.Main)
end

function LoginPanelView:Open()
    self:InitView()
    if LoginProxy.Instance:Is_WLan_Release() then
        LuaLayout.Instance:OpenWidget(UIWidgetNameDef.ReconnectView)
        self.go:SetActive(false)
        self:ClearDelayTimer()
        self.delay_timer = self:AddTimer(function()
            self:AutoLogin()
        end, 1, 1)
    elseif SdkProxy.Instance:isIGGPlatform() then
        
        print("----SdkProxy-----",RoleInfoModel.player_id)
        if RoleInfoModel.severdata  and tonumber(RoleInfoModel.player_id) > 0 and RoleInfoModel.token ~= "" then
            IGGSdkProxy.Instance:Startup()
            LoginProxy.Instance:start_get_account(RoleInfoModel.player_id, RoleInfoModel.token,RoleInfoModel.servertime ,RoleInfoModel.severdata.server_id)
        else
            local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
            IGGSdkProxy.Instance:Quick_Login_Game()
        end
    elseif self.go then
        self.go:SetActive(true)
        self:ClearDelayTimer()
        self.delay_timer = self:AddTimer(function()
            if RoleInfoModel.severdata  and RoleInfoModel.player_id > 0 and RoleInfoModel.token ~= "" then
                LoginProxy.Instance:start_get_account(RoleInfoModel.player_id, RoleInfoModel.token,RoleInfoModel.servertime ,RoleInfoModel.severdata.server_id)
               
            end
        end, 1, 1)
        
    end        
end

function LoginPanelView:ClearDelayTimer()
    if self.delay_timer then
        self:RemoveTimer(self.delay_timer)
        self.delay_timer = nil
    end
end

function LoginPanelView:GetRandomAcount()
    local random_number = math.random(0, 100000)
    local time = os.time()
    local package_id = tonumber(SystemConfig.AgentPackageID)
    local account = package_id + time + random_number
    return account, 123456
end

--模拟自动登陆
function LoginPanelView:AutoLogin()
    if LoginProxy.Instance:Is_WLan_Release() then

        local defaultaccount = PlayerPrefs.GetString(LoginDef.loginAccount)
        local defaultpassword = PlayerPrefs.GetString(LoginDef.loginPassword)

        if string.isEmpty(defaultaccount) and string.isEmpty(defaultpassword) then
            defaultaccount, defaultpassword = self:GetRandomAcount()
        end

        self.accountInp.text = defaultaccount
        self.passwordInp.text = defaultpassword
        PlayerPrefs.SetString(LoginDef.loginAccount, defaultaccount)
        PlayerPrefs.SetString(LoginDef.loginPassword, defaultpassword)
        LoginProxy.Instance:start_login(defaultaccount, defaultpassword)
    end
end

function LoginPanelView:InitView()


    local defaultaccount = PlayerPrefs.GetString(LoginDef.loginAccount)
    local defaultpassword = PlayerPrefs.GetString(LoginDef.loginPassword)

    if not string.isEmpty(defaultaccount) and not string.isEmpty(defaultpassword) then
        self.accountInp.text = defaultaccount
        self.passwordInp.text = defaultpassword
    end
end

function LoginPanelView:Close()
    self.go:SetActive(false)
    self:ClearDelayTimer()
end

function LoginPanelView:Destroy()
    self:ClearDelayTimer()
end

function LoginPanelView:ShowPanelActive()
    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ReconnectView)
    self.go:SetActive(true)
end

function LoginPanelView:Login(account, password, part_id)
    if self.reconnecttimer then
        self.reconnecttimer:Stop()
        self.reconnecttimer = nil
    end

    -- if not cGameNetWork:InNetWork() then
    --     GameLogicTools.ShowConfirmById(1, function(bvalue)
    --         if bvalue then
    --             self.reconnecttimer = Timer.New(function()
    --                 self:Login(account, password)
    --             end, 1, 1)
    --         else
    --             Application.Quit()
    --         end
    --     end)
    --     return
    -- end

    local defaultaccount = account or PlayerPrefs.GetString(LoginDef.loginAccount)
    local defaultpassword = password or PlayerPrefs.GetString(LoginDef.loginPassword)

    if SdkProxy.Instance:isIGGPlatform() then
        -- SdkProxy.Instance:igg_auto_login()

    elseif string.isEmpty(defaultaccount) or string.isEmpty(defaultpassword) then
        self:Open()
    else
        PlayerPrefs.SetString(LoginDef.loginAccount, account)
        PlayerPrefs.SetString(LoginDef.loginPassword, password)
        LoginProxy.Instance:start_login(defaultaccount, defaultpassword, part_id)
    end
end

function LoginPanelView:CheckAcount()
    if string.isEmpty(self.accountInp.text) then
        GameLogicTools.ShowMsgTips("账号不能为空")
        return false
    end

    if string.isEmpty(self.passwordInp.text) then
        self.passwordInp.text = 123456
    end
    return true
end

function LoginPanelView:sdk_login_suc()
    --print("==================>> sdk_login_suc")

    if not isEditor then
        self:Close()
    end

    local defaultaccount = PlayerPrefs.GetString(LoginDef.loginAccount)
    if not string.isEmpty(self.accountInp.text) and defaultaccount ~= self.accountInp.text then
        PlayerPrefs.SetString(LoginDef.loginAccount, self.accountInp.text)
        PlayerPrefs.SetString(LoginDef.loginPassword, self.passwordInp.text)
    end
end

function LoginPanelView:Logout()
    --PlayerPrefs.DeleteKey(LoginDef.loginAccount)
    --PlayerPrefs.DeleteKey(LoginDef.loginPassword)
end

function LoginPanelView:GetSocketPartId()
    local part_id = 1
    local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.LoginView)
    if view and view:IsOpen() then
        part_id = view:GetSocketPanelPartId()
    end
    return part_id
end

return LoginPanelView