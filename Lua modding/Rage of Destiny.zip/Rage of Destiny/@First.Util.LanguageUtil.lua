local cs_coroutine = require "First.Util.cs_coroutine"
local UnityWebRequest = CS.UnityEngine.Networking.UnityWebRequest
local Application = CS.UnityEngine.Application
--local RuntimePlatform = CS.UnityEngine.RuntimePlatform
local PlayerPrefs = CS.UnityEngine.PlayerPrefs
local SystemLanguage = CS.UnityEngine.SystemLanguage
local FileUtils = CS.LJY.NX.FileUtils
local AssetBundle = CS.UnityEngine.AssetBundle
--local AssetBundleCreateRequest = CS.UnityEngine.AssetBundleCreateRequest
local Uri = CS.System.Uri
local cRuntimePlatform = CS.UnityEngine.RuntimePlatform
local AssetLoaderAdapter = CS.LJY.NX.AssetLoaderAdapter

local isEditor = Application.isEditor
local _languageidx = "mx_languageidx"
local _languagedes = "mx_languagedes"
local _languagegameid = "mx_languagegameid"
local _languageDic = {}

local RuntimePlatform = {
    Android = 1,
    IPhonePlayer = 2,
}

local LanguageType ={
    Jianti = 1,
    Fanti = 2,
    English = 3,
    German = 4,
    French = 5,
    Russian = 6,
    Italian = 7,
    Spanish = 8,
    Portuguese = 9,
    Turkish = 10,
    Thai = 11,
    Indonesian = 12,
}

local IGG_GAME_ID = {
    [RuntimePlatform.Android] = {
        [LanguageType.Jianti] = "11181902021", --(简体)
        [LanguageType.Fanti] = "11180202021", --(繁體)
        [LanguageType.English] = "11180102021", --(英语)
        [LanguageType.German] = "11180502021", --(德语)
        [LanguageType.French] = "11180602021", --(法语)
        [LanguageType.Russian] = "11180702021", --(俄语)
        [LanguageType.Italian] = "11181202021", --(意大利语)
        [LanguageType.Spanish] = "11180902021", --(西班牙语)
        [LanguageType.Portuguese] = "11182202021", --(葡萄牙语)
        [LanguageType.Turkish] = "11181602021", --(土耳其语)
        [LanguageType.Thai] = "11181002021", --(泰语)
        [LanguageType.Indonesian] = "11181102021", --(印尼语)
    },
    [RuntimePlatform.IPhonePlayer] = {
        [LanguageType.Jianti] = "11181903031", --(简体)
        [LanguageType.Fanti] = "11180203031", --(繁體)
        [LanguageType.English] = "11180103031", --(英语)
        [LanguageType.German] = "11180503031", --(德语)
        [LanguageType.French] = "11180603031", --(法语)
        [LanguageType.Russian] = "11180703031", --(俄语)
        [LanguageType.Italian] = "11181203031", --(意大利语)
        [LanguageType.Spanish] = "11180903031", --(西班牙语)
        [LanguageType.Portuguese] = "11182203031", --(葡萄牙语)
        [LanguageType.Turkish] = "11181603031", --(土耳其语)
        [LanguageType.Thai] = "11181003031", --(泰语)
        [LanguageType.Indonesian] = "11181103031", --(印尼语)
    },
}

local IGG_AGENTPACKAGE_ID = {
    --Android
    ["11180102021"] = 20001,  --(英语)
    ["11181902021"] = 20002,  --(简体)
    ["11180202021"] = 20003,  --(繁體)
    ["11180502021"] = 20007,  --(德语)
    ["11180602021"] = 20008,  --(法语)
    ["11180702021"] = 20009,  --(俄语)
    ["11181202021"] = 20010,  --(意大利语)
    ["11180902021"] = 20011,  --(西班牙语)
    ["11182202021"] = 20012,  --(葡萄牙语)
    ["11181602021"] = 20013,  --(土耳其语)
    ["11181002021"] = 20014,  --(泰语)
    ["11181102021"] = 20015,  --(印尼语)
    --IPhonePlayer
    ["11180103031"] = 20004,  --(英语)
    ["11181903031"] = 20005,  --(简体)
    ["11180203031"] = 20006,  --(繁體)
    ["11180503031"] = 20016,  --(德语)
    ["11180603031"] = 20017,  --(法语)
    ["11180703031"] = 20018,  --(俄语)
    ["11181203031"] = 20019,  --(意大利语)
    ["11180903031"] = 20020,  --(西班牙语)
    ["11182203031"] = 20021,  --(葡萄牙语)
    ["11181603031"] = 20022,  --(土耳其语)
    ["11181003031"] = 20023,  --(泰语)
    ["11181103031"] = 20024,  --(印尼语)
}

local LanguageDes =
{
    [LanguageType.Jianti] = "Jianti",
    [LanguageType.Fanti] = "Fanti",
    [LanguageType.English] = "English",
    [LanguageType.German] = "German",
    [LanguageType.French] = "French",
    [LanguageType.Russian] = "Russian",
    [LanguageType.Italian] = "Italian",
    [LanguageType.Spanish] = "Spanish",
    [LanguageType.Portuguese] = "Portuguese",
    [LanguageType.Turkish] = "Turkish",
    [LanguageType.Thai] = "Thai",
    [LanguageType.Indonesian] = "Indonesian",
}

local LanguageCode =
{
    [LanguageType.Jianti] = "zh-CN",
    [LanguageType.Fanti] = "zh-TW",
    [LanguageType.English] = "en",
    [LanguageType.German] = "de",
    [LanguageType.French] = "fr",
    [LanguageType.Russian] = "ru",
    [LanguageType.Italian] = "it",
    [LanguageType.Spanish] = "es",
    [LanguageType.Portuguese] = "pt",
    [LanguageType.Turkish] = "tr",
    [LanguageType.Thai] = "th",
    [LanguageType.Indonesian] = "id",


}
local faceBookUrl = {
    [LanguageType.Jianti] = "https://www.facebook.com/RageofDestiny/",
    [LanguageType.Fanti] = "https://www.facebook.com/RageofDestinyTW/",
    [LanguageType.English] = "https://www.facebook.com/RageofDestiny/",
    [LanguageType.German] = "https://www.facebook.com/RageofDestinyDE/",
    [LanguageType.French] = "https://www.facebook.com/RageofDestinyFR/",
    [LanguageType.Russian] = "https://vk.com/rageofdestinyru",
    [LanguageType.Italian] = "https://www.facebook.com/RageofDestinyIT/",
    [LanguageType.Spanish] = "https://www.facebook.com/RageofDestinyES/",
    [LanguageType.Portuguese] = "https://www.facebook.com/RageofDestinyPT/",
    [LanguageType.Turkish] = "https://www.facebook.com/RageofDestinyTR/",
    [LanguageType.Thai] = "https://www.facebook.com/RageofDestinyTH/",
    [LanguageType.Indonesian] = "https://www.facebook.com/RageofDestinyID/",
}

local function _GetLoaclResUrl(resName)
    local abpath = string.format("%s/res/%s.ab", Application.persistentDataPath, string.lower(resName))
    if not FileUtils.FileIsExists(abpath) then
        abpath = string.format("%s/%s.ab", Application.streamingAssetsPath, string.lower(resName))
    end
    if isEditor and not FileUtils.FileIsExists(abpath) then
        print("--------not exist----------",abpath)
        return ""
    end
    return Uri(abpath)
end

local LanguageUtil = {}
function LanguageUtil.Init()
    LanguageUtil.Destroy()
    LanguageUtil.SetAppLanguageInit()
    local idx = LanguageUtil.GetLanguageIdx()
    local abname = string.format("Language/Word/language_%s", idx)
    if isEditor then
        local path = string.format("%s/_Assets/%s.txt", Application.dataPath, abname)
        local content = FileUtils.ReadAllText(path)
        LanguageUtil.InitLanguageDic(content)

        return nil
    else
        local path = _GetLoaclResUrl(abname)
        if path ~= "" then
            return cs_coroutine.start(
                function()
                    local www = UnityWebRequest.Get(path)
                    coroutine.yield(www:SendWebRequest())

                    if www.isNetworkError or www.isHttpError then
                        error(string.format("get error: %s ---- url=%s", www.error, path))
                    else
                        local bundle = AssetBundle.LoadFromMemory(www.downloadHandler.data)
                        if bundle then
                            local objs = bundle:LoadAllAssets()
                            bundle:Unload(false)
                            LanguageUtil.InitLanguageDic(objs[0].text)
                        end
                    end
                    www:Dispose()
                end)
        else
            return nil
        end
        
    end
end

function LanguageUtil.SetAppLanguageInit()
    if not PlayerPrefs.HasKey(_languageidx) then
        local idx = 3
        local str = "English"
        local gameid = "11180102021"
        if SystemConfig.IsOpen12Language then
            if Application.systemLanguage == SystemLanguage.ChineseTraditional then
                idx = LanguageType.Fanti
            elseif Application.systemLanguage == SystemLanguage.ChineseSimplified or Application.systemLanguage == SystemLanguage.Chinese then
                idx = LanguageType.Jianti
            elseif Application.systemLanguage == SystemLanguage.English then
                idx = LanguageType.English
            elseif Application.systemLanguage == SystemLanguage.German then
               idx = LanguageType.German
            elseif Application.systemLanguage == SystemLanguage.French then
               idx = LanguageType.French
            elseif Application.systemLanguage == SystemLanguage.Russian then
               idx = LanguageType.Russian
            elseif Application.systemLanguage == SystemLanguage.Italian then
               idx = LanguageType.Italian
            elseif Application.systemLanguage == SystemLanguage.Spanish then
               idx = LanguageType.Spanish
            elseif Application.systemLanguage == SystemLanguage.Portuguese then
               idx = LanguageType.Portuguese
            elseif Application.systemLanguage == SystemLanguage.Turkish then
               idx = LanguageType.Turkish
            elseif Application.systemLanguage == SystemLanguage.Thai then
               idx = LanguageType.Thai
            elseif Application.systemLanguage == SystemLanguage.Indonesian then
               idx = LanguageType.Indonesian
            else
                idx = LanguageType.English
            end
        else
            if Application.systemLanguage == SystemLanguage.ChineseTraditional then
                idx = LanguageType.Fanti
            elseif Application.systemLanguage == SystemLanguage.ChineseSimplified or Application.systemLanguage == SystemLanguage.Chinese then
                idx = LanguageType.Jianti
            elseif Application.systemLanguage == SystemLanguage.English then
                idx = LanguageType.English
            else
                idx = LanguageType.English
            end
        end
        
        str = LanguageDes[idx] or "English"
        if Application.platform == cRuntimePlatform.Android then
            gameid = IGG_GAME_ID[RuntimePlatform.Android][idx]
        elseif Application.platform == cRuntimePlatform.IPhonePlayer then
            gameid = IGG_GAME_ID[RuntimePlatform.IPhonePlayer][idx]
        end

        PlayerPrefs.SetInt(_languageidx, idx)
        PlayerPrefs.SetString(_languagedes, str)
        PlayerPrefs.SetString(_languagegameid, gameid)
    end
end

function LanguageUtil.GetFaceBookUrl()

    local idx = LanguageUtil.GetLanguageIdx()
    local url = faceBookUrl[idx]
    if url ~= "" then
        return url
    end
end

function LanguageUtil.GetLanguageTraslateCode()
    
    local idx = LanguageUtil.GetLanguageIdx()
    return LanguageCode[idx]
end

function LanguageUtil.GetThaiIdx()
    return LanguageType.Thai
end

function LanguageUtil.GetRussianIdx()
    return LanguageType.Russian
end

function LanguageUtil.GetEnglishIdx()
    return LanguageType.English
end

function LanguageUtil.GetChineseTraditionalIdx()
    return LanguageType.Fanti
end

function LanguageUtil.SetAppLanguageIdx(idx)
    idx = idx or 1
    PlayerPrefs.SetInt(_languageidx, idx)
    PlayerPrefs.SetString(_languagedes, LanguageDes[idx])
    local gameid = LanguageUtil.GetLanguageGameId()
    if Application.platform == cRuntimePlatform.Android then
        gameid = IGG_GAME_ID[RuntimePlatform.Android][idx]
    elseif Application.platform == cRuntimePlatform.IPhonePlayer then
        gameid = IGG_GAME_ID[RuntimePlatform.IPhonePlayer][idx]
    else
        gameid = IGG_GAME_ID[RuntimePlatform.Android][idx]
    end
    if gameid then
        PlayerPrefs.SetString(_languagegameid, gameid)
    end
    print("--------gameid----------",gameid)
end

function LanguageUtil.GetLanguageIdx()
    return PlayerPrefs.GetInt(_languageidx, 1)
end

function LanguageUtil.GetLanguageDes()
    return PlayerPrefs.GetString(_languagedes, "English")
end

--每个语言对应sdk的gameid
function LanguageUtil.GetLanguageGameId()
    local gameid = PlayerPrefs.GetString(_languagegameid)
    if gameid == "999" then
        gameid = "11181902021"
    end
    return gameid
end

function LanguageUtil.GetLanguageIdxStr()
    return _languageidx
end

function LanguageUtil.GetLanguageDesStr()
    return _languagedes
end

function LanguageUtil.GetLanguageGameIdStr()
    return _languagegameid
end

--通过gameid获取AgentPackageID
function LanguageUtil.GetAgentPackageIDByGameId(gameid)
    local _agentPackageID
    if IGG_AGENTPACKAGE_ID[gameid] then
        _agentPackageID = IGG_AGENTPACKAGE_ID[gameid]
    end
    return _agentPackageID
end

function LanguageUtil.Destroy()
end

function LanguageUtil.InitLanguageDic(text)
    _languageDic = {}
    local splitstr = "&&"
    local lines = string.split(text, "\n")
    for _, line in ipairs(lines) do
        local info = string.split(line, splitstr)
        if info and #info == 2 then
            _languageDic[info[1]] = info[2]
        end
    end
end

function LanguageUtil.GetWord(key, ...)
    local state = PlayerPrefs.GetInt("mx_GM_UI", 0)
    if state == 1 then
        return ""
    end
    if _languageDic[key] then
        local str = string.gsub(_languageDic[key], "\\n", "\n")

        if {...} and next({...}) then
            return string.format(str ,...), true
        else
            return str, true
        end
    else
        -- error("language no find key:", key)
        return key, false
    end
end

function LanguageUtil.ChangeLabelFont(label)
    local language_des = LanguageUtil.GetLanguageDes()
    if language_des == "Thai" then
        AssetLoaderAdapter.LoadFont("font_thai", function(target_font)
            label.font = target_font
        end)
    end
end

function LanguageUtil.ChangeOneLabelFont(label)
    AssetLoaderAdapter.LoadFont("font_thai", function(target_font)
        label.font = target_font
    end)
end

function LanguageUtil.TranslateLabel(label)
    local text = label.text

    if not string.isEmpty(text) then
        if string.startswith(text, "#") then
            local key = string.sub(text, 2)
            label.text = LanguageUtil.GetWord(key)
        end
        local state = PlayerPrefs.GetInt("mx_GM_UI", 0)
        if state == 1 then
            label.text = ""
        end
    end
end

function LanguageUtil.TranslateSprite(sprite)
    local atlas = sprite.Atlas
    if atlas and not IsNull(atlas) then
        local atlas_name = atlas.name
        local strs = string.split(atlas_name, "_")
        if #strs >= 2 then
            local module_name, language_flag = strs[1], strs[2]  --Battle_English
            local sprite_name = sprite.SpriteName or ""
            local language_des = LanguageUtil.GetLanguageDes()
            local atlasName = string.format("%s_%s", module_name, language_des)
            local sprite_path = string.format("%s.%s.%s", module_name, atlasName, sprite_name)
            -- print("module_name ====", module_name, language_flag, sprite_name, language_des, sprite_path)
            sprite.Path = sprite_path
        end
    end
end

return LanguageUtil