local BattleProto = require "Core.Implement.Net.BattleProto"

local GuildVersusProxy = GuildVersusProxy or BaseClass(BaseProxy, BattleProto)

function GuildVersusProxy:__init()
	GuildVersusProxy.Instance = self

	self:AddPreBattle(ACTIVITYID.GUILD_VERSUS, self.OnPreBattle) --准备战斗回调
	self:AddSetBattle(ACTIVITYID.GUILD_VERSUS, self.OnSetBattle) --战斗结算回调
	self:AddStartBattle(ACTIVITYID.GUILD_VERSUS, self.OnStartBattle) --战斗开始回调
end

function GuildVersusProxy:__delete()
end

function GuildVersusProxy:OnPreBattle(decoder)
    local heroinfos = self:_DecodeHeroInfo(decoder)
    local enemyinfos = self:_DecodeEnemyInfo(decoder)
    local bufferstr = decoder:Decode("s2")
    -- local enemyid, mainlineid = string.unpack(">I4I4", bufferstr)
    --打开备战界面
    UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 10, ACTIVITYID.GUILD_VERSUS, heroinfos, enemyinfos, "BattleGuildPanel", {})
end

function GuildVersusProxy:OnSetBattle()
end

function GuildVersusProxy:OnStartBattleBuffer(bufferstr, heroinfos, enemyinfos)
    -- print("GuildVersusProxy:OnStartBattleBuffer")
    return {}
end

return GuildVersusProxy