
-- behavior的upadte跟fixeduodate更新管理器

local FrameUpdateMgr = FrameUpdateMgr or {}

local handles = {}

-- local handles_dic = {}

-----------------------
--c#的behaviour所更新的地方
function FrameUpdateMgr.Update(time, deltaTime)
	for i=1,#handles do
		if handles[i] and handles[i].FrameUpdate then
			handles[i]:FrameUpdate(time, deltaTime)
		end	
	end
end

function FrameUpdateMgr.FixedUpdate()
	for i=1,#handles do
		if handles[i] and handles[i].FixedUpdate then
			handles[i]:FixedUpdate()
		end
	end
end

function FrameUpdateMgr.Add( frameUpdate)
	if FrameUpdateMgr.Get(frameUpdate) then
		return
	end
	table.insert( handles , frameUpdate )
end

function FrameUpdateMgr.Remove( frameUpdate)
	local index = FrameUpdateMgr.Get(frameUpdate)
	if index then
		table.remove(handles, index)
	end
end

function FrameUpdateMgr.RemoveAll()
	handles = {}
end

function FrameUpdateMgr.Get( frameUpdate )
	for index,frame in pairs(handles) do
		if frame == frameUpdate then
			return index
		end	
	end
end

return FrameUpdateMgr