local Bezier = Bezier or BaseClass()
function Bezier:__init(from, to, high, pointCount, middlePos)
	self.from = from
	self.to = to
	self.high = high
	self.pointCount = pointCount
	self.middlePos = middlePos

	self.p0 = Vector3.zero
	self.p1 = Vector3.zero
	self.p2 = Vector3.zero
	self.p3 = Vector3.zero

	self.ti = 0
	self.b0 = Vector3.zero
	self.b1 = Vector3.zero
	self.b2 = Vector3.zero
	self.b3 = Vector3.zero

	self.Ax = 0
	self.Ay = 0
	self.Az = 0
	self.Bx = 0
	self.By = 0
	self.Bz = 0
	self.Cx = 0
	self.Cy = 0
	self.Cz = 0
end

function Bezier:SetPosition(v0 , v1 ,v2 ,v3)
	self.p0 = v0
	self.p1 = v1
	self.p2 = v2
	self.p3 = v3
end

function Bezier:SetCallBack(func)
	self.endfunc = func
end

-- 0.0 =< t <= 1.0
function Bezier:GetPointAtTime(t)
    self:CheckConstant()
    local t2 = t * t
    local t3 = t * t * t
    local x = self.Ax * t3 + self.Bx * t2 + self.Cx * t + self.p0.x
    local y = self.Ay * t3 + self.By * t2 + self.Cy * t + self.p0.y
    local z = self.Az * t3 + self.Bz * t2 + self.Cz * t + self.p0.z
    return Vector3.New(x, y, z)
end

function Bezier:CheckConstant()
    if self.p0 ~= self.b0 or self.p1 ~= self.b1 or self.p2 ~= self.b2 or self.p3 ~= self.b3 then
        self:SetConstant()
        self.b0 = self.p0
        self.b1 = self.p1
        self.b2 = self.p2
        self.b3 = self.p3
    end
end

function Bezier:SetConstant()
        -- self.Cx = 3 * (self.p1.x - self.p0.x)
        -- self.Bx = 3 * (self.p2.x - self.p1.x) - self.Cx
        -- self.Ax = self.p3.x - self.p0.x - self.Cx - self.Bx
        -- self.Cy = 3 * (self.p1.y - self.p0.y)
        -- self.By = 3 * (self.p2.y - self.p1.y) - self.Cy
        -- self.Ay = self.p3.y - self.p0.y - self.Cy - self.By
        -- self.Cz = 3 * (self.p1.z - self.p0.z)
        -- self.Bz = 3 * (self.p2.z - self.p1.z) - self.Cz
        -- self.Az = self.p3.z - self.p0.z - self.Cz - self.Bz

        self.Cx = 3 * ((self.p0.x+self.p1.x) - self.p0.x)
        self.Bx = 3 * ((self.p3.x+self.p2.x) - (self.p0.x+self.p1.x)) - self.Cx
        self.Ax = self.p3.x - self.p0.x - self.Cx - self.Bx
        self.Cy = 3 * ((self.p0.y+self.p1.y) - self.p0.y)
        self.By = 3 * ((self.p3.y+self.p2.y) - (self.p0.y+self.p1.y)) - self.Cy
        self.Ay = self.p3.y - self.p0.y - self.Cy - self.By
        self.Cz = 3 * ((self.p0.z+self.p1.z) - self.p0.z)
        self.Bz = 3 * ((self.p3.z+self.p2.z) - (self.p0.z+self.p1.z)) - self.Cz
        self.Az = self.p3.z - self.p0.z - self.Cz - self.Bz
end

function Bezier:CurvePath()
	-- local k = 1
	-- if (self.from.y - self.to.y) ~= 0 and (self.from.x - self.to.x) ~= 0 then
	-- 	k = (-1) / ((self.from.y - self.to.y) / (self.from.x - self.to.x))
	-- end	

	-- local centrePos = Vector3.New((self.from.x + self.to.x) / 2, (self.from.y + self.to.y) / 2, 0)
	-- local midpoint = Vector3.zero
	-- midpoint.x = self.high / math.sqrt((1 + k * k))
	-- if self.high > 0 then 
	-- 	midpoint.x = (centrePos.x - midpoint.x > centrePos.x + midpoint.x ) and centrePos.x - midpoint.x or centrePos.x + midpoint.x
	-- else
	--  	midpoint.x = (centrePos.x - midpoint.x < centrePos.x + midpoint.x ) and centrePos.x - midpoint.x or centrePos.x + midpoint.x
	-- end	
	-- midpoint.y = centrePos.y - k * (centrePos.x - midpoint.x)

	local midpoint = Vector3.New((self.to.x + self.from.x) / 2 , self.high ,(self.to.z + self.from.z) / 2)
	if self.middlePos then
		self:SetPosition(self.from, self.middlePos, Vector3.zero, self.to)
	else
		self:SetPosition(self.from, midpoint, midpoint, self.to)
	end

	local pathList = {}
	for i = 1, self.pointCount do
        local vec = self:GetPointAtTime(i * (1 / self.pointCount))
        table.insert(pathList ,vec)        		
	end	
    return pathList
end

local TweenTools = {}
TweenTools.GameUIUtil = CS.GameUIUtil
function TweenTools.GetBezierPath(from, to, high, pointCount, middlePos)
	local bezier = Bezier.New(from, to, high, pointCount, middlePos)
	return bezier:CurvePath()
end

--左右摇晃 time 多久一次 (渐变抖动)
function TweenTools.ShakeObj(obj, time, delay, isloop, interval,vec3)
	vec3 = vec3 or Vector3.New(0,0,10)
	interval = interval or 1
	delay = delay or 0
	if isloop == nil then isloop = true end
	time = time or 2
	local tween = obj.transform:DOShakeRotation(time, vec3, 20, 180)
	local sequence = DOTween.Sequence()
	if delay > 0 then
		sequence:AppendInterval(delay)
	end	
	sequence:Append(tween)
	sequence:AppendInterval(interval)

	if isloop then
		sequence:SetLoops(-1)
	end	
	return sequence
end

--左右摇晃 time 多久一次 (匀速抖动)
function TweenTools.NormalShakeObj(obj, time, delay, isloop, angles)
	angles = angles or 5
	time = time or 0.1
	delay = delay or 0
	obj.transform.eulerAngles = Vector3.zero

	local sequence = DOTween.Sequence()
	local tween = obj.transform:DOLocalRotate(Vector3.New(0 ,0 ,angles) ,time)  
	sequence:Append(tween)	

	for i=1,8 do
		local idx = math.fmod(i , 2)
		idx = idx == 0 and -1 or 1
		local tween = obj.transform:DOLocalRotate(Vector3.New(0 ,0 ,angles * idx * 2) ,time)  
		sequence:Append(tween)
	end	

	local tween = obj.transform:DOLocalRotate(Vector3.New(0, 0, 0) ,0.1)  
	sequence:Append(tween)	
	if delay > 0 then
		sequence:AppendInterval(delay)
	end	
	
	if isloop then
		sequence:SetLoops(-1)
	end
	return sequence	
end

--抖动 time 多久一次
function TweenTools.ShakePosition(obj, time, vec, isloop, initpos, delay)
	delay = delay or 0
	initpos = initpos or obj.transform.position
	obj.transform.position = initpos
	if isloop == nil then isloop = true end
	time = time or 2
	local tween = obj.transform:DOShakePosition(time, vec, 20)
	local sequence = DOTween.Sequence()
	if delay > 0 then
		sequence:AppendInterval(delay)
	end		
	sequence:Append(tween)
	sequence:AppendCallback(function ()
		obj.transform.position = initpos
	end)	
	-- sequence:AppendInterval(1)
		
	if isloop then
		sequence:SetLoops(-1)
	end
	return sequence
end

--上下移動
function TweenTools.TopShakeObj(obj, time, delay, isloop, angles, upcount)
	angles = angles or 1
	time = time or 0.3
	delay = delay or 0
	upcount = upcount or 8
	local hight = obj.transform.localPosition.y

	local sequence = DOTween.Sequence()
	if delay > 0 then
		sequence:AppendInterval(delay)
	end	
	local tween = obj.transform:DOLocalMoveY(hight + angles, time / 2)  
	sequence:Append(tween)	

	for i=1,upcount do
		local idx = math.fmod(i , 2)
		idx = idx == 0 and -1 or 1
		local tween = obj.transform:DOLocalMoveY(hight + angles * idx * 2, time)  
		sequence:Append(tween)
	end	

	local tween = obj.transform:DOLocalMoveY(hight, time / 2)  
	sequence:Append(tween)	
	-- sequence:AppendInterval(1)

	if isloop then
		sequence:SetLoops(-1)
	end
	return sequence	
end

--透明度 呼吸灯
function TweenTools.TransparentAlpha(obj, time, from, to)
	if not obj then
		print("TransparentAlpha is nil:", debug.traceback())
		return 
	end
	local GameUIUtil = TweenTools.GameUIUtil
	time = time or 1
	from = from or 0
	to = to or 1
	GameUIUtil.SetGroupAlpha(obj, from)
	local sequence = DOTween.Sequence()
	sequence:AppendCallback(function ()
			if GameObjTools.ObjIsNull(obj) then
				sequence:Kill()
			else
				GameUIUtil.SetGroupAlphaInTime(obj ,to ,time)
			end	
		
		end)		
	sequence:AppendInterval(time)
	sequence:AppendCallback(function ()
			if GameObjTools.ObjIsNull(obj) then
				sequence:Kill()
			else
				GameUIUtil.SetGroupAlphaInTime(obj ,from ,time)		
			end			
		
		end)	
	sequence:AppendInterval(time)
	sequence:SetLoops(-1)			
	return sequence
end

--颜色呼吸灯 obj需要支持docolor
function TweenTools.TransparentColor(obj, fromcolor, tocolor, time)
	time = time or 1
	obj.color = fromcolor
	local tween1 = obj:DOColor(tocolor, 1)
	local tween2 = obj:DOColor(fromcolor, 1)

	local sequence = DOTween.Sequence()
	sequence:Append(tween1)
	sequence:Append(tween2)	
	sequence:AppendInterval(time)
	sequence:SetLoops(-1)			
	return sequence	
end

local BattleTipTweenCfg = 
{
	{ method = "DOScale", to = Vector3.one * 1.2, duration = 0.5, ease = Ease.OutBounce },
	{ method = "DOScale", to = Vector3.zero, duration = 0.3, delay = 1.5 },
}

function TweenTools.ShowBattleTip(tipObj, tip1, tip2)
	TweenTools.DoSequence(tipObj.transform, BattleTipTweenCfg)
	local camplbl = GameObjTools.GetChildComponent(tipObj, "COutline_Team", "CLabel")
	camplbl.text = tip1

	local tiplbl = GameObjTools.GetChildComponent(tipObj, "COutline_Text", "CLabel")
	tiplbl.text = tip2
end

--FillAmount 动画  
--count 跑满次数, badd 增加还是减小
--addoption = { count, badd , func, delay}
function TweenTools.SldTween(csprite, from, to, time, addoption)
	time = time or 0.2
	csprite.fillAmount = from
	if addoption then
		if addoption.count and addoption.count > 0 then
			local sequence = DOTween.Sequence()
			for i = 1, addoption.count do			
				local tween = csprite:DOFillAmount(addoption.badd and 1 or 0, time)
				sequence:Append(tween)			
				sequence:AppendCallback(function ()
						csprite.fillAmount = addoption.badd and 0 or 1
						if addoption.func then
							addoption.func()
						end	
					end)
				sequence:AppendInterval(addoption.delay or 0.1)		
			end
			local tween = csprite:DOFillAmount(to, time)
			sequence:Append(tween)
		end 
	else
		csprite:DOFillAmount(to, time)
	end	
end

--addoption :{startnum , count, func, infos={{time=0.5, moveto, badd:1:0:2}} }
function TweenTools.CSldTween(csld, addoption)
	time = time or 0.2	
	local sequence = DOTween.Sequence()
	if addoption and addoption.infos then
		if addoption.count and addoption.count > 0 then
			for i=1,addoption.count do
				local moveto = math.min(addoption.infos[i].moveto, 1)
				local tween = csld:DOValue(moveto, addoption.infos[i].time)
				tween:SetEase(Ease.Linear)
				sequence:Append(tween)
				sequence:AppendCallback(function()
					if addoption.func then
						if addoption.infos[i].badd then
							addoption.func(i, addoption.infos[i].badd)
						end
					end
				end)
				sequence:AppendInterval(0.05)
			end
		end
	end
	return sequence
end

--放大后缩小 scale 放大倍数, interval 放大后延迟缩小时间 ; time放大和缩小时间;  bzero：是否先缩小在播放动画
function TweenTools.ScaleTween(obj, scale, interval, time, bzero)
	time = time or 0.5
	scale = scale or 1.5
	if bzero then
		obj.transform.localScale = Vector3.zero
	end	
	local sequence = DOTween.Sequence()
	local tween1 = obj.transform:DOScale(Vector3.New(scale, scale, scale) ,time)	
	tween1:SetEase(Ease.OutBack)
	local tween2 = obj.transform:DOScale(Vector3.one ,time)
	tween2:SetEase(Ease.OutBack)

	sequence:Append(tween1)
	if interval then
		sequence:AppendInterval(interval)
	end	
	sequence:Append(tween2)	
	return sequence
end

--简单放大time1 放大时间 , time2 缩小时间 , 循环间隔 , 循环次数
function TweenTools.SimpleScaleTween(obj, scale, time1, time2, loopInterval, loops)
	time1 = time1 or 0.1
	time2 = time2 or 0.1
	local sequence = DOTween.Sequence()
	local tween1 = obj.transform:DOScale(Vector3.New(scale ,scale ,scale), time1)
	local tween2 = obj.transform:DOScale(Vector3.one, time2)
	tween1:SetEase(Ease.InBack)
	tween2:SetEase(Ease.OutBack)
	
	sequence:Append(tween1)
	sequence:Append(tween2)	

	if loopInterval then
		sequence:AppendInterval(loopInterval)
		sequence:SetLoops(loops or -1)
	end

	return sequence
end


function TweenTools.DoSequence(target, args)

	local sequence = DOTween.Sequence()

	for i, tw in ipairs(args) do
		if tw.delay then
			sequence:AppendInterval(tw.delay)
		end
		sequence:Append(TweenTools.DoTween(target, tw))
	end

	return sequence

end

function TweenTools.DoTween(target, args)

	local target_component = args.component and target[args.component] or target
	local tween = target_component[args.method](target_component, args.to, args.duration)
	if args.ease then
		tween:SetEase(args.ease)
	end
	return tween
end

--获得物品然后飞过去的动画
function TweenTools.ShowGetIconFlyTween(icon, list, frompos, topos, num, func)
	local GameUIUtil = TweenTools.GameUIUtil

	local itemList = {}
	for _,obj in pairs(list) do
		if not obj.activeSelf and #itemList < num then
			table.insert(itemList, obj)
		end	
	end

	if #itemList < num then
		for i = 1, num - #itemList do
			local obj = GameObjTools.AddChild(icon.transform.parent, icon)
			table.insert(itemList, obj)
			table.insert(list, obj)
		end
	end
	
	local sequencelist = {}
	local delay = 0.02
	local vec = Vector2.New(1.3,1.3)
	local vec2 = Vector3.New(0, 5, 0)
	math.randomseed(os.time())
	for idx,obj in pairs(itemList) do
		obj.transform.position = frompos
		obj.transform.localScale = vec
		GameUIUtil.SetGroupAlpha(obj ,0)
		obj:SetActive(true)

		local sequence = DOTween.Sequence()
		sequence:AppendInterval(idx * delay)

		local x,y = 0,0
		if (math.random(1, 2) == 1) then
			x = math.random(60, 120)
			y = math.random(0, 120)
		else
			x = math.random(0, 120)
			y = math.random(60, 120)		
		end	
		x = (math.random(1, 2)) == 1 and x or -x
		y = (math.random(1, 2)) == 1 and y or -y

		--随机发散
		sequence:AppendCallback(function ()
			GameUIUtil.SetGroupAlphaInTime(obj ,1 ,0.5)
			end)
		local tween1 = obj.transform:DOLocalMove(obj.transform.localPosition + Vector2.New(x,y), 0.4)		
		sequence:Append(tween1)
		sequence:AppendInterval(0.5)

		--移动到目的
		local tween2 = obj.transform:DOMove(topos, 0.6)
		sequence:Append(tween2)

		--缩放
		local tween3 = obj.transform:DOScale(Vector3.one, 0.2)
		sequence:Append(tween3)

		sequence:AppendCallback(function ()
			obj:SetActive(false)	

			if func then
				func(idx, num)
			end	
		end)	

		table.insert(sequencelist, sequence)
	end
	return sequencelist
end


--获得物品然后飞过去的动画goodsDatalist:{{222333, 1}}
function TweenTools.ShowGetGoodsIconFlyTween(icon, goodsDatalist, objList, goodsClassList, frompos, topos, func, sequencelist)
	local GoodsItem = require "Core.Implement.UI.Class.GoodsItem"
	local GameUIUtil = TweenTools.GameUIUtil

	local itemList = {}
	for i,obj in ipairs(objList) do
		if not obj.activeSelf and #itemList < #goodsDatalist then
			table.insert(itemList, obj)
			if goodsClassList[i] then
				goodsClassList[i]:SetData(goodsDatalist[#itemList][1], goodsDatalist[#itemList][2])
			end
		end	
	end

	if #itemList < #goodsDatalist then
		for i = 1, #goodsDatalist - #itemList do
			local obj = GameObjTools.AddChild(icon.transform.parent, icon)
			table.insert(itemList, obj)
			table.insert(objList, obj)
			local goodsItemClass = GoodsItem.New(obj)
			goodsItemClass:SetData(goodsDatalist[#itemList][1], goodsDatalist[#itemList][2])
			table.insert(goodsClassList, goodsItemClass)
		end
	end	

	sequencelist = sequencelist or {}

	local delay = 0.1
	local vec = Vector3.New(1, 1, 1)
	local toVect = Vector3.New(0.5, 0.5, 0.5)
	local offset_point = Vector3.New(0,0,0)
	local defaultPos = Vector3.New(0,0,0)
	if itemList[1] then
		itemList[1].transform.position = frompos
		local locPos = itemList[1].transform.localPosition
		defaultPos = Vector3.New(locPos.x+200, locPos.y-100, 0)
		offset_point = Vector3.New(locPos.x, locPos.y, 0)
	end

	math.randomseed(os.time())
	for idx,obj in ipairs(itemList) do
		obj.transform.localPosition = defaultPos
		obj.transform.localScale = vec
		GameUIUtil.SetGroupAlpha(obj ,0)
		obj:SetActive(true)

		local sequence = DOTween.Sequence()
		sequence:AppendInterval(idx * delay)		

		local x,y = 0,0
		local t1, t2 = math.modf(idx/2)
		local offset_x, offset_y = 0, 0 
		if (math.random(1, 2) == 1) then
			offset_x = math.random(150, 250)
			offset_y = math.random(40, 80)
		else
			offset_x = math.random(80, 200)
			offset_y = math.random(20, 80)		
		end	

		if t2 == 0 then
			y = offset_y
			defaultPos = defaultPos + Vector3.New(-30, -20)
		else
			y = -offset_y
		end
		x = - offset_x
		local pos = Vector3.New(defaultPos.x+x, defaultPos.y+y, 0)
		obj.transform.localPosition = pos

		--随机发散
		sequence:AppendCallback(function ()
			GameUIUtil.SetGroupAlpha(obj, 1)
		end)

		--移动到目的
		local tween2 = obj.transform:DOMove(topos, 1)
		tween2:SetEase(Ease.InSine)
		sequence:Append(tween2)

		--缩放
		local tween3 = obj.transform:DOScale(toVect, 1)
		local insertTime = idx * delay
		sequence:Insert(insertTime, tween3)

		sequence:AppendCallback(function ()
			obj:SetActive(false)	

			if func then
				func(idx, #goodsDatalist)
			end	

		end)	
		table.insert(sequencelist, sequence)
	end
end

--获得物品然后飞过去的动画goodsDatalist:{{222333, 1}}
function TweenTools.ShowGetGoodsIconFlyTween2(icon, goodsDatalist, objList, goodsClassList, frompos, topos, func, sequencelist)
	local GoodsItem = require "Core.Implement.UI.Class.GoodsItem"
	local GameUIUtil = TweenTools.GameUIUtil

	local itemList = {}
	for i,obj in ipairs(objList) do
		if not obj.activeSelf and #itemList < #goodsDatalist then
			table.insert(itemList, obj)
			if goodsClassList[i] then
				goodsClassList[i]:SetData(goodsDatalist[#itemList][1], goodsDatalist[#itemList][2])
			end
		end	
	end
	
	if #itemList < #goodsDatalist then
		for i = 1, #goodsDatalist - #itemList do
			local obj = GameObjTools.AddChild(icon.transform.parent, icon)
			table.insert(itemList, obj)
			table.insert(objList, obj)
			local goodsItemClass = GoodsItem.New(obj)
			goodsItemClass:SetData(goodsDatalist[#itemList][1], goodsDatalist[#itemList][2])
			table.insert(goodsClassList, goodsItemClass)
		end
	end	

	sequencelist = sequencelist or {}

	local delay = 0.1
	local vec = Vector3.New(1, 1, 1)
	local toVect = Vector3.New(0.5, 0.5, 0.5)
	local offset_point = Vector3.New(0,0,0)
	local defaultPos = Vector3.New(0,0,0)
	if frompos then
		defaultPos = Vector3.New(frompos.x, frompos.y, 0)
	end

	math.randomseed(os.time())
	for idx,obj in ipairs(itemList) do
		obj.transform.localPosition = defaultPos
		obj.transform.localScale = vec
		GameUIUtil.SetGroupAlpha(obj ,0)
		obj:SetActive(true)

		local sequence = DOTween.Sequence()
		sequence:AppendInterval(idx * delay)		

		obj.transform.localPosition = defaultPos

		--随机发散
		sequence:AppendCallback(function ()
			GameUIUtil.SetGroupAlpha(obj, 1)
		end)

		--移动到目的
		local tween2 = obj.transform:DOMove(topos, 1)
		tween2:SetEase(Ease.InSine)
		sequence:Append(tween2)

		--缩放
		local tween3 = obj.transform:DOScale(toVect, 1)
		local insertTime = idx * delay
		sequence:Insert(insertTime, tween3)

		sequence:AppendCallback(function ()
			obj:SetActive(false)	

			if func then
				func(idx, #goodsDatalist)
			end	

		end)	
		table.insert(sequencelist, sequence)
	end
end


--获得物品然后飞过去的动画 goods_count:金币数量超过5万分开两个点飞
function TweenTools.ShowCoinIconFlyTween(icon, list, frompos, topos, num, func, goods_count)
	local GameUIUtil = TweenTools.GameUIUtil

	local totalCount = num
	if goods_count then
		if goods_count >= 50000 then
			totalCount = num + num
		end
	end

	local itemList = {}
	for _,obj in pairs(list) do
		if not obj.activeSelf and #itemList < totalCount then
			table.insert(itemList, obj)
		end	
	end

	if #itemList < totalCount then
		for i = 1, totalCount - #itemList do
			local obj = GameObjTools.AddChild(icon.transform.parent, icon)
			table.insert(itemList, obj)
			table.insert(list, obj)
		end
	end	

	local sequencelist = {}
	local delay = 0.02
	local vec = Vector2.New(1.3,1.3)
	local vec2 = Vector3.New(0, 5, 0)

	local firstPos = Vector3.New(0,0,0)
	local secondPos = Vector3.New(0, 0, 0)
	local endPos = Vector3.New(0,0,0)
	local secondFromPos = Vector3.New(0,0,0)
	if itemList[1] then
		itemList[1].transform.position = frompos
		firstPos = itemList[1].transform.localPosition
		itemList[1].transform.position = topos
		endPos = itemList[1].transform.localPosition
		secondPos = firstPos + Vector3.New(-180, -130, 0)
		
	end

	local total_time = 0

	local path_points = 15
	local path_point_time = 0.1

	local index = 0
	math.randomseed(os.time())

	local _between_time = 0
	--计算出本次图标运动时间
	for idx,obj in ipairs(itemList) do

		if idx == num + 1 then
			index = 1
		else
			index = index + 1
		end

		_between_time = index * delay
		if idx > num then
			_between_time = index * delay + 0.5
		end
	end

	total_time = _between_time

	index = 0
	for idx,obj in ipairs(itemList) do

		local random_offset = math.random(1,4)
		local _width, _height = 10, 15
		local _offset_x, _offset_y = 0, 0
		if random_offset == 1 then
			_offset_x = math.random(1, _width)
			_offset_y = math.random(1, _height)
		elseif random_offset == 2 then
			_offset_x = math.random(1, _width)
			_offset_y = math.random(1, _height)
			_offset_y = - _offset_y
		elseif random_offset == 3 then
			_offset_x = math.random(1, _width)
			_offset_y = math.random(1, _height)
			_offset_x = - _offset_x
			_offset_y = -_offset_y
		elseif random_offset == 4 then
			_offset_x = math.random(1, _width)
			_offset_y = math.random(1, _height)
			_offset_x = -_offset_x
		end
		firstPos = firstPos + Vector3.New(_offset_x, _offset_y, 0)
		secondPos = secondPos + Vector3.New(_offset_x, _offset_y, 0)

		obj.transform.localPosition = firstPos
		obj.transform.localScale = vec
		GameUIUtil.SetGroupAlpha(obj ,0)
		obj:SetActive(true)

		if idx == num + 1 then
			index = 1
		else
			index = index + 1
		end

		local x = 0
		local y = 0
		local pos_From = firstPos
		local between_time = index * delay
		if idx > num then
			obj.transform.localPosition = secondPos
			pos_From = secondPos
			between_time = index * delay + 0.5
		end

		local randomIdx = math.random(1,4)
		if randomIdx == 1 then
			x = math.random(50, 150)
			y = math.random(50, 100)
		elseif randomIdx == 2 then
			x = math.random(150, 250)
			y = math.random(100, 150)
		elseif randomIdx == 3 then
			x = math.random(250, 350)
			y = math.random(50, 200)
		elseif randomIdx == 4 then
			x = math.random(350, 500)
			y = math.random(100, 250)
		end

		local sequence = DOTween.Sequence()
		sequence:AppendInterval(between_time)

		--随机发散
		sequence:AppendCallback(function ()
			GameUIUtil.SetGroupAlpha(obj ,1)
			end)

		local pathList
		local t1, t2 = math.modf(index/2)

		if t2 == 0 then
			pathList = TweenTools.GetBezierPath(pos_From, endPos, 0.5, path_points, Vector3.New(x, y, 0))
		else
			pathList = TweenTools.GetBezierPath(pos_From, endPos, 0.5, path_points, Vector3.New(-x, -y, 0))
		end
		--Vector3.New(250, 250, 0)  Vector3.New(-250, -250, 0)
		for i,vec3 in ipairs(pathList) do
			local tween2 = obj.transform:DOLocalMove(vec3, path_point_time)
			tween2:SetEase(Ease.Linear)
			sequence:Append(tween2)
		end

		--缩放
		local tween3 = obj.transform:DOScale(Vector3.one, 0.2)
		sequence:Append(tween3)

		sequence:AppendCallback(function ()
			obj:SetActive(false)	

			if func then
				func(idx, num, totalCount, total_time)
			end	
			end)	

		table.insert(sequencelist, sequence)
	end

	return sequencelist, total_time
end


function TweenTools.ShowUpDownTween(obj, fromposY, toposY, time, loopInterval, loops)
	time = time or 0.5
	local sequence = DOTween.Sequence()
	local tween1 = obj.transform:DOLocalMoveY(toposY, time)
	local tween2 = obj.transform:DOLocalMoveY(fromposY, time)
	sequence:Append(tween1)
	sequence:Append(tween2)	

	if loopInterval then
		sequence:AppendInterval(loopInterval)
	end
	sequence:SetLoops(loops or -1)

	return sequence

end

function TweenTools.OpenStretchTween(obj, fromScale, toScale, time, func, bopen)
	local AudioManager = require "Common.Mgr.Audio.AudioManager"
	local sequence = DOTween.Sequence()
	local fromScale = fromScale or Vector3.New(0, 1, 1)
	local toScale = toScale or Vector3.New(1, 1, 1)
	local time = time or 0.2
	local soundName = ""
	if bopen ~= nil then
		soundName = bopen == true and "view_open" or "view_close"
		AudioManager.PlaySoundByKey(soundName)
	end
	obj:SetActive(true)
	obj.transform.localScale = fromScale
	local tween = obj.transform:DOScale(toScale, time)
	sequence:Append(tween)
	sequence:AppendCallback(function()
		if func then
			func()
		end
	end)
	return sequence
end

--duration 毫秒
function TweenTools.ValueTween(from, to, duration, func, ...)
    local Timer = require "Common.Util.Timer"

    local i = 0
    local ti = 50
    local n = math.floor(duration / ti)
    local a = {...}
    local t = Timer.New(function()
        i = i + 1
        local v = from + (to - from) * (i / n)
        func(v, table.unpack(a))
    end, ti / 1000, n)
    t:Start()
    return t
end

return TweenTools