
local render_area = {global_speed = 1, is_show = true}

local view_manager = require "Battle.render.view_manager"
local render_camera = require "Battle.render.camera.render_camera"

--local bone_skill_anchor = require "Battle.render.anchor.bone_skill_anchor"
--local effect_sprite_model = require "Battle.render.model.effect_sprite_model"

local cRenderAreaAdapt = CS.LJY.NX.RenderAreaAdapt
--local cGameModelPool = CS.LJY.NX.GameModelPool

function render_area.initialize()
    view_manager.initialize()
    render_area._onaddlistener()
end

function render_area.setenable(enable)
    view_manager.show_actor = enable
    view_manager.show_active = enable
end

function render_area.start(gameinfo)
    render_area.setenable(GameConfig.RENDER_ENABLE)
    view_manager.start_game(gameinfo)
end

function render_area.reset()
    view_manager.resume()
    render_camera.resume()
    render_area.global_speed = 1
end

function render_area.destroy()
    render_area.reset()
    --print("--------------------->>>render_area.destroy<<<---------------------")
    render_camera.enable_3d_camera(true)
    view_manager.removeall()
    render_camera.destroy_fadeIn_component()
    render_camera.destroy_effect_camera()
    cRenderAreaAdapt.Destroy()
end

function render_area.dispose()
    --local SceneConstruct = require "Modules.Scene.SceneConstruct"
    render_camera.set_camera_background_color(0, 0, 0, 0)
    SceneConstruct.CleanAllScene()

    local SceneManager = require "Modules.Scene.SceneManager"
    SceneManager.Instance:UnLoadAllScene()
end

function render_area.speed(speed_rate)
    render_area.global_speed = speed_rate
    render_camera.speed(speed_rate)
    view_manager.speed(speed_rate)
end

function render_area.show()
    if render_area.is_show then
        return
    end
    --view_manager.showall()
    render_area.is_show = true
    --print("--------------------->>>render_area.show<<<---------------------")
    render_camera.enable_3d_camera(true)
end

function render_area.hide()
    if not render_area.is_show then
        return
    end
    --view_manager.hideall()
    render_area.is_show = false
    --print("--------------------->>>render_area.hide<<<---------------------")
    render_camera.enable_3d_camera(false)
end

---@param reason table @{spriteid = 放大招的player}
function render_area.pause(reason)
    if reason and reason.spriteid then
        view_manager.pause(reason)
        render_camera.create_effect_camera()
        -- set player layer
        for _, spriteid in ipairs(reason.spriteid) do
            local player_view = view_manager.getsprite(spriteid)
            if player_view then
                player_view:set_layer(LAYERS.EFFECT)
            end
        end
        -- add main camera fade in component
        render_camera.add_fadeIn_component(reason.duration / render_area.global_speed)
    else
        view_manager.pause()
        --render_camera.pause()
    end
end

---@param reason table @{spriteid = 放大招的player}
function render_area.resume(reason)
    if reason and reason.spriteid then
        view_manager.resume(reason)
        --render_camera.resume()
        -- resume player layer
        for _, spriteid in ipairs(reason.spriteid) do
            local player_view = view_manager.getsprite(spriteid)
            if player_view then
                player_view:reset_layer()
            end
        end
        -- disable main camera fade in component
        render_camera.disable_fadeIn_component()

    else
        view_manager.resume()
        --render_camera.resume()
    end
end

function render_area._onaddlistener()
    cRenderAreaAdapt.Initialize(function(handle, spriteid, spritetype)
        if handle == 0 then
            view_manager.onremovesprite(spriteid, spritetype)
        elseif handle == 1 then
            view_manager.onaddsprite(spriteid, spritetype)
        end
    end)
end

function render_area.setmodelactive(bactive)
    cRenderAreaAdapt.SetModelRootAcitve(bactive)
end

return render_area