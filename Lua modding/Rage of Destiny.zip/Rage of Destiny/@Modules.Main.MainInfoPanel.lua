local HeroProxy = require "Modules.Hero.HeroProxy"
local RoleInfoProxy = require "Modules.RoleInfo.RoleInfoProxy"
local HeadItem = require "Core.Implement.UI.Class.HeadItem"
local MainInfoPanel = MainInfoPanel or BaseClass(GameObjFactor, TimerFactor)
function MainInfoPanel:__init(go)
	self.go = go
	self:Load(go)	
end
function MainInfoPanel:Load(obj)
	self.rect = self:GetComponent(obj, "RectTransform")
	self.rectPosition = self.rect.anchoredPosition

	self.btn = self:GetChildComponent(obj, "Headitem/power", "CButton")
	self.btn:AddClick(function ()
		GameLogicTools.ShowLabelTips("unity_tips_1006", self.btn.transform.position)
	end)

	self.expbtn = self:GetChildComponent(obj, "back_exp", "CButton")
	self.expbtn:AddClick(function ()
		local maxexp=RoleInfoProxy.Instance:GetCurrentLevelMaxPlayerExp(RoleInfoModel.level,RoleInfoModel.player_exp)
		local currentexp=RoleInfoProxy.Instance:GetCurrentLevelPlayerExp(RoleInfoModel.level,RoleInfoModel.player_exp)
		local str=tostring(currentexp)
		local str2=tostring(maxexp)
		local str3=tostring(RoleInfoModel.level)
		if maxexp >= 100000 then
			GameLogicTools.ShowLabelTipsAjustWidth("unity_tips_1005", self.expbtn.transform.position,nil,328,str3.."\n",str,str2.."\n\n")
		else
			GameLogicTools.ShowLabelTips("unity_tips_1005", self.expbtn.transform.position,nil, false, str3.."\n",str,str2.."\n\n")
		end
		
	end)
	
	self.headItem = HeadItem.New(self:GetChild(obj, "Headitem"))
	self.headItem:SetHeadOnClickCallBack(function (  )

		local bFinishedNewPlayer=true
		if RoleInfoModel.level >= 1 and bFinishedNewPlayer then
			-- LuaLayout.Instance:OpenWidget(UIWidgetNameDef.HomePageView)
			UIOperateManager.Instance:OpenWidget(AppFacade.RoleInfo)
		end
		
	end)
	local RedPointDef = require "Modules.RedPoint.RedPointDef"
	self.headItem:BindRedDot(RedPointDef.Id.Main_Role_Head)
	self.coinLbl = self:GetChildComponent(obj, "money/item1/CLabel_num", "CLabel")
	self.diamondLbl = self:GetChildComponent(obj, "money/item2/CLabel_num", "CLabel")

	self.coinItemObj = self:GetChild(obj, "money/item1")
	self.gemItemObj = self:GetChild(obj, "money/item2")

	self.coinObj = self:GetChild(obj, "money/item1/sprite")
	self.coinObjScale = self.coinObj.transform.localScale
	self.gemObj = self:GetChild(obj, "money/item2/sprite")
	self.gemObjScale = self.gemObj.transform.localScale

	self.plusBtn = self:GetChildComponent(obj, "money/CButton_open", "CButton")
	self.plusBtn:AddClick(function ()		
		GameLogicTools.ShowMsgTips(self:GetWord("Common_1033"))
	end)	

	self.headObj1 = self:GetChild(obj, "Headitem/CTexture_head")
	self.headObjScale = self.headObj1.transform.localScale

	self.expObj = self:GetChild(obj, "CSprite_headback")
	self.expSlider=self:GetChildComponent(obj,"Viewport/CSlider", "CSlider")
    --self.expLab=self:GetChildComponent(obj,"CSlider_exp/CLabel_num", "CLabel")
end

function MainInfoPanel:Open()
	self:StartOpenTween()
	self:UpdateInfo()
end	

function MainInfoPanel:Close()
	if self.opensequence then
		self.opensequence:Kill()
		self.opensequence = nil
	end		

	self:ClearCoinTween()
	self:ClearGemTween()
	self:ClearExpTween()
	self:ClearCoinTimer()
	self:ClearGemTimer()
	self:ClearExpTimer()
end	

function MainInfoPanel:UpdatePhoto(headid)
	
	self.headItem:UpdatePhoto(headid)
end

function MainInfoPanel:UpdatePhotoFrame(photoframeid)
	
	self.headItem:UpdatePhotoFrame(photoframeid)
end

function MainInfoPanel:UpdateNickName()
	
	self.headItem:UpdateNickName(RoleInfoModel.nickname)
end

function MainInfoPanel:UpdateLevelAndExp()

	
	
	self.headItem:UpdateLevel(RoleInfoModel.level)
	local maxexp=RoleInfoProxy.Instance:GetCurrentLevelMaxPlayerExp(RoleInfoModel.level,RoleInfoModel.player_exp)
    local currentexp=RoleInfoProxy.Instance:GetCurrentLevelPlayerExp(RoleInfoModel.level,RoleInfoModel.player_exp)
    local progress=currentexp*1.0/maxexp*1.0
    if self.expSlider then
        self.expSlider.value=progress
	end
	if self.expLab then
        self.expLab.text=string.format("%d/%d",currentexp,maxexp)
	end
end

function MainInfoPanel:Destroy()
	self:ClearCoinTween()
	self:ClearGemTween()
	self:ClearExpTween()
	self:ClearCoinTimer()
	self:ClearGemTimer()
	self:ClearExpTimer()
end

function MainInfoPanel:StartOpenTween()	
	self.rect.anchoredPosition = Vector2.New(self.rectPosition.x, self.rectPosition.y + 100)
	local tween1 = self.rect:DOAnchorPosY(self.rectPosition.y - 10, 0.2)
	local tween2 = self.rect:DOAnchorPosY(self.rectPosition.y, 0.2)

	local sequence = DOTween.Sequence()
	sequence:Append(tween1)
	sequence:Append(tween2)
	self.opensequence = sequence
end

function MainInfoPanel:UpdateInfo()
	local data = table.deepcopy(RoleInfoModel)
	local str, fight = HeroProxy.Instance:GetMyAllHeroFight()
	data.fight = fight
	self.headItem:SetData(data)
	self:ShowCurrency()
	self:UpdateLevelAndExp()
end

function MainInfoPanel:ShowCurrency()
	self.coinLbl.text = GameLogicTools.GetNumStr(RoleInfoModel.coin)
	self.diamondLbl.text = GameLogicTools.GetNumStr(RoleInfoModel.diamond)
	self:UpdateLevelAndExp()
end

function MainInfoPanel:GetTweenObjs()
	return {self.headObj1, self.coinObj, self.gemObj, self.headObjScale, self.coinObjScale, self.gemObjScale}
end

function MainInfoPanel:TargetTweenScale(targetObj, fromVector, toVector, time, total_time, interval, isLoop)
	targetObj.transform.localScale = fromVector

	local targetTween1 = targetObj.transform:DOScale(toVector, time)
	targetTween1:SetEase(Ease.InBack)
	local targetTween2 = targetObj.transform:DOScale(fromVector, time)
	targetTween2:SetEase(Ease.OutBack)
	local targetBagSequence = DOTween.Sequence()
	targetBagSequence:Append(targetTween1)
	targetBagSequence:Append(targetTween2)
	if interval and isLoop then
		targetBagSequence:AppendInterval(interval)
		targetBagSequence:SetLoops(-1)
	end
	return targetBagSequence
end

function MainInfoPanel:ClearCoinTween()
	if self.coinSeq then
		self.coinSeq:Kill()
		self.coinSeq = nil
	end
	self.coinObj.transform.localScale = self.coinObjScale
end

function MainInfoPanel:ClearGemTween()
	if self.gemSeq then
		self.gemSeq:Kill()
		self.gemSeq = nil
	end
	self.gemObj.transform.localScale = self.gemObjScale
end

function MainInfoPanel:ClearExpTween()
	if self.expSeq then
		self.expSeq:Kill()
		self.expSeq = nil
	end
	self.headObj1.transform.localScale = self.headObjScale
end

function MainInfoPanel:ClearCoinTimer()
	if self.coinTimer then
		self:RemoveTimer(self.coinTimer)
		self.coinTimer = nil
	end
	self.coinObj.transform.localScale = self.coinObjScale
end

function MainInfoPanel:ClearGemTimer()
	if self.gemTimer then
		self:RemoveTimer(self.gemTimer)
		self.gemTimer = nil
	end
	self.gemObj.transform.localScale = self.gemObjScale
end

function MainInfoPanel:ClearExpTimer()
	if self.expTimer then
		self:RemoveTimer(self.expTimer)
		self.expTimer = nil
	end
	self.headObj1.transform.localScale = self.headObjScale
end

--飞图标 目标缩放
function MainInfoPanel:FlyItemScaleTween(scaleType, total_time)
	local BagDef = require "Modules.Bag.BagDef"
	if scaleType == BagDef.FlyIconType.MainViewCion then
		self:CoinTween(total_time, true)
	elseif scaleType == BagDef.FlyIconType.MainViewGem then
		self:GemTween(total_time, true)
	elseif scaleType == BagDef.FlyIconType.MainViewExp then
		self:ExpTween(total_time, true)
	end
end

function MainInfoPanel:CoinTween(total_time, isLoop)
	local toVector = Vector3.New(1.5, 1.5, 1.5)
	local per_time = 0.02
	local interval = 0.02
	self:ClearCoinTween()
	self:ClearCoinTimer()
	self.coinSeq = self:TargetTweenScale(self.coinObj, self.coinObjScale, toVector, per_time, total_time, interval, isLoop)
	self.coinTimer = self:AddTimer(function()
		self:ClearCoinTween()
	end, total_time, 1)
end

function MainInfoPanel:GemTween(total_time, isLoop)
	local toVector = Vector3.New(1.5, 1.5, 1.5)
	local per_time = 0.02
	local interval = 0.02
	self:ClearGemTween()
	self:ClearGemTimer()
	self.gemSeq = self:TargetTweenScale(self.gemObj, self.gemObjScale, toVector, per_time, total_time, interval, isLoop)
	self.gemTimer = self:AddTimer(function()
		self:ClearGemTween()
	end, total_time, 1)
end

function MainInfoPanel:ExpTween(total_time, isLoop)
	local toVector = Vector3.New(1.5, 1.5, 1.5)
	local per_time = 0.02
	local interval = 0.02
	self:ClearExpTween()
	self:ClearExpTimer()
	self.expSeq = self:TargetTweenScale(self.headObj1, self.headObjScale, toVector, per_time, total_time, interval, isLoop)
	self.expTimer = self:AddTimer(function()
		self:ClearExpTween()
	end, total_time, 1)
end

return MainInfoPanel