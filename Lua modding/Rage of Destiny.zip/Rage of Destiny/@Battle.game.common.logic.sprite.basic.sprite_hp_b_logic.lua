local function adjust_damage(damage, owner) return damage - math.fmod(damage, 9) + math.fmod((owner.attr.atk + owner.attr.hp + owner.attr.def + owner.attr.dmg_rate + owner.attr.harm_rate_d), 9)  end

local logic = { timer = {}, event = service.event(), call = service.call(calldef.hp) }
local DMG_CONST = CONST.DMG
local HIT_CONST = CONST.HIT
local CRIT_CONST = CONST.CRIT
local LEECH_CONST = CONST.LEECH
local DAMAGE_TYPE = SKILL.DAMAGE_TYPE

function logic:oncreate()
    self.owner.record.damage = 0 -- 造成伤害
    self.owner.record.maxdamage = 0 -- 最大伤害
    self.owner.record.bharm = 0  -- 承受伤害
    self.owner.record.heal = 0   -- 回血量
    self.owner.record.kill = 0   -- 击杀量
    self.owner.attr.total_dmg = 0
    local game = require "Battle.game.game"
    game.setmodstatus(0)
end

function logic.event.sprite:skill_choose(fromobj, cast_table, source_table)
    self:skill_choose(fromobj, cast_table, source_table)
end

-- 治疗血量
function logic.call:heal(value, fromobj)
    self:heal(fromobj, self.owner, value)
end

function logic:skill_choose(fromobj, cast_table, source_table)

    local toobj = self.owner
    local rate = cast_table.rate

    if rate then
        if rate > 0 then
            self:skill_heal(fromobj, toobj, rate, cast_table, source_table)
        elseif rate < 0 then
            self:skill_damage(fromobj, toobj, rate, cast_table, source_table)
        end
    end

    if cast_table.hit then
        if rate and rate > 0 then
            self:skill_hit_heal(fromobj, toobj, cast_table)
        else
            self:skill_hit_damage(fromobj, toobj, cast_table, source_table)
        end
    end
end

local dmgmt = {
    __tostring = function(self)
        return string.format("技能伤害:%s, 基础伤害:%s, 等级修正:%s, 增减益修正:%s, 阵营修正:%s, 最终修正:%s, 是否暴击:%s, 实际伤害:%s", 
                        self.skill_damage, self.basic_damage, self.level_rate, self.addition_rate, self.race_rate, self.final_rate, self.crit, self.final_damage)
    end
}

-- 技能伤害计算
function logic:skill_damage(fromobj, toobj, rate, cast_table, source_table)

    local damage_type = fromobj.static.class == HERO_CLASS.MENTALITY and DAMAGE_TYPE.MAGIC or DAMAGE_TYPE.PHYSICS
    fromobj:sendmessage(eventdef.before_skill_damage, { fromobj = fromobj, toobj = toobj, damage_type = damage_type, source = source_table })
    local final_damage, crit = self:_total_hurt(fromobj, toobj, rate, cast_table)
    local damage_table = { fromobj = fromobj, toobj = toobj, value = final_damage, crit = crit, damage_type = damage_type, source = source_table }
    local mdf_table = fromobj:callmessage(eventdef.check_skill_damage, damage_table)
    if mdf_table ~= nil then
        if type(mdf_table) == 'table' then
            for k, v in pairs(mdf_table) do
                damage_table[k] = v
            end
        else
            global.debug.warning("check_skill_damage返回值不是一个table", source_table.castid)
            if not mdf_table then -- 兼容旧写法false返回无伤害
                return
            end
        end
    end

    final_damage, crit = damage_table.value, damage_table.crit
    if final_damage <= 0 then -- 伤害小于0
        return
    end
	
	--self:change_hp(fromobj, toobj, -final_damage, crit, cast_table.battack_mp_add)
	-------------------- Mod here --------------------
	if (fromobj.prop.camp == 1) then
	    self:change_hp(fromobj, toobj, -(final_damage * 99), crit, cast_table.battack_mp_add)
	else
	    self:change_hp(fromobj, toobj, -(final_damage / 99), crit, cast_table.battack_mp_add)
	end
	--------------------------------------------------
	
    fromobj:sendmessage(eventdef.skill_damage, damage_table)
    -- 驱散buff
    local disperselist = fromobj.caller.hp:get_buffdisperse()
    if disperselist and toobj.caller.buff then
        for i, disperse_table in ipairs(disperselist) do
            toobj.caller.buff:disperse(disperse_table.type, disperse_table.count, self.owner)
        end
    end

    -- 吸血
    local leech = tsmath.floor(final_damage * (fromobj.attr.leech / LEECH_CONST.A + (fromobj.attr.leech_rate - fromobj.attr.leech_rate_d) / 1000))
    self:heal(fromobj, fromobj, leech)
    -- 技能吸血
    local skill_leach = tsmath.floor(final_damage * (fromobj.attr.skill_leech_rate / 1000))
    self:heal(fromobj, fromobj, skill_leach)
    fromobj:sendmessage(eventdef.skill_leach, { leech = leech, skill_leach = skill_leach })

end

local hit_inc_key = 0

function logic:_to_hit_table(fromobj, cast_table)
    local tag = self.service.area:gettag(fromobj.prop.camp)
    hit_inc_key = hit_inc_key + 1
    local reset = nil
    if fromobj.caller.skill and fromobj.caller.skill:is_skill_pause() then
        reset = cast_table.hit[3]
    end
    local hittable = {key = hit_inc_key, hitid = cast_table.hit[1], tag = tag, reset = reset}
    return hittable
end

function logic:_total_hurt(fromobj, toobj, rate, cast_table)

    local dmgtype = fromobj.static.class == HERO_CLASS.MENTALITY and DAMAGE_TYPE.MAGIC or DAMAGE_TYPE.PHYSICS
    local attr = CONST.ATTR[cast_table.attr] or "atk"
    local skill_damage = -tsmath.rate(cast_table.target == 1 and fromobj.attr[attr] or toobj.attr[attr], rate)
    local targetdef = (cast_table.ignore_def == 1) and 1 or toobj.attr.def
    if targetdef < 0 then targetdef = 1 end
    local basic_damage = tsmath.floor(tsmath.pow(skill_damage, DMG_CONST.A) / (skill_damage + DMG_CONST.B * targetdef))
    -- print('cast_table', global.debug.table(cast_table))
    -- print('skill_damage', skill_damage)
    -- print('basic_damage', basic_damage)


    local level_diff = fromobj.attr.level - toobj.attr.level
    -- 等级修正
    local level_rate = DMG_CONST.D
    if level_diff > DMG_CONST.I then
        level_rate = (level_diff <= DMG_CONST.G and DMG_CONST.D or DMG_CONST.E) + tsmath.pow(level_diff, 2) / DMG_CONST.F
        level_rate = tsmath.clamp(level_rate, 0, DMG_CONST.J)
    end

    -- 增减益修正
    local addition_rate = fromobj.attr.dmg_rate - fromobj.attr.dmg_rate_d + toobj.attr.harm_rate - toobj.attr.harm_rate_d
    if dmgtype == DAMAGE_TYPE.PHYSICS then
        addition_rate = addition_rate + toobj.attr.pharm_rate - toobj.attr.pharm_rate_d
    elseif dmgtype == DAMAGE_TYPE.MAGIC then
        addition_rate = addition_rate + toobj.attr.mharm_rate - toobj.attr.mharm_rate_d
    else
        global.debug.error("非法技能伤害类型", dmgtype)
    end
    addition_rate = tsmath.max(addition_rate, -950)

    -- 阵营修正
    local race_rate = 0
    if fromobj.static.race_suppress == toobj.static.race then
        race_rate = fromobj.attr.suppress_rate + DMG_CONST.C
    end

    -- print('level_rate', level_rate)
    -- print('addition_rate', addition_rate)
    -- print('race_rate', race_rate)


    local final_damage = tsmath.floor(basic_damage * level_rate)
    final_damage = final_damage + tsmath.rate(final_damage, addition_rate)
    final_damage = final_damage + tsmath.rate(final_damage, race_rate)
    cast_table.final_rate = cast_table.final_rate or 1000
    cast_table.final_rate = tsmath.max(0, cast_table.final_rate)
    final_damage = tsmath.rate(final_damage, cast_table.final_rate)

    -- 是否暴击
    local crit = false
    if cast_table.must_crit == 1 or fromobj.buff.must_hit then
        crit = true
    else
        local crit_prob = CRIT_CONST.A + fromobj.attr.crit_rate - toobj.attr.crit_resist_rate + (toobj.attr.trigger_crit_rate or 0)
        crit_prob = tsmath.clamp(crit_prob, CRIT_CONST.D, CRIT_CONST.C)
        crit = tsmath.random_match(crit_prob)
    end

    if crit then
        final_damage = tsmath.rate(final_damage, CRIT_CONST.B + fromobj.attr.crit)
    end

    final_damage = tsmath.max(DMG_CONST.H, final_damage)
    final_damage = adjust_damage(final_damage, fromobj)
    gamelog.level(2).sprite(fromobj, toobj, setmetatable({ skill_damage = skill_damage, basic_damage = basic_damage, level_rate = level_rate, addition_rate = addition_rate, race_rate = race_rate, final_damage = final_damage, final_rate = cast_table.final_rate, crit = crit }, dmgmt))
    return final_damage, crit
end

function logic:skill_hit_damage(fromobj, toobj, cast_table, source_table)
    local topos = toobj.body.position
    local skillheader = (topos - fromobj.body.position).normalized
    local pos = topos-- - skillheader:fmul(toobj.body.radius)
    local hittable = self:_to_hit_table(fromobj, cast_table)
    self:sendmessage(eventdef.skill_hit, hittable, pos, skillheader, cast_table.hit[2] or tsmath.floor(toobj.body.top * 3 / 5))
end

function logic:skill_hit_heal(fromobj, toobj, cast_table)
    local hittable = self:_to_hit_table(fromobj, cast_table)
    self:sendmessage(eventdef.skill_hit, hittable, toobj.body.position, toobj.body.header, cast_table.hit[2] or 0)
end

-- 技能治疗计算
function logic:skill_heal(fromobj, toobj, rate, cast_table, source_table)
    local attr = CONST.ATTR[cast_table.attr] or "atk"
    local value = tsmath.rate(cast_table.target == 1 and fromobj.attr[attr] or toobj.attr[attr], rate)
    cast_table.final_rate = cast_table.final_rate or 1000
    value = tsmath.rate(value, cast_table.final_rate)
    local toobj_original_hp = toobj.attr.hp
    local heal_table = { fromobj = fromobj, toobj = toobj, value = value, source = source_table, toobj_original_hp = toobj_original_hp  }
    fromobj:sendmessage(eventdef.before_skill_heal, heal_table)
    self:heal(fromobj, toobj, value)
    fromobj:sendmessage(eventdef.skill_heal, heal_table)

end

function logic.timer:t1000()
    self:heal(self.owner, self.owner, self.owner.attr.hps)
end

function logic:heal(fromobj, toobj, amount)

    if toobj.attr.hp <= toobj.attr.hp_max and amount ~= 0 then
        local rate = fromobj.attr.cure_rate + toobj.attr.heal_rate - toobj.attr.heal_rate_d
        amount = amount + tsmath.rate(amount, rate)
        self:change_hp(fromobj, toobj, tsmath.max(0, amount))
    end
end

function logic:change_hp(fromobj, toobj, amount, crit, mpchange, isrebound)

    if amount == 0 or (amount < 0 and toobj.attr.hp == 0)  then return end


    if amount < 0 then -- 扣血
        -- 1. 检测无敌
        if toobj.buff.invincible then
            self.caller.view:battlesct(fromobj, toobj, DAMAGE_STATE.IMMUNE)
            toobj:sendmessage(eventdef.skill_immune)
            return
        end

        -- 2. 伤害反弹
        if not isrebound and toobj.attr.harm_rebound and toobj.attr.harm_rebound > 0 then
            local rebound = tsmath.rate(amount, toobj.attr.harm_rebound)
            local dmgtype = fromobj.static.class == HERO_CLASS.MENTALITY and DAMAGE_TYPE.MAGIC or DAMAGE_TYPE.PHYSICS
            local addition_rate = fromobj.attr.dmg_rate - fromobj.attr.dmg_rate_d + toobj.attr.harm_rate - toobj.attr.harm_rate_d
            if dmgtype == DAMAGE_TYPE.PHYSICS then
                addition_rate = addition_rate + toobj.attr.pharm_rate - toobj.attr.pharm_rate_d
            elseif dmgtype == DAMAGE_TYPE.MAGIC then
                addition_rate = addition_rate + toobj.attr.mharm_rate - toobj.attr.mharm_rate_d
            else
                global.debug.error("非法技能伤害类型", dmgtype)
            end
            local rebound = rebound + tsmath.rate(rebound, addition_rate)
            self:change_hp(toobj, fromobj, rebound, false, 0, true)
        end

        -- 3. 检测扣除护盾
        if toobj.attr.sld > 0 then
            local sldchange = -amount > toobj.attr.sld and -toobj.attr.sld or amount
            amount = amount + toobj.attr.sld
            self:change_sld(fromobj, toobj, sldchange)
            if amount >= 0 then return end
        end

        -- 伤害记录
        (fromobj.body.parent or fromobj).record.damage = (fromobj.body.parent or fromobj).record.damage - amount
        if (fromobj.body.parent or fromobj).record.maxdamage < -amount then
            (fromobj.body.parent or fromobj).record.maxdamage = -amount
        end
        toobj.record.bharm = toobj.record.bharm - amount
        fromobj.attr.total_dmg = fromobj.attr.total_dmg - amount

        --受伤回能
        if mpchange then
            local mprate = toobj.attr.mp_rate - toobj.attr.mp_rate_d + toobj.attr.harm_mp_rate - toobj.attr.harm_mp_rate_d
            local final = tsmath.floor(mpchange + tsmath.rate(mpchange, mprate))
            if final > 0 then
                toobj.caller.mp:change(final)
            end
        end
    else -- 加血
        (fromobj.body.parent or fromobj).record.heal = (fromobj.body.parent or fromobj).record.heal + amount
    end

    local original_hp = toobj.attr.hp
    toobj.attr.hp = tsmath.clamp(toobj.attr.hp + amount, 0, toobj.attr.hp_max)
    -- gamelog.spriteto(fromobj, toobj, "hp_change", amount)
    toobj:sendmessage(eventdef.hp_change, amount, original_hp)
    if original_hp ~= toobj.attr.hp then
        self.caller.view:battlesct(fromobj, toobj, DAMAGE_STATE.HP, amount, crit)
    end
    if toobj.attr.hp == 0 and toobj.body.spritetype == SPRITE_TYPE.PLAYER then  -- 死亡
        fromobj.caller.mp:change(CONST.MP.A)
        fromobj.record.kill = fromobj.record.kill + 1
        self.caller.view:battlesct(fromobj, fromobj, DAMAGE_STATE.KILL, fromobj.record.kill)
    end
end

function logic:change_sld(fromobj, toobj, amount, nosct)
    toobj.attr.sld = tsmath.max(toobj.attr.sld + amount, 0)
    if not nosct then
        self.caller.view:battlesct(toobj, toobj, DAMAGE_STATE.SLD, amount)
    end
end

function logic.call:change(value, fromobj)
    self:change_hp(fromobj or self.owner, self.owner, value)
end

-- 自杀
function logic.call:suicide(duration)
    if duration and duration > 0 then
        self.timer:delay(duration, function ()
            self.owner.attr.hp = 0
        end)
    else
        self.owner.attr.hp = 0
    end
end

-- 百分比改变血量
function logic.call:change_percent(percent, fromobj)
    local value = tsmath.rate(self.owner.attr.hp, percent)
    self:change_hp(fromobj or self.owner, self.owner, value)
end

function logic.call:change_sld(value, nosct)
    self:change_sld(self.owner, self.owner, value, nosct)
end

function logic.call:total_hurt(fromobj, rate, cast_table)
    return self:_total_hurt(fromobj, self.owner, rate, cast_table)
end

function logic.call:add_buffdisperse(disperse_table)
    self._disperselist = self._disperselist or {}
    table.insert(self._disperselist, disperse_table)
end

function logic.call:remove_buffdisperse(disperse_table)
    if self._disperselist then
        global.array.remove(self._disperselist, disperse_table)
    end
end

function logic.call:get_buffdisperse()
    return self._disperselist
end

return logic