local logic = { event = { sprite = {} } }

function logic:onenter()
    self.lastvel = nil
end

function logic:onupdate(time, tick)
    local velocity = self.owner.body.velocity


    if not self.lastvel or (velocity.x ~= self.lastvel.x or velocity.y ~= self.lastvel.y) then
        self.lastvel = velocity:clone()
        local stand = self.lastvel.x == 0 and self.lastvel.y == 0
        self.caller.view:start_active(stand and "stand" or "run", self.spdrate)
    end

    return STATE_STATUS.SUSPEND
end

function logic.event.sprite:movspd_change(spdrate)
    self.spdrate = spdrate
end

return logic