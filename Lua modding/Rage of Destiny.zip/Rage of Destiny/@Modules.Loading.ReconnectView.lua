local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"

local ReconnectView = BaseClass(LuaBasicWidget)

function ReconnectView:OnLoad()
    AssetManager.LoadUIPrefab(self, "UICommon.NetworkReconnectView", self.LoadEnd)
end

function ReconnectView:LoadEnd(obj)
    self:SetGo(obj)

    self.rorateObj_1 = self:GetChild(obj, "icon/CSprite_frame1")
    self.rorateObj_2 = self:GetChild(obj, "icon/CSprite_frame2")
    self.rorateObj_3 = self:GetChild(obj, "icon/CSprite_frame3")

    self.vec_1 = Vector3.New(0, 0, 1)
    self.vec_2 = Vector3.New(0, 0, 5)
    self.vec_3 = Vector3.New(0, 0, 2)

    self.effect = UIEffectItem.New("UI_NetworkDelay_light", self.go)

    self:SetStep(0)
end

function ReconnectView:OnOpen()
    self:StartFrame()
    self.effect:Open()
    self:SetObjDepth()
end

function ReconnectView:SetObjDepth()
    self:SetDepth(self.go, 20000)
end

function ReconnectView:OnClose()
    self:EndFrame()
    self.effect:Close()
end

function ReconnectView:OnDestroy()
    self:EndFrame()
    self.effect:Destroy()
end

function ReconnectView:FrameUpdate(time, deltaTime)
    self.rorateObj_1.transform:Rotate(self.vec_1)
    self.rorateObj_2.transform:Rotate(self.vec_2)
    self.rorateObj_3.transform:Rotate(self.vec_3)
end

return ReconnectView