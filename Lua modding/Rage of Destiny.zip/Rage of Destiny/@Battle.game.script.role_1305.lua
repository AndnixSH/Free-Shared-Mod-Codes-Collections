-- 马耶罗-豪琴孤狼-摇滚歌手
local conf = { skill = {}, buff = {}, bullet = {} }

-- 拨动琴弦，射出音符，对最近的敌人，造成80%攻击力的伤害。
conf.skill[130501] = {
    action = {
        default = {
            {trigger.time, {0}, caller.view.active, "attack01" },
            {trigger.time, {500}, caller.body.addchild, {typeid = 130501}, scriptcommon.bullet_trace, {speed = 15000, duration = 2000, rangeid = 130501} },
            {trigger.time, {667} },
        },
    },

}

-- 死亡摇滚
-- "开启疯狂弹奏模式，在极尽华丽的开场后，闪现至随机目标身后，弹出魔鬼音符向前方扇形范围飘去（穿透），
-- 碰到敌人造成n%攻击力伤害，碰到友军回复m%攻击力生命，闪现2次，优先选取友方目标
-- 2级：闪现次数增加到3次
-- 3级：造成的伤害提升至n%攻击力，回复的生命提升至m%攻击力

conf.skill[130511] = script.composite {
    main = {    
        action = {
            default = {
                {trigger.time, {0},     action.addstartbuff,},
                {trigger.time, {0},     caller.view.active, "spell_01_start", caller.skill.pause, 833},
                {trigger.time, {833},   action.active, "spell_01_loop"},
                {trigger.time, {900},   script.append("atk_script")},
                {define = script.greater("ultimatelevel", 2), trigger.time, {0}, script.append("atk_script2")},
                {trigger.time, {0},     script.append("end_atk_script")},
                {trigger.time, {500} },
            },
            atk_script = {
                {trigger.time, {0},     caller.skill.blink_select, -1800, script.prop("rangeid"),},
                {trigger.time, {100},   action.active, "spell_01_loop_02"},
                {trigger.time, {0},     action.addchild, {typeid = 999999}, "bullet_single"},
                {trigger.time, {0},     action.message, "130511_cast"},
                {trigger.time, {800},},
            },
            atk_script2 = {
                {trigger.time, {0},     caller.skill.blink_select, -1800, script.prop("rangeid"),},
                {trigger.time, {100},   action.active, "spell_01_loop_03"},
                {trigger.time, {0},     action.addchild, {typeid = 999999}, "bullet_single"},
                {trigger.time, {0},     action.message, "130511_cast"},
                {trigger.time, {800},},
            },
            end_atk_script = {
                {trigger.time, {0},     caller.skill.blink_select, -1800, script.prop("rangeid"),},
                {trigger.time, {100},   action.active, "spell_01_end"},
                {trigger.time, {0},     action.addchild, {typeid = 999999}, "bullet_single"},
                {trigger.time, {0},     action.message, "130511_cast"},
                {trigger.time, {1100},},
            }
        },
        event = {
            {scriptevent.onstart, onfire = function(self)
                self.prop.ultimatelevel = self.caller.skill:getslotlevel(SKILL.SLOT.ULTIMATE)
                self.prop.damageid = self.caller.skill:getslot(SKILL.SLOT.ULTIMATE).skillid
                self.prop.healid = self.prop.damageid + 50
                self.prop.rangeid = 130564
            end},

            {scriptevent.onend, onfire = function(self)
            end },
        },
    },
    bullet_single={
        action = {
            default = {
                {trigger.time, {0},      action.active, "130511"},
                {trigger.time, {500},    action.cast, script.prop("damageid"),},
                {trigger.time, {0},      action.cast, script.prop("healid"),},
                {trigger.time, {1000},   caller.body.destroy},
            }
        }
    }
}
conf.skill[130512] = conf.skill[130511]
conf.skill[130513] = conf.skill[130511]

-- 魔鬼音符
-- "马耶罗弹奏出3个不同形状的大音符，依次飞向最近敌人，每个造成110%攻击力的伤害与短暂眩晕
-- 2级：音符会在敌人中弹射，最多弹射2次，且伤害不递减
-- 3级：伤害提升至130%攻击力
-- 4级：命中的敌人，在后续4秒内受到伤害提升30%

conf.skill[130521] = {
    action = {
        default = {
                {trigger.time, {0},     caller.view.active, "spell_02",},
                {trigger.time, {1000},  caller.body.addchild, {typeid = 130521}, script.prop("bullet_type"),script.prop("bullet_args")},
                {trigger.time, {200},   caller.body.addchild, {typeid = 130522}, script.prop("bullet_type"),script.prop("bullet_args")},
                {trigger.time, {200},   caller.body.addchild, {typeid = 130523}, script.prop("bullet_type"),script.prop("bullet_args")},
                {trigger.time, {800}, },
            }
        },
    event = {
        {scriptevent.onstart, onfire = function(self)
            local count = self.action.info.level >=2 and 3 or 1-- 弹射次数 + 命中
            local this_slot = SKILL.SLOT.SKILL3
            local slotlevel = self.action.info.level  --self.caller.skill:getslotlevel(this_slot)
            local bullet_castid = self.static.id      --self.caller.skill:getslot(this_slot).skillid
            local bullet_args_trace = {speed = 10000, duration = 2000, rangeid = bullet_castid}
            local bullet_args_bounce = {speed = {10000,10000}, castid ={bullet_castid, bullet_castid}, duration = 3000, rangeid = 900101, count = count }
            self.prop.bullet_args = slotlevel >= 2 and bullet_args_bounce or bullet_args_trace
            -- self.prop.bullet_args = bullet_args_trace
            self.prop.bullet_type = slotlevel >= 2 and scriptcommon.bullet_bounce_trace or scriptcommon.bullet_trace
        end},
    },  
}

conf.skill[130522] = conf.skill[130521]
conf.skill[130523] = conf.skill[130521]
conf.skill[130524] = conf.skill[130521]

-- Hey！brother!
-- 马耶罗在敌人靠近队友时，弹出一个巨大音符飞向目标，对其造成n%攻击力伤害，若为前排队友的敌人，眩晕其2秒；若为后排队友的敌人，击飞对方。
-- 2级：伤害量提升至n%攻击力
-- 3级：伤害量提升至n%攻击力

conf.skill[130531] = script.composite {
    main = {
        action = {
            default = {
                {trigger.time, {0},   caller.view.active, "spell_03",},
                {trigger.time, {1100},  action.addchild, {typeid = 130531}, "bullet"},
                {trigger.time, {450}, },
            },
        },
        event = {
            {scriptevent.onstart, onfire = function(self)
                local args = self.caller.buff:get_state("130531_cast")
                local target = args.target -- 朝向target
                if target then
                    local targetpos = target.body.position
                    local mypos = self.owner.body.position
                    self.owner.body:setheader((targetpos - mypos).normalized)
                end
                local bullet_castid = self.static.id
                self.prop.friend = args.friend
                self.prop.bullet_args = {speed = 10000, duration = 2000, castid = bullet_castid, target = target}
            end},
            {scriptevent.onend, onfire = function(self)
                self.caller.buff:remove_state("130531_cast")
            end},
        }, 
        check = {
            event = {
                {eventdef.skill_damage, modifer = eventmdf.excludeself, onfire = function(self, fromobj, damage_table)
                    local check_hp = 100    -- 重击需要的hp上限
                    if damage_table.toobj ~= self.owner
                    and damage_table.toobj.prop.camp == self.owner.prop.camp 
                    and damage_table.value >= tsmath.rate(damage_table.toobj.attr.hp_max, check_hp) then
                        self.caller.buff:add_state("130531_cast", {target = fromobj, friend = damage_table.toobj})
                        self.action:checksucc()
                    end
                end}
            }
        },
    },
    bullet = {
        event = {
            {scriptevent.onstart, onfire = function (self)
                self.caller.body:addscript(scriptcommon.bullet_trace, self.prop.bullet_args)
            end },

            {eventdef.skill_damage, modifer = eventmdf.excludeself, onfire = function(self, fromobj, damage_table)
                if fromobj == self.owner.body.parent and damage_table.source.castid == self.prop.bullet_args.castid then
                    if self.prop.friend.caller.hp and not self.prop.friend.caller.state:isdead() then
                        self.prop.friend.caller.hp:heal(damage_table.value,  self.owner.body.parent )
                    end

                    if self.prop.skill_lv >= 3 then
                        local targets = self.action:range(SKILL.RANGEID.FRIEND_LOW_HP_HERO)
                        if targets then
                            for _, target in ipairs(targets) do
                                target.caller.hp:heal(damage_table.value,  self.owner.body.parent )
                                break
                            end
                        end
                    end
                end
            end},

            {eventdef.sprite_collide, onfire = function(self, collideobj)
            end },
        },
    },
}
conf.skill[130532] = conf.skill[130531]
conf.skill[130533] = conf.skill[130531]
     
-- }

--狂热艺术
-- 每次承受的伤害都会让马耶罗更加疯狂，攻速提升n%，命中提升m%，叠x层
conf.skill[130541] =  {
    action = {
        -- bullet = {
        -- {trigger.time, {0}, action.cast, 130341, scriptcommon.bullet_single,},
        -- },
    },
    event = {
        {scriptevent.onstart, onfire = function(self)
            self.prop.buffid = ({130541, 130541, 130543})[self.prop.skill_lv]
            self.prop.friend_buffid = ({130542, 130542, 130544})[self.prop.skill_lv]
            -- self.prop.double_rate = 1000
        end},

        {eventdef.skill_damage, modifer = eventmdf.excludeself, onfire = function (self, fromobj, damage_table)
            if  damage_table.toobj ~= self.owner then return end
            local buffid = self.prop.buffid
            local friend_buffid = self.prop.friend_buffid
            local slotlevel = self.prop.skill_lv
            self.caller.buff:add(buffid)

            if slotlevel >= 2 then 
                local friends = self.caller.skill:range(SKILL.RANGEID.FRIENDS_CLOSE_MID)
                for _,friend in ipairs(friends) do
                    if friend ~= self.owner then
                        friend.caller.buff:add(friend_buffid)
                    end
                end
            end

            -- if slotlevel >= 3 and damage_table.crit and tsmath.random_match(self.prop.double_rate) then
            --     self.caller.buff:add(bufflist[1])
            -- end
        end}
    },
}
conf.skill[130542] = conf.skill[130541]
-- 2级：周围队友同样可享受到增益效果，但效果降低50%
conf.skill[130543] = conf.skill[130541]
-- 3级：承受暴击时，有50%概率使收益翻倍

conf.buff[9130510] = {
    event = {
        {scriptevent.onstart, onfire = function (self)
            local exbufflist = {913054,913053,913052,913051}
            local bufflist = {913055,913056,913057,913057}
            local exbuff = self.caller.buff:any(exbufflist)
            local exbufflv = exbuff and exbuff % 10 or 0
            local buffid = bufflist[exbufflv]

            self.prop.exbufflv = exbufflv
            self.prop.exbufflist = exbufflist
            self.prop.bufflist = bufflist
            self.prop.buffid = buffid
        end},

        {"130511_cast", onfire = function (self)
            local targets = self.action:range(SKILL.RANGEID.FRIENDS_CLOSE_LARGE)
            for _, target in ipairs(targets) do
                target.caller.buff:add(self.prop.buffid, self.owner)
            end
        end},

        {scriptevent.ontimer, time = {1000,1000}, onfire = function(self) -- + 30 光环
            if self.prop.exbufflv < 4 then return end
            local targets = self.action:range(SKILL.RANGEID.FRIENDS_CLOSE_LARGE)
            for _, target in ipairs(targets) do
                if targets ~= self.owner then
                    target.caller.buff:add(913058, self.owner)
                end
            end
        end}
    }
}

conf.buff[9130520] = conf.buff[9130510]
conf.buff[9130530] = conf.buff[9130510]
conf.buff[9130540] = conf.buff[9130510]
return conf