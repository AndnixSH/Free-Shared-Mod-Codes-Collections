ConfigManager = {configDatas = {}}

function ConfigManager.InitConfig(name, item)
	if type(item) ~= "table" or name == nil then return end

	ConfigManager.configDatas[name] = item
end


function ConfigManager.GetConfig(name)
	if ConfigManager.configDatas[name] then
		return ConfigManager.configDatas[name]
	end
	local filePathTable = {}
	filePathTable[1] = "Config."
	filePathTable[2] = tostring(name)
	local fileName = table.concat(filePathTable)
	require(fileName)
	if type(name) ~= "string" then name = tostring(name) end
	local result = ConfigManager.configDatas[name]
	return result
end

return ConfigManager