action = {}

function action:destroy()
    self.parent:destroy()
end

function action:run(actionkey)
    self.parent:run(actionkey)
end

function action:stop()
    self.parent:stop()
end

function action:checksucc()
    self.parent:checksucc()
end

function action:settimer(time_table, cb)
    local delay, interval, count = table.unpack(time_table)
    return self.parent._ticktimer:add(delay, interval, count, cb)
end


-- 添加子物体
--[[ create_table
    action.addchild({typeid = 999999}) -- 不带position，默认在自身脚底
    action.addchild(999999) -- 简写，等于上面一条
    action.addchild({typeid = 999999, position = tsvector.new(300, 200)})  -- 指定绝对坐标在300, 200
    action.addchild({typeid = 999999, position = tsvector.new(300, 200), relative = RELATIVE.MAP })  -- 指定相对地图的坐标在300, 200 千分比
    action.addchild({typeid = 999999, position = tsvector.new(300, 200), relative = RELATIVE.SELF })  -- 指定相对自身的坐标在 x为左右 y 为前后
]]
function action:addchild(create_table, scriptname, args)
    local _create_table = {}
    if type(create_table) == 'number' then
        _create_table.typeid = create_table
    else
        for key, value in pairs(create_table) do
            _create_table[key] = value
        end
    end
    local fromobj = self.fromobj or self.owner
    _create_table.position = _create_table.position or self.owner.body.position
    if fromobj.caller.body then
        local child = fromobj.caller.body:addchild(_create_table)
        if scriptname then
            self.parent:redirect(child, scriptname, args)
        end
        return child
    end
end

-- 召唤 create_table, max_count:同typeid最大召唤物数量，survival_time:生存时间，total_max_count: 此精灵的最大召唤物数量，剩下的和addchild的create_table一样
--      scriptname,args 同addchild, 
--      attr_table是属性的加成，keyvalue结构 如{ atk = 1500, def = 800 } 表示攻击力提高1.5，防御力降低0.8，默认全部继承父亲（创建者）的初始属性
function action:summon(create_table, attr_table, scriptname, args)
    local child = self:addchild(create_table, scriptname, args)
    local parent = self.fromobj or self.owner

    local summon_logic = parent:checklogic("sprite.basic.sprite_summon_logic")
    summon_logic:add(child, create_table, attr_table)

    return child
end

-- 跟随 follow_table { rangeid, keep_distance(1500), forward_speed(5000), target)
function action:follow(follow_table)
    self.owner:checklogic("sprite.basic.sprite_follow_logic", follow_table)
end

-- 获取召唤物列表
function action:getsummonlist()
    local parent = self.fromobj or self.owner

    local summon_logic = parent:checklogic("sprite.basic.sprite_summon_logic")
    return summon_logic:getlist()

end

function action:range(castid, buff, args)
    castid = castid or (self.static and self.static.id)
    if not castid then
        global.debug.error(string.format("action.range没有配置有效的castid"))
        return {}
    end
    local fromobj = self.fromobj or self.owner
    if not fromobj.caller.skill then
        global.debug.error('action.range fromobj.caller.skill is nil', fromobj)
        return {}
    end
    local targets = fromobj.caller.skill:range(castid)
    if buff then
        for _, target in ipairs(targets) do
            self.parent:redirect(target, buff, args)
        end
    end
    return targets
end

function action:cast(castid, buff, args)
    castid = castid or (self.static and self.static.id)
    if not castid then
        global.debug.error(string.format("action.cast没有配置有效的castid"))
        return {}
    end
    local fromobj = self.fromobj or self.owner
    if not fromobj.caller.skill then
        global.debug.error('action.cast fromobj.caller.skill is nil', fromobj)
        return {}
    end
    local targets = fromobj.caller.skill:cast(castid, self.owner)
    if buff then
        for _, target in ipairs(targets) do
            self.parent:redirect(target, buff, args)
        end
    end
    return targets
end

function action:addstartbuff(castid)
    castid = castid or (self.static and self.static.id)
    if not castid then
        global.debug.error(string.format("action.addstartbuff没有配置有效的castid"))
    end
    local fromobj = self.fromobj or self.owner
    fromobj.caller.skill:addstartbuff(castid)
end

-- 发消息
function action:message(message, ...)
    local fromobj = self.fromobj or self.owner
    fromobj:sendmessage(message, ...)
end

-- 表现
function action:active(name)
    self.owner.caller.view:active(name)
end
function action:active_random(name)
    self.owner.caller.view:active_random(name)
end

for key, value in pairs(action) do
    metafunc.classify("action", value)
end

action.__index = action

return action