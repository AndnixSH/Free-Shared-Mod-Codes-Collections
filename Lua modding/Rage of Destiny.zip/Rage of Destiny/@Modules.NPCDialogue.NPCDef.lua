local NPCDef = {}

NPCDef.NotifyDef = {
   
    NPCLogUpdate="NPCLogUpdate",
}

NPCDef.CommonDef={
    Senconds="Common_1052",
    Minutes="Common_1053",
    Hours="Common_1054",
    Days="Common_1055",
    Times="Common_1056",
}

return NPCDef