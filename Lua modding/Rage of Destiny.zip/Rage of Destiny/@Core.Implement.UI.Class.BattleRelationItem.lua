local HeroProxy = require "Modules.Hero.HeroProxy"
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"

local BattleRelationItem = BattleRelationItem or BaseClass(GameObjFactor)
--self.Camp , self.viewType
function BattleRelationItem:__init(go, Camp, viewType, frontObj)
	self.go = go
	self.Camp = Camp   --这里 blue：己方 red敌方
	self.viewType = viewType --1上阵界面  2:battleview界面
	self.frontObj = frontObj --特效上层ui
	self:RelationConfig()
	self:Load(go)
end

function BattleRelationItem:DefaultSpName()
 
end

function BattleRelationItem:RelationConfig()
	self.spConfig = {
		[CAMP.BLUE] = {
			--上阵界面蓝
			[1] = {
				"jibanzuo1_1",
				"jibanzuo1_2",
				"jibanzuo1_3",
			},
			--战斗界面蓝
			[2] = {
				"jibanzuo2_1",
				"jibanzuo2_2",
				"jibanzuo2_3",
			},

		},
			
		[CAMP.RED] = {
			--上阵界面红
			[1] ={
				"jibanzuo1_1",
				"jibanzuo1_2", 
				"jibanzuo1_3",
			},
			--战斗界面红
			[2] ={
				"jibanzuo2_1",
				"jibanzuo2_2", 
				"jibanzuo2_3",
			},
		},
	}

	self.effectConfig = {
		[CAMP.BLUE] = {
			--上阵界面蓝
			[1] = {
				"UI_Battle_relationlan",
			},
			--战斗界面蓝
			[2] = {
				"UI_Battle_relation1",
			},
		},
		[CAMP.RED] = {
			--上阵界面红
			[1] = {
				"UI_Battle_relationlan",
			},
			--战斗界面红
			[2] = {
				"UI_Battle_relation1",
			},
		},

	}


end

--精灵配置idx
function BattleRelationItem:GetSpriteName(idx)
	return self.spConfig[self.Camp][self.viewType][idx] or ""
end

function BattleRelationItem:GetEffectName(idx)
	return self.effectConfig[self.Camp][self.viewType][idx]
end
	
function BattleRelationItem:Load(obj)

	self.levelSpList = {}
	for i=1,5 do
		self.levelSpList[i] = self:GetChildComponent(obj, i, "CSprite")
	end

	--战斗界面的特效
	self.effectName = self:GetEffectName(1)

	--上阵界面的特效显示
	self.effectRes = {
		[1] = "UI_Battle_relationlan1",
		[2] = "UI_Battle_relationlan2",
		[3] = "UI_Battle_relationlan3",
		[4] = "UI_Battle_relationlan4",
		[5] = "UI_Battle_relationlan", --命名。。。？？？
	}
	if self.viewType == 2 then
		self.backSp = self:GetChildComponent(obj, "CSprite_back", "CSprite")
		self.effect = UIEffectItem.New(self.effectName, self.backSp.gameObject)
	else
		self.effectLists = {}
		for index, res_name in ipairs(self.effectRes) do
			local effect = UIEffectItem.New(res_name, self.go)
			table.insert(self.effectLists, effect)
		end
	end

end

-- data: {herotypeid}
function BattleRelationItem:SetData(data)
	self.effectDepth = self.effectDepth or self:GetNextDepth() --(noResetDepth and self.effectDepth) or self:GetNextDepth()
	self.frontObjDepth = self.frontObjDepth or self:GetNextDepth() --(noResetDepth and self.frontObjDepth) or self:GetNextDepth()
	self:InitData()
	self.effectCount = 0
	self.relationlevel, self.speciallevel = HeroProxy.Instance:GetRelation(data)
	-- self.backSp.SpriteName = self.speciallevel > 0 and "jibandi_2" or "jibandi_1"
	if self.relationlevel == 1 then
		self.levelSpList[1].SpriteName = self:GetSpriteName(1) --self.Camp == CAMP.RED and "jibanyou1_1" or "jibanzuo1_1"  --self.Camp == CAMP.RED and jiban2_1 or jiban2_1
		self.levelSpList[2].SpriteName = self:GetSpriteName(1)--self.Camp == CAMP.RED and "jibanyou1_1" or "jibanzuo1_1"
		self.levelSpList[3].SpriteName = self:GetSpriteName(1)--self.Camp == CAMP.RED and "jibanyou1_1" or "jibanzuo1_1"
		self.effectCount = 3
		if self.speciallevel > 0 then
			for i=1, self.speciallevel do
				if self.levelSpList[3 + i] then
					self.levelSpList[3 + i].SpriteName = self:GetSpriteName(3)--self.Camp == CAMP.RED and "jibanyou1_3" or "jibanzuo1_3"
					self.effectCount = self.effectCount + 1
				end
			end
		end
	elseif self.relationlevel == 2 then
		self.levelSpList[1].SpriteName = self:GetSpriteName(1)--self.Camp == CAMP.RED and "jibanyou1_1" or "jibanzuo1_1"
		self.levelSpList[2].SpriteName = self:GetSpriteName(1)--self.Camp == CAMP.RED and "jibanyou1_1" or "jibanzuo1_1"
		self.levelSpList[3].SpriteName = self:GetSpriteName(1)--self.Camp == CAMP.RED and "jibanyou1_1" or "jibanzuo1_1"
		self.levelSpList[4].SpriteName = self:GetSpriteName(2)--self.Camp == CAMP.RED and "jibanyou1_2" or "jibanzuo1_2"
		self.levelSpList[5].SpriteName = self:GetSpriteName(2)--self.Camp == CAMP.RED and "jibanyou1_2" or "jibanzuo1_2"
		self.effectCount = 5
	elseif self.relationlevel == 3 then
		self.levelSpList[1].SpriteName = self:GetSpriteName(1)--self.Camp == CAMP.RED and "jibanyou1_1" or "jibanzuo1_1"
		self.levelSpList[2].SpriteName = self:GetSpriteName(1)--self.Camp == CAMP.RED and "jibanyou1_1" or "jibanzuo1_1"
		self.levelSpList[3].SpriteName = self:GetSpriteName(1)--self.Camp == CAMP.RED and "jibanyou1_1" or "jibanzuo1_1"
		self.levelSpList[4].SpriteName = self:GetSpriteName(1)--self.Camp == CAMP.RED and "jibanyou1_1" or "jibanzuo1_1"
		self.effectCount = 4
		if self.speciallevel > 0 then
			self.levelSpList[5].SpriteName = self:GetSpriteName(3)--self.Camp == CAMP.RED and "jibanyou1_3" or "jibanzuo1_3"
			self.effectCount = self.effectCount + 1
		end	

	elseif self.relationlevel == 4 then
		self.levelSpList[1].SpriteName = self:GetSpriteName(1) --self.Camp == CAMP.RED and "jibanyou1_1" or "jibanzuo1_1"
		self.levelSpList[2].SpriteName = self:GetSpriteName(1) --self.Camp == CAMP.RED and "jibanyou1_1" or "jibanzuo1_1"
		self.levelSpList[3].SpriteName = self:GetSpriteName(1) --self.Camp == CAMP.RED and "jibanyou1_1" or "jibanzuo1_1"
		self.levelSpList[4].SpriteName = self:GetSpriteName(1) --self.Camp == CAMP.RED and "jibanyou1_1" or "jibanzuo1_1"
		self.levelSpList[5].SpriteName = self:GetSpriteName(1) --self.Camp == CAMP.RED and "jibanyou1_1" or "jibanzuo1_1"
		self.effectCount = 5
	elseif self.speciallevel == 1 then
		self.levelSpList[1].SpriteName = self:GetSpriteName(3)--self.Camp == CAMP.RED and "jibanyou1_3" or "jibanzuo1_3"
		self.effectCount = 1
	elseif self.speciallevel == 2 then
		self.levelSpList[1].SpriteName = self:GetSpriteName(3)--self.Camp == CAMP.RED and "jibanyou1_3" or "jibanzuo1_3"
		self.levelSpList[2].SpriteName = self:GetSpriteName(3)--self.Camp == CAMP.RED and "jibanyou1_3" or "jibanzuo1_3"
		self.effectCount = 2
	elseif self.speciallevel == 3 then
		self.levelSpList[1].SpriteName = self:GetSpriteName(3)--self.Camp == CAMP.RED and "jibanyou1_3" or "jibanzuo1_3"
		self.levelSpList[2].SpriteName = self:GetSpriteName(3)--self.Camp == CAMP.RED and "jibanyou1_3" or "jibanzuo1_3"
		self.levelSpList[3].SpriteName = self:GetSpriteName(3)--self.Camp == CAMP.RED and "jibanyou1_3" or "jibanzuo1_3"
		self.effectCount = 3
	elseif self.speciallevel == 4 then
		self.levelSpList[1].SpriteName = self:GetSpriteName(3)--self.Camp == CAMP.RED and "jibanyou1_3" or "jibanzuo1_3"
		self.levelSpList[2].SpriteName = self:GetSpriteName(3)--self.Camp == CAMP.RED and "jibanyou1_3" or "jibanzuo1_3"
		self.levelSpList[3].SpriteName = self:GetSpriteName(3)
		self.levelSpList[4].SpriteName = self:GetSpriteName(3)
		self.effectCount = 4
	elseif self.speciallevel == 5 then
		self.levelSpList[1].SpriteName = self:GetSpriteName(3)
		self.levelSpList[2].SpriteName = self:GetSpriteName(3)
		self.levelSpList[3].SpriteName = self:GetSpriteName(3)
		self.levelSpList[4].SpriteName = self:GetSpriteName(3)
		self.levelSpList[5].SpriteName = self:GetSpriteName(3)		
		self.effectCount = 5				
	end	
	self:ShowEffect(self.relationlevel, self.speciallevel)
end

function BattleRelationItem:InitData()
	for idx, sprite in pairs(self.levelSpList) do
		sprite.SpriteName = ""
	end
end

function BattleRelationItem:ResetEffectList()
	if self.effectLists then
		for i,effect in ipairs(self.effectLists) do
			effect:Close()
		end
	end
end

function BattleRelationItem:ResetBattleEffect()
	if self.effect then
		self.effect:Close()
	end
end

function BattleRelationItem:ShowEffect(relationlevel, speciallevel)
	if self.viewType == 2 then
		--战斗界面的特效显示
		self:ResetBattleEffect()
		if relationlevel > 0 then
			self:ShowCampEffect()
		end
	else
		self:ResetEffectList()
		--上阵界面的特效显示
		self:ShowBattleCampEffect()
	end
end

function BattleRelationItem:Close()
	self:ResetEffectList()
	self:ResetBattleEffect()
	self.effectDepth = nil
	self.frontObjDepth = nil
end

function BattleRelationItem:Destroy()
	self:ResetEffectList()
	self:ResetBattleEffect()
	self.effectDepth = nil
	self.frontObjDepth = nil
end

function BattleRelationItem:ShowCampEffect()
	if self.effect then
		self.effect:Open()
		self.effect:SetOrderLayer(self.effectDepth)
		if self.frontObj then
			self:SetDepth(self.frontObj, self.frontObjDepth)
		end
	end
end

function BattleRelationItem:ShowBattleCampEffect()
	if self.effectLists then
		if self.effectLists[self.effectCount] then
			self.effectLists[self.effectCount]:Open()
			self.effectLists[self.effectCount]:SetOrderLayer(self.effectDepth)
			if self.frontObj then
				self:SetDepth(self.frontObj, self.frontObjDepth)
			end
		end
	end
end

return BattleRelationItem