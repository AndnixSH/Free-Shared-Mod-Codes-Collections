local MazeMediator = MazeMediator or BaseClass(StdMediator)
local LoginDef = require "Modules.Login.LoginDef"
local MazeProxy = require "Modules.Maze.MazeProxy"

function MazeMediator:SubListNotificationInterests()
	return {AppFacade.Login}
end

function MazeMediator:OnLuaNotifyForSubList(data, strEvent, args)
	if strEvent == AppFacade.Login then
		if args == LoginDef.NotifyDef.Cross_Day then
			MazeProxy.Instance:CrossDay()
		end
	end
end

return MazeMediator