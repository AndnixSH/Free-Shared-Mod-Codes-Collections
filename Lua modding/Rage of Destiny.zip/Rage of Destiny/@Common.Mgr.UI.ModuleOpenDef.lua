local ModuleOpenDef = {}

--系统开启条件类型
ModuleOpenDef.SystemOpenType = 
{
	--系统
	HeroRootView = 1,  --英雄界面相关(英雄界面，英雄升级，一键穿戴)
	TerritoryView = 2, --领地入口
	CardPortView = 3, --抽卡入口
	TempleView = 4, --大圣堂入口
	FountainView = 5, --洗涤入口
	StoreView = 6, --矮人商店入口
	CrystalView = 7, --共鸣水晶入口

	--玩法
	MazeView = 8, --巨龙迷窟入口
	TowerEntranceView_0 = 9,   --迷宫基础塔
	TowerEntranceView_1 = 10,  --圣光塔
	TowerEntranceView_2 = 11,  --蛮荒塔
	TowerEntranceView_3 = 12,  --自然塔
	TowerEntranceView_4 = 13,  --暗影塔	
	StoryLineRootView = 14,    --剧情副本
	QuickHangUp = 15,          --快速挂机

	--战斗
	AutoBigKill = 16, --自动大招
	DoubleFrame = 17, --2倍速

	MailView = 18, --邮件
	BagRootView = 19, --背包
	HomePageView = 20, --个人主页
	MainTaskView = 30, --主线任务
	MainLine = 31, --主线副本
	FriendlListView = 32, --好友
	GuildRootView = 33, --公会
	ChatRootView = 34, --聊天
	Journey = 35, --征途

	ArenaEntranceView=36,--竞技场
	ProArenaEntranceView=37,--高阶竞技场

	SupplyDepotView = 38, --补给站
	RankListView = 39, --排行榜
	MallRootView = 40, --商城

	ArtifactEquip = 41, --神器
	MazeHard = 42, --巨龙困难模式
	RelationMenuRootView = 43, --英雄羁绊入口
	SupplyDepotQuickDispatch = 44, --补给站一键派遣
	GuildBossSweep = 45, --公会boss扫荡
	ArenaSkip = 46, --竞技场跳过战斗
	CardStarView = 47, --占星

	StoryLine_Copy_1 = 48, --时光副本1
	StoryLine_Copy_2 = 49, 
	StoryLine_Copy_3 = 50, 
	StoryLine_Copy_4 = 51, 
	StoryLine_Copy_5 = 52, 
	StoryLine_Copy_6 = 53, 
	StoryLine_Copy_7 = 54, 
	StoryLine_Copy_8 = 55, 
	StoryLine_Copy_9 = 56, --时光副本9

	RelationMenuRootView_2 = 57, --领地羁绊入口
	ActivityRoot = 58, --领地羁绊入口

	MallDaily = 59, --商城日礼包
	MallWeekly = 60, --商城周礼包
	MallMonthly = 61, --商城月礼包

	Activity_Seven_Login = 62,
	Activity_New_Player = 63,
	Activity_StageClearCharge = 64,
	Activity_HatharalComing = 65,

	AutoBattle = 66,
	DailyTaskView = 67, --日常任务
	WeekTaskView = 68, --周常任务

	RealmRootView = 69, --幻境
	FirstCharge = 70,--首充
	Activity_Share = 71,--分享

	CardWishPool = 72,--心愿单

	CycleActivityRoot = 73,

	Tree = 74, --生命之树
	CycleSevenLoginTypeTwoView = 75, --七日签到2号
	GuildChaosView = 76,  --混沌裂隙

	StoryLine_Copy_10 = 77, --时光副本10
	FourFrame = 78,	--4倍速
	EventsNineBoxView = 79, --九宫格活动
	MobilizeView = 80, --命运总动员
	StoryLine_Copy_11 = 81, --时光副本11
	HappyMonthPanel = 82,  --女王狂欢祭

	VoidBossView = 83, --活动boss：虚空狩猎

	StoryLine_Copy_12 = 84, --时光副本12
}
--conditions = {{openMainId=1,vip=2}} ; conditions = {{openMainId = 1} , {vip = 2}}; conditions = {{openMainId = 1}} ; conditions = {{vip = 1}} 
	--系统开启条件配置 openMainId:主线id(openMainId =1 的意思是已经通关主线id=1 才开启 ) vip（vip等级）  tipsType:未开启时弹tips类型   name:ee title：标题  content：内容 
	--conditions = {{openMainId=0, vip=1}} --同时满足
	--conditions = {{openMainId=0},{vip=1}} --满足其中一个
	--conditions = {{openMainId=0}} --满足主线id
	--conditions = {{vip=1}} --满足vip
ModuleOpenDef.SystemOpen = {
		[ModuleOpenDef.SystemOpenType.HeroRootView] = {conditions = {{openMainId=3}},  tipsType = 2, name = "", title= "Newbie_tips_title_1001", content = ""},--英雄列表
		[ModuleOpenDef.SystemOpenType.TerritoryView] = {conditions = {{openMainId=12}}, tipsType = 2, name = "", title= "Newbie_tips_title_1002", content = ""},--领地
		[ModuleOpenDef.SystemOpenType.CardPortView] = {conditions = {{openMainId=12}}, tipsType = 1, name = "Newbie_tips_name_1001", title= "Newbie_tips_title_1003", content = "Newbie_tips_content_1001"},--星界之门
		[ModuleOpenDef.SystemOpenType.TempleView] = {conditions = {{openMainId=13}}, tipsType = 1, name = "Newbie_tips_name_1002", title= "Newbie_tips_title_1004", content = "Newbie_tips_content_1002"},--光明圣堂
		[ModuleOpenDef.SystemOpenType.FountainView] = {conditions = {{openMainId=14}}, tipsType = 1, name = "Newbie_tips_name_1003", title= "Newbie_tips_title_1005", content = "Newbie_tips_content_1003"},--净化圣泉
		[ModuleOpenDef.SystemOpenType.StoreView] = {conditions = {{openMainId=16}}, tipsType = 1, name = "Newbie_tips_name_1004", title= "Newbie_tips_title_1006", content = "Newbie_tips_content_1004"},--矮人商队
		[ModuleOpenDef.SystemOpenType.CrystalView] = {conditions = {{openMainId=76}}, tipsType = 1, name = "Newbie_tips_name_1005", title= "Newbie_tips_title_1007", content = "Newbie_tips_content_1005"},--命运水晶
		[ModuleOpenDef.SystemOpenType.MazeView] = {conditions = {{openMainId=16}}, tipsType = 1, name = "Newbie_tips_name_1006", title= "Newbie_tips_title_1008", content = "Newbie_tips_content_1006"},--巨龙巢穴
		[ModuleOpenDef.SystemOpenType.TowerEntranceView_0] = {conditions = {{openMainId=28}}, tipsType = 1, name = "Newbie_tips_name_1007", title= "Newbie_tips_title_1009", content = "Newbie_tips_content_1007"},--赎罪之塔
		[ModuleOpenDef.SystemOpenType.TowerEntranceView_1] = {conditions = {{openMainId=512}}, tipsType = 2, name = "", title= "Newbie_tips_title_1010", content = ""},--种族塔
		[ModuleOpenDef.SystemOpenType.TowerEntranceView_2] = {conditions = {{openMainId=512}}, tipsType = 2, name = "", title= "Newbie_tips_title_1011", content = ""},--种族塔
		[ModuleOpenDef.SystemOpenType.TowerEntranceView_3] = {conditions = {{openMainId=512}}, tipsType = 2, name = "", title= "Newbie_tips_title_1012", content = ""},--种族塔
		[ModuleOpenDef.SystemOpenType.TowerEntranceView_4] = {conditions = {{openMainId=512}}, tipsType = 2, name = "", title= "Newbie_tips_title_1013", content = ""},--种族塔
		[ModuleOpenDef.SystemOpenType.DoubleFrame] = {conditions = {{openMainId=3}}, tipsType = 2, name = "", title= "Newbie_tips_title_1014", content = ""},--二倍速
		[ModuleOpenDef.SystemOpenType.StoryLineRootView] = {conditions = {{openMainId=156}}, tipsType = 1, name = "Newbie_tips_name_1008", title= "Newbie_tips_title_1015", content = "Newbie_tips_content_1008"},--时空战场
		[ModuleOpenDef.SystemOpenType.QuickHangUp] = {conditions = {{openMainId=28},{vip=2}}, tipsType = 2, name = "", title= "Newbie_tips_title_1016", content = ""},--快速挂机
		[ModuleOpenDef.SystemOpenType.ArenaEntranceView] = {conditions = {{openMainId=40}}, tipsType = 1, name = "Newbie_tips_name_1009", title= "Newbie_tips_title_1017", content = "Newbie_tips_content_1009"},--竞技场
		[ModuleOpenDef.SystemOpenType.ProArenaEntranceView] = {conditions = {{openMainId=292}}, tipsType = 2, name = "", title= "Newbie_tips_title_1018", content = ""},--高阶竞技场
		[ModuleOpenDef.SystemOpenType.RelationMenuRootView] = {conditions = {{openMainId=36}}, tipsType = 2, name = "", title= "Newbie_tips_title_1019", content = ""},--英雄羁绊入口
		[ModuleOpenDef.SystemOpenType.RelationMenuRootView_2] = {conditions = {{openMainId=36}}, tipsType = 1, name = "Newbie_tips_name_1010", title= "Newbie_tips_title_1019", content = "Newbie_tips_content_1010"},--先知古树入口
		[ModuleOpenDef.SystemOpenType.MailView] = {conditions = {{openMainId=0}}, tipsType = 2, name = "", title= "Newbie_tips_title_1020", content = ""},	--邮件
		[ModuleOpenDef.SystemOpenType.BagRootView] = {conditions = {{openMainId=0}}, tipsType = 2, name = "", title= "Newbie_tips_title_1021", content = ""},	--背包
		[ModuleOpenDef.SystemOpenType.HomePageView] = {conditions = {{openMainId=0}}, tipsType = 2, name = "", title= "Newbie_tips_title_1022", content = ""},	--个人主页
		[ModuleOpenDef.SystemOpenType.MainTaskView] = {conditions = {{openMainId=6}}, tipsType = 2, name = "", title= "Newbie_tips_title_1023", content = ""},	--主线任务
		[ModuleOpenDef.SystemOpenType.MainLine] = {conditions = {{openMainId=0}}, tipsType = 2, name = "", title= "Newbie_tips_title_1024", content = ""},	--主线推图
		[ModuleOpenDef.SystemOpenType.FriendlListView] = {conditions = {{openMainId=12}}, tipsType = 2, name = "", title= "Newbie_tips_title_1025", content = ""},	--好友列表
		[ModuleOpenDef.SystemOpenType.AutoBigKill] = {conditions = {{openMainId=1}}, tipsType = 2, name = "", title= "Newbie_tips_title_1026", content = ""},--自动大招
		[ModuleOpenDef.SystemOpenType.GuildRootView] = {conditions = {{openMainId=32}}, tipsType = 1, name = "Newbie_tips_name_1011", title= "Newbie_tips_title_1027", content = "Newbie_tips_content_1011"},--公会
		[ModuleOpenDef.SystemOpenType.ChatRootView] = {conditions = {{openMainId=0}}, tipsType = 2, name = "", title= "Newbie_tips_title_1028", content = ""},  --聊天	
		[ModuleOpenDef.SystemOpenType.Journey] = {conditions = {{openMainId=16}}, tipsType = 2, name = "", title= "Newbie_tips_title_1029", content = ""}, --征途
		[ModuleOpenDef.SystemOpenType.SupplyDepotView] = {conditions = {{openMainId=52}}, tipsType = 2, name = "Newbie_tips_name_1012", title= "Newbie_tips_title_1030", content = "Newbie_tips_content_1012"},--贸易航线
		[ModuleOpenDef.SystemOpenType.RankListView] = {conditions = {{openMainId=76}}, tipsType = 1, name = "Newbie_tips_name_1013", title= "Newbie_tips_title_1031", content = "Newbie_tips_content_1013"}, --排行榜
		[ModuleOpenDef.SystemOpenType.MallRootView] = {conditions = {{openMainId=14}}, tipsType = 2, name = "", title= "Newbie_tips_title_1032", content = ""},--商城
		[ModuleOpenDef.SystemOpenType.ArtifactEquip] = {conditions = {{openMainId=156}}, tipsType = 2, name = "", title= "Newbie_tips_title_1033", content = ""}, --神器
		[ModuleOpenDef.SystemOpenType.MazeHard] = {conditions = {{openMainId=296}}, tipsType = 2, name = "", title= "Newbie_tips_title_1034", content = ""}, --巨龙困难模式
		[ModuleOpenDef.SystemOpenType.SupplyDepotQuickDispatch] = {conditions = {{openMainId=192},{vip=6}}, tipsType = 2, name = "", title= "Newbie_tips_title_1044", content = ""}, --贸易航线一键派遣
		[ModuleOpenDef.SystemOpenType.GuildBossSweep] = {conditions = {{vip=0}}, tipsType = 2, name = "", title= "Newbie_tips_title_1045", content = ""}, --公会boss扫荡
		[ModuleOpenDef.SystemOpenType.ArenaSkip] = {conditions = {{vip=6}}, tipsType = 2, name = "", title= "Newbie_tips_title_1046", content = ""}, --竞技场跳过
		[ModuleOpenDef.SystemOpenType.CardStarView] = {conditions = {{openMainId = 552} , {vip = 13}}, tipsType = 2, name = "", title= "Newbie_tips_title_1047", content = ""}, --占星
		[ModuleOpenDef.SystemOpenType.MallDaily] = {conditions = {{vip=2}}, tipsType = 2, name = "", title= "Newbie_tips_title_1048", content = ""}, --商城日礼包
		[ModuleOpenDef.SystemOpenType.MallWeekly] = {conditions = {{vip=2}}, tipsType = 2, name = "", title= "Newbie_tips_title_1049", content = ""}, --商城周礼包
		[ModuleOpenDef.SystemOpenType.MallMonthly] = {conditions = {{vip=2}}, tipsType = 2, name = "", title= "Newbie_tips_title_1050", content = ""}, --商城月礼包

		[ModuleOpenDef.SystemOpenType.StoryLine_Copy_1] = {conditions = {{openMainId=156}}, tipsType = 2, name = "", title= "Newbie_tips_title_1035", content = ""}, --时空战场1
		[ModuleOpenDef.SystemOpenType.StoryLine_Copy_2] = {conditions = {{openMainId=196}}, tipsType = 2, name = "", title= "Newbie_tips_title_1036", content = ""}, --时空战场2
		[ModuleOpenDef.SystemOpenType.StoryLine_Copy_3] = {conditions = {{openMainId=236}}, tipsType = 2, name = "", title= "Newbie_tips_title_1037", content = ""}, --时空战场3
		[ModuleOpenDef.SystemOpenType.StoryLine_Copy_4] = {conditions = {{openMainId=276}}, tipsType = 2, name = "", title= "Newbie_tips_title_1038", content = ""}, --时空战场4
		[ModuleOpenDef.SystemOpenType.StoryLine_Copy_5] = {conditions = {{openMainId=316}}, tipsType = 2, name = "", title= "Newbie_tips_title_1039", content = ""}, --时空战场5
		[ModuleOpenDef.SystemOpenType.StoryLine_Copy_6] = {conditions = {{openMainId=356}}, tipsType = 2, name = "", title= "Newbie_tips_title_1040", content = ""}, --时空战场6
		[ModuleOpenDef.SystemOpenType.StoryLine_Copy_7] = {conditions = {{openMainId=396}}, tipsType = 2, name = "", title= "Newbie_tips_title_1041", content = ""}, --时空战场7
		[ModuleOpenDef.SystemOpenType.StoryLine_Copy_8] = {conditions = {{openMainId=436}}, tipsType = 2, name = "", title= "Newbie_tips_title_1042", content = ""}, --时空战场8
		[ModuleOpenDef.SystemOpenType.StoryLine_Copy_9] = {conditions = {{openMainId=476}}, tipsType = 2, name = "", title= "Newbie_tips_title_1043", content = ""}, --时空战场9
		[ModuleOpenDef.SystemOpenType.StoryLine_Copy_10] = {conditions = {{openMainId=516}}, tipsType = 2, name = "", title= "Newbie_tips_title_1065", content = ""}, --时空战场10
		[ModuleOpenDef.SystemOpenType.StoryLine_Copy_11] = {conditions = {{openMainId=556}}, tipsType = 2, name = "", title= "Newbie_tips_title_1069", content = ""}, --时空战场11
		[ModuleOpenDef.SystemOpenType.StoryLine_Copy_12] = {conditions = {{openMainId=596}}, tipsType = 2, name = "", title= "Newbie_tips_title_1071", content = ""}, --时空战场12
	
		[ModuleOpenDef.SystemOpenType.Activity_Seven_Login] = {conditions = {{openMainId=12}}, tipsType = 2, name = "", title= "Newbie_tips_title_1051", content = ""}, --七日登录-小鹿
		[ModuleOpenDef.SystemOpenType.Activity_New_Player] = {conditions = {{openMainId=18}}, tipsType = 2, name = "", title= "Newbie_tips_title_1052", content = ""}, --新兵特训
		[ModuleOpenDef.SystemOpenType.Activity_HatharalComing] = {conditions = {{openMainId=24}}, tipsType = 2, name = "", title= "Newbie_tips_title_1053", content = ""}, --精灵之王
		[ModuleOpenDef.SystemOpenType.Activity_StageClearCharge] = {conditions = {{openMainId=13}}, tipsType = 2, name = "", title= "Newbie_tips_title_1054", content = ""}, --冲关奖励
		[ModuleOpenDef.SystemOpenType.FirstCharge] = {conditions = {{openMainId=14}}, tipsType = 2, name = "", title= "Newbie_tips_title_1058", content = ""}, --首充
		[ModuleOpenDef.SystemOpenType.Activity_Share] = {conditions = {{openMainId=14}}, tipsType = 2, name = "", title= "Newbie_tips_title_1059", content = ""}, --分享

		[ModuleOpenDef.SystemOpenType.CycleActivityRoot] = {conditions = {{openMainId=232}}, tipsType = 2, name = "", title= "Newbie_tips_title_1051", content = ""}, --七日签到-酷夏
	
		[ModuleOpenDef.SystemOpenType.AutoBattle] = {conditions = {{openMainId=6}}, tipsType = 2, name = "", title= "Newbie_tips_title_1055", content = ""}, --自动推图	
		[ModuleOpenDef.SystemOpenType.DailyTaskView] = {conditions = {{openMainId=13}}, tipsType = 2, name = "", title= "Newbie_tips_title_1056", content = ""},	--日常任务
		[ModuleOpenDef.SystemOpenType.WeekTaskView] = {conditions = {{openMainId=13}}, tipsType = 2, name = "", title= "Newbie_tips_title_1057", content = ""},	--周常任务
	
		[ModuleOpenDef.SystemOpenType.RealmRootView] = {conditions = {{openMainId=232}}, tipsType = 1, name = "Newbie_tips_name_1014", title= "Newbie_tips_title_1060", content = "Newbie_tips_content_1014"},	--幻境
		[ModuleOpenDef.SystemOpenType.CardWishPool] = {conditions = {{openMainId=41}}, tipsType = 2, name = "", title= "Newbie_tips_title_1061", content = ""},--许愿单

		[ModuleOpenDef.SystemOpenType.Tree] = {conditions = {{openMainId=272}}, tipsType = 2, name = "", title= "Newbie_tips_title_1062", content = ""},	--神谕树魂
		[ModuleOpenDef.SystemOpenType.GuildChaosView] = {conditions = {{openMainId=272}}, tipsType = 2, name = "", title= "Newbie_tips_title_1063", content = ""},	--混沌裂隙
		[ModuleOpenDef.SystemOpenType.CycleSevenLoginTypeTwoView] = {conditions = {{openMainId=192}}, tipsType = 2, name = "", title= "Newbie_tips_title_1064", content = ""},	--七日签到2号
		[ModuleOpenDef.SystemOpenType.FourFrame] = {conditions = {{openMainId=232},{vip=9}}, tipsType = 2, name = "", title= "Newbie_tips_title_1066", content = ""},	--4倍速战斗
		[ModuleOpenDef.SystemOpenType.EventsNineBoxView] = {conditions = {{openMainId=192}}, tipsType = 2, name = "", title= "Newbie_tips_title_1067", content = ""},	--九宫格活动
		[ModuleOpenDef.SystemOpenType.MobilizeView] = {conditions = {{openMainId=312}}, tipsType = 2, name = "", title= "Newbie_tips_title_1068", content = ""},	--命运总动员
		[ModuleOpenDef.SystemOpenType.HappyMonthPanel] = {conditions = {{openMainId=14}}, tipsType = 2, name = "", title= "Newbie_tips_title_1070", content = ""},	--女王狂欢祭

		[ModuleOpenDef.SystemOpenType.VoidBossView] = {conditions = {{openMainId=0}}, tipsType = 2, name = "", title= "Newbie_tips_title_1063", content = ""},	--虚空狩猎
		
}
return ModuleOpenDef