
local ArenaProxy = require "Modules.Arena.ArenaProxy"
local ArenaDef = require "Modules.Arena.ArenaDef"
local HeroProxy = require "Modules.Hero.HeroProxy"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local CToggleRender = require "Core.Implement.UI.Class.CToggleRender"
local ProArenaBattlePanel = ProArenaBattlePanel or BaseClass(GameObjFactor)
function ProArenaBattlePanel:__init(go)
	--self.args = args
    --self.go = go
   
	self.curIndex=1
	self.teamNum=3
	self.formations={}
	self.heroUpNum=5
	self.type=1 -- 设置防守页面 or 战斗选择页面 防守页面不显示CButton_begin
	self.bShowTeam = false --false显示英雄列表 true编队列表
	self.callback=false
	self.enemyinfos=false
	self.tempformations = {{},{},{}}
	self:Load(go)	
end
function ProArenaBattlePanel:Load(obj)

    self.rootObj=self:GetChild(obj,"newinfo") 
	
	
	self.beginBtn=self:GetChild(obj,"bottom/CButton_begin")

    self.saveBtn = self:GetChildComponent(self.rootObj, "CButton_save", "CButton")
	self.saveBtn:AddClick(function ()
		self:OnClickSave()
	end)
	
	self.nextBtn = self:GetChildComponent(self.rootObj, "CButton_next", "CButton")
	self.nextBtn:AddClick(function ()
		self:OnClickNext()
    end)
    
    local changeteamBtn=self:GetChildComponent(self.rootObj,"CSprite_changeteam","CButton")
    changeteamBtn:AddClick(function ()
		self:OnClickChangeTeam()
    end)

    self.togGroup = self:GetChildComponent(self.rootObj, "CTogglePage", "CToggleGroup")

	self.togRender = CToggleRender.New()
	self.togRender:Load(self.togGroup, 0)
	self.togRender:AddSelect(function(index)
		self:OnTogChange(index)
	end)

	for i=1,self.teamNum do
		self.togRender:Add()
		self.togRender:SetNormalInfo(i, tostring(i))
		self.togRender:SetSelectInfo(i, tostring(i))
		self.togRender:SetLock(i, false)
		self.togRender:SetViewOpen(i, true)
    end
	self.togGroup_pos1 = self.togGroup.transform.localPosition
	self.togGroup_pos2 = Vector3.New(self.togGroup_pos1.x,self.togGroup_pos1.y-45,self.togGroup_pos1.z)
end

function ProArenaBattlePanel:Open(battleSelectHeroItemPanel,curIndex,type,func)
	--type 2为战斗页面 ；nil 或者 1 为设置防守页面
	self.rootObj:SetActive(true)
	self.togGroup.gameObject:SetActive(true)
	self.type=type
	self.curIndex=curIndex
	self.callback=func

	--编队相关
	self.bShowTeam = false
	self:ShowRightGroupObj()

    self.battleSelectHeroItemPanel=battleSelectHeroItemPanel
	local data=ArenaProxy.Instance:GetFormations(ArenaDef.RoomType.HighArena)
	if type == 2 then
		local BattleProxy = require "Modules.Battle.BattleProxy"
		local defaultTeam = BattleProxy.Instance:GetDefaultTeam(ACTIVITYID.HIGHARENA)

		data={}
		for i=1,self.teamNum do
			data[i]={}
		end
		local index=1
		for i=1,#defaultTeam do
			local kk= i / 5 
			if  kk < index then
				
				if self.battleSelectHeroItemPanel:_GetHeroDataByUid(defaultTeam[i]) then
					table.insert(data[index],defaultTeam[i])
				else
					table.insert(data[index],0)
				end
				
			elseif kk == index then
				
				if self.battleSelectHeroItemPanel:_GetHeroDataByUid(defaultTeam[i]) then
					table.insert(data[index],defaultTeam[i])
				else
					table.insert(data[index],0)
				end
				index=index + 1
			end
			
		end
		for i=#defaultTeam+1,self.heroUpNum*self.teamNum do
			local kk= i / 5 
			if  kk < index then
				table.insert(data[index],0)
			elseif kk == index then

				table.insert(data[index],0)
				index=index + 1
			end
			
		end
	end
	self.formations=table.deepcopy(data) 
	if self.curIndex == 0 or self.curIndex > self.teamNum or not self.curIndex then
		self.curIndex=1
	end
	self.togRender:SelectIndex(self.curIndex )
	if self.curIndex  < self.teamNum then
		self:ShowSaveBtn(false)
	else
		self:ShowSaveBtn(true)
	end
end

--编队相关
function ProArenaBattlePanel:OnClickTeamBtn()
	self.bShowTeam = self.bShowTeam == false and true or false
	self:ShowRightGroupObj()
end

function ProArenaBattlePanel:ShowRightGroupObj()
	--self.togGroup.gameObject:SetActive(self.bShowTeam == false and true or false)
	if self.bShowTeam then
		self.togGroup.transform.localPosition = self.togGroup_pos2
	else
		self.togGroup.transform.localPosition = self.togGroup_pos1
	end
end

function ProArenaBattlePanel:Close()
	self.curIndex=1
	self.rootObj:SetActive(false)
	self.beginBtn.gameObject:SetActive(true)
end	

function ProArenaBattlePanel:Destroy()
end
function ProArenaBattlePanel:OnClickSave()
	self:SaveCurTeamFormation()
    local data=self.formations
	local formationsList={}
	for k=1,#self.formations do
		local _formation=self.formations[k]
		local formations={}
		if _formation then
			for i=1,#_formation do
				if _formation[i] then
					if _formation[i] ~= 0 and i <= 5 and _formation[i] ~= -1 then
						local item={}
						item[1]=i
						item[2]=_formation[i]
						table.insert(formations,item)
					end
				end
			end
		end
		table.insert(formationsList,formations)
	end
	for i =1,#formationsList do
		if #formationsList[i] == 0 then
			GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord(ArenaDef.CommonDef.TeamCannotEmpty))
			return
		end
	end
    ArenaProxy.Instance:Send55002(ArenaDef.RoomType.HighArena,formationsList)
end

function ProArenaBattlePanel:OnClickNext()
	local _formation=self.battleSelectHeroItemPanel:GetDefaultSelectHeroList()
		local empty=true
		if _formation then
			for k=1,#_formation do
				if _formation[k] ~= -1 and _formation[k] ~= 0 then
					empty=false
				end
			end
		end
		if empty then
			GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord(ArenaDef.CommonDef.PleaseChooseUpHero))
			return
		end
	if self.curIndex < self.teamNum then
		local index = self.curIndex +1
		if index  <= self.teamNum then
			self.togRender:SelectIndex(index)

			if index == self.teamNum then
				self:ShowSaveBtn(true)
			end
		end
	end
	
end

function ProArenaBattlePanel:ShowSaveBtn(show)
	if self.type ~= 2 then
		self.saveBtn.gameObject:SetActive(show)
		self.nextBtn.gameObject:SetActive(not show)
	else
		self.nextBtn.gameObject:SetActive(not show)
		self.saveBtn.gameObject:SetActive(false)
		self.beginBtn.gameObject:SetActive(show)
	end
	
end

function ProArenaBattlePanel:OnClickChangeTeam()
   local view=LuaLayout.Instance:GetWidget(UIWidgetNameDef.ProArenaTeamChangeView)
   if view then
		
		view.proArenaBattlePanel=self
		view.enemyid=self.battleSelectHeroItemPanel.args[1]
		view:OpenView()
   end
end

function ProArenaBattlePanel:GetSeverHeroData()
	local list={}
	local savedefaultlist={}
	for i, _formation in ipairs(self.formations) do
		local isempty=true
		if _formation then
			local team={}
			for k, v in ipairs(_formation) do
				if v ~= -1 and v ~= 0 then
					isempty=false
					local heroinfo = self.battleSelectHeroItemPanel:_GetHeroDataByUid(v)
					heroinfo.stance = k
					table.insert(team, heroinfo)

					table.insert(savedefaultlist,v)
				else
					table.insert(savedefaultlist,0)
				end
			end
			table.insert(list, team)
		end
		if isempty then
			GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord(ArenaDef.CommonDef.TeamCannotEmpty))
			return nil,nil
		end
	end
	return list,savedefaultlist
end

function ProArenaBattlePanel:SetFormations(end_order)
	local tempdata={}
	for i=1,#end_order do
		table.insert(tempdata,self.formations[end_order[i]])
	end
	self.formations=tempdata
	--切换
	local func=function ( id )
		self:CallBackHandle(id,self.curIndex)
	end
	local defaultTeam={}
	local enemyinfos=ArenaProxy.Instance:GetEnermyFormations(self.curIndex)
	self:UpdateOneFormation(self.curIndex,defaultTeam,enemyinfos,func)
end

function ProArenaBattlePanel:GetMyFormations()
	local list={}
	self:SaveCurTeamFormation() --保存当前场的调整
    local formations=self.formations
    for i, _formation in ipairs(formations) do
        if _formation then
            local team={}
            for k, v in ipairs(_formation) do
                if v ~= -1 and v ~= 0 then
                    local heroinfo = self.battleSelectHeroItemPanel:_GetHeroDataByUid(v)
                    heroinfo.stance = k
                    table.insert(team, heroinfo)
                else
                    table.insert(team, 0)
                end
            end
            table.insert(list, team)
        end
    end
    return list
end

--替换队伍英雄到别的队
function ProArenaBattlePanel:ReplaceFormations(roleIdDic)
	for i,_formation in ipairs(self.formations) do
		for stance, _herouid in ipairs(_formation) do
			local heroinfo = self.battleSelectHeroItemPanel:_GetHeroDataByUid(_herouid)
			if heroinfo then
				if roleIdDic[heroinfo.roleid] then
					_formation[stance] = -1
					self.togRender:SetRed(i,true)
				end
			end
		end
	end
end

function ProArenaBattlePanel:StartGame(battlePanel,enemyinfos)

	self:SaveCurTeamFormation()
	local list,savedefaultlist=self:GetSeverHeroData()
	if not list then
		return
	end
	local BattleProxy = require "Modules.Battle.BattleProxy"
	BattleProxy.Instance:SetDefaultTeam(ACTIVITYID.HIGHARENA, savedefaultlist, nil)  --{enemyid, towerid}
	battlePanel:StartGame(list, enemyinfos)
end

function ProArenaBattlePanel:SaveCurTeamFormation()
	local data=self.battleSelectHeroItemPanel:GetDefaultSelectHeroList()
	local team={}
	for i=1,self.heroUpNum do
		team[i]=-1
	end
    for i=1,#data do
        if data[i] then
            if data[i] ~= 0 and i <= 5 then
                team[i]=data[i]
            end
        end
	end
	self.formations[self.curIndex]=team
end

function ProArenaBattlePanel:CallBackHandle(id,index)
	if id == 0 or id == 1 then
		local show=false
		if id == 1 then
			show=true
		end
		self.togRender:SetRed(index,show)
	elseif id == 2 then
		--上阵
		self.formations = self.tempformations 
		self.battleSelectHeroItemPanel:BackDefaultHeroData(self.formations[index]  )
		
	elseif id == 3 then
		--下阵
		self.tempformations = table.deepcopy(self.formations)
		for i=1 , self.teamNum do
			local _formation=self.formations[i]
			for k=1,self.heroUpNum do
				_formation[k]=-1
			end
		end
		self.battleSelectHeroItemPanel:CleartDefaultHeroData()
	end
	
	self:UpdateRightHeroLockState()
end

function ProArenaBattlePanel:OnTogChange(index)
	if self.curIndex ~= index then
		
		self:SaveCurTeamFormation()
	end

	self.curIndex=index
	if self.curIndex == self.teamNum then
		self:ShowSaveBtn(true)
	else
		self:ShowSaveBtn(false)
	end
	--切换
	local func=function ( id )
		self:CallBackHandle(id,self.curIndex)
	end
	--local formations=self.formations --ArenaProxy.Instance:GetFormations(ArenaDef.RoomType.HighArena)
	local defaultTeam={}
	
	self:HandleRedDot()
	if self.formations then
		local enemyinfos=ArenaProxy.Instance:GetEnermyFormations(index)
		if #self.formations == 0 then
			if self.callback then
				self.callback(defaultTeam,enemyinfos,func,false)
			end
			--self.battleSelectHeroItemPanel:ResetData(defaultTeam)
			return
		end
		
		self:UpdateOneFormation(index,defaultTeam,enemyinfos,func)
	end
end

function ProArenaBattlePanel:UpdateOneFormation(index,defaultTeam,enemyinfos,func)
	local _formation=self.formations[index]
	if _formation then
		for i=1,self.heroUpNum do
			if  _formation[i] == -1 then
				table.insert(defaultTeam,0)
			else
				table.insert(defaultTeam, _formation[i])
			end
		end
		if self.callback then
			self.callback(defaultTeam,enemyinfos,func)
		end
		--self.battleSelectHeroItemPanel:ResetData(defaultTeam)
	end
	self:UpdateRightHeroLockState()
end


function ProArenaBattlePanel:UpdateRightHeroLockState()
	local list={}
	for i=1 ,self.teamNum do
		if i ~= self.curIndex then
			if self.formations[i] then
				for _,v in ipairs(self.formations[i]) do
					if v ~= -1 and v ~= 0 then
						local item={}
						-- local herodata=HeroProxy.Instance:GetHeroDataByUid(v )
						local heroinfo = self.battleSelectHeroItemPanel:_GetHeroDataByUid(v)
						if not heroinfo then
							--防守界面的数据来源和上阵的数据来源不一样
							heroinfo = HeroProxy.Instance:GetHeroDataByUid(v)
						end
						local herocfgid=HeroProxy.Instance:GetRoleCfgByConfigId(heroinfo.roleid)
						item.heroid=v
						item.herocfgid=herocfgid.id
						table.insert(list,item)
					end
				end
			end
		end
	end
	self.battleSelectHeroItemPanel:SetState("SetSelectState",list)
end

function ProArenaBattlePanel:HandleRedDot()
	if self.formations then
		if #self.formations == 0 then
			for i=1,self.teamNum do
				self.togRender:SetRed(i,true)
			end
		end
	end
	for i=1,self.teamNum do
		local _formation=self.formations[i]
		local show=false
		if _formation then
			for k=1,#_formation do
				if _formation[k] then
					if _formation[k] == -1 or _formation[k] == 0 then
						show=true
						self.togRender:SetRed(i,true)
						break
					end
				end
			end
			if not show then
				if #_formation < self.heroUpNum then
					self.togRender:SetRed(i,true)
				else
					self.togRender:SetRed(i,false)
				end
			end
		else
			self.togRender:SetRed(i,true)
		end
	end
end

return ProArenaBattlePanel
