-- 构建服务接口
service = {}

function service.event(t)
    return dynamic(t)
end

function service.call(tag)
    return { tag = tag }
end

function service.timer()
    return {}
end

function service.state()
    return {}
end

return service