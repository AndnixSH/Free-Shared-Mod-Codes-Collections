local render_timer = {_timer_list = {}}

--local _timer_list = {}

-- local render_interval = 1 / CS.UnityEngine.Application.targetFrameRate
-- 延迟帧数执行, 0为下一帧立即执行
function render_timer.delay(frame, cb, ...)
    return render_timer._add_timer(frame, cb, false, ...)
end

-- 每多少帧执行一次, 0为每帧执行
function render_timer.add_timer(frame, cb, ...)
    return render_timer._add_timer(frame, cb, true, ...)
end

-- 延迟毫秒执行
function render_timer.delay_ms(ms, cb, ...)
    -- local frame = math.floor(ms / render_interval)
    return render_timer._add_timer(ms, cb, false, ...)
end

-- 每多少毫秒执行一次
function render_timer.add_timer_ms(ms, cb, ...)
    -- local frame = math.floor(ms / render_interval)
    return render_timer._add_timer(ms, cb, true, ...)
end

function render_timer._add_timer(frame, cb, loop, ...)
    local timer = { cur = 0, count = frame, cb = cb, loop = loop, args = { ... }, _over = false }
    table.insert(render_timer._timer_list, timer)
    return timer
end

function render_timer.remove_timer(timer) -- 下一帧删除
    if timer then
        timer._over = true
    end
end

function render_timer.FrameUpdate(self, time, deltatime)
    for index = #render_timer._timer_list, 1, -1 do
        local timer = render_timer._timer_list[index]
        if timer then
            if timer._over then
                table.remove(render_timer._timer_list, index)
                timer = nil
            else
                timer.cur = timer.cur + deltatime
                if timer.cur >= timer.count then
                    timer.cb(table.unpack(timer.args))
                    if timer.loop then
                        timer.cur = 0
                    else
                        timer._over = true
                    end
                end
            end
        end
    end
end

function render_timer.remove_all_timers()
    render_timer._timer_list = {}
end

return render_timer