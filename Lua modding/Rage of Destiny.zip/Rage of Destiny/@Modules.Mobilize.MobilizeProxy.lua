local BattleProto = require "Core.Implement.Net.BattleProto"
local CampaignProxy = require "Modules.Campaign.CampaignProxy"
local MobilizeDef= require "Modules.Mobilize.MobilizeDef"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local ModuleManager = require "Common.Mgr.UI.ModuleManager"
local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
local CycleActivityDef = require "Modules.CycleActivity.CycleActivityDef"
local ArenaDef = require "Modules.Arena.ArenaDef"
local HeroProxy = require "Modules.Hero.HeroProxy"
local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
local RedPointDef = require "Modules.RedPoint.RedPointDef"
local MobilizeProxy = MobilizeProxy or BaseClass(BaseProxy,BattleProto)


function MobilizeProxy:__init()
    MobilizeProxy.Instance = self
    self.data = {}
    self.data.mobilize = {}
    self:AddProto(65000, self.On65000) 
    self:AddProto(65001, self.On65001) 
    self:AddProto(65002, self.On65002)
    self:AddProto(65003, self.On65003)
    self:AddProto(65005, self.On65005)--上阵
    self:AddProto(65006, self.On65006)--调整防守阵容
    self:AddProto(65007, self.On65007) --开始战斗
    --self:AddProto(65008, self.On65008) --请求防守阵容

    self:AddPreBattle(ACTIVITYID.MOBILIZE, self.OnPreBattle) --准备战斗毁掉
	self:AddSetBattle(ACTIVITYID.MOBILIZE, self.OnSetBattle) --战斗结算回调	
    self:AddStartBattle(ACTIVITYID.MOBILIZE, self.OnStartBattle) --战斗开始回调

    self.test = false
    self.rewardNum = 0
end

function MobilizeProxy:__delete()
    MobilizeProxy.Instance = nil
    self.data = false
end

function MobilizeProxy:GetPointsConfig()
    local config = ConfigManager.GetConfig("data_mobilize_points")
    return config
end

function MobilizeProxy:GetRankConfig()
    local config = ConfigManager.GetConfig("data_mobilize_rank")
    return config
end

function MobilizeProxy:GetTaskConfig()
    local config = ConfigManager.GetConfig("data_mobilize_task")
    return config
end

function MobilizeProxy:GetTimeConfig()
    local config = ConfigManager.GetConfig("data_mobilize_time")
    return config
end

function MobilizeProxy:GetReadyTimeConfig(id)
    local config = self:GetTimeConfig()
    if config and config[id] then
        return config[id].pretime or 0
    end
    return 0
end

function MobilizeProxy:GetPointsById(id)
    local config = self:GetPointsConfig()
    local points = 0
    if config then
        points = config[id].points
    end
    return points
end

function MobilizeProxy:GetRankRewardByRank(rank)
    local config = self:GetRankConfig()
    if config and  self.data.mobilize.room then
        local list = {}
        for _ , cfg in ipairs(config) do
            if cfg.room == self.data.mobilize.room then
                table.insert(list,cfg)
            end
        end
        local rewards = false
        if list[rank] then
            rewards = list[rank].goods_id
        end
        return rewards
    end
end

function MobilizeProxy:GetRewardState(cfg)

    local state = MobilizeDef.Reward_State.CannotGet
    local state1 = MobilizeDef.Reward_State.CannotGet
    if  self.data.mobilize and self.data.mobilize.has_get_reward then
        local find = false
        local find2 = false
        for _ , v in ipairs(self.data.mobilize.has_get_reward) do
            local id = v[1]
            local type = v[2]
            if cfg.id == id then
                if type == MobilizeDef.RewardType.Normal then
                    find = true
                    state = MobilizeDef.Reward_State.HasGet
                elseif type == MobilizeDef.RewardType.Advance then
                    find2 = true
                    state1 = MobilizeDef.Reward_State.HasGet
                end
            end
        end
        if not find then
            if self.data.mobilize.points >= cfg.points then
                state = MobilizeDef.Reward_State.UnGet
            end
        end
        if not find2 then
            if self.data.mobilize.points >= cfg.points then
                state1 = MobilizeDef.Reward_State.UnGet
                --可以购买
            end
        end
    end
    return state , state1
end

function MobilizeProxy:GetMallIconByMallId(mallid)
    local MallProxy = require "Modules.Mall.MallProxy"
    local cfg = MallProxy.Instance:GetGiftConfigById(mallid)
    local icon = ""
    if cfg then
        icon = cfg.icon or ""
    end
    return icon
end

function MobilizeProxy:GetMallGoodsByMallId(mallid)
    local MallProxy = require "Modules.Mall.MallProxy"
    local cfg = MallProxy.Instance:GetGiftConfigById(mallid)
    local goods = {}
    if cfg then
        goods = cfg.goods_id or {}
    end
    return goods
end

function MobilizeProxy:GetRewardList()
    if not self.data.mobilize.room then
        return {}
    end
    if not self.data.mobilize.rewardList then
        local config = self:GetPointsConfig()
        local list = {}
        for _ , v in ipairs(config) do
            if v.room == self.data.mobilize.room then
                local item = {}
                item.id = v.id
                item.index = #list + 1
                item.room = v.room
                item.points = v.points
                if v.goods_id and #v.goods_id > 0 then
                    item.goods_id = v.goods_id[1]
                end
                item.mall_id = v.mall_id
                local state,state1 = self:GetRewardState(v)
                item.state = state
                item.state1 = state1
                item.thelast = false
                table.insert(list,item)
            end
        end
        list[#list].thelast = true
        self.rewardNum = #list
        self.data.mobilize.rewardList = list
    end
    return self.data.mobilize.rewardList
end

function MobilizeProxy:GetCurPointsIndex()
    local list = self:GetRewardList()
    local index = 1
    if self.data.mobilize.points then
        local points = self.data.mobilize.points > list[#list].points and list[#list].points or self.data.mobilize.points
        for k , v in ipairs(list) do
            if v.points >= points then
                index = k
                break
            end
        end
    end
    return index
end

function MobilizeProxy:GetAllReward()
    if  self.data.mobilize.points and self.data.mobilize.has_get_reward then
        local list = self:GetRewardList()
        local getlist = {}
        for _ , item in ipairs(list) do
            if item then
                if self.data.mobilize.points >= item.points then
                    local find = false
                    for _ , v in ipairs(self.data.mobilize.has_get_reward) do
                        local id = v[1]
                        local type = v[2]
                        if id == item.id and type == MobilizeDef.RewardType.Normal then
                            find = true
                        end
                    end
                    if not find and item.goods_id then
                        table.insert(getlist,{item.id,MobilizeDef.RewardType.Normal})
                    end
                end
            end
        end
        if #getlist > 0 then
            self:Send65002(getlist)
        else
            GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord(MobilizeDef.CommonDef.NoReward))
        end
    end
end

function MobilizeProxy:GetTaskList()
    if not self.data.mobilize.task_progress_list then
        return {}
    end
    local config = self:GetTaskConfig()
    local list = {}
    local state , endtime = self:GetEndTime()
    --if state >  MobilizeDef.State.Ready then
    if config then
        local task = {}
        for _ , cfg in ipairs(config) do
            local type = cfg.type
            local nexttask = self:GetNextTask(cfg.task_id)
            if nexttask then
                task[type] = nexttask
            end
        end
        for _ , v in ipairs(self.data.mobilize.task_progress_list) do
            local cfg = self:GetConfigByTaskId(v.task_id)
            if cfg then
                local item = {}
                item.id = cfg.id
                item.task_id = v.task_id
                local value = cfg.count
                item.targetvalue = value[1] or 0
                item.progress = v.progress
                item.state = MobilizeDef.Reward_State.CannotGet
                if item.progress >= item.targetvalue then
                    item.state = MobilizeDef.Reward_State.UnGet
                    if v.state == MobilizeDef.Task_State.ComPlete then
                        item.state = MobilizeDef.Reward_State.HasGet
                    end
                end
                item.dec = LanguageManager.Instance:GetWord(cfg.task_name)
                item.rewards = cfg.rewards[1]
                item.tasktype = cfg.type
                table.insert(list,item)
            end
        end
        for _ , v in ipairs(task) do
            local exist = false
            for _ , _task in ipairs(list) do
                if _task.tasktype == v.type then
                    exist = true
                    break
                end
            end
            if not exist then
                local item = {}
                item.id = v.id
                local value = v.count
                item.progress = value[1] or 0
                item.state = MobilizeDef.Reward_State.HasGet
                item.targetvalue = value[1] or 0
                item.dec = LanguageManager.Instance:GetWord(v.task_name)
                item.rewards = v.rewards[1]
                item.tasktype = v.type
                table.insert(list,item)
            end
        end
    end
    --end

    table.sort(list,function (a,b)
        if a.state == b.state then
            return a.id < b.id
        else
            return a.state < b.state
        end
    end)
    return list
end

function MobilizeProxy:GetNextTask(task_id)
    local config = self:GetTaskConfig()
    if config then
        for _ , v in ipairs(config) do
            if v.lasttask == task_id then
                return v
            end
        end
    end
end

function MobilizeProxy:GetConfigByTaskId(task_id)
    local config = self:GetTaskConfig()
    if config then
        for _ , v in ipairs(config) do
            if v.task_id == task_id then
                return v
            end
        end
    end
end
function MobilizeProxy:CanSend()
    local state,endtime = self:GetEndTime()
    if state == MobilizeDef.State.Duration or state == MobilizeDef.State.Ready then
        return true
    end
    return false
end
function MobilizeProxy:IsTestSever()

    local LoginProxy = require "Modules.Login.LoginProxy"
    local ip, port = LoginProxy.Instance:GetServerInfos()
    -- if ip == "192.168.0.42" then
    --     return true
    -- end
    return true
end

function MobilizeProxy:Send65000()
    if not self:IsTestSever() then
        return
    end
    if   ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.MobilizeView,false) then
        self:SendMessage(65000)
    end
    if self.test then
        self:On65000(nil)
    end
    
end

function MobilizeProxy:On65000(decoder)
    -- 准备时间，开始时间 结束时间
    if not self.test then
        local result = decoder:Decode("I1")
        if result == 0 then
            local roomid,rob_num,open_time,end_time = decoder:Decode("I2I2I4I4")
            local has_get_reward = decoder:DecodeList("I2I1",true)
            local task_progress_list = decoder:DecodeList("I4I4I1",true)
            local formation = decoder:DecodeList("I1I4",true)

            local readytime = self:GetReadyTimeConfig(CycleActivityDef.Events_Type.MobilizeActivity)
            local hero={}
            for k=1,5 do
                hero[k]=-1  --初始id 为-1 表示空位
            end
            for _,v in ipairs(formation) do
                if v[1] <= 5 then
                    hero[v[1]]=v[2]
                end
            end

            local task_progress = {}
            for _ , v in ipairs(task_progress_list) do
                local item = {}
                item.task_id = v[1]
                item.progress = v[2]
                item.state = v[3]
                table.insert(task_progress , item)
            end
           
            self.data.mobilize.readytime = open_time - readytime
            self.data.mobilize.opentime = open_time
            self.data.mobilize.endtime = end_time
            self.data.mobilize.points = RoleInfoModel.mobilize_point
            self.data.mobilize.room = roomid
            self.data.mobilize.has_get_reward = has_get_reward
            self.data.mobilize.task_progress_list = task_progress
            self.data.mobilize.rob_num = rob_num  --打劫次数
            self.data.mobilize.formation = hero --数组{herouid,-1,herouid}
        else

        end
    else
        self.data.mobilize.readytime = RoleInfoModel.servertime - 24*60*60
        self.data.mobilize.opentime = RoleInfoModel.servertime
        self.data.mobilize.endtime = RoleInfoModel.servertime + 7*24*60*60
        self.data.mobilize.points = 180
        self.data.mobilize.room = 1 --
        self.data.mobilize.has_get_reward = {}
        self.data.mobilize.task_progress_list = {}
        self.data.mobilize.rob_num = 1  --打劫次数
        self.data.mobilize.formation = {}
        local config = self:GetTaskConfig()
        local task = {}
        for _ , v in ipairs(config) do
            if v.lasttask == 0 then
                local item = {}
                item.task_id = v.task_id
                item.progress = 80
                item.state = MobilizeDef.Task_State.Get_Award
                table.insert(task , item)
            end
        end
        self.data.mobilize.task_progress_list = task
    end
    --红点信息
    self.data.mobilize.rewardList = false
    self:UpdateRedDot()
    self:ToNotify(self.data,MobilizeDef.NotifyDef.Request_Basic_Info,{})
    --self:ToNotify(self.data,MobilizeDef.NotifyDef.Update_Mobilize_Btn)
end

function MobilizeProxy:Send65002(idlist)
    if not self:IsTestSever() then
        return
    end
    if not self:CanSend() then
        return
    end
    local encoder=NetEncoder.New()
    encoder:EncodeList("I2I1",idlist)
    --self.idlist = idlist
    self:SendMessage(65002,encoder)
    --领取奖励
    --self:On65002(nil)
end

function MobilizeProxy:UpdateRobNum()
    self.data.mobilize.rob_num = self.data.mobilize.rob_num - 1
end

function MobilizeProxy:GetRobNum()
    return self.data.mobilize.rob_num or 0
end

function MobilizeProxy:UpdatePoints()
    self.data.mobilize.points = RoleInfoModel.mobilize_point
    self.data.mobilize.myRankInfo.score = RoleInfoModel.mobilize_point
    if self.data.mobilize.rewardList then
        local config = self:GetPointsConfig()
        for _ , v in ipairs(self.data.mobilize.rewardList) do
            local rewarditem = self:GetOneRewardItemById(v.id)
            if rewarditem then
                local state,state1 = self:GetRewardState(config[v.id])
                rewarditem.state = state
                rewarditem.state1 = state1
            end
        end
    end
end

function MobilizeProxy:GetOneRewardItemById(id)
    for _ , item in ipairs(self.data.mobilize.rewardList) do
        if item.id == id then
            return item
        end
    end
end

function MobilizeProxy:On65002(decoder)

    local idlist = decoder:DecodeList("I2I1",true)
    local newherolist = decoder:DecodeList("I4")
    if not idlist  then
        return
    end
    local rewardlist={}
    local config = self:GetPointsConfig()
    for k,v in ipairs(idlist) do
       
        local id = v[1]
        if config[id] then
            if v[2] == MobilizeDef.RewardType.Advance then 
                local mallId = config[id].mall_id
                local list = self:GetMallGoodsByMallId(mallId)
                for i,reward in ipairs(list) do
                    local item={}
                    item.goodsid = reward[1]
                    item.goodsnum = reward[2]
                    table.insert(rewardlist,item)
                end
            else
                local rewards = config[id].goods_id or {}
                for _, reward in ipairs(rewards) do
                    if reward then
                        local item={}
                        item.goodsid = reward[1]
                        item.goodsnum = reward[2]
                        table.insert(rewardlist,item)
                    end
                end
            end
            table.insert(self.data.mobilize.has_get_reward,v)
            local rewarditem = self:GetOneRewardItemById(id)
            if rewarditem then
                local state,state1 = self:GetRewardState(config[id])
                rewarditem.state = state
                rewarditem.state1 = state1
            end
            
        end
    end
    if #rewardlist > 0 then
        GameLogicTools.ShowGetItemView(rewardlist,1,function (  )
            -- if isnewhero == 1 then
            --     GameLogicTools.ShouldShowNewHeroTipsView(rewards)
            -- end
            if #newherolist > 0 then
                local goodslist = {}
                for _ , goods_type_id in ipairs(newherolist) do
                    table.insert(goodslist,{goods_type_id,1})
                end
                GameLogicTools.ShouldShowNewHeroTipsView(goodslist)
            end
        end)
        self:UpdateRedDot()
        
    else
        --购买高级奖励
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.MobilizeMallView)
    end
    self:ToNotify(self.data,MobilizeDef.NotifyDef.Update_Reward_State,{idlist = idlist,totalnum = self.rewardNum})
end

function MobilizeProxy:Send65003()
    if not self:IsTestSever() then
        return
    end
    if not self:CanSend() then
        return
    end
    self:SendMessage(65003)
    if self.test then
        self:On65003(nil)
    end
    --print("----------Send65003-----------")
end


function MobilizeProxy:On65003(decoder)
    --print("----------On65003-----------")
    local list = {}
    local myRankInfo = false
    local config = self:GetRankConfig()
    if self.test then
       
        for i = 1, 50 do
            local item = {}
            item.rank = i
            local head={}
            head.fight= 100
            head.headicon= RoleInfoModel.headicon
            head.frameicon= RoleInfoModel.frameicon
            head.nickname= RoleInfoModel.nickname
            head.level= RoleInfoModel.level
            head.sex= RoleInfoModel.sex
            head.guserid = RoleInfoModel.guserid
            item.score= 180
            item.guserid= RoleInfoModel.guserid
            item.goods_id = self:GetRankRewardByRank(item.rank)
            item.head=head
            if item.guserid == RoleInfoModel.guserid then
                myRankInfo = item
                --self.data.mobilize.points = item.score
            end
            table.insert(list,item)
        end
    else
        local players = decoder:DecodeList("I8s2I4I4I2I2I4I4I2",true)
        table.sort(players,function (a,b)
            return a[9] < b[9]
        end)
        for i = 1, #players do
            local _player = players[i]
            local item = {}
            item.rank = _player[9]
            local head={}
            head.fight= _player[7]
            head.headicon=_player[3]
            head.frameicon= _player[4]
            head.nickname= _player[2]
            head.level= _player[6]
            head.sex= _player[5]
            head.guserid =_player[1]
            item.score= _player[8]
            item.guserid= _player[1]
            item.goods_id = self:GetRankRewardByRank(item.rank)
            item.head=head
            if item.guserid == RoleInfoModel.guserid then
                myRankInfo = item
                myRankInfo.head.headicon= RoleInfoModel.headicon
                myRankInfo.head.frameicon= RoleInfoModel.frameicon
                myRankInfo.head.nickname= RoleInfoModel.nickname
                myRankInfo.head.level= RoleInfoModel.level
                myRankInfo.head.sex= RoleInfoModel.sex
                --item.score = RoleInfoModel.mobilize_point
                self.data.mobilize.points = RoleInfoModel.mobilize_point
            end
            table.insert(list,item)
        end
        --print("----------On65003--3---------",table.dump(players))
    end
   
    self.data.mobilize.rankList = list
    if myRankInfo then
        self.data.mobilize.myRankInfo = table.deepcopy(myRankInfo)
        self.data.mobilize.myRankInfo.goods_id = false
        local heroList = {}
        for _,herouid in ipairs(self.data.mobilize.formation) do
            if herouid ~= - 1 and herouid > 0 then
                local hero = HeroProxy.Instance:GetHeroDataByUid(herouid)
                if hero then
                    table.insert(heroList,hero)
                end
            end
        end
        local fightstr,fight = HeroProxy.Instance:GetHeroFight(heroList)
        self.data.mobilize.myRankInfo.head.fight = fight
        self.data.mobilize.myRankInfo.score = RoleInfoModel.mobilize_point
    end
    self:ToNotify(self.data,MobilizeDef.NotifyDef.Update_Rank_List)
end

function MobilizeProxy:Send65001(task_id)
    --领取任务奖励
    if not self:IsTestSever() then
        return
    end
    if not self:CanSend() then
        return
    end
    local encoder=NetEncoder.New()
    encoder:Encode("I4",task_id)
    self:SendMessage(65001,encoder)
    --self:On65001(nil,task_id)
end


function MobilizeProxy:On65001(decoder)
    local result,task_id = decoder:Decode("I1I4")
    --print("------------On65001------------",result,task_id)
    if result == 0 then
        local cfg = self:GetConfigByTaskId(task_id)
        if self.data.mobilize.task_progress_list and cfg then
            local rewards =cfg.rewards or {}
            local rewardlist={}
            for _, v in ipairs(rewards) do
                if v then
                    local item={}
                    item.goodsid = v[1]
                    item.goodsnum = v[2]
                    table.insert(rewardlist,item)
                end
            end
            
            GameLogicTools.ShowGetItemView(rewardlist,1,function (  )
               
            end)
            RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.MobilizeTask,tostring(task_id),0)
            local nextTask = self:GetNextTask(task_id)
            for k , v in ipairs(self.data.mobilize.task_progress_list) do
                if v and v.task_id == task_id then
                    if nextTask then
                        v.task_id = nextTask.task_id
                        local value = nextTask.count
                        local targetValue = value[1] or 0
                        if v.progress >= targetValue then
                            v.state = MobilizeDef.Task_State.In_Progress
                        else
                            v.state = MobilizeDef.Task_State.Get_Award
                        end
                        
                        --table.remove(self.data.mobilize.task_progress_list,k)
                    else
                        v.state = MobilizeDef.Task_State.ComPlete
                    end
                    break
                end
            end
        end
        self:UpdateRedDot()
    else
        GameLogicTools.ShowErrorCode(65001,result)
    end
    self:ToNotify(self.data,MobilizeDef.NotifyDef.Update_Task_List,{update = true})
end

function MobilizeProxy:CheckHasUnGetReward()
    local has = false
    if self.data.mobilize.rewardList then
        for _ , v in ipairs(self.data.mobilize.rewardList) do
            local rewarditem = self:GetOneRewardItemById(v.id)
            if rewarditem then
                if rewarditem.state == MobilizeDef.Reward_State.UnGet and not rewarditem.mall_id then
                    has = true
                    break
                end
            end
        end
    end
    return has
end

function MobilizeProxy:GetRankList()
    local state , endtime = self:GetEndTime()
    if state >  MobilizeDef.State.Ready then
        return self.data.mobilize.rankList,self.data.mobilize.myRankInfo
    else
        return {}
    end
end

function MobilizeProxy:GetSelfInfo()
    local info = {}
    if  self.data.mobilize.room then
        info.points = self.data.mobilize.points
        info.room = self.data.mobilize.room
    end
    return info
end

function MobilizeProxy:UpdateRedDot()

   
    if   ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.MobilizeView,false) then
        local state = self:GetEndTime()
        if state == MobilizeDef.State.Duration then
            local config = self:GetPointsConfig()
            local list = {}
            local noget = false
            for _ , v in ipairs(config) do
                if v.room == self.data.mobilize.room then
                    local state,state1 = self:GetRewardState(v)
                    if state == MobilizeDef.Reward_State.UnGet and  v.goods_id  then
                        noget = true
                        RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.MobilizeReward,tostring(v.id),1)
                    else
                        RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.MobilizeReward,tostring(v.id),0)
                    end
                end
            end
            RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.MobilizeGetAllReward,noget and 1 or 0)

            for _ , v in ipairs(self.data.mobilize.task_progress_list) do
                local cfg = self:GetConfigByTaskId(v.task_id)
                if cfg then
                  
                    local value = cfg.count
                    local targetvalue = value[1] or 0
                    local progress = v.progress
                    local state = MobilizeDef.Reward_State.CannotGet
                    if progress >= targetvalue then
                        state = MobilizeDef.Reward_State.UnGet
                        if v.state == MobilizeDef.Task_State.ComPlete then
                            state = MobilizeDef.Reward_State.HasGet
                        end
                    end
                    if  state == MobilizeDef.Reward_State.UnGet then
                        RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.MobilizeTask,tostring(v.task_id),1)
                    else
                        RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.MobilizeTask,tostring(v.task_id),0)
                    end
                end
            end
        end
    end
end

function MobilizeProxy:GetEndTime()
    local state = MobilizeDef.State.UnOpen --活动为开始
    local endtime = 0
    if self.data.mobilize and self.data.mobilize.opentime then
        if self.data.mobilize.readytime - RoleInfoModel.servertime  <= 0  and self.data.mobilize.opentime - RoleInfoModel.servertime > 0 then
            --活动准备阶段
            state = MobilizeDef.State.Ready
            endtime = self.data.mobilize.opentime
        elseif self.data.mobilize.opentime - RoleInfoModel.servertime <= 0 and self.data.mobilize.endtime - RoleInfoModel.servertime > 0 then
            --活动期间
            state = MobilizeDef.State.Duration
            endtime = self.data.mobilize.endtime
        else
            state = MobilizeDef.State.End --活动结束
        end
    end
    --print("--------GetEndTime-----------",state , endtime)
    return state , endtime
end

function MobilizeProxy:GetMoblizeOpenTime()
    local opentime = 0
    if self.data.mobilize and self.data.mobilize.readytime then
        opentime = self.data.mobilize.readytime
    end
    return opentime
end

function MobilizeProxy:GetMoblizeEndTime()
    local endtime = 0
    if self.data.mobilize and self.data.mobilize.endtime then
        endtime = self.data.mobilize.endtime
    end
    return endtime
end


function MobilizeProxy:GetFormation()
    if not self.data.mobilize.formation then
        return {}
    else
        return self.data.mobilize.formation
    end
end
-- function MobilizeProxy:Send65008()

--     self:SendMessage(65008) 
--     if self.test then
--         self:On65008(nil)
--     end
-- end
-- function MobilizeProxy:On65008(decoder)

--     local formation ={} --decoder:Decode("I1I4",true)
--     if not self.test then
--         formation = decoder:DecodeList("I1I4",true)
--     end
--     local hero={}
--     for k=1,5 do
--         hero[k]=-1  --初始id 为-1 表示空位
--     end
--     for _,v in ipairs(formation) do
--         if v[1] <= 5 then
--             hero[v[1]]=v[2]
--         end
--     end
--     self:ToNotify(self.data,MobilizeDef.NotifyDef.Update_Formation,{heroList = hero})
-- end

function MobilizeProxy:Send65006(formation)
    --调整防守阵容
    if not self:IsTestSever() then
        return
    end
    local encoder=NetEncoder.New()
    encoder:EncodeList("I1I4",formation)
    self:SendMessage(65006,encoder)
    self.formations=formation
end

function MobilizeProxy:On65006(decoder)
    local result  =decoder:Decode("I1")
    if result == 0 then
        local heroList={}
        local hero={}
        for k=1,5 do
            hero[k]=-1  --初始id 为-1 表示空位
        end
        for _,v in ipairs(self.formations) do
            hero[v[1]]=v[2]
            
            local hero = HeroProxy.Instance:GetHeroDataByUid(v[2])
            if hero then
                table.insert(heroList,hero)
            end
        end
        self.data.mobilize.formation = hero
        local fightstr,fight = HeroProxy.Instance:GetHeroFight(heroList)
        local formation_power = fight
        self.data.mobilize.myRankInfo.head.fight = fight
        self:ToNotify(self.data,MobilizeDef.NotifyDef.Update_Formation,{formation_power = formation_power, totalnum = #self.data.mobilize.rankList})
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.MobilizeBattleSelectView)
        GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord(ArenaDef.CommonDef.SetDefenceSuccess))
    else
        GameLogicTools.ShowErrorCode(65006, result)
    end
end


function MobilizeProxy:Send65005(guserid)
    --挑战
    if not self:IsTestSever() then
        return
    end
    if not self:CanSend() then
        return
    end
    local encoder=NetEncoder.New()
    encoder:Encode("I8",guserid)
    self:SendMessage(65005,encoder)
    local BattleProxy = require "Modules.Battle.BattleProxy"
    local activityId = ACTIVITYID.MOBILIZE
    --print("-------------Send65005--------------",guserid)
    BattleProxy.Instance:BattleReadySetStep(activityId, 1, 1)
end
    
function MobilizeProxy:On65005(decoder)
    local result =decoder:Decode("I2")
    if result == 0 then

    else
        GameLogicTools.ShowErrorCode(65005,result)
    end
    
    if result ~= 0 then
        local BattleProxy = require "Modules.Battle.BattleProxy"
        local activityId = ACTIVITYID.MOBILIZE
        BattleProxy.Instance:BattleReadyNextStep(activityId, 1)
    end
end

function MobilizeProxy:Send65007(hero_infos, enemy_infos, bufferstr)
    if not self:IsTestSever() then
        return
    end
    if not self:CanSend() then
        return
    end
    --开始战斗
    local encoder = NetEncoder.New()
    self:_EncodeHeroInfo(hero_infos, encoder)
    self:_EncodeEnemyInfo(enemy_infos, encoder)
    encoder:Encode("s2", bufferstr or "")
    self:SendMessage(65007, encoder) 
   
end
function MobilizeProxy:On65007(decoder)
   
    local result =decoder:Decode("I1")
    if result == 0 then
       
    else
        GameLogicTools.ShowErrorCode(65007,result)
    end
end

-- 战前准备
function MobilizeProxy:OnPreBattle(decoder)

    local heroinfos = self:_DecodeHeroInfo(decoder)
	local enemyinfos = self:_DecodeEnemyInfo(decoder)
    local bufferstr = decoder:Decode("s2")
    local panelstr="BattleMobilizePanel"
    local activityId = ACTIVITYID.MOBILIZE
    local enemy_uin=string.unpack(">I8", bufferstr)
    --print("-----------OnPreBattle-----------",enemy_uin)
    self:_UpdateEnemyInfo(enemyinfos)
    UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 10, activityId, heroinfos, enemyinfos,panelstr,{enemy_uin})
end

-- 开始战斗
function MobilizeProxy:OnStartBattle(decoder, seed, activityId, extra)
    local heroinfos = self:_DecodeHeroInfoDetail(decoder)
	local enemyinfos = self:_DecodeEnemyInfoDetail(decoder)
    local bufferstr = decoder:Decode("s2")
  
    local enemy_uin= string.unpack(">I8", bufferstr)

    --self:PlayBgMusic(false)
    self.startBattleArg = { seed = seed, extra = extra }
    self:GenerateBattleInfo(activityId, heroinfos, enemyinfos, self.startBattleArg,{ first = true, enemy_uin=enemy_uin,breport = extra and  extra.report or false })
end

-- 结算
function MobilizeProxy:OnSetBattle(decoder)

    -- print("OnSetBattle")
end

return MobilizeProxy