local MallDef = require "Modules.Mall.MallDef"
local MallCustomProxy = MallCustomProxy or BaseClass(BaseProxy)
local RedPointDef = require "Modules.RedPoint.RedPointDef"


function MallCustomProxy:__init()
	MallCustomProxy.Instance = self

	self:AddProto(20900, self.On20900) --请求所有信息（活动状态改变服务端也会主动更新）
	self:AddProto(20901, self.On20901) --设置保存定制礼包各个选项的选择
	self:AddProto(20902, self.On20902) --购买确认，向服务端确认是否能购买

	self.data = {}
end

function MallCustomProxy:__delete(self)
    MallCustomProxy.Instance = nil
end

function MallCustomProxy:Send20900()
	-- print("MallCustomProxy:Send20900")
	self:SendMessage(20900)
end

function MallCustomProxy:On20900(decoder)
	-- print("MallCustomProxy:On20900")
	local is_open = decoder:Decode("I1")
	self.over_time = decoder:Decode("I4")
	local count = decoder:Decode("I1")
	
	self.is_open = is_open == 1
	self.custom_select_info = {}
	for i = 1, count do
		local custom_id = decoder:Decode("I2")
		local times = decoder:Decode("I1")
		local select_info = decoder:DecodeList("I2")
		self.custom_select_info[custom_id] = {custom_id = custom_id , times = times , select_info = select_info}
	end
	self:InitCustomSelectInfo()
	self:CheckCustomRed()
	-- print(self.is_open, self.over_time, count,"-------On20900--------->",table.dump(self.custom_select_info))
	self:ToNotify(self.data, MallDef.Notify.UpdateAllCustomInfo)
end

function MallCustomProxy:Send20901(custom_id,select_info)
    -- print("MallCustomProxy:Send20901",custom_id,table.dump(select_info))
    local encoder = NetEncoder.New()
	encoder:Encode("I2", custom_id)
	encoder:EncodeList("I2", select_info)
	self:SendMessage(20901,encoder)
	self.cache_select_info = {custom_id = custom_id , select_info = select_info}
end

function MallCustomProxy:On20901(decoder)
	local result = decoder:Decode("I1")
	-- print("MallCustomProxy:On20901",result)
	if result == 0 and self.cache_select_info then
		local custom_id = self.cache_select_info.custom_id
		local select_info = self.cache_select_info.select_info
		self.custom_select_info[custom_id].select_info = select_info
		self:ToNotify(self.data, MallDef.Notify.UpdateAllCustomInfo, {custom_id = custom_id})
	end
end

--如果是免费礼包 则应该通过这个借口直接购买成功 而不走SDK
function MallCustomProxy:Send20902(custom_id)
	-- print("MallCustomProxy:Send20902--------->1")
	if self:CheckCustomCanBuy(custom_id) then
	    local encoder = NetEncoder.New()
		encoder:Encode("I2", custom_id)
		self:SendMessage(20902,encoder)
		-- print("MallCustomProxy:Send20902--------->2")
	end
end

--TODO 购买成功的更新 走 20900
function MallCustomProxy:On20902(decoder)
	
	local result = decoder:Decode("I1")
    -- print("MallCustomProxy:On20902--------->1",result)
    if result == 0 then
    	local custom_id = decoder:Decode("I2")
		local MallProxy = require "Modules.Mall.MallProxy"
		 --print("On20802------------>",pass_base_cfg.gift)
		if not self:IsFree(custom_id) then
			 local gift_id = self:GetGiftIdByCustomId(custom_id)
			 MallProxy.Instance:SDKBuy(gift_id)
		end
		-- print("MallCustomProxy:On20902--------->1",custom_id)
	else
		GameLogicTools.ShowMsgTips("MallSdk6")
	end
end

function MallCustomProxy:InitCustomSelectInfo()

	local function get_init_select_info(custom_cfg)
		local ret = {}
		local temp_list = self:GetCustomGiftListByCustomID(custom_cfg.id)
		for _,gift_id in ipairs(temp_list) do
			table.insert(ret,0)
		end
		return ret
	end

	local custom_cfgs = self:GetCustomConfig()

	for custom_id,cfg in ipairs(custom_cfgs) do
		local info = self.custom_select_info[custom_id]
		if not info then
			info = {}
			info.custom_id = custom_id
			info.select_info = get_init_select_info(cfg)
			info.times = 0
		end
		self.custom_select_info[custom_id] = info
	end
end

--活动结束时间
function MallCustomProxy:GetCustomOverTime()
	return self.over_time
end

--获得购买次数
function MallCustomProxy:GetCustomTimesById(custom_id)
	local info = self.custom_select_info[custom_id]
	return info and info.times or 0
end

--获得剩余购买次数
function MallCustomProxy:GetCustomLeftTimesById(custom_id)
	local MallProxy = require "Modules.Mall.MallProxy"
	local MallDef = require "Modules.Mall.MallDef"

	local limit_times = MallProxy.Instance:GetBuyLimitTimes(MallDef.Type.Self,custom_id)
	local cur_times = self:GetCustomTimesById(custom_id)
	return (limit_times - cur_times)
end

--Copy列表传过去，在UI层会临时修改数据
function MallCustomProxy:GetCustomSelectInfo(custom_id)
	local ret = {}
	local info = self.custom_select_info and self.custom_select_info[custom_id]
	if info then
		for k,v in ipairs(info.select_info) do
			ret[k] = v
		end
	end

	return ret
end

--获取定制礼包中 可以定制的礼包列表
function MallCustomProxy:GetCustomGiftListByCustomID(custom_id)

	local goods_info_list = self:GetGoodsListByCustomID(custom_id)
	local BagDef = require "Modules.Bag.BagDef"
	local ret = {}
	for _,goods_info in ipairs(goods_info_list) do
		local goods_id = goods_info[1]
		local goods_cfg = self:GetGoodsConfigInfo(goods_id)
		if goods_cfg and goods_cfg.subtype == BagDef.SubType.CustomBox then
			table.insert(ret,goods_id)
		end
	end
	return ret
end

--定制礼包中 所有物品（固定物品  和 自选礼包中的已选物品）
function MallCustomProxy:GetCustomGiftGoodsList(custom_id)
	local ret = {}
	local BagDef = require "Modules.Bag.BagDef"
	local goods_info_list = self:GetGoodsListByCustomID(custom_id)
	local custom_index = 1
	for _,goods_info in ipairs(goods_info_list) do
		local goods_id = goods_info[1]
		local goods_cfg = self:GetGoodsConfigInfo(goods_id)
		if goods_cfg and goods_cfg.subtype == BagDef.SubType.CustomBox then
			local select_info = self:GetCustomSelectInfo(custom_id)
			local select_index = select_info[custom_index]
			local custom_goods_list = self:GetCustomGoodsListByCustomIDAndIndex(custom_id,custom_index)
			local custom_goods_info = custom_goods_list[select_index]
			custom_index = custom_index + 1
			table.insert(ret,{custom_goods_info[1],custom_goods_info[2]})
		else
			table.insert(ret,{goods_id,goods_info[2]})
		end
	end
	return ret
end

--定制礼包中 可以选择的定制物品列表
function MallCustomProxy:GetCustomGoodsListByCustomIDAndIndex(custom_id, index)
	local gift_list = self:GetCustomGiftListByCustomID(custom_id)
	local gift_goods_id = gift_list[tonumber(index)]
	local goods_cfg = self:GetGoodsConfigInfo(gift_goods_id) 
	return goods_cfg and goods_cfg.value
end

--获取定制物品中 所有物品列表
function MallCustomProxy:GetGoodsListByCustomID(custom_id)
	local giftid = self:GetGiftIdByCustomId(custom_id)
	local gift_cfg = self:GetGiftConfigById(giftid)
	return gift_cfg and gift_cfg.goods_id
end

function MallCustomProxy:IsFree(custom_id)
	local giftid = self:GetGiftIdByCustomId(custom_id)

	local config = self:GetGiftConfigById(giftid)
	return config and config.pcid == "0"
end

function MallCustomProxy:GetGiftIdByCustomId(custom_id)
	local custom_cfg = self:GetCustomConfigById(custom_id)
	return custom_cfg and custom_cfg.gift_ids[1]
end

function MallCustomProxy:GetCustomConfig()
	local config = ConfigManager.GetConfig("data_mall_self")
	return config
end

function MallCustomProxy:GetCustomConfigById(id)
	local config = ConfigManager.GetConfig("data_mall_self")
	return config and config[id]
end

function MallCustomProxy:GetGiftConfig()
	local config = ConfigManager.GetConfig("data_mall_gift")
	return config
end

function MallCustomProxy:GetGiftConfigById(id)
	local config = self:GetGiftConfig()
	return config[id]
end

function MallCustomProxy:GetGoodsConfigInfo(goods_type_id)
    local goods_config = ConfigManager.GetConfig("data_goods")
    return goods_config[goods_type_id]
end

function MallCustomProxy:GetEventsMainlineidOpenId(events_id)
    local config = ConfigManager.GetConfig("data_events_time")
    if config and config[events_id] then
        return config[events_id].open_mainline or 0
    end
    return 0
end

function MallCustomProxy:CheckMallCustomOpen()
	
	if not self.is_open then
		return false
	end
	
	if RoleInfoModel.servertime >= self.over_time then
		return false
	end
	return true
end

function MallCustomProxy:GetSelectGoodsCfg(custom_id, grid_index, goods_index)
	local goods_info_list = self:GetCustomGoodsListByCustomIDAndIndex(custom_id,grid_index)
	local goods_info = goods_info_list[goods_index]
	local goods_cfg = self:GetGoodsConfigInfo(goods_info[1])
	return goods_cfg
end

--获得空格子的索引，也是用于判断是否填满了定制格子
function MallCustomProxy:GetNullCustomGridIndex(custom_id,select_info)
	local custom_gift_list = self:GetCustomGiftListByCustomID(custom_id)	
	local select_info = select_info or self:GetCustomSelectInfo(custom_id)
	for i in ipairs(custom_gift_list) do
		local select_index = select_info[i]
		if not select_index or select_index == 0 then
			return i
		end
	end
end

--限购次数、没有空格子
function MallCustomProxy:CheckCustomCanBuy(custom_id)
	local MallProxy = require "Modules.Mall.MallProxy"
	local MallDef = require "Modules.Mall.MallDef"
	local limit_times = MallProxy.Instance:GetBuyLimitTimes(MallDef.Type.Self,custom_id)
	local cur_times = self.custom_select_info[custom_id].times
	if cur_times >= limit_times then
		return false
	end
	local null_index = self:GetNullCustomGridIndex(custom_id)
	if null_index then
		return false
	end
	return true
end

--检查物品列表中是否有 可以帅选种族或职业的 物品
--目前的筛选目标 装备 进阶石 英雄卡
function MallCustomProxy:CheckRaceOrClassGoods(class,race,goods_list)
	local ret = {}
	local BagDef = require "Modules.Bag.BagDef"
	local check_class_func = function (goods_cfg)
		local subtype = goods_cfg.subtype
		local goods_id = goods_cfg.id
		local class_2_subtype_dict = BagDef.ClassSubType[class]
		local class_2_goodsid_dict = BagDef.ClassGoodsId[class]
		--检查装备和进阶石
		if class_2_subtype_dict[subtype] or class_2_goodsid_dict[goods_id] then
			return true
		end
		--检查英雄卡
		if subtype == BagDef.SubType.Elite_Hero_Card or subtype == BagDef.SubType.Rare_Hero_Card then
			local hero_id = goods_cfg.value[1]
			local HeroProxy = require "Modules.Hero.HeroProxy"
			local hero_cfg = HeroProxy.Instance:GetRoleCfgByConfigId(hero_id)
			if hero_cfg.class == class then
				return true
			end
		end
		return false
	end

	local check_race_func = function (goods_cfg)
		local subtype = goods_cfg.subtype
		local goods_race = goods_cfg.race
		if goods_race and goods_race == race then
			return true
		end
		return false
	end

	for index,info in ipairs(goods_list) do
		local goods_id = info[1]
		local goods_cfg = self:GetGoodsConfigInfo(goods_id)
		local temp_bool = true
		if class and not check_class_func(goods_cfg) then
			temp_bool = false
		end
		if race and not check_race_func(goods_cfg) then
			temp_bool = false
		end
		if temp_bool then
			info.index = index
			table.insert(ret,info)
		end
	end
	return ret
end

--获得物品列表 包含的种族和阵营
--目前的职业向的获取目标 装备 进阶石 英雄卡 ， 阵营的获取目标又填表决定
function MallCustomProxy:GetGoodsListRackOrClass(goods_list)
	local race_dict = {}
	local class_dict = {}
	local BagDef = require "Modules.Bag.BagDef"
	for _,info in ipairs(goods_list) do
		local goods_id = info[1]
		local goods_cfg = self:GetGoodsConfigInfo(goods_id)
		local subtype = goods_cfg.subtype
		--判断class
		local target_class
		if subtype == BagDef.SubType.Elite_Hero_Card or subtype == BagDef.SubType.Rare_Hero_Card then
			local class_2_subtype_dict = BagDef.ClassSubType[class]
			local class_2_goodsid_dict = BagDef.ClassGoodsId[class]
			for class,info in pairs(BagDef.ClassSubType) do
				if info[subtype] then
					target_class = class
					break
				end
			end
			for class,info in pairs(BagDef.ClassGoodsId) do
				if info[goods_id] then
					target_class = class
					break
				end
			end
			if target_class then
				class_dict[target_class] = true
			end
		end
		--判断race
		if goods_cfg.race then
			race_dict[goods_cfg.race] = true
		end
	end
	return race_dict,class_dict
end

function MallCustomProxy:CheckCustomRed()
	local have_red = false
	if self:CheckMallCustomOpen() then
	 	local custom_cfgs = self:GetCustomConfig()
	 	for id,cfg in ipairs(custom_cfgs) do
	 		if self:IsFree(id) then
	 			local left_times = self:GetCustomLeftTimesById(id)
	 			have_red = left_times > 0
	 		end
	 	end
	end
 	local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
 	RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.MallLimitSelf, have_red and 1 or 0)
end

return MallCustomProxy