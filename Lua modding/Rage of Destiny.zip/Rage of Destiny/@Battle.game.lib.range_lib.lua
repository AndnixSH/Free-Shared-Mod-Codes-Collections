local target_filter = {
    [SKILL.TARGET_FILTER.EXCEPT_CASTER] = function(self, caster, target)
        caster = caster.body.parent or caster
        return target ~= caster
    end,
    [SKILL.TARGET_FILTER.HT_1] = function(self, caster, target)
        return target.static.class == 1
    end,
    [SKILL.TARGET_FILTER.HT_2] = function(self, caster, target)
        return target.static.class == 2
    end,
    [SKILL.TARGET_FILTER.HT_1_2] = function(self, caster, target)
        return target.static.class == 1 or target.static.class == 2
    end,
    [SKILL.TARGET_FILTER.HT_3] = function(self, caster, target)
        return target.static.class == 3
    end,
    [SKILL.TARGET_FILTER.HR_1] = function(self, caster, target)
        return target.static.race == 1
    end,
    [SKILL.TARGET_FILTER.HR_2] = function(self, caster, target)
        return target.static.race == 2
    end,
    [SKILL.TARGET_FILTER.HR_3] = function(self, caster, target)
        return target.static.race == 3
    end,
    [SKILL.TARGET_FILTER.HR_4] = function(self, caster, target)
        return target.static.race == 4
    end,
    [SKILL.TARGET_FILTER.HP_GE] = function(self, caster, target, value)
        return target.attr.hp >= tsmath.rate(target.attr.hp_max, value)
    end,
    [SKILL.TARGET_FILTER.HP_LE] = function(self, caster, target, value)
        return target.attr.hp <= tsmath.rate(target.attr.hp_max, value)
    end,
    [SKILL.TARGET_FILTER.MP_GE] = function(self, caster, target, value)
        return target.attr.mp >= tsmath.rate(target.attr.mp_max, value)
    end,
    [SKILL.TARGET_FILTER.MP_LE] = function(self, caster, target, value)
        return target.attr.mp <= tsmath.rate(target.attr.mp_max, value)
    end,
    [SKILL.TARGET_FILTER.ATTR_LT] = function(self, caster, target, attrid, value)
        return target.attr[CONST.ATTR[attrid]] < value
    end,
    [SKILL.TARGET_FILTER.ATTR_GT] = function(self, caster, target, attrid, value)
        return target.attr[CONST.ATTR[attrid]] > value
    end,
    [SKILL.TARGET_FILTER.ATTR_EQ] = function(self, caster, target, attrid, value)
        return target.attr[CONST.ATTR[attrid]] == value
    end,
    [SKILL.TARGET_FILTER.FRONT_ROW] = function(self, caster, target)
        return target.prop.stance and target.prop.stance <= 2
    end,
    [SKILL.TARGET_FILTER.BACK_ROW] = function(self, caster, target)
        return target.prop.stance and target.prop.stance > 2
    end,
    [SKILL.TARGET_FILTER.FACE] = function(self, caster, target)
        caster = caster.body.parent or caster
        local stance = caster.prop.stance
        return target.prop.stance and stance and target.prop.stance == stance
    end,
    [SKILL.TARGET_FILTER.FRONT] = function(self, caster, target)
        local dir = (target.body.position - caster.body.position).normalized
        local header = caster.body.header
        local dot = tsvector.dot(dir, header)
        return dot > 0
    end,
    [SKILL.TARGET_FILTER.BEHIND] = function(self, caster, target)
        local dir = (target.body.position - caster.body.position).normalized
        local header = caster.body.header
        local dot = tsvector.dot(dir, header)
        return dot < 0
    end,
    [SKILL.TARGET_FILTER.TARGET_BUFF] = function(self, caster, target, ...)
        for _, buffid in ipairs({...}) do
            if target.caller.buff and target.caller.buff:has(buffid) then
                return true
            end
        end
    end,
    [SKILL.TARGET_FILTER.TARGET_BUFF_NOT] = function(self, caster, target, ...)
        for _, buffid in ipairs({...}) do
            if target.caller.buff and target.caller.buff:has(buffid) then
                return false
            end
        end
        return true
    end,
    [SKILL.TARGET_FILTER.TARGET_BUFF_TYPE] = function(self, caster, target, bufftype)
        return target.caller.buff and target.caller.buff:contains_type(bufftype)
    end,
    [SKILL.TARGET_FILTER.ENEMY_SIDE] = function (self, caster, target, ...)
        local rect = global.service.area:getbattleside(CAMP.BLUE)
        return rect:contains(target.body.position)
    end,
    [SKILL.TARGET_FILTER.FRIEND_SIDE] = function (self, caster, target, ...)
        local rect = global.service.area:getbattleside(CAMP.RED)
        return rect:contains(target.body.position)
    end,
    [SKILL.TARGET_FILTER.GENDER] = function (self, caster, target, gender)
        return target.static and target.static.gender == gender
    end,
}

local range_filter = {
    [SKILL.RANGE.ALL] = function()
        return true
    end,
    [SKILL.RANGE.CIRCLE] = function(center, header, target, range1, range2)
        return tsvector.distance_less_equal(center, target.body.position, range1 + target.body.radius)
    end,
    [SKILL.RANGE.SECTOR] = function(center, header, target, range1, range2)
        local targetpos = target.body.position
        if tsvector.distance_less_equal(center, targetpos, range1 + target.body.radius) then
            local pos_angle = tsvector.angle(targetpos - center, header)
            if math.abs(pos_angle) < tsmath.floor(range2 / 2) then
                return true
            end
        end
    end,
    [SKILL.RANGE.RECT] = function(center, header, target, range1, range2, rect)
        return rect:contains(target.body.position, target.body.radius)
    end,
    [SKILL.RANGE.RECT_CENTER] = function(center, header, target, range1, range2, rect)
        return rect:contains(target.body.position, target.body.radius)
    end,
    [SKILL.RANGE.ENEMY_SIDE] = function(center, header, target, range1, range2, rect)
        return rect:contains(target.body.position)
    end,
    [SKILL.RANGE.FRIEND_SIDE] = function(center, header, target, range1, range2, rect)
        return rect:contains(target.body.position)
    end
}

---------------------------------------selecter---------------------------------------
local selecter = { _attrmax = {}, _attrmin = {}, _other = {} }

selecter.max = function(cb)

    return function(last, target, caster)
        local new = cb(target, caster)
        if not last or new > last then return new end
    end
end

selecter.min = function(cb)
    return function(last, target, caster)
        local new = cb(target, caster)
        if not last or new < last then return new end
    end
end

selecter.attr = function(attrname)
    return function(target)
        return target.attr[attrname]
    end
end

selecter.intensive = function (radius)
    return function (target, caster)
        local actors = global.service.area:getactors(target.prop.camp)
        local count = 0
        local targetpos = target.body.position
        for i, actor in ipairs(actors) do
            if tsvector.distance_less(actor.body.position, targetpos, radius) then
                count = count + 1
            end
        end
        return count
    end
end

selecter.getfilter = function(select)

    local selectid = select[1]

    if selectid == SKILL.SELECT.ATTR_MAX then
        local attrname = CONST.ATTR[select[2]]
        selecter._attrmax[attrname] = selecter._attrmax[attrname] or selecter.max(selecter.attr(attrname))
        return selecter._attrmax[attrname]
    elseif selectid == SKILL.SELECT.ATTR_MIN then
        local attrname = CONST.ATTR[select[2]]
        selecter._attrmin[attrname] = selecter._attrmin[attrname] or selecter.min(selecter.attr(attrname))
        return selecter._attrmin[attrname]
    else
        return selecter._other[selectid]
    end

end

selecter._getter = {
    [SKILL.SELECT.DIS_MIN] = function(target, caster)
        return tsvector.distance_squared(caster.body.position, target.body.position)
    end,

    [SKILL.SELECT.DIS_MAX] = function(target, caster)
        return tsvector.distance_squared(caster.body.position, target.body.position)
    end,

    [SKILL.SELECT.DEGREE_MIN] =function (target, caster)
        local dir = (target.body.position - caster.body.position).normalized
        local forward = caster.body.header-- caster.prop.camp == CAMP.RED and tsvector.new(0, 1000) or tsvector.new(0, -1000)
        return tsvector.angle(dir, forward)
    end,

    [SKILL.SELECT.INTENSIVE_1] = selecter.intensive(3000),
    [SKILL.SELECT.INTENSIVE_2] = selecter.intensive(4000),
    [SKILL.SELECT.INTENSIVE_3] = selecter.intensive(6000),

    [SKILL.SELECT.DIS_FORWARD] = function (target, caster)
        local _sizex, _sizey = global.service.area:getbattlesize()
        local _centerx, _centery = global.service.area:getbattlecenter()
        local _sidey = _centery + (_sizey/2)
        local _side = ({_sidey - target.body.position.y, target.body.position.y})[target.prop.camp]
        return _side
    end
}

selecter._other = {

    [SKILL.SELECT.DIS_MIN] = selecter.min(selecter._getter[SKILL.SELECT.DIS_MIN]),
    [SKILL.SELECT.DIS_MAX] = selecter.max(selecter._getter[SKILL.SELECT.DIS_MAX]),
    [SKILL.SELECT.DEGREE_MIN] = selecter.min(selecter._getter[SKILL.SELECT.DEGREE_MIN]),
    [SKILL.SELECT.INTENSIVE_1] = selecter.max(selecter._getter[SKILL.SELECT.INTENSIVE_1]),
    [SKILL.SELECT.INTENSIVE_2] = selecter.max(selecter._getter[SKILL.SELECT.INTENSIVE_2]),
    [SKILL.SELECT.INTENSIVE_3] = selecter.max(selecter._getter[SKILL.SELECT.INTENSIVE_3]),
    [SKILL.SELECT.DIS_FORWARD] = selecter.min(selecter._getter[SKILL.SELECT.DIS_FORWARD]),
}
---------------------------------------selecter---------------------------------------



---------------------------------------comparer---------------------------------------
local comparer = { _attrmax = {}, _attrmin = {}, }

comparer.max = function(cb, caster)
    return function(left, right)
        return cb(left, caster) > cb(right, caster)
    end
end

comparer.min = function(cb, caster)
    return function(left, right)
        return cb(left, caster) < cb(right, caster)
    end
end

comparer.getfilter = function(select, caster)

    local selectid = select[1]

    if selectid == SKILL.SELECT.ATTR_MAX then
        local attrname = CONST.ATTR[select[2]]
        comparer._attrmax[attrname] = comparer._attrmax[attrname] or comparer.max(selecter.attr(attrname))
        return comparer._attrmax[attrname]
    elseif selectid == SKILL.SELECT.ATTR_MIN then
        local attrname = CONST.ATTR[select[2]]
        comparer._attrmin[attrname] = comparer._attrmin[attrname] or comparer.min(selecter.attr(attrname))
        return comparer._attrmin[attrname]
    elseif selectid == SKILL.SELECT.DIS_MIN then
        return comparer.min(selecter._getter[selectid], caster)
    elseif selectid == SKILL.SELECT.DIS_MAX then
        return comparer.max(selecter._getter[selectid], caster)
    elseif selectid == SKILL.SELECT.DEGREE_MIN then
        return comparer.min(selecter._getter[selectid], caster)
    elseif selectid == SKILL.SELECT.INTENSIVE_1 or selectid == SKILL.SELECT.INTENSIVE_2 or selectid == SKILL.SELECT.INTENSIVE_3 then
        return comparer.max(selecter._getter[selectid], caster)
    elseif selectid == SKILL.SELECT.DIS_FORWARD then
        return comparer.min(selecter._getter[selectid], caster)
    end
end
---------------------------------------comparer---------------------------------------

---------------------------------------amendment---------------------------------------
local amendment = {
    [AMENDMENT.TYPE.PERCENT] = function (caster, target, value, rate)
        return value + tsmath.rate(value, rate)
    end,
    [AMENDMENT.TYPE.CONSTANT] = function (caster, target, value, constant)
        return constant
    end,
    [AMENDMENT.TYPE.HP_LINEAR] = function (caster, target, value, targetid, attrfrom, attrto, valuefrom, valueto)
        local sprite = targetid == 1 and caster or target
        local factor = sprite.attr.hp
        local factor_from = tsmath.rate(sprite.attr.hp_max, attrfrom)
        local factor_to = tsmath.rate(sprite.attr.hp_max, attrto)
        local rate = tsmath.factor_lerp(valuefrom, valueto, factor, factor_from, factor_to)
        return value + tsmath.rate(value, rate)
    end,
    [AMENDMENT.TYPE.MP_LINEAR] = function (caster, target, value, targetid, attrfrom, attrto, valuefrom, valueto)
        local sprite = targetid == 1 and caster or target
        local factor = sprite.attr.mp
        local factor_from = tsmath.rate(sprite.attr.mp_max, attrfrom)
        local factor_to = tsmath.rate(sprite.attr.mp_max, attrto)
        local rate = tsmath.factor_lerp(valuefrom, valueto, factor, factor_from, factor_to)
        return value + tsmath.rate(value, rate)
    end,
    [AMENDMENT.TYPE.ATTR_LINEAR] = function (caster, target, value, targetid, attr, attrfrom, attrto, valuefrom, valueto)
        local sprite = targetid == 1 and caster or target
        local factor = sprite.attr[CONST.ATTR[attr]]
        local factor_from = tsmath.rate(1000, attrfrom)
        local factor_to = tsmath.rate(1000, attrto)
        local rate = tsmath.factor_lerp(valuefrom, valueto, factor, factor_from, factor_to)
        return value + tsmath.rate(value, rate)
    end,
    [AMENDMENT.TYPE.ATTR_PERCENT] = function (caster, target, value, targetid, attr, rate)
        local sprite = targetid == 1 and caster or target
        local sprite_attr = sprite.attr[CONST.ATTR[attr]]
        return value + tsmath.rate(sprite_attr, rate)
    end,
    [AMENDMENT.TYPE.BUFF_LEVEL] = function (caster, target, value, targetid, buff, rate, constant)
        local sprite = targetid == 1 and caster or target
        local bufflv = 0
        if sprite.caller.buff then
            if type(buff) == "table" then
                for _, buffid in ipairs(buff) do
                    bufflv = bufflv + sprite.caller.buff:getlevel(buffid)
                end
            else
                bufflv = bufflv + sprite.caller.buff:getlevel(buff)
            end
            return value + (constant and rate * bufflv or tsmath.rate(value, rate * bufflv))
        end
        return value
    end,
    [AMENDMENT.TYPE.DISTANCE_LINEAR] = function (caster, target, value, disfrom, disto, valuefrom, valueto)
        local distance = tsvector.distance(caster.body.position, target.body.position)
        local factor = distance
        local factor_from = tsmath.rate(1000, disfrom)
        local factor_to = tsmath.rate(1000, disto)
        local rate = tsmath.factor_lerp(valuefrom, valueto, factor, factor_from, factor_to)
        -- print(value + tsmath.rate(value, rate))
        return value + tsmath.rate(value, rate)
    end,
    [AMENDMENT.TYPE.DISTANCE_COMPARE] = function (caster, target, value, typeid, distance_to, value_to)
        local distance = tsvector.distance(caster.body.position, target.body.position)
        local istype = typeid == 1 and distance_to > distance or distance_to < distance
        return istype and value + tsmath.rate(value, value_to) or value
    end,
}
---------------------------------------amendment---------------------------------------

rangelib = {target_filter = target_filter, range_filter = range_filter, selecter = selecter, comparer = comparer, amendment = amendment}
