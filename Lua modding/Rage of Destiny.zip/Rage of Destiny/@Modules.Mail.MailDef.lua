local MailDef = {}

MailDef.NotifyDef = {
    Mail_Request = "Mail_Request", --请求邮件信息
    Mail_Update="Mail_Update",--刷新邮件
    Mail_DeleteReadMailResult="Mail_DeleteReadMailResult",--一键删除已读邮件后刷新显示
}

MailDef.CommonDef={
    MailViewTitle="MailView_1001",--邮件标题
    GetBtn="MailView_1002",--一键领取
    DeleteBtn="MailView_1003",--一键删除
    EnsureBtn="MailView_1004",--确定
    GoBtn="MailView_1005",--前往
    MailDetailTitle="MailView_1006",--邮件详情标题
    ReceiveBtn="MailView_1007",--领取
    ExpireHour="MailView_1008",--小时后过期
    ExpireDay="MailView_1009",--天后过期
    ReceiveHour="MailView_1010", --小时前
    ReceiveDay="MailView_1011",--天前 
    DeleteMailSuccess="MailView_1012",--删除已读邮件成功
    NoRewardMail="MailView_1013",--没有奖励可领取
    SpecialMailTips="MailView_1014",--当前邮件奖励无法领取
    DeleteMailTips="MailView_1015",--确认删除所有已读邮件？
}

MailDef.MailType={
    normal=0, --普通邮件
    special=1,--特殊邮件版本更新
    system=2,--系统玩法自触发邮件
}

MailDef.TitleColor={
    [1]="<color=#FFFFFFCD>%s</color>",
    [2]="<color=#FFFFFF66>%s</color>"
}

MailDef.ExpiryTimeColor={
    [1]="<color=#FFFFFF7F>%s</color>",
    [2]="<color=#FFFFFF33>%s</color>"
}

MailDef.ReceptionTimeColor={
    [1]="<color=#FFFFFF4C>%s</color>",
    [2]="<color=#FFFFFF48>%s</color>"
}

MailDef.PostUrl ="http://192.168.0.133:8091/api/game"
return MailDef