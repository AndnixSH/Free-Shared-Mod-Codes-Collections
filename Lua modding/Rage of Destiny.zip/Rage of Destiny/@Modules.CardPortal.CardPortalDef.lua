local CardPortalDef = {}

CardPortalDef.TabType = 
{
    [1] = {key = ""},
    [2] = {key = ""},
    [3] = {key = ""},
}

CardPortalDef.Notify = {
	Update_CardPortal_Infos = "Update_CardPortal_Infos",
	Update_Draw_Card = "Update_Draw_Card",
    Update_Draw_Card_Data = "Update_Draw_Card_Data",

    Update_CardStar_SetHero="Update_CardStar_SetHero",
    Update_CardStar_BuyResult="Update_CardStar_BuyResult",
    GetNewHeroInfos = "GetNewHeroInfos",
}

--翻译文本key
CardPortalDef.LanguageKey = {
}

--标签抽卡类型
CardPortalDef.DrawCardType = 
{
	Normal = 1, --普通
	Faction = 2, --种族
    Companion = 3, --友情点
    StarGaze = 4, --占星
}

--抽卡类型
CardPortalDef.DrawType = 
{
    normal_one = 1, -- 普通单抽
    normal_ten = 2, -- 普通十连抽
    faction_one = 3, -- 种族单抽
    faction_ten = 4, -- 种族十连抽
    companion_one = 5, -- 友情点单抽
    companion_ten = 6, -- 友情点十连抽
    faction_elite_hero_card = 7, -- 种族紫卡
    faction_rare_hero_card = 8, -- 种族蓝卡
    elite_hero_soulstone = 9, -- 紫色灵魂石
    rare_hero_soulstone = 10, -- 蓝色灵魂石
    stargaze_one = 11, -- 占星单抽
    stargaze_ten = 12 -- 占星十连抽									
}

CardPortalDef.CacheRedDotType = 
{
	DrawCard = 1, --主界面红点
	NormalDrawCard = 2,  --普通抽卡
	RaceDrawCard = 3,  -- 种族抽卡
}

CardPortalDef.Page = 
{   
    DrawCard=0,--抽卡
    StarCard=1,--占星
}
    
CardPortalDef.PreLoaderRes = {
    --闪光特效
    FlashEffects = {
        [2] = "Scenes_20009_EndingFlashGreen",
        [3] = "Scenes_20009_EndingFlashBlue",
        [5] = "Scenes_20009_EndingFlashPurple",
    },
    
    --柱子特效
    BeamEffects = {
        [2] = {"Scenes_20009_EndingLightBeamGreen", 7}, --7个
        [3] = {"Scenes_20009_EndingLightBeamBlue", 5}, --5个
        [5] = {"Scenes_20009_EndingLightBeamPurple", 3},  --3个
    },
    
    --普通卡池特效
    NormalEffects = "Scenes_20009_0_m",
    
    --种族卡池特效
    RaceEffects = 
    {
        [1] = "Scenes_20009_1_m",
        [2] = "Scenes_20009_2_m",
        [3] = "Scenes_20009_3_m",
        [4] = "Scenes_20009_4_m",
    },
    
    --友情卡池特效
    CompanionEffects = "Scenes_20009_5_m", 

    --进度条特效
    Progress_effect_name_Res = "Scenes_20009_EndingShinyFlash_m",

    StandModels_Res = {
        [1] = "scence_20009_jindutiao_1",
        [2] = "scence_20009_jindutiao_2",
        --[3] = "scence_20009_jindutiao_2",
        [4] = "scence_20009_jindutiao_3",
    },

}

return CardPortalDef