

local ChatDef = require "Modules.Chat.ChatDef"
local GuildProxy = require "Modules.Guild.GuildProxy"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local DateFormatUtil = require "Common.Util.DateFormatUtil"
local HtmlUtil = CS.HtmlUtil

local ChatProxy = ChatProxy or BaseClass(BaseProxy, TimerFactor)
local chat_channel = {
    native = 1000,
    world = 2000,
    guild = 3000,
    private = 4000,
    army = 5000,
}

function ChatProxy:__init()
    ChatProxy.Instance = self
    self.data={}
    self.sevenDays=7*60*60*24
    self.oneDay=1*60*60*24
    self.fiveMinutes=5*60
    self.selectKey=""

    self:AddProto(31000, self.On31000)
    self:AddProto(31001, self.On31001)
    self:AddProto(31002, self.On31002)
    self:AddProto(31003, self.On31003)
    self:AddProto(31004, self.On31004)
    self:AddProto(31005, self.On31005)
    self:AddProto(31006, self.On31006)
    self:AddProto(31007, self.On31007)
    self:AddProto(31008, self.On31008) --解除禁言
    self.world_channelId=1

    self.ExpressionList={}
    --self.ExpressionList.expression={{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20}}
    self.ExpressionList.title={1,2}
self.ExpressionList.expression ={{ "叅","叇","喌","喎","喦","喸","嗀","嗁","嗋","嘂",
	"圝","圞","嘑","嘓","嘦","鰢","嘼","噐","噚","噛",
	"噝","噮","噵","噽","嚂","嚃","嚈","嚋","嚘","嚠",
	"嚪","嚭","嚱","嚲"},{"嚵","嚹","嚻","嚽","囆","囇","囐","囕","囖","墝","壄","嗧","壏","壐","壣","壪","嬨","嬮","嬯","嬱"},{} }--,  
	--   ,--    ,"嬺","嬻",
	--    "孂","孋","孍","嶳","嶷","巁","巂","巄","巆",
	-- 	"巇","巈","巉","巊","巌","巏","巐","巑","巕",
	-- 	 "巗","巘","巙","巚","廏","廕","廞","廤","廥","廧",
	-- 	 "廨","廭","廮","廯","廰","廱","廲","瀗",
	-- 	  "瀡","瀣","瀤","瀥","瀩","瀫","瀯","瀱","瀳",
	-- 	  "瀴","瀵","瀶","瀺","瀻","瀽","灁","瀺",
	-- 	  "灅","灆","灇","灈","灉","灊","灋","灍","灎","灐",
	-- 	  "灒","灓","灖","灗","灙","灚","灛","灟","灠","灥",
	-- 	  "灦","灧","灪","燲","燳","燵","燵","牋","燺","燽",
	-- 	  "爁","爄","爇","爊","爌","爏","爜","爝","爡","爥","爧",
    -- 		"爨","爩","犡","犤","犥","犪","犫" }
    
    self.room_per_num=50
    self.player_data =false

    self.enable_chat = false
end

function ChatProxy:__delete()
    ChatProxy.Instance = nil
end

function ChatProxy:Send70002(roomid)
   --切换世界聊天房间
   local encoder=NetEncoder.New()
    encoder:Encode("I4",roomid)
   self:SendMessage(70000,encoder)
end
function ChatProxy:GetRoomListData(startroomid,endroomid)
    if not self.data.roomList then
        self.data.roomList={}
        -- for i=1,1000 do
        --     local item={}
        --     item.roomid=i
        --     item.curPeopleNum=math.random(1,150)
        --     table.insert(self.data.roomList,item)
        -- end
    end
    local list={}
    for i=startroomid,endroomid do
        if self.data.roomList[i] then
            table.insert(list,self.data.roomList[i])
        end
    end
    return list
end

function ChatProxy:GetRoomTitleListData()
    if not self.data.roomList then
        self.data.roomList={}
        -- for i=1,1000 do
        --     local item={}
        --     item.roomid=i
        --     item.curPeopleNum=math.random(1,150)
        --     table.insert(self.data.roomList,item)
        -- end
    end
    local count,mod=math.modf( #self.data.roomList / self.room_per_num)
    
    local tt= #self.data.roomList % self.room_per_num
    if mod ~= 0 then
        count = count + 1
    end
    local list={}
    for i=  1, count do
        local item={}
        item.id=i
        local init=(i-1)*self.room_per_num 
        item.startroomid = (init == 0 and 1 or init)
        local endvalua=i*self.room_per_num-1 
        item.endroomid= endvalua >= #self.data.roomList and #self.data.roomList or endvalua
        item.name=LanguageManager.Instance:GetWord("ChatView_1042")..string.format("%s-%s",item.startroomid,item.endroomid)
        table.insert(list,item)
    end
    return list
end

function ChatProxy:On70002(decoder)
    local result=0-- decoder:Decode("I1")
    if result == 0 then
        
        GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord(ChatDef.CommonDef.ChangeSuccess))
    else
        GameLogicTools.ShowErrorCode(70001,result)
    end
end

function ChatProxy:Send70000()
    self:SendMessage(70000)
end

function ChatProxy:UpdateSelectTitle()
    self:ToNotify(self.data,ChatDef.NotifyDef.Chat_UpdateSelectTitle,{})
end

function ChatProxy:OnClickHeadBtn(player)

    local find=false
    local newtitle={}
    for _,v in ipairs(self.data.titleList) do
        if v.player then
            if v.player.uin == player.uin then
                find=true
                newtitle=v
                break
            end
        end
    end
    local key =self:GetKeyById(ChatDef.ChatType.chat_Private,player) 
    if not find  then
        local func=function ( data )
            --置顶按钮
           
            self:HandleTopBtn(data)
        end
        
        local func2=function ( data )
            --删除按钮
            self:HandleDeleteBtn(data)
        end
        --print("---------ChatProxy:OnClickHeadBtn--------")
       
        newtitle.topstate=0
        newtitle.list={}
        newtitle.player=player
        local privatelist=self:GetPrivatePlayerList()
        newtitle.id=ChatDef.ChatType.chat_Private + #privatelist + 1
        newtitle.newInfo=self:GetTitleChatContenShowInfo(0,nil,"")
        newtitle.timestamp=RoleInfoModel.servertime
        if not self.data.titleList then
            self.data.titleList={}
        end
        newtitle.topFunc=func
        newtitle.deleteFunc=func2
        local index=1
        for k, v in ipairs(self.data.titleList) do
            local key=self:GetKeyById(v.id,v.player)
            if self:GetChatTopState(key) == 0 then
                index = k
                break
            end
        end
        self:SetPrivateChatInfo(player,{})
        table.insert(self.data.titleList,index,newtitle)
        self:SetChatSelectKey(key)
        
    else
        self:SetChatSelectKey(key)
    end
    self:ToNotify(self.data,ChatDef.NotifyDef.Chat_UpdateTitleList,{titlelist=self.data.titleList, cur_change_titleData =newtitle})
end

function ChatProxy:Send70001(content,key)
    --type 1为文字内容，2，为表情
    local channel
    local uin=-1
    local data=self:GetDataByKey(key)
    local Item=self:CreatOneNewsForSelf(content)
    if  data and data.list then
        
         if #data.list > 0 then
            local timestr=self:GetDiffTimeStr(Item.timestamp,data.list[#data.list].timestamp)
            if timestr then
                local additem={}
                additem.uin = -1
                additem.time=timestr
                table.insert(data.list,additem)
            end
        end
        table.insert(data.list,Item)
      
        data.timestamp=data.list[#data.list].timestamp

        local nickname=Item.nickname
        if key == ChatDef.Chat_Key[1] then
            channel=chat_channel.world
            --self:SetChatWorldInfo(self.world_channelId,data.list)
        elseif key == ChatDef.Chat_Key[2] then
            channel=chat_channel.native
            --self:SetLocalChatInfo(data.list)
        elseif key == ChatDef.Chat_Key[3] then
            channel=chat_channel.guild
            --self:SetGuilChatInfo(data.list)
        elseif key == ChatDef.Chat_Key[4] then
            channel=chat_channel.army
            --self:SetArmyChatInfo(data.list)
        else
            nickname=nil
            channel=chat_channel.private
            data.player.timestamp=Item.timestamp
            uin=data.player.uin
            self:SetPrivateChatInfo(data.player,data.list)
        end
        data.newInfo=self:GetTitleChatContenShowInfo(0,nickname,content)

        self:ToNotify(self.data,ChatDef.NotifyDef.Chat_UpdateCurContentList,{list=data.list})
        self:ToNotify(self.data,ChatDef.NotifyDef.Chat_UpdateTitleList,{titlelist=self.data.titleList, cur_change_titleData =data})
    else
         --新建的聊天窗口
         print("--------------Send70001--------error-----------------")
        -- local newtitle={}
        -- newtitle.topstate=0
        -- newtitle.list={}
        -- newtitle.player=player
        -- newtitle.newInfo=self:GetTitleChatContenShowInfo(content)
        -- table.insert(newtitle.list,Item)
        -- self:SetPrivateChatInfo(player,newtitle.list)
        -- channel=chat_channel.private
        -- uin=player.uin
        -- self:ToNotify(self.data,ChatDef.NotifyDef.Chat_UpdateCurContentList,newtitle.list)
    end
    if channel == chat_channel.private then
        self:Send31002(uin,content)
    elseif channel == chat_channel.world then
        self:Send31004(content)
    else
        self:Send31001(channel,content)
    end
    
end

function ChatProxy:CaculateStrCount(str,limit_count)

    local lenInByte = #str
    local count = 0
    local i = 1
    local bytenum=0
    local cutstr=""
    local _byte = 1
    while true do
        local curByte = string.byte(str, i)
        if i > lenInByte then
            break
        end
        local byteCount = 1
        if curByte > 0 and curByte <= 127 then
            byteCount = 1                                              --1字节字符
            _byte = 1
        elseif curByte >= 192 and curByte < 223 then
            byteCount = 2                                              --双字节字符
            _byte = 2
        elseif curByte >= 224 and curByte < 239 then
            byteCount = 3                                              --中文
            _byte = 2
        elseif curByte >= 240 and curByte <= 247 then
            byteCount = 4                                              --4字节字符
            _byte = 2
        else
            break
        end

        if count <= limit_count and byteCount > 0 then
            cutstr=cutstr..string.sub(str , i , i+byteCount-1)
        end
        i = i + byteCount

        if byteCount >= 1 then
            count = count + _byte
        end
        
    end
    return count,cutstr
end
function ChatProxy:IsExpression(content)
    --是否为表情
    local result=string.split(content,"<emo name=")
    if result and  #result >= 2 then
        return true
       
    end
    return false
end

function ChatProxy:IsBigExpression(key)
    --是否为大表情
    for k , expressions in ipairs(self.ExpressionList.expression) do
        if k ~= 1 then
            for _ , v in ipairs(expressions) do
                 if v == key then
                    return true
                 end
            end
        end
    end
    return false
end
function ChatProxy:GetBigExpressionSprName(key)
    --是否为大表情
    for k , expressions in ipairs(self.ExpressionList.expression) do
       if k ~= 1 then
            for i , v in ipairs(expressions) do
                if v == key then
                     return  string.format("Emoji_%s",tostring((k - 1 )*1000+i))
                end
            end
       end 
    end
    return  "Emoji_1001"
end

function ChatProxy:GetTitleChatContenShowInfo(unreadnum,nickname,content,type)
    --local str="<emo name=%s scale=0.8 size=1 />"
    local headstr=""
    if nickname then
        headstr=string.format("%s%s:",LanguageManager.Instance:GetWord(ChatDef.CommonDef.Iam),nickname)
    end
    if self:IsBigExpression(content) then

        return headstr..string.format("[%s]",LanguageManager.Instance:GetWord(ChatDef.CommonDef.Expression))
        
    else
        local limit_count=20 --12个，因为加了一个空格
        if nickname then
            if content == "enter_guild_tips!" then
                content = string.format(LanguageManager.Instance:GetWord(ChatDef.CommonDef.AddGuildTips),nickname)
            elseif content == "exist_guild_tips!" then
                content= string.format(LanguageManager.Instance:GetWord(ChatDef.CommonDef.ExistGuildTips),nickname)
            end
        end
        if content == "agree_friend_tips!" then
            content = LanguageManager.Instance:GetWord(ChatDef.CommonDef.AgreeFriendTips)
        end
        local len,str=self:CaculateStrCount(headstr..content,limit_count)
        if len >= limit_count then
            if nickname then
                str = string.gsub(str,":","：",1)
            end
            return str.."…"
        else
            if nickname then
                headstr =  string.gsub(headstr,":","：",1)
            end
            
            return headstr..content
        end
    end
  
    -- if string.contains(content,str,false) then
    --     return string.format("[%s]",LanguageManager.Instance:GetWord(ChatDef.CommonDef.Expression))
    -- else
    --     local len=self:CaculateStrCount(content)
    --     if len > 15 then
    --         return string.sub(content,1,15).."…"
    --     else
    --         return content
    --     end
    -- end
end
--收到消息
function ChatProxy:Send70003(content,chattype,player,timestamp)
    --type 1为文字内容，2，为表情
    --local type=1
    --local content=""
    --local chattype=ChatDef.ChatType.chat_World
    --local player={}
    --local timestamp=os.time()
    local channelid=0 --频道id
    --local contentList={}
    local key=""
    local curkey=self:GetChatSelectKey()
   
    local nickname=player.nickname
    if chattype < ChatDef.ChatType.chat_Private then
        key=self:GetKeyById(chattype)
    else
        nickname=nil
        key=self:GetKeyById(ChatDef.ChatType.chat_Private,player)
    end

    local unreadnum=self:GetChatUnReadNum(key)
    local count = unreadnum
    if content ~= "enter_guild_tips!" and  content ~= "exist_guild_tips!"  then
        count=unreadnum+1
    end
    if curkey == key then
        count=0
    end
    local newInfo=self:GetTitleChatContenShowInfo(count,nickname,content)

    local _titleData=false
    local Item=self:CreatOneNewsForOther(content,player,timestamp)
    if not self.data.titleList then
        self.data.titleList={}
    end
    for i=1,#self.data.titleList do
        local _key=self:GetKeyById(self.data.titleList[i].id,self.data.titleList[i].player)
        if _key == key then
            _titleData=self.data.titleList[i]
            table.remove(self.data.titleList,i)
            local index=1
            for k, v in ipairs(self.data.titleList) do
                local key=self:GetKeyById(v.id,v.player)
                if self:GetChatTopState(key) == 0 then
                    index = k
                    break
                end
            end
            table.insert(self.data.titleList,index,_titleData)
            break
        end
    end
    if not self:IsTheKeyExist(key) or not _titleData then
        local list={}  --不存在改聊天窗口时
        if key == ChatDef.Chat_Key[1] then
            self:HandleWorldChatInfo(self.data.titleList,list,{})
        elseif key == ChatDef.Chat_Key[2] then
            self:HandleLocalChatInfo(self.data.titleList,list,{})
        elseif key == ChatDef.Chat_Key[3] then
            self:HandleGuildChatInfo(self.data.titleList,list,{})
        elseif key == ChatDef.Chat_Key[4] then
            self:HandleArmyChatInfo(self.data.titleList,list,{})
        else
            self:HandlePrivateChatInfo(self.data.titleList,list,{})
        end
        for i=1,#self.data.titleList do
            local _key=self:GetKeyById(self.data.titleList[i].id,self.data.titleList[i].player)
            if _key == key then
                _titleData=self.data.titleList[i]
                break
            end
        end
    end
    
    if _titleData then
        --收到存在对象的一条新消息
        
    else
        local func=function ( data )
            --置顶按钮
           
            self:HandleTopBtn(data)
        end
        
        local func2=function ( data )
            --删除按钮
            self:HandleDeleteBtn(data)
        end
        local newtitle={}
        newtitle.topstate=0
        newtitle.list={}
        newtitle.player=player
        local isprivate=true
        if chattype < ChatDef.ChatType.chat_Private then
            --删除后又收到消息
            newtitle.id=chattype
            isprivate=false
            if chattype == ChatDef.ChatType.chat_World then
                newtitle.channelid=self.world_channelId
                --self.world_channelId=channelid
            end
        else
            --收到新的对象的私聊信息
            local privatelist=self:GetPrivatePlayerList()
            newtitle.id=ChatDef.ChatType.chat_Private + #privatelist + 1
        end
        newtitle.topFunc=func
        newtitle.deleteFunc=func2
        local index=1
        for k, v in ipairs(self.data.titleList) do
            local key=self:GetKeyById(v.id,v.player)
            if self:GetChatTopState(key) == 0 then
                index = k
                break
            end
        end
        table.insert(self.data.titleList,index,newtitle)
        -- if isprivate then
        --     table.insert(self.data.titleList,newtitle)
        -- else
        --     local index=#self.data.titleList
        --     for k, v in ipairs(self.data.titleList) do
        --         local key=self:GetKeyById(v.id,v.player)
        --         if v.id >= ChatDef.ChatType.chat_Private and self:GetChatTopState(key) == 0 then
        --             index = k
        --             break
        --         end
        --     end
        --     table.insert(self.data.titleList,index+1,newtitle)
        -- end
        _titleData=newtitle
    end
    if _titleData then
        
        if chattype == ChatDef.ChatType.chat_Guild then
            if content ~= "exist_guild_tips!" and content ~= "enter_guild_tips!" then
                _titleData.newInfo=newInfo
            end
        else
            _titleData.newInfo=newInfo
        end
        if #_titleData.list > 0 then
            if _titleData.list[#_titleData.list].timestamp then
                local timestr=self:GetDiffTimeStr(timestamp,_titleData.list[#_titleData.list].timestamp)
                if timestr then
                    local additem={}
                    additem.uin = -1
                    additem.time=timestr
                    table.insert(_titleData.list,additem)
                end
            end
        end
        table.insert(_titleData.list,Item) -----消息在此处塞入聊天内容队列
        _titleData.timestamp=_titleData.list[#_titleData.list].timestamp
    end
    if key == ChatDef.Chat_Key[1] then
        --self:SetChatWorldInfo(self.world_channelId,_titleData.list)
    elseif key == ChatDef.Chat_Key[2] then
        --self:SetLocalChatInfo(_titleData.list)
    elseif key == ChatDef.Chat_Key[3] then
        --self:SetGuilChatInfo(_titleData.list)
    elseif key == ChatDef.Chat_Key[4] then
        --self:SetArmyChatInfo(_titleData.list)
    else
        _titleData.player.timestamp=Item.timestamp
        self:SetPrivateChatInfo(_titleData.player,_titleData.list)
    end
   
    if curkey == key then
        self:ToNotify(self.data,ChatDef.NotifyDef.Chat_UpdateCurContentList,{list=_titleData.list,breceive=true}) --收到当前消息
    end
    local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.ChatRootView)
    if view and  view:IsOpen() then
        if curkey ~= key then
            self:SetChatUnReadNum(key,count)
        end
    else
        --没有打开
        self:SetChatUnReadNum(key,count)
    end
    if chattype >= ChatDef.ChatType.chat_Private then
        --私聊是在这里保存
        --保存本地聊天消息后才可以通知更新，因为title那里是从本地读取聊天记录进行刷新
        self:ToNotify(self.data,ChatDef.NotifyDef.Chat_UpdateTitleList,{titlelist=self.data.titleList, cur_change_titleData =_titleData})
    end
end
function ChatProxy:OpenChat(player)

    if player and player.uin == RoleInfoModel.guserid then
        GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord(ChatDef.CommonDef.CannotSendMsgToSelf))
        return
    end
    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.OtherPlayerInfolView)
    local view=LuaLayout.Instance:GetWidget(UIWidgetNameDef.ChatRootView)
    if view then

        
        if not view:IsOpen() then
            self.player_data=player
            local key=self:GetKeyById(ChatDef.ChatType.chat_Private,player)
            self:SetChatSelectKey(key)
            UIOperateManager.Instance:OpenWidget(AppFacade.Chat)
        else
            if player then
                local _player={}
                _player.uin=player.uin
                _player.headicon=player.headicon
                _player.frameicon=player.frameicon
                _player.nickname=player.nickname
                _player.sex = player.sex
                _player.level=player.level

                _player.fight=GameLogicTools.GetNumStr(0)
                _player.content=""
                _player.timestamp=RoleInfoModel.servertime
                _player.newstype=0
                self:OnClickHeadBtn(_player)
            else
                print("--------OpenChat----player null---------")
            end
            
        end
    end
end

function ChatProxy:GetChatInfoForMainView()
    local data={}
    self:HandleWorldChatInfo(data,{},{})
    self:HandleLocalChatInfo(data,{},{})
    self:HandleGuildChatInfo(data,{},{})
    self:HandleArmyChatInfo(data,{},{})
    self:HandlePrivateChatInfo(data,{},{})
    return data
end

function ChatProxy:CreatOneNewsForOther(content,player,timestamp)
    local item={}
    item.uin=player.uin
    item.headicon=player.headicon
    item.frameicon=player.frameicon
    item.nickname=player.nickname
    item.sex = player.sex
    item.level=player.level
    item.fight=GameLogicTools.GetNumStr(0)
    item.content=content
    item.timestamp=timestamp
    item.newstype=0
    item.guildname = player.guildname
    item.translate = ""
    return item
end


function ChatProxy:CreatOneNewsForSelf(content)
    local item={}
    item.uin=RoleInfoModel.guserid
    item.headicon=RoleInfoModel.headicon
    item.frameicon=RoleInfoModel.frameicon
    item.nickname=RoleInfoModel.nickname
    item.sex = RoleInfoModel.sex
    item.level=RoleInfoModel.level
    item.fight=GameLogicTools.GetNumStr(0)
    item.content=content
    item.timestamp=RoleInfoModel.servertime
    item.newstype=0
    item.translate = ""
    return item
end

function ChatProxy:On70001(decoder)
    local result=0-- decoder:Decode("I1")
    if result == 0 then
        
        
    else
        GameLogicTools.ShowErrorCode(70001,result)
    end
end
function ChatProxy:GetDiffTimeStr(timestamp1,timestamp2)
    local difftime=os.difftime(timestamp1,timestamp2)
    if difftime > self.fiveMinutes then
        local time=os.difftime(RoleInfoModel.servertime,timestamp1)
        --local tb = {}
        
        -- local tb = DateFormatUtil.Date("*t", timestamp1)

        -- local cDateTodayTime = DateFormatUtil.Time({year=tb.year, month=tb.month, day=tb.day, hour=0,min=0,sec=0})
        -- local tt = RoleInfoModel.servertime - cDateTodayTime -- 包含当天

        --用本地时间显示
        local tb2 = os.date("*t", timestamp1)

        local cDateTodayTime2 = os.time({year=tb2.year, month=tb2.month, day=tb2.day, hour=0,min=0,sec=0})
        local tt2 = RoleInfoModel.servertime - cDateTodayTime2 -- 包含当天

        local year = tb2.year
        local month = tb2.month
        local dd = tb2.day
        local hour = tb2.hour
        local minute = tb2.min
        local mstr= month < 10 and "0"..tostring(month) or tostring(month)
        local dstr=dd < 10 and "0"..tostring(dd) or tostring(dd)
        local hstr=hour < 10 and "0"..tostring(hour) or tostring(hour) 
        local mistr=minute < 10 and "0"..tostring(minute) or tostring(minute) 
        
        --local weekday = (DateFormatUtil.Date("%w", timestamp1))
        local weekday = (os.date("%w", timestamp1))
        if tt2 < self.oneDay then
             --当天消息
             return string.format("%s:%s",hstr ,mistr )
        elseif tt2 >= self.oneDay and tt2 < 2 *self.oneDay then
            --隔天 消息
            return string.format("%s %s:%s",LanguageManager.Instance:GetWord(ChatDef.CommonDef.YesterDay),hstr ,mistr )
        else
            if tt2 <  7 * self.oneDay then -- 包含当天 --(7 - weekday + 1)
                --一星期内
                return string.format("%s %s:%s",LanguageManager.Instance:GetWord(ChatDef.WeekDay[tonumber(weekday) == 0 and 7 or tonumber(weekday)]),hstr ,mistr )
            end
             --其他时间消息
             return string.format("%s/%s/%s %s:%s",year,mstr,dstr,hstr ,mistr )
        end
    end
end
function ChatProxy:DeleteExpireContent(list)
    local newlist={}
    local count = 0
    if list then
        for i=#list ,1,-1 do
            local item=list[i]
            if item then
                local time=os.difftime(RoleInfoModel.servertime,item.timestamp)
                if time > self.sevenDays then
                    break
                else
                   
                    table.insert(newlist,1,item)
                    count = count + 1
                    if count >= 1000 then
                        break --最多1000 条
                    end
                    local beforitem=list[i-1]
                    if beforitem then
                        local timestr=self:GetDiffTimeStr(item.timestamp,beforitem.timestamp)
                        if timestr then
                            local additem={}
                            additem.uin = -1
                            additem.time=timestr
                            table.insert(newlist,1,additem)
                        end
                    end
                    
                end
            end
        end
        return newlist
    end
end

function ChatProxy:HandleWorldChatInfo(titleList,worldlist,new_worldlist,world_channelid)
    local id = ChatDef.ChatType.chat_World
    local key=self:GetKeyById(id)
    local unreadnum=self:GetChatUnReadNum(key)
   -------------------之前的聊天内容---------------------------
    local channelid=0
    channelid,worldlist=self:GetChatWorldInfo() 
    if world_channelid then
        if  channelid ~= world_channelid then
            channelid=world_channelid
        end
    end
    if channelid ~= 0 then
        self.world_channelId=channelid
    end
    
    if not worldlist  then
        worldlist={}
    end
    local topstate =0
    if key then
        topstate = self:GetChatTopState(key)
    end
    --------------------发来的最新消息------------------
    if not new_worldlist then
        new_worldlist={}
    end
    for i,v in pairs(new_worldlist) do
        if v then
            table.insert(worldlist,v)
        end
    end
    table.sort(
        worldlist,
        function(a, b) --排序
            return a.timestamp < b.timestamp --因为时间有先后顺序，新消息直接塞进之前读取本地消息之后的表里  ,未读消息数量需加上现在接受到的新消息数
        end
    )
    worldlist=self:DeleteExpireContent(worldlist) --消息只保存最近7天的
    self:SetChatWorldInfo(self.world_channelId,worldlist)

    local num=unreadnum + ( new_worldlist and #new_worldlist or 0)
    self:SetChatUnReadNum(key,num > #worldlist and #worldlist or num)
    local newInfo=""
    if #worldlist > 0 then
        newInfo=self:GetTitleChatContenShowInfo(num,worldlist[#worldlist].nickname,worldlist[#worldlist].content)
    end
    table.insert(titleList,{id= id,timestamp= #worldlist > 0 and worldlist[#worldlist].timestamp or 0,channelid=self.world_channelId,list=worldlist,topstate=topstate,newInfo=newInfo})
end

function ChatProxy:HandleLocalChatInfo(titleList,locallist,new_locallist)
    local id = ChatDef.ChatType.chat_Local
    local key=self:GetKeyById(id)
    local unreadnum=self:GetChatUnReadNum(key)
    -------------------之前的聊天内容---------------------------
    locallist=self:GetLocalChatInfo() or {}
    if not locallist  then
        
        locallist={}
    end 
    local topstate =0
    if key then
        topstate = self:GetChatTopState(key)
    end
      
    --------------------发来的最新消息------------------
    if not  new_locallist then
        new_locallist={}
    end
    for i,v in pairs(new_locallist) do
        if v then
            table.insert(locallist,v)
        end
    end
    table.sort(
        locallist,
        function(a, b) --排序
            return a.timestamp < b.timestamp --因为时间有先后顺序，新消息直接塞进之前读取本地消息之后的表里  ,未读消息数量需加上现在接受到的新消息数
        end
    )
    locallist=self:DeleteExpireContent(locallist)
    self:SetLocalChatInfo(locallist)
    
    local num=unreadnum + ( new_locallist and #new_locallist or 0)
    
    self:SetChatUnReadNum(key,num > #locallist and #locallist or num)

    local newInfo=""
    if #locallist > 0 then
        newInfo=self:GetTitleChatContenShowInfo(num,locallist[#locallist].nickname,locallist[#locallist].content,locallist[#locallist].newstype)
    end
    
    table.insert(titleList,{id=id,timestamp=#locallist > 0 and locallist[#locallist].timestamp or 0 ,list=locallist,topstate=topstate,newInfo=newInfo})
end

function ChatProxy:HandlePrivateChatInfo(titleList,privatelist,new_privatelist)

    
    local init=ChatDef.ChatType.chat_Private
    privatelist=self:GetPrivatePlayerList() or {}
    if not  privatelist  then
        privatelist={}
    end
    if not new_privatelist then
        new_privatelist={}
    end
    for k,player in pairs(new_privatelist) do
        local find=false
        for i,v in pairs(privatelist) do
            if v.uin == player.uin then
                find=true
                local id = init+(k - 1)
                local key=self:GetKeyById(id,v)
                local contentlist=self:GetOnePrivateChatInfo(v.uin)
                for _, _content in pairs(player.content) do
                    table.insert(contentlist,_content)
                end
                table.sort(
                    contentlist,
                    function(a, b) --排序
                        return a.timestamp < b.timestamp
                    end
                )
                local newlist=self:DeleteExpireContent(contentlist)
                v.timestamp=newlist[#newlist].timestamp
                local initnum=self:GetChatUnReadNum(key)
                local num=initnum + #player.content
                self:SetChatUnReadNum(key,num > #newlist and #newlist or num) 
                self:SetPrivateChatInfo(v,newlist)
                break
            end
        end
        if not find then
            local id = init+(k - 1)
            local key=self:GetKeyById(id,player)
            table.sort(
                player.content,
                function(a, b) --排序
                    return a.timestamp < b.timestamp
                end
            )
            local newlist=self:DeleteExpireContent(player.content)
            player.timestamp=newlist[#newlist].timestamp
            self:SetChatUnReadNum(key,#newlist) 
            self:SetPrivateChatInfo(player,newlist)
            table.insert(privatelist,player)
        end
    end
    table.sort(
        privatelist,
        function(a, b) --排序
            return a.timestamp < b.timestamp
        end
    )
    for i,v in pairs(privatelist) do

        local id = init+(i - 1)
        local key=self:GetKeyById(id,v)
        local topstate =0
        if key then
            topstate = self:GetChatTopState(key)
        end
        -- table.sort(
        -- v.content,
        -- function(a, b) --排序
        --     return a.timestamp < b.timestamp
        -- end)
        local num=self:GetChatUnReadNum(key)
        local contentlist=self:GetOnePrivateChatInfo(v.uin)
        local newlist=self:DeleteExpireContent(contentlist)
        self:SetChatUnReadNum(key,num > #newlist and #newlist or num) 
        self:SetPrivateChatInfo(v,newlist)
        local newInfo=""
        if #newlist > 0 then
            newInfo=self:GetTitleChatContenShowInfo(0,nil,newlist[#newlist].content,newlist[#newlist].newstype)
        end
        table.insert(titleList,{id= id,timestamp= #newlist > 0 and newlist[#newlist].timestamp or 0,list=newlist,player=v,topstate=topstate,newInfo=newInfo})
    end
end

function ChatProxy:HandleGuildChatInfo(titleList,guildlist,new_guildlist)

    local guilname= GuildProxy.Instance:GetGuildName()
    if guilname ~= "" then 
        -- table.sort(
        --     guildlist,
        --     function(a, b) --排序
        --         return a.timestamp < b.timestamp
        --     end
        -- )
        local id = ChatDef.ChatType.chat_Guild
        local key=self:GetKeyById(id)
        local unreadnum=self:GetChatUnReadNum(key)
        guildlist=self:GetGuilChatInfo() or {}
        if not guildlist then
            guildlist={}
        end
        local topstate =0
        if key then
            topstate = self:GetChatTopState(key)
        end
        if not new_guildlist then
            new_guildlist={}
        end
        table.sort(
            guildlist,
            function(a, b) --排序
                return a.timestamp < b.timestamp
            end
        )
        table.sort(
            new_guildlist,
            function(a, b) --排序
                return a.timestamp < b.timestamp
            end
        )
        -- 从服务器里获取的信息列表里刷选新消息
        local timestamp = 0
        local new_unread=0
        if #guildlist > 0 then
            timestamp = guildlist[#guildlist].timestamp
        end
        for i,v in ipairs(new_guildlist) do
            if v then
                if v.timestamp > timestamp then
                    if v.content   ~= "exist_guild_tips!" and v.content ~= "enter_guild_tips!" then
                        new_unread = new_unread +  1
                    end
                    table.insert(guildlist,v)
                end
            end
        end
        guildlist=self:DeleteExpireContent(guildlist)
        self:SetGuilChatInfo(guildlist)
        local num=unreadnum + new_unread
        self:SetChatUnReadNum(key,num > #guildlist and #guildlist or num)

        local newInfo=""
        if #guildlist > 0 then
            for i = #guildlist , 1, -1 do
                if guildlist[i].uin > 0 and guildlist[i].content   ~= "exist_guild_tips!" and guildlist[i].content ~= "enter_guild_tips!" then
                    newInfo=self:GetTitleChatContenShowInfo(num,guildlist[i].nickname,guildlist[i].content,guildlist[i].type)
                    break
                end
            end
        end
        table.insert(titleList,{id=id,timestamp=#guildlist > 0 and guildlist[#guildlist].timestamp or 0,list=guildlist,guilname=guilname,topstate=topstate,newInfo=newInfo})
    else

        local id = ChatDef.ChatType.chat_Guild
        local key=self:GetKeyById(id)
        if self:IsTheKeyExist(key) then
            self:DeleteOneTitle(key)
        end
    end
end

function ChatProxy:HandleArmyChatInfo(titleList,armylist,new_armylist)
    local barmyOpen=false
    if barmyOpen then
        local id = ChatDef.ChatType.chat_Army
        local key=self:GetKeyById(id)
        local unreadnum=self:GetChatUnReadNum(key)

        armylist=self:GetArmyChatInfo() 
        if not armylist then
            armylist={}
        end
        if not  new_armylist then
            new_armylist={}
        end
        for i,v in pairs(new_armylist) do
            if v then
                table.insert(armylist,v)
            end
        end
        table.sort(
            armylist,
            function(a, b) --排序
                return a.timestamp < b.timestamp
            end
        )
        local topstate =0
        if key then
            topstate = self:GetChatTopState(key)
        end
        armylist=self:DeleteExpireContent(armylist)
        self:SetArmyChatInfo(armylist)
        local num=unreadnum + ( new_armylist and #new_armylist or 0)
        self:SetChatUnReadNum(key,num > #armylist and #armylist or num)

        local newInfo=""
        if #armylist > 0 then
            newInfo=self:GetTitleChatContenShowInfo(num,armylist[#armylist].nickname,armylist[#armylist].content,armylist[#armylist].newstype)
        end
        table.insert(titleList,{id=id,timestamp=armylist[#armylist].timestamp,list=armylist,topstate=topstate,newInfo=newInfo})
    end
end

function ChatProxy:On70000(world_channelid,new_worldlist,new_locallist,new_privatelist,new_guildlist,new_armylist)
    local titleList={}
    
    local worldlist={}
    local locallist={}
    local privatelist={}

    local guildlist={}
    local armylist={}

 
        --------------------最新消息等待服务器发来，------------------
    -- local new_worldlist={}
    -- local new_locallist={}
    -- local new_privatelist={} --页签列表，每个页签又又聊天内容列表
    -- local new_guildlist={}
    -- local new_armylist={}

    -- local uinkey=tostring(RoleInfoModel.guserid)..ChatDef.Chat_Setting.WorldChat.."_UnRead"
    -- if not PlayerPrefs.HasKey(uinkey) then
    --     --测试数据
    --     local tb = {}
    --     tb.year = tonumber(os.date("%Y",RoleInfoModel.servertime))
    --     tb.month =tonumber(os.date("%m",RoleInfoModel.servertime))
    --     tb.day = tonumber(os.date("%d",RoleInfoModel.servertime))
        
    
    --     local tt=0
    --     for i=1,15 do 
    --         tt = tt +i
    --         local item={}
    --         item.uin=1
    --         if i%4 == 0 then
    --             item.uin=RoleInfoModel.guserid
    --         end
    --         local cDateTodayTime = os.time({year=tb.year, month=tb.month, day=tb.day, hour=16,min=40+tt,sec=0})
    --         item.headicon=10001
    --         item.frameicon=21001
    --         item.nickname="测试"..tostring(i)
    --         item.sex=1
    --         if i%5 == 0 then
    --             item.sex=2
    --         end
    --         item.level=i
    --         item.fight=GameLogicTools.GetNumStr(0)
    --         item.content="测试聊天内容"
    --         item.timestamp=cDateTodayTime
    --         item.newstype=1
    --         if i%5 == 0 then
    --             item.newstype=2
    --             item.content="测试聊天内容   <emo name=ex_2 scale=0.8 size=1 />"
    --         end
    --         table.insert(new_worldlist,item)
    --         table.insert(new_locallist,item)
    --         table.insert(new_guildlist,item)
    --     end
    -- end

    local func=function ( data )
        --置顶按钮
       
		self:HandleTopBtn(data)
    end
    
    local func2=function ( data )
        --删除按钮
        self:HandleDeleteBtn(data)
    end

    self:HandleWorldChatInfo(titleList,worldlist,new_worldlist,world_channelid)
    self:HandleLocalChatInfo(titleList,locallist,new_locallist)
    self:HandleGuildChatInfo(titleList,guildlist,new_guildlist)
    self:HandleArmyChatInfo(titleList,armylist,new_armylist)
    self:HandlePrivateChatInfo(titleList,privatelist,new_privatelist)
    local sortlist={}
    local topList={}
    for i=#titleList ,1,-1 do
        local item=titleList[i]
        if item.topstate > 0 then
            --置顶
            table.remove(titleList,i)
            table.insert(topList,item)
        else
            local key=self:GetKeyById(item.id,item.player)
            local num=self:GetChatUnReadNum(key)
            if num ~= 0 then
                --未读
                if item.list and  #item.list > 0 then
                    table.remove(titleList,i)
                    table.insert(sortlist,item)
                end
            end
        end
        item.topFunc=func
        item.deleteFunc=func2
    end
    table.sort(
        topList,
        function(a, b) --排序
            return a.topstate < b.topstate
        end
    )
    table.sort(
        sortlist,
        function(a, b) --排序
            return a.timestamp < b.timestamp
        end
    )

    for i=1 ,#sortlist do  --新消息时间规则排序
        table.insert(titleList,1,sortlist[i])
    end
    for i=1 ,#topList do --置顶规则排序
        table.insert(titleList,1,topList[i])
    end

    self.data.titleList=titleList
    local key=self:GetChatSelectKey()
    local selectindex=self:GetIndexByKey(key == "" and ChatDef.Chat_Setting.WorldChat or key)
    self:ToNotify(self.data,ChatDef.NotifyDef.Chat_Request,titleList)

    self:UpdateTotalUnReadNum()
end

function ChatProxy:HideTotalRedNum()
    self:ToNotify(self.data,ChatDef.NotifyDef.Chat_UpdateFullTitleRedDot,{redcount=0})
end

function ChatProxy:UpdateTotalUnReadNum()
    
    local total_unread_num=0
    if self.data.titleList then
        local view=LuaLayout.Instance:GetWidget(UIWidgetNameDef.ChatRootView) --在聊天界面查看他人信息时不要更新红点
        if view:IsOpen() and  view.go.activeSelf then
            for i=1,#self.data.titleList do
                local key=self:GetKeyById(self.data.titleList[i].id,self.data.titleList[i].player)
                local num =self:GetChatUnReadNum(key)
                total_unread_num =total_unread_num+ num
            end
            self:ToNotify(self.data,ChatDef.NotifyDef.Chat_UpdateFullTitleRedDot,{redcount=total_unread_num})
        end
    end
end

function ChatProxy:HandleTopBtn(data)

    local key=self:GetKeyById(data.id,data.player)
    local state=self:GetChatTopState(key)
    local value=0
    if state == 0 then
        --置顶
        --print("------------置顶--------------=",data.id)
        local max=self:GetChatTopStateMax()
        value = max +1
        
        for k, v in ipairs(self.data.titleList) do
            if v.id == data.id then
                local item={}
                item=v
                table.remove(self.data.titleList,k)
                table.insert(self.data.titleList,1,item)
                self:SetChatTopState(key,value)
                self:ToNotify(self.data,ChatDef.NotifyDef.Chat_UpdateTitleList,{titlelist=self.data.titleList,cur_change_titleData = v,btopoperator=true})
                break
            end
        end
    else
        --取消置顶
        --print("------------取消置顶--------------=",data.id)
        value=0
        for k, v in ipairs(self.data.titleList) do
            if v.id == data.id then
                local item={}
                item=v
                table.remove(self.data.titleList,k)
                local isprivate=true
                for i=1,ChatDef.ChatType.chat_Army do
                    if data.id == i then
                        isprivate=false
                    end
                end
                if isprivate then
                    table.insert(self.data.titleList,item)
                else
                    local index=#self.data.titleList
                    for k, v in ipairs(self.data.titleList) do
                        local key=self:GetKeyById(v.id,v.player)
                        if v.id >= ChatDef.ChatType.chat_Private and self:GetChatTopState(key) == 0 then
                            index = k
                            break
                        end
                    end
                    --print("-------index----------=",index)
                    table.insert(self.data.titleList,index+1,item)
                end
                self:SetChatTopState(key,value)
                self:ToNotify(self.data,ChatDef.NotifyDef.Chat_UpdateTitleList,{titlelist=self.data.titleList,cur_change_titleData = v,btopoperator=true})
                break
            end
        end
    end
   
end

function ChatProxy:GetExpressionList()
    return self.ExpressionList
end

function ChatProxy:HandleDeleteBtn(data)
    for k, v in ipairs(self.data.titleList) do
        if v.id == data.id then
            --print("------------删除--------------=",data.id)
            table.remove(self.data.titleList,k)
            local key=self:GetKeyById(data.id,data.player)
            self:DeleteOneTitle(key)
            if data.id >= ChatDef.ChatType.chat_Private then
                --处理私聊列表
                local privatelist={}
                for k, v in ipairs(self.data.titleList) do
                    if v.id >= ChatDef.ChatType.chat_Private then
                        table.insert(privatelist,v)
                    end
                end
                self:SetPrivatePlayerList(privatelist)
            end
            break
        end
    end
    self:ToNotify(self.data,ChatDef.NotifyDef.Chat_UpdateTitleList,{titlelist=self.data.titleList,delete=true,cur_change_titleData=data})
end

function ChatProxy:GetDataByKey(key)

    for i=1,#self.data.titleList do
        if key == self:GetKeyById(self.data.titleList[i].id,self.data.titleList[i].player) then
            return self.data.titleList[i]
        end
    end
    -- if self.data and self.data.titleList then
    --     return self.data.titleList[index]
    -- end
end

function ChatProxy:GetKeyById(id,player)
    local key=self:GetChatTypeKey(id)
    if not key then
        if player then
            return ChatDef.Chat_Setting.PrivateChat..tostring(player.uin)
        else
            return ChatDef.Chat_Key[1]
            --print("--------GetKeyById------------------error-------------------------",id)
        end
    end
    return key 
end


function ChatProxy:GetIdByKey(key)
    local id=ChatDef.Chat_Key_Index[key]
    local uin
    if not id then
       
         local result=string.split(key,"_")
         uin= result and result[3] or nil
         return tonumber(uin) --私聊返回玩家uin
    end
    return id
end

function ChatProxy:GetIndexByKey(key)
    local id=self:GetIdByKey(key)
    if self.data and self.data.titleList then
        for i,v in ipairs(self.data.titleList) do
            if v then
               if id then
                    if id == v.id or (v.player and v.player.uin == id) then
                       
                        return i
                    end
               else
                    --print("---------GetIndexByKey----------error------------",key)
               end
            end
        end
    end
    return 0
end

function ChatProxy:DeleteOneTitle(key)
    if key then
        local index=self:GetIndexByKey(key)
        if self.data and self.data.titleList then
            if self.data.titleList[index] then
                table.remove(self.data.titleList,index)
            end
        end
        self:DeleteOneKey(key) --
        if key == self:GetChatSelectKey() then
            self:DeleteSelectKey()
        end
    else
        --print("------DeleteOneTitle----",key)
    end
    
end
function ChatProxy:UpdateNewEffect(type)
    self:ToNotify(self.data,ChatDef.NotifyDef.Chat_UpdateNewEffect,{type = type})
end
------------------------------------------------------------存本地------------------------------------------------------
function ChatProxy:IsTheKeyExist(key)
	
	return PlayerPrefs.HasKey(tostring(RoleInfoModel.guserid)..key)
end

function ChatProxy:SetChatUnReadNum(type,unreadNum)
	local uinkey=tostring(RoleInfoModel.guserid)..type.."_UnRead"
    PlayerPrefs.SetInt(uinkey,unreadNum or 0)
end
function ChatProxy:GetChatUnReadNum(type)
	local uinkey=tostring(RoleInfoModel.guserid)..type.."_UnRead"
	return PlayerPrefs.GetInt(uinkey)
end

function ChatProxy:DeleteChatUnReadNumKey(key)
    local _key=key.."_UnRead"
    if PlayerPrefs.HasKey(_key) then
        PlayerPrefs.DeleteKey(_key)
    end
end

function ChatProxy:SetChatTopStateMax(value)
    local uinkey=tostring(RoleInfoModel.guserid).."Chat_Top_Max"
	PlayerPrefs.SetInt(uinkey,value or 0)
end

function ChatProxy:GetChatTopStateMax()
    local uinkey=tostring(RoleInfoModel.guserid).."Chat_Top_Max"
	return PlayerPrefs.GetInt(uinkey)
end

function ChatProxy:SetChatTopState(type,value)

	local uinkey=tostring(RoleInfoModel.guserid)..type.."_Top"
    PlayerPrefs.SetInt(uinkey,value or 0)
    local max=self:GetChatTopStateMax()
    if value > max then
        self:SetChatTopStateMax(value)
    end
    
end
function ChatProxy:GetChatTopState(type)
	local uinkey=tostring(RoleInfoModel.guserid)..type.."_Top"
	return PlayerPrefs.GetInt(uinkey)
end

function ChatProxy:DeleteChatTopStateKey(key)

    local _key=key.."_Top"
    if PlayerPrefs.HasKey(_key) then
        PlayerPrefs.DeleteKey(_key)
    end
    
end

function ChatProxy:SetChatWorldInfo(channelID,contentlist)
	--‘&,’作为隔断符
	local interstr="&,"
	if not channelID then
		return
	end
	local str=tostring(channelID)
	if contentlist then
		for i,v in pairs(contentlist) do
			if v and v.uin and v.uin ~= -1 then
				str = str..interstr
				local playerstr=self:GetPlayerInfoString(v)
				str = str..playerstr
			end
		end
	end
	local uinkey=tostring(RoleInfoModel.guserid)..ChatDef.Chat_Setting.WorldChat
    PlayerPrefs.SetString(uinkey,str)
end

function ChatProxy:GetChatWorldInfo()

	local interstr="&,"
	local uinkey=tostring(RoleInfoModel.guserid)..ChatDef.Chat_Setting.WorldChat
    local infostr=PlayerPrefs.GetString(uinkey)
	local info=string.split(infostr,interstr)
	local channelID=0
	local contentlist={}
	if info then 
		if info == "" then
			return 0,{}
		end
		channelID=tonumber(info[1] or 0)
		table.remove(info,1)
		contentlist=self:GetChatList(info)
	end
	return channelID,contentlist
end

function ChatProxy:GetPlayerInfoString(player)
	--‘#,’作为隔断符
	return string.format("%s#,%s#,%s#,%s#,%s#,%s#,%s#,%s#,%s#,%s",player.uin,player.headicon,player.frameicon,player.nickname,player.sex,player.level,player.content,player.timestamp,player.newstype,player.guildname or "")
end

function ChatProxy:SetLocalChatInfo(contentlist)
	self:SetCommonChatInfo(ChatDef.Chat_Setting.LocalChat,contentlist)
end

function ChatProxy:GetLocalChatInfo()
	return self:GetCommonChatInfo(ChatDef.Chat_Setting.LocalChat)
end

function ChatProxy:SetArmyChatInfo(contentlist)
	self:SetCommonChatInfo(ChatDef.Chat_Setting.ArmyChat,contentlist)
end

function ChatProxy:GetArmyChatInfo()
	return self:GetCommonChatInfo(ChatDef.Chat_Setting.ArmyChat)
end


function ChatProxy:SetGuilChatInfo(contentlist)
	self:SetCommonChatInfo(ChatDef.Chat_Setting.GuilChat,contentlist)
end

function ChatProxy:GetGuilChatInfo()
	return self:GetCommonChatInfo(ChatDef.Chat_Setting.GuilChat)
end

function ChatProxy:GetChatTypeKey(index)
	return ChatDef.Chat_Key[index]
end
function ChatProxy:GetChatList(info)
	local contentlist={}
	local interstr="#,"
	for i,v in pairs(info) do
		local player=self:GetOnePlayerInfo(v)
		if player then
			table.insert(contentlist,player)
		end
	end
	return contentlist
end

function ChatProxy:GetOnePlayerInfo(v)
	local item = {}
	local interstr="#,"
	if v and v ~= "" then
		local player=string.split(v,interstr)
		if player then
			item.uin=tonumber(player[1])
			item.headicon=tonumber(player[2])
			item.frameicon=tonumber(player[3])
			item.nickname=player[4]
			item.sex=tonumber(player[5])
			item.level=tonumber(player[6])
			item.fight=GameLogicTools.GetNumStr(0)
			item.content=player[7]
            item.timestamp=tonumber(player[8])
            item.newstype=tonumber(player[9])
            item.guildname = player[10]
            item.translate = "" --翻译
			return item
		end
	end
end

function ChatProxy:SetCommonChatInfo(type,contentlist)
	--‘&,’作为隔断符
	local interstr="&,"
	local str=""
	if contentlist then
		str=""
		for i,v in pairs(contentlist) do
			if v and v.uin and v.uin ~= -1 then
				if str ~= "" then
					str = str..interstr
				end
				local playerstr=self:GetPlayerInfoString(v)
				str = str..playerstr
			end
		end
	end
	local uinkey=tostring(RoleInfoModel.guserid)..type
	PlayerPrefs.SetString(uinkey,str)
end

function ChatProxy:GetCommonChatInfo(type)

	local interstr="&,"
	local uinkey=tostring(RoleInfoModel.guserid)..type
	local infostr=PlayerPrefs.GetString(uinkey)
	local info=string.split(infostr,interstr)
	local contentlist={}
	if info then 
		if info == "" then
			return contentlist
		end
		contentlist=self:GetChatList(info)
	end
	return contentlist
end

function ChatProxy:SetPrivateChatInfo(player,contentlist)
	
	if not player then
		return
	end
	local playerlist=self:GetPrivatePlayerList()
	if not  playerlist then
		playerlist={}
    end
    local has=false
    for i,v in pairs(playerlist) do
        if v.uin == player.uin then
            has=true
            playerlist[i]=player
            break
        end
    end
    if not has then
        table.insert(playerlist,player)
        self:SetPrivatePlayerList(playerlist)
    end
	self:SetCommonChatInfo(ChatDef.Chat_Setting.PrivateChat..tostring(player.uin),contentlist or {})--私聊天内容
	
end

function ChatProxy:GetOnePrivateChatInfo(uin)
	local interstr="&,"
	local uinkey=tostring(RoleInfoModel.guserid)..ChatDef.Chat_Setting.PrivateChat..tostring(uin)
	local infostr=PlayerPrefs.GetString(uinkey)
	local info=string.split(infostr,interstr)
	local contentlist={}
	if info then 
		if info ~= "" then
			contentlist=self:GetChatList(info)
		end
	end
	return contentlist
end

function ChatProxy:SetPrivatePlayerList(playerlist)
    --‘&,’作为隔断符
	local interstr="&,"
    local str=""  --所有玩家私聊列表
	if playerlist then --聊天内容
		for i,v in ipairs(playerlist) do
			if v and v.uin and v.uin ~= -1  then
				local playerstr=self:GetPlayerInfoString(v)
				str=str..playerstr
				if i ~= #playerlist then
					str = str..interstr
				end
			end
		end
    end
    local uinkey=tostring(RoleInfoModel.guserid)..ChatDef.Chat_Setting.PrivateChatList
	PlayerPrefs.SetString(uinkey,str)
end

function ChatProxy:GetPrivatePlayerList()

	local interstr="&,"
	local uinkey=tostring(RoleInfoModel.guserid)..ChatDef.Chat_Setting.PrivateChatList
	local infostr=PlayerPrefs.GetString(uinkey)
	local info=string.split(infostr,interstr)
	local playerlist={}
	if info then 
		if info == "" then
			return {}
		end
		for i,v in pairs(info) do
			local player=self:GetOnePlayerInfo(v)  --私聊列表的玩家信息没有时间戳 与聊天内容
            if player then
               --player.content=self:GetOnePrivateChatInfo(player.uin)
				table.insert(playerlist,player)
			end
		end
    end
    table.sort(
        playerlist,
        function(a, b) --排序
            return a.timestamp < b.timestamp
        end
    )
	return playerlist
end
function ChatProxy:GetChatSelectKey()
    if self.selectKey == "" then
        return ChatDef.Chat_Key[1]
    end
	--local uinkey=tostring(RoleInfoModel.guserid)..ChatDef.Chat_Setting.SelectKey
    --return PlayerPrefs.GetString(uinkey)
    return self.selectKey
end

function ChatProxy:SetChatSelectKey(key)
    self.selectKey=key
	--local uinkey=tostring(RoleInfoModel.guserid)..ChatDef.Chat_Setting.SelectKey
	--return PlayerPrefs.SetString(uinkey,key)
end

function ChatProxy:DeleteSelectKey()
	-- local uinkey=tostring(RoleInfoModel.guserid)..ChatDef.Chat_Setting.SelectKey
    -- PlayerPrefs.DeleteKey(uinkey)
    self.selectKey=""
end

function ChatProxy:DeleteOneKey(key)
    local uinkey=tostring(RoleInfoModel.guserid)..key
    if PlayerPrefs.HasKey(uinkey) then
        PlayerPrefs.DeleteKey(uinkey)
    end
	self:DeleteChatUnReadNumKey(uinkey)
	self:DeleteChatTopStateKey(uinkey)
end

--------------------------------------------------------------

function ChatProxy:On31000(decoder)
    -- print("------->>>On31000")
    local channel = decoder:Decode("I2")
    local from_guserid = decoder:Decode("I8")

    local from_player_info = {}
    from_player_info.nickname = decoder:Decode("s2")
    from_player_info.sex = decoder:Decode("I1")
    from_player_info.level = decoder:Decode("I2")
    from_player_info.headicon = decoder:Decode("I2")
    from_player_info.frameicon = decoder:Decode("I2")
    from_player_info.uin=from_guserid
    
    local content = decoder:Decode("s2")
    local time = decoder:Decode("I4")
    local guildname
    local chattype = ChatDef.ChatType.chat_Local
    if channel == chat_channel.native then
        guildname = decoder:Decode("s2")
        chattype=ChatDef.ChatType.chat_Local
    elseif channel == chat_channel.world then
        guildname = decoder:Decode("s2")
        chattype=ChatDef.ChatType.chat_World
    elseif channel == chat_channel.guild then
        chattype=ChatDef.ChatType.chat_Guild
    elseif channel == chat_channel.private then
        chattype=ChatDef.ChatType.chat_Private
    elseif channel == chat_channel.army then
        chattype=ChatDef.ChatType.chat_Army
    end
    from_player_info.guildname = guildname or ""
    if from_guserid ~= RoleInfoModel.guserid then
        
        self:Send70003(content,chattype,from_player_info,time) 
        self:UpdateTotalUnReadNum()
        
    else
        --自己发的
    end
    -- 统一在这里存储到本地 私聊例外（因为私聊自己发送消息这里不会收到），在发送时就存储
    local key = ""
    if chattype < ChatDef.ChatType.chat_Private then
        key=self:GetKeyById(chattype)
    else
        --key=self:GetChatSelectKey()   --self:GetKeyById(ChatDef.ChatType.chat_Private,from_player_info)
    end
    local msg=self:CreatOneNewsForOther(content,from_player_info,time)
    if key == ChatDef.Chat_Key[1] then
        local channelid,worldlist = self:GetChatWorldInfo()
        table.insert(worldlist,msg)
        self:SetChatWorldInfo(self.world_channelId,worldlist)
    elseif key == ChatDef.Chat_Key[2] then
        local list = self:GetLocalChatInfo()
        table.insert(list,msg)
        self:SetLocalChatInfo(list)
    elseif key == ChatDef.Chat_Key[3] then
        local list = self:GetGuilChatInfo()
        table.insert(list,msg)
        self:SetGuilChatInfo(list)
    elseif key == ChatDef.Chat_Key[4] then
        local list = self:GetArmyChatInfo()
        table.insert(list,msg)
        self:SetArmyChatInfo(list)
    else
    --    local list = self:GetOnePrivateChatInfo(from_guserid) --私聊例外
    --    table.insert(list,msg)
    --     self:SetPrivateChatInfo(from_player_info,list)
    end

    --更新title
    local selectKey=self:GetChatSelectKey()
	
    local _titleData= false
    for i=1,#self.data.titleList do
        local _key=self:GetKeyById(self.data.titleList[i].id,self.data.titleList[i].player)
        if _key == key then
            _titleData=self.data.titleList[i]
            break
        end
    end
    if key ~= "" and _titleData then
       
        self:ToNotify(self.data,ChatDef.NotifyDef.Chat_UpdateTitleList,{titlelist=self.data.titleList, cur_change_titleData =_titleData})
    else
        -- 私聊
    end
   
    --print("On30000 -->", channel, from_guserid, table.dump(from_player_info), content, time)
end

-- 本地聊天
function ChatProxy:Send31001(channel, content)

    local guildname = GuildProxy.Instance:GetGuildName()
    local encoder = NetEncoder.New()
    encoder:Encode("I2", channel)
    encoder:Encode("s2s2", content,guildname)
    self:SendMessage(31001, encoder)
    --print("-------------channel----------content------------",channel,content)
end

function ChatProxy:On31001(decoder)
    local result = decoder:Decode("I1")
    print("result --> On31001", result)
    if result == 0 then
        --print("send success")
    else
        if result == 1 then
            GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord("ChatView_1028"))
        end
    end
end

-- 私聊
function ChatProxy:Send31002(to_guserid, content)
    local encoder = NetEncoder.New()
    encoder:Encode("I8", to_guserid)
    --print("----------Send31002----------",to_guserid)
    encoder:Encode("s2", content)
    self:SendMessage(31002, encoder)
end

function ChatProxy:On31002(decoder)
    local result = decoder:Decode("I1")
    print("result --> On31001", result)
    if result == 0 then
        --print("send private chat success")
    else
        if result == 1 then
            GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord("ChatView_1028"))
        end
    end
end
function ChatProxy:CheckEnabelChat()
    return self.enable_chat
end

-- 请求聊天基础信息
function ChatProxy:Send31003()
    self:SendMessage(31003)
end

function ChatProxy:On31003(decoder)
    local world_chat_room ,exist_guild,enable_chat = decoder:Decode("I2I1I1")
    self:StartChatHeartbeat(world_chat_room)
    local offline_private_chat_infos = decoder:DecodeList("I8s2I1I2I2I2s2I4",true)
    local guild_chat_messages = decoder:DecodeList("I8s2I1I2I2I2s2I4",true)
    self.enable_chat = enable_chat == 0 and true or false
    local offline_private_infosList={}
    for _, v in ipairs(offline_private_chat_infos) do
        if v then
            local find=false
            local player={}
            for _, _player in ipairs(offline_private_infosList) do
                if _player.uin == v[1] then
                    player=_player
                    find=true
                    break
                end
            end
            if not find then
                player.uin=v[1]
                player.nickname=v[2]
                player.sex=v[3]
                player.level=v[4]
                player.headicon=v[5]
                player.frameicon=v[6]
                player.fight=GameLogicTools.GetNumStr(0)
                player.content={}
                --player.timestamp=v[8]
                table.insert(offline_private_infosList,player)
            end
            local content=self:CreatOneNewsForOther(v[7] and v[7] or "",player,v[8])--string.unpack(">s2"
            table.insert(player.content,content)
        end
    end

    local guild_chat_messages_list={}
    if exist_guild == 0 then
        for _, v in ipairs(guild_chat_messages) do
            if v then
                local player={}
                player.uin=v[1]
                player.nickname=v[2]
                player.sex=v[3]
                player.level=v[4]
                player.headicon=v[5]
                player.frameicon=v[6]
                local content=self:CreatOneNewsForOther(v[7] and v[7] or "",player,v[8])--string.unpack(">s2"
                table.insert(guild_chat_messages_list,content)
            end
        end
        table.sort(
            guild_chat_messages_list,
            function(a, b) --排序
                return a.timestamp < b.timestamp
            end
        )
    else
        local id = ChatDef.ChatType.chat_Guild
        local key=self:GetKeyById(id)
        if self:IsTheKeyExist(key) then
            self:DeleteOneTitle(key)
        end
    end
    --self:Send31004("你好呀你是谁呀~~~~~")
    self:On70000(world_chat_room,{},{},offline_private_infosList,guild_chat_messages_list,{})
    if self.player_data then
        self:OpenChat(self.player_data)
        self.player_data=false
    end
end

-- 发送世界聊天
function ChatProxy:Send31004(content)
    local guildname = GuildProxy.Instance:GetGuildName()
    local encoder = NetEncoder.New()
    encoder:Encode("s2I2s2", content,self.world_channelId,guildname)
    self:SendMessage(31004, encoder, "chat")
end

function ChatProxy:On31004(decoder)
    local result = decoder:Decode("I1")
    print("result --> On31004", result)
    if result == 0 then
        --print("send world chat success")
    else
        if result == 1 then
            GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord("ChatView_1028"))
        end
    end
end

-- 请求世界聊天频道信息
function ChatProxy:Send31005()
    self:SendMessage(31005, "", "chat")
end

function ChatProxy:On31005(decoder)
    local room_infos = decoder:DecodeList("I2I2", true)
    --print("------>>room_infos", table.dump(room_infos))
    self.data.roomList={}
    for i=1,#room_infos do
        local item={}
        item.roomid=room_infos[i][1]
        item.curPeopleNum=room_infos[i][2]
        table.insert(self.data.roomList,item)
    end
end

-- 切换世界聊天房间频道
function ChatProxy:Send31006(roomId)
    local encoder = NetEncoder.New()
    encoder:Encode("I2", roomId)
    self:SendMessage(31006, encoder)
end

function ChatProxy:On31006(decoder)
    local result ,roomId= decoder:Decode("I1I2")
    --print("result --> On31006", result)
    if result == 0 then
        self:StartChatHeartbeat(roomId)
        GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord(ChatDef.CommonDef.ChangeSuccess))
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.PindaoRootView)
        self.world_channelId=roomId
        for i=1,#self.data.titleList do
            if self.data.titleList[i].id == ChatDef.ChatType.chat_World then
                self.data.titleList[i].channelid=roomId
                self.data.titleList[i].newInfo=""
                self.data.titleList[i].timestamp=RoleInfoModel.servertime
                self.data.titleList[i].list={}
                self:ToNotify(self.data,ChatDef.NotifyDef.Chat_UpdateCurContentList,{list=self.data.titleList[i].list})
                self:SetChatWorldInfo(roomId,self.data.titleList[i].list) 
                self:ToNotify(self.data,ChatDef.NotifyDef.Chat_UpdateTitleList,{titlelist=self.data.titleList,cur_change_titleData=self.data.titleList[i]})
                break
            end
        end
    else
        GameLogicTools.ShowErrorCode(31006,result)
    end
end

function ChatProxy:StartChatHeartbeat(room_id)
    self:RemoveChatHearbeat()
    self.heartbeatTimer = self:AddTimer(function()
        self:Send31007(room_id)
    end, 5 * 60)
end

function ChatProxy:RemoveChatHearbeat()
    if self.heartbeatTimer then
        self:RemoveTimer(self.heartbeatTimer)
        self.heartbeatTimer = nil
    end
end

-- 发送世界聊天心跳包
function ChatProxy:Send31007(room_id)
    local encoder = NetEncoder.New()
    encoder:Encode("I2", room_id)
    self:SendMessage(31007, encoder, "chat")
end

function ChatProxy:On31007(decoder)
    local result = decoder:Decode("I1")
    if result == 0 then
        --print("send 31007 success")
    end
end

function ChatProxy:On31008(decoder)
    local enable_chat = decoder:Decode("I1")
    if enable_chat == 0 then
       self.enable_chat = true
    else
        self.enable_chat = false
    end
end

function ChatProxy:GetTranslateState()
    return self.bTranslate
end

function ChatProxy:Translating(content,item)
    if not self.bTranslate then
        self.curkey = self:GetChatSelectKey()
        self.classItem = item
        local str_tb = string.split(content,"<color=#ffffff00>")
        local str = ""
        self.small_express = {}
        for k , v in ipairs(str_tb) do
            if k == 1 then
                if v ~= ""  then
                    local tt2 = string.split(v ,"<color=#00000000>.</color>")
                    if #tt2 == 1 then
                        str = str..tt2[1]
                    else
                        for ii , _v in ipairs(tt2) do
                            if _v ~= "" then
                                str = str.._v.." "
                            end
                        end
                    end
                end
            else
                if v ~= "" then

                    local tt = string.split(v ,"<color=#00000000>.</color>")
                    if #tt == 1 then
                        local tt2 = string.split(tt[1],"</color>")
                        str = str.."@^"
                        table.insert(self.small_express,tt2[1])
                        if tt2[2] ~= "" then
                            str = str..tt2[2]
                        end
                    else
                        for ii , _v in ipairs(tt) do
                            if ii == 1 then
                                local tt2 = string.split(_v,"</color>")
                                str = str.."@^"
                                table.insert(self.small_express,tt2[1])
                                if tt2[2] ~= "" then
                                    str = str..tt2[2]
                                end
                            else
                                if _v ~= "" then
                                    str = str.._v.." "
                                end
                            end
                        end
                    end
                end
            end
        end
        self.translate_content = str
        local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
        local LanguageUtil = require "First.Util.LanguageUtil"
        IGGSdkProxy.Instance:TranslateText(nil,LanguageUtil.GetLanguageTraslateCode(),str)
        self.bTranslate = true
    end
end

function ChatProxy:TranslatingEnd(str,sourceLanguage)
    self.bTranslate =  false
    if str ~= "" then
        --翻译成功
        
        local str_tb = string.split(str,"@^")
        print("-------TranslatingEnd-0------",table.dump(str_tb))
        local deststr = ""
        for k , v in ipairs(str_tb) do

            if self.small_express[k] then
                deststr = deststr..v..self.small_express[k]
            else
                deststr = deststr..v
            end
        end
        --print("-------TranslatingEnd-------",deststr)
        -- -- 刷新datatitle
        -- local key=self.curkey 
        -- if key ~= "" then
        --     local data=self:GetDataByKey(key)
        --     for _ ,  v in ipairs(data.list or {}) do
        --         if v.timestamp and self.classItem and self.classItem.data then
        --             if v.timestamp == self.classItem.data.timestamp then
        --                 v.translate = str
        --                 break
        --             end
        --         end
        --     end
        -- end
        local sourcestr = ChatDef.Language[sourceLanguage] and  LanguageManager.Instance:GetWord(ChatDef.Language[sourceLanguage]) or nil
        self:ToNotify(self.data,ChatDef.NotifyDef.Chat_TranslateEnd,{translate = deststr ,item = self.classItem ,sourceLanguage = sourcestr  })
        self.classItem = false
    end
end
--------------------------------------------------------------
return ChatProxy