GameLogicTools = {}

----------------确认框------------
--该弹窗不走UI层级管理
function GameLogicTools.ShowConfirmById(id, call, ...)
	local config = ConfigManager.GetConfig("data_tips").confirm_tips[id]
	if config then
		local ConfirmView = require "First.Update.View.ConfirmView"
		local LanguageUtil = require "First.Util.LanguageUtil"		
		local content = string.format(LanguageUtil.GetWord(config.strContent), ...)
		return ConfirmView.Show(content, call, config.strLeft, config.strRight, config.strMiddle, config.type, config.strTitle, config.bclose,id, config.depth, config.bclickBack)
	end
end

--该弹窗走UI层级管理
function GameLogicTools.ShowConfirmById2(id, call, ...)
	local config = ConfigManager.GetConfig("data_tips").confirm_tips[id]
	if config then
		local NewConfirmView = require "Modules.Common.Msg.NewConfirmView"
		local LanguageUtil = require "First.Util.LanguageUtil"		
		local content = string.format(LanguageUtil.GetWord(config.strContent), ...)
		return NewConfirmView.Show(content, call, config.strLeft, config.strRight, config.strMiddle, config.type, config.strTitle, config.bclose,id, config.style, config.strRemind)
	end
end

----------------消耗确认框------------
function GameLogicTools.ShowCostConfirmById(id, call, needlist, ...)
	local config = ConfigManager.GetConfig("data_tips").cost_confirm_tips[id]
	if config then
		local CostConfirmView = require "Modules.Common.Msg.CostConfirmView"
		local LanguageUtil = require "First.Util.LanguageUtil"		
		local content = string.format(LanguageUtil.GetWord(config.strContent), ...)
		CostConfirmView.Show(content, call, config.strLeft, config.strRight, config.strTitle, config.property, needlist, config.show_type)
	end	
end

function GameLogicTools.ShowCostConfirmById2(id, call, customParam, ...)
	local config = ConfigManager.GetConfig("data_tips").cost_confirm_tips[id]
	if config then
		local CostConfirmView = require "Modules.Common.Msg.CostConfirmView"
		local LanguageUtil = require "First.Util.LanguageUtil"		
		local content = string.format(LanguageUtil.GetWord(config.strContent), ...)
		CostConfirmView.Show(content, call, config.strLeft, config.strRight, config.strTitle, config.property, nil, config.show_type, customParam)
	end	
end


----------------购买物品框------------ grid 格子id
function GameLogicTools.ShowFastShopView(property,currency_type, needcount,grid,call, ...)
	local CostConfirmView = require "Modules.Common.Msg.FastshopView"
	CostConfirmView.Show(property, currency_type,needcount,grid,call)
end

-------------移动提示--------------
function GameLogicTools.ShowMsgTips(strContent)
	-- print("===ShowMsgTips ===", strContent ,debug.traceback())
	local LanguageUtil = require "First.Util.LanguageUtil"		
	local MsgTipsView = require "Modules.Common.Msg.MsgTipsView"
	MsgTipsView.ShowMsgTips(LanguageUtil.GetWord(strContent))
end

function GameLogicTools.ShowErrorCode(cmd, result)
	local strContent = string.format("errorcode_%s_%s", cmd, result)
	local LanguageUtil = require "First.Util.LanguageUtil"		
	local MsgTipsView = require "Modules.Common.Msg.MsgTipsView"
	local str, bshow = LanguageUtil.GetWord(strContent)
	if bshow then
		MsgTipsView.ShowMsgTips(str)
	end	
end

--------------文本说明---------
-- content:string or table（a = {} ,a[1] = { strTitle = "tile", strContent = "haha"} ）
--parama {lineSpacing = 1, alignment = 0, fontSize=20}
function GameLogicTools.ShowText(content ,title1 ,parama)
	local ContentTipsView = require "Modules.Common.Msg.ContentTipsView"
	ContentTipsView.ShowMsgContent(content ,title1 ,parama)
end

function GameLogicTools.ShowTextByType(content ,title1 ,toggleTitle ,parama)
	local ContentPageTipsView = require "Modules.Common.Msg.ContentPageTipsView"
	ContentPageTipsView.ShowMsgContent(content ,title1 ,toggleTitle  ,parama)
end

function GameLogicTools.ShowTextById(id)
	local config = ConfigManager.GetConfig("data_tips").rule_tips[id]
	if config then
		if not config.tipsType or config.tipsType == 1 then
			GameLogicTools.ShowText(config.context ,config.title, config.parama)
		else
			GameLogicTools.ShowTextByType(config.context ,config.title,config.toggleTitle, config.parama)
		end
		
	end	
end

----------小文本说明
function GameLogicTools.ShowLabelTips(strContent, position, localPosition, fitWidth, ...)
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.LabelTipsView)
	if view then
		local LanguageUtil = require "First.Util.LanguageUtil"
		view.goodsid = goodsid
		view.position = position
		view.localPosition = localPosition
		view.fitWidth = fitWidth or false --只有一行时，是否适配宽度
		--view.label = strContent
		local content=LanguageUtil.GetWord(strContent)
		view.label =string.format(content, ...) 
		if view:IsOpen() then
			view:UpdateInfo()
		else
			view:OpenView()	
		end	
	end
end

----------小文本说明
function GameLogicTools.ShowLabelTipsAjustWidth(strContent, position, localPosition,width,...)
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.LabelTipsView)
	if view then
		local LanguageUtil = require "First.Util.LanguageUtil"
		view.goodsid = goodsid
		view.position = position
		view.localPosition = localPosition
		view.adjustwidth=width
		view.fitWidth = false --只有一行时，是否适配宽度
		--view.label = strContent
		local content=LanguageUtil.GetWord(strContent)
		view.label =string.format(content, ...) 
		if view:IsOpen() then
			view:UpdateInfo()
		else
			view:OpenView()	
		end	
	end
end

----------小文本说明
--parama = {offsetLocalPosition , fitWidth , hideMask, isId} isId:strContent的内容是ID
--customPosTb = {clickGo , offsetPos} 
--clickGo:点击的GameObject,用其宽高做偏移
--offsetPos:根据正负围绕点击Go做上下左右偏移(若溢出屏幕则偏移无效),例：{0,0.5}显示在点击位置上方并且向上偏移(ClickGo高度)/2+0.5
function GameLogicTools.ShowLabelTipsParama(strContent, position, localPosition, parama, ...)
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.LabelTipsView)
	if view then
		local LanguageUtil = require "First.Util.LanguageUtil"
		view.goodsid = goodsid
		view.position = position
		view.localPosition = localPosition
		view.offsetLocalPosition = parama and parama.offsetLocalPosition
		view.fitWidth = parama and parama.fitWidth or false --只有一行时，是否适配宽度
		view.hideMask = parama and parama.hideMask or false
		view.customPosTb = parama and parama.customPosTb

		--view.label = strContent
		local content = LanguageUtil.GetWord(strContent)
		if parama and parama.isId then
			local tempContent = GameLogicTools.GetStrContentById(strContent)
			content = LanguageUtil.GetWord(tempContent)
		end
		view.label =string.format(content, ...) 
		if view:IsOpen() then
			view:UpdateInfo()
		else
			view:OpenView()	
		end	
	end
end

----------小文本说明
function GameLogicTools.ShowLabelTipsById(id, position, localPosition, offsetLocalPosition,parama, ...)
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.LabelTipsView)
	if view then
		local config = ConfigManager.GetConfig("data_tips").label_tips
		local strContent = ""
		if config[id] and config[id].strContent then
			strContent = config[id].strContent
		end
		local LanguageUtil = require "First.Util.LanguageUtil"
		view.goodsid = goodsid
		view.position = position
		view.localPosition = localPosition
		view.offsetLocalPosition = offsetLocalPosition
		view.fitWidth = false --只有一行时，是否适配宽度
		view.customPosTb = parama and parama.customPosTb
		local content=LanguageUtil.GetWord(strContent)
		view.label =string.format(content, ...)
		if view:IsOpen() then
			view:UpdateInfo()
		else
			view:OpenView()	
		end	
	end
end

function GameLogicTools.GetStrContentById(id)
	local config = ConfigManager.GetConfig("data_tips").label_tips
	local strContent = ""
	if config[id] and config[id].strContent then
		strContent = config[id].strContent
	end
	return strContent
end

--普通物品tips
function GameLogicTools.ShowItemTipsView(goodsId, count, param)
	local ItemTipsView = require "Modules.Common.Msg.ItemTipsView"
	ItemTipsView.ShowItemTipsView(goodsId, count, param)
end

--物品装备tips
function GameLogicTools.ShowItemEquipTipsView(goodsId,goodsEnhanceGrade, count)
	local ItemEquipTipsView = require "Modules.Common.Msg.ItemEquipTipsView"
	ItemEquipTipsView.ShowItemEquipTipsView(goodsId,goodsEnhanceGrade, count)
end

--物品大于601子类型的宝箱tips
function GameLogicTools.ShowItemBoxTipsView(goodsId, count)
	local ItemBoxTipsView = require "Modules.Common.Msg.ItemBoxTipsView"
	ItemBoxTipsView.ShowItemBoxTipsView(goodsId, count)
end

--资源货币tips
function GameLogicTools.ShowItemLableView(goodsId,localPosition, position)
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.ItemLableView)
	if view then
		view.goodsId = goodsId
		view.position = position
		view.localPosition = localPosition
		if view:IsOpen() then
			view:UpdateInfo()
		else
			view:OpenView()	
		end	
	end
end

--roleId:英雄配置id, rank：英雄品质, level：英雄等级, bshow_effect：是否显示闪光特效, bdelay_show:延迟显示 new_hero_flag:新英雄标签
function GameLogicTools.ShowHeroTipsView(roleId, rank, level, bshow_effect, bdelay_show, new_hero_flag, func)
	local HeroTipsView = require "Modules.Common.Msg.HeroTipsView"
	HeroTipsView.ShowHeroTipsView(roleId, rank, level, bshow_effect, bdelay_show, new_hero_flag, func)
end

function GameLogicTools.ShowNewHeroTipsViewByRole(roleinfolist)
	if #roleinfolist > 0 then
		local roleinfo = roleinfolist[1]
		table.remove(roleinfolist,1)
		GameLogicTools.ShowHeroTipsView(roleinfo[1],roleinfo[2], 1, true, true, true, function()
			if #roleinfolist > 0 then
				GameLogicTools.ShowNewHeroTipsViewByRole(roleinfolist)
			end
		end)
	else
		
	end
end
function GameLogicTools.ShouldShowNewHeroTipsView(goodslist)

	local BagProxy = require "Modules.Bag.BagProxy"
	local roleidlist = BagProxy.Instance:GetRoleIdByGoodsTypeId(goodslist)
	if #roleidlist > 0 then
		GameLogicTools.ShowNewHeroTipsViewByRole(roleidlist)
		return true
	end
	return false
end

function GameLogicTools.CheckShowNewHeroTipsView(goodsid)

	
	local HeroProxy = require "Modules.Hero.HeroProxy"
	if HeroProxy.Instance:IsHero(goodsid)  then
		local BagProxy = require "Modules.Bag.BagProxy"
		local HeroDef = require "Modules.Hero.HeroDef"
		local goodscfg = BagProxy.Instance:GetGoodsCfgById(goodsid)
		local roleid = goodscfg.value[1]
		local rank = goodscfg.value[2] >= HeroDef.Hero_Rank_Enum.purple and HeroDef.Hero_Rank_Enum.purple or goodscfg.value[2]
		if HeroProxy.Instance:IsNewHero(roleid) then
			GameLogicTools.ShowHeroTipsView(roleid, rank, 1, true, true, true, function()
				--英雄获得界面后 展示获得英雄通用奖励界面
				HeroProxy.Instance:UpdateRoleIdList(roleid)
			end)
			return true
		end
	end
	return false
end

-- type (1:通用奖励类型) itemList 的格式为 itemList = {{goodsid = xxx, goodsnum = xxx}, ...} ， func 按钮回调，
-- type (2:带标题奖励) itemList 的格式为 itemList = {{{goodsid = xxx, goodsnum = xxx},...}, ... }, func 按钮回调，titles={"111", "222"},btnInfos{goodsid,count,sp,desc}
-- type (3:显示英雄物品图标 ， 根据roleid 转换英雄物品id { {{ goodsid, goodsnum = xxx, roleid=xxx,rank =xx, level = xxx},{ goodsid, goodsnum = xxx}, { goodsid, goodsnum = xxx, equipInfos=},..}}) hero 及普通物品, 装备混合列表
-- type (4:通用奖励类型) itemList 的格式为 itemList = {{goodsid = xxx, goodsnum = xxx}, ...} ， func 按钮回调，不在主界面时，显示虚假背包按钮，关闭时奖励飞入背包按钮处
-- type (5:通用奖励类型) itemList 的格式为 itemList = {{goodsid = xxx, goodsnum = xxx}, ...} ， func 按钮回调，和 type1 一样 只是不显示奖励获得页面，直接飞入背包
function GameLogicTools.ShowGetItemView(itemList, type, func, titles, btnInfos, showshare, specialLogicType, specialLogicPara)
	if itemList == nil or nil == next(itemList) then
	else
		local GetItemView = require "Modules.Common.GetItem.GetItemView"
		GetItemView.Show(itemList, type, func, titles, btnInfos, showshare, specialLogicType, specialLogicPara)
	end
end

--itemList:和配置表的奖励格式一致,例如{{301002,2},{701001,20},}
function GameLogicTools.ShowGetItemView2(itemList, type, func, titles, btnInfos)
	local goods = {}
	for i=1,#itemList do
		local temp = {}
		temp.goodsid = itemList[i][1]
		temp.goodsnum = itemList[i][2]
		table.insert(goods, temp)
	end
	GameLogicTools.ShowGetItemView(goods, type, func, titles, btnInfos)
end

--战斗力文本
function GameLogicTools.GetNumStr(fight)
	local str = fight
	if fight > 99999999 then
		str = math.floor(fight / 1000000)..'M' 
	elseif fight >= 100000 then
		str = math.floor(fight / 1000)..'K'
	else
		str = math.floor(fight)	
	end	
	return str
end

--掉落显示
--金币获得
function GameLogicTools.ShowCoinDrop(from, goods_count)
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.ItemDropView)
	if view:IsOpen() then
		view:UpdateCoinInfo(1, from, 20, nil, goods_count)
	end	
end

--经验获得
function GameLogicTools.ShowExpDrop(from, goods_count)
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.ItemDropView)
	if view:IsOpen() then
		view:UpdateCoinInfo(0, from, 20, nil, goods_count)

		--金币音效
		local AudioManager = require "Common.Mgr.Audio.AudioManager"
		AudioManager.PlaySoundByKey("common_coin_get")
	end	
end

--钻石获得
function GameLogicTools.ShowGemDrop(from, goods_count)
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.ItemDropView)
	if view:IsOpen() then
		view:UpdateCoinInfo(2, from, 20, nil, goods_count)
	end	
end

--物品获得goodsDatalist:{{222333, 1}}
function GameLogicTools.ShowGoodsDrop(goodsDatalist, frompos, topos, func)
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.ItemDropView)
	if view:IsOpen() then
		view:UpdateGoodsInfo(goodsDatalist, frompos, topos, func)
	end	
end

--物品获得goodsDatalist:{{222333, 1}}
function GameLogicTools.ShowAwardGoodsDrop(datalist, frompos, topos, func, bNotChangeFromPos)
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.ItemDropView)
	if view:IsOpen() then
		view:UpdateAwardGoodsInfo(datalist, frompos, topos, func, bNotChangeFromPos)
	end	
end

function GameLogicTools.ShowItemQuickUse(goodsId, needcount)
	UIOperateManager.Instance:OpenWidget(AppFacade.Hero, 10, goodsId, needcount)
end

function GameLogicTools.GetPropertyByGoodsId(goodsid)
	if goodsid == 701001 then
		return RoleInfoModel.diamond
	elseif goodsid == 702001 then
		return RoleInfoModel.coin
	elseif goodsid == 703001 then
		return RoleInfoModel.player_exp
	elseif goodsid == 704001 then
		return RoleInfoModel.hero_exp
	elseif goodsid == 705001 then
		return RoleInfoModel.vip_exp
	elseif goodsid == 706001 then
		return RoleInfoModel.medals_valor
	elseif goodsid == 707001 then
		return RoleInfoModel.guild_coin
	elseif goodsid == 708001 then
		return RoleInfoModel.hero_coin
	elseif goodsid == 709001 then
		return RoleInfoModel.labyrinth_token
	elseif goodsid == 710001 then	
		return RoleInfoModel.challenger_coin
	elseif goodsid == 711001 then
		return RoleInfoModel.twisted_sigil
	elseif goodsid == 712001 then
		return RoleInfoModel.companion_points
	elseif goodsid == 713001 then
		return RoleInfoModel.heroic_merit
	elseif goodsid == 714001 then
		return RoleInfoModel.inv_essence
	elseif goodsid == 714001 then
		return RoleInfoModel.mobilize_point
	elseif goodsid == 715001 then
		return 0
	elseif goodsid == 716001 then
		return 0
	elseif goodsid == 717001 then	
		return 0
	elseif goodsid == 720001 then
		return RoleInfoModel.tree_exp
	else
		local BagProxy = require "Modules.Bag.BagProxy"
		local num = BagProxy.Instance:GetItemCountByID(goodsid)
		return num
	end	
end

function GameLogicTools.GetBlueCardByRace(race)
	if race == 1 then
		return 302001
	elseif race == 2 then
		return 302002
	elseif race == 3 then
		return 302003
	elseif race== 4 then
		return 302004
	end
end

--获取怪物阵营列表
function GameLogicTools.GetEnemyList(id)
	local config = ConfigManager.GetConfig("data_enemy")
	if config[id] then
		local cfg = config[id]
		local list = {}
		local boss = nil
		for i=1, 5 do
			local enemydata = cfg["enemy"..i]
			if enemydata and next(enemydata) then
				enemydata.stance = enemydata.stance or i				
				if cfg.boss.location == i then
					enemydata.boss = cfg.boss
					boss = enemydata
				else
					enemydata.boss = nil
				end	
				list[i] = enemydata
			else
				list[i] = {role = 0}
			end
		end	
		return list, boss
	else
		print("error: GetEnemyList is nil:", id)
	end	
end

--获取敌人配置
function GameLogicTools.GetEnemyCfg(enemyID)
	local config = ConfigManager.GetConfig("data_enemy")
	return config[enemyID]
end

--获取奖励列表
function GameLogicTools.GetReward(id)
	local list = {}
	local configs = ConfigManager.GetConfig("data_drop")
	for _, cfg in pairs(configs) do
		if cfg.bag_id == id then
			table.insert(list, {cfg.drop_id, cfg.num})
		end
	end
	table.sort(list, function (a,b)
		return a[1] < b[1]
	end)
	return list
end

--对文字长度进行计算 length：字符个数     maxWord:指定字符数量
function GameLogicTools.CheckContentLength(content, maxWord)
	local length = 0
    local lenInByte = #content
    local i = 1
    local wordStr = ""       --返回指定字符数量的字符串
    while (i<=lenInByte) 
    do
        local curByte = string.byte(content, i)
        local byteCount = 1;
        if curByte>0 and curByte<=127 then
            byteCount = 1                                              
        elseif curByte>=192 and curByte<223 then
            byteCount = 2                                              
        elseif curByte>=224 and curByte<239 then
            byteCount = 3                                            
        elseif curByte>=240 and curByte<=247 then
            byteCount = 4                                               
        end    
        local char = string.sub(content, i, i+byteCount-1)                                                         
        i = i + byteCount   
        if byteCount == 1 then   
        	length = length + 0.5  
       	else                                     
        	length = length + 1  
        end
        if maxWord then
	        if length <= maxWord then
				wordStr = wordStr .. char
	        end   
	    end                                     
    end
	return length, wordStr, i-1
end

--奖励数量合并，例如{{707001，10},{707001，20}} => {{707001，30}}
function GameLogicTools.HandleRewardMergeNum(rewards)
	-- print("HandleRewardMergeNum Before", table.dump(rewards))

	local temp = {} --key:奖励id value:奖励总数
	for i=1,#rewards do
		local reward = rewards[i]
		local rewardId = reward[1]
		local rewardNum = reward[2]
		if not temp[rewardId] then
			temp[rewardId] = rewardNum
		else
			temp[rewardId] = temp[rewardId] + rewardNum
		end
	end

	local result = {}
	for k,v in pairs(temp) do
		local t = {}
		t[1] = k
		t[2] = v
		table.insert(result, t)
	end
	
	-- print("HandleRewardMergeNum After", table.dump(result))

	return result
end

--奖励数量合并，例如{{["goodsid"]=707001，["goodsnum"]=10},{["goodsid"]=707001，["goodsnum"]=20}} => {{["goodsid"]=707001，["goodsnum"]=30}}
function GameLogicTools.HandleRewardMergeNum2(rewards)
	-- print("HandleRewardMergeNum2 Before", table.dump(rewards))

	local temp = {} --key:奖励id value:奖励总数
	for i=1,#rewards do
		local reward = rewards[i]
		local rewardId = reward.goodsid
		local rewardNum = reward.goodsnum
		if not temp[rewardId] then
			temp[rewardId] = rewardNum
		else
			temp[rewardId] = temp[rewardId] + rewardNum
		end
	end

	local result = {}
	for k,v in pairs(temp) do
		local t = {}
		t.goodsid = k
		t.goodsnum = v
		table.insert(result, t)
	end
	
	-- print("HandleRewardMergeNum2 After", table.dump(result))

	return result
end

--offsetHeith:输入框距离屏幕中点Y轴距离
function GameLogicTools.AdjustObjPosY(obj, originPos, offsetHeith, isFocused, bResetPox)
    if not obj then return end
    local isEditor = CS.UnityEngine.Application.isEditor
    if isEditor then return end

    local TouchScreenKeyboard = CS.UnityEngine.TouchScreenKeyboard
    local Application = CS.UnityEngine.Application
    local Screen = CS.UnityEngine.Screen
    local _pos = originPos
    if TouchScreenKeyboard.visible and isFocused then
        -- TouchScreenKeyboard.hideInput = true 
        local screenRect = UILayerTool.CurrentScreen()
        local MobileDevicesUtils = require "Modules.Sdk.MobileDevicesUtils"
        local keyboardHeight = MobileDevicesUtils.GetKeyboardHeight()
        local keyboardHeight2 = MobileDevicesUtils.GetKeyboardHeight2()
        local _system_height = MobileDevicesUtils.GetDisplaySystemHeight()
        local _height = screenRect.height * (keyboardHeight / Screen.height)
        local _height2 = screenRect.height * (keyboardHeight2 / Screen.height)

        local height1 = _height2
        -- local _pos = originPos
        if offsetHeith >= 0 then
            if height1 > (offsetHeith + screenRect.height/2) then
                height1 = height1 - (offsetHeith + screenRect.height/2)
                _pos = Vector3.New(0, originPos.y+height1, 0)
            end
        else
            if height1 > (screenRect.height/2- math.abs(offsetHeith)) then
                height1 = height1 - (screenRect.height/2 - math.abs(offsetHeith))
                _pos = Vector3.New(0, originPos.y+height1, 0)
            end
        end
        -- obj.transform.localPosition = _pos
        -- print("AdjustObjPosY====", isFocused, _height, _height2, _pos.y, keyboardHeight, keyboardHeight2, _system_height, height1, TouchScreenKeyboard.visible, screenRect.height, Screen.height, offsetHeith)
    else
        -- obj.transform.localPosition = originPos
    end

    if bResetPox then
    	obj.transform.localPosition = originPos
    else
    	obj.transform.localPosition = _pos
    end

    return _pos.y
end

--跳转到商城
function GameLogicTools.JumpToMall()
	--优先级:起航礼包>钻石礼包
	local MallDef = require "Modules.Mall.MallDef"
	local MallProxy = require "Modules.Mall.MallProxy"
	local canShowSail = MallProxy.Instance:CanShowSail()
	if canShowSail then
		UIOperateManager.Instance:OpenWidget(AppFacade.Mall, 1, MallDef.RootType.Limit, MallDef.LimitType.Sail)
	else
		UIOperateManager.Instance:OpenWidget(AppFacade.Mall, 1, MallDef.RootType.Normal, MallDef.NormalType.Gem)
	end
end

function GameLogicTools.JumpToMall2()
	--优先级:月礼包>钻石礼包
	local MallDef = require "Modules.Mall.MallDef"
	local MallProxy = require "Modules.Mall.MallProxy"
	local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
	local ModuleManager = require "Common.Mgr.UI.ModuleManager"
	local isOpen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.MallMonthly, false)
	if isOpen then
		UIOperateManager.Instance:OpenWidget(AppFacade.Mall, 1, MallDef.RootType.Normal, MallDef.NormalType.Monthly)
	else
		UIOperateManager.Instance:OpenWidget(AppFacade.Mall, 1, MallDef.RootType.Normal, MallDef.NormalType.Gem)
	end
end

--同JumpToMall , 区别是这是同界面跳转
function GameLogicTools.JumpToMall3()
	--优先级:起航礼包>钻石礼包
	local MallDef = require "Modules.Mall.MallDef"
	local MallProxy = require "Modules.Mall.MallProxy"
	local canShowSail = MallProxy.Instance:CanShowSail()
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MallRootView)
	if view:IsOpen() then
		local selectIndex1 , selectIndex2
		if canShowSail then
			selectIndex1 = MallDef.RootType.Limit
			selectIndex2 = MallDef.LimitType.Sail
		else
			selectIndex1 = MallDef.RootType.Limit
			selectIndex2 = MallDef.LimitType.Sail
		end
		view.selectIndex = selectIndex1
		view.selectIndex2 = selectIndex2
		view:UpdateToggleSelect()
	end
end

--输入:12345 输出:12,345
function GameLogicTools.NumToCommaFormat(num)
	local result = {}
	local str = ""
	local count

	while (num ~= 0) do
		local a = math.floor(num / 1000)
		local b = num % 1000
		table.insert(result, b)
		num = a
	end

	count = #result
	for i=1,count do
		local temp = result[i]
		temp = tostring(temp)

		--补0处理
		if i ~= count then
			for j=string.len(temp),2 do
				temp = "0" .. temp
			end
		end
		
		if i == count then
			str = temp .. str
		else
			str = "," .. temp .. str
		end
	end

	return str
end
	
function GameLogicTools.FormatPercent(percent, prefix)
	local pre = prefix and tostring(prefix) or ""
	return pre .. tostring(percent) .. "%"
end
	
function GameLogicTools.FormatAddPercent(percent)
	return GameLogicTools.FormatPercent(percent, "+")
end