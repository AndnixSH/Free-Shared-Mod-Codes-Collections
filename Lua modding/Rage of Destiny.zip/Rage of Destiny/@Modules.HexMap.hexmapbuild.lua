local HexMapUI = require "Modules.HexMap.HexMapUI"
local hexmaprender = require "Modules.HexMap.hexmaprender"
local hexmapcamera = require "Modules.HexMap.hexmapcamera"
local sequencer = require "Modules.HexMap.sequencer"
local tunpack = table.unpack
local hexmapbuild = {}

-- 格子状态
local CELL_STATUS =
{
    INIT = 0,
    OPEN = 1,
    DONE = 2,
}

local monster_type = {
    HEXMAP_BUILD.MONSTER,
    HEXMAP_BUILD.BUFF_MONSTER,
    HEXMAP_BUILD.CAMP_MONSTER,
    HEXMAP_BUILD.TRIBE_MONSTER
}

local show_tips = function(key)
    GameLogicTools.ShowMsgTips(key)
end

local show_view = function (viewlist, viewargs)
    if viewlist then
        for i, viewid in ipairs(viewlist) do
            hexmaprender.start_view(viewid, viewargs)
        end
    end
end

local show_reward_view = function (rewards, args)
    -- print("打开奖励", table.dump(rewards))
    if #rewards > 0 then
        local goodsInfos = {}
        for i,info in ipairs(rewards) do
            table.insert(goodsInfos, {goodsid = info[1], goodsnum = info[2]})
        end
        args = args or {}

        local show = function ()
            if args.build_type and args.build_type == HEXMAP_BUILD.COUNT_REWARD then
                --類型3不弹奖励面板
                local _fromPos = nil
                if args.position then
                    _fromPos = UILayerTool.WorldToScreenPoint(args.position)
                end
                GameLogicTools.ShowAwardGoodsDrop(rewards, _fromPos, nil, nil, true)
            else
                GameLogicTools.ShowGetItemView(goodsInfos, 4, function ()
                    if args.onclick then
                        args.onclick()
                    end
                    for i, value in ipairs(goodsInfos) do
                        if GameLogicTools.CheckShowNewHeroTipsView(value.goodsid) then
                            break
                        end
                    end
                end)
            end
        end

        if args.delay and args.delay > 0 then
            hexmaprender.delay(args.delay, show)
        else
            show()
        end
    end
end

local function packbuffer(fmt, ...)
    return { fmt = fmt, data = {...}}
end

local function packlist(fmt, list)
    local _fmt = "I2"
    local count = #list
    local data = {}
    table.insert(data, count)
    for i = 1, count do
        _fmt = _fmt .. fmt
        table.insert(data, list[i])
    end
    return { fmt = _fmt, data = data }
end

local basebuild = {}

function basebuild:new(o)
    o = o or {}
    setmetatable(o, {__index = self})
    return o
end

-- 初始化
function basebuild:init()
    if self.oninit then
        self:oninit()
    end
    self.hexmap:proxy_notify("OnBuildAppear", self)
end

function basebuild:refresh()
    if self.onrefresh then
        self:onrefresh()
    end
end

function basebuild:active()

    if self.onactive then
        self:onactive()
    end
end

function basebuild:reach()
    local curid = self.hexmap:getfollower()
    if curid and curid ~= self.cell.id then
        self.hexmap:moveto(self.cell, function ()
            if self.onreach then self:onreach() end
        end)
    else
        if self.onreach then self:onreach() end
    end
    
end

-- 检测是否可达到点击
function basebuild:check_reach()
    local curid = self.hexmap:getfollower()
    if curid and curid ~= self.cell.id  then
        return self.hexmap:get_path(self.cell) ~= nil
    end
    return true
end

-- 操作，点击格子
function basebuild:operate()
    if self.static.click_tips then
        show_tips(self.static.click_tips)
    end
    if self.onoperate then
        self:onoperate()
    end
    self.hexmap:proxy_notify("OnBuildClick", self.static.id)
end

function basebuild:open(step, decoder)
    if self.onopen then
        self:onopen(decoder, step)
    end
end

function basebuild:enter(from)
    if self.onenter then
        self:onenter(from)
    end
end

function basebuild:show_special_view(index, viewargs)
    if self.static.view_special and self.static.view_special[index] then
        show_view(self.static.view_special[index], viewargs)
    end
end

function basebuild:showinit()
    if self.static.view_init then
        show_view(self.static.view_init, {position=self.cell.top_position})
    end
end

function basebuild:showguide(callback)
    if self.static.guide then
		if self.prop.enter then
			return
		end
		self.prop.enter = true
        hexmaprender.start_view_args({ type=14, args = self.static.guide, cb = function()
					if callback then
						callback()
					end
				end,})
    end
end

function basebuild:showfailtips()
	if self.static.use_fail_tips then
		show_tips(self.static.use_fail_tips)
	end
end

-- 完成，格子的事件
function basebuild:done(bsucc, nextbuild, decoder)
    if bsucc then
        if self.ondone then self:ondone(decoder) end
        if self.static.use_success_tips then
            show_tips(self.static.use_success_tips)
        end
        if not self.oncheckguide or self:oncheckguide() then
            self:showguide()
        end
        if self.static.view_done and (self.type ~= HEXMAP_BUILD.CONDITION_OBSTACLE or nextbuild == 0)   then
            local active_name
            if self.type == HEXMAP_BUILD.CONDITION_OBSTACLE and nextbuild == 0 then
                active_name = "Death_Build"
            end
            show_view(self.static.view_done, { position = self.cell.top_position, at_cell = self.cell , active_name = active_name})
        end
    else
        if self.onfail then self:onfail(decoder) end
        self:showfailtips()
    end
    if self.ondonemsg then
        self:ondonemsg(bsucc, nextbuild)
    end
    if bsucc then
        self.hexmap:proxy_notify("OnBuildDisappear", self)
        if nextbuild ~= 0 then
            hexmapbuild.add_build(self.cell, nextbuild)
        else
            hexmapbuild._block_cell_list[self.cell] = nil

            self.hexmap:set_build(self.cell, nil)
            self.hexmap:update_cell(self.cell,{enable = true, fog = 0, walkable = true})
            self.hexmap:enableingrid(self.cell)

            self.hexmap:update_cell_status(self.cell.id, CELL_STATUS.DONE)
            hexmapbuild._notify_cell_done(self.cell.id)

        end
        hexmapbuild._refresh_block_cells()
    end
end

local default = basebuild:new{
    onoperate = function (self)
        self:reach()
    end,
    onreach = function (self)
        self.hexmap:done_cell(self.cell.id)
    end
}

local default_simple = basebuild:new{
    onoperate = function (self)
        self:openview()
    end,

    openview = function (self)
        local parama = {}
        local buildcfg = self.static
        if buildcfg then
            parama.buildType = buildcfg.type
            parama.title = buildcfg.name
            parama.content = buildcfg.info
            parama.icon = buildcfg.view_pic
            parama.btnInfos = buildcfg.button
        end
        parama.func = function(args)
            if self.onclick then
                self:onclick(args)
            end
        end
        parama.clickable = self:check_reach()
        HexMapUI.OpenWidget(UIWidgetNameDef.HexStrangeAltarView, parama)
    end,

    onclick = function (self, args)
        self:reach()
    end,

    onreach = function (self)
        self.hexmap:done_cell(self.cell.id)
    end
}

local default_single_btn = basebuild:new{
    onoperate = function (self)
        self:openview()
    end,

    openview = function (self, args)
        local parama = {}
        local buildcfg = self.static
		
        if buildcfg and buildcfg.button then

            if buildcfg then
                parama.buildType = buildcfg.type
                parama.title = buildcfg.name
                parama.content = buildcfg.info
                parama.icon = buildcfg.view_pic
                parama.btnInfos = buildcfg.button
            end
            if args then for k,v in pairs(args) do parama[k] = v end end
            parama.func = function()
                if self.onclick then
                    self:onclick()
                end
            end
            parama.clickable = self:check_reach()
            HexMapUI.OpenWidget(UIWidgetNameDef.HexBuildView, parama)
        end
    end,

    onclick = function (self)
        self:reach()
    end,
    
    onreach = function (self)
        self.hexmap:done_cell(self.cell.id)
    end
}

local default_empty = basebuild:new {

}

-- 怪物 1
local monster = basebuild:new {

    onoperate = function (self)
        -- if not GameConfig.HEXMAP.super then
        --     self.hexmap:open_cell(self.cell.id, 1)
        -- else
        --     self.hexmap:done_cell(self.cell.id, packbuffer("I2I2I2", 0, 0, 0))
        -- end
        self.hexmap:open_cell(self.cell.id, 1)
        -- self.hexmap:done_cell(self.cell.id, packbuffer("I2I2I2", 0, 0, 0))
    end,

    onreach = function (self)
        local BattleProxy = require "Modules.Battle.BattleProxy"
        BattleProxy.Instance:BattleReadySetStep(self.hexmap:getactivityid(), 1, 1)
        self.hexmap:open_cell(self.cell.id, 2)
    end,
    
    onopen = function (self, decoder, step)
        if step == 1 then
            local enemyinfos = self:_decode_enemyinfos(decoder)
            self:_show_monster_info({infos = enemyinfos})
        end
    end,

    _decode_enemyinfos = function (self, decoder)
        local enemyinfos = {}
        local count = decoder:Decode("I2")
        for i=1, count do
            local enemyinfo = {}
            enemyinfo.roleid = decoder:Decode("I4")
            enemyinfo.level = decoder:Decode("I2")
            enemyinfo.rank = decoder:Decode("I2")
            enemyinfo.curskin = decoder:Decode("I4")
            enemyinfo.stance = decoder:Decode("I2")
            enemyinfo.exclusive = decoder:Decode("I2")
            enemyinfo.equips = decoder:DecodeList("I4I1", true)
            enemyinfo.prop = decoder:DecodeList("I2I4", true)
            table.insert(enemyinfos, enemyinfo)
        end
        return enemyinfos
    end,

    _show_monster_info = function (self, args)
        
        local parama = {}
        parama.buildcfg = self.static
        local buildcfg = self.static
        if buildcfg then
            parama.buildType = buildcfg.type
            parama.title = buildcfg.name
            parama.content = buildcfg.info
        end
        args = args or {}
        for k, v in pairs(args) do
            parama[k] = v
        end
        parama.func = function()
            self:reach()
        end
        parama.clickable = self:check_reach()
        self:_onopenmonsterview(parama)
    end,

    _onopenmonsterview = function (self, parama)
        HexMapUI.OpenWidget(UIWidgetNameDef.EnemyInfoView, parama)
    end,

    ondone = function (self)
        hexmapbuild.ntf("ntf_monster_kill", self.cell.id)
    end,

    onfail = function (self)
        hexmapbuild.ntf("ntf_monster_kill_fail", self.cell.id)
    end
}

local monster_kill_check = basebuild:new{

    onoperate = function (self)
        self:reach()
    end,
}

-- 迷宫怪
local maze_monster = monster:new {

    oninit = function (self)
        if self.cell.fog ~= 1 then
            local disable_block = self.hexmap:getbuildshare("disable_block")
            if disable_block == 0 and not GameConfig.HEXMAP.super  then
                for dir = 1, 6 do
                    local found = self.hexmap:surroundcell_dir(self.cell, dir)
                    if found and found.build and found.build.static.immune_disable ~= 1 then
                        hexmapbuild._block_cell_list[found] = (hexmapbuild._block_cell_list[found] or 0) + 1
                    end
                end
                hexmapbuild._refresh_block_cells()
            end
        end
    end,

    onopen = function (self, decoder, step)
        if step == 1 then
            local enemyinfos = self:_decode_enemyinfos(decoder)
            local monster_reward_list = decoder:DecodeList("I4I4", true)
        
            self:_show_monster_info({infos = enemyinfos, monster_reward_list = monster_reward_list, reward_add_percent = self.hexmap:get_reward_add_percent()})
        end
    end,

    _onopenmonsterview = function (self, parama)
        HexMapUI.OpenWidget(UIWidgetNameDef.MazeEnemyInfoView, parama)
    end,


    ondone = function (self)
        hexmapbuild.ntf("ntf_monster_kill", self.cell.id)
        for dir = 1, 6 do
            local found = self.hexmap:surroundcell_dir(self.cell, dir)
            if found and hexmapbuild._block_cell_list[found] then
                hexmapbuild._block_cell_list[found] = hexmapbuild._block_cell_list[found] - 1
            end
        end
    end
}

-- 奖励 2
local reward = basebuild:new{
    onoperate = function (self)
        self:reach()
    end,
    onreach = function (self)
        self.hexmap:done_cell(self.cell.id)
    end,
    ondone = function (self, decoder)
        local rewards = decoder:DecodeList("I4I4", true)
        local delay = self.static.prefab_id == "baoxiang" and 1 or 0.4
        show_reward_view(rewards, { build_type = self.static.type, delay=delay })-- 开宝箱奖励
    end,
    onfail = function (self)
        show_tips("打开奖励失败"..self.id)
    end
}

local key_reward = reward:new {
    ondone = function (self, decoder)
        local curcellid = self.cell.id
        local onclick = function () hexmapbuild._hexmap:open_cell(curcellid, 1) end
        local rewards = decoder:DecodeList("I4I4", true)
        show_reward_view(rewards, { build_type = self.static.type, onclick=onclick, delay=1.8})-- 开通关宝箱奖励
    end,
    onfail = function (self)
    end
}

local maze_end_reward = key_reward:new {
}

local count_reward = reward:new {
    ondone = function (self, decoder)
        local rewards = decoder:DecodeList("I4I4", true)
        local rainbow_egg = decoder:Decode("I2")
        self.hexmap:setbuildshare("rainbow_egg_count", rainbow_egg)
        local MazeDef = require "Modules.Maze.MazeDef"
        self.hexmap:proxy_notify(MazeDef.NotifyDef.Update_Maze_Rainbow_Egg, {count = rainbow_egg})
        show_reward_view(rewards, { build_type = self.static.type, delay=0.4, position = self.cell.top_position })-- 开宝箱奖励
    end,
    onfail = function (self)
    end
}


-- 龙蛋 3
local egg = basebuild:new{

    onoperate = function (self)
        self:reach()
    end,

    onreach = function (self)
        self.hexmap:done_cell(self.cell.id)
    end,

}

-- 符文 4
local rune = basebuild:new {

    onoperate = function (self)
        self.hexmap:open_cell(self.cell.id, 1)
    end,

    onopen = function (self, decoder)
        
        local select_list = decoder:DecodeList("I4")
        -- print('select_list', table.dump(select_list))
        if select_list and #select_list > 0 then
            local parama={}
            parama.select_list=select_list
            parama.callback=function (index ,id)
                self.rune_select_index=index
                self.rune_select_id=id
                self:reach()
                LuaLayout.Instance:CloseWidget(UIWidgetNameDef.RuneChooseView)
            end
            parama.clickable = self:check_reach()
            HexMapUI.OpenWidget(UIWidgetNameDef.RuneChooseView,parama)
        end
    end,

    onreach = function (self)
        --local select_index = 1
        self.hexmap:done_cell(self.cell.id, packbuffer("I2", self.rune_select_index or 0))
       
    end,
    ondone = function (self)
        if self:check_reach() then
            local view =LuaLayout.Instance:GetWidget(UIWidgetNameDef.RuneChooseView)
            if view then
                local from = self.cell.top_position
                view:DoRuneAnimation(from,self.rune_select_index)
            end
        end
    end,

    onfail = function (self)
        
    end
}

-- 障碍 5
local obstacle = default_empty

-- 复活 51
local shop = basebuild:new{
    onoperate = function (self)
        local parama = {}
        parama.func = function()
            self:reach()
        end
        parama.show_indexs = self.cell.build.data
        parama.clickable = self:check_reach()
        HexMapUI.OpenWidget(UIWidgetNameDef.HexStoreView, parama)
    end,
    onreach = function (self)
        self.hexmap:done_cell(self.cell.id)
    end,
}

-- 回复 52
local recover = basebuild:new{
    onoperate = function (self)
        self:reach()
    end,
    onreach = function (self)
        self.hexmap:done_cell(self.cell.id)
    end,
    ondone = function (self)
        if self.hexmap:getactivityid() == ACTIVITYID.MAZE then
            self.hexmap:require_hero_list()
        end
    end
}

-- 回复-有UI
local recover2 = default_single_btn

-- 复活 53
local revive = default_single_btn:new {
    ondone = function (self)
        if self.hexmap:getactivityid() == ACTIVITYID.MAZE then
            self.hexmap:require_hero_list()
        end
    end
}

-- 马车 54  佣兵营地
local cart = basebuild:new{
    onoperate = function(self)
        self.hexmap:open_cell(self.cell.id, 1)
    end,

    onopen = function (self, decoder)
        local heroInfos = {}
        local hero_count = decoder:Decode("I2")
        for i=1, hero_count do
            local item = {}
            item.roleid = decoder:Decode("I4")
            item.level = decoder:Decode("I2")
            item.rank = decoder:Decode("I2")
            item.equips = decoder:DecodeList("I4I1", true)
            item.tree_info = decoder:DecodeList("I2")
            table.insert(heroInfos, item)
        end 
       -- print("heroInfos========", table.dump(heroInfos))
        -- local heroInfos = decoder:DecodeList("I4I2I2", true)
        local parama = {}
        local buildcfg = self.static
        if buildcfg then         
            parama.buildType = buildcfg.type
            parama.title = buildcfg.name
            parama.content = buildcfg.info
            parama.icon = buildcfg.view_pic
            parama.btnInfos = buildcfg.button
			parama.playType = 3
        end
        parama.heroInfos = heroInfos
        parama.func = function(selectIdx, fromPos)
            self.prop.selectIdx = selectIdx
            self:reach()
            if self:check_reach() then
                local from = fromPos
                local toPos = Vector3.New(-998.7, -0.9, 0)
                local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MazeView)
                if view and view:IsOpen() then
                    local btnListPos = view:GetItemBtnsPos()
                    if btnListPos[UIWidgetNameDef.HexHeroView] then
                        toPos = btnListPos[UIWidgetNameDef.HexHeroView]
                    end
                end

                local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.StoryLineView)
                if view and view:IsOpen() then
                    local btnListPos = view:GetItemBtnsPos()
                    if btnListPos[UIWidgetNameDef.HexHeroView] then
                        toPos = btnListPos[UIWidgetNameDef.HexHeroView]
                    end
                end

                local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.RealmView)
                if view and view:IsOpen() then
                    local btnListPos = view:GetItemBtnsPos()
                    if btnListPos[UIWidgetNameDef.HexHeroView] then
                        toPos = btnListPos[UIWidgetNameDef.HexHeroView]
                    end
                end

                local heroSelect = heroInfos[selectIdx]
                local parama = {}
                parama.fromPos, parama.toPos = fromPos, toPos
                parama.duration, parama.roleid, parama.level, parama.rank = 1, heroSelect.roleid, heroSelect.level, heroSelect.rank
                parama.scale = Vector3.New(1, 1, 1)
                parama.funcName = "FlyHireHero"
                parama.callback = function()
                end
                
                local HexMapFlyIconTitleView = require "Modules.HexMap.HexMapFlyIconTitleView"
                HexMapFlyIconTitleView.ShowView(parama)
            end
        end
        parama.clickable = self:check_reach()
        HexMapUI.OpenWidget(UIWidgetNameDef.HeroHireView, parama)
    end,

    onreach = function (self)
        self.hexmap:done_cell(self.cell.id, packbuffer("I2", self.prop.selectIdx))
    end,

}


-- 钥匙 55
local key = basebuild:new{
    onoperate = function (self)
        self:reach()
    end,

    onreach = function (self)
        -- self.hexmap:done_cell(self.cell.id)
    end,

    onreach = function (self)

        self.hexmap:done_cell(self.cell.id)

        local exit_cell_id = self.static.data[1]
        if not exit_cell_id then return end

        local exit_cell = self.hexmap:getcell(exit_cell_id)
        if not exit_cell then return end

        local from = self.cell.top_position
        local to = exit_cell.top_position
        hexmaprender.cellcmd(self.cell, "set_build_active", false)

        local parama = {}
        parama.fromPos, parama.toPos = from, to
        parama.duration, parama.iconName = 1, "yaoshi"
        parama.scale = Vector3.New(1.31, 1.31, 1)
        parama.funcName = "KeyFly"
        parama.callback = function ()
            self:show_special_view(1, { position = to })
        end

        local HexMapFlyIconTitleView = require "Modules.HexMap.HexMapFlyIconTitleView"
        HexMapFlyIconTitleView.ShowView(parama)

    end
}

-- 出口建筑提示
local exit_alert = { 1, 4, 8, 9, 10, 49, 50, 52, 59}

local function is_alert(type)
    for i, v in ipairs(exit_alert) do
        if v == type then
            return true
        end
    end
    return false
end

-- 出口 56
local exit = basebuild:new{

    onopen = function (self, decoder, step)
        if step == 1 then
            local level_list = decoder:DecodeList("I2")
            if #level_list == 1 then
                self:_select_level(1)
            elseif #level_list > 1 then
                -- 打开选择界面
                local parama = {}
                parama.title = ""
                local buildcfg = self.static
                if buildcfg then         
                    parama.title = buildcfg.name
                end
                parama.func = function(index)
                    self:_select_level(index)
                end
                HexMapUI.OpenWidget(UIWidgetNameDef.HexPortalView, parama)
            end
        elseif step == 2 then
            self:_jump_next()
            self.hexmap:next_level()
        end
    end,

    _select_level = function (self, index)

        local alert = false

        local MazeDef = require "Modules.Maze.MazeDef"
        local map_config = self.hexmap:getmapconfig()
        if map_config.type == MazeDef.LevelType.Easter then
            local data_maze_common = ConfigManager.GetConfig("data_maze_common")
            alert = self.hexmap:getbuildshare("rainbow_egg_count") < data_maze_common[1].rainbow_egg
        else
            local allcells = self.hexmap:getallcells()
            for i, cell in pairs(allcells) do
                if cell.build and is_alert(cell.build.type) then
                    alert = true
                    break
                end
            end
        end

        if alert then
            GameLogicTools.ShowConfirmById(31, function (ok)
                if ok then
                    hexmaprender.delay(0.25, function () self:_do_select_level(index) end)
                end
            end)
        else
            self:_do_select_level(index)
        end
    end,

    _do_select_level = function (self, index)
        self.hexmap:open_cell(self.cell.id, 2, packbuffer("I2", index))
    end,

    _jump_next = function (self)
    end,

    onoperate = function (self)
        self:reach()
    end,

    onreach = function (self)
        self.hexmap:open_cell(self.cell.id, 1)
    end,

}

-- 出口 特定战斗次数消失
local battle_count_exit = exit:new {
    oninit = function (self)
        local config = ConfigManager.GetConfig("data_maze_common")
        local battle_count = self.hexmap:getbuildshare("battle_count")
        if battle_count >= config[1].battle_num then
            self.hexmap:open_cell(self.cell.id, 3)
        end
    end,

    _jump_next = function (self)
        self.hexmap:open_cell(self.cell.id, 3)
    end,

    _select_level = function (self, index)
        self.hexmap:open_cell(self.cell.id, 2, packbuffer("I2", index))
    end,
}

--祭坛 57
local altar = basebuild:new{
    onoperate = function (self)
        self.hexmap:open_cell(self.cell.id, 1)
    end,

    onopen = function (self, decoder)
        local count = decoder:Decode("I2")
        local order = decoder:DecodeList("I2")
        self.prop.count = count
        local parama = {}
        parama.resultList = order
        local buildcfg = self.static
        if buildcfg then
            parama.buildType = HEXMAP_BUILD.ALTAR
            parama.title = buildcfg.name
            parama.content = buildcfg.info
            parama.contentArgs = {self.prop.count}
            parama.icon = buildcfg.view_pic
            parama.btnInfos = buildcfg.button
        end
        parama.func = function(order_list)
            self.prop.order_list = order_list
            self:reach()
        end
        parama.clickable = self:check_reach()
        HexMapUI.OpenWidget(UIWidgetNameDef.HexStrangeAltarView, parama)
        
    end,

    onreach = function (self)
        self.hexmap:done_cell(self.cell.id, packlist("I2", self.prop.order_list))
    end,

    ondone = function (self)
        for k, v in pairs(hexmapbuild._block_cell_list) do
            hexmapbuild._block_cell_list[k] = 0
        end
        hexmapbuild._refresh_block_cells()
        hexmapbuild._block_cell_list = {}
        local cells = self.hexmap:getallcells()
        for k, cell in pairs(cells) do
            self.hexmap:update_cell(cell, {fog = 0})
        end
        self.hexmap:setbuildshare("disable_block", 1)
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.HexStrangeAltarView)
    end,

    onfail = function (self)
        self.prop.count = self.prop.count - 1
        if self.prop.count == 0 then
            LuaLayout.Instance:CloseWidget(UIWidgetNameDef.HexStrangeAltarView)
            self.hexmap:set_build(self.cell, nil)
        else
            local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.HexStrangeAltarView)
            if view and view:IsOpen() then
                view:ReSetResultInfo()
                view:ReSetContent({self.prop.count})
            end
        end
    end
}

--攻击 58
local attack = default_single_btn:new {

    onoperate = function (self)
        local trigger = self.static.data[1]
        if trigger == 1 then -- 主动触发
            self.hexmap:open_cell(self.cell.id, 2)
        end
    end,

    onreach = function (self)
        local trigger = self.static.data[1]
        if trigger == 1 then -- 主动触发
            self.hexmap:open_cell(self.cell.id, 1)
        end
    end,

    _fire_bullet = function (self, fromcell, targetcell)
        local bulletviewid = nil
        local view_special = self.static.view_special
        if view_special and #view_special > 0 then
            bulletviewid = view_special[1][1]
        end
        if bulletviewid then
            hexmaprender.cellcmd(self.cell, "start_build_active", "attack")
            hexmaprender.start_view(bulletviewid,{ fromcell = fromcell or self.cell, tocell = targetcell, cb = function ()
                self.hexmap:done_cell(self.cell.id)

                if targetcell.build and targetcell.build.static.type == HEXMAP_BUILD.ATTACK then
                    local trigger = targetcell.build.static.data[1]
                    if trigger ~= 1 then
                        self.hexmap:open_cell(targetcell.id, 1)
                    end
                end
            end})
        end
    end,

    _not_target = function (self)
        show_tips("Msgtips_hexmap_1019")
    end,
    
    onopen = function (self, decoder, step)

        if step == 2 then
            local count = decoder:Decode("I2")
            self:openview({contentArgs={count}})
            return
        end

        local hits = decoder:DecodeList("I2")
        if #hits == 0 then 
            self:_not_target()
            return
        end

        local trigger, range_cast, count = tunpack(self.static.data)
        
        local range = range_cast[1]
        local type = range[1]

        if type == 1 or type == 4 or type == 5 or type == 6 then
            local hitid = hits[1]
            local targetcell = self.hexmap:getcell(hitid)
            if hitid ~= 0 and targetcell then
                if type == 5 then
                    local frombuildid = range[2]
                    local fromcell = self.hexmap:searchcell(function (found) return found.build and found.build.id == frombuildid end)
                    hexmaprender.start_view(99996, { fromcell = self.cell, tocell = fromcell, cb = function ()
                        self:_fire_bullet(fromcell, targetcell)
                    end})
                else
                    self:_fire_bullet(self.cell, targetcell)
                end
            end
        elseif type == 2 then
            -- 喔哦，暂时无表现
        elseif type == 3 then
            local x, y = self.hexmap:idtoxy(self.cell.id)
            local mapinfo = self.hexmap:getmapinfo()
            local mid = math.floor(mapinfo.width / 2)
            local centerid = self.hexmap:xytoid(mid, y)
            local centercell = self.hexmap:getcell(centerid)
            self.hexmap:done_cell(self.cell.id)
            self:show_special_view(1, { position = centercell.top_position })
        end
    end,

    _show_rewards = function (self, decoder)
        local trigger = self.static.data[1]
        if trigger == 1 then
            local rewards = decoder:DecodeList("I4I4", true)
            local onclick = function () self.hexmap:proxy_notify("OnRewardClosed", self) end
            show_reward_view(rewards, {build_type = self.static.type, delay=0.8,onclick=onclick})-- 炎魔之塔攻击怪物奖励
        end
    end,

    onfail = function (self, decoder)
        self:_show_rewards(decoder)
    end,


    ondone = function (self, decoder)
        self:_show_rewards(decoder)
    end,
}

local attack2 = attack:new {
    _not_target = function (self)
        self.hexmap:done_cell(self.cell.id)
    end,
    _show_rewards = function (self, decoder)
        local rewards = decoder:DecodeList("I4I4", true)
        local onclick = function () self.hexmap:proxy_notify("OnRewardClosed", self) end
        show_reward_view(rewards, {build_type = self.static.type, delay=2.0,onclick=onclick})-- 巨龙号角攻击怪物奖励
    end,
    -- onoperate = function (self)
    -- end,
    -- onreach = function (self)
    -- end,
}

local turret = default_empty

--探险者遗骸 59
local remain = default_single_btn:new{
    
    ondone = function(self, decoder)
        local select_type = decoder:Decode("I1")
        if select_type == 1 then
            local hasreward = decoder:Decode("I1")
            if hasreward == 0 then
                local rewards = decoder:DecodeList("I4I4", true)
                show_reward_view(rewards, {build_type = self.static.type})
            else
                show_tips("打开奖励失败"..self.id)
            end
        end
    end
}

--祝福图腾 60
local bless = basebuild:new{  
    onoperate = function (self)
        self:openview()
    end,

    openview = function (self)
        local parama = {}
        local buildcfg = self.static
        if buildcfg then         
            parama.buildType = buildcfg.type
            parama.title = buildcfg.name
            parama.content = buildcfg.info or ""
            parama.icon = buildcfg.view_pic
            parama.btnInfos = buildcfg.button
			parama.playType = 1
        end
        parama.func = function(blessIdx, pos)
            if self.onclick then
                self:onclick(blessIdx, pos)
            end
        end
        parama.clickable = self:check_reach()
        HexMapUI.OpenWidget(UIWidgetNameDef.HeroHireView, parama)

    end,

    onclick = function (self, blessIdx, pos)
        self.blessIdx = blessIdx
        self.fromPos = pos
        self:reach()
    end,


    onreach = function (self)
        self.hexmap:done_cell(self.cell.id, packbuffer("I2", self.blessIdx))
    end,  

    ondone = function (self)
        if self:check_reach() then
            local fromPos = self.fromPos
            local toPos = Vector3.New(-998.7, -0.9, 0)
            local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MazeView)
            if view and view:IsOpen() then
                local btnListPos = view:GetItemBtnsPos()
                if btnListPos[UIWidgetNameDef.RuneListView] then
                    toPos = btnListPos[UIWidgetNameDef.RuneListView]
                end
            end

            view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.StoryLineView)
            if view and view:IsOpen() then
                local btnListPos = view:GetItemBtnsPos()
                if btnListPos[UIWidgetNameDef.RuneListView] then
                    toPos = btnListPos[UIWidgetNameDef.RuneListView]
                end
            end

            view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.RealmView)
            if view and view:IsOpen() then
                local btnListPos = view:GetItemBtnsPos()
                if btnListPos[UIWidgetNameDef.RuneListView] then
                    toPos = btnListPos[UIWidgetNameDef.RuneListView]
                end
            end

            local parama = {}
            parama.fromPos, parama.toPos = fromPos, toPos
            parama.duration, parama.iconName = 1, "zhenying" .. self.blessIdx
            parama.scale = Vector3.New(1, 1, 1)
            parama.funcName = "NormalFly"
            parama.callback = function()
            end
            local HexMapFlyIconTitleView = require "Modules.HexMap.HexMapFlyIconTitleView"
            HexMapFlyIconTitleView.ShowView(parama)
        end

    end
}

local bless2 = basebuild:new{  
    onoperate = function (self)
        self.hexmap:open_cell(self.cell.id, 1)
    end,

    onopen = function (self, decoder, step)
        self.selectidx = decoder:Decode("I1")

        local parama = {}
        local buildcfg = self.static
        if buildcfg then         
            parama.buildType = buildcfg.type
            parama.title = buildcfg.name
            parama.content = buildcfg.info or ""
            parama.icon = buildcfg.view_pic
            parama.btnInfos = buildcfg.button
            parama.selectidx = self.selectidx
			parama.playType = 1
        end
        parama.func = function(blessIdx, pos)
            if self.onclick then
                self:onclick(self.selectidx, pos)
            end
        end
        parama.clickable = self:check_reach()
        HexMapUI.OpenWidget(UIWidgetNameDef.HeroHireView, parama)

    end,

    onclick = bless.onclick,
    onreach = bless.onreach,
    -- ondone = bless.ondone,
    ondone = function (self)
        bless.ondone(self)
        local pos = nil
        local followrid = self.hexmap:getfollower()
        if followrid then
            pos = self.hexmap:getcell(followrid).top_position
        end
        self:show_special_view(self.selectidx, { position = pos or self.cell.top_position })
    end

}

--障碍 62
local barrier = default_single_btn:new {
    onreach = function (self)
    end
}
--引导 63
local guide = basebuild:new {

    onoperate = function (self)
        self:reach()
    end,

	onopen = function(self)
		self:showguide(function ()
			self:do_finish()
		end)
	end,
	
    onenter = function (self)
		if self:_check_is_finish_guide_done_cell() then
			self.hexmap:open_cell(self.cell.id, 1)
		else
	        self:do_finish()
		end
    end,
	
    ondone = function (self)
    end,
	do_finish = function(self)
		self.hexmap:done_cell(self.cell.id)
	end,
	
	_check_is_finish_guide_done_cell = function(self)
		local data = self.static.data
		if data and data[1] and (type(data[1]) == "table") then
			return true
		end
		return false
	end
}

-- 机关 1. 主动 2. 自动
local gear = default_single_btn:new {

    oninit = function (self)
        if self.static.data then
            self.prop.trigger_type = self.static.data[3] or 1
            if self.prop.trigger_type == 2 then
                self.hexmap:open_cell(self.cell.id, 2)
            else
                self.hexmap:open_cell(self.cell.id, 1)
            end
        end
    end,

    onrefresh = function (self)
        self:init()
    end,

    onoperate = function (self)
        if self.prop.trigger_type == 1 then
            self:openview()
        else
            self:reach()
        end
    end,

    onreach = function (self)
        if self.prop.trigger_type == 1 then
            self.hexmap:open_cell(self.cell.id, 2)
        end
    end,

    onopen = function (self, decoder, step)
        local btrigger = decoder:Decode("I2")
        local targetcell = nil
        if btrigger == 1 and self.static.data then
            self.prop.btrigger = true
            local open_list, model = tunpack(self.static.data)
            for i, cellid in ipairs(open_list) do
                local cell = self.hexmap:getcell(cellid)
                targetcell = cell
                self.hexmap:set_build(cell, nil)
                self.hexmap:update_cell(cell,{enable = true, fog = 0, walkable = true, prefab_id = model})
                self.hexmap:enableingrid(cell)
                if step == 2 then
                    self:show_special_view(1, {position = cell.top_position})
                end
            end

            if self.static.create then
                hexmapbuild.add_build(self.cell, self.static.create)
            end
        else
            local open_list = tunpack(self.static.data)
            for i, cellid in ipairs(open_list) do
                local cell = self.hexmap:getcell(cellid)
                if cell then
                    hexmaprender.cellcmd(cell, "set_alpha", 0.25)
                    -- hexmaprender.cellcmd(cell, "flash", 0.6, 0.4, 0.8)
                end
            end
        end
        if step == 2 and targetcell then
            self:showguide()

            if self.static.create then
                hexmapbuild.add_build(self.cell, self.static.create)
            end

        end

        
    end,
}

-- 传送
local transfer = default_single_btn:new {

    onreach = function (self)
        local tocellid = tunpack(self.static.data)
		if tocellid  then
	        local tocell = self.hexmap:getcell(tocellid)
	        self.hexmap:blinkto(tocell)
	        self.hexmap:open_cell(self.cell.id, 1)
	        self:show_special_view(1, { position = self.cell.top_position })
	        self:show_special_view(1, { position = tocell.top_position })
		end
    end,
}

--传送:data数据(单独传送到的格子,{特殊传送门顺序列表(build_id)}, 特殊传送到的格子)
--local transfer2 = basebuild:new {

    --onoperate = function (self)
        --self:reach()
    --end,

    --onenter = function (self, from)
		--local special_order_transfer = self:_check_special_order_transfer()
		--local data_index = special_order_transfer and 3 or 1
        --local tocellid = self.static.data[data_index]
        --if tocellid and from and from ~= tocellid and not self.hexmap:getfollowing() then
            --local tocell = self.hexmap:getcell(tocellid)
            --self.hexmap:blinkto(tocell)
            --self.hexmap:open_cell(self.cell.id, 1)
            --self:show_special_view(1, { position = self.cell.top_position })
            --self:show_special_view(1, { position = tocell.top_position })
			
			--self.prop.transfer_order_list = {}
			--hexmapbuild.ntf("ntf_transfer", self, self.cell.id, tocellid)
        --end
    --end,
		
	--_check_special_order_transfer = function(self)
		--self.prop.transfer_order_list = self.prop.transfer_order_list or {}
		--local order_cfg_list = self.static.data[2] or {}
		--if next(order_cfg_list) then
			--for i,cfg_build_id in ipairs(order_cfg_list) do
				--if (not self.prop.transfer_order_list[i]) or (self.prop.transfer_order_list[i] ~= cfg_build_id) then
					--return false
				--end
			--end
			--return true
		--end
		--return false
	--end,
	
	--ntf_transfer = function(self, transfer_build, from_cell_id, to_cell_id)
		--if transfer_build then
			--self.prop.transfer_order_list = self.prop.transfer_order_list or {}
			--local order_cfg_list = self.static.data[2] or {}
			--local index = table.indexof(order_cfg_list, transfer_build.id)
			--if index and (#self.prop.transfer_order_list == (index - 1)) then
				--table.insert(self.prop.transfer_order_list, transfer_build.id)
			--else
				--self.prop.transfer_order_list = {}
			--end
		--end
	--end
--}

--data数据(单独传送到的格子,{特殊传送格子和次数列表}, 特殊传送到的格子)
local transfer2 = basebuild:new {
	oninit = function(self)
		if self.cell.id == self.hexmap:getfollower() then
			self:onenter(self.cell.id)
		end
	end,
	
	onoperate = function (self)
		self:reach()
	end,
	
	onenter = function (self, from)
		self.prop.enter_from = from
		self.hexmap:open_cell(self.cell.id, 1)
	end,
	
	onopen = function(self, decoder)
		local tocellid = decoder:Decode("I2")
		local from = self.prop.enter_from
		local tocell = self.hexmap:getcell(tocellid)
		if tocellid and tocell and from and (from ~= tocellid) and (not self.hexmap:getfollowing()) then
			self.hexmap:blinkto(tocell)
			
			self:show_special_view(1, { position = self.cell.top_position })
			self:show_special_view(1, { position = tocell.top_position })
		end
	end
}

-- 滑轨
local rail = default_single_btn:new {

    onreach = function (self)
        self.hexmap:open_cell(self.cell.id, 1)
    end,

    onopen = function (self, decoder)
        
        local move_result_list = decoder:DecodeList("I2I2", true)

		for i,v in pairs(move_result_list) do
			
			local objcellid, targetcellid = table.unpack(v)
			-- print("objcellid", objcellid, "targetcellid", targetcellid)
			
	        if objcellid ~= 0 and targetcellid ~= 0 then
	            local objcell = self.hexmap:getcell(objcellid)
	            local targetcell = self.hexmap:getcell(targetcellid)
	
	            if objcell and targetcell then
	
	                local objbuild = objcell.build
	                local cam_position = (objcell.top_position + targetcell.top_position) / 2
	                local build_header = objcell.static.build_header or objbuild.static.header
	
	                sequencer.start({ render_args = {type = 13, speed = 4, position = cam_position} },
	                                { render_args = {type = 20, prefab_id = objbuild.static.prefab_id, fromcell = objcell, tocell = targetcell, header = build_header },
	                                  onstart = function ()
	                                      self.hexmap:set_build(objcell, nil)
										  self.hexmap:enableingrid(objcell)
	                                  end,
	                                  onend = function ()
										  hexmapbuild.add_build(targetcell, objbuild.id)
	                                      --local newbuild = hexmapbuild.create_build(targetcell, objbuild.id)
	                                      --self.hexmap:set_build(targetcell, newbuild)
	                                  end,
	                                  delay = 0.2})
	            end
	        else
	            self:show_special_view(1)
	        end
		end
    end
}

local monster_record = basebuild:new {

    active_cell = nil,

    onoperate = function (self)
        self:reach()
    end,

    oninit = function (self)
        self.hexmap:open_cell(self.cell.id, 1) -- 请求添加记录
    end,

    onopen = function (self, decoder, step)
        local left, completecell, activecell = decoder:Decode("I2I2I2")
        active_cell = activecell
        -- print('checksucc', left, completecell, activecell, self.static.data[2])
        if completecell == self.static.data[2] then
            if step == 1 then
                if left == 0 then
                    local cell = self.hexmap:getcell(completecell)
                    if cell and cell.build then
                        self.hexmap:set_build(cell, nil)
                        self:show_special_view(2)
                    end
                elseif left > 0 then
                    self:show_special_view(1, { wordargs = {left} })
                end
            end

            if left > 0 then
                local prefab_id = "Scenes_24004_num"..left
                hexmaprender.cmdfollower("add_title", prefab_id)
            else
                hexmaprender.cmdfollower("remove_title")
            end
        end
    end,

    onenter = function (self)
        self.hexmap:open_cell(self.cell.id, 2) -- 请求添加记录
        self:show_special_view(3)
    end,

    _oncheck = function (self, cellid)
        if active_cell == self.cell.id and self.hexmap:getlastbattle() == cellid then
            self.hexmap:open_cell(self.cell.id, 1) -- 检查是否有记录
        end
    end,

    ntf_monster_kill = function (self, cellid)
        self:_oncheck(cellid)
    end,

    ntf_monster_kill_fail = function (self, cellid)
        self:_oncheck(cellid)
    end,

    ntf_set_build = function (self, newbuild, oldbuild)
        if newbuild == nil and oldbuild.cell.id == self.static.data[2] then
            hexmaprender.cmdfollower("remove_title")
        end
    end
}

local monster_abuff = basebuild:new {

    onopen = function (self, decoder, step)
        local hasbuff = decoder:Decode("I1") == 1
        if hasbuff and step == 1 then
            local wordargs = {}
            for i, value in ipairs(self.static.data) do
                local prop, propchange = tunpack(value)
                table.insert(wordargs, math.abs(math.floor(propchange / 10)))
            end
            self:show_special_view(1, { wordargs = wordargs })
        end
    end,

    onenter = function (self)
        self.hexmap:open_cell(self.cell.id, 2) -- 请求添加buff
    end,

    ntf_monster_kill = function (self)
        self.hexmap:open_cell(self.cell.id, 1) -- 检查是否有buff
    end,

    onoperate = function (self)
        self:reach()
    end,
}

local monster_dbuff = default_single_btn:new {

    ondone = function (self)
        hexmaprender.delay(2, function () self:_ondbuff() end)
    end,

    _ondbuff = function (self)
        -- local map_config = self.hexmap:getmapconfig()
        -- hexmapcamera.attach_effect(map_config.camera_effect)
        hexmapcamera.detach_mask()
        hexmaprender.cmdfollower("remove_title")
        self.hexmap:setbuildshare("dark_mode", 0)
    end
}

local tips = default_single_btn:new {
	onoperate = function (self)
		self.hexmap:open_cell(self.cell.id, 1)
		self:openview()
	end,
    onreach = function (self)
    end,
	onopen = function(self, decoder, step)
	end
}

local tips2 = default_single_btn

local stair_gear = default_single_btn:new {

    oninit = function (self)
        self:_change_stairs(tunpack(self.static.data))
    end,

    _change_stairs = function (self, down_list, up_list)

        for i, cellid in ipairs(up_list) do
            local cell = self.hexmap:getcell(cellid)
            if cell then
                self.hexmap:set_step(cell, 2)
            end
        end

        for i, cellid in ipairs(down_list) do
            local cell = self.hexmap:getcell(cellid)
            if cell then
                self.hexmap:set_step(cell, 1)
            end
        end
    end

}

local fallen_start = basebuild:new{
    oninit = function (self)
        self.hexmap:open_cell(self.cell.id, 1)
    end,

    onoperate = function (self)
        self:reach()
    end,

    onopen = function (self, decoder)
        local opencnt = decoder:Decode("I2")
        if opencnt == 1 then
            local viewid, cell_list = tunpack(self.static.data)
            hexmaprender.start_view(viewid, { cb = function () self:_start_fall(cell_list) end })
        end
    end,

    _start_fall = function (self, cell_list)
        
        for i, value in ipairs(cell_list) do

            local cellid, camera_time, fall_time = tunpack(value)
            local curcell = self.hexmap:getcell(cellid)

            hexmaprender.start_view_args({type = 13, delay = camera_time, duration = 2, position = curcell.position, cb = nil})

            if fall_time and fall_time > 0 then
                hexmaprender.delay(fall_time, function ()
                    hexmaprender.cellcmd(curcell, "fallen")
                    self.hexmap:remove_cell(cellid)
                end)
            end
        end

    end
}

local refresher = basebuild:new {
    oninit = function (self)
        local list, viewid = tunpack(self.static.data)
        hexmaprender.start_view(viewid, { cb = function () self:_refresh(list) end })
    end,

    _refresh = function (self, list)
        for _, value in ipairs(list) do
            local cellid, buildid, delay = tunpack(value)
            local cell = self.hexmap:getcell(cellid)
            if cell then
                hexmaprender.delay(delay, function () 
                    hexmapbuild.add_build(cell, buildid) 
                    if table.contains(monster_type, cell.build.static.type) then
                        self:show_special_view(1, {position=cell.top_position})
                    end
                end)
            end
        end
    end
}

local tribe = default_single_btn:new {
    oninit = function (self)
        local blockcell, monster_list, unkill, kill = tunpack(self.static.data)
        local allkill = true

        self.prop.blockcell = self.hexmap:getcell(blockcell)
        self.prop.kill_cnt = 0
        self.prop.max_kill_cnt = #monster_list
        self.prop.unkill_view = unkill
        self.prop.kill_view = kill
        self.prop.monster_record = {}

        for _, cellid in ipairs(monster_list) do
            self.prop.monster_record[cellid] = true
            local monster_cell = self.hexmap:getcell(cellid)
            if monster_cell then
                if not monster_cell.build or monster_cell.build.type ~= HEXMAP_BUILD.TRIBE_MONSTER then
                    self.prop.kill_cnt = self.prop.kill_cnt + 1
                else
                    monster_cell.build:set_tribe(self)
                end
            end
        end

        self:_check_all_kill_monster()

    end,

    onrefresh = function(self)
        self:_check_all_kill_monster()
    end,

    onreach = function (self)
        local allkill = self.prop.kill_cnt >= self.prop.max_kill_cnt
        local click_view = allkill and self.prop.kill_view or self.prop.unkill_view
        local cb = allkill and function() self:_kill() end or nil
        
        hexmaprender.start_view(click_view, {cb = cb})
    end,

    _kill = function (self)
        self:_check_all_kill_monster()
    end,

    ntf_monster_kill = function (self, cellid)
        if self.prop.monster_record[cellid] then
            self.prop.kill_cnt = self.prop.kill_cnt + 1
        end
    end,

    _check_all_kill_monster = function (self)
        local allkill = self.prop.kill_cnt >= self.prop.max_kill_cnt
        if self.prop.blockcell then
            if allkill then
                self:show_special_view(1, {position = self.prop.blockcell.top_position})
                self.hexmap:enableingrid(self.prop.blockcell)
                self.hexmap:set_build(self.prop.blockcell, nil)
            else
                self:show_special_view(2, {position = self.cell.top_position})
                self.hexmap:disableingrid(self.prop.blockcell)
            end
        end
    end,

    get_kill_cnt = function (self)
        return self.prop.kill_cnt
    end
}

-- 伏兵怪
local tribe_monster = monster:new {
    oncheckguide = function (self)
        return self.prop.tribe:get_kill_cnt() == 1
    end,
    
    set_tribe= function (self, tribe)
        self.prop.tribe = tribe
    end
}

-- BUFF怪
local buff_monster = monster:new {
    _onopenmonsterview = function (self, parama)
        HexMapUI.OpenWidget(UIWidgetNameDef.EnemyBuffView, parama)
    end,
}

-- 阵营怪
local camp_monster = monster:new {
    ondonemsg = function (self, bsucc, nextbuild)
        if bsucc then
            self:show_special_view((nextbuild ~= 0) and 1 or 2)
        end
    end,
}

local monster_born_buff = basebuild:new {
    oninit = function (self)
        self.hexmap:open_cell(self.cell.id, 1)
    end,

    onrefresh = function (self)
        self:init()
    end,

    onopen = function (self)
        local allcells = self.hexmap:getallcells()
        for i, cell in pairs(allcells) do
            self:_show_buff_effect(cell.build, 1)
        end
    end,

    _is_monster = function (self, newbuild)
        return newbuild and table.contains(monster_type, newbuild.static.type)
    end,

    _show_buff_effect = function (self, newbuild, index)
        if self:_is_monster(newbuild) then
            local rotation = hexmaprender.cellcmd(newbuild.cell, "get_build_rotation")
            newbuild:show_special_view(index, { position = newbuild.cell.top_position, rotation = rotation })
        end
    end,

    ntf_set_build = function (self, newbuild)
        self:_show_buff_effect(newbuild, 1)
    end
}

local fallen_cell = basebuild:new {
    oninit = function (self)
        self.prop.fallen_list, self.prop.delay = tunpack(self.static.data)
        self.hexmap:open_cell(self.cell.id, 1)
    end,

    onoperate = function (self)
        self:reach()
    end,

    onopen = function (self, decoder)
        local curidx = decoder:Decode("I2")
        self.prop.curidx = curidx
    end,

    ntf_monster_kill = function (self)
        -- removecurrent
        self:_remove_cur_cell()
    end,

    _remove_cur_cell = function (self, delay)
        if self.prop.curidx then
            
            local curcell = nil

            while not curcell and self.prop.curidx <= #self.prop.fallen_list do
                curcell = self.hexmap:getcell(self.prop.fallen_list[self.prop.curidx])
                self.prop.curidx = self.prop.curidx + 1
            end

            if curcell then
                self.hexmap:remove_cell(curcell.id)
                hexmaprender.cellcmd(curcell, "fallen")
             end
        end
    end,
}

local bomb_cell = basebuild:new {
    
    ondone = function (self)
    end,

    _bomb = function (self, cbdone)

        local cell_list, delay = tunpack(self.static.data)
        show_view(self.static.view_done, { position = self.cell.top_position } )

        local seqitem = {}
        for i, cellid in ipairs(cell_list) do
            local cell = self.hexmap:getcell(cellid)
            if cell then
                self.hexmap:remove_cell(cellid)
                table.insert(seqitem, {duration = delay, onend = function () hexmaprender.cellcmd(cell, "fallen") end})
            end
        end

        sequencer.startlist(seqitem):setonend(cbdone)
    end,

    call_start_bomb = function (self, cbdone)

        local cell_list, delay = tunpack(self.static.data)
        local cell_cnt = 0
        local firstcell = nil
        for i, cellid in ipairs(cell_list) do
            local cell = self.hexmap:getcell(cellid)
            if cell then
                cell_cnt = cell_cnt + 1
                if not firstcell then
                    firstcell = cell
                end
            end
        end
        self.prop.cell_max = cell_cnt
        if self.prop.cell_max > 0 then
            hexmaprender.start_view_args({type = 13, duration = 2, position = firstcell.position, cb = function() self:_bomb(cbdone) end })
        else
            cbdone()
        end
        
    end
}

local bomb_platform = basebuild:new {
    ondone = function (self)
    end,
    
    _bomb = function (self, cbdone)
        show_view(self.static.view_done, { position = self.cell.top_position } )
        hexmapbuild.ntf("ntf_bomb_trigger", self.cell.id, cbdone)
        self.hexmap:set_build(self.cell, nil)
    end,

    call_start_bomb = function (self, cbdone)
        hexmaprender.start_view_args({type = 13, duration = 2, position = self.cell.position, cb = function()  self:_bomb(cbdone) end })
    end
}

local bomb_trigger = basebuild:new {
    onenter = function (self)
        if self.prop.enter then return end
        self.prop.enter = true
        self.hexmap:open_cell(self.cell.id, 1)
        -- self.hexmap:done_cell(self.cell.id)
        self:showguide()
        sequencer.start({from = 1, to = 0, duration = 0.5, onupdate = function(value) hexmaprender.cellcmd(self.cell, "set_build_alpha", value) end, 
                                                            onend = function() hexmaprender.cellcmd(self.cell,"set_build_active", false) end },
                        {delay = 0.5, duration = 0, onstart = function () self:_call_start_bomb(1) end})
    end,

    onrefresh = function (self)
        if self.prop.enter then
            hexmaprender.cellcmd(self.cell,"set_build_active", false)
        end
    end,

    _call_start_bomb = function (self, index)

        local cell_list = self.static.data[1]
        if index > #cell_list then
            hexmaprender.cmdfollower("focus", 1)
            return
        end
        local cell = self.hexmap:getcell(cell_list[index])
        if cell and cell.build then
            cell.build:call_start_bomb(function ()
                self:_call_start_bomb(index + 1)
            end)
        else
            self:_call_start_bomb(index + 1)
        end
    end,

    onoperate = function (self)
        self:reach()
    end,
}

local high_platform = basebuild:new {

    oninit = function (self)
        local platform_cells, bomb_cells = tunpack(self.static.data)
        self.prop.platform_cells = platform_cells
        self.prop.bomb_max = #bomb_cells
        self.prop.bomb_record = {}

        for i, cellid in ipairs(bomb_cells) do
            self.prop.bomb_record[cellid] = true
        end

        self.hexmap:open_cell(self.cell.id, 1)

    end,

    onrefresh = function (self)
        self:init()
    end,

    onopen = function (self, decoder)
        local bomb_trigger_cnt = decoder:Decode("I2")
        self.prop.bomb_trigger_cnt = bomb_trigger_cnt
        self:_lift_platform(bomb_trigger_cnt < self.prop.bomb_max)
    end,

    ntf_bomb_trigger = function (self, cellid, cbdone)
        if self.prop.bomb_record[cellid] then
            self.prop.bomb_trigger_cnt = self.prop.bomb_trigger_cnt + 1
            if self.prop.bomb_trigger_cnt >= self.prop.bomb_max then
                self:_lift_platform(false, cbdone)
                self.hexmap:done_cell(self.cell.id)
            else
                sequencer.start({duration = 1}):setonend(cbdone)
            end
        end

    end,

    _lift_platform = function (self, blift, cbdone)

        local itemlist = {}

        local platform_cells = self.prop.platform_cells
        for _, cellgroup in ipairs(platform_cells) do
            
            table.insert(itemlist, {duration = 0.5, onstart = function () 
                for _, cellid in ipairs(cellgroup) do
                    local cell = self.hexmap:getcell(cellid)
                    if cell then
                        local value = blift and 2 or 1
                        self.hexmap:set_step(cell, value) 
                    end
                end

            end})
        end

        sequencer.startlist(itemlist):setonend(cbdone)

    end,
}

local key_tips = basebuild:new {
    onoperate = function (self)
        self:reach()
    end,
    onreach = function (self)
        self.hexmap:done_cell(self.cell.id)
    end,
}

local door = basebuild:new {
	--data格式{{对应开关格子列表},{门关闭时的build, 门打开时的build},{门柱格子列表}}
	onoperate = function (self)
		if self:_check_open() then
			self:reach()
		end
	end,
	onopen = function(self, decoder, step)
		local result = decoder:Decode("I1")
		if result == 0 then
			if step == 1 then
				
				local cam_position = self.cell.top_position

				sequencer.start({ render_args = {type = 13, speed = 4, position = cam_position},
						onend = function ()
							self.hexmap:done_cell(self.cell.id, packbuffer("I1", step))
						end, })
			else
				self.hexmap:done_cell(self.cell.id, packbuffer("I1", step))
			end
		end
	end,
	_check_open = function(self)
		return self.id == self.static.data[2][2]
	end
}

local stockade = basebuild:new {
}

local ball_ejector = attack:new {
	--data格式{发射方向,{发射类型列表},次数}
	onoperate = function (self)
		self.hexmap:open_cell(self.cell.id, 3)
	end,

	onreach = function (self)
		self.hexmap:open_cell(self.cell.id, 2)
	end,
	
	onopen = function (self, decoder, step)
		if step == 3 then
			self:_open_view(decoder)
		elseif step == 2 then
			self:_do_ejector(decoder)
		end
	end,
	
	_open_view = function(self, decoder)
		local count = decoder:Decode("I2")
		self:openview({contentArgs={count}})
	end,
	
	onclick = function (self)
		local can_operate = self:_check_can_operate()
		if can_operate then
			self:reach()
		else
			self:showfailtips()
		end
	end,
	
	_do_ejector = function(self, decoder)
		local result = decoder:Decode("I1")
		if result == 0 then
			local can_operate, cell, dir = self:_check_can_operate()
			if can_operate then
				if self.static.type == HEXMAP_BUILD.BALL_EJECTOR then
					self:_show_special_view(
						function()
							hexmaprender.cellcmd(self.cell, "set_build_active", true)
							self.hexmap:open_cell(cell.id, 1, packbuffer("I2I2I1", self.static.type, self.cell.id, dir))
						end)
				else
					self.hexmap:open_cell(cell.id, 1, packbuffer("I2I2I1", self.static.type, self.cell.id, dir))
				end
			end
		end
	end,
	
	_check_can_operate = function(self)
		local dir = self.static.data[1]
		local cell = self.hexmap:surroundcell_dir(self.cell, dir)
		if cell and cell.build then
			local found = table.indexof(self.static.data[2], cell.build.static.type)
			if found then
				return true, cell, dir
			end
		end
	end,
	
	_show_special_view = function(self, callback)
		hexmaprender.cellcmd(self.cell, "set_build_active", false)
		
		local view_special = self.static.view_special
		local viewid =  (view_special and (#view_special > 0) and view_special[1][1])
		
		local rotation = hexmaprender.cellcmd(self.cell, "get_build_rotation")
		if viewid then
			hexmaprender.start_view(viewid, {rotation = rotation, position = self.cell.top_position, cb = callback})
		else
			if callback then
				callback()
			end
		end
	end
}

local ball_emitter = ball_ejector:new {
	--data格式{发射方向,{发射类型列表},次数,生成build}
	onopen = function (self, decoder, step)
		if step == 3 then
			self:_open_view(decoder)
		elseif step == 2 then
			self:_do_ejector(decoder)
		elseif step == 1 then
			self:_do_emitter(decoder)
		end
	end,
	
	onreach = function (self)
		self.hexmap:open_cell(self.cell.id, 1)
	end,
	
	_do_emitter = function(self, decoder)
		local result = decoder:Decode("I1")
		if result == 0 then
			local can_operate, cell, dir, buildid = self:_check_can_operate()
			if can_operate then
				self:_show_special_view(
					function()
						hexmaprender.cellcmd(self.cell, "set_build_active", true)
						
						self.hexmap:remove_build_by_id(buildid)
						hexmapbuild.add_build(cell, buildid)
						self.hexmap:open_cell(self.cell.id, 2)
					end)
			end
		end
	end,
	
	_check_can_operate = function(self)
		local dir = self.static.data[1]
		local cell = self.hexmap:surroundcell_dir(self.cell, self.static.data[1])
		if cell then
			local function _check_can_replace_build(old_build, create_build_id)
				local build = hexmapbuild.create_build(cell, create_build_id)
				if build then
					if build.static.type == HEXMAP_BUILD.BALL then
						if build and build._check_can_destroy then
							return build:_check_can_destroy(old_build.static.type)
						end
					end
				end
				return false
			end
			
			local buildid = self.static.data[4]
			local can_operate = (not cell.build) or (cell.build.id == buildid) or (_check_can_replace_build(cell.build, buildid))
			return can_operate, cell, dir, buildid
		end
	end
}

local ball = basebuild:new {
	--data格式{{可通过的类型列表(栅栏会摧毁)},{球自己会被摧毁的类型列表}}
	onopen = function(self, decoder)
		local result = decoder:Decode("I1")
		if result == 0 then
			local dir, destroy = decoder:Decode("I1I1")
			local be_destroy = (destroy == 1)
			local target_cells = decoder:DecodeList("I2")
			self:_on_move(target_cells, dir, be_destroy)
		end
	end,
	
	_on_move = function(self, target_cells, dir, be_destroy)
		hexmapbuild.move_build(self.hexmap, self.cell.id, target_cells, {dir}, be_destroy)
	end,
	
	_on_move_finish = function(self, last_cellid, dir)
		--检查同方向是否要传递力量
		if last_cellid == self.cell.id then
			local found = self.hexmap:surroundcell_dir(self.cell, dir)
			if found and found.build and (found.build.static.type == self.static.type) then
				self.hexmap:open_cell(found.id, 1, packbuffer("I2I2I1", self.static.type, self.cell.id, dir))
			end
		end
	end,
	_get_finish_move_view_id = function(hexmap, cell, build, target_cells, be_destroy)
		if be_destroy then
			if target_cells and (#target_cells > 0) then
				local last_cell_id = target_cells[#target_cells]
				local last_cell = hexmap:getcell(last_cell_id)
				if last_cell and last_cell.build then
					local build_type = last_cell.build.static.type
					local be_destroy_types = build and build.static.data[2] or {}
					local index = table.indexof(be_destroy_types, build_type)
					if index then
						local view_done = build and build.static.view_done or {}
						return view_done[index]
					end
				end
			end
		else
			local view_special = build and build.static.view_special or {}
			if view_special and #view_special > 0 then
				return view_special[1][2]
			end
		end
	end,
	_check_can_destroy = function(self, destroy_build_type)
		local destroy_build_types = self.static.data[1] or {}
		for i,type in ipairs(destroy_build_types) do
			if type == destroy_build_type then
				return true
			end
		end
		return false
	end,
}

local change_dir_rail_end = basebuild:new {
}

local door_post = basebuild:new {
}

local condition_obstacle = default_single_btn:new {

}

local weight_cell_obstacle = basebuild:new {
    oninit = function (self)
        self.hexmap:open_cell(self.cell.id, 3)
    end,

    onoperate = function (self)
        if self.prop.can_reach then
            self:reach()
        end
    end,

    onrefresh = function (self)
        self:init()
    end,

    onopen = function (self, decoder, step)
        
        local real_step = decoder:Decode("I1")

        if self.prop.view_uid then
            hexmaprender.stop_view(self.prop.view_uid)
            self.prop.view_uid = nil
        end

        if real_step == 2 then
            local special_view_id = self.static.view_special[1][2]
			if special_view_id then
				self.prop.view_uid = hexmaprender.start_view(special_view_id,{ position = self.cell.position })
			end
            self.prop.can_reach = false
            hexmaprender.cellcmd(self.cell, "set_weight", 0)
            if step ~= 3 then
                hexmaprender.cellcmd(self.cell, "start_cell_active", "LavaGround2")
            end
            self.hexmap:disableingrid(self.cell)
        elseif real_step == 1 then
            local special_view_id = self.static.view_special[1][1]
			if special_view_id then
            	self.prop.view_uid = hexmaprender.start_view(special_view_id, { position = self.cell.position })
			end
            self.prop.can_reach = true
            hexmaprender.cellcmd(self.cell, "set_weight", 1)
            if step ~= 3 then
                hexmaprender.cellcmd(self.cell, "start_cell_active", "LavaGround1")
            end
            self.hexmap:enableingrid(self.cell)
        end
    end,
}

--激光发射器:data数据(发射器类型(1是主动发射器，异色光照射后停止，0是被动发射器，2是激光转换器),颜色类型(冰是1、火是2),{发射方向列表})
local laser_generator = default_single_btn:new {
	--oninit = function (self)
		--self.prop.laser_active = (self.static.data[1] == 1)
	--end,

    onclick = function (self)
    end,

    is_need_laser_active = function (self)
        return self.static.data[1] == 0 or self.static.data[1] == 2
    end,
	
	is_laser_active = function(self)
		return self.prop.laser_active
	end,

    get_laser_color_type = function (self)
        return self.prop.laser_color_type
    end,

    set_laser_color_type = function (self,laser_color_type)
        if self.static.data[1] == 0 or self.static.data[1] == 2 then
            self.prop.laser_color_type = laser_color_type
        end
    end,

    _get_laser_dirs = function (self)
        return self.prop.laser_dirs or self.static.data[3]
    end,

    set_laser_dirs = function (self,dirs)
        self.prop.laser_dirs = dirs
    end,
	
	_change_laser_active = function(self, value)
    --print("_change_laser_active", self.cell.id ,value, laser_color_type)
		self.prop.laser_active = value
		self:_send_laser()
	end,
	
	_send_laser = function(self)
		self:_clear_laser_cells()
		
		if self:is_laser_active() then
			local laser_dirs = self:_get_laser_dirs() --self.static.data[3]
			local line_map = self:_get_laser_line_cell(laser_dirs)
			if laser_dirs then
				local line_infos = {}
				for i,dir in ipairs(laser_dirs) do
					local list = line_map[dir]
					
					local pixel_distance = 0
					local enabled = false
					
					if list and next(list) then
						enabled = true
						for i,line_cell in ipairs(list) do
							if i == #list then
								if self.hexmap:is_can_through_laser_cell(self.cell.id, line_cell.id) then
									self:_add_laser_cell(line_cell)
								end 

								pixel_distance = Vector3.Distance(self.cell.top_position, line_cell.top_position)
                                if not line_cell.build then
                                    pixel_distance = pixel_distance + 0.5
                                end
								--print("计算激光长度", self.cell.id, self.cell.top_position, line_cell.top_position)
							else
								self:_add_laser_cell(line_cell)
							end
						end
					end
                    --类型0激光分射器才使用这个参数,所以不要给这个参数默认值
					local laser_color_type = self:get_laser_color_type()
                    local custom_dir
                    if self.static.data[1] == 2 then
                        dirs = self:_get_laser_dirs()
                        custom_dir = dirs[1]
                    end
					table.insert(line_infos, {enabled = enabled, pixel_distance = pixel_distance, laser_color_type = laser_color_type, custom_dir = custom_dir})
				end
				hexmaprender.cellcmd(self.cell, "set_build_laser_line", line_infos)
			end
		end
	end,
	_clear_laser_cells = function(self)
		self.prop.laser_cells = self.prop.laser_cells or {}
		for i,cell in ipairs(self.prop.laser_cells) do
			if self.hexmap:is_walkable_cell(cell.id, self.cell.step) then
				--if self.cell.id == 332 then
					--print("格子可走", cell.id)
				--end
				self.hexmap:enableingrid(cell)
			end
		end
		self.prop.laser_cells = {}
		
		hexmaprender.cellcmd(self.cell, "set_build_laser_line", {})
	end,
	_add_laser_cell = function(self, cell)
		--print("添加格子激光,激光源:", self.cell.id, cell.id)
		if (cell.step == self.cell.step) then
			self.prop.laser_cells = self.prop.laser_cells or {}
			table.insert(self.prop.laser_cells, cell)
			
			self.hexmap:disableingrid(cell)
			--if self.cell.id == 332 then
				--print("禁止格子行走,激光源:", self.cell.id, cell.id)
			--end
		end
	end,
	--射线格子包含最后一个不可通过格子(两种情况:没有格子则不包含或者格子上有建筑包含)
	_get_laser_line_cell = function(self,dirs)
		local line_map = {}
		local laser_dirs = dirs or self.static.data[3]
		if laser_dirs then
			for i,dir in ipairs(laser_dirs) do
				local continuous_cells = self.hexmap:find_continuous_cells_by_dir(self.cell, dir, function(cell)
					return true
				end)
				
				local cells = {}
				for j,cell in ipairs(continuous_cells) do
					if self.hexmap:is_can_through_laser_cell(self.cell.id, cell.id) then
						table.insert(cells, cell)
					else
						break
					end
				end
				
				if #cells > 0 then
					local found = self.hexmap:searchcell_dir(cells[#cells], dir, function()
						return true
					end)
					if found then
						table.insert(cells, found)
					end
				end
				
				line_map[dir] = cells
			end
		end
		
		return line_map
	end
}

--建筑生成器:data数据({格子,建筑id}列表)
local build_creator = basebuild:new {
	onoperate = function(self)
		self:reach()
	end,
	
	onenter = function(self)
		self.hexmap:done_cell(self.cell.id)
	end,
	
	ondone = function(self, decoder)
		local list = self.static.data[1]
		if list then
			for i,info in ipairs(list) do
				local cell = self.hexmap:getcell(info[1])
				if cell then
					hexmapbuild.add_build(cell, info[2])
				end
			end
		end
	end
}

local laser_switch = default_single_btn:new {

    _change_active = function (self,laser_color_type)
        
        -- local active_type = laser_color_type == 0 and 0 or 1
        print("_change_active" , laser_color_type , self.static.data[1] , active_type , self.static.id,self.cell.id)
        -- if self.static.data[1] ~= active_type then
        --     self.hexmap:done_cell(self.cell.id,packbuffer("I2", active_type))
        -- end



        if self.static.data[1] ~= laser_color_type then
            self.hexmap:done_cell(self.cell.id,packbuffer("I2", laser_color_type))
        end
    end,

    onclick = function (self)
    end,

}

local multiple_switch = basebuild:new {
}

local done_guide = basebuild:new {
}

function hexmapbuild.move_build(hexmap, start_cell_id, target_cells, dirs, be_destroy, callback)
	local start_cell = hexmap:getcell(start_cell_id)
	if start_cell and start_cell.build then
		hexmap:setfollowing(true)
		
		local buildid = start_cell.build.id
		local paths = {table.unpack(target_cells)}
		
		local cellviewid = nil
		local finishviewid = nil
		local view_special = start_cell.build.static.view_special
		if view_special and #view_special > 0 then
			cellviewid = view_special[1][1]
			finishviewid = view_special[1][2]
		end
		if start_cell.build._get_finish_move_view_id then
			finishviewid = start_cell.build._get_finish_move_view_id(hexmap, start_cell, start_cell.build, target_cells, be_destroy)
		end
		
		if #target_cells > 0 then
			hexmap:set_build(start_cell, nil)
			hexmap:update_cell(start_cell, {enable = true, fog = 0, walkable = true})
			hexmap:enableingrid(start_cell)
		end
		
		local move_build_callback = function(last_cellid, dir)
			local last_cell = hexmap:getcell(last_cellid)
			
			local finish_view_func = function()
				hexmap:setfollowing(false)
				
				hexmap:done_cell(start_cell_id)
				if last_cell and (not be_destroy) then
					hexmapbuild.add_build(last_cell, buildid)
					if last_cell.build and last_cell.build._on_move_finish then
						last_cell.build:_on_move_finish(last_cellid, dir)
					end
				end
				if callback then
					callback({start_cellid = start_cell_id, last_cellid = last_cellid, dir = dir})
				end
			end
			
			local addfinishviewid = true
			if last_cell then
				if last_cell._is_same_rail and start_cell._is_same_rail then
					local is_same = last_cell:_is_same_rail(start_cell)
					addfinishviewid = not is_same
				end
			end
			
			if finishviewid and addfinishviewid and last_cell and (#paths > 0) then
				--local y_rotation = {120, 180, 240, -60, 0, 60}
				local y_rotation = {60, 90, 150, -150, -90, -30}
				local rotation = {x = 0, y = y_rotation[dir], z = 0}
				hexmap:setfollowing(true)
				hexmaprender.start_view(finishviewid,{rotation = rotation, cb = finish_view_func, position = last_cell.top_position})
			else
				finish_view_func()
			end
		end
		
		if #target_cells > 0 then
			hexmapbuild.on_move_build(hexmap, start_cell, start_cell.id, target_cells, dirs, {cellviewid = cellviewid}, move_build_callback)
		else
			move_build_callback(start_cell_id, dirs and dirs[#dirs])
		end
	end
end

function hexmapbuild.on_move_build(hexmap, start_cell, from_cellid, target_cells, dirs, args, callback)
	local do_move_build_callback = function(from_cellid, last_cellid, is_last, dir)
		if is_last then
			if callback then
				callback(last_cellid, dir)
			end
		else
			if (not dirs) or (#dirs == 0) then
				dirs = {dir}
			end
			hexmapbuild.on_move_build(hexmap, start_cell, last_cellid, target_cells, dirs, args, callback)
		end
	end

	if #target_cells > 0 then
		hexmapbuild.do_move_build(hexmap, start_cell, from_cellid, table.remove(target_cells, 1), #target_cells == 0, table.remove(dirs, 1), args, do_move_build_callback)
	end
end

function hexmapbuild.do_move_build(hexmap, start_cell, from_cellid, cellid, is_last, dir, args, callback)
	local fromcell = hexmap:getcell(from_cellid)
	local targetcell = hexmap:getcell(cellid)
	if targetcell and fromcell then
		local do_next = function ()
							if targetcell.build and targetcell.build.static.type == HEXMAP_BUILD.STOCKADE then
								hexmap:done_cell(targetcell.id, packbuffer("I2", start_cell.id))
							end
							if callback then
								callback(from_cellid, cellid, is_last, dir)
							end
						end
		local cellviewid = args and args.cellviewid
		if cellviewid then
			hexmaprender.start_view(cellviewid,{ fromcell = fromcell, tocell = targetcell, cb = do_next})
		else
			do_next()
		end
	else
		print("没有这个Cell", cellid)
	end
end

local dict = {
    [HEXMAP_BUILD.MONSTER] = monster,
    [HEXMAP_BUILD.REWARD] = reward,
    [HEXMAP_BUILD.KEY_REWARD] = key_reward,
    [HEXMAP_BUILD.COUNT_REWARD] = count_reward,
	[HEXMAP_BUILD.MAZE_END_REWARD] = maze_end_reward,
    [HEXMAP_BUILD.EGG] = egg,
    [HEXMAP_BUILD.RUNE] = rune,
    [HEXMAP_BUILD.OBSTACLE] = obstacle,
    [HEXMAP_BUILD.BATTLE_COUNT_EXIT] = battle_count_exit,
    [HEXMAP_BUILD.SHOP] = shop,
    [HEXMAP_BUILD.RECOVER] = recover,
    [HEXMAP_BUILD.RECOVER2] = recover2,
    [HEXMAP_BUILD.REVIVE] = revive,
    [HEXMAP_BUILD.CART] = cart,
    [HEXMAP_BUILD.KEY] = key,
    [HEXMAP_BUILD.EXIT] = exit,
    [HEXMAP_BUILD.ALTAR] = altar,
    [HEXMAP_BUILD.ATTACK] = attack,
    [HEXMAP_BUILD.ATTACK2] = attack2,
    [HEXMAP_BUILD.TURRET] = turret,
    [HEXMAP_BUILD.REMAIN] = remain,
    [HEXMAP_BUILD.BLESS] = bless,
    [HEXMAP_BUILD.BARRIER] = barrier,
    [HEXMAP_BUILD.GUIDE] = guide,
    [HEXMAP_BUILD.GEAR] = gear,
    [HEXMAP_BUILD.TRANSFER] = transfer,
    [HEXMAP_BUILD.TRANSFER2] = transfer2,
    [HEXMAP_BUILD.RAIL] = rail,
    [HEXMAP_BUILD.MONSTER_RECORD] = monster_record,
    [HEXMAP_BUILD.MONSTER_ABUFF] = monster_abuff,
    [HEXMAP_BUILD.MONSTER_DBUFF] = monster_dbuff,
    [HEXMAP_BUILD.TIPS] = tips,
    [HEXMAP_BUILD.TIPS2] = tips2,
    [HEXMAP_BUILD.STAIR_GEAR] = stair_gear,
    [HEXMAP_BUILD.FALLEN_START] = fallen_start,
    [HEXMAP_BUILD.BLESS2] = bless2,
    [HEXMAP_BUILD.REFRESHER] = refresher,
    [HEXMAP_BUILD.TRIBE] = tribe,
    [HEXMAP_BUILD.TRIBE_MONSTER] = tribe_monster,
    [HEXMAP_BUILD.MONSTER_BORN_BUFF] = monster_born_buff,
    [HEXMAP_BUILD.FALLEN_CELL] = fallen_cell,
    [HEXMAP_BUILD.BOMB_CELL] = bomb_cell,
    [HEXMAP_BUILD.BOMB_PLATFORM] = bomb_platform,
    [HEXMAP_BUILD.BOMB_TRIGGER] = bomb_trigger,
    [HEXMAP_BUILD.HIGH_PLATFORM] = high_platform,
    [HEXMAP_BUILD.CAMP_MONSTER] = camp_monster,
    [HEXMAP_BUILD.BUFF_MONSTER] = buff_monster,
    [HEXMAP_BUILD.MAZE_MONSTER] = maze_monster,
    [HEXMAP_BUILD.MONSTER_KILL_CHECK] = monster_kill_check,
    [HEXMAP_BUILD.KEY_TIPS] = key_tips,
	[HEXMAP_BUILD.DOOR] = door,
	[HEXMAP_BUILD.STOCKADE] = stockade,
	[HEXMAP_BUILD.BALL_EMITTER] = ball_emitter,
	[HEXMAP_BUILD.BALL_EJECTOR] = ball_ejector,
	[HEXMAP_BUILD.BALL] = ball,
	[HEXMAP_BUILD.CHANGE_DIR_RAIL_END] = change_dir_rail_end,
	[HEXMAP_BUILD.DOOR_POST] = door_post,
    [HEXMAP_BUILD.CONDITION_OBSTACLE] = condition_obstacle,
    [HEXMAP_BUILD.WEIGHT_CELL_OBSTACLE] = weight_cell_obstacle,
	[HEXMAP_BUILD.LASER_GENERATOR] = laser_generator,
	[HEXMAP_BUILD.BUILD_CREATOR] = build_creator,
    [HEXMAP_BUILD.LASER_SWITCH] = laser_switch,
    [HEXMAP_BUILD.MULTIPLE_SWITCH] = multiple_switch,
    [HEXMAP_BUILD.DONE_GUIDE] = done_guide,
}

local data_cell_build = ConfigManager.GetConfig("data_cell_build")

function hexmapbuild.getbuildconfig(buildid)
    if buildid then
        return data_cell_build[buildid]
    else
        print("找不到build配置", buildid)
    end
end

function hexmapbuild.init(hexmap)
    hexmapbuild._hexmap = hexmap
    hexmapbuild._condcheck = {}
    hexmapbuild._ntf_key_list = {}
    hexmapbuild._block_cell_list = {}
end

function hexmapbuild._refresh_block_cells()
    if next(hexmapbuild._block_cell_list) then
        for cell, block_count in pairs(hexmapbuild._block_cell_list) do
            if cell.fog ~= 1 then
                hexmapbuild._hexmap:update_cell(cell,{enable = block_count <= 0})
            end
        end
    end
end

function hexmapbuild.destroy()
end

function hexmapbuild.create_build(cell, buildid, prop)
	--print("创建建筑", cell.id, buildid)
	
    local buildcfg = hexmapbuild.getbuildconfig(buildid)
    if not buildcfg then
        return nil
    end
    
    return hexmapbuild._create_build(cell, buildcfg, prop)
end

function hexmapbuild.add_build(cell, nextbuild)
    local newbuild = hexmapbuild.create_build(cell, nextbuild)
    if newbuild then
        hexmapbuild._hexmap:set_build(cell, newbuild)
        newbuild:init()
        hexmapbuild._hexmap:update_cell(cell,{enable = true, fog = 0, walkable = true})
        if newbuild.static.through == 1 then
            hexmapbuild._hexmap:enableingrid(cell)
        else
            hexmapbuild._hexmap:disableingrid(cell)
        end
        if newbuild.static.view_born then
            show_view(newbuild.static.view_born, { position = cell.top_position, at_cell = cell })
        end
    end
end

function hexmapbuild.ntf(ntf_key, ...)
    local list = hexmapbuild._ntf_key_list[ntf_key]
    if list then
        for i, value in ipairs(list) do
            value.cb(value.context, ...)
        end
    end
end

local ntf_const = { "ntf_monster_kill", "ntf_bomb_trigger", "ntf_set_build", "ntf_monster_kill_fail", "ntf_transfer" }

function hexmapbuild._create_build(cell, buildcfg, prop)

    local build = { id = buildcfg.id, type = buildcfg.type, prefab_id = buildcfg.prefab_id, prefab_type = buildcfg.prefab_type,
                    cell = cell, prop = prop or {}, data = buildcfg.data, static = buildcfg, hexmap = hexmapbuild._hexmap, through = buildcfg.through }
    local map_build = dict[buildcfg.type]
    if map_build then
        for _, ntf_key in ipairs(ntf_const) do
            if map_build[ntf_key] then
                hexmapbuild._ntf_key_list[ntf_key] = hexmapbuild._ntf_key_list[ntf_key] or {}
                table.insert(hexmapbuild._ntf_key_list[ntf_key], { context = build, cb = map_build[ntf_key] })
            end
        end
        setmetatable(build, {__index = map_build, __tostring = function (self)
            return string.format("id:%s type:%d", self.id, self.type)
        end})
    else
        print("错误的build类型", buildcfg.type)
        return nil
    end
    return build
end

function hexmapbuild._notify_cell_done(cellid)
end

return hexmapbuild
