scriptcommon = {}

-- 直线子弹
scriptcommon.bullet_line = {
    action  = {
        default = {
            { trigger.time, {0}, caller.body.move, script.prop("speed"), caller.body.addlogic, "sprite.bullet.bullet_line", caller.view.active, "bullet_start" },
            { trigger.time, script.tableprop("duration"), caller.body.destroy }
        },
        collide = {
            { trigger.time, {0}, caller.skill.cast, script.prop("castid"), caller.body.destroy }
        }
    },
    event = {
        { scriptevent.onstart, onfire = function (self)
            if self.prop.rangeid then
                self.caller.body:addlogic("sprite.bullet.bullet_follow", {rangeid = self.prop.rangeid})
            end
        end },
        { eventdef.sprite_collide, script.run("collide") }
    }
}

-- 抛物线子弹
scriptcommon.bullet_parabola = {

    event = {
        { scriptevent.onstart, onfire = function (self)
            
            self.caller.view:active("bullet_start")
            self.caller.body:addlogic("sprite.bullet.bullet_parabola", self.prop)

        end },
        { eventdef.bullet_move_end, onfire = function (self)
            if self.prop.castid then
                local parent = self.owner.body.parent
                if parent.caller.skill then
                    parent.caller.skill:cast(self.prop.castid, self.owner)
                end
            end
            self.caller.body:destroy()
        end }
    }
}

-- 穿透子弹
scriptcommon.bullet_through = {
    action  = {
        default = {
            { trigger.time, {0}, caller.body.move, script.prop("speed"), caller.body.addlogic, "sprite.bullet.bullet_line", caller.view.active, "bullet_start" },
            { trigger.time, script.tableprop("duration"), caller.body.destroy }
        },
    },
    event = {
        { scriptevent.onstart, onfire = function (self)
            self.prop.record = {}
            if self.prop.rangeid then
                self.caller.body:addlogic("sprite.bullet.bullet_follow", {rangeid = self.prop.rangeid})
            end
        end },
        { eventdef.sprite_collide, onfire = function(self, collideobj)
            if not self.prop.record[collideobj] then
                self.prop.record[collideobj] = true
                self.caller.skill:cast(self.prop.castid)
            end
        end}
    }
}

-- 回旋镖子弹
scriptcommon.bullet_pullback = {
    event = {
        { scriptevent.onstart, onfire = function (self)
            
            self.caller.view:active("bullet_start")
            self.caller.body:addlogic("sprite.bullet.bullet_pullback", self.prop)

        end },
    }
}
-- 弧形回旋镖子弹
scriptcommon.bullet_pullback_curve = {
    event = {
        { scriptevent.onstart, onfire = function (self)
            
            self.caller.view:active("bullet_start")
            self.caller.body:addlogic("sprite.bullet.bullet_pullback_curve", self.prop)

        end },
    }
}

--[[追踪子弹 
    rangeid  选取目标，并选取第一个作为追踪对象
    speed    速度
    castid   子弹销毁后cast，可为空，不填默认为rangeid
    duration 子弹存活最大时间，可为空
]]
scriptcommon.bullet_trace = {
    event = {
        { scriptevent.onstart, onfire = function (self)
            
            self.caller.view:active("bullet_start")
            self.caller.body:addlogic("sprite.bullet.bullet_trace", self.prop)
        end },
    }
}

scriptcommon.bullet_trace_curve = {
    event = {
        { scriptevent.onstart, onfire = function (self)
            
            self.caller.view:active("bullet_start")
            self.caller.body:addlogic("sprite.bullet.bullet_trace_curve", self.prop)
        end },
    }
}

-- 弹射子弹
local create_bounce = function (trace) return {
    action  = {
        default = {
            { trigger.time, {0}, caller.body.move, script.prop("speed", 1), caller.body.addlogic, "sprite.bullet.bullet_line", caller.view.active, "bullet_start" },
            { trigger.time, script.tableprop("duration"), caller.body.destroy }
        },
    },
    event = {
        { scriptevent.onstart, onfire = function (self)
            self.prop._hitrecord = {} -- 击中记录
            self.prop._hitlist = {}
            self.prop._hitcount = 0   -- 击中次数
            assert(self.prop.rangeid)
            assert(self.prop.castid)
            assert(self.prop.speed)

            if trace then
                local firstcast = self.prop.castid[1]
                local parent = self.owner.body.parent
                if parent.caller.skill then
                    local targets = parent.caller.skill:range(firstcast)
                    if #targets > 0 then
                        self.owner:checklogic("sprite.play.sprite_lookat", {target = targets[1], speed=self.prop.speed[1]})
                    end
                end
            end
            
        end },
        { eventdef.sprite_collide, onfire = function (self)

            if trace then
                self.owner:destroylogic("sprite.play.sprite_lookat")
            end

            local castid = self.prop.castid[tsmath.min(self.prop._hitcount + 1, #self.prop.castid)]
            local targets = self.caller.skill:cast(castid)

            if not targets or #targets == 0 then -- 没有目标直接销毁
                self.caller.body:destroy()
                return
            else
                for _, target in ipairs(targets) do
                    self.prop._hitrecord[target] = true
                    table.insert(self.prop._hitlist, target)
                    self.prop._lasthit = target
                end
            end
 
            self.prop._hitcount = self.prop._hitcount + 1

            if self.prop._hitcount >= self.prop.count then
                self.caller.body:destroy()
                return
            end

            local targets = self.caller.skill:range(self.prop.rangeid)

            local selection = {}
            -- 击中所有人后还有次数则可击中同一目标
            if #targets >= 2 and #targets == #self.prop._hitlist and self.prop.sametarget then  
                self.prop._hitrecord = {}
            end

            for _, target in ipairs(targets) do
                if not self.prop._hitrecord[target] and target ~= self.prop._lasthit then
                    table.insert(selection, target)
                end
            end

            if #selection > 0 then
                local select = selection[tsmath.random(#selection)]
                local header = (select.body.position - self.owner.body.position).normalized
                self.caller.body:setheader(header)
                local speed = self.prop.speed[tsmath.min(self.prop._hitcount + 1, #self.prop.speed)]
                self.caller.body:move(speed)
            else
                self.caller.body:destroy()
            end

        end }
    }
} end

scriptcommon.bullet_bounce = create_bounce()
scriptcommon.bullet_bounce_trace = create_bounce(true)

-- 脚下空白子弹
scriptcommon.bullet_single = {
    event = {
        { scriptevent.onstart, onfire = function (self)
            self.action:addchild(999999, "bullet_single")
            self.action:destroy()
        end },
    }
}

scriptcommon.circle_block = {
    action  = {
        default = {
            { trigger.time, script.tableprop("duration") }
        },
    },
    event = {
        { scriptevent.onstart, onfire = function (self)
        end },
        { scriptevent.onend, onfire = function (self)
        end },
        { scriptevent.ontimer, time = {0,0}, onfire = function (self)
            local center = self.prop.center
            local radius = self.prop.radius

            local position = self.owner.body.position
            local myradius = self.owner.body.radius
            if tsvector.distance_less_equal(position, center, radius + myradius) then
                if self.prop._lastpos then
                    self.owner.body:setposition(self.prop._lastpos)
                end
            end
            self.prop._lastpos = position
        end }
    }
}