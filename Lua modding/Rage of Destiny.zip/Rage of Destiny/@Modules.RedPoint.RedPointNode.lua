local RedPointDef = require "Modules.RedPoint.RedPointDef"
local ModuleManager = require "Common.Mgr.UI.ModuleManager"

local RedPointNode = RedPointNode or BaseClass()

function RedPointNode:__init(id)
	self.id = id
	self.go = nil --红点go
	self.numComp = nil --数量控件(一般numGo要作为红点go的子物体)
	self.num = 0
	self.parent = nil
	self.children = {} --key:id value:node
	self.func = self.UpdateUI --设置默认的更新方法
	self.isHide = false --true表示隐藏,红点数量强制设为0,不再显示红点
end

function RedPointNode:AddChild(node)
	local id = node.id
	if not self.children[id] then
		self.children[id] = node
		node.parent = self
	end
end

function RedPointNode:SetNum(num)
	if self.isHide then
		num = 0
	end
	if next(self.children) then --仅允许设置叶子节点
		CS.UnityEngine.Debug.LogError("RedPointNode:SetNum:" .. self.id)
		return
	end
	if num ~= self.num then
		self.num = num
		self:OnChange()

		local parent = self.parent
		if parent then
			parent:UpdateNum()
		end
	end
end

function RedPointNode:UpdateNum()
	local num = 0
	local canUpdate = true
	local systemOpenType = RedPointDef.CheckSystemOpen[self.id]
	
	--检查系统开放
	if systemOpenType then
		--测试
		-- local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		-- if systemOpenType == ModuleOpenDef.SystemOpenType.MallDaily then
		-- 	print("RedPointNode:UpdateNum", systemOpenType, tostring(ModuleManager.SystemIsOpen(systemOpenType, false)))
		-- end

		if not ModuleManager.SystemIsOpen(systemOpenType, false) then
			canUpdate = false
		end
	end

	if canUpdate then
		for k,v in pairs(self.children) do
			num = num + v.num
		end
	end

	if num ~= self.num then
		self.num = num
		self:OnChange()

		local parent = self.parent
		if parent then
			parent:UpdateNum()
		end
	end
end

function RedPointNode:OnChange()
	if self.func then
		self.func(self)
	end
end

function RedPointNode:UpdateUI()
	if not IsNil(self.go) then
		self.go:SetActive(self.num > 0)
	end
	if not IsNil(self.numComp) then
		self.numComp.text = self.num
	end
end

function RedPointNode:Hide()
	self:SetNum(0)
	self.isHide = true
end

--有红点的情况下，点击后红点消失，且后面不再出现红点
--isTodayNoShow:true表示今日不再出现但次日恢复 false表示本地登录不出现但重登后恢复
function RedPointNode:CheckClickHide(isTodayNoShow)
	-- print("RedPointNode:CheckClickHide", self.id)
	if self.num > 0 then
		self:Hide()
	
		if isTodayNoShow then
			local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
			RedPointProxy.Instance:SetTodayNoShowValue(self.id)
		end
	end
end

function RedPointNode:SetHideState(state)
	self.isHide = state
end

return RedPointNode