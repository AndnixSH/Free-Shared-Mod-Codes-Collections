

local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local RelationDef=require "Modules.Relation.RelationDef"
local HeroProxy = require "Modules.Hero.HeroProxy"
local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
local RedPointDef = require "Modules.RedPoint.RedPointDef"
local RelationProxy = RelationProxy or BaseClass(BaseProxy)
local AudioManager = require "Common.Mgr.Audio.AudioManager"

function RelationProxy:__init()
    RelationProxy.Instance = self
    self:AddProto(20300, self.On20300)
    self:AddProto(20301, self.On20301)
    self:AddProto(20302, self.On20302)
    self:AddProto(20303, self.On20303)
    self:AddProto(20304, self.On20304)
    self:AddProto(20305, self.On20305)
    self:AddProto(20306, self.On20306)
    self:AddProto(20307, self.On20307)
    self.data={}
    local HeroDef = require "Modules.Hero.HeroDef"
    self.maxRank=HeroDef.Hero_Rank_Enum.yellow_plus --史诗+
    self.confiditonNum=3 --三个条件 {普通 ，精英+，史诗+}

    self.goBackCallBack = false -- 返回需要播放对应的音效
end

function RelationProxy:SetCallBack(callback)
    self.goBackCallBack = callback
end
function RelationProxy:GetCallBack(callback)
    return self.goBackCallBack 
end

function RelationProxy:__delete()
    RelationProxy.Instance = nil
end

function RelationProxy:Send20300()
    self:SendMessage(20300)
   
end
function RelationProxy:GetRelationCfg()
    return ConfigManager.GetConfig("data_union")
end
function RelationProxy:On20300(decoder)
    local union_infos = decoder:DecodeList("I2I1s2", true)
    local aid_heroinfos = decoder:DecodeList("I4s2", true)
    self:On20301(aid_heroinfos)
    --print("------On20300------",table.dump(union_infos))
    local config=self:GetRelationCfg()
    if not config then
        return     
    end
    local relation_list={}
    for _,v in ipairs(config) do
        local item={}
        item.id=v.id
        item.union_id=v.union_id
        item.progress=0
        item.heroNum=v.hero and #v.hero or 0
        item.heroinfos={}
        item.is_full_active=1
        item.name=LanguageManager.Instance:GetWord(v.name)
        for k, _roleid in ipairs(v.hero) do
            local info={}
            info.roleid=_roleid
            info.index=k
            table.insert(item.heroinfos,info)
        end
        table.insert(relation_list,item)
    end
    if union_infos  then
        for _,v in pairs(union_infos) do
            for _, item in ipairs(relation_list) do
                if item.union_id == v[1] then
                    item.is_full_active=v[2]
                    if  item.is_full_active ~= 0 then
                        if v[3] and v[3] ~= "" then
                            local dd=NetDecoder.New(v[3],1)
                            local active_infos=dd:DecodeList("I1I1I1I4I8I4s2I2I1",true)
                            self:UpdateOneItemInfo(item,active_infos)
                        end
                    else
                        for k, hero in ipairs(item.heroinfos) do
                            hero.rank = self.maxRank
                        end
                        item.progress=1
                    end
                    break
                end
            end
        end
    end
    self.data.relation_list=relation_list
    self:ToNotify(self.data,RelationDef.NotifyDef.Relation_RequestList,relation_list)
end

function RelationProxy:UpdateOneItemInfo(item,active_infos,isActive)
    local _config=self:GetConfigByRelationId(item.id)
    if not _config then
        print("------------UpdateOneItemInfo error---------------")
        return
    end
    local count=0
    local isprogressincline=false
    local last_hasheronum={}
    if isActive then
        for i = 1,self.confiditonNum do
            local hasheronum=self:GetTaskProgress(_config.union_id,i)
            table.insert(last_hasheronum,hasheronum)
        end
    end
    for k , hero in ipairs(active_infos) do
        local info=item.heroinfos[hero[1]] --hero[1] pos
        if not info then
            break
        end
        --info.pos=hero[1]
        info.permanent_active=hero[2]
        if info.permanent_active == 0 then
            count = count +1
            info.rank=self.maxRank
        else
            if hero[8] ~= 0 then
                info.rank=hero[8]
            else
                info.rank=nil
            end
        end
        info.level=hero[3]
        info.herouid=hero[4]
        info.hired_guserid=hero[5]
        info.hire_hero_id=hero[6]
        info.nickname=hero[7]
        if info.hired_guserid == 0 and info.herouid ~= 0 and info.permanent_active ~= 0 then
            --自己的
            info.nickname=RoleInfoModel.nickname
        end
        info.can_be_permanent_active=hero[9] --为2可以被永久激活
        if info.can_be_permanent_active == 2 then
            RedPointProxy.Instance:SetNodeNumDynamic(tostring(item.union_id),tostring(info.roleid),1)
        end
    end
    local view=LuaLayout.Instance:GetWidget(UIWidgetNameDef.RelationMenuRootView)
    local effect={}
    if isActive and view and view:IsOpen() then
        local cur_hasheronum={}
        for i = 1,self.confiditonNum do
            local hasheronum=self:GetTaskProgress(_config.union_id,i)
            table.insert(cur_hasheronum,hasheronum)
        end
        local play = false --播放激活属性音效
        local showtips = false
        for i = 1,self.confiditonNum do
            if last_hasheronum[i] < #item.heroinfos and cur_hasheronum[i] >= #item.heroinfos then
                play = true
                table.insert(effect,i)
            end
           if last_hasheronum[i] ~= cur_hasheronum[i] then
                showtips=true
           end
        end
        if showtips then
            GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord(RelationDef.CommonDef.ActiveProgressIncline))
        end
        if play then
            local AudioManager = require "Common.Mgr.Audio.AudioManager"
	        AudioManager.PlaySoundByKey("bond_suc_1")
        end
    end
    
    item.progress=count / #_config.hero
    --print("------UpdateOneItemInfo--22----",table.dump(active_infos))
    return effect
end

function RelationProxy:Send20301()
    --self:SendMessage(20301)
end
function RelationProxy:On20301(aid_heroinfos)
    --local aid_heroinfos = decoder:DecodeList("I4s2", true)
    local heros={}
    for i=1,#aid_heroinfos do
        local item={}
        item.herouid=aid_heroinfos[i][1]
        item.dec=LanguageManager.Instance:GetWord(RelationDef.CommonDef.Resting)
        if aid_heroinfos[i][2] ~= "" then
            item.dec=string.format(LanguageManager.Instance:GetWord(RelationDef.CommonDef.DoTasking),aid_heroinfos[i][2])
        end
        table.insert(heros,item)
    end
    for i=#aid_heroinfos + 1,6 do
        local item={}
        table.insert(heros,item)
    end
    self.data.AidInfo={heros=heros,amount=#aid_heroinfos}
    self:ToNotify(self.data,RelationDef.NotifyDef.Relation_RequestMyAidList,self.data.AidInfo)
end

function RelationProxy:GetAidInfo()
    if self.data.AidInfo then
        return self.data.AidInfo
    end
end

function RelationProxy:Send20302(herouid)
    local encoder=NetEncoder.New()
    encoder:Encode("I4", herouid)
    self:SendMessage(20302,encoder)
end
function RelationProxy:GetRelationHeroList()
    local data=HeroProxy.Instance:GetHeroDataList()
    local list={}
    for _, v in pairs(data) do
        local has=false
        for _, hero in pairs(self.data.AidInfo.heros) do
            if v.herouid and v.herouid == hero.herouid then
                has=true
            end
        end
        if not has then
            table.insert(list,v)
        end
    end
    table.sort(list, function(a, b)
        return a.rank > b.rank
    end)
    return list
end
function RelationProxy:On20302(decoder)
    local result = decoder:Decode("I1")
    -- print("-----20302---",result)
    if result == 0 then
        local herouid = decoder:Decode("I4")
        for _, v in ipairs(self.data.AidInfo.heros) do
            if v then
                if not v.herouid  then
                    v.herouid=herouid
                    v.dec=LanguageManager.Instance:GetWord(RelationDef.CommonDef.Resting)
                    self.data.AidInfo.amount = self.data.AidInfo.amount + 1
                    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.RelationHeroView)
                    self:ToNotify(self.data,RelationDef.NotifyDef.Relation_RequestMyAidList,self.data.AidInfo)
                    break
                end 
            end
        end
        AudioManager.PlaySoundByKey("battleselecttop_view_1")
    else
        GameLogicTools.ShowErrorCode(20302,result)
    end
    --print("-----20302---")
end


function RelationProxy:Send20303(herouid)
    local encoder=NetEncoder.New() 
    encoder:Encode("I4", herouid)
    self:SendMessage(20303,encoder)

end
function RelationProxy:On20303(decoder)
    
    local result = decoder:Decode("I1")
    --print("-----On20303---",result)
    if result == 0 then
        local herouid = decoder:Decode("I4")
        for i, v in pairs(self.data.AidInfo.heros) do
            if v then
                if v.herouid and  v.herouid == herouid then
                    table.remove(self.data.AidInfo.heros,i)
                    table.insert(self.data.AidInfo.heros,{})
                    self.data.AidInfo.amount = self.data.AidInfo.amount - 1
                    self:ToNotify(self.data,RelationDef.NotifyDef.Relation_RequestMyAidList,self.data.AidInfo)
                    break
                end 
            end
        end
        
    else
        GameLogicTools.ShowErrorCode(20303,result)
    end
end

function RelationProxy:GetConfigByRelationId(relationid)
    local cfg=self:GetRelationCfg()
    if cfg then
        return cfg[relationid]
    end
end

function RelationProxy:GetOneRelationHerosList_Left_ByRelationId(relationid)
    --左边显示英雄图片信息
    local cfg=self:GetConfigByRelationId(relationid)
    if cfg then
        local hero=cfg.hero
        local pos =cfg.pos
        local data={}
        if hero and pos then
            local heroinfos=self:GetOneRelationHerosList_Right_ByRelationId(relationid)
            local count = #hero
            for i=#hero,1,-1 do
                local item={}
                item.roleid=hero[i]
                item.pos= pos[i] and pos[i] or {0,0}
                for _, v in ipairs(heroinfos) do
                    if item.roleid == v.roleid then
                        item.rank = v.rank
                    end
                end
                item.direction =1   -- x中间
                local index = 0
                for k=#hero,1,-1 do
                    if k ~= i then
                        local xx =  pos[k][1]
                        if pos[i][1] > xx then
                            index = index + 1
                        elseif pos[i][1] < xx  then
                            index = index - 1
                        end
                    end
                end
                if index == 0 then
                    item.direction = 2
                elseif index == 1 or index == 2 then
                    item.direction = 3
                elseif index == -1 or index == -2 then
                    item.direction = 1
                end
                
                item.order = count - i 
                item.num = #hero
                table.insert(data,item)
            end
        end
        return data , LanguageManager.Instance:GetWord(cfg.name)
    end
end

function RelationProxy:GetOneRelationHerosList_Right_ByRelationId(relationid)
    --右边显示英雄图片信息
    for _ ,v in ipairs(self.data.relation_list) do
        if v and v.id == relationid then
            return v.heroinfos
        end
    end
end

function RelationProxy:GetTaskProgress(union_id,level)
    if not self.data.relation_list then
        return -1
    end
    local count=0
    for _ ,v in ipairs(self.data.relation_list) do
        if v then
            if v.union_id == union_id then
                if v.is_full_active and v.is_full_active == 0 then
                    return 0
                end
                for _, _info in ipairs(v.heroinfos) do
                    if (_info.permanent_active and _info.permanent_active == 0) or ( _info.level and _info.level >= level and _info.rank ~= nil ) then
                        count = count + 1
                    end
                end
                if count ~= 0 then
                    return count
                else
                    return -1
                end
               
            end
        end
    end
    return -1
end

function RelationProxy:GetOneRelationPropertyByRelationId(relationid)
    local cfg=self:GetConfigByRelationId(relationid)
    if cfg then
        local data={}
        local str="value"
        for i=1,3 do 
            local item={}
            local need_heronum= cfg.hero and #cfg.hero  or 0
            local hasheronum=self:GetTaskProgress(cfg.union_id,i)
            if hasheronum == -1 then
                hasheronum=0
            elseif hasheronum == 0 then
                hasheronum=need_heronum
            end
            item.index = i
            item.progressLab=string.format( "(%s/%s)",hasheronum,need_heronum)
            local str2 = LanguageManager.Instance:GetWord(RelationDef.Rank[i])
            item.title=string.format(LanguageManager.Instance:GetWord(RelationDef.Property[i]),need_heronum,str2)
            item.state= hasheronum == need_heronum 
            item.attr={}
            local propertyList=cfg[str..tostring(i)]
            if propertyList then
                for k, v in pairs(propertyList) do
                    if v and v[1] then
                        local _property={}
                        if v[1] == 2 or v[1] == 7 or v[1] == 8 then
                            _property.sprname="attr_"..tostring(v[1])
                        else
                            _property.sprname="attr_0"
                        end
                       
                        local property=HeroProxy.Instance:GetAttrValueCfgByType(v[1])
                        local value=string.format( property.valuestring,(v[2] or 0) / property.conversion )
                        _property.attr_value=LanguageManager.Instance:GetWord(property.name).."+"..tostring(value)
                        table.insert(item.attr,_property)
                    end
                end
            end
            table.insert(data,item)
        end
        return data
    end
end

function RelationProxy:GetOneRelationStoryByRelationId(relationid)

    local cfg=self:GetConfigByRelationId(relationid)
    if cfg then
        return LanguageManager.Instance:GetWord(cfg.story)
    end
    return ""
end

function RelationProxy:GetRoleIdByRelationIdWithPos(relationid,pos)
    local cfg=self:GetConfigByRelationId(relationid)
    if cfg then
        if cfg.hero  then
            return cfg.hero[pos]
        end
    end
end


function RelationProxy:Send20304(union_id,union_pos)
    local encoder=NetEncoder.New()
    encoder:Encode("I2I1", union_id,union_pos)
    self:SendMessage(20304,encoder)
end
function RelationProxy:On20304(decoder)
    local result = decoder:Decode("I1")
    if result == 0 then
        local union_id, union_pos=decoder:Decode("I2I1")
        local own_hero_type_infos=decoder:DecodeList("I4I4I2",true)
        local other_hero_type_infos=decoder:DecodeList("I8s2I4I4I2",true)
        --print("-----On20304-own_hero_type_infos--",table.dump(own_hero_type_infos))
        --print("-----On20304-other_hero_type_infos--",table.dump(other_hero_type_infos))

        local data={}
        for _, v in ipairs(own_hero_type_infos) do
            if v then
                local hero={}
                hero.guserid=RoleInfoModel.guserid
                hero.herouid=v[1]
                hero.roleid=v[2]
                hero.rank=v[3]
                hero.own_nickname=RoleInfoModel.nickname
                hero.showlevel = false
                table.insert(data,hero)
            end
        end
        for _, v in ipairs(other_hero_type_infos) do
            if v then
                local hero={}
                hero.guserid=v[1]
                hero.own_nickname=v[2]
                hero.herouid=v[3]
                hero.roleid=v[4]
                hero.rank=v[5]
                hero.showlevel = false
                table.insert(data,hero)
            end
        end
        local selectIndex=0
        table.sort(data, function(a, b)
            return a.rank > b.rank
        end)
        for _, v in ipairs(self.data.relation_list) do
            if v then
                if v.union_id == union_id then
                    local item=v.heroinfos[union_pos]
                    if item.rank then
                        for k, hero in ipairs(data) do

                            if (hero.herouid == item.herouid and item.herouid ~= 0 and  item.hired_guserid == 0 and hero.guserid == RoleInfoModel.guserid ) 
                            or (hero.herouid == item.hire_hero_id and  item.hired_guserid ~= 0 and hero.guserid == item.hired_guserid) then

                                selectIndex=k
                                break
                            end
                        end
                    end
                    break
                end
            end
        end
        self:ToNotify(self.data,RelationDef.NotifyDef.Relation_SetRelationHeroList,{heroInfos=data,selectIndex=selectIndex})
    else
        GameLogicTools.ShowErrorCode(20304,result)
    end
end

function RelationProxy:Send20305(union_id,union_pos,guser_id,guser_hero_id)
    local encoder=NetEncoder.New()
    encoder:Encode("I2I1I8I4", union_id,union_pos,guser_id,guser_hero_id)
    self:SendMessage(20305,encoder)
end

function RelationProxy:On20305(decoder)
    local result = decoder:Decode("I1")
    if result == 0 then
        local effect = {}
        local union_id,is_full_active,buffstr = decoder:Decode("I2I1s2")
        local dd=NetDecoder.New(buffstr,1)
        local active_infos=dd:DecodeList("I1I1I1I4I8I4s2I2I1",true)
        for _, item in ipairs(self.data.relation_list) do
            if item.union_id == union_id then
                item.is_full_active=is_full_active
                if  item.is_full_active ~= 0 then
                    effect = self:UpdateOneItemInfo(item,active_infos,true)

                    if self.data.redDotInfo and self.data.redDotInfo[union_id] then

                        local heros = self.data.redDotInfo[union_id]
                        for _ , v in ipairs(active_infos) do
                            for k , _hero in ipairs(heros) do
                                if v[1] == _hero.union_pos then
                                    if v[2] == 0 then
                                        table.remove(self.data.redDotInfo[union_id],k)
                                    else
                                        _hero.currank = v[8]
                                    end
                                    break
                                end
                            end
                        end
                    else
                        self.data.redDotInfo[union_id] = {}
                        for _ , v in ipairs(active_infos) do
                            local union ={}
                            union.union_pos= v[1]
                            union.currank = v[8]
                            union.cansetrank = {v[8]}
                            table.insert( self.data.redDotInfo[union_id], union)
                        end
                    end
                else

                    for k, hero in ipairs(item.heroinfos) do
                        hero.rank = self.maxRank
                    end
                    item.progress=1
                    
                    if self.data.redDotInfo and self.data.redDotInfo[union_id] then
                        for k , v in pairs(self.data.redDotInfo) do
                            if v == self.data.redDotInfo[union_id] then
                                table.remove(self.data.redDotInfo,k)
                                break
                            end
                        end
                    end
                end
                self:UpdateRedDot()
                break
            end
        end
        self:ToNotify(self.data,RelationDef.NotifyDef.Relation_DoingActive,{effect = effect})
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.RelationHeroView)
        --local active_infos=decoder:DecodeList("I1I1I1I4I8I4",true)
    else
        GameLogicTools.ShowErrorCode(20305,result)
    end
end

function RelationProxy:Send20306(union_id,union_pos)
    local encoder=NetEncoder.New()
    encoder:Encode("I2I1", union_id,union_pos)
    self:SendMessage(20306,encoder)
end
function RelationProxy:On20306(decoder)
    local result = decoder:Decode("I1")
    if result == 0 then
        local union_id,is_full_active,buffstr = decoder:Decode("I2I1s2")
        local dd=NetDecoder.New(buffstr,1)
        local active_infos=dd:DecodeList("I1I1I1I4I8I4s2I2I1",true)
        local index = 1
        local _data = false
        local effect = {}
        for kk, item in ipairs(self.data.relation_list) do
            if item.union_id == union_id then
                index = kk
                _data = item
               
                item.is_full_active=is_full_active
                if  item.is_full_active ~= 0 then
                    effect = self:UpdateOneItemInfo(item,active_infos,true)
                    if self.data.redDotInfo and self.data.redDotInfo[union_id] then
                        local heros = self.data.redDotInfo[union_id]
                        for _ , v in ipairs(active_infos) do
                            for k , _hero in ipairs(heros) do
                                if v[1] == _hero.union_pos then
                                    if v[2] == 0 then
                                        table.remove(self.data.redDotInfo[union_id],k)
                                    else
                                        _hero.currank = v[8]
                                    end
                                    break
                                end
                            end
                        end
                    else
                        self.data.redDotInfo[union_id] = {}
                        for _ , v in ipairs(active_infos) do
                            local union ={}
                            union.union_pos= v[1]
                            union.currank = v[8]
                            union.cansetrank = {v[8]}
                            table.insert( self.data.redDotInfo[union_id], union)
                        end
                    end
                else
                    for k, hero in ipairs(item.heroinfos) do
                        hero.rank = self.maxRank
                    end
                    for i = 1,self.confiditonNum do
                        local hasheronum=self:GetTaskProgress(union_id,i)
                        if hasheronum < #item.heroinfos then
                            table.insert(effect,i)
                        end
                    end
                    item.progress=1
                    if self.data.redDotInfo and self.data.redDotInfo[union_id] then
                        for k , v in pairs(self.data.redDotInfo) do
                            if v == self.data.redDotInfo[union_id] then
                                self.data.redDotInfo[union_id] = nil
                                break
                            end
                        end
                    end
                     --全部永久激活
                     local AudioManager = require "Common.Mgr.Audio.AudioManager"
                     AudioManager.PlaySoundByKey("bond_suc_1")
                end
                self:UpdateRedDot()
                break
            end
        end
        self:ToNotify(self.data,RelationDef.NotifyDef.Relation_DoingActive,{is_single_active_forever = true,index = index ,cur_union =_data,effect = effect})
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.RelationforeverView)
    else
        GameLogicTools.ShowErrorCode(20306,result)
    end
end

function RelationProxy:Send20307()
    self:SendMessage(20307)
end

function RelationProxy:On20307(decoder)
    local count = decoder:Decode("I2")
    local redDotInfo = {}
    for i = 1 ,count do
        local union ={}
        local union_id,union_pos,currank = decoder:Decode("I2I1I2")
        local cansetrank = decoder:DecodeList("I2")
        if not redDotInfo[union_id] then
            redDotInfo[union_id] = {}
        end
        union.union_pos= union_pos
        union.currank = currank
        union.cansetrank = cansetrank
        table.insert( redDotInfo[union_id] , union)
        table.sort(redDotInfo[union_id], function(a,b)
            return a.union_pos < b.union_pos
        end)
    end
    self.data.redDotInfo = redDotInfo
    self:UpdateRedDot()
end

function RelationProxy:CheckShowAddPlus(union_id,union_pos)
    if self.data.redDotInfo then
        if self.data.redDotInfo[union_id] then
            local find = false
            for _, union in ipairs(self.data.redDotInfo[union_id] or {}) do
                if union_pos == union.union_pos then
                    find = true
                    local len = union.cansetrank == nil and 0 or #union.cansetrank
                    if len > 0 then
                        return true
                    end
                    return false
                end
            end
            if not find then
                return false
            end
        else
            return false
        end
    end
    return true
end

function RelationProxy:UpdateRedDot()
    if not self.data.redDotInfo then
        return
    end
    local ModuleManager = require "Common.Mgr.UI.ModuleManager"
    local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
    local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.RelationMenuRootView_2,false)
    if not  bopen then
        return
    end
    
    --local cfg = self:GetRelationCfg()
    if not self.data.relation_list then
        return
    end
    for _ ,  v in ipairs( self.data.relation_list ) do

        --local id = RedPointDef.Id.Relation..tostring(v.union_id)
        if v.union_id and self.data.redDotInfo[v.union_id] then
            local showredPoint = false
            for k , hero in ipairs(v.heroinfos  or {}) do
                local find = false
                for _, union in ipairs(self.data.redDotInfo[v.union_id] or {}) do
                    if k == union.union_pos then
                        local len = #union.cansetrank
                        table.sort(union.cansetrank, function(a,b)
                            return a < b
                        end)
                        local thelast_rank = len > 0 and union.cansetrank[len] or 0
                        local HeroDef = require "Modules.Hero.HeroDef"
                        if thelast_rank == 0  or union.currank >= thelast_rank  then
                            local showred = false
                            if v.is_full_active == 1 then
                                if hero.permanent_active == 1 and hero.can_be_permanent_active == 2  then
                                    showred = true
                                end
                            end
                            if not showredPoint then
                                showredPoint = showred
                               
                            end
                            RedPointProxy.Instance:SetNodeNumDynamic(tostring(v.union_id),tostring(hero.roleid),showred and 1 or 0)
                        else
                            showredPoint = true
                            RedPointProxy.Instance:SetNodeNumDynamic(tostring(v.union_id),tostring(hero.roleid),1)
                        end
                        find = true
                        break
                    end
                end
                if not find then
                    RedPointProxy.Instance:SetNodeNumDynamic(tostring(v.union_id),tostring(hero.roleid),0)
                end
            end
            RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.Relation,tostring(v.union_id),showredPoint and 1 or 0)
        else
            for _ , hero in ipairs(v.heroinfos or {}) do
                RedPointProxy.Instance:SetNodeNumDynamic(tostring(v.union_id),tostring(hero.roleid),0)
            end
            RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.Relation,tostring(v.union_id),0)
        end
    end
    local num = RedPointProxy.Instance:GetNodeNum(RedPointDef.Id.Relation)
    RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.Relation_2,num)
    RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.Relation_3,num)
end

function RelationProxy:GetAttr(roleid)
    local attributes={}
    local attributes_config = HeroProxy.Instance:GetAttrNames()
    if not self.data.relation_list then
        return attributes
    end
    for _, v in ipairs(self.data.relation_list) do
        if  v then
            if v.heroinfos then
                for _, item in ipairs(v.heroinfos) do
                    if item then
                        if item.roleid == roleid then
                            local relationid=v.id
                            local  cfg=self:GetConfigByRelationId(relationid)
                            local heronum=v.heroNum
                            local str="value"
                            for i = 1,self.confiditonNum do
                                local hasheronum=self:GetTaskProgress(cfg.union_id,i)
                                if hasheronum == heronum then
                                    --满足条件 属性加成
                                    local propertyList=cfg[str..tostring(i)]
                                    if propertyList then
                                        for k, v in pairs(propertyList) do
                                            if v and v[1] then
                                                local key = attributes_config[v[1]]
                                                if attributes[key] then
                                                    attributes[key] = attributes[key] + v[2]
                                                else
                                                    attributes[key] = v[2]
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                            return attributes
                        end
                    end
                end
            end
        end
    end
    return attributes
end

function RelationProxy:CheckShowAidRedDot()
    local key = tostring(RoleInfoModel.guserid).."AidRedDot"
    local state = PlayerPrefs.GetInt(key)
    if state == 0 then
        return true
    elseif state == 1 then
        return false
    end 
end

function RelationProxy:SetAidRedDotState(state)
    local key = tostring(RoleInfoModel.guserid).."AidRedDot"
    PlayerPrefs.SetInt(key,state) --0未显示，1显示
    if state == 1 then
        self:ToNotify(self.data,RelationDef.NotifyDef.Relation_UpdateAidRedDot,{})
    end
end
return RelationProxy