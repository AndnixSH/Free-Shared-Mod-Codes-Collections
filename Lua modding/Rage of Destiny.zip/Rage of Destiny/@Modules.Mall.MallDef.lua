local MallDef = {}

MallDef.LanguageKey = {
	MallSdk1 = "MallSdk1",
	MallSdk2 = "MallSdk2",
	MallSdk3 = "MallSdk3",
	MallSdk4 = "MallSdk4",
	MallSdk5 = "MallSdk5",
	MallSdk6 = "MallSdk6",
	MallSdk7 = "MallSdk7",

	MallRootView1 = "MallRootView1",
	MallRootView2 = "MallRootView2",
	MallRootView3 = "MallRootView3",
	MallRootView4 = "MallRootView4",
	MallRootView5 = "MallRootView5",
	MallRootView6 = "MallRootView6",

	MallNormalView1 = "MallNormalView1",
	MallNormalView2 = "MallNormalView2",
	MallNormalView3 = "MallNormalView3",
	MallNormalView4 = "MallNormalView4",
	MallNormalView5 = "MallNormalView5",
	MallNormalView6 = "MallNormalView6",
	MallNormalView7 = "MallNormalView7",
	MallNormalView8 = "MallNormalView8",
	MallNormalView9 = "MallNormalView9",
	MallNormalView10 = "MallNormalView10",
	MallNormalView11 = "MallNormalView11",
	MallNormalView12 = "MallNormalView12",
	MallNormalView13 = "MallNormalView13",

	MallLimitView1 = "MallLimitView1",
	MallLimitView2 = "MallLimitView2",
	MallLimitView3 = "MallLimitView3",
	MallLimitView4 = "MallLimitView4",
	MallLimitView5 = "MallLimitView5",
	MallLimitView6 = "MallLimitView6",
	MallLimitView7 = "MallLimitView7",
	MallLimitView8 = "MallLimitView8",
	MallLimitView9 = "MallLimitView9",
	MallLimitView10 = "MallLimitView10",
	MallLimitView11 = "MallLimitView11",
	MallLimitView12 = "MallLimitView12",
	MallLimitView13 = "MallLimitView13",

	MallMonthCardView1 = "MallMonthCardView1",
	MallMonthCardView2 = "MallMonthCardView2",
	MallMonthCardView3 = "MallMonthCardView3",
	MallMonthCardView4 = "MallMonthCardView4",
	MallMonthCardView5 = "Mall_MonthlyCard_1008",

	MallPushView1 = "MallPushView1",

	MallConfirmView1 = "MallConfirmView1",
	MallConfirmView2 = "MallConfirmView2",
	MallConfirmView3 = "MallConfirmView3",

	MallFirstCharge_Second = "MallFirstCharge_Second",
	MallFirstCharge_SecondTips = "MallFirstCharge_SecondTips",


}

MallDef.Notify = {
	UpdateAllMallInfo = "UpdateAllMallInfo", --所有商城信息
	UpdateMallInfo = "UpdateMallInfo", --商城信息
	Update_First_Charge = "Update_First_Charge", --首充
	UpdateGrowCon = "UpdateGrowCon", --成长礼包条件
	UpdateGrowAllHadGet = "UpdateGrowAllHadGet", --当前成长礼包的所有奖励都领取完
	UpdatePushIcon = "UpdatePushIcon", --推送礼包主界面图标
	UpdateAllPassInfo = "UpdateAllPassInfo",--更新通行证信息
	UpdatePassInfo = "UpdatePassInfo", --更新通行证信息
	UpdatePassRewardInfo = "UpdatePassRewardInfo",--更新通行证奖励信息
	UpdateAllCustomInfo = "UpdateAllCustomInfo",
	UpdateMainLeftActivity = "UpdateMainLeftActivity", --主界面左侧图标
}

--所有商船类型(界面标签)
MallDef.RootType = {
	Limit = 1, --限时商船
	Normal = 2, --普通商船
	MonthCard = 3, --月卡
	Pass = 4,
}

--普通商船类型(界面标签)
MallDef.NormalType = {
	Daily = 1, --日礼包
	Weekly = 2, --周礼包
	Monthly = 3, --月礼包
	Gem = 4, --钻石礼包
	FirstCharge_Second = 5, --首充二档
}

--限时商船类型(界面标签)
MallDef.LimitType = {
	Sail = 1, --起航礼包
	Grow = 2, --成长礼包
	Self = 3, --自选礼包
	HappyMonth = 4,--女王狂欢祭
}

--月卡类型(界面标签)
MallDef.MonthCardType = {
	MonthCard = 1, --月卡
}

--商城类型
MallDef.Type = {
	Daily = 1, --日礼包
	Weekly = 2, --周礼包
	Monthly = 3, --月礼包
	Gem = 4, --钻石礼包
	Sail = 5, --起航礼包
	Grow = 6, --成长礼包
	MonthCard = 7, --月卡礼包
	Push = 8, --推送礼包
	Pass = 9, --通行证
	Self = 10, --自选礼包
	DailySupply = 13, --每日补给
}

--格子类型
MallDef.GridType = {
	Sequence = 1, --顺序
	Random = 2, --随机
	Choose = 3, --自选
	Diamond = 4, --钻石
	MonthCard = 5, --月卡
}

--礼包类型
MallDef.GiftType = {
	Fixed = 1, --固定
	Choose = 2, --自选
	Push = 3, --推送
}

MallDef.CantBuyGiftReason = {
	Times = 50, --次数限制
	NoExist = 51, --礼包不存在
	Time = 52, --时间限制
	ExistActivateDailySupply = 54, --存在已激活的每日补给礼包
}

--月卡状态
MallDef.MonthCardState = {
	None = 1, --从未购买
	Activate = 2, --已激活
	Overdue = 3, --过期
}

--月卡每日奖励状态
MallDef.MonthCardDailyRewardState = {
	CantGet = 1, --不可领取
	CanGet = 2, --可领取
	HadGet = 3, --已领取
}

--服务端存储的数据
MallDef.GrowConState = {
	NotGet = 0, --未领取
	HadGet = 1, --已领取
}

--客户端状态判定
MallDef.GrowConState2 = {
	CanGet = 0, --可领取
	CantGet = 1, --不可领取
	HadGet = 2, --已领取
}

--成长礼包有效的原因
MallDef.GrowValidReason = {
	Times = 1, --有可购买次数
	Goods = 2, --奖励未全部领完
}

--每日补给状态
MallDef.DailySupplyState = {
	None = 1, --从未购买
	Activate = 2, --已激活
	Overdue = 3, --过期
}

--每日补给每日奖励状态
MallDef.DailySupplyDailyRewardState = {
	CantGet = 1, --不可领取
	CanGet = 2, --可领取
	HadGet = 3, --已领取
}

--商城推送礼包条件
MallDef.PushConType = {
    Lv = 10, --账号等级
    Mainline = 11, --主线通关
    TowerBase = 20, --普通塔
    TowerType1 = 21, --圣光塔
    TowerType2 = 22, --蛮荒塔
    TowerType3 = 23, --自然塔
    TowerType4 = 24, --暗影塔
    Crystal = 12, --共鸣水晶
    Storyline = 13, --剧情副本
    Realm = 14, --位面幻境
    Tree = 15, --生命之树
    Activity = 16, --活动
}

MallDef.TexBGConfig = {
	[MallDef.Type.Sail] = {pos = Vector3.New(493.2,15.5,0)},
	[MallDef.Type.Daily] = {pos = Vector3.New(619,-98,0)},
	[MallDef.Type.Weekly] = {pos = Vector3.New(687,-130.8,0)},
	[MallDef.Type.Monthly] = {pos = Vector3.New(585,-22.5,0)},
}

MallDef.RootTabType = {
	{key = MallDef.LanguageKey.MallRootView2, icon = "xianshi0", icon2 = "xianshi", widgetName = UIWidgetNameDef.MallLimitView},
	{key = MallDef.LanguageKey.MallRootView1, icon = "putong0", icon2 = "putong", widgetName = UIWidgetNameDef.MallNormalView},
	{key = MallDef.LanguageKey.MallRootView3, icon = "yueka0", icon2 = "yueka", widgetName = UIWidgetNameDef.MallMonthCardView},
	{key = "Mall_Pass_1001", icon = "jiajiangling0", icon2 = "jiajiangling", widgetName = UIWidgetNameDef.MallPassView},
}

MallDef.NormalTabType = {
	{key = MallDef.LanguageKey.MallNormalView1, rootObjName = "day"},
	{key = MallDef.LanguageKey.MallNormalView2, rootObjName = "week"},
	{key = MallDef.LanguageKey.MallNormalView3, rootObjName = "month"},
	{key = MallDef.LanguageKey.MallNormalView4, rootObjName = "gem"},
	{key = MallDef.LanguageKey.MallFirstCharge_Second, rootObjName = "hero"},
}

MallDef.PassTabType = {	
	{key = "Mall_Pass_1002"},--日常犒赏
	{key = "Mall_Pass_1004"},--巨龙犒赏
	{key = "Mall_Pass_1006"},--混沌犒赏
}

MallDef.MallPassType = {
	Task = 1, --日常犒赏
	Maze = 2, --巨龙犒赏
	GuildChaos = 3, --混沌犒赏
}
MallDef.MallPassGoodsName = {
	[MallDef.MallPassType.Task] = "Mall_Pass_1003",
	[MallDef.MallPassType.Maze] = "Mall_Pass_1005",
	[MallDef.MallPassType.GuildChaos] = "Mall_Pass_1007",
}

MallDef.MallPassType2PassBaseId = {
	[MallDef.MallPassType.Task] = 1001,
	[MallDef.MallPassType.Maze] = 1002,
	[MallDef.MallPassType.GuildChaos] = 1003,
}

MallDef.MallPassType2GoodsId = {
	[MallDef.MallPassType.Task] = CURRENCY_TYPE_GOODID[CURRENCY_TYPE.medals_valor],
	[MallDef.MallPassType.Maze] = CURRENCY_TYPE_GOODID[CURRENCY_TYPE.heroic_merit],
	[MallDef.MallPassType.GuildChaos] = CURRENCY_TYPE_GOODID[CURRENCY_TYPE.twisted_sigil],
}

MallDef.LimitTabType = {
	{key = MallDef.LanguageKey.MallLimitView1, rootObjName = "sail"},
	{key = MallDef.LanguageKey.MallLimitView2, rootObjName = "grow"},
	{key = "MallCustomPack_1001", rootObjName = "self"},
	{key = "Mall_Happymonth_1000", rootObjName = "HappyMonth"},
}

MallDef.MonthCardTabType = {
	{key = MallDef.LanguageKey.MallRootView3, rootObjName = "monthcard"},
}

MallDef.FirstChargetType = {
	first = 1,--第一档 任意金额
	second = 2, -- 第二档 648
}

MallDef.FirstCharge_Config_ID = {
	[MallDef.FirstChargetType.first] = 2021,--第一档 任意金额
	[MallDef.FirstChargetType.second] = 2022,--第一档 任意金额
}

MallDef.PassFullScreenViewBg = {
	"Tex_Bg_Pass1",
	"Tex_Bg_Pass2",
	"Tex_Bg_Pass3",
}

MallDef.PassIconBg = {
	[MallDef.MallPassType.Task] = {
		"Tex_Pass_1_0",
		"Tex_Pass_1_1",
	},
	[MallDef.MallPassType.Maze] = {
		"Tex_Pass_2_0",
		"Tex_Pass_2_1",
	},
	[MallDef.MallPassType.GuildChaos] = {
		"Tex_Pass_3_0",
		"Tex_Pass_3_1",
	},
}

MallDef.FirstChargeState = {
	UnCharge_First = 0, --未充值任意金额
	UnGet_First = 1,--充值任意金额，未领取首充一档奖励
	Get_First = 2,--一档奖励领取完
	Hide_Second = 3,--一档奖励领取完，充值累计未满足128 
	Show_Second = 4,--一档奖励领取完，充值累计满足128，未充值单笔648
	UnGet_Second = 5,--一档奖励领取完，充值累计满足128，有充值单笔648，未领取首充二档奖励
	Get_Second = 6, --一档奖励领取完，充值累计满足128，有充值单笔648，领取首充二档奖励
}

--奖励状态
MallDef.CommonRewardState = {
	CantGet = 1, --不可领取
	CanGet = 2, --可领取
	HadGet = 3, --已领取
}

--定制礼包用 多选一礼包 小类

MallDef.CustomGiftSubType = 606

return MallDef