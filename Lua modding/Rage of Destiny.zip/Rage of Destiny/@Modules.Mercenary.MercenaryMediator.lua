local MercenaryMediator = MercenaryMediator or BaseClass(StdMediator)

function MercenaryMediator:OnEnterScenceFirst()
	self:DelayExecute(function()
		local MercenaryProxy = require "Modules.Mercenary.MercenaryProxy"
		MercenaryProxy.Instance:Send20500()
		MercenaryProxy.Instance:Send20509()
	end)
end

return MercenaryMediator