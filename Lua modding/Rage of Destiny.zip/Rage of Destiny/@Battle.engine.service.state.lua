-- local statestatus = { hold = 1, over = 2, suspend = 3 }

local statemachine = class({})

function statemachine:constructor()
    self._relations = {}
    self._current = nil
    self.data = {}
    self._bstart = false
    -- self.status = statestatus
    self._ticktimer = nil
end

function statemachine:configure(fromstate, tostate, breakstates, isdefault)

    assert(not self._relations[fromstate])

    fromstate.state = self
    tostate.state = self

    if breakstates then
        for _, _state in ipairs(breakstates) do
            _state.state = self
        end
    end

    self._relations[fromstate] = { tostate = tostate, breakstates = breakstates }

    if isdefault then
        self._current = fromstate
    end
end

function statemachine:destroy()
    self._current = nil
    self.data = nil
    self._relations = {}
    self._bstart = false
    if self._ticktimer then
        global.service.timer:destroytimer(self._ticktimer)
        self._ticktimer = nil
    end
end

function statemachine:sendevent(eventname, ...)
    local func = self.event and self.event[eventname] or nil
    if func then
        func(self, ...)
    end
end

function statemachine:start(tick, source)
    if not self._bstart and self._current then
        self._bstart = true
        if self.onstatechange ~= nil then
            self.onstatechange(nil, self._current)
        end
        self:_to(self._current)
        if self.isdebug then
            global.debug.info(string.format("%s start [%s]", self._current.owner.uid, self._current.typeid))
        end

        if tick then
            self._ticktimer = global.service.timer:createtimer(self, source)
            self._ticktimer:_internal_add(0, tick, nil, self.update, nil)
        end
    end
end

function statemachine:getcurrent()
    return self._current
end

function statemachine:stop(immediate)
    if self._bstart and self._current then
        self._bstart = false
        if self._ticktimer then
            global.service.timer:destroytimer(self._ticktimer)
            self._ticktimer = nil
        end
        if immediate then
            self:_exit(self._current)
        else
            global.service.frame:afterframe(self._exit, self, self._current) -- 延迟退出
        end
        if self.isdebug then
            global.debug.info(string.format("stop [%s]", self._current.typeid))
        end
    end
end

function statemachine:update(time, tick)

    if self._current and self._bstart then

        local status = STATE_STATUS.SUSPEND

        if self._current.onupdate then
            status = self._current:onupdate(time, tick)
        end

        if status == STATE_STATUS.HOLD then return end

        local relation = self._relations[self._current]
        if relation == nil then
            global.debug.error(string.format("error, current statemachine %s relation is nil", self._current.typeid))
            return
        end

        local tostate = nil

        if status == STATE_STATUS.OVER then
            tostate = relation.tostate
        elseif status == STATE_STATUS.SUSPEND and relation.breakstates then

            for _, breakstate in ipairs(relation.breakstates) do
                if breakstate.onbreak and breakstate:onbreak(time, tick) then
                    tostate = breakstate
                    break
                end
            end
        end

        if tostate then
            self:_transfer(tostate, time)
        end
    end
end

function statemachine:_exit(exitstate, time)
    if exitstate.onexit then
        exitstate:onexit(time)
    end
end

function statemachine:_to(tostate, time)
    if tostate.onenter then
        tostate:onenter(time)
    end
end

function statemachine:_transfer(tostate, time)
    if self._current then
        if self.isdebug then
            global.debug.info(string.format("%s [%s -> %s] %s", self._current.owner.uid, self._current.typeid, tostate.typeid, time))
        end
        self:_exit(self._current, time)
        if self.onstatechange ~= nil then
            self.onstatechange(self._current, tostate)
        end
        self._current = tostate
        self:_to(self._current, time)
    end
end

local stateserver = {}

function stateserver:load()
    return statemachine()
end

function stateserver:unload(state)
    -- state:stop(true)
    state:destroy()
end

function stateserver:dump()
end

function stateserver:dispose()
end

return stateserver