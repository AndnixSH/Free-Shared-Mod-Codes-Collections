local logic = { event = service.event(), timer = {}, call = service.call(calldef.life) }

function logic:oncreate()
end

function logic.call:born(args)
    -- self:createlogic("sprite.basic.sprite_view_logic")
    if args.active then
        self.caller.view:start_active(args.active)
    end
end

function logic.call:prepared(args)
    self:createlogic("sprite.basic.sprite_buff_logic_v2")
    self:createlogic("sprite.basic.sprite_hp_b_logic")
    self:createlogic("sprite.basic.sprite_mp_logic")
    self:createlogic("sprite.basic.sprite_spd_logic")
    if args.ai then
        self:createlogic("sprite.basic.sprite_ai_logic")
    end
    self:createlogic("sprite.basic.sprite_state_logic")
    self:createlogic("sprite.basic.sprite_taunt_logic")

    if args.bufflist then
        for _, buffid in ipairs(args.bufflist) do
            self.caller.buff:add(buffid)
        end
    end
end

function logic.event.sprite:sprite_dead()
    self:freeze()
    self.area:remove_actor(self.owner)

    -- 如果是怪物死亡直接销毁 todo要移走
    if self.owner.body.spritetype == SPRITE_TYPE.MONSTER then
        self:sendmessage(eventdef.monster_dead, self.owner.body.position, self.owner.static.type)
        if global.game.gameid == GAMEPLAYID.HANGUP then
            self.owner:destroy()
        end
    end

end

function logic.event.game.public:gameclear()
    self:freeze()
end

function logic:freeze()
    -- print('freeze', self.owner)
    self.owner.body:setvelocity(tsvector.zero)
    if self.caller.ai then
        self.caller.ai:stop(true)
    end
    self.caller.state:stop(true)
end

return logic