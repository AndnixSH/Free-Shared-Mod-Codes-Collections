ConfigManager.InitConfig('data_tips', {

	--loading
    ["loading_tips"] = {
        [1] = "LoadingTips_1001",
        [2] = "LoadingTips_1002",
        [3] = "LoadingTips_1003",
        [4] = "LoadingTips_1004",
        [5] = "LoadingTips_1005",
        [6] = "LoadingTips_1006",

    },
    ["loading_tex"] = {
        [1] = {background = "Tex_Bg_1"},
    },

	--确认框
	--type 1 一个按钮 2 两个按钮 3 三个按钮
	--params: strContent, strLeft, strRight, strMiddle, strTitle, bclose, style, bclickBack(bclickBack: 点击空白处是否需要响应 :nil, true, :false )
	["confirm_tips"] = 
	{
		[1] = { type = 2, strContent = "confirm_tips_1001", strLeft = "Common_1042", strRight = "Common_1040",strTitle = "Common_1006" , bclickBack = false},
        [2] = { type = 2, strContent = "confirm_tips_1002", strLeft = "Common_1005", strRight = "Common_1004", strMiddle = "",strTitle = "Common_1006" },
        [3] = { type = 1, strContent = "confirm_tips_1023", strMiddle = "confirm_tips_1024",strTitle = "Common_1006"},
        [4] = { type = 2, strContent = "confirm_tips_1004", strLeft = "Common_1005", strRight = "Common_1004", strMiddle = "",strTitle = "Common_1006" },
        [5] = { type = 1, strContent = "confirm_tips_1009", strLeft = "", strRight = "", strMiddle = "HeroView_1004",strTitle = "Common_1006" },
        [6] = { type = 1, strContent = "confirm_tips_1010", strLeft = "", strRight = "", strMiddle = "Common_1036",strTitle = "Common_1006" },
        [7] = { type = 2, strContent = "confirm_tips_1011", strLeft = "Common_1005", strRight = "Common_1004", strMiddle = "",strTitle = "Common_1006" },
        [8] = { type = 2, strContent = "confirm_tips_1012", strLeft = "Common_1005", strRight = "Common_1004", strMiddle = "",strTitle = "Common_1006" },  
        [9] = { type = 2, strContent = "MailView_1015", strLeft = "Common_1005", strRight = "Common_1004", strMiddle = "",strTitle = "Common_1006" },
        [10] = { type = 2, strContent = "confirm_tips_1013", strLeft = "Common_1005", strRight = "Common_1004", strMiddle = "",strTitle = "Common_1006" },
        [11] = { type = 1, strContent = "confirm_tips_1014", strLeft = "", strRight = "", strMiddle = "Common_1004",strTitle = "Common_1006" },
        [12] = { type = 2, strContent = "confirm_tips_1015", strLeft = "Common_1005", strRight = "Common_1004", strMiddle = "",strTitle = "Common_1006" },
        [13] = { type = 2, strContent = "confirm_tips_1019", strLeft = "Common_1005", strRight = "Common_1004", strMiddle = "",strTitle = "Common_1006" },
        [14] = { type = 2, strContent = "Msgtips_Maze_1004", strLeft = "Common_1005", strRight = "Common_1004", strMiddle = "",strTitle = "Common_1006" },
        [15] = { type = 2, strContent = "Msgtips_Maze_1005", strLeft = "Common_1005", strRight = "Common_1004", strMiddle = "",strTitle = "Common_1006" },
        [16] = { type = 2, strContent = "confirm_tips_1020", strLeft = "Common_1005", strRight = "Common_1004", strMiddle = "",strTitle = "Common_1006" },
        [17] = { type = 1, strContent = "confirm_tips_1021", strMiddle = "Common_1039",strTitle = "Common_1006"},
        [18] = { type = 1, strContent = "CardPortalView_1004", strMiddle = "Common_1004",strTitle = "Common_1006"},
        [19] = { type = 1, strContent = "CardPortal_1007", strMiddle = "CardPortal_1008",strTitle = "Common_1006"},
        [20] =  { type = 2, strContent = "ChatView_1001", strLeft = "Common_1005", strRight = "Common_1004", strMiddle = "",strTitle = "Common_1006" },
        [21] =  { type = 2, strContent = "GuildView_1003", strLeft = "Common_1005", strRight = "Common_1004", strMiddle = "",strTitle = "Common_1006" }, --是否确定将会长职位禅让给%s？
        [22] =  { type = 2, strContent = "GuildView_1004", strLeft = "Common_1005", strRight = "Common_1004", strMiddle = "",strTitle = "Common_1006" }, --是否确定解散公会？
        [23] = { type = 1, strContent = "FormationTips_1001", strMiddle = "Common_1004",strTitle = "Common_1006", style= 2},
        [24] = { type = 1, strContent = "MercenaryTips_1001", strMiddle = "Common_1004",strTitle = "Common_1006"},
        [25] = { type = 2, strContent = "Quit_Tips_1001", strLeft = "Common_1005", strRight = "Common_1004",strTitle = "Common_1006" },
        [26] = { type = 1, strContent = "Sign_in_1005", strMiddle = "Common_1004",strTitle = "Common_1006", bclickBack = false},  --登陆失败 token过期
        [27] = { type = 1, strContent = "Sign_in_1006", strMiddle = "Common_1004",strTitle = "Common_1006", bclickBack = false},  --登陆失败 被封禁  
        [28] = { type = 1, strContent = "Sign_in_1007", strMiddle = "Common_1004",strTitle = "Common_1006", bclickBack = false},  --账号被封   
        [29] = { type = 1, strContent = "Sign_in_1008", strMiddle = "Common_1004",strTitle = "Common_1006", bclickBack = false},  --igg登陸失敗
        [30] = { type = 1, strContent = "Sign_in_1010", strMiddle = "Common_1004",strTitle = "Common_1006", bclickBack = false},  --踢人
        [31] =  { type = 2, strContent = "Msgtips_Maze_1007", strLeft = "Common_1005", strRight = "Common_1004", strMiddle = "",strTitle = "Common_1006" },
        [32] =  { type = 2, strContent = "TSH_1001", strLeft = "Common_1005", strRight = "Common_1004", strMiddle = "",strTitle = "Common_1006" },
        [33] = { type = 1, strContent = "ArenaView_1044", strMiddle = "Common_1004",strTitle = "Common_1006"},  --点击编队替换近几场已其他队已上阵的英雄
        [34] = { type = 2, strContent = "MallLimitView9", strLeft = "Common_1005", strRight = "MallLimitView10", strMiddle = "",strTitle = "MallLimitView2" }, --购买成长礼包
        [35] =  { type = 2, strContent = "Fountain_1010", strLeft = "Common_1005", strRight = "Common_1004", strMiddle = "",strTitle = "Common_1006" },
        [36] = { type = 1, strContent = "confirm_tips_1001", strLeft = "", strRight = "", strMiddle = "Common_1004",strTitle = "Common_1006", depth = 20002}, --1030到10001
        [37] = { type = 1, strContent = "confirm_tips_1001", strLeft = "", strRight = "", strMiddle = "Common_1004",strTitle = "Common_1006", depth = 20002}, --连接超时
        [38] = { type = 1, strContent = "ArenaView_1043", strMiddle = "Common_1004",strTitle = "Common_1006"}, --高阶是否卸下全部上阵英雄
        [39] = { type = 2, strContent = "FriendView_1037", strLeft = "Common_1005", strRight = "Common_1004", strMiddle = "",strTitle = "Common_1006" }, --删除好友
        [40] = {type =2 , strContent = "EquipmentEnhance_1006", strLeft = "Common_1005", strRight = "Common_1004", strMiddle = "", strTitle = "Common_1006"}, --强化选中传说材料提示
        [41] = { type = 2, strContent = "confirm_tips_1025", strLeft = "Common_1005", strRight = "Common_1004", strMiddle = "",strTitle = "Common_1006" },
        [42] = {type = 2, strContent = "MercenaryView_1006", strLeft = "Common_1005", strRight = "Common_1004",strTitle = "Common_1006"},
        [43] = {type = 2, strContent = "GuildView_1057", strLeft = "Common_1005", strRight = "Common_1004",strTitle = "Common_1006"}, --公会踢出成员
        [44] = {type = 2, strContent = "GuildView_1058", strLeft = "Common_1005", strRight = "Common_1004",strTitle = "Common_1006"}, --公会取消无畏之手
        [45] = {type = 2, strContent = "GuildView_1059", strLeft = "Common_1005", strRight = "Common_1004",strTitle = "Common_1006"}, --公会退出公会
        [46] = {type = 2, strContent = "ItemQuickUseView_02", strLeft = "Common_1005", strRight = "Common_1004",strTitle = "Common_1006"}, --确定一键使用背包中所有此类道具?
        [47] = {type = 2, strContent = "GuildView_1060", strLeft = "Common_1005", strRight = "Common_1004",strTitle = "Common_1006",style = 2}, --混沌裂隙进入战斗
        [48] = {type = 2, strContent = "GuildView_1061", strLeft = "Common_1005", strRight = "Common_1004",strTitle = "Common_1006"}, --混沌裂隙退出战斗
        [49] = {type = 2, strContent = "CardPortalWishView_1003", strLeft = "Common_1005", strRight = "Common_1004",strTitle = "Common_1006"}, --心愿单
        [50] = { type = 1, strContent = "MallPassView_1007", strLeft = "Common_1005", strRight = "Common_1004",strTitle = "MallPassView_1008" },
		[51] = {type = 2, strContent = "MainlineMultiple_1006", strLeft = "Common_1005", strRight = "Common_1004",strTitle = "Common_1006"}, --多队推图
        [52] = {type = 2, strContent = "CardPortalWishView_1005", strLeft = "Common_1005", strRight = "Common_1004",strTitle = "Common_1006"}, --占星英雄
        
		[53] = {type = 2, strContent = "MainlineMultiple_1002", strLeft = "Common_1005", strRight = "Common_1004",strTitle = "Common_1006"}, --多队推图替换英雄
		[54] = {type = 2, strContent = "MainlineMultiple_1007", strLeft = "Common_1005", strRight = "Common_1004",strTitle = "Common_1006"}, --多队推图替换编队英雄
        [55] = { type = 2, strContent = "confirm_tips_1002", strLeft = "Common_1005", strRight = "Common_1004", strMiddle = "",strTitle = "Common_1006" },
    
        [56] = {type = 2, strContent = "GuildView_1062", strLeft = "Common_1005", strRight = "Common_1004",strTitle = "Common_1006"}, --公会罢免副会长
        [57] = {type = 2, strContent = "Mall_Happymonth_1003", strLeft = "Common_1005", strRight = "Store_1004",strTitle = "Common_1006"}, --神魔狂欢
    },

    --消耗确定框 
    --params: strContent, strLeft, strRight, strTitle
    --[img]1[/img] 1为property索引
    ["cost_confirm_tips"] = 
    {
        [1] = { strContent = "confirm_tips_1003", property= {{701001,"zuanshi",0.9},}},--确定使用  [img]1[/img]  %s,购买%s个格子
        [2] = { strContent = "confirm_tips_1005", property= {{701001,"zuanshi",0.9},}},
        [3] = { strContent = "confirm_tips_1006", property= {{714001,"shuijing",0.9},}},
        [4] = { strContent = "confirm_tips_1007", property= {{714001,"shuijing",0.9},{701001,"zuanshi",0.9}}},
        [5] = { strContent = "confirm_tips_1008", property= {{701001,"zuanshi",0.9}}},
        [6] = { strContent = "confirm_tips_1016", property= {{701001,"zuanshi",0.9}}},
        [7] = { strContent = "confirm_tips_1017", property= {{701001,"zuanshi",0.9}}},
        [8] = { strContent = "confirm_tips_1018", property= {{701001,"zuanshi",0.9}}},
        [9] = { strContent = "confirm_tips_1022", property= {{701001,"zuanshi",0.9}}},
        [10] = { strContent = "confirm_tips_1026", property= {{701001,"zuanshi",0.9}}},
        [11] = { strContent = "Tree_view_1019", property= {{701001,"zuanshi",0.9}}, strTitle = "Tree_view_1012", show_type = 2}, --重置对应分支树
        [12] = { strContent = "Activityinfo_1032", property= {{701001,"zuanshi",0.9}}},
        
    },

	--规则框
    ["rule_tips"] = 
    { ----tipsType = 1 ContentTipsView tipsType = 2 ContentPageTipsView
        [1] = {
            title = "CardPortalWish_1001",
            context = {
                { strTitle = "CardPortalWish_1003" },
                { strTitle = "CardPortalWish_1004" },
                { strTitle = "CardPortalWish_1005" },
                { strTitle = "CardPortalWish_1006" },
                { strTitle = "CardPortalWish_1007" },
            },
        },
        [2] = {
            title = "迷宮",
            context = {
                { strTitle = "<size=28><color=#373d4b>当前勤奋值 :%s</color></size>" },
                { strTitle = "<color=#373D4B>1. 获得条件:</color>\n完成比赛+2分，获得MVP+3分，每连胜一次+1分，最高加5分。\n<color=#373D4B>2. 双倍星星:</color>\n勤奋值达到上限（100分），下一场胜利时，段位额外加1颗星，扣掉70分勤奋值。\n<color=#373D4B>3. 降级保护:</color>\n勤奋值大等于30时，若本局失败掉段，启动保护机制，保护此次不掉段。" },
            },
        },
        [3] = {
            title = "英雄列表",
            context = {
                { strTitle = "<size=28><color=#373d4b>当前勤奋值 :%s</color></size>" },
                { strTitle = "<color=#373D4B>1. 获得条件:</color>\n完成比赛+2分，获得MVP+3分，每连胜一次+1分，最高加5分。\n<color=#373D4B>2. 双倍星星:</color>\n勤奋值达到上限（100分），下一场胜利时，段位额外加1颗星，扣掉70分勤奋值。\n<color=#373D4B>3. 降级保护:</color>\n勤奋值大等于30时，若本局失败掉段，启动保护机制，保护此次不掉段。" },
            },
        },
        [4] = {
            title = "MainCommon_1009",
            context = {
                {
                    { strTitle = "StoryLine_1001" },
                    { strTitle = "StoryLine_1002" },
                    { strTitle = "StoryLine_1003" },
                    { strTitle = "StoryLine_1004" },
                },
                {
                  
                    { strTitle = "StoryLine_1005" },
                    
                },
            },
            toggleTitle = {"StoryLine_1006","StoryLine_1007"},
            tipsType = 2 ,
        },
        [5] = {
            title = "FullScreen_1025",
            context = {
                { strTitle = "RankList_1001" },
                { strTitle = "RankList_1002" },
                { strTitle = "RankList_1003" },
                { strTitle = "RankList_1004" },
                { strTitle = "RankList_1005" },
            },
            --tipsType = 1
        },
        [6] = { --公会boss
            title = "MainCommon_1012",
            context = {
                {
                    { strTitle = "MainSystemInfo_1009" },
                },
                {
                    { strTitle = "Boss_story_1001" },   
                },
            },
            toggleTitle = {"StoryLine_1006","StoryLine_1007"},
            tipsType = 2 ,
        },
        [7] = {--命运水晶
            title = "MainCommon_1013",
            context = {
                {
                    { strTitle = "MainSystemInfo_1017" },
                },
                {
                    { strTitle = "MainSystemStory_1014" },   
                },
            },
            toggleTitle = {"StoryLine_1006","StoryLine_1007"},
            tipsType = 2 ,
        },
        [8] = {--大圣堂
            title = "FullScreen_1007",
            context = {
                {
                    { strTitle = "MainSystemInfo_1013" },
                },
                {
                    { strTitle = "MainSystemStory_1012" },   
                },
            },
            toggleTitle = {"StoryLine_1006","StoryLine_1007"},
            tipsType = 2 ,
        },
        [9] = { --重置
            title = "FullScreen_1011",
            context = {
                {
                    { strTitle = "MainSystemInfo_1014" },
                },
                {
                    { strTitle = "MainSystemStory_1013" },   
                },
            },
            toggleTitle = {"StoryLine_1006","StoryLine_1007"},
            tipsType = 2 ,
        },
        [10] = { --遣散
            title = "FullScreen_1011",
            context = {
                {
                    { strTitle = "MainSystemInfo_1015" },
                },
                {
                    { strTitle = "MainSystemStory_1013" },   
                },
            },
            toggleTitle = {"StoryLine_1006","StoryLine_1007"},
            tipsType = 2 ,
        },
        [11] = { --回退
            title = "FullScreen_1011",
            context = {
                {
                    { strTitle = "MainSystemInfo_1016" },
                },
                {
                    { strTitle = "MainSystemStory_1013" },   
                },
            },
            toggleTitle = {"StoryLine_1006","StoryLine_1007"},
            tipsType = 2 ,
        },
        [12] = { --羁绊
            title = "FullScreen_1020",
            context = {
                {
                    { strTitle = "MainSystemInfo_1018" },
                },
                {
                    { strTitle = "MainSystemStory_1015" },   
                },
            },
            toggleTitle = {"StoryLine_1006","StoryLine_1007"},
            tipsType = 2 ,
         },
         [13] = { --位面幻境
            title = "MainCommon_1011",
            context = {
                { strTitle = "MainSystemInfo_1026" },
            },
         },
         [14] = { --生命古树
            title = "Tree_view_1001",
            context = {
                {
                    { strTitle = "MainSystemInfo_1028" },
                },
                {
                    { strTitle = "MainSystemStory_1019" },
                },
            },
            toggleTitle = {"StoryLine_1006","StoryLine_1007"},
            tipsType = 2 ,
         },
         [15] = { --混沌裂隙
            title = "Chaos_view_1001",
            context = {
                {
                    { strTitle = "MainSystemInfo_1027" },
                },
                {
                    { strTitle = "MainSystemStory_1018" },   
                },
            },
            toggleTitle = {"StoryLine_1006","StoryLine_1007"},
            tipsType = 2,
        },
        [16] = { --混沌裂隙段位奖励说明
            title = "Chaos_view_1001",
            context = {
                { strTitle = "MainSystemInfo_1029" },
            },
        },
        [17] = { --皇室嘉奖令
            title = "Mall_Pass_1002",
            context = {
                { strTitle = "MainSystemInfo_1030" },
            },
         },
        [18] = { --屠龙嘉奖令
            title = "Mall_Pass_1004",
            context = {
                { strTitle = "MainSystemInfo_1031" },
            },
         },
        [19] = { --混沌裂隙排行说明
            title = "Chaos_view_1001",
            context = {
                { strTitle = "MainSystemInfo_1033" },
            },
        },

        [20] = { --混沌嘉奖令
            title = "Mall_Pass_1006",
            context = {
                { strTitle = "MainSystemInfo_1032" },
            },
         },
        [21] = { --命运总动员说明
            title = "Activityinfo_2001",
            context = {
                { strTitle = "Mobilize_ActivityTips_1001" },
            },
        },
	},

    --文本描述框
    ["label_tips"] =
    {
        [1] = {strContent = "unity_tips_1001"},
        [2] = {strContent = "unity_tips_1002"},
        [3] = {strContent = "unity_tips_1003"},
        [4] = {strContent = "unity_tips_1004"},
        [5] = {strContent = "unity_tips_1005"},
        [6] = {strContent = "unity_tips_1006"},
        [7] = {strContent = "TaskView_1005"},
        [8] = {strContent = "Activityinfo_1004"},
        [9] = {strContent = "FriendView_1048"},
        [10] = {strContent = "GuildChaosRankView_1005"},
        [401001] = {strContent = "Good_info_401001"},
        [401002] = {strContent = "Good_info_401002"},
        [401011] = {strContent = "Good_info_401011"},
        [401021] = {strContent = "Good_info_401021"},
        [401031] = {strContent = "Good_info_401031"},
        [401041] = {strContent = "Good_info_401041"},
        [401051] = {strContent = "Good_info_401051"},
        [401061] = {strContent = "Good_info_401061"},
        [401071] = {strContent = "Good_info_401071"},
        [402011] = {strContent = "Good_info_402011"},
        [402021] = {strContent = "Good_info_402021"},
        [402031] = {strContent = "Good_info_402031"},
        [402041] = {strContent = "Good_info_402041"},
        [402051] = {strContent = "Good_info_402051"},
        [402061] = {strContent = "Good_info_402061"},
        [402071] = {strContent = "Good_info_402071"},
        [403011] = {strContent = "Good_info_403011"},
        [403012] = {strContent = "Good_info_403012"},
        [403021] = {strContent = "Good_info_403021"},
        [403022] = {strContent = "Good_info_403022"},
        [403031] = {strContent = "Good_info_403031"},
        [403032] = {strContent = "Good_info_403032"},
        [405011] = {strContent = "Good_info_405011"},
        [690001] = {strContent = "Good_info_690001"},
        [691001] = {strContent = "Good_info_691001"},
        [692001] = {strContent = "Good_info_692001"},
        [693001] = {strContent = "Good_info_693001"},
        [701001] = {strContent = "Good_info_701001"},
        [702001] = {strContent = "Good_info_702001"},
        [703001] = {strContent = "Good_info_703001"},
        [704001] = {strContent = "Good_info_704001"},
        [705001] = {strContent = "Good_info_705001"},
        [706001] = {strContent = "Good_info_706001"},
        [707001] = {strContent = "Good_info_707001"},
        [708001] = {strContent = "Good_info_708001"},
        [709001] = {strContent = "Good_info_709001"},
        [710001] = {strContent = "Good_info_710001"},
        [711001] = {strContent = "Good_info_711001"},
        [712001] = {strContent = "Good_info_712001"},
        [713001] = {strContent = "Good_info_713001"},
        [714001] = {strContent = "Good_info_714001"},
        [715001] = {strContent = "Good_info_715001"},     
        [720001] = {strContent = "Good_info_720001"},
        [694001] = {strContent = "Good_info_694001"},

    },
})