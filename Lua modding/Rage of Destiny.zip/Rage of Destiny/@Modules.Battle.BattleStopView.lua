local BattleProxy = require "Modules.Battle.BattleProxy"
local CampaignProxy = require "Modules.Campaign.CampaignProxy"

local BattleStopView = BattleStopView or LuaWidgetClass()

--需要隐藏"再次挑战"按钮的Activity
local restartHideActivityIds = {
	[ACTIVITYID.TRIAL] = true,
	[ACTIVITYID.ARENA] = true,
	[ACTIVITYID.HIGHARENA] = true,
	[ACTIVITYID.FRIEND_VERSUS] = true,
	[ACTIVITYID.GUILD_VERSUS] = true,
	[ACTIVITYID.GUILD_CHAOS] = true,
	[ACTIVITYID.SUPPLY_DEPOT] = true,
}

function BattleStopView:__init()
end

function BattleStopView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Battle.BattleStopView", self.LoadEnd)
end

function BattleStopView:LoadEnd(obj)
	self:SetGo(obj)
	self:InitUI()
	self:SetStep(0)
end

function BattleStopView:InitUI()
	self.stopInfoObj = self:GetChild(self.go, "Stop")
	self.stopInfoObj:SetActive(false)
    self.boxcollider = self:GetChildComponent(self.stopInfoObj, "Black", "CBoxCollider")
    self.boxcollider:AddClick(function(go)
        self:OnClickContinue()
    end)

	self.escBtn = self:GetChildComponent(self.stopInfoObj, "CHorizontalItem/item1", "CButton")
	self.escBtn:AddClick(function ()
		self:OnClickEsc()
	end)

	self.restartBtn = self:GetChildComponent(self.stopInfoObj, "CHorizontalItem/item2", "CButton")
	self.restartBtn:AddClick(function ()
		self:OnClickRestart()
	end)

	self.continueBtn = self:GetChildComponent(self.stopInfoObj, "CHorizontalItem/item3", "CButton")
	self.continueBtn:AddClick(function ()
		self:OnClickContinue()
	end)
end

--继续游戏
function BattleStopView:OnClickContinue()
	self.stopInfoObj:SetActive(false)
	BattleProxy.Instance:ContinusGame()
end

--退出游戏
function BattleStopView:OnClickEsc()
	local activityid

	if self.data and self.data.activityid then
		activityid = self.data.activityid
	end

	if activityid == ACTIVITYID.GUILD_CHAOS then
		GameLogicTools.ShowConfirmById2(48, function (bValue)
			if bValue then
				BattleProxy.Instance:EscGame()
			end
		end)
	else
		self.stopInfoObj:SetActive(false)

		if activityid == ACTIVITYID.MAINLINE then
			if SystemConfig.isIGGTestPlatform() then
				local SdkProxy = require "Modules.Sdk.SdkProxy"
				local SdkDef = require "Modules.Sdk.SdkDef"
				local mainlineid = RoleInfoModel.mainlineid
				local param = {}
				param.mission = mainlineid
				SdkProxy.Instance:sdk_logevent(SdkDef.firebase_event.Battle_Exit, param)
			end
		end
		
		self:EscGame()
	end
end	

function BattleStopView:EscGame()
	if self:IsMultiEnemy() then
		self:OnClickRestart()
	else
		BattleProxy.Instance:EscGame()
	end
end

function BattleStopView:IsMultiEnemy()
	if self.data and (self.data.activityid == ACTIVITYID.MAINLINE) then
		return CampaignProxy.Instance:HasExtraEnemy(RoleInfoModel.mainlineid)
	end
	return false
end

--重新开始
function BattleStopView:OnClickRestart()
	BattleProxy.Instance:RestartGame(self.data and self.data.enemyid)
end	

function BattleStopView:OnOpen()
	self:AutoRegister()
	self.stopInfoObj:SetActive(false)
	if self.data and self.data.activityid then
		local activityid = self.data.activityid
		if restartHideActivityIds[activityid] then
			self.restartBtn.gameObject:SetActive(false)
		else
			self.restartBtn.gameObject:SetActive(true)
		end
	else
		self.restartBtn.gameObject:SetActive(true)
	end
end

function BattleStopView:OnClose()
	self:AutoUnRegister()
	self.data=false
end

function BattleStopView:OnDestroy()
	self:AutoUnRegister()
	self.data=false
end

function BattleStopView:UpdateView(bactive)
	local depth = self:GetNextDepth()
	self.stopInfoObj:SetActive(bactive)
	self:SetOverrideSorting(self.stopInfoObj, bactive)
	self:SetDepth(self.stopInfoObj, depth)
	self:UpdateRestartBtn()
end

function BattleStopView:UpdateRestartBtn()
	local breport = BattleProxy.Instance:IsReportBattle()
	if self.data and self.data.activityid then
		local activityid = self.data.activityid
		if restartHideActivityIds[activityid] then
			self.restartBtn.gameObject:SetActive(false)
		else
			self.restartBtn.gameObject:SetActive(breport==false and true or false)
		end
	else
		self.restartBtn.gameObject:SetActive(breport==false and true or false)
	end
end

function BattleStopView.EvtNotify.Battle.data:StopGame(data, args)
	local bactive = args.bShow 
	self:UpdateView(bactive)
end

function BattleStopView.EvtNotify.Battle.data:BattleReport(data, args)
	self:UpdateRestartBtn()
end


return BattleStopView