local GameUIUtil = CS.GameUIUtil 
local ClistRender = ClistRender or BaseClass()
function ClistRender:Load(clist , itemClass)
	self.clist = clist
	self.clist:AddSetData(function (go ,data) self:SetData(go ,data) end)
	self.clist:AddSelect(function (go, index) self:OnSelectCallBack(go, index)	end)
	self.clist:AddDeSelect(function (go, index) self:OnDeSelectCallBack(go, index)	end)
	self.clist:AddAdhere(function (go ,index) self:OnAdhereCallBack(go ,index) end)
	-- self.clist:AddPositionChange(function (pos) self:OnPosChangeCallBack(pos) end)

	self.clist.renderPrefab.gameObject:SetActive(false)
	self.itemClass = itemClass
	self.contentRect = GameObjTools.GetComponent(self.clist.content, "RectTransform")

	self._obj_pool = {}	--value
	self.prefab_pool = {} --key obj ,value class
	self.poolCount = 0
	self.dataList = {}
	self.dirtyData = {} --含有一些为了实现表现的脏数据
	self.inTween = false
	self.enabled = true
end

function ClistRender:SetMaskShader()
	local viewport = GameObjTools.GetChild(self.clist.gameObject, "Viewport")
	GameObjTools.SetShader(viewport, "UI/UI_Mask", false)
end

function ClistRender:SetData(go , data)
	if self.prefab_pool[go] == nil then		
		if "table" == type(data) and data.isnil then
			go:SetActive(false)
		else	
			local class = self:NewItem(go)
			class.dataIdx = self:GetDataIdx(data)
			class.clist = self.clist
			self.prefab_pool[go] = class

			go:SetActive(true)
			if class.SetData then
				class:SetData(data)
			end
		end	
	else	
		if "table"  == type(data) and data.isnil then
			go:SetActive(false)
		else	
			local class = self.prefab_pool[go]		
			class.dataIdx = self:GetDataIdx(data)
			class.clist = self.clist
			
			go:SetActive(true)
			if class.SetData then
				class:SetData(data)
			end
		end	
	end		
end

function ClistRender:NewItem(go)
	local class = self.itemClass.New(go)	
	self.poolCount = self.poolCount + 1
	class.index = self.poolCount
	return class
end

function ClistRender:GetDataIdx(data)
	for idx,info in pairs(self.dataList) do
		if info == data then
			return idx
		end	
	end	
end

function ClistRender:OnSelectCallBack(go ,index)
	local selectIdx = index + 1
	if self.prefab_pool[go] then
		local class = self.prefab_pool[go]	
		class:OnSelect(selectIdx)
	end	

	if self.onSelect then		
		self.onSelect(self.prefab_pool[go] ,selectIdx)
	end
end

function ClistRender:OnDeSelectCallBack(go ,index)
	local selectIdx = index + 1
	if self.prefab_pool[go] then
		local class = self.prefab_pool[go]
		class:DeSelect(selectIdx)
	end	

	if self.onDeSelect then		
		self.onDeSelect(self.prefab_pool[go] ,selectIdx)
	end
end

function ClistRender:OnAdhereCallBack(go ,index)
	local curIdx = index + 1
	if self.clist.isScaleTween == true then 
		curIdx = curIdx + self.clist.scaleIdx
	end	

	if self.onAdhere and self.prefab_pool[go] then
		self.onAdhere(self.prefab_pool[go]  ,index + 1)
	end	
end

--对外接口
function ClistRender:GetClassOnIdx(index)
	for _,class in pairs(self.prefab_pool) do
		if class.index == index then
			return class
		end	
	end	
end

function ClistRender:ClearData(...)
	if not self.clist then return end
	self:SelectIndex(0)
	self.clist:ClearData()
	self:Close(...)
end

function ClistRender:ExecuteMethod(funcname, ...)
	for _,class in pairs(self.prefab_pool) do
		if class and class[funcname] then
			class[funcname](class, ...)
		end
	end	
end

function ClistRender:Close(...)
	for _,class in pairs(self.prefab_pool) do
		if class and class.Close then
			class:Close(...)
		end
	end		
	self:ClearOpenTween()
	-- self:ClearData()
end

function ClistRender:SelectIndex(idx)
	self.clist.SelectIndex = idx - 1
end

--开场动画要去掉
function ClistRender:GotoIndex(index, anim)
	local banim = false
	if anim or anim == nil then
		banim = true
	end	
	self.clist:GotoIndex(index - 1, banim)	
end

--开场动画要去掉
function ClistRender:ScrollTo(vec2, anim)
	local banim = false
	if anim or anim == nil then
		banim = true
	end	
	self.clist:ScrollTo(vec2, banim)
end

function ClistRender:DataChanged()
	self.clist:DataChanged(true)
end

--ScrollTo 动画时长
function ClistRender:SetEaseTime(easeTime)
	self.clist.easeTime = easeTime or 0.25
end

--只能添加list , 打开动画 btweenline = 几行动画,
function ClistRender:AppendDataList(list, btweenline)
	local dataList = list or {}	
	dataList = self:ScaleTweenDeal(dataList)	
	self.dataList = dataList
	-- self.clist:AppendDataList(dataList)	
	self.clist:AppendDataList(self.dirtyData)	

	--默认打开动画
	self:ClearOpenTween()
	if btweenline == nil or tonumber(btweenline) then
		self:ShowOpenLineTween(btweenline)
	end	
end

--只能添加list , 打开动画 btweenline = 几行动画,
function ClistRender:AppendDataList2(list, bgoto)

	local dataList = list or {}	
	dataList = self:ScaleTweenDeal(dataList)	
	self.dataList = dataList
	self.clist:AppendDataList(self.dirtyData,bgoto)	
end

--横向脏数据添加,例如 -1-1,1,2,3 显示
function ClistRender:ScaleTweenDeal(list)
	self.dirtyData = {}

	--防止脏数据重用
	if list and next(list) then
		for i = #list, 1, -1 do
			if "table" == type(list[i]) and list[i].isnil then
				table.remove(list, i)
			else
				table.insert(self.dirtyData ,1 ,list[i])	
			end	
		end		
	end	

	--吸附动画要前后添加空数据，否则选不中第一个
	if self.clist.isScaleTween == true then 
		for i = 1,self.clist.scaleIdx do
			local nilTab = { isnil = true}
			table.insert (self.dirtyData, i ,nilTab)
			table.insert (self.dirtyData, nilTab)
		end	
	end	

	return list
end

function ClistRender:AppendData(data)
	self.clist:AppendData(data)
end

function ClistRender:GetItemData(index)
	local selectIdx = index - 1
	return self.clist:GetItemData(selectIdx)
end

--取的数据源中符合判断的数据
function ClistRender:GetDataList(func,...)
	local tab = {}
	if self.dataList then
		for idx,data in pairs(self.dataList) do
			if not func or func(data,...) then
				local t = {}
				t.idx = idx
				t.data = data
				table.insert(tab, t)
			end	
		end
	end	
	return tab
end

--取的类中符合判断的类
function ClistRender:GetClassList(func, ...)
	local tab = {}
	if self.prefab_pool then
		for idx,data in pairs(self.prefab_pool) do
			if not func or func(data, ...) then
				table.insert(tab, data)
			end	
		end
	end	
	return tab	
end

--手动计算
function ClistRender:GetNewObj()
	if #self._obj_pool > 0 then
		local obj = self._obj_pool[#self._obj_pool]
		obj:SetActive(true)
		table.remove(self._obj_pool, #self._obj_pool)
		return obj
	end	
	local obj = GameObjTools.AddChild(self.clist.renderPrefab.transform.parent, self.clist.renderPrefab.gameObject)
	
	return obj
end

function ClistRender:ManualAddData(data)
	local newObj = self:GetNewObj()
	self:SetData(newObj , data)
	local pos = self:GetRenderPos(self.poolCount - 1)
	local vec = Vector2.New(0,1)
	GameObjTools.SetRectTransform(newObj ,nil ,pos ,vec ,vec ,vec)
	self:SetContentSize(self:GetRenderPos(self.poolCount))
end

function ClistRender:GetRenderPos(index)
	local posx = self.clist.leftTop.x
	local posy = - self.clist.leftTop.y

	--一行
	if self.clist.columns == 0 then
		posx = posx + (self.clist.ItemWidth + self.clist.pad.x) * index

	--一列
	elseif self.clist.columns == 1 then
		posy = posy + (self.clist.ItemHeight + self.clist.pad.y) * index

	--多列	
	else
		posx = posx + math.fmod(index , self.clist.columns) * (self.clist.ItemWidth + self.clist.pad.x)
		posy = posy - math.floor(index / self.clist.columns) * (self.clist.ItemHeight + self.clist.pad.y);		
	end	
	return Vector2.New(posx ,posy)
end

--size : vec2
function ClistRender:SetContentSize(size)
	self.clist.content.sizeDelta = size
end

function ClistRender:SetContentSizeOffset(size)
	self.clist.content.sizeDelta = self.clist.content.sizeDelta + size
end

function ClistRender:ManualClearData()
	for obj,class in pairs(self.prefab_pool) do
		obj:SetActive(false)
		table.insert(self._obj_pool, obj)
	end

	self.prefab_pool = {}
	self.poolCount = 0	
end

--Tween
--一行行显示
function ClistRender:ShowOpenLineTween(line)
	--如果滑块移动过,则不要动画,否则有冲突
	local movepos = self.contentRect.anchoredPosition
	if movepos.x > self.clist.ItemWidth / 2 or movepos.y > self.clist.ItemHeight / 2 then
		return
	end	

	local movetime = 0.4
	local delaytime = 0.1
	local movey = -80
	local columns = self.clist.columns
	local curcount = 0
	local addcount = 0
	local curline = 0
	local maxline = line or 5

	if columns > 0  then	
		self.clist.enabled = false
		self.inTween = true

		for obj,class in pairs(self.prefab_pool) do
			curcount = curcount + 1
		end	

		if curcount > maxline * columns then
			curcount = maxline * columns
		end

		local sequence = DOTween.Sequence()
		for obj,class in pairs(self.prefab_pool) do			
			local index = class.index - 1	
			local line = math.modf((index) / columns)
			if line <= maxline then										
				local posx = self.clist.leftTop.x + math.fmod(index , self.clist.columns) * (self.clist.ItemWidth + self.clist.pad.x) + self.clist.ItemWidth / 2
				local posy = - self.clist.leftTop.y	 - math.floor(index / self.clist.columns) * (self.clist.ItemHeight + self.clist.pad.y) - self.clist.ItemHeight / 2

				local curpos = Vector2.New(posx, posy)
				local startpos = curpos + Vector2.New(0, movey)
				obj.transform.localPosition = startpos
				GameUIUtil.SetGroupAlpha(obj ,0)

				local tweenObj, time, topos = obj, movetime, curpos
				local tween = tweenObj.transform:DOLocalMove(topos, time)	
				tween:SetEase(Ease.OutBack)
				tween:OnComplete(function ()
						local line = math.modf((index) / columns)
						addcount = addcount + 1
						if addcount == curcount then						
							self:ClearOpenTween()						
						end	
					end)	
				sequence:Insert(delaytime * line, tween)
				sequence:InsertCallback(delaytime * line, function ()
					GameUIUtil.SetGroupAlphaInTime(tweenObj ,1 ,time)
				end)		
			else
				GameUIUtil.SetGroupAlpha(obj ,1)	
			end	
		end
		self.openSequence = sequence
	end
end

--一个个显示
function ClistRender:ShowOpenOrderTween(line)
	local movetime = 0.4
	local delaytime = 0.2
	local movey = -80
	local columns = self.clist.columns
	local curcount = 0
	local addcount = 0
	local curline = 0
	local maxline = line or 5

	if columns > 0  then	
		self.clist.enabled = false
		self.inTween = true

		for obj,class in pairs(self.prefab_pool) do
			curcount = curcount + 1
		end	

		if curcount > maxline * columns then
			curcount = maxline * columns
		end

		local sequence = DOTween.Sequence()
		for obj,class in pairs(self.prefab_pool) do			
			local index = class.index - 1	
			local line = math.modf((index) / columns)
			if line <= maxline then
				GameUIUtil.SetGroupAlpha(obj ,0)
				sequence:InsertCallback(delaytime * index, function ()
					GameUIUtil.SetGroupAlphaInTime(obj ,1 ,movetime)
				end)		
			else
				GameUIUtil.SetGroupAlpha(obj ,1)	
			end	
		end
		self.openSequence = sequence
	end	
end

function ClistRender:ClearOpenTween()
	self.inTween = false
	if self.enabled then
		self.clist.enabled = true
	end	
	if self.openSequence then
		self.openSequence:Kill()
		self.openSequence = nil		
	end	
end

---------------

function ClistRender:Destroy()
	if self.clist then
		self.clist:RemoveSetData()
		self.clist:RemoveSelect()
		self.clist:RemoveDeSelect()
		self.clist:RemoveAdhere()
	end
	for _,class in pairs(self.prefab_pool) do
		if class and class.Destroy then
			class:Destroy()
		end
	end	

	self.inTween = false
	self.itemClass = nil
	self.clist = nil
	self.prefab_pool = nil
	self._obj_pool = nil
	self:DeleteMe()
end

--增加事件
function ClistRender:AddSelect(func)
	self.onSelect = func
end

function ClistRender:AddDeSelect(func)
	self.onDeSelect = func
end

function ClistRender:AddAdhere(func)
 	self.onAdhere = func
end 

function ClistRender:OnPosChangeCallBack(pos)
	if self.onChange then
		self.onChange(pos)
	end	
end

function ClistRender:AddPositionChange(func)
	self.clist:AddPositionChange(function (pos) self:OnPosChangeCallBack(pos) end)
 	self.onChange = func
end

function ClistRender:SetEnable(beanble)
	self.enabled = beanble
	self.clist.enabled = beanble
end

return ClistRender