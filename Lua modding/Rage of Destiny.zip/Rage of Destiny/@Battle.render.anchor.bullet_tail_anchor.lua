local bullet_tail_anchor = BaseClass()

local cBulletTailAnchor = CS.LJY.NX.BulletTailAnchor

function bullet_tail_anchor:__init(sprite_id)
    self.canchor = cBulletTailAnchor(sprite_id)
end

function bullet_tail_anchor:__delete()
    if self.canchor then
        self.canchor = nil
    end
end

return bullet_tail_anchor