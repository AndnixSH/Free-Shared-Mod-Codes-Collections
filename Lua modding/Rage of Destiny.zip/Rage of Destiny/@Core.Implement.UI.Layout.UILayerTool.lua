UILayerTool = UILayerTool or {}

local RectTransformUtility = CS.UnityEngine.RectTransformUtility
local Screen = CS.UnityEngine.Screen
local Input = CS.UnityEngine.Input
local isEditor = CS.UnityEngine.Application.isEditor

UILayerTool.STANDARD_WIDTH = 1334
UILayerTool.STANDARD_HEIGHT = 750
UILayerTool.STANDARD_RATE = UILayerTool.STANDARD_WIDTH / UILayerTool.STANDARD_HEIGHT --标准分辨率比
UILayerTool.CurrentRate = Screen.width / Screen.height

UILayerTool.UICamera = nil
UILayerTool.UIRoot = nil

UILayerTool.UIRootRect = nil
UILayerTool.EventSystem = CS.UnityEngine.EventSystems.EventSystem
local worldCamera = Camera.main
local CanvasDepth = 10
local ObjZDepth = 0

--限制屏幕位置
local function ClampScreenPosition(position)
	if position.x > Screen.width then
		position.x = Screen.width
	elseif position.x < 0 then
		position.x = 0
	end	

	if position.y > Screen.height then
		position.y = Screen.height
	elseif position.y < 0 then
		position.y = 0
	end	

    return position
end

--UI适配
local function UIAdaptation()
	local rect = GameObjTools.GetComponent(UILayerTool.UIRoot , "RectTransform")

	rect.localPosition = Vector2.New(-1000 ,0) --偏移，否则照射到未初始化物体	

	local scaler = GameObjTools.GetComponent(UILayerTool.UIRoot, "CanvasScaler")
	if UILayerTool.STANDARD_RATE > rect.rect.width / rect.rect.height then
		scaler.matchWidthOrHeight = 0
	else
		scaler.matchWidthOrHeight = 1
	end

	local canvas = GameObjTools.GetComponent(UILayerTool.UIRoot , "Canvas")
	canvas.sortingOrder = 1	

	UILayerTool.UIRootRect = rect
end

function UILayerTool.Init()
	if UILayerTool.UICamera == nil then
		local obj = GameObjTools.GetGameObjectByFind("UICamera")
		if obj then
			UILayerTool.UICamera = GameObjTools.GetComponent(obj,"Camera")
			UILayerTool.UICamera.depth = 1
			obj.transform.localPosition = Vector3(0, 0, -30000)
		end		
	end	

	if UILayerTool.UIRoot == nil then
		UILayerTool.UIRoot = GameObjTools.GetGameObjectByFind("UIRoot")

		--if CS.UnityEngine.Application.isEditor then
		--	local childs = GameObjTools.GetComponentsInChildren(UILayerTool.UIRoot, "Transform")
		--	for k,trans in pairs(childs) do
		--		if trans ~= UILayerTool.UICamera.transform and not string.find(trans.name, "UpdateView") then
		--			GameObjTools.Destroy(trans.gameObject)
		--		end
		--	end
		--end

		UIAdaptation()
	end	
end

function UILayerTool.Screen()
	return Screen
end

function UILayerTool.CurrentScreen()
	if UILayerTool.UIRootRect then
		return UILayerTool.UIRootRect.rect
	else
		return Screen
	end	
end

--判断世界坐标对象是否存在于屏幕上
function UILayerTool.IsExitScreenByWorldPos(worldPos)
	local viewportPoint =  UILayerTool.WorldToViewportPoint(worldPos)
	if not viewportPoint then return end
	--保留差值
	local offset = 0
	if viewportPoint.x > (1 + offset) or viewportPoint.x < (-offset) then
		return false
	elseif viewportPoint.y < (-offset) or viewportPoint.y > (1 + offset) then
		return false							
	else
		return true
	end			
end

function UILayerTool.GetUICameraWorldPosByCameraScreenPos(cameraScreenPos)

	return UILayerTool.UICamera:ScreenToWorldPoint(cameraScreenPos)
end


function UILayerTool.GetCameraScreenPosByUIScreenPos(uiScreenPos)

	--local worldCamera = Camera.main
	return Vector3.New( worldCamera.pixelWidth* uiScreenPos.x/ UILayerTool.STANDARD_WIDTH + worldCamera.pixelWidth/2, worldCamera.pixelHeight * uiScreenPos.y / UILayerTool.STANDARD_HEIGHT + worldCamera.pixelHeight / 2,0)

end

--世界坐标转屏幕坐标
function UILayerTool.WorldToScreenPoint(worldPos)
	-- local cameraScreenPos = worldCamera:WorldToScreenPoint(worldPos)
	-- local retVec = Vector3.New( cameraScreenPos.x - worldCamera.pixelWidth / 2,  cameraScreenPos.y - worldCamera.pixelHeight / 2, 0)
	-- local uiScreenPos = Vector3.New( UILayerTool.STANDARD_WIDTH  * retVec.x / worldCamera.pixelWidth,
	-- 	 UILayerTool.STANDARD_HEIGHT * retVec.y / worldCamera.pixelHeight, 0)
	local cameraScreenPos = worldCamera:WorldToScreenPoint(worldPos)
	local screenPos = UILayerTool.ScreenRateToScreenPoint(cameraScreenPos)
	local screen = UILayerTool.CurrentScreen()
	local uiScreenPos = Vector3.New(screenPos.x - screen.width / 2, screenPos.y - screen.height / 2, 0)
	return uiScreenPos
end	

--屏幕坐标转世界坐标
function UILayerTool.ScreenToWorldPoint(screenPos, plane)
	-- local UICamera = UILayerTool.UICamera
	-- local hitPosition = ClampScreenPosition(screenPos)
 --    local worldPosition = UICamera:ScreenToWorldPoint(Vector3.New(hitPosition.x, hitPosition.y ,0))
 --    return worldPosition

 	--local worldCamera = Camera.main
 	local ray = worldCamera:ScreenPointToRay(screenPos)
 	local dir = ray.direction
 	if dir.y == 0 then return Vector3.zero end
 	local num = (plane - ray.origin.y) / dir.y
	return ray.origin + ray.direction * num
end

--世界坐标转视窗坐标
function UILayerTool.WorldToViewportPoint(worldPos)
	--local worldCamera = Camera.main
	if not worldCamera then return end
	local viewportPoint = worldCamera:WorldToViewportPoint(worldPos)
	return viewportPoint
end	

--Screen坐标(unity的屏幕分辨率比) 转 实际屏幕坐标
function UILayerTool.ScreenRateToScreenPoint(position)
	local x = position.x / Screen.width * UILayerTool.CurrentScreen().width
	local y = position.y / Screen.height * UILayerTool.CurrentScreen().height
	return Vector3.New(x, y)
end

function UILayerTool.InitDepth()
	CanvasDepth = 10
	ObjZDepth = 0
end

function UILayerTool.InitZDepth(value)
	value = value or 0
	ObjZDepth = value
end

function UILayerTool.GetNextDepth(addnext)
	CanvasDepth = CanvasDepth + (addnext and addnext or 1)
	return CanvasDepth
end

function UILayerTool.GetCurrentDepth()
	return CanvasDepth
end

function UILayerTool.SetZDepth(depth)
	ObjZDepth = depth
end

function UILayerTool.GetNextZDepth()
	ObjZDepth = ObjZDepth + 1200
	return ObjZDepth
end

function UILayerTool.GetCurrentZDepth()
	return ObjZDepth
end

function UILayerTool.UpdateCanvases()
	CS.UnityEngine.Canvas.ForceUpdateCanvases()
end

function UILayerTool.GetInputScreenPosition()
	local position = Vector2.zero
	if isEditor then
		position = Input.mousePosition			
	elseif Input.touchCount >= 1 then
		local touch = Input.touches[0]
        position = Input.touches[0].position
	end 
	local screenPos = UILayerTool.ScreenRateToScreenPoint(position)
	local screen = UILayerTool.CurrentScreen()
	return Vector2.New(screenPos.x - screen.width / 2, screenPos.y - screen.height / 2, 0)
end

--logic
function UILayerTool.GetSpriteScreenPos(spriteid)
	local spritedata = global.service.readonly:reader(spriteid)
	if spritedata then
		local position = spritedata.body.position
		local worldPos = Vector3.New(position.x / 1000, 0.5, position.y / 1000)
		local screenPos = UILayerTool.WorldToScreenPoint(worldPos)
		return screenPos
	end
end

function UILayerTool.GetInputPosition()
	local position = nil
	if isEditor then
		position = Input.mousePosition
	elseif Input.touchCount > 0 then
		position = Input.touches[0].position
		position = Vector3.New(position.x, position.y, 0)
	end
	return position
end
