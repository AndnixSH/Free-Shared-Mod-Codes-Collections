local FriendDef = {}

FriendDef.FriendTabType = {
	[1] = {key = "FriendView_1004", icon = "friendlogo", level = 0, view = "FriendListItemPanel", netStep = 1},   --level :等级开启
	[2] = {key = "FriendView_1013", icon = "yongbinglogo", level = 0, view = "HireHeroListItemPanel", netStep = 1},   --level :等级开启
}

FriendDef.Notify = {
	UpdateFriendList = "UpdateFriendList",
	UpdateSearchList = "UpdateSearchList",
	UpdateApplyList = "UpdateApplyList",
	UpdateBlackList = "UpdateBlackList",
	UpdateSendIntimacy = "UpdateSendIntimacy",  --赠送爱心刷新
	UpdateGetIntimacy = "UpdateGetIntimacy", --领取爱心刷新

	UpdateSendApplyList = "UpdateSendApplyList",
	UpdateFriendSortType = "UpdateFriendSortType",

}

--翻译文本key
FriendDef.LanguageKey = {
	FriendBlacklist = "FriendView_1005",
	FriendReport = "FriendView_1006",
}

FriendDef.OperateType = {
	--公会和好友公用一个小弹窗 类型错开
	FriendBlacklist = 101, --好友拉黑
	FriendReport = 102, --好友举报
}

--操作類型 , 操作名稱翻譯, 方法名
FriendDef.OperateTab = {
	{FriendDef.OperateType.FriendBlacklist, FriendDef.LanguageKey.FriendBlacklist, "FriendBlacklist"},
	{FriendDef.OperateType.FriendReport, FriendDef.LanguageKey.FriendReport, "FriendReport"},
}

return FriendDef