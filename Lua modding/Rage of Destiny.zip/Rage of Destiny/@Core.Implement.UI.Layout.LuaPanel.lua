LuaPanel = LuaPanel or BaseClass()

function LuaPanel:__init(widget, name)
    self.widget = widget
    self.name = name
    self.isopen = false
end

function LuaPanel:__delete()
end

function LuaPanel:IsOpen()
    return self.isopen
end

function LuaPanel:Open()
    --if not self.isopen then
        self.isopen = true
		LuaLayout.Instance:OnOpenPanel(self.widget, self.name)
    --end
end

function LuaPanel:Close()
    if self.isopen then
        self.isopen = false
		LuaLayout.Instance:OnClosePanel(self.widget, self.name)
    end
end

