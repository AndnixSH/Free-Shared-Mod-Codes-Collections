
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local DateFormatUtil = require "Common.Util.DateFormatUtil"
local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
local RedPointDef = require "Modules.RedPoint.RedPointDef"
local RealmDef = require "Modules.Realm.RealmDef"
local HexMapProxy = require "Modules.HexMap.HexMapProxy"
local StoryLineDef = require "Modules.StoryLine.StoryLineDef"
local RealmProxy = RealmProxy or BaseClass(BaseProxy)

local hexproto = {
    open = 63004,  -- 打开格子
    done = 63005,  -- 完成格子
    move = 63003,  -- 移动
    hero = 63007,  -- 英雄
    rune = 63008,  -- 符文
    hero_to_battle = 63010 -- 英雄上阵
}
function RealmProxy:__init()
    RealmProxy.Instance = self

    self:AddProto(63000, self.On63000)
    self:AddProto(63001, self.OnCopyInfo)
    self:AddProto(63002, self.On63002)
	--self:AddProto(54007, self.OnHeroList)
    self:AddProto(63006, self.OnGuideInfo)
    self:AddProto(63009, self.OnEndCopy)
    self:AddProto(63011, self.OnComplete)
    self.data = { curpos = 0 }

    self.data = {}
    self.data.copyList = {}
    self.enterCopyId= 0
end

function RealmProxy:__delete()
    RealmProxy.Instance = nil
end

function RealmProxy:OnComplete(decoder)

    self:ToNotify(self.data,RealmDef.NotifyDef.Activity_Complete)
end

function RealmProxy:Send63000()
    --请求活动副本列表相关信息
    --open 0 未开启，1开启，2过期(过期的可以不发过来，开启需要及时吗，比如刚登录未开启，在游戏里开启时间到了 ，或者登录游戏是开启的，在游戏里的时候时间到了)
    --endtime
    self:SendMessage(63000)
end

function RealmProxy:On63000(decoder)
    local curcopyid,count = decoder:Decode("I2I2")
    local copyList = {}

    local showred = false
    for i = 1, count do
        local id, open,opentime,endtime = decoder:Decode("I2I1I4I4")
        local senior={}
        local general={}
        senior.rewards= decoder:DecodeList("I1") --获得奖励的索引
        general.rewards= decoder:DecodeList("I1") --获得奖励的索引
        
       
        local cfg=self:GetMapConfig(id)
        local seniorcount=#senior.rewards
        local generalcount=#general.rewards
        local  progress_str,progress=self:GetOneCopyProgress(id,seniorcount,generalcount)
        local item={}
        item.id=id
        item.open= open 
        --item.progress=progress  
        item.senior= senior 
        item.general= general
        item.name=LanguageManager.Instance:GetWord( cfg and cfg.name or "")
        item.artifactid = cfg and cfg.artifact
        item.opentime = opentime
        item.endtime = endtime
        item.dec = LanguageManager.Instance:GetWord(cfg and cfg.info or "")
        table.insert(copyList,item)
        local red = 0
        if progress < 1 then
            red = 1
        end
        if not self:IsTheSameToday(id) and open == 1 then
            if red == 1 then
                showred =true
            end
            RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.Realm,tostring(id),red)
        else
            RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.Realm,tostring(id),0)
        end
    end
    local ModuleManager = require "Common.Mgr.UI.ModuleManager"
	local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
    local systemopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.RealmRootView,false)
    if showred and systemopen then
        RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.Realm2,1)
    else
        RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.Realm2,0)
    end
    
    table.sort(
        copyList,
        function(a, b) --排序
            return a.id < b.id
        end
    )
    self.data.curcopyid=curcopyid
    self.data.copyList=copyList
    self:ToNotify(self.data,RealmDef.NotifyDef.UpdateActivityInfo,{curcopyid = curcopyid,copyList = copyList})
end

function RealmProxy:SaveLoginTime(type)

    PlayerPrefs.SetInt(tostring(RoleInfoModel.guserid).."Realm"..tostring(type),RoleInfoModel.servertime)
 end
 function RealmProxy:GetLoginTime(type)
     return PlayerPrefs.GetInt(tostring(RoleInfoModel.guserid).."Realm"..tostring(type))
 end

function RealmProxy:IsTheSameToday(type)
    local last_login_time = self:GetLoginTime(type)
    local DateFormatUtil = require "Common.Util.DateFormatUtil"
    local date_a = DateFormatUtil.Date("*t",last_login_time) -- os.date("*t", last_login_time)
    local date_b =DateFormatUtil.Date("*t",RoleInfoModel.servertime)-- os.date("*t", RoleInfoModel.servertime)

    return date_a.day == date_b.day and date_a.month == date_b.month and date_a.year == date_b.year
 end

-- 请求副本信息
function RealmProxy:RequireCopyInfo(copyid)
    local encoder = NetEncoder.New()
    encoder:Encode("I2", copyid)
    self:SendMessage(63001, encoder)
end

function RealmProxy:OnCopyInfo(decoder)
    local result,copyid = decoder:Decode("I1I2")
    if result == 0 then

        local senior = {}
        senior.rewards = decoder:DecodeList("I1")

        local general = {}
        general.rewards = decoder:DecodeList("I1")

        local cfg=self:GetMapConfig(copyid)
        local  progress=self:GetOneCopyProgress(copyid,#senior.rewards,#general.rewards)
        local copy = {}
        copy.id = copyid
        copy.senior = senior
        copy.general = general
        copy.name = LanguageManager.Instance:GetWord(cfg and cfg.name or "")
        copy.dec = LanguageManager.Instance:GetWord(cfg and tostring(cfg.info) or "")
        copy.progress = progress
        copy.artifactid = cfg and cfg.artifact or nil

       -- print("OnCopyInfo", table.dump(copy))
       self:ToNotify(self.data,StoryLineDef.NotifyDef.Update_CopyInfo,copy)
    else
        GameLogicTools.ShowErrorCode(63001,result)
    end
end


-- 请求地图信息
function RealmProxy:Send63002(copyid, reenter)
    self.data.reenter = reenter
    local encoder = NetEncoder.New()
    encoder:Encode("I2", copyid)
    self:SendMessage(63002, encoder)
end

function RealmProxy:On63002(decoder)
    local result = decoder:Decode("I1")
    if result == 0 then
        local copyid, curpos, dark_mode, unread, map_buffer = decoder:Decode("I2I2I1I1s2")
         --print("On63002", copyid, curpos, dark_mode, unread, #map_buffer)
        self.data.curpos = curpos
        self.enterCopyId=copyid
        self.data.curcopyid = copyid
        local map_config = self:GetMapConfig(copyid)
        local cell_config = self:_GetCellsConfig(copyid)
    
        local cellinfos, decoder = HexMapProxy:DecodeCellInfos(map_buffer, cell_config)
    
        HexMapProxy.Instance:SetCellProxy(ACTIVITYID.ACTIVITY, self, hexproto)

        RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.StoryLineLog,unread)
        local SceneManager = require "Modules.Scene.SceneManager"
        local SceneDef = require "Modules.Scene.SceneDef"
        local tab={reenter=self.data.reenter,copyid=copyid,map_config=map_config,cell_config=cell_config,celldata={cellinfos = cellinfos, buildshare = { dark_mode = dark_mode }},curpos=curpos}
        SceneManager.Instance:EnterScene(SceneDef.SceneType.Activity,tab) --副本id与索引是一致的
    else
        GameLogicTools.ShowErrorCode(63002,result)
    end
end

function RealmProxy:GetCurCopyId()

    return self.data.curcopyid
end

function RealmProxy:GetCopySeniorAwardCfg(copyid)
    local cfg=self:GetMapConfig(copyid)
    if cfg then
        return cfg.senior_award
    end
end

function RealmProxy:GetCopyGeneralAwardCfg(copyid)
    local cfg=self:GetMapConfig(copyid)
    if cfg then
        return cfg.general_award
    end
end

function RealmProxy:GetOneCopyProgress(id,seniorcount,generalcount)
    local gf=3
    local sf=1
    local seniorawardlist=self:GetCopySeniorAwardCfg(id)
    local generalawardlist=self:GetCopyGeneralAwardCfg(id)
    local  progress=(seniorcount*gf+generalcount*sf)*1.0/( (seniorawardlist and #seniorawardlist or 1) * gf + (generalawardlist and #generalawardlist or 1) * sf )
    local progress_str = progress == 0 and "0" or string.format("%.3f",progress)
    return progress_str , progress
end

function RealmProxy:GetRemainAaward(copyid,bgeneral )
    local data =self:GetCopyInfoByCopyId(copyid)
    local tab={}
    local awardlist={}
    local getaward={}
    if not data then
        return awardlist
    end
    if bgeneral then
        awardlist=self:GetCopyGeneralAwardCfg(copyid)
        getaward=data.general and data.general.rewards or {}
       
    else
        awardlist=self:GetCopySeniorAwardCfg(copyid)
        getaward=data.senior and data.senior.rewards or {}
    end
    if awardlist and getaward then
        for i=1, #awardlist do
            local hasget=false
            for k,id in pairs(getaward) do
                if i == id then
                    hasget=true
                    break
                end
            end
            if not hasget then
                table.insert(tab,{id=awardlist[i][1],num=awardlist[i][2]})
            end
        end
    end
    return tab
end

function RealmProxy:GetActivityCopyOpenTime()
    local time = false
    if self.data.copyList then
        if #self.data.copyList > 0 then
            for _,v in ipairs(self.data.copyList) do
                if v then
                    if v.open == 0 then
                        if not time then
                            time = v.opentime
                        else
                            if time < v.opentime then
                                time = v.opentime
                            end
                        end
                    end
                end
            end
        end
    end
    return time
end

function RealmProxy:GetActivityCopyEndTime()
    local time = false
    if self.data.copyList then
        if #self.data.copyList > 0 then
            for _,v in ipairs(self.data.copyList) do
                if v then
                    if v.open == 1 then
                        if not time then
                            time = v.endtime
                        else
                            if time < v.endtime then
                                time = v.endtime
                            end
                        end
                    end
                end
            end
        end
    end
    return time
end

function RealmProxy:CheckExistActivityCopy()
    if self.data.copyList then
        if #self.data.copyList > 0 then
            for _,v in ipairs(self.data.copyList) do
                if v then
                    if v.open == 1 then
                        local curtime = RoleInfoModel.servertime
                        local diff = os.difftime(v.endtime ,curtime)
                        if diff > 0 then
                            return true
                        end
                    end
                end
            end
        end
        return false
    end
    return false
end

function RealmProxy:GetCopyInfoByCopyId(copyid)
    if self.data.copyList then
        for _, v in ipairs(self.data.copyList) do
            if v then
                if v.id == copyid then
                    return v
                end
            end
        end
    end
end

function RealmProxy:GetCopyList()
    if self.data.copyList then
        return self.data.copyList
    end
end

function RealmProxy:SetEnterCopyId(copyid)
    self.enterCopyId = copyid
end

function RealmProxy:GetEnterCopyId()
    return self.enterCopyId
end
function RealmProxy:UpdateFullScreenTitle(copyid)

    if self.data.copyList then
        local  data = RealmDef.BigTitleList[copyid] or RealmDef.BigTitleList[1]
        self:ToNotify(self.data,RealmDef.NotifyDef.UpdateActivityTitle,{name = LanguageManager.Instance:GetWord(data[1]) , explainContentId = data[2]})
    end
end

function RealmProxy:GetMapConfig(copyid)
    local config = ConfigManager.GetConfig("data_realm")
    return config[copyid]
end

function RealmProxy:_GetCellsConfig(copyid)
    local config = ConfigManager.GetConfig("data_realm_cell_" .. copyid)
    return config
end


function RealmProxy:Send63006(copyid)
    self:SendMessage(63006)
end

function RealmProxy:OnGuideInfo(decoder)
    local guide_list = {}
    local count = decoder:Decode("I2")
    for i = 1, count do
        local id, time = decoder:Decode("I2I4")
        table.insert(guide_list, { id = id, time = time })
    end
    table.sort(guide_list, function(a,b)
		return a.time > b.time
	end)
    local HexMapUI = require "Modules.HexMap.HexMapUI"
    HexMapUI.OpenWidget(UIWidgetNameDef.HexNPCLogView,guide_list)
    RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.StoryLineLog,0)
end
-- 结束副本
function RealmProxy:RequireEndCopy(copyid)
    local encoder = NetEncoder.New()
    encoder:Encode("I2", copyid)
    self:SendMessage(63009,encoder)
end

function RealmProxy:OnEndCopy(decoder)
    local result = decoder:Decode("I1")
    local view=LuaLayout.Instance:GetWidget(UIWidgetNameDef.RealmRootView)
    if view then
        if view:IsOpen() then
            if result ~= 0 then
                GameLogicTools.ShowErrorCode(63009,result)
            else
                GameLogicTools.ShowMsgTips(StoryLineDef.CommonDef.CloseSuccess)
                self.data.curcopyid=0
                self:ToNotify(self.data,StoryLineDef.NotifyDef.EndExpore)
            end
            return
        end
    end
    local SceneManager = require "Modules.Scene.SceneManager"
    local SceneDef = require "Modules.Scene.SceneDef"
    SceneManager.Instance:EnterScene(SceneDef.SceneType.Main,{UIWidgetNameDef.RealmRootView})
    if result ~= 0 then
        GameLogicTools.ShowErrorCode(63009,result)
    else
        GameLogicTools.ShowMsgTips(StoryLineDef.CommonDef.CloseSuccess)
        self.data.curcopyid=0
    end
end

return RealmProxy