local logic = template({}, "sprite.buff.buff_timemerge")
local stateproc = {}

function logic:oncreate()
    self.bstart = false
end

function logic:ontstart(level)
    if self.bstart then return end
    self.bstart = true

    for _, stateid in ipairs(self.static.args_script[1]) do
        local buffstate = BUFF.STATE[stateid]
        self.owner.buff[buffstate] = self.owner.buff[buffstate] or 0
        if self.owner.buff[buffstate] == 0 then
            self:onstateadd(stateid)
        end
        if self.owner.buff[buffstate] then
            self.owner.buff[buffstate] = self.owner.buff[buffstate] + 1
        end
        -- print(buffstate, self.owner.buff[buffstate])
    end
end

function logic:ontstop(level)
    for _, stateid in ipairs(self.static.args_script[1]) do
        local buffstate = BUFF.STATE[stateid]
        if self.owner.buff[buffstate] then
            self.owner.buff[buffstate] = tsmath.max(self.owner.buff[buffstate] - 1, 0)
            if self.owner.buff[buffstate] == 0 then
                self.owner.buff[buffstate] = nil
                self:onstateremove(stateid)
            end
        end
        -- print(buffstate, self.owner.buff[buffstate])
    end
end

function logic:onstateadd(stateid)
    local proc = stateproc[stateid]
    if proc and proc.add then
        proc.add(self)
    end
end

function logic:onstateremove(stateid)
    local proc = stateproc[stateid]
    if proc and proc.remove then
        proc.remove(self)
    end
end

stateproc = {
    [1] = {
        add = function (self)
            self.owner.caller.suffer:entersuffer(self.buff:getfromobj(), self.static.id)
            self.owner.body:setvelocity(tsvector.zero)
        end,
        remove = function(self)
            self.owner.caller.suffer:exitsuffer()
        end
    },
    [6] = {
        add = function (self)
            if self.caller.skill then
                self.caller.skill:setslotactive(false, {2,3,4,5})
            end
        end,
        remove = function(self)
            if self.caller.skill then
                self.caller.skill:setslotactive(true, {2,3,4,5})
            end
        end
    },
    [7] = {
        add = function (self)
            if self.caller.skill then
                self.caller.skill:setslotactive(false, {2})
            end
        end,
        remove = function(self)
            if self.caller.skill then
                self.caller.skill:setslotactive(true, {2})
            end
        end
    },
    [8] = {
        add = function (self)
            self:sendmessage(eventdef.fake_dead_start)
        end,
        remove = function (self)
            self:sendmessage(eventdef.fake_dead_end)
        end,
    }
}

return logic
