local GuildDef = require "Modules.Guild.GuildDef"
local ClistRender = require "Core.Implement.UI.Class.ClistRender"
local ClistItem = require "Core.Implement.UI.Class.ClistItem"
local GuildProxy = require "Modules.Guild.GuildProxy"
local HeadItem = require "Core.Implement.UI.Class.HeadItem"
local DateFormatUtil = require "Common.Util.DateFormatUtil"
local AudioManager = require "Common.Mgr.Audio.AudioManager"
local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
local RedPointDef = require "Modules.RedPoint.RedPointDef"

local GuildHallViewItem = GuildHallViewItem or BaseClass(ClistItem, TimerFactor)
function GuildHallViewItem:Load(obj)
	if not self.lookFunc then
		self.lookFunc = function()
			if self.data then
				if self.data.guser == RoleInfoModel.guserid then
					--点到自己了
					-- GameLogicTools.ShowMsgTips(GuildDef.LanguageKey.GuildHallView2)

					UIOperateManager.Instance:OpenWidget(AppFacade.RoleInfo, 1)
				else
					local view=LuaLayout.Instance:GetWidget(UIWidgetNameDef.OtherPlayerInfolView)
				    if view then
				        view.playerUid = self.data.guser
				        view.selectTab = 1
				        view.openTabs = {1}
				  		view.openType = 2 --公会打开
				  		--print("self.data.guser========", self.data.guser)
				        -- view.guser = self.data.guser
				        view:OpenView()
				    end
				end
			end
		end
	end

	self.headItemObj = self:GetChild(self.go, "Headitem")
	self.headClass = HeadItem.New(self.headItemObj)
	self.headClass:SetHeadOnClickCallBack(self.lookFunc)

	self.serverLab = self:GetChildComponent(self.go, "fuwuqiID", "CLabel")

	self.livenessLab = self:GetChildComponent(self.go, "CSprite_huoyuedu/CLabel", "CLabel")
	self.onlineLab = self:GetChildComponent(self.go, "condition/onLine", "CLabel")
	self.offlineLab = self:GetChildComponent(self.go, "condition/offLine", "CLabel")
	self.persidentObj = self:GetChild(self.go, "zhiwei/huizhang")
	self.viceChairmanObj = self:GetChild(self.go, "zhiwei/fuhuizhang")
	self.fearlessHandObj = self:GetChild(self.go, "zhiwei/wuweizhishou")
	self.battleBtn = self:GetChildComponent(self.go, "CSprite_tiaozhan", "CButton")
	self.battleBtn:AddClick(function()
		-- print(table.dump(self.data))
		GuildProxy.Instance:Send70028(self.data.guser)
	end)

	local btn

	btn = self:GetComponent(self.persidentObj, "CButton")
	btn:AddClick(function()
		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildLableView)
		view.titleKey = "GuildView_1033"
		view.descKey = "GuildView_1034"
		view:OpenView()
	end)

	btn = self:GetComponent(self.viceChairmanObj, "CButton")
	btn:AddClick(function()
		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildLableView)
		view.titleKey = "GuildView_1037"
		view.descKey = "GuildView_1038"
		view:OpenView()
	end)

	btn = self:GetComponent(self.fearlessHandObj, "CButton")
	btn:AddClick(function()
		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildLableView)
		view.titleKey = "GuildView_1035"
		view.descKey = "GuildView_1036"
		view:OpenView()
	end)

	btn = self:GetComponent(self.go, "CButton")
	btn:AddClick(self.lookFunc)
end

function GuildHallViewItem:SetData(data)
	self.data = data
	self.headClass:SetData(data.headItem)
	self.serverLab.text = self:GetWord(GuildDef.LanguageKey.GuildLogoView4, data.serverId)
	self.livenessLab.text = data.sevenActivityPoint --data.liveness

	self.persidentObj:SetActive(data.job == GuildDef.Job.Persident and true or false)
	self.viceChairmanObj:SetActive(data.job == GuildDef.Job.ViceChairman and true or false)
	self.fearlessHandObj:SetActive(data.fearlessHand == GuildDef.Job.FearlessHand and true or false)
	
	self.onlineLab.gameObject:SetActive(data.lineState==0 and true or false)
	self.offlineLab.gameObject:SetActive(data.lineState>0 and true or false)
	
	if data.lineState > 0 then
		self:ClearTimer()
		local diffTime = RoleInfoModel.servertime - data.lineState
		local str = DateFormatUtil.formatToOffLine(diffTime)
		self.offlineLab.text = str
		self.leftTimer = self:AddTimer(function()
			--最小显示单位到分钟
			diffTime = diffTime + 60
			local str = DateFormatUtil.formatToOffLine(diffTime)
			self.offlineLab.text = str
		end, 60, -1)
	end

	self.battleBtn.gameObject:SetActive(data.guser ~= RoleInfoModel.guserid)
end

function GuildHallViewItem:ClearTimer()
	if self.leftTimer then
		self:RemoveTimer(self.leftTimer)
		self.leftTimer = nil
	end
end

function GuildHallViewItem:Close()
	self:ClearTimer()
end

function GuildHallViewItem:Destroy()
	self:ClearTimer()
end








local GuildHallView = GuildHallView or LuaWidgetClass()

function GuildHallView:__init()
	
	self.fullScreenOption = {onclosefunc = function ()
		self:CloseView()

		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildEntranceView)
		if not view:IsOpen() then
			view:OpenView()
		end
	end}
end

function GuildHallView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Guild.GuildHallView", self.LoadEnd)
end

function GuildHallView:LoadEnd(obj)
	self:SetGo(obj)
	self:InitUI()
	self:SetStep(0)
end

function GuildHallView:InitUI()
	self.leftObj = self:GetChild(self.go, "Left")
	self.guildNameLab = self:GetChildComponent(self.leftObj, "Guildname", "CLabel")
	self.guildIconTex = self:GetChildComponent(self.leftObj, "CTexture_LOGO", "CTexture")
	self.livenessLab = self:GetChildComponent(self.leftObj, "CSprite_huoyuedu/CLabel", "CLabel")
	self.guildIdLab = self:GetChildComponent(self.leftObj, "CLabelID/CLabel", "CLabel")
	self.announcementLab = self:GetChildComponent(self.leftObj, "CSprite_back/CLabel", "CLabel")
	self.levelLab = self:GetChildComponent(self.leftObj, "Progress/CLabel_LvNum", "CLabel")
	self.slider = self:GetChildComponent(self.leftObj, "Progress/CSlider_Progress/Progress/CSlider", "CSlider")
	self.progressSp = self:GetChildComponent(self.leftObj, "Progress/CSlider_Progress/Progress/CSprite_New", "CSprite")
	self.levelIconRedObj = self:GetChild(self.leftObj, "Progress/CSprite_LvNumBack/red")

	self.expLab = self:GetChildComponent(self.leftObj, "Progress/CSlider_Progress/Progress/CLabel_huoyuedu", "CLabel")

	self.rightObj = self:GetChild(self.go, "Right")
	self.clist = self:GetChildComponent(self.rightObj, "RankList/CList_Rank", "CList")
	self.clistRender = ClistRender.New()
	self.clistRender:Load(self.clist, GuildHallViewItem)


	self.memberLab = self:GetChildComponent(self.rightObj, "num/CLabel_num", "CLabel")

	self.btn1 = self:GetChildComponent(self.rightObj, "item1", "CButton")
	self.btn2 = self:GetChildComponent(self.rightObj, "item2", "CButton")
	self.redDot = self:GetChild(self.rightObj, "item2/red")
	self.redDot:SetActive(false)
	self.btn1:AddClick(function()
		if self.guildInfos then
			self:OpenOperatesView()
		end
	end)

	self.btn2:AddClick(function()
		LuaLayout.Instance:OpenWidget(UIWidgetNameDef.GuildRecordView)
	end)

	local btn
	btn = self:GetChildComponent(self.leftObj, "Progress/CSlider_Progress/CSliderClick", "CButton")
	btn:AddClick(function()
		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildlTipsView)
		view.type = 2
		view:OpenView()

		if GuildProxy.Instance:GetIsLevelUpTips() == 1 then
			GuildProxy.Instance:Send70031()
		end
	end)

	btn = self:GetChildComponent(self.leftObj, "CSprite_huoyuedu/Click", "CButton")
	btn:AddClick(function()
		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildlTipsView)
		view.type = 1
		view:OpenView()
	end)

	btn = self:GetChildComponent(self.leftObj, "CTexture_LOGO", "CButton")
	btn:AddClick(function()
		local job, fearlessHand = GuildProxy.Instance:GetGuildJob()
        if job == GuildDef.Job.Persident or job == GuildDef.Job.ViceChairman then
        	if self.guildInfos then
				local GuildLogoView = require "Modules.Guild.GuildLogoView"
				GuildLogoView.guildLevel = self.guildInfos.level
				GuildLogoView.cur_icon_id = self.guildInfos.icon_id
				GuildLogoView.callBack = function(select_id)
					if select_id ~= self.select_icon_id then
						GuildProxy.Instance:Send70013(select_id)
					end
				end
				LuaLayout.Instance:OpenWidget(UIWidgetNameDef.GuildLogoView)
			end
        else
        	GameLogicTools.ShowMsgTips("Guild_flag_1003")
        end
	end)

	--红点
	RedPointProxy.Instance:BindNode(RedPointDef.Id.GuildLevelIcon, self.levelIconRedObj)
end

--打开管理操作界面
function GuildHallView:OpenOperatesView()
	local job = self.guildInfos.job --自己的职位
	local count = #self.guildInfos.memberInfos  --人数
	local operateTab = {}  --管理 弹出列表项
	if job == GuildDef.Job.Persident then
		local tab = GuildDef.OperateTab[job]
		local index = count == 1 and 1 or 2
		operateTab = tab[index]  --
	else
		operateTab = GuildDef.OperateTab[job]
	end

	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildEditorView)
	local infos = {}
	for i,v in ipairs(operateTab) do
		local item = {}
		item.operate = v
		item.guser = nil
		table.insert(infos, item)
	end
	view.operateTables = infos
	view.position = self.btn1.gameObject.transform.position
	view:OpenView()

end

function GuildHallView:OnClose()
	self.clistRender:ClearData()
	self:AutoUnRegister()
	self:PlayTerritorySound()
end

function GuildHallView:PlayTerritorySound()
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildEntranceView)
	if GuildProxy.Instance:ExistGuild() then
	else
		GuildProxy.Instance:StopGuildBgm()	
		local TerritoryProxy = require "Modules.Territory.TerritoryProxy"
		TerritoryProxy.Instance:GoBack()
	end
end

function GuildHallView:OnDestroy()
	GuildProxy.Instance:StopGuildBgm()
	self.clistRender:ClearData()
	self:AutoUnRegister()
end

function GuildHallView:OnOpen()
	GuildProxy.Instance:PlayGuildBgm()
	self:AutoRegister()
	self:SetNetStep(1)
	GuildProxy.Instance:Send70000()
end

function GuildHallView:OnNetOpen()
	if self.result == 1 then
		self:UpdateView()
	else
		self:CloseView()
	end
end

function GuildHallView.EvtNotify.Guild.data:UpdateGuildInfos(data, args)
	self.result = args.result
	-- print("GuildHallView====", self.result, table.dump(args.guildInfos))
	self.guildInfos = args.guildInfos
	self:NetStep(1)
end
--成员添加减少
function GuildHallView.EvtNotify.Guild.data:UpdateMemberInfosCount(data, args)
	self.guildInfos = GuildProxy.Instance:GetGuildInfos()
	self:UpdateView()
end
--职位改变
function GuildHallView.EvtNotify.Guild.data:UpdateGuildJob(data, args)
	self.guildInfos = GuildProxy.Instance:GetGuildInfos()
	self:UpdateView()
end
--禅让通知
function GuildHallView.EvtNotify.Guild.data:UpdateDemise(data, args)
	self.guildInfos = GuildProxy.Instance:GetGuildInfos()
	self:UpdateView()
end
--公告更新
function GuildHallView.EvtNotify.Guild.data:UpdateNotice(data, args)
	self.guildInfos.notice = args.notice
	self.announcementLab.text = self.guildInfos.notice
end
--入会条件更新
function GuildHallView.EvtNotify.Guild.data:UpdateLimit(data, args)
	self.guildInfos.condition_limit, self.guildInfos.level_limit = args.conditionType, args.levelType
end
--公会图标更新
function GuildHallView.EvtNotify.Guild.data:UpdateGuildIcon(data, args)
	self.guildInfos.icon_id = args.icon_id
	local cfg = GuildProxy.Instance:GetGuildIconById(self.guildInfos.icon_id)
	if cfg then
		AssetManager.LoadUITexture(AssetManager.UITexture.Guild, cfg.icon, self.guildIconTex)
	end
	self.select_icon_id = self.guildInfos.icon_id --当前选中的
end
--公会名更新
function GuildHallView.EvtNotify.Guild.data:UpdateGuildName(data, args)
	self.guildInfos.name = args.guild_name
	self.guildNameLab.text = self.guildInfos.name
end
--宣言更新
function GuildHallView.EvtNotify.Guild.data:UpdateAnnouncement(data, args)
	self.guildInfos.announcement = args.announcement
end

function GuildHallView:UpdateView()
	self:ShowLeftView()
	self:ShowRightView()
end

function GuildHallView:ShowLeftView()
	self.guildNameLab.text = self.guildInfos.name
	local cfg = GuildProxy.Instance:GetGuildIconById(self.guildInfos.icon_id)
	if cfg then
		AssetManager.LoadUITexture(AssetManager.UITexture.Guild, cfg.icon, self.guildIconTex)
	end
	self.select_icon_id = self.guildInfos.icon_id --当前选中的
	
	self.livenessLab.text = self.guildInfos.liveness
	self.guildIdLab.text = self.guildInfos.guild_id
	self.announcementLab.text = self.guildInfos.notice
	self.levelLab.text = self.guildInfos.level

	local guildMaxLevel = GuildProxy.Instance:GetGuildMaxLevel()
	local bmaxLevel = self.guildInfos.level >= guildMaxLevel and true or false
	if bmaxLevel then
		-- self.slider.value = 1
		self.progressSp.fillAmount = 1
		local cur_Cfg = GuildProxy.Instance:GetLevelConfigByLevel(self.guildInfos.level)
		self.expLab.text = string.format("%d/%d", self.guildInfos.guild_exp, cur_Cfg.total_exp)
	else
		local cur_Cfg = GuildProxy.Instance:GetLevelConfigByLevel(self.guildInfos.level)
		local next_Cfg = GuildProxy.Instance:GetLevelConfigByLevel(self.guildInfos.level+1)
		if cur_Cfg and next_Cfg then
			-- local count = next_Cfg.total_exp - cur_Cfg.total_exp
			-- local cur_count = math.max(self.guildInfos.guild_exp - cur_Cfg.total_exp, 0)
			-- self.slider.value = self.guildInfos.guild_exp / next_Cfg.total_exp
			self.progressSp.fillAmount = self.guildInfos.guild_exp / next_Cfg.total_exp
			self.expLab.text = string.format("%d/%d", self.guildInfos.guild_exp, next_Cfg.total_exp)
		end
	end

end

function GuildHallView:ShowRightView()
	local guildInfos = GuildProxy.Instance:GetGuildInfos()
	local level = guildInfos.level
	local curConfig = GuildProxy.Instance:GetLevelConfigByLevel(level)
	self.memberLab.text = self:GetWord(GuildDef.LanguageKey.GuildHallView1, #self.guildInfos.memberInfos, curConfig.population)
	self.clistRender:ClearData()

	--排序:会长>副会长>无畏之手 在线>不在线
	--lineState:在线状态  0:在线  大于0：离线时间
	-- print(table.dump(self.guildInfos.memberInfos))
	table.sort(self.guildInfos.memberInfos, function (a, b)
		local orderA = self:GetMemberOrder(a)
		local orderB = self:GetMemberOrder(b)
		local order2A = self:GetMemberOrder2(a)
		local order2B = self:GetMemberOrder2(b)

		if orderA == orderB then
			if order2A == order2B then
				if order2A == 1 then
					return a.guser < b.guser
				else
					return a.lineState > b.lineState
				end
			else
				return order2A < order2B
			end
		else
			return orderA < orderB
		end
	end)

	self.clistRender:AppendDataList(self.guildInfos.memberInfos)
end

--用于成员列表的排序
function GuildHallView:GetMemberOrder(memberInfo)
	if memberInfo.job == GuildDef.Job.Persident then
		return 1
	elseif memberInfo.job == GuildDef.Job.ViceChairman then
		return 2
	elseif memberInfo.fearlessHand == GuildDef.Job.FearlessHand then
		return 3
	else
		return 4
	end
end

function GuildHallView:GetMemberOrder2(memberInfo)
	if memberInfo.lineState == 0 then
		return 1
	else
		return 2
	end
end

function GuildHallView:GetGuildOnlineMember()
	local online_count = 0
	local total_count = #self.guildInfos.memberInfos
	for i,v in ipairs(self.guildInfos.memberInfos) do
		if v.lineState == 0 then
			online_count = online_count + 1
		end
	end
	return online_count, total_count
end



return GuildHallView