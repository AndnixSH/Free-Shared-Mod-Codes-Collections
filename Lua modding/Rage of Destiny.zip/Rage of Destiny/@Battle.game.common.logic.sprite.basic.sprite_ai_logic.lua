local logic = { state = {}, event = service.event(), call = service.call(calldef.ai) }

function logic:oncreate()
    local wander = self:createlogic("sprite.ai.wander")
    local attack = self:createlogic("sprite.ai.attack")

    -- self.state.isdebug = true
    self.state:configure(wander, wander, {attack}, true)
    self.state:configure(attack, wander, nil)
    self.state:start(250, self.owner)
end

function logic.call:stop(immediate)
    self.state:stop(immediate)
end

return logic