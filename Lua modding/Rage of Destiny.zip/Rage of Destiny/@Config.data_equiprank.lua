ConfigManager.InitConfig('data_equiprank', {
[1]={id=1,rank=1,name="Common_1021",color="#ececec",maxgrade=0,exp=10,bigframe="wupinjieshao_1"},
[2]={id=2,rank=2,name="Common_1022",color="#5bd494",maxgrade=0,exp=40,bigframe="wupinjieshao_2"},
[3]={id=3,rank=3,name="Common_1023",color="#5fa3ff",maxgrade=3,exp=100,bigframe="wupinjieshao_3"},
[4]={id=4,rank=4,name="Common_1024",color="#5fa3ff",maxgrade=3,exp=240,bigframe="wupinjieshao_3"},
[5]={id=5,rank=5,name="Common_1025",color="#be60ff",maxgrade=4,exp=500,exclusivesig=1,bigframe="wupinjieshao_5"},
[6]={id=6,rank=6,name="Common_1026",color="#be60ff",maxgrade=4,exp=1000,exclusivesig=1,bigframe="wupinjieshao_5"},
[7]={id=7,rank=7,name="Common_1027",color="#ffbc52",maxgrade=5,exp=2000,exclusivesig=2,bigframe="wupinjieshao_7"},
[8]={id=8,rank=8,name="Common_1028",color="#ffbc52",maxgrade=5,exp=4000,exclusivesig=2,bigframe="wupinjieshao_7"},
[9]={id=9,rank=9,name="Common_1029",color="#ff5f5f",maxgrade=5,exp=8000,exclusivesig=3,bigframe="wupinjieshao_9"},
[10]={id=10,rank=10,name="Common_1029_t1",color="#ff5f5f",maxgrade=5,exp=0,exclusivesig=3,bigframe="wupinjieshao_9"},
[11]={id=11,rank=11,name="Common_1029_t2",color="#ff5f5f",maxgrade=5,exp=0,exclusivesig=3,bigframe="wupinjieshao_9"},
[12]={id=12,rank=12,color="#f1c5ff",bigframe="wupinjieshao_12"},
})