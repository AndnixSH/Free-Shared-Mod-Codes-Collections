local HeroProxy = require "Modules.Hero.HeroProxy"
local AudioManager = require "Common.Mgr.Audio.AudioManager"
local ClistRender = require "Core.Implement.UI.Class.ClistRender"
local ClistItem = require "Core.Implement.UI.Class.ClistItem"
local HeroItem = require "Core.Implement.UI.Class.HeroItem"
local NewbieWidget = require "Core.Implement.UI.Widgets.NewbieWidget"
local BattleDef = require "Modules.Battle.BattleDef"
local MercenaryDef = require "Modules.Mercenary.MercenaryDef"
local MercenaryProxy = require "Modules.Mercenary.MercenaryProxy"
local BattleProxy = require "Modules.Battle.BattleProxy"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"

local ShowRaceWord =
{
	[1] = { tips = "Common_1007", nohero = "Common_1014"},
	[2] = { tips = "Common_1008", nohero = "Common_1015"},
	[3] = { tips = "Common_1009", nohero = "Common_1016"},
	[4] = { tips = "Common_1010", nohero = "Common_1017"},
	[5] = { tips = "Common_1011", nohero = "Common_1018"},
	[6] = { tips = "Common_1012", nohero = "Common_1019"},
	[7] = { tips = "Common_1013", nohero = "Common_1020"},
}

local PoolItem = PoolItem or BaseClass(ClistItem, NewbieWidget, TimerFactor)

function PoolItem:Load(obj)
	self.itemBtn = self:GetComponent(obj, "CButton")
	self.list=false
	self.itemBtn:AddMouseDown(function()
		if not self.data.lockHero then
			self.bBtnDown = true
			self.blongClick = false
		end
	end)

	self.itemBtn:AddClick(function()
		if self:CanOperate() then
			if self.blongClick then
			else
				if PoolItem.target then
					self:OnTriggerClick()
					PoolItem.callback(PoolItem.target, self, self.dataIdx)
				end
			end
		end
	end)

	self.itemBtn:AddLongClick(function()
		if self:CanOperate() then
			local is_hire = self.data.hire_hero_type == BattleDef.Hire_Hero_Type.Hire_Hero
			if not self.data.isNewbieItem then -- and not is_hire
				if self.blongClick ~= nil and self.blongClick == false then
					self.blongClick = true
					
					local battleview = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleNetSelectView)
					local activityId
					if battleview and battleview:IsOpen() then
						activityId = battleview.activityid
					end
					local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleHeroInfoView)
					if self.data and self.data.herouid then
						local herouid = self.data.herouid
						--剧情副本的herouid，fromuid
						if activityId == ACTIVITYID.STORYLINE or activityId == ACTIVITYID.MAZE or activityId == ACTIVITYID.ACTIVITY then
							herouid = self.data.fromuid
						end
						view.activityid = activityId
						view.herouid = herouid
						view.roleid =  self.data.roleid
						view.rank = self.data.rank
						
						-- local level = self.data.level
						-- if self.data.crystalLevel and self.data.crystalLevel > self.data.level then
						-- 	level = self.data.crystalLevel
						-- end
						view.level = BattleProxy.Instance:GetHeroLv(self.data, activityId, false)
	
						view.sublevelup = 0 --迷宫子等级 迷宫玩法默认0， 其他玩法的通过herouid获取
						view.equips = self.data.equips or {}  --迷宫现在上阵英雄都不带装备self.equips({{equipTypeId, lv}, ...}),  其他玩法的装备列表通过herouid获取
						view.isMercenary = is_hire
						local list, can_open = self:FilterWinTeamHero(self.data.heroList)
						view.heroList = list
						if can_open then
							view:OpenView()
						else							
						end
					end
	
				end
			end
		end
	end)

    self.heroItem = HeroItem.New(self:GetChild(obj, "Heroitem"))
    self.selectObj = self:GetChild(obj, "Heroitem/select")
    self.lockObj = self:GetChild(obj, "Heroitem/CSprite_lock")
    self.attributeObj = self:GetChild(obj, "attribute")
    self.attributeObj:SetActive(true)
	self.hpSp = self:GetChildComponent(obj, "attribute/CSlider_hp/icon", "CSprite")
	self.mpSp = self:GetChildComponent(obj, "attribute/CSlider_mp/icon", "CSprite")

    self.propsAttr = {}
	self.propsAttr["hp"] = self.hpSp
	self.propsAttr["mp"] = self.mpSp    
end

function PoolItem:CanOperate()
	if self.data.lockHero then
		GameLogicTools.ShowMsgTips("MainlineMultiple_1003")
		return false
	end
	return true
end

function PoolItem:FilterWinTeamHero(herolist)
	local list = {}
	local otherTeamList, heromap = self.GetOtherTeamList()
	if heromap[self.data.herouid] and heromap[self.data.herouid].pass then
		return {}, false
	end
	for i, hero in ipairs(herolist) do
		if heromap[hero.herouid] and heromap[hero.herouid].pass then
		else
			table.insert(list, hero)
		end
	end
	return list, (#list > 0) and true or false
end

function PoolItem:OnTriggerClick()
	if self.data.isNewbieItem then
		self:OnTriggerClickBtn(self.itemBtn)
	end
end

--已经上阵多少个英雄
function PoolItem:CheckSelectHeroCount(data)
	local count = 0
	if data and data.leftItemList then
		for k,info in pairs(data.leftItemList) do
			if info.heroid and info.heroid > 0 then
				count = count + 1
			end
		end
	end
	return count
end

function PoolItem:DealNewBie(data)
	self:ClearTimer()
	if data.isNewbieItem then
		--已经上阵英雄满了，就不进行引导，手动完成引导
		-- local count = self:CheckSelectHeroCount(data)
		-- if count < 5 then
			local clist1, clist2
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleNetSelectView)
			if view and view:IsOpen() then
				clist1, clist2 = view:GetHeroCList()
			end

			self.delaytimer = self:AddTimer(function()
				self:RegisterButton(self.itemBtn, data.isNewbieItem[1], data.isNewbieItem[2], clist1)
			end, 0.3, 1)
		-- else
			-- local NewbieManager = require "Modules.Newbie.NewbieManager"
			-- local cur_newbie_id, cur_newbie_step = NewbieManager.Instance:GetCurNewbieId()
			-- NewbieManager.Instance:CompleteNewbie(cur_newbie_id)
		-- end
	end
end

function PoolItem:ClearTimer()
	if self.delaytimer then
		self:RemoveTimer(self.delaytimer)
		self.delaytimer = nil
	end
end

function PoolItem:SetData(data)
	self.bclickDown = false
	self.data = data
	self.GetOtherTeamList = data.GetOtherTeamList	
	self.cfg = HeroProxy.Instance:GetRoleCfgByConfigId(data.roleid)
	self.spritecfg = HeroProxy.Instance:GetSpriteConfigeById(self.cfg.id)

	local hero_data = HeroProxy.Instance:GetHeroDataByUid(data.fromuid)

	data.level = hero_data and hero_data.level or data.level
    data.crystalLevel = hero_data and hero_data.crystalLevel or data.crystalLevel
    self.heroItem:SetData(data)
	local props = self.data.prop
	if props and next(props) then
		self.attributeObj:SetActive(true)
		for k,prop in pairs(props) do
			if self.propsAttr[CONST.ATTR[prop[1]]] then
				self.propsAttr[CONST.ATTR[prop[1]]].fillAmount = prop[2] / 1000
			end
		end
	else
		self.attributeObj:SetActive(false)
	end

   	self.selectObj:SetActive(self.data.bselect)
   	if self.data.bselect then
   		--self.lockObj:SetActive(false)
   		self.heroItem:SetLockObj(false)
   	else
   		self.heroItem:SetLockObj(false)
   		--self.lockObj:SetActive(self.data.bcant == false and true or false)
   	end
   	self:SetState(data.leftItemList)

   	self.heroItem:ShowHeroHireObj(data.hire_hero_type == BattleDef.Hire_Hero_Type.Hire_Hero, data.fromuid)

   	self:DealNewBie(data)
end

function PoolItem:SetHireState(itemList)
	--雇佣状态
	if self.data.bhireHero then
		if self.data.hireHeroState == 1 then
			self.selectObj:SetActive(false)
			--self.lockObj:SetActive(true)
			self.heroItem:SetLockObj(true)
			self.data.bcant = false
		else
			local hire_herouids = {}
			local hero_roleid_map = {}
			local hireFriendHeroNum = 0
			for _,item in pairs(itemList) do
				if item.heroid ~= 0 then
					hero_roleid_map[item.herocfgid] = true
					if item.bhireHero then
						hire_herouids[item.heroid] = 1
						if MercenaryProxy.Instance:CheckIsHireHero(item.fromuid) then
							hireFriendHeroNum = hireFriendHeroNum + 1
						end
					end
				end
			end
			
			local fullFriendHire = hireFriendHeroNum >= self.data.canHireFriendHeroNum
			local isFriendHireHero = MercenaryProxy.Instance:CheckIsHireHero(self.data.fromuid or 0)
			
			if (isFriendHireHero and fullFriendHire) and (not hire_herouids[self.data.herouid]) then
				self.data.hireHeroState = 2
				self.selectObj:SetActive(false)
				--self.lockObj:SetActive(true)
				self.heroItem:SetLockObj(true)
				self.data.bcant = false
			else
				self.data.hireHeroState = 0
				if hero_roleid_map[self.cfg.id] then
					self.selectObj:SetActive(false)
					self.heroItem:SetLockObj(true)
					self.data.bcant = false
				end
			end
		end
	end
end

function PoolItem:SetState(itemList)
	local list = {table.unpack(itemList)}
	local otherTeamList = self.GetOtherTeamList()
	for _,v in ipairs(otherTeamList) do
		table.insert(list, v)
	end
	
	self.selectObj:SetActive(false)
	--self.lockObj:SetActive(false)
	self.heroItem:SetLockObj(false)

	self.data.bselect = false
	self.data.bcant = true

	self:SetHireState(list)
	for _, item in pairs(itemList) do
		if item.heroid == self.data.herouid then
			self.selectObj:SetActive(true)
			--self.lockObj:SetActive(false)
			self.heroItem:SetLockObj(false)
			self.data.bselect = true
			self.data.bcant = false
			return
		elseif item.heroid ~= 0 then
			if item.herocfgid == self.cfg.id then
				self.selectObj:SetActive(false)
				--self.lockObj:SetActive(true)
				self.heroItem:SetLockObj(true)
				self.data.bcant = false				
				return
			end	
		end	
	end

	self:UpdateState()
end
--竞技场有三队，第一队选中的，在第二队应该都是锁的状态
function PoolItem:SetSelectState(data)
	local itemList=data.list
	self.list=itemList
	local leftItemList=data.leftItemList
	if leftItemList then
		for _, item in pairs(leftItemList) do
			if item.heroid == self.data.herouid then
				self.selectObj:SetActive(true)
				-- self.lockObj:SetActive(false)
				self.heroItem:SetLockObj(false)
				self.data.bselect = true
				self.data.bcant = false
				return
			elseif item.herocfgid == self.cfg.id  then
				return
			end
		end
	end
	self:UpdateState()
end

function PoolItem:UpdateState()
	local list = self.list
	if not list then
		list = self.GetOtherTeamList()
	end
	if list and (not self.data.bhireHero) then
		self.selectObj:SetActive(false)
		-- self.lockObj:SetActive(false)
		self.heroItem:SetLockObj(false)
		self.data.bselect = false
		self.data.bcant = true

		for _, item in pairs(list) do
			if item.heroid == self.data.herouid then
				--self.lockObj:SetActive(true)
				self.heroItem:SetLockObj(true)
				self.data.bcant = false
				return
			elseif item.heroid ~= 0 then
				if item.herocfgid == self.cfg.id then
					-- self.lockObj:SetActive(true)
					self.heroItem:SetLockObj(true)
					self.data.bcant = false				
					return
				end	
			end	
		end
	end
	
end

function PoolItem:ReSetData(data, infos)
	-- if self.data and infos[self.dataIdx] then
	-- 	self:ReSetData(infos[self.dataIdx])
	-- end
end

function PoolItem:Close()
	self.list=false
	self:ClearTimer()
	self:UnRegisterNewbie()
end

function PoolItem:Destroy()
	self.list=false
	self:ClearTimer()
	self:UnRegisterNewbie()
end

local BattleSelectHeloPanel = BattleSelectHeloPanel or BaseClass(GameObjFactor)

function BattleSelectHeloPanel:__init(obj)
	self:InitUI(obj)
end
	
function BattleSelectHeloPanel:InitUI(obj)
	self.righPaneltObj = obj
    self.herodontLbl = self:GetChildComponent(self.righPaneltObj, "CLabel_none", "CLabel")
    self.rightRect = self:GetComponent(self.righPaneltObj, "RectTransform")

    self.heroListObj1 = self:GetChild(self.righPaneltObj, "CList_hero1")
    self.heroList1 = self:GetChildComponent(self.righPaneltObj, "CList_hero1", "CList")
    self.heroList1.gameObject:SetActive(true)
    self.herolistRender1 = ClistRender.New()
    self.herolistRender1:Load(self.heroList1, PoolItem)
    -- self.herolistRender1:AddSelect(function(item, index)
    -- 		if item then
    -- 			item:OnTriggerClick()
    -- 		end
    --         self:OnClickPoolIdx(item, index)
    --     end)

    self.heroListObj2 = self:GetChild(self.righPaneltObj, "CList_hero2")
    self.heroList2 = self:GetChildComponent(self.righPaneltObj, "CList_hero2", "CList")
    self.heroList2.gameObject:SetActive(true)
    self.herolistRender2 = ClistRender.New()
    self.herolistRender2:Load(self.heroList2, PoolItem)
    -- self.herolistRender2:AddSelect(function(item, index)
    -- 	    if item then
    -- 			item:OnTriggerClick()
    -- 		end
    --         self:OnClickPoolIdx(item, index)
    --     end)

    PoolItem.target = self
    PoolItem.callback = self.OnClickPoolIdx


    self.lineRect1 = self:GetChildComponent(self.righPaneltObj, "CSprite_line1", "RectTransform")
    self.lineRect2 = self:GetChildComponent(self.righPaneltObj, "CSprite_line2", "RectTransform")

    self.bopenBtn = self:GetChildComponent(self.righPaneltObj, "CButton_open", "CButton")
    self.bopenSpObj = self:GetChild(self.bopenBtn.gameObject, "open")
    self.bcloseSpObj = self:GetChild(self.bopenBtn.gameObject, "close")
    self.bopenBtn:AddClick(function()
    	self.bopen = self.bopen == false and true or false
    	self:SetHeroListActive()
    end)

	self.raceItemList = {}
	for i=1, 8 do
		local item = {}
		local index = i - 1
		local itemObj = self:GetChild(self.righPaneltObj, "CLayoutItem/item"..index)
		item.obj = itemObj
		item.index = index		
		item.selectObj = self:GetChild(itemObj, "select")		
		self.raceItemList[i] = item

		local btn = self:GetComponent(itemObj, "CButton")
		btn:AddClick(function ()
			self:OnClickRace(index)
		end)
	end

end

function BattleSelectHeloPanel:AddPoolItemClickFunc(func)
	self._poolItemClick = func
end

function BattleSelectHeloPanel:RemovePoolItemClickFunc()
	self._poolItemClick = nil
end

function BattleSelectHeloPanel:AddRaceItemClickFunc(func)
	self._raceItemClick = func
end

function BattleSelectHeloPanel:RemoveRaceItemClickFunc()
	self._raceItemClick = nil
end

function BattleSelectHeloPanel:Open(args)
    PoolItem.target = self
    PoolItem.callback = self.OnClickPoolIdx
    self.args = args or {}
	self.bopen = false
	self.infos = {}
	self:DefaultView()
end

function BattleSelectHeloPanel:DefaultView()
	self.herolistRender1:ClearData()
	self.herolistRender2:ClearData()
	self.bopenSpObj:SetActive(self.bopen == false and true or false)
	self.bcloseSpObj:SetActive(self.bopen == true and true or false)

	self.heroListObj1:SetActive(self.bopen == false and true or false)
	self.heroListObj2:SetActive(self.bopen)
	local toVec, lineVec1, lineVec2 = self:GetRectSize()

	self.rightRect.sizeDelta = toVec
	self.lineRect1.sizeDelta = lineVec1
	self.lineRect2.sizeDelta = lineVec2

end

function BattleSelectHeloPanel:Close()
	self:ClearData()
	self.herolistRender1:ClearData()
	self.herolistRender2:ClearData()
	self:ClearTween()
end

function BattleSelectHeloPanel:Destroy()
	self:ClearData()
	self.herolistRender1:ClearData()
	self.herolistRender2:ClearData()
	self:ClearTween()
end

function BattleSelectHeloPanel:ClearData()
	self.bOnlyRace = nil
	self.raceIdx = nil
end

function BattleSelectHeloPanel:GetCurRaceIdx()
	return self.raceIdx 
end


function BattleSelectHeloPanel:OnClickPoolIdx(class, index)
	local state = 0
	if class.data.bselect then
		AudioManager.PlaySoundByKey("battleselectdown_view")
		state = 1  --取消选中
	elseif not class.data.bcant then	
		state = 2  --不可以选中
	elseif not class.data.bselect then
		AudioManager.PlaySoundByKey("battleselecttop_view")
		state = 0  --可选中
	end

	if self._poolItemClick then
		self._poolItemClick(class, index, state)
	end
end

--bOnlyRace 是否只显示单一种族
function BattleSelectHeloPanel:OnClickRace(index, bOnlyRace)
	bOnlyRace = bOnlyRace or false

	if self.bOnlyRace then
		GameLogicTools.ShowMsgTips("TowerEntrance_1003")
		return
	end

	if self.raceIdx then
		if self.raceIdx == index then
			return
		else
			self.raceIdx = index
		end
	else
		self.bOnlyRace = bOnlyRace
		self.raceIdx = index
		self:SetRaceItemGray()
	end

	self:SetRaceItemSelect()

	if index ~= 0 and self.bOnlyRace ~= true then
		GameLogicTools.ShowMsgTips(self:GetWord("unity_tips_1018", self:GetWord(ShowRaceWord[index].tips)))
		AudioManager.PlaySoundByKey("clayoutItem_show"..index)
	end

	if self._raceItemClick then
		self._raceItemClick(index)
	end

end

--灰置状态
function BattleSelectHeloPanel:SetRaceItemGray()
	for _, item in pairs(self.raceItemList) do
		GameObjTools.SetGray(item.obj, self.bOnlyRace and (item.index ~= self.raceIdx), true)
	end	
end

--选中状态
function BattleSelectHeloPanel:SetRaceItemSelect()
	for _, item in pairs(self.raceItemList) do
		item.selectObj:SetActive(item.index == self.raceIdx)
	end
end





--外部接口 设置列表数据
function BattleSelectHeloPanel:SetHeroListData(infos, race, activityid)
	infos = infos or {}
	race = race or 0
	activityid = activityid or 0
	self:SetHeroListPad(activityid)

	self:ShowHeroList(infos, race)
end




function BattleSelectHeloPanel:UpdateHeroItemExecuteMethod(methodStr, data)
	self.herolistRender1:ExecuteMethod(methodStr, data)
	self.herolistRender2:ExecuteMethod(methodStr, data)
end

--设置列表偏移量
function BattleSelectHeloPanel:SetHeroListPad(activityid)
	--迷宫带有血量条，间距大
	local padY = activityid == ACTIVITYID.MAZE and 6 or -8
	self.heroList1.pad = Vector2.New(-12, padY)
	self.heroList2.pad = Vector2.New(-12, padY)
end

function BattleSelectHeloPanel:SetHeroListInfos()
	for i, v in ipairs(self.infos) do
		v.heroList = self.infos
	end
	if self.bopen == false then
		self.herolistRender1:ClearData()
    	self.herolistRender1:AppendDataList(self.infos, false) -- 7
	else
		self.herolistRender2:ClearData()
   		self.herolistRender2:AppendDataList(self.infos, false) --7
	end
end

function BattleSelectHeloPanel:ShowHeroList(infos, race)
	self.infos = infos
	self:SetHeroListInfos()

    if next(self.infos) then
    	self.herodontLbl.gameObject:SetActive(false)
    else
    	self.herodontLbl.gameObject:SetActive(true)
    	if race and race ~= 0 and ShowRaceWord[race] then
    		self.herodontLbl.text = self:GetWord("HeroCommon_1001", self:GetWord(ShowRaceWord[race].nohero))    	
    	else
    	    self.herodontLbl.text = ""	
    	end
    end	
end

function BattleSelectHeloPanel:SetHeroListActive()
	self.bopenSpObj:SetActive(self.bopen == false and true or false)
	self.bcloseSpObj:SetActive(self.bopen == true and true or false)
	if self.bopen == true then
		self.heroListObj1:SetActive(self.bopen == false and true or false)
		self.heroListObj2:SetActive(self.bopen)
		self:SetHeroListInfos()
	end
	self:SetHeroListAreaWidth()
end

function BattleSelectHeloPanel:GetRectSize()
	local smallWidth = 364  --小的宽度
	local bigWidth = 564  --大的宽度
	local toVecX = (self.bopen == true) and bigWidth or smallWidth

	local lineVecform1 = Vector2.New(182, 12)   --左侧line小 宽
	local lineVecTo1 = Vector2.New(281, 12)      --左侧line大 宽

	local lineVecform2 = Vector2.New(182, 12)   --右侧line小 宽 
	local lineVecTo2 = Vector2.New(281, 12)        --右侧line大 宽

	local lineVec1 = (self.bopen == true) and lineVecTo1 or lineVecform1
	local lineVec2 = (self.bopen == true) and lineVecTo2 or lineVecform2

	local toVec = Vector2.New(toVecX, 750)

	return toVec, lineVec1, lineVec2
end


function BattleSelectHeloPanel:SetHeroListAreaWidth()
	self:ClearTween()

	local fromVectX = self.rightRect.sizeDelta.x

	local toVec, lineVec1, lineVec2 = self:GetRectSize()

	local moveTime = 0.3
	self.sequence = DOTween.Sequence()
	local tween = self.rightRect:DOSizeDelta(toVec, moveTime, false)

	self.sequence:Append(tween)
	self.sequence:AppendCallback(function()
		if self.bopen == false then
			self.heroListObj1:SetActive(true)
			self.heroListObj2:SetActive(false)
			self:SetHeroListInfos()
		end	
	end)

	self.lineSeq1 = self:LineTween(self.lineRect1, lineVec1, moveTime)
	self.lineSeq2 = self:LineTween(self.lineRect2, lineVec2, moveTime)
end

function BattleSelectHeloPanel:LineTween(objRect, toSize, moveTime)
	local sequence = DOTween.Sequence()
	local tween = objRect:DOSizeDelta(toSize, moveTime, false)
	sequence:Append(tween)
	return sequence
end

function BattleSelectHeloPanel:ClearTween()
	if self.lineSeq1 then
		self.lineSeq1:Kill()
		self.lineSeq1 = nil
	end

	if self.lineSeq2 then
		self.lineSeq2:Kill()
		self.lineSeq2 = nil
	end

	if self.sequence then
		self.sequence:Kill()
		self.sequence = nil
	end
end

function BattleSelectHeloPanel:Newbie_Notify(args)
	local newbie, step = args.newbieid, args.step
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	if NewbieDef.SelectHeroTrigger[newbie] then
		for k,_step in pairs(NewbieDef.SelectHeroTrigger[newbie]) do
			if step == _step then
				self.heroList1.enabled = false
				break
			end
		end
	end
end

function BattleSelectHeloPanel:GetHeroCList()
	return self.heroList1, self.heroList2
end


return BattleSelectHeloPanel