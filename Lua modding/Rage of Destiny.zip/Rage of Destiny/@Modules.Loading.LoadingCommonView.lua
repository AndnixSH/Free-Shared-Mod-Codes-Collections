local LoadingCommonView = LoadingCommonView or BaseClass(LuaBasicWidget)

LoadingCommonView.percentage = 0
LoadingCommonView.speed = 50
--local pre_scene = nil
--local enter_scene = nil

function LoadingCommonView.ShowLoading(percentage)
    --防止进度错乱
    if percentage == 0 then
        LoadingCommonView.percentage = 0
    elseif percentage > LoadingCommonView.percentage then
        LoadingCommonView.percentage = percentage
    end
    LoadingCommonView.speed = 80

    local SceneManager = require "Modules.Scene.SceneManager"
    local SceneDef = require "Modules.Scene.SceneDef"
    local curScene = SceneManager.Instance:GetCurSceneType()
    local lastScene = SceneManager.Instance:GetLastSceneType()
    local complete = percentage == 100

    if curScene == SceneDef.SceneType.Hero then
        LoadingCommonView.speed = complete and 1000 or 100
    else
        if curScene == SceneDef.SceneType.StoryLine or curScene == SceneDef.SceneType.Activity or
                (curScene == SceneDef.SceneType.Main and lastScene == SceneDef.SceneType.TowerBattle) or
                (curScene == SceneDef.SceneType.Main and lastScene == SceneDef.SceneType.StoryLine) or
                (curScene == SceneDef.SceneType.Main and lastScene == SceneDef.SceneType.GuildChaosBattle) or
                (curScene == SceneDef.SceneType.Main and lastScene == SceneDef.SceneType.GuildBossBattle) or
                (curScene == SceneDef.SceneType.Main and lastScene == SceneDef.SceneType.HighArenaBattle) or
                (curScene == SceneDef.SceneType.Main and lastScene == SceneDef.SceneType.SupplyDepotBattle) or
                (curScene == SceneDef.SceneType.Main and lastScene == SceneDef.SceneType.MobilizeBattle) or
                (curScene == SceneDef.SceneType.Main and lastScene == SceneDef.SceneType.Activity) or
                (curScene == SceneDef.SceneType.StoryLine and lastScene == SceneDef.SceneType.StoryLineBattle)
        then
            LoadingCommonView.speed = complete and 80 or 50
        else
            LoadingCommonView.speed = complete and 1000 or 100
        end
    end

    --print("lastSceneTyp curSceneType speed", lastScene, curScene, LoadingCommonView.speed)
  
    local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.LoadingCommonView)
    if not view:IsOpen() then
        view:OpenView()
    end
end

function LoadingCommonView.CloseLoading()
    local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.LoadingCommonView)
    if view:IsOpen() then
        view:CloseView()
    end
end
-----------------
function LoadingCommonView:__init()
    self._bsave = true
end

function LoadingCommonView:OnLoad()
    AssetManager.LoadUIPrefab(self, "Loading.LoadingCommonView", self.LoadEnd)
end

function LoadingCommonView:LoadEnd(obj)
    self:SetGo(obj)

    self.backTex1 = self:GetChildComponent(obj, "background1", "CTexture")
    self.backTex2 = self:GetChildComponent(obj, "background2", "CTexture")
    self.percentageLbl = self:GetChildComponent(obj, "label/COutline_New2", "CLabel")

    self:Step(0)
end

function LoadingCommonView:OnOpen()
    GameObjTools.SetDepth(self.go, 10000)
    GameObjTools.SetModelDepth(self.go, 10000)
    self.value = 0
    self.percentageLbl.text = math.floor(self.value) .. '%'
    self.percentageLbl.gameObject:SetActive(LoadingCommonView.percentage ~= nil)
    self.texcfg = ConfigManager.GetConfig("data_tips")["loading_tex"]

    self:ShowTips()

    self:StartFrame()

end

function LoadingCommonView:OnClose()
    local SceneManager = require "Modules.Scene.SceneManager"
    SceneManager.Instance:SceneLoadingEnd()
    local ScreenShotter = require "Common.Util.ScreenShotter"
    ScreenShotter.Clear()
    self:EndFrame()
    self.value = 0
    LoadingCommonView.percentage = nil
    self.backTex1.texture = nil
end

function LoadingCommonView:ShowTips()

    local ScreenShotter = require "Common.Util.ScreenShotter"
    local load_texture = ScreenShotter.Texture()

    local bloadtexture = load_texture ~= nil
    self.backTex1.gameObject:SetActive(bloadtexture)
    self.backTex2.gameObject:SetActive(not bloadtexture)

    if bloadtexture then
        self.backTex1.texture = load_texture
    else
        local texTab = self.texcfg[math.random(1, #self.texcfg)]
        local str = texTab.background
        AssetManager.LoadUITexture(AssetManager.UITexture.Background, str, self.backTex2)
    end

end

function LoadingCommonView:FrameUpdate()
    
    local percentage =  LoadingCommonView.percentage
    local speed = LoadingCommonView.speed

    if percentage then
        if self.value < percentage and self.value < 100 then
            self.value = math.min(self.value + Time.deltaTime * LoadingCommonView.speed, percentage)
            self.percentageLbl.text =  self:GetWord("LoadingView_1002", math.floor(self.value))--math.floor(self.value) .. '%'
        elseif self.value >= 100 then
            self.percentageLbl.text = self:GetWord("LoadingView_1002", 100)
            self:CloseView()
        end
    end
end

return LoadingCommonView