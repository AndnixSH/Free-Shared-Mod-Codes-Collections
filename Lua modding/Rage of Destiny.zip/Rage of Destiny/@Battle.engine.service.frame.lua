local frame = {}

function frame:init()
    self._list_proc = {}
    self._list_add = {}
end

function frame:afterframe(handler, ...)
    table.insert(self._list_add, { handler, {...} })
end

function frame:process_late(time, tick)

    local count_add = #self._list_add
    if count_add > 0 then
        for i = 1, count_add do
            local add = self._list_add[i]
            if add then
                table.insert(self._list_proc, add)
            end
        end
        self._list_add = {}
    end

    local count_proc = #self._list_proc
    if count_proc > 0 then
        for i = 1, count_proc do
            local late = self._list_proc[i]
            if late then
                late[1](table.unpack(late[2]))
            end
        end
        self._list_proc = {}
    end
    
end

function frame:dump()
    global.debug.info("frame._list_proc", self._list_proc and #self._list_proc)
end

function frame:dispose()
    self._list_proc = {}
    self._list_add = {}
end

return frame