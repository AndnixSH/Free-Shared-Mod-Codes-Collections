local RoleInfoDef = {}

RoleInfoDef.NotifyDef = {
	Currency_Change = "Currency_Change",
    RoleInfo_Update = "RoleInfo_Update",
    RoleInfo_Request = "RoleInfo_Request", --请求个人主页信息
    MainLineUp_Update = "MainLineUp_Update",
    Signature_Update = "Signature_Update",
    NickName_Update = "NickName_Update",
    Sex_Update = "Sex_Update",
    PhotoInfo_Request = "PhotoInfo_Request",
    Photo_Update = "Photo_Update",
    PhotoFrame_Update = "PhotoFrame_Update",
    Currency_Info_Change = "Currency_Info_Change", --货币栏更改
    OtherRoleInfo_Update = "OtherRoleInfo_Update", --显示其他玩家个人信息
    Update_ChangeNameTips = "Update_ChangeNameTips", --
}

-- 消耗货币（type:1金币，2钻石）
RoleInfoDef.CurrencyType =
{
    [0] = "crash",    -- 现金
    [1] = "diamond",    -- 钻石
    [2] = "coin",    -- 金币
    [3] = "player_exp",    -- 账号经验
    [4] = "hero_exp",    -- 英雄经验
    [5] = "vip_exp",    -- vip经验
    [6] = "medals_valor",   -- 日常币
    [7] = "guild_coin",    -- 公会币
    [8] = "hero_coin",    -- 遣散币
    [9] = "labyrinth_token", -- 迷宫币
    [10] = "challenger_coin", -- 竞技币
    [11] = "twisted_sigil", -- 梦境币
    [12] = "companion_points", -- 友情币
    [13] = "heroic_merit",  -- 迷宫活跃
    [14] = "inv_essence",  --水晶币
    [15] = "dragon_ball", --迷宫龙珠
    [16] = "recruit_merit", -- 新兵训练活跃
    [17] = "tree_exp", --生命树经验
    [18] = "mobilize_point", --命运总动员积分
}

RoleInfoDef.RoleInfoBtn = ----需要改成多语言配置的id
{
    [1]="RoleInfoView_1001", --信息
    [2]="RoleInfoView_1003",--设置
    --[3]="Common_1014", --成就
}

RoleInfoDef.RoleInfoIcon = ----需要改成多语言配置的id
{
    [1]="yingxiong_1", --信息
    [2]="settingpage",--设置
    --[3]="Common_1014", --成就
}

RoleInfoDef.OtherRoleInfoBtn = ----需要改成多语言配置的id
{
    [1]="RoleInfoView_1001", --信息
    [2]="RoleInfoView_1071",--队伍
}

RoleInfoDef.EditorBtn = ----需要改成多语言配置的id
{
    -- [1]="RoleInfoView_1006", --修改头像
    -- [2]="RoleInfoView_1005", --修改头像框
    
    [1]="RoleInfoView_1008", --修改名字
    [2]="RoleInfoView_1007", --修改性别
    [3]="RoleInfoView_1056", --主力阵容
    [4]="RoleInfoView_1078", --编辑签名
    -- [5]="RoleInfoView_1009",--复制昵称
    -- [6]="RoleInfoView_1010", --复制ID
    
}
RoleInfoDef.PhotoModifyBtn = ----需要改成多语言配置的id
{
    [1]={"RoleInfoView_1006","touxiang"}, --头像
    [2]={"RoleInfoView_1005","touxiangkuang"}, --头像框
    --[3]="Common_1014", --其他
}
RoleInfoDef.PhotoSelectBtn = ----需要改成多语言配置的id
{
    [1]="RoleInfoView_1020", --全部
}
RoleInfoDef.PhotoFrameSelectBtn = ----需要改成多语言配置的id
{
    [1]="RoleInfoView_1020", --全部
    [2]="RoleInfoView_1021",--稀有
    [3]="RoleInfoView_1022", --史诗
    [4]="RoleInfoView_1023",--限定
}
RoleInfoDef.PhotoState = ----需要改成多语言配置的id
{
    Using="RoleInfoView_1016",--正在使用
    CanBeUse="RoleInfoView_1017",--立即使用
    NotGet="RoleInfoView_1018",--尚未获得
}


RoleInfoDef.SexName= ----需要改成多语言配置的id
{
    [1]={"RoleInfoView_1025","nan"}, --男
    [2]={"RoleInfoView_1026","nv"}, --女
    [3]={"RoleInfoView_1027","baomi"},--隐藏
}
RoleInfoDef.CommonDef= ----需要改成多语言配置的id
{
    Ensure="RoleInfoView_1051", --确定

    GuildNameTips="RoleInfoView_1034", --尚未加入战队

    PhotoModifySuccess="RoleInfoView_1019",--头像修改成功
    PhotoFrameModifySuccess="RoleInfoView_1065", --头像框修改成功
    PhotoModifyTitle="RoleInfoView_1006",--头像修改界面标题
    PhotoFrameModifyTitle="RoleInfoView_1005",--头像框修改界面标题

    GenderModifySuccess="RoleInfoView_1065",--性别修改成功
    GenderModifyTitle="Common_1014",--性别修改界面标题

    SignatrueModifySuccess="RoleInfoView_1065",--签名修改成功
    SignatureModifyTitle="Common_1014",--签名修改界面标题
    SignatureTips1="RoleInfoView_1035",--这里是你的个性签名喔，不喜欢可随意更改
    SignatureTips2="RoleInfoView_1036",--这个人很懒，什么都没有填写！
    SignatureTips3="RoleInfoView_1063",--文字包含敏感词汇
    SignatureTips4="RoleInfoView_1064",--签名长度不能超过30字内
    SignatureTips5="RoleInfoView_1068",--5/40字数限制
   
    NameModifyTitle="Common_1014",--名字修改界面标题
    NameModifySuccess="RoleInfoView_1033",--名字修改成功
    ModifyNameTips1="RoleInfoView_1029",--首次更改名字“免费”
    ModifyNameTips2="RoleInfoView_1031",--“更改名字需要消耗%s颗“钻石”即可更改名字是否前往 商城购买充值？” //更改名字需要消耗%s颗
    ModifyNameTips3="RoleInfoView_1032",--是否消耗%s数量钻石将名字%s修改为%s //更改名字需要消耗%s颗 名字需要用特殊颜色
    ModifyNameTips4="RoleInfoView_1066",--改名将消耗多少钻石
    
    CopySuccess="RoleInfoView_1067",--复制成功
    
    PleaseInputName="RoleInfoView_1030",--请在这里输入要更改的名字
    InputNameTooShort="RoleInfoView_1057",--长度不能少于三个汉字
    InputNameTooLen="RoleInfoView_1058",--长度不能超过六个汉字
    InputNameSensitive="RoleInfoView_1060",--★名字包含敏感词汇
    InputNameEmpty="RoleInfoView_1059",--名字不能为空
    InputNameExist="RoleInfoView_1061",--名字已存在
    InputNameFrequent="RoleInfoView_1062",--操作过于频繁，请稍后…
    InputNameExistSpecialWord="FormationInputCheck_4",--特殊字符
    RemainWordsCountTip="FormationInputCheck_5",--特殊字符
    CanUseTheName="RoleInfoView_1072",--恭喜，该名字可以使用

    MainLineUpTitle="RoleInfoView_1056" ,--主力阵容标题
    MainLineUpExistEditorBtn="RoleInfoView_1037", --退出编辑
    MainLineUpSaveBtn="RoleInfoView_1038", --保存

    JourneyTitle="RoleInfoView_1040", --征途
    Journey_NotOnList="RoleInfoView_1047", --未上榜
    Journey_Rank="RoleInfoView_1046", --上榜

    visitorTitle="RoleInfoView_1048", --访客

    communityBtn="RoleInfoView_1055", --社区按钮

    invitionCodeBtn="RoleInfoView_1049", --兑换码按钮
    invitionCodeTitle="RoleInfoView_1049",--兑换码标题
    invitionCodeTips="RoleInfoView_1050",--请输入兑换码
    invitionCodeSuccess="RoleInfoView_1053",--兑换成功
    invitionCodeFail="RoleInfoView_1054",--兑换失败

    stickersBtn="Common_1014",--贴纸
    stickersBtnTips="RoleInfoView_1014", --敬请期待
    saveSuccess="RoleInfoView_1069",--保存成功

    CannotReportMySelf = "ChatView_1038",
    ReportSuccess = "ChatView_1039",
    ReportTips = "ChatView_1037",
    Server = "RoleInfoView_1012_2",
}

RoleInfoDef.PhotoFrameQuality = 
{
    Hare=1,--稀有
    Epic=2,--史诗
    Limit=3,--限定
}

RoleInfoDef.Sex = 
{
    Boy=1,--男
    Girl=2,--女
    Hide=3,--隐藏
}

RoleInfoDef.SexSpriteName = {
    [RoleInfoDef.Sex.Boy] = "nanshengtubiao",
    [RoleInfoDef.Sex.Girl] = "nvshengtubiao",
    [RoleInfoDef.Sex.Hide] = "baomitubiao",
}

RoleInfoDef.JourneyTexName = {
    [1] = "Tex_RankList_1",
    [2] = "Tex_RankList_2",
}

RoleInfoDef.Views = 
{
    -- [1]={UIWidgetNameDef.CustomizeView,1}, --修改头像1 -- 1 为修改头像，2为修改头像框
    -- [2]={UIWidgetNameDef.CustomizeView,2}, --修改头像框2
    
    [1]={UIWidgetNameDef.ChangeNameView}, --修改名字
    [2]={UIWidgetNameDef.SexView}, --修改性别
    -- [5]={""},--复制昵称
    -- [6]={""}, --复制ID
    [3]={UIWidgetNameDef.LineUpView}, --主力阵容
    [4]={UIWidgetNameDef.SignatureView}, --主力阵容
}

RoleInfoDef.ToggleViews = 
{
    [1]=UIWidgetNameDef.PlayerInfoView, 
    [2]=UIWidgetNameDef.SettingMenuView, 
}


--SOP奖励类型
RoleInfoDef.Sop_Award_Type = {
    Rating_Award = 1, --评星奖励

}

return RoleInfoDef