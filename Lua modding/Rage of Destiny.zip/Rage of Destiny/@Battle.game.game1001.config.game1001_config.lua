local data_battle_key = ConfigManager.GetConfig("data_battle_key")

local scenekey = function (key)
    local tbl = {}
    for k, v in pairs(data_battle_key) do
        tbl[k] = v[key]
    end
    return keyselect(tbl)
end


local game = 
{
    tick = 30,
    sceneid = 0,
    area = scenekey("area") --战斗区域
}

local logic = {}

logic["game.basic.player_born_logic"] = 
{
    players =
    { -- 出生位置
        { seat =  1, camp = 1, stance = 1, roleid = 1102, position = { 4000, 5500 }, header = { 0, 1000 }, name = '坦克',},
        { seat =  2, camp = 1, stance = 2, roleid = 1104, position = { 7800, 5500 }, header = { 0, 1000 }, name = '野蛮人',},
        { seat =  3, camp = 1, stance = 3, roleid = 3202, position = { 2000, 2000 }, header = { 0, 1000 }, name = '刺客',},
        { seat =  4, camp = 1, stance = 4, roleid = 3203, position = { 6000, 2000 }, header = { 0, 1000 }, name = '射手',},
        { seat =  5, camp = 1, stance = 5, roleid = 3201, position = { 10000, 2000 }, header = { 0, 1000 }, name = '法师',},
 
        { seat =  6, camp = 2, stance = 1, roleid = 1105, position = { 4000, 14500 }, header = { 0, -1000 }, name = '野蛮人',},
        { seat =  7, camp = 2, stance = 2, roleid = 1103, position = { 7800, 14500 }, header = { 0, -1000 }, name = '坦克',},
        { seat =  8, camp = 2, stance = 3, roleid = 3201, position = { 2000, 18000 }, header = { 0, -1000 }, name = '射手',},
        { seat =  9, camp = 2, stance = 4, roleid = 3202, position = { 6000, 18000 }, header = { 0, -1000 }, name = '法师',},
        { seat = 10, camp = 2, stance = 5, roleid = 3204, position = { 10000, 18000 }, header = { 0, -1000 }, name = '刺客',},
    },

    born = { 
        [1] = { delay = 500, interval = 500, active = "born_battle" }, -- 己方阵营
        [2] = { active = "born_battle"} -- 敌方阵营
     },
    prepare_time = scenekey("prepare_time"), --角色开始移动的时间
    buff = scenekey("buff"),
}

logic["game.play.game_timerunle_logic"] =
{
    duration = 90000,--0,
    settle = {
        [1] = { duration = 3000 }, -- 阵营1胜利
        [2] = { duration = 1500 }, -- 阵营2胜利
    }
}

logic["game.basic.camera_adjust_logic"] =
{
    delay = scenekey("camera_adjust_delay"),  -- 延迟检测(运镜开始时间) 
    interval = 300, -- 检测间隔
    clampx = {-8000,8000},  -- x偏移范围
    clampy = {-8000,8000},  -- y偏移范围
    lift = 0,
}

--摄像机类型
logic["game.basic.camera_strategy_logic"] =
{
    delay = scenekey("camera_strategy_delay"),
    strategy_list = 
    {
        gamestart = 
        {
            strategy = CAMERA_STRATEGY.BONE,
            confkey = "data_battle_key",
            argskey = "camera_start",
        },
        game_fast_start = 
        {
            strategy = CAMERA_STRATEGY.TRANSFORM,
            confkey = "data_battle_key",
            argskey = "game_fast_start",
        },
        camera_adjust_start = 
        {
            strategy = CAMERA_STRATEGY.ADJUST,
            confkey = "data_battle_key",
            argskey = "camera_adjust",
        }
    }
}

return { game, logic }