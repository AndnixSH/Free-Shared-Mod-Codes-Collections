local CampaignProxy = require "Modules.Campaign.CampaignProxy"
local BattleProxy = require "Modules.Battle.BattleProxy"
local HeroProxy = require "Modules.Hero.HeroProxy"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"

local BattleMainPanle = BattleMainPanle or BaseClass(GameObjFactor)
function BattleMainPanle:__init(go, args)
	self.args = args
	self.go = go
	self:Load(go)	
end
function BattleMainPanle:Load(obj)
   	--info
   	self.titleLbl = self:GetChildComponent(obj, "TopPanel/title/CLabel_title", "CLabel")
   	self.topTipsObj = self:GetChild(obj, "TopPanel/TipsPanel")
   	self.tipsLab = self:GetChildComponent(obj, "TopPanel/TipsPanel/CSprite_Back/CCanvas_New/Viewport/Content", "CLabel")
end

function BattleMainPanle:Open()
	local mainlineid = self.args[2]
	local mainlinecfg = CampaignProxy.Instance:GetMainLineCfgById(mainlineid)
	self.titleLbl.text = string.format("%s-%s", mainlinecfg.chapter, mainlinecfg.section)--self:GetWord("MainLineCommon_1001", string.format("%s-%s", mainlinecfg.chapter, mainlinecfg.section))
	
	if mainlinecfg.system_prompt then
		if mainlinecfg.system_prompt ~= "" then
			self.topTipsObj:SetActive(true)
			self.tipsLab.text = LanguageManager.Instance:GetWord(mainlinecfg.system_prompt)
		else
			self.topTipsObj:SetActive(false)
		end
	else
		self.tipsLab.text = ""
		self.topTipsObj:SetActive(false)
	end
end

function BattleMainPanle:Close()
end

function BattleMainPanle:Destroy()
end

function BattleMainPanle:StartGame(hero_infos, enemyinfos)

	local MercenaryProxy = require "Modules.Mercenary.MercenaryProxy"
	local result = MercenaryProxy.Instance:CheckUseHireHeroBattle(hero_infos, ACTIVITYID.MAINLINE, 0)
	if result ~= 0 then
		return
	end

	local bStart, lowestPower = self:CheckFight(hero_infos, self.args[1])
	if not bStart then
		local str = LanguageManager.Instance:GetWord("BattleSelect_1005", lowestPower)
		GameLogicTools.ShowMsgTips(str)
		return
	end

	local bufferstr = string.pack(">I4I4", table.unpack(self.args))
	-- BattleProxy.Instance:Send50005(ACTIVITYID.MAINLINE, hero_infos, enemyinfos, bufferstr)
	CampaignProxy.Instance:Send51007(hero_infos, enemyinfos, bufferstr)

	if SystemConfig.isIGGTestPlatform() then
		local SdkProxy = require "Modules.Sdk.SdkProxy"
		local SdkDef = require "Modules.Sdk.SdkDef"
		local mainlineid = RoleInfoModel.mainlineid
		local param = {}
		param.mission = mainlineid
		SdkProxy.Instance:sdk_logevent(SdkDef.firebase_event.Battle_Start, param)
	end
end

function BattleMainPanle:SetEnemy(enemyid)
	if self.args then
		self.args[1] = enemyid
	end
end

function BattleMainPanle:CheckFight(hero_infos, enemyid)
	local lowestPower = self:GetLowestPower(enemyid)
	local fightstr, fight = HeroProxy.Instance:GetHeroFight(hero_infos)
	local bstart = fight >= lowestPower and true or false
	return bstart, lowestPower
end

--上阵英雄所需最低战力
function BattleMainPanle:GetLowestPower(enemyid)
	local mainlineid = self.args[2]
	return CampaignProxy.Instance:GetLowestPower(mainlineid, enemyid)
end


return BattleMainPanle
