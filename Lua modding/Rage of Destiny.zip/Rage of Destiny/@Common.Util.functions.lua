require "Common.Util.bit"

local isShowLog = true

--新建表
function newTable(table)
    local o = {}
    setmetatable(o, table)
    table.__index = table
    return o
end

-- 将数字转出字符串，大于一万转出格式为x.xx万
function numToString(num)
    if num < 10000 then
        local str = tostring(num)
        return str
    else
        local newNum = num / 10000
        local str = string.format("%.2f万", newNum)
        return str
    end
end

function numToString3(num)
    if num < 10000 then
        local str = tostring(num)
        return str
    else
        local newNum = num / 10000
        local str = string.format("%.2fw", newNum)
        return str
    end
end

-- 将数字转出字符串，格式为xx,xxx,xxx
function numToString2(num, fuhao)
    if num < 1 then
        return "0"
    end

    local str = ""
    local count = 0
    while (true) do
        local n1 = math.floor(num / 10)
        local n2 = num - n1 * 10

        if count >= 3 then
            count = 0

            if nil == fuhao then
                str = tostring(n2) .. "," .. str
            else
                str = tostring(n2) .. fuhao .. str
            end
        else
            str = tostring(n2) .. str
        end

        if n1 <= 0 then
            return str
        end

        num = n1

        count = count + 1
    end

    return "numToString2 Error:" .. tostring(num)
end

-- 将牌值转出0x进制字符串
function convertToCardName(cardValue)
    local v2 = cardValue % 16
    local s2 = tostring(v2)
    if v2 == 10 then
        s2 = "A"
    elseif v2 == 11 then
        s2 = "B"
    elseif v2 == 12 then
        s2 = "C"
    elseif v2 == 13 then
        s2 = "D"
    end

    return "0x" .. tostring(math.floor(cardValue / 16)) .. s2
end

--table拷贝（不建议拷贝有多重循环的表）
function copyTable(cTab)
    local tab = {}
    for k, v in pairs(cTab or {}) do
        if "table" == type(v) then
            tab[k] = v
        else
            tab[k] = copyTable(v)
        end
    end

    return tab
end

--unity 对象判断为空, 如果你有些对象是在c#删掉了，lua 不知道
--判断这种对象为空时可以用下面这个函数
function IsNil(uobj)
    return uobj == nil or uobj:Equals(nil)
end

function connectStr(_mainCmb, _subCmd)
    local a = ""
    if tonumber(_subCmd) >= 100 then
        a = "0" .. tostring(_subCmd)
    elseif tonumber(_subCmd) < 100 and tonumber(_subCmd) >= 10 then
        a = "00" .. tostring(_subCmd)
    elseif tonumber(_subCmd) < 10 and tonumber(_subCmd) > 0 then
        a = "000" .. tostring(_subCmd)
    end
    return tostring(_mainCmb) .. a
end

-- 所有超过万的数值，都显示为万的格式，并预留两位小数。如561111，显示为56.11万
function formatNumber2Chinese(_number)
    if type(_number) ~= "number" then
        return "value not 'number' type"
    end
    if tonumber(_number) >= 10000 then
        local value = _number / 10000
        local _d, _f = math.modf(value)

        local str = tostring(_d)
        --预留两位小数
        _f = string.format("%.2f", _f)
        _f = toCharArray(_f)
        if tonumber(_f[3]) >= 0 and tonumber(_f[4]) > 0 then
            str = string.format("%.2f", value)
        elseif tonumber(_f[3]) > 0 and tonumber(_f[4]) == 0 then
            str = string.format("%.1f", value)
        end
        return str .. "万"
    end

    return tostring(_number)
end

-- 所有超过万的数值，都显示为万的格式，总共需要四位（包含小数）
function formatNumber2Four(_number)
    if type(_number) ~= "number" then
        return "value not 'number' type"
    end
    if tonumber(_number) >= 10000 then
        local _d = string.sub(tostring(_number), 1, -5)
        local str = _d
        local xiaoshu = string.sub(tostring(_number), -4, -1)
        local _d1 = string.sub(xiaoshu, 1, 1)
        local _d2 = string.sub(xiaoshu, 2, 2)
        if (tonumber(_d) / 100 >= 1) and (tonumber(_d) / 100 < 10) then
            if tonumber(_d1) > 0 then
                str = _d .. "." .. _d1
            else
                str = _d
            end
        elseif tonumber(_d) / 100 >= 10 then
            str = _d
        else
            if tonumber(_d1) >= 0 and tonumber(_d2) > 0 then
                str = _d .. "." .. _d1 .. _d2
            elseif tonumber(_d1) > 0 and tonumber(_d2) == 0 then
                str = _d .. "." .. _d1
            end
        end
        return tostring(str) .. "万"
    end

    return tostring(_number)
end
-- 将字符串转正字符数组
function toCharArray(_str)
    if not _str then
        return nil
    end
    if type(_str) ~= "string" then
        _str = tostring(_str)
    end

    -- local str1 = "OK 我赢了,.12345679abcdefghijklmnopqrstuvwxyz!@#$%^&*()_+"
    local arr = {}
    --方法一：原始方法来判断
    -- i = 1
    -- while true do
    --     c = string.sub(_str,i,i)
    --     b = string.byte(c)
    --     if b > 128 then
    --         -- print(string.sub(_str,i,i+2))
    --         table.insert(arr, string.sub(_str,i,i+2))
    --         i = i + 3
    --     else
    --         table.insert(arr, c)
    --         i = i + 1
    --     end
    --     if i > #_str then
    --         break
    --     end
    -- end

    --方法二：通过正则来判断
    -- 得到str中的字符数
    local _, count = string.gsub(_str, "[^\128-\193]", "")
    -- 把_str中所有字符压入table表arr中
    for uchar in string.gfind(_str, "[%z\1-\127\194-\244][\128-\191]*") do
        arr[#arr + 1] = uchar
    end
    return arr
end

--[[
    比较两个时间，返回相差多少时间
    参数：os.time()
]]
function timediffent(time1, time2)
    --得到相差秒数
    local str1 = time1
    local y1, mo1, d1 = string.match(str1, "(%d+)-(%d+)-(%d+)")
    local h1, m1, s1 = string.match(str1, "(%d+):(%d+):(%d+)")
    local dif1 = os.time({year = y1, month = mo1, day = d1, hour = h1, min = m1, sec = s1})
    return math.abs(dif1 - time2)
end

--从字符串str中找出被分割符split分割的字段并转换为数字，返回一个单个数字的tabel表
--如LuaSplit("1,2,3,4", ",")
--结果：tab = {1,2,3,4}而不是{"1","2","3","4"}
function LuaSplitToNumber(str, split)
    if str == nil then
        return nil
    end
    local lcSubStrTab = {}
    while true do
        local lcPos = string.find(str, split)
        if not lcPos then
            lcSubStrTab[#lcSubStrTab + 1] = tonumber(str)
            break
        end
        local lcSubStr = string.sub(str, 1, lcPos - 1)
        lcSubStrTab[#lcSubStrTab + 1] = tonumber(lcSubStr)
        str = string.sub(str, lcPos + 1, #str)
    end
    return lcSubStrTab
end

--从字符串str中找出被分割符split分割的字段，返回一个单个字符的tabel表
--如LuaSplit("1,2,3,4", ",")
--结果：tab = {"1","2","3","4"}而不是{1,2,3,4}
function LuaSplitToString(str, split)
    if str == nil then
        return nil
    end
    local lcSubStrTab = {}
    while true do
        local lcPos = string.find(str, split)
        if not lcPos then
            lcSubStrTab[#lcSubStrTab + 1] = str
            break
        end
        local lcSubStr = string.sub(str, 1, lcPos - 1)
        lcSubStrTab[#lcSubStrTab + 1] = lcSubStr
        str = string.sub(str, lcPos + 1, #str)
    end
    return lcSubStrTab
end

--将数字IP转化成字符串IP
function ConvertIP_Num2Str(_number)
    if _number == nil or type(_number) ~= "number" or _number == 0 then
        return nil
    end
    local str = ""
    local mask = bit:d2b(_number)
    local mask_part = {}
    local x = 1
    for j = 1, 4 do
        mask_part[j] = {}
        for k = 1, 8 do
            mask_part[j][k] = mask[x]
            x = x + 1
        end
    end

    for i = 4, 1, -1 do
        str = str .. tostring(bit:_rshift(bit:b2d(mask_part[i]), 24)) .. "."
    end

    return string.sub(str, 1, string.len(str) - 1)
end

function getTableLength(array)
    array = array or {}
    local length = 0
    for k, v in pairs(array) do
        if v then
            length = length + 1
        end
    end
    return length
end
----------------------------------------------------

function SubUTF8String(s, n)
    local dropping = string.byte(s, n + 1)

    if not dropping then
        return s
    end
    if dropping >= 128 and dropping < 192 then
        return SubUTF8String(s, n - 1)
    end

    return string.sub(s, 1, n)
end

function GetIP(txt)
    if WWW == nil then
        return "未知"
    end
    local lowww =
        coroutine.create(
        function()
            local www = WWW("http://ip.chinaz.com/getip.aspx")
            coroutine.www(www)
            if txt == nil then
                return
            end
            local ttt = {}
            for w in string.gmatch(www.text, "%d+") do
                table.insert(ttt, w)
            end
            if txt == nil then
                return
            end
            txt.text = table.concat(ttt, ".")
        end)
    coroutine.resume(lowww)
end

--  封装函数回调参数
--  不管C#接口是否有回传数据也可以自身封装调用返回数据
function selfFunc(func, self, arg)
    local func2 = function(...)
        if arg == nil then
            return func(self, ...)
        else
            return func(self, arg, ...)
        end
    end
    return func2
end

-- 最小数值和最大数值指定返回值的范围。
-- @function [parent=#math] clamp
function math.clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    elseif v > maxValue then
        return maxValue
    else
        return v
    end
end

-- 深拷贝对象
function deepcopy(object)
	local lookup_table = {}

	local function _copy(object)
		if type(object) ~= "table" then
			return object
		elseif lookup_table[object] then
			return lookup_table[object]
		end

		local new_table = {}
		lookup_table[object] = new_table
		for index, value in pairs(object) do
			new_table[_copy(index)] = _copy(value)
		end

        -- return setmetatable(new_table, getmetatable(object))
        return new_table
	end

	return _copy(object)
end

function deepcopy2(orig)
    local orig_type = type(orig)
    local copy
    if orig_type == 'table' then
        copy = {}
        for orig_key, orig_value in next, orig, nil do
            copy[deepcopy(orig_key)] = deepcopy(orig_value)
        end
        setmetatable(copy, deepcopy(getmetatable(orig)))
    else -- number, string, boolean, etc
        copy = orig
    end
    return copy
end

function shallowcopy(orig)
    local orig_type = type(orig)
    local copy
    if orig_type == 'table' then
        copy = {}
        for orig_key, orig_value in pairs(orig) do
            copy[orig_key] = orig_value
        end
    else -- number, string, boolean, etc
        copy = orig
    end
    return copy
end

function deepcompare(t1,t2,ignore_mt)
    local ty1 = type(t1)
    local ty2 = type(t2)
    if ty1 ~= ty2 then return false end
    -- non-table types can be directly compared
    if ty1 ~= 'table' and ty2 ~= 'table' then return t1 == t2 end
    -- as well as tables which have the metamethod __eq
    local mt = getmetatable(t1)
    if not ignore_mt and mt and mt.__eq then return t1 == t2 end
    for k1,v1 in pairs(t1) do
        local v2 = t2[k1]
        if v2 == nil or not deepcompare(v1,v2) then 
            return false, k1, v1, v2 
        end
    end
    for k2,v2 in pairs(t2) do
        local v1 = t1[k2]
        if v1 == nil or not deepcompare(v1,v2) then 
            return false, k2, v1, v2 
        end
    end
    return true
end

function isEqual(a,b)

    local function isEqualTable(t1,t2)
 
       if t1 == t2 then
          return true
       end
 
        for k,t1v in pairs(t1) do

            local t2v = t2[k]
            local type1 = type(t1v)
            local type2 = type(t2v)
 
            if type1 ~= type2 then
                return false
            end

            if type1 == "table" then
                if not isEqualTable(t1v, t2v) then
                    return false
                end
            else
                if t1v ~= t2v then
                    return false
                end
            end
       end
 
       for k,t2v in pairs(t2) do

            local t1v = t1[k]
            local type1 = type(t1v)
            local type2 = type(t2v)

            if type1 ~= type2 then
                return false
            end

            if type1 == "table" then
                if not isEqualTable(t1v, t2v) then
                    return false
                end
            else
                if t1v ~= t2v then
                    return false
                end
            end
       end
 
       return true
    end

    local typea = type(a)
    local typeb = type(b)
 
    if typea ~= typeb then
       return false
    end
 
    if typea == "table" then
       return isEqualTable(a,b)
    else
       return (a == b)
    end
 
 end

function guser_encode(zoneid, partid, uin)
    assert(zoneid < 0xffff)
    assert(partid < 0xffff)
    assert(uin < 0xffffffff)
    return (zoneid<<48) + (partid<<32) + uin
end

function guser_decode(guin)
    local uin = guin & 0xffffffff
    guin = guin >> 32
    local partid = guin & 0xffff
    local zoneid = guin >> 16
    return zoneid, partid, uin
end