local RoleInfoProxy = RoleInfoRroxy or BaseClass(BaseProxy)
local RoleInfoDef = require "Modules.RoleInfo.RoleInfoDef"
local LoginProxy = require "Modules.Login.LoginProxy"
local LoginDef = require "Modules.Login.LoginDef"
local CampaignProxy = require "Modules.Campaign.CampaignProxy"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"
local TowerProxy = require "Modules.Tower.TowerProxy"
local crypt = require "crypt"
local md5 = require "First.Util.md5"
local rapidjson = require "rapidjson"
local httputil = require "Common.Util.httputil"
local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
local RedPointDef = require "Modules.RedPoint.RedPointDef"
local HeroProxy = require "Modules.Hero.HeroProxy"
local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
local IGGSdkDef = require "Modules.IGGSdk.IGGSdkDef"
local BagProxy = require "Modules.Bag.BagProxy"

local costWayConfig = {
    [2101] = "Sop_spend_virtual_currency_1001",

    [2141] = "Sop_spend_virtual_currency_1002",
    [2142] = "Sop_spend_virtual_currency_1002",
    
    [2181] = "Sop_spend_virtual_currency_1004",
    [2182] = "Sop_spend_virtual_currency_1005",

    [2221] = "Sop_spend_virtual_currency_1006",
    [2222] = "Sop_spend_virtual_currency_1006",
    [2223] = "Sop_spend_virtual_currency_1006",
    [2224] = "Sop_spend_virtual_currency_1006",

    [2231] = "Sop_spend_virtual_currency_1008",
    [2232] = "Sop_spend_virtual_currency_1008",
    [2233] = "Sop_spend_virtual_currency_1008",
    [2234] = "Sop_spend_virtual_currency_1008",
    [2235] = "Sop_spend_virtual_currency_1008",
    [2236] = "Sop_spend_virtual_currency_1008",

    [2301] = "Sop_spend_virtual_currency_1009",
    [2302] = "Sop_spend_virtual_currency_1009",
    [2304] = "Sop_spend_virtual_currency_1009",
    [2305] = "Sop_spend_virtual_currency_1009",
    [2306] = "Sop_spend_virtual_currency_1009",

    [2311] = "Sop_spend_virtual_currency_1010",
    [2312] = "Sop_spend_virtual_currency_1010",
    [2313] = "Sop_spend_virtual_currency_1010",
    [2314] = "Sop_spend_virtual_currency_1010",
    [2315] = "Sop_spend_virtual_currency_1010",
}

function RoleInfoProxy:__init()
    RoleInfoProxy.Instance = self

    self.data = {}
    self.data.isCreateRole = false
    self:AddProto(10001, self.On10001)
    self:AddProto(10014, self.On10014)
    self:AddProto(10016, self.On10016) -- 人物基础信息改变

    self:AddProto(10017, self.On10017) 
    self:AddProto(10019, self.On10019)
    self:AddProto(10020, self.On10020)
    self:AddProto(10021, self.On10021)
    self:AddProto(10022, self.On10022)
    self:AddProto(10023, self.On10023)
    self:AddProto(10024, self.On10024) 
    self:AddProto(10025, self.On10025) 
    self:AddProto(10026, self.On10026) 
    self:AddProto(10027, self.On10027) 
    self:AddProto(10028, self.On10028) 

    self:AddProto(10029, self.On10029) 
    self:AddProto(10030, self.On10030)

    self:AddProto(10031, self.On10031)
    self:AddProto(10032, self.On10032)
	self:AddProto(10033, self.On10033)
	self:AddProto(10034, self.On10034)
    self:AddProto(10035, self.On10035)

    self.photoData={}
    
    self.data.mainLineUp={}
    self.tempdata=false
    self.data.journey={} --征途
    --self.visitors={} --访客
    self.signature=""
    self.haseditnickname=0
    self.haseditmainlineup = 0
    
    self.fromMainLineUpgradeData={}
end

function RoleInfoProxy:__delete()
    self.data = nil
end

function RoleInfoProxy:On10001(decoder)
    --print("----RoleInfoProxy--On10001---------")
    local currency_infos = decoder:DecodeList("I4")
    for currency_type, currency_count in ipairs(currency_infos) do
        local key = RoleInfoDef.CurrencyType[currency_type]
        RoleInfoModel[key] = currency_count
    end
    RoleInfoModel.guserid = decoder:Decode("I8")
    RoleInfoModel.nickname = decoder:Decode("s2")
    RoleInfoModel.sex = decoder:Decode("I1")
    RoleInfoModel.level = decoder:Decode("I2")
    --RoleInfoModel.player_exp = decoder:Decode("I4")
    --RoleInfoModel.coin = decoder:Decode("I4")
    --RoleInfoModel.diamond = decoder:Decode("I4")
    RoleInfoModel.headicon = decoder:Decode("I2")
    RoleInfoModel.frameicon = decoder:Decode("I2")
    RoleInfoModel.mainlineid = decoder:Decode("I2") + 1
    RoleInfoModel.current_section = decoder:Decode("I1")
    --RoleInfoModel.hero_exp = decoder:Decode("I4")
    --RoleInfoModel.vip_exp = decoder:Decode("I4")
    --RoleInfoModel.medals_valor = decoder:Decode("I4")
    --RoleInfoModel.guild_coin = decoder:Decode("I4")
    --RoleInfoModel.hero_coin = decoder:Decode("I4")
    --RoleInfoModel.labyrinth_token = decoder:Decode("I4")
    --RoleInfoModel.challenger_coin = decoder:Decode("I4")
    --RoleInfoModel.twisted_sigil = decoder:Decode("I4")
    --RoleInfoModel.companion_points = decoder:Decode("I4")
    --RoleInfoModel.heroic_merit = decoder:Decode("I4")
    --RoleInfoModel.inv_essence = decoder:Decode("I4")
    --RoleInfoModel.dragon_ball = decoder:Decode("I4")
    RoleInfoModel.viplevel = decoder:Decode("I2")
    
    local serverTimeZoneSign = decoder:Decode("I1")
    local serverTimeZone = decoder:Decode("I1")
    if serverTimeZoneSign == 2 then --1:正号 2:负号
        serverTimeZone = serverTimeZone * -1
    end
    RoleInfoModel.serverTimeZone = serverTimeZone

    local is_newbie_drama = 0
    is_newbie_drama = decoder:Decode("I1")

    RoleInfoModel.is_open_rating = decoder:Decode("I1")
    -- print("RoleInfoProxy:On10001", serverTimeZone)

    local need_agreement = 1
    need_agreement = decoder:Decode("I1")

    --设想玩家基础信息
    --local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
    IGGSdkProxy.Instance:SetPlayerInfo(
        RoleInfoModel.uid, RoleInfoModel.nickname,
        RoleInfoModel.level, RoleInfoModel.server_id, 0
    )
    
    CampaignProxy.Instance:SetGoBtnState()
    if not LoginProxy.Instance:GetIsReconnect() then -- 断线重连
       

        self:SetDefaultRoleName()

        --请求得到玩家数据在进入主场景
        --local SceneManager = require "Modules.Scene.SceneManager"
        --local SceneDef = require "Modules.Scene.SceneDef"
        if SystemConfig.isIGGTestPlatform() then
            local SdkProxy = require "Modules.Sdk.SdkProxy"
            local SdkDef = require "Modules.Sdk.SdkDef"
            local params = {}
            params.memory = tostring(CS.UnityEngine.SystemInfo.systemMemorySize)
            SdkProxy.Instance:sdk_logevent(SdkDef.firebase_event.Game_Start, params)
        end

        if SystemConfig.isIGGPlatform() then
            --在游戏loading开始前调用InformAsap 弹协议相关
            --local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
            IGGSdkProxy.Instance:InformAsap()

            --if need_agreement == 0 then -- 需要弹协议
			if RoleInfoModel.mainlineid > IGGSdkDef.ShowInformViewMainlineID then -- 需要弹协议
                IGGSdkProxy.Instance:InformKindly()
            end

            -- local NewbieDef = require "Modules.Newbie.NewbieDef"
            -- local _key = NewbieDef.FinishNewbieKey .. RoleInfoModel.uid
            -- local FinishNewbieKeyValue = PlayerPrefs.GetInt(_key, 0)
            -- if FinishNewbieKeyValue == 1 then
            --     local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
            --     IGGSdkProxy.Instance:InformKindly()
            -- end
        end
        --print("----RoleInfoProxy--On10001----is_newbie_drama-----",is_newbie_drama)
        if is_newbie_drama == 0 then
            SceneManager.Instance:EnterScene(SceneDef.SceneType.Drama)
        else
            SceneManager.Instance:EnterScene(SceneDef.SceneType.Main)
            -- local ScreenShotter = require "Common.Util.ScreenShotter"
            -- ScreenShotter.Enable()
        end
    else
        self:SendCacheProto()
        LoginProxy.Instance:SetIsReconnect(false)
    end
    self:Send10029()

    --系统开放
    local ModuleManager = require "Common.Mgr.UI.ModuleManager"
    ModuleManager.InitSystemOpen()
end

function RoleInfoProxy:SetDefaultRoleName()
    if RoleInfoModel.nickname and RoleInfoModel.nickname ~= "" then
        local defaultname = self:GetDefaultName()
        if defaultname ~= RoleInfoModel.nickname then
            self.data.isCreateRole = true
        end
    else
        self.data.isCreateRole = false
    end
end

--默认名字
function RoleInfoProxy:GetDefaultName()
    local defaultname = ""
    local SdkProxy = require "Modules.Sdk.SdkProxy"
    local isIgg = SdkProxy.Instance:isIGGPlatform()
    if isIgg then
        defaultname = string.format("ID.%s", RoleInfoModel.player_id)
    else
        defaultname = string.format("DEBUG.%s", RoleInfoModel.player_id)
    end
    return defaultname
end

function RoleInfoProxy:GetMainLineUp()
    return self.data.mainLineUp --仅仅只是herouid
end

function RoleInfoProxy:GetCurrentLevelMaxPlayerExp(level,player_exp)
    local config= ConfigManager.GetConfig("data_account")
    local data=config[level]
    if data then
        return data.upgrad_exp
    end
    return 100
end

function RoleInfoProxy:GetCurrentLevelPlayerExp(level,player_exp)
    local config= ConfigManager.GetConfig("data_account")
    if not config[level-1] then
        --print(string.format("error GetCurrentLevelPlayerExp:%d",level))
        return player_exp
    end
    local exp=level <= 1 and  player_exp or (player_exp-config[level-1].total_exp)
   
    if exp then
        return exp
    end
    return 0
end

--是否创角
function RoleInfoProxy:IsCreateRole()
    return self.data.isCreateRole
end

--data Proto
function RoleInfoProxy:On10014(decoder)
    local typeid, count, way = decoder:Decode("I2I4I2")
    local changeValue = 0

    local key = RoleInfoDef.CurrencyType[typeid]
    if key then
        changeValue = count - RoleInfoModel[key]

        RoleInfoModel[key] = count
        self:ToNotify(self.data, RoleInfoDef.NotifyDef.Currency_Change, {typeid = typeid, count = count})   
    
        -- print("RoleInfoProxy:On10014", way, changeValue, typeid)

        --事件
        local goodsid = CURRENCY_TYPE_GOODID[typeid]
        local costWay = costWayConfig[way]
        if changeValue < 0 and goodsid and costWay and (typeid == CURRENCY_TYPE.diamond or typeid == CURRENCY_TYPE.coin) then
            local jsonStr
            local cfg = BagProxy.Instance:GetGoodsCfgById(goodsid)
            local name = LanguageManager.Instance:GetWord(cfg.name)

            if SystemConfig.isIGGPlatform() then
                -- local p = {
                --     [IGGSdkDef.SecondEventParam.SpendVirtualCurrencyItemName] = LanguageManager.Instance:GetWord(costWay),
                --     [IGGSdkDef.SecondEventParam.SpendVirtualCurrencyContent] = name,
                --     [IGGSdkDef.SecondEventParam.SpendVirtualCurrencyValue] = changeValue * -1,
                --     [IGGSdkDef.SecondEventParam.SpendVirtualCurrencyContentId] = tostring(goodsid),
                --     [IGGSdkDef.SecondEventParam.SpendVirtualCurrencyContentType] = tostring(cfg.type),
                -- }
                -- jsonStr = rapidjson.encode(p)
                -- IGGSdkProxy.Instance:Track(IGGSdkDef.SecondEventName.SpendVirtualCurrency, jsonStr)
                IGGSdkProxy.Instance:SendSpendVirtualCurrency(name, tostring(goodsid), tostring(cfg.type), changeValue * -1, LanguageManager.Instance:GetWord(costWay))
            end

            -- print("RoleInfoProxy:On10014", name, changeValue * -1, LanguageManager.Instance:GetWord(costWay))
        end
    end
end

function RoleInfoProxy:GetUpgradeInfo()
    return self:GetAccountUpgradeData()
end

function RoleInfoProxy:On10016(decoder) --信息发生改变  先收到等级 后收到经验
    local type,level = decoder:Decode("I2I4")
    if type == CURRENCY_TYPE.player_exp then
        if level ~= RoleInfoModel.level then
            --弹出等级升级奖励动画
            local awardlist={}
            local count=decoder:Decode("I2")
            for i=1,count do
                local goodsid,goodsnum=decoder:Decode("I4I2")
                table.insert(awardlist,{goodsid,goodsnum})
            end
			
			local Item={}
			Item.curlevel=RoleInfoModel.level
			Item.targetlevel=level
			Item.awardlist=awardlist
			table.insert(self.fromMainLineUpgradeData,Item)
			
            if SceneManager.Instance.sceneType == SceneDef.SceneType.Main then
                LuaLayout.Instance:OpenWidget(UIWidgetNameDef.AccountUpgradeView)
            end
            
            if SystemConfig.isIGGTestPlatform() then
                local SdkProxy = require "Modules.Sdk.SdkProxy"
                local SdkDef = require "Modules.Sdk.SdkDef"
                local param = {}
                param.level = level
                SdkProxy.Instance:sdk_logevent(SdkDef.firebase_event.Playerlv_up, param)
            end

            local IGGSdkDef = require "Modules.IGGSdk.IGGSdkDef"
            local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"

            local max_level = IGGSdkDef.AFEventPlayerLevel[#IGGSdkDef.AFEventPlayerLevel][1]
            if RoleInfoModel.level < max_level then
                for _ , v in ipairs(IGGSdkDef.AFEventPlayerLevel) do
                    if v then
                        if RoleInfoModel.level < v[1] and v[1] <= level then
                            IGGSdkProxy.Instance:Track(v[2])
                        end
                    end
                end
            end
            
            IGGSdkProxy.Instance:SendLevelUp(RoleInfoModel.nickname, level)

        end
        RoleInfoModel.level=level
    elseif type == CURRENCY_TYPE.vip_exp then
        local isChange = false
        if level ~= RoleInfoModel.viplevel then
            --弹出VIP升级提示弹窗
            local VipProxy = require "Modules.Vip.VipProxy"
			VipProxy.Instance:Send72005()
            
            isChange = true
            
            for k = RoleInfoModel.viplevel , level do
                if k > 0 and k <= IGGSdkDef.AFEventVIP.max then
                    IGGSdkProxy.Instance:Track(IGGSdkDef.AFEventVIP.flag..tostring(k))
                end
            end
        end
        --print("------level------------",level)
        RoleInfoModel.viplevel = level

        --系统开放
        if isChange then
            local ModuleManager = require "Common.Mgr.UI.ModuleManager"
            ModuleManager.CheckSystemOpen()
        end
    elseif type == CURRENCY_TYPE.hero_exp then
        
    end
    self:ToNotify(self.data, RoleInfoDef.NotifyDef.RoleInfo_Update)
    -- todo
end

function RoleInfoProxy:HasAccountUpgradeData()
	return self.fromMainLineUpgradeData and (#self.fromMainLineUpgradeData > 0)
end

function RoleInfoProxy:GetAccountUpgradeData()
    if self:HasAccountUpgradeData() then
        local curlevel=self.fromMainLineUpgradeData[1].curlevel
        local targetlevel = self.fromMainLineUpgradeData[#self.fromMainLineUpgradeData].targetlevel
        local awardlist={}
        for k,v in ipairs(self.fromMainLineUpgradeData) do
            if v.awardlist then
                for _, award in pairs(v.awardlist) do
                    local has=false
                    for _, tt in pairs(awardlist) do
                        if tt[1] == award[1] then
                            has=true
                            tt[2] = tt[2] + award[2]
                            break
                        end
                    end
                    if not has then
                        table.insert(awardlist,award)
                    end
                end
            end
        end
		
		local item = {}
        item.curlevel=curlevel
        item.targetlevel=targetlevel
        item.awardlist=awardlist
        return item
    end
end

function RoleInfoProxy:ClearAccountUpgradeData()
    self.fromMainLineUpgradeData={}
end

function RoleInfoProxy:Send10017(decoder)
    --获取个人主页相关信息
    self:SendMessage(10017)
end

function RoleInfoProxy:On10017(decoder)
    local  signature,haseditnickname, part,haseditmainlineup = decoder:Decode("s2I2I2I1")  --公会名字，公会火力值 签名 第一次修改名字，征途： 主线 等级 排名 排名
    local mainlineupIdList=decoder:DecodeList("I4")
    local visitors = decoder:DecodeList("I8I4I4",true)
    --local mainLineUp=self:GetMainLineUpData(mainlineupIdList)
    self.data.mainLineUp=mainlineupIdList
    local visitorsList = {}
    for _ ,v in ipairs(visitors) do
        if v then
            local item = {}
            item.guserid = v[1]
            item.headicon = v[2]
            item.frameicon = v[3]
            table.insert(visitorsList , item)
        end
    end
    local journey=self:GetJourneyData(RoleInfoModel.mainlineid,TowerProxy.Instance:GetCurTowerLayer(0))
    self.data.journey=journey
    
    local tab={}
    local GuildProxy = require "Modules.Guild.GuildProxy"
    tab.guildName= GuildProxy.Instance:ExistGuild() and GuildProxy.Instance:GetGuildName() or ""
    --tab.guildEnergy=guildEnergy
    tab.signature=signature
    tab.serverName=tostring(part)..LanguageManager.Instance:GetWord(RoleInfoDef.CommonDef.Server)
    self.haseditnickname=haseditnickname
    self.haseditmainlineup=haseditmainlineup
    self.signature=signature
    tab.visitors = visitorsList
    self:ToNotify(self.data,RoleInfoDef.NotifyDef.RoleInfo_Request,tab)
end

function RoleInfoProxy:HasEditNickName()
    return self.haseditnickname
end
function RoleInfoProxy:GetSignature()
    return self.signature
end
function RoleInfoProxy:GetJourneyData( mainlineid,level )
    local journey={} --征途
    local tab={}
    tab.id=1  
    tab.name=LanguageManager.Instance:GetWord("RoleInfoView_1041")--"主线" --需根据mainline_id 读配置
    local config=CampaignProxy.Instance:GetMainLineCfgById(mainlineid == 0 and 1 or mainlineid)
    tab.level=config and config.chapter or 0 --章
    tab.layer=config and  config.section or 0--节
    table.insert(journey,tab)
    local tab1={}
    tab1.id=2  --需根据level 读配置
    tab1.name=LanguageManager.Instance:GetWord("RoleInfoView_1042")--"王座之塔"
    tab1.level=level--TowerProxy.Instance:GetCurTowerLayer(0)
    local ModuleManager = require "Common.Mgr.UI.ModuleManager"
    local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
    local openType = ModuleOpenDef.SystemOpenType.TowerEntranceView_0
    local bopen =false
    local config = ModuleManager.GetSystemOpenConfig()
    if config[openType] then
        if config[openType].conditions then
            for i,value in ipairs(config[openType].conditions) do
                if value.openMainId then
                    bopen = mainlineid >= value.openMainId and true or false
                    if bopen then break end
                end
            end
        end
    end
    tab1.bopen = bopen
    table.insert(journey,tab1)
    --config= ConfigManager.GetConfig("data_common")["arena_limit"]
    -- local tab2={}
    -- tab2.id=3  --需根据rank 读配置
    -- tab2.name=LanguageManager.Instance:GetWord("RoleInfoView_1043")--"竞技场"
    -- local limit=config.value1 and  config.value1[1] or 100
    -- tab2.level=rank < limit and rank or 0
    -- table.insert(journey,tab2)
    -- local tab3={}
    -- tab3.id=4  --需根据rank2 读配置
    -- tab3.name=LanguageManager.Instance:GetWord("RoleInfoView_1044")--"高阶竞技场"
    -- config= ConfigManager.GetConfig("data_common")["highlevelarena_limit"]
    -- limit=config.value1 and  config.value1[1] or 100
    -- tab3.level=rank2 < limit and rank2 or 0
    -- table.insert(journey,tab3)
    return journey
end

function RoleInfoProxy:GetMainLineUpData()
    
   local mainLineUp={} --已上阵
   local mainlineupIdList=self.data.mainLineUp
    for i = 1, #mainlineupIdList do 
        local heros=HeroProxy.Instance:GetHeroDataList()
        if heros then
            for k, v in ipairs(heros) do
                if v.herouid == mainlineupIdList[i] then
                    table.insert(mainLineUp,v)
                    break
                end
            end
        end
        
    end
    return mainLineUp
end

function RoleInfoProxy:GetPhotoIconNameById(photoid)

    local config= ConfigManager.GetConfig("data_collection")
    if config[photoid] then
        local icon=config[photoid].icon
        return  icon
    else
        return nil
    end
   
   
end

function RoleInfoProxy:GetPhotoFrameIconNameById(photoframeid)

    local config= ConfigManager.GetConfig("data_collection")

    if config[photoframeid] then
        local icon=config[photoframeid].icon
        return  icon
    else
        return nil
    end
end

function RoleInfoProxy:GetPhotoData()

    local config= ConfigManager.GetConfig("data_collection")
    local tab={}  --获取头像数据
    if not config then
        return tab
    end
    for _, v in pairs(config) do
        if v then
            if v.type == 1 then
                table.insert(tab,v)
            end
        end
    end
    table.sort(tab, function(a,b)
        return a.id < b.id
    end)
    return tab
end

function RoleInfoProxy:GetPhotoFrameData()

    local tab={}  --获取头像框数据
    local config= ConfigManager.GetConfig("data_collection")
    if not config then
        return  tab
    end
    for _, v in pairs(config) do
        if v then
            if v.type == 2 then
                table.insert(tab,v)
            end
        end
    end
    table.sort(tab, function(a,b)
        return a.id < b.id
    end)
    return tab
end


function RoleInfoProxy:Send10019()
    --获取持有的 头像框  头像列表
    self:SendMessage(10019)
end


function RoleInfoProxy:On10019(decoder)
    --获取持有的 头像框  头像列表
    local photoData={}
    local frameData={}

    local ownphotoData={}
    local ownframeData={}

    ownphotoData=decoder:DecodeList("I2")
    ownframeData=decoder:DecodeList("I2")
    local config= ConfigManager.GetConfig("data_collection")
    for k,id in pairs(ownframeData) do
        local item={}
        item.id=id
        local _config = config[id]
        if _config then
            item.frameicon=_config.icon 
            item.name=LanguageManager.Instance:GetWord(_config.name or "")
            item.bhas=true
            item.quality=_config.quality or 1
            item.comefrom=LanguageManager.Instance:GetWord(_config.get_info or "")
            table.insert(frameData,item)
        end
        
    end
    for k,id in pairs(ownphotoData) do
        local item={}
        item.id=id
        local _config = config[id]
        if _config then
            item.headicon=_config.icon
            item.name=LanguageManager.Instance:GetWord(_config.name or "")
            item.bhas=true
            item.comefrom=LanguageManager.Instance:GetWord(_config.get_info or "")
            table.insert(photoData,item)
        end
    end
    table.sort(photoData, function(a,b)
        return a.id < b.id
    end)

    table.sort(frameData, function(a,b)
        return a.id < b.id
    end)
    
    local tab={}
    tab.photoData=photoData
    tab.frameData=frameData
    RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.Head_New,0)
    self:ToNotify(self.data,RoleInfoDef.NotifyDef.PhotoInfo_Request,tab)
end



function RoleInfoProxy:On10021(decoder)
    --修改头像
    local result=decoder:Decode("I1")
    if result == 0 then
       RoleInfoModel.headicon=self.tempdata
       self:ToNotify(self.data,RoleInfoDef.NotifyDef.Photo_Update)
    else
        GameLogicTools.ShowErrorCode(10021, result)
    end
end

function RoleInfoProxy:Send10021(headicon)
    --修改头像
    self.tempdata=headicon
    local encoder=NetEncoder.New()
    encoder:Encode("I2",headicon)
    self:SendMessage(10021,encoder)
    
    print("发送成功="..tostring(headicon))
end

function RoleInfoProxy:On10020(decoder)
    --修改头像框
    local result=decoder:Decode("I1")
    if result == 0 then
       RoleInfoModel.frameicon=self.tempdata
       self:ToNotify(self.data,RoleInfoDef.NotifyDef.PhotoFrame_Update)
    else
        GameLogicTools.ShowErrorCode(10020, result)
    end
end

function RoleInfoProxy:Send10020(frameicon)
    --修改头像框
    self.tempdata=frameicon
    local encoder=NetEncoder.New()
    encoder:Encode("I2",frameicon)
    self:SendMessage(10020,encoder)
end

function RoleInfoProxy:Send10022(index)
    --修改性别
    self.tempdata=index
    local encoder=NetEncoder.New()
    encoder:Encode("I1",index)
    self:SendMessage(10022,encoder)
end

function RoleInfoProxy:On10022(decoder)
    --修改性别
    local result=decoder:Decode("I1")
    if result == 0 then
       RoleInfoModel.sex=self.tempdata
       self:ToNotify(self.data,RoleInfoDef.NotifyDef.Sex_Update)
    else
        GameLogicTools.ShowErrorCode(10022, result)
    end
end

function RoleInfoProxy:Send10023(nickname)
    --修改名字
    
    local encoder=NetEncoder.New()
    encoder:Encode("s2",nickname)
    self:SendMessage(10023,encoder)
end

function RoleInfoProxy:On10023(decoder)
    --修改名字
    local result, newName=decoder:Decode("I1s2")
    -- local result=decoder:Decode("I1")
    if result == 0 then
        -- RoleInfoModel.nickname= self.tempdata
        RoleInfoModel.nickname= newName
        self.haseditnickname=1
        --self:ToNotify(self.data,RoleInfoDef.NotifyDef.NickName_Update)
    else
        GameLogicTools.ShowErrorCode(10023, result)
    end
   
end

function RoleInfoProxy:Send10025(signature)
    --修改签名
    self.tempdata=signature
    local encoder=NetEncoder.New()
    encoder:Encode("s2",signature)
    self:SendMessage(10025,encoder)
end

function RoleInfoProxy:On10025(decoder)
    --修改签名
    local result=decoder:Decode("I1")
    if result == 0 then

        local signature=self.tempdata
        self.signature=signature
        self:ToNotify(self.data,RoleInfoDef.NotifyDef.Signature_Update,signature)
    else
        GameLogicTools.ShowErrorCode(10025, result)
    end
    self.tempdata=false
end

function RoleInfoProxy:Send10024(mainlineUp)
    --修改主力阵容
   
    local encoder= NetEncoder.New()
    encoder:EncodeList("I4",mainlineUp)
    self.tempdata=mainlineUp
    self:SendMessage(10024,encoder)
end


function RoleInfoProxy:On10024(decoder)
    --修改主力阵容
    local result=decoder:Decode("I1")
    if result == 0 then
        --成功
        self.haseditmainlineup = 1
        if self.tempdata then
            
            local mainlineupIdList={}
            for i=1,#self.tempdata do
                table.insert(mainlineupIdList,self.tempdata[i])
            end
            --local mainLineUp=self:GetMainLineUpData(mainlineupIdList)
            self.data.mainLineUp=mainlineupIdList
            self:ToNotify(self.data,RoleInfoDef.NotifyDef.MainLineUp_Update)
        end
        GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord(RoleInfoDef.CommonDef.saveSuccess))
    else
        GameLogicTools.ShowErrorCode(10024, result)
    end
    self.tempdata=false
end

function RoleInfoProxy:CheckShowChangeNameView()

    local mainlinecfg=CampaignProxy.Instance:GetCurMainLine()
    if RoleInfoModel.mainlineid == 31  and not CampaignProxy.Instance:IsPassToNextChapter() then -- 当玩家未起名的状态下，通关3-6后会返回主界面，此时自动弹出取名界面
    --if  CampaignProxy.Instance:IsPassToNextChapter() and mainlinecfg.chapter == 2 then
        
        --第二关打完后需要弹出改名页面 ,只弹一次
        local show = self:HasShowChangeNameViewAuto()
        if not show then
            self:SetShowChangeNameViewAutoState()
            LuaLayout.Instance:OpenWidget(UIWidgetNameDef.ChangeNameView)
        end
    end
end



-- function RoleInfoProxy:Send10025(accountId)
--     --发送兑换码
-- end
    
-- function RoleInfoProxy:On10025(decoder)
--     --发送兑换码

-- end

function RoleInfoProxy:Send10026(guerid)
    --请求其他玩家的信息
    local encoder= NetEncoder.New()
    encoder:Encode("I8",guerid)
    self:SendMessage(10026,encoder)
end

function RoleInfoProxy:On10026(decoder)
    
   local HeroProxy = require "Modules.Hero.HeroProxy"
   local ArenaDef = require "Modules.Arena.ArenaDef"
   local list={}
   local defencefight={}
   local formations={}
   local num=1
   local roomType=1
   if roomType ==ArenaDef.RoomType.HighArena then
        num=3
   end
   local roleinfo={}
    roleinfo.mainupdata={} --主力阵容
    --roleinfo.herodata={}  --防守阵容
    --roleinfo.defencefight={}
    local guildName = "" --公会名字
    local serverName = "s1" --服务器名字
    local guildEnergy = 100
    local level = 20 --王座之塔排名
    local rank =  1
    local rank2 = 1
    local mainlineid=1
    local fight=0
    local part = 1
    local result = decoder:Decode("I1")
    if result == 0 then
        local mainlineup_data=decoder:DecodeList("I4I4I2I2I2I4",true)
        roleinfo.nickname,
        roleinfo.sex ,roleinfo.level,roleinfo.headicon,roleinfo.frameicon,roleinfo.uid,
        roleinfo.player_exp,roleinfo.signature,fight,guildName,level,mainlineid,part = decoder:Decode("s2I1I2I2I2I4I4s2I4s2I2I4I2")
        roleinfo.fight = GameLogicTools.GetNumStr(fight)
        for _,v in ipairs(mainlineup_data) do
            if v then
                local hero={}
                hero.herouid=v[1]
                hero.roleid=v[2]
                hero.level=v[3]
                hero.rank=v[4]
                if v[5] > 0 then
                    hero.crystalLevel = v[5]
                end
                hero.curskin=v[6]
                table.insert(roleinfo.mainupdata,hero)
            end
        end
        local towercfg=TowerProxy.Instance:GetTowerCfgById(level)
        local layer = 1
        if towercfg then
            layer=towercfg.layer
        else
            print("-------towerid=------------",level)
        end
        local journey=self:GetJourneyData(mainlineid + 1,layer)
        roleinfo.journey=journey
        
        local tab={}
        tab.guildName=guildName
        tab.guildEnergy=guildEnergy
        tab.signature=roleinfo.signature
        tab.serverName=tostring(part)..LanguageManager.Instance:GetWord(RoleInfoDef.CommonDef.Server)
        roleinfo.guild=tab
        self:ToNotify(self.data,RoleInfoDef.NotifyDef.OtherRoleInfo_Update,roleinfo)
    else
        GameLogicTools.ShowErrorCode(10026,result)
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.NetworkDelayView)
    end
    
end

--领取sop奖励
function RoleInfoProxy:Send10027(sop_award_type)
    local encoder = NetEncoder.New()
    encoder:Encode("I2", sop_award_type)
    self:SendMessage(10027, encoder)
end

function RoleInfoProxy:On10027(decoder)
    local award_list = decoder:DecodeList("I4I2", true)
    local goodsInfos = {}
    for i,v in ipairs(award_list) do
        table.insert(goodsInfos, {goodsid = v[1], goodsnum = v[2]})
    end
    if #goodsInfos > 0 then
        --还没有领取过奖励
        GameLogicTools.ShowGetItemView(goodsInfos,1)
    end
    -- print("awardlist====", table.dump(award_list))
end

--获取sop类型奖励是否已领取, 之前是领了奖励就不再弹出
function RoleInfoProxy:Send10028(sop_award_type)
    local encoder = NetEncoder.New()
    encoder:Encode("I2", sop_award_type)
    -- print("Send10028===", sop_award_type)
    self:SendMessage(10028, encoder)
end

function RoleInfoProxy:On10028(decoder)
    local sop_type, get_status = decoder:Decode("I2I2")
    -- print("On10028===", sop_type, get_status)
    if sop_type == RoleInfoDef.Sop_Award_Type.Rating_Award then
        --获取sop类型奖励是否已领取, 之前是领了奖励就不再弹出
        self:CheckShowRatingView()
    end
end

--弹出评星奖励界面
function RoleInfoProxy:CheckShowRatingView()
    if SystemConfig.isIGGPlatform() then 
        if RoleInfoModel.is_open_rating == 0 then
            if SystemConfig.AppConfig and SystemConfig.AppConfig["rawString"] and
                SystemConfig.AppConfig["rawString"]["Misc"] and 
                SystemConfig.AppConfig["rawString"]["Misc"]["rating"] then
                    local rating = SystemConfig.AppConfig["rawString"]["Misc"]["rating"]
                    local _value = tonumber(rating)
                    if _value ~= 0 then
                        local useWebFeedback = _value == 1 and true or false
                        local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
                        IGGSdkProxy.Instance:ShowAppRating(useWebFeedback)
                        --打开就不弹了
                        self:Send10032() 
                    end
            end
        end
     end
end

--请求头像 头像框红点信息
function RoleInfoProxy:Send10029()
    
    self:SendMessage(10029)
end

function RoleInfoProxy:On10029(decoder)
    local head_new,frame_new ,haseditnickname= decoder:Decode("I1I1I1")

    
    RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.Head_New,head_new)
    RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.Frame_New,frame_new)
    self.haseditnickname = haseditnickname
end

--头像框红点信息
function RoleInfoProxy:Send10030()
    
    self:SendMessage(10030)
    RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.Frame_New,0)
end

function RoleInfoProxy:On10030(decoder)

end

function RoleInfoProxy:Send10031()
    self:SendMessage(10031)
end

function RoleInfoProxy:On10031(decoder)
    local result = decoder:Decode("I1")
    print("On10031 result", result)
end

function RoleInfoProxy:Send10032()
    self:SendMessage(10032)
end

function RoleInfoProxy:On10032(decoder)
    local result = decoder:Decode("I1")
    RoleInfoModel.is_open_rating = 1
    -- print("On10032 result", result)
end

function RoleInfoProxy:On10033(decoder)
	--SdkEventProxy处理
end

function RoleInfoProxy:On10034(decoder)
	--SdkEventProxy处理
end

function RoleInfoProxy:Send10035(value)
    local encoder  = NetEncoder.New()
    encoder:Encode("I1",value)
    self:SendMessage(10035,encoder)
end

function RoleInfoProxy:On10035(decoder)

end

function RoleInfoProxy:SetShowChangeNameViewAutoState()
    local key ="HasShowChangeName"..tostring(RoleInfoModel.guserid)
    PlayerPrefs.SetInt(key,1)
end
function RoleInfoProxy:HasShowChangeNameViewAuto()
    if self.haseditnickname == 1 then
        return true
    end
    local key ="HasShowChangeName"..tostring(RoleInfoModel.guserid)
    local state = PlayerPrefs.GetInt(key)
    if state == 1 then
            return true
    end
    return false
end

--检查是否同名
function RoleInfoProxy:CheckNickName(nickname)
    -- print("CheckNickName===", nickname)
    self.tempdata = nickname
    local t = {
        ["uin"] = RoleInfoModel.uid,
        ["nickname"] = nickname,
        ["zone"] = RoleInfoModel.zone_id,
        ["part"] = RoleInfoModel.server_id,
    }

    local p = {
        ["api"] = "nickname",
        ["func"] = "DistinctName",
        ["time"] = RoleInfoModel.servertime,
        ["params"] = t,
    }

    local params = {}
    params.token = LoginProxy.Instance:cms_encrypt(rapidjson.encode(p))

    local baseUrl = SystemConfig.Router
    local url = baseUrl .. LoginDef.api.gameapi
    httputil.post(url, params, function(text)
       
        local info = rapidjson.decode(text)
        -- print("-------CheckNickName--------",table.dump(info))
        self:OnCheckNickName(info)
    end)
   
end

function RoleInfoProxy:OnCheckNickName(info)
    local code = info.code
    self:ToNotify(self.data,RoleInfoDef.NotifyDef.Update_ChangeNameTips,{code = code , content = self.tempdata })
     --print("OnCheckNickName===", table.dump(info))
end


--起名
function RoleInfoProxy:ChangekNickName(nickname)
    -- print("ChangekNickName===", nickname)
    self.tempdata=nickname
    local t = {
        ["uin"] = RoleInfoModel.uid,
        ["nickname"] = nickname,
        ["zone"] = RoleInfoModel.zone_id,
        ["part"] = RoleInfoModel.server_id,
    }

    local p = {
        ["api"] = "nickname",
        ["func"] = "ChangeName",
        ["time"] = RoleInfoModel.servertime,
        ["params"] = t,
    }
    
    local params = {}
    params.token = LoginProxy.Instance:cms_encrypt(rapidjson.encode(p))

    local baseUrl = SystemConfig.Router
    local url = baseUrl .. LoginDef.api.gameapi
    httputil.post(url, params, function(text)
       
        local info = rapidjson.decode(text)
        -- print("-------ChangekNickName--------",table.dump(info))
        self:OnChangeNickName(info)
    end)

end

function RoleInfoProxy:OnChangeNickName(info)
    local code = info.code
    if code ~= 0 then
        ---local text =LanguageManager.Instance:GetWord(RoleInfoDef.CommonDef.InputNameExist)
        --GameLogicTools.ShowMsgTips(text)
        
    else
        RoleInfoModel.nickname= self.tempdata
        self.haseditnickname=1
        self:ToNotify(self.data,RoleInfoDef.NotifyDef.NickName_Update)
        self.tempdata = false
    end
   
    -- print("OnChangeNickName===", table.dump(info))
end

return RoleInfoProxy
