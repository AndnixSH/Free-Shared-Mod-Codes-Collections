local WordFilter = {_inited = false, _tree = {},_nameTree = {}}

local strSub = string.sub
local strLen = string.len

local _maskWord = "*"

function _word2Tree(root, word)
    if strLen(word) == 0 or type(word) ~= "string" then
        return
    end

    local function _byte2Tree(r, ch, tail)
        if tail then
            if type(r[ch]) == "table" then
                r[ch].isTail = true
            else
                r[ch] = true
            end
        else
            if r[ch] == true then
                r[ch] = {isTail = true}
            else
                r[ch] = r[ch] or {}
            end
        end
        return r[ch]
    end

    local tmpparent = root
    local len = strLen(word)
    for i = 1, len do
        tmpparent = _byte2Tree(tmpparent, strSub(word, i, i), i == len)
    end
end

function _check(parent, word, idx)
    local len = strLen(word)
    local ch = strSub(word, 1, 1)
    local child = parent[ch]
    if not child then
    elseif type(child) == "table" then
        if len > 1 then
            if child.isTail then
                return _check(child, strSub(word, 2), idx + 1) or idx
            else
                return _check(child, strSub(word, 2), idx + 1)
            end
        elseif len == 1 then
            if child.isTail == true then
                return idx
            end
        end
    elseif (child == true) then
        return idx
    end
    return false
end



function WordFilter.init()
    if WordFilter._inited then return end
    local words = faceConfig["data_chatnameSen"] --取名聊天模糊
    WordFilter.addWords_new(words,WordFilter._tree)

    local words2 = faceConfig["data_nameSen"] --取名模糊
    WordFilter.addWords_new(words2,WordFilter._nameTree)

    WordFilter._inited = true
end

function WordFilter.addWord(word)
    _word2Tree(WordFilter._tree, word)
end


function WordFilter.splitWordString(str)
    local strTable = {}
    local len = strLen(str)
    local wordNum = 0
    local i = 1
    while (i<=len) do
        local curByte = string.byte(str, i)
        local byteCount = 1
        if curByte>0 and curByte<=127 then
            byteCount = 1                                              
        elseif curByte>=192 and curByte<223 then
            byteCount = 2                                              
        elseif curByte>=224 and curByte<239 then
            byteCount = 3                                            
        elseif curByte>=240 and curByte<=247 then
            byteCount = 4                                               
        end 
        local char = strSub(str, i, i+byteCount-1)
        local item = {}
        item.char = char
        item.len = byteCount
        item.chs= {}
        local index = i
        for i=1,byteCount do
            table.insert(item.chs, strSub(str, index+i-1, index+i-1))
        end
        table.insert(strTable, item)
        i = i + byteCount
    end
    return strTable
end

function WordFilter.addWords_new(words,tree)
    if type(words) == "table" then
        for _, word in pairs(words) do 
            local str = word and word.content or word.name
            if str then
                local _word = string.lower(str)
                _word2Tree(tree, _word)
            end
        end
    end
end


function WordFilter.addWords(words)
    if type(words) == "table" then
        for _, word in pairs(words) do 
            word = string.lower(word)
            _word2Tree(WordFilter._tree, word)
        end
    end
end

function WordFilter.maskString(s)
    if type(s) ~= "string" then
        return
    end
    local i = 1
    local len = strLen(s)
    local word, idx, tmps
    while i <= len do
        word = strSub(s, i)
        idx = _check(WordFilter._tree, word, i)
        if idx then
            tmps = strSub(s, 1, i - 1)
            for j = 1, idx - i + 1 do
                tmps = tmps .. _maskWord
            end
            s = tmps .. strSub(s, idx + 1)
            i = idx + 1
        else
            i = i + 1
        end
    end
    return s
end

function WordFilter.maskNameString(s)
    if type(s) ~= "string" then
        return
    end
    local i = 1
    local len = strLen(s)
    local word, idx, tmps
    while i <= len do
        word = strSub(s, i)
        idx = _check(WordFilter._nameTree, word, i)
        if idx then
            tmps = strSub(s, 1, i - 1)
            for j = 1, idx - i + 1 do
                tmps = tmps .. _maskWord
            end
            s = tmps .. strSub(s, idx + 1)
            i = idx + 1
        else
            i = i + 1
        end
    end
    return s
end

function WordFilter._getindex(splitTable, i)
    local index = 0
    for k,item in ipairs(splitTable) do
        if k <= i then 
            index = index + item.len
            if i == k then
                index = index - item.len + 1
            end
        end
    end
    return index
end

function WordFilter._checkcontaint(parent, word, splitTable, i, originWord, j, num, originParent, starIndexs)
    local len = strLen(word)
    local ch = strSub(word, 1, 1)
    local child = parent[ch]
    local num = num
    local i = i
    local j = j

    if not child then
        if i >= #splitTable then
            return false, j
        else
            i = i + 1
            if splitTable[i] then
                local index = WordFilter._getindex(splitTable, i)
                return WordFilter._checkcontaint(originParent, strSub(originWord, index, strLen(originWord)), splitTable, i, originWord,j, 0, originParent,starIndexs)
            else
                return false, j
            end
        end
    else
        if type(child) == "table" then
            num = num + 1
            if child.isTail then
                table.insert(starIndexs, i)
                return true, j
            elseif num == splitTable[i].len then
                table.insert(starIndexs, i)
                i = i + 1
                if splitTable[i] then
                    local index = WordFilter._getindex(splitTable, i)
                    return WordFilter._checkcontaint(child, strSub(originWord, index, strLen(originWord)), splitTable, i, originWord, j, 0, child, starIndexs)
                else
                    return false, j
                end
            else
                return WordFilter._checkcontaint(child, strSub(word, 2, strLen(word)), splitTable, i, originWord, j, num, originParent, starIndexs)
            end
        elseif child == true then
            table.insert(starIndexs, i)
            return true, j
        end
    end
    return false, j
end

function WordFilter.checkContaintMaskString(content)
    local cacheStr = content
    local s = content
    s = string.lower(s)
    local splitTable = WordFilter.splitWordString(s)
    local count = #splitTable
    local len = strLen(s)
    local word, idx
    local i = 1
    local j = 1
    local index = 1
    local sensitive = false
    local originWord = s
    local starTables = {}  
    while index <= len do
        word = strSub(s, index)
        local tmpparent = WordFilter._tree
        local starIndexs = {}
        local ismaskWord, idx = WordFilter._checkcontaint(tmpparent, word, splitTable, i, originWord, j, 0, tmpparent, starIndexs)
        if ismaskWord == true then
            sensitive = true
            for i,value in ipairs(starIndexs) do
                local iscaontaint = WordFilter.checkContaintSameIndex(starTables, value)
                if not iscaontaint then table.insert(starTables, value) end
            end
        end
        index = index + splitTable[j].len
        j = idx +1
        i = j
    end
    local str = WordFilter.matchMaskContentByStar(cacheStr, starTables, splitTable)
    return sensitive, str
end

function WordFilter.checkContaintSameIndex(starIndexs, index)
    for k,value in pairs(starIndexs) do
        if value == index then
            return true            
        end
    end
    return false
end

function WordFilter.matchMaskContentByStar(s, starTables, splitTable)
    local tmp = ""
    for i,index in ipairs(starTables) do
        local idx = WordFilter._getindex(splitTable, index)
        if splitTable[index] then
            local len = splitTable[index].len
            tmp = strSub(s, 1, idx-1)
            for i=1,len do
                tmp = tmp .. _maskWord
            end
            tmp = tmp .. strSub(s, idx+len)
            s = tmp
        end
    end
    return s
end

function WordFilter.checkContainMaskWords(s)
    --此处均为模糊屏蔽，用于聊天、取名屏蔽（所有包括取名的功能，包括宠物，联盟、公会取名等）
    local s =  string.lower(s)
    local originStr = s
    local maskstr = WordFilter.maskString(s)
    if originStr ~= maskstr then
        return true, maskstr
    end
    return false, ""
end

function WordFilter.checkNameMaskWords(s)
    --此处均为模糊屏蔽,取名屏蔽（所有包括取名的功能，包括宠物，联盟、公会取名等）
    local s =  string.lower(s)
    local originStr = s
    local maskstr = WordFilter.maskNameString(s)
    if originStr ~= maskstr then
        return true, maskstr
    end
    local result , str = WordFilter.checkContainMaskWords(s)
    return result, str
end

function WordFilter.checkContainAccurateMaskWords(s)
    -- 聊天精准屏蔽
    local words = faceConfig["data_chatSen"] --聊天精准
    if words then
        for _, word in pairs(words) do 
            if word and word.content then
                local _word = string.lower(word.content)
                if _word == string.lower(s) then
                    local temps = ""
                    local splitTable = WordFilter.splitWordString(s)
                    for j = 1, #splitTable do
                        temps = temps .. _maskWord
                    end
                    return true,temps
                end
            end
        end
    end
    return false,""
end


WordFilter.init()

return WordFilter
