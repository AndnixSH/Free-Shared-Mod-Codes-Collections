local BattleBaseClass = require "Core.Implement.UI.Class.BattleBaseClass"
local State =
{
	Init = 0,
	Loading = 1,
	Show = 2,
	Hide = 3,
}

local SpriteTitleBase = SpriteTitleBase or LuaEventClass(BattleBaseClass)
function SpriteTitleBase:__init(spriteid)
	self.spriteid = spriteid
	self.state = State.Init
	self.bActive = false
	self.prepared = false
	self.spritedata = global.service.readonly:reader(spriteid)
	self:OnLoad()	
end

function SpriteTitleBase:__delete()
	self:UnRegisterSpriteEvent()
	self.spritedata = nil
	self:OnDestroy()
end

function SpriteTitleBase:Registers(event)
end

function SpriteTitleBase:UnRegisters(event)
end


function SpriteTitleBase:LoadStart(resname)
	local bone_ui_anchor = require "Battle.render.anchor.bone_ui_anchor"
	local ui_normal_model = require "Battle.render.model.ui_normal_model"
	local view_manager = require "Battle.render.view_manager"

	self.state = State.Loading
	local spriteview = view_manager.getsprite(self.spriteid)
	if spriteview and spriteview:get_body_item() then		
		local anchor = bone_ui_anchor.New(spriteview:get_body_item(), SPRITE_BONE_ANCHOR.UITITLE)
		self.model = ui_normal_model.New(anchor)
		self.model:load(resname, AssetType.UI, function (gameItemModel) self:LoadCallback(gameItemModel) end)
	else
		self.state = State.Init
	end	
end

function SpriteTitleBase:LoadCallback(gameItemModel)
	gameItemModel:ModelScale(4)
	self:LoadEnd(gameItemModel.gameItem)
	self:setactive(true)
	self:RegisterSpriteEvent(self.spriteid)
end

--系统是否开启血条显示
function SpriteTitleBase:SystemTitleActive()
	local SettingMenuProxy = require "Modules.SettingMenu.SettingMenuProxy"
	local SettingMenuDef = require "Modules.SettingMenu.SettingMenuDef"
	local status = SettingMenuProxy.Instance:GetSystemState(SettingMenuDef.Systerm_Option_Key[SettingMenuDef.Systerm_Option_Type.BloodBar])
	local bActive = status == 1 and true or false
	return bActive
end

function SpriteTitleBase:open()
	self:OnOpen()
	self:PullSpriteEvent(self.spriteid)

	local bActive = self:SystemTitleActive()

	if self.model and self.prepared and bActive then
		self.model:showmodel()
	end	
end

function SpriteTitleBase:close()
	if self.model then
		self.model:hidemodel()
	end	
	self:OnClose()
end

function SpriteTitleBase:release()
	if self.model then
		self.model:release()
		self.model = nil
	end	
	self:OnDestroy()
end

function SpriteTitleBase:setactive(bshow)
	if self.bActive == bshow then return end
	self.bActive = bshow 
	if bshow then
		self:open()		
	else
		self:close()
	end	
end

function SpriteTitleBase:showview(bshow)
	if self.model then
		if bshow then
			self.model:showmodel()
		else
			self.model:hidemodel()
		end
	end	
end

--子类继承
function SpriteTitleBase:LoadEnd(obj)
end

function SpriteTitleBase:OnLoad()	
end

function SpriteTitleBase:OnOpen()
end

function SpriteTitleBase:OnClose()	
end

function SpriteTitleBase:OnDestroy()	
end
--end


return SpriteTitleBase