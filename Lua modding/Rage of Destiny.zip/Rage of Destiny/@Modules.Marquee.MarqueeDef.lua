local MarqueeDef= {}

MarqueeDef.Notify = {
	UpdateMarqueeType = "UpdateMarqueeType",
	UpdateMarqueeInfo = "UpdateMarqueeInfo",
	CloseMarquee = "CloseMarquee",
}

return MarqueeDef