local sprite_view_class = require "Battle.render.view.base_sprite_view"

local player_sprite_model = require "Battle.render.model.player_sprite_model"
local effect_sprite_model = require "Battle.render.model.effect_sprite_model"
--local sprite_center_anchor = require "Battle.render.anchor.sprite_center_anchor"
local sprite_frame_anchor = require "Battle.render.anchor.sprite_frame_anchor"
local buff_anchor = require "Battle.render.anchor.buff_anchor"
--local render_camera = require "Battle.render.camera.render_camera"

local player_title_view = require "Modules.Battle.Title.PlayerTitleView"

local player_sprite_view = sprite_view_class()
local active_config = faceConfig["data_active"]

function player_sprite_view:__init()
end

function player_sprite_view:create()
    self.game_id = global.game.gameid

    local data = global.service.readonly:reader(self.sprite_id)
    if not data or not data.body then
        print("the sprite_id data is nil", self.sprite_id)
        return
    end
    local body_anchor = sprite_frame_anchor.New(self.sprite_id)
    self.body = player_sprite_model.New(body_anchor, data.body.prefab_id[1])

    if self.game_id ~= GAMEPLAYID.HANGUP then
        self.title_view = player_title_view.New(self.sprite_id)
    end

    self.is_show = true
end

function player_sprite_view:release()
    if self.body then
        self.body:release()
        self.body = nil
    end

    if self.title_view then
        self.title_view:release()
        self.title_view = nil
    end

    --if self.buff_view then
    --    self.buff_color_array = {}
    --    self.buff_rim_color_array = {}
    --
    --    for buff_id, _ in pairs(self.buff_view) do
    --        self.buff_view[buff_id]:release()
    --        self.buff_view[buff_id] = nil
    --    end
    --end

    if self.model_view then
        self.color_list = {}
        self.rim_color_list = {}

        for key, _ in pairs(self.model_view) do
            self.model_view[key]:release()
            self.model_view[key]:DeleteMe()
            self.model_view[key] = nil
        end
    end
    self.is_show = false
end

function player_sprite_view:show()
    if self.is_show then
        return
    end

    if self.body then
        self.body:show_model()
    end

    if self.title_view then
        self.title_view:setactive(true)
    end

    if self.buff_view then
        for buff_id, _ in pairs(self.buff_view) do
            self.buff_view[buff_id]:show_model()
        end
    end

    if self.model_view then
        for key, _ in pairs(self.model_view) do
            self.model_view[key]:show_model()
        end
    end
    self.is_show = true
end

function player_sprite_view:hide()
    if not self.is_show then
        return
    end

    if self.body then
        self.body:hide_model()
    end

    if self.title_view then
        self.title_view:setactive(false)
    end

    if self.buff_view then
        for buff_id, _ in pairs(self.buff_view) do
            self.buff_view[buff_id]:hide_model()
        end
    end

    if self.model_view then
        for key, _ in pairs(self.model_view) do
            self.model_view[key]:hide_model()
        end
    end
    self.active_name = ""
    self.is_show = false
end

---@deprecated 弃用 改用单个event方式
function player_sprite_view.event.sprite:_buff_start(buff_id)
    local view_manager = require "Battle.render.view_manager"
    if not view_manager.show_active then
        return
    end
    local buff_config_info = faceConfig["buff_static"][buff_id]
    if not buff_config_info then
        --print("buff config not find")
        return
    end

    if not self.buff_view then
        self.buff_view = {}
    end

    if buff_config_info.color then
        self:_set_color(buff_config_info.color)
        table.insert(self.buff_color_array, { buff_id = buff_id, color = buff_config_info.color })
    end

    if buff_config_info.rim then
        self:_set_rim_color(buff_config_info.rim)
        table.insert(self.buff_rim_color_array, { buff_id = buff_id, rim = buff_config_info.rim })
    end

    if buff_config_info.prefab_id then
        local body_item = self:get_body_item()

        local header_type = buff_config_info.header_type or 0
        local anchor = buff_anchor.New(body_item, header_type, buff_config_info.bone)
        self.buff_view[buff_id] = effect_sprite_model.New(anchor, buff_config_info.prefab_id)
    end
end

---@deprecated 弃用 改用单个event方式
function player_sprite_view.event.sprite:_buff_stop(buff_id)
    local buff_config_info = faceConfig["buff_static"][buff_id]
    if buff_config_info then
        if buff_config_info.color then
            for index, buff_color in ipairs(self.buff_color_array) do
                if buff_color.buff_id == buff_id then
                    table.remove(self.buff_color_array, index)
                    break
                end
            end

            if #self.buff_color_array == 0 then
                self:_reset_color()
            else
                local color = self.buff_color_array[#self.buff_color_array].color
                self:_set_color(color)
            end
        end

        if buff_config_info.rim then
            for index, buff_rim_color in ipairs(self.buff_rim_color_array) do
                if buff_rim_color.buff_id == buff_id then
                    table.remove(self.buff_rim_color_array, index)
                    break
                end
            end

            if #self.buff_rim_color_array == 0 then
                self:_reset_rim_color()
            else
                local rim = self.buff_rim_color_array[#self.buff_rim_color_array].rim
                self:_set_rim_color(rim)
            end
        end
    end

    if self.buff_view[buff_id] then
        self.buff_view[buff_id]:release()
        self.buff_view[buff_id]:DeleteMe()
        self.buff_view[buff_id] = nil
    end
end

function player_sprite_view.event.sprite:sprite_dead()
    self.body:start_active(string.format("%s_%s", self.config_id, "dead"), self.global_speed, 0, function()
        local view_manager = require "Battle.render.view_manager"
        view_manager.remove_sprite(self.sprite_id, SPRITE_TYPE.PLAYER)
    end)

    if self.title_view then
        self.title_view:setactive(false)
    end

    --if self.buff_view then
    --    for buff_id, _ in pairs(self.buff_view) do
    --        self.buff_view[buff_id]:release()
    --        self.buff_view[buff_id] = nil
    --    end
    --end

    if self.model_view then
        for key, _ in pairs(self.model_view) do
            self.model_view[key]:release()
            self.model_view[key]:DeleteMe()
            self.model_view[key] = nil
        end
    end
end

function player_sprite_view.event.sprite:slot_use(slotid)
    if SKILL.SLOT.ULTIMATE == slotid then
    end
end

function player_sprite_view.event.sprite:show_view()
    self:show()
end

function player_sprite_view.event.sprite:hide_view()
    self:hide()
end

function player_sprite_view.event.sprite:show_title_view()
    if self.title_view then
        self.title_view:setactive(true)
    end
end

function player_sprite_view.event.sprite:hide_title_view()
    if self.title_view then
        self.title_view:setactive(false)
    end
end

-- anchor_table: {header_type, bone}
function player_sprite_view.event.sprite:add_model(key, model_name, anchor_table)
    self:add_model({ key = key, prefab_name = model_name, anchor = anchor_table })
end

function player_sprite_view.event.sprite:remove_model(model_name)
    self:remove_model({ key = model_name })
end

-- anchor_table: {header_type, bone}
-- active_table: {active, tag}
function player_sprite_view.event.sprite:add_active_model(model_name, anchor_table, active_table)
    self:add_active_model({ prefab_name = model_name, anchor = anchor_table, active = active_table })
end

function player_sprite_view.event.sprite:add_color(key, color_table)
    self:add_color({ key = key, color = color_table })
end

function player_sprite_view.event.sprite:remove_color(key)
    self:remove_color({ key = key })
end

function player_sprite_view.event.sprite:add_rim_color(key, color_table)
    self:add_rim_color({ key = key, rim_color = color_table })
end

function player_sprite_view.event.sprite:remove_rim_color(key)
    self:remove_rim_color({ key = key })
end

function player_sprite_view.event.sprite:add_sound(soundname)
    self:add_sound(soundname)
end

function player_sprite_view.event.sprite:remove_sound(soundname)
    self:remove_sound(soundname)
end

function player_sprite_view.event.sprite:add_special_state(key, state)
    self:add_special_state({key = key, state = state})
end

function player_sprite_view.event.sprite:remove_special_state(key)
    self:remove_special_state({key = key})
end

function player_sprite_view.event.sprite:start_replace_model(key, modelname)
    self:add_replace_model({key = key, modelname = modelname})
end

function player_sprite_view.event.sprite:stop_replace_model(key)
    self:remove_replace_model({key = key})
end

function player_sprite_view.event.sprite:camera_active(params)
    if params then
        --render_camera.shake_camera_strategy(params)
    end
end

function player_sprite_view.event.sprite:set_layer()
    self:set_layer(LAYERS.EFFECT)
end

function player_sprite_view.event.sprite:reset_layer()
    self:reset_layer()
end

function player_sprite_view.event.sprite:start_active(active_name, speed, tag)
    local view_manager = require "Battle.render.view_manager"
    if not view_manager.show_active then
        return
    end

    local player_active_info = active_config[tostring(self.config_id)]
    if not player_active_info then
        return
    end

    if not player_active_info[active_name] then
        return
    end

    speed = speed and speed / 1000 or 1
    tag = tag or 0
    if not self.body or self.is_pause then
        return
    end

    if string.contains(active_name, "attack") then
        self.body:start_active(string.format("%s_%s", self.config_id, active_name), speed * self.global_speed, tag)
        self.active_name = active_name
        self.active_speed = speed
    else
        if self.active_name ~= active_name then
            self.body:start_active(string.format("%s_%s", self.config_id, active_name), speed * self.global_speed, tag)
            self.active_name = active_name
            self.active_speed = speed
        end
    end
end

function player_sprite_view:speed_active()
    if self.body and self.active_name then
        --self.body:set_active_speed(self.global_speed * self.active_speed)
    end
end

function player_sprite_view:pause_active()
    player_sprite_view.super.pause_active(self)
end

function player_sprite_view:resume_active()
    player_sprite_view.super.resume_active(self)
end

function player_sprite_view:pause_anchor()
    player_sprite_view.super.pause_anchor(self)
end

function player_sprite_view:resume_anchor()
    player_sprite_view.super.resume_anchor(self)
end

function player_sprite_view:get_title_view()
    if self.title_view then
        return self.title_view
    end
end

function player_sprite_view:add_replace_model(params)
    if not self.replace_model_list then
        self.replace_model_list = {}
    end

    table.insert(self.replace_model_list, params)
    local modelname = self.replace_model_list[#self.replace_model_list].modelname
    self:replace_model(modelname)
end

function player_sprite_view:remove_replace_model(params)
    if not self.replace_model_list then
        return
    end

    local remove_key = params.key
    for index, replace_model_info in ipairs(self.replace_model_list) do
        if replace_model_info.key == remove_key then
            table.remove(self.replace_model_list, index)
            break
        end
    end

    local modelname
    if #self.replace_model_list > 0 then
        modelname = self.replace_model_list[#self.replace_model_list].modelname
    else
        local data = global.service.readonly:reader(self.sprite_id)
        if data and data.body then
            modelname = data.body.prefab_id[1]
        end
    end

    if modelname then
        self:replace_model(modelname)
    end
end

function player_sprite_view:replace_model(model_name)
    if self.body then
        self.body:release()
        self.body = nil

        local body_anchor = sprite_frame_anchor.New(self.sprite_id)
        self.body = player_sprite_model.New(body_anchor, model_name)
        self.active_name = ""
    end

end

function player_sprite_view:remove_title_view()
    if self.title_view then
        self.title_view:release()
        self.title_view = nil
    end
end

function player_sprite_view:set_layer(layer)
    if self.body then
        self.body:set_layer(layer)
    end
end

function player_sprite_view:reset_layer()
    if self.body then
        self.body:reset_layer()
    end
end

return player_sprite_view