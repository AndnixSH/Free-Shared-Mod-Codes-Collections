local BattleProto = require "Core.Implement.Net.BattleProto"
local ArenaDef = require "Modules.Arena.ArenaDef"
local HeroProxy = require "Modules.Hero.HeroProxy"
local MailDef = require "Modules.Mail.MailDef"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local BattleProxy = require "Modules.Battle.BattleProxy"
local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
local RedPointDef = require "Modules.RedPoint.RedPointDef"
local ArenaProxy = ArenaProxy or BaseClass(BaseProxy,BattleProto)

function ArenaProxy:__init()
	ArenaProxy.Instance = self
    self.data={}
    
    self:AddProto(55000, self.On55000) --请求竞技场信息(1 赛季结束时间，2 竞技场排名或高级段位 3防守阵位(竞技5个，可能有空位为0，高级3队，可能有空位))
    self:AddProto(55001, self.On55001)
    self:AddProto(55002, self.On55002)
    self:AddProto(55003, self.On55003)
    self:AddProto(55004, self.On55004)
    self:AddProto(55005, self.On55005)
    self:AddProto(55006, self.On55006)
    self:AddProto(55007, self.On55007)
    self:AddProto(55008, self.On55008) 

    self:AddProto(55009, self.On55009)
    self:AddProto(55010, self.On55010)

    self:AddPreBattle(ACTIVITYID.ARENA, self.OnPreBattle) --准备战斗毁掉
	self:AddSetBattle(ACTIVITYID.ARENA, self.OnSetBattle) --战斗结算回调	
    self:AddStartBattle(ACTIVITYID.ARENA, self.OnStartBattle) --战斗开始回调


    self:AddPreBattle(ACTIVITYID.HIGHARENA, self.OnPreBattle) --准备战斗毁掉
	self:AddSetBattle(ACTIVITYID.HIGHARENA, self.OnSetBattle) --战斗结算回调	
    self:AddStartBattle(ACTIVITYID.HIGHARENA, self.OnStartBattle) --战斗开始回调
    
    self.formations=false
    self.oneMinutes=60
    self.oneHour=60*60
    self.oneDay=60*60*24
    
    self.freeChanllegeTimes=3
    self.challageSpendArenaCoin=1
    self.maxCoinGet=10000
    self.teamNum=3
    self.heroUpNum=5
    self.highUpHeroInfos={}
    self.round=0
    self.game_result={}
    self.blueSpriteData={} --高阶数据统计缓存
    self.startBattleSeed=false

    self.data.recordsList={}

    self.enermy_head = false
    self.enter_from_page=false -- 从挑战进入战斗的， 还时从记录进入战斗的  回来时需要打开对应的页面
    --2 --战斗记录页面进入的回放战斗页面  ,1-- 结算页面进入的回放战斗
    --2 --对战记录页面进入的战斗  , 1--挑战页面进入的战斗页面

    self.record_id_max = 10000
    self.playMusic = false
end

function ArenaProxy:__delete()
	self.data=nil
	ArenaProxy.Instance = nil
end

function ArenaProxy:PlayBgMusic(play)
    if play then
        if not self.playMusic then
            self.playMusic = true
            local AudioManager = require "Common.Mgr.Audio.AudioManager"
            AudioManager.PlayBGM("jinjichang_fw")
            
        end
    else
        self.playMusic = false
    end
    
end

function ArenaProxy:Send55000()
    self:SendMessage(55000)
    --self:On55000(nil)
end

function ArenaProxy:On55000(decoder)

    self.enter_from_page = 0
    local arenaList={}
    local arena_list=decoder:DecodeList("I1I1I4I2I4I4I1",true)
    if not arena_list then
        return
    end
    -- print("On55000====",table.dump(arena_list))

    ---测试
    --table.insert(arena_list,{2,1,os.time(),146,1000,6000})
    
    for _, _list in ipairs(arena_list) do
        local rank=_list[4] or 0
        local fight=_list[5] or 0

        local item={}
        item.status=_list[2] or 0 -- 0未开启，1开启
        item.endTime=_list[3] or 0
        item.id=_list[1] or 1
        item.rank=rank 
        if _list[1] == ArenaDef.RoomType.HighArena then
            item.rank=self:GetHighArenaRankNameByRank(rank) --段位名字
            item.hasGetCoin=_list[6] or 0 --RoleInfoModel. 高级产出未领取的货币
        end
        item.redDot=_list[7] 
        item.fight=GameLogicTools.GetNumStr(fight) 
        table.insert(arenaList,item)
    end
    local item={}
    item.status=0 -- 0未开启，1开启
    item.id=#arenaList + 1
    table.insert(arenaList,item)
    table.sort(
        arenaList,
        function(a, b) --排序
            return a.id < b.id
        end
    )
    self.data.Arena=arenaList
    RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.ArenaRecord,arenaList[1].redDot )
    RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.ProArenaRecord,arenaList[2].redDot )
    self:ShowHighArenaUnGetCoinAni()
    self:ToNotify(self.data,ArenaDef.NotifyDef.Arena_Request,arenaList)
end

function ArenaProxy:ShowHighArenaUnGetCoinAni()
    if not self.data.Arena or not self.data.Arena[ArenaDef.RoomType.HighArena] then
        return false
    end
    local coin = self.data.Arena[ArenaDef.RoomType.HighArena].hasGetCoin or 0
    if coin >= self:GetmaxCoinGet()/2 then
        RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.ProArena_GetCoin,1)
        return true
    end
    RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.ProArena_GetCoin,0)
    return false
end

function ArenaProxy:GetHighArenaRankNameByRank(rank)
    local cfg=ConfigManager.GetConfig("data_senior_arena_rank")
    if cfg then
        local len= #cfg 
        local rankname=cfg[rank] and LanguageManager.Instance:GetWord(cfg[rank].rank_name) or LanguageManager.Instance:GetWord(cfg[len].rank_name)
        local challenger_coin_rate=cfg[rank] and cfg[rank].challenger_coin_rate or cfg[len].challenger_coin_rate
        return rankname, challenger_coin_rate
    end
    return "",0
end

function ArenaProxy:GetRankCfg()
    local cfg=ConfigManager.GetConfig("data_senior_arena_rank")
    return cfg
end

function ArenaProxy:GetRankCfgByRankId(rank_id)
    local cfg=ConfigManager.GetConfig("data_senior_arena_rank")
    if cfg then
        for _ ,v in ipairs(cfg) do
            if v.rank_id == rank_id then
                return v
            end
        end
    end
end


function ArenaProxy:Send55001(roomtype)
    --列表
    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.NetworkDelayView)
    -- print("-----Send55001=",roomtype)
    local encoder=NetEncoder.New()
    encoder:Encode("I1",roomtype)
    self:SendMessage(55001,encoder)
    --self:On55001(nil)
end

function ArenaProxy:On55001(decoder)
    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.NetworkDelayView)
    local rankList={}
    local roomid=1 
    local currank=1
    local gaiCoinPerSecond=0
    local hasGetCoin=0
    local myInfo={}
     --上阵英雄 高级3场
    local heroArray={}
    local roomtype=decoder:Decode("I1") --ArenaDef.RoomType.Arena
    if roomtype == ArenaDef.RoomType.Arena then
        roomid=decoder:Decode("I2") --1 --普通竞技场 
    end
    local rank_list=decoder:DecodeList("I4s2I1I2I2I2I4I1I2I8",true) --arena_rank_player_info
    local formations={}


    
    myInfo.score=1
    myInfo.rank=1
    myInfo.rank_id=0
    if roomtype == ArenaDef.RoomType.Arena then
        formations=decoder:DecodeList("I1I4",true)
        myInfo.score=decoder:Decode("I2") --normal_arena_points
        myInfo.fight=GameLogicTools.GetNumStr(decoder:Decode("I4") or 0) 
        myInfo.rank=decoder:Decode("I2")

        table.insert(heroArray,formations)
    elseif roomtype ==ArenaDef.RoomType.HighArena then
       -- gaiCoinPerSecond=decoder:Decode("I2") --advance_arena_score_per_seconds
       local count=decoder:Decode("I1")
       for i=1 ,count do
            local formations=decoder:DecodeList("I1I4",true)
            table.insert(heroArray,formations)
       end
       
        myInfo.rank=decoder:Decode("I2")--排名
        myInfo.rank_id=decoder:Decode("I2")--段位 
        --myInfo.score=decoder:Decode("I2")--段位名字
        myInfo.highscore=decoder:Decode("I4")
        hasGetCoin=decoder:Decode("I4")
        myInfo.fight=GameLogicTools.GetNumStr(decoder:Decode("I4") or 0) 
        myInfo.score,gaiCoinPerSecond=self:GetHighArenaRankNameByRank( myInfo.rank_id)
    end
    
     
    -- print("On55001==roomtype==",roomtype)
     print("On55001==roomid==",roomid)
    -- print("On55001====",table.dump(rank_list))
    -- print("On55001==formationslist==",table.dump(heroArray))
    -- print("On55001==normal_arena_points==",myInfo.score)
    -- print("On55001==advance_arena_score_per_seconds==",gaiCoinPerSecond)
    -- print("On55001==hasGetCoin==",hasGetCoin)
    -- print("On55001==myInfo==",table.dump(myInfo))
    local func2=function ( uid,guserid )
        self:ToShowOtherPlayerInfo(roomtype,uid,guserid)
     end
    for _, _list in ipairs(rank_list) do
        local item={}
        item.rank=_list[8]
        item.rank_id=_list[9] --段位id
        local head={}
        head.fight=GameLogicTools.GetNumStr(_list[7])
        head.headicon=_list[5]
        head.frameicon=_list[6]
        head.nickname=_list[2]
        head.level=_list[4]
        head.sex=_list[3]
        item.score=_list[9]
        item.guserid=_list[10]
        item.head=head
        if roomtype ==ArenaDef.RoomType.HighArena then
            item.score=self:GetHighArenaRankNameByRank(item.rank_id) --段位名字
        end
        --item.id =_
        item.uid=_list[1]
        item.callback2=func2
        table.insert(rankList,item)
        -- print(" On55001 --=", RoleInfoModel.uid)
    end
    table.sort(
        rankList,
        function(a, b) --排序
            return a.rank < b.rank
        end
    )

    local heroList={}
    for i=1,#heroArray do
        local formation=heroArray[i]
        if formation then
            local hero={}
            for k=1,5 do
                hero[k]=-1  --初始id 为-1 表示空位
            end
            for _,v in ipairs(formation) do
                if v[1] <= 5 then
                    hero[v[1]]=v[2]
                end
            end
            table.insert(heroList,hero)
        end
        
    end
    self.data.Arena[roomtype].fight=myInfo.fight
    self.data.Arena[roomtype].currank= myInfo.rank --排名
    self.data.Arena[roomtype].score= myInfo.score --段位名字 普通高阶同样是排名
    self.data.Arena[roomtype].rank_id= myInfo.rank_id --段位id
    self.data.Arena[roomtype].roomid=roomid
    self.data.Arena[roomtype].formations=heroList
    self.data.Arena[roomtype].gaiCoinPerSecond=gaiCoinPerSecond
    self.data.Arena[roomtype].hasGetCoin=hasGetCoin > self.maxCoinGet and self.maxCoinGet or hasGetCoin
    self.rankListNum = #rankList
    
    myInfo.head=self:GetMyHeadInfo(roomtype)
    self:ToNotify(self.data,ArenaDef.NotifyDef.Arena_ListRequest,{roomtype=roomtype,rankList=rankList,myInfo=myInfo})
   
end

function ArenaProxy:GetMyHeadInfo(roomtype)
    local head={}
    head.fight=self.data.Arena[roomtype].fight
    head.headicon=RoleInfoModel.headicon
    head.frameicon=RoleInfoModel.frameicon
    head.nickname=RoleInfoModel.nickname
    head.level=RoleInfoModel.level
    head.sex=RoleInfoModel.sex
    head.guserid=RoleInfoModel.guserid
    head.uid=RoleInfoModel.uid
    head.rank_id = self.data.Arena[roomtype].rank_id
    -- print(" GetMyHeadInfo --=", RoleInfoModel.uid)
    return head,self.data.Arena[roomtype].score
end

function ArenaProxy:GetFormations(roomtype)

    if self.data.Arena and self.data.Arena[roomtype] then
        if roomtype == ArenaDef.RoomType.HighArena then
            if not self.data.Arena[roomtype].formations then
                self.data.Arena[roomtype].formations={}
            end
            if #self.data.Arena[roomtype].formations == 0 then
                for i=1,self.teamNum do
                    local _formation={}
                    for k=1,self.heroUpNum do
                        _formation[k]=-1
                    end
                    table.insert(self.data.Arena[roomtype].formations, _formation)
                end
            end
        end
        
        return self.data.Arena[roomtype].formations
    end
end

function ArenaProxy:GetCurRank(roomtype)

    if self.data.Arena and self.data.Arena[roomtype] then
        return self.data.Arena[roomtype].currank
    end
    
end

function ArenaProxy:GetCurRankId(roomtype)

    if self.data.Arena and self.data.Arena[roomtype] then
        return self.data.Arena[roomtype].rank_id
    end
    
end

function ArenaProxy:GetAward(roomtype,rank)
    --高阶没有结算奖励
    local award={}
    if roomtype == ArenaDef.RoomType.Arena then
        local cfg=ConfigManager.GetConfig("data_arena_rewards")
        if cfg then
            award[1]=cfg[rank].daily_gain
            award[2]=cfg[rank].season_gain
        end
    end
    return award
end

-- function ArenaProxy:GetDefenseInfo(roomtype)

--     local herolist={}
--     if self.data.Arena and self.data.Arena[roomtype] then
--         for _,id in pairs(self.data.Arena[roomtype].heroidlist) do
--             local hero=HeroProxy.Instance:GetHeroDataByUid()
--             table.insert(herolist,hero)
--         end
--         return herolist
--     else
        -- print("roomtype error:"..tostring(roomtype))
--     end
-- end
function ArenaProxy:Send55002(roomtype,formations)
    --调整防守阵容
    local encoder=NetEncoder.New()
    encoder:Encode("I1I1",roomtype,#formations)
    for _,v in ipairs(formations) do
        encoder:EncodeList("I1I4",v)
    end
    -- print("-------------------------=",table.dump(formations))
    self:SendMessage(55002,encoder)
    self.formations=formations
end

function ArenaProxy:On55002(decoder)
    local result ,roomtype,formation_power =decoder:Decode("I1I1I4")
    if result == 0 then
        local heroList={}
        for i=1,#self.formations do
            local formation=self.formations[i]
            if formation then
                local hero={}
                for k=1,5 do
                    hero[k]=-1  --初始id 为-1 表示空位
                end
                for _,v in pairs(formation) do
                    hero[v[1]]=v[2]
                end
                table.insert(heroList,hero)
            end
        end
        self.data.Arena[roomtype].formations=heroList
        self.data.Arena[roomtype].fight = formation_power
        self:ToNotify(self.data,ArenaDef.NotifyDef.Arena_UpdateDefenseList,{formation_power = formation_power,roomtype = roomtype , totalnum = self.rankListNum})
        if roomtype == ArenaDef.RoomType.Arena then
            LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ArenaBattleSelectView)
        elseif roomtype ==ArenaDef.RoomType.HighArena then
            LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ProArenaBattleSelectView)
        end
        GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord(ArenaDef.CommonDef.SetDefenceSuccess))
    else
        GameLogicTools.ShowErrorCode(55002, result)
    end
end

function ArenaProxy:Send55003(roomtype)
    
    --对战记录=
    local encoder=NetEncoder.New()
    encoder:Encode("I1",roomtype)
    self:SendMessage(55003,encoder)
    --self:On55003(nil)
end

function ArenaProxy:CaculateReceptiontTime(receivetime)
    
    local receptiontime=""
    local time=os.difftime(RoleInfoModel.servertime,receivetime)
    local hour=math.ceil(time*1.0/3600)
    local timestr = ""
    if time > 0 then
                
        local NPCDef=require "Modules.NPCDialogue.NPCDef"
        if time >  self.oneDay then
            timestr=string.format(LanguageManager.Instance:GetWord(NPCDef.CommonDef.Days),tostring(math.ceil(time*1.0/self.oneDay)))
        elseif time >  self.oneHour then
            timestr=string.format(LanguageManager.Instance:GetWord(NPCDef.CommonDef.Hours),tostring(math.ceil(time*1.0/self.oneHour)))
        elseif time > self.oneMinutes then
            timestr=string.format(LanguageManager.Instance:GetWord(NPCDef.CommonDef.Minutes),tostring(math.ceil(time*1.0/self.oneMinutes)))
        else
            timestr=string.format(LanguageManager.Instance:GetWord(NPCDef.CommonDef.Senconds),tostring(math.ceil(time)))
        end
    elseif time == 0 then
        timestr=string.format(LanguageManager.Instance:GetWord(NPCDef.CommonDef.Senconds),"1")
        
    end

    -- if hour < self.oneDayToHours then
    --     --24小时内接收到
    --     receptiontime=string.format(LanguageManager.Instance:GetWord(MailDef.CommonDef.ReceiveHour),hour <= 0 and "1" or tostring(hour))
    -- else
    --     local day=math.ceil(hour*1.0/self.oneDayToHours)
    --     receptiontime=string.format(LanguageManager.Instance:GetWord(MailDef.CommonDef.ReceiveDay),day)
    -- end
    return timestr
end

function ArenaProxy:OnClickRecordDetail( id ,uid ,roomtype)

    local data=self:GetOneRecordById(id)
    if data then
        self.enermy_head = data and data.head or {}
    end
    if roomtype == ArenaDef.RoomType.HighArena then
        local guser = RoleInfoModel.guserid
        local reportid
        if data then
            local state = data.head.state
            if state == 1 then
                guser =  data.head.guserid
            end
            reportid = data.reportid
        else
            reportid = id
        end
        local ReportLoader = require "Modules.Common.ReportLoader"
        local reporter =  ReportLoader.New(guser, ACTIVITYID.HIGHARENA, reportid)
        reporter:RequestSettle(function (decoder) 
            if decoder then
                --判断战报是否存在
                local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.ProArenaBattleRecordView)
                if view then
                    view.data = {id  = id}
                    view:OpenView()
                end
            else
                -- dosomething
                print('no report')
            end
        end)
        
    elseif roomtype == ArenaDef.RoomType.Arena then
        
        
        self:Send55009(id,roomtype)
    end
end

function ArenaProxy:On55003(decoder)
    
    local recordsList={}   --缺少免费次数
    local roomtype, freetiems =decoder:Decode("I1I4")
    local records_list={}
    if roomtype == ArenaDef.RoomType.HighArena then
        records_list=decoder:DecodeList("I2I4I8I2s2I1I2I2I4I4i2I1I2I1I4",true)
        RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.ProArenaRecord,0 )
        if self.data.Arena and self.data.Arena[2] then
            self.data.Arena[2].redDot = 0
        end
    elseif roomtype == ArenaDef.RoomType.Arena then
        records_list=decoder:DecodeList("I2I4I8I2s2I1I2I2I4I4i2I1I2I1",true)
        RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.ArenaRecord,0 )
        if self.data.Arena and self.data.Arena[1] then
            self.data.Arena[1].redDot = 0
        end
    end
    --print("On55003==records_list==",table.dump(records_list))
    local func=function ( uid ,id )

        local data=self:GetOneRecordById(id)
        self.enermy_head = data and data.head or {}
        self:ToChanllageWithOthes(roomtype,uid,id)
    end
    local func2=function ( uid,guserid ,is_robot)

        if not is_robot and is_robot ~= nil then
            self:ToShowOtherPlayerInfo(roomtype,uid,guserid)
        end
       
    end
    local func3=function ( id ,uid )

        self:OnClickRecordDetail(id,uid,roomtype)
     end
    for _, _list in ipairs(records_list) do
        local item={}
        item.time=_list[9]
        item.timeText=self:CaculateReceptiontTime( item.time)
        item.gainscore=_list[11]
        
        local head={}

        item.is_robot= _list[12] == 0 and true or false
        head.headicon=_list[7]
        head.frameicon=_list[8]
        head.nickname=_list[5]
        if item.is_robot then
            head.nickname = LanguageManager.Instance:GetWord(_list[5])
        end
        head.level=_list[4]
        head.sex=_list[6]
        head.uid=_list[2] -- 对方的uin
        head.guserid=_list[3] -- 对方的guserid
        head.fight=GameLogicTools.GetNumStr(_list[10])
        head.state=_list[14] --0 是我发起挑战，1是对方发起的挑战
        item.head=head
        item.id =_list[1]
        item.uid=_list[2] -- 对方的uin
        item.guserid=_list[3] -- 对方的guserid
        if roomtype == ArenaDef.RoomType.HighArena then
            local rank=_list[15]  ---------------------------高阶需要知道排名来获取段位
            item.rankname = self:GetHighArenaRankNameByRank(rank)
            item.rank_id = rank
            item.gainscore = _list[11] == 0 and 1 or -10000 --高阶竞技场没有挑战按钮
            
        else
            item.change_value =_list[11]
        end
        
        item.reportid = _list[13]

        item.callback=func
        item.callback2=func2
        item.callback3=func3
        table.insert(recordsList,item)
    end
    table.sort(
        recordsList,
        function(a, b) --排序
            return a.time > b.time
        end
    )
    self.freeChanllegeTimes=freetiems
    --self:HandleRecordRedPoint(recordsList)
    self.data.recordsList=recordsList
    self.enter_from_page = 2 --战斗记录页面进入
    self:ToNotify(self.data,ArenaDef.NotifyDef.Arena_Records,recordsList)
end

function ArenaProxy:GetOneRecordById(id)

    if self.data and self.data.recordsList then
        for _ ,v in ipairs(self.data.recordsList) do
            if v.id == id then
                return v
            end
        end
    end
end

function ArenaProxy:ToChanllageWithOthes(roomtype,uid,record)
    if self.freeChanllegeTimes > 0 then
        --挑战
        self:Send55005(roomtype,uid,record)
        
    else
        local spend=self:GetChallageSpendArenaCoin(roomtype)
        local coin=GameLogicTools.GetPropertyByGoodsId(ArenaDef.ArenaCoinGoodsId[roomtype])
        if coin - spend >= 0 then
            --挑战
            self:Send55005(roomtype,uid,record)
        else
            --打开购买页面
            local currency_type ,needcount=self:GetBuyArenaCoinSpendMoney(roomtype)
            GameLogicTools.ShowFastShopView({ArenaDef.ArenaCoinGoodsId[roomtype],1},currency_type,needcount,roomtype,function (ok)
                --钻石购买竞技币 协议
                
            end)
        end
    end
end

function ArenaProxy:ToShowOtherPlayerInfo(roomtype,uid,guserid)
    --显示玩家信息
    -- print("显示玩家信息")
    --请求其他玩家信息
    local view=LuaLayout.Instance:GetWidget(UIWidgetNameDef.OtherPlayerInfolView)
    if view then
        view.playerUid=guserid
        view.guser=guserid
        view.teamType=roomtype
        view.callback=function (  )
            
            self:Send55008(roomtype,uid)
        end
        view:OpenView()
    end
end

function ArenaProxy:HandleRecordRedPoint(recordsList)
    if self.data then
        if self.data.recordsList  then

            if #recordsList > 0 then
                if  #self.data.recordsList > 0 then
                    if self.data.recordsList[1].uid == recordsList[1].uid and self.data.recordsList[1].time == recordsList[1].time then
                        self:ToNotify(self.data,ArenaDef.NotifyDef.Arena_RecordsRed,true)
                        return
                    end
                else
                    self:ToNotify(self.data,ArenaDef.NotifyDef.Arena_RecordsRed,true)
                    return
                end
            end
        else
            if #recordsList > 0 then
                self:ToNotify(self.data,ArenaDef.NotifyDef.Arena_RecordsRed,true)
                return
            end
        end
    end
    self:ToNotify(self.data,ArenaDef.NotifyDef.Arena_RecordsRed,false)
end

function ArenaProxy:GetRecordsList(roomType)
    if self.data  then
        return self.data.recordsList
    end
end

function ArenaProxy:FreeChanllegeTimes()
    return self.freeChanllegeTimes
end


function ArenaProxy:GetChallageSpendArenaCoin()
    return self.challageSpendArenaCoin
end

function ArenaProxy:GetArenaCfg(  )
    local cfg = ConfigManager.GetConfig("data_arena")
    return cfg
end

function ArenaProxy:GetBuyArenaCoinSpendMoney(roomType)
    local cfg=ConfigManager.GetConfig("data_shop_fast")
    local StoreProxy = require "Modules.Store.StoreProxy"
    local _config=cfg[roomType]
    if cfg and _config then
        local goodsid = _config.goods_id[1][1] and _config.goods_id[1][1] or 0
        local goodsnum = _config.goods_id[1][2] and _config.goods_id[1][2] or 0
        local currency_type, price, icon, race, goodtype = StoreProxy.Instance:GetCurrencyType(goodsid, _config.cost_id)
        local discount = _config.discount and _config.discount or 1
        return  currency_type, tonumber(string.format("%d", price * goodsnum * discount * 1.0 / 100))
    end
    return 10
end

-- function ArenaProxy:Send55006(goodsid,num)
--     local encoder=NetEncoder.New()
--     encoder:Encode("I4I4",goodsid,num)
--     self:SendMessage(55006,encoder)
-- end 

-- function ArenaProxy:On55006(decoder)
--     local result=decoder:Decode("I1")
--     if result == 0 then
--         GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord(ArenaDef.CommonDef.BuyGoodsSuccess))
--         LuaLayout.Instance:CloseWidget(UIWidgetNameDef.FastshopView)
--     else
--         GameLogicTools.ShowErrorCode(55006,result)
--     end
-- end

function ArenaProxy:Send55004(roomtype)
    
    --挑战列表
    local encoder=NetEncoder.New()
    encoder:Encode("I1",roomtype)
    self:SendMessage(55004,encoder)
    --self:On55004(nil)
end

function ArenaProxy:On55004(decoder)
    local chanllageList={}
    local roomtype=decoder:Decode("I1")
    local chanllage_list=decoder:DecodeList("I4Bs2I1I2I2I2I4I2I8",true)
    local freetiems=decoder:Decode("I4")
    -- print("On55004 -freetiems----=",freetiems)
    local func=function ( uid )

        local data=self:GetChanllagePlayerInfoByUid(uid)
        self.enermy_head = data and data.head or {}
        self:ToChanllageWithOthes(roomtype,uid,0)
    end
    local func2=function ( uid ,guserid)
        self:ToShowOtherPlayerInfo(roomtype,uid,guserid)
     end
    for _, _list in ipairs(chanllage_list) do
        local item={}
        item.score=_list[9] --分值以及段位
        item.guserid=_list[10]
        if roomtype == ArenaDef.RoomType.Arena then
            item.rankname=tostring(item.score)
        elseif roomtype == ArenaDef.RoomType.HighArena then
            local gaincoin=3
            item.rankname,gaincoin=self:GetHighArenaRankNameByRank(item.score)
            item.gaincoin=string.format("<color=#b1f278>+%s</color>/"..LanguageManager.Instance:GetWord(ArenaDef.CommonDef.Hour),(gaincoin-self.data.Arena[roomtype].gaiCoinPerSecond))
        end
        item.is_robot=_list[2] == 0 and true or false
        local head={}
        head.fight=GameLogicTools.GetNumStr(_list[8])
        head.headicon=_list[6]
        head.frameicon=_list[7]
        head.nickname=_list[3]
        if item.is_robot then
            head.nickname = LanguageManager.Instance:GetWord(_list[3])
        end
        head.level=_list[5]
        head.sex=_list[4]
        head.uid=_list[1]
        item.head=head
        item.uid=_list[1]
        item.callback=func
        item.callback2=func2
        table.insert(chanllageList,item)
    end
    table.sort(
        chanllageList,
        function(a, b) --排序
            if roomtype == ArenaDef.RoomType.Arena then
                return a.score > b.score
            elseif roomtype == ArenaDef.RoomType.HighArena then
                return a.score < b.score
            end
        end
    )
    self.freeChanllegeTimes=freetiems
    self.data.chanllageList=chanllageList
    self:ToNotify(self.data,ArenaDef.NotifyDef.Arena_ChallengeList,chanllageList)
    self.enter_from_page = 1 --挑战页面进入
end

function ArenaProxy:GetChanllagePlayerInfoByUid(uid)
    for _, item in ipairs(self.data.chanllageList) do
        if item.uid == uid then
            return item
        end
    end
end

function ArenaProxy:Send55005(roomtype,uid,record)
    --挑战
    local encoder=NetEncoder.New()
    encoder:Encode("I1I4I2",roomtype,uid,record)
    self:SendMessage(55005,encoder)
    --self:On55005(nil)
    local BattleProxy = require "Modules.Battle.BattleProxy"
    local activityId = roomtype == ArenaDef.RoomType.Arena and ACTIVITYID.ARENA or ACTIVITYID.HIGHARENA
    BattleProxy.Instance:BattleReadySetStep(activityId, 1, 1)
end
    
function ArenaProxy:On55005(decoder)
    local result =decoder:Decode("I2")
     print("On55005==result==",result)
    if result == 0 then

    else
        GameLogicTools.ShowErrorCode(55005,result)
    end
    
    if result ~= 0 then
        local roomtype = decoder:Decode("I1")
        local BattleProxy = require "Modules.Battle.BattleProxy"
        local activityId = roomtype == ArenaDef.RoomType.Arena and ACTIVITYID.ARENA or ACTIVITYID.HIGHARENA
        BattleProxy.Instance:BattleReadyNextStep(activityId, 1)
    end
end
    
function ArenaProxy:Send55006()
    
    --高阶领取货币
    if RoleInfoModel.challenger_coin >= 500000 then
        GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord(ArenaDef.CommonDef.GetCoinTips))
        return
    end
    local encoder=NetEncoder.New()
    self:SendMessage(55006,encoder)
    --self:On55005(nil)
end

function ArenaProxy:On55006(decoder)
    local result =decoder:Decode("I1")
    -- print("On55006==result==",result)
    if result == 0 then
        local goodslist=decoder:DecodeList("I4I4",true)
        local rewardlist={}
        for k , _reward in ipairs(goodslist) do
            local item={}
            item.goodsid=_reward[1]
            item.goodsnum=_reward[2]
            table.insert(rewardlist,item)
        end
        if self.data.Arena[ArenaDef.RoomType.HighArena] then
            self.data.Arena[ArenaDef.RoomType.HighArena].hasGetCoin=0
        end
        GameLogicTools.ShowGetItemView(rewardlist,1,function (  )

        end)
        RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.ProArena_GetCoin,0)
        self:ToNotify(self.data,ArenaDef.NotifyDef.Arena_UpdateHasGetCoin)
    else
        if result == 2 then
            GameLogicTools.ShowMsgTips(ArenaDef.CommonDef.NoCoin)
        else
            GameLogicTools.ShowErrorCode(55006,result)
        end
       
    end
end


function ArenaProxy:Send55007(roomType,hero_infos, enemy_infos, bufferstr)

    --开始战斗
    local encoder = NetEncoder.New()
    self:_EncodeHeroInfo(hero_infos, encoder)
    self:_EncodeEnemyInfo(enemy_infos, encoder)
    encoder:Encode("s2", bufferstr or "")
    encoder:Encode("I1", roomType)
    -- print(" Send55007 ===-----------------------------------hero_infos1----------------",table.dump(hero_infos))
    -- print(" Send55007 ===-------------------------------------enemy_infos--------------",table.dump(enemy_infos))
    self:SendMessage(55007, encoder) 
  
end
function ArenaProxy:On55007(decoder)
    
    local result =decoder:Decode("I1")
    print("On55007====",result)
    if result == 0 then
       
    else
        if result == 2 then
            local fight =decoder:Decode("I4")
            local str = string.format(LanguageManager.Instance:GetWord("BattleSelect_1005"),fight)
            GameLogicTools.ShowMsgTips(str)
        else
            GameLogicTools.ShowErrorCode(55007,result)
        end
        
    end
end

function ArenaProxy:Send55008(roomType,uid)

    --请求防守阵容
    local encoder = NetEncoder.New()
    encoder:Encode("I1I4", roomType,uid)
    self:SendMessage(55008, encoder) 
   
end
function ArenaProxy:On55008(decoder)
    -- print("On55008====")
    local roomType=decoder:Decode("I1")
    local formations={}
    local herodata={}
    if roomType == ArenaDef.RoomType.Arena then
        local count=decoder:Decode("I1")
        local heros={}
        for i=1,self.heroUpNum do
            heros[i]=-1
        end
        for i=1,count do
            local hero={}
            local pos=1
            hero.herouid, hero.roleid,hero.level,hero.rank,hero.crystalLevel,hero.curskin,pos,hero.artifact_goodsid =decoder:Decode("I4I4I2I2I2I4I1I4")
            hero.heroskins=decoder:DecodeList("I4",true)
            hero.equips=decoder:DecodeList("I1I4",true)
            if hero.crystalLevel == 0 then
                hero.crystalLevel = nil
            end
            heros[pos]=hero
        end
        table.insert(herodata,heros)
    elseif roomType == ArenaDef.RoomType.HighArena then

        local count=decoder:Decode("I1")
        for i=1 ,count do
            local num=decoder:Decode("I1")
            local heros={}
            for k=1,self.heroUpNum do
                heros[k]=-1
            end
            for k=1,num do
                local hero={}
                local pos=1
                hero.herouid, hero.roleid,hero.level,hero.rank,hero.crystalLevel,hero.curskin,pos,hero.artifact_goodsid=decoder:Decode("I4I4I2I2I2I4I1I4")
                hero.heroskins=decoder:DecodeList("I4",true)
                hero.equips=decoder:DecodeList("I1I4",true)
                if hero.crystalLevel == 0 then
                    hero.crystalLevel = nil
                end
                heros[pos]=hero
            end
             table.insert(herodata,heros)
        end
    end
    local defencefight=decoder:DecodeList("I4")
    self:ToNotify(self.data,ArenaDef.NotifyDef.Arena_UpdatePlayerDefenceHeros,{herodata=herodata,defencefight=defencefight})
end

function ArenaProxy:Send55009(id,roomType)

    --请求数据统计
    -- local encoder = NetEncoder.New()
    -- encoder:Encode("I1I2",roomType, id)
    -- self:SendMessage(55009, encoder) 
    local data=self:GetOneRecordById(id)
    local guser = RoleInfoModel.guserid
    local reportid
    if data then
        local state = data.head.state
        if state == 1 then
            guser =  data.head.guserid
        end
        reportid = data.reportid
    else
        reportid = id
    end
    
    --local activityid = roomType == ArenaDef.RoomType.Arena and ACTIVITYID.ARENA or ACTIVITYID.HIGHARENA

    local ReportLoader = require "Modules.Common.ReportLoader"
    if roomType == ArenaDef.RoomType.Arena then
        local reporter =  ReportLoader.New(guser, ACTIVITYID.ARENA, reportid)
        reporter:RequestSettle(function (decoder) 
            if decoder then
                self:On55009(decoder,roomType,id) 
            else
                -- dosomething
                print('no report')
            end
        end)
    else
        local settledata = {}
        for k = 1,self.teamNum do
            local reporter =  ReportLoader.New(guser, ACTIVITYID.HIGHARENA, reportid + self.record_id_max*(k - 1))
            reporter:RequestSettle(function (decoder) 
                if decoder then
                    local result =decoder:Decode("I2")
                    if result == 0 then
                        settledata[k] = self:DecodeSettleData(decoder)
                        if #settledata == self.teamNum then
                            self:HandleHighArenaSettleData(settledata,id) 
                        end
                    end
                else
                    -- dosomething
                    print('no report')
                end
            end)
        end
    end
    
end

function ArenaProxy:HandleHighArenaSettleData(settledata,id)
    -- local settledata={}
    -- settledata[1] = self:DecodeSettleData(decoder[1])
    -- settledata[2] = self:DecodeSettleData(decoder[2])
    -- settledata[3] = self:DecodeSettleData(decoder[3])
    local data={}
    data.result={}
    data.myformations={}
    data.enermyformations={}
    data.myhead =self:GetMyHeadInfo(ArenaDef.RoomType.HighArena)
    data.enermyhead= self:GetEnermyHead()
    data.id=id
    for i , v in ipairs(settledata) do
        local team={}
        for k = 1, self.heroUpNum do
            table.insert(team,-1)
        end
        table.insert(data.myformations,team)
        table.insert(data.enermyformations,table.deepcopy(team))
        local my_formation={}
        local enermy_formation={}
        if data.enermyhead.state and data.enermyhead.state == 1 then
            data.result[i] = settledata[i].result == 0 and 1 or 0
            my_formation=settledata[i].camps[2]
            enermy_formation =settledata[i].camps[1]
        else
            data.result[i] = settledata[i].result
            my_formation=settledata[i].camps[1]
            enermy_formation =settledata[i].camps[2]
        end

        for _, hero in ipairs(my_formation ) do
            data.myformations[i][hero.stance] = hero
        end
        for _, hero in ipairs(enermy_formation ) do
            data.enermyformations[i][hero.stance] = hero
        end
    end
    self.data.high_settledata=settledata
    self:ToNotify(self.data,ArenaDef.NotifyDef.Arena_UpdateRecordsDetail,data)
end

function ArenaProxy:On55009(decoder,roomType,id)
    
    local result =decoder:Decode("I2")
    if result == 0 then
        if roomType == ArenaDef.RoomType.Arena then

            local settledata = self:DecodeSettleData(decoder)
            local redData = {}
            local blueData = {}
            redData = table.deepcopy(RoleInfoModel)
            blueData =self:GetEnermyHead()
            
            local camps=settledata.camps
            local result = settledata.result
            if blueData.state and blueData.state == 1 then
                camps={}
                result = settledata.result == 0 and 1 or 0
                table.insert(camps,settledata.camps[2])
                table.insert(camps,settledata.camps[1])
            end

            local func = function(  )
                self:Send55010(id,ArenaDef.RoomType.Arena)
            end
            UIOperateManager.Instance:OpenWidget(AppFacade.Battle,4,result == 0 and CAMP.RED or CAMP.BLUE, redData, blueData,camps,func,{true, true})
        elseif roomType == ArenaDef.RoomType.HighArena then

        end
    else
        GameLogicTools.ShowErrorCode(55009,result)
    end
end

function ArenaProxy:Send55010(id,roomType,index)

    --播放回放
    -- local encoder = NetEncoder.New()
    -- if roomType == ArenaDef.RoomType.Arena then
    --     encoder:Encode("I1I2I1",roomType, id,index or 1)
    -- elseif roomType == ArenaDef.RoomType.HighArena then
    --     encoder:Encode("I1I2I1",roomType, id,index or 1)
    --     self.round = index
    -- end
    -- --print("---------Send55010--------------",index)
    -- self:SendMessage(55010, encoder) 

    local data=self:GetOneRecordById(id)
    local guser = RoleInfoModel.guserid
    local reportid
    if data then
        local state = data.head.state
        if state == 1 then
            guser =  data.head.guserid
        end
        reportid = data.reportid
    else
        reportid = id
    end
    
    local activityid = roomType == ArenaDef.RoomType.Arena and ACTIVITYID.ARENA or ACTIVITYID.HIGHARENA
    if roomType == ArenaDef.RoomType.HighArena then
        self.round = index
        reportid = reportid + (index - 1)* self.record_id_max
    end
    local ReportLoader = require "Modules.Common.ReportLoader"
    local reporter =  ReportLoader.New(guser, activityid, reportid)
    reporter:RequestPlay()
end


function ArenaProxy:On55010(decoder)
    
    local result ,roomType,id=decoder:Decode("I1I1I2")
    --print("-------On55010---------",result)
    if result == 0 then
        --local data=self:GetOneRecordById(id)
        --self.enermy_head = data and data.head or {}
    else
        GameLogicTools.ShowErrorCode(55010,result)
    end
end

function ArenaProxy:GetEnterFromPage()
    return self.enter_from_page
end

function ArenaProxy:SetEnterFromPage(page)
     self.enter_from_page = page ---  -1不返回竞技场
end

function ArenaProxy:GetEnermyHead()
    return self.enermy_head
end

function ArenaProxy:GetHighArenaSettleData(index)
    --数据统计
    if self.data.high_settledata then
        return self.data.high_settledata[index]
    end
end

function ArenaProxy:SendHighArenaBattleData(index,hero_infos, bufferstr,enemy_uin)
    if hero_infos  then
        self.highArenaBattle.UpHeroInfos={}
        self.highArenaBattle.UpHeroInfos=table.deepcopy(hero_infos)
    end
    if bufferstr  then
        self.highArenaBattle.bufferstr=table.deepcopy(bufferstr)
    end

    if index > 1 and index <= self.teamNum then
        self.round =self.round +1
        if #self.highArenaBattle.enermy_formations[index] ~= 0 then
            self:GenerateBattleInfo(ACTIVITYID.HIGHARENA, self.highArenaBattle.UpHeroInfos[index], self.highArenaBattle.enermy_formations[index], self.startBattleArg,{enemy_uin=enemy_uin})
        else
            self:SetgGameResult(index,0)
            return false
        end
        
        
    else
        --只有第一场战斗才发送开始战斗 ，但不一定就是第一组，第一组数据为空时，则直接进行第二组
        local kk =4
        if #self.highArenaBattle.enermy_formations[index] == 0 then --可能前面组队为空
            for i=1,#self.highArenaBattle.enermy_formations do
                if #self.highArenaBattle.enermy_formations[i] ~= 0 then
                    kk=i
                    break
                else
                    self:SetgGameResult(i,0)
                end
            end
        else
            kk=index
        end
        self.round=kk
        if kk <= 3 then
            local heros_list={} --服务器存储战斗记录需要
            for k , team in ipairs(self.highArenaBattle.UpHeroInfos) do
                if team then
                    for _, v in ipairs(team) do
                        if v then 
                            local hero=table.deepcopy(v)
                            hero.stance= hero.stance + ( k - 1) * self.heroUpNum
                            table.insert(heros_list,hero)
                        end
                    end
                end
            end
           
            --self:Send55007(ArenaDef.RoomType.HighArena ,self.highArenaBattle.UpHeroInfos[kk],self.highArenaBattle.enermy_formations[kk],self.highArenaBattle.bufferstr)
            self:Send55007(ArenaDef.RoomType.HighArena ,heros_list,self.highArenaBattle.enermy_formations[kk],self.highArenaBattle.bufferstr)
        else
            return false
        end
    end
    return true
end



function ArenaProxy:GetmaxCoinGet()
    return self.maxCoinGet
end

-- 战前准备
function ArenaProxy:OnPreBattle(decoder)

    local heroinfos = self:_DecodeHeroInfo(decoder)
	local enemyinfos = self:_DecodeEnemyInfo(decoder)
    local bufferstr = decoder:Decode("s2")
    -- print("OnPreBattle==heroinfos==",table.dump(heroinfos))
     --print("OnPreBattle==enemyinfos==",table.dump(enemyinfos))  --高阶3队站位1-15
    
    local enemy_uin,roomtype=string.unpack(">I4I1", bufferstr)
    -- print("----enemy_uin---=",enemy_uin)

    local enemyinfolist={}
    local activityId=ACTIVITYID.ARENA
    local panelstr="BattleArenaPanel"
    if roomtype == ArenaDef.RoomType.HighArena then
        for i=1,#self.game_result do
            self.game_result[i] = 1
        end
		self.battle_round_settle_stat = {}
		
        activityId=ACTIVITYID.HIGHARENA
        panelstr="BattleProArenaPanel"

        table.sort(
            enemyinfos,
            function(a, b) --排序
                return a.stance < b.stance
            end
        )
        -- 数据转换为3组
        for i=1,self.teamNum do
            enemyinfolist[i]={}
        end
        for k,_enermy in ipairs(enemyinfos) do
            local d=math.floor(_enermy.stance / self.heroUpNum)   
            local mod=_enermy.stance % self.heroUpNum 
            if d == 0 then
                _enermy.stance=mod 
                table.insert(enemyinfolist[1],_enermy)
            elseif d  == 1 then
                if mod == 0 then
                    _enermy.stance=self.heroUpNum
                    table.insert(enemyinfolist[1],_enermy)
                else
                    _enermy.stance=mod
                    table.insert(enemyinfolist[2],_enermy)
                end
            elseif d == 2 then
                if mod == 0 then
                    _enermy.stance=self.heroUpNum
                    table.insert(enemyinfolist[2],_enermy)
                else
                    _enermy.stance=mod
                    table.insert(enemyinfolist[3],_enermy)
                end
            else
                _enermy.stance=self.heroUpNum
                table.insert(enemyinfolist[3],_enermy)
            end
            
        end
        self.highArenaBattle={}
        self.highArenaBattle.enermy_formations=enemyinfolist
         --print("OnPreBattle==enemyinfolist==",table.dump(enemyinfolist))
        self:_UpdateEnemyInfo(enemyinfolist[1])   --enemy_uin 竞技场里面的是 敌方的
        UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 10, activityId, heroinfos, enemyinfolist[1],panelstr,{enemy_uin,roomtype})
    else
        -- print("OnPreBattle==enemyinfos==",table.dump(enemyinfos))
        self:_UpdateEnemyInfo(enemyinfos)
        UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 10, activityId, heroinfos, enemyinfos,panelstr,{enemy_uin,roomtype})
    end
    self.round=0
end  

function ArenaProxy:GetEnermyFormations(index)
    if self.highArenaBattle and self.highArenaBattle.enermy_formations then
        return self.highArenaBattle.enermy_formations[index]
    end
end

function ArenaProxy:GetMyUpFormations(index)
    if self.highArenaBattle and self.highArenaBattle.UpHeroInfos then
        return self.highArenaBattle.UpHeroInfos[index]
    end
end

-- 开始战斗
function ArenaProxy:OnStartBattle(decoder, seed, activityId, extra)
    local heroinfos = self:_DecodeHeroInfoDetail(decoder)
	
	if extra and extra.report then
		BattleProxy.Instance:SetIsReport(true)
		for _, heroinfo in pairs(heroinfos) do
			heroinfo.herouid = 0
		end
	else
		BattleProxy.Instance:SetIsReport(false)
	end
	
	local enemyinfos = self:_DecodeEnemyInfoDetail(decoder)
    local bufferstr = decoder:Decode("s2")
     --print("OnStartBattle==heroinfos==",table.dump(heroinfos))
    -- print("OnStartBattle==enemyinfos==",table.dump(enemyinfos))

    local enemy_uin,roomtype= string.unpack(">I4I1", bufferstr)

    local activityId=ACTIVITYID.ARENA
    if roomtype == ArenaDef.RoomType.HighArena then
        activityId=ACTIVITYID.HIGHARENA

        if extra and extra.report then
        else
            heroinfos = self:GetMyUpFormations(self.round) or {}
            enemyinfos = self:GetEnermyFormations(self.round)  or {}
        end
       
        --self.round =self.round +1
    end
    self:PlayBgMusic(false)
    -- print("---------OnStartBattle----seed-------",seed,enemy_uin)
    -- print("---------heroinfos----seed-------",table.dump(heroinfos))
    --print("---------OnStartBattle----enemyinfos-------",table.dump(enemyinfos))
    self.startBattleArg = { seed = seed, extra = extra }
    self:GenerateBattleInfo(activityId, heroinfos, enemyinfos , self.startBattleArg,{ first = true, enemy_uin=enemy_uin,breport = extra and  extra.report or false })
end

function ArenaProxy:GetRound()
    return self.round
end

function ArenaProxy:GetgGameResult()
    return self.game_result
end

function ArenaProxy:GetBattleRoundSettleStat()
	return self.battle_round_settle_stat or {"", "", ""}
end

function ArenaProxy:SetgGameResult(index,result,settlestr)
	self.game_result[index]=result
	self.battle_round_settle_stat[index] = BattleProxy.Instance:_GetSettleStat()
	
	-- local spritelist = BattleProxy.Instance:GetSpriteList(CAMP.BLUE)
	-- local sprite 
	-- for _, spriteid in pairs(spritelist) do
	--     sprite = BattleProxy.Instance:GetSprite(spriteid)
	--     break
	-- end
	--self.blueSpriteData[index]=sprite
	if #self.highArenaBattle.enermy_formations[index]  == 0 then
	
	self.blueSpriteData[index]= ""
	else
	self.blueSpriteData[index]=settlestr
	end
    
end
function ArenaProxy:GetBlueSpriteData()
    return self.blueSpriteData
end

function ArenaProxy:GetBlueSpriteDetailData(index)
   
    for k ,v in ipairs(self.blueSpriteData ) do
        if k == index then
            if v then
                local settlestr, framestr = string.unpack(">s2s2", v)
                local data = string.pack(">I1s2",self.game_result[index],settlestr)
                local decoder = NetDecoder.New(data, 1)
                local settledata = self:DecodeSettleData(decoder)
                --print("-------------------",table.dump(settledata))
                return settledata
             end
        end
        
    end
   
end

-- 结算
function ArenaProxy:OnSetBattle(decoder)

    -- print("OnSetBattle")
end

--获取竞技场已上阵的英雄，以及当前选中的标签
function ArenaProxy:GetArenaSelectInfos()
    local curIndex, infos = nil
    --还有一个防守界面
    local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleNetSelectView)
    if view and view:IsOpen() then
        curIndex, infos = view:GetArenaSelectInfos()
    end

    local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.ProArenaBattleSelectView)
    if view and view:IsOpen() then
        curIndex, infos = view:GetArenaSelectInfos()
    end

    return curIndex, infos
end


--获取竞技场已上阵的英雄，以及当前选中的标签
function ArenaProxy:ReplaceProArenaFormations(roleIdDic)
    local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleNetSelectView)
    if view and view:IsOpen() then
        view:ReplaceProArenaFormations(roleIdDic)
    end

    local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.ProArenaBattleSelectView)
    if view and view:IsOpen() then
        view:ReplaceProArenaFormations(roleIdDic)
    end
end

function ArenaProxy:SaveLoginTime(type)

    PlayerPrefs.SetInt(tostring(RoleInfoModel.guserid).."Arena"..tostring(type),RoleInfoModel.servertime)
 end
 function ArenaProxy:GetLoginTime(type)
     return PlayerPrefs.GetInt(tostring(RoleInfoModel.guserid).."Arena"..tostring(type))
 end

function ArenaProxy:IsTheSameToday(type)
    local last_login_time = self:GetLoginTime(type)
    local DateFormatUtil = require "Common.Util.DateFormatUtil"
    local date_a = DateFormatUtil.Date("*t",last_login_time) -- os.date("*t", last_login_time)
    local date_b =DateFormatUtil.Date("*t",RoleInfoModel.servertime)-- os.date("*t", RoleInfoModel.servertime)

    return date_a.day == date_b.day and date_a.month == date_b.month and date_a.year == date_b.year
 end

return ArenaProxy
