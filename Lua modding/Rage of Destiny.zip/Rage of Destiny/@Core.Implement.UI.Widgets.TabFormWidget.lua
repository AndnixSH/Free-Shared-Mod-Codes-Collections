local ModuleManager = require "Common.Mgr.UI.ModuleManager"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local CToggleRender = require "Core.Implement.UI.Class.CToggleRender"

TabFormWidget = TabFormWidget or BaseClass(LuaBasicWidget)
function TabFormWidget:AddTogGroup(togGroup, idx,bneedopentween)	

	self.togGroup = togGroup
	self.togData = {}
	
	self.togRender = CToggleRender.New()
	self.togRender:Load(self.togGroup, idx or 1,bneedopentween)
	self.togRender:AddSelect(function (index)		
		self:OnTabWidgetChange(index)
		self:OnSelectChange(index)
	end)
end

function TabFormWidget:AddTabDataList(dataList)
	local count = #dataList
	for i = 1, count do
		self.togRender:Add()
		self.togRender:SetNormalInfo(i, dataList[i].title, dataList[i].normalicon, dataList[i].back,dataList[i].norIconGray)
		self.togRender:SetSelectInfo(i, dataList[i].title, dataList[i].selecticon)
		self.togRender:SetRed(i, false)

		if dataList[i].newbieid then
			self.togRender:SetNewbie(i, dataList[i].newbieid, dataList[i].step)
		end	
		local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
		if dataList[i].redDot_key and dataList[i].redDot_key ~= "" then
			RedPointProxy.Instance:BindNode(dataList[i].redDot_key, self.togRender:GetRedObj(i))
		end
		table.insert(self.togData, dataList[i])
	end		

	self.togGroup:Reposition()
end

function TabFormWidget:AddTabData(data)
	self.togRender:Add()
	self.togRender:SetNormalInfo(#self.togData + 1, data[i].title, data[i].normalicon)
	self.togRender:SetSelectInfo(#self.togData + 1, data[i].title, data[i].selecticon)	
	table.insert(self.togData, data)

	self.togGroup:Reposition()
end	

function TabFormWidget:OnTabWidgetChange(index)	
	if self.selectIdx == index then return end		
	self.lastselectIdx = self.selectIdx
	self.selectIdx = index

	if self.togData[self.lastselectIdx] then
		local data = self.togData[self.lastselectIdx]
		local view = LuaLayout.Instance:GetWidget(data.view)
		if view and view:IsOpen() then
			view:CloseView()
		end
	end
	if self.togData[self.selectIdx] then
		local data = self.togData[self.selectIdx]
		local view = LuaLayout.Instance:GetWidget(data.view)
		if view and not view:IsOpen() then
			view:OpenView()
		end	
	end		
end	

function TabFormWidget:ShowNewOpenTween()
	self.togRender:ShowNewOpenTween()
end

--对外接口
function TabFormWidget:RemoveAll()
	self.togGroup:RemoveAll()
end

function TabFormWidget:TabSelect(index)
	self:CheckLock()

	for _,data in pairs(self.togData) do
		LuaLayout.Instance:CloseWidget(data.view)	
	end
	self.selectIdx = nil
	if tonumber(index) then
		self.togRender:SelectIndex(index)
	end
end	

function TabFormWidget:CheckLock()
	for idx, data in ipairs(self.togData) do
		local lock = ModuleManager.GetUIViewIsLock(data.view)
		self.togRender:SetLock(idx, lock)

		self.togRender:SetViewOpen(idx, data.view ~= "")
	end
end

function TabFormWidget:OnSelectChange(index)
end

function TabFormWidget:GetChildView()
	if self.togData[self.selectIdx] then
		local data = self.togData[self.selectIdx]		
		local childView = LuaLayout.Instance:GetWidget(data.view)	
		return childView
	end		
end

function TabFormWidget:SetRedDot(idx, isShow, num)
	self.togRender:SetRed(idx, isShow, num)
end

function TabFormWidget:GetRedObj(idx)
	return self.togRender:GetRedObj(idx)
end

function TabFormWidget:SetTabFlag(idx, isShow, spriteName)
	--print("idx ", idx, isShow, spriteName)
	self.togRender:SetFlag(idx, isShow, spriteName)
end