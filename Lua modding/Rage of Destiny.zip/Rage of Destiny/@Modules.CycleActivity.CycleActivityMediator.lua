local CycleActivityMediator = CycleActivityMediator or BaseClass(StdMediator)
local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"
local CycleActivityProxy = require "Modules.CycleActivity.CycleActivityProxy"
function CycleActivityMediator:OnEnterLoadingEnd()		
	
end
function CycleActivityMediator:OnEnterScenceEnd()


    if SceneManager.Instance.sceneType == SceneDef.SceneType.Main then
        self:DelayExecute(function()
            CycleActivityProxy.Instance:RequestUpdateRedDot()
        end)
    end
	
end
function CycleActivityMediator:OnEnterScenceFirst()

    CycleActivityProxy.Instance:Send64000()
end

return CycleActivityMediator