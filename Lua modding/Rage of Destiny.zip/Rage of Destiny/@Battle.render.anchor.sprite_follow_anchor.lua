local sprite_follow_anchor = BaseClass()

local cSpriteFollowAnchor = CS.LJY.NX.SpriteFollowAnchor

function sprite_follow_anchor:__init(sprite_id)
    self.canchor = cSpriteFollowAnchor(sprite_id)
end

function sprite_follow_anchor:__delete()
    if self.canchor then
        self.canchor = nil
    end
end

return sprite_follow_anchor