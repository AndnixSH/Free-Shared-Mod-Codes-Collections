local step = {}
local done_set = {} -- 完成列表
local wait_list = {} -- 等待列表
local guide = 0 -- 0表示处于新手
local logflag = false -- 日志开关
local data_maze_guide = ConfigManager.GetConfig("data_maze_guide")

local str_status = function ()
    local done_list = {}
    for k, v in pairs(done_set) do
        table.insert(done_list, k)
    end
    local donestr = table.concat(done_list, ", ")


    local waitid_list = {}
    for i, wait in ipairs(wait_list) do
        table.insert(waitid_list, wait.stepconf.id)
    end
    local waitstr = table.concat(waitid_list, ", ")

    local str = string.format("guide:%s | donelist:[%s] | waitlist:[%s]", guide, donestr, waitstr)
    return str
end

-- 打印
local log = function (key, id)
    if not logflag then return end
    print(key, id, str_status())
end




-- 触发引导
local function trigger_step(stepconf, args)
    log("触发引导->", stepconf.id)
    local stepid = stepconf.id
    if step[stepid] then
        step[stepid](stepconf, args)
    elseif step[stepconf.view_type] then
        step[stepconf.view_type](stepconf, args)
    else
        print('触发引导失败，没有合适的step回调', stepid, stepconf.view_type, table.dump(args))
    end
end

-- 完成引导
local function finish_step(stepid)
    done_set[stepid] = true
    local _stepconf = data_maze_guide[stepid]
    if _stepconf and _stepconf.complete then
        for _, id in ipairs(_stepconf.complete) do
            done_set[id] = true
        end
    end

    local MazeProxy = require "Modules.Maze.MazeProxy"
    MazeProxy.Instance:AddGuideStep(stepid)
    log("完成引导->", stepid)

    local next_triggers = {}
    for i = #wait_list, 1, -1 do

        local stepconf = wait_list[i].stepconf

        if stepconf.pre == stepid then
            table.insert(next_triggers, 1, wait_list[i])
        end

        if stepconf.id == stepid then
            table.remove(wait_list, i)
        end
    end

    for _, value in ipairs(next_triggers) do
        trigger_step(value.stepconf, value.args)
    end
end

-- 尝试触发，不成功则加入队列
local function try_step(stepconf, args)
    local satisfy = true
    if stepconf.pre and not done_set[stepconf.pre] then
        satisfy = false
    end

    if satisfy then
        trigger_step(stepconf, args)
    else
        table.insert(wait_list, { stepconf = stepconf, args = args })
        log("加入引导->", stepconf.id)
    end
end


-- 条件判断，返回true满足
local condition_parser = {}

local condition_match = function (condition, condition_args, notify_args)
    if condition_parser[condition] then
        return condition_parser[condition](condition_args, notify_args)
    else
        print('条件匹配失败，没有合适的condition_parser回调', condition)
    end

    return true
end

local MazeGuide = {}

function MazeGuide.Init(_guide, done_list)
    guide = _guide
    done_set = {}
    wait_list = {}
    for _, stepid in ipairs(done_list) do
        done_set[stepid] = true
    end
    log("开始引导")
end

function MazeGuide.Notify(condition, args)

    if guide == 0 then
        for stepid, stepconf in pairs(data_maze_guide) do
            if (not done_set[stepid]) and condition ==  stepconf.condition and condition_match(condition, stepconf.condtion_args, args) then
                try_step(stepconf, args)
            end
        end
    end
end

function MazeGuide.IsStepFinish(stepid)
    if guide == 0 then
        return done_set[stepid]
    end
    return true
end


------------------CONDITION--------------------

condition_parser = { -- 条件判断，返回true满足

    -- 关卡开始
    ["level_start"] = function ()
        return true
    end,
    
    -- 关卡结束
    ["level_end"] = function ()
        return true
    end,

    -- 英雄选择
    ["hero_select"] = function ()
        return true
    end,

    -- 关闭攻击建筑的奖励面板
    ["attack_reward_close"] = function (condition_args, notify_args)
        local buildid = condition_args[1]
        if notify_args.buildid == buildid then
            return true
        end
    end,
        
    -- 建筑生成
    ["build_born"] = function (condition_args, notify_args)
        local buildid = condition_args[1]
        -- print('build_born_condition_args', table.dump(condition_args))
        -- print('build_born_notify_args', table.dump(notify_args))
        if notify_args.buildid == buildid then
            return true
        end
    end,

    -- 建筑消失
    ["build_close"] = function (condition_args, notify_args)
        local buildid = condition_args[1]
        if notify_args.buildid == buildid then
            return true
        end
    end,

    -- 格子无迷雾
    ["cell_nofog"] = function (condition_args, notify_args)
        local cellid = condition_args[1]
        if notify_args.cellid == cellid then
            return true
        end
    end,
}
------------------CONDITION--------------------


---------------------STEP----------------------

-- 在第一次进入假副本时弹出
step[1] = function (stepconf, args)
    -- open ui 
    -- ui click callback -> finish_step(stepconf.id)
    -- print("step 1========", stepconf.id)
    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.NewbieSignalView)
    local NewbieSignalView = require "Modules.Newbie.NewbieSignalView"
    local parama = {}
    parama.id = stepconf.id
    parama.show_type = 1
    parama.callback = function(id)
        finish_step(id)
    end
    NewbieSignalView.ShowView(parama)
end

-- 弹出英雄阵容界面时触发，引导用户选择英雄阵容
-- step[2] = function (stepconf, args)
--     -- same as s1
--     -- print("step 2========", stepconf.id)
--     local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MazeView)
--     if view and view:IsOpen() then
--         view:OpenHeroSelectView(true, stepconf.id, function(id)
--             finish_step(id)
--         end)
--     end
-- end

-- args:{position}
step["tips"] = function (stepconf, args)
    -- print("tips stepconf.id======>>", stepconf.id)
    local NewbieNpcDialogueView = require "Modules.Newbie.NewbieNpcDialogueView"
    local parama = {}
    parama.id = stepconf.id
    parama.callback = function(id)
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.NewbieNpcDialogueView)
        finish_step(id)
    end
    NewbieNpcDialogueView.ShowView(parama)
end

-- args:{position}
step["finger"] = function (stepconf, args)
    -- print("finger stepconf==", table.dump(stepconf), table.dump(args))
    local NewbieFingerView = require "Modules.Newbie.NewbieFingerView"
    local parama = {}
    parama.id = stepconf.id
    local position = UILayerTool.WorldToScreenPoint(args.position)
    parama.position = position --不需要再转换坐标了
    parama.bConvert = false --不需要再转换坐标了
    parama.bForceGuide = true
    parama.callback = function(id)
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.NewbieFingerView)
        finish_step(id)
    end
    NewbieFingerView.ShowView(parama)
end

step[14] = function (stepconf, args)
    -- print("stepconf==========>>", stepconf.id)
    -- LuaLayout.Instance:DestroyWidget(UIWidgetNameDef.NewbieNpcDialogueView)
    local NewbieNpcDialogueView = require "Modules.Newbie.NewbieNpcDialogueView"
    local parama = {}
    parama.bSetDepth = true 
    parama.id = stepconf.id
    parama.callback = function(id)
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.NewbieNpcDialogueView)
        finish_step(id)
    end
    NewbieNpcDialogueView.ShowView(parama)
end

step[99] = function (stepconf, args)
    -- print("stepconf==========>>", stepconf.id)
    local MazeProxy = require "Modules.Maze.MazeProxy"
    MazeProxy.Instance:FinishMazeDungenNewbie(stepconf.id, true, function(id)
        finish_step(id)
    end)
end



---------------------STEP----------------------

return MazeGuide