local UINormalWidget = UINormalWidget or BaseClass(LuaBasicWidget)
function UINormalWidget:OnLoad()
	local obj = GameObject(UIWidgetNameDef.Root_normal)	
	GameObjTools.AddComponent(obj,"RectTransform")
	self:LoadEnd(obj)
end

function UINormalWidget:LoadEnd(obj)
	self:SetGo(obj)
	self:AddPanel(UIWidgetNameDef.NormalPanel)	
	self:Step(0)
end

function UINormalWidget:OnOpen()
	self:SetDepth(self.go , 0)
	self:SetModelDepth(self.go, 0)
end

return UINormalWidget
