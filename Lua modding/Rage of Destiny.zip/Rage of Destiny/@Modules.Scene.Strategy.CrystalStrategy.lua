local BasicSceneStrategy = require "Modules.Scene.Strategy.BasicSceneStrategy"
local CrystalStrategy = CrystalStrategy or BaseClass(BasicSceneStrategy)
local BattleProxy = require "Modules.Battle.BattleProxy"
local render_camera = require "Battle.render.camera.render_camera"

function CrystalStrategy:OnLoad()
    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.NetworkDelayView)
    local scenename = "20007"
    self.closeParam = self.args[1] --目前是空表，以后若有多种跳转再考虑加参数
    self:LoadScene(nil, scenename)

    render_camera.free_trunk_strategy()
    render_camera.set_camera_field_of_view(55)
    render_camera.set_camera_transform({x = 2.45, y = 2.73, z = -9.93, pitch = 7.23, yaw = -1.33, roll = 0})
end

function CrystalStrategy:Destroy()
    self:UnloadScene()
end

function CrystalStrategy:OnStartEntry()
    self:DefaultOpenWidgets()
end

function CrystalStrategy:DefaultOpenWidgets()
    BattleProxy.Instance:StopGame()
    local render_area = require "Battle.render.render_area"
    render_area.destroy()

    -- local render_camera = require "Battle.render.camera.render_camera"
    -- render_camera.free_trunk_strategy()
    -- render_camera.set_camera_field_of_view(55)
    -- render_camera.set_camera_transform({x = 0.78, y = 3.38, z = -7.72, pitch = 7.23, yaw = 0, roll = 0})

    --[[
    local simple_anchor = require "Battle.render.anchor.simple_anchor"
    local simple_model = require "Battle.render.model.simple_model"

    local anchor = simple_anchor.New(x, y, z, r_x, r_y, r_z)
    local model = simple_model.New(anchor, "name")
    ]]

    local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.CrystalView)
    view.closeParam = self.closeParam
    view:OpenView()
    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.NetworkDelayView)
end

return CrystalStrategy