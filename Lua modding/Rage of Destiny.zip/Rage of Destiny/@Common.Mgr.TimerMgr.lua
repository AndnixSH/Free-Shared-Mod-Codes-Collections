local TimerMgr = TimerMgr or {}

local items = {}

--  仅供c#的behaviour调用
function TimerMgr.ToUpdate()
	for i = 1, #items do
		if items[i] then
			items[i]:Update()
		end
	end
end

function TimerMgr.Add(timer)
	table.insert(items, timer)
end

function TimerMgr.Remove(timer)
	for i = #items, 1, -1 do
		if items[i] == timer then
			table.remove(items, i)
			return
		end
	end
end

function TimerMgr.RemoveAll()
	items = {}
end

return TimerMgr
