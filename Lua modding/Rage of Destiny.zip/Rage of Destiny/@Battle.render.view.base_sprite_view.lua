local dynamictable
dynamictable = function(t)
    return setmetatable(t or {}, {
        __index = function(t, k)
            if not rawget(t, k) then
                rawset(t, k, dynamictable())
                return rawget(t, k)
            end
            return rawget(t, k)
        end
    })
end

local SpriteInterface = CS.LJY.NX.NxSpriteProxy


local base_sprite_view = BaseClass()
base_sprite_view.event = dynamictable()

local buff_anchor = require "Battle.render.anchor.buff_anchor"
local effect_sprite_model = require "Battle.render.model.effect_sprite_model"
local tail_effect_sprite_model = require "Battle.render.model.tail_effect_sprite_model"

function base_sprite_view:__init(sprite_id, config_id, _type)
    self.sprite_id = sprite_id
    self.config_id = config_id
    self._type = _type
    self.is_pause = false
    self.is_show = false

    -- speed
    local render_area = require "Battle.render.render_area"
    self.global_speed = render_area.global_speed
    self.active_speed = 1

    -- buff
    self.model_view = {}
    self.color_list = {}
    self.rim_color_list = {}
    self.special_state_list = {}

    -- event
    local spriteobj = global.service.pool:get_obj(sprite_id)
    global.service.eventslots:load(self.event, self, spriteobj, "view")
end

function base_sprite_view:__delete()
    global.service.eventslots:unload(self.event, self)
end

function base_sprite_view:create()
end

function base_sprite_view:release()
end

function base_sprite_view:speed(speed_rate)
    self.global_speed = speed_rate
    self:speed_active()
end

function base_sprite_view:pause()
    self.is_pause = true
    self:pause_active()
    self:pause_anchor()
end

function base_sprite_view:resume()
    if self.is_pause then
        self.is_pause = false
        self:resume_active()
        self:resume_anchor()
    end
end

function base_sprite_view:speed_active()
end

function base_sprite_view:pause_active()
    if self.body then
        self.body:pause_active()
    end
end

function base_sprite_view:resume_active()
    if self.body then
        self.body:resume_active()
    end
end

function base_sprite_view:pause_anchor()
    if self.body then
        self.body:pause_anchor()
    end
end

function base_sprite_view:resume_anchor()
    if self.body then
        self.body:resume_anchor()
    end
end

function base_sprite_view:get_body_item()
    if self.body then
        return self.body:get_game_item_model()
    end
end

function base_sprite_view:add_model(params)
    local key = params.key
    local prefab_name = params.prefab_name

    local anchor
    if params.anchor then
        local body_item = self:get_body_item()
        local header_type = params.anchor.header_type or 0
        local bone = params.anchor.bone
        anchor = buff_anchor.New(body_item, header_type, bone)
    end

    if anchor then
        if params.anchor.has_tail then
            local model = tail_effect_sprite_model.New(anchor, prefab_name)
            self.model_view[key] = model
        else
            local model = effect_sprite_model.New(anchor, prefab_name)
            self.model_view[key] = model
        end
    end
end

function base_sprite_view:remove_model(params)
    if self.model_view[params.key] then
        self.model_view[params.key]:release()
        self.model_view[params.key]:DeleteMe()
        self.model_view[params.key] = nil
    end
end

function base_sprite_view:add_active_model(params)
    local prefab_name = params.prefab_name

    local anchor
    if params.anchor then
        local body_item = self:get_body_item()
        local header_type = params.header_type or 0
        local bone = params.bone
        anchor = buff_anchor.New(body_item, header_type, bone)
    end

    local active, tag
    if params.active then
        active = params.active.active
        tag = params.active.tag or 0
    else
        active = ""
        tag = 0
    end

    local model = effect_sprite_model.New(anchor, prefab_name)
    model:start_active(string.format("%s_%s", prefab_name, active), self.global_speed, tag, function()
        model:release()
        model:DeleteMe()
    end)
end

function base_sprite_view:add_color(params)
    local key = params.key
    local color = params.color

    self:_set_color(color)
    table.insert(self.color_list, { key = key, color = color })
end

function base_sprite_view:remove_color(params)
    local key = params.key

    for index, buff_color in ipairs(self.color_list) do
        if buff_color.key == key then
            table.remove(self.color_list, index)
            break
        end
    end

    if #self.color_list == 0 then
        self:_reset_color()
    else
        local color = self.color_list[#self.color_list].color
        self:_set_color(color)
    end
end

function base_sprite_view:add_special_state(params)
    local key = params.key
    local state = params.state

    self:_set_special_state(state)
    table.insert(self.special_state_list, {key = key, state = state})
end

function base_sprite_view:remove_special_state(params)
    local key = params.key

    for index, special_state in ipairs(self.special_state_list) do
        if special_state.key == key then
            if special_state.state == 1 and self.body then
                self.body:unfreeze()
            elseif special_state.state == 2 and self.body then
                self.body:unpetrified()
            elseif special_state.state == 3 and self.body then
                self.body:unfreeze()
            elseif special_state.state == 4 and self.body and self.body.un_crystalized then
                self.body:un_crystalized()
            elseif special_state.state == 5 and self.body and self.body.un_rebirth then
                self.body:un_rebirth()
            elseif special_state.state == 6 and self.body and self.body.un_grace then
                self.body:un_grace()
            end
            table.remove(self.special_state_list, index)
            break
        end
    end

    if #self.special_state_list == 0 then
        self:_reset_special_state()
    else
        local state = self.special_state_list[#self.special_state_list].state
        self:_set_special_state(state)
    end
end

function base_sprite_view:add_rim_color(params)
    local key = params.key
    local rim_color = params.rim_color

    self:_set_rim_color(rim_color)
    table.insert(self.rim_color_list, { key = key, rim = rim_color })
end

function base_sprite_view:remove_rim_color(params)
    local key = params.key

    for index, buff_rim_color in ipairs(self.rim_color_list) do
        if buff_rim_color.key == key then
            table.remove(self.rim_color_list, index)
            break
        end
    end

    if #self.rim_color_list == 0 then
        self:_reset_rim_color()
    else
        local rim = self.rim_color_list[#self.rim_color_list].rim
        self:_set_rim_color(rim)
    end
end

function base_sprite_view:_set_color(color_table)
    if #color_table == 3 then
        local red = color_table[1] / 255
        local green = color_table[2] / 255
        local blue = color_table[3] / 255

        if self.body then
            self.body:set_color(Color.New(red, green, blue))
        end
    end
end

function base_sprite_view:_reset_color()
    if self.body then
        self.body:set_color(Color.white)
    end
end

function base_sprite_view:_set_rim_color(rim_table)
    if rim_table and #rim_table == 9 then
        local inner_red = rim_table[1] / 255
        local inner_green = rim_table[2] / 255
        local inner_blue = rim_table[3] / 255
        local inner_power = rim_table[4]
        local inner_color = Color.New(inner_red, inner_green, inner_blue)

        local red = rim_table[5] / 255
        local green = rim_table[6] / 255
        local blue = rim_table[7] / 255
        local color = Color.New(red, green, blue)
        local rim_power = rim_table[8]
        local rim_intensity = rim_table[9]

        if self.body then
            self.body:enable_rim_color(inner_color, inner_power, color, rim_power, rim_intensity)
        end
    else
        print("-->> rim_color error")
    end
end

function base_sprite_view:_reset_rim_color()
    if self.body then
        self.body:disable_rim_color()
    end
end

-- 1:冰冻 2:石化 3:减速 4:水晶
function base_sprite_view:_set_special_state(state)
    if state == 1 then
        if self.body then
            self.body:frozen()
            self:pause()
        end
    elseif state == 2 then
        if self.body then
            self.body:petrified()
            self:pause()
        end
    elseif state == 3 then
        if self.body and self.body.frozen then
            self.body:frozen()
        end
    elseif state == 4 then
        if self.body and self.body.crystalized then
            self.body:crystalized()
        end
    elseif state == 5 then --轮回
        if self.body and self.body.rebirth then
            self.body:rebirth()
        end
    elseif state == 6 then --神恩
        if self.body and self.body.grace then
            self.body:grace()
        end
    end
end

function base_sprite_view:_reset_special_state()
    if self.body then
        self:resume()
    end
end

local AudioManager = require "Common.Mgr.Audio.AudioManager"
function base_sprite_view:add_sound(soundname)
    AudioManager.PlaySoundByKey(soundname)
end

function base_sprite_view:remove_sound(soundname)
    AudioManager.StopSoundByKey(soundname)
end

--[[events]]
function base_sprite_view.event.sprite:SyncHeader(hx, hy)
    -- print(self.sprite_id, "SyncHeader", hx, hy)
    SpriteInterface.SetHeader(self.sprite_id, hx, hy)
end

function base_sprite_view.event.sprite:SyncPosition(px, py)
    -- print("SyncPosition", self.sprite_id, px, py)
    SpriteInterface.SetPosition(self.sprite_id, px, py)
end

function base_sprite_view.event.sprite:SyncHeight(h)
    -- print("SyncHeight", self.sprite_id, px, py)
    SpriteInterface.SetHeight(self.sprite_id, h)
end

--[[events]]

local base_sprit_view_class = function(...)
    local class = BaseClass(base_sprite_view, ...)
    class.event = dynamictable()
    if base_sprite_view.event then
        for k1, v1 in pairs(base_sprite_view.event) do
            for k2, v2 in pairs(v1) do
                class.event[k1][k2] = v2
            end
        end
    end
    return class
end

return base_sprit_view_class

--return sprite_view