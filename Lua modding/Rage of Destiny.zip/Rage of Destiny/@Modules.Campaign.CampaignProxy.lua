local CampaignDef = require "Modules.Campaign.CampaignDef"
local BattleProto = require "Core.Implement.Net.BattleProto"
local IGGSdkDef = require "Modules.IGGSdk.IGGSdkDef"
local SdkEventProxy = require "Modules.Sdk.SdkEventProxy"

local CampaignProxy = CampaignProxy or BaseClass(BaseProxy, BattleProto)
function CampaignProxy:__init(name)
    CampaignProxy.Instance = self

    self:AddProto(51000, self.On51000) --挂机信息
    self:AddProto(51001, self.On51001) --领取挂机奖励
    self:AddProto(51002, self.On51002) --快速挂机信息
    self:AddProto(51003, self.On51003) --领取快速奖励
    self:AddProto(51004, self.On51004) --开始主线战斗
	self:AddProto(51005, self.On51005) --获取挂机时间
    self:AddProto(51006, self.On51006) --前往下一章
    self:AddProto(51007, self.On51007) --主线上阵
    self:AddProto(51008, self.On51008) --
    self:AddProto(51009, self.On51009) --
    self:AddProto(51010, self.On51010) --
    self:AddProto(51011, self.On51011) --自动推图
	self:AddProto(51012, self.On51012) --清空多队推图胜场数据

    self:AddPreBattle(ACTIVITYID.MAINLINE, self.OnPreBattle) --准备战斗回调
    self:AddSetBattle(ACTIVITYID.MAINLINE, self.OnSetBattle) --战斗结算回调
    self:AddStartBattle(ACTIVITYID.MAINLINE, self.OnStartBattle) --战斗开始回调

    self:AddAutoPreBattle(ACTIVITYID.MAINLINE, self.OnAutoPreBattle) --自动战斗回调

    self.data = {}
    self.data.hangupInfo = {}
    self.data.fasthangupInfo = {}
	self.data.pass_map = {}
    self.bClickGoBtn=true
    self.tmp_max_hangup_time = 12 * 60 * 60 -- 临时最大挂机时间 临时数据

    self.twelve_Hours = 12 * 60 *60
    self.delayTimer = false
    self.delayTimer2 = false
end

function CampaignProxy:__delete()
    self.data = nil
end

--proto
function CampaignProxy:Send51000()
    self:SendMessage(51000)
end

function CampaignProxy:GetMaxHangupTime()
    local VipProxy = require "Modules.Vip.VipProxy"
    local VipDef = require "Modules.Vip.VipDef"
    local time =self.tmp_max_hangup_time
    local add_time = VipProxy.Instance:GetCurrentVipLevelPrivilege(VipDef.privilegeType.privilegeType_9)
    return time  + add_time * 60 * 60
end

function CampaignProxy:On51000(decoder)
    local hangupInfo = {}
    hangupInfo.time = decoder:Decode("I4")  --挂机时间 
    hangupInfo.time = math.min(hangupInfo.time, self:GetMaxHangupTime())
    hangupInfo.rewards = {}
    local count = decoder:Decode("I2")
    if count > 0 then
        for i = 1, count do
            local info = {}
            info.goodsid, info.goodsnum = decoder:Decode("I4I4")
            table.insert(hangupInfo.rewards, info)
        end
    end
	--print("rewards -->", table.dump(hangupInfo))
    self.data.hangupInfo = hangupInfo
    self:ToNotify(self.data, CampaignDef.NotifyDef.ShowHangUp, hangupInfo)

    self:UpdateNotification(self.data.hangupInfo,false)
end

function CampaignProxy:UpdateNotification(hangupInfo,reset)
    local time = hangupInfo.time
    if not hangupInfo or not time then
        return
    end
    
    if reset then
        time = 0
    end
    local remaintime = self.twelve_Hours - time
    local remaintime2 = 2*self.twelve_Hours - time
    local SettingMenuProxy = require "Modules.SettingMenu.SettingMenuProxy"
	local SettingMenuDef = require "Modules.SettingMenu.SettingMenuDef"
    local Timer = require "Common.Util.Timer"
    print("----remaintime-------------",remaintime)

    if remaintime2 <= 0 then
        --挂机超过24小时
        SettingMenuProxy.Instance:SendHangUpNotification(SettingMenuDef.NotificationExplicitID.hangup_24,2*self.twelve_Hours,reset,0)
    else

        if remaintime2 >= self.twelve_Hours then
            --挂机不足12小时
            SettingMenuProxy.Instance:SendHangUpNotification(SettingMenuDef.NotificationExplicitID.hangup_12,self.twelve_Hours,reset,remaintime2 - self.twelve_Hours)
        else
            --挂机超过12小时 但不足24小时
            SettingMenuProxy.Instance:SendHangUpNotification(SettingMenuDef.NotificationExplicitID.hangup_12,self.twelve_Hours,reset,0)
        end
    end
    if remaintime > 0 then
        --挂机不足12小时
        --SettingMenuProxy.Instance:SendSimplyNotification(SettingMenuDef.NotificationExplicitID.hangup_12,remaintime,reset)
    else
         --挂机超过12小时
         --SettingMenuProxy.Instance:SendSimplyNotification(SettingMenuDef.NotificationExplicitID.hangup_12,1,reset)
    end
end

function CampaignProxy:Send51001()
    self:SendMessage(51001)
end

function CampaignProxy:On51001(decoder)
    local result, total_count = decoder:Decode("I1I4")
    if result == 0 then
        self:UpdateNotification(self.data.hangupInfo,true)
        self:ToNotify(self.data, CampaignDef.NotifyDef.GetHangUpReward, self.data.hangupInfo)
        self.data.hangupInfo = {}

        local view_manager = require "Battle.render.view_manager"
        view_manager.on_hangup_reward(0)
		
		SdkEventProxy.Instance:TrackSdkEvent(IGGSdkDef.AFEventHangUp[total_count])
    end
end

function CampaignProxy:Send51002()
    self:SendMessage(51002)
end

function CampaignProxy:On51002(decoder)
    self.data.fasthangupInfo.resettime, self.data.fasthangupInfo.usecount, self.data.fasthangupInfo.leftcount = decoder:Decode("I4I1I1")
    self:ToNotify(self.data, CampaignDef.NotifyDef.ShowFastHangUp, self.data.fasthangupInfo)

    local MainProxy = require "Modules.Main.MainProxy"
    local MainDef = require "Modules.Main.MainDef"
    MainProxy.Instance:UpdateRedDot(MainDef.MainRedDotType.FreeFastReward, self.data.fasthangupInfo.usecount == 0 and 1 or 0)
end

function CampaignProxy:Send51003()
    self:SendMessage(51003)
end

function CampaignProxy:On51003(decoder)
    local result = decoder:Decode("I1")
    if result == 0 then
        local rewards = {}
        local count = decoder:Decode("I2")
        if count > 0 then
            for i = 1, count do
                local info = {}
                info.goodsid, info.goodsnum = decoder:Decode("I4I4")
                table.insert(rewards, info)
            end
        end
        self:ToNotify(self.data, CampaignDef.NotifyDef.GetFastHangUpReward, rewards)
    end
end

function CampaignProxy:Send51004(enemy_id)
    local encoder = NetEncoder.New()
    encoder:Encode("I4I4", RoleInfoModel.mainlineid, enemy_id or 0)
    self:SendMessage(51004, encoder)

    local BattleProxy = require "Modules.Battle.BattleProxy"
    BattleProxy.Instance:BattleReadySetStep(ACTIVITYID.MAINLINE, 1)
end

function CampaignProxy:On51004(decoder)
    local result, last_pass_mainline_time = decoder:Decode("I2I4")
    if result ~= 0 then
        local BattleProxy = require "Modules.Battle.BattleProxy"
        BattleProxy.Instance:BattleReadyNextStep(ACTIVITYID.MAINLINE, 1)
    else
        self.data.last_pass_mainline_time = last_pass_mainline_time
    end
end

function CampaignProxy:Send51005()
	self:SendMessage(51005)
end

function CampaignProxy:On51005(decoder)
	local hangup_time = decoder:Decode("I4")
	--print("hangup_time", hangup_time)
    local view_manager = require "Battle.render.view_manager"
    view_manager.on_hangup_reward(hangup_time)
end

function CampaignProxy:Send51006()
    
    if AppConfig.ISALONE then
        RoleInfoModel.current_section = RoleInfoModel.current_section + 1
        self:ResetGoBtnState()
    else
        self:SendMessage(51006)
    end
end

function CampaignProxy:On51006(decoder)
    local result = decoder:Decode("I1")
    if result == 0 then
        --RoleInfoModel.current_section = RoleInfoModel.current_section + 1
        self:ResetGoBtnState()
    end
end

--上阵
function CampaignProxy:Send51007(hero_infos, enemy_infos, bufferstr)
    --print("Send51007==========", table.dump(hero_infos), table.dump(enemy_infos))
    local encoder = NetEncoder.New()
    self:_EncodeHeroInfo(hero_infos, encoder)
    self:_EncodeEnemyInfo(enemy_infos, encoder)
    encoder:Encode("s2", bufferstr or "")
    self:SendMessage(51007, encoder)
end

function CampaignProxy:On51007(decoder)
    local result = decoder:Decode("I1")
    if result == 1 then
        local lowestPower = decoder:Decode("I4")
        local LanguageManager = require "Common.Mgr.Language.LanguageManager"
        local str = LanguageManager.Instance:GetWord("BattleSelect_1005", lowestPower)
        GameLogicTools.ShowMsgTips(str)
    end
end

function CampaignProxy:Send51008(mainlineid)
    local encoder = NetEncoder.New()
    encoder:Encode("I4", mainlineid)
    self:SendMessage(51008, encoder)
end

function CampaignProxy:On51008(decoder)
    local infos = {}
    local count = decoder:Decode("I2")
    for i=1,count do
        local item = {}
        item.activityId = ACTIVITYID.MAINLINE
        item.guser = decoder:Decode("I8")
        item.mainlineid = decoder:Decode("I4")
        
        local headItem = {}
        headItem.nickname = decoder:Decode("s2")
        headItem.headIcon = decoder:Decode("I4")
        headItem.frameIcon = decoder:Decode("I4")
        headItem.sex = decoder:Decode("I2")
        headItem.level = decoder:Decode("I2")
        headItem.fight = decoder:Decode("I4")
        item.type = decoder:Decode("I2")

        item.headItem = headItem
        table.insert(infos, item)
    end
    table.sort(infos, function(a, b)
        if a.type == b.type then
            return a.headItem.fight < b.headItem.fight
        else
            return a.type < b.type
        end
    end)
    -- print("On51008========", table.dump(infos))
    self:ToNotify(self.data, CampaignDef.NotifyDef.UpdateMainlineReportInfoMembers, {memberInfos = infos})
end

function CampaignProxy:Send51009(guser, mainlineid, headItem, index)
	self:GetBattleRecord(headItem, mainlineid, guser, index,
		function (decoder)
			if decoder then
				self:On51009(decoder, headItem, mainlineid, guser, index)
			end
	end)
end

function CampaignProxy:DecodeBattleReport(decoder, headItem, mainlineid, guser, index)
	local _result = decoder:Decode("I2")
	if _result == 0 then
		local settledata = self:DecodeSettleData(decoder)
		local redData = headItem
		local blueData = {}
		local camps = settledata.camps
		local result = settledata.result

		local enemys = self:GetAllEnemy(mainlineid)
		local enemyid = enemys[index or 1]
		local enemylist, bossinfo = GameLogicTools.GetEnemyList(enemyid)
		local info = bossinfo or enemylist[1]
		if info then
			local HeroProxy = require "Modules.Hero.HeroProxy"
			local herocfg = HeroProxy.Instance:GetRoleCfgByConfigId(info.role)
			local LanguageManager = require "Common.Mgr.Language.LanguageManager"
			blueData.nickname = LanguageManager.Instance:GetWord(herocfg.name)
			blueData.level = info.level
			blueData.rank = info.rank
			blueData.roleid = info.role
		end

		local winCamp = result == 0 and CAMP.RED or CAMP.BLUE
		
		local func = function ()
			self:Send51010(guser, mainlineid, index)
		end
		
		return {winCamp = winCamp, redData = redData, blueData = blueData, camps = camps, func = func}
	end
end

function CampaignProxy:On51009(decoder, headItem, mainlineid, guser, index)
	local result = self:DecodeBattleReport(decoder, headItem, mainlineid, guser, index)
	UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 4, result.winCamp, result.redData, result.blueData, result.camps, result.func)
end

function CampaignProxy:Send51010(guser, mainlineid, index)
    local ReportLoader = require "Modules.Common.ReportLoader"
    local reporter =  ReportLoader.New(guser, ACTIVITYID.MAINLINE, self:GetBattleReportKey(mainlineid, index))
    reporter:RequestPlay(guser)
end

function CampaignProxy:On51010(decoder)
    local result = decoder:Decode("I2")
    
end

--自动战斗
function CampaignProxy:Send51011(enemyid)
	local encoder = NetEncoder.New()
	encoder:Encode("I4I4", RoleInfoModel.mainlineid, enemyid or 0)
	self:SendMessage(51011, encoder)
end

function CampaignProxy:On51011(decoder)
    local result = decoder:Decode("I2")
    --print("On51011==", result)
end

--清空多队推图胜场数据
function CampaignProxy:Send51012(mainlineid)
	local encoder = NetEncoder.New()
	encoder:Encode("I4", RoleInfoModel.mainlineid)
	self:SendMessage(51012, encoder)
end

function CampaignProxy:On51012(decoder)
	local result = decoder:Decode("I2")
	--print("On51011==", result)
end

function CampaignProxy:GetBattleRecord(headItem, mainlineid, guser, index, callback)
	local ReportLoader = require "Modules.Common.ReportLoader"
	local reporter =  ReportLoader.New(guser, ACTIVITYID.MAINLINE, self:GetBattleReportKey(mainlineid, index))
	reporter:RequestSettle(function (decoder)
			if callback then
				callback(decoder, index)
			end
		end)
end

function CampaignProxy:GetBattleReportKey(mainlineid, index)
	if index and (index > 1) then
		return tostring(mainlineid) .. "_" .. tostring(index)
	end
	return tostring(mainlineid)
end

function CampaignProxy:ResetGoBtnState()
    --点击了前往下一章节，信息需要重置
    self.bClickGoBtn=true
    local SceneManager = require "Modules.Scene.SceneManager"
    local SceneDef = require "Modules.Scene.SceneDef"
    RoleInfoModel.mainlineid = RoleInfoModel.mainlineid +1
    SceneConstruct.CleanSceneByType(SceneDef.SceneType.Main)
    SceneManager.Instance:EnterScene(SceneDef.SceneType.Main)

    local MallProxy = require "Modules.Mall.MallProxy"
    MallProxy.Instance:UpdateRedPointGrow()
    local CardPortalProxy = require "Modules.CardPortal.CardPortalProxy"
    CardPortalProxy.Instance:UpdateWishListRedDot()
end
--设置通关状态
function CampaignProxy:SetGoBtnState()
    --通关了， 没有点击前往
    local mainlinecfg = self:GetCurMainLine()
    if mainlinecfg.section == 1 and RoleInfoModel.current_section ~=  mainlinecfg.chapter then
        self.bClickGoBtn=false
        RoleInfoModel.mainlineid = RoleInfoModel.mainlineid - 1  --没有点击前往，主线id不用加1 此时改章节已经通过了（服务端只记录已通过的章节）
    else
        self.bClickGoBtn=true
    end

    local MallProxy = require "Modules.Mall.MallProxy"
    MallProxy.Instance:UpdateRedPointGrow()
end

--是否通关了
function CampaignProxy:IsPassToNextChapter()
    return  not self.bClickGoBtn
end

--获取已通关的主线任务id
function CampaignProxy:GetPassMainlineid()
    if self:IsPassToNextChapter() then
        return RoleInfoModel.mainlineid
    else
        return RoleInfoModel.mainlineid - 1
    end
end

function CampaignProxy:OnPreBattleBuffer(bufferstr)
    local enemyid, mainlineid = string.unpack(">I4I4", bufferstr)
    return { enemyid = enemyid, view = { name = "BattleMainPanle", args = {enemyid, mainlineid} }}
end

function CampaignProxy:OnStartBattleBuffer(bufferstr)
	local enemyid, mainlineid = string.unpack(">I4I4", bufferstr)
	return { mainlineid = mainlineid, enemyid = enemyid }
end

function CampaignProxy:OnSetBattle()
end

--config
function CampaignProxy:GetMainLineConfig()
    local config = ConfigManager.GetConfig("data_mainline")
    return config
end

function CampaignProxy:GetMainLineCfgById(id)
    local cfg = self:GetMainLineConfig()
    if cfg[id] then
        return cfg[id]
    else
        print("not find mainline ,id:", id)
    end
end

function CampaignProxy:GetMainLineCfgByInfo(chapter, section)
    local cfgs = self:GetMainLineConfig()
    for _, cfg in pairs(cfgs) do
        if cfg.chapter == chapter and cfg.section == section then
            return cfg
        end
    end
    print("not find mainline ,chapter, section:", chapter, section)
end

function CampaignProxy:GetChapterCfgById(id)
    local cfg = ConfigManager.GetConfig("data_chapter")
    if cfg[id] then
        return cfg[id]
    else
        -- print("not find data_chapter ,id:",id)
    end
end

--logic
function CampaignProxy:GetMainLineBossInfo(id)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local LanguageUtil = require "First.Util.LanguageUtil"
    local info = {}
    local cfg = self:GetMainLineCfgById(id)
    local _, bossinfo = GameLogicTools.GetEnemyList(cfg.enemy_id)
    if cfg and bossinfo then
        local herocfg = HeroProxy.Instance:GetRoleCfgByConfigId(bossinfo.role)
        info.nickname = LanguageUtil.GetWord(herocfg.name)
        info.level = bossinfo.level
        info.rank = bossinfo.rank
        info.roleid = bossinfo.role
    end
    return info
end

--关卡挂机怪物
function CampaignProxy:GetMainLineMonster(id)
    local list = {}
    local cfg = self:GetMainLineCfgById(id)
    if cfg and cfg.monster then
        return cfg.monster
    end
    return list
end

--当前关卡挂机怪物
function CampaignProxy:GetCurMainLineMonster()
    local mainlinecfg = self:GetCurMainLine()
    return self:GetMainLineMonster(mainlinecfg.id)
end

--当前关卡配置 ,若为空取最大关卡
function CampaignProxy:GetCurMainLine()
    local mainlinecfg = self:GetMainLineCfgById(RoleInfoModel.mainlineid)
    if not mainlinecfg then
        local cfgs = self:GetMainLineConfig()
        mainlinecfg = cfgs[#cfgs]
    end
    return mainlinecfg
end

--当前章节配置 ,若为空取最大章节
function CampaignProxy:GetCurChapter()
    local mainlinecfg = self:GetCurMainLine()
    local cfg = self:GetChapterCfgById(mainlinecfg.chapter)
    return cfg
end

--是否通关了
function CampaignProxy:IsPass()
    local mainlinecfg = self:GetMainLineCfgById(RoleInfoModel.mainlineid)
    return mainlinecfg == nil
end

function CampaignProxy:GetMaxChapter()
	local cfg = ConfigManager.GetConfig("data_chapter")
	if cfg and (#cfg > 0) then
		return cfg[#cfg].id
	end
	return 0
end

--获得对应消耗道具的 挂机 每秒收益
function CampaignProxy:GetExchangeCount(exchangeId)
    local mainline_id = self:GetPassMainlineid()
    mainline_id = (mainline_id == 0 or mainline_id < 0) and 1 or mainline_id
    local mainLineCfg = self:GetMainLineCfgById(mainline_id)
    local goodsKey = {
        [CURRENCY_TYPE_GOODID[CURRENCY_TYPE.coin]] = "coin",
        [CURRENCY_TYPE_GOODID[CURRENCY_TYPE.hero_exp]] = "hero_exp",
        [690001] = "hero_essence",
    }
    if goodsKey[exchangeId] and mainLineCfg[goodsKey[exchangeId]] then
        return mainLineCfg[goodsKey[exchangeId]]
    end
    return nil
end

function CampaignProxy:NotifyBoxRewardViewClose()
	self:ToNotify(self.data, CampaignDef.NotifyDef.NotifyBoxRewardViewClose)
end

--多队推图
function CampaignProxy:HasExtraEnemy(mainlineid)
	local enemy_list = self:GetExtraEnemy(mainlineid)
	return enemy_list and (#enemy_list > 0)
end

--多队推图额外敌人
function CampaignProxy:GetExtraEnemy(mainlineid)
	local mainlinecfg = self:GetMainLineCfgById(mainlineid)
	if mainlinecfg then
		return mainlinecfg.more_enemy or {}
	end
	return {}
end

--主线推图全部敌人
function CampaignProxy:GetAllEnemy(mainlineid)
	local mainlinecfg = self:GetMainLineCfgById(mainlineid)
	if mainlinecfg then
		return {mainlinecfg.enemy_id, table.unpack(self:GetExtraEnemy(mainlineid))}
	end
	return {}
end

function CampaignProxy:GetPassStateList(mainlineid)
	if not self.data.pass_map[mainlineid] then
		self.data.pass_map[mainlineid] = {}
	end
	return self.data.pass_map[mainlineid]
end

function CampaignProxy:SetPassState(mainlineid, enemyid)
	local pass_map = self:GetPassStateList(mainlineid)
	pass_map[enemyid] = true
end

--多队推图通关敌人数据
function CampaignProxy:GetPassState(mainlineid, enemyid)
	local pass_map = self:GetPassStateList(mainlineid)
	return pass_map[enemyid] or false
end

function CampaignProxy:GetEnemyIndex(mainlineid, enemyid)
	return table.indexof(self:GetAllEnemy(mainlineid), enemyid)
end

function CampaignProxy:IsPassAllEnemy(mainlineid)
	local enemys = self:GetAllEnemy(mainlineid)
	local all_pass = true
	for _,v in ipairs(enemys) do
		if not self:GetPassState(mainlineid, v) then
			return false
		end
	end
	return all_pass
end

function CampaignProxy:ClearPassState(mainlineid)
	self.data.pass_map[mainlineid] = {}
	self:Send51012(mainlineid)
end

function CampaignProxy:GetLowestPower(mainlineid, enemyid)
	local powers = self:GetAllLowestPower(mainlineid)
	return powers[self:GetEnemyIndex(mainlineid, enemyid)]
end

function CampaignProxy:GetAllLowestPower(mainlineid)
	local mainLineCfg = self:GetMainLineCfgById(mainlineid)
	if self:HasExtraEnemy(mainlineid) then
		return {mainLineCfg.lowest_power, table.unpack(mainLineCfg.more_power)}
	end
	return {mainLineCfg.lowest_power}
end

function CampaignProxy:HasPassOneEnemy(mainlineid)
	local pass_map = self:GetPassStateList(mainlineid)
	for enemyid, pass in pairs(pass_map) do
		if pass then
			return true
		end
	end
	return false
end

function CampaignProxy:ShowBattleRecordListView(activity_id, mainlineid, guser, headItem)
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleRecordListView)
	if view then
		view.activity_id = activity_id
		view.level_id = mainlineid
		view.guser = guser
		view.headItem = headItem
		view:OpenView()
	end
end

function CampaignProxy:GetLastPassMainLineTime()
    local time = 0
    if self.data.last_pass_mainline_time and self.data.last_pass_mainline_time ~= 0 then
        local current_time = RoleInfoModel.servertime
        local last_pass_mainline_time = self.data.last_pass_mainline_time

        time = Mathf.Max(0, current_time - last_pass_mainline_time)
    end
    self.data.last_pass_mainline_time = 0
    return time
end

return CampaignProxy
