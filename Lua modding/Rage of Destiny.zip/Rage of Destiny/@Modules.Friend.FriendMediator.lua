local FriendMediator = FriendMediator or BaseClass(StdMediator)

function FriendMediator:OnEnterScenceFirst()
	self:DelayExecute(function()
		local FriendProxy = require "Modules.Friend.FriendProxy"
		FriendProxy.Instance:Send19002()
		FriendProxy.Instance:Send19000()
		FriendProxy.Instance:Send19003()
		FriendProxy.Instance:Send19011()
	end)

end


return FriendMediator