local synchronous_anchor = BaseClass()

local cSynchronousAnchor = CS.LJY.NX.SynchronousAnchor

function synchronous_anchor:__init(targetanchor)
    self.canchor = cSynchronousAnchor(targetanchor.canchor)
end

function synchronous_anchor:__delete()
    if self.canchor then
        self.canchor = nil
    end
end

return synchronous_anchor