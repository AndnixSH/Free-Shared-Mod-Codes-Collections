local MarqueeProxy = require "Modules.Marquee.MarqueeProxy"
local ObjPoolRender = require "Core.Implement.UI.Class.ObjPoolRender"
local ObjPoolItem = require "Core.Implement.UI.Class.ObjPoolItem"

------------------------PoolItem----------------------
local PoolItem = PoolItem or BaseClass(ObjPoolItem, TimerFactor)

function PoolItem:Load(obj)
	self.go = obj

	self.backWidth = 870
	self.backHeight = 37
	self.maxChar = 300
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MainView)
	if view and view:IsOpen() then
		self.backWidth, self.backHeight = view:GetMarqueePanelRect()
	end

	self:InitUI()
end

function PoolItem:InitUI()
	self.contentLab = self:GetComponent(self.go, "CLabel")
	self.contentTrm = self:GetComponent(self.go, "RectTransform")
	self.contentLab.gameObject:SetActive(false)
	self.originPos = Vector3.New(self.backWidth,0,0)
end

function PoolItem:SetData(data)
	self.contentLab.gameObject:SetActive(false)
	self.data = data

	local lenth, content = GameLogicTools.CheckContentLength(self.data.content, self.maxChar)
	self.contentLab.gameObject:SetActive(true)
	self.contentLab.text = content
	UILayerTool.UpdateCanvases()
	local width = self.contentLab.preferredWidth
	self.contentTrm.sizeDelta = Vector2.New(width+20, self.contentLab.preferredHeight)
	self:AnimMove(width+self.backWidth, self.data.duration)


end

--dic ：运动距离  duration:时间
function PoolItem:AnimMove(dic, duration)
	self.contentLab.gameObject.transform.localPosition = self.originPos
	self.quence = DOTween.Sequence()
	local tween = self.contentLab.transform:DOLocalMoveX(self.originPos.x-dic, duration)
	tween:SetEase(Ease.Linear)
	self.quence:Append(tween)
	self.quence:AppendCallback(function( ... )

		if PoolItem.target and PoolItem.callback then
			PoolItem.callback(PoolItem.target, self)
		end

	end)
end

function PoolItem:Close()
	self.contentLab.gameObject:SetActive(false)
	if self.quence then self.quence:Kill() self.quence = nil end
end

function PoolItem:Destroy()
	if self.quence then self.quence:Kill() self.quence = nil end
end



---------------------MarqueePanel------------------------
local MainMarqueePanel = MainMarqueePanel or BaseClass(GameObjFactor, TimerFactor)

function MainMarqueePanel:__init(go)
	self.startInterval = 0.1  --黑底出现0.1秒后文字出现
	self.endInterval = 0.2     --文字消失0.2秒后，黑底消失
	self:LoadEnd(go)
end

function MainMarqueePanel:LoadEnd(obj)
	self.go = obj
	self:InitUI()
end

function MainMarqueePanel:Open()
	self.tipsInfoObj:SetActive(true)
	self.backSp.enabled = true
	self.go:SetActive(true)
	self:UpdateView()
end

function MainMarqueePanel:Close()
	self:ClearMarqueeBeginTimer()
	self:ClearMarqueeEndTimer()
	self.go:SetActive(false)
	self.poolRender:ReleaseAll()
end

function MainMarqueePanel:InitUI()
	self._canvas = self:GetChildComponent(self.go, "CSprite_Back/CCanvas_New", "CCanvas")
	self._canvasRect = self:GetChildComponent(self.go, "CSprite_Back/CCanvas_New", "RectTransform")
	self.canvasSizeDelta = self._canvasRect.sizeDelta
	self.tipsInfoObj = self:GetChild(self.go, "CSprite_Back")
	self.backSp = self:GetComponent(self.tipsInfoObj, "CSprite")
	self.tipsInfoObj:SetActive(false)
	self.itemPatent = self:GetChild(self.go, "CSprite_Back/CCanvas_New/Viewport")
	self.contentItem = self:GetChild(self.go, "CSprite_Back/CCanvas_New/Viewport/Content")
	self.contentItem:SetActive(false)

	self.poolRender = ObjPoolRender.New()
	self.poolRender:Load(self.contentItem, self.contentItem.transform.parent, PoolItem)
	PoolItem.target = self
	PoolItem.callback = self.OnItemCallback
end

function MainMarqueePanel:GetCanvasRect()
	return self.canvasSizeDelta.x, self.canvasSizeDelta.y
end

function MainMarqueePanel:OnItemCallback(class)

	-- MarqueeProxy.Instance:RemoveMarqueeInfo()

	self:ClearMarqueeEndTimer()
	self.endTimer = self:AddTimer(function()
		if self.closeMarquee == true then
			self:Close()
			return
		end

		if class then
			self.poolRender:Release(class)
		end
		self:UpdateView()
	end, self.endInterval, 1)

end

function MainMarqueePanel:Destroy()
	self:ClearMarqueeBeginTimer()
	self:ClearMarqueeEndTimer()
	self.poolRender:ReleaseAll()
end

function MainMarqueePanel:UpdateView()
	self.closeMarquee = false
	local info = MarqueeProxy.Instance:GetMarqueeInfo()
	if not info then
		self:Close()
		return
	end

	self:ClearMarqueeBeginTimer()
	self.backSp.enabled = true
	self.beginTimer = self:AddTimer(function()
		--延迟self.beginTimer 显示内容
		self.poolRender:Get(info)
		MarqueeProxy.Instance:RemoveMarqueeInfo()

	end, self.startInterval, 1)

end

function MainMarqueePanel:ClearMarqueeBeginTimer()
	if self.beginTimer then
		self:RemoveTimer(self.beginTimer)
		self.beginTimer = nil
	end
end

function MainMarqueePanel:ClearMarqueeEndTimer()
	if self.endTimer then
		self:RemoveTimer(self.endTimer)
		self.endTimer = nil
	end
end

function MainMarqueePanel:UpdateMarqueeInfo()
	self:Open()
end

function MainMarqueePanel:UpdateMarqueeType()
	self.poolRender:ReleaseAll()
	self:Close()
end

function MainMarqueePanel:CloseMarquee()
	self.closeMarquee = true
end

return MainMarqueePanel