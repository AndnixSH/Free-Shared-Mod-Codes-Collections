local TweenTools =  require "Common.Util.TweenTools"
local GameUIUtil = CS.GameUIUtil
local ItemDropView = ItemDropView or BaseClass(LuaBasicWidget)
ItemDropView.DropType = 
{
	Exp = 0,
	Coin = 1,
	Gem = 2,
	Goods = 3,
}
function ItemDropView:__init()

end

function ItemDropView:OnLoad()
	AssetManager.LoadUIPrefab(self, "UICommon.ItemDropView",self.LoadEnd)
end

function ItemDropView:LoadEnd(obj)
	self:SetGo(obj)

	self.expItem = self:GetChild(obj, "exproot/sprite")
	self.expItemList = {}

	self.coinItem = self:GetChild(obj, "coinroot/sprite")
	self.coinItemList = {}

	self.gemItem = self:GetChild(obj, "gemroot/sprite")
	self.gemItemList = {}	

	self.goodsItem = self:GetChild(obj, "goodsroot/GoodsItem")
	self.goodsList = {}
	self.goodsClassList = {}
	

	self.bagBtnObj=self:GetChild(obj,"bagroot")
	self.bagSpriteObj=self:GetChild(self.bagBtnObj,"sprite")
	self.bagRedObj=self:GetChild(self.bagSpriteObj,"red")
	self:SetStep(0)
end

function ItemDropView:OnOpen()
	self:SetDepth(self.go, 1500)
end

function ItemDropView:OnClose()
	self:ClearAwardGoodsSeq()
end

function ItemDropView:KillSeqLists(sequencList)
	if sequencList then
		for k,sequencelist in pairs(sequencList) do
			for k,v in pairs(sequencelist) do
				v:Kill()
			end
		end
		sequencList = {}
	end
end

function ItemDropView:OnDestroy()
	
	self:KillSeqLists(self.expSequencList)
	self:KillSeqLists(self.gemSequencList)
	self:KillSeqLists(self.coinSequencList)

	self:ClearAwardGoodsSeq()
	if self.goodsSequencList then
		for i,sequence in pairs(self.goodsSequencList) do
			sequence:Kill()
		end
		self.goodsSequencList = nil
	end
	self:ClearTargetObjTween()
	self:ClearTargetCoinTween()
	self:ClearTargetGemTween()
	self:ClearTargetExpTween()
end

function ItemDropView:UpdateInfo(droptype, from, to, num, func)
	--nil获去主界面的位置
	if to == nil then
		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MainView)
		if view:IsOpen() then
			local tweenObjs = view.mainInfoPanel:GetTweenObjs()

			if droptype == ItemDropView.DropType.Exp then
				to = tweenObjs[1].transform.position
			elseif droptype == ItemDropView.DropType.Coin then
				to = tweenObjs[2].transform.position
			elseif droptype == ItemDropView.DropType.Gem then
				to = tweenObjs[3].transform.position
			else
				view.mainSystemPanel:ShowBar(0) --展开列表
				to = view.mainSystemPanel:GetBagItemPos()
			end	
		else
			to=self.bagBtnObj.transform.position
		end
	end	

	if droptype == ItemDropView.DropType.Exp then
		self.expSequencList = self.expSequencList or {}
		TweenTools.ShowGetIconFlyTween(self.expItem, self.expItemList, from, to, num, func)

	elseif droptype == ItemDropView.DropType.Coin then
		self.coinSequencList = self.coinSequencList or {}
		TweenTools.ShowGetIconFlyTween(self.coinItem, self.coinItemList, from, to, num, func)

	elseif droptype == ItemDropView.DropType.Gem then
		self.gemSequencList = self.gemSequencList or {}
		TweenTools.ShowGetIconFlyTween(self.gemItem, self.gemItemList, from, to, num, func)
	end	
end

function ItemDropView:FlyItemScaleTweenView(widgetName, scaleType, total_time)
	if widgetName and scaleType and total_time then
		local view = LuaLayout.Instance:GetWidget(widgetName)
		if view and view:IsOpen() then
			view:FlyItemScaleTween(scaleType, total_time)
		end
	end
end

function ItemDropView:UpdateCoinInfo(droptype, from, num, func, goods_count)
	--nil获去主界面的位置
	local widgetName, scaleType = nil

	local BagProxy = require "Modules.Bag.BagProxy"
	to, widgetName, scaleType = BagProxy.Instance:GetFullScreenPropertyByGoodId(nil, droptype)
	if to and widgetName and scaleType then
		local _callback = function(idx, num, totalcount, move_time)
			if idx == 1 then
				self:FlyItemScaleTweenView(widgetName, scaleType, move_time)
			end
		end

		if droptype == ItemDropView.DropType.Exp then
			self.expSequencList = self.expSequencList or {}
			local sequencelist, totle_time = TweenTools.ShowCoinIconFlyTween(self.expItem, self.expItemList, from, to, num, _callback)
			table.insert(self.expSequencList, sequencelist)
		elseif droptype == ItemDropView.DropType.Coin then
			self.coinSequencList = self.coinSequencList or {}
			local sequencelist, totle_time = TweenTools.ShowCoinIconFlyTween(self.coinItem, self.coinItemList, from, to, num, _callback, goods_count)
			table.insert(self.coinSequencList, sequencelist)
		elseif droptype == ItemDropView.DropType.Gem then
			self.gemSequencList = self.gemSequencList or {}
			local sequencelist, totle_time = TweenTools.ShowCoinIconFlyTween(self.gemItem, self.gemItemList, from, to, num, _callback)
			table.insert(self.gemSequencList, sequencelist)
		end
	else
		to=self.bagBtnObj.transform.position
		if droptype == ItemDropView.DropType.Exp then
			self.expSequencList = self.expSequencList or {}
			local sequencelist, totle_time = TweenTools.ShowCoinIconFlyTween(self.expItem, self.expItemList, from, to, num, nil)
			table.insert(self.expSequencList, sequencelist)
		elseif droptype == ItemDropView.DropType.Coin then
			self.coinSequencList = self.coinSequencList or {}
			local sequencelist, totle_time = TweenTools.ShowCoinIconFlyTween(self.coinItem, self.coinItemList, from, to, num, nil, goods_count)
			table.insert(self.coinSequencList, sequencelist)
		elseif droptype == ItemDropView.DropType.Gem then
			self.gemSequencList = self.gemSequencList or {}
			local sequencelist, totle_time = TweenTools.ShowCoinIconFlyTween(self.gemItem, self.gemItemList, from, to, num, nil)
			table.insert(self.gemSequencList, sequencelist)
		end
	end
end

--{{222,1}, ...} 过滤英雄图标
function ItemDropView:FilterHeroTyprGoods(goodsList)
	local BagProxy = require "Modules.Bag.BagProxy"
	local BagDef = require "Modules.Bag.BagDef"
	local goodsInfos = {}
	for i,v in ipairs(goodsList) do
		local goodscfg = BagProxy.Instance:GetGoodsCfgById(v[1])
		if goodscfg.subtype ~= BagDef.SubType.Elite_Hero_Card and goodscfg.subtype ~=  BagDef.SubType.Rare_Hero_Card then
			table.insert(goodsInfos, v)
		end
	end
	return goodsInfos
end

--飞物品图标
function ItemDropView:UpdateGoodsInfo(goodsDatalist, frompos, topos, func)
	frompos = frompos or self.go.transform.position
	goodsDatalist = self:FilterHeroTyprGoods(goodsDatalist)
	if #goodsDatalist == 0 then
		return
	end
	--nil获去主界面的位置
	local btnObj
	if topos == nil then
		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MainView)
		if view and view:IsOpen() then
			local state = view.mainSystemPanel:GetState()
			if state == 1 then
				view.mainSystemPanel:ShowBar(0) --展开列表
				--展开有位移动画，获取位置不正确，延迟获取
				self:AddTimer(function()
					topos, btnObj = view.mainSystemPanel:GetBagItemPos()
					self:Tween(btnObj, goodsDatalist, frompos, topos, btnObj)
				end, 0.3, 1)
			else
				topos, btnObj = view.mainSystemPanel:GetBagItemPos()
				self:Tween(btnObj, goodsDatalist, frompos, topos, btnObj)
			end
		end
	end	
end

function ItemDropView:ClearAwardGoodsSeq()
	if self.awardGoodsSequence then
		self.awardGoodsSequence:Kill()
		self.awardGoodsSequence = nil
	end
end

function ItemDropView:UpdateAwardGoodsInfo(datalist, frompos, topos, func, bNotChangeFromPos)
	frompos = frompos or self.go.transform.position
	datalist = self:FilterHeroTyprGoods(datalist)
	if #datalist == 0 then
		return
	end
	self.bagSpriteObj.gameObject:SetActive(true)
	local BagProxy = require "Modules.Bag.BagProxy"
	local count=BagProxy.Instance:GetBagRootViewRedCount()
	if count > 0 then
		self.bagRedObj.gameObject:SetActive(true)
	else
		self.bagRedObj.gameObject:SetActive(false) 
	end
	
	GameUIUtil.SetGroupAlpha(self.bagSpriteObj.gameObject, 0)
	GameUIUtil.SetGroupAlphaInTime(self.bagSpriteObj.gameObject, 1, 0.5)
	local func=function (  )
		self:ClearAwardGoodsSeq()
		local sequence = DOTween.Sequence()
		local tween1 = self.bagSpriteObj.transform:DOScale(Vector3.New(1.5 ,1.5 ,1.5), 0.2)
		local tween2 = self.bagSpriteObj.transform:DOScale(Vector3.one, 0.2)
		tween1:SetEase(Ease.InBack)
		tween2:SetEase(Ease.OutBack)
		
		sequence:Append(tween1)
		sequence:Append(tween2)
		sequence:AppendCallback(function ()
			GameUIUtil.SetGroupAlphaInTime(self.bagSpriteObj.gameObject, 0, 0.5)
			--self.bagSpriteObj.gameObject:SetActive(false)
		end)
		self.awardGoodsSequence = sequence
	end

	self:Tween(self.bagBtnObj, datalist, frompos, self.bagBtnObj.transform.position, self.bagSpriteObj, func, bNotChangeFromPos)
end

function ItemDropView:Tween(btnObj, goodsDatalist, frompos, topos, targetObj,callback, bNotChangeFromPos)
	if btnObj then
		self:SetDepth(btnObj, 1000, true)
		self:SetModelDepth(btnObj, 2000)
		self._canvas = self:TryGetComponent(btnObj, "Canvas")
		self._btn = self:GetComponent(btnObj, "CButton")
		if self._btn then
			self._btn.enabled = false
		end
	else
		self._canvas = nil
		self._btn = nil
	end

	self:ClearTargetObjTween()

	local func = function(idx, totalcount)
		if idx == totalcount then
			if idx == 1 then
				self.targetBagSequence = self:TargetTweenScale(targetObj, Vector3.New(1,1,1), Vector3.New(1.5,1.5,1.5), 0.15, nil, function()
					if btnObj and self._canvas then
						self._canvas.overrideSorting = false
					end	
					if btnObj and self._btn then 
						self._btn.enabled = true
					end
					if callback then
						callback()
					end
					self:ClearTargetObjTween()
					targetObj.transform.localScale = Vector3.New(1,1,1)
				end, false)
			else
				self:ClearTargetObjTween()
				if btnObj and self._canvas then
					self._canvas.overrideSorting = false
				end	
				if btnObj and self._btn then 
					self._btn.enabled = true
				end
				if callback then
					callback()
				end
				targetObj.transform.localScale = Vector3.New(1,1,1)
			end
		elseif idx == 1 then
			self.targetBagSequence = self:TargetTweenScale(targetObj, Vector3.New(1,1,1), Vector3.New(1.5,1.5,1.5), 0.1, 0.05, nil, true)
		end

		--物品飞背包音效
		if idx == totalcount then
			if idx == 1 then
				self:PlayGetGoodsSound()
			end
		else
			self:PlayGetGoodsSound()
		end
	end
	self.goodsSequencList = self.goodsSequencList or {}
	if bNotChangeFromPos then
		--坐标不需要再转换
		TweenTools.ShowGetGoodsIconFlyTween2(self.goodsItem, goodsDatalist, self.goodsList, self.goodsClassList, frompos, topos, func, self.goodsSequencList)
	else
		TweenTools.ShowGetGoodsIconFlyTween(self.goodsItem, goodsDatalist, self.goodsList, self.goodsClassList, frompos, topos, func, self.goodsSequencList)
	end
end

function ItemDropView:ClearTargetObjTween()
	if self.targetBagSequence then
		self.targetBagSequence:Kill()
		self.targetBagSequence = nil
	end
end

function ItemDropView:ClearTargetExpTween()
	if self.expSeq then
		self.expSeq:Kill()
		self.expSeq = nil
	end
end

function ItemDropView:ClearTargetGemTween()
	if self.gemSeq then
		self.gemSeq:Kill()
		self.gemSeq = nil
	end
end

function ItemDropView:ClearTargetCoinTween()
	if self.coinSeq then
		self.coinSeq:Kill()
		self.coinSeq = nil
	end
end

function ItemDropView:TargetTweenScale(targetObj, fromVector, toVector, time, interval, callback, isLoop)
	targetObj.transform.localScale = fromVector

	local targetTween1 = targetObj.transform:DOScale(toVector, time)
	targetTween1:SetEase(Ease.InBack)
	local targetTween2 = targetObj.transform:DOScale(fromVector, time)
	targetTween2:SetEase(Ease.OutBack)
	local targetBagSequence = DOTween.Sequence()
	targetBagSequence:Append(targetTween1)
	targetBagSequence:Append(targetTween2)
	if callback then
		targetBagSequence:AppendCallback(function()
			callback()
		end)
	end
	if interval and isLoop then
		targetBagSequence:AppendInterval(interval)
		targetBagSequence:SetLoops(-1)
	end
	return targetBagSequence
end

--物品飞背包音效
function ItemDropView:PlayGetGoodsSound()
	local AudioManager = require "Common.Mgr.Audio.AudioManager"
	AudioManager.PlaySoundByKey("common_item_get")
end

return ItemDropView