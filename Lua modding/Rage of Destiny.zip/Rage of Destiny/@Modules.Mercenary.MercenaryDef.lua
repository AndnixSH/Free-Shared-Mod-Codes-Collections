local MercenaryDef = {}

MercenaryDef.Notify = {
	UpdateMercenaryInfo = "UpdateMercenaryInfo",
	UpdateApplyHeroInfo = "UpdateApplyHeroInfo",
	UpdateOtherApplyInfo = "UpdateOtherApplyInfo",
	UpdateLendHeroInfo = "UpdateLendHeroInfo",

	UpdateApplyOperateInfo = "UpdateApplyOperateInfo", --申请
	UpdateApplyUnOperateInfo = "UpdateApplyUnOperateInfo", --撤回申请

	UpdateRefuseApplyInfo = "UpdateRefuseApplyInfo", --拒绝
	UpdateAgreeApplyInfo = "UpdateAgreeApplyInfo",  --同意

	UpdateDealAllApplyInfo = "UpdateDealAllApplyInfo", --一键拒绝一键同意
	UpdateHireHeroActivityInfo = "UpdateHireHeroActivityInfo",

	UpdateHireListInfo = "UpdateHireListInfo" --退还雇佣更新
}

MercenaryDef.Config = {
	Apply_Max_count = 5, --最大申请次数
	Intimacy_Max_Count = 50, --本周最大亲密度
	HireFriendHeroMaxCount = 1, --只能上一个好友雇佣英雄战斗
}

MercenaryDef.LanguageKey = {
	MercenaryKey1 = "MercenaryKey1",
	MercenaryKey2 = "MercenaryKey2",
	MercenaryKey3 = "MercenaryKey3",
	MercenaryKey4 = "MercenaryKey4",
	MercenaryKey5 = "MercenaryKey5",
	MercenaryKey6 = "MercenaryKey6",	
	MercenaryKey7 = "MercenaryKey7",	
	MercenaryKey8 = "MercenaryKey8",
}

MercenaryDef.ActivityUseHireHeroCount = 
{
	[ACTIVITYID.MAINLINE] = 1,
	[ACTIVITYID.TOWER] = 1,

}

return MercenaryDef