local SelectTweenPanel = SelectTweenPanel or BaseClass(GameObjFactor)
function SelectTweenPanel:__init(go)
	self.go = go
	self:Load(go)	
end
function SelectTweenPanel:Load(obj)
	self.toprect = self:GetChildComponent(obj, "TopPanel", "RectTransform")
	self.toprectPosition = self.toprect.anchoredPosition

	self.leftrect = self:GetChildComponent(obj, "Skill_left", "RectTransform")
	self.leftrectPosition = self.leftrect.anchoredPosition	

	self.rightrect = self:GetChildComponent(obj, "Skill_right", "RectTransform")
	self.rightrectPosition = self.rightrect.anchoredPosition

	self.botrect = self:GetChildComponent(obj, "bottom", "RectTransform")
	self.botrectPosition = self.botrect.anchoredPosition

	self.bossrect = self:GetChildComponent(obj, "BossInfo", "RectTransform")
	self.bossrectPosition = self.bossrect.anchoredPosition	
end
function SelectTweenPanel:Open()
	self:StartOpenTween()
end	

function SelectTweenPanel:Close()
end	

function SelectTweenPanel:Destroy()
end


function SelectTweenPanel:StartOpenTween()
	self.toprect.anchoredPosition = Vector2.New(self.toprectPosition.x, self.toprectPosition.y + 100)
	local tween1 = self.toprect:DOAnchorPosY(self.toprectPosition.y - 10, 0.2)
	local tween2 = self.toprect:DOAnchorPosY(self.toprectPosition.y, 0.2)

	local sequence = DOTween.Sequence()
	sequence:Append(tween1)
	sequence:Append(tween2)
	self.topsequence = sequence

	self.rightrect.anchoredPosition = Vector2.New(self.rightrectPosition.x + 100, self.rightrectPosition.y)
	local tween1 = self.rightrect:DOAnchorPosX(self.rightrectPosition.x - 10, 0.2)
	local tween2 = self.rightrect:DOAnchorPosX(self.rightrectPosition.x, 0.2)

	local sequence = DOTween.Sequence()
	sequence:Append(tween1)
	sequence:Append(tween2)
	self.rightsequence = sequence

	self.leftrect.anchoredPosition = Vector2.New(self.leftrectPosition.x - 100, self.leftrectPosition.y)
	local tween1 = self.leftrect:DOAnchorPosX(self.leftrectPosition.x + 10, 0.2)
	local tween2 = self.leftrect:DOAnchorPosX(self.leftrectPosition.x, 0.2)

	local sequence = DOTween.Sequence()
	sequence:Append(tween1)
	sequence:Append(tween2)
	self.leftsequence = sequence

	self.botrect.anchoredPosition = Vector2.New(self.botrectPosition.x, self.botrectPosition.y - 100)
	local tween1 = self.botrect:DOAnchorPosY(self.botrectPosition.y + 10, 0.2)
	local tween2 = self.botrect:DOAnchorPosY(self.botrectPosition.y, 0.2)

	local sequence = DOTween.Sequence()
	sequence:Append(tween1)
	sequence:Append(tween2)
	self.botsequence = sequence	

	self.bossrect.anchoredPosition = Vector2.New(self.bossrectPosition.x + 100, self.bossrectPosition.y)
	local tween1 = self.bossrect:DOAnchorPosX(self.bossrectPosition.x - 10, 0.2)
	local tween2 = self.bossrect:DOAnchorPosX(self.bossrectPosition.x, 0.2)

	local sequence = DOTween.Sequence()
	sequence:Append(tween1)
	sequence:Append(tween2)
	self.bosssequence = sequence	
end	

return SelectTweenPanel
