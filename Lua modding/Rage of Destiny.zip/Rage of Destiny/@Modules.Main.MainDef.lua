local MainDef = {}
MainDef.NotifyDef =
{
	Main_Tween_bar = "Main_Tween_bar",
	ReShow = "ReShow",
	UpdateRedDot = "UpdateRedDot",
	HideScene = "HideScene",
	HideView = "HideView",
	OpenFullScreenWidget = "OpenFullScreenWidget",
}

MainDef.MainBarState = 
{
	Show = 0,
	Hide = 1,
}

MainDef.MainRedDotType =
{
	FreeFastReward =1, --免费快速挂机奖励
	Hero = 2, --英雄
	DrawCard = 3, --抽卡
	Bag = 4, --背包
	Task = 5, --任务
	Mail=6, --邮件
	Friend = 7, --好友
}

--主界面左侧的类型
MainDef.LeftActivityType =
{
	Mall = 1, --商城
	FirstCharge = 2, --首充
	Sail = 3, --起航
	DailySupply = 4, --每日补给
}

return MainDef