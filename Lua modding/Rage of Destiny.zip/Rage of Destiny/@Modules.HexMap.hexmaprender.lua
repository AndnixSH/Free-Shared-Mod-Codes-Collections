local simple_anchor = require "Battle.render.anchor.simple_anchor"
local map_effect_model = require "Modules.HexMap.map_effect_model"
local follow_view = require "Modules.HexMap.follow_view"
local build_view = require "Modules.HexMap.build_view"
local Timer =  require "Common.Util.Timer"
local data_cell_view = ConfigManager.GetConfig("data_cell_view")
local HexMapUI = require "Modules.HexMap.HexMapUI"
local render_camera = require "Battle.render.camera.render_camera"
local AudioManager = require "Common.Mgr.Audio.AudioManager"

local hexmaprender = {}
local viewcmd = {}
local viewlist = {}
local viewuidgen = 0
local delay_list = {}
local context = {}

local function delay(duration, cb)
    local timer = Timer.New(cb, duration, 1)
    timer:Start()
    return timer
end

local function start_view(viewtb)

    local cmd = viewcmd[viewtb.type]
    if cmd then
        -- print("start_view", viewtb.id, viewtb.type)
        local handler = cmd.start(viewtb)
        viewtb.handler = handler

        if viewtb.duration and viewtb.duration > 0 then
            viewtb.timer = delay(viewtb.duration, function() hexmaprender.stop_view(viewtb.uid) end)
        end
    else
        print("错误的cell_view类型", viewtb.type)
    end
end

local function stop_view(viewtb, isdestroy)
    if viewtb.timer then
        viewtb.timer:Stop()
        viewtb.timer = nil
    end

    local cmd = viewcmd[viewtb.type]
    if cmd.stop then
        cmd.stop(viewtb)
    end
    viewtb.handler = nil

    if viewtb.cb and not isdestroy then
        viewtb.cb()
    end
end

local function gethexmap()
    return require "Modules.HexMap.hexmap"
end

function hexmaprender.start_view(viewid, args)
    local viewconf = data_cell_view[viewid]
    if viewconf then
        local viewtb = {}
        for k, v in pairs(viewconf) do
            viewtb[k] = v
        end
        if args then
            for k, v in pairs(args) do
                viewtb[k] = v
            end
        end
        if viewconf.position then
            viewtb.position = Vector3.New(table.unpack(viewconf.position))
        end
        return hexmaprender.start_view_args(viewtb)
    else
        print("data_cell_view找不到配置", viewid)
    end
end

function hexmaprender.start_view_args(viewtb)
    viewuidgen = viewuidgen + 1
    viewtb.uid = viewuidgen
    viewlist[viewuidgen] = viewtb

    if viewtb.delay and viewtb.delay > 0 then
        local timer = delay(viewtb.delay, function() start_view(viewtb) end)
        viewtb.timer = timer
    else
        start_view(viewtb)
    end

    return viewuidgen
end

function hexmaprender.stop_view(viewuid)
    local viewtb = viewlist[viewuid]
    if viewtb then
        stop_view(viewtb)
    end
    viewlist[viewuid] = nil
end



function hexmaprender.destroy()
    for key, viewtb in pairs(viewlist) do
        if viewtb then
            stop_view(viewtb, true)
        end
    end
    viewlist = {}
    viewuidgen = 0
    for i, timer in ipairs(delay_list) do
        timer:Stop()
    end
    delay_list = {}
    context = {}
end

function hexmaprender.delay(duration, func)
    local timer = delay(duration, func)
    table.insert(delay_list, timer)
end

function hexmaprender.cellcmd(cell, cmd, ...)

    local hexmapview = LuaLayout.Instance:GetWidget(UIWidgetNameDef.HexMapView)
    if hexmapview then
        local cellview = hexmapview:GetCellView(cell.id)
        if cellview and cellview.cmd and cellview.cmd[cmd] then
            return cellview.cmd[cmd](cellview, ...)
        else
            print(string.format("在cellview%s上找不到cmd%s", cell.id, cmd))
        end
    end
end

function hexmaprender.cmdfollower(cmd, ...)
    local hexmapview = LuaLayout.Instance:GetWidget(UIWidgetNameDef.HexMapView)
    if hexmapview then
        local follower_view = hexmapview:GetFollowerView()
        if follower_view and follower_view.cmd and follower_view.cmd[cmd] then
            return follower_view.cmd[cmd](follower_view, ...)
        else
            print(string.format("在follower_view上找不到cmd%s", cmd))
        end
    end
    
end

function hexmaprender.cmdstart(type, viewtb)
    local cmd = viewcmd[type]
    if cmd and cmd.start then
        cmd.start(viewtb)
    end
end

function hexmaprender.cmdstop(type, viewtb)
    local cmd = viewcmd[type]
    if cmd and cmd.stop then
        cmd.stop(viewtb)
    end
end

viewcmd = {
    [0] = { -- 关闭
        start = function (viewtb)
            for _, viewid in ipairs(viewtb.args) do
                for key, viewtb in pairs(viewlist) do
                    if viewtb and viewtb.id == viewid then
                        hexmaprender.stop_view(viewtb.uid)
                    end
                end
            end
            
        end
    },
    [1] = { -- 开启
        start = function(viewtb)
            for _, viewid in ipairs(viewtb.args) do
                hexmaprender.start_view(viewid)
            end
        end
    },
    [11] = { -- 特效
        start = function (viewtb)
            local position = viewtb.position
            local r_x, r_y, r_z = 0, 0, 0
            local rotation = viewtb.rotation
            if rotation then
                r_x = rotation.x r_y = rotation.y r_z = rotation.z
            end
            local anchor = simple_anchor.New(position.x, position.y, position.z, r_x, r_y, r_z)
            local model = map_effect_model.New(anchor, viewtb.prefab_id)
            if viewtb.active_name then
                model.prop.active = viewtb.active_name
            end
            return model
        end,
        stop = function (viewtb)
            viewtb.handler:release()
            viewtb.handler:DeleteMe()
        end
    },
    [12] = { -- 音效
        start = function (viewtb)
            AudioManager.PlaySoundByKey(viewtb.prefab_id)
        end,
        stop = function (viewtb)
            AudioManager.StopSoundByKey(viewtb.prefab_id)
        end,
    },
    [13] = { -- 镜头移动
        start = function (viewtb)
			gethexmap():setfollowing(true)
			
            local position = viewtb.position
            local curpos = render_camera.get_story_line_target_position()

            local xlen = curpos.x - position.x
            local ylen = curpos.z - position.z

            local dis = math.sqrt(xlen * xlen + ylen * ylen)

            if viewtb.speed then
                viewtb.duration = dis / viewtb.speed
            end

            if viewtb.duration then
                viewtb.speed = dis / viewtb.duration
            end

            local hexmapcamera = require "Modules.HexMap.hexmapcamera"
            hexmapcamera.set_target_position(position, viewtb.speed)
        end,

        stop = function (viewtb)
			gethexmap():setfollowing(false)
        end,
    },
    [14] = { -- 引导
        start = function (viewtb)

            local guideconf = viewtb.args
            if guideconf and #guideconf > 0 then

                --print("guide", table.dump(guideconf))
                hexmaprender.cmdfollower("set_moving", false)
                local NPCDialogueProxy=require "Modules.NPCDialogue.NPCDialogueProxy"
                local tab={}
                local showred = false
                for i,v in ipairs(guideconf) do
                    table.insert(tab,v)
                    local guidecfg = NPCDialogueProxy.Instance:GetCfgById(v[3])
                    if guidecfg and guidecfg.data then
                        showred = true
                    end
                end
                local func = function ()
                    hexmaprender.cmdfollower("set_moving", true)
                    hexmaprender.stop_view(viewtb.uid)
                    
                    local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
                    local RedPointDef = require "Modules.RedPoint.RedPointDef"
                    RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.StoryLineLog,showred and 1 or 0)
                end
                HexMapUI.OpenWidget(UIWidgetNameDef.HexNPCDialogueView,{ guideConfig = tab,func = func})
            end
        end,
    },
    [15] = { -- 镜头抖动
        start = function (viewtb)
            render_camera.set_shake_camera(viewtb.args[1])
        end
    },
    [16] = { -- 子弹移动
        start = function (viewtb)

            gethexmap():setfollowing(true)

            local frompos, topos = viewtb.fromcell.top_position, viewtb.tocell.top_position
            topos = Vector3.New(topos.x, frompos.y, topos.z)
            local args = { prefab_id = viewtb.prefab_id, asset_type = viewtb.assettype or AssetType.EFFECT, position_list = { frompos, topos }, header = viewtb.header }
            local speed = viewtb.args and viewtb.args[1]
            local follow_view = follow_view.New(args)
            follow_view:set_follow_speed(speed)
            follow_view:move_follow_path(args.position_list, function () hexmaprender.stop_view(viewtb.uid) end, nil, viewtb.keepheader)
            return follow_view
        end,

        stop = function (viewtb)
            gethexmap():setfollowing(false)

            viewtb.handler:release()
            local reachviewlist = viewtb.args and viewtb.args[2]
            if reachviewlist then

                local viewset = {}
                for _, value in ipairs(reachviewlist) do
                    local type, list = table.unpack(value)
                    viewset[type] = list
                end

                local viewlist = nil
                if viewtb.tocell.build then
                    viewlist = viewset[viewtb.tocell.build.static.type]
                end

                viewlist = viewlist or viewset[0]
                if viewlist then
                    local args = { position = viewtb.tocell.top_position }
                    for _, viewid in ipairs(viewlist) do
                        hexmaprender.start_view(viewid, args)
                    end
                end
            end
            
        end
    },
    [17] = { -- 提示
        start = function (viewtb)
            local LanguageManager = require "Common.Mgr.Language.LanguageManager"
            local MsgTipsView = require "Modules.Common.Msg.MsgTipsView"
            local strcontent = LanguageManager.Instance:GetWord(viewtb.prefab_id, table.unpack(viewtb.wordargs or {}))
            MsgTipsView.ShowMsgTips(strcontent)
        end
    },
    [18] = {
        start = function (viewtb)
            if viewtb.at_cell then
                hexmaprender.cellcmd(viewtb.at_cell, "set_build_active", false)
            end
        end,

        stop = function (viewtb)
            if viewtb.at_cell then
                hexmaprender.cellcmd(viewtb.at_cell, "set_build_active", true)
            end
        end,
    },
    [20] = {
        start = function (viewtb)

            gethexmap():setfollowing(true)

            local frompos, topos = viewtb.fromcell.top_position, viewtb.tocell.top_position
            local speed = viewtb.speed or 2
            local args = { prefab_id = viewtb.prefab_id, position = frompos, header = viewtb.header }
            local follow_view = build_view.New(args)
            follow_view:move_to(topos, speed, function () hexmaprender.stop_view(viewtb.uid) end)
            return follow_view
        end,

        stop = function (viewtb)
            gethexmap():setfollowing(false)
            viewtb.handler:release()
        end
    },
}

return hexmaprender