local config = {}

function config:init(getter)
    self.getter = getter
    assert(getter)
    assert(type(getter) == "function")
end

function config:get(name, readonly)
    local table = self.getter(name)
    if table and readonly then
        local t = {}
        setmetatable(t, { __index = table })
        table = t;
    end
    return table
end

function config:dispose()
    self.getter = nil
end

return config