tsmath = {
    _seed = 64654541,
    _sin_map = {    [0] = 0,
                    [1] = 17, [2] = 34, [3] = 52, [4] = 69, [5] = 87, [6] = 104, [7] = 121, [8] = 139, [9] = 156, [10] = 173,
                    [11] = 190, [12] = 207, [13] = 224, [14] = 241, [15] = 258, [16] = 275, [17] = 292, [18] = 309, [19] = 325, [20] = 342,
                    [21] = 358, [22] = 374, [23] = 390, [24] = 406, [25] = 422, [26] = 438, [27] = 453, [28] = 469, [29] = 484, [30] = 499,
                    [31] = 515, [32] = 529, [33] = 544, [34] = 559, [35] = 573, [36] = 587, [37] = 601, [38] = 615, [39] = 629, [40] = 642,
                    [41] = 656, [42] = 669, [43] = 681, [44] = 694, [45] = 707, [46] = 719, [47] = 731, [48] = 743, [49] = 754, [50] = 766,
                    [51] = 777, [52] = 788, [53] = 798, [54] = 809, [55] = 819, [56] = 829, [57] = 838, [58] = 848, [59] = 857, [60] = 866,
                    [61] = 874, [62] = 882, [63] = 891, [64] = 898, [65] = 906, [66] = 913, [67] = 920, [68] = 927, [69] = 933, [70] = 939,
                    [71] = 945, [72] = 951, [73] = 956, [74] = 961, [75] = 965, [76] = 970, [77] = 974, [78] = 978, [79] = 981, [80] = 984,
                    [81] = 987, [82] = 990, [83] = 992, [84] = 994, [85] = 996, [86] = 997, [87] = 998, [88] = 999, [89] = 999, [90] = 1000,
    }
}

local _floor = math.floor

function tsmath.abs(x)
    return math.abs(x)
end

function tsmath.max(a, b)
    return a > b and a or b
end

function tsmath.min(a, b)
    return a < b and a or b
end

function tsmath.clamp(value, min, max)
    if value < min then
        value = min
    elseif value > max then
        value = max
    end
    return value
end

function tsmath.pow(a, b)
    for i = 1, b-1 do
        a = a * a
    end
    return a
end

function tsmath.rate(a, rate)
    return _floor(rate / 1000 * a)
end

function tsmath.floor(a)
    return _floor(a)
end

-- factor in [factor_from, factor_to] -> result in [from, to]
function tsmath.factor_lerp(from, to, factor, factor_from, factor_to)
    local r = from  + (to - from) * (factor - factor_from) / (factor_to - factor_from)
    r = _floor(r)
    if from > to then
        r = tsmath.clamp(r, to, from)
    else
        r = tsmath.clamp(r, from, to)
    end
    return r
end

function tsmath.seed(seed)
    tsrandom.seed(seed)
end

function tsmath.random(n, m)
    return tsrandom.range(n, m)
end

-- 返回1..n的随机数组
function tsmath.random_shuffle(n)
    return tsrandom.shuffle(n)
end

-- 从table t中随机选中n个
function tsmath.random_select(t, n)
    return tsrandom.select(t, n)
end

-- 是否满足概率 probability 0 - 1000
function tsmath.random_match(probability)
    return tsrandom.match(probability)
end

function tsmath.nmul(n1, n2)
    return _floor(n1 * n2 / 1000)
end

function tsmath.vmul(v, n)
    return (n / 1000) * v
end

function tsmath.ndiv(n1, n2)
    return _floor(n1 / n2 * 1000)
end

function tsmath.vdiv(v, n)
    return v / (n / 1000)
end

function tsmath.create_rect(center, header, headsize, othersize)
    return tsgeometry.create_rect(center, header, headsize, othersize)
end


function tsmath.create_normalrect(ld, size)
    return tsgeometry.create_normalrect(ld, size)
end

function tsmath.sin(angle)
    local deg = angle % 360
    local qua = math.modf(deg / 90)
    local deg = math.floor(math.fmod(deg, 90))
    --print(angle, qua, deg, "deg")
    if 0 == qua then
        return tsmath._sin_map[deg]
    elseif 1 == qua then
        return tsmath._sin_map[90 - deg]
    elseif 2 == qua then
        return -tsmath._sin_map[deg]
    elseif 3 == qua then
        return -tsmath._sin_map[90 - deg]
    end
    print("sin error")
end

function tsmath.cos(angle)
    return tsmath.sin(90 - angle)
end

function tsmath.asin(a)
    local left, right = 0, 90
    local n = _floor(math.abs(a))
    while left < right do
        local mid = _floor((left + right) / 2)
        if tsmath._sin_map[mid] == n then
            right = mid
            break
        elseif tsmath._sin_map[mid] < n then
            left = mid + 1
        else
            right = mid
        end
    end
    if a > 0 then
        return right
    else
        return -right
    end
end

function tsmath.acos(a)
    return 90 - tsmath.asin(a)
end

return tsmath