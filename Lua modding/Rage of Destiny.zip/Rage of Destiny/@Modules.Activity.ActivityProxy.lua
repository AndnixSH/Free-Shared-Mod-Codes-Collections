
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local ActivityDef = require "Modules.Activity.ActivityDef"
local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
local RedPointDef = require "Modules.RedPoint.RedPointDef"
local CampaignProxy = require "Modules.Campaign.CampaignProxy"
local HeroProxy = require "Modules.Hero.HeroProxy"
local ModuleManager = require "Common.Mgr.UI.ModuleManager"
local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
local ActivityProxy = ActivityProxy or BaseClass(BaseProxy)
function ActivityProxy:__init()
    ActivityProxy.Instance = self
    self:AddProto(62000, self.On62000) --七日登录
    self:AddProto(62001, self.On62001)

    self:AddProto(62002, self.On62002)--新兵特训
    self:AddProto(62003, self.On62003)--新兵特训

    self:AddProto(62004, self.On62004)--英雄集结
    self:AddProto(62005, self.On62005)--英雄集结

    self:AddProto(62006, self.On62006)--冲关奖励

    self:AddProto(62007, self.On62007)--精灵王降临
    self:AddProto(62008, self.On62008)--精灵王降临

    self:AddProto(62009, self.On62009)--分享有礼
    self:AddProto(62010, self.On62010)--分享次数

    self:AddProto(62011, self.On62011)--通用精灵王
    self:AddProto(62012, self.On62012)--通用精灵王

    self:AddProto(62013, self.On62013)--女王狂欢祭
    self:AddProto(62014, self.On62014)--女王狂欢祭
    self.data = {}
    self.data.seven_login = {}
    self.data.new_player = {}
    self.data.hero_gathering = {}
    self.data.stage_clear = {}
    self.data.expire_time = {}
    self.data.hatharalcoming = {}
    self.data.herocoming = {}
    self.data.share = {}
    self.data.happymonth = {}
    local config = self:GetNewPlayerTrainConfig()
    local day = 1
    for _ ,v in pairs(config) do
        if v and v.day then
            if v.day > day then
                day = v.day
            end
        end
    end
    self.new_player_max_days = day

    self.new_player_redpointid = {RedPointDef.Id.New_Player_Train_Day1,RedPointDef.Id.New_Player_Train_Day2,
    RedPointDef.Id.New_Player_Train_Day3,RedPointDef.Id.New_Player_Train_Day4,RedPointDef.Id.New_Player_Train_Day5}
    self.ShareMaxTimes = 2  
end

function ActivityProxy:__delete()
    ActivityProxy.Instance = nil
end

function ActivityProxy:CheckActivityFinsh(type)
    local finish = false
    if self.data.expire_state then
        for _ , v in ipairs(self.data.expire_state) do
            if v[1] == type then
                if v[2] == 1 then
                    finish = true --0 没有过期，1过期
                end
                break
            end
        end
    end
    -- elseif type == ActivityDef.toggleType.New_Player then
    --     finish = self.data.expire_state[] --self:CheckNewPlayerFinish()
    -- elseif type == ActivityDef.toggleType.HeroGathering then
    --     finish =  --self:CheckHeroGatheringFinish()
    -- end
    return finish
end

function ActivityProxy:UpdateExpireState(type,state)
    --0 没有过期，1过期
    if self.data.expire_state and state then
        for _ , v in ipairs(self.data.expire_state) do
            if v[1] == type then
                v[2] = state
                break
            end
        end
    end
end

function ActivityProxy:HasFinishSevenLogin()
    local config =self:GetSevenLoginConfig()
    local max_days = config and #config or 0 
    if self.data and self.data.seven_login and self.data.seven_login.has_get_reward_days then
        --local count =#config
        if max_days == #self.data.seven_login.has_get_reward_days then
            return true
        end
        -- for _, v in ipairs(self.data.seven_login.has_get_reward_days) do
        --     if v == count then
        --         return true
        --     end
        -- end
    end
end

function ActivityProxy:GetOneRewardState(day)
    if self.data and self.data.seven_login then
        if self.data.seven_login.has_get_reward_days and self.data.seven_login.un_get_reward_days then
            for _, v in ipairs(self.data.seven_login.has_get_reward_days) do
                if v == day then
                    return ActivityDef.Reward_State.HasGet
                end
            end
            for _, v in ipairs(self.data.seven_login.un_get_reward_days) do
                if v == day then
                    return ActivityDef.Reward_State.UnGet
                end
            end
        end
    end
    return ActivityDef.Reward_State.CannotGet
end

function ActivityProxy:GetNewPlayerStageConfig()
    local config = ConfigManager.GetConfig("data_activity_newbiestage")
    return config
end

function ActivityProxy:GetNewPlayerTrainConfig()
    local config = ConfigManager.GetConfig("data_activity_newbietask")
    return config
end

function ActivityProxy:GetSevenLoginConfig()
    local config = ConfigManager.GetConfig("data_activity_7days")
    return config
end

function ActivityProxy:GetHeroGatheringConfig()
    local config = ConfigManager.GetConfig("data_activity_mass")
    return config
end

function ActivityProxy:GetStageClearChargeConfig()
    local config = ConfigManager.GetConfig("data_activity_mainline")
    return config
end

function ActivityProxy:GetHatharalComingConfig()
    local config = ConfigManager.GetConfig("data_activity_elfking")
    return config
end

function ActivityProxy:GetHeroComingConfig()
    local config = ConfigManager.GetConfig("data_activity_pizza")
    return config
end

function ActivityProxy:GetHappyMonthConfig()
    local config = ConfigManager.GetConfig("data_activity_happymonth")
    return config
end

function ActivityProxy:GetActivityTimeConfig()
    local config = ConfigManager.GetConfig("data_activity_time")
    return config
end

function ActivityProxy:GetSevenLoginHero()
    local config = ConfigManager.GetConfig("data_common")
    local cfg = config.activity_seven_login_hero
    if config and  cfg then
        
        return cfg.value1
    end
    return config
end

function ActivityProxy:GetShareAwardHero()
    local config = ConfigManager.GetConfig("data_common")
    local cfg = config.activity_share_hero
    if config and  cfg then
        
        return cfg.value1
    end
    return config
end

function ActivityProxy:GetHeroComingHero(id)
    local config = ConfigManager.GetConfig("data_common")
    local cfg = config.activity_herocoming_hero
    if config and  cfg then
        local data = cfg.value1 or {}
        for _ , v in ipairs(data) do
            if v then
                if v[1] == id then
                    return v[2]
                end
            end
        end
        return nil
    end
    return config
end

function ActivityProxy:GetNewsConfig()
    --活动一览
    local config = ConfigManager.GetConfig("data_activityover")
    return config
end

function ActivityProxy:GetActivityOverList()
    local config = self:GetNewsConfig()
    local list = {}
    if config then
        for _ , v in pairs(config) do
            if v then
                local item = {}
                item.id = v.id
                item.name = LanguageManager.Instance:GetWord(v.name)
                item.type = v.type
                item.res = v.res
                item.titleSp = v.titleSp
                item.sort = v.sort
                item.panel = v.panel
                item.activity = v.activity
                item.switch = v.switch
                table.insert(list,item)
            end
            
        end
    end
    table.sort( list, function (a , b)
        return a.sort < b.sort
    end)
    return list
end

function ActivityProxy:IsHeroComingHero(id)
    local cfg = ActivityDef.HeroComingId
    for _ , v in ipairs(cfg) do
        if v then
            if v == id then
                return true
            end
        end
    end
    return false
end

function ActivityProxy:GetFirstCannotGetDay()
    local days = {}
    if self.data and self.data.seven_login then
        if self.data.seven_login.has_get_reward_days and self.data.seven_login.un_get_reward_days then
            for k, v in ipairs(self.data.seven_login.has_get_reward_days) do
                table.insert(days,v)
            end
            for _, v in ipairs(self.data.seven_login.un_get_reward_days) do
                table.insert(days,v)
            end
            table.sort( days, function ( a,b )
                return a < b
            end )
        end
    end
    local first_cannot_get_day = #days == 0 and 1 or (days[#days]+1)
    return first_cannot_get_day
end

function ActivityProxy:GetSevenRewards()
    local rewards_list = {}
    local first_cannot_get_day = self:GetFirstCannotGetDay()
    local config = self:GetSevenLoginConfig()
    if config then
        for _ ,v in ipairs(config) do
            if v then
                local item = {}
                item.id = v.id or 0
                item.goods_id = v.goods_id or {}
                item.state = self:GetOneRewardState(v.id)
                item.first_cannot_get_day = first_cannot_get_day
                item.redpointparentid = RedPointDef.Id.Seven_Login
                item.type = 1 --开服七日登录
                item.activity_id = ActivityDef.toggleType.Seven_Login
                table.insert(rewards_list,item)
            end
        end
    end
    table.sort( rewards_list, function ( a,b )

        if a.state == b.state then
            return a.id < b.id
        else
            return a.state < b.state
        end
    end )
    return rewards_list
end

function ActivityProxy:Send62000()
    self:SendMessage(62000)
 end
 
 function ActivityProxy:On62000(decoder)
     local has_get_reward_days = decoder:DecodeList("I1")
     local un_get_reward_days = decoder:DecodeList("I1")
     local expire_state = decoder:DecodeList("I1I1",true)
     table.sort( has_get_reward_days, function ( a,b )
         return a < b
     end )
     table.sort( un_get_reward_days, function ( a,b )
        return a < b
    end )
     self.data.seven_login.has_get_reward_days = has_get_reward_days
     self.data.seven_login.un_get_reward_days = un_get_reward_days
     self.data.expire_state = expire_state --0 没有过期，1过期
     self.data.expire_time[ActivityDef.toggleType.Seven_Login] = 0
     self:UpdateRedDot()
     if expire_state and expire_state[ActivityDef.toggleType.Share] == 1 then
        self:ActivityEnd(ActivityDef.toggleType.Share)
     end
     self:ToNotify(self.data,ActivityDef.NotifyDef.UpdateSevenLogin,{})
 end

 function ActivityProxy:UpdateRedDot()
    
    local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.Activity_Seven_Login,false)
    if bopen then
        if self.data and self.data.seven_login and self.data.seven_login.un_get_reward_days then
            local count = #self.data.seven_login.un_get_reward_days
            for k, v in ipairs(self.data.seven_login.has_get_reward_days) do
                RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.Seven_Login,tostring(v),0)
            end
            for _, v in ipairs(self.data.seven_login.un_get_reward_days) do
                RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.Seven_Login,tostring(v),1)
            end
            
        end
    end
 end

 --领取奖励
function ActivityProxy:Send62001(day)

    local finish = self:CheckActivityFinsh(ActivityDef.toggleType.Seven_Login)
    if finish then
        return
    end
    local encoder = NetEncoder.New()
    encoder:Encode("I1",day)
    self:SendMessage(62001,encoder)
end

function ActivityProxy:On62001(decoder)
    local result,day = decoder:Decode("I1I1")
    if result == 0 then
        local isnewhero = decoder:Decode("I1")
        local config = self:GetSevenLoginConfig()
        if config and config[day] then
            local rewards =config[day].goods_id or {}
            local rewardlist={}
            for _, v in ipairs(rewards) do
                if v then
                    local item={}
                    item.goodsid = v[1]
                    item.goodsnum = v[2]
                    table.insert(rewardlist,item)
                end
            end
            
            GameLogicTools.ShowGetItemView(rewardlist,1,function (  )
                if isnewhero == 1 then
                    GameLogicTools.ShouldShowNewHeroTipsView(rewards)
                    for _ , v in ipairs(rewards) do
                        if v then
                            if v[1] == ActivityDef.Seven_LoginIn_Hero[1] or ActivityDef.Seven_LoginIn_Hero[2] == v[1] then
                                local BagProxy = require "Modules.Bag.BagProxy"
                                local goodscfg = BagProxy.Instance:GetGoodsCfgById(v[1])
                                local roleid = goodscfg.value[1]
                                HeroProxy.Instance:UpdateRoleIdList(roleid)
                            end
                        end
                    end
                end
                
            end)
        end
        for k , v in ipairs(self.data.seven_login.un_get_reward_days) do
            if v and v == day then
                table.remove(self.data.seven_login.un_get_reward_days,k)
                break
            end
        end
        table.insert(self.data.seven_login.has_get_reward_days,day)
        self:UpdateRedDot()
        local max_days =config and #config or 0 
        if #self.data.seven_login.has_get_reward_days == max_days then
            self:UpdateExpireState(ActivityDef.toggleType.Seven_Login,1)
            LuaLayout.Instance:CloseWidget(UIWidgetNameDef.SevenDaysCheckinView)
            LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ActivityRootView)
            self:ActivityEnd(ActivityDef.toggleType.Seven_Login)
        else
            self:ToNotify(self.data,ActivityDef.NotifyDef.Update_Reward_State,{day = day})
        end
        
    else
        GameLogicTools.ShowErrorCode(62001,result)
    end
end

function ActivityProxy:ActivityEnd(id)
    local activeCfg = ModuleManager.GetActivityConfig()
    local index = 0
    for _ , v in ipairs(activeCfg) do
        local parama = v.parama
        if parama and parama[1] and parama[2]then
            if parama[1] == AppFacade.Activity then
                if parama[2] == id then
                    index = v.index
                    break
                end
            end
        end
    end
    self:ToNotify(self.data,ActivityDef.NotifyDef.ActivityEnd,{index = index})
end

function ActivityProxy:UpdateTitlteName(name)
    
    self:ToNotify(self.data,ActivityDef.NotifyDef.UpdateTitleName,name)
end

function ActivityProxy:Send62002()
    local finish = self:CheckActivityFinsh(ActivityDef.toggleType.New_Player)
    if finish then
        self:UpdateNewPlayerRedDot()
        return
    end
    self:SendMessage(62002)
 end
 
 function ActivityProxy:On62002(decoder)
    local active_day ,count ,has_get_new_player_points ,endtime = decoder:Decode("I1I1I1I4")
    local new_player_train_curtask = {}
    for k = 1 , count do
        local task = decoder:DecodeList("I2I2",true)
        table.insert(new_player_train_curtask,task)
    end
    local has_get_new_player_train_stage_reward = decoder:DecodeList("I1")
    self.data.new_player.active_day = active_day 
    self.data.new_player.new_player_train_curtask = new_player_train_curtask 
    self.data.new_player.has_get_new_player_train_stage_reward = has_get_new_player_train_stage_reward
    --self.data.new_player.endtime = endtime
    self.data.expire_time[ActivityDef.toggleType.New_Player] = endtime
    self.data.new_player.has_get_new_player_points = has_get_new_player_points
    self:ToNotify(self.data,ActivityDef.NotifyDef.UpdateNewPlayerInfo,{endtime = endtime})
    self:UpdateNewPlayerRedDot()
 end

 function ActivityProxy:CheckActivityExpire(type)
    if self.data.expire_time  then
        local endtime = self.data.expire_time[type]
        if endtime == 0 or not endtime then
            return false
        else
            local difftime = os.difftime(endtime,RoleInfoModel.servertime)
            if difftime <= 0 then
                self:UpdateExpireState(type,1)
                return true
            end
        end
        
    end
    return false
 end
 function ActivityProxy:UpdateNewPlayerRedDot()

    local bactivity_end = self:CheckActivityFinsh(ActivityDef.toggleType.New_Player)
    local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.Activity_New_Player,false)
    if not bopen then
        return
    end
    local showred = false
    local finish = true
    if  self.data and self.data.new_player and self.data.new_player.new_player_train_curtask then
        local config = self:GetNewPlayerTrainConfig()
        for k , _daytask in ipairs( self.data.new_player.new_player_train_curtask) do
            if k <= self.data.new_player.active_day then
                for _ , v in pairs(_daytask) do
                    local cfg = config[v[1]] 
                    if cfg then
                        if v[2] >= cfg.value and not bactivity_end then
                            showred = true
                            RedPointProxy.Instance:SetNodeNumDynamic(self.new_player_redpointid[k],tostring(cfg.id),1)
                        else
                            finish =false
                            RedPointProxy.Instance:SetNodeNumDynamic(self.new_player_redpointid[k],tostring(cfg.id),0)
                        end
                    end
                    
                end
            end
        end
       
        local config = self:GetNewPlayerStageConfig()
        if config then
            for _ , v in ipairs(config) do
                if v then
                    
                    local state = ActivityDef.Reward_State.CannotGet
                    if self.data.new_player.has_get_new_player_points >= v.points then
                        state = ActivityDef.Reward_State.UnGet
                    end
                    for _ , _id in ipairs(self.data.new_player.has_get_new_player_train_stage_reward) do
                        if v.id == _id then
                            state = ActivityDef.Reward_State.HasGet
                            break
                        end
                    end
                    if state == ActivityDef.Reward_State.UnGet and not bactivity_end then
                        showred = true
                        RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.New_Player_Train,tostring(v.id),1)
                    else
                        RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.New_Player_Train,tostring(v.id),0)
                    end
                end
            end
        end
    end

   
    if not self:IsTheSameToday(ActivityDef.toggleType.New_Player)  then

        if not bactivity_end and not showred and not finish then
        
            RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.New_Player_Train2,1)
        else
            RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.New_Player_Train2,0)
        end
    end
 end
 function ActivityProxy:GetOneDayOneTypeTask(list,day,type,id)
    local config = self:GetNewPlayerTrainConfig()
    if config and id then
        local lasttaskid =config[id].lasttask
        if lasttaskid ~= 0 then
            local last_cfg = config[lasttaskid]
            if last_cfg then
                local item =self:CreatOneItem(last_cfg,day)
                if item then
                    table.insert(list ,item)
                end
            end
        end
    else
        if not id then
            if config then
                local needcreatlist = {}
                for _ , v in pairs(config) do
                    if v.day == day then
                        local find = false
                        for _ , task in ipairs(list) do
                            if task.tasktype == v.type then
                                find = true
                                break
                            end
                        end
                        if not find then
                            local exist = false
                            for _ , _item in ipairs(needcreatlist) do
                                if _item[1] == v.type then
                                    if _item[2] < v.id then
                                        _item[2] = v.id
                                    end
                                    exist = true
                                    break
                                end
                            end
                            if not exist then
                                table.insert(needcreatlist,{v.type,v.id})
                            end
                        end
                    end
                end
                for _, v in ipairs(needcreatlist) do
                    if config[v[2]] then
                        local item =self:CreatOneItem(config[v[2]],day)
                        if item then
                            table.insert(list ,item)
                        end
                    end
                end
            end
        end
    end
 end

 function ActivityProxy:CreatOneItem(last_cfg,day)
    if last_cfg then
        local item = {}
        item.id = last_cfg.id
        item.value = last_cfg.value
        item.target_value = last_cfg.value
        item.goods_id = last_cfg.goods_id or {}
        item.dec = LanguageManager.Instance:GetWord(last_cfg.info)
        item.reddotparent = self.new_player_redpointid[day]
        item.tasktype = last_cfg.type
        item.points = last_cfg.points or 0
        item.sort = last_cfg.sort
        item.state = ActivityDef.Reward_State.HasGet 
        return item
    end
 end

 function ActivityProxy:GetNewPlayerTaskListByDay(day)
    local config = self:GetNewPlayerTrainConfig()
    local taskList = {}
    if  self.data and self.data.new_player and self.data.new_player.new_player_train_curtask then
        local tasks = self.data.new_player.new_player_train_curtask[day] or {}
        for _ , v in pairs(tasks) do
            local item = {}
            item.id = v[1]
            local cfg = config[v[1]] 
            if cfg then
                item.value = v[2] 
                item.target_value = cfg.value
                item.goods_id = cfg.goods_id or {}
                item.dec = LanguageManager.Instance:GetWord(cfg.info)
                item.reddotparent = self.new_player_redpointid[day]
                item.tasktype = cfg.type
                item.points = cfg.points or 0
                item.sort = cfg.sort
                item.state = ActivityDef.Reward_State.CannotGet 
                if item.value >=  item.target_value then
                    item.state = ActivityDef.Reward_State.UnGet
                end
                table.insert(taskList ,item)
                self:GetOneDayOneTypeTask(taskList,day,cfg.type,item.id )
            end
        end
        self:GetOneDayOneTypeTask(taskList,day)
    end
    table.sort(taskList,function ( a,b )
        if a.state ==  b.state then
            return a.sort < b.sort
        else
            return a.state < b.state
        end
        
    end)
    return taskList
 end
 function ActivityProxy:GetNewPlayerFirstUnFinishDay()
    if  self.data and self.data.new_player and self.data.new_player.new_player_train_curtask then
        local config = self:GetNewPlayerTrainConfig()
        for k , _daytask in ipairs( self.data.new_player.new_player_train_curtask) do
            for _ , v in pairs(_daytask) do
                local cfg = config[v[1]] 
                if cfg then
                    if v[2] < cfg.value then
                        return k
                    end
                end
                
            end
        end
       
    end
    return self.new_player_max_days
 end

 function ActivityProxy:GetNewPlayerNextTask(curtaskid)
    local config = self:GetNewPlayerTrainConfig()
    if config then
        for _ , cfg in pairs(config) do
            if cfg and cfg.lasttask then
                if cfg.lasttask == curtaskid then
                    return cfg.id
                end
            end
        end
    end
 end

 function ActivityProxy:GetNewPlayerMaxDays()
    return self.new_player_max_days
 end

 function ActivityProxy:GetNewPlayerMaxDays()
    return self.new_player_max_days
 end

 function ActivityProxy:Send62003(type,id)
    local finish = self:CheckActivityFinsh(ActivityDef.toggleType.New_Player)
    if finish then
        return
    end
    local encoder = NetEncoder.New()
    encoder:Encode("I1I2",type,id)
    self:SendMessage(62003,encoder)
 end
 function ActivityProxy:UpdateStateReward(id)
    local config = self:GetNewPlayerStageConfig()
    if config and config[id] then
        local rewardlist={}
        local rewards = config[id].goods_id or {}
        for _, v in ipairs(rewards) do
            if v then
                local item={}
                item.goodsid = v[1]
                item.goodsnum = v[2]
                table.insert(rewardlist,item)
            end
        end
        table.insert(self.data.new_player.has_get_new_player_train_stage_reward,id)
        if #self.data.new_player.has_get_new_player_train_stage_reward ==#config then
            self:UpdateExpireState(ActivityDef.toggleType.New_Player,1)
            self:ActivityEnd(ActivityDef.toggleType.New_Player)
            LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ActivityRootView)
        end
        self:UpdateNewPlayerRedDot()
        self:ToNotify(self.data,ActivityDef.NotifyDef.GetStageReward,{})
        GameLogicTools.ShowGetItemView(rewardlist,1,function (  )
    
        end)
    end
 end
 function ActivityProxy:On62003(decoder)
    local result ,id,type = decoder:Decode("I1I2I1")
    if result == 0 then
        if type == 2 then
            self:UpdateStateReward(id)
            return
        end
        local config = self:GetNewPlayerTrainConfig()
        if config and config[id] then
            local day = config[id].day
            local rewards =config[id].goods_id or {}
            local rewardlist={}

            local tasks = self.data.new_player.new_player_train_curtask[day]
            local curcount = 0
            local addcount = 0
            local index = 0
            local stage_config = self:GetNewPlayerStageConfig()
            local max_point = stage_config[#stage_config].points 
            if tasks then
                table.sort(tasks,function ( a,b )
                    return a[1] < b[1]
                end)
                for k, v in ipairs(tasks) do
                    if v[1] == id then
                        local next_task_id = self:GetNewPlayerNextTask(id)
                        if next_task_id then
                            v[1] = next_task_id
                        else
                           
                            table.remove(tasks,k)
                        end
                        index = k
                        curcount = self.data.new_player.has_get_new_player_points
                        addcount =  config[id].points
                        self.data.new_player.has_get_new_player_points = self.data.new_player.has_get_new_player_points + config[id].points
                        RedPointProxy.Instance:SetNodeNumDynamic(self.new_player_redpointid[day],tostring(id),0)
                        break
                    end
                end
            end
            
            self:ToNotify(self.data,ActivityDef.NotifyDef.UpdateNewPlayerInfo,{update = true , day = day,endtime = self.data.expire_time[ActivityDef.toggleType.New_Player]})
            self:UpdateNewPlayerRedDot()
            for _, v in ipairs(rewards) do
                if v then
                    local item={}
                    item.goodsid = v[1]
                    item.goodsnum = v[2]
                    table.insert(rewardlist,item)
                end
            end
            GameLogicTools.ShowGetItemView(rewardlist,1,function (  )
                self:ToNotify(self.data,ActivityDef.NotifyDef.DoFlyCoinAni,{curcount = curcount ,addcount = addcount  ,index = index , max_point = max_point })
            end)
        end
    else
        GameLogicTools.ShowErrorCode(62003,result)
    end
 end

 function ActivityProxy:GetStateReward()
    local config = self:GetNewPlayerStageConfig()
    local max_point = 100
    local stageList ={}
    if config then
        for _ , v in ipairs(config) do
            if v then
                local item = {}
                item.id = v.id
                item.points = v.points
                item.state = ActivityDef.Reward_State.CannotGet
                if self.data.new_player.has_get_new_player_points >= v.points then
                    item.state = ActivityDef.Reward_State.UnGet
                end
                for _ , _id in ipairs(self.data.new_player.has_get_new_player_train_stage_reward) do
                    if v.id == _id then
                        item.state = ActivityDef.Reward_State.HasGet
                        break
                    end
                end
                item.goods_id = v.goods_id
                table.insert(stageList,item)
            end
        end
        max_point = config[#config].points
    end
    return stageList,self.data.new_player.has_get_new_player_points , max_point
 end

 function ActivityProxy:Send62004()
    local finish = self:CheckActivityFinsh(ActivityDef.toggleType.HeroGathering)
    if finish then
        self:UpdateHeroGatheringRedDot()
        return
    end
    self:SendMessage(62004)
 end
 
 function ActivityProxy:On62004(decoder)
    local herocount,endtime = decoder:Decode("I2I4")
    local has_get_hero_gathering_reward = decoder:DecodeList("I1")
    self.data.hero_gathering.has_get_hero_gathering_reward = has_get_hero_gathering_reward 
    --self.data.hero_gathering.endtime = endtime
    self.data.expire_time[ActivityDef.toggleType.HeroGathering] = endtime
    self.data.hero_gathering.herocount = herocount
    self:ToNotify(self.data,ActivityDef.NotifyDef.UpdateHeroGatheringInfo,{doAni = true})
    self:UpdateHeroGatheringRedDot()
 end
 
 function ActivityProxy:UpdateHeroGatheringRedDot()
    if self.data and  self.data.hero_gathering and  self.data.hero_gathering.has_get_hero_gathering_reward then
        local bactivity_end = self:CheckActivityFinsh(ActivityDef.toggleType.HeroGathering)
        local config = self:GetHeroGatheringConfig()
        local showred = false
        if config then
            for _ , v  in ipairs(config) do
                local find = false
                for _ , _id  in ipairs(self.data.hero_gathering.has_get_hero_gathering_reward) do

                    if  v.id == _id then
                        find = true
                        break
                    end
                end
                if not find then
                    if self.data.hero_gathering.herocount >= v.collect_heroes and not bactivity_end then
                        showred = true
                        RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.HeroGathering,tostring(v.id),1)
                    else
                        RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.HeroGathering,tostring(v.id),0)
                    end
                else
                    RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.HeroGathering,tostring(v.id),0)
                end
            end
            
        end
    
        if  not self:IsTheSameToday(ActivityDef.toggleType.HeroGathering) then
           
            if not showred and not bactivity_end  then
                RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.HeroGathering2,1)
            else
                RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.HeroGathering2,0)
            end
        end
    end
 end
 function ActivityProxy:SaveLoginTime(type)

    PlayerPrefs.SetInt(tostring(RoleInfoModel.guserid).."Activity"..tostring(type),RoleInfoModel.servertime)
 end
 function ActivityProxy:GetLoginTime(type)
     return PlayerPrefs.GetInt(tostring(RoleInfoModel.guserid).."Activity"..tostring(type))
 end
 function ActivityProxy:IsTheSameToday(type)
    local last_login_time = self:GetLoginTime(type)
    local DateFormatUtil = require "Common.Util.DateFormatUtil"
    local date_a = DateFormatUtil.Date("*t",last_login_time) -- os.date("*t", last_login_time)
    local date_b =DateFormatUtil.Date("*t",RoleInfoModel.servertime)-- os.date("*t", RoleInfoModel.servertime)

    return date_a.day == date_b.day and date_a.month == date_b.month and date_a.year == date_b.year
 end

 function ActivityProxy:Send62005(type,id)
    local finish = self:CheckActivityFinsh(type)
    if finish then
        return
    end
    local encoder = NetEncoder.New()
    encoder:Encode("I1I2",type,id)
    self:SendMessage(62005,encoder)
 end
 function ActivityProxy:GetHeroGatheringReward(id)
    local config = self:GetHeroGatheringConfig()
    if config[id] then
        table.insert(self.data.hero_gathering.has_get_hero_gathering_reward,id)
        self:ToNotify(self.data,ActivityDef.NotifyDef.UpdateHeroGatheringInfo,{doAni = false})
        self:UpdateHeroGatheringRedDot()
        local rewards =config[id].goods_id or {}
        local rewardlist={}
        for _, v in ipairs(rewards) do
            if v then
                local item={}
                item.goodsid = v[1]
                item.goodsnum = v[2]
                table.insert(rewardlist,item)
            end
        end
        
        GameLogicTools.ShowGetItemView(rewardlist,1,function (  )

        end)
        if #self.data.hero_gathering.has_get_hero_gathering_reward == #config then
            LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ActivityRootView)
            self:UpdateExpireState(ActivityDef.toggleType.HeroGathering,1)
            self:ActivityEnd(ActivityDef.toggleType.HeroGathering)
        end
    end
    
 end
 function ActivityProxy:GetStageClearReward(id)
    local config = self:GetStageClearChargeConfig()
    local index = 0
    if config[id] then
        local data = self:GetStageClearChargeList()
        table.insert(self.data.stage_clear.has_get_reward,id)
        
        if #self.data.stage_clear.has_get_reward == #config then
            
            self:UpdateExpireState(ActivityDef.toggleType.StageClearCharge,1)
            self:ActivityEnd(ActivityDef.toggleType.StageClearCharge)
            LuaLayout.Instance:CloseWidget(UIWidgetNameDef.StageClearChargeView)
            LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ActivityRootView)
        else
            self:ToNotify(self.data,ActivityDef.NotifyDef.UpdateStageClearChargeInfo,{updata = true,totalnum  = #data , id = id})
        end
        self:UpdateStageClearChargeRedDot()
        local rewards =config[id].goods_id or {}
        local rewardlist={}
        for _, v in ipairs(rewards) do
            if v then
                local item={}
                item.goodsid = v[1]
                item.goodsnum = v[2]
                table.insert(rewardlist,item)
            end
        end
        if id == 1 or id == 2 then
            GameLogicTools.ShowGetItemView(rewardlist,5,function (  )

            end)
        else
            GameLogicTools.ShowGetItemView(rewardlist,1,function (  )

            end)
        end
    end
    
 end
 function ActivityProxy:On62005(decoder)
    local result, type,id = decoder:Decode("I1I1I2")
    if result == 0 then
        if type == ActivityDef.toggleType.HeroGathering then
            self:GetHeroGatheringReward(id)

        elseif type == ActivityDef.toggleType.StageClearCharge then
            self:GetStageClearReward(id)
        elseif type == ActivityDef.toggleType.HatharalComing then
            self:GetHatharalComingReward(id)
        elseif type == ActivityDef.toggleType.Share then
            local isnew = decoder:Decode("I1")
            self:GetShareReward(isnew)
        else
            self:GetHeroComingReward(type,id)
        end
    else
        GameLogicTools.ShowErrorCode(62005,result)
    end
 end

 function ActivityProxy:GetHeroGatheringList()
    local config = self:GetHeroGatheringConfig()
    local list = {}
    if config then
        for _ , v  in ipairs(config) do
            local item = {}
            local has_get = false
            for _ , _id  in ipairs(self.data.hero_gathering.has_get_hero_gathering_reward) do

                if  v.id == _id then
                    has_get = true
                    break
                end
            end
            item.id = v.id
            item.total = v.collect_heroes
            item.num = self.data.hero_gathering.herocount
            item.has_get = has_get
            item.goods_id = v.goods_id
            table.insert(list,item)
        end
    end
    return list , self.data.expire_time[ActivityDef.toggleType.HeroGathering] or 0
 end

 function ActivityProxy:Send62006()
    local finish = self:CheckActivityFinsh(ActivityDef.toggleType.StageClearCharge)
    if finish then
        self:UpdateStageClearChargeRedDot()
        return
    end
    self:SendMessage(62006)
 end
 function ActivityProxy:On62006(decoder)
    local endtime = decoder:Decode("I4")
    local has_get_stage_clear_reward = decoder:DecodeList("I1")
    self.data.stage_clear.has_get_reward = has_get_stage_clear_reward 
    --self.data.stage_clear.endtime = endtime
    self.data.expire_time[ActivityDef.toggleType.StageClearCharge] = endtime
    self:ToNotify(self.data,ActivityDef.NotifyDef.UpdateStageClearChargeInfo,{})
    self:UpdateStageClearChargeRedDot()
   
 end

 function ActivityProxy:IsFinishSecondChapter()
    -- 改成完成第一章
    local CampaignProxy =require "Modules.Campaign.CampaignProxy"
    local cfg =  CampaignProxy.Instance:GetCurMainLine()
    if cfg and cfg.chapter >= 2 then
        return true
    end
    return false
 end
 function ActivityProxy:UpdateStageClearChargeRedDot()
    local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.Activity_StageClearCharge,false)
    if not bopen then
        return
    end
    if not self:IsFinishSecondChapter() then
        return
    end
    if self.data and self.data.stage_clear and self.data.stage_clear.has_get_reward then

        local endactivity = self:CheckActivityFinsh(ActivityDef.toggleType.StageClearCharge)
        local config = self:GetStageClearChargeConfig()
        local mainlineId = RoleInfoModel.mainlineid -1
        if  CampaignProxy.Instance:IsPassToNextChapter() then
            mainlineId = RoleInfoModel.mainlineid
        end
        local mainlinecfg = mainlineId == 0 and nil or CampaignProxy.Instance:GetMainLineCfgById(mainlineId)
        local showred = false
        if config then
            for _ , v  in ipairs(config) do
                local find = false
                for _ , _id  in ipairs(self.data.stage_clear.has_get_reward or {}) do
                    if  v.id == _id then
                        find = true
                        break
                    end
                end
                if not find then
                    local chaptercfg = CampaignProxy.Instance:GetChapterCfgById(v.mainline)
                    if mainlinecfg  then
                        if (mainlinecfg.section >= chaptercfg.total_section and mainlinecfg.chapter == v.mainline) or mainlinecfg.chapter > v.mainline  and not endactivity then
                            showred = true
                            RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.StageClearCharge,tostring(v.id),1)
                        else
                            RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.StageClearCharge,tostring(v.id),0)
                        end
                    else
                        RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.StageClearCharge,tostring(v.id),0)
                    end
                else
                    RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.StageClearCharge,tostring(v.id),0)
                end
            end
            
        end
    
        
        if not self:IsTheSameToday(ActivityDef.toggleType.StageClearCharge) then
            
            local finish = self:CheckFinishStageClearActivity()
            if not showred and not endactivity and not finish then
                RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.StageClearCharge2,1)
            else
                RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.StageClearCharge2,0)
            end
        end
    end
    
 end
 function ActivityProxy:CheckFinishStageClearActivity()
    local config =self:GetStageClearChargeConfig()
    if config and self.data.stage_clear.has_get_reward then
        if #config == #self.data.stage_clear.has_get_reward then
            return true
        end
    end
    return false
 end
 function ActivityProxy:GetStageClearChargeList()

    if not self.data.stage_clear.has_get_reward then
        return {}
    end
    local config = self:GetStageClearChargeConfig()
    local mainlineId = RoleInfoModel.mainlineid - 1
    if  CampaignProxy.Instance:IsPassToNextChapter() then
        mainlineId = RoleInfoModel.mainlineid
    end
    local mainlinecfg = mainlineId == 0 and nil or CampaignProxy.Instance:GetMainLineCfgById(mainlineId)
    local list = {}
    if config then
        for _ , v in ipairs(config) do
            if v then
                local item = {}
                item.id = v.id
                item.chapter = v.mainline or 1
                local total = 0
                local chaptercfg = CampaignProxy.Instance:GetChapterCfgById(v.mainline)
                item.pass_chapter = mainlinecfg and mainlinecfg.chapter or 1
                item.name = chaptercfg and string.format("%s.%s",tostring(v.id),LanguageManager.Instance:GetWord(chaptercfg.name)) or ""
                
                if item.pass_chapter == v.mainline then
                    item.pass = mainlinecfg and mainlinecfg.section or 0
                else
                    item.pass = 0
                end
                item.total = chaptercfg and chaptercfg.total_section or 0
                item.goods_id = v.goods_id
                item.has_get = false
                item.state = ActivityDef.Reward_State.CannotGet
                for _ , _id in ipairs(self.data.stage_clear.has_get_reward) do
                    if _id and _id == v.id then
                        item.has_get =true
                        item.state = ActivityDef.Reward_State.HasGet
                        break
                    end
                end
                table.insert(list,item)
            end
        end
    end
    table.sort(list,function (a,b  )
        if a.state  ~= b.state then
            return a.state  < b.state
        else
            return a.id < b.id
        end
     end)
    return list , self.data.expire_time[ActivityDef.toggleType.StageClearCharge] or 0 
 end

 function ActivityProxy:GetHatharalComingHero()
    local config = ConfigManager.GetConfig("data_common")
    local cfg = config.activity_hatharalcoming_hero
    if cfg then
        
        return cfg.value1
    end
    return config
end

function ActivityProxy:GetHatharalComingEndTime(id)
    if not id then
        local config = self:GetHatharalComingConfig()
        local max = config and #config or 1
        if self.data.expire_time then
            local hasnum = math.max(#self.data.hatharalcoming.has_get_reward - #self.data.hatharalcoming.use_id_list)
            return hasnum,self.data.hatharalcoming.use_id_list, max, self.data.expire_time[ActivityDef.toggleType.HatharalComing]
        end
    else
        local config,count = self:GetHeroComingCfgById(id)
        local max = count
        if self.data.expire_time then
            local hasnum = math.max(#self.data.herocoming[id].has_get_reward - #self.data.herocoming[id].use_id_list)
            return hasnum,self.data.herocoming[id].use_id_list, max, self.data.expire_time[id]
        end
    end
    
end

function ActivityProxy:GetHatharalComingTaskList()
    
    local config = self:GetHatharalComingConfig()
    local list = {}
    if config and self.data.hatharalcoming.task_progress then
        for _ , cfg in ipairs(config) do

            local item = {}
            item.id = cfg.id
            item.state = ActivityDef.Reward_State.CannotGet
            local cur_value = self.data.hatharalcoming.task_progress[cfg.type or 1]
            local target_value = cfg.value or 0
            if cur_value >= target_value then
                local hasget = false
                for _ , _id in ipairs(self.data.hatharalcoming.has_get_reward) do
                    if cfg.id == _id then
                        hasget = true
                        item.state = ActivityDef.Reward_State.HasGet
                        break
                    end
                end
                if not hasget then
                    item.state = ActivityDef.Reward_State.UnGet
                end
            end
            item.value = cur_value
            item.target_value = target_value
            item.goods_id = cfg.goods_id or {}
            item.sort = cfg.sort
            item.tasktype = cfg.type
            item.openstate = 1
            local openType = ActivityDef.HatharalComing_OpenCondition[item.tasktype]
            local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
            local bopen = ModuleManager.SystemIsOpen(openType,false)
            if openType and not bopen then	
                item.openstate = 0
            end
            item.dec = LanguageManager.Instance:GetWord(cfg.info)
            table.insert(list,item)
        end
    end
    table.sort(list,function (a,b  )
        if a.state  ~= b.state then
            return a.state  < b.state
        else
            if a.openstate == b.openstate then
                return a.sort < b.sort
            else
                return a.openstate > b.openstate
            end
        end
     end)
    return list
end

function ActivityProxy:GetHeroComingTaskList(id)
    
    local config,count = self:GetHeroComingCfgById(id)
    local list = {}
    if config and self.data.herocoming[id].task_progress then
        for _ , cfg in pairs(config) do

            local item = {}
            item.id = cfg.id
            item.state = ActivityDef.Reward_State.CannotGet
            local cur_value = self.data.herocoming[id].task_progress[cfg.type or 1]
            local target_value = cfg.value or 0
            local hasget = false
            for _ , _id in ipairs(self.data.herocoming[id].has_get_reward) do
                if cfg.id == _id then
                    hasget = true
                    item.state = ActivityDef.Reward_State.HasGet
                    cur_value = target_value
                    break
                end
            end
            if cur_value >= target_value and not hasget then
                item.state = ActivityDef.Reward_State.UnGet
            end
            item.value = cur_value
            item.target_value = target_value
            item.goods_id = cfg.goods_id or {}
            item.sort = cfg.sort
            item.tasktype = cfg.type
            item.openstate = 1
            item.typeid = id --任务大id
            local openType = ActivityDef.HatharalComing_OpenCondition[item.tasktype]
            local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
            local bopen = ModuleManager.SystemIsOpen(openType,false)
            if openType and not bopen then	
                item.openstate = 0
            end
            item.dec = LanguageManager.Instance:GetWord(cfg.info)
            table.insert(list,item)
        end
    end
    table.sort(list,function (a,b  )
        if a.state  ~= b.state then
            return a.state  < b.state
        else
            if a.openstate == b.openstate then
                return a.sort < b.sort
            else
                return a.openstate > b.openstate
            end
        end
     end)
    return list
end

function ActivityProxy:Send62007()
    local finish = self:CheckActivityFinsh(ActivityDef.toggleType.HatharalComing)
    if finish then
        self:UpdateHatharalComingRedDot()
        return
    end
    self:SendMessage(62007)
end
 function ActivityProxy:On62007(decoder)
    local endtime = decoder:Decode("I4")
    local has_get_reward = decoder:DecodeList("I1")
    local use_id_list = decoder:DecodeList("I1")
    local task_progress = decoder:DecodeList("I2")
    self.data.hatharalcoming.has_get_reward = has_get_reward 
    self.data.hatharalcoming.task_progress = task_progress
    self.data.hatharalcoming.use_id_list = use_id_list
    self.data.expire_time[ActivityDef.toggleType.HatharalComing] = endtime

    self:ToNotify(self.data,ActivityDef.NotifyDef.UpdateHatharalComingInfo,{has_num = math.max(0,#has_get_reward - #use_id_list)})
    self:UpdateHatharalComingRedDot()
   
 end

 function ActivityProxy:UpdateHatharalComingRedDot()
    local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.Activity_HatharalComing,false)
    if not bopen then
        return
    end
    if self.data and self.data.hatharalcoming and self.data.hatharalcoming.has_get_reward and self.data.hatharalcoming.task_progress then

        local endactivity = self:CheckActivityFinsh(ActivityDef.toggleType.HatharalComing)
        local config = self:GetHatharalComingConfig()
        local showred = false
        if config and self.data.hatharalcoming.task_progress then
            for _ , cfg in ipairs(config) do
                if cfg then
                    local cur_value = self.data.hatharalcoming.task_progress[cfg.type]
                    local target_value = cfg.value
                    if cur_value >= target_value then
                        local hasget = false
                        for _ , _id in ipairs(self.data.hatharalcoming.has_get_reward) do
                            if cfg.id == _id then
                                hasget = true
                                break
                            end
                        end
                        if not hasget and not endactivity then
                            showred = true
                            RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.HatharalComing2,tostring(cfg.id),1)
                        else
                            RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.HatharalComing2,tostring(cfg.id),0)
                        end
                    else
                        RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.HatharalComing2,tostring(cfg.id),0)
                    end
                end
            end

            local count = #self.data.hatharalcoming.has_get_reward
            if  count > 0 and count ~= #self.data.hatharalcoming.use_id_list  and not endactivity then
                showred = true
                RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.HatharalComing4,1)
            else
                RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.HatharalComing4,0)
            end
        end
        if not self:IsTheSameToday(ActivityDef.toggleType.HatharalComing) then
            
            if not showred and not endactivity  then
                RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.HatharalComing3,1)
            else
                RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.HatharalComing3,0)
            end
        end
    end
    
 end

 function ActivityProxy:Send62008()
    local finish = self:CheckActivityFinsh(ActivityDef.toggleType.HatharalComing)
    if finish then
        return
    end
    self:SendMessage(62008)
 end

 function ActivityProxy:On62008(decoder)
 
    local result ,isnew = decoder:Decode("I1I1")
    local use_id_list = decoder:DecodeList("I1")
    if result == 0 then
        local last_own = math.max(0,#self.data.hatharalcoming.has_get_reward - #self.data.hatharalcoming.use_id_list)
        self.data.hatharalcoming.use_id_list = use_id_list
        local ownnum = math.max(0,#self.data.hatharalcoming.has_get_reward - #self.data.hatharalcoming.use_id_list)
        RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.HatharalComing4,0)
        local config = self:GetHatharalComingConfig()
        local isfull = #self.data.hatharalcoming.use_id_list == #config and true or false
        local rewardlist = {} 
        if isfull then
            local hero = self:GetHatharalComingHero()
            local heroid = hero[1]
            local heros_config = HeroProxy.Instance:GetHeroConfige()
            if heros_config and heroid then
                local item={}
                item.goodsid = heros_config[heroid].goods_id
                item.goodsnum = 1
                table.insert(rewardlist,item)
            end
            self:UpdateExpireState(ActivityDef.toggleType.HatharalComing,1)
            self:ActivityEnd(ActivityDef.toggleType.HatharalComing)
        end
        if last_own > 0 then
            self:ToNotify(self.data,ActivityDef.NotifyDef.DoHatharalComingFlyIcon,{last_own = last_own,has_num = ownnum ,isfull = isfull ,rewardlist = rewardlist ,isnew = isnew })
        end
    else
        GameLogicTools.ShowErrorCode(62008,result)
    end
    
 end

 function ActivityProxy:GetHatharalComingReward(id)
    local config = self:GetHatharalComingConfig()
    local index = 0
    if config[id] then
        local data = self:GetHatharalComingTaskList()
        table.insert(self.data.hatharalcoming.has_get_reward,id)
        local hasnum = math.max(0,#self.data.hatharalcoming.has_get_reward - #self.data.hatharalcoming.use_id_list)
        self:ToNotify(self.data,ActivityDef.NotifyDef.UpdateHatharalComingInfo,{updata = true, totalnum = #data ,id = id, has_num = hasnum })
        self:UpdateHatharalComingRedDot()
        local rewards =config[id].goods_id or {}
        local rewardlist={}
        for _, v in ipairs(rewards) do
            if v then
                local item={}
                item.goodsid = v[1]
                item.goodsnum = v[2]
                table.insert(rewardlist,item)
            end
        end
        GameLogicTools.ShowGetItemView(rewardlist,1,function (  )

        end)
    end
    
 end
 function ActivityProxy:CheckExistActivity()

    for k,v in ipairs(ActivityDef.Btn) do
        local finish =self:CheckActivityFinsh(k)
        if finish or k == ActivityDef.toggleType.Share then

        else
            if ActivityDef.SystemOpenType[k] then
                local ModuleManager = require "Common.Mgr.UI.ModuleManager"
                if ModuleManager.SystemIsOpen(ActivityDef.SystemOpenType[k],false) then
                    if k == ActivityDef.toggleType.StageClearCharge then
                        if  self:IsFinishSecondChapter() then
                           return true
                        end
                    else
                        return true
                    end
                end
            else
                return true
            end
        end
    end
    return false
 end

 function ActivityProxy:GetHeroComingReward(typeid,id)
    local config ,count= self:GetHeroComingCfgById(typeid)
    local index = 0
    if config[id] then
        local data = self:GetHeroComingTaskList(typeid)
        table.insert(self.data.herocoming[typeid].has_get_reward,id)
        local hasnum = math.max(0,#self.data.herocoming[typeid].has_get_reward - #self.data.herocoming[typeid].use_id_list)
        self:ToNotify(self.data,ActivityDef.NotifyDef.UpdateHatharalComingInfo,{updata = true, totalnum = #data ,id = id, has_num = hasnum })
        self:UpdateHeroComingRedDot(typeid)
        local rewards =config[id].goods_id or {}
        local rewardlist={}
        for _, v in ipairs(rewards) do
            if v then
                local item={}
                item.goodsid = v[1]
                item.goodsnum = v[2]
                table.insert(rewardlist,item)
            end
        end
        GameLogicTools.ShowGetItemView(rewardlist,1,function (  )

        end)
    end
    
 end

 function ActivityProxy:GetHasGetFragment(id)
    if not id then
        if self.data.hatharalcoming.has_get_reward then
            local count = math.max(0,#self.data.hatharalcoming.has_get_reward - #self.data.hatharalcoming.use_id_list)
            
            return count
        end
        return 0
    else
        if self.data.herocoming[id].has_get_reward then
            local count = math.max(0,#self.data.herocoming[id].has_get_reward - #self.data.herocoming[id].use_id_list)
            
            return count
        end
        return 0
    end
    
 end

 function ActivityProxy:GetHatharalComingGetRewardList(id)
    if not id then
        if self.data.hatharalcoming.has_get_reward then
            return self.data.hatharalcoming.has_get_reward
        end
    else
        if self.data.herocoming[id].has_get_reward then
            return self.data.herocoming[id].has_get_reward
        end
    end
    
 end

 function ActivityProxy:Send62009()

    local finish = self:CheckActivityFinsh(ActivityDef.toggleType.Share)
    if finish then
        return
    end
    self:SendMessage(62009)

 end

 function ActivityProxy:On62009(decoder)
    local share_times,hasget = decoder:Decode("I1I1")
    self.data.share.share_times = share_times
    self.data.share.hasget = hasget
    self.data.expire_time[ActivityDef.toggleType.Share] = 0
    self:UpdateShareRedDot()
 end

 function ActivityProxy:Send62010()
    self:SendMessage(62010)
 end

 function ActivityProxy:On62010(decoder)
 
    local share_times = decoder:Decode("I1")
    self.data.share.share_times = share_times
    self:UpdateShareRedDot()
    self:ToNotify(self.data,ActivityDef.NotifyDef.UpdateShareRed,{})
 end

 function ActivityProxy:UpdateShareRedDot()
    if self.data.share.share_times then
        if self.data.share.share_times >= self.ShareMaxTimes then
            if self.data.share.hasget == ActivityDef.Reward_State.UnGet then
                RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.Activity_Share_Get,1)
            elseif self.data.share.hasget == ActivityDef.Reward_State.HasGet then
                RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.Activity_Share_Get,0)
            end
        else
            RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.Activity_Share_Get,0)
        end
    end
 end

 function ActivityProxy:GetShareReward(isnew)
     self.data.share.hasget = ActivityDef.Reward_State.HasGet
     local hero = self:GetShareAwardHero()
     local roleid = hero[1]
     local heros_config = HeroProxy.Instance:GetHeroConfige()
     local rewardlist = {}
     if heros_config and roleid then
         local item={}
         item.goodsid = heros_config[roleid].goods_id
         item.goodsnum = 1
         table.insert(rewardlist,item)
     end
     GameLogicTools.ShowGetItemView(rewardlist,1,function (  )
        if isnew == 1 then
            GameLogicTools.ShowHeroTipsView(roleid, heros_config[roleid].rank_min, 1, true, true, true, function()
                local HeroProxy = require "Modules.Hero.HeroProxy"
                HeroProxy.Instance:UpdateRoleIdList(roleid)
            end)
        end
        
    end)
     self:UpdateShareRedDot()
     self:ToNotify(self.data,ActivityDef.NotifyDef.GetShareAward,{})
     self:ActivityEnd(ActivityDef.toggleType.Share)
     LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ShareChargeView)
 end
 function ActivityProxy:GetShareRewardState()
    local finish = self:CheckActivityFinsh(ActivityDef.toggleType.Share)
    if finish then
        return ActivityDef.Reward_State.HasGet
    end
    local state = ActivityDef.Reward_State.CannotGet
    if self.data.share.share_times then
        if self.data.share.share_times >= self.ShareMaxTimes then
            if self.data.share.hasget == ActivityDef.Reward_State.UnGet then
                state = ActivityDef.Reward_State.UnGet
            elseif self.data.share.hasget == ActivityDef.Reward_State.HasGet then
                state = ActivityDef.Reward_State.HasGet
            end
        else
        end
    end
    return state
 end

 function ActivityProxy:Send62011(id)
    local finish = self:CheckActivityFinsh(id)
    if finish then
        self:UpdateHeroComingRedDot(id)
        return
    end
    local encoder = NetEncoder.New()
    encoder:Encode("I1",id)
    self:SendMessage(62011,encoder)
 end

 function ActivityProxy:On62011(decoder)

    local id,endtime = decoder:Decode("I1I4")
    local has_get_reward = decoder:DecodeList("I1")
    local use_id_list = decoder:DecodeList("I1")
    local task_progress = decoder:DecodeList("I2")
    if not self.data.herocoming[id] then
        self.data.herocoming[id] = {}
    end
    self.data.herocoming[id].has_get_reward = has_get_reward 
    self.data.herocoming[id].task_progress = task_progress
    self.data.herocoming[id].use_id_list = use_id_list
    self.data.expire_time[id] = endtime

    self:ToNotify(self.data,ActivityDef.NotifyDef.UpdateHatharalComingInfo,{has_num = math.max(0,#has_get_reward - #use_id_list)})
    self:UpdateHeroComingRedDot(id)

 end

 function ActivityProxy:GetHeroComingCfgById(id)
    local config = self:GetHeroComingConfig()
    local card = id - 5
    local cfglist = {}
    local count = 0
    for _ , v in pairs(config) do
        if v then
            if v.card == card then
                --table.insert(cfglist, v)
                cfglist[v.id] = v
                count = count + 1
            end
        end
    end
    return cfglist,count
 end

 function ActivityProxy:UpdateHeroComingRedDot(id)
    local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.Activity_HatharalComing,false)
    if not bopen then
        return
    end
 
    local showred = false
    local config,count = self:GetHeroComingCfgById(id)
    local endactivity = self:CheckActivityFinsh(id)
    local parent_redpoint=ActivityDef.HeroComingRedPointId[id]
    if config and self.data.herocoming[id] and self.data.herocoming[id].task_progress and #self.data.herocoming[id].task_progress > 0 then
        for _ , cfg in pairs(config) do
            if cfg then
                local cur_value = self.data.herocoming[id].task_progress[cfg.type]
                if not cur_value then
                    print("--------UpdateHeroComingRedDot--id---cfgid-type-----",id,cfg.id,cfg.type,table.dump(self.data.herocoming[id].task_progress))
                end
                local target_value = cfg.value
                if cur_value >= target_value then
                    local hasget = false
                    for _ , _id in ipairs(self.data.herocoming[id].has_get_reward) do
                        if cfg.id == _id then
                            hasget = true
                            break
                        end
                    end
                    if not hasget and not endactivity then
                        showred = true
                        RedPointProxy.Instance:SetNodeNumDynamic(parent_redpoint,RedPointDef.Id.HeroComing2..tostring(id)..tostring(cfg.id),1)
                    else
                        RedPointProxy.Instance:SetNodeNumDynamic(parent_redpoint,RedPointDef.Id.HeroComing2..tostring(id)..tostring(cfg.id),0)
                    end
                else
                    RedPointProxy.Instance:SetNodeNumDynamic(parent_redpoint,RedPointDef.Id.HeroComing2..tostring(id)..tostring(cfg.id),0)
                end
            end
        end

        local count = #self.data.herocoming[id].has_get_reward
        if  count > 0 and count ~= #self.data.herocoming[id].use_id_list and not endactivity then
            showred = true
            RedPointProxy.Instance:SetNodeNumDynamic(parent_redpoint,RedPointDef.Id.HeroComing4..tostring(id),1)
        else
            RedPointProxy.Instance:SetNodeNumDynamic(parent_redpoint,RedPointDef.Id.HeroComing4..tostring(id),0)
        end
    end
    RedPointProxy.Instance:SetNodeNumDynamic(parent_redpoint,RedPointDef.Id.HeroComing2..tostring(id),showred and 1 or 0)
    if not self:IsTheSameToday(id) then
        
        if not showred and not endactivity  then
            RedPointProxy.Instance:SetNodeNumDynamic(parent_redpoint,RedPointDef.Id.HeroComing3..tostring(id),1)
        else
            RedPointProxy.Instance:SetNodeNumDynamic(parent_redpoint,RedPointDef.Id.HeroComing3..tostring(id),0)
        end
    end
 end

 function ActivityProxy:Send62012(id)
    local finish = self:CheckActivityFinsh(id)
    if finish then
        return
    end
    local encoder = NetEncoder.New()
    encoder:Encode("I1",id)
    self:SendMessage(62012,encoder)
 end

 function ActivityProxy:On62012(decoder)
 
    local result ,isnew,id = decoder:Decode("I1I1I1")
    local use_id_list = decoder:DecodeList("I1")
    if result == 0 then
        local last_own = math.max(0,#self.data.herocoming[id].has_get_reward - #self.data.herocoming[id].use_id_list)
        self.data.herocoming[id].use_id_list = use_id_list
        local ownnum = math.max(0,#self.data.herocoming[id].has_get_reward - #self.data.herocoming[id].use_id_list)
        self:UpdateHeroComingRedDot(id)
        local config,count = self:GetHeroComingCfgById(id)
        local isfull = #self.data.herocoming[id].use_id_list == count and true or false
        local rewardlist = {} 
        if isfull then
            local heroid = self:GetHeroComingHero(id)
            local heros_config = HeroProxy.Instance:GetHeroConfige()
            if heros_config and heroid then
                local item={}
                item.goodsid = heros_config[heroid].goods_id
                item.goodsnum = 1
                table.insert(rewardlist,item)
            end
            self:UpdateExpireState(id,1)
            self:ActivityEnd(id)
        end
        if last_own > 0 then
            self:ToNotify(self.data,ActivityDef.NotifyDef.DoHatharalComingFlyIcon,{last_own = last_own,has_num = ownnum ,isfull = isfull ,rewardlist = rewardlist ,isnew = isnew })
        end
    else
        GameLogicTools.ShowErrorCode(62012,result)
    end
    
 end




 function ActivityProxy:Send62013()
    local finish = self:CheckActivityFinsh(ActivityDef.toggleType.HappyMonth)
    if finish then
        return
    end
    self:SendMessage(62013)
 end

 function ActivityProxy:On62013(decoder)
    local buystate, endtime,isbuy = decoder:Decode("I1I4I1")
    local has_get_reward_days = decoder:DecodeList("I1")
    local un_get_reward_days = decoder:DecodeList("I1")
    self.data.happymonth.has_get_reward_days = has_get_reward_days
    self.data.happymonth.un_get_reward_days = un_get_reward_days
    self.data.happymonth.buystate = buystate
    self.data.expire_time[ActivityDef.toggleType.HappyMonth] = endtime
    self:UpdateHappyMonthRedDot()
    if isbuy == 1 then
        --刚刚够了
        local rewardlist={}
        local list = self:GetMallGoodsByMallId(ActivityDef.HappyMonth_GiftId)
        for i,reward in ipairs(list) do
            local item={}
            item.goodsid = reward[1]
            item.goodsnum = reward[2]
            table.insert(rewardlist,item)
        end
        GameLogicTools.ShowGetItemView(rewardlist,1,function (  )
           
        end)
    end
    self:ToNotify(self.data,ActivityDef.NotifyDef.Update_Happy_Month_Info,{})
 end

 function ActivityProxy:Send62014(idlist)
    local finish = self:CheckActivityFinsh(ActivityDef.toggleType.HappyMonth)
    if finish then
        return
    end
    if #idlist == 0 then
        return
    end
    local encoder= NetEncoder.New()
    encoder:EncodeList("I1",idlist)
    self:SendMessage(62014,encoder)
 end

 function ActivityProxy:On62014(decoder)
    local result = decoder:Decode("I1")
    if result == 0 then
        local rewardlist = {}
        local get_id_list = decoder:DecodeList("I1")
        local new_hero_list = decoder:DecodeList("I4")
        local config = self:GetHappyMonthConfig()
        if config then
            for _ , id in ipairs(get_id_list) do
                if config[id] then
                    local cfg = config[id]
                    if cfg then
                        local rewards = cfg.goods_id
                        for _ , reward in ipairs(rewards or {}) do
                            local item={}
                            item.goodsid = reward[1]
                            item.goodsnum = reward[2]
                            table.insert(rewardlist,item)
                        end
                    end

                    table.insert(self.data.happymonth.has_get_reward_days,id)
                    for k , _id in ipairs(self.data.happymonth.un_get_reward_days) do
                        if _id == id then
                            table.remove(self.data.happymonth.un_get_reward_days,k)
                            break
                        end
                    end
                end
            end
        end
        if #rewardlist > 0 then
            GameLogicTools.ShowGetItemView(rewardlist,1,function (  )
               
                if #new_hero_list > 0 then
                    local goodslist = {}
                    for _ , goods_type_id in ipairs(new_hero_list) do
                        table.insert(goodslist,{goods_type_id,1})
                    end
                    GameLogicTools.ShouldShowNewHeroTipsView(goodslist)
                end
            end)
            self:UpdateHappyMonthRedDot()
            
        end
        local finish = false
        if #self.data.happymonth.has_get_reward_days == #config then
            
            self:UpdateExpireState(ActivityDef.toggleType.HappyMonth,1)
            self.data.expire_time[ActivityDef.toggleType.HappyMonth] = 0
            finish = true
        end
        self:ToNotify(self.data,ActivityDef.NotifyDef.Update_Happy_Month_Info,{update = true,finish = finish})
    else
        GameLogicTools.ShowErrorCode(62014,result)
    end
 end

 function ActivityProxy:GetAllReward()
    if #self.data.happymonth.un_get_reward_days > 0 then
        self:Send62014(self.data.happymonth.un_get_reward_days)
    end
 end
 function ActivityProxy:GetMallGoodsByMallId(mallid)
    local MallProxy = require "Modules.Mall.MallProxy"
    local cfg = MallProxy.Instance:GetGiftConfigById(mallid)
    local goods = {}
    if cfg then
        goods = cfg.goods_id or {}
    end
    return goods
end

function ActivityProxy:CheckHasUnGet()
    if self.data.happymonth.un_get_reward_days then
        if #self.data.happymonth.un_get_reward_days > 0 then
            return true
        end
    end
    return false
end

 function ActivityProxy:ExpireTime(id)
    if self.data.expire_time then
        return self.data.expire_time[id]
    end
    
 end

 function ActivityProxy:CheckHasBought()
    local buy = false
    if self.data.happymonth.buystate then
        if self.data.happymonth.buystate == 1 then
            buy = true
        end
    end
    return buy
 end

 function ActivityProxy:GetHappyMonthRewardState(id)

    local state = ActivityDef.Reward_State.CannotGet
    for _ ,v in ipairs(self.data.happymonth.has_get_reward_days)do
        if v == id then
            state = ActivityDef.Reward_State.HasGet
            return state
        end
    end
    for _ ,v in ipairs(self.data.happymonth.un_get_reward_days)do
        if v == id then
            state = ActivityDef.Reward_State.UnGet
            return state
        end
    end
    return state
 end
 function ActivityProxy:GetHappyMonthList()
    local list = {}
    if self.data.happymonth.has_get_reward_days then
        local config = self:GetHappyMonthConfig()
        if config then
            for _ , v in ipairs(config) do
                local item = {}
                item.id = v.id
                item.goods_id = v.goods_id[1]
                item.state = self:GetHappyMonthRewardState(v.id)
                table.insert(list,item)
            end
        end
    end
    return list
 end
 function ActivityProxy:UpdateHappyMonthRedDot()
    local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.HappyMonthPanel,false)
    if not bopen then
        return
    end
    if self.data.happymonth.un_get_reward_days then
        if #self.data.happymonth.un_get_reward_days > 0 then
            RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.HappyMonthGet,1)
        else
            RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.HappyMonthGet,0)
        end

        -- if self.data.happymonth.buystate == 0 then
        --     --未购买
        --     if not self:IsTheSameToday(ActivityDef.toggleType.HappyMonth) then
            
        --         local finish = self:CheckActivityFinsh(ActivityDef.toggleType.HappyMonth)
        --         if not finish then
        --             RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.HappyMonthBuyTip,1)
        --         else
        --             RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.HappyMonthBuyTip,0)
        --         end
        --     end
        -- end
    end
 end

 function ActivityProxy:CheckNoDeadLineTime(id)
    local config = self:GetActivityTimeConfig()
    if config and config[id] then
        local deadline = config[id].deadline or 0 
        if deadline == - 1 then
            return true
        end
    end
    return false
 end

return ActivityProxy