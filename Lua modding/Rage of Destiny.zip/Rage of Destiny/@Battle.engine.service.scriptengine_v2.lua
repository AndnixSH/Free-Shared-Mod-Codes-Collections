_G.script = {

    -- 等于
    equal = function(propname, value)
        return function(scriptobj)
            local prop = scriptobj:getprop(propname)
            return prop == value
        end
    end,

    -- 不等于
    notequal = function(propname, value)
        return function(scriptobj)
            local prop = scriptobj:getprop(propname)
            return prop ~= value
        end
    end,

    -- 大于
    greaterthan = function(propname, value)
        return function(scriptobj)
            local prop = scriptobj:getprop(propname)
            return prop > value
        end
    end,

    -- 大于等于
    greater = function(propname, value)
        return function(scriptobj)
            local prop = scriptobj:getprop(propname)
            return prop >= value
        end
    end,

    -- 小于
    lessthan = function(propname, value)
        return function(scriptobj)
            local prop = scriptobj:getprop(propname)
            return prop < value
        end
    end,

    -- 小于等于
    less = function(propname, value)
        return function(scriptobj)
            local prop = scriptobj:getprop(propname)
            return prop <= value
        end
    end,

    prop = function(name, key)
        return function(scriptobj)
            local value = scriptobj:getprop(name)
            local result = value
            if value and key then
                result = value[key]
            end
            if result == nil then
                global.debug.warning(string.format("%s script.prop(%s)为空", scriptobj, name))
            end
            return result
        end
    end,
    tableprop = function (name)
        return function(scriptobj)
            return {scriptobj:getprop(name)}
        end
    end,
    static = function(name)
        return function(scriptobj)
            local result = scriptobj:getstatic(name)
            if result == nil then
                global.debug.warning(string.format("%s script.static(%s)为空", scriptobj, name))
            end
            return result
        end
    end,
    tablestatic = function (name)
        return function(scriptobj)
            return {scriptobj:getstatic(name)}
        end
    end,
    append = function(name)
        return function(scriptobj)
            scriptobj:append(name)
        end
    end,
    run = function (name)
        return function (scriptobj)
            scriptobj:run(name)
        end
    end,
    destroy = function ()
        return function (scriptobj)
            scriptobj:destroy()
        end
    end,
    event = function (eventkey)
        return function (scriptobj)
            scriptobj:fire(eventkey)
        end
    end,
    load = function(file)
        return global.service.scriptengine_v2:loadscript(file)
    end,
    composite = function (t)
        t.__composite = true
        return t
    end,
}

_G.scriptevent = {
    onstart = "onstart",
    onend = "onend",
    ondestroy = "ondestroy",
    ontimer = "ontimer",
}

local tunpack = table.unpack
local tinsert = table.insert
local script = {}

function script:init(script_table)
    if script_table.__composite then
        self._composite_table = script_table
        script_table = assert(script_table.main)
    end
    self.action = setmetatable({ static = self.static, owner = self.owner, caller = self.caller, parent = self }, self.service.scriptengine_v2:getactionscript())
    self._script_table = script_table
    self._eventlist = nil
    self._checkeventlist = nil
    self._checkcb = nil
    self._scripteventlist = nil
    self._running = false
    self._param = {}

    local check = script_table.check
    if check and type(check) == 'function' then
        self._checkcb = check
    end
end

function script:start(prop, param, speed)
    if self._running then return end
    self:log("start_script", prop, speed)
    self._running = true
    self._speed = speed or self._speed
    self.prop = {}
    if prop then
        for key, value in pairs(prop) do
            self.prop[key] = value
        end
    end
    if param then
        for key, value in pairs(param) do
            self.action[key] = value
            self._param[key] = value
        end
    end

    self._ticktimer = global.service.timer:createtimer(self, self.owner)
    -- self._ticktimer:setspeed(self._speed)
    self._ticktimer:_internal_add(0, global.service.time.tick, nil, self._update, nil)

    if self._script_table.event then
        self._eventlist = {}
        for _, value in ipairs(self._script_table.event) do
            local eventkey = value[1]
            if scriptevent[eventkey] or value.slot == "script" then
                self._scripteventlist = self._scripteventlist or {}
                self._scripteventlist[eventkey] = assert(value.onfire)
                if eventkey == "ontimer" then
                    local delay, interval, count = tunpack(value.time)
                    self._ticktimer:_internal_add(delay or 0, interval or 0, count, value.onfire, nil)
                end
            else
                local eventobj = self:_register_obj_event(eventkey, value)
                tinsert(self._eventlist, eventobj)
            end
        end
    end

    self:_runscriptevent(scriptevent.onstart)
    self:run("default")
    return true
end

function script:_register_obj_event(eventkey, value)
    local slot = value.slot or self.owner.type
    local modifer = value.modifer or "private"
    local eventobj = {self = self, eventkey = eventkey, slot = slot, func = value[2], count = 0, max = value.count, onfire = value.onfire}
    self.service.eventslots:getslot(slot):add(eventkey, self._eventcb, eventobj, self.owner, modifer)
    return eventobj
end

function script:check()

    local check = self._script_table.check
    if check and not self._checkeventlist and type(check) == 'table' then
        self._checkeventlist = {}
        for index, value in ipairs(check.event) do
            local eventkey = value[1]
            local eventobj = self:_register_obj_event(eventkey, value)
            tinsert(self._checkeventlist, eventobj)
        end
        self._checkcb = self._defaultcheckcb
    end

    if self._checkcb then
        return self._checkcb(self)
    end
    return true
end

function script:satisfy()
    if self._script_table.satisfy then
        return self._script_table.satisfy(self)
    end
    return true
end

function script:checksucc()
    if self._checkeventlist then
        for index, eventobj in ipairs(self._checkeventlist) do
            self.service.eventslots:getslot(eventobj.slot):remove(eventobj.eventkey, self._eventcb, eventobj)
        end
        self._checkeventlist = nil
    end
    self._checkok = true
end

function script:_defaultcheckcb()
    return self._checkok
end

function script:fire(eventkey)
    self:_runscriptevent(eventkey)
end

function script:run(actionkey)
    
    if self._script_table.action then
        local action = self._script_table.action[actionkey]
        if action then
            self:log("run_action", actionkey)
            self._curseq = 0
            self._curaction = action
            self._curtrigger = nil
            self:_start_trigger()
        end
    end
end

function script:redirect(owner, key, args)
    local script_table = key
    if type(key) == 'string' then
        script_table = assert(self._composite_table[key])
    end
    local _script = self.service.scriptengine_v2:create(owner, script_table)
    _script._composite_table = self._composite_table
    local prop = {}
    if args then
        for k, v in pairs(args) do
            prop[k] = v
        end
        for k, v in pairs(self.prop) do
            prop[k] = v
        end
    else
        prop = self.prop
    end
    _script:start(prop, self._param)
end

function script:setspeed(speed)
    self._speed = speed
end

function script:getspeed()
    return self._speed
end

function script._eventcb(eventobj, ...)
    local self = eventobj.self
    if eventobj.max and eventobj.count >= eventobj.max then return end

    self:log("recv event", eventobj.eventkey, eventobj.func)
    
    if eventobj.func then
        eventobj.func(self)
    end
    eventobj.count = eventobj.count + 1
    if eventobj.onfire then
        return eventobj.onfire(self, ...)
    end
end

function script:_runscriptevent(name)
    if self._scripteventlist then
        local func = self._scripteventlist[name]
        if func then
            return func(self)
        end
    end
end

function script:_getscriptevent(name)
    return self._scripteventlist and self._scripteventlist[name]
end

function script:_update(time, tick)
    if self._curtrigger and not self._curtrigger:update(time, tick) then
        self:_start_trigger()
    end
end

function script:append(actionkey)
    local triggerlist = assert(self._script_table.action[actionkey])
    local templist = {}
    for index, value in ipairs(self._curaction) do
        templist[index] = value
    end
    for index, value in ipairs(triggerlist) do
        tinsert(templist, index + self._curseq, value)
    end
    self._curaction = templist
end

function script:setprop(name, value)
    self.prop[name] = value
end

function script:getprop(name)
    return self.prop and self.prop[name]
end

function script:getstatic(name)
    return self.static and self.static[name]
end

function script:getaction(name)
    return self._script_table.action and self._script_table.action[name]
end

function script:getowner()
    return self.owner
end

function script:isrun()
    return self._running
end

function script:stop()
    if not self._running then return end
    self._running = false
    self:log("stop_script")
    self:_runscriptevent(scriptevent.onend)

    if self.cbend then
        self.cbend()
    end

    self:_cleanup()
end


function script:_cleanup()

    self:_runscriptevent(scriptevent.ondestroy)

    if self._eventlist then
        for index, eventobj in ipairs(self._eventlist) do
            self.service.eventslots:getslot(eventobj.slot):remove(eventobj.eventkey, self._eventcb, eventobj)
        end
        self._eventlist = nil
    end

    if self._checkeventlist then
        for index, eventobj in ipairs(self._checkeventlist) do
            self.service.eventslots:getslot(eventobj.slot):remove(eventobj.eventkey, self._eventcb, eventobj)
        end
        self._checkeventlist = nil
    end

    if self._ticktimer then
        global.service.timer:destroytimer(self._ticktimer)
        self._ticktimer = nil
    end

    self.prop = nil
    -- self._speed = nil
    -- self._curaction = nil
    self._curtrigger = nil
    -- self._curseq = nil
    self._scripteventlist = nil
    self._checkok = false
    -- self._checkcb = nil
end

function script:dispose()
    self:_cleanup()
    self._script_table = nil
end

function script:ondestroy()
    -- self:stop()
    self:dispose()
end

function script:log(...)
    -- gamelog.debug(self.owner, ...)
end

function script:tostring()
    return string.format("script:%s", self.static and self.static.id)
end

function script:_create_trigger(trigger_table)
    if not trigger_table.define or trigger_table.define(self) then
        local trigger = trigger_table[1](self, tunpack(trigger_table, 2, #trigger_table))
        return trigger
    end
end

function script:_start_trigger()
    self._curseq = self._curseq + 1
    local trigger_table = self._curaction[self._curseq]
    if trigger_table then
        self._curtrigger = self:_create_trigger(trigger_table)
        self:log("start_trigger", self._curseq, self._curtrigger)
        if not self._curtrigger or not self._curtrigger:start() then
            self:_start_trigger()
        end
    else
        self._curtrigger = nil
        self:stop()
    end
end


local scriptengine = {}

function scriptengine:create(owner, script_table, typeid, static)
    local _script = global.service.logic_factory:createlogic(owner, typeid, static, nil, script)
    _script:init(script_table)
    return _script
end

function scriptengine:init(args)
    self._path = args.searchpath
    self._common = args.commonscript
    self._action = require(self._path..'.'..args.actionscript)
    self._fallback = args.fallbackscript
end

function scriptengine:getactionscript()
    return self._action
end

function scriptengine:register_scriptconf_path(path)
    self._path = path
end

function scriptengine:setcommon(key)
    self._common = key
end

function scriptengine:loadscript(key)
    if self._common then
        require(self._path..'.'..self._common)
        self._common = nil
    end
    local status, conf = pcall(require, self._path..'.'..key)
    if not status then
        global.debug.warning(conf)
    else
        return conf
    end
end

function scriptengine:loadscripttable(key, group, scriptid, fallback)
    local script_table = self:_loadscripttable(key, group, scriptid)
    if not script_table and fallback then
        script_table = self:_loadscripttable(fallback, group, scriptid)
    end
    if not script_table and self._fallback then
        script_table = self:_loadscripttable(self._fallback, group, scriptid)
    end
    return script_table
end

function scriptengine:_loadscripttable(key, group, scriptid)
    local conf = self:loadscript(key)
    if conf and type(conf) == 'table' and conf[group] then
        return conf[group][scriptid]
    end
end

function scriptengine:dispose()
end

return scriptengine
