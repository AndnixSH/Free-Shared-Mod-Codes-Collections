local bullet = { timer = {}, sprite = {} }

-- speed distance duration position
function bullet:oncreate()

    self.prop.duration = self.prop.duration or 1000
    self._cur_time = 0
    self._stage = 1
    self.prop.speed_multi = self.prop.speed_multi or 0

    local duration = self.prop.duration
    local header = self.owner.body.header

    if not self.prop.speed then
        local distance = self.prop.distance

        if not distance and self.prop.position then
            distance = tsvector.distance(self.prop.position, self.owner.body.position)
        end

        if not distance then

            local target = self.prop.target

            if not target and self.prop.rangeid then
                local targets = self.owner.body.parent.caller.skill:range(self.prop.rangeid, self.owner)
                if #targets > 0 then
                    target = targets[1]
                end
            end

            if target then
                distance =  tsvector.distance(target.body.position, self.owner.body.position)
                header = (target.body.position - self.owner.body.position).normalized
            end
        end

        if distance then
            self.prop.speed = tsmath.ndiv(distance, duration)
        end
    end

    if self.prop.speed then
        self.owner.body:setvelocity(header:fmul(self.prop.speed))
    else
        global.debug.warning("回旋子弹speed为空")
    end
end

function bullet.timer:f1(time, tick)
    self.service.area:collidecheck(self)
    self._cur_time = self._cur_time + tick
    if self._stage == 2 and self._cur_time < self.prop.duration then
        self._cur_time = self.prop.duration
    end

    if self._cur_time >= self.prop.duration then
        if self._stage == 1 then
            self._stage = 2
            self.curcollide = nil
        end
        if self._cur_time >= self.prop.duration * 2 then
            self:destroy()
        end
    end

    local header = nil
    if self._stage == 1 then
        header = self.owner.body.header
        self.prop.speed = self.prop.speed + self.prop.speed_multi / (1000 / tick)
    else
        local body = self.owner.body
        header = (body.parent.body.position - body.position).normalized
        self.prop.speed = self.prop.speed - self.prop.speed_multi / (1000 / tick)
        if (self.last_header and tsvector.dot(header, self.last_header) < 0) then
            self:destroy()
        end
        self.last_header = header
    end
    self.owner.body:setvelocity(header:fmul(tsmath.max(self.prop.speed, 0)))
end

function bullet.sprite:onhitsprite(spritobj)
    if self._stage >= 2 and spritobj == self.owner.body.parent then -- 回手
        self:sendmessage(eventdef.sprite_collide, spritobj)
        self:destroy()
        return 
    end
    if spritobj.prop.camp == self.owner.prop.camp or spritobj.body.spritetype == self.owner.body.spritetype or self._dirty then return end
    if spritobj == self._last_hit and self._stage > 1 then return end   -- 提前返回时不伤害最后击中的人
    if spritobj ~= self.curcollide then
        self.curcollide = spritobj
        if self.prop.castid then
            local count = #self.prop.castid
            local castid = self._stage <= count and self.prop.castid[self._stage] or self.prop.castid[count]
            local parent = self.owner.body.parent
            if parent.caller.skill then
                parent.caller.skill:cast(castid, self.owner)
            end
        end
        self:sendmessage(eventdef.sprite_collide, spritobj)
        if self.prop.backrate and tsmath.random_match(1000 - self.prop.backrate) then 
            -- self._cur_time = self.prop.duration
            self._stage = 2
            self._last_hit = spritobj
        end
    end
end

function bullet:ondestroy()
    self.owner:destroy()
end

function bullet.sprite:onhitblock()
    -- self._cur_time = self.prop.duration
    self._stage = 2
end

return bullet