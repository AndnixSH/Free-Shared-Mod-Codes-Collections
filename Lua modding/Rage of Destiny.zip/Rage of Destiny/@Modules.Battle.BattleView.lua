local SkillHandle = require "Modules.Battle.Handle.SkillHandle"
local SystemHandle = require "Modules.Battle.Handle.SystemHandle"
local TopHandle = require "Modules.Battle.Handle.TopHandle"
local BossInfoHandle =require "Modules.Battle.Handle.BossInfoHandle"

local TouchRender = require "Core.Implement.UI.Class.TouchRender"
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"
local BattleProxy = require "Modules.Battle.BattleProxy"

local BattleBaseClass = require "Core.Implement.UI.Class.BattleBaseClass"
local BattleView = BattleView or LuaWidgetClass(BattleBaseClass)
function BattleView:__init()
end

function BattleView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Battle.BattleView",self.LoadEnd)
end

function BattleView:LoadEnd(obj)
	self:SetGo(obj)

	self.skillHandle = SkillHandle.New(self:GetChild(obj, "NewSkill"))
	self.systemHandle = SystemHandle.New(self:GetChild(obj, "SystemPanel"))
	self.topHandle = TopHandle.New(self:GetChild(obj, "TopPanel"), self:GetChild(obj, "Title"))
	self.bossInfoHandle = BossInfoHandle.New(self:GetChild(obj, "TopPanel/boss_attribute"))
	
	self.clickEffectList = {}
	self.touchRender = TouchRender.New()
	self.touchRender:SetClickCallback(function (position)
		self:OnTouchClick(position)
	end)
	
	self:SetStep(0)
end

function BattleView:OnOpen()
	self:RegisterBattleGlobalEvent()
	self:AutoRegister()
	self:UpdateInfo()

	self.touchRender:Start()

	self:OpenGMView()
end

function BattleView:OnClose()	
	self:UnRegisterBattleGlobalEvent()
	self:AutoUnRegister()
	self.skillHandle:Close()
	self.systemHandle:Close()
	self.bossInfoHandle:Close()
	
	self.touchRender:Stop()
    for _,effectitem in pairs(self.clickEffectList) do
        effectitem:Close()
	end	
	self.paramData=false
end

function BattleView:OnDestroy()
	self:UnRegisterBattleGlobalEvent()
	self:AutoUnRegister()
	self.skillHandle:Destroy()
	self.systemHandle:Destroy()
	self.bossInfoHandle:Destroy()

	self.touchRender:Stop()
    for _,effectitem in pairs(self.clickEffectList) do
        effectitem:Destroy()
    end
	self.clickEffectList = {}
	self.paramData=false
end

function BattleView:OpenGMView()
	if SystemConfig.is_gm then
		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.CheatGMBtnView)
		if view then
			view.gmTab = 3
			view:OpenView()
		end
	end
end

function BattleView:UpdateInfo()
	self.skillHandle:Open(self.paramData)
	self.systemHandle:Open()
	self.topHandle:Open(self.paramData)
	self.bossInfoHandle:Open()

	LuaLayout.Instance:OpenWidget(UIWidgetNameDef.BattleWordView)
end

function BattleView:GetClickEffect()
    for _,effectitem in pairs(self.clickEffectList) do
        if not effectitem:IsOpen() then
            return effectitem
        end    
    end
    local effect = UIEffectItem.New("UI_common_click" ,self.go)
    table.insert(self.clickEffectList, effect)
    return effect
end

--onclick
function BattleView:OnTouchClick(position)
	local SettingMenuProxy = require "Modules.SettingMenu.SettingMenuProxy"
	local SettingMenuDef = require "Modules.SettingMenu.SettingMenuDef"
	local state = SettingMenuProxy.Instance:GetSystemState(SettingMenuDef.Systerm_Option_Key[SettingMenuDef.Systerm_Option_Type.ClickEffect])
	if state == 1 then
		local effectitem = self:GetClickEffect()
		effectitem:SetLocalPosition(position.x, position.y, 0)
		effectitem:SetOrderLayer(9999)
		effectitem:Play()
	end
end

--notify
function BattleView.EvtNotify.Battle.data:StopGame(data, args)
	-- self.systemHandle:OnStopGame(args)
end	

function BattleView.EvtNotify.Battle.data:UserSkill(data, args)
	self.skillHandle:OnUserSkill(args)
end

function BattleView.event.game:gametime(time)
	self.topHandle:ShowCountDown(time)
end

function BattleView.event.game:gamesettle()
	BattleProxy.Instance:SpeedGame(1)
end

--怒气满才触发自动释放大招
function BattleView:RegisterAutoSkillBtn()
	self.systemHandle:RegisterAutoSkillBtn()
end

function BattleView.EvtNotify.Newbie.data:Newbie_State_Notify(data, args)
	local newbieid, state = args.newbieid, args.state
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	local NewbieProxy = require "Modules.Newbie.NewbieProxy"

	local _newbie_id, _newbie_step = NewbieProxy.Instance:GetNewbieIdAndStep(NewbieDef.AutoSkillTrigger)
	local _newbie_id2, _newbie_step2 = NewbieProxy.Instance:GetNewbieIdAndStep(NewbieDef.AutoBattleTrigger)
	if newbieid == NewbieDef.NewbieConst.ReleaseSkill then
	elseif newbieid == _newbie_id then
		self.systemHandle:SetAutoObjActive()
	elseif newbieid == _newbie_id2 then
		self.systemHandle:SetAutoBattleObjActive()
	end
end

return BattleView