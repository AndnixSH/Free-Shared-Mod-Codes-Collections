local FormationDef = require "Modules.Formation.FormationDef"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local FormationProxy = FormationProxy or BaseClass(BaseProxy)

function FormationProxy:__init()
	FormationProxy.Instance = self
	self:AddProto(20400, self.On20400)
	self:AddProto(20401, self.On20401)
	self:AddProto(20402, self.On20402)
	self:AddProto(20403, self.On20403)
	self:AddProto(20404, self.On20404)
	self:AddProto(20405, self.On20405)
	self:AddProto(20406, self.On20406)
	self:AddProto(20407, self.On20407)
	self.data = {}
	self.formation_infos = {}
	self.skipTips = false  --保存编队的时候是否要弹窗确认
end

function FormationProxy:__delete()
	self.data = {}
	self.formation_infos = {}
	self.skipTips = false  --保存编队的时候是否要弹窗确认
end

function FormationProxy:GetSkipTipsValue()
	return self.skipTips
end

function FormationProxy:SetSkipTipsValue(value)
	self.skipTips = value
end

function FormationProxy:Send20400()
	-- print("Send20400=====")
	self:SendMessage(20400)
end
function FormationProxy:On20400(decoder)
	local formation_infos = {}
	local count = decoder:Decode("I2")
	for i=1,count do
		local item = {}
		item.state = FormationDef.Formation_State.Exist
		item.type, item.index, item.name = decoder:Decode("I2I4s2") 
		local formations = decoder:DecodeList("I4I2", true)
		item.formation_count = #formations
		item.formations = {}
		for j,info in ipairs(formations) do
			item.formations[info[2]] = info[1]
		end
		table.insert(formation_infos, item)
	end
	formation_infos = self:ConstructionFormationInfo(formation_infos)
	self.formation_infos = formation_infos
	-- print("On20400=====", table.dump(formation_infos))
	self:ToNotify(self.data, FormationDef.Notify.Fromations_Info, {formation_infos = formation_infos})
end

--合并数据
function FormationProxy:ConstructionFormationInfo(formation_infos)
	local count = #formation_infos
	if count < 10 then
		for i = count+1, 10 do
			local item = {}
			item.state = (i == (count+1)) and FormationDef.Formation_State.CanEditor or FormationDef.Formation_State.NotEditor
			item.index, item.name = 0, LanguageManager.Instance:GetWord(FormationDef.LanguageKey.FormationKey1, i)
			item.formations = {}
			table.insert(formation_infos, item)
		end
	else
		if count < FormationDef.FormationParama.Max_Count then
			local item = {}
			item.state = FormationDef.Formation_State.CanEditor
			item.index, item.name = 0, LanguageManager.Instance:GetWord(FormationDef.LanguageKey.FormationKey1, count+1)
			item.formations = {}
			table.insert(formation_infos, item)
		end
	end
	return formation_infos
end

function FormationProxy:GetExitStateInfos()
	local infos = {}
	for i,v in ipairs(self.formation_infos) do
		if v.state == FormationDef.Formation_State.Exist then
			table.insert(infos, v)
		end
	end
	return infos
end

--是否有相同的编队
function FormationProxy:CheckSameHeroFormation(formation_count, formation_dic)
	local bsame = false
	for k,info in ipairs(self.formation_infos) do
		if info.state == FormationDef.Formation_State.Exist then
			if info.formation_count == formation_count then
				local formation = {}
				local _bsame = true
				for pos,herouid in pairs(formation_dic) do
					if not info.formations[pos] then
						_bsame = false
					elseif info.formations[pos] ~= herouid then
						_bsame = false
					end
				end
				if _bsame then
					bsame = true
					break
				end
			end
		end
	end
	return bsame
end

--添加编队
function FormationProxy:Send20401(name, formations)
	--print("Send20401=======", name, table.dump(formations))
	local encoder = NetEncoder.New()
	encoder:Encode("s2", name)
	encoder:EncodeList("I4I2", formations)

	self:SendMessage(20401, encoder)
end
function FormationProxy:On20401(decoder)
	local result = decoder:Decode("I2")
	-- print("On20401=====", result)
	if result == 0 then
		local item = {}
		item.state = FormationDef.Formation_State.Exist
		item.type, item.index, item.name = decoder:Decode("I2I4s2") 
		local formations = decoder:DecodeList("I4I2", true)
		-- print("On20401==", table.dump(formations))
		item.formation_count = #formations
		item.formations = {}
		for j,info in ipairs(formations) do
			item.formations[info[2]] = info[1]
		end

		local infos = self:GetExitStateInfos()
		table.insert(infos, item)
		self.formation_infos = self:ConstructionFormationInfo(infos)

		self:ToNotify(self.data, FormationDef.Notify.Formation_Add_Formation, {formation_infos = self.formation_infos})
	end
	GameLogicTools.ShowErrorCode(20401, result)
end

--改名
function FormationProxy:Send20402(index, name)
	-- print("Send20402=======", index, name)
	local encoder = NetEncoder.New()
	encoder:Encode("I4s2", index, name)
	self:SendMessage(20402, encoder)
end

function FormationProxy:On20402(decoder)
	local result = decoder:Decode("I2")
	if result == 0 then
		local index, name = decoder:Decode("I4s2")

		for i,info in ipairs(self.formation_infos) do
			if info.index == index then
				info.name = name
				break
			end
		end

		self:ToNotify(self.data, FormationDef.Notify.FormationName_Change, {index = index, name = name})
	end
	GameLogicTools.ShowErrorCode(20402, result)
end

--置顶
function FormationProxy:Send20403(index)
	-- print("Send20403=======", index)
	local encoder = NetEncoder.New()
	encoder:Encode("I4", index)
	self:SendMessage(20403, encoder)
end
function FormationProxy:On20403(decoder)
	local result = decoder:Decode("I2")
	-- print("On20403===", result)
	if result == 0 then
		local index = decoder:Decode("I4")
		-- print("On20403===", index)
		local idx
		for i,info in ipairs(self.formation_infos) do
			if info.index == index then
				idx = i
				break
			end
		end
		if idx then
			local info = self.formation_infos[idx]
			table.remove(self.formation_infos, idx)
			table.insert(self.formation_infos, 1, info)
		end

		self:ToNotify(self.data, FormationDef.Notify.Formation_Top_Change, {formation_infos = self.formation_infos})
	end
	GameLogicTools.ShowErrorCode(20403, result)
end

--删除
function FormationProxy:Send20404(index)
	-- print("Send20404====", index)
	local encoder = NetEncoder.New()
	encoder:Encode("I4", index)
	self:SendMessage(20404, encoder)
end
function FormationProxy:On20404(decoder)
	local result = decoder:Decode("I2")
	if result == 0 then
		local index = decoder:Decode("I4")

		local idx
		for i,info in ipairs(self.formation_infos) do
			if info.index == index then
				idx = i
				break
			end
		end
		table.remove(self.formation_infos, idx)	

		local infos = self:GetExitStateInfos()
		self.formation_infos = self:ConstructionFormationInfo(infos)

		self:ToNotify(self.data, FormationDef.Notify.Formation_Delete_Change, {formation_infos = self.formation_infos})
	end
	-- print("On20404===", result)
	GameLogicTools.ShowErrorCode(20404, result)
end

--修改编队
function FormationProxy:Send20405(index, formations)
	-- print("Send20405====", index, table.dump(formations))
	local encoder = NetEncoder.New()
	encoder:Encode("I4", index)
	encoder:EncodeList("I4I2", formations)

	self:SendMessage(20405, encoder)
end
function FormationProxy:On20405(decoder)
	local result = decoder:Decode("I2")
	-- print("On20405===", result)
	if result == 0 then
		local index = decoder:Decode("I4") 
		local formations = decoder:DecodeList("I4I2", true)
		local formation_count = #formations
		local _formations = {}
		for j,info in ipairs(formations) do
			_formations[info[2]] = info[1]
		end

		for i,_info in ipairs(self.formation_infos) do
			if _info.index == index then
				_info.formation_count = formation_count
				_info.formations = _formations
				break
			end
		end
		-- print("formations===", table.dump(formations))
		self:ToNotify(self.data, FormationDef.Notify.Formation_Info_Change, {index = index, formation_infos = _formations})
	end
	GameLogicTools.ShowErrorCode(20405, result)
end

function FormationProxy:Send20406()
	-- print("Send20406======")
	self:SendMessage(20406)
end

function FormationProxy:On20406(decoder)
	local heroinfos = {}
	local count = decoder:Decode("I2")
	for i=1, count do
		local heroinfo = {}
		heroinfo.herouid = decoder:Decode("I4")
		heroinfo.fromuid = decoder:Decode("I4")
		heroinfo.fromtype = decoder:Decode("I2")
		heroinfo.roleid = decoder:Decode("I4")
		heroinfo.level = decoder:Decode("I2")
		heroinfo.rank = decoder:Decode("I2")
		heroinfo.curskin = decoder:Decode("I4")
		local crystalLevel = decoder:Decode("I2")
		if crystalLevel >= heroinfo.level then
			local HeroProxy = require "Modules.Hero.HeroProxy"
			crystalLevel = HeroProxy.Instance:GetHeroMaxLevelByRoleId(crystalLevel, heroinfo.roleid)
			heroinfo.crystalLevel = crystalLevel
		else
			heroinfo.crystalLevel = nil
		end
		heroinfo.stance = decoder:Decode("I2")
		heroinfo.prop = decoder:DecodeList("I2I4", true)
		table.insert(heroinfos, heroinfo)
	end
	-- print("On20406======", table.dump(heroinfos))
	self:ToNotify(self.data, FormationDef.Notify.Formation_GetHeroInfos, {heroinfos = heroinfos})
end

--保存特殊编队{{roleid, stance}, {roleid, stance}}
function FormationProxy:Send20407(name, formations)
	local encoder = NetEncoder.New()
	encoder:Encode("s2", name)
	encoder:EncodeList("I4I2", formations)
	self:SendMessage(20407, encoder)
end

--特殊编队存的的roleid，站位
function FormationProxy:On20407(decoder)
	local result = decoder:Decode("I2")
	-- print("on20407======", result)
	if result == 0 then
		local item = {}
		item.state = FormationDef.Formation_State.Exist
		item.type, item.index, item.name = decoder:Decode("I2I4s2") 
		local formations = decoder:DecodeList("I4I2", true) --特殊编队存的的roleid，站位
		-- print("On20407==", table.dump(formations))
		item.formation_count = #formations
		item.formations = {}
		for j,info in ipairs(formations) do
			item.formations[info[2]] = info[1]
		end
		
		local infos = self:GetExitStateInfos()
		table.insert(infos, item)
		self.formation_infos = self:ConstructionFormationInfo(infos)

		self:ToNotify(self.data, FormationDef.Notify.Formation_Add_Formation, {formation_infos = self.formation_infos})
	end
	GameLogicTools.ShowErrorCode(20407, result)

end


function FormationProxy:GetFormationInfos()
	return self.formation_infos or {}
end

function FormationProxy:GetFormationEditorName()
	local formation_infos = self:GetFormationInfos()
	local name = ""
	for i,v in ipairs(formation_infos) do
		if v.state == FormationDef.Formation_State.CanEditor then
			name = v.name
			break
		end
	end
	return name
end

return FormationProxy