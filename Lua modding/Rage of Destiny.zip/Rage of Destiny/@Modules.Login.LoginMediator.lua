LoginMediator = LoginMediator or BaseClass(StdMediator)

function LoginMediator:__init()
	LoginMediator.Instance = self
end

function LoginMediator:OnEnterScence()	
end

function LoginMediator:OnEnterLoadingEnd()
end	

return LoginMediator