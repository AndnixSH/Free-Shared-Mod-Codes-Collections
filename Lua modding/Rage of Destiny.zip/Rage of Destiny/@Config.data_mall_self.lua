ConfigManager.InitConfig('data_mall_self', {
[1]={id=1,item_id=1,grid_type=1,gift_ids={1861.0}, buy_limit={{0,20,1},}, },
[2]={id=2,item_id=2,grid_type=1,gift_ids={1862.0}, buy_limit={{0,10,1},{11,20,2},}, },
[3]={id=3,item_id=3,grid_type=1,gift_ids={1863.0}, buy_limit={{0,10,1},{11,20,2},}, },
[4]={id=4,item_id=4,grid_type=1,gift_ids={1864.0}, buy_limit={{0,10,1},{11,20,2},}, },
[5]={id=5,item_id=5,grid_type=1,gift_ids={1865.0}, buy_limit={{0,10,1},{11,20,2},}, },
})