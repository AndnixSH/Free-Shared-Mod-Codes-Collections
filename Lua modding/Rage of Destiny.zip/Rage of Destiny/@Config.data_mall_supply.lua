ConfigManager.InitConfig('data_mall_supply', {
[1]={id=1,item_id=1,grid_type=1,gift_ids={2071.0}, buy_limit={{0,20,1},}, time=1,daily_goods={{601501,4},{601401,4},{601201,4},{701001,100},}, },
[2]={id=2,item_id=2,grid_type=1,gift_ids={2072.0}, buy_limit={{0,20,1},}, time=7,daily_goods={{601501,4},{601401,4},{601201,4},{701001,100},}, },
})