local NewbieManager = require "Modules.Newbie.NewbieManager"
local NewbieDef = require "Modules.Newbie.NewbieDef"
local httputil = require "Common.Util.httputil"

local NewbieProxy = NewbieProxy or BaseClass(BaseProxy)

function NewbieProxy:__init(name)
	NewbieProxy.Instance = self

	self:AddProto(18000, self.On18000) --引导列表
	self:AddProto(18001, self.On18001) --改变引导状态
	self:AddProto(18002, self.On18002) 

	self.manager = NewbieManager.New()	
	self.data = {}
	self.newbieList = {}
	self.data.binit = false

	self.data.checkMaskView = false

	self.data.agreementStatus = false --弹协议状态，每次进游戏调用一次,18000协议返回后
	self.data.showagreement = false --完成某个引导后（回到主界面）调用一次

	self.specailStatus = false --主界面不需要触发特殊引导30001
	self.data.specailNewbieData = {}

	self.cacheFinishId = {}--弱引导，出现及完成18002完成
end

function NewbieProxy:__delete()
	self.data.specailNewbieData = {}
	self.data.agreementStatus = false
	self.data.showagreement = false

	self.data.checkMaskView = false

	self.data = nil
	self.cacheFinishId = nil
end

--data Proto
function NewbieProxy:Send18000()
	self:SendMessage(18000)
end

function NewbieProxy:On18000(decoder)
	self.cacheFinishId = {}
	local newbieList = {}
	local count = decoder:Decode("I2")
	if count > 0 then 
		for i=1,count do
			local newbieid,state = decoder:Decode("I4I2") 
			newbieList[newbieid] = state 
		end
	end	

	self.newbieList = newbieList
	self:SetInitData(true)
	
	if self:GetCheckMaskViewStata() then
		local bOpen = self:CheckOpenNewbieViewCondition()
		if not bOpen then
			self:EnableNewbieMaskView(false)
		end
		self:SetCheckMaskViewStata(false)
		
		local NewbieManager = require "Modules.Newbie.NewbieManager"
		NewbieManager.Instance:TriggerNewbie()
	end

	--self:SetShowAgreementStatus()
	-- print("On18000==", table.dump(self.newbieList))
end

function NewbieProxy:Send18001(newbieid, state)
	if self.newbieList[newbieid] == state then return end

	--不用等服务器回调
	self.newbieList[newbieid] = state	
	
	local encoder = NetEncoder.New()
	encoder:Encode("I4I2", newbieid, state)
	self:SendMessage(18001, encoder)
end

function NewbieProxy:On18001(decoder)
	local result, newbieid, state = decoder:Decode("I2I4I2")
	self.newbieList[newbieid] = state

	-- print("On18001===", result, newbieid, state, table.dump(self.newbieList))
	self:ToNotify(self.data ,NewbieDef.NotifyDef.Newbie_State_Notify ,{newbieid = newbieid, state = state})

	if state == NewbieDef.State.Complete then
		self.manager:TriggerNewbie()
		--self:SetAgreementView(newbieid)
	end	
end

--完成某个引导后，每次进游戏都调用一次, 依赖新手完成状态
function NewbieProxy:SetShowAgreementStatus()
	--if self.data.agreementStatus == false then
    --    local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
    --    local NewbieDef = require "Modules.Newbie.NewbieDef"
    --    local _newbie_id, _step = self:GetNewbieIdAndStep(NewbieDef.TenDrawCard)
    --    for newbie_id, state in pairs(self.newbieList) do
    --    	if _newbie_id == newbie_id and state == NewbieDef.State.Complete then
    --    		IGGSdkProxy.Instance:InformKindly()
    --    		break
    --    	end
    --    end
	--
	--	self.data.agreementStatus = true
	--end
end

function NewbieProxy:GetNewbieFinishAgreement()
	return self.data.showagreement
end

function NewbieProxy:SetNewbieFinishAgreement(value)
	self.data.showagreement = value
end

--弹协议 完成某個引導的時候,回到主界面再調用一次
function NewbieProxy:SetAgreementView(newbie_id)
	--if newbie_id then
    --    local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
    --    --local NewbieDef = require "Modules.Newbie.NewbieDef"
    --    local SceneManager = require "Modules.Scene.SceneManager"
    --    local SceneDef = require "Modules.Scene.SceneDef"
    --    local _newbie_id, _step = self:GetNewbieIdAndStep(NewbieDef.TenDrawCard)
    --    if _newbie_id == newbie_id then
    --    	if SceneManager.Instance:GetCurSceneType() == SceneDef.SceneType.Main then
	--    	    IGGSdkProxy.Instance:InformKindly()
	--    	else
	--    		self.data.showagreement = true
    --    	end
    --    end
	--end
end

function NewbieProxy:Send18002(newbieid)
	if not self.cacheFinishId[newbieid] then
		self.cacheFinishId[newbieid] = true
		local encoder = NetEncoder.New()
		encoder:Encode("I4", newbieid)
		self:SendMessage(18002, encoder)
	end
end

function NewbieProxy:On18002(decoder)
	local result = decoder:Decode("I1")
end

--logic

function NewbieProxy:SetInitData(binit)
	if AppConfig.IsOpenNewbie == false then
		binit = false
	end
	self.data.binit = binit
end

function NewbieProxy:NewBieNotify(newbieid, step)
	self:ToNotify(self.data ,NewbieDef.NotifyDef.Newbie_Notify ,{newbieid = newbieid, step = step})
end

function NewbieProxy:CheckNewbie()
	for newbieid, state in pairs(self.newbieList) do
		if self:IsNeedGuild(newbieid) then
			self.manager:StartNewbie(newbieid)
		end	
	end
end

function NewbieProxy:GetNewbieState(newbieid)
	return self.newbieList[newbieid] or NewbieDef.State.None
end

--是否需要引导
function NewbieProxy:IsNeedGuild(newbieid)
	return self.newbieList[newbieid] ~= NewbieDef.State.Complete
end

function NewbieProxy:NewbieIsReady()
	return self.data.binit
end

--系统第一次打开 对话tips
function NewbieProxy:ShowFirstSpecailDialogView(newbieid)
	local bOpen = false
    local NewbieDef = require "Modules.Newbie.NewbieDef"
	if self.newbieList[newbieid] == nil then
		self:Send18001(newbieid, NewbieDef.State.Accept)
	end

	if self.newbieList[newbieid] == NewbieDef.State.Accept then
		local NewbieManager = require "Modules.Newbie.NewbieManager"
		bOpen = NewbieManager.Instance:ShowSpecialDialogView(newbieid, 1)
	end
	return bOpen
end

--特殊引導，只是显示界面，没有其他引导逻辑(在抽卡界面引导点击占星按钮)
function NewbieProxy:ShowCardStarWeakNewbie(btn, newbieid)
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	if self.newbieList[newbieid] ~= nil and
		(self.newbieList[newbieid] == NewbieDef.State.Accept or self.newbieList[newbieid] == NewbieDef.State.Complete) then
		return
	end

	local newbie_cfg = self:GetNewbieTaskConfig()
	if newbie_cfg.weakguide[2041] then
		local _cfg = newbie_cfg.weakguide[2041]
		if RoleInfoModel.mainlineid >= _cfg.parama.mainlineid then
			local parama = {}
			parama.selectObj = btn.gameObject
			parama.cfg = _cfg
			parama.newbieid = newbieid
			parama.bForce = false
			local NewbieSpecialWeakView = require "Modules.Newbie.NewbieSpecialWeakView"
			NewbieSpecialWeakView.ShowView(parama)
		end
	end
end
--特殊引導，只是显示界面，没有其他引导逻辑(占星引导点击占星英雄)
function NewbieProxy:ShowCardStarHeroWeakNewbie(btn, newbieid)
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	local newbie_cfg = self:GetNewbieTaskConfig()
	if newbie_cfg.weakguide[2042] then
		local _cfg = newbie_cfg.weakguide[2042]
		if RoleInfoModel.mainlineid >= _cfg.parama.mainlineid then
			local parama = {}
			parama.selectObj = btn.gameObject
			parama.cfg = _cfg
			parama.newbieid = newbieid
			parama.bForce = false
			local NewbieSpecialWeakView = require "Modules.Newbie.NewbieSpecialWeakView"
			NewbieSpecialWeakView.ShowView(parama)
		end
	end
end
--特殊引導，只是显示界面，没有其他引导逻辑(迷宫引导结束后需要加一个指向战役的引导)
function NewbieProxy:ShowMazeCompleteWeakNewbie(btn)
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	local newbie_cfg = self:GetNewbieTaskConfig()
	if newbie_cfg.weakguide[2043] then
		local _cfg = newbie_cfg.weakguide[2043]
		local parama = {}
		parama.selectObj = btn.gameObject
		parama.cfg = _cfg
		parama.newbieid = nil
		parama.bForce = false
		local NewbieSpecialWeakView = require "Modules.Newbie.NewbieSpecialWeakView"
		NewbieSpecialWeakView.ShowView(parama)
	end
end

--是否弹等级提升界面 等主线 1-4 新手跑完才弹
function NewbieProxy:CheckShowAccountUpgradeView()
	local bOpen = true
	local mainlineid = RoleInfoModel.mainlineid
	bOpen = mainlineid >= 18 and true or false
	local newbieids = {
		[10015] = {1},
		[10016] = {1},
		[10017] = {1},
		[10018] = {1},
		[10019] = {1},
		[10020] = {1},
	}
    local NewbieDef = require "Modules.Newbie.NewbieDef"
    local NewbieManager = require "Modules.Newbie.NewbieManager"
    local cur_newbie_id, cur_newbie_step = NewbieManager.Instance:GetCurNewbieId()
	for newbieid,steps in pairs(newbieids) do
		for i,step in ipairs(steps) do
			if cur_newbie_id == newbieid and cur_newbie_step == step then
				bOpen = false
				break
			end
		end
	end
	return bOpen
end

function NewbieProxy:GetNewbieTaskConfig()
	local cfg = ConfigManager.GetConfig("data_newbie")
	return cfg
end

function NewbieProxy:GetNewbieTaskCfgById(id)
	local cfg = self:GetNewbieTaskConfig()
	return cfg.newbie[id]
end

--普通新手对话框
function NewbieProxy:GetNormalDialogTipsById(Id)
	local cfg = self:GetNewbieTaskConfig()
	return cfg.normal_dialog[Id]
end


--巨龙巢穴Tips配置
function NewbieProxy:GetMazeNewbieTipsConfig()
	local cfg = self:GetNewbieTaskConfig()
	return cfg.mazenewbie_tips
end

--迷宫对话
function NewbieProxy:GetMazeNewbieTipsIdConfig(id)
	local cfg = self:GetMazeNewbieTipsConfig()
	return cfg[id]
end

--迷宫手指
function NewbieProxy:GetMazeFingerConfig(id)
	local cfg = self:GetNewbieTaskConfig()
	local fingercfg = cfg.mazenewbie_finger
	return fingercfg[id]
end

--迷宫副本对话tips
function NewbieProxy:GetDialogConfig(args)
	local cfg = self:GetNewbieTaskConfig()
	local infos = {}
	for i,value in ipairs(args) do
		local step = math.floor(value)
		--print("step============", step)
		local info = self:GetMazeNewbieTipsIdConfig(step)
		if info then
			table.insert(infos, info)
		end
	end
	return infos
end

function NewbieProxy:SendMazeClickScreenNotify()
	self:ToNotify(self.data, NewbieDef.NotifyDef.MazeClickScreenNotify)
end

-----------------------主线失败后返回主界面引导 start ------------------
--回到主界面是从主线胜利回来还是失败回来
function NewbieProxy:SetSpecialStatus(value)
	self.specailStatus = value
end

function NewbieProxy:SetSpecialStepAdd()
	if self.special_step then
		self.special_step = self.special_step + 1
	end
end

function NewbieProxy:GetSpecialStatus(newbieid)
	if newbieid == NewbieDef.NewbieConst.MainlineFailBack then
		local CampaignProxy = require "Modules.Campaign.CampaignProxy"
		local cfg = CampaignProxy.Instance:GetMainLineCfgById(RoleInfoModel.mainlineid)
		if cfg.chapter > 2 then
			return false
		end
		return self.specailStatus
	elseif newbieid == NewbieDef.NewbieConst.CardPordSpecial then
		local _newbieid_cfg = self:GetNewbieTaskCfgById(newbieid)
		if _newbieid_cfg and _newbieid_cfg[1] then
			local NewbieManager= require "Modules.Newbie.NewbieManager"
			local bopen = NewbieManager.Instance:CheckStartCondition(newbieid, 1)
			return bopen
		end
		return false
	end

	return false
end

--主动触发某一步
function NewbieProxy:TriggerSpecailNewbie(newbieid, step)
	self:StartSpecialNewbie(nil, nil, newbieid, step)
end

function NewbieProxy:ClearSpecailNewbieData()
	if self.data then
		self.data.specailNewbieData = {}
	end
end

function NewbieProxy:StartSpecialNewbie(bRegister, btn, newbieid, step)
	local bOpen = self:GetSpecialStatus(newbieid)
	if not bOpen then
		return
	end

	if newbieid == NewbieDef.NewbieConst.CardPordSpecial then
		if step == 1 then
			if self.newbieList[newbieid] == NewbieDef.State.Complete then
				return false
			else
				self:Send18001(NewbieDef.NewbieConst.CardPordSpecial, NewbieDef.State.Complete)
			end
		end
	end

	local NewbieManager = require "Modules.Newbie.NewbieManager"
	local NewbieDef = require "Modules.Newbie.NewbieDef"

	if not bRegister then
		if self.data.specailNewbieData[newbieid] and 
			self.data.specailNewbieData[newbieid][step] then
		else
			return
		end
	else
		if not self.data.specailNewbieData[newbieid] then
			self.data.specailNewbieData[newbieid] = {}
		end
		if not self.data.specailNewbieData[newbieid][step] then
			self.data.specailNewbieData[newbieid][step] = {}
		end
		self.data.specailNewbieData[newbieid][step] = {newbieid, step, btn}
	end

	if not self.special_step then
		self.special_step = 1
	end

	if step > self.special_step then
		return
	end

	LuaLayout.Instance:CloseWidget(UIWidgetNameDef.NewbieSpecialWeakView)

	local _newbie_id, _step, _btn
	local infos = self.data.specailNewbieData[newbieid]

	if infos and infos[self.special_step] then
		_newbie_id, _step, _btn = infos[self.special_step][1], infos[self.special_step][2], infos[self.special_step][3]
	end

	if not _newbie_id or not _step then
		return
	end

	local _newbie_cfg, _type = NewbieManager.Instance:GetNewbieStepConfig(_newbie_id, _step)
	local view_name = ""
	if _type == NewbieDef.NewbieType.Weakguide then
		view_name = _newbie_cfg.view
	elseif _type == NewbieDef.NewbieType.Dialog then
		view_name = _newbie_cfg[1].view
	end

	local _view = LuaLayout.Instance:GetWidget(view_name)
	if _view and _view:IsOpen() then
			
		if _type == NewbieDef.NewbieType.Weakguide and _btn then
			local parama = {}
			parama.selectObj = _btn.gameObject
			parama.cfg = _newbie_cfg
			parama.newbieid = _newbie_id
			parama.bForce = false
			local NewbieSpecialWeakView = require "Modules.Newbie.NewbieSpecialWeakView"
			NewbieSpecialWeakView.ShowView(parama)
			
		elseif _type == NewbieDef.NewbieType.Dialog then
			local NewbieNormalNpcDialogView = require "Modules.Newbie.NewbieNormalNpcDialogView"
			local parama = {}
			parama.infos = _newbie_cfg
			parama.callback = function()
				self:SetSpecialStepAdd()
				self:TriggerSpecailNewbie(newbieid, 2)
			end
			NewbieNormalNpcDialogView.ShowView(parama)
		end
	end

	local _newbieid_cfg = self:GetNewbieTaskCfgById(newbieid)

	if step == #_newbieid_cfg then
		self:SetSpecialStatus(false)
		self.data.specailNewbieData = {}
		self.special_step = nil
	end

	return
end




-----------------------主线失败后返回主界面引导 end ------------------

--主线结算后是否需要返回主界面进行其他引导(需要停掉自动推图以及下一关按钮)
function NewbieProxy:NewbieBackMainView(mainlineid)
	local bBack = false
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	if NewbieDef.NewbieMainlineId[mainlineid] then
		bBack = true
	end
	return bBack
end

--活动章节奖励引导（活动系统判断是否需要跳转到冲关奖励页签
function NewbieProxy:BActivityNewbie()
	local NewbieManager = require "Modules.Newbie.NewbieManager"
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	local cur_newbie, cur_step = NewbieManager.Instance:GetCurNewbieIdStep()
	local bActive = false
	for _newbie_id, _step in pairs(NewbieDef.ActivityAwardBtn) do
		if _newbie_id == cur_newbie and cur_step == _step then
			bActive = true
			break
		end
	end
	return bActive
end

--NewbieDef
function NewbieProxy:GetNewbieIdAndStep(cfgDef)
	local _newbieid, _step
	for id, step in pairs(cfgDef) do
		_newbieid, _step = id, step
	end
	return _newbieid, _step
end

--下一章 按鈕引導判斷
function NewbieProxy:GetNewbiePassToMainlineid()
	local CampaignProxy = require "Modules.Campaign.CampaignProxy"
	local mainline = CampaignProxy.Instance:GetPassMainlineid()
	return mainline
end

--普通对话框引导关闭
function NewbieProxy:NormalNpcDialogCloseNotify(newbieid)
	--print("NormalNpcDialogCloseNotify=====", newbieid)
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	self:ToNotify(self.data, NewbieDef.NotifyDef.NormalNpcDialogCloseNotify, {newbieid = newbieid})
end

--是否完成
function NewbieProxy:NewbieIsComplete(newbieid)
	local bComplete = false
	if self.newbieList[newbieid] ~= nil and 
		self.newbieList[newbieid] == NewbieDef.State.Complete then
			bComplete = true
	end
	return bComplete
end

function NewbieProxy:GetCheckMaskViewStata()
	return self.data.checkMaskView
end

function NewbieProxy:SetCheckMaskViewStata(value)
	self.data.checkMaskView = value
end

--主界面将要触发的引导id
function NewbieProxy:BTriggerNewbie()
	local trigger_id = nil
	for newbieid, lastNewbies in pairs(NewbieDef.TriggerDef) do
		if self.newbieList[newbieid] ~= NewbieDef.State.Complete then
			local bTrigger = true
			for _,lastid in pairs(lastNewbies) do
				if self.newbieList[lastid] ~= NewbieDef.State.Complete then
					bTrigger = false
				end 	
			end
			
			if bTrigger then
				trigger_id = newbieid
			end	
		end	
	end

	local check_list = {}
	if trigger_id then
		table.insert(check_list, trigger_id)
	end

	for newbie_id,state in pairs(self.newbieList) do
		if state == NewbieDef.State.Accept then
			table.insert(check_list, newbie_id)
		end
	end

	return check_list
end

function NewbieProxy:CheckOpenNewbieViewCondition()
	local NewbieManager = require "Modules.Newbie.NewbieManager"
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	local check_list = self:BTriggerNewbie()
	local bOpenNewBie = false
	for i,newbie_id in ipairs(check_list) do
		local bStart = NewbieManager.Instance:CheckStartCondition(newbie_id, 1)
		if NewbieDef.MaskNewbieId[newbie_id] and bStart then
			bOpenNewBie = bStart
		end
	end
	if bOpenNewBie then
		self:EnableNewbieMaskView(true)
	end
	return bOpenNewBie
end

--引导遮罩
function NewbieProxy:EnableNewbieMaskView(active)
	if active then
		LuaLayout.Instance:OpenWidget(UIWidgetNameDef.NewMaskView)
	else
		LuaLayout.Instance:CloseWidget(UIWidgetNameDef.NewMaskView)
	end
end

--主场景是否需要打开新手遮罩
function NewbieProxy:OpenNewbieMask()
	if self:NewbieIsReady() then
		self:CheckOpenNewbieViewCondition()
	else
		self:EnableNewbieMaskView(true)
		self:SetCheckMaskViewStata(true)
	end
end

function NewbieProxy:SendPoint(newbie_info_id)
	local LoginProxy = require "Modules.Login.LoginProxy"
	local rapidjson = require "rapidjson"

	local t = {
		["uin"] = RoleInfoModel.uid,
		["tradeuin"] = RoleInfoModel.player_id,
		["package"] = LoginProxy.Instance:get_package_id(),
		["part"] = RoleInfoModel.server_id,
		["newbie_id"] = newbie_info_id
	}

	local p = {
		["api"] = "NewbiePoint",
		["func"] = "index",
		["params"] = rapidjson.encode(t),
		["time"] = os.time()
	}
	local LoginDef = require "Modules.Login.LoginDef"
	local baseUrl = SystemConfig.Router
	local url = baseUrl .. LoginDef.api.gameapi

	local params = {}
	params.token = LoginProxy.Instance:cms_encrypt(rapidjson.encode(p))
	httputil.post(url, params)
end

return NewbieProxy
