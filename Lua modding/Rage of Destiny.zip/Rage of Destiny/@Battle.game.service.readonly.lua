-- 只读属性
local readonly = {}

local function error_readonly_handler(t, k, v)
    error(string.format("attempt to update a read-only table [ key = %s, value = %s ]", k, v))
end

local function readonlytable(table)
    return setmetatable({}, { __index = table, __newindex = error_readonly_handler, __metatable = false });
end

function readonly:reader(uid)
    local obj = global.service.pool:get_obj(uid)
    if obj then

        local proxy = { typeid = obj.typeid, uid = uid }

        if obj.static then
            proxy.static = obj.static
        end

        if obj.prop then
            proxy.prop = readonlytable(obj.prop)
        end

        if obj.attr then
            proxy.attr = readonlytable(obj.attr)
        end

        if obj.body then
            proxy.body = readonlytable(obj.body)
        end

        if obj.record then
            proxy.record = readonlytable(obj.record)
        end

        if obj.caller then
            proxy.caller = readonlytable(obj.caller)
        end

        return proxy
    else
        global.debug.warning("readonly can not find obj " .. uid)
    end

end

function readonly:dispose()
end


return readonly