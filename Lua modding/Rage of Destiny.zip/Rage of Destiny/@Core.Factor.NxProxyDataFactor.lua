NxProxyDataBase = NxProxyDataBase or BaseClass()
NxProxyDataSetFactor = NxProxyDataSetFactor or BaseClass(NxProxyDataBase)
NxProxyDataEvtFactor = NxProxyDataEvtFactor or BaseClass(NxProxyDataBase)



local _FakeObjs = _FakeObjs or {}
local _ObjectEvtProp = _ObjectEvtProp or {}
local _ObjectEvtNotify = _ObjectEvtNotify or {}
local _ObjectEvtIndex = _ObjectEvtIndex or {}


function NxProxyDataBase:__init()
end

function NxProxyDataBase:__delete()
end


function NxProxyDataBase:TransProxyData(data)
	if nil ==_FakeObjs[data] then

			
		_FakeObjs[data] = true

		--printTable(data)
		--move data

		local obj = {}
		--print(data)
		for key, value in pairs(data) do
			obj[key] = value
			data[key] = nil
		end
		--data = {}
		data._obj = obj


		setmetatable(data, 
		{
			__newindex =
				function(t,k,v) 
					--print("hello")

					local oldvalue = obj[k]
					obj[k] = v

					if _ObjectEvtProp[t] then
						if _ObjectEvtProp[t][k] then
							local list = _ObjectEvtProp[t][k]
							if list then
								for key, value in pairs(list) do
									key:ReplaceLuaData(t, k, oldvalue, obj[k],  value)
								end
							end		
						end
					end


					if _ObjectEvtIndex[t] then

						local list = _ObjectEvtIndex[t]
						if list then

							for key, value in pairs(list) do
									--key:ReplaceLuaData(t, k, obj[t], v,  value)
									--print(t)
								if nil == obj[k] and nil ~= v then
									key:OnAddLuaIndex(t, k, v, value)
								end

								if nil == v and nil ~= obj[k] then
									--(data, index, nxdata, strContext)
									key:OnDelLuaIndex(t, k, v, value)
								end
							end
						end
					end


					--obj[k] = v

				end
			, 
			__index =
				function(t,k)
					-- print("function(t,k)")
					return obj[k]
				end
		})
	end
end

function NxProxyDataBase:RetoreFakeObj(data)
	-- body
end




------------------------------------------------------------------

function NxProxyDataSetFactor:__init()
end

function NxProxyDataSetFactor:__delete()
end



function NxProxyDataSetFactor:ToNotify(data, strEvent, args)
	self:TransProxyData(data)
	if _ObjectEvtNotify[data] then
		if _ObjectEvtNotify[data][strEvent] then
			local list = _ObjectEvtNotify[data][strEvent]
			if list then
				for key, value in pairs(list) do
					key:OnLuaNotify(data, strEvent, args, value)
				end
			end		
		end
	end
	if _ObjectEvtProp[data] then
		if _ObjectEvtProp[data][strEvent] then
			local list = _ObjectEvtProp[data][strEvent]
			if list then
				for key, value in pairs(list) do
					key:OnLuaData(data, strEvent, args, value)
				end
			end		
		end
	end
end

------------------------------------------------------------------

function NxProxyDataEvtFactor:__init()
end

function NxProxyDataEvtFactor:__delete()
end

function NxProxyDataEvtFactor:RegisterLuaData(data, strProtery, strContext, bScan)

	if nil == data or nil == strProtery then
		return nil
	end

	self:TransProxyData(data)

	if nil == _ObjectEvtProp[data] then
		_ObjectEvtProp[data] = {}
	end

	if nil == _ObjectEvtProp[data][strProtery] then
		_ObjectEvtProp[data][strProtery] = {}
	end

	if nil == _ObjectEvtProp[data][strProtery][self] then
		if strContext then
			_ObjectEvtProp[data][strProtery][self] = strContext
		else
			_ObjectEvtProp[data][strProtery][self] = true
		end
	end

	if bScan then
		self:ReplaceLuaData(data, strProtery, data[strProtery], data[strProtery], strContext)
	end
	
end



function NxProxyDataEvtFactor:UnRegisterLuaData(data, strProtery)


	if nil == data or nil == strProtery then
		return nil
	end

	if nil ~= _ObjectEvtProp[data] then
		if nil ~= _ObjectEvtProp[data][strProtery] then
			if nil ~= _ObjectEvtProp[data][strProtery][self] then
				 _ObjectEvtProp[data][strProtery][self] = nil
				 
			end
		end
	end
end



function NxProxyDataEvtFactor:RegisterLuaNotify(data, strEvent, strContext, bScan)

	if nil == data or nil == strEvent then
		return nil
	end

	self:TransProxyData(data)

	if nil == _ObjectEvtNotify[data] then
		_ObjectEvtNotify[data] = {}
	end

	if nil == _ObjectEvtNotify[data][strEvent] then

		_ObjectEvtNotify[data][strEvent] = {}
	end
	if nil == _ObjectEvtNotify[data][strEvent][self] then
		if strContext then
			_ObjectEvtNotify[data][strEvent][self] = strContext
		else
			_ObjectEvtNotify[data][strEvent][self] = true
		end
	end

	if bScan then
		--OnLuaDataNotify(data, strEvent, args, strContext)
		self:OnLuaDataNotify(data, strEvent, nil, strContext)
	end
end

function NxProxyDataEvtFactor:UnRegisterLuaNotify(data, strEvent)
	if nil == data or nil == strEvent then
		return nil
	end
	-- print("====================", data, strEvent, _ObjectEvtNotify[data], _ObjectEvtNotify[data][strEvent], _ObjectEvtNotify[data][strEvent][self])
	if nil ~= _ObjectEvtNotify[data] then
		if nil ~= _ObjectEvtNotify[data][strEvent] then
			if nil ~= _ObjectEvtNotify[data][strEvent][self] then
				 _ObjectEvtNotify[data][strEvent][self] = nil
			end
		end
	end
end

function NxProxyDataEvtFactor:RegisterLuaIndex(data, strContext, bScan)

	if nil == data then
		return nil
	end

	self:TransProxyData(data)

	if nil == _ObjectEvtIndex[data] then
		_ObjectEvtIndex[data] = {}
	end

	if nil == _ObjectEvtIndex[data][self] then
		if strContext then
			_ObjectEvtIndex[data][self] = strContext
		else
			_ObjectEvtIndex[data][self] = true
		end
	end

end

function NxProxyDataEvtFactor:UnRegisterLuaIndex(nxlistdata)
	if nil == data then
		return nil
	end

	if nil ~= _ObjectEvtIndex[data] then
		if nil ~= _ObjectEvtIndex[data][self] then
			_ObjectEvtIndex[data][self] = nil
		end
	end
end



function NxProxyDataEvtFactor:ReplaceLuaData(data, strProtery, fromValue, toValue, strContext)
	
end

function NxProxyDataEvtFactor:OnLuaDataNotify(data, strEvent, args, strContext)
end


function NxProxyDataEvtFactor:OnAddLuaIndex(data, index, indata, strContext)
	-- body
end

function NxProxyDataEvtFactor:OnDelLuaIndex(data, index, indata, strContext)
	-- body
end