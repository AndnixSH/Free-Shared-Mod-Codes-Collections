local MobilizeMediator = MobilizeMediator or BaseClass(StdMediator)
local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"
local MobilizeProxy = require "Modules.Mobilize.MobilizeProxy"
function MobilizeMediator:OnEnterLoadingEnd()		
	
end
function MobilizeMediator:OnEnterScenceEnd()

    if SceneManager.Instance.sceneType == SceneDef.SceneType.Main then
        self:DelayExecute(function()
        
            MobilizeProxy.Instance:Send65000()
        end)
    end
    
end
function MobilizeMediator:OnEnterScenceFirst()

    MobilizeProxy.Instance:Send65000()
    -- self:DelayExecute(function()
        
    --     MobilizeProxy.Instance:Send65000()
    -- end)
end

return MobilizeMediator