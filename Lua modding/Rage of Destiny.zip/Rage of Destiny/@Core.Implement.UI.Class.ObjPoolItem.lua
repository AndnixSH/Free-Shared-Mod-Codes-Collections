local ObjPoolItem = ObjPoolItem or BaseClass(GameObjFactor)

function ObjPoolItem:__init(go)
	self.go = go
	self:Load(go)
end

function ObjPoolItem:Load(go)
end

function ObjPoolItem:SetData()
	self.go:SetActive(true)
end	 

function ObjPoolItem:Close()
	self.go:SetActive(false)
end

function ObjPoolItem:Destroy()
end

function ObjPoolItem:Release()	
end

function ObjPoolItem:ScaleTween(obj)
	local defaultVec = Vector3.New(0.8, 0.8, 0.8)
	if obj then
		obj.transform.localScale = defaultVec
		local scaleSeq = DOTween.Sequence()
		local tween1 = obj.transform:DOScale(Vector3.New(1.5, 1.5, 1.5), 0.2)
		local tween2 = obj.transform:DOScale(Vector3.one, 0.2)
		tween1:SetEase(Ease.InBack)
		tween2:SetEase(Ease.OutBack)
		
		scaleSeq:Append(tween1)
		scaleSeq:Append(tween2)
		scaleSeq:AppendCallback(function()
		end)
		return scaleSeq
	end
end

return ObjPoolItem