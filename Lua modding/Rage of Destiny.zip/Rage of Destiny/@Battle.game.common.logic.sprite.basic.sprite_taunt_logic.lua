local logic = { call = service.call(calldef.taunt)}

function logic:oncreate()
    self._taunt_list = {}  -- 被嘲讽列表
end

function logic.call:add(sprite)
    for _, _sprite in ipairs(self._taunt_list) do
        if sprite == _sprite then
            return
        end
    end
    table.insert(self._taunt_list, sprite)
end

function logic.call:get()
    return self._taunt_list
end

function logic.call:remove(sprite)
    
    for i = #self._taunt_list, 1, -1 do
        if self._taunt_list[i] == sprite then
            table.remove(self._taunt_list, i)
        end
    end

end

return logic