local cs_coroutine = require "First.Util.cs_coroutine"
local UnityWebRequest = CS.UnityEngine.Networking.UnityWebRequest
local Application = CS.UnityEngine.Application
local NetworkReachability = CS.UnityEngine.NetworkReachability
local RuntimePlatform = CS.UnityEngine.RuntimePlatform
local FileUtils = CS.LJY.NX.FileUtils
local AssetBundle = CS.UnityEngine.AssetBundle
--local AssetBundleCreateRequest = CS.UnityEngine.AssetBundleCreateRequest
local isEditor = Application.isEditor

local Uri = CS.System.Uri

local UpdateMananger = {}
--[[
	update param
]]
local _versionFileName = "version"
local _buildInfoFileName = "buildinfo"

local _localVersion = 0
local _remoteVersion = 0

local _remoteVersionData = nil
local _remoteBuildInfoData = nil

local _localBuildInfo = nil
local _remoteBuildInfo = nil
local _downloadBuildInfo = nil


local _completefunc = nil
--[[  
	update func 
]]
local function _GetRealAbName(resName)
	if string.find(resName, ".ab") then
		return resName
	else
		return resName..".ab"
	end	
end

local function _GetRemoteResUrl(resName)
	resName = _GetRealAbName(resName)
	local abpath = string.format("%s%s?%s", SystemConfig.RemoteResPath, string.lower(resName), os.time())
	return abpath
end

local function _GetLoaclResUrl(resName)
	resName = _GetRealAbName(resName)
	local abpath = string.format("%s/%s", SystemConfig.OutsideResPath, string.lower(resName))
	if not FileUtils.FileIsExists(abpath) then
        abpath = string.format("%s/%s", Application.streamingAssetsPath, string.lower(resName))
	end	
	if isEditor and not FileUtils.FileIsExists(abpath) then
		print("--------not exist----------",abpath)
		return ""
	end
	return Uri(abpath)
end

local function _LoadLoaclVersionInfo()
	_localVersion = 0
	SystemConfig.ResVersion = 0
	local abUrl = _GetLoaclResUrl(_versionFileName)

	if abUrl ~= "" then
		return cs_coroutine.start(function()			
			local www = UnityWebRequest.Get(abUrl)
			coroutine.yield(www:SendWebRequest())

			if www.isNetworkError or www.isHttpError then
				error(string.format("get error: %s ---- url=%s", www.error, abUrl))
	            
	            local LanguageUtil = require "First.Util.LanguageUtil"
	            local ConfirmView = require "First.Update.View.ConfirmView"    
	            local content = string.format(LanguageUtil.GetWord("confirm_tips_1001"))
	            ConfirmView.Show(content, function()
	                Application.Quit()
	            end, nil, nil, "Common_1004", 1, "Common_1006")

			else
				_remoteVersionData = www.downloadHandler.data
				local bundle = AssetBundle.LoadFromMemory(www.downloadHandler.data)
				if bundle then
					local objs = bundle:LoadAllAssets()
					bundle:Unload(false)
					_localVersion = tonumber(objs[0].text)
					SystemConfig.ResVersion = _localVersion
				end	
			end
			www:Dispose()
		end)
	else
		return nil
	end
end

local function _LoadRemoteVersionInfo()
	local abUrl = _GetRemoteResUrl(_versionFileName)

	return cs_coroutine.start(function()
			local www = UnityWebRequest.Get(abUrl)
			coroutine.yield(www:SendWebRequest())

			if www.isNetworkError or www.isHttpError then
				local LanguageUtil = require "First.Util.LanguageUtil"
				local ConfirmView = require "First.Update.View.ConfirmView"
				local content = string.format(LanguageUtil.GetWord("confirm_tips_1001"))
				ConfirmView.Show(content, function()
					Application.Quit()
				end, nil, nil, "Common_1004", 1, "Common_1006")
				error(string.format("get error: %s ---- url=%s", www.error, abUrl))
			else
				_remoteVersionData = www.downloadHandler.data
				local bundle = AssetBundle.LoadFromMemory(www.downloadHandler.data)
				if bundle then
					local objs = bundle:LoadAllAssets()
					bundle:Unload(false)
					_remoteVersion = tonumber(objs[0].text)
				end	
			end
			www:Dispose()
		end)
end

local function _GetBuildInfo(text, buildinfos)
	if text and buildinfos then
		local lines = string.split(text, "\n")		
		for _, line in ipairs(lines) do
			local info = string.split(line, "|")
			if info and #info == 4 then
				buildinfos[info[1]] = {name = info[1], hashCode = info[2], md5 = info[3], size = tonumber(info[4])}
			end	
		end
	end	
end

local function _LoadLoaclBuildInfo()
	_localBuildInfo = {}
	local abUrl = _GetLoaclResUrl(_buildInfoFileName)
	if abUrl ~= "" then
		return cs_coroutine.start(function()
			local www = UnityWebRequest.Get(abUrl)
			coroutine.yield(www:SendWebRequest())

			if www.isNetworkError or www.isHttpError then
				error(string.format("get error: %s ---- url=%s", www.error, abUrl))
			else
				local bundle = AssetBundle.LoadFromMemory(www.downloadHandler.data)
				if bundle then
					local objs = bundle:LoadAllAssets()
					bundle:Unload(false)					
					_GetBuildInfo(tostring(objs[0].text), _localBuildInfo)
				end	
			end
			www:Dispose()			
		end)
	else
		return nil
	end
		
end

local function _LoadRemoteBuildInfo()
	local remoteBuildInfoFileName = string.format("v%s/%s", _remoteVersion, _buildInfoFileName);
	local abUrl = _GetRemoteResUrl(remoteBuildInfoFileName)
	return cs_coroutine.start( function()			
			local www = UnityWebRequest.Get(abUrl)
			coroutine.yield(www:SendWebRequest())

			if www.isNetworkError or www.isHttpError then
				error(string.format("get error: %s ---- url=%s", www.error, abUrl))                   
			else
				_remoteBuildInfoData = www.downloadHandler.data
				local bundle = AssetBundle.LoadFromMemory(www.downloadHandler.data)
				if bundle then
					local objs = bundle:LoadAllAssets()
					bundle:Unload(false)
					_remoteBuildInfo = {}
					_GetBuildInfo(tostring(objs[0].text), _remoteBuildInfo)
				end	
			end
			www:Dispose()
		end)	
end

--[[  
	update start 
]]
function UpdateMananger.Init()
    if SystemConfig.AppUpdate ~= true then
        UpdateMananger.UpdateEnd(false)
        return
    end

	if not SystemConfig.RemoteResPath then
		print("RemoteResPath is nil")
		return
	end

	-- if Application.internetReachability == NetworkReachability.NotReachable then
	-- 	print("NotReachable !!!", Application.internetReachability)
	-- 	return
	-- end	

	return cs_coroutine.start(function()
			coroutine.yield(_LoadLoaclVersionInfo())
			coroutine.yield(_LoadRemoteVersionInfo())
			print(string.format("serverVersion = %s, localVersion = %s", _remoteVersion, _localVersion));
			if _localVersion < _remoteVersion then
				coroutine.yield(_LoadLoaclBuildInfo())
				coroutine.yield(_LoadRemoteBuildInfo())
				local size = UpdateMananger.CreateDownloadList()
				local ConfirmView = require "First.Update.View.ConfirmView"
				local str= "Sign_in_1009"--游戏有%.2fM资源更新,是否下载
				local LanguageUtil = require "First.Util.LanguageUtil"
				local strContent =  string.format(LanguageUtil.GetWord(str),size / 1024 / 1024)
				--local strLeft = "Common_1005"
				--local strRight = "Common_1004"
				local strTitle = "Common_1006"
				local strMiddle = "Common_1004"
				local updateView = GetUpdateView()
				updateView:SetUpdateState(updateView.UpdateState.EntryGame, 1, 1)
				coroutine.yield(CS.UnityEngine.WaitForSeconds(0.02))
				ConfirmView.Show(strContent, function ( ok )
					if ok then
						UpdateMananger.StartDownload()
					else
						Application.Quit()
					end
				end, nil, nil, strMiddle, 1, strTitle, true, nil, nil, false)
				--coroutine.yield(UpdateMananger.StartDownload())
			else
				local updateView = GetUpdateView()
				updateView:SetUpdateState(updateView.UpdateState.EntryGame, 1, 1)
				coroutine.yield(CS.UnityEngine.WaitForSeconds(0.02))
				UpdateMananger.UpdateEnd(false)				
			end	
		end)		
end

function UpdateMananger.CreateDownloadList()
	
	_downloadBuildInfo = {}
	local downsize=0
	for name, info in pairs(_remoteBuildInfo) do
		if not _localBuildInfo[name] or (_localBuildInfo[name].md5 ~= info.md5) then
			table.insert(_downloadBuildInfo, info)
			if info.size then
				downsize = downsize + info.size
			end
		end	
	end
	return downsize
end

function UpdateMananger.StartDownload()
	if #_downloadBuildInfo > 0 then
		local updateView = GetUpdateView()
		updateView:SetUpdateState(updateView.UpdateState.UpdateBundle, 0, 0)
		local UpdateDownload = require "First.Update.UpdateDownload"
		UpdateDownload.AddDownloadTask(_downloadBuildInfo, _remoteVersion, UpdateMananger.DownloadComplete)
		return UpdateDownload.StartDownloadTask()
	else
		UpdateMananger.UpdateEnd(true)
	end	
end

function UpdateMananger.DownloadComplete()
	FileUtils.CreateFile(string.format("%s/%s.ab", SystemConfig.OutsideResPath, _versionFileName), _remoteVersionData)
	FileUtils.CreateFile(string.format("%s/%s.ab", SystemConfig.OutsideResPath, _buildInfoFileName), _remoteBuildInfoData)

	UpdateMananger.UpdateEnd(true)
end

function UpdateMananger.UpdateEnd(restart)
	if _completefunc then
		_completefunc(restart)
	end
end

--是否需要更新
function UpdateMananger.CheckIsNeedUpdate()
	coroutine.yield(_LoadLoaclVersionInfo())
	coroutine.yield(_LoadRemoteVersionInfo())
	if _localVersion < _remoteVersion then
		return true
	end
	return false
end


function UpdateMananger.GetLocalVersionInfo()

	coroutine.yield(_LoadLoaclVersionInfo())
	return true

end

--[[
	update callback
]]
function UpdateMananger.SetCompleteCallBack(func)
	_completefunc = func
end

return UpdateMananger