local logic = { buff = {}, timer = {} }

function logic.buff:onstart()
    self._maxlevel = self.static.maxlevel or 1
    self._level = 0
    self:_execute()
end

function logic.buff:onmerge()
    self:_execute()
end

function logic.buff:onend()
    self:_tstop()
end

function logic.buff:ongetlevel()
    return self._level or 1
end

function logic.buff:onreset_time()
    self:_start_timer()
end

function logic.buff:onshorten(rate)
    if self.onshorten then
        self:onshorten(rate)
    end
end

-- 修正
function logic:amendment(value)

    if self.caller.buff then
        local amendment_static = self.caller.buff:get_amendment_static(self.static.class) or self.static
        local fromobj = self.buff:getfromobj() or self.owner
        if amendment_static.amendment then
            value = self.service.area:amendment_multi(fromobj, self.owner, value, amendment_static.amendment_cond, amendment_static.amendment)
        end
        if amendment_static.amendment_2 then
            value = self.service.area:amendment_multi(fromobj, self.owner, value, amendment_static.amendment_cond_2, amendment_static.amendment_2) -- 第二次修正
        end
        if amendment_static.amendment_3 then
            value = self.service.area:amendment_multi(fromobj, self.owner, value, amendment_static.amendment_cond_3, amendment_static.amendment_3) -- 第三次修正
        end
    end
    return value
end

function logic:getlevel()
    return self._level or 1
end

function logic:gettargetobj(target)
    local fromobj = self.buff:getfromobj() or self.owner
    local targetobj = target == 1 and fromobj or self.owner
    return targetobj
end

function logic:_execute()

    self:_start_timer()

    if not self._maxlevel or self._level < self._maxlevel then
        self._level = self._level + 1
        self:_tstart()
    end
end

function logic:_start_timer()
    if self.static.time_script then
        if self._timer then
            self.timer:remove(self._timer)
        end
        local delay, interval, count = table.unpack(self.static.time_script)
        local tmdf = self.caller.buff:get_timemdf(self.static.type or 0)
        if tmdf and tmdf ~= 0 then
            if delay then
                delay = delay + tsmath.rate(delay, tmdf)
            end
            if count then
                count = count + tsmath.rate(count, tmdf)
            end
        end
        self._tmax = count
        self._tcount = 0
        self._timer = self.timer:add(delay, interval, count, self._tinterval)
    end
end

function logic:countleft()
    if self._tmax then
        return self._tmax - self._tcount
    end
end

function logic:_tstart()
    if self.ontstart then
        self:ontstart(self._level)
    end
end

function logic:_tinterval()
    if self.ontinterval then
        self:ontinterval(self._level)
    end
    if self.static.loop_view_script then
        self.caller.view:start_view(self.static.id, self.static.loop_view_script)
    end
    self._tcount = self._tcount + 1
    if not self._tmax or self._tcount >= self._tmax then
        self:_tstop()
    end
end

function logic:_tstop()
    if self._level ~= 0 and self.ontstop then
        self:ontstop(self._level)
    end
    self._level = 0
    self.buff:stop()
end

return logic