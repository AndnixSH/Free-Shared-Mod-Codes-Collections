local BattleProxy = require "Modules.Battle.BattleProxy"
local SettingProxy = require "Modules.Setting.SettingProxy"
local SettingDef = require "Modules.Setting.SettingDef"
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"
local NewbieWidget = require "Core.Implement.UI.Widgets.NewbieWidget"
local ModuleManager = require "Common.Mgr.UI.ModuleManager"
local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"

local NewbieDef = require "Modules.Newbie.NewbieDef"
local NewbieProxy = require "Modules.Newbie.NewbieProxy"
local NewbieManager = require "Modules.Newbie.NewbieManager"

local LanguageManager = require "Common.Mgr.Language.LanguageManager"

local Input = CS.UnityEngine.Input
local isEditor = CS.UnityEngine.Application.isEditor
local RuntimePlatform = CS.UnityEngine.RuntimePlatform
local KeyCode = CS.UnityEngine.KeyCode

local SpeedBtnItem = SpeedBtnItem or LuaEventClass(GameObjFactor, NewbieWidget)

local SpeedBtnData = 
{
	[ModuleOpenDef.SystemOpenType.DoubleFrame] = {
		setting_key = SettingDef.Game_Setting.Speed,
		speed = 1.3,
		count = 2,
		effect_name = "UI_Battle_button2",
	},
	
	[ModuleOpenDef.SystemOpenType.FourFrame] = {
		setting_key = SettingDef.Game_Setting.FourSpeed,
		speed = 1.7,
		count = 4,
		effect_name = "UI_Battle_button3",
	}
}

local default_speed = 0.9

function SpeedBtnItem:__init(obj, open_type)
	self.open_type = open_type
	self.data = SpeedBtnData[open_type]
	self.selected = false
	self.go = obj
	self:InitObj(obj)
	self:InitBtnEffect()
end

function SpeedBtnItem:InitObj(obj)
	self.speedBtn = self:GetComponent(obj, "CButton")
	self.speedBtn:AddClick(function ()
			if self:SpeedIsOpen(true) then
				if not self.selected then
					GameLogicTools.ShowMsgTips(LanguageManager:GetWord("msgtips_battle_1002", self.data.count))
				end
				
				if self.OnClickSpeedCallback then
					self.OnClickSpeedCallback(self.open_type)
				end
			end
			
			if BattleProxy.Instance:IsStop() then
				BattleProxy.Instance:ContinusGame()
			end
			self:OnTriggerClickBtn(self.speedBtn)
		end)
	self.speedObj = self:GetChild(self.speedBtn.gameObject, "CSprite_Select")
	self.speedEffectObj = self:GetChild(self.speedBtn.gameObject, "effectRoot")
end

function SpeedBtnItem:Open()
	self:UpdateInfo()
	self:RegisterNewbieData()
end

function SpeedBtnItem:Close()
	self.btnEffect:Close()
end

function SpeedBtnItem:UpdateInfo()
	self.selected = SettingProxy.Instance:GetSettingInfo(self.data.setting_key)
	self:UpdateBtnEffect()
end

function SpeedBtnItem:RegisterNewbieData()
	--多倍速
	if self.open_type == ModuleOpenDef.SystemOpenType.DoubleFrame then
		local cur_newbie_id, cur_newbie_step = NewbieManager.Instance:GetCurNewbieIdStep()
		local _newbie_id, _newbie_step = NewbieProxy.Instance:GetNewbieIdAndStep(NewbieDef.DoubleFrameTrigger)
		if _newbie_id and _newbie_step then
			if _newbie_id == cur_newbie_id and _newbie_step == cur_newbie_step then
				local bOpen = self:SpeedIsOpen(false)
				if bOpen then
					self:RegisterButton(self.speedBtn, cur_newbie_id, cur_newbie_step)
					BattleProxy.Instance:StopGame(false)
				end
			end
		end
	end
end

--二倍速是否开启
function SpeedBtnItem:SpeedIsOpen(bshowTips)
	local bopen = ModuleManager.SystemIsOpen(self.open_type, bshowTips)
	return bopen
end

function SpeedBtnItem:IsSelect()
	return self.selected
end

function SpeedBtnItem:GetSpeed()
	return self.data.speed
end

function SpeedBtnItem:SetClickSpeedCallback(callback)
	self.OnClickSpeedCallback = callback
end

function SpeedBtnItem:SetSelect(select)
	if self.selected ~= select then
		SettingProxy.Instance:SetSettingInfo(self.data.setting_key)
	end
	self.selected = select and true or false
	self:UpdateBtnEffect()
end

function SpeedBtnItem:GetOpenType()
	return self.open_type
end

function SpeedBtnItem:InitBtnEffect()
	self.btnEffect = UIEffectItem.New(self.data.effect_name, self.speedEffectObj)
end

function SpeedBtnItem:UpdateBtnEffect()
	self.speedObj:SetActive(self.selected)
	if self.selected then
		self.btnEffect:Open()
		self.btnEffect:SetOrderLayer(self:GetNextDepth())
	else
		self.btnEffect:Close()
	end
end





local SystemHandle = SystemHandle or LuaEventClass(GameObjFactor,TimerFactor, NewbieWidget)
function SystemHandle:__init(obj)
	self.go = obj
	self:InitObj(obj)
end

function SystemHandle:InitObj(obj)
	self.rect = self:GetComponent(obj, "RectTransform")
	self.rectPosition = self.rect.anchoredPosition

	self.autoBtn = self:GetChildComponent(obj, "CButton_Auto", "CButton")
	self.autoGraySp = self:GetChildComponent(obj, "CButton_Auto/sprite", "CSprite")
	self.autoSp = self:GetChildComponent(obj, "CButton_Auto/CSprite_Select/sprite", "CSprite")
	self.autoBtn:AddClick(function ()
		self:OnTriggerClickBtn(self.autoBtn)
		local bopen = self:AutoSkillIsOpen(true)
		if bopen then
			self:OnClickAuto()
		end

		if BattleProxy.Instance:IsStop() then
			BattleProxy.Instance:ContinusGame()
		end
		
	end)
	self.autoObj = self:GetChild(self.autoBtn.gameObject, "CSprite_Select")
	self.autoEffectObj = self:GetChild(self.autoBtn.gameObject, "effectRoot")

	self.layoutObj = self:GetChild(obj, "CLayoutItem")
	self.layoutObj2 = self:GetChild(obj, "CLayoutItem2")
	
	self.speedLayoutObj = self.layoutObj
	self.speed_list = {ModuleOpenDef.SystemOpenType.DoubleFrame}
	
	if ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.FourFrame, false) then
		table.insert(self.speed_list, ModuleOpenDef.SystemOpenType.FourFrame)
		self.layoutObj:SetActive(false)
		self.layoutObj2:SetActive(true)
		self.speedLayoutObj = self.layoutObj2
	else
		self.layoutObj:SetActive(RoleInfoModel.mainlineid >= 2 and true or false)
	end
	
	self.stopBtn = self:GetChildComponent(self.speedLayoutObj, "CButton_Stop", "CButton")
	self.stopBtn:AddClick(function ()
			self:OnClickStop()
		end)
	
	self.speedBtns = {}
	for i = 1, #self.speed_list do
		local speedBtnName = "CButton_Speed" .. ((i == 1) and "" or tostring(i))
		local obj = self:GetChild(self.speedLayoutObj, speedBtnName)
		local btn = SpeedBtnItem.New(obj, self.speed_list[i])
		btn:SetClickSpeedCallback(function(open_type)
				self:OnClickSpeedCallback(open_type)
			end)
		table.insert(self.speedBtns, btn)
	end

	self.exitBtn = self:GetChildComponent(obj, "CButton_Exit", "CButton")
	self.exitBtn:AddClick(function()
		BattleProxy.Instance:JumpGame()
	end)

	self.autoBattleBtn = self:GetChildComponent(obj, "CButton_computer", "CButton")
	self.autoBattleSelectObj = self:GetChild(self.autoBattleBtn.gameObject, "CSprite_Select")
	self.autoBattleBtn.gameObject:SetActive(false)
	self.autoBattleBtn:AddClick(function()
		local bopen = self:AutoBattleIsOpen(true)
		if bopen then
			local AutoBattleProxy = require "Modules.AutoBattle.AutoBattleProxy"
			local status = AutoBattleProxy.Instance:GetAutoBattleStatus()
			AutoBattleProxy.Instance:SetAutoBattleStatus(status == 0 and 1 or 0)
			self:ShowAutoBattleBtnStatus()
			local AutoBattleDef = require "Modules.AutoBattle.AutoBattleDef"

			local _status = AutoBattleProxy.Instance:GetAutoBattleStatus()
			if _status == 1 then
				GameLogicTools.ShowMsgTips(AutoBattleDef.LanguageKeys.LanguageKey2)
			else
				GameLogicTools.ShowMsgTips(AutoBattleDef.LanguageKeys.LanguageKey1)
			end
		end

		if BattleProxy.Instance:IsStop() then
			BattleProxy.Instance:ContinusGame()
		end
		self:OnTriggerClickBtn(self.autoBattleBtn)

	end)

	self:InitEffect()
end

function SystemHandle:ShowStopBtn(show)
	self.stopBtn.gameObject:SetActive(show)
end

function SystemHandle:OnClickSpeedCallback(open_type)
	for i, speedBtn in ipairs(self.speedBtns) do
		if speedBtn:GetOpenType() == open_type then
			speedBtn:SetSelect(not speedBtn:IsSelect())
		else
			speedBtn:SetSelect(false)
		end
	end
	
	self:UpdateSpeedBtn()
end

function SystemHandle:UpdateSpeedBtn()
	local speed = default_speed
	for i, speedBtn in ipairs(self.speedBtns) do
		if speedBtn:IsSelect() then
			speed = speedBtn:GetSpeed()
		end
	end
	
	BattleProxy.Instance:SpeedGame(speed)
end
	
function SystemHandle:UpdateReportBtn()
	local breport = BattleProxy.Instance:IsReportBattle()
	self.exitBtn.gameObject:SetActive(breport)
	local iscomplete = self:AutoSkillIsComplete()
	if not breport then
		self.autoBtn.gameObject:SetActive(iscomplete)
	else
		self.autoBtn.gameObject:SetActive(false)
	end

	if breport then
		self.autoBattleBtn.gameObject:SetActive(false)
	else
		self.autoBattleBtn.gameObject:SetActive(false)
		local autoBattle = self:AutoBattleIsComplete()
		if autoBattle then
			local activity_id = BattleProxy.Instance:GetBattleActivityId()
			if activity_id and (activity_id == ACTIVITYID.MAINLINE or activity_id == ACTIVITYID.TOWER) then
				self.autoBattleBtn.gameObject:SetActive(true)
				self:ShowAutoBattleBtnStatus()
			end
		end
	end
end
	
function SystemHandle:ShowAutoBattleBtnStatus()
	local AutoBattleProxy = require "Modules.AutoBattle.AutoBattleProxy"
	local status = AutoBattleProxy.Instance:GetAutoBattleStatus()
	local bopen = self:AutoBattleIsOpen(false)
	local bActive = (status == 1 and bopen == true) and true or false
	self.autoBattleSelectObj:SetActive(bActive)

	if bActive then
		self.btnEffect_3:Open()
		local depth = self:GetNextDepth()
		self.btnEffect_3:SetOrderLayer(depth)
	else
		self.btnEffect_3:Close()
	end
end

--自动释放大招引导是否完成
function SystemHandle:AutoSkillIsComplete()
	local _newbie_id, _newbie_step = NewbieProxy.Instance:GetNewbieIdAndStep(NewbieDef.AutoSkillTrigger)
	local iscomplete = NewbieProxy.Instance:NewbieIsComplete(_newbie_id)
	
	local _cur_newbie_id, _cur_newbie_step = NewbieManager.Instance:GetCurNewbieIdStep()
	
	if not iscomplete then
		if self:AutoSkillIsOpen(false) and 
			(_cur_newbie_id ~= _newbie_id or _cur_newbie_step ~= _newbie_step) then
			iscomplete = true
		end
	end


	if AppConfig.IsOpenNewbie == false then
		iscomplete = true
	end
	return iscomplete
end

--自动推图引导是否完成
function SystemHandle:AutoBattleIsComplete()
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	local NewbieProxy = require "Modules.Newbie.NewbieProxy"
	local NewbieManager = require "Modules.Newbie.NewbieManager"
	local _newbie_id, _newbie_step = NewbieProxy.Instance:GetNewbieIdAndStep(NewbieDef.AutoBattleTrigger)
	local iscomplete = NewbieProxy.Instance:NewbieIsComplete(_newbie_id)

	local _cur_newbie_id, _cur_newbie_step = NewbieManager.Instance:GetCurNewbieIdStep()
	if not iscomplete then
		if self:AutoBattleIsOpen(false) then
			iscomplete = true
		end
	end

	if AppConfig.IsOpenNewbie == false then
		iscomplete = true
	end
	return iscomplete
end

function SystemHandle:Open()
	local iscomplete = self:AutoSkillIsComplete()
	self.autoBtn.gameObject:SetActive(iscomplete)	

	self:StartOpenTween()
	self:InitSettingInfo()

	
	for i, speedBtn in pairs(self.speedBtns) do
		speedBtn:Open()
	end
	
	self:UpdateSpeedBtn()
	
	local depth = self:GetNextDepth()
	self:SetDepth(self.autoEffectObj, depth)
	-- depth = self:GetNextDepth()
	-- self:SetDepth(self.stopInfoObj, depth)

	self.autoGraySp.SpriteName = "zidonghui"
	self.autoSp.SpriteName = "zidong"

	self:UpdateReportBtn()

	self:CheckPressButton()
	self:RegisterNewbieData()
end

function SystemHandle:CheckPressButton()

	if self.update_timer then
		self:RemoveTimer(self.update_timer)
		self.update_timer=false
	end
	self.update_timer=self:AddTimer(function()
		if  Input.GetKeyDown(KeyCode.Escape) then

			if isEditor or  Application.platform == RuntimePlatform.Android  then

				if self.stopBtn.gameObject.activeSelf then
					self:OnClickStop()
				end
			end
		end
	end, 0.02, -1)
end

function SystemHandle:Destroy()

	if self.update_timer then
		self:RemoveTimer(self.update_timer)
		self.update_timer=false
	end	
	self:ClearEffect(true)
	
end

function SystemHandle:Close()
	self:ClearEffect()
	if self.opensequence then
		self.opensequence:Kill()
		self.opensequence = nil
	end	
	
	if self.update_timer then
		self:RemoveTimer(self.update_timer)
		self.update_timer=false
	end	
	
	for i, speedBtn in pairs(self.speedBtns) do
		speedBtn:Close()
	end
end	

function SystemHandle:InitEffect()
	self.btnEffect_1 = UIEffectItem.New("UI_Battle_button", self.autoEffectObj)
	self.btnEffect_3 = UIEffectItem.New("UI_Battle_button", self.autoBattleBtn.gameObject) --自动推图
end

function SystemHandle:ClearEffect(bdestroy)
	if bdestroy then
		self.btnEffect_1:Destroy()
		self.btnEffect_3:Destroy()
		self.btnEffect_1 = nil
		self.btnEffect_3 = nil		
	else
		self.btnEffect_1:Close()
		self.btnEffect_3:Close()
	end	
end

function SystemHandle:StartOpenTween()	
	self.rect.anchoredPosition = Vector2.New(self.rectPosition.x - 300, self.rectPosition.y)
	local tween1 = self.rect:DOAnchorPosX(self.rectPosition.x + 10, 0.2)
	local tween2 = self.rect:DOAnchorPosX(self.rectPosition.x, 0.2)

	local sequence = DOTween.Sequence()
	sequence:Append(tween1)
	sequence:Append(tween2)
	self.opensequence = sequence
end
	
function SystemHandle:InitSettingInfo()
	local bauto = SettingProxy.Instance:GetSettingInfo(SettingDef.Game_Setting.Auto)
	self:OnClickAuto(bauto)

	local bopen = self:AutoSkillIsOpen(false)
	local bComplete = self:AutoSkillIsComplete()
	local bactive = (bopen and bComplete and bauto) and true or false
	self.autoObj:SetActive(bactive)
end

--自动大招是否开启
function SystemHandle:AutoSkillIsOpen(bshowTips)
	local ModuleManager = require "Common.Mgr.UI.ModuleManager"
	local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
	local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.AutoBigKill, bshowTips)
	return bopen
end

--自动推图
function SystemHandle:AutoBattleIsOpen(bshowTips)
	local ModuleManager = require "Common.Mgr.UI.ModuleManager"
	local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
	local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.AutoBattle, bshowTips)
	return bopen
end
	
	
function SystemHandle:OnStopGame(args)
	-- local bactive = args.bShow 
	-- self.stopInfoObj:SetActive(bactive)
	-- self:SetOverrideSorting(self.stopInfoObj, bactive)
end

--OnCLICK
function SystemHandle:OnClickStop()
	BattleProxy.Instance:StopGame()
end	
	
function SystemHandle:OnClickAuto(bauto)
	local bopen = self:AutoSkillIsOpen(false)
	-- local NewbieDef = require "Modules.Newbie.NewbieDef"
	-- local NewbieProxy = require "Modules.Newbie.NewbieProxy"
	-- local _newbie_id, _newbie_step = NewbieProxy.Instance:GetNewbieIdAndStep(NewbieDef.AutoSkillTrigger)
	local bComplete = self:AutoSkillIsComplete()--NewbieProxy.Instance:NewbieIsComplete(_newbie_id)
		
	if bauto == nil then
		bauto = not SettingProxy.Instance:GetSettingInfo(SettingDef.Game_Setting.Auto)
		
		local bactive = (bopen and bComplete and bauto) and true or false
		self.autoObj:SetActive(bactive)
		BattleProxy.Instance:AutoGame(bactive)
		
		SettingProxy.Instance:SetSettingInfo(SettingDef.Game_Setting.Auto)
		
		if bactive then
			GameLogicTools.ShowMsgTips("msgtips_battle_1001")
		end			
	else		
		local bactive = (bopen and bComplete and bauto) and true or false
		self.autoObj:SetActive(bactive)
		BattleProxy.Instance:AutoGame(bactive)	
	end
	if bopen and bComplete and bauto then
		self.btnEffect_1:Open()
		local depth = self:GetNextDepth()
		self.btnEffect_1:SetOrderLayer(depth)
	else
		self.btnEffect_1:Close()
	end	
end

function SystemHandle:OnClickEsc()
	-- self.stopInfoObj:SetActive(false)
	-- BattleProxy.Instance:EscGame()
end	

function SystemHandle:OnClickRestart()
	-- BattleProxy.Instance:RestartGame()
end	

function SystemHandle:OnClickContinue()
	-- self.stopInfoObj:SetActive(false)
	-- BattleProxy.Instance:ContinusGame()
end

--自动引导按钮引导后 设置自动按钮显示
function SystemHandle:SetAutoObjActive()
	-- local NewbieDef = require "Modules.Newbie.NewbieDef"
	-- local NewbieProxy = require "Modules.Newbie.NewbieProxy"
	-- local _newbie_id, _newbie_step = NewbieProxy.Instance:GetNewbieIdAndStep(NewbieDef.AutoSkillTrigger)
	-- local iscomplete = NewbieProxy.Instance:NewbieIsComplete(_newbie_id)
	-- self.autoBtn.gameObject:SetActive(iscomplete)
	-- local bauto = SettingProxy.Instance:GetSettingInfo(SettingDef.Game_Setting.Auto)
	-- self:OnClickAuto(bauto)
	if BattleProxy.Instance:IsStop() then
		BattleProxy.Instance:ContinusGame()
	end
	self:OnTriggerClickBtn(self.autoBtn)
end

--自动引导按钮引导后 设置自动按钮显示
function SystemHandle:SetAutoBattleObjActive()
	if BattleProxy.Instance:IsStop() then
		BattleProxy.Instance:ContinusGame()
	end
	self:OnTriggerClickBtn(self.autoBattleBtn)
end

function SystemHandle:RegisterNewbieData()
	local cur_newbie_id, cur_newbie_step = NewbieManager.Instance:GetCurNewbieId()

	local bStopGame = false

	--自动推图
	local _newbie_id, _newbie_step = NewbieProxy.Instance:GetNewbieIdAndStep(NewbieDef.AutoBattleTrigger)
	if _newbie_id and _newbie_step then
		if _newbie_id == cur_newbie_id and _newbie_step == cur_newbie_step then
			local bOpen = self:AutoBattleIsOpen(false)
			if bOpen then
				bStopGame = true
				self.autoBattleBtn.gameObject:SetActive(true)
				self:RegisterButton(self.autoBattleBtn, cur_newbie_id, cur_newbie_step)
			end
		end
	end

	if bStopGame then
		BattleProxy.Instance:StopGame(false)
	end
end

--自动释放技能
function SystemHandle:RegisterAutoSkillBtn()
	local NewbieManager = require "Modules.Newbie.NewbieManager"
	local NewbieProxy = require "Modules.Newbie.NewbieProxy"
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	local cur_newbie_id, cur_newbie_step = NewbieManager.Instance:GetCurNewbieIdStep()
	local _newbie_id, _newbie_step = NewbieProxy.Instance:GetNewbieIdAndStep(NewbieDef.AutoSkillTrigger)
	--print("_newbie_id, _newbie_step=========", _newbie_id, _newbie_step)
	if _newbie_id and _newbie_step then 
		if _newbie_id == cur_newbie_id  and _newbie_step == cur_newbie_step then
			self.autoBtn.gameObject:SetActive(true)
			self:RegisterButton(self.autoBtn, cur_newbie_id, cur_newbie_step)
		end
	end
end


return SystemHandle	