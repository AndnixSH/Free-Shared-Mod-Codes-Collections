local bullet = { timer = {}, sprite = {} }

-- speed distance duration position
function bullet:oncreate()

    self.prop.duration = self.prop.duration or 1000
    self._cur_time = 0
    self._stage = 1
    self._hitrecord = {{},{}}
    self._direction = 1  -- 转向方向
    self._hitblock = 0  ---击中墙壁数
    self._pause = false
    self._angle_rate = 1000

    self.prop.wait_time = self.prop.wait_time or 0
    self.prop.duration_mul = self.prop.duration_mul or 1
    self.prop.speed_multi = self.prop.speed_multi or 0
    self.prop.minspeed = self.prop.minspeed or 1000
    self.prop.back_speed_rate = self.prop.back_speed_rate or 1
    self.prop.stop_distance = self.prop.stop_distance or nil
    
    local duration = self.prop.duration / self.prop.duration_mul
    local header = self.owner.body.header

    if not self.prop.speed then
        local distance = self.prop.distance

        if not distance and self.prop.position then
            distance = tsvector.distance(self.prop.position, self.owner.body.position)
            self._targetpos = self.prop.position
        end

        if not distance then

            local target = self.prop.target

            if not target and self.prop.rangeid then
                local targets = self.owner.body.parent.caller.skill:range(self.prop.rangeid, self.owner.body.parent)
                if #targets > 0 then
                    target = targets[1]
                end
            end

            if target then
                local targetpos = target.body.position
                distance =  tsvector.distance(targetpos, self.owner.body.position)
                header = (targetpos - self.owner.body.position).normalized
                self.prop.target = target
                self._targetpos = targetpos
                self.prop.stop_distance = self.prop.stop_distance or (target and target.body.radius + 50 or 500)
            end
        end

        if distance then    -- 计算加速度
            local finalspeed = self.prop.minspeed
            local avgspeed = tsmath.ndiv(distance, duration)
            local startspeed = (avgspeed * 2) - finalspeed
            local accspeed = tsmath.ndiv(finalspeed - startspeed, (duration)/1.1)
            self.prop.speed = startspeed
            self.prop.speed_multi = accspeed
            -- self.prop.speed = tsmath.ndiv(distance, duration)
        end
    end
    
    -----------------------------
    if self.prop.degree then
        header = tsvector.rotate(header, self.prop.degree)
        self._direction = self.prop.degree >= 0 and -1 or 1
    end

    if self.prop.speed then
        self.owner.body:setvelocity(header:fmul(self.prop.speed))
    else
        global.debug.warning("弧形回旋子弹speed为空")
    end
    
end

function bullet.timer:f1(time, tick)
    self.service.area:collidecheck(self)
    self._cur_time = self._cur_time + tick
    local distance = tsvector.distance(self._targetpos, self.owner.body.position) or self.prop.distance

    if self._cur_time >= self.prop.duration and self.prop.wait_time > 0 then
        self._cur_time = self._cur_time - tick
        self.prop.wait_time = self.prop.wait_time - tick
        if not self._pause then
            self._pause = true
            self:sendmessage(eventdef.bullet_move_pause) -- 最远处停留
        end
    end

    if self.prop.wait_time <= 0 and self._pause then
        self._pause = false
    end

    if self._cur_time >= self.prop.duration then
        if self._stage == 1 then
            self._stage = 2
            -- self._angle_rate = self._angle_rate * self.prop.back_speed_rate
            self.curcollide = nil
            self.prop.target = self.owner.body.parent
            self._targetpos = self.owner.body.parent.body.position
            -- self:turndirection(true)
        end
        if self._cur_time >= self.prop.duration * 2 then
            self:destroy()
        end
    end

    local body = self.owner.body
    local header = body.header

    if not self._pause then
        if self._stage == 1 then    -- 赋予加速度
            header = self._targetpos and (self._targetpos - body.position) or body.header
            self.prop.speed = self.prop.speed + self.prop.speed_multi / (1000 / tick)
        else
            self._targetpos = body.parent.body.position
            header = (self._targetpos - body.position) or body.header
            self.prop.speed = self.prop.speed - (self.prop.speed_multi / (1000 / tick) * self.prop.back_speed_rate)
        end
        self.prop.speed = tsmath.max(self.prop.minspeed, self.prop.speed)
    end
    -----------------------------
    header = header:fdiv(distance) -- 单位变量
    local angle = tsvector.angle(self.owner.body.header, header)
    local walk_header = self.owner.body.header
    local degree = tsmath.min(angle/(distance/self._angle_rate), angle)
    local tradius = self.prop.stop_distance or 500
    if distance <= (tradius + self.owner.body.radius) then
        if self._stage == 1 then
            self._cur_time = self.prop.duration
        end
    else
        if angle >= 5 then
            walk_header = tsvector.rotate( walk_header, degree * self._direction)
            -- if self._stage > 1 and angle <= tsvector.angle(self._targetpos, walk_header) then
            --     self:turndirection(true)
            -- end
        end
        self.owner.body:setvelocity(walk_header:fmul(self._pause and 0 or (self.prop.speed or 1000)), walk_header)
        self._last_header = self.owner.body.header
    end 
end

function bullet.sprite:onhitsprite(spritobj)
    if self._stage > 1 and spritobj == self.owner.body.parent and not self._pause then -- 回手
        self:sendmessage(eventdef.sprite_collide, spritobj)
        self:destroy()
        return 
    end

    if self._hitrecord[self._stage][spritobj]                   -- 每个阶段同一敌人只打一次伤害
    -- or (self._stage > 1 and spritobj == self._last_hit )    -- 二阶段时不击中上一阶段最后命中的敌人
    or spritobj.prop.camp == self.owner.prop.camp 
    or spritobj.body.spritetype == self.owner.body.spritetype 
    or self._dirty then return end
    if spritobj ~= self.curcollide then
        self.curcollide = spritobj
        if self.prop.castid then
            local count = #self.prop.castid
            local castid = self._stage <= count and self.prop.castid[self._stage] or self.prop.castid[count]
            local parent = self.owner.body.parent
            if parent.caller.skill then
                parent.caller.skill:cast(castid, self.owner, {spritobj})
            end
        end
        self:sendmessage(eventdef.sprite_collide, spritobj)
        self._hitrecord[self._stage][spritobj] = true
        self._last_hit = spritobj
        -- self._hitblock = self._hitblock + 1
    end
end

function bullet:ondestroy()
    self.owner:destroy()
end

function bullet:turndirection(ifdegree) -- 纠正角度
    local header = self._targetpos - self.owner.body.position   
    local distance = tsvector.distance(self._targetpos, self.owner.body.position)
   
    header = header:fdiv(distance)
    header = ifdegree and tsvector.rotate(header, self.prop.degree) or header
    -- header = (tsvector.angle(self.owner.body.header, header) < self.prop.degree) and tsvector.rotate(header, self.prop.degree) or header
    self.owner.body:setheader(header)
end

function bullet.sprite:onhitblock()
    if self._hitblock > 0 then  -- 防止畸形回弹
        self.prop.target = self.owner.body.parent
        self._targetpos = self.owner.body.parent.body.position
        self._cur_time = self._stage == 1 and self.prop.duration or self._cur_time
        self._hitblock = 0
    end
    self:turndirection()
    -------------------------------------------------
    -- local sizex, sizey = self.service.area:getbattlecenter()
    -- local position = self.owner.body.position
    -- local hitdownwall =  (self.owner.body.radius + position.x + 1000) >= (sizex*2) and true or false
    -- local hitrightwall = (self.owner.body.radius + position.y + 1000) >= (sizey*2) and true or false
    -- local hitupwall = (self.owner.body.radius + 1000) >= (position.x) and true or false
    -- local hitleftwall = (self.owner.body.radius + 1000) >= (position.y) and true or false
    -- print(self.owner.body.radius, position,sizex*2, sizey*2)
    -- print("上方", hitupwall, "右方",hitrightwall,"下方", hitdownwall,"左方", hitleftwall)
    -- print(self._targetpos, self.owner.body.parent.body.position, self.owner.body.header)
    self._hitblock = self._hitblock + 1
end

return bullet