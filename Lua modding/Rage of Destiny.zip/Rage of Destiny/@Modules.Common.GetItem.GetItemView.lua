local AudioManager = require "Common.Mgr.Audio.AudioManager"

local GoodsItem = require "Core.Implement.UI.Class.GoodsItem"

local ObjPoolRender = require "Core.Implement.UI.Class.ObjPoolRender"
local ClistRender = require "Core.Implement.UI.Class.ClistRender"
local ClistItem = require "Core.Implement.UI.Class.ClistItem"
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"

local TweenTools =  require "Common.Util.TweenTools"
local NewbieWidget = require "Core.Implement.UI.Widgets.NewbieWidget"
local GameUIUtil = CS.GameUIUtil

local _clistvec4_1, _clistvec4_2 = nil, nil

local PoolItem = PetPoolItem or BaseClass(ClistItem)
function PoolItem:Load(obj)
	self.goodsObj = self:GetChild(obj, "GoodsItem")
    self.goodsItem = GoodsItem.New(self.goodsObj)
    self.goodsItem:SetClickOpenInfo()
end

function PoolItem:SetData(data)
	if self.bscele == nil then
		self.bScale = true
	end
	if self.bScale then
		local delaytime, scale = 0 , 2.5
		self.scaleSeq = self:ScaleTween(self.goodsObj, scale, delaytime)
		self.bScale = false
	end
	local goodsnum = data.goodsnum > 1 and data.goodsnum or nil
	local goodsItemInfo = {data.goodsid, goodsnum}
	if data.roleid and data.rank and data.level then
		--例如回退英雄 显示
		goodsItemInfo = {data.goodsid, goodsnum, data.roleid, data.rank, data.level}
	elseif data.equipInfos then
		--装备显示
		goodsItemInfo = {data.goodsid, goodsnum, data.equipInfos}
	end
	self.goodsItem:SetData(table.unpack(goodsItemInfo))
	self.goodsItem:SetClickOpenInfo()
	local BagProxy = require "Modules.Bag.BagProxy"
	local BagDef = require "Modules.Bag.BagDef"
	local cfg = BagProxy.Instance:GetGoodsCfgById(data.goodsid)

	if cfg and cfg.quality and cfg.subtype then
		if (cfg.subtype == BagDef.SubType.Elite_Hero_Card or cfg.subtype == BagDef.SubType.Rare_Hero_Card) then
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.GetItemView)
			if view and data and data.bloopeffect then
				self.goodsItem:ShowQualityCircleEffect(cfg.quality, view._clistvec4_1)
			else
				self.goodsItem:ShowQualityCircleEffectLoop(cfg.quality)
			end
		end
	end
end

function PoolItem:Close()
	if self.scaleSeq then
		self.scaleSeq:Kill()
		self.scaleSeq = nil
	end
	self.bScale = nil
end

function PoolItem:Destroy()
	if self.scaleSeq then
		self.scaleSeq:Kill()
		self.scaleSeq = nil
	end
	self.bScale = nil
end


------------带标题奖励---------
local TitlePoolItem = TitlePoolItem or BaseClass(ClistItem)
function TitlePoolItem:Load(obj)
	--poolitem
	self.goodsPoolObj = self:GetChild(obj, "Reward1")
	self.goodsItem = self:GetChild(obj, "Reward1/CLayoutItem/item1")
    self.goodsPoolRender = ObjPoolRender.New()
    self.goodsPoolRender:Load(self.goodsItem, self.goodsItem.transform.parent, PoolItem)

    --poollist
    self.goodsListObj = self:GetChild(obj, "Reward2")
    self.poolList = self:GetChildComponent(obj, "Reward2/CList_Item", "CList")
    -- local _clistvec4_2 = CS.UtilsGameObj.GetWorldCorners(self.poolList.gameObject)
    self.listRender = ClistRender.New()
    self.listRender:Load(self.poolList, PoolItem)

    self.titleLab = self:GetChildComponent(obj, "title/COutline_title", "CLabel")

end

function TitlePoolItem:SetData(data)
	self.goodsPoolRender:ReleaseAll()
	self.listRender:ClearData()
	self.titleLab.text = self:GetWord(data.title)
	if #data.infos > 10 then
		self.goodsPoolObj:SetActive(false)
		self.goodsListObj:SetActive(true)	  
		self:ClidEffect(data.infos, true)
	    self.listRender:AppendDataList(data.infos, nil, false)
	    self.listRender:ShowOpenOrderTween()
	else
		self.goodsPoolObj:SetActive(true)
		self.goodsListObj:SetActive(false)
		self:ClidEffect(data.infos, false)
		self.goodsPoolRender:GetList(data.infos)
	end	
end

function TitlePoolItem:ClidEffect(infos, bloopeffect)
	for i,v in ipairs(infos) do
		v.bloopeffect = bloopeffect
	end
end

function TitlePoolItem:Close()
	self.goodsPoolRender:ReleaseAll()
	self.listRender:ClearData()
end

function TitlePoolItem:Destroy()
	self.goodsPoolRender:ReleaseAll()
	self.listRender:ClearData()
end


-------------------------
local GetItemView = GetItemView or BaseClass(LuaBasicWidget, NewbieWidget)

GetItemView.MaxItemCount = 0
GetItemView.itemList = {} --普通奖励
GetItemView.func = nil
GetItemView.titleList = {} --标题奖励
GetItemView.type = 0
GetItemView.title = "huodejiangli"
GetItemView.titles = nil
GetItemView.btnInfos = nil

local contentPos = Vector2.zero
local contentPos2 = Vector2.New(0, -47)

-- type (1:通用奖励类型) itemList 的格式为 itemList = {{goodsid = xxx, goodsnum = xxx}, ...} ， func 按钮回调，
-- type (2:带标题奖励) itemList 的格式为 itemList = {{{goodsid = xxx, goodsnum = xxx},...}, ... }, func 按钮回调，titles={"111", "222"},btnInfos{goodsid,count,sp,desc}
-- type (3:显示英雄物品图标 ， 根据roleid 转换英雄物品id { {{ goodsid, goodsnum = xxx, roleid=xxx,rank =xx, level = xxx},{ goodsid, goodsnum = xxx}, { goodsid, goodsnum = xxx, equipInfos=},..}}) hero 及普通物品, 装备混合列表
-- type (4:通用奖励类型) itemList 的格式为 itemList = {{goodsid = xxx, goodsnum = xxx}, ...} ， func 按钮回调，不在主界面时，显示虚假背包按钮，关闭时奖励飞入背包按钮处
-- type (5:通用奖励类型) itemList 的格式为 itemList = {{goodsid = xxx, goodsnum = xxx}, ...} ， func 按钮回调，和 type1 一样 只是不显示奖励获得页面，直接飞入背包
function GetItemView.Show(itemList, type, func, titles, btnInfos, showshare, specialLogicType, specialLogicPara)
	GetItemView.type = type or 1
	GetItemView.func = func or nil
	GetItemView.titles = titles or nil
	GetItemView.btnInfos = btnInfos or nil
	
	local temp_item_list = {}
	local currency_item_list = {}
	local other_item_list = {}
	
	local currency_goods_id_map = {}
	for k,id in pairs(CURRENCY_TYPE_GOODID) do
		currency_goods_id_map[id] = k
	end
	
	for k,v in ipairs(itemList) do
		if currency_goods_id_map[v.goodsid] then
			table.insert(currency_item_list, v)
		else
			table.insert(other_item_list, v)
		end
	end
	
	local BagProxy = require "Modules.Bag.BagProxy"
	table.sort(currency_item_list, function (a, b)
		local config_a = BagProxy.Instance:GetGoodsCfgById(a.goodsid)
		local config_b = BagProxy.Instance:GetGoodsCfgById(b.goodsid)
		if config_a and config_b then
			return config_a.quality > config_b.quality
		end
		return false
	end)
	
	table.sort(other_item_list, function (a, b)
		local config_a = BagProxy.Instance:GetGoodsCfgById(a.goodsid)
		local config_b = BagProxy.Instance:GetGoodsCfgById(b.goodsid)
		if config_a and config_b then
			return config_a.quality > config_b.quality
		end
		return false
	end)
	
	for k,v in ipairs(currency_item_list) do
		table.insert(temp_item_list, v)
	end
	
	for k,v in ipairs(other_item_list) do
		table.insert(temp_item_list, v)
	end
	
	GetItemView.itemList = temp_item_list
	GetItemView.showshare = showshare or nil
	GetItemView.specialLogicType = specialLogicType
	GetItemView.specialLogicPara = specialLogicPara

	if GetItemView.type == 1 or GetItemView.type == 5 then
		GetItemView.itemList = temp_item_list
		GetItemView.MaxItemCount = #temp_item_list
	elseif GetItemView.type == 2 then
		GetItemView.titleList = temp_item_list
		GetItemView.MaxItemCount = #GetItemView.titleList[1]
	elseif GetItemView.type == 3  or GetItemView.type == 4 then
		GetItemView.itemList = temp_item_list
		GetItemView.MaxItemCount = #temp_item_list
	end

	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.GetItemView)
	if view and view:IsOpen() then
		LuaLayout.Instance:CloseWidget(UIWidgetNameDef.GetItemView)
	end
	LuaLayout.Instance:OpenWidget(UIWidgetNameDef.GetItemView)
end 

function GetItemView:__init()
end

function GetItemView:OnLoad()
	AssetManager.LoadUIPrefab(self, "UICommon.GetItemView",self.LoadEnd)
end

function GetItemView:LoadEnd(obj)
	self:SetGo(obj)

	self.contentObj = self:GetChild(obj, "obj")
	self.contentRect = self:GetComponent(self.contentObj, "RectTransform")

	--poolitem
	self.goodsPoolObj = self:GetChild(self.contentObj, "Reward1")
	self.goodsItem = self:GetChild(self.contentObj, "Reward1/CLayoutItem/item1")
    self.goodsPoolRender = ObjPoolRender.New()
    self.goodsPoolRender:Load(self.goodsItem, self.goodsItem.transform.parent, PoolItem)

    --poollist
    self.goodsListObj = self:GetChild(self.contentObj, "Reward2")
    self.poolList = self:GetChildComponent(self.contentObj, "Reward2/CList_Item", "CList")
    _clistvec4_1 = CS.UtilsGameObj.GetWorldCorners(self.poolList.gameObject)
    self._clistvec4_1 = _clistvec4_1
    self.listRender = ClistRender.New()
    self.listRender:Load(self.poolList, PoolItem)

    --titleType
    self.titleObj = self:GetChild(self.contentObj, "title_type")
    self.titleItemObj = self:GetChild(self.titleObj, "CVerticalItem/item1")
    self.titleItemPoolRender = ObjPoolRender.New()
    self.titleItemPoolRender:Load(self.titleItemObj, self.titleItemObj.transform.parent, TitlePoolItem)

	self.closeBtn = self:GetChildComponent(obj, "Black", "CButton")
	self.closeBtn:AddClick(function (go) self:OnClickClose(1) end)


	self.labelObj = self:GetChild(obj, "COutline_click")

	self.confirmBtn = self:GetChildComponent(self.contentObj, "Confirm", "CButton")
	-- self.confirmLab = self:GetChildComponent(self.contentObj, "Confirm/label", "CLabel")
	self.tenBtn = self:GetChildComponent(self.contentObj, "CButton_ten", "CButton")
	self.confirmBtn:AddClick(function()
		self:OnClickClose(2)
	end)

	self.tenSp = self:GetChildComponent(self.contentObj, "CButton_ten/icon", "CSprite")
	-- self.tenLabel = self:GetChildComponent(self.contentObj, "CButton_ten/label", "CLabel")
	self.tenCount = self:GetChildComponent(self.contentObj, "CButton_ten/value", "CLabel")
	self.tenBtn:AddClick(function()
		self:OnClickClose(3)
	end)

	self.effectObj = self:GetChild(obj, "CTexture_title")
	self.titleAlphaObj = self:GetChild(obj, "title")
	self.titleSp = self:GetChildComponent(obj, "CSprite_title", "CSprite")
	self.closeClickObj = self:GetChild(obj, "COutline_click")
	self.texObj = self:GetChild(self.effectObj, "CTexture_back")

	self.posObj = self:GetChild(self.go, "EmptyObjPos")
	self.rootPos = self.posObj.transform.localPosition

	self.effectRoot1 = self:GetChild(self.go, "effectroot")
	self.effect_shine = UIEffectItem.New("UI_Common_UpdateTitle_shine", self.effectRoot1)
	self.effect_shine2 = UIEffectItem.New("UI_Common_UpdateTitle_shine2", self.effectRoot1)

	self.sharebtn = self:GetChildComponent(self.go, "CButton_share", "CButton")
	self.sharebtn:AddClick(function()
		local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
		local ActivityProxy = require "Modules.Activity.ActivityProxy"
        IGGSdkProxy.Instance:FacebookShareLink("https://rageofdestiny.onelink.me/Rvc2?pid=igg&c=igg.rod.global.noninct.share.20210508")
        ActivityProxy.Instance:Send62010()
	end)
	self.sharebtn.gameObject:SetActive(false)

	if GetItemView.type == 5 then
		GameUIUtil.SetGroupAlpha(obj,0) 
	else
		GameUIUtil.SetGroupAlpha(obj,1) 
	end

	self.guildBossNameObj = self:GetChild(obj, "GuildBossName")
	self.guildBossNameLb = self:GetComponent(self.guildBossNameObj, "CLabel")

	self:Step(0)
end

function GetItemView:OnClose()
	self:ShowDropItem()
	if self.timesequence then
		self.timesequence:Kill()
		self.timesequence = nil
	end	
	if self.effect_shine then
		self.effect_shine:Destroy()
		self.effect_shine = nil
	end
	if self.effect_shine2 then
		self.effect_shine2:Destroy()
		self.effect_shine2 = nil
	end
	self.listRender:ClearData()
	self.goodsPoolRender:ReleaseAll()
	self.titleItemPoolRender:ReleaseAll()
	GameUIUtil.SetGroupAlpha(self.go,1) 

	self:RegisterNewbieData()

	--商城推送礼包
    local MallProxy = require "Modules.Mall.MallProxy"
    local MallDef = require "Modules.Mall.MallDef"
    MallProxy.Instance:CheckShowPushView(MallDef.PushConType.Activity)
end

function GetItemView:RegisterNewbieData()
	local NewbieManager = require "Modules.Newbie.NewbieManager"
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	local NewbieProxy = require "Modules.Newbie.NewbieProxy"

    local cur_newbie_id,cur_newbie_step = NewbieManager.Instance:GetCurNewbieId()
	for newbie_id, steps in pairs(NewbieDef.SupplyDepot8Empty) do
		if cur_newbie_id == newbie_id then
			for i,_step in ipairs(steps) do
				if cur_newbie_step == _step then
					NewbieManager.Instance:NextStep()
					break
				end
			end
		end
	end
end

function GetItemView:OnDestroy()
	if self.timesequence then
		self.timesequence:Kill()
		self.timesequence = nil
	end	
	if self.effect_shine then
		self.effect_shine:Destroy()
		self.effect_shine = nil
	end
	if self.effect_shine2 then
		self.effect_shine2:Destroy()
		self.effect_shine2 = nil
	end
	self:ClearDropSequence()
	self.listRender:ClearData()
	self.goodsPoolRender:ReleaseAll()
	self.titleItemPoolRender:ReleaseAll()
end

function GetItemView:PlayEffect()
	self.effect_shine:Open()
	self.effect_shine2:Open()
	self.effect_shine:SetOrderLayer(self.nextDepth1)
	self.effect_shine2:SetOrderLayer(self.nextDepth1)
end

function GetItemView:SetObjDepth()
	self.nextDepth1 = self:GetNextDepth()
	self.nextDepth2 = self:GetNextDepth()
	-- GameObjTools.SetDepth(self.effectRoot1, self.nextDepth1)
	GameObjTools.SetDepth(self.titleSp.gameObject, self.nextDepth2)
	self.contentObj:SetActive(false)
	self.closeClickObj:SetActive(false)
end

function GetItemView:StretchTween()
	local fromScale = Vector3.New(0,1,1)
	local toScale = Vector3.New(1,1,1)
	local time = 0.3

	self.stretchSeq = TweenTools.OpenStretchTween(self.effectObj, fromScale, toScale, time, function()
		self:AttrTween()
	end, true)
end

function GetItemView:TitleScale()
	local fromScale = Vector3.New(3,3,1)
	local toScale = Vector3.New(1,1,1)
	local time = 0.3
	self:PlayTitleSound()
	self.scaleSeq = TweenTools.OpenStretchTween(self.titleSp.gameObject, fromScale, toScale, time, function()
		
	end)
	self:FireTitleAlpha(self.titleSp.gameObject, 0, 0.3)
end

function GetItemView:FireTitleAlpha(obj, fromAlpha, time)
	GameUIUtil.SetGroupAlpha(obj, fromAlpha)
	GameUIUtil.SetGroupAlphaInTime(obj, 1, time)
end

--标题通用特效
function GetItemView:PlayTitleSound()
	local AudioManager = require "Common.Mgr.Audio.AudioManager"
	AudioManager.PlaySoundByKey("Common_title_light")
end

function GetItemView:AttrTween()
	self.contentObj:SetActive(true)
	self:RefreshView()
end

function GetItemView:ShowTween()
	self:SetObjDepth()
	self:PlayEffect()
	self:StretchTween()
	self:TitleScale()
	self:FireTitleAlpha(self.titleAlphaObj, 0, 0.3)
end

function GetItemView:OnOpen()
	self:InitInfo()
end

function GetItemView:InitInfo()
	if not self.effect_shine then
		--只能在此创建，否则关闭后，切换场景后特效会强制释放，但是effect_shine不会为空
		self.effect_shine = UIEffectItem.New("UI_Common_UpdateTitle_shine", self.effectRoot1)
	end
	if not self.effect_shine2 then
		self.effect_shine2 = UIEffectItem.New("UI_Common_UpdateTitle_shine2", self.effectRoot1)
	end
	if GetItemView.type == 5 then
		self:RefreshView()
		self:CloseView()
	else
		AudioManager.PlaySoundByKey("campaigntime_view")
		self:ShowTween()
		-- self:RefreshView()
		self.timesequence = TweenTools.TransparentAlpha(self.labelObj, 1)
		if GetItemView.showshare then
			self.sharebtn.gameObject:SetActive(true)
		else
			self.sharebtn.gameObject:SetActive(false)
		end

		--特殊逻辑处理
		if GetItemView.specialLogicType == 1 then --公会boss
			self.guildBossNameObj:SetActive(true)
			self.guildBossNameLb.text = GetItemView.specialLogicPara[1]
			self.contentRect.anchoredPosition = contentPos2
		else
			self.guildBossNameObj:SetActive(false)
			self.contentRect.anchoredPosition = contentPos
		end
	end
end

function GetItemView:RefreshView()
	self.goodsPoolRender:ReleaseAll()
	self.listRender:ClearData()
	self.titleItemPoolRender:ReleaseAll()
	self.coinCount = 0
	self.gemCount = 0
	self.expCount = 0
	self.goodsList = {}
	if GetItemView.type == 1 or GetItemView.type == 3  or GetItemView.type == 4  or GetItemView.type == 5 then
		self:ShowNormalAward()  
	else
		self:ShowTitleAward()
	end

	self:ShowCallBackBtn()
end

function GetItemView:ShowNormalAward()
	self.titleObj:SetActive(false)

	-- print("GetItemView.itemList -->", GetItemView.type, table.dump(GetItemView.itemList), GetItemView.MaxItemCount)
	for i,v in ipairs(GetItemView.itemList) do
		self:ShowGoodsList(v.goodsid, v.goodsnum)
	end

	if GetItemView.MaxItemCount > 10 then
		self.goodsPoolObj:SetActive(false)
		self.goodsListObj:SetActive(true)	    
		self:ClidEffect(GetItemView.itemList, true)
	    self.listRender:AppendDataList(GetItemView.itemList, nil, false)
	    -- self.listRender:ShowOpenOrderTween()
	else
		self.goodsPoolObj:SetActive(true)
		self.goodsListObj:SetActive(false)
		self:ClidEffect(GetItemView.itemList, false)
		self.goodsPoolRender:GetList(GetItemView.itemList)
	end	

end

function GetItemView:ClidEffect(info, bloopeffect)
	for i,v in ipairs(info) do
		v.bloopeffect = bloopeffect
	end
end

function GetItemView:ShowTitleAward()
	self.titleObj:SetActive(true)
	self.goodsPoolObj:SetActive(false)
	self.goodsListObj:SetActive(false)	

	local titleInfos = {}
	for i,v in ipairs(GetItemView.titleList) do
		local item = {}
		item.title = ""
		if GetItemView.titles and GetItemView.titles[i] then
			item.title = GetItemView.titles[i]
		end
		item.infos = v
		table.insert(titleInfos, item)
		for k,info in ipairs(v) do
			self:ShowGoodsList(info.goodsid, info.goodsnum)
		end
	end
	self.titleItemPoolRender:GetList(titleInfos)
end

function GetItemView:ShowCallBackBtn()
	self.confirmBtn.gameObject:SetActive((GetItemView.btnInfos ~= nil and true or false))
	self.tenBtn.gameObject:SetActive((GetItemView.btnInfos ~= nil and true or false))
	self.labelObj:SetActive((GetItemView.btnInfos == nil and true or false))
	-- self.closeBtn.enabled = (GetItemView.btnInfos == nil and true or false)

	if GetItemView.btnInfos ~= nil then
		-- self.confirmLab.text = self:GetWord("RoleInfoView_1051")
		self.tenSp.SpriteName = GetItemView.btnInfos[3]
		-- self.tenLabel.text = self:GetWord("CardPortal_1002")
		self.tenCount.text = GetItemView.btnInfos[2]
	end
end

function GetItemView:ShowGoodsList(goodsid, goodsnum)
	-- print("goodsid, goodsnum==", goodsid, goodsnum)
	if goodsid == 702001 then
		--金币
		self.coinCount = self.coinCount + goodsnum
	elseif goodsid == 701001 then
		--钻石
		self.gemCount = self.gemCount + goodsnum
	elseif goodsid == 703001 then
		--账号经验
		self.expCount = self.expCount + goodsnum
	else
		table.insert(self.goodsList, {goodsid, goodsnum})
	end	
end

function GetItemView:ClearDropSequence()
	if self.dropSeq then
		self.dropSeq:Kill()
		self.dropSeq = nil
	end
end

--飞货币排列 循序
function GetItemView:ShowDropSequence(seqDatas)
	self:ClearDropSequence()
	local _interval = 0.35
	self.dropSeq = DOTween.Sequence()
	for i,_data in ipairs(seqDatas) do
		self.dropSeq:AppendCallback(function()
			if _data[1] == 0 then
				GameLogicTools.ShowExpDrop(_data[2], _data[3])
			elseif _data[1] == 1 then
				GameLogicTools.ShowCoinDrop(_data[2], _data[3])
			elseif _data[1] == 2 then
				GameLogicTools.ShowGemDrop(_data[2], _data[3])
			end
		end)
		self.dropSeq:AppendInterval(_interval)
	end
end

function GetItemView:ShowDropItem()
	local BagProxy = require "Modules.Bag.BagProxy"
	self.seqDatas = {}  --{fromPos, count}
	--金币
	if self.coinCount and self.coinCount > 0 then
		local offsetPos = Vector3.New(170, -150, 0)
		self.posObj.transform.localPosition = self.rootPos + offsetPos
		local fromPos = self.posObj.transform.position
		table.insert(self.seqDatas, {1, fromPos, self.coinCount})
	end
	
	--钻石
	if self.gemCount and self.gemCount > 0 then
		local offsetPos = Vector3.New(235, -100, 0)
		self.posObj.transform.localPosition = self.rootPos + offsetPos
		local fromPos = self.posObj.transform.position
		table.insert(self.seqDatas, {2, fromPos, self.gemCount})
	end

	--英雄经验
	if self.expCount and self.expCount > 0 then
		local offsetPos = Vector3.New(150, -190, 0)
		self.posObj.transform.localPosition = self.rootPos + offsetPos
		local fromPos = self.posObj.transform.position
		table.insert(self.seqDatas, {0, fromPos, self.expCount})	
	end

	self:ShowDropSequence(self.seqDatas)

	--进背包物品
	if self.goodsList and #self.goodsList > 0 then
		local _pos = self.go.transform.position
		local pos = Vector3.New(_pos.x, _pos.y, 0)
		self:ShowBagItemDrop(self.goodsList, pos, nil, func)
	end
end

--飞背包图标 飞向主界面背包图标或者itemdropview 里的bagitem
function GetItemView:ShowBagItemDrop(goodsList, pos, to, func)
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MainView)
	if view and view:IsOpen() then
		GameLogicTools.ShowGoodsDrop(goodsList, pos, to, func)
	else
		GameLogicTools.ShowAwardGoodsDrop(goodsList, pos, to, func)
	end
end


--onclick
function GetItemView:OnClickClose(btn_type)
	LuaLayout.Instance:CloseWidget(UIWidgetNameDef.GetItemView)
	if GetItemView.func then
		GetItemView.func(btn_type)
	end
end

return GetItemView