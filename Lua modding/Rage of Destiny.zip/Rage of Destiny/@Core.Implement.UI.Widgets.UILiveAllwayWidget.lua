local UILiveAllwayWidget = UILiveAllwayWidget or BaseClass(LuaBasicWidget)
function UILiveAllwayWidget:OnLoad()
	local obj = GameObject(UIWidgetNameDef.Root_liveAllway)
	GameObjTools.AddComponent(obj,"RectTransform")
	self:LoadEnd(obj)
end

function UILiveAllwayWidget:LoadEnd(obj)
	self:SetGo(obj)
	self:AddPanel(UIWidgetNameDef.LiveAllwayPanel)
	self:Step(0)
end

function UILiveAllwayWidget:OnOpen()
	self:SetDepth(self.go , 0)
	self:SetModelDepth(self.go, 0)
end

return UILiveAllwayWidget