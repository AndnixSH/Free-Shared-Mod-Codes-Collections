function ModulesInit()
    --init proxy/mediator
    local CheatProxy = require "Modules.Cheat.CheatProxy"
    CheatProxy.New(AppFacade.Cheat)

    local SceneProxy = require "Modules.Scene.SceneProxy"
    local SceneMediator = require "Modules.Scene.SceneMediator"
    SceneProxy.New(AppFacade.Scene)
    SceneMediator.New()

    local SdkProxy = require "Modules.Sdk.SdkProxy"
    SdkProxy.New(AppFacade.Sdk)

    local RoleInfoProxy = require "Modules.RoleInfo.RoleInfoProxy"
    local RoleInfoMediator = require "Modules.RoleInfo.RoleInfoMediator"
    RoleInfoProxy.New(AppFacade.RoleInfo)
    RoleInfoMediator.New()

    local LoginMediator = require "Modules.Login.LoginMediator"
    local LoginProxy = require "Modules.Login.LoginProxy"
    LoginProxy.New(AppFacade.Login)
    LoginMediator.New()

    local MainProxy = require "Modules.Main.MainProxy"
    local MainMediator = require "Modules.Main.MainMediator"
    MainProxy.New(AppFacade.Main)
    MainMediator.New() 

    local LoadingMediator = require "Modules.Loading.LoadingMediator"
    LoadingMediator.New()

    local BattleProxy = require "Modules.Battle.BattleProxy"
    local BattleMediator = require "Modules.Battle.BattleMediator"
    BattleProxy.New(AppFacade.Battle)
    BattleMediator.New() 

    local SettingProxy = require "Modules.Setting.SettingProxy"
    local SettingMediator = require "Modules.Setting.SettingMediator"
    SettingProxy.New(AppFacade.Setting)
    SettingMediator.New() 

    local CampaignProxy = require "Modules.Campaign.CampaignProxy"
    local CampaignMediator = require "Modules.Campaign.CampaignMediator"
    CampaignProxy.New(AppFacade.Campaign)
    CampaignMediator.New() 

    local HeroProxy = require "Modules.Hero.HeroProxy"
    local HeroMediator = require "Modules.Hero.HeroMediator"
    HeroProxy.New(AppFacade.Hero)
    HeroMediator.New() 

    local OutdoorsProxy = require "Modules.Outdoors.OutdoorsProxy"
    local OutdoorsMediator = require "Modules.Outdoors.OutdoorsMediator"
    OutdoorsProxy.New(AppFacade.Outdoors)
    OutdoorsMediator.New() 

    local TerritoryProxy = require "Modules.Territory.TerritoryProxy"
    local TerritoryMediator = require "Modules.Territory.TerritoryMediator"
    TerritoryProxy.New(AppFacade.Territory)
    TerritoryMediator.New()             

    local BagProxy = require "Modules.Bag.BagProxy"
    local BagMediator = require "Modules.Bag.BagMediator"
    BagProxy.New(AppFacade.Bag)
    BagMediator.New()

    local TowerProxy = require "Modules.Tower.TowerProxy"
    local TowerMediator = require "Modules.Tower.TowerMediator"
    TowerProxy.New(AppFacade.Tower)
    TowerMediator.New()  

    local EquipProxy = require "Modules.Equip.EquipProxy"
    local EquipMediator = require "Modules.Equip.EquipMediator"
    EquipProxy.New(AppFacade.Equip)
    EquipMediator.New()  

    local HexMapProxy = require "Modules.HexMap.HexMapProxy"
    HexMapProxy.New(AppFacade.HexMap)

    local MazeProxy = require "Modules.Maze.MazeProxy"
	local MazeMediator = require "Modules.Maze.MazeMediator"
    MazeProxy.New(AppFacade.Maze)
	MazeMediator.New()

    local CrystalProxy = require "Modules.Crystal.CrystalProxy"
    local CrystalMediator = require "Modules.Crystal.CrystalMediator"
    CrystalProxy.New(AppFacade.Crystal)
    CrystalMediator.New()

    local TempleProxy = require "Modules.Temple.TempleProxy"
    TempleProxy.New(AppFacade.Temple)

    local CardPortalProxy = require "Modules.CardPortal.CardPortalProxy"
    local CardPortalMediator = require "Modules.CardPortal.CardPortalMediator"
    CardPortalProxy.New(AppFacade.CardPortal)
    CardPortalMediator.New()
    
    --init view
    local BasicSceneUIDefine = require "Modules.Define.BasicSceneUIDefine"
    BasicSceneUIDefine.RegisterStaticWidgets()

    local MailProxy = require "Modules.Mail.MailProxy"
    MailProxy.New(AppFacade.Mail)

    local StoreProxy = require "Modules.Store.StoreProxy"
    StoreProxy.New(AppFacade.Store)

    local StoryLineProxy = require "Modules.StoryLine.StoryLineProxy"
    StoryLineProxy.New(AppFacade.StoryLine)
    local StoryLineMediator = require "Modules.StoryLine.StoryLineMediator"
    StoryLineMediator.New()

    local WorldMapProxy=require "Modules.WorldMap.WorldMapProxy"
    WorldMapProxy.New(AppFacade.WorldMap)

    local TaskProxy=require "Modules.Task.TaskProxy"
    TaskProxy.New(AppFacade.Task)
    local TaskMediator = require "Modules.Task.TaskMediator"
    TaskMediator.New()

    local NPCDialogueProxy=require "Modules.NPCDialogue.NPCDialogueProxy"
    NPCDialogueProxy.New(AppFacade.NPCDialogue)

    local ArenaProxy = require "Modules.Arena.ArenaProxy"
    local ArenaMediator = require "Modules.Arena.ArenaMediator"
    ArenaProxy.New(AppFacade.Arena)
    ArenaMediator.New()

    local FriendProxy = require "Modules.Friend.FriendProxy"
    FriendProxy.New(AppFacade.Friend)
    local FriendMediator = require "Modules.Friend.FriendMediator"
    FriendMediator.New() 

    local NewbieProxy = require "Modules.Newbie.NewbieProxy"
    NewbieProxy.New(AppFacade.Newbie)
    local NewbieMediator = require "Modules.Newbie.NewbieMediator"
    NewbieMediator.New()

    local ChatProxy = require "Modules.Chat.ChatProxy"
    ChatProxy.New(AppFacade.Chat)
    
    local RelationProxy = require "Modules.Relation.RelationProxy"
    RelationProxy.New(AppFacade.Relation)
    local RelationMediator = require "Modules.Relation.RelationMediator"
    RelationMediator.New()

    local GuildProxy = require "Modules.Guild.GuildProxy"
    GuildProxy.New(AppFacade.Guild)
    local GuildMediator = require "Modules.Guild.GuildMediator"
    GuildMediator.New()
    
    local GuildChaosProxy = require "Modules.Guild.GuildChaosProxy"
    GuildChaosProxy.New(AppFacade.GuildChaos)

    local GuildVersusProxy = require "Modules.Guild.GuildVersusProxy"
    GuildVersusProxy.New(AppFacade.GuildVersus)

    local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
    RedPointProxy.New(AppFacade.RedPoint)

    local FormationProxy = require "Modules.Formation.FormationProxy"
    FormationProxy.New(AppFacade.Formation) 
    local FormationMediator = require "Modules.Formation.FormationMediator"
    FormationMediator.New()

    local SupplyDepotProxy = require "Modules.SupplyDepot.SupplyDepotProxy"
    SupplyDepotProxy.New(AppFacade.SupplyDepot)
    local SupplyDepotMediator = require "Modules.SupplyDepot.SupplyDepotMediator"
    SupplyDepotMediator.New()

    local RankListProxy = require "Modules.RankList.RankListProxy"
    RankListProxy.New(AppFacade.RankList)


    local SettingMenuProxy = require "Modules.SettingMenu.SettingMenuProxy"
    SettingMenuProxy.New(AppFacade.SettingMenu)
    local SettingMenuMediator = require "Modules.SettingMenu.SettingMenuMediator"
    SettingMenuMediator.New()
    
    local MercenaryProxy = require "Modules.Mercenary.MercenaryProxy"
    MercenaryProxy.New(AppFacade.Mercenary) 
    local MercenaryMediator = require "Modules.Mercenary.MercenaryMediator"
    MercenaryMediator.New()
    
    local MallProxy = require "Modules.Mall.MallProxy"
    MallProxy.New(AppFacade.Mall)
    local MallMediator = require "Modules.Mall.MallMediator"
    MallMediator.New()

	local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
    IGGSdkProxy.New(AppFacade.IGGSdk)

    local VipProxy = require "Modules.Vip.VipProxy"
    VipProxy.New(AppFacade.Vip)
    
    local MarqueeProxy = require "Modules.Marquee.MarqueeProxy"
    MarqueeProxy.New(AppFacade.Marquee)
    local MarqueeMediator = require "Modules.Marquee.MarqueeMediator"
    MarqueeMediator.New()


    local ActivityProxy = require "Modules.Activity.ActivityProxy"
    ActivityProxy.New(AppFacade.Activity)

    local AutoBattleProxy = require "Modules.AutoBattle.AutoBattleProxy"
    AutoBattleProxy.New(AppFacade.AutoBattle)


    local RealmProxy = require "Modules.Realm.RealmProxy"
    RealmProxy.New(AppFacade.Realm)
    local RealmMediator = require "Modules.Realm.RealmMediator"
    RealmMediator.New()
    
    local CycleActivityProxy = require "Modules.CycleActivity.CycleActivityProxy"
    CycleActivityProxy.New(AppFacade.CycleActivity)
    local CycleActivityMediator = require "Modules.CycleActivity.CycleActivityMediator"
    CycleActivityMediator.New()

    local TreeProxy = require "Modules.Tree.TreeProxy"
    TreeProxy.New(AppFacade.Tree)


    local MallPassProxy = require "Modules.Mall.MallPassProxy"
    MallPassProxy.New(AppFacade.MallPass)

    local MallCustomProxy = require "Modules.Mall.MallCustomProxy"
    MallCustomProxy.New(AppFacade.MallCustom)
	
	local SdkEventProxy = require "Modules.Sdk.SdkEventProxy"
	SdkEventProxy.New(AppFacade.SdkEvent)

    local MobilizeProxy = require "Modules.Mobilize.MobilizeProxy"
    MobilizeProxy.New(AppFacade.Mobilize)
    local MobilizeMediator = require "Modules.Mobilize.MobilizeMediator"
    MobilizeMediator.New()
end