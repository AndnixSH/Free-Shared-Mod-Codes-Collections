LanguageDef = {}

LanguageDef.LanguageType = 
{
	[1] = {id = 1, des = "Jianti", info = "简体中文", name = "cn", gameid = 1, facebookurl = "https://www.facebook.com/RageofDestiny/"},            --(简体)
	[2] = {id = 2, des = "Fanti", info = "繁體中文", name = "tw", gameid = 1, facebookurl = "https://www.facebook.com/RageofDestinyTW/"},             --(繁體)
	[3] = {id = 3, des = "English", info = "English", name = "en", gameid = 1, facebookurl = "https://www.facebook.com/RageofDestiny/"},           --(英语)
	-- [3] = {id = 3, des = "de", info = "Deutsch", name = "de"},		      --(德语)
	-- [4] = {id = 4, des = "Fanti", info = "français", name = "fr"},         --(法语)
	-- [5] = {id = 5, des = "English", info = "Русский", name = "ru"},        --(俄语)
	-- [6] = {id = 6, des = "English", info = "日本語", name = "jp"},          --(日语)
	-- [7] = {id = 7, des = "Jianti", info = "Español", name = "es"},          --(西班牙语)
	-- [8] = {id = 8, des = "Fanti", info = "ไทย", name = "th"},               --(泰语)
	-- [9] = {id = 9, des = "English", info = "Indonesia", name = "id"},       --(印度尼西亚语)
	-- [10] = {id = 10, des = "Jianti", info = "italiano", name = "it"},       --(意大利语)
	-- [11] = {id = 11, des = "Fanti", info = "한국어", name = "kr"},           --(韩语)
	-- [12] = {id = 12, des = "English", info = "Malaysia", name = "my"},       --(马来西亚语)
	-- [13] = {id = 13, des = "Jianti", info = "Tiếng Việt", name = "vn"},      --(越南语)
	-- [14] = {id = 14, des = "Fanti", info = "Türkçe", name = "tr"},           --(土耳其语)
	-- [15] = {id = 15, des = "English", info = "Indonesia", name = "in"},      --(印度尼西亚语)
	-- [16] = {id = 16, des = "English", info = "Português", name = "pt"},      --(葡萄牙语)
	-- [17] = {id = 17, des = "Jianti", info = "Čeština", name = "cz"},         --(捷克语)
	-- [18] = {id = 18, des = "Fanti", info = "Українська", name = "ua"},       --(乌克兰语)
	-- [19] = {id = 19, des = "English", info = "română", name = "ro"},         --(罗马尼亚语)
	-- [20] = {id = 20, des = "Fanti", info = "polski", name = "pl"},           --(波兰语)
	-- [21] = {id = 21, des = "English", info = "Nederlands", name = "nl"},     --(荷兰语)
}


return LanguageDef