local propchange = {}


function propchange:tabletrack(slotname, source)
    local t = { _prop = true }
    local _base = {}
    local _percent = {}
    local _slotname = slotname
    local mt = {
        __index = function (t, k)
            local value = _base[k]
            if _percent[k] then
                value = value + math.floor(_percent[k] / 1000 * value)
            end
            return value
        end,
        __newindex = function (t, k, v)
            local old = t[k]
            _base[k] = v
            self:notify(_slotname, source, k, t[k], old)
        end,
    }
    t.setpercent = function (t, k, v)
        local old = t[k]
        _percent[k] = (_percent[k] or 0) + v
        self:notify(_slotname, source, k, t[k], old)
    end
    t.setbase = function (t, k, v)
        local old = t[k]
        _base[k] = (_base[k] or 0) + v
        self:notify(_slotname, source, k, t[k], old)
    end
    return setmetatable(t, mt)
end

function propchange:pull(event, context, prop)
    local keylist = {}
    for key, value in pairs(event) do
        table.insert(keylist, key)
    end
    table.sort(keylist)
    for _, key in ipairs(keylist) do
        local func = event[key]
        assert(type(func) == 'function')
        local value = prop[key]
        func(context, value, value)
    end
end

function propchange:notify(slot, to, key, newvalue, oldvalue)
    local slot = global.service.eventslots:getslot(slot)
    slot:send(to, key, newvalue, oldvalue)
end

function propchange:dispose()
end

return propchange