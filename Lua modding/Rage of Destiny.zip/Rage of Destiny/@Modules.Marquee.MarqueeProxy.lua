local Timer = require "Common.Util.Timer"
local httputil = require "Common.Util.httputil"
local rapidjson = require "rapidjson"
local LoginProxy = require "Modules.Login.LoginProxy"
local LoginDef = require "Modules.Login.LoginDef"
local MarqueeDef = require "Modules.Marquee.MarqueeDef"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local LanguageDef = require "Common.Mgr.Language.LanguageDef"

local MarqueeProxy = MarqueeProxy or BaseClass(BaseProxy)
function MarqueeProxy:__init()
	MarqueeProxy.Instance = self
	self.data = {}
	self.data.marqueeInfo = {}
	self.data.lastdata = {}
	self.isshow = false
	self:AddProto(20600, self.On20600)
	self:AddProto(20601, self.On20601)
end

function MarqueeProxy:__delete()
	if self.marqueeTimer then self.marqueeTimer:Stop() self.marqueeTimer = nil end
	self.isshow = false
	self.data = nil
end

function MarqueeProxy:Send20600()
	self:SendMessage(20600)
end

function MarqueeProxy:On20600(decoder)
	local _type,_msg_type,_marqueeid,_duration = decoder:Decode("I2I2I4I4")
	-- print("On20600=====",  _type,_msg_type,_marqueeid,_duration)
	--消息类型（1及时消息 2循环消息） 跑马灯类型（1自由编辑内容 2读配置） 跑马灯id 跑马灯显示时间
	self.data._type, self.data._msg_type, self.data._marqueeid, self.data._duration = _type,_msg_type,_marqueeid,_duration
	self:GetRandomNum(_type, _msg_type, _marqueeid)
end

function MarqueeProxy:GetRandomNum(_type, _msg_type, _marqueeid)
	if self.data.lastdata and self.data.lastdata._type and self.data.lastdata._msg_type and self.data.lastdata._marqueeid then
		if self.marqueeTimer then
			self.marqueeTimer:Stop()
			self.marqueeTimer = nil
		end
		if _type == self.data.lastdata._type then 
			self:GetMarqueeInfoByTypeMarqueeid(self.data.lastdata._type, self.data.lastdata._msg_type, self.data.lastdata._marqueeid)
		else
			--更换不同类型消息
			self.data.marqueeInfo = {}
			self:ToNotify(self.data, MarqueeDef.Notify.UpdateMarqueeType)
		end
	else
		if self.data.lastdata and self.data.lastdata.curtype then
			if _type ~= self.data.lastdata.curtype then
				--更换不同类型消息
				self.data.marqueeInfo = {}
				self:ToNotify(self.data, MarqueeDef.Notify.UpdateMarqueeType)
			end
		end
	end
	self.data.lastdata = {curtype = _type, _type = _type, _msg_type = _msg_type, _marqueeid= _marqueeid}
	local num = math.random(1, 10)
	self.marqueeTimer = Timer.New(function()
		if self.marqueeTimer then self.marqueeTimer:Stop() self.marqueeTimer = nil end
		self:GetMarqueeInfoByTypeMarqueeid(_type, _msg_type, _marqueeid)
		self.data.lastdata = {curtype= _type}
	end, num, 1)
	self.marqueeTimer:Start()
end

function MarqueeProxy:GetMarqueeInfoByTypeMarqueeid(_type, _msg_type, marqueeid)
	--目前没有配置跑马灯类型
	-- if _msg_type ~= 1 then
	-- 	--读配置
	-- 	local info = self:GetMarqueeInfoById(marqueeid)
	-- 	if info then 
	-- 		self:OnMarqueeCallBack(info)
	-- 	else
	-- 		print("marqueeid is nil, marqueeid: ", marqueeid)
	-- 	end
	-- 	return 
	-- end

    local t = {
        ["marqueeid"] = marqueeid,
        ["package"] = SystemConfig.AgentPackageID,
    }

    local p = {
        ["api"] = "horse",
        ["func"] = "getHorse",
        ["params"] = t
    }
    local params = {}
    params.token = LoginProxy.Instance:cms_encrypt(rapidjson.encode(p))
    local baseUrl = SystemConfig.Router
    local url = baseUrl .. LoginDef.api.gameapi
    httputil.post(url, params, function(text)
        local info = rapidjson.decode(text)
        -- print("GetMarqueeInfoByTypeMarqueeid=========", table.dump(info))
        self:OnMarqueeCallBack(info.code, info.data)
    end)
end

--<%t11122221>
function MarqueeProxy:MatchTime(content)
	local strContent = ""
	if content then
		for s in string.gmatch(content, "%<%%t(%d+)%>") do
			local DateFormatUtil = require "Common.Util.DateFormatUtil"
			local s1 = DateFormatUtil.format(math.ceil(tonumber(s)))
			local key = '%<%%t'..s..'%>'
			content = string.gsub(content, key, s1)
		end
		strContent = content
	end
	return strContent
end

function MarqueeProxy:OnMarqueeCallBack(code, data)
	local info = {}
	if code and code == 0 then
		local strConten = self:MatchTime(data.content)
		info.content = strConten
		self.data._duration = (self.data._duration==0) and 5 or self.data._duration
		info.duration = self.data._duration
		if self.isshow then
			table.insert(self.data.marqueeInfo, info)
			self:ToNotify(self.data, MarqueeDef.Notify.UpdateMarqueeInfo, {})
			-- local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MarqueeView)
			-- if view and not view:IsOpen() then
			-- 	LuaLayout.Instance:OpenWidget(UIWidgetNameDef.MarqueeView)
			-- end
		end
	end
end

function MarqueeProxy:GetMarqueeInfo()
	if self.data.marqueeInfo[1] then
		return self.data.marqueeInfo[1]
	end
	return nil
end

function MarqueeProxy:RemoveMarqueeInfo()
	table.remove(self.data.marqueeInfo, 1)
end

--关闭跑马灯
function MarqueeProxy:On20601(decoder)
	local isclose = decoder:Decode("I2")
	if self.marqueeTimer then self.marqueeTimer:Stop() self.marqueeTimer = nil end
	self.data.marqueeInfo = {}
	self.data.lastdata = {}
	self:ToNotify(self.data, MarqueeDef.Notify.CloseMarquee)
	-- local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MarqueeView)
end

function MarqueeProxy:SetMarqueeShowActive(bActive)
	self.isshow = bActive
end

function MarqueeProxy:ClearMarqueeInfos()
	if self.data.marqueeInfo then
		self.data.marqueeInfo = {}
	end
end

function MarqueeProxy:GetMarqueeConfig()
	local config = ConfigManager.GetConfig("data_marquee")
	return config
end

function MarqueeProxy:GetMarqueeInfoById(id)
	local config = self:GetMarqueeConfig()
	if config[id] then
		return config[id]
	end
	return nil
end



return MarqueeProxy