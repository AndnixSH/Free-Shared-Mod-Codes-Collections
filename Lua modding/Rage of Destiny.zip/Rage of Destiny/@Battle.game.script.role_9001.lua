-- 挂机怪物
local conf = {skill = {}, buff = {}}


return conf