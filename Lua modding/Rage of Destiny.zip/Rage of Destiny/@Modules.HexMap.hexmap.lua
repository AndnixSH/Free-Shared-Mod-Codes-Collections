local hexmapbuild = require "Modules.HexMap.hexmapbuild"

local printwalkpath = false

-- 格子状态
local CELL_STATUS =
{
	INIT = 0,
	OPEN = 1,
	DONE = 2,
}

local function packbuffer(fmt, ...)
	return { fmt = fmt, data = {...}}
end

local function packlist(fmt, list)
	local _fmt = "I2"
	local count = #list
	local data = {}
	table.insert(data, count)
	for i = 1, count do
		_fmt = _fmt .. fmt
		table.insert(data, list[i])
	end
	return { fmt = _fmt, data = data }
end

local base_cell = {}

function base_cell:New(o)
	o = o or {}
	setmetatable(o, {__index = self})
	return o
end

function base_cell:init()
	if self.oninit then
		--print("初始化格子", self.id)
		self:oninit()
	end
end

function base_cell:enter(from, is_follower)
	if not self.hexmap:getfollowing() then
		self.prop.entered = true
		if self.onenter then
			--print(is_follower and "马车" or "build","进入格子", self.id)
			self:onenter(from, is_follower)
		end
	end
end

function base_cell:leave(is_follower)
	if self.prop.entered then
		self.prop.entered = false
		if self.onleave then
			--print(is_follower and "马车" or "build","离开格子", self.id)
			self:onleave(is_follower)
		end
	end
end

function base_cell:clear()
	if self.build.type == HEXMAP_BUILD.LASER_GENERATOR then
		self.build:_clear_laser_cells()
	end
	if self.build.type == HEXMAP_BUILD.DONE_GUIDE then
		self.build:showguide()
	end
end

function base_cell:setbuild(newbuild)
	local oldbuild = self.build
	if oldbuild then
		self:leave(false)
		self:clear()
	end
	self.build = newbuild
	--print("设置build，格子ID", self.id, "buildid", newbuild and newbuild.id or nil)
	if newbuild then
		self:enter(nil, false)
	end
end

local hexcell = base_cell:New{ 
    __tostring = function(self)
        return string.format("id:%s fog:%d enable:%s walkable:%s step:%s", self.id, self.fog, self.enable, self.walkable, self.step)
    end,
}

--开关格子(type=2)
local switch_cell = hexcell:New{
	--data格式{要操作的格子,{cell底图资源列表}}
	oninit = function(self)
		if self.build then
			self:enter(nil, false)
		end
	end,
	onenter = function(self, from, is_follower)
		self:_change_cell_bg(true)
		self:_operate_target(true)
	end,

	onleave = function(self, is_follower)
		--用于follower或者其他物体离开格子时的逻辑时
		self:_change_cell_bg(false)
		self:_operate_target(false)
	end,
	
	_change_cell_bg = function(self, benter)
		local prefabs = self.static.data[2]--cell底图资源列表
		self.hexmap:update_cell(self, {prefab_id = benter and prefabs[1] or prefabs[2]})
	end,

	_operate_target = function(self, benter)
		if self.hexmap:getfollower() then
			local cellid = self:_get_operate_target_cell_id()
			self.hexmap:open_cell(cellid, benter and 1 or 2, packbuffer("I2", self.hexmap:getfollower()))--1为进入格子2为离开格子
		end
	end,

	_get_operate_target_cell_id = function(self)
		return self.static.data[1]--要操作的格子
	end,
}

--变向滑轨开关格子(控制滑轨是否变向)(type=3)
local switch_cell_for_change_dir_rail = switch_cell:New{
	--data格式{{控制的变向滑轨格子列表},{cell底图资源列表},{两头建筑格子},真假开关}
	_on_refresh_dir = function(self, benter)
		local cellids = self.static.data[1]
		local dir_index = self:_get_dir_index(benter)
		if dir_index == HEXMAP_DIR_CONST.ORIGINAL_DIR then
			cellids = table.reverse(cellids)
		end
		
		--先清除数据(有可能两个物体紧挨着在滑轨上)
		for _, cellid in ipairs(cellids) do
			local cell = self.hexmap:getcell(cellid)
			if cell and cell.build then
				cell.build.prop.move_to_cell_id = nil
			end
		end
		
		for _, cellid in ipairs(cellids) do
			local cell = self.hexmap:getcell(cellid)
			if cell then
				cell:_refresh_dir(benter)
			end
		end
		
		local end_cellids = self.static.data[3] or {}
		for _, cellid in ipairs(end_cellids) do
			--替换两头建筑
			self.hexmap:done_cell(cellid, packbuffer("I1", dir_index))
		end
	end,
	
	_operate_target = function(self, benter)
		local can_operate = self.static.data[4]
		if can_operate and (can_operate == 1) then
			self:_on_refresh_dir(benter)
		end
	end,
	
	_get_dir_index = function(self, benter)
		if benter ~= nil then
			return benter and HEXMAP_DIR_CONST.OPPOSITE_DIR or HEXMAP_DIR_CONST.ORIGINAL_DIR
		else
			if self.build or (self.hexmap:getfollower() and (self.id == self.hexmap:getfollower())) then
				return HEXMAP_DIR_CONST.OPPOSITE_DIR
			end
			return HEXMAP_DIR_CONST.ORIGINAL_DIR
		end
	end
}

--变向滑轨格子(type=4)
local change_dir_rail_cell = hexcell:New{
	--data格式{对应控制开关格子,{原始方向, 变化方向},{cell底图列表(两张,原始方向在前)}}
	onenter = function(self, from, is_follower)
		if not is_follower then
			self:_check_move_build()
		end
	end,
	
	_check_move_build = function(self, benter)
		if self.build then
			local control_cell = self.hexmap:getcell(self.static.data[1])
			if control_cell then
				local dir_index = control_cell:_get_dir_index(benter)
				local dir = self.static.data[2][dir_index]
	
				local cellids = control_cell.static.data[1]
				if dir_index == HEXMAP_DIR_CONST.ORIGINAL_DIR then
					cellids = table.reverse(cellids)
				end
				
				local to_cell_map = {}
				local from_cell_map = {}
				for _, cellid in ipairs(cellids) do
					if cellid == self.id then
						--只记录先移动的build就可以了
						break
					end
					local cell = self.hexmap:getcell(cellid)
					if cell and cell.build and cell.build.prop.move_to_cell_id then
						to_cell_map[cell.build.prop.move_to_cell_id] = cellid
						from_cell_map[cellid] = cell.build.prop.move_to_cell_id
					end
				end
				
				for _, cellid in ipairs(cellids) do
					if cellid == self.id then
						self.build.prop.move_to_cell_id = self.id
						break
					end
					if not to_cell_map[cellid] then
						self.build.prop.move_to_cell_id = cellid
						--if self.build.type == HEXMAP_BUILD.BALL then
							--self.hexmap:open_cell(self.id, 1, packbuffer("I1", dir))
						--else
							--self.hexmap:move_build(self.id, dir, cellid)
						--end
						self.hexmap:move_build(self.id, dir, cellid)
						break
					end
				end
			end
		end
	end,
	
	_refresh_dir = function(self, benter)
		self:_change_cell_bg(benter)
		self:_check_move_build(benter)
	end,
	
	_change_cell_bg = function(self, benter)
		local control_cell = self.hexmap:getcell(self.static.data[1])
		if control_cell then
			local dir_index = control_cell:_get_dir_index(benter)
			
			local prefabs = self.static.data[3]--cell底图资源列表
			self.hexmap:update_cell(self, {prefab_id = prefabs[dir_index]})
		end
	end,
	
	_is_same_rail = function(self, other_cell)
		return self.static.data[1] == other_cell.static.data[1]
	end,
}

--变向滑轨上的开关(type=5)
local switch_cell_on_change_dir_rail = {
--data格式{对应控制开关格子,{原始方向, 变化方向},{{有build或者follower底图列表(两张,原始方向在前)},{没build和follower底图列表(两张,原始方向在前)}},控制的门格子}
	onenter = function(self, from, is_follower)
		self:_change_cell_bg(true)
		if is_follower then
			if from then
				self:_operate_target(true)
			end
		else
			self:_operate_target(true)
			self:_check_move_build(true)
		end
	end,

	_change_cell_bg = function(self, enter_status)
		local control_cell = self.hexmap:getcell(self.static.data[1])
		if control_cell then
			local dir_index = control_cell:_get_dir_index()
			local benter = self.build or (self.hexmap:getfollower() and (self.id == self.hexmap:getfollower()))
			if (enter_status ~= nil) and (enter_status == false) then
				--传入false参数权限最高(follower离开格子时触发)
				benter = enter_status
			end
			local cell_bgs_index = benter and 1 or 2
			local prefabs = self.static.data[3][cell_bgs_index]--cell底图资源列表
			self.hexmap:update_cell(self, {prefab_id = prefabs[dir_index]})
		end
	end,
	
	_get_operate_target_cell_id = function(self)
		return self.static.data[4]--要操作的格子
	end,
}
setmetatable(switch_cell_on_change_dir_rail, {__index = function(t, k)
				local list = {switch_cell, change_dir_rail_cell}
				for _, v in ipairs(list) do
					if v[k] then
						return v[k]
					end
				end
			end})

--滑动格子(有build在上面可以滑动)(type=6)
local slide_cell = hexcell:New{
	--data格式{dir}
	onenter = function(self, from, is_follower)
		if (not is_follower)then
			self:_check_move_build()
		end
	end,
	
	_check_move_build = function(self)
		if self.build then
			local dir = self.static.data[1]
			local paths = {}
			local found = self.hexmap:surroundcell_dir(self, dir)
			while found and (not found.build) do
				table.insert(paths, found.id)
				if (found.static.type == HEXMAP_CELL.SLIDE) and (found.static.data[1] == dir) then
					--方向要一致
					found = self.hexmap:surroundcell_dir(found, dir)
				else
					break
				end
			end
			if #paths > 0 then
				self.hexmap:move_build(self.id, dir, paths[#paths])
			end
		end
	end
}

local CELL_TYPE_MAP = 
{
	[HEXMAP_CELL.NORMAL] = hexcell,
	[HEXMAP_CELL.SWITCH] = switch_cell,
	[HEXMAP_CELL.SWITCH_FOR_CHANGE_DIR_RAIL] = switch_cell_for_change_dir_rail,
	[HEXMAP_CELL.CHANGE_DIR_RAIL] = change_dir_rail_cell,
	[HEXMAP_CELL.SWITCH_ON_CHANGE_DIR_RAIL] = switch_cell_on_change_dir_rail,
	[HEXMAP_CELL.SLIDE] = slide_cell,
}

local hexmap = {}

function hexmap:init(map_config, cell_config, map_data, proxy)
    hexmapbuild.init(self)
    self.proxy = proxy
    self.map_data = map_data
    self.follower = nil
    self.following = false
    self._last_surr = nil
    self.map_step = nil
    self.map_config = map_config

    local width, height, cell_radius, start, cell_level = map_config.width, map_config.height, map_config.cell_radius, map_config.start, map_config.cell_level
    self.cshex = CS.LJY.HexMap.HexMap(width, height, cell_radius)
    self.mapinfo = { width = width,  height = height, outer_radius = cell_radius, inner_radius = cell_radius * 0.866025404, start = start, cell_level = cell_level }
    self.cells = {}


    local disablelist = {}
    local index = 0
    for z = 0, height - 1 do
        for x = 0, width - 1 do
            local cellcfg = cell_config[index]
            local cellinfo = map_data.cellinfos[index]
            if cellcfg and cellinfo then
                local cell = self:_create_cell(x, z, index, cellcfg, cellinfo)
                if not GameConfig.HEXMAP.super then
                    if not cell.walkable or (cell.build and not cell.build.through) then
                        table.insert(disablelist, index)
                    end
                end
            else
                table.insert(disablelist, index)
            end
            index = index + 1
        end
    end
    if #disablelist > 0 then
        self.cshex:Disable(disablelist)
    end

    for _, cell in pairs(self.cells) do
		cell:init()
        if cell.build then
            cell.build:init()
            cell.build:showinit()
        end
    end

	self:refresh_laser_build_info()
end

function hexmap:clear_follower()
	self.follower = nil
end

function hexmap:refresh()
    for _, cell in pairs(self.cells) do
        self:_notifycellupdate(cell)
		cell:init()
        if cell.build then
            cell.build:refresh()
            cell.build:showinit()
        end
    end
    self.cshex:RefreshMapView()
	
	self:refresh_laser_build_info()
end

function hexmap:_create_cell(x, z, index, cellcfg, cellinfo)

    local ix  = (x + z * 0.5 - math.floor(z / 2)) * self.mapinfo.inner_radius * 2
    local iz = (z * self.mapinfo.outer_radius * 1.5)

    local position = Vector3.New(ix, 0, iz)

    local status = cellinfo and cellinfo.status or CELL_STATUS.INIT
    local fog = status ~= CELL_STATUS.INIT and 0 or (cellcfg.fog or 0)
    local sight = true
    local cell = { id = index, type = cellcfg.type or HEXMAP_CELL.NORMAL, fog = fog, enable = true, walkable = cellcfg.walkable == 1, header = cellcfg.header, sight = sight, step = 1,
                    build = nil, position = position, prefab_id = cellcfg.prefab_id, static = cellcfg, hexmap = self, prop = {} }

    self:_update_step(cell, cellcfg.height)

    if status ~= CELL_STATUS.DONE and cellinfo.build ~= 0 then
        cell.build = hexmapbuild.create_build(cell, cellinfo.build)
    end
	setmetatable(cell, {__index = CELL_TYPE_MAP[cell.type]})
	
    self.cells[index] = cell
    self:_notifycellupdate(cell)
    return cell

end

function hexmap:enableingrid(cell)
    self.cshex:EnableCell(cell.id)
end

function hexmap:disableingrid(cell)
    self.cshex:DisableCell(cell.id)
end

function hexmap:_update_surround(cellid, updatevo)
    local surround = self:getsurround(cellid)
    for _, surr in ipairs(surround) do
        self:update_cell(surr, updatevo)
    end
end

function hexmap:operatecell(cellid)

    if not self:_canoperate() then return end

    local updatevo = {fog = 0}
    local curcell = self.cells[cellid]
    if curcell then
        self:update_cell(curcell, updatevo)
        if curcell.build then
			--print("操作", curcell.build.id, curcell.build.type)
            curcell.build:operate()
        end
        if self:getfollower()  then
            if not curcell.build then
                self:moveto(curcell)
            end
        else
            self:_update_surround(cellid, updatevo)
        end
    end
end

function hexmap:_canoperate()
    if self.follower then
        return not self.following
    end
    return true
end

function hexmap:setfollower(cellid)
    -- print("setfollower", cellid)
    local from = self.follower
	if from then
		local leave_cell = self:getcell(from)
		if leave_cell then
			leave_cell:leave(true)
		end
	end
    self.follower = cellid
	--print("设置跟随", cellid)
    local updatevo = {fog = 0,sight = true}
    local cell = self:getcell(cellid)
    if cell then
        self:setmapstep(cell.step)
        self:update_cell(cell, updatevo)
    end
    if cell then
		cell:enter(from, true)
		if cell.build then
			cell.build:enter(from)
		end
    end

    local surroundset = {}
    local surround = self:getsurround(cellid)
    for _, surr in ipairs(surround) do
        self:update_cell(surr, updatevo)
        surroundset[surr] = true
    end
    self._last_surr = surroundset
end

function hexmap:setmapstep(step)
    if self.map_step ~= step then
        self.map_step = step
        self.cshex:SetMapStep(step)
        local height = self.mapinfo.cell_level[step][2]
        local hexmaprender = require "Modules.HexMap.hexmaprender"
        hexmaprender.cmdfollower("update_shadow", height)
		
		self:refresh_laser_build_info()
    end
end

function hexmap:getmapstep()
    return self.map_step or 1
end

function hexmap:getfollower()
    return self.follower
end

function hexmap:_notifycellupdate(cell)
    self.proxy:UpdateCell(cell)
end

function hexmap:update_cell(cell, updatevo)
    local bupdate = false
    for k, v in pairs(updatevo) do
        if cell[k] ~= nil and cell[k] ~= v then
            cell[k] = v
            bupdate = true
            if k == 'fog' then
                self:proxy_notify("OnCellFogChange", cell)
            end
        end
    end
    if bupdate then
        self:_notifycellupdate(cell)
    end
end

function hexmap:set_build(cell, newbuild)
    local oldbuild = cell.build
	cell:setbuild(newbuild)
	
    self.proxy:UpdateBuild(cell)
    hexmapbuild.ntf("ntf_set_build", newbuild, oldbuild)
	self:refresh_laser_build_info()
end

function hexmap:_update_step(cell, step)
    if step ~= cell.step then
        cell.step = step -- 格子阶梯
        self.cshex:SetCellStep(cell.id, step)
    end
    local cell_lv = self.mapinfo.cell_level[cell.step]
    cell.height = cell_lv[2]
    cell.position = Vector3.New(cell.position.x, cell_lv[1], cell.position.z) -- 格子地下位置
    cell.top_position = Vector3.New(cell.position.x, cell.height, cell.position.z) -- 格子表层位置，build的位置
	
	if self:getfollower() then
		self:refresh_laser_build_info()
	end
	--print(cell.id, cell.height, cell.position, cell.top_position)
end

function hexmap:set_step(cell, step)
    if cell.step ~= step then
        self:_update_step(cell, step)
        local hexmaprender = require "Modules.HexMap.hexmaprender"
        hexmaprender.cellcmd(cell,"move_y", cell.position.y, 0.5)
        if self.follower and self.follower == cell.id then
            self:setmapstep(step)
            hexmaprender.cmdfollower("move_y", cell.height, 0.5)
        end
    end
end

function hexmap:update_build(cell, updatevo)
    for k, v in pairs(updatevo) do
        cell.build[k] = v
    end
    self.proxy:UpdateBuild(cell)
end

function hexmap:open_cell(cellid, step, buffer)
    self.proxy:OpenCell(cellid, step, buffer)
end

function hexmap:done_cell(cellid, buffer)
    self.proxy:DoneCell(cellid, buffer)
end

function hexmap:move_build(cellid, dir, to_cell_id)
	if cellid ~= to_cell_id then
		self.proxy:MoveBuild(cellid, dir, to_cell_id)
	end
end

function hexmap:getbuildshare(key)
    return self.map_data.buildshare[key]
end

function hexmap:setbuildshare(key, value)
    self.map_data.buildshare[key] = value
end

function hexmap:get_reward_add_percent()
	return self:getbuildshare("reward_add_percent") or 0
end

-- 获取格子服务器信息
function hexmap:getcellinfo(cellid)
    return self.map_data.cellinfos[cellid]
end

function hexmap:update_cell_status(cellid, status)
    local cell = self.cells[cellid]
    if cell then cell.status = status end
    local cellinfo = self.map_data.cellinfos[cellid]
    if cellinfo then cellinfo.status = status end
end

function hexmap:next_level()
    self.proxy:CreateCells()
end

function hexmap:getactivityid()
    return self.proxy:GetActivityid()
end

function hexmap:remove_build_by_id(buildid)
	for _, cell in pairs(self:getallcells()) do
		if cell then
			if cell.build and (cell.build.id == buildid) then
				hexmap:set_build(cell, nil)
				hexmap:update_cell(cell, {enable = true, fog = 0, walkable = true})
				hexmap:enableingrid(cell)
			end
		end
	end
end

function hexmap:pos_to_cell(pos)
    local x = pos.x / (self.mapinfo.inner_radius * 2)
    local y = -x
    local offset = pos.z / (self.mapinfo.outer_radius * 3)
    x = x - offset
    y = y - offset

    local ix = math.floor(x + 0.5)
    local iy = math.floor(y + 0.5)
    local iz = math.floor(-x - y + 0.5)

    if ix + iy + iz ~= 0 then
        local dx = math.abs(x - ix)
        local dy = math.abs(y - iy)
        local dz = math.abs(-x - y - iz)

        if dx > dy and dx > dz then
            ix = -iy - iz
        elseif  dz > dy then
            iz = -ix - iy
        end
    end


    local px = ix + math.floor(iz / 2)
    local py = iz

    local cell = self:_getcell(px, py)
    return cell

end

function hexmap:pathto(from, to, forcelast)
    local path_array = self.cshex:PathTo(from, to, forcelast)
    local paths = {}
    for i = 0, path_array.Length - 1 do
        table.insert(paths, path_array[i])
    end
    return paths
end

function hexmap:get_path(tocell, round)
	local now_round = round or 0
    local path = self:pathto(self.follower, tocell.id, tocell.build ~= nil)
    if #path > 0 then
        if tocell.build and not tocell.build.through then
            table.remove(path)
        end
		local follower_cell = self:getcell(self.follower)
		if follower_cell then
			if (follower_cell.type == HEXMAP_CELL.SWITCH) or (follower_cell.type == HEXMAP_CELL.SWITCH_ON_CHANGE_DIR_RAIL) then
				local door_operate_cell_id = follower_cell:_get_operate_target_cell_id()
				if table.indexof(path, door_operate_cell_id) then
					if now_round >= 2 then
						return nil
					else
						local door_operate_cell = self:getcell(door_operate_cell_id)
						self:disableingrid(door_operate_cell)
						local new_path = self:get_path(tocell, now_round + 1)
						self:enableingrid(door_operate_cell)
						return new_path
					end
				end
			end
		end
        return path
    end
end

function hexmap:remove_cell(cellid)
    self.cells[cellid] = nil
end

function hexmap:moveto(tocell, cbreach)

    if not self.follower or self.follower == tocell.id then return end

    local path = self:get_path(tocell)
    if not path then
        GameLogicTools.ShowMsgTips("Msgtips_hexmap_1014")
        return
    end
    -- print("moveto", #path, table.dump(path))
    if printwalkpath then
        local pathstr = {}
        table.insert(pathstr, tostring(self.follower))
        for i, v in ipairs(path) do
            table.insert(pathstr, tostring(v))
        end
        print("打印路径", #pathstr, table.concat(pathstr, ", "))
    end
    if #path > 0 then
        local targetcellid = path[#path]
        self.following = true
		local stop_following = false
		
		local move_end_func = function(cellid, reach)
			self.following = false
			self.proxy:MoveTo(cellid)
			self:setfollower(cellid)
			if cbreach and reach then cbreach() end
		end
		
        self.proxy:UpdateFollower(path, function ()
			if not stop_following then
            	move_end_func(targetcellid, true)
			end
        end, function (index)
            -- print("node", index)
            if index <= #path then
				local now_cell_id = path[index]
				
				--检测下一个格子是否可以走
				local next_index = index + 1
				if next_index <= #path then
					local next_cell_id = path[next_index]
					local next_cell = self:getcell(next_cell_id)
					if next_cell and (not self:is_walkable_cell(next_cell_id)) then
						stop_following = true
					end
				end
					
				if stop_following then
					local cell = self:getcell(now_cell_id)
					if cell then
						self.proxy:StopFollower({position = cell.top_position})
					end
						
					move_end_func(now_cell_id)
				else
					self:setfollower(now_cell_id)
					self:setfollowing(true)
				end
            end
        end)
    else
        if cbreach then cbreach() end
    end
end

function hexmap:setfollowing(bfllowing)
    self.following = bfllowing
end

function hexmap:getfollowing()
    return self.following
end

function hexmap:blinkto(tocell)
    if tocell and tocell.walkable and tocell.enable then
        self.proxy:BlinkFollower(tocell.id)
        self.proxy:MoveTo(tocell.id)
        self:setfollower(tocell.id)
        return true
    end
    return false
end

function hexmap:getsurround(cellid)
    local width = self.mapinfo.width
    local x, y = cellid % width, math.floor(cellid / width)
    local surround = {}
    self:_addtosurround(surround, x - 1, y)
    self:_addtosurround(surround, x + 1, y)
    local left = y % 2 == 0 and x - 1 or x
    self:_addtosurround(surround, left, y - 1)
    self:_addtosurround(surround, left + 1, y - 1)
    self:_addtosurround(surround, left, y + 1)
    self:_addtosurround(surround, left + 1, y + 1)
    return surround
end

function hexmap:idtoxy(cellid)
    local width = self.mapinfo.width
    local x, y = cellid % width, math.floor(cellid / width)
    return x, y
end

function hexmap:xytoid(x, y)
    local index = x + y * self.mapinfo.width
    return index
end

function hexmap:getmapinfo()
    return self.mapinfo
end

function hexmap:getmapconfig()
    return self.map_config
end

function hexmap:_addtosurround(surround, x, y)
    local cell = self:_getcell(x, y)
    if cell then
        table.insert(surround, cell)
    end
end

function hexmap:_getcell(x, y)
    if x >= 0 and x < self.mapinfo.width and y >= 0 and y < self.mapinfo.height then
        local index = x + y * self.mapinfo.width
        return self.cells[index]
    end
end

function hexmap:getallcells()
    return self.cells
end

function hexmap:getcell(cellid)
    return self.cells[cellid]
end

function hexmap:searchcell(filter)

    if not filter then return end

    for k, cell in pairs(self.cells) do
        if filter(cell) then
            return cell
        end
    end
end

function hexmap:searchcell_dir(cell, dir, filter)

    if not filter then return end
    
    local cellid = cell.id
    local width = self.mapinfo.width
    local x, y = cellid % width, math.floor(cellid / width)

    local found = nil
    local scount = 0

    while true do

        local even = y % 2 == 0

        if dir == 1 then
            x = even and x or x + 1
            y = y + 1
        elseif dir == 2 then
            x = x + 1
        elseif dir == 3 then
            x = even and x or x + 1
            y = y - 1
        elseif dir == 4 then
            x = even and x - 1 or x
            y = y - 1
        elseif dir == 5 then
            x = x - 1
        elseif dir == 6 then
            x = even and x - 1 or x
            y = y + 1
        else
            print("错误的方向", dir)
            break
        end

        cell = self:_getcell(x, y)
        scount = scount + 1

        if not cell or filter(cell) then
            found = cell
            break
        end
    end

    return found

end

function hexmap:surroundcell_dir(cell, dir)

    local cellid = cell.id
    local width = self.mapinfo.width
    local x, y = cellid % width, math.floor(cellid / width)

    local even = y % 2 == 0

    if dir == 1 then
        x = even and x or x + 1
        y = y + 1
    elseif dir == 2 then
        x = x + 1
    elseif dir == 3 then
        x = even and x or x + 1
        y = y - 1
    elseif dir == 4 then
        x = even and x - 1 or x
        y = y - 1
    elseif dir == 5 then
        x = x - 1
    elseif dir == 6 then
        x = even and x - 1 or x
        y = y + 1
    else
        print("错误的方向", dir)
    end

    local found = self:_getcell(x, y)
    return found

end

function hexmap:find_continuous_cells_by_dir(cell, dir, filter)
	local cells = {}
	local found = self:searchcell_dir(cell, dir, filter)
	local count = 1000
	while found and (count > 0) do
		table.insert(cells, found)
		found = self:searchcell_dir(found, dir, filter)

		count = count - 1
	end
	return cells
end

function hexmap:require_hero_list()
    self.proxy:RequireHeroList()
end

function hexmap:proxy_notify(key, args)
    self.proxy:Proxy_Notify(key, args)
end

function hexmap:proxy_calll(call, ...)
    self.proxy:Proxy_Call(call, ...)
end

function hexmap:getlastbattle()
    return self.proxy:GetBattleCell()
end

function hexmap:is_walkable_cell(cellid, check_step)
	if GameConfig.HEXMAP.super then
		return true
	end
	check_step = check_step or self.map_step
	local cell = self:getcell(cellid)
	if cell then
		if cell.step == check_step then
			if (not cell.walkable) or (cell.build and not cell.build.through) then
				return false
			end
			return true
		end
	end
	return false
end

function hexmap:is_can_through_laser_cell(from_cell_id, to_cell_id)
	local from_cell = self:getcell(from_cell_id)
	local cell = self:getcell(to_cell_id)
	if from_cell and cell then
		if from_cell.step > cell.step then
			return true
		elseif cell.step == from_cell.step then
			if not cell.build then
				return true
			end
		end
	end
	return false
end

function hexmap:refresh_laser_build_info()
	--print("刷新激光开始",debug.traceback())
	
	local laser_cell_map = {}
	local laser_switch_map = {}

	local wait_init_laser_transform_cell = {}
	local wait_init_laser_color_cell = {}

	local init_laser_info_func = function (cell, line_cell_map)
		if cell.build.static.data[1] == 0 or cell.build.static.data[1] == 2 then
			wait_init_laser_color_cell[cell.id] = true
		end

		for dir, line_cells in pairs(line_cell_map) do
			local last_cell = line_cells[#line_cells]
			if last_cell and last_cell.build and (last_cell.build.type == HEXMAP_BUILD.LASER_GENERATOR) then
				--受不同颜色激光照射 会禁止
				--受激光照射 发射同种颜色光线
				if last_cell.build.static.data[1] == 0 or last_cell.build.static.data[1] == 2 or (last_cell.build.static.data[1] == 1 and last_cell.build.static.data[2] ~= cell.build.static.data[2]) then
					laser_cell_map[last_cell.id] = laser_cell_map[last_cell.id] or {build = last_cell.build, laser_source = {}, effect_cell_ids = {}, active = true, laser_source_dir = {}}
					table.insert(laser_cell_map[last_cell.id].laser_source, cell.id)
					table.insert(laser_cell_map[last_cell.id].laser_source_dir, dir)
					table.insert(laser_cell_map[cell.id].effect_cell_ids, last_cell.id)
					--last_cell.build:set_laser_color_type()
				end

			end
			if last_cell and last_cell.build and (last_cell.build.type == HEXMAP_BUILD.LASER_SWITCH) then
		 		laser_switch_map[last_cell.id] = laser_switch_map[last_cell.id] or {build = last_cell.build, laser_source = {}}
		 		table.insert(laser_cell_map[cell.id].effect_cell_ids, last_cell.id)
		 	end
		end
	end

	local all_cells = self:getallcells()
	for i,cell in pairs(all_cells) do
		if cell.build and (cell.build.type == HEXMAP_BUILD.LASER_GENERATOR) then
			laser_cell_map[cell.id] = laser_cell_map[cell.id] or {build = cell.build, laser_source = {}, effect_cell_ids = {}, active = true, laser_source_dir = {}}
			--类型2 激光转换器没有初始方向 需要知道其入射光才能知道方向
			if cell.build.static.data[1] ~= 2 or #laser_cell_map[cell.id].laser_source > 0 then
				local line_cell_map = cell.build:_get_laser_line_cell()
				init_laser_info_func(cell, line_cell_map)
			else
				wait_init_laser_transform_cell[cell.id] = laser_cell_map[cell.id]
			end
		elseif cell.build and (cell.build.type == HEXMAP_BUILD.LASER_SWITCH) then
			laser_switch_map[cell.id] = laser_switch_map[cell.id] or {build = cell.build, laser_source = {}}
		end
	end

	--类型2 激光转换器没有初始方向 需要知道其入射光才能知道方向 所以放在后面再进行一次初始化
	for cellid,info in pairs(wait_init_laser_transform_cell) do
		local cell = self:getcell(cellid)
		if #laser_cell_map[cell.id].laser_source > 0 then
			local source_cell_id = laser_cell_map[cell.id].laser_source[1]
			local source_dir = info.laser_source_dir[1]

			local line_cell_map = cell.build:_get_laser_line_cell(info.laser_source_dir)
			init_laser_info_func(cell, line_cell_map)
			cell.build:set_laser_dirs(info.laser_source_dir)
		end
	end

	local temp_bool = true
	local limit_times = 10
	while temp_bool and limit_times > 0 do
		temp_bool = false
		for cellid in pairs(wait_init_laser_color_cell) do
			local info = laser_cell_map[cellid]
			local cell = self:getcell(cellid)
			local laser_color_type = cell.build:get_laser_color_type()
			if not laser_color_type and #info.laser_source > 0 then
				local source_cell = self:getcell(info.laser_source[1])
				local source_cell_color_type = source_cell.build.static.data[2]
				if source_cell.build:is_need_laser_active() then
					source_cell_color_type = source_cell.build:get_laser_color_type()
				end
				if source_cell_color_type then
					if cell.build.static.data[1] == 2 then
						source_cell_color_type = source_cell_color_type == 1 and 2 or 1
					end
					cell.build:set_laser_color_type(source_cell_color_type)
					temp_bool = true
				end
			end
		end
		limit_times = limit_times - 1
	end

	
	--print("激光格子统计", table.dump(laser_cell_map))
	
	local init_laser_cell_list = {}
	local init_laser_cell_map = {}
	local init_laser_switch_map = {}

	local total_laser_cell_num = 0
	
	local init_laser_cell_func = function(cell_id, can_laser)
		--print("初始化激光格子", cell_id, can_laser, debug.traceback())
		local info = laser_cell_map[cell_id]
		if info then
			info.build:_change_laser_active(can_laser)
			info.active = can_laser
			
			if (not init_laser_cell_map[cell_id]) then
				table.insert(init_laser_cell_list, cell_id)
				init_laser_cell_map[cell_id] = true
			end
		end
	end

	local init_laser_effect_cell_func = function (self,cell_info)
		local info = cell_info
		for i,effect_cell_id in ipairs(info.effect_cell_ids) do
			local effect_cell = self:getcell(effect_cell_id)
			if effect_cell.build.type == HEXMAP_BUILD.LASER_GENERATOR then
				if effect_cell.build.static.data[1] == 1  then
					if laser_cell_map[effect_cell_id] and (not init_laser_cell_map[effect_cell_id]) then
						init_laser_cell_func(effect_cell_id, false)
					end
				elseif effect_cell.build.static.data[1] == 0 or effect_cell.build.static.data[1] == 2 then
					if laser_cell_map[effect_cell_id] and (not init_laser_cell_map[effect_cell_id]) then
						init_laser_cell_func(effect_cell_id, true)
					end
				end
			elseif effect_cell.build.type == HEXMAP_BUILD.LASER_SWITCH then
				local source_laser_type = info.build:get_laser_color_type() or info.build.static.data[2]
				effect_cell.build:_change_active(source_laser_type)
				init_laser_switch_map[effect_cell_id] = true
			end
		end
	end
	
	for cell_id, info in pairs(laser_cell_map) do
		total_laser_cell_num = total_laser_cell_num + 1
		--判断是否被其他激光发射器影响
		--local cell = self:getcell(cell_id)
		if info.build.static.data[1] == 1  then
			if #info.laser_source == 0 then
				init_laser_cell_func(cell_id, true)
				init_laser_effect_cell_func(self, info)

			end
		elseif info.build.static.data[1] == 0 or info.build.static.data[1] == 2 then
			if #info.laser_source > 0 then

				local source_cell_id = info.laser_source[1]
				local source_cell = self:getcell(source_cell_id)
				if not source_cell.build:is_need_laser_active() or source_cell.build:is_laser_active() then
					init_laser_cell_func(cell_id, true) -- source_cell.build.static.data[2]
					init_laser_effect_cell_func(self, info)
				end
			end
		end
	end
	
	local max_loop = 10
	local count = 0
	while ((#init_laser_cell_list) < total_laser_cell_num) and (count < max_loop) do
		for cell_id, info in pairs(laser_cell_map) do
			local cell = self:getcell(cell_id)
			if (not init_laser_cell_map[cell_id]) then
				local can_laser = true
				local laser_active_type = cell.build.static.data[1]
				if laser_active_type == 1 then
					for i,source_cell_id in ipairs(info.laser_source) do
						local source_cell_info = laser_cell_map[source_cell_id]
						
						if (not init_laser_cell_map[source_cell_id]) or (source_cell_info and source_cell_info.active) then
							can_laser = false
							break
						end
					end
				elseif laser_active_type == 0 or laser_active_type == 2 then
					can_laser = false
					for i,source_cell_id in ipairs(info.laser_source) do
						local source_cell_info = laser_cell_map[source_cell_id]
						
						if (init_laser_cell_map[source_cell_id]) and (source_cell_info and source_cell_info.active) then
							can_laser = true
							break
						end
					end
				end
				
				if can_laser then
					init_laser_cell_func(cell_id, true)
				end
			end
		end
		count = count + 1
	end
	if count >= max_loop then
		print("发射激光循环次数超出上限")
	end
	
	for cell_id,info in pairs(laser_cell_map) do
		if (not init_laser_cell_map[cell_id]) then
			print("没有真正初始化", cell_id)
			init_laser_cell_func(cell_id, false)
		end
	end

	for cell_id in pairs(laser_switch_map) do
		if not init_laser_switch_map[cell_id] then
			local cell = self:getcell(cell_id)
			cell.build:_change_active(0)
		end
	end
	
	--print("刷新激光结束")
end

return hexmap
