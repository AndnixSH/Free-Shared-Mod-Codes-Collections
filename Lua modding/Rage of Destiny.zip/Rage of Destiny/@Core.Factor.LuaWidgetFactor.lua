local DynamicTable = nil
-- 能动态创建非nil字段的table
DynamicTable = function(_table)
    local func = function(t1, k)
        if not rawget(t1, k) then
            t1[k] = {}
            return DynamicTable(t1[k])
        end
        return t1[k]
    end
    setmetatable(_table, { __index = func })
    return _table
end

function LuaWidgetClass(...)
    local class = LuaEventClass(LuaBasicWidget, ...)
    return class
end

function LuaEventClass(...)
    local class = BaseClass(...)
    class.EvtNotify = {} --Proxy事件
    class.EvtProp = {} --table属性事件
    class.event = {} --战斗用的事件

    DynamicTable(class.EvtNotify)
    DynamicTable(class.EvtProp)
    DynamicTable(class.event)
    return class
end

local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local FrameUpdateMgr = require "First.Util.FrameUpdateMgr"
local TweenWidget = require "Core.Implement.UI.Widgets.TweenWidget"
local ModuleManager = require "Common.Mgr.UI.ModuleManager"

LuaWidgetFactor = LuaWidgetFactor or BaseClass(TweenWidget)

WidgetState = {
    free = 0,
    loading = 1,
    open = 2,
    close = 3,
}
LuaWidgetFactor.bTween = true

function LuaWidgetFactor:__init()
    self.state = WidgetState.free
    self._bsave = false
    self.bloadendopen = true --用来标志加载完以后是否打开还是关闭,解决异步打开时候突然关闭问题
    self.setcount = -1
    self.netsetcount = -1
    self.canvasDepth = 0
    self.listpanel = {}
    self.wigetName = nil
end

function LuaWidgetFactor:__delete()
    self.go = nil
end

function LuaWidgetFactor:SetGo(obj)
    self.go = obj
    if obj == nil then
        print("-------------------ERROR obj is nil:", LuaLayout.Instance:GetWidgetName(self))
        return
    else
        self:SetPopupView()
    end

    local layoutInfo = LuaLayout.Instance:GetLayoutInfo(self)
    if layoutInfo then
        local parenWidget = LuaLayout.Instance:GetWidget(layoutInfo.parentname)
        if parenWidget and parenWidget.go then
            GameObjTools.SetParent(obj, parenWidget.go)
            self:SetUIFit(obj)
            if GameConfig.ISEDITOR then -- 方便策划修改预设
                self:SetLabel(obj) -- 使用awake callback的方式
                self:SetAtlasSprite(obj) -- 使用awake callback的方式
            end
        end
    end

    self.wigetName = LuaLayout.Instance:GetWidgetName(self)
end

function LuaWidgetFactor:SetPopupView()
    if self.tweenOption and self.tweenOption.bScale then
        self._tweenObj = self:GetChild(self.go, "root")
        self._closebtn = self:GetChildComponent(self.go, "mask/Black", "CButton")
        if self._closebtn then
            self._closebtn:AddClick(function()
                if self.tweenOption.closeCallback then
                    self.tweenOption.closeCallback()
                else
                    self:CloseView()
                end
            end)
        end
    end
end

function LuaWidgetFactor:SetUIFit(obj)
    GameObjTools.SetRectTransform(obj, Vector2.zero, Vector2.zero, Vector2.one, Vector2.zero, Vector2.New(0.5, 0.5))
end

function LuaWidgetFactor:SetLabel(obj)
    LanguageManager.Instance:TranslateChildLabel(obj)
end

--多语言设置atlas
function LuaWidgetFactor:SetAtlasSprite(obj)
    LanguageManager.Instance:TranslateChildSprite(obj)
end

function LuaWidgetFactor:Open()
    if WidgetState.free == self.state then
        self.state = WidgetState.loading
        self:OnLoad()
    elseif self.state == WidgetState.close then
        self.state = WidgetState.open
        self:CheckOpen()
    elseif self.state == WidgetState.loading then
        self.bloadendopen = true
    end
end

function LuaWidgetFactor:Close()
    if self.state == WidgetState.open then
        self:CheckClose()
        for name, panel in pairs(self.listpanel) do
            self:ClosePanel(name)
        end
        self.state = WidgetState.close
    elseif self.state == WidgetState.loading then
        -- self.state = WidgetState.close
        self.bloadendopen = false
    end
end

function LuaWidgetFactor:Destroy()
    if self.state == WidgetState.free or self.state == WidgetState.loading then
        return
    end

    self:EnableWidgetCallBack(false)
    self.state = WidgetState.free
    self:OnDestroy()
    --if self.resName then
    --    AssetManager.UnloadUIPrefab(self.resName)
    --end
    --GameObjTools.Destroy(self.go)
    AssetManager.DestroyUIPrefab(self.resName, self.go, self._bsave)
end

function LuaWidgetFactor:Step(step)
    self.setcount = self.setcount - step
    if 0 >= self.setcount then
        self:StepEnd()
    end
end

function LuaWidgetFactor:SetStep(count)
    self.setcount = count
    if 0 == self.setcount then
        self:StepEnd()
    end
end

function LuaWidgetFactor:StepEnd()
    if self.state == WidgetState.loading then
        if self.bloadendopen then
            self.state = WidgetState.open
            self:CheckOpen()
        else
            self.state = WidgetState.close
            self.bloadendopen = true --回复正常状态
            self.go:SetActive(false)
        end

    elseif self.state == WidgetState.close then
        self.go:SetActive(false)
    end

end

--网络加载step return 是否在等待中
function LuaWidgetFactor:NetStep(step)
    if 0 >= self.netsetcount then
        return false
    end --反正二次回调

    self.netsetcount = self.netsetcount - step or 1
    if 0 >= self.netsetcount then
        self:NetStepEnd()
    end
    return true
end

function LuaWidgetFactor:SetNetStep(count)
    if AppConfig.ISALONE then
        self:OnNetOpen()
        return
    end
    self.netsetcount = count
    if 0 == self.netsetcount then
        self:NetStepEnd()
    else
        LuaLayout.Instance:OpenWidget(UIWidgetNameDef.ReconnectView)
    end
end

function LuaWidgetFactor:NetStepEnd()
    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ReconnectView)
    self:OnNetOpen()
    self:_ViewCheckNewbie()
end

function LuaWidgetFactor:IsReady()
    if self.state == WidgetState.free then
        return false
    end
    return true
end

function LuaWidgetFactor:IsOpen()
    if self.state == WidgetState.open then
        return true
    end
    return false
end

function LuaWidgetFactor:IsLoading()
    if self.state == WidgetState.loading then
        return true
    end
    return false
end

function LuaWidgetFactor:CheckOpen()
    local wigetName = LuaLayout.Instance:GetWidgetName(self)
    local option = ModuleManager.GetFullScreenOption(wigetName)
    if option then
        self.fullScreenOption = self.fullScreenOption or {}
        if option.isOpen then
            for k, v in pairs(option) do
                self.fullScreenOption[k] = v
            end
        else
            local FullScreenView = require "Modules.Common.FullScreen.FullScreenView"
            FullScreenView.UpdateOption(option)
        end
    end

    local openfunc = function()
        self:_AutoSetDepth()
        self:OnOpen()
        self:_ViewCheckNewbie()
        self:EnableWidgetCallBack(true)
    end

    if self.tweenOption and LuaWidgetFactor.bTween then
        if self.tweenOption.bInterlude or self.tweenOption.bInterludeOnlyOpen then
            self:OpenAniView(function()
                openfunc()
            end)

        elseif self.tweenOption.bScale then
            self:OpenScaleTween(self._tweenObj or self.go , self.tweenOption.OpenTweenCallback)
            openfunc()
        else
            openfunc()
        end
    else
        openfunc()
    end
end

function LuaWidgetFactor:CheckClose()

    local closefunc = function()
        self:EnableWidgetCallBack(false)
        self:_AutoClearDepth()
        self:OnClose()
    end

    if self.tweenOption and LuaWidgetFactor.bTween then
        if self.tweenOption.bInterlude then
            self:CloseAniView(function()
                closefunc()
            end)
        elseif self.tweenOption.bScale then
            self:CloseScaleTween(self._tweenObj or self.go, function()
                closefunc()
            end)
        else
            closefunc()
        end
    else
        closefunc()
    end
end

function LuaWidgetFactor:_ViewCheckNewbie()
    if self.netsetcount <= 0 and self.CheckAllNewbieInfo then
        self:CheckAllNewbieInfo()
    end
end

function LuaWidgetFactor:_AutoSetDepth()
    self.go:SetActive(true)

    local widget = LuaLayout.Instance:GetWidgetName(self)
    local viewcfg = ModuleManager.GetUIViewCfg(self.wigetName)
    if widget and (viewcfg and viewcfg.bautodepth ~= false) then
        local parentwidget = LuaLayout.Instance:GetWidget(widget.parentname)

        local autoZDepth = UILayerTool.GetNextZDepth() + (parentwidget and parentwidget.modelDepth or 0)
        local autoCanveDepth = UILayerTool.GetNextDepth() + (parentwidget and parentwidget.canvasDepth or 0)
        self.modelDepth = autoZDepth
        self.canvasDepth = autoCanveDepth

        GameObjTools.SetDepth(self.go, autoCanveDepth)
        GameObjTools.SetModelDepth(self.go, autoZDepth)
    end
end

function LuaWidgetFactor:_AutoClearDepth()
    self.go:SetActive(false)

    local widget = LuaLayout.Instance:GetWidgetName(self)
    if widget then
        local parentwidget = LuaLayout.Instance:GetWidget(widget.parentname)
        local curModelDepth = (self.modelDepth or 0) - (parentwidget and parentwidget.modelDepth or 0)
        --z轴回退
        if curModelDepth == UILayerTool.GetCurrentZDepth() then
            UILayerTool.SetZDepth(curModelDepth - 1200)
        end
    end
end

--返回数据后打开/ 一定要保证预设加载完后才调用
function LuaWidgetFactor:OnNetOpen()
end

--预设加载完后打开
function LuaWidgetFactor:OnOpen()
    -- print("LuaWidgetFactor:onopen()")
end

function LuaWidgetFactor:OnLoad()
    -- print("LuaWidgetFactor:onload()")
end

function LuaWidgetFactor:OnClose()
    --close panel
    -- print("LuaWidgetFactor:onclose()")
end

function LuaWidgetFactor:OnDestroy()
    -- print("LuaWidgetFactor:ondestroy()")
end

--全屏界面隱藏obj
function LuaWidgetFactor:OnShowWidgetObj()
    -- print("LuaWidgetFactor:OnShowWidgetObj()")
end

--全屏界面显示obj
function LuaWidgetFactor:OnHideWidgetObj()
    -- print("LuaWidgetFactor:OnHideWidgetObj()")
end

function LuaWidgetFactor:CloseView()
    if self.state == WidgetState.open then
        local wigetName = LuaLayout.Instance:GetWidgetName(self)
        LuaLayout.Instance:CloseWidget(wigetName)
    end
end

function LuaWidgetFactor:OpenView()
    if self.state ~= WidgetState.open then
        local wigetName = LuaLayout.Instance:GetWidgetName(self)
        return LuaLayout.Instance:OpenWidget(wigetName)
    end
end

--------------panel-------------------

function LuaWidgetFactor:AddPanel(name)
    if self.listpanel[name] then
        return false
    end
    self.listpanel[name] = LuaPanel.New(self, name)
    return true
end

function LuaWidgetFactor:DelPanel(name)
    if self.listpanel[name] then
        self.listpanel[name] = nil
    end

end

function LuaWidgetFactor:GetPanel(name)
    if self.listpanel[name] then
        return self.listpanel[name]
    end
    return nil
end

function LuaWidgetFactor:OpenPanel(name)
    if self.listpanel[name] and self.state == WidgetState.open then
        --if not self.listpanel[name]:IsOpen() then
        self.listpanel[name]:Open()
        --end
    end
end

function LuaWidgetFactor:ClosePanel(name)
    if self.listpanel[name] and self.state == WidgetState.open then
        if self.listpanel[name]:IsOpen() then
            self.listpanel[name]:Close()
        end
    end
end

--widget 打开或关闭 回调，用于开关功能
function LuaWidgetFactor:EnableWidgetCallBack(enable)
    if not enable and self.CloseAllTimer then
        self:CloseAllTimer()
    end

    self:EnableFullScreen(enable) --开启全屏
end

--fullscreen
function LuaWidgetFactor:EnableFullScreen(enable)
    local FullScreenView = require "Modules.Common.FullScreen.FullScreenView"
    if enable then
        if self.fullScreenOption then
            FullScreenView.PushView(self)
        end
    else
        if self.fullScreenOption then
            FullScreenView.EraseView(self)
        end
    end
end