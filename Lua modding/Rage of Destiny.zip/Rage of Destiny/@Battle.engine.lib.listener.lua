listener = class({})

function listener:constructor()
    self._list = {}
end

function listener:add(cb)
    assert(type(cb) == "function")
    table.insert(self._list, cb)
end

function listener:remove(cb)
    assert(type(cb) == "function")
    for i = #self._list, 1, -1 do
        if cb == self._list[i] then
            table.remove(self._list, i)
        end
    end
    table.insert(self._list, cb)
end

function listener:invoke(...)
    for _, cb in ipairs(self._list) do
        cb(...)
    end
end

return listener
