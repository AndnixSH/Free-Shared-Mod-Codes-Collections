local ModuleManager = require "Common.Mgr.UI.ModuleManager"
local ClistRender = require "Core.Implement.UI.Class.ClistRender"
local ClistItem = require "Core.Implement.UI.Class.ClistItem"
local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
local RedPointDef = require "Modules.RedPoint.RedPointDef"
local ObjPoolRender = require "Core.Implement.UI.Class.ObjPoolRender"
local ModuleManager = require "Common.Mgr.UI.ModuleManager"
local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
local MallProxy = require "Modules.Mall.MallProxy"
local MallDef = require "Modules.Mall.MallDef"
local NewbieWidget = require "Core.Implement.UI.Widgets.NewbieWidget"
local DateFormatUtil = require "Common.Util.DateFormatUtil"
local Timer = require "Common.Util.Timer"
local ActivityProxy = require "Modules.Activity.ActivityProxy"
local ActivityDef = require "Modules.Activity.ActivityDef"
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local MobilizeProxy = require "Modules.Mobilize.MobilizeProxy"
local MobilizeDef = require "Modules.Mobilize.MobilizeDef"
----------------
local PoolItem = PetPoolItem or BaseClass(ClistItem, NewbieWidget,TimerFactor)
function PoolItem:Load(obj)
	self.go = obj
	self.root = self:GetChild(obj,"item")
	self.label = self:GetChildComponent(self.root, "COutline_label", "CLabel")
	self.iconSp = self:GetChildComponent(self.root, "CSprite_icon", "CSprite")
	self.timeLb = self:GetChildComponent(self.root, "Time", "CLabel")
	self.redPointObj = self:GetChild(self.root, "RedPoint")
	self.btn = self:GetComponent(self.root, "CButton")
	self.btn:AddClick(function ()
		self:OnTriggerClickBtn(self.btn)
		self:OnClick()
	end)
	self.propStr = ""
	self.oneDay = 24*60 * 60
	--self.effectroot = self:GetChild(obj,"effectroot")
end

--注册新手引导数据
function PoolItem:RegisterNewbieData()
	local NewbieManager = require "Modules.Newbie.NewbieManager"
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	for _newbie_id, _step in pairs(NewbieDef.ActivityBtn) do
		self:RegisterButton(self.btn, _newbie_id, _step)
	end
end

--是否是领取奖励引导
function PoolItem:CheckActivityNewbie()
	local NewbieManager = require "Modules.Newbie.NewbieManager"
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	local bNewbie = false
	local curNewbieid, curStep = NewbieManager.Instance:GetCurNewbieId()
	if curNewbieid and curStep then
		for _newbie_id, infos in pairs(NewbieDef.ActivityAwardBtn) do
			for _,value in ipairs(infos) do
				if curNewbieid == _newbie_id and value[1] == curStep then
					bNewbie = true
					break
				end
			end
		end
	end
	return bNewbie
end

function PoolItem:SetData(data)
	self.data = data
	self.label.text = self:GetWord(data.label)
	self.iconSp.SpriteName = data.icon
	self.timeLb.text = ""
	self.propStr = ""
	self.dataIdx = data.index
	if data.redpointId then
		RedPointProxy.Instance:BindNode(data.redpointId, self.redPointObj)
	end
	
	if data.index == 1 then
		local SettingMenuProxy = require "Modules.SettingMenu.SettingMenuProxy"
		SettingMenuProxy.Instance:UpdateNewsRedDot()
	end
	local isShow = self:CheckShowItem()
	self.btn.transform.parent.gameObject:SetActive(isShow)
	
	local activeCfg = ModuleManager.GetActivityConfig()

	if self.dataIdx == #activeCfg then
		self:RegisterNewbieData()
	end
	--self:ShowEffect()
end
function PoolItem:CheckShowItem()
	local isShow = true
	if self.data.parama[1] == AppFacade.CycleActivity then
		local CycleActivityProxy = require "Modules.CycleActivity.CycleActivityProxy"
		local CycleActivityDef = require "Modules.CycleActivity.CycleActivityDef"
		local endtime = CycleActivityProxy.Instance:GetEventsEndTime(self.data.parama[2])
		isShow = false
		if endtime and endtime > 0 then
			local ModuleManager = require "Common.Mgr.UI.ModuleManager"
			if   ModuleManager.SystemIsOpen(CycleActivityDef.SystemOpen[self.data.parama[2]],false) then
				isShow = true
			end
		end
	elseif self.data.parama[1] == AppFacade.Mobilize then
		isShow = self:CheckShowMobilizeBtn()
		
	elseif self.dataIdx == 2 then
		
		local state = ActivityProxy.Instance:GetShareRewardState()
		if state == ActivityDef.Reward_State.HasGet then
			isShow = false
		else
			local ModuleManager = require "Common.Mgr.UI.ModuleManager"
			local type =self.data.parama[2] or 1
			if not  ModuleManager.SystemIsOpen(ActivityDef.SystemOpenType[type],false) then
				isShow = false
			end
		end
		isShow = false --屏蔽分享按钮
	elseif self.dataIdx == 1 then -- 新闻临时入口
		isShow = false
	else 
		if self.data.parama then
			local activeCfg = ModuleManager.GetActivityConfig()
			if self.dataIdx == #activeCfg then
				isShow = true
			else
				local type =self.data.parama[2] or 1
				local finish = ActivityProxy.Instance:CheckActivityFinsh(type)
				if finish then
				end
				if finish  then
					isShow = false
				else
					if ActivityDef.SystemOpenType[type] then
						local ModuleManager = require "Common.Mgr.UI.ModuleManager"
						if not  ModuleManager.SystemIsOpen(ActivityDef.SystemOpenType[type],false) then
							isShow = false
						end
						if type == ActivityDef.toggleType.StageClearCharge then
							if not ActivityProxy.Instance:IsFinishSecondChapter() then
								isShow = false
							end
						end
					end
				end
			end
			
		end
	end
	return isShow
end

function PoolItem:CheckShowMobilizeBtn()
	local ModuleManager = require "Common.Mgr.UI.ModuleManager"
	local isShow = false
	if   ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.MobilizeView,false) then
		isShow = self:StartTimeCountDown()
	end
	return isShow
end

function PoolItem:StartTimeCountDown(endtime)
    local remaintime=0
	local state , endtime = MobilizeProxy.Instance:GetEndTime()
	local isShow = false
	if state == MobilizeDef.State.Ready then
		isShow = true
		self.propStr = LanguageManager.Instance:GetWord(MobilizeDef.CommonDef.CountTimeTip1) 
	elseif state == MobilizeDef.State.Duration then
		isShow = true
		self.propStr = LanguageManager.Instance:GetWord(MobilizeDef.CommonDef.CountTimeTip2)
	else
		if self.timer then
            self:RemoveTimer(self.timer)
            self.timer = false
        end
		self.go:SetActive(false)
	end
	self.timeLb.gameObject:SetActive(false)
    -- if endtime and endtime > 0 then
    --     if self.timer then
    --         self:RemoveTimer(self.timer)
    --         self.timer = false
    --     end
    --     remaintime=os.difftime(endtime,RoleInfoModel.servertime)
    --     if remaintime > 0 then
            
    --         local seconds,min,hour, day=self:SecondsToTime(remaintime)
    --         local count=remaintime + 1
            
    --         self.timer=self:AddTimer(function ()
    --             remaintime=remaintime-1
    --             self:UpdateTimeCountDown(remaintime)
    --         end, 1, count)
    --         self:UpdateTimeCountDown(remaintime)
    --     else
    --         --过期
	-- 		local str = string.format("%02d:%02d:%02d",0,0,0)
    --         self.timeLb.text= string.format(self.propStr,str)
	-- 		self:StartTimeCountDown()
    --     end
    -- end
	return isShow
end

function PoolItem:UpdateTimeCountDown(remaintime)
	if remaintime > 0 then
		local ss,mm,hh, dd=self:SecondsToTime(remaintime)
		if  remaintime > self.oneDay then
			local str = tostring(dd)..LanguageManager.Instance:GetWord(MobilizeDef.CommonDef.Day) --..string.format("%02d:%02d:%02d",hh,mm,ss)
			self.timeLb.text=string.format(self.propStr,str)
		else
			--24小时内
			local str = string.format("%02d:%02d:%02d",hh,mm,ss)
			self.timeLb.text=  string.format(self.propStr,str)
		end
	else
		--过期
		local str = string.format("%02d:%02d:%02d",0,0,0)
		self.timeLb.text= string.format(self.propStr,str)
		self:StartTimeCountDown()
	end
end

function PoolItem:SecondsToTime(ts)
    local seconds = math.fmod(ts, 60)
    local min = math.floor(ts/60)
    local hour = math.floor(min/60) 
    local day = math.floor(hour/24)

	local hh=(hour - day*24)
	local mm=(min - hour*60)
    return math.floor(seconds), mm > 0 and mm or 0,hh > 0 and hh or 0,day
end

function PoolItem:ShowEffect()

	-- if self.dataIdx == 8 then
		
	-- 	if not self.effect then
	-- 		self.effect = UIEffectItem.New("UI_Main_button2",self.effectroot)
	-- 	end
	-- 	self.effect:Open()
	-- 	-- local depth = UILayerTool.GetNextDepth()
	-- 	-- self:SetEffectDepth(depth)
	-- else
	-- 	if self.effect then
	-- 		self.effect:Destroy()
	-- 		self.effect = false
	-- 	end
	-- end
	
end
function PoolItem:SetEffectDepth(depth)
	-- if self.dataIdx == 8 then
	-- 	--local depth = UILayerTool.GetNextDepth()
	-- 	GameObjTools.SetDepth(self.root,depth)
	-- 	--depth = UILayerTool.GetNextDepth()
	-- 	GameObjTools.SetDepth(self.effectroot,depth+1)
	-- end
	
end

function PoolItem:OnClick()
	local parama = self.data.parama
	if parama then
		local activeCfg = ModuleManager.GetActivityConfig()
			
		if self.dataIdx == #activeCfg and self:CheckActivityNewbie() then
			--有新手，跳转写死
			local ActivityDef = require "Modules.Activity.ActivityDef"
			parama[2] = ActivityDef.toggleType.StageClearCharge
			UIOperateManager.Instance:OpenWidget(table.unpack(parama))
		else
			UIOperateManager.Instance:OpenWidget(table.unpack(parama))
		end
		
	else
		GameLogicTools.ShowMsgTips(self:GetWord("Common_1033"))
	end
end

--是否是领取奖励引导
function PoolItem:CheckActivityNewbie()
	local NewbieManager = require "Modules.Newbie.NewbieManager"
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	local bNewbie = false
	local curNewbieid, curStep = NewbieManager.Instance:GetCurNewbieId()
	if curNewbieid and curStep then
		for _newbie_id, infos in pairs(NewbieDef.ActivityAwardBtn) do
			for _,value in ipairs(infos) do
				if curNewbieid == _newbie_id and value[1] == curStep then
					bNewbie = true
					break
				end
			end
		end
	end
	return bNewbie
end

function PoolItem:Hide(index)
	if self.dataIdx == index then
		self.btn.transform.parent.gameObject:SetActive(false)
		if self.dataIdx == 8 then
			if self.effect then
				self.effect:Close()
			end
		end
	end
end
function PoolItem:Show(index)
	if self.dataIdx == index then
		self.btn.transform.parent.gameObject:SetActive(true)
		if self.dataIdx == 8 then
			if not self.effect then
				self.effect = UIEffectItem.New("UI_Main_button2",self.effectroot)
			end
			if self.effect then
				self.effect:Open()
				-- local depth = UILayerTool.GetNextDepth()
				-- self:SetEffectDepth(depth)
			end
		end
	end
end

function PoolItem:Close()
	if self.effect then
		self.effect:Close()
	end
	self:UnRegisterNewbie()
end

function PoolItem:Destroy()
	if self.effect then
		self.effect:Destroy()
		self.effect = false
	end
	self:UnRegisterNewbie()
end

---------------
local MainState = {
    Show = 0,
    Hide = 1
}

local MainActivityPanel = MainActivityPanel or BaseClass(GameObjFactor)
function MainActivityPanel:__init(go)
	self.go = go
	self:Load(go)	
end
function MainActivityPanel:Load(obj)
	self.rect = self:GetComponent(obj, "RectTransform")
	self.rectPosition = self.rect.anchoredPosition	
	self.backRect = self:GetChildComponent(obj, "CSprite_back", "RectTransform")

    -- self.poolList = self:GetChildComponent(obj, "CList_menu", "CList")
    -- self.listRender = ClistRender.New()
    -- self.listRender:Load(self.poolList, PoolItem)

    self.openObj = self:GetChild(obj, "CSprite_back/CButton_close/sprite")
	self.openBtn = self:GetChildComponent(obj, "CSprite_back/CButton_close", "CButton")
	self.openBtn:AddClick(function ()
		self:ShowBar()
	end)
	
	self.poolRender = ObjPoolRender.New()
	local item = self:GetChild(obj, "CList_menu2/Viewport/Content/item")
	item:SetActive(false)
	self.poolRender:Load(item, item.transform.parent, PoolItem)
	self.scrollRect = self:GetChildComponent(obj,"CList_menu2","ScrollRect")

	PoolItem.view = self
	-- local clist = self:GetChild(obj,"CList_menu2")
	-- local viewport = GameObjTools.GetChild(clist, "Viewport")
	-- GameObjTools.SetShader(viewport, "UI/UI_Mask", false)
    -- self.clist_effect = CS.UtilsGameObj.GetWorldCorners(clist.gameObject)
end

function MainActivityPanel:Open()
	self.go:SetActive(true)	
	self:ShowBar(MainState.Show)
	self:SetDepth(self.openBtn.gameObject, self:GetNextDepth())
	self:StartOpenTween()
end	

function MainActivityPanel:UpdateDepth(depth)
	self:SetDepth(self.openBtn.gameObject, depth)
	
	--self.poolRender:ExecuteMethod("SetEffectDepth",depth)
end


function MainActivityPanel:Close()
	self.go:SetActive(false)
	if self.opensequence then
		self.opensequence:Kill()
		self.opensequence = nil
	end		
	self.poolRender:ExecuteMethod("Destroy")
	self.poolRender:ReleaseAll()
end	

function MainActivityPanel:Destroy()

	
	self.poolRender:ReleaseAll()
end

function MainActivityPanel:UpdateInfo()
	local activeCfg = ModuleManager.GetActivityConfig()
	self.poolRender:ReleaseAll()
	local count = 0
	for _ , v in ipairs(activeCfg) do
		if v then
			local class = self.poolRender:Get(v )
			if class:CheckShowItem() then
				count = count + 1
			end
		end
	end
	if count >= 8 then
		self.scrollRect.enabled = true
	else
		self.scrollRect.enabled = false
	end
	--self.poolRender:ExecuteMethod("ShowEffect")
	
	-- if self.state == MainState.Show and #activeCfg >= 5 then
	-- 	self.scrollRect.enabled = true
	-- else
	-- 	self.scrollRect.enabled = false
	-- end
end

function MainActivityPanel:ShowBar(state)
    if state == nil then
        state = (self.state == MainState.Hide) and MainState.Show or MainState.Hide        
    end

	self.state = state
	if state == MainState.Show then		
		local activeCfg = ModuleManager.GetActivityConfig()
		local height = 201 + (#activeCfg > 5 and 5 or #activeCfg) * 100 - 100

		self.openObj.transform.localScale = Vector3.New(1, 1, 1)
		self.backRect:DOSizeDelta(Vector2.New(98, height), 0.2)
	else
		local height = 201
		self.openObj.transform.localScale = Vector3.New(1, -1, 1)
		self.backRect:DOSizeDelta(Vector2.New(98, height), 0.2)
	end	
	self:UpdateInfo()
end	

function MainActivityPanel:UpdateBtn(index)
	self.poolRender:ExecuteMethod("Hide",index)
end

function MainActivityPanel:Update_Mobilize_Btn(show)
	self.poolRender:ExecuteMethod("CheckShowMobilizeBtn")
end

function MainActivityPanel:StartOpenTween()	
	self.rect.anchoredPosition = Vector2.New(self.rectPosition.x, self.rectPosition.y+100)
	local tween1 = self.rect:DOAnchorPosY(self.rectPosition.y + 10, 0.2)
	local tween2 = self.rect:DOAnchorPosY(self.rectPosition.y, 0.2)

	local sequence = DOTween.Sequence()
	sequence:Append(tween1)
	sequence:Append(tween2)
	self.opensequence = sequence
end

return MainActivityPanel