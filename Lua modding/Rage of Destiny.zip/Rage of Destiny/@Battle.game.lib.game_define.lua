OBJ_TYPE = {
    SPRITE = "sprite",
    GAME = "game",
}


-- 精灵类型
SPRITE_TYPE = {
    PLAYER = 1,  -- 英雄/玩家
    MONSTER = 2, -- 怪物
    PROP = 4,    -- 道具
    BULLET = 8,  -- 子弹
}

-- 子弹类型
BULLET_TYPE = {
    LINE = 1,    -- 直线
    PARABOLA = 2,-- 抛物线
    PULLBACK = 3,-- 来回
    TRACK = 4,   -- 跟踪
    REFLECT = 5, -- 反射
}

-- 英雄大类
HERO_CLASS = {
    STRENGTH = 1, -- 力量
    AGILITY = 2,  -- 敏捷 
    MENTALITY = 3,-- 智力
}

-- 英雄定位类型
HERO_BATTLE_TYPE = {
    TANK = 1, --坦克
    DPS = 2,  --输出
    SUP = 3,  --辅助
}

-- 怪物类型
MONSTER_TYPE = {
    NORMAL = 1, -- 普通
    ELITE = 2,  -- 精英
    BOSS = 3,   -- BOSS
}

CAMP = {
    RED = 1,
    BLUE = 2,
}

AMENDMENT = {}

AMENDMENT.TYPE = {
    PERCENT = 1,       -- 百分比修正  {id, target, rate}
    CONSTANT = 2,      -- 固定值修正  {id, target, constant}
    HP_LINEAR = 3,     -- HP线性修正  {id, target, targetid, attrfrom, attrto, valuefrom, valueto} 修正ID,修正对象,属性来源,属性开始,属性结束,修正开始,修正结束
    MP_LINEAR = 4,     -- MP线性修正  {id, target, targetid, attrfrom, attrto, valuefrom, valueto}
    ATTR_PERCENT = 5,  -- 属性固定    {id, target, targetid, attr, rate}
    ATTR_LINEAR = 6,   -- 属性线性修正  {id, target, targetid, attr, attrfrom, attrto, valuefrom, valueto}
    BUFF_LEVEL = 7,    -- buff层数修正  {id, target, targetid, buffid, value, contant}
    DISTANCE_LINEAR = 8,-- 距离线性修正  {id, target, distancefrom, distanceto, valuefrom, valueto}
    DISTANCE_COMPARE = 9,-- 距离比较修正 {id, target, typeid, distanceto, valueto}
}

AMENDMENT.PROP = {
    [1] = "final_rate",
    [2] = "must_hit",
    [3] = "must_crit",
    [4] = "ignore_def",
    [5] = "buff",
    [6] = "rate",
}

BUFF = {}

BUFF.CLASS = {
    [1] = "buff_attr",        -- 属性buff
    [2] = "buff_state",       -- 状态buff
    [3] = "buff_hp",          -- 血量buff
    [4] = "buff_mp",          -- 蓝量buff
    [5] = "buff_sld",         -- 护盾buff
    [6] = "buff_hp_def",      -- 血量buff 走伤害公式
    [7] = "buff_attr_level",  -- 属性buff？
    [8] = "buff_timemerge",   -- 空buff
    [9] = "buff_steal",       -- 属性偷取buff
    [10] = "buff_amendment",  -- 技能修正buff {技能槽位1,技能槽位2,...}
    [11] = "buff_taunt",      -- 嘲讽buff {被嘲讽的rangeid}
    [12] = "buff_disperse",   -- 驱散buff 概率，{类型(1-type，2-group),...},次数  type:0所有,1正面,2负面   group:groupid
    [13] = "buff_timemdf",    -- 时间buff {类型(0：所有，1：增益，2：负面)，时间(千分比)}
    [14] = "buff_amendbuff",  -- buff修正buff {buff大类1,buff大类2,...}
    [15] = "buff_charm",      -- 魅惑buff
    [100] = "buff_killself",  -- 自杀buff
}

BUFF.STATE = {
    [1] = "dizzy",              -- 眩晕
    [2] = "must_eva",           -- 绝对闪避
    [3] = "invincible",         -- 无敌
    [4] = "immune_select",      -- 无法选中
    [5] = "immune_shift_suffer",  -- 免疫位移suffer（击飞，击退）
    [6] = "silence",            -- 沉默
    [7] = "silence_ultimate",   -- 沉默
    [8] = "immune_dead",        -- 免死
    [9] = "immune_enemy_select",-- 无法被敌方阵营选中
}
BUFF.STATE_NAME = {
    DIZZY = 1,          -- 眩晕
    MUST_EVA = 2,       -- 绝对闪避
    ININCIBLE = 3,       -- 无敌
    IMMUNE_SELECT = 4,  -- 无法选中
    IMMUNE_SHIFT_SUFFER = 5,  -- 免疫位移suffer（击飞，击退）
    SILENCE = 6,        -- 沉默
    SILENCE_ULTIMATE = 7,        -- 沉默大招
}

BUFF.GROUP = {
    [1]= "atk_up",
    [2] = "atk_down",
    [3] = "def_up",
    [4] = "def_down",
    [5] = "spd_up",
    [6] = "spd_down",
    [7] = "crit_rate_up",
    [8] = "crit_rate_down",
    [98] = "hit",
    [99] = "dizzy",
}

BUFF.GROUP_NAME = {
    ATK_UP = 1,
    ATK_DOWN = 2,
    DEF_UP = 3,
    DEF_DOWN = 4,
    SPD_UP = 5,
    SPD_DOWN = 6,
    CRIT_RATE_UP = 7,
    CRIT_RATE_DOWN = 8,
    HIT = 98,
    DIZZY = 99,
}

BUFF.SHOW_ATK_GROUP = {
	[1] = {[1] = "aw", [2]= "bx"},
	[2] = {[1] = "ay", [2]= "bz"},
	[3] = {[1] = "cw", [2]= "dx"},
	[4] = {[1] = "cy", [2]= "dz"},
	[5] = {[1] = "ew", [2]= "fx"},
	[6] = {[1] = "ey", [2]= "fz"},
}

SKILL = {}

-- 技能槽位/类型
SKILL.SLOT = {
    NORMAL = 1,    -- 槽位1 普攻
    ULTIMATE = 2,  -- 槽位2 大招
    SKILL3 = 3,    -- 槽位3
    SKILL4 = 4,    -- 槽位4
    SKILL5 = 5,    -- 槽位5
    SKILL6 = 6,    -- 槽位6
    SKILL7 = 7,    -- 槽位7
    SKILL8 = 8,    -- 槽位8
    SKILL9 = 9,    -- 槽位9
    SKILL10 = 10,  -- 槽位10
}

-- 技能槽位状态
SKILL.SLOT_STATUS = {
    ENABLE = 1,  -- 可用
    DISABLE = 2, -- 不可用
    CHARGE = 3,  -- 蓄力
}

-- 技能选取目标
SKILL.SELECT = {
    ALL = 0,          -- 所有
    DIS_MIN = 51,       -- 距离最近
    DIS_MAX = 52,       -- 距离最远
    DEGREE_MIN = 53,    -- 角度最小
    DIS_FORWARD = 55,       -- 最靠前
    INTENSIVE_1 = 54,     -- 密集（同阵营人数最多处，3000）
    INTENSIVE_2 = 56,     -- 密集（同阵营人数最多处，4000）
    INTENSIVE_3 = 57,     -- 密集（同阵营人数最多处，6000）

    ATTR_MAX = 61,      -- 属性最大
    ATTR_MIN = 62,      -- 属性最小

    RANDOM = 99,        -- 随机
}

-- 技能生效目标
SKILL.TARGET = {
    ENEMY = 1,          -- 敌方所有
    ENEMY_HERO = 2,     -- 敌方英雄+敌方怪物BOSS
    SELF = 3,           -- 自身
    FRIEND = 5,         -- 友方所有
    FRIEND_HERO = 6,    -- 友方英雄+友方怪物BOSS
    FRIEND_SUMMON = 7,  -- 友方召唤物
    ENEMY_SUMMON = 8,   -- 敌方召唤物
    ALL = 9,            -- 全体
}

-- 技能生效目标过滤
SKILL.TARGET_FILTER = {

    EXCEPT_CASTER = 4,  -- 除去施法者

    HT_1 = 11,          -- 力量型英雄
    HT_2 = 12,          -- 敏捷型英雄
    HT_3 = 13,          -- 智力型英雄
    HR_1 = 14,          -- 人类英雄
    HR_2 = 15,          -- 兽人英雄
    HR_3 = 16,          -- 精灵英雄
    HR_4 = 17,          -- 亡灵英雄
    HT_1_2 = 18,        -- 物理英雄


    FRONT_ROW = 21,     -- 前排
    BACK_ROW = 22,      -- 后排
    FACE = 23,          -- 对称位置
    FRONT = 24,         -- 身前
    BEHIND = 25,        -- 身后

    HP_GE = 31,         -- HP高于n%
    HP_LE = 32,         -- HP低于n%
    MP_GE = 33,         -- MP高于n%
    MP_LE = 34,         -- MP低于n%
    ATTR_LT = 35,       -- 属性小于n
    ATTR_GT = 36,       -- 属性大于n
    ATTR_EQ = 37,       -- 属性等于n

    FETTER = 41,        -- 羁绊 N
    TARGET_BUFF = 42,   -- 目标是否有buff
    TARGET_BUFF_TYPE = 43,-- 目标是否有类buff
    TARGET_BUFF_NOT  = 44,   -- 目标是否没有buff

    ENEMY_SIDE = 54,    -- 敌方半场
    FRIEND_SIDE = 55,   -- 我方半场

    GENDER = 61,        -- 性别
}

-- 技能范围
SKILL.RANGE = {
    ALL =   0,         -- 全图
    RECT =   1,        -- 矩形
    SECTOR = 2,        -- 扇形
    CIRCLE = 3,        -- 圆形
    ENEMY_SIDE = 4,    -- 敌方半场
    FRIEND_SIDE = 5,   -- 我方半场
    RECT_CENTER = 6,   -- 中心矩形
}

-- 技能伤害类型
SKILL.DAMAGE_TYPE = {
    PHYSICS = 1,
    MAGIC = 2,
}

-- 技能选取ID
SKILL.RANGEID = {
    BULLET_BOUNCE = 900101,     -- 弹射子弹通用选取
    BULLET_BOUNCE_DEGREE = 900102,     -- 弹射子弹通用选取

    ALL = 900116,               -- 全体
    ENEMYS = 900120,            -- 敌人
    ENEMYS_CLOSE = 900111,      -- 最近敌人
    ENEMYS_CLOSE_SMALL = 900137,-- 最近敌人小范围
    ENEMYS_CLOSE_MID = 900138,  -- 最近敌人中范围
    ENEMYS_CLOSE_LARGE = 900139,-- 最近敌人小范围
    ENEMYS_FARTHEST = 900131,   -- 最远敌人
    ENEMY_RANDOM = 900114,      -- 随机敌人
    ENEMY_FACE = 900118,        -- 对位的敌人
    ENEMYS_SUMMON = 900122,     -- 敌人召唤物
    ENEMY_LOW_HP = 900124,      -- 血量最低的敌人
    ENEMY_LOW_HP_HERO = 900123, -- 血量最低的敌人英雄
    ENEMY_LOW_DEGREE = 900132,  -- 角度最小的敌人
    ENEMY_LOW_DEF = 900133,     -- 防御最小的敌人
    ENEMY_HIGH_ATK = 900134,    -- 攻击最高的敌人
    ENEMYS_LOW_HP_HERO = 900140, -- 血量最低的敌人英雄们

    FRIENDS_CLOSE_SMALL = 900141,       -- 小范围周围右方英雄
    FRIENDS_CLOSE_MID = 900142,         -- 中范围周围右方英雄
    FRIENDS_CLOSE_LARGE = 900143,       -- 大范围周围右方英雄
    FRIEND_RANDOM_NOTSELF = 900115,     -- 随机队友 不包含自己
    FRIEND_RANDOM = 900125,      -- 随机队友
    FRIENDS_NOTSELF = 900117,    -- 队友、除了自己
    FRIENDS = 900119,            -- 全体队友
    FRIEND_LOW_HP = 900112,      -- 血量最低的队友
    FRIEND_LOW_HP_HERO = 900148, -- 血量最低的队友英雄
    FRIENDS_SUMMON = 900121,     -- 右方召唤物
    FRIENDS_BACK_ROW = 900127,   -- 友方后排英雄
    FRIENDS_MENTALITY = 900128,  -- 友方智力英雄
    FRIENDS_STRENGTH = 900135,   -- 友方力量英雄
    FRIENDS_AGILITY = 900136,    -- 友方敏捷英雄
    FRIENDS_CLOSE = 900129,      -- 最近的友军
    FRIENDS_HOLY = 900144,       -- 圣光友军
    FRIENDS_WILD = 900145,       -- 蛮荒友军
    FRIENDS_NATURE = 900146,     -- 自然友军
    FRIENDS_DARKNESS = 900147,   -- 暗影友军

    ENEMYS_SIDE = 900126,        -- 敌方半场
    FRIENDS_SIDE = 900130,       -- 我方半场
}
CONST = {}

-- 伤害
CONST.DMG = {
    A = 2,
    B = 5,
    C = 250,
    D = 1,
    E = 1.1,
    F = 1000,
    G = 10,
    H = 0,
    I = 0,
    J = 2,
}

-- 命中
CONST.HIT = {
    A = 1000,
    B = 1,
}

-- 暴击
CONST.CRIT = {
    A = 50,
    B = 2000,
    C = 1000,
    D = 0,
}

-- 吸血
CONST.LEECH = {
    A = 100,
}

-- 急速
CONST.SPD = {
    A = 7, -- 急速常量
    B = 500,   -- 最小保底值
    C = 2000,  -- 最大值
}

-- 生命
CONST.HP = {

}

-- 能量
CONST.MP = {
    A = 200,
}

-- 状态
CONST.BUFF = {

}


CONST.ATTR = {
    [1] = "level", -- 等级
    [2] = "hp_max", -- 生命上限
    [3] = "hp", -- 生命
    [4] = "sld",     -- 护盾
    [5] = "mp_max", -- 能量上限
    [6] = "mp", -- 初始能量
    [7] = "atk", -- 攻击
    [8] = "def", -- 防御
    [9] = "hit", -- 命中
    [10] = "eva", -- 闪避
    [11] = "spd", -- 急速
    [12] = "spd_d", -- 减速
    [13] = "mov", -- 移速
    [14] = "leech", -- 吸血
    [15] = "immune_suffer", -- 免疫控制
    [16] = "harm_rebound", -- 反弹伤害
    [17] = "suppress_rate", -- 种族压制
    [21] = "hps", -- 生命恢复
    [22] = "heal_rate", -- 疗效提升
    [23] = "heal_rate_d", -- 疗效降低
    [24] = "cure_rate", -- 治疗提升
    [31] = "mps", -- 能量回复
    [33] = "mp_rate", -- 回能提升
    [34] = "mp_rate_d", -- 回能降低
    [35] = "harm_mp_rate", -- 受伤回能提升
    [36] = "harm_mp_rate_d", -- 受伤回能降低
    [41] = "dmg_rate", -- 伤害提升
    [42] = "dmg_rate_d", -- 伤害降低
    [43] = "harm_rate", -- 伤害易伤
    [44] = "harm_rate_d", -- 伤害减免
    [45] = "pharm_rate", -- 物理增伤
    [46] = "pharm_rate_d", -- 物理减伤
    [47] = "mharm_rate", -- 魔法增伤
    [48] = "mharm_rate_d", -- 魔法减伤
    [60] = "crit_resist_rate", -- 暴击抗性
    [61] = "crit_rate", -- 暴击率
    [62] = "eva_rate", -- 闪避率
    [63] = "crit", -- 暴击伤害
    [64] = "atkspd", -- 攻击速度
    [65] = "atkspd_rate", -- 攻速提升
    [66] = "atkspd_rate_d", -- 攻速降低
    [67] = "spellspd_rate", -- 施法提升
    [68] = "spellspd_rate_d", -- 施法降低
    [69] = "leech_rate", -- 吸血提升
    [70] = "leech_rate_d", -- 吸血降低
    [71] = "skill_leech_rate", -- 技能吸血
    [72] = "trigger_crit_rate", -- 易暴率
    [98] = "total_dmg", -- 总伤害
    [99] = "fight", -- 战力
    [102] = "hp_max_rate", -- 生命百分比
    [107] = "atk_rate", -- 攻击百分比
    [108] = "def_rate", -- 防御百分比
    [109] = "fight_factor", -- 单纯用作战力计算
}

CONST.ATTR_NAME = {
	level = 1,
	hp_max = 2,
	hp = 3,
	sld = 4,
	mp_max = 5,
	mp = 6,
	atk = 7,
	def = 8,
	hit = 9,
	eva = 10,
	spd = 11,
	spd_d = 12,
	mov = 13,
	leech = 14,
	immune_suffer = 15,
	harm_rebound = 16,
	suppress_rate = 17,
	hps = 21,
	heal_rate = 22,
	heal_rate_d = 23,
	cure_rate = 24,
	mps = 31,
	mp_rate = 33,
	mp_rate_d = 34,
	harm_mp_rate = 35,
	harm_mp_rate_d = 36,
	dmg_rate = 41,
	dmg_rate_d = 42,
	harm_rate = 43,
	harm_rate_d = 44,
	pharm_rate = 45,
	pharm_rate_d = 46,
	mharm_rate = 47,
	mharm_rate_d = 48,
	crit_resist_rate = 60,
	crit_rate = 61,
	eva_rate = 62,
	crit = 63,
	atkspd = 64,
	atkspd_rate = 65,
	atkspd_rate_d = 66,
	spellspd_rate = 67,
	spellspd_rate_d = 68,
	leech_rate = 69,
	leech_rate_d = 70,
	skill_leech_rate = 71,
	trigger_crit_rate = 72,
	total_dmg = 98,
	fight = 99,
	hp_max_rate = 102,
	atk_rate = 107,
	def_rate = 108,
	fight_factor = 109,
}

--anchor
SPRITE_BONE_ANCHOR = 
{
    HEADER = "HeadPos",
    UITITLE = "HeadUPPos",
    WEAPON_R = "RightHandPos_wuqi",
    CENTER = "Pelvis",
    CHEST = "Chest Pos",
}

CAMERA_STRATEGY = 
{
    BONE   = 1,  -- 骨骼摄像机
    ADJUST = 2,  -- 运镜摄像机
    TRANSFORM = 3, -- 固定位置摄像机
}

--状态名字
DAMAGE_STATE =
{
    HP = 1, --血量
    MP = 2, --能量 
    SLD = 3, --护盾
    NOHIT = 4, --闪避
    IMMUNE = 5, --免疫
    KILL = 6, --击杀
    CHARM = 7, --魅惑
}

LAYERS =
{
    DEFAULT = 0, -- 默认层
    UI = 5, -- UI层
    TERRIAN = 9, -- 地形层
    SPRITE = 10, -- 精灵层
    EFFECT = 11, -- 大招表现层
}

GAMEPLAYID =
{
    MAINLINE = 1001, --主线战斗
    HANGUP = 1002, --挂机战斗
    TRAINING = 1003, -- 训练场
    TESTALLHERO = 1004,-- 英雄测试
}

ACTIVITYID =
{
    HANGUP = 100, --挂机副本    
    MAINLINE = 101, --主线副本
    TOWER = 102, --爬塔副本
    MAZE = 103, --迷宫副本
    STORYLINE = 104, --剧情副本
    ARENA = 105, --竞技场
    HIGHARENA = 106, --高阶竞技场
    LEGEND_ARENA = 107, --巅峰竞技场
    GUILD_BOSS = 108, --公会boss
    FRIEND_VERSUS = 109, --好友 友谊战
    SUPPLY_DEPOT = 110, --补给站
    GUILD_VERSUS = 111, --公会切磋
    ACTIVITY = 112,--活动副本
    GUILD_CHAOS = 113, --混沌裂隙
    MOBILIZE = 114 , --命运总动员
    
    TRIAL = 998,--英雄试玩
    TRAINING = 999,--训练场
    TEST_ALL_HERO = 996, --英雄测试
}

ACTIVE_TAG = 
{
    CAMP1 = 13, -- 己方阵营1101
    CAMP2 = 14, -- 敌方阵营1110
    NOHANGUP = 7, -- 非挂机场景0111
    HANGUP = 11,   -- 挂机场景1011
}

ACTIVE_BIT =
{
    CAMP1 = 1, -- 己方阵营
    CAMP2 = 2, -- 敌方阵营
    NOHANGUP = 4, -- 非挂机场景
    HANGUP = 8,   -- 挂机场景
}

HEXMAP_BUILD = 
{
    MONSTER = 1,           --怪物
    REWARD = 2,            --奖励
    EGG = 3,               --龙蛋
    RUNE = 4,              --符文
    OBSTACLE = 5,          --障碍
    BUFF_MONSTER = 6,      --buff怪
    CAMP_MONSTER = 7,      --阵营怪
    MAZE_MONSTER = 8,      --迷宫怪
    KEY_REWARD = 9,        --钥匙奖励
    COUNT_REWARD = 10,     --次数上限宝箱
	MAZE_END_REWARD = 11,  --巨龙关底宝箱
    ATTACK2 = 49,          --攻击不需要目标
    BATTLE_COUNT_EXIT = 50,--出口
    SHOP = 51,             --商店
    RECOVER = 52,          --回复
    REVIVE = 53,           --复活
    CART = 54,             --马车
    KEY = 55,              --钥匙
    EXIT = 56,             --出口
    ALTAR = 57,            --祭坛
    ATTACK = 58,           --攻击
    REMAIN = 59,           --探险者遗骸
    BLESS = 60,            --祝福图腾
    TURRET = 61,           --炮台
    BARRIER = 62,          --障碍血量
    GUIDE = 63,            --引导
    GEAR =  64,            --机关
    TRANSFER = 65,         --传送
    MONSTER_DBUFF = 66,    --驱散buff
    RAIL = 67,             --滑轨
    MONSTER_RECORD = 68,   --打怪记录，通过重置
    MONSTER_ABUFF = 69,    --加buff
    RECOVER2 = 70,         --回复2
    TIPS = 71,             --提示
    STAIR_GEAR = 72,       --升降机关
    FALLEN_START = 73,     --格子陨落开始
    BLESS2 = 74,           --固定祝福图腾
    REFRESHER = 75,        --刷新器
    TRIBE = 76,            --爪痕部落
    TRIBE_MONSTER = 77,    --爪痕怪物
    MONSTER_BORN_BUFF = 78, --怪物出生buff
    FALLEN_CELL = 79,      --格子陨落
    BOMB_CELL = 80,        --断桥炸弹
    BOMB_PLATFORM = 81,    --高台炸弹
    BOMB_TRIGGER = 82,     --起爆机关
    HIGH_PLATFORM = 83,    --高台
    TRANSFER2 = 84,        --传送门2
    TIPS2 = 85,             --提示2
    MONSTER_KILL_CHECK = 86, --怪物击杀提示
    KEY_TIPS = 87,          --钥匙提示
	
	DOOR = 92,  		   --门
	STOCKADE = 93,  	   --栅栏
	BALL_EMITTER = 94,     --球发射器(雪球发射器)
	BALL_EJECTOR = 95, 	   --球推进器(摆锤)
	BALL = 96, 			   --球(或者是可被推动物体)
	CHANGE_DIR_RAIL_END = 97, 			   --变向滑轨两头建筑
	DOOR_POST = 98, 	   --门柱
    CONDITION_OBSTACLE = 99, --固定条件 改变障碍物状态
    WEIGHT_CELL_OBSTACLE = 101, --状态切换有渐变特效的 障碍物
	LASER_GENERATOR = 102, --激光发射器
	BUILD_CREATOR = 103, --建筑生成器
    LASER_SWITCH = 104, --受激光照射改变状态建筑物
    MULTIPLE_SWITCH = 105,--多重开关（关联的格子上都是同状态的开关 触发 另一个建筑完成）
    DONE_GUIDE = 106, --特殊引导，靠clear触发
}

--格子类型
HEXMAP_CELL =
{
	NORMAL = 1,           				--普通
	SWITCH = 2,            				--开关
	SWITCH_FOR_CHANGE_DIR_RAIL = 3,  	--变向滑轨开关
	CHANGE_DIR_RAIL = 4,              	--变向滑轨
	SWITCH_ON_CHANGE_DIR_RAIL = 5,   	--变向滑轨上的开关
	SLIDE = 6,							--滑动格子
}

-- 记录
HEXMAP_RECORD = 
{
    TOTAL_KILL = 1,-- 击杀次数
    DRAGON_BLOOD_USE = 2,-- 龙血使用次数
    TOTAL_WIN = 3, -- 胜利场次
}

-- 信息
HEXMAP_INFO = 
{
    MAZE_LEVEL = "MAZE_LEVEL" -- 巨龙层数
}

-- 相对
RELATIVE = 
{
    MAP = 1,  -- 相对地图原点 千分比
    SELF = 2, -- 相对自身     具体值
}

-- 记录
HEXMAP_DIR_CONST =
{
	ORIGINAL_DIR = 1,-- 相同方向
	OPPOSITE_DIR = 2,-- 相反方向
}

CONST.ATTR_NUM =
{
	HP = 3,
	MP = 6,
}