local AudioManager = require "Common.Mgr.Audio.AudioManager"
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"

local BattleReadyView = BattleReadyView or BaseClass(LuaBasicWidget)
function BattleReadyView:__init()
	self.callback = nil
end

function BattleReadyView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Battle.BattleReadyView",self.LoadEnd)
end

function BattleReadyView:LoadEnd(obj)
	self:SetGo(obj)

	self.effect = UIEffectItem.New("UI_BattleReady_ready", obj)

	self:SetStep(0)
end

function BattleReadyView:OnOpen()	
	AudioManager.PlaySoundByKey("battleworldmid_view")
	self.effect:SetOrderLayer(self:GetNextDepth())
	self.effect:Play()
	self:AddTimer(function ()
		self:CloseView()
	end, 1.5, 1)
end

function BattleReadyView:OnClose()
	self.effect:Close()
	if self.callback then
		self.callback()
		self.callback = nil
	end	
end

function BattleReadyView:OnDestroy()
	self.effect:Destroy()
end

return BattleReadyView