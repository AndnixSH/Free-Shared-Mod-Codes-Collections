local GameUIUtil = CS.GameUIUtil
local SpriteTitleBase = require "Modules.Battle.Title.SpriteTitleBase"
local SettingMenuProxy = require "Modules.SettingMenu.SettingMenuProxy"
local SettingMenuDef = require "Modules.SettingMenu.SettingMenuDef"

local function IsAlawaysActive()
	local status = SettingMenuProxy.Instance:GetSystemState(SettingMenuDef.Systerm_Option_Key[SettingMenuDef.Systerm_Option_Type.BloodBar])
	return status == 1
end

local PlayerTitleView = PlayerTitleView or LuaEventClass(GameObjFactor, TimerFactor, SpriteTitleBase)

function PlayerTitleView:OnLoad()
	self:LoadStart("Battle.PlayerTitleItem")
end

function PlayerTitleView:LoadEnd(obj)
	self.hpSld = self:GetChildComponent(obj, "attribute/CSlider_Hp", "CSlider")
	self.mpSld = self:GetChildComponent(obj, "attribute/CSlider_Mp", "CSlider")
	self.mpSld.gameObject:SetActive(true)
	self.hpSp = self:GetChildComponent(self.hpSld.gameObject, "hp", "CSprite")
	self.hpbackSp = self:GetChildComponent(self.hpSld.gameObject, "hpback", "CSprite")
	self.mpSp = self:GetChildComponent(self.mpSld.gameObject, "Fill Area/Fill", "CSprite")

	self.buffObj = self:GetChild(obj, "buff/CHorizontalItem/item1")
	self.buffTex = self:GetChildComponent(obj, "buff/CHorizontalItem/item1/CTexture_Buff", "CTexture")
	self.go = obj
	self:showview(false)
end

function PlayerTitleView:OnOpen()
	-- self.prepared = false
	self:InitInfo()
end

function PlayerTitleView:OnClose()
	-- self.prepared = false
	self:_ClearBuff()
	self:CloseAllTimer()
	if self.showTimer then
		self:RemoveTimer(self.showTimer)
		self.showTimer = nil
	end	
end

function PlayerTitleView:OnDestroy()
	-- self.prepared = false
	self._bdirty = true
	self:_ClearBuff()
	self:CloseAllTimer()
	if self.showTimer then
		self:RemoveTimer(self.showTimer)
		self.showTimer = nil
	end		
end

function PlayerTitleView:ShowOrHideView(bshow)
	if not self._bdirty then
		self:showview(bshow and self.prepared and self.bActive)
	end	
end

function PlayerTitleView:InitInfo()
	-- self:ChangeHp()
	-- self:ChangeMp()
	self.hpSp.fillAmount = 1
	self:SetBloodDefault()
	self.hpSp.SpriteName = self.spritedata.prop.camp == CAMP.RED and "BloodBar" or "EnemyBloodBar"
end

function PlayerTitleView:ChangeHp()
	local hp_max = self.spritedata.attr.hp_max
	local cur_hp = self.spritedata.attr.hp
	local value = cur_hp / hp_max
	if self.hpSp.fillAmount ~= value then
		self:ShowBloodView()
	end		
	self.hpSp.fillAmount = value
	self.hpbackSp:DOFillAmount(value, 0.5)
end

function PlayerTitleView:ChangeMp()
	local mp_max = self.spritedata.attr.mp_max
	local cur_mp = self.spritedata.attr.mp
	local value = cur_mp / mp_max
	self.mpSld.value = value
end

function PlayerTitleView:SetBloodDefault()
	self:ClearTimer()
	self:ShowOrHideView(IsAlawaysActive())
end

function PlayerTitleView:_SetActive(bactive)
	if not self._bdirty then
		self:showview(bactive and self.prepared)
	end
end

function PlayerTitleView:ClearTimer()
	if self.showTimer then
		self:RemoveTimer(self.showTimer)
		self.showTimer = nil
	end
end

function PlayerTitleView:ShowViewTimer()
	self:ClearTimer()
	
	self:ShowOrHideView(true)
	self.showTimer = self:AddTimer(function ()
		self:ShowOrHideView(false)
	end, 4, 1)
end

function PlayerTitleView:ShowBloodView()

	if IsAlawaysActive() then
		self:ShowOrHideView(true)
	else
		self:ShowViewTimer()
	end
end

function PlayerTitleView:ShowIcon(icon, time)
	self:_ClearBuff()
	AssetManager.LoadUITexture(AssetManager.UITexture.Buff, icon, self.buffTex)

	self.buffObj:SetActive(true)

	self.sequence0 = DOTween.Sequence()
	GameUIUtil.SetGroupAlpha(self.buffObj, 1)
	local tween0 = self.buffObj.transform:DOScale(Vector3.New(2.5, 2.5, 2.5), 0.18)
	local tween0_1 = self.buffObj.transform:DOScale(Vector3.one, 0.3)
	self.sequence0:Append(tween0)
	self.sequence0:Append(tween0_1)
	self.sequence0:AppendCallback(function()
		local sequence = DOTween.Sequence()
		local tween1 = self.buffObj.transform:DOScale(Vector3.New(1.3, 1.3, 1.3), 0.5)	
		local tween2 = self.buffObj.transform:DOScale(Vector3.one, 0.5)
		sequence:AppendCallback(function ()
			GameUIUtil.SetGroupAlphaInTime(self.buffObj ,0.4 ,0.5)
			end)
		sequence:Append(tween1)
		sequence:AppendCallback(function ()
			GameUIUtil.SetGroupAlphaInTime(self.buffObj ,1 ,0.5)
			end)			
		sequence:Append(tween2)
		sequence:SetLoops(-1)
		self.buffsequence = sequence
	end)

	if time and time > 0 then
		self.bufftimer = self:AddTimer(function ()
			self:_ClearBuff()
		end, time, 1)
	end	
end

function PlayerTitleView:_ClearBuff()
	GameUIUtil.SetGroupAlpha(self.buffObj, 1)
	self.buffObj:SetActive(false)

	if self.sequence0 then
		self.sequence0:Kill()
		self.sequence0 = nil
	end

	if self.buffsequence then
		self.buffsequence:Kill()
		self.buffsequence = nil
	end

	if self.bufftimer then
		self:RemoveTimer(self.bufftimer)
		self.bufftimer = nil
	end	
end	

function PlayerTitleView.event.attr:hp(newvalue, oldvalue)
	self:ChangeHp()
end

function PlayerTitleView.event.attr:hp_max(newvalue, oldvalue)
	self:ChangeHp()
end

function PlayerTitleView.event.attr:mp(newvalue, oldvalue)	
	self:ChangeMp()
end

function PlayerTitleView.event.attr:mp_max(newvalue, oldvalue)
	self:ChangeMp()
end

function PlayerTitleView.event.sprite:add_icon(icon, time)
	self:ShowIcon(icon, time)
end	

function PlayerTitleView.event.sprite:remove_icon(icon)
	self:_ClearBuff()
end	

function PlayerTitleView.event.game.public:gameprepared()
	self.prepared = true
	self:SetBloodDefault()
end

return PlayerTitleView
 