-- 精灵卫士·兰黛
local conf = {skill = {}, buff = {}, bullet = {} }

-- 挥砍（普攻）——一段攻击，造成n%攻击力的伤害
conf.skill[310301] = {
    action = {
        default = {
            {trigger.time, {0},     caller.view.active, "attack01" },
            {trigger.time, {400},   action.cast, },
            {trigger.time, {500} },
        },
    },
}

-- 拔刀术（必杀技）——多段伤害，朝前方快速突刺多下，每段造成n%攻击力伤害，最后一下挥斩，造成m%攻击力伤害
conf.skill[310311] = {
    action = {
        default = {
            {trigger.time, {0},     caller.view.active, "spell_01", caller.skill.pause, 1000 },
            {trigger.time, {880},   action.cast, },
            {trigger.time, {50},    action.cast, },
            {trigger.time, {50},    action.cast, },
            {trigger.time, {500},   action.cast, },
            {trigger.time, {500},   action.cast, 310351 },
            {trigger.time, {900} },
        },
    },
}

-- 鼓舞（被动技能）——使前排友军攻击提高n%
conf.skill[310321] = {
    action = {
        default = {
            {trigger.time, {0}, action.cast },
        },
    },
}

return conf