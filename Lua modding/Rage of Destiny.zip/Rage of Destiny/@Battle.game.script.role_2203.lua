-- 边陲之矛·希莱雅（羊头）
local conf = { skill = {}, buff = {}, bullet = {} }

-- 飞矛（普攻）——投掷长矛，对目标造成n%攻击力的伤害
conf.skill[220301] = {
    action = {
        default = {
            {trigger.time, {0}, caller.view.active, "attack01" },
            {trigger.time, {530}, caller.body.addchild, script.prop("bullet_table"), scriptcommon.bullet_trace, script.prop("bullet_args")},
            {trigger.time, {200} },
        },
    },
    event = {
        {scriptevent.onstart, onfire = function(self)
            local slot4level = self.caller.skill:getslotlevel(SKILL.SLOT.SKILL4)
            local slot4buff = slot4level + 220330
            local ischangetype = self.caller.buff:maxlevel(slot4buff)
            local ischangespeed = self.caller.buff:maxlevel(slot4buff)

            self.prop.bullet_table = {typeid = ischangetype and 220302 or 220301}
            self.prop.bullet_args = {speed = ischangespeed and 30000 or 18000, duration = 2000, rangeid = 220301} 
        end}
    }
}

-- 先祖祝福（必杀技）——受到先祖的祝福，所有攻击必定命中目标，且自身每秒回复5%最大生命值，持续8秒
conf.skill[220311] = {
    action = {
        default = {
            {trigger.time, {0},     caller.view.active, "spell_01", caller.skill.pause, 1100 },
            {trigger.time, {200},   },
            {trigger.time, {1000},  action.addstartbuff },
        },
    },
}
--击杀或助攻回复50% mp, （助攻：敌人身上有220301这个buff（持续六秒）
-- 持续期间击杀或助攻将回复自身25%最大生命值的血量
conf.buff[2203120] = {
    event = {
        { eventdef.sprite_dead, modifer = eventmdf.excludeself, onfire = function (self, fromobj)
            if fromobj.prop.camp ~= self.owner.prop.camp and fromobj.caller.buff:contains(220301) then--如果敌人身上有被攻击的标记buff 
                local slot2level = self.caller.skill:getslotlevel(SKILL.SLOT.ULTIMATE)
                local mpid = 220313
                local hpid = 220314

                if slot2level >= 2 then
                    self.caller.buff:add(mpid)   -- 回怒
                end

                if slot2level >= 3 then
                    self.caller.buff:add(hpid)  -- 回血
                end

            end
        end}
    }
}
conf.buff[2203130] = conf.buff[2203120]

conf.skill[220312] = conf.skill[220311]
conf.skill[220313] = conf.skill[220311]

-- 越战越勇（被动技能1）持续命中当前目标，会对其伤害加深，每次命中伤害提升n%，若击杀目标，将保留伤害层数转移到下一个目标中；若助攻目标，保留一半伤害层数
conf.skill[220321] = {
    event = {
        {scriptevent.onstart, onfire = function (self)
            self.prop.layers = 0
            self.prop.last_hit = self.owner
            self.prop.buffid = self.action.info.level + 220321 - 1
            self.prop.buffid_sign = 220329                              -- 易伤标记
        end},
        {eventdef.before_skill_damage, onfire = function (self, damage_table)
            local buffid = self.prop.buffid
            local last_obj = self.prop.last_hit
            if damage_table.toobj == self.prop.last_hit and damage_table.toobj.attr.hp > 0 then -- 击中同一个敌人 或者 继承击杀/助攻的攻击提升 
                damage_table.toobj.caller.buff:add(self.prop.buffid_sign)
                self.caller.buff:add(buffid)--添加伤害提升buff
                self.prop.layers = self.prop.layers ==10 and 10 or self.prop.layers + 1
            elseif self.caller.buff:contains_state("teleport") then
                damage_table.toobj.caller.buff:add(self.prop.buffid_sign)
                if self.prop.layers == 10 then 
                    self.caller.buff:remove_state("teleport")
                else 
                    self.caller.buff:remove(buffid)
                    for i = 1, self.prop.layers + 1 do -- 实际层数应该是继承层数加上这一次的攻击
                        self.caller.buff:add(buffid)--添加伤害提升buff
                    end 
                    self.prop.layers = self.prop.layers ==10 and 10 or self.prop.layers + 1
                    self.caller.buff:remove_state("teleport")
                end    
                -- print("转移完毕，目前层数：",self.caller.buff:getlevel(buffid),"记录的buff层数：", self.prop.layers)
            else --目标改变则清空攻击buff，和记录 
                self.caller.buff:remove(buffid)
                self.prop.layers = 0
            end
            -- 更新记录击中的敌人
            if last_obj and last_obj ~= damage_table.toobj and last_obj.attr.hp > 0 then self.prop.last_hit.caller.buff:remove(self.prop.buffid_sign) end
            self.prop.last_hit = damage_table.toobj

            -- print("实际buff层数：", self.caller.buff:getlevel(buffid),"记录的buff层数：", self.prop.layers)
        end},
        {eventdef.skill_damage, onfire = function (self, damage_table)
                if damage_table.toobj.attr.hp == 0 and damage_table.toobj == self.prop.last_hit and damage_table.toobj.caller.buff:contains(220301) then 
                    --如果两次打中同一个敌人且敌人死亡
                    self.caller.buff:add_state("teleport") --添加继承状态
                    self.prop.layers = self.prop.layers --转移层数
                end
        end},
        { eventdef.sprite_dead, modifer = eventmdf.excludeself, onfire = function (self, fromobj)
                if self.caller.buff:contains_state("teleport") and fromobj == self.prop.last_hit then --判断这个死亡敌人是击杀，不是助攻，退出事件
                    -- print("击杀转移", self.prop.layers)
                    return 
                end
                if fromobj.prop.camp ~= self.owner.prop.camp and fromobj.caller.buff:contains(220301) and fromobj == self.prop.last_hit then--助攻目标 保留一半伤害层数
                    self.prop.layers = self.prop.skill_lv >= 3 and self.prop.layers or tsmath.floor(self.prop.layers/2)
                    self.caller.buff:add_state("teleport")
                    -- print("助攻转移", self.prop.layers)
                end
        end}
    }
}
-- 每次命中伤害提升n%
conf.skill[220322] = conf.skill[220321]
-- 每次命中伤害提升n%
conf.skill[220323] = conf.skill[220321]
-- 每次命中伤害提升n%
conf.skill[220324] = conf.skill[220321]

-- todo 疾风暴雨（被动技能2）每次命中目标，攻速提升n%，最多可叠加n层
-- todo 攻速叠到上限时，承受伤害降低30%
conf.skill[220331] = {
    event = {
        {eventdef.skill_damage, onfire = function (self, damage_table)
            if damage_table.value > 0  then
                self.caller.buff:add(self.static.id)
                --print(self.caller.buff:getlevel(220331))
            end
        end},

        { "atkspd_rate", slot = eventslot.attr, onfire = function (self, newvalue, oldvalue)
            if self.prop.skill_lv > 1 and self.caller.buff:maxlevel(self.static.id)then 
                self.caller.buff:add (220333)
            else
                self.caller.buff:remove(220333)
            end
        end }
    },
}
conf.skill[220332] = conf.skill[220331]
return conf