-----------------------------include-----------------------------

local Timer =  require "Common.Util.Timer"
local hexmaprender = require "Modules.HexMap.hexmaprender"

local function delay(duration, cb)
    local timer = Timer.New(cb, duration, 1)
    timer:Start()
    return timer
end


-----------------------------seqitem-----------------------------
local seqitem = {}

function seqitem:new(o)
    o = o or {}
    setmetatable(o, {__index = self})
    return o
end

function seqitem:setonstart(value)
    self.onstart = value
    return self
end

function seqitem:setonend(value)
    self.onend = value
    return self
end

function seqitem:setduration(value)
    self.duration = value
    return self
end

function seqitem:setdelay(value)
    self.delay = value
    return self
end

function seqitem:_exec(_sequencer)
    self._sequencer = _sequencer
    if self.delay and self.delay > 0 then
        self._timer = delay(self.delay, function () self:_start() end)
    else
        self:_start()
    end
end

function seqitem:_start()
    if self.onstart then
        self.onstart()
    end
    if self._timer then
        self._timer:Stop()
        self._timer = nil
    end
    if self.duration and self.duration > 0 then
        self._timer = delay(self.duration, function () self:_end() end)
    else
        self:_end()
    end
end

-- 手动完成
function seqitem:finish()
    self:_end()
end

function seqitem:_end()
    if self.onend then
        self.onend()
    end
    self:_dispose()
    self._sequencer:_next()
end

function seqitem:_dispose()
    if self._timer then
        self._timer:Stop()
        self._timer = nil
    end
end

-----------------------------tweenitem-----------------------------
local tweenitem = seqitem:new()

function tweenitem:setfrom(value)
    self.from = value
end

function tweenitem:setto(value)
    self.to = value
end

function tweenitem:setinterval(value)
    self.interval = value
end

function tweenitem:setonupdate(value)
    self.onupdate = value
end

function tweenitem:_start()
    local i = 0
    local ti = self.interval or 0.05
    local n = math.floor(self.duration / ti)
    local t = Timer.New(function()
        i = i + 1
        local v = self.from + (self.to - self.from) * (i / n)

        if self.onupdate then
            self.onupdate(v)
        end

        if i >= n then
            self:_end()
        end

    end, ti, n)
    t:Start()
    self._timer = t
end

-----------------------------hexrenderitem-----------------------------
local hexrenderitem = seqitem:new()

function hexrenderitem:_start()
    if self.onstart then
        self.onstart()
    end
    self.render_args.cb = function ()
        self:_end()
    end
    hexmaprender.start_view_args(self.render_args)
end


-----------------------------sequencer-----------------------------
local sequencer = {  seqlist = {}  }
sequencer.__index = sequencer

function sequencer.new()
    local seq = setmetatable({ itemlist = {}, seqid = 0 }, sequencer)
    sequencer.seqlist[seq] = true
    return seq
end

function sequencer.start(...)
    return sequencer.startlist({...})
end

function sequencer.startlist(itemlist)
    local seq = sequencer.new()
    for i, itemtable in ipairs(itemlist) do
        seq:append(itemtable)
    end
    seq:run()
    return seq
end

function sequencer.destroy()
    for seq, _ in pairs(sequencer.seqlist) do
        seq:dispose()
    end
    sequencer.seqlist = {}
end

function sequencer:append(itemtable)
    local item = nil
    itemtable = itemtable or {}
    if itemtable.from and itemtable.to then   -- todo 代表是tween
        item = tweenitem:new(itemtable)
    elseif itemtable.render_args then
        item = hexrenderitem:new(itemtable)
    else
        item = seqitem:new(itemtable)
    end
    table.insert(self.itemlist, item)
    return item
end

function sequencer:_next()
    self.seqid = self.seqid + 1
    local item = self.itemlist[ self.seqid]
    if item then
        item:_exec(self)
    else
        if self.onend then self.onend() end
        self:dispose()
    end
end

function sequencer:run()
    if self.onstart then self.onstart() end
    self:_next()
end

function sequencer:dispose()
    for _, item in ipairs(self.itemlist) do
        item:_dispose()
    end
    sequencer.seqlist[self] = nil
end

function sequencer:setonstart(value)
    self.onstart = value
    return self
end

function sequencer:setonend(value)
    self.onend = value
    return self
end

return sequencer



--[[
    local seq = sequencer.new()
    seq:append({delay = 1, duration = 2}):setonstart():setonend()
    seq:append({delay = 0, duration = 3, onstart = nil, onend = nil})
    seq:append({delay = 0, duration = 5, onstart = nil, onend = nil})
    seq:run()
]]