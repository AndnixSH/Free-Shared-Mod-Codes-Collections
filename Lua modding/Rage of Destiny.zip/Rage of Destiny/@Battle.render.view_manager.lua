local view_manager = {
    --_sprite_view = {},
    _sprite_player_view = {},
    _sprite_monster_view = {},
    _sprite_bullet_view = {},
    _game_view = nil,
    show_active = true,
    show_actor = true,
    show_scene = true,
}

local player_sprite_view = require "Battle.render.view.player_sprite_view"
local bullet_sprite_view = require "Battle.render.view.bullet_sprite_view"
local monster_sprite_view = require "Battle.render.view.monster_sprite_view"

local FrameUpdateMgr = require "First.Util.FrameUpdateMgr"
local render_timer = require "Battle.render.render_timer"

require "Core.Implement.Config.ConfigManager"
require "Core.Face.faceConfig"

local cActiveManager = CS.LJY.NX.ActiveManager

function view_manager.initialize()
    FrameUpdateMgr.Add(render_timer)
    cActiveManager.Instance:Init(faceConfig["data_active"])
end

function view_manager.onaddsprite(sprite_id, sprite_type)
    if not view_manager.show_actor then
        return
    end
    local data = global.service.readonly:reader(sprite_id)
    --print("onaddsprite -->", sprite_id, sprite_type)
    if not data then
        --print("the sprite_id data is nil", sprite_id)
        return
    end

    local view
    if sprite_type == SPRITE_TYPE.PLAYER then
        view = player_sprite_view.New(sprite_id, data.typeid, sprite_type)
        view_manager._sprite_player_view[sprite_id] = view
        view:create()
    elseif sprite_type == SPRITE_TYPE.MONSTER then
        view = monster_sprite_view.New(sprite_id, data.typeid, sprite_type)
        view_manager._sprite_monster_view[sprite_id] = view
        view:create()
    elseif sprite_type == SPRITE_TYPE.BULLET then
        view = bullet_sprite_view.New(sprite_id, data.typeid, sprite_type)
        view_manager._sprite_bullet_view[sprite_id] = view
        view:create()
    end
end

function view_manager.onremovesprite(sprite_id, sprite_type)
    if sprite_type == SPRITE_TYPE.BULLET then
        view_manager._on_remove_sprite(view_manager._sprite_bullet_view, sprite_id)
    end
end

function view_manager.remove_sprite(sprite_id, sprite_type)
    if sprite_type == SPRITE_TYPE.PLAYER then
        view_manager._on_remove_sprite(view_manager._sprite_player_view, sprite_id)
    elseif sprite_type == SPRITE_TYPE.MONSTER then
        view_manager._on_remove_sprite(view_manager._sprite_monster_view, sprite_id)
    elseif sprite_type == SPRITE_TYPE.BULLET then
        view_manager._on_remove_sprite(view_manager._sprite_bullet_view, sprite_id)
    end
end

function view_manager._on_remove_sprite(sprite_views, sprite_id)
    local view = sprite_views[sprite_id]
    if not view then
        --print("the sprite_id view is not exit", sprite_id)
        return
    end

    view:release()
    view:DeleteMe()
    sprite_views[sprite_id] = nil
end

function view_manager.speed(speed_rate)
    view_manager._on_speed_view(view_manager._sprite_player_view, speed_rate)
    view_manager._on_speed_view(view_manager._sprite_monster_view, speed_rate)
    view_manager._on_speed_view(view_manager._sprite_bullet_view, speed_rate)
end

function view_manager._on_speed_view(sprite_views, speed_rate)
    for _, sprite_view in pairs(sprite_views) do
        sprite_view:speed(speed_rate)
    end
end

function view_manager.pause(reason)
    if reason and reason.spriteid then
        view_manager._on_pause_view(view_manager._sprite_player_view, reason.spriteid)
    else
        view_manager._on_pause_view(view_manager._sprite_player_view)
    end

    view_manager._on_pause_view(view_manager._sprite_monster_view)
    view_manager._on_pause_view(view_manager._sprite_bullet_view)
end

function view_manager._on_pause_view(sprite_views, sprite_id)
    if sprite_id then
        for id, sprite_view in pairs(sprite_views) do
            local need_pause = true
            for _, _spriteid in ipairs(sprite_id) do
                if id == _spriteid then
                    need_pause = false
                    break
                end
            end
            if need_pause then
                sprite_view:pause()
            end
        end
    else
        for _, sprite_view in pairs(sprite_views) do
            sprite_view:pause()
        end
    end

end

function view_manager.resume(reason)
    if reason and reason.spriteid then
        view_manager._on_resume_view(view_manager._sprite_player_view, reason.spriteid)
    else
        view_manager._on_resume_view(view_manager._sprite_player_view)
    end

    view_manager._on_resume_view(view_manager._sprite_monster_view)
    view_manager._on_resume_view(view_manager._sprite_bullet_view)

    if view_manager._game_view then
        view_manager._game_view:on_reset_hit()
    end
end

function view_manager._on_resume_view(sprite_views, spriteid)
    if spriteid then
        for id, sprite_view in pairs(sprite_views) do
            local need_resume = true
            for _, _spriteid in ipairs(spriteid) do
                if id == _spriteid then
                    need_resume = false
                    break
                end
            end
            if need_resume then
                sprite_view:resume()
            end
        end
    else
        for _, sprite_view in pairs(sprite_views) do
            sprite_view:resume()
        end
    end
end

function view_manager.start_game(game_info)
    -- print("game_info.gameid --->>", game_info.gameid)
    if game_info.gameid == GAMEPLAYID.MAINLINE or game_info.gameid == GAMEPLAYID.TRAINING then
        local main_line_game_view = require "Battle.render.view.main_line_game_view"
        view_manager._game_view = main_line_game_view.New(game_info)
    elseif game_info.gameid == GAMEPLAYID.HANGUP then
        local hang_up_game_view = require "Battle.render.view.hang_up_game_view"
        view_manager._game_view = hang_up_game_view.New(game_info)
    end
    if view_manager._game_view then
        view_manager._game_view:on_start()
    end
end

function view_manager._remove_all_player()
    for sprite_id, _ in pairs(view_manager._sprite_player_view) do
        view_manager.remove_sprite(sprite_id, SPRITE_TYPE.PLAYER)
    end
end

function view_manager._remove_all_monster()
    for sprite_id, _ in pairs(view_manager._sprite_monster_view) do
        view_manager.remove_sprite(sprite_id, SPRITE_TYPE.MONSTER)
    end
end

function view_manager._remove_all_bullet()
    for sprite_id, _ in pairs(view_manager._sprite_bullet_view) do
        view_manager.remove_sprite(sprite_id, SPRITE_TYPE.BULLET)
    end
end

function view_manager.showall()
    for _, view in pairs(view_manager._sprite_player_view) do
        view:show()
    end

    for _, view in pairs(view_manager._sprite_monster_view) do
        view:show()
    end

    for _, view in pairs(view_manager._sprite_bullet_view) do
        view:show()
    end

    view_manager.show_actor = true
    view_manager.show_active = true

    if view_manager._game_view then
        view_manager._game_view:show()
    end
end

function view_manager.hideall()
    for _, view in pairs(view_manager._sprite_player_view) do
        view:hide()
    end

    for _, view in pairs(view_manager._sprite_monster_view) do
        view:hide()
    end

    for _, view in pairs(view_manager._sprite_bullet_view) do
        view:hide()
    end

    view_manager.show_actor = false
    view_manager.show_active = false

    if view_manager._game_view then
        view_manager._game_view:hide()
    end
end

function view_manager.removeall()
    view_manager._remove_all_player()
    view_manager._remove_all_monster()
    view_manager._remove_all_bullet()

    view_manager._sprite_player_view = {}
    view_manager._sprite_monster_view = {}
    view_manager._sprite_bullet_view = {}

    if view_manager._game_view then
        view_manager._game_view:on_end()
        view_manager._game_view:DeleteMe()
        view_manager._game_view = nil
    end

    render_timer.remove_all_timers()
end

function view_manager.on_bullet_tail(tail_id, sprite_id)
    if view_manager._game_view then
        view_manager._game_view:on_bullet_tail(tail_id, sprite_id)
    end
end

function view_manager.on_hangup_reward(hangup_time)
    if view_manager._game_view and view_manager._game_view.on_hangup_reward then
        view_manager._game_view:on_hangup_reward(hangup_time)
    end
end

function view_manager.getsprite(sprite_id)
    if view_manager._sprite_player_view[sprite_id] then
        return view_manager._sprite_player_view[sprite_id]

    elseif view_manager._sprite_monster_view[sprite_id] then
        return view_manager._sprite_monster_view[sprite_id]
    end
end

return view_manager