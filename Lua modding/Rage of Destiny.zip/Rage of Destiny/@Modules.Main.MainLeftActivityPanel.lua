local ClistRender = require "Core.Implement.UI.Class.ClistRender"
local ClistItem = require "Core.Implement.UI.Class.ClistItem"
local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
local RedPointDef = require "Modules.RedPoint.RedPointDef"
local ObjPoolRender = require "Core.Implement.UI.Class.ObjPoolRender"
local ModuleManager = require "Common.Mgr.UI.ModuleManager"
local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
local MallProxy = require "Modules.Mall.MallProxy"
local MallDef = require "Modules.Mall.MallDef"
local NewbieWidget = require "Core.Implement.UI.Widgets.NewbieWidget"
local DateFormatUtil = require "Common.Util.DateFormatUtil"
local Timer = require "Common.Util.Timer"
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"
local GameUIUtil = CS.GameUIUtil
local MainDef = require "Modules.Main.MainDef"

----------------
local PoolItem = PetPoolItem or BaseClass(ClistItem, NewbieWidget)
function PoolItem:Load(obj)
	self.go = obj
	local root = obj
	self.label = self:GetChildComponent(root, "COutline_label", "CLabel")
	self.iconSp = self:GetChildComponent(root, "CSprite_icon", "CSprite")
	self.timeLb = self:GetChildComponent(root, "Time", "CLabel")
	self.redPointObj = self:GetChild(root, "RedPoint")
	self.btn = self:GetComponent(root, "CButton")
	self.btn:AddClick(function ()
		self:OnTriggerClickBtn(self.btn)
		self:OnClick()
	end)
end

--注册新手引导数据
function PoolItem:RegisterNewbieData()
	local NewbieManager = require "Modules.Newbie.NewbieManager"
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	for _newbie_id, _step in pairs(NewbieDef.ActivityBtn) do
		self:RegisterButton(self.btn, _newbie_id, _step)
	end
end

--是否是领取奖励引导
function PoolItem:CheckActivityNewbie()
	local NewbieManager = require "Modules.Newbie.NewbieManager"
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	local bNewbie = false
	local curNewbieid, curStep = NewbieManager.Instance:GetCurNewbieId()
	if curNewbieid and curStep then
		for _newbie_id, infos in pairs(NewbieDef.ActivityAwardBtn) do
			for _,value in ipairs(infos) do
				if curNewbieid == _newbie_id and value[1] == curStep then
					bNewbie = true
					break
				end
			end
		end
	end
	return bNewbie
end

function PoolItem:SetData(data)
	self.data = data
	self.label.text = self:GetWord(data.label)
	self.iconSp.SpriteName = data.icon
	self.timeLb.text = ""

	self.dataIdx = data.index
	if data.index == MainDef.LeftActivityType.Mall then --商城
		RedPointProxy.Instance:BindNode(RedPointDef.Id.Mall, self.redPointObj)
	elseif data.index == MainDef.LeftActivityType.FirstCharge then --首充
		RedPointProxy.Instance:BindNode(RedPointDef.Id.FirstCharge_First, self.redPointObj)
	elseif data.index == MainDef.LeftActivityType.DailySupply then --每日补给
		RedPointProxy.Instance:BindNode(RedPointDef.Id.MallDailySupply, self.redPointObj)
	end

	if self.timer then
		self.timer:Stop()
		self.timer = nil
	end

	if data.mallItem then
		local giftId = data.mallItem.giftId
		self.leftTime = MallProxy.Instance:GetPushLeftTime(giftId)
		self.timeLb.text = DateFormatUtil.formatTickTime(self.leftTime)

		self.timer = Timer.New(function ()
			if self.leftTime > 0 then
				-- self.leftTime = self.leftTime - 1
				self.leftTime = MallProxy.Instance:GetPushLeftTime(giftId)
				self.timeLb.text = DateFormatUtil.formatTickTime(self.leftTime)
			else
				self.view:UpdateInfo()
			end
		end, 1, -1)
		self.timer:Start()
	elseif data.index == MainDef.LeftActivityType.Sail then --起航
		self.timer = Timer.New(function ()
			local canShowSail = MallProxy.Instance:CanShowSail()
			if not canShowSail then
				self.view:UpdateInfo()
			end
		end, 1, -1)
		self.timer:Start()
	end

	-- print("PoolItem:SetData")

	if self.effect then
		self.effect:Destroy()
		self.effect = nil
	end

	-- if self.data.index == 1 or self.data.mallItem then
		if not self.effect then
			self.effect = UIEffectItem.New("UI_Main_button", self.go, self.view.clist_effect)
		end
		
		local order = self.view.mainViewCanvas.sortingOrder + 1
		self.effect:Open()
		self.effect:SetOrderLayer(order)
		-- print("xxx", order)
	-- end
end

function PoolItem:OnClick()
	local parama = self.data.parama
	if parama then
		UIOperateManager.Instance:OpenWidget(table.unpack(parama))
	else
		GameLogicTools.ShowMsgTips(self:GetWord("Common_1033"))
	end
end

function PoolItem:Hide(index)
	if self.dataIdx == index then
		self.btn.transform.parent.gameObject:SetActive(false)

		-- print("PoolItem:Hide", index)
	end
end
function PoolItem:Show(index)
	if self.dataIdx == index then
		self.btn.transform.parent.gameObject:SetActive(true)

		-- print("PoolItem:Show", index)
	end
end

function PoolItem:Close()
	self:UnRegisterNewbie()

	if self.timer then
		self.timer:Stop()
		self.timer = nil
	end

	if self.effect then
		self.effect:Close()
	end

	-- print("PoolItem:Close")
end

function PoolItem:Destroy()
	self:UnRegisterNewbie()

	if self.effect then
		self.effect:Destroy()
	end

	-- print("PoolItem:Destroy")
end

---------------
local MainState = {
    Show = 0,
    Hide = 1
}

local MainLeftActivityPanel = MainLeftActivityPanel or BaseClass(GameObjFactor,TimerFactor)

function MainLeftActivityPanel:__init(go)
	self.state = MainState.Show
	self.go = go
	self:Load(go)	
end

function MainLeftActivityPanel:Load(obj)
	self.rect = self:GetComponent(obj, "RectTransform")
	self.rectPosition = self.rect.anchoredPosition		
	self.backRect = self:GetChildComponent(obj, "CSprite_back", "RectTransform")

    self.poolList = self:GetChildComponent(obj, "CList_menu", "CList")
    self.menuListRectTra = self:GetChildComponent(obj, "CList_menu", "RectTransform")
    self.menuListMaxHeight = self.menuListRectTra.sizeDelta.y + 50
    self.contentRect = self:GetChildComponent(obj, "CList_menu/Viewport/Content", "RectTransform")
    self.poolList:AddContentChange(function ()
    	self.contentRect.sizeDelta = Vector2.New(188, #self.list * 108 + 10)
    end)

    self.listRender = ClistRender.New()
    self.listRender:Load(self.poolList, PoolItem)

    self.clist_effect = CS.UtilsGameObj.GetWorldCorners(self.poolList.gameObject)

    self.openObj = self:GetChild(obj, "CSprite_back/CButton_close/sprite")
	self.openBtn = self:GetChildComponent(obj, "CSprite_back/CButton_close", "CButton")
	self.openBtn:AddClick(function ()
		if self.state == MainState.Hide then
			self.state = MainState.Show
		else
			self.state = MainState.Hide
		end
		self:UpdateInfo()
	end)

	PoolItem.view = self

	local mainViewWidget = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MainView)
	self.mainViewCanvas = GameObjTools.TryGetComponent(mainViewWidget.go, "Canvas")
end

function MainLeftActivityPanel:Open()
	self.nextDepth = self:GetNextDepth()
	-- print(self.nextDepth)

	-- self.go:SetActive(true)
	self:UpdateInfo()
	self:SetDepth(self.openBtn.gameObject, self.nextDepth)
	self:StartOpenTween()
end	

function MainLeftActivityPanel:UpdateDepth(depth)
	self:SetDepth(self.openBtn.gameObject, depth)
end

function MainLeftActivityPanel:Close()
	-- self.go:SetActive(false)
	if self.opensequence then
		self.opensequence:Kill()
		self.opensequence = nil
	end
	self.listRender:ClearData()
	
end	

function MainLeftActivityPanel:Destroy()
	self.listRender:ClearData()
	self.systemCfg = nil
end

function MainLeftActivityPanel:GetSystemCfg()
	local systemCfg = ModuleManager.GetLeftActivityConfig()
	return systemCfg
end

function MainLeftActivityPanel:UpdateInfo()
	-- print("MainLeftActivityPanel:UpdateInfo")

	self.systemCfg = self:GetSystemCfg()
	local list = {}

	--顺序:商城>首充>每日补给>起航
	for i,v in ipairs(self.systemCfg) do
		local isShow = true
    
		if i == MainDef.LeftActivityType.Mall then --商城
			if not ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.MallRootView, false) then
				isShow = false
			end
		elseif i == MainDef.LeftActivityType.FirstCharge then --首充
			local state = MallProxy.Instance:GetFirstChargeState()
			if state >= MallDef.FirstChargeState.Get_First then
				isShow = false
			else
				if not ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.FirstCharge, false) then
					isShow = false
				end
		   	end
		elseif i == MainDef.LeftActivityType.DailySupply then --每日补给
			isShow = false

			-- local state = MallProxy.Instance:GetFirstChargeState()
			-- if state < MallDef.FirstChargeState.Get_First then
			-- 	isShow = false
			-- elseif not ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.FirstCharge, false) then
			-- 	isShow = false
			-- else
			-- 	local activateId, canGet, hadGet = MallProxy.Instance:GetActivateDailySupplyInfo()
			-- 	if hadGet then
			-- 		isShow = false
			-- 	end
			-- end
		elseif i == MainDef.LeftActivityType.Sail then --起航
			if not ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.MallRootView, false) then
				isShow = false
			end
			if isShow then
				isShow = MallProxy.Instance:CanShowSail()
			end
		end

		if isShow then
			table.insert(list, v)
		end
	end

	--推送礼包
	MallProxy.Instance:SortPush()
	local mall = MallProxy.Instance:GetMall(MallDef.Type.Push)
	if mall then
		for i=1,#mall do
			local mallItem = mall[i]
			local leftTime = MallProxy.Instance:GetPushLeftTime(mallItem.giftId)
			if leftTime > 0 then
	   			local temp = {}
	   			temp.mallItem = mallItem
	   			temp.label = "Main_1008"
	   			temp.icon = "1_4"
	   			temp.parama = {AppFacade.Mall,3,mallItem.giftId}
	   			table.insert(list, temp)
	   		end
   		end
	end
   	
   	if self.state == MainState.Hide then
   		list = {list[1]}
   	end

   	self.list = list
	-- self.go:SetActive(#list > 0 and true or false)
    self.listRender:ClearData()
    self.listRender:AppendDataList(list)
    self.listRender:SetEnable(self.state == MainState.Show and #list >= 4)

    if self.state == MainState.Show then
		local height = #self.list * 108 + 52
		height = math.min(height, self.menuListMaxHeight)
		self.openObj.transform.localEulerAngles = Vector3.New(0, 0, 270)
		self.backRect:DOSizeDelta(Vector2.New(98, height), 0.2)
	else
		self.openObj.transform.localEulerAngles = Vector3.New(0, 0, 90)
		self.backRect:DOSizeDelta(Vector2.New(98, 150), 0.2)
	end

	if #list == 0 then
		self.backRect.gameObject:SetActive(false)
	else
		self.backRect.gameObject:SetActive(true)
	end
end

function MainLeftActivityPanel:StartOpenTween()
	-- self.rect.anchoredPosition = Vector2.New(self.rectPosition.x - 100, self.rectPosition.y)
	-- local tween1 = self.rect:DOAnchorPosX(self.rectPosition.x + 10, 0.2)
	-- local tween2 = self.rect:DOAnchorPosX(self.rectPosition.x, 0.2)

	-- local sequence = DOTween.Sequence()
	-- sequence:Append(tween1)
	-- sequence:Append(tween2)
	-- self.opensequence = sequence

	GameUIUtil.SetGroupAlpha(self.rect.gameObject,0)
	GameUIUtil.SetGroupAlphaInTime(self.rect.gameObject ,1 ,0.3)
end


function MainLeftActivityPanel:GetState()
	return self.state
end

return MainLeftActivityPanel