local BagDef = require "Modules.Bag.BagDef"
local BagProxy = BagProxy or BaseClass(BaseProxy)
function BagProxy:__init(name)
    BagProxy.Instance = self

    self:AddProto(15000, self.On15000) --请求背包信息
    self:AddProto(15001, self.On15001) --背包物品数量发生变化广播
    self:AddProto(15002, self.On15002) --使用物品
    self:AddProto(15003, self.On15003) --出售物品
    self:AddProto(15004, self.On15004)
    self:AddProto(15005, self.On15005) -- 同时使用多种时间道具

    self.data = {}

    --全部物品
    self.bagGoodsInfos = {}


    --装备物品 key value
    self.equipGoodsInfo = {}
    --非装备物品
    self.normalGoodsInfo = {}


    --装备物品 self.equipDataInfos[0][1][1] = {}  key1:有无被穿戴的装备  key2：被穿戴装备部位   key3：装备class
    self.equipDataInfos = {}

    self.data.bCheckHeroRed = false
end

function BagProxy:__delete()
    self.data.bCheckHeroRed = false
    self.data = nil
    self.bagGoodsInfos = nil
    self.equipGoodsInfo = nil
    self.equipDataInfos = nil
    self.normalGoodsInfo = nil
end

--proto
-- 请求背包列表
function BagProxy:Send15000()
    self:SendMessage(15000)
end

function BagProxy:On15000(decoder)
    local EquipProxy = require "Modules.Equip.EquipProxy"
    local goodsInfos = {}
    local equipInfos = {}
    self.normalGoodsInfo = {}
    self.equipGoodsInfo = {}
    self.equipDataInfos = {}
    local goodsCount = decoder:Decode("I2")
    for i = 1, goodsCount do
        local item = {}
        item.goodsId, item.goodsTypeId, item.goodsCount = decoder:Decode("I4I4I4")
        item.goodsEnhanceGrade, item.goodsEnhanceExp, item.equippedHeroId = 0, 0, 0
        item.isEquip = false
        local goodsCfg = self:GetGoodsCfgById(item.goodsTypeId)
        if goodsCfg then
            item.type = goodsCfg.type
            item.subtype = goodsCfg.subtype
            item.equipPart = 0
            item.equipClass = 0
            item.quality = goodsCfg.quality
            -- table.insert(goodsInfos, item)

            self:NormalGoodsInfoTable(item)
        end
    end

    local equipsCount = decoder:Decode("I2")
    for i = 1, equipsCount do
        local item = {}
        item.goodsId, item.goodsTypeId, item.goodsCount, item.goodsEnhanceGrade = decoder:Decode("I4I4I4I2")
        item.goodsEnhanceExp, item.equippedHeroId = decoder:Decode("I4I4")
        item.isEquip = true
        local goodsCfg = self:GetGoodsCfgById(item.goodsTypeId)
        local equipCfg = EquipProxy.Instance:GetHeroEquipById(item.goodsTypeId)
        if goodsCfg then
            item.type = goodsCfg.type
            item.subtype = goodsCfg.subtype
            item.equipPart = equipCfg.position
            item.equipClass = equipCfg.class
            item.quality = goodsCfg.quality
            -- table.insert(goodsInfos, item)
            -- table.insert(equipInfos, item)

            self:EquipGoodsDataKeyTable(item)
            self:EquipGoodsInfoTable(item)
        end
    end

    -- self.bagGoodsInfos = goodsInfos
    --print("on15000=", table.dump(self.bagGoodsInfos))
    --print("on15000========", table.dump(self.normalGoodsInfo), table.dump(self.equipGoodsInfo), table.dump(self.equipDataInfos), table.dump(self.equipDataInfos[0]))
    if not self.data.bCheckHeroRed then
        EquipProxy.Instance:GetHeroTabRedDot(true)
        self.data.bCheckHeroRed = true
    end
    self:GetBagRedDot(true)
    self:ToNotify(self.data, BagDef.NotifyDef.Open_Bag)
    
    local CardPortalProxy = require "Modules.CardPortal.CardPortalProxy"
    CardPortalProxy.Instance:UpdateCardRedPoint()
end

function BagProxy:EquipGoodsDataKeyTable(item)
    local bweard = item.equippedHeroId == 0 and 0 or 1
    if self.equipDataInfos[bweard] then
        if self.equipDataInfos[bweard][item.equipPart] then
            if self.equipDataInfos[bweard][item.equipPart][item.equipClass] then
                table.insert(self.equipDataInfos[bweard][item.equipPart][item.equipClass], item)
            else
                self.equipDataInfos[bweard][item.equipPart][item.equipClass] = {}
                table.insert(self.equipDataInfos[bweard][item.equipPart][item.equipClass], item)
            end
        else
            self.equipDataInfos[bweard][item.equipPart] = {}
            self.equipDataInfos[bweard][item.equipPart][item.equipClass] = {}
            table.insert(self.equipDataInfos[bweard][item.equipPart][item.equipClass], item)
        end
    else
        self.equipDataInfos[bweard] = {}
        self.equipDataInfos[bweard][item.equipPart] = {}
        self.equipDataInfos[bweard][item.equipPart][item.equipClass] = {}
        table.insert(self.equipDataInfos[bweard][item.equipPart][item.equipClass], item)
    end
end

--装备物品改变
function BagProxy:EquipGoodsDataKeyTableChange(goodsId, goodsCount, equipPart, equipClass, info)
    local goodsInfo = table.deepcopy(info)
    local bfind = false
    local wearChange = false

    for k, v in pairs(self.equipDataInfos) do
        if v[equipPart] and v[equipPart][equipClass] then
            for i, item in ipairs(v[equipPart][equipClass]) do
                if item.goodsId == goodsId then
                    if goodsCount == 0 then
                        table.remove(v[equipPart][equipClass], i)
                    else
                        if item.equippedHeroId ~= goodsInfo.equippedHeroId then
                            --穿戴变化(穿戴，卸下，替换)
                            wearChange = true
                            table.remove(v[equipPart][equipClass], i)
                        else
                            -- item = goodsInfo --数量变化
                            v[equipPart][equipClass][i] = goodsInfo
                        end
                    end
                    bfind = true
                    break
                end
            end
        end
        if bfind then
            break
        end
    end
    if not bfind or wearChange then
        self:EquipGoodsDataKeyTable(goodsInfo)
    end
end

function BagProxy:EquipGoodsInfoTable(item)
    self.equipGoodsInfo[item.goodsId] = item
end

--装备物品改变
function BagProxy:EquipGoodsInfoTableChange(goodsId, goodsCount, info)
    local goodsInfo = table.deepcopy(info)
    if self.equipGoodsInfo[goodsId] then
        if goodsCount == 0 then
            self.equipGoodsInfo[goodsId] = nil
        else
            self.equipGoodsInfo[goodsId] = goodsInfo
        end
    else
        self:EquipGoodsInfoTable(goodsInfo)
    end
end

function BagProxy:NormalGoodsInfoTable(item)
    self.normalGoodsInfo[item.goodsId] = item
end

--普通物品改变
function BagProxy:NormalGoodsInfoTableChange(goodsId, goodsCount, info)
    local goodsInfo = table.deepcopy(info)
    if self.normalGoodsInfo[goodsId] then
        if goodsCount == 0 then
            self.normalGoodsInfo[goodsId] = nil
        else
            self.normalGoodsInfo[goodsId] = goodsInfo
        end
    else
        self:NormalGoodsInfoTable(goodsInfo)
    end
end

-- 物品发生改变
function BagProxy:On15001(decoder)
    local goodsId, goodsTypeId, count = decoder:Decode("I4I4I4")
    -- print("On15001==", goodsId, goodsTypeId, count)
    -- local itemData = self:GetItemByID(goodsId)

    -- if itemData ~= nil then
    --     if count == 0 then
    --         self:RemoveItemByID(goodsTypeId)
    --     else
    --         itemData.goodsCount = count
    --     end
    -- else
    --     --普通物品
    --     local item = {}
    --     item.goodsId, item.goodsTypeId,item.goodsCount = goodsId, goodsTypeId, count
    --     item.goodsEnhanceGrade,item.goodsEnhanceExp,item.equippedHeroId = 0,0,0
    --     item.isEquip = false
    --     local goodsCfg = self:GetGoodsCfgById(item.goodsTypeId)
    --     if goodsCfg then
    --         item.type = goodsCfg.type
    --         item.subtype = goodsCfg.subtype
    --         self:InsterItem(item)
    --     end
    -- end

    local goodsCfg = self:GetGoodsCfgById(goodsId)
    local item = {}
    item.goodsId, item.goodsTypeId, item.goodsCount = goodsId, goodsTypeId, count
    item.goodsEnhanceGrade, item.goodsEnhanceExp, item.equippedHeroId = 0, 0, 0
    item.isEquip, item.equipPart, item.equipClass = false, 0, 0
    item.type, item.subtype, item.quality = goodsCfg.type, goodsCfg.subtype, goodsCfg.quality
    self:NormalGoodsInfoTableChange(goodsId, count, item)

    --print("On15001 = ", goodsId, goodsTypeId, count, table.dump(self.bagGoodsInfos))
    self:AutoUseGoods(goodsId, count)
    self:GetBagRedDot(true)
    self:ToNotify(self.data, BagDef.NotifyDef.Update_Bag, goodsId)

    local CardPortalProxy = require "Modules.CardPortal.CardPortalProxy"
    CardPortalProxy.Instance:UpdateCardRedPoint()
end

-- 使用物品
function BagProxy:Send15002(goodsid, count)
    local encoder = NetEncoder.New()
    encoder:Encode("I4I2", goodsid, count)
    self:SendMessage(15002, encoder)
end

--抽卡使用随机种族卡
function BagProxy:Send15002OnRandomRace(goodsid, count, race)
    local encoder = NetEncoder.New()
    encoder:Encode("I4I2I1", goodsid, count, race)
    self:SendMessage(15002, encoder)
end

--背包使用随机种族卡
function BagProxy:Send15002BagRandomRace(goodsid, count, race)
    local encoder = NetEncoder.New()
    encoder:Encode("I4I2I1", goodsid, count, race)
    self:SendMessage(15002, encoder)
end

--使用瓜子宝箱subtype=605
function BagProxy:Send15002OnBox(goodsid, count, goodsList)
    local encoder = NetEncoder.New()
    encoder:Encode("I4I2", goodsid, count)
    encoder:EncodeList("I4I2", goodsList)
    self:SendMessage(15002, encoder)
end

--使用宝箱subtype=604
function BagProxy:Send15002OneChest(goodsid, count, replace_goods_id)
    local encoder = NetEncoder.New()
    encoder:Encode("I4I2", goodsid, count)
    encoder:Encode("I4", replace_goods_id)
    self:SendMessage(15002, encoder)
end

function BagProxy:On15002(decoder)
    local result = decoder:Decode("I1")
    if result == 0 then
        --使用英雄召唤类,获得英雄做展示显示
        local _type = decoder:Decode("I2")  -- 根据子类型做一些特殊奖励展示:0   303:种族自选英雄卡(抽卡界面使用) 305种族自选英雄卡(背包使用)
        local rewards = decoder:DecodeList("I4I4", true)
        local new_hero_list = decoder:DecodeList("I4I4I2I2", true)  --新英雄列表
        local goods_list = {}
        for i, v in ipairs(rewards) do
            table.insert(goods_list, { goodsid = v[1], goodsnum = v[2] })
        end
        -- print("UseGoods========", _type, table.dump(new_hero_list))
        -- if _type == 0 then
        --     GameLogicTools.ShowGetItemView(goods_list, 1)
        -- end
        self:ToNotify(self.data, BagDef.NotifyDef.UseGoods, { result = result, _type = _type, goods_list = goods_list, new_hero_list= new_hero_list})
    else
        self:ToNotify(self.data, BagDef.NotifyDef.UseGoods, { result = result })
    end
end

-- 出售物品
function BagProxy:Send15003(goodsid, count)
    local encoder = NetEncoder.New()
    encoder:Encode("I4I2", goodsid, count)
    self:SendMessage(15003, encoder)
end

function BagProxy:On15003(decoder)
    local result = decoder:Decode("I1")
    if result == 0 then
        local rewardId, rewardCount = decoder:Decode("I4I4")
        local rewardInfos = {}
        table.insert(rewardInfos, { goodsid = rewardId, goodsnum = rewardCount })
        GameLogicTools.ShowGetItemView(rewardInfos, 1)
    end
end

function BagProxy:Send15004(goodsid, count, value)
    --print("Send15004 ", goodsid, count, value)
    local encoder = NetEncoder.New()
    encoder:Encode("I4I2I4", goodsid, count, value)
    self:SendMessage(15004, encoder)
end

function BagProxy:On15004(decoder)
    local result, goodsid, value = decoder:Decode("I2I4I4")
    --print("On15004 = ", result, goodsid, value)
    if result == 0 then
        self:ToNotify(self.data, BagDef.NotifyDef.Update_Special_Tool, { goodsid = goodsid, value = value })
    end
end


--同时使用多种不同物品(目前只能用于使用多种 时间道具 subType 601)
function BagProxy:Send15005(goodsList)
    local encoder = NetEncoder.New()
    encoder:EncodeList("I4I4", goodsList)
    --encoder:Encode("I4I2I4", goodsid, count, value)
    self:SendMessage(15005, encoder)
end

function BagProxy:On15005(decoder)
    local rewards = decoder:DecodeList("I4I4", true)
    local goods_list = {}
    for i, v in ipairs(rewards) do
        table.insert(goods_list, { goodsid = v[1], goodsnum = v[2] })
    end
    -- print("UseGoods========", _type, table.dump(new_hero_list))
    -- if _type == 0 then
    --     GameLogicTools.ShowGetItemView(goods_list, 1)
    -- end
    local result = #goods_list > 0 and 0 or 1
    self:ToNotify(self.data, BagDef.NotifyDef.UseGoods, { result = result, _type = 0, goods_list = goods_list, new_hero_list= new_hero_list})
end

--data cfg
function BagProxy:GetGoodsCfg()
    local configList = ConfigManager.GetConfig("data_goods")
    return configList
end

--获得背包里 所有对应消耗道具(经验、金币、粉尘) 的 加速获得道具
function BagProxy:GetGoodsListByCurrencyID(currencyId)
    local ret = {}
    local configList = self:GetGoodsCfg()
    for goodsId,v in pairs(configList) do
        if v.subtype == BagDef.SubType.TimeLinessTool then
            local goodsInfo = self:GetGoodsInfoById(goodsId)
            if v.value and v.value[1] and #v.value == 1 and v.value[1][1] == currencyId and goodsInfo then
                table.insert(ret,goodsInfo)
            end
        end
    end
    return ret
end

function BagProxy:GetGoodsCfgById(goodsid)
    local configList = self:GetGoodsCfg()
    if configList[goodsid] then
        return configList[goodsid]
    end
    -- for k,v in pairs(configList) do
    --     if v.id == goodsid then
    --         return v            
    --     end
    -- end

end

-------------
function BagProxy:GetEquipsByGoodsTypeId(goodsTypeId)
    for i, v in ipairs(self.bagGoodsInfos) do
        if v.isEquip then
            if v.goodsTypeId == goodsTypeId then
                return v
            end
        end
    end
end

--data logic 普通物品的goodsId 和goodsTypeId 相同
function BagProxy:GetItemByID(itemId)
    -- for k, v in pairs(self.bagGoodsInfos) do
    --     if itemId == v.goodsId then
    --         return v
    --     end
    -- end
    local info = self:GetGoodsInfoById(itemId)
    return info
end

function BagProxy:GetGoodsInfoById(goodsId)
    if self.normalGoodsInfo[goodsId] then
        return self.normalGoodsInfo[goodsId]
    end

    if self.equipGoodsInfo[goodsId] then
        return self.equipGoodsInfo[goodsId]
    end
    return nil
end

function BagProxy:GetItemCountByID(itemId)
    local count = self:GetGoodsCountById(itemId)
    -- for k, v in pairs(self.bagGoodsInfos) do
    --     if itemId == v.goodsId then
    --         count = count + v.goodsCount
    --     end
    -- end
    return count
end
function BagProxy:GetGoodsCountById(goodsId)
    local count = 0
    if self.normalGoodsInfo[goodsId] then
        return self.normalGoodsInfo[goodsId].goodsCount
    end

    if self.equipGoodsInfo[goodsId] then
        return self.equipGoodsInfo[goodsId].goodsCount
    end
    return count
end

function BagProxy:RemoveItemByID(itemId)
    for k, v in ipairs(self.bagGoodsInfos) do
        if itemId == v.goodsId then
            table.remove(self.bagGoodsInfos, k)
        end
    end
end

function BagProxy:InsterItem(item)
    table.insert(self.bagGoodsInfos, item)
end

function BagProxy:GetGoodsInfo()
    return self.bagGoodsInfos
end
function BagProxy:GetNormalGoodsInfo()
    return self.normalGoodsInfo
end
function BagProxy:GetEquipGoodsInfo()
    return self.equipGoodsInfo
end

--对应equipPart, equipClass未使用的装备列表
function BagProxy:GetUnUseEquipByPosAndClass(equipPart, equipClass)
    if self.equipDataInfos[0] and self.equipDataInfos[0][equipPart] and
            self.equipDataInfos[0][equipPart][equipClass] and
            #self.equipDataInfos[0][equipPart][equipClass] > 0 then
        return self.equipDataInfos[0][equipPart][equipClass]
    end
    return nil
end

--equipPart:装备槽位 equipClass:职业
function BagProxy:GetEquipGoodsInfoByPosAndClass(equipPart, equipClass)
    local unUseGoods = {}
    local usedGoods = {}
    for _bused, info in pairs(self.equipDataInfos) do
        local goodsInfos = {}
        if info[equipPart] and info[equipPart][equipClass] then
            goodsInfos = info[equipPart][equipClass]
        end
        if _bused == 0 then
            unUseGoods = goodsInfos
        else
            usedGoods = goodsInfos
        end
    end
    return unUseGoods, usedGoods
end
------------------



--自动使用物品
function BagProxy:AutoUseGoods(goodsid, count)
    if count > 0 then
        local itemConfig = self:GetGoodsCfgById(goodsid)
        if itemConfig.autouse and itemConfig.autouse > 0 then
            self:Send15002(goodsid, count)
        end
    end
end

function BagProxy:GetGoodsSubTypeDesc(type, subtype)
    for i, config in pairs(BagDef.GoodsTypeDesc) do
        if config.type == type and config.subtype == subtype then
            return config
        end
    end
end

--装备物品
function BagProxy:GetEquipGoods()
    local infos = {}
    for i, info in ipairs(self.bagGoodsInfos) do
        if info.isEquip then
            table.insert(infos, info)
        end
    end
    return infos
end

function BagProxy:GetTabGoodsType(tab)
    for i, info in pairs(BagDef.BagTabType) do
        if info.tab == tab then
            return info.goodsType
        end
    end
    return {}
end

function BagProxy:CheckExistValue(values, value)
    for k, v in pairs(values) do
        if v == value then
            return true
        end
    end
    return false
end

function BagProxy:GetGoodsFrame(quality)
    local cfg = ConfigManager.GetConfig("data_goodsrank")
    return cfg[quality]
end

--背包红点
function BagProxy:GetBagRedDot(bupdate)
    local count = self:GetBagRootViewRedCount()
    if bupdate then
        local MainProxy = require "Modules.Main.MainProxy"
        local MainDef = require "Modules.Main.MainDef"
        MainProxy.Instance:UpdateRedDot(MainDef.MainRedDotType.Bag, count)
    end
    return count
end


--获取页签红点
function BagProxy:GetTabRedDot(tab)
    local count = 0
    local bagGoods = self:GetNormalGoodsInfo()
    local goodsTypes = self:GetTabGoodsType(tab)
    for i, v in pairs(bagGoods) do
        if v.equippedHeroId == 0 and self:CheckExistValue(goodsTypes, v.type) then
            local goodsCfg = self:GetGoodsCfgById(v.goodsTypeId)
            if goodsCfg then
                if BagDef.SubType.Hero_Stone == v.subtype then
                    --灵魂石
                    local num = v.goodsCount - goodsCfg.value[2] >= 0 and 1 or 0
                    count = count + num
                elseif BagDef.SubType.Hero_Fragment == v.subtype then
                    --英雄碎片
                    local num = v.goodsCount - goodsCfg.value[4] >= 0 and 1 or 0
                    count = count + num
                elseif BagDef.SubType.Race_Hero_Card == v.subtype then
                    --英雄碎片
                    count = count + 1
                elseif BagDef.SubType.Hero_Choice_Card_On_Bag == v.subtype then
                    --背包自选英雄卡
                    count = count + 1
				elseif BagDef.SubType.RandomItemChest == v.subtype then
					--随机物品宝箱
					count = count + 1
                end
                if count > 0 then
                    break
                end
            end
        end
    end
    return count
end

--背包红点
function BagProxy:GetBagRootViewRedCount()
    local count = self:GetTabRedDot(1)
    return count
end

function BagProxy:GetFlyTypeByDropType(FlyIconTypeGoodsId, dropType)
    for _type,_drop_type in pairs(FlyIconTypeGoodsId) do
        if _drop_type == dropType then
            return _type
        end
    end
end

-- 0：账号经验  1:金币 2：粉尘  获取货币目标坐标，目标obj, 初始缩放, 目标缩放 
function BagProxy:GetFullScreenPropertyByGoodId(id, dropType)
    --货币飞去全屏界面货币栏
    local fullView = LuaLayout.Instance:GetWidget(UIWidgetNameDef.FullScreenView)
    if id and fullView and fullView:IsOpen() then
        local position = fullView:GetProperTyItemsByGoodsId(id)
        local flyItemType = self:GetFlyTypeByDropType(BagDef.FullViewFlyIconTypeGoodsId, dropType)
        if position and flyItemType then
            return position, UIWidgetNameDef.FullScreenView, flyItemType
        end
    end

    --货币飞去主界面左上角
    local position, targetObj, originScale, toScale = nil, nil, nil, nil
    local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MainView)
    if view and view:IsOpen() then
        local objs = view.mainInfoPanel:GetTweenObjs()
        if objs[dropType+1] then
            position = objs[dropType+1].transform.position
            local flyItemType = self:GetFlyTypeByDropType(BagDef.MainViewFlyIconTypeGoodsId, dropType)
            return position, UIWidgetNameDef.MainView, flyItemType
        end
    end

end

--是否是随机装备
function BagProxy:CheckRandomEquipSubType(goodsTypeId)
    local bRandomEquip = false
    local cfg = self:GetGoodsCfgById(goodsTypeId)
    if cfg.type == BagDef.BagType.Basic_Equip and BagDef.RandomEquipSubeType[cfg.subtype] then
        bRandomEquip = true
    end
    return bRandomEquip
end

function BagProxy:GetRoleIdByGoodsTypeId(goodslist)
    
    local roleidList = {}
    local HeroDef = require "Modules.Hero.HeroDef"
    for _ , v in ipairs(goodslist) do
        local goods_type_id = v[1]
        local cfg = self:GetGoodsCfg() 
        if cfg then
            local goods_config_info = cfg[goods_type_id]
            if goods_config_info then
                if goods_config_info.type == BagDef.BagType.Soul_Stones then
                    if goods_config_info.autouse > 0 then
                        local parama = goods_config_info.value
                        if parama then
                            local roleid = parama[1]
                            local rank = parama[2] >= HeroDef.Hero_Rank_Enum.purple and HeroDef.Hero_Rank_Enum.purple or parama[2]
                            table.insert(roleidList,{roleid,rank})
                        end
                    end
                end
            end
        end 
    end
    return roleidList
end
return BagProxy
