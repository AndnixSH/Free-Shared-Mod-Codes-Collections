local cell_center_anchor = BaseClass()

local cCellCenterAnchor = CS.LJY.NX.CellCenterAnchor

function cell_center_anchor:__init(position, rotx, roty, rotz)
    self.canchor = cCellCenterAnchor(position.x, position.y, position.z, rotx or 0, roty or 0, rotz or 0)
end

function cell_center_anchor:__delete()
    if self.canchor then
        self.canchor = nil
    end
end

function cell_center_anchor:set_moving(moving)
    if self.canchor then
        self.canchor:SetMoving(moving)
    end
end

function cell_center_anchor:move_up_down(value, duration)
    if self.canchor then
        self.canchor:MoveUpDown(value, duration)
    end
end

function cell_center_anchor:move_y(value, duration)
    if self.canchor then
        self.canchor:MoveY(value, duration)
    end
end

function cell_center_anchor:move_follow_path(position_list, speed, cbreach, cbnode, keepheader)
    if self.canchor then
        return self.canchor:MoveFollowPath(position_list, speed, cbreach, cbnode, keepheader)
    end
end

function cell_center_anchor:set_position(position)
    if self.canchor then
        self.canchor:SetPosition(position)
    end
end

function cell_center_anchor:getcanchor()
    if self.canchor then
        return self.canchor
    end
end

return cell_center_anchor