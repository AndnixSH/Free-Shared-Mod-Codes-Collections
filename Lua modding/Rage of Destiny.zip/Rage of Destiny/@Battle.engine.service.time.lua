local time = { frame = 0, tick = 0, time = 0 }

function time:process(time, tick)
    self.tick = tick
    self.time = time
    self.frame = self.frame + 1
end

function time:dispose()
    self.time = 0
    self.frame = 0
    self.time = 0
end

function time:dump()
    global.debug.info(string.format("time:%s frame:%s tick:%s", self.time, self.frame, self.tick))
end

return time