FaceProxy = FaceProxy or BaseClass()

faceProxyList = faceProxyList or {}

function FaceProxy:__init(name)
	self.data = {}
	self.proxyName = name
	faceProxyList[name] = self
end

function FaceProxy:__delete()
	if self.proxyName then
		faceProxyList[self.proxyName] = nil
	end
end