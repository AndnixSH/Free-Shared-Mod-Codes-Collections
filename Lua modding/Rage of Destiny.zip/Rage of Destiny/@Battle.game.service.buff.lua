local buff_base = {}
buff_base.__index = buff_base

function buff_base:init(context)
    self._context = context
    self._over = false
end

function buff_base:start(fromobj)
    self._over = false
    self._fromobj = fromobj
    if self.onstart and self._context then
        self.onstart(self._context)
    end
end

function buff_base:getfromobj()
    return self._fromobj
end

function buff_base:getcontext()
    return self._context
end

function buff_base:getlevel()
    if self.ongetlevel and self._context then
        return self.ongetlevel(self._context)
    end
end

function buff_base:merge()
    if self.onmerge and self._context then
        self.onmerge(self._context)
    end
end

function buff_base:shorten(rate)
    if self.onshorten and self._context then
        self.onshorten(self._context, rate)
    end
    self:stop()
end

function buff_base:reset_time()
    if self.onreset_time and self._context then
        self.onreset_time(self._context)
    end
end

function buff_base:stop()
    if self._over then return end
    self._over = true
    if self.onend and self._context then
        self.onend(self._context)
    end
    if self.cbend and self._context then
        self.cbend(self._context)
    end
    self.cbend = nil
end

function buff_base:isrun()
    return not self._over
end

function buff_base:destroy()
    if self._context and self._context.destroy then
        self._context:destroy()
    end
end



local buffserver = { _buffreplace = {} }

function buffserver:load(tb, context, source)
    setmetatable(tb, buff_base)
    local newskill = {}
    setmetatable(newskill, {__index = tb})
    newskill:init(context)
    return newskill
end

function buffserver:replacebuff(fromid, toid)
    self._buffreplace[fromid] = toid
end

function buffserver:getbuffid(typeid)
    return self._buffreplace[typeid] or typeid
end

function buffserver:addbuff(obj, buffid, prop)
    local buff_config = global.service.config:get("buff_static")
    local static = buff_config[buffid]
    if not static then
        global.debug.warning("buff_static找不到"..buffid)
    end
    local buffpath = nil
    if static and static.class then
        buffpath = "sprite.buff.".. BUFF.CLASS[static.class]
    else
        buffpath = "sprite.buff.buff_script_runner"
    end


    local template = global.service.requirer:require(buffpath)
    return global.service.logic_factory:createlogic(obj, buffid, static, prop, template)
end

function buffserver:unload(tb)
    tb:destroy()
end

function buffserver:dump()
end

function buffserver:dispose()
    self._buffreplace = {}
end

return buffserver