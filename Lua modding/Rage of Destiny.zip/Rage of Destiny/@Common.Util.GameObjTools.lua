local GameUIUtil = CS.GameUIUtil

GameObjTools = {}
local types = {}
types.CDrag 			= typeof(CS.CDrag)
types.CButton 			= typeof(CS.CButton)
types.CLabel 			= typeof(CS.CLabel)
types.CSprite			= typeof(CS.CSprite)
types.CAtlas 			= typeof(CS.CAtlas)
types.RectTransform 	= typeof(CS.UnityEngine.RectTransform)
types.Transform 		= typeof(CS.UnityEngine.Transform)
types.CList 			= typeof(CS.CList)
types.CBaseRender		= typeof(CS.CBaseRender)
types.Camera			= typeof(CS.UnityEngine.Camera)
types.CToggleGroup 		= typeof(CS.CToggleGroup)
types.CCheckBox 		= typeof(CS.CCheckBox)
types.CTexture 			= typeof(CS.CTexture)
types.Canvas 			= typeof(CS.UnityEngine.Canvas)
types.CanvasGroup 		= typeof(CS.UnityEngine.CanvasGroup)
types.GraphicRaycaster  = typeof(CS.UnityEngine.UI.GraphicRaycaster)
types.CComboBox			= typeof(CS.CComboBox)
types.CTextInput		= typeof(CS.CTextInput)
types.CImageLabel		= typeof(CS.CImageLabel)
types.CFont				= typeof(CS.CFont)
types.CanvasScaler		= typeof(CS.UnityEngine.UI.CanvasScaler)
types.Image				= typeof(CS.UnityEngine.UI.Image)
types.Outline			= typeof(CS.UnityEngine.UI.Outline)
types.CSlider			= typeof(CS.CSlider)
types.SkinnedMeshRenderer = typeof(CS.UnityEngine.SkinnedMeshRenderer)
types.Renderer 		 	= typeof(CS.UnityEngine.Renderer)
types.ParticleSystem	= typeof(CS.UnityEngine.ParticleSystem)
types.TrailRenderer		= typeof(CS.UnityEngine.TrailRenderer)
types.LineRenderer 		= typeof(CS.UnityEngine.LineRenderer)
types.CSelect			= typeof(CS.CSelect)
types.COutline			= typeof(CS.COutline)
types.CBoxCollider		= typeof(CS.CBoxCollider)
types.GridLayoutGroup	= typeof(CS.UnityEngine.UI.GridLayoutGroup)
types.CRichLabel        = typeof(CS.CRichLabel)
types.CCanvas			= typeof(CS.CCanvas)
types.Gradient			= typeof(CS.Gradient)
types.SpriteGravity 	= typeof(CS.LJY.NX.SpriteGravity)
types.VerticalLayoutGroup 			= typeof(CS.UnityEngine.UI.VerticalLayoutGroup)
types.HorizontalLayoutGroup 		= typeof(CS.UnityEngine.UI.HorizontalLayoutGroup)
types.LayoutGroup 		= typeof(CS.UnityEngine.UI.LayoutGroup)
types.HeroShowController = typeof(CS.HeroShowController)
types.AnimatorStateInfo = typeof(CS.UnityEngine.AnimatorStateInfo)
types.Animator = typeof(CS.UnityEngine.Animator)
types.MeshRenderer = typeof(CS.UnityEngine.MeshRenderer)
types.CScrollBar = typeof(CS.CScrollBar)
types.ScrollRect 		= typeof(CS.UnityEngine.UI.ScrollRect)
types.CEmoLabel = typeof(CS.CEmoLabel)
types.UniWebView = typeof(CS.UniWebView)
types.HollowOutMask = typeof(CS.HollowOutMask)
types.Animation = typeof(CS.UnityEngine.Animation)
types.GameObjectGyroController = typeof(CS.GameObjectGyroController)
types.CEffect = typeof(CS.CEffect)
function GameObjTools.typeof(name)
	local ret = nil
	ret = types[name]
	if nil == ret then
		return typeof(name)
	end
	return ret
end

function GameObjTools.ObjIsNull(obj)
	if obj == nil or string.find(tostring(obj) , "null") then
		return true
	else
		return false
	end	
end

function GameObjTools.GetGameObjectByFind(objName)
	return GameObject.Find(objName)
end

function GameObjTools.SetParent(child , parent)
	child.transform:SetParent(parent.transform)
	child.transform.localPosition = Vector3.zero
    child.transform.localRotation = Quaternion.identity
    child.transform.localScale = Vector3.one
    child.layer = parent.layer
end

function GameObjTools.AddComponent(go,class)
	return go:AddComponent(GameObjTools.typeof(class))
end	

function GameObjTools.GetComponent(go,class)
	return go:GetComponent(GameObjTools.typeof(class))
end	

function GameObjTools.GetChild(go,path)
	local child  = go.transform:Find(path)
	if child ~= nil then
		return child.gameObject
	end	
end	

function GameObjTools.GetChildByIndex(go, index)
	local child = go.transform:GetChild(index)
	if child ~= nil then
		return child.gameObject
	end	
end

function GameObjTools.GetChildComponent(go, path, class)
	local childObj = GameObjTools.GetChild(go,path)
	if childObj ~= nil then
		return GameObjTools.GetComponent(childObj,GameObjTools.typeof(class))
	end
	return nil
end

function GameObjTools.GetComponentsInChildren(go, class, includeself)

	local comps = GameObjTools._GetComponentsInChildren(go, class)

	if includeself then
		local com = GameObjTools.GetComponent(go, class)
		if nil == com or string.find(tostring(com) , "null") then
		else
			table.insert(comps, com)
		end	
	end

	return comps

end

function GameObjTools._GetComponentsInChildren(go, class, _coms)
	-- return go:GetComponentsInChildren(GameObjTools.typeof(class))
	local coms = _coms or {}
	local tran = go.transform

	for i=1, tran.childCount do
		local child = tran:GetChild(i - 1)
		local com = GameObjTools.GetComponent(child.gameObject, class)

		if nil == com or string.find(tostring(com) , "null") then
		else
			table.insert(coms, com)
		end	

		coms = GameObjTools._GetComponentsInChildren(child.gameObject, class, coms)
	end
	return coms
end

function GameObjTools.TryGetComponent(obj, typeName)
	if (nil ~= obj) then 
		local comp = obj:GetComponent(GameObjTools.typeof(typeName))
		if nil == comp or string.find(tostring(comp) , "null") then
			comp = obj:AddComponent(GameObjTools.typeof(typeName))
		end
		return comp
	else
		return nil
	end
end	

function GameObjTools.AddChild(parent, go)
	if go and parent then
		local child = GameObject.Instantiate(go)
		GameObjTools.SetParent(child , parent)
		return child
	end	
end	

function GameObjTools.SetRectTransform(go ,sizeDelta ,anchoredPosition ,anchorMax ,anchorMin ,pivot )
	local rect = GameObjTools.GetComponent(go,"RectTransform")
	if rect then
		if anchorMax then
			rect.anchorMax = anchorMax
		end	
		if anchorMin then
			rect.anchorMin = anchorMin
		end
		if pivot then	
			rect.pivot = pivot
		end
		if sizeDelta then	
			rect.sizeDelta = sizeDelta
		end
		if anchoredPosition then	
			rect.anchoredPosition = anchoredPosition
		end	
	end	
end

function GameObjTools.SetRectOffset(go ,left ,right ,top ,bottom)
	local rect = GameObjTools.GetComponent(go,"RectTransform")
	if rect then
		rect.offsetMin = Vector2.New(left ,bottom)
		rect.offsetMax = Vector2.New(right ,top)
	end	
end

function GameObjTools.Destroy(obj)
	if obj then
		GameObject.Destroy(obj)
	end
end

function GameObjTools.SetGray(obj, value, bincludeChildren)
	if bincludeChildren == nil then bincludeChildren = false end
	GameUIUtil.SetGray(obj, value, bincludeChildren)
end

function GameObjTools.SetShader(obj ,str ,bincludeChildren)
	if bincludeChildren == nil then bincludeChildren = false end
	GameUIUtil.SetShader(obj, str, bincludeChildren)
end

function GameObjTools.SetSelected(obj)
	if obj then
		local EventSystem = CS.UnityEngine.EventSystems.EventSystem
		EventSystem.current:SetSelectedGameObject(obj)
	end	
end

function GameObjTools.SetDepth(obj, depth, bsetLayer)
	local canvas = GameObjTools.TryGetComponent(obj, "Canvas")
	local ray = GameObjTools.TryGetComponent(obj, "GraphicRaycaster")	
	ray.ignoreReversedGraphics = false
	if canvas then
		if depth > 0 then
			canvas.overrideSorting = true
	        canvas.sortingOrder = depth	  
	    else
	    	canvas.overrideSorting = false    
	    end	

	    if bsetLayer ~= nil and bsetLayer == true then
	    	obj.layer = 5
	    end
	end		
end

function GameObjTools.SetAnimator(obj, bopen)
	local animator = GameObjTools.GetComponent(obj, "Animator")
	if animator then
		if not bopen then
			animator.enabled = false
		else
			animator.enabled = true
			animator:Rebind()
		end
	end		
end

function GameObjTools.SetModelDepth(obj, depth)
	local trans = obj.transform
	local pos = trans.localPosition 
	trans.localPosition = Vector3.New(pos.x ,pos.y ,- depth)	
end