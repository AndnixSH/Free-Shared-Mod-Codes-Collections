local logic = {timer = {},event = service.event()}

function logic:oncreate()
    -- self:send_strategy("gamestart")
    local activity_info = self.owner.prop.activity_info
    local cur_round = activity_info and activity_info.round
    local fast_start = activity_info and activity_info.fast_start

    if not cur_round or cur_round == 1 then
        self.timer:delay(self.static.delay or 0, self.send_strategy, fast_start and "game_fast_start" or "gamestart")
    end
end

function logic.event.game:gameprepared()
    self:send_strategy(eventdef.gameprepared)
end

function logic.event.game:camera_adjust_start()
    self:send_strategy(eventdef.camera_adjust_start)
end

function logic:send_strategy(strategykey)
    local value = self.static.strategy_list[strategykey]
    -- print('send_strategy', strategykey, value)
    if value then
        local args = value.args or self:_getargs(value.confkey, value.argskey)
        if args then
            self:sendmessage(eventdef.camera_strategy, assert(value.strategy), args)
        else
            global.debug.error("摄像机策略为空", self.owner.prop.config_key, strategykey)
        end
    end
end

function logic:_getargs(confkey, argskey)
    local data_key = self.service.config:get(confkey)
    if data_key then
        local conf = data_key[self.owner.prop.config_key]
        if conf then
            return conf[argskey]
        end
    end
end

return logic
