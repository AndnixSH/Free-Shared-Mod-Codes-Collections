
local conf = {skill = {}, buff = {}, bullet = {}}

-- 朝最近的目标射出星火术，造成70%攻击力的伤害。

conf.skill[330301] = {
    action = {
        default = {
            {trigger.time, {0},     action.active_random, { "attack01", "attack02"}, },
            {trigger.time, {500},   caller.body.addchild, {typeid = 330301}, scriptcommon.bullet_trace, {speed = 15000, duration = 2000, rangeid = 330301}},
            --{trigger.time, {500}, action.cast, },
            {trigger.time, {500} },
        },
    },
}

-- 双翅举起，头顶出现月蚀标识，持续召唤星火（期间霸体，只会被自己的失误打断），每发对随机敌人造成n%攻击力的伤害。发射4发后，后续每落下一发，增加8%的失误率。失误时，施法会中断并使自身短暂眩晕
-- 有25%的概率发射蓝色星火，使目标受到n点减速效果，可叠加，持续4秒
-- 有25%的概率发射绿色星火，造成伤害的100%转化为回复自身生命
conf.skill[330311] = script.composite {
    main = {
        action = {
            default = {
                {trigger.time, {0},             action.active, "spell_01_start", caller.skill.pause, 1500},
                -- {trigger.time, {0},          action.addstartbuff},
                {trigger.time, {1500},          action.active, "spell_01_loop"},
                {trigger.time, {100,800,20},    action.message, "330311_bullettype", action.addchild, script.prop("bullet_table"), "bullet_single"},
            },
            stop = {
                {trigger.time, {100},           caller.buff.add, script.prop("stopid")},
            },
        },
        event = {
            {scriptevent.onstart, onfire = function (self)
                local exbuff = self.caller.buff:get_state("exbuff")
                self.owner.attr:setbase("immune_suffer", 1)
                self.prop.stopid = 900103 -- 失误后眩晕时间
                self.prop.failnum = 4 -- 发射4发后，后续每落下一发，增加失误率。
                self.prop.failrate = 80 -- 之后每发增加的失误率
                self.prop.bullet_table = {typeid = 999999}
                self.prop.target = {false}
                self.prop.same_target = exbuff and exbuff[SKILL.SLOT.ULTIMATE] or false
                self.prop.last_target = self.action:range(self.static.id)[1]
            end},

            {"330311_bullettype", onfire =function(self)
                -- 发射前确定子弹类型 以及失误情况
                local bluebullet = tsmath.random_match(self.prop.skill_lv >= 2 and 250 or 0)
                local greenbullet = tsmath.random_match(self.prop.skill_lv >= 3 and 250 or 0)
                local bulletlist = {330311,330312,330313}
                local typeid = (greenbullet and bulletlist[3]) or (bluebullet and bulletlist[2]) or bulletlist[1]
                self.prop.bullet_castid = typeid
                self.prop.bullet_active = typeid .. ""

                local failrate = self.prop.failnum <= 0 and tsmath.abs(self.prop.failnum) * self.prop.failrate or 0
                local iffail = tsmath.random_match(failrate)
                local target = self.action:range(self.static.id)[1]
                target = self.prop.same_target and self.prop.last_target or target
                target = iffail and self.owner or target
                self.prop.bullet_table.position = target and target.body.position or nil
                self.prop.target = {target}
                self.prop.failnum = self.prop.failnum - 1
                self.prop.iffail = iffail
            end},

            {"330311_cast", onfire = function(self)
                self.caller.skill:cast(self.prop.bullet_castid, self.owner, self.prop.target)
                if self.prop.target[1] == self.owner or self.prop.iffail then
                    -- local bufflist = self.static.start_buff
                    -- self.caller.buff:removelist(bufflist)
                    self.owner.attr:setbase("immune_suffer", -1)
                    self.action:message("3303_failed", self.static.id)  -- 发送失误消息
                    self.caller.buff:add(self.prop.stopid, self.owner)
                    self.action:run("stop")
                    -- self.action:stop()
                end
            end},

            {eventdef.skill_damage, onfire = function (self, damage_table)  -- 治疗子弹
                if not damage_table.source or damage_table.source.castid ~= 330313 then return end
                local heal_rate = 1500
                self.caller.hp:heal(tsmath.rate(damage_table.value, heal_rate), self.owner)
            end},

            {scriptevent.onend, onfire = function (self)
            end},
        },
    },
    bullet_single = {
        action = {
            default = {
                {trigger.time, {0},     caller.view.active, script.prop("bullet_active")},
                {trigger.time, {1000},  action.message, "330311_cast"},
                -- {trigger.time, {0},  action.cast, script.prop("bullet_castid")},
                {trigger.time, {2000},  caller.body.destroy},
            },
        },
        event = {
            {scriptevent.onstart, onfire = function (self)
            end },
        }
    },
}
conf.skill[330312] = conf.skill[330311]
conf.skill[330313] = conf.skill[330311]

-- 优先对未被标记月蚀的敌人使用，对其造成170%攻击力的伤害并标记为月蚀直至战斗结束。月蚀状态下，友军释放大招时，其在4秒内受到的伤害提高20%。使用时，有25%的几率失误，此时效果会作用包括自己在内的随机1个友军。
-- 2级：伤害提升至220%攻击力。
-- 3级：月蚀状态下，受到的魔法伤害提高30%。
-- 4级：伤害提升至270%攻击力。

conf.skill[330321] = {
        action = {
            default = {
                {trigger.time, {0},     action.active, "spell_02"},
                {trigger.time, {667},   action.message, "330321_cast"},
                {trigger.time, {900}},
            },
        },
        event = {
            {"330321_cast", onfire = function (self)
                local failrate = 500
                local iffail = tsmath.random_match(failrate)
                local targets = self.action:range()
                local exbuff = self.caller.buff:get_state("exbuff")
                
                if iffail then
                    local randomfriend = self.action:range(SKILL.RANGEID.FRIEND_RANDOM)
                    targets = randomfriend
                end
                
                self.prop.iffail = iffail
                self.caller.skill:cast(self.static.id, self.owner, targets)
            end},

            {scriptevent.onend, onfire  = function(self)
                if self.prop.iffail then
                    self.action:message("3303_failed", self.static.id)
                end
            end},
        },
}

conf.buff[3303210] = {
    event = {
        {scriptevent.onstart, onfire = function(self)
        end },

        {eventdef.slot_use, modifer  = eventmdf.excludeself, onfire = function(self, frombj, slotid)
            if frombj.prop.camp ~= self.owner.prop.camp and slotid == SKILL.SLOT.ULTIMATE then
                local bufflist = {330322} -- 易伤buff
                -- exbuff 失误时回血
                if self.action.fromobj.prop.camp == self.owner.prop.camp and self.action.fromobj.caller.buff:contains_state("exbuff") then
                    bufflist = {933035}
                end
                self.caller.buff:addlist(bufflist, self.action.fromobj)
            end
        end},

        {scriptevent.ontimer, time = {10000,1000,1}, onfire = function(self)   -- 3级：失误时，友军的日蚀标记缩短为10秒后消失
            if self.action.fromobj.prop.camp == self.owner.prop.camp and self.action.fromobj.caller.skill:getslotlevel(SKILL.SLOT.SKILL3) >= 3 then
                self.caller.buff:remove(330321)
            end
        end}
    }
}
conf.skill[330322] = conf.skill[330321]
conf.skill[330323] = conf.skill[330321]
conf.skill[330324] = conf.skill[330321]

-- 将最近的敌人传送至最远的敌人上空落下，落地时造成290%攻击力的范围伤害，并使范围内的敌人受到3秒眩晕。但有50%几率失误，优先选择一名最近的友军传送出去
-- 2级：友军落地时不会受到伤害和眩晕效果
-- 3级：眩晕时间延长至4秒

conf.skill[330331] = script.composite {
    main = {    
        action = {
            default = {
                {trigger.time, {0},     action.active, "spell_03" },
                {trigger.time, {1333},  caller.skill.cast, script.static("id"), script.prop("castobj"), script.prop("target")},
                -- {trigger.time, {3},  action.message, "330331_transport"},
                {trigger.time, {833} },  
            },                 
        }, 
        event = {
            {scriptevent.onstart, onfire = function(self)
                local failrate = 500    -- 失误率
                local iffail = tsmath.random_match(failrate)
                local rangeid = iffail and  SKILL.RANGEID.FRIENDS_CLOSE or SKILL.RANGEID.ENEMYS_CLOSE
                local targets = self.action:range(rangeid)
                local target = (targets[1] == self.owner and #targets > 1) and (tsvector.distance(targets[2].body.position, self.owner.body.position) <= 4000 and targets[2]) or targets[1]
                -- 如果最近的队友离自己超过4000距离，选择自己
                local position = #self.action:range() >= 1 and self.action:range()[1].body.position -- or target.body.position
                self.prop.castobj = self.owner
                self.prop.position = position
                self.prop.target = {target}
                self.prop.iffail = iffail
            end},

            {scriptevent.onend, onfire = function(self)
                if self.prop.iffail then
                    self.action:message("3303_failed", self.static.id)
                end
            end},
        },
    },
}

conf.buff[3303310] = script.composite { -- 传送
    main = {
        event = {
            {scriptevent.onstart, onfire = function(self)
                self.owner:sendmessage(eventdef.hide_view)
                local fromobj = self.action.fromobj
                local targets = fromobj.caller.skill:range(SKILL.RANGEID.ENEMYS_FARTHEST)
                local position = #targets >= 1 and targets[1].body.position or self.owner.body.position
                self.action:addchild({typeid = 999999, header = tsvector.new(0, 1000),position = position}, "bullet_effect")
                self.owner.body:setposition(position)
                self.caller.suffer:add(fromobj, fromobj, {6,{0,5000},{0,1500,200,1000},1000})
                ----------------------------------------------------------------------------
                -- 专武
                local exbuff= fromobj.caller.buff:get_state("exbuff")
                if exbuff and exbuff[SKILL.SLOT.SKILL4] and self.owner.prop.camp == fromobj.prop.camp then
                    self.caller.buff:add(933036, fromobj)
                end
            end},

            {scriptevent.ontimer, time = {1400,1,1}, onfire = function(self)
                self.owner:sendmessage(eventdef.show_view)
            end},

            {eventdef.suffer_move_end, onfire = function (self)
                local fromobj = self.action.fromobj
                local fromslotlevel = fromobj.caller.skill:getslotlevel(SKILL.SLOT.SKILL4)
                self.prop.castid = 330360 + fromslotlevel
                if self.owner.prop.camp == fromobj.prop.camp and fromslotlevel == 1 then    -- 低级会伤害队友
                    fromobj.caller.skill:cast(self.prop.castid, fromobj, {self.owner})
                end

                self.action:addchild({ typeid = 999999, position = self.owner.body.position}, "bullet_single")
                self.caller.buff:remove(330331)
            end }   
        }
    },
    bullet_effect = {
        action = {
            default = {
                {trigger.time, {100},   action.active, "330331"},
                {trigger.time, {2000},  caller.body.destroy},
            }
        },
    },
    bullet_single = {
        action = {
            default = {
                {trigger.time, {0},     action.active, "330332"},
                {trigger.time, {100},   action.cast, script.prop("castid")},
                {trigger.time, {500},   caller.body.destroy},
            }
        },
        event = {
            {scriptevent.onstart, onfire = function(self)
                self.owner.body.parent = self.action.fromobj  -- 转移父亲
            end}
        }
    }
}

conf.skill[330332] = conf.skill[330331]
conf.skill[330333] = conf.skill[330331]


-- 每次失误都会让鲁齐亚诺更渴望证明自己，增加n%的急速，最多叠加m层
-- 每次失误都会让鲁齐亚诺更渴望证明自己，增加n%的急速
-- 急速达到上限时，所有技能都会必定命中目标

conf.skill[330341] = {
    event = {
        {scriptevent.onstart, onfire = function(self)
            self.prop.bufflist = {330341,330342,330342,330343}
        end},

        {"3303_failed", onfire = function(self)
            if self.caller.buff:contains(self.prop.bufflist[#self.prop.bufflist]) then return end
            local skill_lv = self.prop.skill_lv
            local bufflist = self.prop.bufflist
            self.caller.buff:add(bufflist[skill_lv])
            if self.caller.buff:maxlevel(bufflist[skill_lv])then
                self.caller.buff:add(bufflist[#bufflist])
            end
        end}
    }

}

conf.skill[330342] = conf.skill[330341]
conf.skill[330343] = conf.skill[330341]

--===========================================================================
-- 专属武器模板
-- 日蚀失误后，下次释放该技能，对目标造成的伤害将转为对最虚弱的友军回复200%的生命值。
-- 【+10】星界传送失误后，下次释放该技能失误时，被传送的友军在落地后的6秒内免疫一切伤害。
-- 【+20】星火燎原失误后，立即回复300点怒气。
-- 【+30】星火燎原失误后，下次释放该技能时，本次的所有星火将会对同一目标使用。

conf.buff[9330310] = {
    event = {
        {scriptevent.onstart, onfire = function (self)
            --------------------------------------------------------- 按队列加入buff
            local exbufflist = {933034,933033,933032,933031}
            local bufflist =  {933035,933036,933037,933038}
            local exbuff = self.caller.buff:any(exbufflist)
            local exbufflv = exbuff and exbuff % 10 or 0

            self.prop.mpchange = ({0,0,300,300})[exbufflv]      -- 专武回能
            self.prop.exbufflv = exbufflv
            self.caller.buff:add_state("exbuff", {true, false, true, true})
            self.caller.buff:add_state("exbufflist", bufflist)
            self.caller.buff:add_state("exbufflv", exbufflv)
        end},

        {"3303_failed", onfire = function(self, skillid)
            -- 星火 skill2
            -- 月蚀： Skill3
            -- 传送 skill4
            local exbufflv = self.prop.exbufflv
            local slotid =  self.caller.skill:toslotid(skillid)
            if (slotid == SKILL.SLOT.ULTIMATE and exbufflv >= 4)
                or (slotid == SKILL.SLOT.SKILL4 and exbufflv >= 2) 
                or (slotid == SKILL.SLOT.SKILL3) then
                -- local exfail_table = self.caller.buff:get_state("exbuff")
                self.caller.buff:get_state("exbuff")[slotid] = true
                -- print(skillid, slotid, self.caller.buff:get_state("exbuff")[slotid])
            end

            if (slotid == SKILL.SLOT.ULTIMATE and exbufflv >= 3) then
                self.caller.mp:cast_change(self.prop.mpchange)
            end
        end},

        -- {eventdef.check_skill_damage, onfire = function(self, damage_table)
        --     if damage_table.source.slotid == SKILL.SLOT.SKILL3
        --     and self.caller.buff:get_state("exbuff")[damage_table.source.slotid] then

        --         self.caller.buff:get_state("exbuff")[damage_table.source.slotid] = false    -- 已使用
                -- local targets = self.action:range(SKILL.RANGEID.FRIEND_LOW_HP)
                -- local target = #targets > 0 and targets[1] or nil
                -- if target then
                --     target.caller.hp:heal(damage_table.value * 2, self.owner)
                -- end

        --     end
        -- end},
    }
}

conf.buff[9330320] = conf.buff[9330310]
conf.buff[9330330] = conf.buff[9330320]
conf.buff[9330340] = conf.buff[9330320]

conf.buff[9330350] = {
    event = {
        {scriptevent.ontimer, time = {0,1000,99}, onfire = function(self)
            local heal_rate = 50
            local heal_value = tsmath.rate(self.owner.attr.hp_max - self.owner.attr.hp, heal_rate)
            self.caller.hp:heal(heal_value, self.owner)
        end}
    }
}

return conf

