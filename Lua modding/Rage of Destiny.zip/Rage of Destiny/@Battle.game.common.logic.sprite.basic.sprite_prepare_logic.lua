local logic = { event = { sprite = {} } }

function logic:onenter(time)
    self.enter_time = self.time.time
    self.caller.view:start_active("appearance")
end

function logic:onupdate(time, tick)
    
    if self.time.time - self.enter_time >= self.prop.prepare_duration then
        return STATE_STATUS.OVER
    end

    return STATE_STATUS.SUSPEND
end

return logic