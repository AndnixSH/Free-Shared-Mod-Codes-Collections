local CampaignProxy = require "Modules.Campaign.CampaignProxy"
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"
local MainDef = require "Modules.Main.MainDef"
local NewbieManager = require "Modules.Newbie.NewbieManager"
local NewbieDef = require "Modules.Newbie.NewbieDef"
local NewbieWidget = require "Core.Implement.UI.Widgets.NewbieWidget"
local UISpineView = require "Core.Implement.UI.Class.UISpineView"

local CampaignGamePanel = CampaignGamePanel or BaseClass(GameObjFactor, TimerFactor, NewbieWidget)
function CampaignGamePanel:__init(go)
	self.go = go
	self:Load(go)	
end

function CampaignGamePanel:Load(obj)
	self.rect = self:GetComponent(obj, "RectTransform")
	self.rectPosition = self.rect.anchoredPosition

	self.battleBtn = self:GetChildComponent(obj, "CButton_begin", "CButton")
	self.battleBtn:AddClick(function ()
		self:OnTriggerClickBtn(self.battleBtn)
		self:OnClickBattle()
	end)
	
	self.battleBtnSprite = self:GetChildComponent(obj, "CButton_begin/sprite", "CSprite")
	self.battleBtnSprite.enabled = false
	
	-- self.battleBtnEffect = UIEffectItem.New("UI_Campaign_begin2", self.battleBtn.gameObject)
	self.effectRoot1 = self:GetChild(self.battleBtn, "figetEffect1")
	self.effectRoot2 = self:GetChild(self.battleBtn, "figetEffect2")

	self.battleLbl = self:GetChildComponent(self.battleBtn.gameObject, "label", "CLabel")

	self.rewardBtn = self:GetChildComponent(obj, "CButton_box", "CButton")
	self.rewardBtn:AddClick(function ()
		LuaLayout.Instance:CloseWidget(UIWidgetNameDef.NewbieSpecialWeakView)
		LuaLayout.Instance:OpenWidget(UIWidgetNameDef.BoxRewardView)
	end)
	self.fastrewardBtn = self:GetChildComponent(obj, "CButton_time", "CButton")
	self.fastrewardBtn:AddClick(function ()		
		self:OnClickFast()
	end)
	self.fastReddot = self:GetChild(obj, "CButton_time/CSprite_redpoint")
	
end
	
function CampaignGamePanel:GetBattleBtn()
	return self.battleBtn
end
	
--注册挑战首领和下一章按钮
function CampaignGamePanel:RegisterBattleBtn()

	local battle_newbieids = NewbieDef.MainViewTriggerBattle
	local battleBtn = self:GetBattleBtn()
	local mainlineid = RoleInfoModel.mainlineid
	for _newbieid, _step in pairs(battle_newbieids) do
		local cfg = NewbieManager.Instance:GetNewbieStepConfig(_newbieid, _step) --挑战首领1-1
		-- if cfg and cfg.parama and cfg.parama.mainlineid == mainlineid then
			--print("_newbieid, _step===", _newbieid, _step)
			self:RegisterButton(self.battleBtn, _newbieid, _step)
		-- end
	end

	--下一章
	-- local NewbieProxy = require "Modules.Newbie.NewbieProxy"
	-- local nextChapterId = NewbieProxy.Instance:GetNewbiePassToMainlineid()
	-- local _newbie_id, _step = NewbieProxy.Instance:GetNewbieIdAndStep(NewbieDef.MainViewNextChapter)
	-- local cfg = NewbieManager.Instance:GetNewbieStepConfig(_newbie_id, _step)
	-- self:RegisterButton(self.battleBtn, _newbie_id, _step)
end

function CampaignGamePanel:RegisterCampaignGamePanelBtn()
	local battleBtn = self:GetBattleBtn()
	local mainlineid = RoleInfoModel.mainlineid
	
	--挑战首领
	self:RegisterBattleBtn()

	-- 获得新英雄
	local _newbie_id, _step, _roleid, rank, level = self:CheckExistHeroRoleId()
	if _newbie_id and _step and _roleid then
		print("CheckExistHeroRoleId===", _newbie_id, _step, _roleid)
		self:RegisterNewHero(_newbie_id, _step, _roleid, rank, level)
	end

	--对话dialog
	local newbie_id, step = self:CheckNormalNpcMainDialog()
	if newbie_id and step then
		self:RegisterNpcDialog(newbie_id, step)
	end 

end

function CampaignGamePanel:CheckExistHeroRoleId()
	local HeroProxy = require "Modules.Hero.HeroProxy"
	local newbieid, step, _roleid, rank, level

	local bFind = false
	for _newbie_id, _step in pairs(NewbieDef.NewbieHeroTrigger) do
		local bcomplete = NewbieManager.Instance:NewbieIsComplete(_newbie_id)
		if not bcomplete then
			local cfg1 = NewbieManager.Instance:GetNewbieStepConfig(_newbie_id, _step)
			if cfg1 then
				local herolist = HeroProxy.Instance:GetHeroDataList()
				for i,info in ipairs(herolist) do
					if info.roleid == cfg1.parama.roleid then
						newbieid, step = _newbie_id, _step
						_roleid = cfg1.parama.roleid
						rank = info.rank
						level = info.level
						break
					end
				end
			end
		end
		if newbieid then
			break
		end
	end
	return newbieid, step, _roleid, rank, level
end

function CampaignGamePanel:CheckNormalNpcMainDialog()
	local newbieid, step
	local main_dialogs = NewbieDef.DialogTrigger.Main
	local mainlineid = RoleInfoModel.mainlineid
	for _newbie_id, _step in pairs(main_dialogs) do
		local cfg = NewbieManager.Instance:GetNewbieStepConfig(_newbie_id, _step)
		if cfg and cfg[1] then
			if cfg[1].parama.mainlineid == mainlineid then
				newbieid, step = _newbie_id, _step
				break
			end
		end
	end

	if not newbieid or not step then
		local NewbieProxy = require "Modules.Newbie.NewbieProxy"
		local nextChapterId = NewbieProxy.Instance:GetNewbiePassToMainlineid()
		local _newbie_id, _step = NewbieProxy.Instance:GetNewbieIdAndStep(NewbieDef.MainViewNextDialog)
		local cfg = NewbieManager.Instance:GetNewbieStepConfig(_newbie_id, _step)
		
		if cfg and cfg[1] and cfg[1].parama.mainlineid == nextChapterId then
			newbieid, step = _newbie_id, _step
		end
	end

	return newbieid, step
end
	
function CampaignGamePanel:RegisterNewbieData()
	self:RegisterCampaignGamePanelBtn()

end

function CampaignGamePanel:OpenSpecialNewbie()
	local NewbieProxy = require "Modules.Newbie.NewbieProxy"
	NewbieProxy.Instance:StartSpecialNewbie(true, self.rewardBtn, NewbieDef.NewbieConst.MainlineFailBack, 1)
end

--如果返回领地界面，需要开始挑战首领 引导的话，先关闭引导
function CampaignGamePanel:CheckCloseWeakGuildView(active)

	if active == false then
	else
		self:RegisterNewbieData()
	end
end

function CampaignGamePanel:Open()
	self.battleBtnEffect = UISpineView.New(self.battleBtnSprite.gameObject)
	self.battleBtnEffect:SetModel("UI_Campaign_begin", nil, nil,
		function ()
			local effect_obj = self:GetChildByIndex(self.battleBtnSprite.gameObject, 0)
			if effect_obj then
				if not self:GetComponent(effect_obj, "CEffect") then
					self:AddComponent(effect_obj, "CEffect")
				end
			end
		end)
	
	self:ShowAppRating()
	--self:ShowAgreenment()
	self:StartOpenTween()	
	-- self.battleBtnEffect:Open()
	self:UpdateInfo()

	self:ClearTimer()
	self.newbietimer = self:AddTimer(function()
		if self.go.activeSelf == true then
			self:RegisterNewbieData()
		end
	end, 0.4, 1)

	self:OpenSpecialNewbie()
end

function CampaignGamePanel:ShowAppRating()
	--在10连抽引导后打一关，不是出於引导状态时弹出
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	local NewbieProxy = require "Modules.Newbie.NewbieProxy"
	local newbie_id, step = NewbieProxy.Instance:GetNewbieIdAndStep(NewbieDef.TenDrawCard)
	local bComplete = NewbieProxy.Instance:NewbieIsComplete(newbie_id)
	local cur_mainline = RoleInfoModel.mainlineid

	local IGGSdkDef = require "Modules.IGGSdk.IGGSdkDef"
	if cur_mainline > IGGSdkDef.ShowRatingViewMainlineID then
        local RoleInfoProxy = require "Modules.RoleInfo.RoleInfoProxy"
        local RoleInfoDef = require "Modules.RoleInfo.RoleInfoDef"
		--RoleInfoProxy.Instance:Send10028(RoleInfoDef.Sop_Award_Type.Rating_Award)
		RoleInfoProxy.Instance:CheckShowRatingView()
	end
end

--弹协议，完成某个引导的时候 如果不是在主场景，回到主场景才调用
function CampaignGamePanel:ShowAgreenment()
	--local NewbieProxy = require "Modules.Newbie.NewbieProxy"
	--local status = NewbieProxy.Instance:GetNewbieFinishAgreement()
	--if status then
	--	NewbieProxy.Instance:SetNewbieFinishAgreement(false)
	--	local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
	--	IGGSdkProxy.Instance:InformKindly()
	--end
end

function CampaignGamePanel:ClearTimer()
	if self.newbietimer then
		self:RemoveTimer(self.newbietimer)
		self.newbietimer = nil
	end
end


function CampaignGamePanel:SetActive(active)
	self.go:SetActive(active)
	if active then
		self:CheckShowNextChapterGuideEffect()
	end
	self:CheckCloseWeakGuildView(active)
end

function CampaignGamePanel:IsActive()
	if self.go then
		return self.go.activeSelf
	end
end

function CampaignGamePanel:Close()
	if self.battleBtnEffect then
		self.battleBtnEffect:Destroy()
		self.battleBtnEffect = nil
	end
	if self.opensequence then
		self.opensequence:Kill()
		self.opensequence = nil
	end	

	-- self.battleBtnEffect:Close()
	self:ClearTimer()
	self:UnRegisterNewbie()
end	

function CampaignGamePanel:Destroy()
	-- if self.battleBtnEffect then
		-- self.battleBtnEffect:Destroy()
		-- self.battleBtnEffect = nil
	-- end	
	self:ClearTimer()
	self:UnRegisterNewbie()
end

function CampaignGamePanel:StartOpenTween()	
	self.rect.anchoredPosition = Vector2.New(self.rectPosition.x, self.rectPosition.y - 100)
	local tween1 = self.rect:DOAnchorPosY(self.rectPosition.y + 10, 0.2)
	local tween2 = self.rect:DOAnchorPosY(self.rectPosition.y, 0.2)

	local sequence = DOTween.Sequence()
	sequence:Append(tween1)
	sequence:Append(tween2)
	self.opensequence = sequence
end

function CampaignGamePanel:UpdateInfo()
	self.mainlinecfg = CampaignProxy.Instance:GetMainLineCfgById(RoleInfoModel.mainlineid)
	self:CheckShowNextChapterGuideEffect()
end

function CampaignGamePanel:ShowRedDot(redtype, rednum)
	if redtype == MainDef.MainRedDotType.FreeFastReward then
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.QuickHangUp, false)
		if bopen then
			self.fastReddot:SetActive(rednum > 0)
		end
	end	
end

--onclick
function CampaignGamePanel:OnClickBattle()
	local curmax_chapter = CampaignProxy.Instance:GetMaxChapter()
	local ModuleManager = require "Common.Mgr.UI.ModuleManager"
	local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
	local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.MainLine)
	if bopen then

		local mainlinecfg = self.mainlinecfg
		if CampaignProxy.Instance:IsPassToNextChapter() then
			if mainlinecfg.chapter >= curmax_chapter then
				GameLogicTools.ShowMsgTips("Common_1002")
				return
			end
			local SceneManager = require "Modules.Scene.SceneManager"
			local SceneDef = require "Modules.Scene.SceneDef"
			SceneManager.Instance:EnterScene(SceneDef.SceneType.WorldMap)
			self.battleresult=false
		else
			if mainlinecfg then
				if mainlinecfg.chapter >= curmax_chapter + 1 then
					GameLogicTools.ShowMsgTips("Common_1002")
					return
				end
				if mainlinecfg.chapter == 1 then
					if math.fmod(mainlinecfg.section, 3) == 0 then
						UIOperateManager.Instance:OpenWidget(AppFacade.Campaign, 1, RoleInfoModel.mainlineid)
					else
						local enemyid = self.mainlinecfg.enemy_id
						local enemylist = GameLogicTools.GetEnemyList(enemyid)
						UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 1, ACTIVITYID.MAINLINE, enemylist, enemyid)
					end
				else
					if math.fmod(mainlinecfg.section, 4) == 0 then
						UIOperateManager.Instance:OpenWidget(AppFacade.Campaign, 1, RoleInfoModel.mainlineid)
					else
						local enemyid = self.mainlinecfg.enemy_id
						local enemylist = GameLogicTools.GetEnemyList(enemyid)
						UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 1, ACTIVITYID.MAINLINE, enemylist, enemyid)
					end
				end
			else
				GameLogicTools.ShowMsgTips("Common_1002")
			end	
		end
	end
	self:CloseNextChapterGuideEffect()
end

function CampaignGamePanel:OnClickFast()
	local ModuleManager = require "Common.Mgr.UI.ModuleManager"
	local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
	local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.QuickHangUp)
	if bopen then
		LuaLayout.Instance:OpenWidget(UIWidgetNameDef.FastRewardView)
	end
end

function CampaignGamePanel:CheckShowNextChapterGuideEffect()
	if  CampaignProxy.Instance:IsPassToNextChapter() then
		self.battleLbl.text = self:GetWord("CampaignView_1002")
		local mainlineid = CampaignProxy.Instance:GetPassMainlineid()
		local cfg = CampaignProxy.Instance:GetMainLineCfgById(mainlineid)
		local chapters = {
			[2] = true,
			[3] = true,
			--[4] = true,
			--[5] = true,
		}
		if chapters[cfg.chapter] then
			self:DoShowNextChapterGuideEffect()
		else
			self:CloseNextChapterGuideEffect()
		end

	else
		self.battleLbl.text = self:GetWord("CampaignView_1001")
		self:CloseNextChapterGuideEffect()
	end
end

function CampaignGamePanel:DoShowNextChapterGuideEffect()
	self:CloseNextChapterGuideEffect()
	
	self.figet_effect1 = UIEffectItem.New("UI_Common_FingerClick2_m", self.effectRoot1)
	self.figet_effect1:SetScale(2,2,2)

	self.figer_effect2 = UIEffectItem.New("UI_Common_FingerClick1_m", self.effectRoot2)
	self.figer_effect2:SetScale(2,2,2)

	self.figet_effect1:Open()
	local depth1 = self:GetNextDepth()
	local depth2 = self:GetNextDepth()
	self:SetDepth(self.effectRoot1, depth1)
	self:SetDepth(self.effectRoot2, depth2)
	self.figer_effect2:Open()
end

function CampaignGamePanel:CloseNextChapterGuideEffect()
	if self.figet_effect1 then
		self.figet_effect1:Destroy()
		self.figet_effect1 = nil
	end
	if self.figer_effect2 then
		self.figer_effect2:Destroy()
		self.figer_effect2 = nil
	end
end

return CampaignGamePanel