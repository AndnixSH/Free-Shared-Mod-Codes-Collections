ConfigManager.InitConfig('data_mall_monthly', {
[1]={id=1,item_id=1,grid_type=1,gift_ids={1411.0}, buy_limit={{0,20,1},}, },
[2]={id=2,item_id=2,grid_type=1,gift_ids={1421.0}, buy_limit={{0,5,1},{6,8,2},{9,10,3},{11,20,4},}, },
[3]={id=3,item_id=3,grid_type=1,gift_ids={1431.0}, buy_limit={{0,5,1},{6,8,2},{9,10,3},{11,20,4},}, },
[4]={id=4,item_id=4,conditions={{2,4.99,}}, grid_type=1,gift_ids={1441.0}, buy_limit={{0,5,1},{6,8,2},{9,10,3},{11,20,4},}, },
[5]={id=5,item_id=5,conditions={{2,4.99,}}, grid_type=1,gift_ids={1451.0}, buy_limit={{0,5,1},{6,8,2},{9,10,3},{11,20,4},}, },
[6]={id=6,item_id=6,conditions={{2,4.99,}}, grid_type=1,gift_ids={1461.0}, buy_limit={{0,5,1},{6,8,2},{9,10,3},{11,20,4},}, },
[7]={id=7,item_id=7,conditions={{2,4.99,}}, grid_type=1,gift_ids={1471.0}, buy_limit={{0,5,1},{6,8,2},{9,10,3},{11,20,4},}, },
[8]={id=8,item_id=8,conditions={{2,4.99,}}, grid_type=1,gift_ids={1481.0}, buy_limit={{0,5,1},{6,8,2},{9,10,3},{11,20,4},}, },
[9]={id=9,item_id=9,conditions={{2,4.99,}}, grid_type=1,gift_ids={1491.0}, buy_limit={{0,5,1},{6,8,2},{9,10,3},{11,20,4},}, },
[10]={id=10,item_id=10,conditions={{2,4.99,}}, grid_type=1,gift_ids={1501.0}, buy_limit={{0,5,1},{6,8,2},{9,10,3},{11,20,4},}, },
[11]={id=11,item_id=11,conditions={{2,4.99,}}, grid_type=1,gift_ids={1511.0}, buy_limit={{0,5,1},{6,8,2},{9,10,3},{11,20,4},}, },
[12]={id=12,item_id=12,conditions={{1,353,},{2,4.99,}}, grid_type=1,gift_ids={1521.0}, buy_limit={{0,5,1},{6,8,2},{9,10,3},{11,20,4},}, },
})