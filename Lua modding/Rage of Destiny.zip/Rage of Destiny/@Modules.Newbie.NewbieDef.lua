local NewbieDef = {}

NewbieDef.NotifyDef =
{
	Newbie_Notify = "Newbie_Notify",
	Newbie_State_Notify = "Newbie_State_Notify",
	MazeClickScreenNotify = "MazeClickScreenNotify",
	NormalNpcDialogCloseNotify = "NormalNpcDialogCloseNotify",
}

NewbieDef.NewbieType =
{	
	None = 0,  --程序控制（如抽卡界面，等抽卡流程跑完再出发下一步）
	Forceguide = 1,  --强引导
	Weakguide = 2,   --弱引导
	NewHero = 3,     --获得新英雄
	Dialog = 4,      --对话框
}

NewbieDef.NewbieConst =
{
	FristEnter = 10001, --第一个引导id
	--Battle
	ReleaseSkill = 90001,  --释放大招

	--特殊任務id 前两章失败后回到主界面就触发
	--30001,  特殊引導寫死處理
	MainlineFailBack = 30001,
	CardPordSpecial = 20006,--心愿单引导

	StarGazeOpen = 20005, --占星开启引导

	NotNewbie = 99999,  --跳过引导id
}


--主界面需要触发的引导 战斗按钮
NewbieDef.MainViewTriggerBattle = {
	[10001] = 2, --10001引导的第2步
	[10003] = 2, --
	[10004] = 2, --
	[10007] = 1, --
	[10008] = 1, --
	[10011] = 2, --
	[10014] = 1, --
	-- [10018] = 7,
	[10030] = 2,
	[10032] = 1, --
}

----下一章节出發
NewbieDef.MainViewNextChapter = {
	-- [10012] = 2, --下一章节
}
----下一章节dialog
NewbieDef.MainViewNextDialog = {
	[10012] = 1,
}

--主界面需要注册获得新英雄界面弹出
NewbieDef.NewbieHeroTrigger = {
	[10002] = 1, --杰西卡
	[10005] = 1, --法林
	[10010] = 1, --罗珊
}

NewbieDef.NewbieDialogKey = 
{
	Dialog_10001_1 = 10001,
	Dialog_10003_1 = 10003,
	Dialog_10004_1 = 10004,
	Dialog_10005_2 = 10005,
	Dialog_10006_1 = 10006,
	Dialog_10011_1 = 10011,
	-- Dialog_10012_1 = 10012,
	Dialog_10014_2 = 10014,
	Dialog_10015_2 = 10015,
	Dialog_10020_3 = 10020,
	Dialog_10021_3 = 10021,
	Dialog_10026_3 = 10026,
	-- Dialog_30001_4 = 30001,
	Dialog_10023_12 = 10023,

	-- Dialog_10018_8 = 10018,

	Dialog_10029_1 = 10029,
	Dialog_10030_1 = 10030,


}
--触发对话框引导
NewbieDef.DialogTrigger = {
	--主界面触发
	Main = {
		[NewbieDef.NewbieDialogKey.Dialog_10001_1] = 1,
		[NewbieDef.NewbieDialogKey.Dialog_10003_1] = 1,
		[NewbieDef.NewbieDialogKey.Dialog_10004_1] = 1,
		[NewbieDef.NewbieDialogKey.Dialog_10006_1] = 1,
		[NewbieDef.NewbieDialogKey.Dialog_10011_1] = 1,
		[NewbieDef.NewbieDialogKey.Dialog_10030_1] = 1,
		-- [NewbieDef.NewbieDialogKey.Dialog_10012_1] = 1,
	},
	--领地
	Territory = {
	},
	--远征
	Field = {
		
		[NewbieDef.NewbieDialogKey.Dialog_10015_2] = 2,
	},

	--上阵界面
	BattleNetSelectView = {
		[NewbieDef.NewbieDialogKey.Dialog_10014_2] = 2,
		-- [NewbieDef.NewbieDialogKey.Dialog_10018_8] = 8,
	},

	ApplyGuildView = {
		[NewbieDef.NewbieDialogKey.Dialog_10020_3] = 3,
	},
	RelationMenuView = {
		[NewbieDef.NewbieDialogKey.Dialog_10021_3] = 3,
	},
	TowerEntranceView = {
		[NewbieDef.NewbieDialogKey.Dialog_10026_3] = 3,
	},

	--英雄列表
	HeroList = {
		-- [NewbieDef.NewbieDialogKey.Dialog_30001_4] = 4,
	},
	
	--对话引导触发系统界面
	SupplyDepotView= {
		[NewbieDef.NewbieDialogKey.Dialog_10023_12] = 12,
	},

}

--主线 开始战斗 按钮引导
NewbieDef.MainlineBattleBtn = {
	-- [10001] = 5,
	[10001] = 5,
	[10003] = 5,
	[10007] = 3,
	[10011] = 4,
	[10030] = 5,
	[10004] = 4,
	[10008] = 2,
	[10032] = 3, 

	
}

--上阵英雄引导
NewbieDef.SelectHeroTrigger = {
	[10001] = {3, 4}, --上阵1103鲍德维克 3103兰黛
	[10003] = {3}, --上阵英雄1303杰西卡
	[10007] = {2},  --上阵法林
	[10011] = {3},  --上阵矮人射手
	[10030] = {4},  --上阵碧伦丝
}

--下阵英雄引导
NewbieDef.SelectFormationHeroTrigger = {
    [10030] = 3,  --下阵兰黛

}


--英雄站位引导
NewbieDef.SelectHeroPosTrigger = {
	[10003] = 4,
}

--自动释放技能
NewbieDef.AutoSkillTrigger = {
	[10003] = 6, 
}

--双倍速
NewbieDef.DoubleFrameTrigger = {
	[10007] = 4, 
}

--自动推图
NewbieDef.AutoBattleTrigger = {
	[10009] = 1, 
}

--挑战boss弹窗
NewbieDef.BossInfoTrigger = {
	[10004] = 3,
	[10032] = 2,
}

--领地建筑引导,第一个参数是步骤 第二个参数是建筑索引
NewbieDef.TerritoryView = {
	[10013] = {2, 2}, --单抽传送门 2
	[10018] = {2, 2},--10抽传送门 2
	[10020] = {2, 4}, --公会 4
	[10021] = {2, 5}, --羁绊树 5
	[10028] = {1, 7}, --光明圣堂
}

--远征建筑引导
NewbieDef.FieldView = {
	[10015] = {3, 4},  --远征迷宫 
	[10019] = {2, 5},  --赎罪之塔
	[10022] = {2, 1}, --竞技场
	[10023] = {2, 2}, --贸易航线
	[10024] = {2, 6}, --剧情副本
	[10025] = {2, 1}, --高阶竞技场
	[10026] = {2, 5}, --种族赎罪之塔
}

--英雄展示列表icon
NewbieDef.HeroListIcon = {
	[10006] = {3},--点击英雄展示列表英雄图标 点击1201矮人枪手头像
	[10027] = {2},--点击英雄展示列表英雄图标 点击杰西卡头像
}

--英雄升级引导
NewbieDef.HeroUpLevelBtn = {
	[10006] = 4,--引导升级
}

--英雄装备页签
NewbieDef.HeroEquipToggle = {
	-- [10006] = 5,--引导装备页签
	[10027] = 3,--引导装备页签
}

--英雄装备一健穿戴
NewbieDef.HeroWearEquip = {
	-- [10006] = 6,
	[10027] = 4,
}

--全屏界面 关闭按钮
NewbieDef.FullScreenClose = {
	-- [10006] = {7, 8},
	[10006] = {5, 6},
	[10013] = {5},
	[10017] = {3},
	[10018] = {5},
	[10027] = {5, 6},
	[10028] = {7},
}

--主界面地下按钮 （步骤，按钮索引）
NewbieDef.CampaignBottom = {
	[10013] = {{1, 1}, {6, 4}},--领地, 战役
	[10015] = {{1, 2}},--远征
	[10018] = {{1, 1}},--领地, 战役
	[10019] = {{1, 2}},--远征
	[10020] = {{1, 1}},--领地
	[10021] = {{1, 1}},--领地
	[10022] = {{1, 2}},--远征
	[10023] = {{1, 2}},--远征
	[10024] = {{1, 2}},--远征
	[10025] = {{1, 2}},--远征
	[10026] = {{1, 2}},--远征
	[10006] = {{2, 3}},--英雄
	[10027] = {{1, 3}},--英雄

	[10012] = {{2, 1}},--领地
	[10028] = {{8,4}},-- 战役
	-- [30001] = {{3, 3}},--英雄
}

-------------------抽卡
NewbieDef.OneDrawCard = {
	[10013] = 3,--单抽
}

NewbieDef.TenDrawCard = {
	[10018] = 3,--10抽
}

--阵容克制关系
NewbieDef.CampRelation = {
	[10016] = 1,
}

--活动按钮
NewbieDef.ActivityBtn = 
{
	[10017] = 1,
}

--活动奖励按钮
NewbieDef.ActivityAwardBtn = 
{
	[10017] = {{2, 1}},--活动章节第一个奖励,活动章节第二个奖励  第二个值代表clist索引
}

--赎罪之塔普通塔 废弃，现在种族卡没开，不会打开enter界面
NewbieDef.NormalTower = {
	[10019] = 3,
}

--赎罪之塔普通塔挑战按钮
NewbieDef.NormalTowerBtn = {
	[10019] = 3,
}


--选着普通竞技场
NewbieDef.NormalArena = {
	[10022] = 3,
}
--普通竞技场 战斗btn
NewbieDef.NormalArenaBtn = {
	[10022] = 4,
}

--选着高阶竞技场
NewbieDef.ProArena = {
	[10025] = 3,
}
--高阶竞技场 战斗btn
NewbieDef.ProArenaBtn = {
	[10025] = 4,
}

--贸易航线SUPPLY_DEPOT
NewbieDef.SupplyDepot3 = {
	[10023] = 3,--远征界面贸易航线第一个
}
--贸易航线SUPPLY_DEPOT
NewbieDef.SupplyDepot4 = {
	[10023] = 4,--贸易航线 点加号 派遣
}
--贸易航线SUPPLY_DEPOT
NewbieDef.SupplyDepot5 = {
	[10023] = 5,--贸易航线 派遣第一个英雄
}
--贸易航线SUPPLY_DEPOT
NewbieDef.SupplyDepot6 = {
	[10023] = 6,--贸易航线 点击派遣按钮
}
--贸易航线SUPPLY_DEPOTf
NewbieDef.SupplyDepot7 = {
	[10023] = 7,--贸易航线 点击领取奖励
}

--贸易航线SUPPLY_DEPOTf
NewbieDef.SupplyDepot8 = {
	[10023] = 8,--贸易航线 领取奖励后会弹获得奖励界面，空引导，领取奖励界面关闭后再触发下一步
}

--贸易航线SUPPLY_DEPOTf
NewbieDef.SupplyDepot9 = {
	[10023] = 9,--贸易航线 点击升级
}

--贸易航线SUPPLY_DEPOTf
NewbieDef.SupplyDepot10 = {
	[10023] = 10,-- 贸易航线 升级界面 点击升级
}

--贸易航线SUPPLY_DEPOTf
NewbieDef.SupplyDepot11 = {
	[10023] = 11,--贸易航线 升级后会打开等级提升界面 ，空引导，等级提升界面关闭后再触发下一步
}

--贸易航线SUPPLY_DEPOTf
NewbieDef.SupplyDepot12 = {
	[10023] = 12,--贸易航线 对话
}

--抽卡空引导步骤
NewbieDef.CardEmptyStep = {
	[10013] = {4},
	[10018] = {4},
}

--贸易航线空引导步骤
NewbieDef.SupplyDepot8Empty = {
	[10023] = {8},
}

--贸易航线空引导步骤
NewbieDef.SupplyDepot11Empty = {
	[10023] = {11},
}


--剧情副本 开始探索btn
NewbieDef.StoryDungen = {
	[10024] = 3,--开始探索btn
}

--大圣堂英雄选择
NewbieDef.TempleHeroSelect = {
	[10028] = {2, 3, 4},
}

--大圣堂英雄进阶btn
NewbieDef.TempleUpGrade = {
	[10028] = {5},
}

--大圣堂英雄进阶成功后空引导
NewbieDef.TempleSuccessViewEmpty = {
	[10028] = {6},
}
-- -- 特殊引导1 前两章失败后回到主界面触发
-- NewbieDef.SpecialNewbie1 = {
-- 	[30001] = 1, --自动挂机按钮
-- }
-- NewbieDef.SpecialNewbie2 = {
-- 	[30001] = 2, --自动挂机领取奖励按钮
-- }

--在主界面会自动判断触发
--引导id = {已触发的引导id}
NewbieDef.TriggerDef =
{
	[10001] = {},       -- 基础操作引导
	[90001] = {10001},  -- 引导释放大招
	[10002] = {90001},  -- 将获得杰西卡
	[10003] = {10002},  -- 引导杰西卡上阵
	[10004] = {10003},  -- 引导1-3挑战
	[10005] = {10004},  -- 获得法林
	[10006] = {10005},  --引导杰西卡升级
	[10007] = {10006},  --引导法林上阵
	[10027] = {10007},  --引导杰西卡穿戴装备
	[10008] = {10027},  --引导挑战1-5

	[10032] = {10008},  -- 引导挑战 1-6
	[10010] = {10032},  -- 送罗珊
	[10011] = {10010},  -- 上阵罗珊

	
    
	[10009] = {10011},  -- 自动推图

	[10013] = {10009},  -- 引导单抽

	
	[10030] = {10013},  -- 引导上阵单抽紫色英雄
	[10017] = {10030},  -- 引导冲关奖励
	[10018] = {10017},	-- 10连抽

    [10028] = {10018}, --  升阶引导
	[10014] = {10028}, --  2-2弹出聊天对话
	[10015] = {10014}, --  引导点击巨龙巢穴
	[10016] = {10015}, --  英雄上阵界面 阵容克制
	
	[10019] = {10016}, --  引导普通种族塔
	[10020] = {10019}, --  引导公会
	[10021] = {10020}, --  引导羁绊树
	[10022] = {10021}, --  普通竞技场
	[10023] = {10022}, --  贸易航线
	[10024] = {10023}, --  劇情副本
	[10025] = {10024}, --  高阶竞技场
	[10026] = {10025}, --  种族塔

}

NewbieDef.MaskNewbieId = 
{
	[10001] = 1, --引导基础操作
	[10002] = 1, --获得杰西卡
	[10003] = 1, --引导杰西卡上阵
	[10004] = 1, --引导挑战首领
	[10005] = 1, --获得法林
	[10006] = 1, --引导法林升级 穿装备
	[10007] = 1, --引导法林上阵
	[10027] = 1, --引导杰西卡穿装备
	[10008] = 1, --引导挑战首领
	[10012] = 1, --引导进行下一章节2-1
	[10013] = 1, --1-6引导单抽
	-- [10014] = 1, --抽卡结束后，领地界面引导返回主界面
	[10015] = 1, -- 引导点击巨龙巢穴
	[10017] = 1, --引导点击活动界面按钮
	[10018] = 1, --引导进行10连抽

}

--在挑战首领按钮显示下一章的时候触发的步骤
NewbieDef.NextChaptherNewbie = {
	[10013] = {1},
}

--npc对话框特殊引导(某些系统第一次进入弹) 引导从20001开始
NewbieDef.NpcDialogDef = 
{
	Temple = 20001, --光明圣堂
	HeroReset = 20002, --英雄重置
	HeroRetire = 20003, --英雄遣散
	Crystal = 20004, --共鸣水晶
	StarGaze = 20005, --占星
}

NewbieDef.State = 
{
	Accept = 0,
	Complete = 1,
}

NewbieDef.NewbieDepths = 
{
	NewbieMask = 9900,
	NewbieView = 9950,
	NewbieBtn = 9990,
	NewbieEffect = 9991,
}

--主线通关关卡后只能返回主界面进行引导, 在这里配置主线关卡id
--也需要考虑一些特殊的引导，比如前两章失败后进行的引导
NewbieDef.NewbieMainlineId = {
	[1] = 1,
	[2] = 1,
	[3] = 1,
	[4] = 1,
	[5] = 1,
	[6] = 1,
	[7] = 1,
	[13] = 1,
	[14] = 1,
	[17] = 1,
	[20] = 1,
	[25] = 1,
	[29] = 1,
	[31] = 1,
	[33] = 1,
	[37] = 1,
	[41] = 1,
	[53] = 1,
	[157] = 1,
	[293] = 1,
	[513] = 1,
}


NewbieDef.FinishNewbieKey = "DFinishNewbieKey"

return NewbieDef

