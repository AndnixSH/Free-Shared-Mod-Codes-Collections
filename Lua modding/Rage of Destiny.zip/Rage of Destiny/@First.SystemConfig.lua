local cs_coroutine = require "First.Util.cs_coroutine"
local UnityWebRequest = CS.UnityEngine.Networking.UnityWebRequest
local Application = CS.UnityEngine.Application
local RuntimePlatform = CS.UnityEngine.RuntimePlatform
local rapidjson = require 'rapidjson'
local FileUtils = CS.LJY.NX.FileUtils
local Uri = CS.System.Uri

SystemConfig = {}
SystemConfig.AppWeb = {
    Lan = 1, --内网
    Wlan = 2, --外网
}
SystemConfig.AppType = {
    Debug = 1,
    Release = 2,
}

SystemConfig.IsOpen12Language = true --true,开启12国语言，屏蔽12国语言
SystemConfig.ServerTime = 0
SystemConfig.BundleURL = "https://static-rod.igg.com/"
--SystemConfig.IsAuditVersion = false  --是否提审

local isEditor = Application.isEditor

local function _GetPlatForm()
    if Application.platform == RuntimePlatform.Android or isEditor then
        return "android"
    elseif Application.platform == RuntimePlatform.IPhonePlayer then
        return "ios"
    else
        return "pc"
    end
end

function SystemConfig.Init()
    local extSyscfgPath = Application.dataPath .. '/../extcfg.json'
    if FileUtils.FileIsExists(extSyscfgPath) then
        local text = FileUtils.ReadAllText(extSyscfgPath)
        SystemConfig.InitExtSyscfg(text)
    else
        SystemConfig.InitExtSyscfg()
    end

    local syscfgPath = Uri(Application.streamingAssetsPath .. '/syscfg.json')
    --print("--syscfgPath", syscfgPath)
    return cs_coroutine.start(
            function()
                local www = UnityWebRequest.Get(syscfgPath)

                coroutine.yield(www:SendWebRequest())

                if www.isNetworkError or www.isHttpError then
                    error(string.format("get error: %s ---- url=%s", www.error, syscfgPath))
                else
                    SystemConfig.InitSystemCfg(www.downloadHandler.text)
                end
                www:Dispose()
            end)
end

function SystemConfig.InitExtSyscfg(text)
    if text then
        local data = rapidjson.decode(text)
        SystemConfig.OutsideResPath = data.ResPath and string.format("%s/../%s/%s/resoutput", Application.dataPath, data.ResPath, _GetPlatForm()) or ""
        SystemConfig.IsResFromAB = (data.ResFromAB == "true")
        SystemConfig.IsLuaFromAb = (data.LuaFromAB == "true")
    else
        SystemConfig.OutsideResPath = string.format("%s/res", Application.persistentDataPath)
        SystemConfig.IsResFromAB = false
        SystemConfig.IsLuaFromAb = false
    end
end

function SystemConfig.InitSystemCfg(text)
    local data = rapidjson.decode(text)
    SystemConfig.Router = data.Router or ""
    SystemConfig.AuditRouter = data.AuditRouter or "https://single-ios-rod.igg.com/" -- iOS审核服router
    SystemConfig.DownPath = string.format("%s/patch", Application.persistentDataPath)
    SystemConfig.IsDebug = (data.DebugMode == "true")
    SystemConfig.ResVersion = Application.version
    SystemConfig.CurAppWeb = data.AppWeb and tonumber(data.AppWeb) or 1
    SystemConfig.CurAppType = data.AppType and tonumber(data.AppType) or 1
    if isEditor then
        SystemConfig.AppUpdate = false
    else
        SystemConfig.AppUpdate = (data.AppUpdate == "true")
    end
    SystemConfig.IsSop = (data.Sop == "true")
    SystemConfig.UpdateUrl = data.UpdateUrl or "http://192.168.0.175/static/mx_debug/"
    SystemConfig.AgentName = data.AgentName or "debug"
    SystemConfig.AgentID = data.AgentID and tonumber(data.AgentID) or 1
    SystemConfig.AgentPackageID = data.AgentPackageID and tonumber(data.AgentPackageID) or 1000
    SystemConfig.RestartAfterUpdate = (data.RestartAfterUpdate == "true")
    SystemConfig.ReportUploadUrl = data.ReportUploadUrl or "https://statics.igg.com/storage/protracted/1118/11180102021/2021/0610/00/"
    if SystemConfig.IsSop then
        SystemConfig.ReportUploadUrl = "https://statics.igg.com/storage/protracted/1118/11181902021/2021/0610/00/"
    end

    SystemConfig.SetRemoteResPath(SystemConfig.UpdateUrl)
    SystemConfig.InitGM()
end

function SystemConfig.InitGM()
    SystemConfig.is_gm = true
    if SystemConfig.CurAppType == SystemConfig.AppType.Release and SystemConfig.CurAppWeb == SystemConfig.AppWeb.Wlan then
        SystemConfig.is_gm = false
    end

    if SystemConfig.is_gm then
        local obj = CS.UnityEngine.GameObject.Find("Shell")
        obj:AddComponent(typeof(CS.MonoNetPing))
    end
end

function SystemConfig.SetRemoteResPath(value)
    if not value then
        if SystemConfig.CurAppType == SystemConfig.AppType.Debug then
            SystemConfig.RemoteResPath = string.format("%s%s/", "http://192.168.0.175/static/mx_debug/", _GetPlatForm())

        elseif SystemConfig.CurAppType == SystemConfig.AppType.Release then
            if SystemConfig.CurAppWeb == SystemConfig.AppWeb.Lan then
                SystemConfig.RemoteResPath = string.format("%s%s/", "http://192.168.0.175/static/mx_release/", _GetPlatForm())

            elseif SystemConfig.CurAppWeb == SystemConfig.AppWeb.Wlan then
                if SystemConfig.isIGGPlatform() then
                    SystemConfig.RemoteResPath = string.format("%s%s/", SystemConfig.BundleURL, _GetPlatForm())
                else
                    SystemConfig.RemoteResPath = string.format("%s%s/", "https://res-dgame.oss-cn-guangzhou.aliyuncs.com/", _GetPlatForm())
                end
            end
        end
    else
        if SystemConfig.IsSop then
            SystemConfig.RemoteResPath = string.format("%s%s/", "https://res-dgame.oss-cn-guangzhou.aliyuncs.com/", _GetPlatForm())
        else
            SystemConfig.RemoteResPath = string.format("%s%s/", value, _GetPlatForm())
        end
    end
end

function SystemConfig.isIGGPlatform()
    return SystemConfig.AgentID == 2
end

function SystemConfig.isIGGTestPlatform()
    return SystemConfig.AgentID == 3
end

function SystemConfig.InitAppConfig(data)
    if data then
        local rawString = data:GetRawString()
        local maintenance = data:GetMaintenance()
        local bmaintain = maintenance:UnderMaintenance() or false

        local clientIp = data:GetClientIp()
        local _data = rapidjson.decode(rawString)
        --print("InitAppConfig==", clientIp, table.dump(_data))
        -- print("InitAppConfig=======", maintenance.State, bmaintain, maintenance.Title, maintenance.Message,maintenance.BundleURL,maintenance.ServerTime.Timestamp, maintenance.ServerTime.StringValue, table.dump(_data))
        -- print("TimePeriod===========>>", maintenance.TimePeriod.StartAt.Timestamp, maintenance.TimePeriod.StartAt.StringValue, maintenance.TimePeriod.EndAt.Timestamp, maintenance.TimePeriod.EndAt.StringValue)
        SystemConfig.AppConfig = {
            code = 0,
            rawString = _data,
            clientIp = clientIp,
            bundleURL = SystemConfig.BundleURL,
            --维护信息
            MainTainIn = {
                isMaintain = bmaintain, --是否维护
                titleStr = maintenance.Title or "", --维护标题
                contentStr = maintenance.Message or "", --维护内容
                awardNum = _data.LoginBox.maintenanceAwardNum or 0,
                startTime = (maintenance.TimePeriod.StartAt and maintenance.TimePeriod.StartAt.Timestamp) and tonumber(maintenance.TimePeriod.StartAt.Timestamp) or 0, --维护开始时间戳 1615209863
                startTimeStr = (maintenance.TimePeriod.StartAt and maintenance.TimePeriod.StartAt.StringValue) and maintenance.TimePeriod.StartAt.StringValue or "", --维护开始日期 2021-03-08 08:24:23(西五区)
                endTime = (maintenance.TimePeriod.EndAt and maintenance.TimePeriod.EndAt.Timestamp) and tonumber(maintenance.TimePeriod.EndAt.Timestamp) or 0, --维护开始时间戳 1615209863
                endTimeStr = (maintenance.TimePeriod.EndAt and maintenance.TimePeriod.EndAt.StringValue) and maintenance.TimePeriod.EndAt.StringValue or "", --维护开始日期 2021-03-08 08:24:23 (西五区)
            },
        }
    else
        SystemConfig.AppConfig = SystemConfig.default_appconfig()
    end

    SystemConfig.SetRemoteResPath(SystemConfig.AppConfig.bundleURL)
    SystemConfig.CheckRouterUrl()
end

-- 苹果审核服 切换router请求地址
function SystemConfig.CheckRouterUrl()
    if Application.platform == RuntimePlatform.IPhonePlayer then
        local logincfg = SystemConfig.AppConfig.rawString["LoginBox"]
        if logincfg then
            if logincfg['nextVersionCheck'] == "1" then -- 开启审核开关
                local nextVersion = logincfg["nextVersion"] -- 正在审核的版本
                if nextVersion and nextVersion ~= "" and nextVersion == Application.version then
                    SystemConfig.Router = SystemConfig.AuditRouter
                end
            end
        end
    end
end

function SystemConfig.IsExamineVersion()
    if Application.platform == RuntimePlatform.IPhonePlayer then
        local logincfg = SystemConfig.AppConfig.rawString["LoginBox"]
        if logincfg then
            if logincfg['nextVersionCheck'] == "1" then -- 开启审核开关
                local nextVersion = logincfg["nextVersion"] -- 正在审核的版本
                if nextVersion and nextVersion ~= "" and nextVersion == Application.version then
                    return true
                end
            end
        end
    end
    return false
end

--默认appconfig
function SystemConfig.default_appconfig()
    local default_appconfig = {
        ["code"] = 104,
        ["clientIp"] = "",
        ["rawString"] = {
            ["Messages"] = {
                ["content"] = {
                    ["forceUpdate"] = "",
                    ["maintain"] = "",
                    ["update"] = "",
                    ["login"] = "",
                },
            },
            ["ComplianceSetting"] = {
                ["virtualPay"] = "1",
            },
            ["InformedConsent"] = {
                ["mode"] = "asap",
            },
            ["LoginBox"] = {
                ["version"] = "",
                ["showLoginPop"] = "1",
                ["whiteListStatus"] = "0",
                ["whiteListIp"] = "",
                ["nextVersion"] = "",
                ["forceVersion"] = "",
                ["startTime"] = "",
                ["endTime"] = "",
                ["maintenanceAwardNum"] = "",
            },
            ["PageLink"] = {
                ["event"] = "",
                ["guide"] = "",
            },
            ["Misc"] = {
                ["rating"] = "0",
                ["cdkey"] = "0",
            },
            ["Update"] = {
                ["googleUrl"] = "",
                ["appleUrl"] = "",
                ["finalized"] = {
                    ["endAt"] = "",
                    ["startAt"] = "",
                },
                ["isMaintain"] = {
                    ["startAt"] = "",
                    ["endAt"] = "",
                    ["state"] = "1",
                },
            },
            ["LoginServer"] = {
                [1] = {
                    ["host"] = "",
                    ["port"] = "",
                },
            },
        },
        bundleURL = SystemConfig.BundleURL,
        --维护信息
        MainTainIn = {
            isMaintain = false, --是否维护
            startTime = 0, --维护开始时间戳 1615209863
            startTimeStr = "", --维护开始日期 2021-03-08 08:24:23
            endTime = 0, --维护开始时间戳 1615209863
            endTimeStr = "", --维护开始日期 2021-03-08 08:24:23
        },
    }
    return default_appconfig
end