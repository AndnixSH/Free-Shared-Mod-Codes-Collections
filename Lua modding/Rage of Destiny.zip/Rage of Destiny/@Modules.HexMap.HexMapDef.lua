local HexMapDef = {}
HexMapDef.NotifyDef =
{
    UpdateCellView = "UpdateCellView",
    UpdateBuildView = "UpdateBuildView",
    CreateCells = "CreateCells",
    UpdateFollower = "UpdateFollower",
    Update_Hero_List = "Update_Hero_List",
    Update_Rune_List = "Update_Rune_List",
    OnMapPreInit = "OnMapPreInit",
    OnBuildAppear = "OnBuildAppear",
    OnBuildClick = "OnBuildClick",
	StopFollower = "StopFollower",
}



return HexMapDef