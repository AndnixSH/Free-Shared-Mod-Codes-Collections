local HeroProxy = require "Modules.Hero.HeroProxy"
local BagProxy = require "Modules.Bag.BagProxy"
local EquipProxy = require "Modules.Equip.EquipProxy"
local CrystalProxy = require "Modules.Crystal.CrystalProxy"
local ColorTools = require "Common.Util.ColorTools"	

local ObjPoolRender = require "Core.Implement.UI.Class.ObjPoolRender"
local ObjPoolItem = require "Core.Implement.UI.Class.ObjPoolItem"
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"
---
local GameUIUtil = CS.GameUIUtil

local HeroItem = HeroItem or BaseClass(GameObjFactor)
function HeroItem:__init(go)
	self.go = go
	self:Load(go)
end

function HeroItem:Load(obj)
	self.effectRoot = self:GetChild(obj, "effectRoot")
	self.levelObj = self:GetChild(obj, "lv")
	self.levelLbl = self:GetChildComponent(obj, "lv/CLabel_num", "CLabel")
	self.raceSp = self:GetChildComponent(obj, "CSprite_race", "CSprite")
	self.rackBackSp = self:GetChildComponent(obj, "CSprite_raceback", "CSprite")
	-- self.headTex = self:GetChildComponent(obj, "CTexture_head", "CTexture")
	self.headSp = self:GetChildComponent(obj, "CSprite_head", "CSprite")
	self.rankSp = self:GetChildComponent(obj, "CSprite_Frame", "CSprite")
	self.exclusiveSp = self:GetChildComponent(obj, "CSprite_Sig", "CSprite")
	self.lvmaxObj = self:GetChild(obj, "lvmax")
	self.exclusiveSp.gameObject:SetActive(false)	

	self.rankStarObj = self:GetChild(obj, "star")
	self.rankStarItem = self:GetChild(obj, "star/CHorizontalItem/item1")
    self.starPoolRender = ObjPoolRender.New()
    self.starPoolRender:Load(self.rankStarItem, self.rankStarItem.transform.parent, ObjPoolItem)
    self.plusObj = self:GetChild(obj, "CSprite_plus")
    self.plusSp_1 = self:GetChildComponent(obj, "CSprite_plus/CSprite_plus1", "CSprite")
    self.plusSp_2 = self:GetChildComponent(obj, "CSprite_plus/CSprite_plus2", "CSprite")
    self.plusBackObj_1 = self:GetChildComponent(obj, "CSprite_plus/plus1back", "CSprite")
    self.plusBackObj_2 = self:GetChildComponent(obj, "CSprite_plus/plus2back", "CSprite")

	self.redDotObj = self:GetChild(obj, "CSprite_redpoint")
	self.redDotObj:SetActive(false)

	self.selectObj = self:GetChild(obj, "select")
	self.selectObj:SetActive(false)

	self.friendHeroHireFlag = self:GetChild(obj, "CSprite_hire")
	self.otherHeroHireFlag = self:GetChild(obj, "CSprite_hire2")
	self.applyHireFlag = self:GetChild(obj, "CSprite_applyHire")

	self.ownerNameLbl = self:GetChildComponent(obj, "CLabel_ownerName", "CLabel")

	self.lockObj = self:GetChild(obj, "CSprite_lock")
	self.lockIcon = self:GetChild(self.lockObj, "CSprite_lock")
	self.lockObj:SetActive(false)

	self.alphaEffects = {}
end

--{herocfgid or role or roleid, level, rank, crystalLevel}
function HeroItem:SetData(data)

	self.data = data
	self:SetLockObj(false)
	self:SetRedDot(false)
	local herocfgid = data.herocfgid or data.role or data.roleid
	local level = data.level or 1
	local rank = data.rank or 1
	local crystalLevel = data.crystalLevel
	local equips = data.equips
	local chaosRoomLv = data.chaosRoomLv

	self.cfg = HeroProxy.Instance:GetRoleCfgByConfigId(herocfgid)
	self.spritecfg = HeroProxy.Instance:GetSpriteConfigeById(herocfgid)
	self.rankinfo = HeroProxy.Instance:GetRankInfoCfgById(rank)

	self.levelObj:SetActive(true)
	if self.friendHeroHireFlag then
		self.friendHeroHireFlag:SetActive(false)
	end
	if self.otherHeroHireFlag then
		self.otherHeroHireFlag:SetActive(false)
	end
	if self.applyHireFlag then
		self.applyHireFlag:SetActive(false)
	end
	self:ShowHireHeroGray(false)
	-- self.levelLbl.text = HeroProxy.Instance:GetHeroLevelString(herouid)

	if self.exclusiveSp then
		self.exclusiveSp.gameObject:SetActive(false)
	end

	if data.herouid and self.raceSp.gameObject.activeSelf then
	 	local herodata = HeroProxy.Instance:GetHeroDataByUid(data.herouid)
	 	if herodata and herodata.equips and next(herodata.equips) then
	 		local exclusiveGoodsId = EquipProxy.Instance:GetExclusiveEquipGoodsId(herodata.equips)
	 		self:SetExclusiveIcon(exclusiveGoodsId)
	 	end
	elseif equips then --在不同系统 的herodata里 相同的关键字 equips 居然存在两套同样用1、2做Key的数据结构,两套的1,2 代表的意义却不同,只有其中一套能用于此
		-- local exclusiveGoodsId = EquipProxy.Instance:GetExclusiveEquipGoodsId(equips)
		-- self:SetExclusiveIcon(exclusiveGoodsId)
	end

	if chaosRoomLv then --混沌裂隙
		self.levelLbl.text = self:GetWord("Common_1001", chaosRoomLv)
		self.levelLbl.color = ColorTools.RichText2Color("5bd494")
	elseif crystalLevel then --水晶等级
		self.levelLbl.text = self:GetWord("Common_1001", crystalLevel)
		if CrystalProxy.Instance:IsUnLock() then
			self.levelLbl.color = Color.yellow
		else
			self.levelLbl.color = ColorTools.RichText2Color("80cded")
		end
		-- self.lvmaxObj:SetActive(crystalLevel >= self.cfg.level_max)
	else
		-- self.lvmaxObj:SetActive(level >= self.cfg.level_max)
		self.levelLbl.text = self:GetWord("Common_1001", level)
		self.levelLbl.color = Color.white
	end

	self.raceSp.SpriteName = string.format("zhenying_%s", self.cfg.race)
	self.rackBackSp.color = ColorTools.RichText2Color(self.rankinfo.raceback)

	self.rankSp.SpriteName = self.rankinfo.headframe

	self.rankStarObj:SetActive(self.rankinfo.star > 0 and true or false)
	self.starPoolRender:ReleaseAll()
	for i=1,self.rankinfo.star do
		self.starPoolRender:Get({})
	end
	if self.rankinfo.frameangle then
		self.plusObj:SetActive(true)
		self.plusSp_1.SpriteName = self.rankinfo.frameangle
		self.plusSp_2.SpriteName = self.rankinfo.frameangle
		local ColorTools = require "Common.Util.ColorTools"
		self.plusBackObj_1.color = ColorTools.RichText2Color(self.rankinfo.raceback)
		self.plusBackObj_2.color = ColorTools.RichText2Color(self.rankinfo.raceback)
	else
		self.plusObj:SetActive(false)	
	end

	if self.ownerNameLbl then
		self.ownerNameLbl.gameObject:SetActive(false)
	end

	-- AssetManager.LoadUITexture(AssetManager.UITexture.HeroHead, self.spritecfg.prefab_id[1], self.headTex)
	--TODO 设置不同皮肤下的头像
	self.headSp.SpriteName = self.spritecfg.prefab_id[1]
	self:Show()
	self:CloseAlphaEffect()
	self:ClearTempleEffect()
end

function HeroItem:PlayScaleTween()
	if self.scaleSequence then
		self.scaleSequence:Kill()
		self.scaleSequence = nil
	end

	self.go.transform.localScale = Vector3.zero
	self.scaleSequence = DOTween.Sequence()

	local tween = self.go.transform:DOScale(Vector3.one, 0.2)
	tween:SetEase(Ease.OutBack)
	self.scaleSequence:Append(tween)
end

function HeroItem:SetExclusiveIcon(exclusiveId)
	if exclusiveId then
		local cfg = BagProxy.Instance:GetGoodsCfgById(exclusiveId)
		if cfg then
			local equipRankCfg = EquipProxy.Instance:GetEquipQualityColorByQuality(cfg.quality)
			if equipRankCfg and equipRankCfg.exclusivesig and self.exclusiveSp then
				self.exclusiveSp.gameObject:SetActive(true)
				self.exclusiveSp.SpriteName = string.format("zhuanshu%d", equipRankCfg.exclusivesig)
			end
		end
	end
end

function HeroItem:SetExclusiveIconByRank(exclusive_rank)
	if exclusive_rank then
		local equipRankCfg = EquipProxy.Instance:GetEquipQualityColorByQuality(exclusive_rank)
		if equipRankCfg and equipRankCfg.exclusivesig and self.exclusiveSp then
			self.exclusiveSp.gameObject:SetActive(true)
			self.exclusiveSp.SpriteName = string.format("zhuanshu%d", equipRankCfg.exclusivesig)
		end
	end
end

function HeroItem:SetRedDot(isShow)
	self.redDotObj:SetActive(isShow)
end

function HeroItem:SetSelectItem(active)
	if self.selectObj then
		self.selectObj:SetActive(active)
	end
end

function HeroItem:SetAlpha(value)
	GameUIUtil.SetGroupAlpha(self.go, value)
end

function HeroItem:Close()
	self:CloseAlphaEffect()
	if self.flashEffect then
		self.flashEffect:Close()
		self.flashEffect = nil
	end
	if self.scaleSequence then
		self.scaleSequence:Kill()
		self.scaleSequence = nil
	end
end

function HeroItem:Destroy()
	self.showEffectName = nil
	self:DestroyAlphaEffect()
	if self.templeEffect then
		self.templeEffect:Destroy()
		self.templeEffect = nil
	end
	if self.flashEffect then
		self.flashEffect:Destroy()
		self.flashEffect = nil
	end
	if self.scaleSequence then
		self.scaleSequence:Kill()
		self.scaleSequence = nil
	end
end

function HeroItem:Show()
	self.go:SetActive(true)
end

function HeroItem:Hide()
	self.go:SetActive(false)
end

function HeroItem:SetHeroSprite(name)
	self.headSp.SpriteName = name
end

function HeroItem:SetRankSprite(name)
	local _name = name or "daojukuangkong"
	self.rankSp.SpriteName = _name
end

function HeroItem:ShowRankSprite(show)
	
	self.rankSp.gameObject:SetActive(show)
end

function HeroItem:SetLevelStr(str)
	self.levelLbl.text = str
end

function HeroItem:ShowLevelMaxObj(lv)
	self.lvmaxObj:SetActive(lv >= self.cfg.level_max)
end

function HeroItem:SetLevelObjActive(bactive)
	self.levelObj:SetActive(bactive)
end

--是否是雇佣英雄
function HeroItem:ShowHeroHireObj(bHireHero, fromuid)
	local MercenaryProxy = require "Modules.Mercenary.MercenaryProxy"
	local friendHireHero = MercenaryProxy.Instance:CheckIsHireHero(fromuid or 0)
	if self.friendHeroHireFlag then
		self.friendHeroHireFlag:SetActive(friendHireHero and bHireHero)
	end
	if self.otherHeroHireFlag then
		self.otherHeroHireFlag:SetActive((not friendHireHero) and bHireHero)
	end
end

--是否申请雇佣英雄
function HeroItem:ShowHeroApplyHireObj(bApplyHire)
	if self.applyHireFlag then
		self.applyHireFlag:SetActive(bApplyHire)
	end
end

function HeroItem:ShowRankStarObj(bshow)
	self.rankStarObj:SetActive(bshow)
end

--种族灰态
function HeroItem:ShowRaceSpGray(bGray)
	self.raceSp.Gray = bGray
	self.rackBackSp.Gray = bGray
end
--专属品质框灰态
function HeroItem:ShowExclusiveSpGray(bGray)
	self.exclusiveSp.Gray = bGray
end
--英雄头像灰态
function HeroItem:ShowHeadTexGray(bGray)
	self.headSp.Gray = bGray
end
--英雄品质框灰态
function HeroItem:ShowHeadFrameGray(bGray)
	self.rankSp.Gray = bGray
	self.plusSp_1.Gray = bGray
	self.plusSp_2.Gray = bGray
	self.plusBackObj_1.Gray = bGray
	self.plusBackObj_2.Gray = bGray
end
--雇佣兵英雄列表显示
function HeroItem:ShowHireHeroGray(bGray)
	self:ShowRankStarObj(bGray==false and true or false)
	self:ShowRaceSpGray(bGray)
	self:ShowExclusiveSpGray(bGray)
	self:ShowHeadTexGray(bGray)
	self:ShowHeadFrameGray(bGray)
end

function HeroItem:SetGray(bGray)
	self:ShowHireHeroGray(bGray)
end

--星星灰态
function HeroItem:SetRankStarGray(bGray)
	if self.rankinfo then
		self.starPoolRender:ReleaseAll()
		for i=1,self.rankinfo.star do
			self.starPoolRender:Get({bGray=bGray})
		end
	end
end

function HeroItem:SetLockObj(active)
	self.lockObj:SetActive(active)
	self:SetLockIcon(true)
	local tempcolor = active and Color.New(0.4,0.4,0.4,1) or Color.New(1,1,1,1)
	self.exclusiveSp.color = tempcolor
	self.raceSp.color = tempcolor
end

function HeroItem:SetLockIcon(active)
	self.lockIcon:SetActive(active)
end
function HeroItem:ShowAlphaEffect(clistvec4)
	local effectName = self.rankinfo.effect1
	if effectName then
		if not self.alphaEffects[effectName] then
			local effect = UIEffectItem.New(effectName, self.effectRoot, clistvec4)
			effect:Open()
			self.alphaEffects[effectName] = effect
		else
			if self.showEffectName and self.alphaEffects[self.showEffectName] then
				self.alphaEffects[self.showEffectName]:Close()
			end
			self.alphaEffects[effectName]:Open()
		end
		self.showEffectName = effectName
	else
		if self.showEffectName and self.alphaEffects[self.showEffectName] then
			self.alphaEffects[self.showEffectName]:Close()
		end
	end
end

function HeroItem:CloseAlphaEffect()
	for k,effect in pairs(self.alphaEffects) do
		effect:Close()
	end
end

function HeroItem:DestroyAlphaEffect()
	for k,effect in pairs(self.alphaEffects) do
		effect:Destroy()
	end
	self.alphaEffects = {}
end

function HeroItem:ShowTempleEffect(clistvec4)
	local depth1 = self:GetCurrentDepth() + 1
	if self.templeEffect then
		self.templeEffect:Close()
		self.templeEffect:SetOrderLayer(depth1)
		self.templeEffect:Open()
	else
		self.templeEffect = UIEffectItem.New("UI_Common_WaresItemsTitle_flash", self.effectRoot, clistvec4)
		self.templeEffect:SetOrderLayer(depth1)
		self.templeEffect:Open()
	end
end

function HeroItem:ClearTempleEffect()
	if self.templeEffect then
		self.templeEffect:Close()
	end
end

--通用闪光特效 单次特效 不裁剪
function HeroItem:ShowHeroCellflashEffectLoop()
	local depth = self:GetCurrentDepth() + 1
	if self.flashEffect then
		self.flashEffect:Close()
		self.flashEffect:SetOrderLayer(depth)
		self.flashEffect:Open()
	else	
		if self.effectRoot then
			self.flashEffect = UIEffectItem.New("UI_Common_HeroCell_flash_Loop", self.effectRoot)  
			self.flashEffect:SetOrderLayer(depth)
			self.flashEffect:Open()
		end
	end
end

function HeroItem:ShowHeroCellFlashEffect(clistvec4)
	local depth = self:GetCurrentDepth() + 1
	if self.flashEffect then
		self.flashEffect:Close()
		self.flashEffect:SetOrderLayer(depth)
		self.flashEffect:Open()
	else	
		if self.effectRoot then
			self.flashEffect = UIEffectItem.New("UI_Common_HeroCell_flash", self.effectRoot, clistvec4)
			self.flashEffect:SetOrderLayer(depth)
			self.flashEffect:Open()
		end
	end
end

--设置拥有者名字
function HeroItem:SetOwnerName(isShow, str)
	if self.ownerNameLbl then
		if isShow then
			self.ownerNameLbl.gameObject:SetActive(true)
			self.ownerNameLbl.text = str
		else
			self.ownerNameLbl.gameObject:SetActive(false)
		end
	end
end

return HeroItem