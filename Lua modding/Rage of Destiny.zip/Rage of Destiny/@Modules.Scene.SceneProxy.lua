local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"

local SceneProxy = SceneProxy or BaseClass(BaseProxy)
function SceneProxy:__init()
	SceneProxy.Instance = self
	self.manager = SceneManager.New()
end	

function SceneProxy:__delete(self)
    SceneProxy.Instance = nil
end

function SceneProxy:GetSceneCfgById(id)
	local config = ConfigManager.GetConfig("data_scene")
	if config[id] then
		return config[id]
	else
		print("config is null: id: ", id)
	end	
end

--获取当前章节地图
function SceneProxy:GetCurChapterSceneCfg()
	local CampaignProxy = require "Modules.Campaign.CampaignProxy"
	local chapter = CampaignProxy.Instance:GetCurChapter()
	local scenecfg = self:GetSceneCfgById(chapter.scence)
	return scenecfg
end

return SceneProxy