local BagProxy = require "Modules.Bag.BagProxy"
local BagDef = require "Modules.Bag.BagDef"
local EquipProxy = require "Modules.Equip.EquipProxy"
local HeroProxy = require "Modules.Hero.HeroProxy"
local TweenTools =  require "Common.Util.TweenTools"
local ObjPoolRender = require "Core.Implement.UI.Class.ObjPoolRender"
local ClistItem = require "Core.Implement.UI.Class.ClistItem"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"




local PoolItem = PoolItem or BaseClass(ClistItem)

function PoolItem:__init()
end

function PoolItem:Load(obj)
	self.starObj = self:GetChild(self.go, "sprite")
end

function PoolItem:SetData(data)
end











local GoodsItem = GoodsItem or BaseClass(GameObjFactor)

function GoodsItem:__init(go)
	self.go = go
	self:Load(go)
end

function GoodsItem:Load(obj)
	self.frameSp = self:GetChildComponent(obj, "CSprite_frame", "CSprite")
	self.iconTex = self:GetChildComponent(obj, "CTexture_icon", "CTexture")
	self.numLbl = self:GetChildComponent(obj, "CLabel_num", "CLabel")
	self.nameLbl = self:GetChildComponent(obj, "CLabel_name", "CLabel")

	self.fragmentSp = self:GetChildComponent(obj, "CSprite_fragment", "CSprite")
	self.redDotObj = self:GetChild(obj, "CSprite_redpoint")
	self.timeObj = self:GetChild(obj, "CSprite_time")
	if self.timeObj then
		self.timeLab = self:GetChildComponent(self.timeObj, "CLabel_lable", "CLabel")
	end

	
	self.starObj = self:GetChild(obj, "star")
	self.startItemObj = self:GetChild(obj, "star/CVerticalItem")
	self.starItems = {}
	for i=1,5 do
		local starItem = self:GetChild(self.starObj, string.format("CVerticalItem/item%d", i))
		table.insert(self.starItems, starItem)
	end
	
	self.goodsLvObj = self:GetChild(obj, "lv")
	self.goodsLvBackSp = self:GetChildComponent(self.goodsLvObj, "CSprite_back", "CSprite")
	self.goodsLv = self:GetChildComponent(self.goodsLvObj, "CLabel_num", "CLabel")
		
	self.raceSp = self:GetChildComponent(obj, "CSprite_race", "CSprite")

	self.countMaxObj = self:GetChild(self.go, "CSprite_limit")

	self.framePlusObj = self:GetChild(self.go, "CSprite_plus")
	self.framePlusSp1 = self:GetChildComponent(self.framePlusObj, "CSprite_plus1", "CSprite")
	self.framePlusSp2 = self:GetChildComponent(self.framePlusObj, "CSprite_plus2", "CSprite")
	self.frameBackSp1 = self:GetChildComponent(self.framePlusObj, "plus1back", "CSprite")
	self.frameBackSp2 = self:GetChildComponent(self.framePlusObj, "plus2back", "CSprite")


	self.heroFragmentSp = self:GetChildComponent(self.go, "CSprite_icon", "CSprite")

	--hero
	self.heroObj = self:GetChild(self.go, "hero")
	self.raceBackObjsp = self:GetChildComponent(self.heroObj, "CSprite_raceback", "CSprite")
	self.heroRaceSp = self:GetChildComponent(self.heroObj, "CSprite_race", "CSprite")
	
	self.heroFrameSp = self:GetChildComponent(self.heroObj, "CSprite_Frame", "CSprite")
	self.heroFrameSp.gameObject:SetActive(true)
	self.heroIconSp = self:GetChildComponent(self.heroObj, "CSprite_head", "CSprite")
	self.heroLvLab = self:GetChildComponent(self.heroObj, "lv/CLabel_num", "CLabel")
	self.heroFramePlusObj = self:GetChild(self.heroObj, "CSprite_plus")
	self.heroFramePlus1 = self:GetChildComponent(self.heroFramePlusObj, "CSprite_plus1", "CSprite")
	self.heroFramePlus2 = self:GetChildComponent(self.heroFramePlusObj, "CSprite_plus2", "CSprite")
	self.heroFrameBackPlus1 = self:GetChildComponent(self.heroFramePlusObj, "plus1back", "CSprite")
	self.heroFrameBackPlus2 = self:GetChildComponent(self.heroFramePlusObj, "plus2back", "CSprite")	
	self.heroStarObj = self:GetChild(self.heroObj, "star") 
	self.heroStarItem = self:GetChild(self.heroStarObj, "CHorizontalItem/item1")
    self.heroStarRender = ObjPoolRender.New()
    self.heroStarRender:Load(self.heroStarItem, self.heroStarItem.transform.parent, PoolItem)
    self.heroExclusiveSp = self:GetChildComponent(self.heroObj, "CSprite_Sig", "CSprite")

	self.btn = self:GetComponent(self.go, "CButton")
	self.btn:AddClick(function()
		--弹物品tips

		if self.func then
			self.func()
		end

		--点击回调
		if self.callBack then
			self.callBack()
		end
	end)

	self.defaultShowEffectMinQuality = 5
	--effect
	self.qualityEffectKey = {
		[2] = "UI_Common_QualityGreen_circlelight_m",
		[3] = "UI_Common_QualityBlue_circlelight_m",
		[4] = "UI_Common_QualityBlue_circlelight_m",
		[5] = "UI_Common_QualityPurple_circlelight_m",
		[6] = "UI_Common_QualityOrange_circlelight_m",
		[7] = "UI_Common_QualityRed_circlelight_m",
		[8] = "UI_Common_QualityWhite_circlelight_m",
	}

	self.qualityEffectLoopKey = {
		[2] = "UI_Common_QualityGreen_circlelight_m_Loop",
		[3] = "UI_Common_QualityBlue_circlelight_m_Loop",
		[4] = "UI_Common_QualityBlue_circlelight_m_Loop",
		[5] = "UI_Common_QualityPurple_circlelight_m_Loop",
		[6] = "UI_Common_QualityOrange_circlelight_m_Loop",
		[7] = "UI_Common_QualityRed_circlelight_m_Loop",
		[8] = "UI_Common_QualityWhite_circlelight_m_Loop",
	}	
	self.qualityEffects = {}  --品质转圈特效 有裁剪

	self.qualityEffects2 = {}  --品质转圈特效

	--支持裁剪
	self.t1t2Effects = {
		[BagDef.EquipT1T2Type.T1] = "UI_Common_QualityRed_circlelight_m",
		[BagDef.EquipT1T2Type.T2] = "UI_Common_QualityRedT1_circlelight_m",
	}
	--不支持裁剪
	self.t1t2Effects2 = {
		[BagDef.EquipT1T2Type.T1] = "UI_Common_QualityRed_circlelight_m_Loop",
		[BagDef.EquipT1T2Type.T2] = "UI_Common_QualityRedT1_circlelight_m_loop",
	}
	self.equipT1T2Effect = {} --t1t2转圈特效 有裁剪
	self.equipT1T2Effect2 = {} --t1t2转圈特效 没裁剪

	self.effectObj1 = self:GetChild(self.go, "effectRoot1")

	self.noGetObj = self:GetChild(self.go, "weihuode")

	self.selectObj = self:GetChild(self.go, "select")

	if self.selectObj then
		self.hookObj = self:GetChild(self.selectObj, "CSprite_hook")
	end
end

function GoodsItem:GetRedDotObj()
	return self.redDotObj
end

--{goodsId, num, ...}
--外部接口 前端配置id，普通物品展示
function GoodsItem:SetData(goodsId, num, ...)
	self.args = {...}
	self.goodsShowType = 0  --非特殊英雄物品类型，区分显示
	local cfg = BagProxy.Instance:GetGoodsCfgById(goodsId)
	if not cfg then
		return
	end
	if self.countMaxObj then
		self.countMaxObj:SetActive(false)
	end

	if cfg.type == BagDef.BagType.Basic_Equip then
		--args[1] :equipInfo = EquipProxy.Instance:ConstructionEquipItemInfo(goodsTypeId, goodsCount, goodsEnhanceGrade, goodsEnhanceExp)
		self:SetDataByGoodsInfo(BagDef.BagType.Basic_Equip, self.args[1], goodsId, num)
	elseif cfg.subtype == BagDef.SubType.Equip_Exclusive then
		--args[1] ：exclusi_equipInfo = EquipProxy.Instance:ConstructionExclusiveItemInfo(goodsId, goodsTypeId, goodsCount, exclusiveGrade)
		self:SetDataByGoodsInfo(BagDef.SubType.Equip_Exclusive, self.args[1], goodsId, num)
	elseif cfg.subtype == BagDef.SubType.Equip_Artifacts then
		--args[1] ：equipInfo = EquipProxy.Instance:ConstructionArtifactItemInfo(goodsId, goodsTypeId, goodsCount, goodsEnhanceGrade)
		self:SetDataByGoodsInfo(BagDef.SubType.Equip_Artifacts, self.args[1], goodsId, num)
	elseif cfg.subtype == BagDef.SubType.Elite_Hero_Card or cfg.subtype == BagDef.SubType.Rare_Hero_Card then
		--self.args : {roleid, rank, level}
		self:ShowHeroInfo(goodsId, num, self.args)
	else
		self:ShowNormalGoodsInfo(goodsId, num) --通用物品展示
	end
end
 
--外部接口 特殊英雄物品（通过roleid匹配对应英雄物品）
function GoodsItem:SetHeroDataByRoleId(roleid, num, rank, level)
	self.goodsShowType = 1  --特殊英雄物品类型（显示数据构造）
	self.roleid = roleid
	self.rank = rank
	self.level = level
	local heroCfg = HeroProxy.Instance:GetRoleCfgByConfigId(roleid)
	self:HideObjs()
	self.go:SetActive(true)
	if heroCfg then
		--物品名字
		self.nameLbl.text = self:GetWord(heroCfg.name)
	end
	--物品数量
	self.numLbl.text = (num ~= nil and num > 1) and num or ""

	self:HideNormalGoodsFrameObj(false)
	self.heroObj:SetActive(true)
	--英雄物品边框
	local cfg = HeroProxy.Instance:GetRankInfoCfgById(self.rank)

	local bodyCfg = HeroProxy.Instance:GetSpriteConfigeById(self.roleid)
	if bodyCfg then
		self.heroIconSp.SpriteName = bodyCfg.prefab_id[1]  --英雄头像
	end
	if self.level then
		self.heroLvLab.text = self:GetWord("Common_1001", self.level)
		-- self.heroLvLab.text = string.format("LV.%d", self.level)  --英雄等级
	else
		self.heroLvLab.text = ""
	end

	self.heroStarRender:ReleaseAll()
	if cfg then
		self.heroFrameSp.SpriteName = cfg.headframe  --英雄品质框
		if cfg.frameangle then
			self.heroFramePlusObj:SetActive(true)
			self.heroFramePlus1.SpriteName = cfg.frameangle   --英雄品质角标
			self.heroFramePlus2.SpriteName = cfg.frameangle
			local ColorTools = require "Common.Util.ColorTools"
			if self.heroFrameBackPlus1 and self.heroFrameBackPlus2 then
				self.heroFrameBackPlus1.color = ColorTools.RichText2Color(cfg.raceback)
				self.heroFrameBackPlus2.color = ColorTools.RichText2Color(cfg.raceback)
			end
		else
			self.heroFramePlusObj:SetActive(false)
		end

		local star = cfg.star
		local starItems = {}
		if star > 0 then
			for i=1,star do
				table.insert(starItems, i)
			end
			self.heroStarRender:GetList(starItems)  --英雄星数
		else
			self.heroStarRender:GetList({})
		end
	end

	--碎片角标
	if self.fragmentSp then
		self.fragmentSp.gameObject:SetActive(false)
	end

	if self.timeLab then
		self.timeObj:SetActive(false)
	end
	if self.redDotObj then
		self.redDotObj:SetActive(false)
	end

	--种族
	self.raceSp.gameObject:SetActive(false)
	if heroCfg.race then
		if self.raceBackObjsp then
			self.raceBackObjsp.gameObject:SetActive(heroCfg.race > 0 and true or false)
		end
		local ColorTools = require "Common.Util.ColorTools"
		if cfg and self.raceBackObjsp then
			self.raceBackObjsp.color = ColorTools.RichText2Color(cfg.raceback)
		end
		self.heroRaceSp.gameObject:SetActive(heroCfg.race > 0 and true or false)
		self.heroRaceSp.SpriteName = string.format("zhenying_%d", heroCfg.race)
		self.raceSp.SpriteName = string.format("zhenying_%d", heroCfg.race)
	end

	self.goodsLvObj:SetActive(false)
end

function GoodsItem:SetGoodsHeroRace(show_goods_race)
	if self.cfg.race then
		if self.roleid then
			local heroCfg = HeroProxy.Instance:GetRoleCfgByConfigId(self.roleid)
			if (heroCfg and heroCfg.race) then
				self.heroRaceSp.gameObject:SetActive(not show_goods_race)
				self.raceSp.gameObject:SetActive(show_goods_race and true or false)
			end
		end
		self.raceSp.gameObject.transform:SetAsLastSibling()
	end
end

--基础装备物品或者专属装备物品展示
--goodsType:物品大類型  goodsInfo: 物品数据整合的table  
function GoodsItem:SetDataByGoodsInfo(goodsType, goodsInfo, goodsTypeId, goodsCount)
	self:HideNormalEffect()
	if not goodsInfo then
		if goodsType == BagDef.BagType.Basic_Equip then
			goodsInfo = EquipProxy.Instance:ConstructionEquipItemInfo(goodsTypeId, goodsCount, 0, 0)
		elseif goodsType == BagDef.SubType.Equip_Exclusive then
			goodsInfo = EquipProxy.Instance:ConstructionExclusiveItemInfo(nil, goodsTypeId, goodsCount, 0)
		elseif goodsType == BagDef.SubType.Equip_Artifacts then
			goodsInfo = EquipProxy.Instance:ConstructionArtifactItemInfo(nil, goodsTypeId, goodsCount, 0)
		end
	else
		goodsTypeId = goodsTypeId or goodsInfo.goodsTypeId
		goodsCount = goodsCount or goodsInfo.goodsCount
	end
	self.goodsShowType = 0 --非特殊英雄物品类型，区分显示

	self:ShowNormalGoodsInfo(goodsTypeId, goodsCount)

	if goodsType == BagDef.BagType.Basic_Equip then
		--基础装备
		self:SetEquipData(goodsInfo)
	elseif goodsType == BagDef.SubType.Equip_Exclusive then
		--专属装备
		self:SetExclusiveData(goodsInfo)
	elseif goodsType == BagDef.SubType.Equip_Artifacts then
		self:SetArtifactData(goodsInfo)
	end
end

--设置英雄图标专属装备角标 exclusiveId:专属装备物品配置id
function GoodsItem:SetHeroExclusiveSp(exclusiveId)
	local goodscfg = BagProxy.Instance:GetGoodsCfgById(exclusiveId)
	if goodscfg and goodscfg.subtype == BagDef.SubType.Equip_Exclusive then
		local equipRankCfg = EquipProxy.Instance:GetEquipQualityColorByQuality(goodscfg.quality)
		if equipRankCfg and equipRankCfg.exclusivesig and self.heroExclusiveSp then
			self.heroExclusiveSp.gameObject:SetActive(true)
			self.heroExclusiveSp.SpriteName = string.format("zhuanshu%d", equipRankCfg.exclusivesig)
		end
	end
end

function GoodsItem:SetExclusiveGray(bGray)
	self.iconTex.Gray = bGray
	self.frameSp.Gray = bGray
end

--基础装备
--{goodsTypeId= 111, goodsCount =1, goodsEnhanceGrade=1, isEquip = true}
function GoodsItem:SetEquipData(goodsInfo)
	self.goodsEnhanceGrade = goodsInfo.goodsEnhanceGrade
	-- print("SetEquipData =", table.dump(goodsInfo))
	if goodsInfo and goodsInfo.isEquip == true then
		local name = self:GetWord(self.cfg.name)
		local equipName = EquipProxy.Instance:GetEquipQualityColor(self.cfg.quality, name)
		self.nameLbl.text = equipName

		if goodsInfo.goodsEnhanceGrade then
			self.starObj:SetActive((goodsInfo.goodsEnhanceGrade > 0) and true or false)
			self.startItemObj:SetActive((goodsInfo.goodsEnhanceGrade > 0) and true or false)
			for i=1, #self.starItems do
				if goodsInfo.goodsEnhanceGrade then
					self.starItems[i]:SetActive((goodsInfo.goodsEnhanceGrade >= i) and true or false)
				end
			end
		end

		self:ShowEquipGoodsT()
	end
end

function GoodsItem:PlayScaleTween()
	if self.scaleSequence then
		self.scaleSequence:Kill()
		self.scaleSequence = nil
	end

	self.go.transform.parent.localScale = Vector3.zero
	self.scaleSequence = DOTween.Sequence()

	local tween = self.go.transform.parent:DOScale(Vector3.one, 0.2)
	tween:SetEase(Ease.OutBack)
	self.scaleSequence:Append(tween)
end


function GoodsItem:CloseEquipT1T2Effect()
	for k,_effect in pairs(self.equipT1T2Effect) do
		_effect:Destroy()
		self.equipT1T2Effect[k] = nil
	end
end

function GoodsItem:CloseEquipT1T2Effect2()
	for k,_effect in pairs(self.equipT1T2Effect2) do
		_effect:Destroy()
		self.equipT1T2Effect2[k] = nil
	end
end


--T1T2装备转圈特效 支持裁剪
function GoodsItem:ShowT1T2EquipEffect(quality, clistvec4, depth)
	local depth = depth or (self:GetCurrentDepth() + 1)
	if self.equipT1T2Effect[quality] then
		self.equipT1T2Effect[quality]:Close()
		self.equipT1T2Effect[quality]:SetOrderLayer(depth)
		self.equipT1T2Effect[quality]:Open()
	else	
		if self.effectObj1 and self.t1t2Effects[quality] then
			self.equipT1T2Effect[quality] = UIEffectItem.New(self.t1t2Effects[quality], self.effectObj1, clistvec4)
			self.equipT1T2Effect[quality]:SetOrderLayer(depth)
			self.equipT1T2Effect[quality]:Open()  
		end
	end
end

--T1T2装备转圈特效 不支持裁剪
function GoodsItem:ShowT1T2EquipEffec2(quality, depth)
	local depth = depth or (self:GetCurrentDepth() + 1)
	if self.equipT1T2Effect2[quality] then
		self.equipT1T2Effect2[quality]:Close()
		self.equipT1T2Effect2[quality]:SetOrderLayer(depth)
		self.equipT1T2Effect2[quality]:Open()
	else
		if self.effectObj1 and self.t1t2Effects2[quality] then
			self.equipT1T2Effect2[quality] = UIEffectItem.New(self.t1t2Effects2[quality], self.effectObj1)
			self.equipT1T2Effect2[quality]:SetOrderLayer(depth)
			self.equipT1T2Effect2[quality]:Open()  
		end
	end
end

--专属装备
--{goodsId =1,goodsTypeId= 111, goodsCount =1, exclusiveGrade=1, isEquip = true}
function GoodsItem:SetExclusiveData(goodsInfo)

	if goodsInfo then
		local name = self:GetWord(self.cfg.name)
		local equipName = EquipProxy.Instance:GetEquipQualityColor(self.cfg.quality, name)
		self.nameLbl.text = equipName
		self.goodsLvObj:SetActive(false)
		if goodsInfo.exclusiveGrade then
			self.goodsLvObj:SetActive(goodsInfo.exclusiveGrade > 0 and true or false)
			self.goodsLv.text = "+" .. goodsInfo.exclusiveGrade
			self.goodsLvBackSp.gameObject:SetActive(true)
			self.goodsLvBackSp.SpriteName = "daojukuangmiaoshu"
		end
	end
end

--神器装备
--{goodsId =1,goodsTypeId= 111, goodsCount =1, goodsEnhanceGrade=1}
function GoodsItem:SetArtifactData(goodsInfo)
	if goodsInfo then
		local name = self:GetWord(self.cfg.name)
		local equipName = EquipProxy.Instance:GetEquipQualityColor(self.cfg.quality, name)
		self.nameLbl.text = equipName
		
		if goodsInfo.goodsEnhanceGrade then
			self.starObj:SetActive((goodsInfo.goodsEnhanceGrade > 0) and true or false)
			self.startItemObj:SetActive((goodsInfo.goodsEnhanceGrade > 0) and true or false)
			for i=1, #self.starItems do
				if goodsInfo.goodsEnhanceGrade then
					self.starItems[i]:SetActive((goodsInfo.goodsEnhanceGrade >= i) and true or false)
				end
			end
		end
	end
	self.countMaxObj:SetActive(false)
end

function GoodsItem:HideNormalGoodsFrameObj(active)
	self.frameSp.gameObject:SetActive(active)
	self.iconTex.gameObject:SetActive(active)
	self.heroFragmentSp.gameObject:SetActive(active)
end

--英雄展示
function GoodsItem:ShowHeroInfo(goodsId, num, args)
	self:HideNormalEffect()
	self.goodsId = goodsId
	self.num = num
	self.cfg = BagProxy.Instance:GetGoodsCfgById(goodsId)
	local name = ""
	if args and #args > 0 then
		self.goodsShowType = 1  --特殊英雄物品类型（显示数据构造）
		self.roleid, self.rank, self.level = args[1] , args[2], args[3]
		self.heroCfg = HeroProxy.Instance:GetRoleCfgByConfigId(self.roleid)
		name = self:GetWord(self.heroCfg.name)
	else
		self.goodsShowType = 0
		self.roleid, self.rank, self.level = self.cfg.value[1], self.cfg.value[2], self.cfg.value[3]
		self.heroCfg = HeroProxy.Instance:GetRoleCfgByConfigId(self.roleid)
		name = self:GetWord(self.cfg.name)
	end
	self:HideObjs()
	self.go:SetActive(true)
	self.heroCfg = HeroProxy.Instance:GetRoleCfgByConfigId(self.roleid)
	self.nameLbl.text = name

	--物品数量
	self.numLbl.text = (num ~= nil and num > 1) and num or ""

	self:HideNormalGoodsFrameObj(false)
	self.heroObj:SetActive(true)
	--英雄物品边框
	local cfg = HeroProxy.Instance:GetRankInfoCfgById(self.rank)

	local bodyCfg = HeroProxy.Instance:GetSpriteConfigeById(self.roleid)
	if bodyCfg then
		self.heroIconSp.SpriteName = bodyCfg.prefab_id[1]  --英雄头像
	end
	if self.level then
		self.heroLvLab.text = self:GetWord("Common_1001", self.level)
		-- self.heroLvLab.text = string.format("LV.%d", self.level)  --英雄等级
	else
		self.heroLvLab.text = ""
	end

	self.heroStarRender:ReleaseAll()
	if cfg then
		self.heroFrameSp.SpriteName = cfg.headframe  --英雄品质框
		if cfg.frameangle then
			self.heroFramePlusObj:SetActive(true)
			self.heroFramePlus1.SpriteName = cfg.frameangle   --英雄品质角标
			self.heroFramePlus2.SpriteName = cfg.frameangle
			local ColorTools = require "Common.Util.ColorTools"
			if self.heroFrameBackPlus1 and self.heroFrameBackPlus2 then
				self.heroFrameBackPlus1.color = ColorTools.RichText2Color(cfg.raceback)
				self.heroFrameBackPlus2.color = ColorTools.RichText2Color(cfg.raceback)
			end
		else
			self.heroFramePlusObj:SetActive(false)
		end

		local star = cfg.star
		local starItems = {}
		if star > 0 then
			for i=1,star do
				table.insert(starItems, i)
			end
			self.heroStarRender:GetList(starItems)  --英雄星数
		else
			self.heroStarRender:GetList({})
		end
	end

	--碎片角标
	if self.fragmentSp then
		self.fragmentSp.gameObject:SetActive(false)
	end

	if self.timeLab then
		self.timeObj:SetActive(false)
	end
	if self.redDotObj then
		self.redDotObj:SetActive(false)
	end

	--种族
	self.raceSp.gameObject:SetActive(false)
	if self.heroCfg.race then
		if self.raceBackObjsp then
			self.raceBackObjsp.gameObject:SetActive(self.heroCfg.race > 0 and true or false)
		end
		local ColorTools = require "Common.Util.ColorTools"
		if cfg and self.raceBackObjsp then
			self.raceBackObjsp.color = ColorTools.RichText2Color(cfg.raceback)
		end
		self.raceSp.SpriteName = string.format("zhenying_%d", self.heroCfg.race)
		self.heroRaceSp.gameObject:SetActive(self.heroCfg.race > 0 and true or false)
		self.heroRaceSp.SpriteName = string.format("zhenying_%d", self.heroCfg.race)
	end

	self.goodsLvObj:SetActive(false)
end



function GoodsItem:ShowNormalGoodsInfo(goodsId, num)
	self:HideNormalEffect()
	self.goodsId = goodsId
	self.num = num
	self:HideObjs()
	self.go:SetActive(true)
	self:SetExclusiveGray(false)
	self.cfg = BagProxy.Instance:GetGoodsCfgById(goodsId)
	if not self.cfg then
		print("-------ShowNormalGoodsInfo----error---------",goodsId)
		return
	end
	if self.cfg then
		--self.nameLbl.text = self:GetWord(self.cfg.name)
		local qualityDesc =LanguageManager.Instance:GetWord(self.cfg.name) 
		local _text = EquipProxy.Instance:GetEquipQualityColor(self.cfg.quality, qualityDesc)
		self.nameLbl.text=_text
	end
	self.numLbl.text = (num ~= nil and num > 1) and GameLogicTools.GetNumStr(num) or ""


		self:HideNormalGoodsFrameObj(true)
		self.heroObj:SetActive(false)
		--普通物品边框
		local frameCfg = BagProxy.Instance:GetGoodsFrame(self.cfg.quality)
		if frameCfg then
			self.frameSp.SpriteName = frameCfg.frame
			if frameCfg.frameangle then
				self.framePlusObj:SetActive(true)
				self.framePlusSp1.SpriteName = frameCfg.frameangle
				self.framePlusSp2.SpriteName = frameCfg.frameangle
				local ColorTools = require "Common.Util.ColorTools"

				if self.frameBackSp1 and self.frameBackSp2 then
					self.frameBackSp1.color = ColorTools.RichText2Color(frameCfg.raceback)
					self.frameBackSp2.color = ColorTools.RichText2Color(frameCfg.raceback)
				end
			else
				self.framePlusObj:SetActive(false)
			end
		end

		if self.cfg.subtype == BagDef.SubType.Hero_Fragment then
			--英雄碎片
			local roleid = self.cfg.value[1]
			self.iconTex.gameObject:SetActive(false)
			self.heroFragmentSp.gameObject:SetActive(true)

			local bodyCfg = HeroProxy.Instance:GetSpriteConfigeById(roleid)
			if bodyCfg then
				self.heroFragmentSp.SpriteName = bodyCfg.prefab_id[1] 
			end
		else
			self.iconTex.gameObject:SetActive(true)
			self.heroFragmentSp.gameObject:SetActive(false)
			AssetManager.LoadUITexture(AssetManager.UITexture.Goods, self.cfg.icon, self.iconTex)
		end


	if self.fragmentSp then
		if self.cfg.subtype == BagDef.SubType.Hero_Fragment or self.cfg.subtype == BagDef.SubType.Hero_Stone then
			self.fragmentSp.gameObject:SetActive(true)
		else
			self.fragmentSp.gameObject:SetActive(false)
		end
	end
	
	if self.timeLab then
		self.timeObj:SetActive(false)
		if self.cfg.type == BagDef.BagType.Gift_Item and self.cfg.subtype == BagDef.SubType.TimeLinessTool then
			local value = self.cfg.value
			if value and value[1] then
				self.timeObj:SetActive(true)
				self.timeLab.text = math.floor(value[1][2]/60) .. self:GetWord("Goodsbutton_1004")
			end
		end
	end
	if self.redDotObj then
		self.redDotObj:SetActive(false)
	end

	if self.raceSp then
		self.raceSp.gameObject:SetActive(false)
	end
	if self.cfg.race then
		self.raceSp.gameObject:SetActive(self.cfg.race > 0 and true or false)
		self.raceSp.SpriteName = string.format("zhenying_%d", self.cfg.race)
	end

	self:ShowNormalGoodsT()
end

function GoodsItem:ShowMaxCountObj(num)
	if self.countMaxObj and self.cfg and num then
		self.countMaxObj:SetActive((self.cfg.stack <= num) and true or false)
		if self.cfg.stack <= num then
			self:SetGoodsCountStr("")
		end
	end	
end

function GoodsItem:ShowNormalGoodsT()
	if self.cfg then
		local t = ""
		if self.cfg.subtype == BagDef.SubType.Rune_Stone_one then
			t = "T1"
			self.goodsLvBackSp.SpriteName = "daojukuangmiaoshu"

		elseif self.cfg.subtype == BagDef.SubType.Rune_Stone_tow then
			t = "T2"
			self.goodsLvBackSp.SpriteName = "daojukuangmiaoshu"
		end
		self.goodsLvBackSp.gameObject:SetActive(t ~= "" and true or false)
		self.goodsLvObj:SetActive(t ~= "" and true or false)
		self.goodsLv.text = t
	end
end

function GoodsItem:ShowEquipGoodsT()
	if self.cfg then
		self.goodsLvObj:SetActive(self.cfg.quality >=10 and true or false)
		self.goodsLv.text = "T" .. math.max(self.cfg.quality - 9, 1)
		if self.cfg.quality == 10 then
			self.goodsLvBackSp.SpriteName = "daojukuangmiaoshu"
		else
			self.goodsLvBackSp.SpriteName = "daojukuangmiaoshu"
		end
		self.goodsLvBackSp.gameObject:SetActive(true)
	end
end

function GoodsItem:HideObjs()
	self.starObj:SetActive(false)
	self.goodsLvObj:SetActive(false)
	self.raceSp.gameObject:SetActive(false)
	if self.raceBackObjsp then
		self.raceBackObjsp.gameObject:SetActive(false)
	end
	if self.countMaxObj then
		self.countMaxObj:SetActive(false)
	end
	self.heroExclusiveSp.gameObject:SetActive(false)

	self.framePlusObj:SetActive(false)
	self.heroFramePlusObj:SetActive(false)

end

function GoodsItem:SetRedDot(redDot)
	if self.redDotObj then
		self.redDotObj:SetActive(redDot > 0 and true or false)
	end
end

function GoodsItem:SetGoodsCountStr(countStr)
	self.numLbl.text = countStr
end

function GoodsItem:SetGoodsNameStr(nameStr)
	self.nameLbl.text = nameStr
end

function GoodsItem:SetNoGet(isActive)
	self.noGetObj:SetActive(isActive)
end

function GoodsItem:SetSelectObj(isActive)
	self.selectObj:SetActive(isActive)
end

function GoodsItem:GetHookObj()
	return self.hookObj
end

function GoodsItem:ClearTween()
	if self.scaleSequence then
		self.scaleSequence:Kill()
		self.scaleSequence = nil
	end
end

function GoodsItem:Close()
	self:ClearTween()
	self:HideNormalEffect()
	self:SingleEffect()
	self.go:SetActive(false)
end

function GoodsItem:Destroy()
	self:ClearTween()
	self:HideNormalEffect()
	self:SingleEffect()
	self.go:SetActive(false)
end

------effect--------

function GoodsItem:HideNormalEffect()

	if self.effect2 then
		self.effect2:Destroy()
		self.effect2 = nil
	end

	for quality,effect in pairs(self.qualityEffects) do
		effect:Destroy()
		self.qualityEffects[quality] = nil
	end
	
	for quality,effect in pairs(self.qualityEffects2) do
		effect:Destroy()
		self.qualityEffects2[quality] = nil
	end

	if self.effect22 then
		self.effect22:Destroy()
		self.effect22 = nil
	end

	if self.raceEffect then
		self.raceEffect:Destroy()
		self.raceEffect = nil
	end
	self:CloseEquipT1T2Effect()
	self:CloseEquipT1T2Effect2()
end

function GoodsItem:SingleEffect()
	if self.effect1 then
		self.effect1:Destroy()
		self.effect1 = nil
	end

	if self.effect11 then
		self.effect11:Destroy()
		self.effect11 = nil
	end
end

--通用闪光特效 单次特效
function GoodsItem:ShowHeroCellFlashEffect()
	local depth = self:GetCurrentDepth() + 1
	if self.effect1 then
		self.effect1:Close()
		self.effect1:SetOrderLayer(depth)
		self.effect1:Open()
	else	
		if self.effectObj1 then
			self.effect1 = UIEffectItem.New("UI_Common_HeroCell_flash", self.effectObj1)  
			self.effect1:SetOrderLayer(depth)
			self.effect1:Open()
		end
	end
end

--通用闪光特效 单次特效 不裁剪
function GoodsItem:ShowHeroCellFlashEffectLoop()
	local depth = self:GetCurrentDepth() + 1
	if self.effect11 then
		self.effect11:Close()
		self.effect11:SetOrderLayer(depth)
		self.effect11:Open()
	else	
		if self.effectObj1 then
			self.effect11 = UIEffectItem.New("UI_Common_HeroCell_flash_Loop", self.effectObj1)  
			self.effect11:SetOrderLayer(depth)
			self.effect11:Open()
		end
	end
end

--种族图标闪光 单次特效
function GoodsItem:ShowHeroRaceIconEffect()
	local depth = self:GetCurrentDepth() + 1
	if self.raceEffect then
		self.raceEffect:Close()
		self.raceEffect:SetOrderLayer(depth)
		self.raceEffect:Open()
	else
		self.raceEffect = UIEffectItem.New("UI_Common_HeroCellRace_flash", self.raceSp.gameObject)
		self.raceEffect:SetLocalPosition(40, -37, 0)
		self.raceEffect:SetOrderLayer(depth)
		self.raceEffect:Open()
	end
end

--循环特效
function GoodsItem:ShowHeroRaceShineEffect(bOpen)
	local depth = self:GetCurrentDepth() + 1
	local bopen = true 
	if bOpen ~= nil and bOpen == false then
		bopen = false
	end
	if self.effect2 then
		self.effect2:Close()
		if bopen then
			self.effect2:SetOrderLayer(depth)
			self.effect2:Open()
		end
	else	
		if self.effectObj1 and bopen then
			self.effect2 = UIEffectItem.New("UI_Common_HeroCellRace_shine", self.effectObj1)
			self.effect2:SetOrderLayer(depth)
			self.effect2:Open()  
		end
	end
end

--循环特效 不裁剪
function GoodsItem:ShowHeroRaceShineEffectLoop(bOpen, depth)
	if not depth then
		depth = self:GetCurrentDepth() + 1
	end
	-- local depth = self:GetCurrentDepth() + 1
	local bopen = true 
	if bOpen ~= nil and bOpen == false then
		bopen = false
	end
	if self.effect22 then
		self.effect22:Close()
		if bopen then
			self.effect22:SetOrderLayer(depth)
			self.effect22:Open()
		end
	else	
		if self.effectObj1 and bopen then
			self.effect22 = UIEffectItem.New("UI_Common_HeroCellRace_shine_Loop", self.effectObj1)
			self.effect22:SetOrderLayer(depth)
			self.effect22:Open()  
		end
	end
end

function GoodsItem:ChangeShowEffectMinQuality(min_quality)
	self.defaultShowEffectMinQuality = min_quality
end

--品质转圈特效 UI_Common_AvatarGreen_highlight
function GoodsItem:ShowQualityCircleEffect(quality, clistvec4, target_depth)
	if (not quality) or (quality < self.defaultShowEffectMinQuality) then
		return
	end

	if quality > 8 then
		quality = 8
	end

	local depth = (target_depth or self:GetCurrentDepth() + 1)
	if self.qualityEffects[quality] then
		self.qualityEffects[quality]:Close()
		self.qualityEffects[quality]:SetOrderLayer(depth)
		self.qualityEffects[quality]:Open()
	else	
		if self.effectObj1 and self.qualityEffectKey[quality] then
			self.qualityEffects[quality] = UIEffectItem.New(self.qualityEffectKey[quality], self.effectObj1, clistvec4)
			self.qualityEffects[quality]:SetOrderLayer(depth)
			self.qualityEffects[quality]:Open()  
		end
	end
end

--品质转圈特效 不裁剪
function GoodsItem:ShowQualityCircleEffectLoop(quality)
	if (not quality) or (quality < self.defaultShowEffectMinQuality) then
		return
	end
	
	--大于8的都是用白色
	if quality > 8 then
		quality = 8
	end

	local depth = self:GetCurrentDepth() + 1
	if self.qualityEffects2[quality] then
		self.qualityEffects2[quality]:Close()
		self.qualityEffects2[quality]:SetOrderLayer(depth)
		self.qualityEffects2[quality]:Open()
	else	
		if self.effectObj1 and self.qualityEffectLoopKey[quality] then
			self.qualityEffects2[quality] = UIEffectItem.New(self.qualityEffectLoopKey[quality], self.effectObj1)
			self.qualityEffects2[quality]:SetOrderLayer(depth)
			self.qualityEffects2[quality]:Open()  
		end
	end
end

--物品tips
function GoodsItem:ShowGoodsInfo(localPosition,param)
	if self.goodsShowType == 1 then
		--特殊英雄物品（不通过物品表数据显示）
		GameLogicTools.ShowHeroTipsView(self.roleid, self.rank, self.level)
	else
		if self.goodsId then
			local BagProxy = require "Modules.Bag.BagProxy"
			local goodscfg = BagProxy.Instance:GetGoodsCfgById(self.goodsId)
			if goodscfg then
				if goodscfg.type == BagDef.BagType.Res_Item then
					--货币tips
					GameLogicTools.ShowItemLableView(self.goodsId,localPosition, self.go.transform.position)
				elseif goodscfg.type == BagDef.BagType.Basic_Equip then
					--装备tips
					GameLogicTools.ShowItemEquipTipsView(self.goodsId,self.goodsEnhanceGrade, self.num)
				elseif goodscfg.subtype == BagDef.SubType.OneChest or goodscfg.subtype == BagDef.SubType.AwardBox then
					--大于604 605类型的宝箱tips
					GameLogicTools.ShowItemBoxTipsView(self.goodsId, self.num)
				elseif goodscfg.subtype == BagDef.SubType.Elite_Hero_Card or goodscfg.subtype == BagDef.SubType.Rare_Hero_Card
					or goodscfg.subtype == BagDef.SubType.Hero_Fragment then
						GameLogicTools.ShowHeroTipsView(goodscfg.value[1], goodscfg.value[2], goodscfg.value[3])
				else
					GameLogicTools.ShowItemTipsView(self.goodsId, self.num,param)
				end
			end
		end
	end
end

function GoodsItem:AddClickCallBack(callBack)
	self.callBack = callBack
end

function GoodsItem:SetClickOpenInfo(localPosition,param)
	self.func = function( ... )
		self:ShowGoodsInfo(localPosition,param)
	end
end

return GoodsItem