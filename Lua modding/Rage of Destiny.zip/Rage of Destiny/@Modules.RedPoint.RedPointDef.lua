local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"

local RedPointDef = {}

--节点id
RedPointDef.Id = 
{
	--主界面
	Territory = "Territory", --主界面的领地入口
	Journey = "Journey", --主界面的征途入口
	Mall = "Mall", --主界面的商城入口
	Friend = "Friend", --主界面的好友入口

	Territory2 = "Territory2", --英雄列表的领地入口
	Journey2 = "Journey2", --英雄列表的征途入口
	Hero2 = "Hero2", --英雄列表的英雄入口

	Hero = "Hero", --英雄入口
	HeroTab = "HeroTab", --英雄页签入口
	HeroBook = "HeroBook",--英雄图鉴页签入口

	--领地界面
	Guild = "Guild", --领地界面的公会入口
	CardPortal = "CardPortal", --领地界面的传送门入口
	RankList = "RankList", --排行榜入口
	Crystal = "Crystal", --共鸣水晶入口
	Temple = "Temple", --光明圣堂

	--征途界面
	SupplyDepot = "SupplyDepot", --征途界面的补给站入口
	Tower = "Tower", --征途界面的爬塔

	Realm = "Realm", --幻境入口
	Realm2 = "Realm2", --幻境入口

	TowerType0 = "TowerType0", --爬塔中立塔

	--商城
	MallNormal = "MallNormal", --普通商船
	MallNormalDaily = "MallNormalDaily", --普通商船下的日礼包
	MallNormalWeekly = "MallNormalWeekly", --普通商船下的周礼包
	MallNormalMonthly = "MallNormalMonthly", --普通商船下的月礼包
	MallNormalGem = "MallNormalGem", --普通商船下的钻石礼包
	MallLimit = "MallLimit", --限时商船
	MallLimitGrow = "MallLimitGrow", --限时商船下的成长礼包
	MallLimitSelf = "MallLimitSelf", --限时商船下的定制礼包
	MallLimitGrow2Show = "MallLimitGrow2Show", --成长礼包2首次出现
	MallMonthCard = "MallMonthCard", --月卡
	MallMonthCardMonth = "MallMonthCardMonth", --月卡下的月卡
	MallMonthCardMonthBox1 = "MallMonthCardMonthBox1", --月卡下的月卡的宝箱1
	MallMonthCardMonthBox2 = "MallMonthCardMonthBox2", --月卡下的月卡的宝箱2
	MallMonthCardMonthBox3 = "MallMonthCardMonthBox3", --月卡下的月卡的宝箱3
	MallMonthCardMonthOverdue1 = "MallMonthCardMonthOverdue1", --普通月卡过期
	MallMonthCardMonthOverdue2 = "MallMonthCardMonthOverdue2", --超级月卡过期
	MallMonthCardMonthFirst = "MallMonthCardMonthFirst", --首次打开商城,月卡出现红点
	MallPass = "MallPass",
	MallPassTask = "MallPassTask",
	MallPassMaze = "MallPassMaze",
	MallPassGuildChaos = "MallPassGuildChaos",
	HappyMonthPanel = "HappyMonthPanel", --女王狂欢祭
	HappyMonthGet = "HappyMonthGet",--女王狂欢祭
	HappyMonthBuyTip = "HappyMonthBuyTip",--女王狂欢祭未购买时红点提示
	MallDailySupply = "MallDailySupply", --每日补给

	--公会
	GuildLevelIcon = "GuildLevelIcon", --公会等级图标
	GuildBoss = "GuildBoss", --公会界面的boss入口
	GuildBossLeftArrow = "GuildBossLeftArrow", --公会boss左箭头
	GuildBossRightArrow = "GuildBossRightArrow", --公会boss右箭头
	GuildBossChallengeNormal = "GuildBossChallengeNormal", --公会boss挑战按钮(普通)
	GuildBossChallengeHigh = "GuildBossChallengeHigh", --公会boss挑战按钮(高级)
	GuildBossOpenHigh = "GuildBossOpenHigh", --可以开启高级boss

	--混沌裂隙
	GuildChaos = "GuildChaos", --公会界面的混沌裂隙入口
	GuildChaosChallenge = "GuildChaosChallenge", --混沌裂隙挑战

	--抽卡
	CardPortalNormal = "CardPortalNormal", --普通抽卡(页签)
	CardPortalNormalOne = "CardPortalNormalOne", --普通抽卡(单抽)
	CardPortalNormalTen = "CardPortalNormalTen", --普通抽卡(十抽)
	CardPortalFaction = "CardPortalFaction", --种族抽卡(页签)
	CardPortalFactionOne = "CardPortalFactionOne", --种族抽卡(单抽)
	CardPortalFactionTen = "CardPortalFactionTen", --种族抽卡(十抽)
	CardPortalCompanion = "CardPortalCompanion", --友情抽卡(页签)
	CardPortalCompanionOne = "CardPortalCompanionOne", --友情抽卡(单抽)
	CardPortalCompanionTen = "CardPortalCompanionTen", --友情抽卡(十抽)
	CardPortalRaceCard = "CardPortalRaceCard", --种族卡
	CardPortalWishList = "CardPortalWishList", --心愿单
	CardPortNewHero = "CardPortNewHero" ,-- 新英雄红点race 1-4
	CardPortNewHero_2 = "CardPortNewHero_2" ,-- 新英雄红点 race 5 6

	CardStarTen = "CardStarTen",--占星十抽
	CardStarOne = "CardStarOne",--占星单抽
	CardStar = "CardStar",--占星
	CardPortal_2 = "CardPortal_2",--占星普通抽卡入口

	--排行榜
	Lightbearers_ladder = "Lightbearers_ladder",
    Maulers_ladder = "Maulers_ladder",
    Wilders_laddder = "Wilders_laddder",
    Graveborn_ladder = "Graveborn_ladder",
    Stage_progression_ladder = "Stage_progression_ladder",
	Tower_progression_ladder = "Tower_progression_ladder",
	Rank_Award1  = "Rank_Award1" ,
	Rank_Award2  = "Rank_Award2" ,
	Rank_Award3  = "Rank_Award3" ,
	Rank_Award4  = "Rank_Award4" ,
	Rank_Award5  = "Rank_Award5" ,
	Rank_Award6  = "Rank_Award6" ,

	--补给站
	SupplyDepotLevelInfo = "SupplyDepotLevelInfo", --等级信息
	SupplyDepotLevelUp = "SupplyDepotLevelUp", --等级提升
	SupplyDepotTaskCanGet1 = "SupplyDepotTaskCanGet1", --任务可接取
	SupplyDepotTaskCanGet2 = "SupplyDepotTaskCanGet2",
	SupplyDepotTaskCanGet3 = "SupplyDepotTaskCanGet3",
	SupplyDepotTaskCanGet4 = "SupplyDepotTaskCanGet4",
	SupplyDepotTaskCanGet5 = "SupplyDepotTaskCanGet5",
	SupplyDepotTaskCanGet6 = "SupplyDepotTaskCanGet6",
	SupplyDepotTaskCanGet7 = "SupplyDepotTaskCanGet7",
	SupplyDepotTaskCanGet8 = "SupplyDepotTaskCanGet8",
	SupplyDepotTaskCanReward1 = "SupplyDepotTaskCanReward1", --任务可领奖
	SupplyDepotTaskCanReward2 = "SupplyDepotTaskCanReward2",
	SupplyDepotTaskCanReward3 = "SupplyDepotTaskCanReward3",
	SupplyDepotTaskCanReward4 = "SupplyDepotTaskCanReward4",
	SupplyDepotTaskCanReward5 = "SupplyDepotTaskCanReward5",
	SupplyDepotTaskCanReward6 = "SupplyDepotTaskCanReward6",
	SupplyDepotTaskCanReward7 = "SupplyDepotTaskCanReward7",
	SupplyDepotTaskCanReward8 = "SupplyDepotTaskCanReward8",
	SupplyDepotShip1 = "SupplyDepotShip1", --商船

	--竞技场
	ArenaRecord = "ArenaRecord",
	ProArenaRecord = "ProArenaRecord",
	ArenaEnter = "ArenaEnter", --征途入口
	List_NormalArena = "List_NormalArena",
	List_ProArena = "List_ProArena",
	ProArena_GetCoin = "ProArena_GetCoin",
	List_LegendArena = "List_LegendArena",

	--剧情副本日志
	StoryLineLog = "StoryLineLog",
	StoryLineEnter = "StoryLineEnter", --野外入口
	

	--VIP入口
	VIPEnter = "VipEnter",
	VIP_Get = "VIP_Get",--vip 领取奖励

	--领地里 生命之树 和 羁绊的入口 
	RootRelation = "RootRelation",

	--生命之树
	Tree = "Tree",

	--羁绊
	Relation = "Relation", --领地羁绊入口
	Relation_2 = "Relation_2", --英雄羁绊入口
	Relation_3 = "Relation_3", --羁绊页签
	--首充
	FirstCharge_First = "FirstCharge_First",
	FirstCharge_Second = "FirstCharge_Second",

	--活动
	Activity = "Activity", --活动入口
	Seven_Login_Enter = "Seven_Login_Enter",
	Seven_Login = "Seven_Login",
	Events_Seven_Login = "Events_Seven_Login",
	Events_Seven_Login_Two = "Events_Seven_Login_Two",
	Nine_Grid = "Nine_Grid",
	MobilizeEnter = "MobilizeEnter",
	MobilizeTask = "MobilizeTask",
	MobilizeReward = "MobilizeReward",
	MobilizeGetAllReward = "MobilizeGetAllReward",

	New_Player_Enter = "New_Player_Enter",
	New_Player_Train = "New_Player_Train",
	New_Player_Train2 = "New_Player_Train2",
	New_Player_Train_Day1 = "New_Player_Train_Day1",
	New_Player_Train_Day2 = "New_Player_Train_Day2",
	New_Player_Train_Day3 = "New_Player_Train_Day3",
	New_Player_Train_Day4 = "New_Player_Train_Day4",
	New_Player_Train_Day5 = "New_Player_Train_Day5",
	HeroGathering = "HeroGathering",
	HeroGathering2 = "HeroGathering2",

	StageClearChargeEnter = "StageClearChargeEnter",
	StageClearCharge = "StageClearCharge",
	StageClearCharge2 = "StageClearCharge2",

	HatharalComingEnter = "HatharalComingEnter",
	HatharalComing = "HatharalComing",
	HatharalComing2 = "HatharalComing2",
	HatharalComing3 = "HatharalComing3",
	HatharalComing4 = "HatharalComing4",

	HeroComingEnter = "HeroComingEnter", --活动入口按钮红点 --新增活动需新增一个活动入口按钮红点id
	HeroComing = "HeroComing",--活动页签红点 ---新增活动需新增一个活动页签红点id

	HeroComingEnter_Two = "HeroComingEnter_Two", --活动入口按钮红点 --新增活动需新增一个活动入口按钮红点id
	HeroComing_Two = "HeroComing_Two",--活动页签红点 ---新增活动需新增一个活动页签红点id

	
	ActivityOver = "ActivityOver",--活动一览 页签红点

	HeroComing2 = "HeroCominggobtn",--奖励领取红点 --通用
	HeroComing3 = "HeroComingLogin", --每天登录后显示一次红点 --通用
	HeroComing4 = "HeroComingUse", --碎片未使用红点 --通用

	

	Head_New = "Head_New",
	Frame_New = "Frame_New" ,
	Main_Role_Head = "Main_Role_Head", --头像入口
	Role_Head = "Role_Head", 

	Activity_Share = "Activity_Share" , --分享入口
	Activity_Share_Get = "Activity_Share_Get", --分享领取按钮

	--好友
	FriendTogFriend = "FriendTogFriend", --好友标签
	FriendTogHireHero = "FriendTogHireHero", --佣兵标签
	FriendManage = "FriendManage", --好友管理
	FriendApply = "FriendApply", --好友申请
	FriendQuickSendGet = "FriendQuickSendGet", --一键领取赠送

	Maze = "Maze", --征途巨龙建筑

	HireHeroManager = "HireHeroManager", --佣兵管理
	HireHeroApply = "HireHeroApply", --佣兵申请

	HireHeroSuccess = "HireHeroSuccess", --佣兵申请成功

	Activity_News = "Activity_News", --新闻页红点
}

--树 key:节点 value:子节点列表
RedPointDef.Tree =
{
	--领地界面
	[RedPointDef.Id.Territory] = { RedPointDef.Id.Guild, RedPointDef.Id.CardPortal, RedPointDef.Id.RankList,RedPointDef.Id.RootRelation,
		RedPointDef.Id.Crystal, RedPointDef.Id.Temple},
	[RedPointDef.Id.Territory2] = {RedPointDef.Id.Territory},
	--征途界面
	[RedPointDef.Id.Journey] = { RedPointDef.Id.SupplyDepot, RedPointDef.Id.ArenaEnter, RedPointDef.Id.Tower, RedPointDef.Id.Maze,RedPointDef.Id.StoryLineEnter,
	RedPointDef.Id.Realm2},
	[RedPointDef.Id.Journey2] = {RedPointDef.Id.Journey},

	--商城
	[RedPointDef.Id.Mall] = { RedPointDef.Id.MallNormal, RedPointDef.Id.MallLimit, RedPointDef.Id.MallMonthCard , RedPointDef.Id.MallPass},
	[RedPointDef.Id.MallNormal] = { RedPointDef.Id.MallNormalDaily, RedPointDef.Id.MallNormalWeekly, RedPointDef.Id.MallNormalMonthly, RedPointDef.Id.MallNormalGem, RedPointDef.Id.FirstCharge_Second },
	[RedPointDef.Id.MallLimit] = { RedPointDef.Id.MallLimitGrow, RedPointDef.Id.MallLimitSelf,RedPointDef.Id.HappyMonthPanel},
	[RedPointDef.Id.MallLimitGrow] = { RedPointDef.Id.MallLimitGrow2Show, },
	[RedPointDef.Id.MallMonthCard] = { RedPointDef.Id.MallMonthCardMonth, },
	[RedPointDef.Id.MallPass] = {RedPointDef.Id.MallPassTask , RedPointDef.Id.MallPassMaze, RedPointDef.Id.MallPassGuildChaos},
	[RedPointDef.Id.HappyMonthPanel] = {RedPointDef.Id.HappyMonthGet,RedPointDef.Id.HappyMonthBuyTip},
	
	[RedPointDef.Id.MallNormalGem] = { RedPointDef.Id.VIPEnter, },

	[RedPointDef.Id.MallMonthCardMonth] = {
		RedPointDef.Id.MallMonthCardMonthBox1,
		RedPointDef.Id.MallMonthCardMonthBox2,
		RedPointDef.Id.MallMonthCardMonthBox3,
		RedPointDef.Id.MallMonthCardMonthOverdue1,
		RedPointDef.Id.MallMonthCardMonthOverdue2,
		RedPointDef.Id.MallMonthCardMonthFirst,
	},

	--公会
	[RedPointDef.Id.Guild] = { RedPointDef.Id.GuildBoss, RedPointDef.Id.GuildChaos, },
	[RedPointDef.Id.GuildBoss] = { RedPointDef.Id.GuildBossLeftArrow, RedPointDef.Id.GuildBossRightArrow, },
	[RedPointDef.Id.GuildBossLeftArrow] = { RedPointDef.Id.GuildBossChallengeNormal, },
	[RedPointDef.Id.GuildBossRightArrow] = { RedPointDef.Id.GuildBossChallengeHigh, RedPointDef.Id.GuildBossOpenHigh, },
	
	--混沌裂隙
	[RedPointDef.Id.GuildChaos] = { RedPointDef.Id.GuildChaosChallenge, },

	--抽卡
	[RedPointDef.Id.CardPortalNormal] = { RedPointDef.Id.CardPortalNormalOne, RedPointDef.Id.CardPortalNormalTen, },
	[RedPointDef.Id.CardPortalFaction] = { RedPointDef.Id.CardPortalFactionOne, RedPointDef.Id.CardPortalFactionTen, },
	[RedPointDef.Id.CardPortalCompanion] = { RedPointDef.Id.CardPortalCompanionOne, RedPointDef.Id.CardPortalCompanionTen, },

	--排行榜
	[RedPointDef.Id.RankList] = { RedPointDef.Id.Lightbearers_ladder, RedPointDef.Id.Maulers_ladder,RedPointDef.Id.Wilders_laddder,RedPointDef.Id.Graveborn_ladder,RedPointDef.Id.Stage_progression_ladder,RedPointDef.Id.Tower_progression_ladder, },
	[RedPointDef.Id.Lightbearers_ladder] = { RedPointDef.Id.Rank_Award1, },
	[RedPointDef.Id.Maulers_ladder] = { RedPointDef.Id.Rank_Award2, },
	[RedPointDef.Id.Wilders_laddder] = { RedPointDef.Id.Rank_Award3, },
	[RedPointDef.Id.Graveborn_ladder] = { RedPointDef.Id.Rank_Award4, },
	[RedPointDef.Id.Stage_progression_ladder] = { RedPointDef.Id.Rank_Award5, },
	[RedPointDef.Id.Tower_progression_ladder] = { RedPointDef.Id.Rank_Award6, },

	--补给站
	[RedPointDef.Id.SupplyDepot] = {
		RedPointDef.Id.SupplyDepotLevelInfo,
		RedPointDef.Id.SupplyDepotTaskCanGet1,
		RedPointDef.Id.SupplyDepotTaskCanGet2,
		RedPointDef.Id.SupplyDepotTaskCanGet3,
		RedPointDef.Id.SupplyDepotTaskCanGet4,
		RedPointDef.Id.SupplyDepotTaskCanGet5,
		RedPointDef.Id.SupplyDepotTaskCanGet6,
		RedPointDef.Id.SupplyDepotTaskCanGet7,
		RedPointDef.Id.SupplyDepotTaskCanGet8,
		RedPointDef.Id.SupplyDepotTaskCanReward1,
		RedPointDef.Id.SupplyDepotTaskCanReward2,
		RedPointDef.Id.SupplyDepotTaskCanReward3,
		RedPointDef.Id.SupplyDepotTaskCanReward4,
		RedPointDef.Id.SupplyDepotTaskCanReward5,
		RedPointDef.Id.SupplyDepotTaskCanReward6,
		RedPointDef.Id.SupplyDepotTaskCanReward7,
		RedPointDef.Id.SupplyDepotTaskCanReward8,
		RedPointDef.Id.SupplyDepotShip1,
	},
	[RedPointDef.Id.SupplyDepotLevelInfo] = { RedPointDef.Id.SupplyDepotLevelUp, },

	--VIP
	[RedPointDef.Id.VIPEnter] = { RedPointDef.Id.VIP_Get, },

	[RedPointDef.Id.RootRelation] = {RedPointDef.Id.Relation,RedPointDef.Id.Tree},
	[RedPointDef.Id.Relation] = {},
	[RedPointDef.Id.Tree] = {},

	[RedPointDef.Id.Activity] = {RedPointDef.Id.Seven_Login_Enter,RedPointDef.Id.New_Player_Enter,RedPointDef.Id.HeroGathering,RedPointDef.Id.StageClearChargeEnter,RedPointDef.Id.HatharalComingEnter,RedPointDef.Id.HeroComingEnter
	,RedPointDef.Id.ActivityOver},
	
	[RedPointDef.Id.ActivityOver] = {RedPointDef.Id.Activity_News},
	
	[RedPointDef.Id.New_Player_Enter] = {RedPointDef.Id.New_Player_Train,},
	[RedPointDef.Id.New_Player_Train] = {RedPointDef.Id.New_Player_Train2,RedPointDef.Id.New_Player_Train_Day1,RedPointDef.Id.New_Player_Train_Day2,
		RedPointDef.Id.New_Player_Train_Day3,RedPointDef.Id.New_Player_Train_Day4,RedPointDef.Id.New_Player_Train_Day5,
	},
	
	[RedPointDef.Id.Seven_Login_Enter] = {RedPointDef.Id.Seven_Login,},

	[RedPointDef.Id.HeroGathering] = {RedPointDef.Id.HeroGathering2},

	[RedPointDef.Id.StageClearChargeEnter] = {RedPointDef.Id.StageClearCharge},
	[RedPointDef.Id.StageClearCharge] = {RedPointDef.Id.StageClearCharge2},

	[RedPointDef.Id.HatharalComingEnter] = {RedPointDef.Id.HatharalComing},
	[RedPointDef.Id.HatharalComing] = {RedPointDef.Id.HatharalComing2,RedPointDef.Id.HatharalComing3},
	[RedPointDef.Id.HatharalComing2] = {RedPointDef.Id.HatharalComing4},

	[RedPointDef.Id.HeroComingEnter] = {RedPointDef.Id.HeroComing}, --页签红点
	[RedPointDef.Id.HeroComingEnter_Two] = {RedPointDef.Id.HeroComing_Two}, --页签红点

	[RedPointDef.Id.Main_Role_Head] = {RedPointDef.Id.Role_Head},
	[RedPointDef.Id.Role_Head] = {RedPointDef.Id.Head_New,RedPointDef.Id.Frame_New},

	[RedPointDef.Id.Activity_Share] = {RedPointDef.Id.Activity_Share_Get,},

	[RedPointDef.Id.ArenaEnter] = {RedPointDef.Id.List_NormalArena,RedPointDef.Id.List_ProArena,},
	[RedPointDef.Id.List_NormalArena] = {RedPointDef.Id.ArenaRecord,},
	[RedPointDef.Id.List_ProArena] = {RedPointDef.Id.ProArenaRecord,RedPointDef.Id.ProArena_GetCoin},

	--好友
	[RedPointDef.Id.Friend] = { RedPointDef.Id.FriendTogFriend, RedPointDef.Id.FriendTogHireHero, },
	[RedPointDef.Id.FriendTogFriend] = { RedPointDef.Id.FriendManage, RedPointDef.Id.FriendQuickSendGet },
	[RedPointDef.Id.FriendManage] = { RedPointDef.Id.FriendApply, },
	[RedPointDef.Id.FriendTogHireHero] = { RedPointDef.Id.HireHeroManager, },
	[RedPointDef.Id.HireHeroManager] = { RedPointDef.Id.HireHeroApply, RedPointDef.Id.HireHeroSuccess},

	[RedPointDef.Id.Hero] = { RedPointDef.Id.HeroTab,RedPointDef.Id.HeroBook},
	[RedPointDef.Id.Hero2] = {RedPointDef.Id.Hero},

	[RedPointDef.Id.Tower] = {RedPointDef.Id.TowerType0, },

	--命运总动员
	[RedPointDef.Id.MobilizeEnter] = {RedPointDef.Id.MobilizeReward,RedPointDef.Id.MobilizeTask },
}

--有红点时,点击后红点消失,且今日不再出现红点
RedPointDef.TodayNoShow =
{
	-- RedPointDef.Id.CardPortal,
}

--需要检查系统开放的节点,一般填系统的入口
RedPointDef.CheckSystemOpen =
{
	[RedPointDef.Id.Territory] = ModuleOpenDef.SystemOpenType.TerritoryView,
	[RedPointDef.Id.Journey] = ModuleOpenDef.SystemOpenType.Journey,

	[RedPointDef.Id.Territory2] = ModuleOpenDef.SystemOpenType.TerritoryView,
	[RedPointDef.Id.Journey2] = ModuleOpenDef.SystemOpenType.Journey,
	[RedPointDef.Id.Hero2] = ModuleOpenDef.SystemOpenType.HeroRootView,

	[RedPointDef.Id.Guild] = ModuleOpenDef.SystemOpenType.GuildRootView,
	[RedPointDef.Id.GuildChaos] = ModuleOpenDef.SystemOpenType.GuildChaosView,
	[RedPointDef.Id.SupplyDepot] = ModuleOpenDef.SystemOpenType.SupplyDepotView,

	--商城
	[RedPointDef.Id.Mall] = ModuleOpenDef.SystemOpenType.MallRootView,
	[RedPointDef.Id.MallNormalDaily] = ModuleOpenDef.SystemOpenType.MallDaily,
	[RedPointDef.Id.MallNormalWeekly] = ModuleOpenDef.SystemOpenType.MallWeekly,
	[RedPointDef.Id.MallNormalMonthly] = ModuleOpenDef.SystemOpenType.MallMonthly,

	--共鸣水晶
	[RedPointDef.Id.Crystal] = ModuleOpenDef.SystemOpenType.CrystalView,
	--光明圣堂
	[RedPointDef.Id.Temple] = ModuleOpenDef.SystemOpenType.TempleView,
	[RedPointDef.Id.Hero] = ModuleOpenDef.SystemOpenType.HeroRootView,
	[RedPointDef.Id.HeroTab] = ModuleOpenDef.SystemOpenType.HeroRootView,

	--中立塔
	[RedPointDef.Id.Tower] = ModuleOpenDef.SystemOpenType.TowerEntranceView_0,
	--巨龙
	[RedPointDef.Id.Maze] = ModuleOpenDef.SystemOpenType.MazeView,

	[RedPointDef.Id.RootRelation] = ModuleOpenDef.SystemOpenType.RelationMenuRootView_2,
}

return RedPointDef