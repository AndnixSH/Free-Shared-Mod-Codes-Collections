local logic = { event = service.event(), call = service.call(calldef.input) }

function logic:oncreate()
    self.camp = {}
end

function logic.event.game:fire_slot(spriteid, slotid)
    local spriteobj = global.service.pool:get_obj(spriteid)
    spriteobj.caller.skill:fire(slotid)
end

function logic.event.game:targetandfire(spriteid, slotid)
    local spriteobj = global.service.pool:get_obj(spriteid)
    if not spriteobj.caller.skill then return end

    spriteobj.caller.skill:targetfire(slotid)
   
end

function logic.event.game:set_auto_fire(camp, bauto)

    local campcfg = self.camp[camp]
    if not campcfg then 
        campcfg = {}
        self.camp[camp] = campcfg
    end
    campcfg.bauto = bauto
end

function logic.call:getauto(camp)
    local campcfg = self.camp[camp]
    local bauto = campcfg and campcfg.bauto
    return bauto
end

function logic.event.game:move(spriteid, spd)
    local spriteobj = global.service.pool:get_obj(spriteid)
    spriteobj.body:setvelocity(spd)
end

return logic