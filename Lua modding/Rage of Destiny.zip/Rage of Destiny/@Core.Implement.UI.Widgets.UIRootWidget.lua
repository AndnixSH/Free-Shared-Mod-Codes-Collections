local UIRootWidget = UIRootWidget or BaseClass(LuaBasicWidget)
function UIRootWidget:OnLoad()
	local obj = UILayerTool.UIRoot
	self:LoadEnd(obj)
end

function UIRootWidget:LoadEnd(obj)
	self:AddPanel(UIWidgetNameDef.UIRootPanel)
	self:SetGo(obj)
	self:Step(0)
end

function UIRootWidget:OnOpen()
	self:SetDepth(self.go , 0)
	self:SetModelDepth(self.go, 0)
end

return UIRootWidget