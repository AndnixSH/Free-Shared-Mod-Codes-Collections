local bone_camera_anchor = bone_camera_anchor or BaseClass()

local cBoneCameraAnchor = CS.LJY.NX.BoneCameraAnchor

function bone_camera_anchor:__init()
    self.canchor = cBoneCameraAnchor()
end

function bone_camera_anchor:__delete()
    self.canchor = nil
end

-- 未实现
--function bone_ui_anchor:set_delta(delta)
--    if self.canchor then
--        self.canchor:SetDelta(delta)
--    end
--end

return bone_camera_anchor