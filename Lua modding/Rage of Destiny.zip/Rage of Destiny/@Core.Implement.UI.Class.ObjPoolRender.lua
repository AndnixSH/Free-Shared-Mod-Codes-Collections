local ObjPoolRender = PoolRender or BaseClass()

ObjPoolRender.State = 
{
	Free = 0,
	Get = 1,
}

function ObjPoolRender:Load(obj, parent, class, bautoenable)
	self._obj = obj
	self._parent = parent
	self._class = class
	self._obj:SetActive(false)
	if bautoenable == nil or bautoenable == true then
		self._bautoenable = true
	else
		self._bautoenable = false
	end	
	self.pools = {}
	self._getcount = 0
end

function ObjPoolRender:_New(data, ...)
	local obj = GameObjTools.AddChild(self._parent, self._obj)
	if self._bautoenable then
		obj:SetActive(true)
	end	
	local class = self._class.New(obj)
	class.Release = function (class)
		self:Release(class)
	end	
	class._state = ObjPoolRender.State.Get
	class:SetData(data, ...)
	table.insert(self.pools, class)
	return class
end

function ObjPoolRender:Get(data, ...)
	self._getcount = self._getcount + 1
	for _,class in ipairs(self.pools) do
		if class._state == ObjPoolRender.State.Free then
			class._state = ObjPoolRender.State.Get
			class.go:SetActive(true)
			class:SetData(data, ...)
			return class
		end
	end

	return self:_New(data, ...)
end

function ObjPoolRender:GetList(datalist)
	for idx, data in pairs(datalist) do
		self:Get(data, idx)
	end
end

function ObjPoolRender:Release(class)
	if class._state ~= ObjPoolRender.State.Free then
		class._state = ObjPoolRender.State.Free	
		class:Close()
		self._getcount = self._getcount - 1
		if self._bautoenable then
			class.go:SetActive(false)
		end	
	end	
end

function ObjPoolRender:ReleaseAll()
	self._getcount = 0
	for idx, class in ipairs(self.pools) do		
		self:Release(class)
	end	
end

function ObjPoolRender:ExecuteMethod(method, ...)
	for _,class in ipairs(self.pools) do
		if class._state == ObjPoolRender.State.Get and class[method] then
			class[method](class, ...)
		end
	end
end

function ObjPoolRender:Count()
	return self._getcount
end

return ObjPoolRender



