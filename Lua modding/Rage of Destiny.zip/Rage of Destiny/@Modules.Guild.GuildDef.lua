local GuildDef = {}

GuildDef.Parama = {
    Create_Guild_Diamond = 500, --创建公会所需钻石
    Guild_Name_Max_Char = 14, --公会名最大字符
    Guild_Name_Min_Char = 4,--公会名最少字符
    Guild_Announcement_Max_Char = 100,  --公会宣言最大字符 对外
    Guild_Notice_Max_Char = 100, --公会公告最大字符 对内
    Guild_Refresh_Recommend_Cd = 10, --刷新推荐公会cd
    Guild_Change_GuildName_Diamond = 500, --改名消耗钻石
    Guild_Member_Activity_Point_Daily = 100, --每人每日给公会的活跃度
    Guild_Exit_CD = 3600, --退出公会cd
}

GuildDef.Notify = {
    UpdateGuildInfos = "UpdateGuildInfos",
    UpdateRecommendInfos = "UpdateRecommendInfos",
    UpdateHadApplyInfos = "UpdateHadApplyInfos",
    UpdateSearchInfos = "UpdateSearchInfos",
    UpdateApplyInfos = "UpdateApplyInfos",
    UpdateNotice = "UpdateNotice", --更新公告
    UpdateLimit = "UpdateLimit",  --更新入会条件
    UpdateGuildIcon = "UpdateGuildIcon", --更新公会图标
    UpdateGuildName = "UpdateGuildName", --更新公会名
    UpdateAnnouncement = "UpdateAnnouncement", --更新宣言
    UpdateLogInfos = "UpdateLogInfos",
    UpdateOtherGuildInfo = "UpdateOtherGuildInfo", --查看其他协会
    UpdateApplyGuildStatus = "UpdateApplyGuildStatus", --刷新申请公会状态
    UpdateGuildJob = "UpdateGuildJob",  --职位改变
    UpdateDemise = "UpdateDemise", --禅让通知
    UpdateMemberInfosCount = "UpdateMemberInfosCount", --成员添加减少
    UpdateGuildLevelUp = "UpdateGuildLevelUp", --公会等级提升
    UpdatePassedGuild = "UpdatePassedGuild", --被同意加入公會
    UpdateKickOutGuild = "UpdateKickOutGuild", --被踢出工會

    UpdateBossInfo = "UpdateBossInfo",--boss信息
    UpdateBossSweepReward = "UpdateBossSweepReward", --boss扫荡奖励
    UpdateBossRankList = "UpdateBossRankList", --排行榜列表
    UpdateBossRankMy = "UpdateBossRankMy", --排行榜玩家自身
    UpdateBossRankHighest = "UpdateBossRankHighest", --排行榜进度最高玩家
    UpdateBossChallengeBtn = "UpdateBossChallengeBtn", --更新挑战按钮

    UpdateChaosInfo = "UpdateChaosInfo", --基础信息
    UpdateChaosChallengeBtn = "UpdateChaosChallengeBtn", --挑战按钮
    UpdateChaosRecordList = "UpdateChaosRecordList", --挑战记录列表
    UpdateChaosRankList = "UpdateChaosRankList", --全服排行榜列表
}

GuildDef.Job = {
    Persident = 1, --会长
    ViceChairman = 2, --副会长
    Member = 3, --成员

    FearlessHand = 4, --无畏之手
}

GuildDef.ContentInputType = {
    GuildNameType = 1,  --创建公会输入名字
    GuildAnnouncementType = 2, --公会宣言输入名字
    GuildNoticeType = 3,  --公会公告输入字符
}

--翻译文本key
GuildDef.LanguageKey = 
{
    GuildLogoView1 = "GuildLogoView_1001",
    GuildLogoView2 = "GuildLogoView_1002", 
    GuildLogoView3 = "GuildLogoView_1003",  --选中未开启的公会图标
    GuildLogoView4 = "GuildLogoView_1004", 

    ApplyGuildView1 = "ApplyGuildView_1001",

    GuildApplyView1 = "ApplyGuildView_1002",
    
    GuildHallView1 = "GuildHallView_1001",--大厅成员人数
    GuildHallView2 = "GuildHallView_1002",

    GuildEditorView1 = "GuildEditorView_1001",
    GuildEditorView2 = "GuildEditorView_1002",
    GuildEditorView3 = "GuildEditorView_1003",
    GuildEditorView4 = "GuildEditorView_1004",
    GuildEditorView5 = "GuildEditorView_1005",

    GuildEditorView6 = "GuildEditorView_1006",
    GuildEditorView7 = "GuildEditorView_1007",
    GuildEditorView8 = "GuildEditorView_1008",
    GuildEditorView9 = "GuildEditorView_1009",
    GuildEditorView10 = "GuildEditorView_1010",
    GuildEditorView11 = "GuildEditorView_1011",
    GuildEditorView12 = "FriendView_1006",  --举报


    GuildSetView1 = "GuildSetView_1001",
    GuildSetView2 = "GuildSetView_1002",
    GuildSetView3 = "GuildSetView_1003",
    GuildSetView4 = "GuildSetView_1004",

    GuildRecordView1 = "GuildRecordView_1001",  --2
    GuildRecordView2 = "GuildRecordView_1002",  --1
    GuildRecordView3 = "GuildRecordView_1003",--2
    GuildRecordView4 = "GuildRecordView_1004",--3
    GuildRecordView5 = "GuildRecordView_1005",--3
    GuildRecordView6 = "GuildRecordView_1006",--2
    GuildRecordView7 = "GuildRecordView_1007",--2
    GuildRecordView8 = "GuildRecordView_1008",--2
    GuildRecordView9 = "GuildRecordView_1009",--2
    GuildRecordView10 = "GuildRecordView_1010",--2
    GuildRecordView11 = "GuildRecordView_1011",--1
    GuildRecordView12 = "GuildRecordView_1012",

    GuildRecordView13 = "GuildRecordView_1013", --2
    GuildRecordView14 = "GuildRecordView_1014",--2

    GuildBossView1 = "GuildBossView1",
    GuildBossView2 = "GuildBossView2",
    GuildBossView3 = "GuildBossView3",
    GuildBossView4 = "GuildBossView4",
    GuildBossView5 = "GuildBossView5",
    GuildBossView9 = "GuildBossView9",
    GuildBossView10 = "GuildBossView10",
    GuildBossView11 = "GuildBossView11",

    GuildBossRankView1 = "GuildBossRankView1",
    GuildBossRankView2 = "GuildBossRankView2",

    GuildBossResultView1 = "GuildBossResultView1",
    GuildBossResultView2 = "GuildBossResultView2",
    GuildBossResultView3 = "GuildBossResultView3",
    GuildBossResultView4 = "GuildBossResultView4",
    GuildBossResultView5 = "GuildBossResultView5",

    GuildBossChallengeRewardView1 = "GuildBossChallengeRewardView1",
    GuildBossChallengeRewardView2 = "GuildBossChallengeRewardView2",

    GuildChaosView1 = "Chaos_view_1010",
    GuildChaosView2 = "Chaos_view_1011",
    GuildChaosView3 = "Chaos_view_1012",
    GuildChaosView4 = "Chaos_view_1013",
    GuildChaosView5 = "Chaos_view_1014",
    GuildChaosView6 = "Chaos_view_1015",
    GuildChaosView7 = "Chaos_view_1016",
    GuildChaosView8 = "Chaos_view_1017",
    GuildChaosView9 = "Chaos_view_1018",
    GuildChaosView10 = "Chaos_view_1019",
    GuildChaosView11 = "Chaos_view_1020",
    GuildChaosView12 = "Chaos_view_1021",
    GuildChaosView13 = "Chaos_view_1024",
    GuildChaosView14 = "Chaos_view_1025",
    GuildChaosView15 = "Chaos_view_1026",
    GuildChaosView16 = "Chaos_view_1027",
    GuildChaosView17 = "Chaos_view_1028",
    GuildChaosView18 = "Chaos_view_1029",
    GuildChaosView19 = "Chaos_view_1030",
    GuildChaosView20 = "Chaos_view_1031",
    GuildChaosView21 = "Chaos_view_1032",
    GuildChaosView22 = "Chaos_view_1033",
    GuildChaosView23 = "Chaos_view_1034",
    GuildChaosView24 = "Chaos_view_1035",
    GuildChaosView25 = "Chaos_view_1036",
    GuildChaosView26 = "Chaos_view_1037",
}

--日志类型
GuildDef.GuildLogType = {
    EnterGuild = 1,--新成员XXX加入了本公会
    ExitGuild = 2, --XXX离开了本公会
    AppointViceChairman = 3, --公会长将XXX任命为副会长
    PersidentAppointFearlessHand = 4, --公会长XXX将XXX任命为无畏之手
    ViceChairmanAppointFearlessHand = 5, --副会长XXX将XXX任命为无畏之手
    PersidentRetireViceChairman = 6, --公会长取消了XXX副会长
    PersidentRetireFearlessHand = 7, --公会长取消了XXX无畏之手职位
    ExplaceGuild = 8, --公会长将职位禅让给XXX
    PersidentKickOutMember = 9, --公会长将XXX逐出公会
    ViceChairmanKickOutMember = 10, --副会长将XXX逐出公会
    PersidentOpenActivity = 11, --会长XXX开启了活动，大家快去击杀BOSS
    ActivityOver = 12, --活动BOSS已离开！

    ElderAppointElder = 13, --副会长将XXX任命为副会长
    ElderRetireExemplar = 14, --副会长取消了XXX无畏之手职位
}

--日志类型对应翻译文本, 以及有幾個替換名稱 1 使用第一位值 2使用第二位值  3使用两个值  4不适用值
GuildDef.GuildLogInfos = {
    [GuildDef.GuildLogType.EnterGuild] = {GuildDef.LanguageKey.GuildRecordView1, 2},
    [GuildDef.GuildLogType.ExitGuild] = {GuildDef.LanguageKey.GuildRecordView2, 1},
    [GuildDef.GuildLogType.AppointViceChairman] = {GuildDef.LanguageKey.GuildRecordView3, 2},
    [GuildDef.GuildLogType.PersidentAppointFearlessHand] = {GuildDef.LanguageKey.GuildRecordView4, 3},
    [GuildDef.GuildLogType.ViceChairmanAppointFearlessHand] = {GuildDef.LanguageKey.GuildRecordView5, 3},
    [GuildDef.GuildLogType.PersidentRetireViceChairman] = {GuildDef.LanguageKey.GuildRecordView6, 2},
    [GuildDef.GuildLogType.PersidentRetireFearlessHand] = {GuildDef.LanguageKey.GuildRecordView7, 2},
    [GuildDef.GuildLogType.ExplaceGuild] = {GuildDef.LanguageKey.GuildRecordView8, 2},
    [GuildDef.GuildLogType.PersidentKickOutMember] = {GuildDef.LanguageKey.GuildRecordView9, 2},
    [GuildDef.GuildLogType.ViceChairmanKickOutMember] = {GuildDef.LanguageKey.GuildRecordView10, 2},
    [GuildDef.GuildLogType.PersidentOpenActivity] = {GuildDef.LanguageKey.GuildRecordView11, 1},
    [GuildDef.GuildLogType.ActivityOver] = {GuildDef.LanguageKey.GuildRecordView12, 4},
    [GuildDef.GuildLogType.ElderAppointElder] = {GuildDef.LanguageKey.GuildRecordView13, 2},
    [GuildDef.GuildLogType.ElderRetireExemplar] = {GuildDef.LanguageKey.GuildRecordView14, 2},
}


GuildDef.OperateType = {
    EnterApply = 1,  --入会申请
    GuildSetting = 2,  --公会设置
    EditorAnnouncement = 3, --修改公告
    ExitGuild = 4, --退出公会
    RetireGuild = 5, --解散工會

    ExplaceGuild = 6, --禅让会长
    AppointViceChairman = 7, --任命副会长
    RetireViceChairman = 8, --罢免副会长
    AppointFearlessHand = 9, --任命无畏之手
    RetireFearlessHand = 10, --罢免无畏之手
    RetireMember = 11, --踢除成员

    Report = 12, --举报
}

--入会条件类型
GuildDef.ConditionType = {
    NotLimite = 1, --所有人可加入
    NeedAproval = 2, --需要审批加入
    CanNotEnter = 3,  --不收人
}

GuildDef.ConditionTypeStr = {
    [GuildDef.ConditionType.NotLimite] = GuildDef.LanguageKey.GuildSetView1,
    [GuildDef.ConditionType.NeedAproval] = GuildDef.LanguageKey.GuildSetView2,
    [GuildDef.ConditionType.CanNotEnter] = GuildDef.LanguageKey.GuildSetView3,
}

--入会等级类型
GuildDef.LevelType = {
    5,
    10,
    15,
    20,
    25,
    30,
    35,
    40,
    45,
    50,
    55,
    60,
    65,
    70,
    75,
    80,
    85,
    90,
    95,
    100,
}


--公会大厅管理按钮操作权限 操作類型 , 操作名稱翻譯, 方法名
GuildDef.OperateTab = {
    [GuildDef.Job.Persident] = {
        --公会成员只有会长一个人时
        [1] = {
            {GuildDef.OperateType.EnterApply, GuildDef.LanguageKey.GuildEditorView1, "EnterApply"},
            {GuildDef.OperateType.GuildSetting, GuildDef.LanguageKey.GuildEditorView2, "GuildSetting"}, 
            {GuildDef.OperateType.EditorAnnouncement, GuildDef.LanguageKey.GuildEditorView3, "EditorAnnouncement"}, 
            {GuildDef.OperateType.RetireGuild, GuildDef.LanguageKey.GuildEditorView5, "RetireGuild"}, 
        },  
        --公会成员有多人时
        [2] = {
            {GuildDef.OperateType.EnterApply, GuildDef.LanguageKey.GuildEditorView1, "EnterApply"}, 
            {GuildDef.OperateType.GuildSetting, GuildDef.LanguageKey.GuildEditorView2, "GuildSetting"}, 
            {GuildDef.OperateType.EditorAnnouncement, GuildDef.LanguageKey.GuildEditorView3, "EditorAnnouncement"}, 
            {GuildDef.OperateType.ExitGuild, GuildDef.LanguageKey.GuildEditorView4, "ExitGuild"}, 
        },  
    },
    --副会长可操作内容
    [GuildDef.Job.ViceChairman] = {
        {GuildDef.OperateType.EnterApply, GuildDef.LanguageKey.GuildEditorView1, "EnterApply"}, 
        {GuildDef.OperateType.GuildSetting, GuildDef.LanguageKey.GuildEditorView2, "GuildSetting"}, 
        {GuildDef.OperateType.EditorAnnouncement, GuildDef.LanguageKey.GuildEditorView3, "EditorAnnouncement"}, 
        {GuildDef.OperateType.ExitGuild, GuildDef.LanguageKey.GuildEditorView4, "ExitGuild"}, 
    }, 
    --普通成员可操作内容
    [GuildDef.Job.Member] = {
        {GuildDef.OperateType.ExitGuild, GuildDef.LanguageKey.GuildEditorView4, "ExitGuild"}, 
    },  
}

--操作類型 和 操作名稱翻譯
GuildDef.Permission = {
    [GuildDef.Job.Persident] = {
        --任命副会长 任命无畏之手  踢除成员 禅让会长
        [1] = {
            {GuildDef.OperateType.AppointViceChairman, GuildDef.LanguageKey.GuildEditorView7, "AppointViceChairman"}, 
            {GuildDef.OperateType.AppointFearlessHand, GuildDef.LanguageKey.GuildEditorView9, "AppointFearlessHand"}, 
            {GuildDef.OperateType.RetireMember, GuildDef.LanguageKey.GuildEditorView11, "RetireMember"}, 
            {GuildDef.OperateType.ExplaceGuild, GuildDef.LanguageKey.GuildEditorView6, "ExplaceGuild"},
            {GuildDef.OperateType.GuildReport, GuildDef.LanguageKey.GuildEditorView12, "GuildReport"}, 
        },
        --任命副会长 罢免无畏之手  踢除成员 禅让会长
        [2] = {
            {GuildDef.OperateType.AppointViceChairman, GuildDef.LanguageKey.GuildEditorView7, "AppointViceChairman"}, 
            {GuildDef.OperateType.RetireFearlessHand, GuildDef.LanguageKey.GuildEditorView10, "RetireFearlessHand"}, 
            {GuildDef.OperateType.RetireMember, GuildDef.LanguageKey.GuildEditorView11, "RetireMember"}, 
            {GuildDef.OperateType.ExplaceGuild, GuildDef.LanguageKey.GuildEditorView6, "ExplaceGuild"}, 
            {GuildDef.OperateType.GuildReport, GuildDef.LanguageKey.GuildEditorView12, "GuildReport"},
        },
        --罢免副会长 任命无畏之手  踢除成员 禅让会长
        [3] = {
            {GuildDef.OperateType.RetireViceChairman, GuildDef.LanguageKey.GuildEditorView8, "RetireViceChairman"},
            {GuildDef.OperateType.AppointFearlessHand, GuildDef.LanguageKey.GuildEditorView9, "AppointFearlessHand"},
            {GuildDef.OperateType.RetireMember, GuildDef.LanguageKey.GuildEditorView11, "RetireMember"},
            {GuildDef.OperateType.ExplaceGuild, GuildDef.LanguageKey.GuildEditorView6, "ExplaceGuild"},
            {GuildDef.OperateType.GuildReport, GuildDef.LanguageKey.GuildEditorView12, "GuildReport"},
        },
        --罢免副会长 罢免无畏之手  踢除成员 禅让会长
        [4] = {
            {GuildDef.OperateType.RetireViceChairman, GuildDef.LanguageKey.GuildEditorView8, "RetireViceChairman"},
            {GuildDef.OperateType.RetireFearlessHand, GuildDef.LanguageKey.GuildEditorView10, "RetireFearlessHand"},
            {GuildDef.OperateType.RetireMember, GuildDef.LanguageKey.GuildEditorView11, "RetireMember"},
            {GuildDef.OperateType.ExplaceGuild, GuildDef.LanguageKey.GuildEditorView6, "ExplaceGuild"},
            {GuildDef.OperateType.GuildReport, GuildDef.LanguageKey.GuildEditorView12, "GuildReport"},
        },
        --任命无畏之手(对自己操作)
        [5] = {
            {GuildDef.OperateType.AppointFearlessHand, GuildDef.LanguageKey.GuildEditorView9, "AppointFearlessHand"},
        },
        --罢免无畏之手(对自己操作)
        [6] = {
            {GuildDef.OperateType.RetireFearlessHand, GuildDef.LanguageKey.GuildEditorView10, "RetireFearlessHand"},
        },
    },

    [GuildDef.Job.ViceChairman] = {
        --对方是基础成员 任命无畏之手 踢除成员
        [1] = {
            {GuildDef.OperateType.AppointFearlessHand, GuildDef.LanguageKey.GuildEditorView9, "AppointFearlessHand"},
            {GuildDef.OperateType.RetireMember, GuildDef.LanguageKey.GuildEditorView11, "RetireMember"},
            {GuildDef.OperateType.GuildReport, GuildDef.LanguageKey.GuildEditorView12, "GuildReport"},
        },
        --对方是基础成员 罢免无畏之手 踢除成员
        [2] = {
            {GuildDef.OperateType.RetireFearlessHand, GuildDef.LanguageKey.GuildEditorView10, "RetireFearlessHand"},
            {GuildDef.OperateType.RetireMember, GuildDef.LanguageKey.GuildEditorView11, "RetireMember"},
            {GuildDef.OperateType.GuildReport, GuildDef.LanguageKey.GuildEditorView12, "GuildReport"},
        },

        --对方是副会长 任命无畏之手
        [3] = {
            {GuildDef.OperateType.AppointFearlessHand, GuildDef.LanguageKey.GuildEditorView9, "AppointFearlessHand"},
            {GuildDef.OperateType.GuildReport, GuildDef.LanguageKey.GuildEditorView12, "GuildReport"},
        },
        --任命无畏之手(对自己操作)
        [4] = {
            {GuildDef.OperateType.AppointFearlessHand, GuildDef.LanguageKey.GuildEditorView9, "AppointFearlessHand"},
        },
        --罢免无畏之手(对自己操作)
        [5] = {
            {GuildDef.OperateType.RetireFearlessHand, GuildDef.LanguageKey.GuildEditorView10, "RetireFearlessHand"},
        },

    },

    [GuildDef.Job.Member] = {
        [1] = {
            {GuildDef.OperateType.GuildReport, GuildDef.LanguageKey.GuildEditorView12, "GuildReport"},
        } ,
    },  

}

--boss奖励类型
GuildDef.BossRewardType = {
    Challenge = 1,   --挑战奖励
    Finish = 2,      --通关奖励
}

--boss类型
GuildDef.BossType = {
    Normal = 1,   --普通
    High = 2,     --高级
}

--boss高级开启状态
GuildDef.BossHighState = {
    NoOpen = 0,  --未开启
    Open = 1,    --已开启
}

return GuildDef