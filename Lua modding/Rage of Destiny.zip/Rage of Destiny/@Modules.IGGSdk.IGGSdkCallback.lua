IGGSdkCallback = {}

---快速登录成功
local function OnLoginSuccess(iggSession)
    print("IGGSdkCallback----------->>>OnLoginSuccess")
   	local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
    IGGSdkProxy.Instance:OnLoginSuccess(iggSession)
end

local function OnLoginFail(iggError)
    print("IGGSdkCallback----------->>>OnLoginFail")
    local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
    IGGSdkProxy.Instance:OnLoginFail(iggError)
end

-- 账号禁止操作的处理（如：封号）
local function OnAccountNotAllowOperation()
    print("IGGSdkCallback----------->>>OnAccountNotAllowOperation")
    -- local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
    -- IGGSdkProxy.Instance:OnAccountNotAllowOperation()
end

-- 本地session过期 
local function OnSessionInvalidated()
    print("==========OnSessionInvalidated==========")
    local parenWidget = LuaLayout.Instance:GetWidget(UIWidgetNameDef.Root_IGG)
    local rootObj = parenWidget.go
    local obj1 = GameObjTools.GetChild(rootObj,"AccountUIProfileManagementPanelYellowG")
    if obj1 then
        obj1:SetActive(false)
    end

    local obj2 = GameObjTools.GetChild(rootObj,"AccountManagerBindItemYellowG")
    if obj2 then
        obj2:SetActive(false)
    end
    local obj3 = GameObjTools.GetChild(rootObj,"AccountUIAccountSwitchingPanelYellowG")
    if obj3 then
        obj3:SetActive(false)
    end

    local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.LoginView)
     if view then
         view.bLoginType = false
         view:OpenView()
     end
end

-- 切换账号失败
local function OnSwitchAccountFailed(error)
    print("IGGSdkCallback----------->>>OnSwitchAccountFailed")
end

-- 切换账号成功
local function OnSwitchAccountSuccess(iggSession)
    print("IGGSdkCallback----------->>>OnSwitchAccountSuccess", iggSession:GetIGGId())
    local parenWidget = LuaLayout.Instance:GetWidget(UIWidgetNameDef.Root_IGG)
    local rootObj = parenWidget.go
    local obj1 = GameObjTools.GetChild(rootObj,"AccountUIProfileManagementPanelYellowG") 
    if obj1 then
        obj1:SetActive(false)
    end

    local obj2 = GameObjTools.GetChild(rootObj,"AccountManagerBindItemYellowG") 
    if obj2 then
        obj2:SetActive(false)
    end
    local obj3 = GameObjTools.GetChild(rootObj,"AccountUIAccountSwitchingPanelYellowG")
    if obj3 then
        obj3:SetActive(false)
    end
    LuaMain.ReBoot()
end

-- 绑定账号成功
local function OnBinded()
    print("IGGSdkCallback----------->>>OnBinded")
end

-- 绑定账号失败
local function OnBindingFailed()
    print("IGGSdkCallback----------->>>OnBindingFailed")
end

-- 加载IGG商品列表成功
local function OnProductsLoaded(products)
    print("IGGSdkCallback----------->>>OnProductsLoaded")
    local MallProxy = require "Modules.Mall.MallProxy"
    
    local temp = {}
    for i=0,products.Count-1 do
    	local product = products[i]
    	local id = product:GetId()

    	-- id = tonumber(id)
    	temp[id] = product
    	-- print(id, product:GetTypeValue(), type(product:GetId()))
    end
    MallProxy.Instance:SetProducts(temp)
end

-- 加载IGG商品列表失败
local function OnProductsLoadFail(error)
    print("IGGSdkCallback----------->>>OnProductsLoadFail:" .. error:GetCode())
    local MallProxy = require "Modules.Mall.MallProxy"
	MallProxy.Instance:ClearProducts()
end

-- 购买或者订阅成功
local function OnPayOrSubscribeToSuccess()
    print("IGGSdkCallback----------->>>OnPayOrSubscribeToSuccess")
    local MallDef = require "Modules.Mall.MallDef"
    GameLogicTools.ShowMsgTips(MallDef.LanguageKey.MallSdk2)
end

-- 购买或者订阅失败
local function OnPayOrSubscribeToFailed(error)
    print("IGGSdkCallback----------->>>OnPayOrSubscribeToFailed:" .. error:GetCode())
    local MallDef = require "Modules.Mall.MallDef"
    GameLogicTools.ShowMsgTips(MallDef.LanguageKey.MallSdk3)

    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.BlockView)
end

-- 发起支付或订阅前期准备失败（一般时谷歌或Appstore支付服务有问题）
local function OnPayOrSubscribeToStartingFailed(error)
    print("IGGSdkCallback----------->>>OnPayOrSubscribeToStartingFailed:" .. error:GetCode())
    local MallDef = require "Modules.Mall.MallDef"
    GameLogicTools.ShowMsgTips(MallDef.LanguageKey.MallSdk4)

    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.BlockView)
end

--返回所有后台配置的协议
local function OnRequestAssignedAgreements(agreements)
    
    print("IGGSdkCallback----------->>>OnRequestAssignedAgreements=",agreements.Agreements.Count)
    local agreementsList = {}
   
    for _ , v in pairs(agreements.Agreements) do
        if v.Type ~= 3 then
            local Item = {}
            Item.ID = v.ID
            Item.URL = v.URL
            Item.LocalizedName = v.LocalizedName
            table.insert(agreementsList,Item)
        end
    end
    local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.SecondChooseView)
    if view then
        view.data = {}
        local LanguageManager = require "Common.Mgr.Language.LanguageManager"
        view.data.btnList = agreementsList
        view.data.title = LanguageManager.Instance:GetWord("SettingMenuView_1015")
        view:OpenView()
    end
end

-- 取消购买或者订阅
local function OnPayOrSubscribeToCancel()
    print("IGGSdkCallback----------->>>OnPayOrSubscribeToCancel")
    local MallDef = require "Modules.Mall.MallDef"
    GameLogicTools.ShowMsgTips(MallDef.LanguageKey.MallSdk6)

    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.BlockView)
end

-- 已订阅
local function OnFailedForHasSubscribe()
    print("IGGSdkCallback----------->>>OnFailedForHasSubscribe")

    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.BlockView)
end

-- 该商品在这个谷歌（苹果）账号上以为其他IGGID订阅，请换成消耗类商品订阅
local function OnIGGSubscriptionShouldMakeRecurringPaymentsInsteadFail(message)
    print("IGGSdkCallback----------->>>OnIGGSubscriptionShouldMakeRecurringPaymentsInsteadFail")
    local MallDef = require "Modules.Mall.MallDef"
    GameLogicTools.ShowMsgTips(MallDef.LanguageKey.MallSdk5)

    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.BlockView)
end

-- 打开TSH弹窗
local function OnOpenTSHDialog(message)
    print("IGGSdkCallback-------------->>OnOpenTSHDialog: ", message)
    GameLogicTools.ShowConfirmById(32, function(bValue)
        if bValue then
            local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
            IGGSdkProxy.Instance:ShowTSHPanel()
        end
    end, message)
end

---TSH 未读消息条数
local function OnUnreadMessageCount(count)

end

-- 打开webView
local function OnOpenWebView(url)

    if url ~= "" then
        local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
        IGGSdkProxy.Instance:ShowUniWebView(url)
    end
end

-- 举报相关
local function OnReportResult(error)
    
    local LanguageManager = require "Common.Mgr.Language.LanguageManager"
    local RoleInfoDef =require "Modules.RoleInfo.RoleInfoDef"
    if error:IsOccurred() then
        local message = ""
        local error_code = "(Error: " .. error:GetCode() .. ")"
        GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord(error_code))
        return
    end
    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ReportView)
    GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord(RoleInfoDef.CommonDef.ReportSuccess))
    -- show success
end

-- 评星相关
local function OnRatingResult(error)
    print("IGGSdkCallback==================>>OnRatingResult")
    if error then
        local error_code = error:GetCode()
        if error_code == "310112" or error_code == "310113" then
            local RoleInfoDef = require "Modules.RoleInfo.RoleInfoDef"
            local RoleInfoProxy = require "Modules.RoleInfo.RoleInfoProxy"
            RoleInfoProxy.Instance:Send10027(RoleInfoDef.Sop_Award_Type.Rating_Award)
        end
    end
end

local function OnRatingCloseClick()
    print("OnRatingCloseClick==============>>")

end

local function OnRatingUnlikeClick()
    print("OnRatingUnlikeClick==============>>")
    local RoleInfoProxy = require "Modules.RoleInfo.RoleInfoProxy"
    local RoleInfoDef = require "Modules.RoleInfo.RoleInfoDef"

    --点击不喜欢发评星奖励
    RoleInfoProxy.Instance:Send10027(RoleInfoDef.Sop_Award_Type.Rating_Award)
end

local function OnRatingLikeClick()
    print("OnRatingLikeClick==============>>")
    local RoleInfoProxy = require "Modules.RoleInfo.RoleInfoProxy"
    local RoleInfoDef = require "Modules.RoleInfo.RoleInfoDef"

    --点击喜欢发评星奖励
    RoleInfoProxy.Instance:Send10027(RoleInfoDef.Sop_Award_Type.Rating_Award)
end

--- 翻译相关
---成功
local function OnTranslateSuccess(result)
    print("-------OnTranslateSuccess-------")
    local translation = result:GetByIndex(0)
    local str = translation:GetText()
    local  SourceLanguage = translation:GetSourceLanguage()
    print("-------OnTranslateSuccess--3-----",str,SourceLanguage)
    local ChatProxy = require "Modules.Chat.ChatProxy"
    ChatProxy.Instance:TranslatingEnd(str,SourceLanguage)
   
end

---失败
local function OnTranslateFailed(error)
    print("-------OnTranslateFailed-------")
    local LanguageManager = require "Common.Mgr.Language.LanguageManager"
    local ChatProxy = require "Modules.Chat.ChatProxy"
    ChatProxy.Instance:TranslatingEnd("")
    --GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord("翻译失败"))
end

---Facebook 分享链接成功
local function OnFacebookShareLinkSuccess()
    local ActivityDef = require "Modules.Activity.ActivityDef"
    local LanguageManager = require "Common.Mgr.Language.LanguageManager"
    GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord(ActivityDef.CommonDef.Share_Success))
end

---Facebook 分享链接失败
local function OnFacebookShareLinkFailed()

    local ActivityDef = require "Modules.Activity.ActivityDef"
    local LanguageManager = require "Common.Mgr.Language.LanguageManager"
    GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord(ActivityDef.CommonDef.Share_Faild))
end

---Facebook 取消分享链接
local function OnFacebookShareLinkCancelled()

    local ActivityDef = require "Modules.Activity.ActivityDef"
    local LanguageManager = require "Common.Mgr.Language.LanguageManager"
    GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord(ActivityDef.CommonDef.Share_Cancel))
end

-- 获取WebSSOToken
local function OnRequestWebSSOTokenComplete(iggError, webSSOToken)
    local code = iggError:GetCode()
    -- print("OnRequestWebSSOTokenComplete--------:", type(code), webSSOToken)
    if code == "0" then
        local SettingMenuProxy = require "Modules.SettingMenu.SettingMenuProxy"
        SettingMenuProxy.Instance:SetSSOTokeState(true, webSSOToken)
    end
end

IGGSdkCallback.OnLoginSuccess = OnLoginSuccess
IGGSdkCallback.OnLoginFail = OnLoginFail
IGGSdkCallback.OnAccountNotAllowOperation = OnAccountNotAllowOperation
IGGSdkCallback.OnSessionInvalidated = OnSessionInvalidated

IGGSdkCallback.OnProductsLoaded = OnProductsLoaded
IGGSdkCallback.OnProductsLoadFail = OnProductsLoadFail
IGGSdkCallback.OnPayOrSubscribeToSuccess = OnPayOrSubscribeToSuccess
IGGSdkCallback.OnPayOrSubscribeToFailed = OnPayOrSubscribeToFailed
IGGSdkCallback.OnPayOrSubscribeToStartingFailed = OnPayOrSubscribeToStartingFailed
IGGSdkCallback.OnPayOrSubscribeToCancel = OnPayOrSubscribeToCancel
IGGSdkCallback.OnFailedForHasSubscribe = OnFailedForHasSubscribe

IGGSdkCallback.OnIGGSubscriptionShouldMakeRecurringPaymentsInsteadFail = OnIGGSubscriptionShouldMakeRecurringPaymentsInsteadFail

IGGSdkCallback.OnRequestAssignedAgreements = OnRequestAssignedAgreements

IGGSdkCallback.OnSwitchAccountFailed = OnSwitchAccountFailed
IGGSdkCallback.OnSwitchAccountSuccess = OnSwitchAccountSuccess
IGGSdkCallback.OnBinded = OnBinded
IGGSdkCallback.OnBindingFailed = OnBindingFailed

IGGSdkCallback.OnOpenTSHDialog = OnOpenTSHDialog
IGGSdkCallback.OnUnreadMessageCount = OnUnreadMessageCount
IGGSdkCallback.OnOpenWebView = OnOpenWebView

IGGSdkCallback.OnReportResult = OnReportResult

IGGSdkCallback.OnRatingResult = OnRatingResult
IGGSdkCallback.OnRatingLikeClick = OnRatingLikeClick
IGGSdkCallback.OnRatingUnlikeClick = OnRatingUnlikeClick
IGGSdkCallback.OnRatingCloseClick = OnRatingCloseClick

IGGSdkCallback.OnTranslateSuccess = OnTranslateSuccess
IGGSdkCallback.OnTranslateFailed = OnTranslateFailed

IGGSdkCallback.OnFacebookShareLinkSuccess = OnFacebookShareLinkSuccess
IGGSdkCallback.OnFacebookShareLinkFailed = OnFacebookShareLinkFailed
IGGSdkCallback.OnFacebookShareLinkCancelled = OnFacebookShareLinkCancelled

IGGSdkCallback.OnRequestWebSSOTokenComplete = OnRequestWebSSOTokenComplete