BaseProxy = BaseProxy or BaseClassEx({NxNetFactor, 0}, {NxProxyDataSetFactor,0}, {FaceProxy,1,0})

--mediator之间的消息派发
function BaseProxy:SendFacedeNotify(notifyDef)
	self:ToNotify(self.data ,self.proxyName ,notifyDef)
end


