local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local CToggleRender = require "Core.Implement.UI.Class.CToggleRender"
local RelationDef=require "Modules.Relation.RelationDef"
local AudioManager = require "Common.Mgr.Audio.AudioManager"
local TreeProxy = require "Modules.Tree.TreeProxy"
local RelationProxy = require "Modules.Relation.RelationProxy"
local ModuleManager = require "Common.Mgr.UI.ModuleManager"
local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
local RedPointDef = require "Modules.RedPoint.RedPointDef"
local RelationMenuRootView = RelationMenuRootView or LuaWidgetClass()

function RelationMenuRootView:__init()
    self.fullScreenOption = { onclosefunc = function () self:OnClickClose() end }
end

function RelationMenuRootView:OnLoad()
	self.Index= self.init_index or 1
	AssetManager.LoadUIPrefab(self, "Relation.RelationMenuRootView",self.LoadEnd)
end

function RelationMenuRootView:LoadEnd(obj)
	self:SetGo(obj)
	self:Init(obj)
	self:SetStep(0)
	
end

function RelationMenuRootView:Init(obj)

 --    self.helpBtn=self:GetChildComponent(obj,"root/CButton_help","CButton")
	-- self.helpBtn:AddClick(function ( )
 --        LuaLayout.Instance:OpenWidget(UIWidgetNameDef.MyAidView)
 --    end)

    local togGroup = self:GetChildComponent(obj, "yeqian/CTogglePage", "CToggleGroup")

	self.togRender = CToggleRender.New()
	self.togRender:Load(togGroup, 1,true)
	self.togRender:AddSelect(function(index)
		local bopen = ModuleManager.SystemIsOpen(RelationDef.ModuleOpenType[index])
		if bopen then
			self:OnTogChange(index)
		elseif index ~= self.Index then
			 self.togRender:SelectIndex(self.Index)
		end
	end)

	self.red_objs = {}
	for i=1,#RelationDef.Btn do
		self.togRender:Add()
		self.togRender:SetNormalInfo(i, LanguageManager.Instance:GetWord(RelationDef.Btn[i]), RelationDef.BtnIcon[i])
		self.togRender:SetSelectInfo(i, LanguageManager.Instance:GetWord(RelationDef.Btn[i]), RelationDef.BtnIcon[i])
		self.togRender:SetLock(i, false)
		self.togRender:SetViewOpen(i, true)

		if i == 1 then
			RedPointProxy.Instance:BindNode(RedPointDef.Id.Relation_3,self.togRender:GetRedObj(i))
		end
		table.insert(self.red_objs,self.togRender:GetRedObj(i))
	end

	local tt = self:GetChildComponent(obj,"root","RectTransform")
	local  ss  = 1157 --tt.rect.width
	local pos = tt.localPosition
	local screen = UILayerTool.CurrentScreen()
	local aa = ss / UILayerTool.STANDARD_WIDTH *screen.width
	tt.anchorMin =  Vector2.New(0.5, 0.5)
    tt.anchorMax =  Vector2.New(0.5, 0.5)
	tt.localPosition = pos
	tt.sizeDelta =Vector2.New(((aa- ss)/2 + ss) ,tt.rect.height) 

end 
function RelationMenuRootView:OnTogChange(index)
	local view = LuaLayout.Instance:GetWidget(RelationDef.OpenViews[self.Index])
	local fullScreenView = LuaLayout.Instance:GetWidget(UIWidgetNameDef.FullScreenView)
	if view:IsOpen() then
		LuaLayout.Instance:CloseWidget(RelationDef.OpenViews[self.Index])
	end
	if RelationDef.OpenViews[index] and RelationDef.OpenViews[index] ~= "" then
		LuaLayout.Instance:OpenWidget(RelationDef.OpenViews[index])
		--初始化时 fullScreenView 还没加载 跑不进来 所以是用配置里默认的，之后的切页才会跑这里
		if fullScreenView and fullScreenView:IsOpen() then
			fullScreenView:UpdateTitleName(self:GetWord(RelationDef.Btn[index]))
			fullScreenView:UpdateExplainIndex(index)
			fullScreenView:Updatebackground(RelationDef.FullScreenViewBg[index])
		end
	end
	self.Index=index
end

function RelationMenuRootView:OnOpen()

	self:AutoRegister()
	self:UpdateView()
	if self.togRender then
		self.togRender:SelectIndex(1)
	end
	self.togRender:ShowNewOpenTween()
	-- self.helpBtn:ShowRedTip(RelationProxy.Instance:CheckShowAidRedDot())
	-- AudioManager.PlayBGM("jiban_bg")
end

-- function RelationMenuRootView.EvtNotify.Relation.data:Relation_UpdateAidRedDot(data,info)
	
-- 	self.helpBtn:ShowRedTip(RelationProxy.Instance:CheckShowAidRedDot())
-- end

function RelationMenuRootView:UpdateView()
	self:UpdateTreeTogRed()
end

function RelationMenuRootView:UpdateTreeTogRed()
	-- Tree red
	local new_water_red = TreeProxy.Instance:CheckWaterInfo()
    local red_count = RedPointProxy.Instance:GetNodeNum(RedPointDef.Id.Tree)
	local ModuleManager = require "Common.Mgr.UI.ModuleManager"
	local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
    local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.Tree,false)
    local tree_red = (red_count > 0 or new_water_red) and bopen
    self.red_objs[2]:SetActive(tree_red)
end

function RelationMenuRootView.EvtNotify.Tree.data:UpdateTree()
	self:UpdateTreeTogRed()
end

function RelationMenuRootView.EvtNotify.Tree.data:UpdateTreeNewHeroInfo(data, water_info)
	self:UpdateTreeTogRed()
end


function RelationMenuRootView:OnClickClose()
	local bDestory=false
	local view =LuaLayout.Instance:GetWidget(RelationDef.OpenViews[self.Index])
	if view:IsOpen() then
		LuaLayout.Instance:CloseWidget(RelationDef.OpenViews[self.Index])
	end
    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.RelationMenuRootView,bDestory)
end

function RelationMenuRootView:OnClose()
	self:AutoUnRegister()
	local callback = RelationProxy.Instance:GetCallBack()
	if not callback  then
		local TerritoryProxy = require "Modules.Territory.TerritoryProxy"
		TerritoryProxy.Instance:GoBack()
	else
		callback()
	end
end

function RelationMenuRootView:OnDestroy()
	self:AutoUnRegister()
end

return RelationMenuRootView
