local logic = { call = service.call(calldef.buff), event = service.event(), timer = {} }

local BUFF_TYPE = {
    LOGIC = 1,
    SCRIPT = 2,
    EMPTY = 3,
}

function logic:oncreate()
    self._buffid = {}
    self._buffreplace = {} -- buff替换列表
    self._isreplace = {} -- buff替换确认（确认更新buff
    self._buffstate = {}

    -- self:_addstartbuff()
    self.timer:delay(0, self._addstartbuff) -- 延迟一帧添加，以防skill是空
end

function logic:_addstartbuff()
    local buff_list = self.owner.prop.buff_list 
    if buff_list then
        for i, buffid in ipairs(buff_list) do
            self.call.add(self, buffid)
        end
    end
end

function logic.call:getreplace(typeid)
    return self._buffreplace[typeid]
end

function logic:getconfig(typeid)
    return self.service.config:get("buff_static")[typeid]
end

function logic:getviewscript(typeid)
    local config = self:getconfig(typeid)
    return config and config.view_script
end

function logic:show_merge_view(typeid)
    local config = self:getconfig(typeid)
    return config and config.disable_merge_view == nil
end

-- 检查是否触发
function logic:checktrigger(typeid, fromobj)
    local config = self:getconfig(typeid)
    if config and config.resist then
        local result = not self.service.area:filter_target(fromobj, self.owner, table.unpack(config.resist))
        if not result then
            self:sendmessage(eventdef.buff_resist, { buffid = typeid, config = config })
        end
        return result
    end
    return true
end

function logic.call:add_state(key, value)
    self._buffstate[key] = value or true
end

function logic.call:get_state(key)
    return self._buffstate[key]
end

function logic.call:remove_state(key)
    self._buffstate[key] = nil
end

function logic.call:contains_state(key)
    return self._buffstate[key]
end

-- 判断是否是stateid的状态buff
function logic.call:isstate(typeid, stateid)
    local config = self:getconfig(typeid)
    if config and config.class == 2 then
        local statelist = config.args_script[1]
        if statelist then
            for i, v in ipairs(statelist) do
                if v == stateid then
                    return true
                end
            end
        end
    end
    return false
end

-- 获取buff的group标签
function logic.call:getgroup(typeid)
    local config = self:getconfig(typeid)
    if config and config.group then
        return config.group
    end
    return false
end

-- 是否包含buff的group标签
function logic.call:hasgroup(typeid, grouptag)
    local config = self:getconfig(typeid)
    if config and config.group then
        for _, tag in ipairs(config.group) do
            if tag == grouptag then
                return true
            end
        end
    end
    return false
end

-- 添加buff
function logic.call:add(typeid, fromobj)

    local buffid = self._buffreplace[typeid] or typeid
    if typeid == buffid and fromobj then
        buffid = fromobj.caller.buff:getreplace(typeid) or buffid
    end

    if self:checktrigger(buffid, fromobj) then
        self:_start_buff(typeid, buffid, fromobj, true) -- mainbuff
        if self:checktrigger(buffid*10, fromobj) then
            self:_start_buff(typeid*10, buffid*10, fromobj)    -- subbuff
        end
    end
end

-- 添加buff列表
function logic.call:addlist(typeidlist, fromobj)
    for i, typeid in ipairs(typeidlist) do
        self.call.add(self, typeid, fromobj)
    end
end

-- 添加指定层数buff
function logic.call:addlevel(typeid, level, fromobj)
    for i = 1, level do
        self.call.add(self, typeid, fromobj)
    end
end

function logic:_start_buff(typeid, buffid, fromobj, allowempty)

    local buff = self._buffid[typeid]
    if buff and typeid ~= buffid and self._isreplace[typeid] ~= buffid then
        self.call.remove(self, typeid)
        buff = nil
    end

    if not buff then
        local buff, bufftype = self:_create_buff(buffid, fromobj, allowempty)
        if not buff then return end -- 创建buff不成功返回

        self._buffid[typeid] = buff
        self._isreplace[typeid] = buffid
        if bufftype == BUFF_TYPE.LOGIC then
            buff.cbend = function () self:buffend(typeid, buffid) end
            buff:start(fromobj)
        elseif bufftype == BUFF_TYPE.SCRIPT then
            buff.cbend = function () self:buffend(typeid, buffid) end
            buff:start(nil, { fromobj = fromobj })
        end
        if not buff.isrun or buff:isrun() then
            self:sendmessage(eventdef.buff_start, buffid)
            local view_script = self:getviewscript(buffid)
            if view_script then
                self.caller.view:start_view(buffid, view_script)
            end
        end
    elseif buff.merge then
        buff:merge()
        self:sendmessage(eventdef.buff_start, buffid)
        local view_script = self:getviewscript(buffid)
        if view_script and self:show_merge_view(buffid) then
            self.caller.view:start_view(buffid, view_script, buff:getlevel())
        end
    end

    gamelog.level(3).sprite(self.owner, "buff_start", typeid, buffid, fromobj or self.owner)

end

function logic:_create_buff(buffid, fromobj, allowempty)
    local buff, bufftype = nil, nil
    local staticconf = self:getconfig(buffid)
    if staticconf and staticconf.class then
        local buffpath = "sprite.buff.".. BUFF.CLASS[staticconf.class]
        local template = self.service.requirer:require(buffpath)
        local bufflogic = self.service.logic_factory:createlogic(self.owner, buffid, staticconf, nil, template)
        buff = assert(bufflogic.buff)
        bufftype = BUFF_TYPE.LOGIC
    else
        local script_table = self.service.scriptengine_v2:loadscripttable("role_"..self.owner.typeid, "buff", buffid, fromobj and "role_"..fromobj.typeid)
        if script_table then
            buff = self.service.scriptengine_v2:create(self.owner, script_table, nil, staticconf)
            bufftype = BUFF_TYPE.SCRIPT
        elseif allowempty then
            buff = {}
            bufftype = BUFF_TYPE.EMPTY
        end
    end
    return buff, bufftype
end

function logic:buffend(typeid, buffid)
    gamelog.level(3).sprite(self.owner, "buff_stop", buffid)
    self:sendmessage(eventdef.buff_stop, buffid)
    local view_script = self:getviewscript(buffid)
    if view_script then
        self.caller.view:stop_view(buffid)
    end
    self._buffid[typeid]:destroy()
    self._buffid[typeid] = nil

    local subbuffid = typeid*10
    if self._buffid[subbuffid] then
        self.call.remove(self, subbuffid)
    end
end

-- 移除buff
function logic.call:remove(typeid)
    local buff = self._buffid[typeid]
    if buff and buff.stop then
        buff:stop()
    end
    self._buffid[typeid] = nil
end

-- 移除buff列表
function logic.call:removelist(typeidlist)
    if typeidlist then
        for i, typeid in ipairs(typeidlist) do
            self.call.remove(self, typeid)
        end
    end
end

function logic.call:has(typeid)
    return self._buffid[typeid] and true or false
end

-- 是否包含buff
function logic.call:contains(typeid)
    return self._buffid[typeid] and true or false
end

-- 是否包含某种类型buff 1 增益 2 减益
function logic.call:contains_type(type)
    local buff_list = self.call.getallbuff(self)
    for i, buffid in ipairs(buff_list) do
        local conf = self:getconfig(buffid)
        if conf and conf.type == type then
            return true
        end
    end
    return false
end

-- 获取所有某种类型的buff
function logic.call:getalltypebuff(type)
    local bufflist = {}
    local buff_list = self.call.getallbuff(self)
    for _, buffid in ipairs(buff_list) do
        local conf = self:getconfig(buffid)
        if conf and conf.type == type then
            table.insert(bufflist, buffid)
        end
    end
    table.sort(bufflist)
    return bufflist
end

-- 获取buff层数
function logic.call:getlevel(typeid)
    local buff = self._buffid[typeid]
    if buff and buff.getlevel then
        return buff:getlevel() or 0
    end
    return 0
end

-- buff是否最大层数
function logic.call:maxlevel(typeid)
    local buff = self._buffid[typeid]
    if buff and buff.getlevel then
        local maxlevel = self:getconfig(typeid).maxlevel
        return buff:getlevel() == maxlevel 
    end
end

-- 获取buff最大层数
function logic.call:getmaxlevel(typeid)
    return self:getconfig(typeid).maxlevel or 0
end

-- 是否不包含buff
function logic.call:notcontains(typeid)
    return not self._buffid[typeid]
end

-- 是否包含任意一个bufflist中的buff
function logic.call:any(bufflist)
    for _, buffid in ipairs(bufflist) do
        if self._buffid[buffid] then
            return buffid
        end
    end
end

-- 是否包含所有bufflist中的buff
function logic.call:all(bufflist)
    if #bufflist == 0 then return false end
    for _, buffid in ipairs(bufflist) do
        if not self._buffid[buffid] then
            return false
        end
    end
    return true
end

-- 替换buffid
function logic.call:replace(fromid, toid)
    self._buffreplace[fromid] = toid
end

-- 驱散
function logic.call:disperse(type, count, fromobj)
    local buff_list = self.call.getallbuff(self)
    local iter = 0

    local _type, _typearg = table.unpack(type)
    local disperse_list = {}

    for i, buffid in ipairs(buff_list) do

        if not count or iter < count then

            local remove = false
            local conf = self:getconfig(buffid)

            if not conf or conf.disperse == 1 then
                if _type == 1 then     -- type
                    remove = (_typearg == 0) or (conf and conf.type == _typearg)
                elseif _type == 2 then -- group
                    remove = conf and conf.group == _typearg
                end

                if remove then
                    self.call.remove(self, buffid)
                    table.insert(disperse_list, { buffid = buffid, bufftype = conf.type })
                    iter = iter + 1
                end
            end
        end
    end

    if #disperse_list > 0 then
        self:sendmessage(eventdef.buff_disperse, { fromobj = fromobj, toobj = self.owner, count = #disperse_list, disperse_list = disperse_list })
    end
end

-- 缩短buff
function logic.call:shorten(typeid, rate)
    rate = rate or 1000
    local buff = self._buffid[typeid]
    if buff and buff.shorten then
        buff:shorten(rate)
    end
end

-- 重置时间
function logic.call:reset_time(typeid)
    local buff = self._buffid[typeid]
    if buff and buff.reset_time then
        buff:reset_time()
    end
end

function logic.call:getallbuff()
    local bufflist = {}
    for buffid, _ in pairs(self._buffid) do
        table.insert(bufflist, buffid)
    end
    table.sort(bufflist)

    return bufflist

end

function logic.event.sprite:sprite_dead()
    self.timer:delay(0, self._removeall) -- 延迟一帧移除，以防buff上的精灵死亡事件监听不到
end

function logic.event.game.public:gameclear()
    local bufflist = self.call.getallbuff(self)
    for _, buffid in ipairs(bufflist) do
        local view_script = self:getviewscript(buffid)
        if view_script then
            self.caller.view:stop_view(buffid)
        end
    end
end

function logic:_removeall()
    if self._clear then return end
    self._clear = true
    local bufflist = self.call.getallbuff(self)
    for _, buffid in ipairs(bufflist) do
        self.call.remove(self, buffid)
    end
end

function logic.call:add_timemdf(type, time)
    self._timemdf = self._timemdf or {}
    self._timemdf[type] = (self._timemdf[type] or 0) + time
end

function logic.call:remove_timemdf(type, time)
    if self._timemdf and self._timemdf[type] then
        self._timemdf[type] = self._timemdf[type] - time
    end
end

function logic.call:get_timemdf(type)
    if self._timemdf then
        return self._timemdf[type]
    end
end

function logic.call:add_amendment_static(type, amendment_static)
    self._amendment = self._amendment or {}
    self._amendment[type] = amendment_static
end

function logic.call:remove_amendment_static(type)
    self._amendment[type] = nil
end

function logic.call:get_amendment_static(type)
    return self._amendment and self._amendment[type]
end

return logic