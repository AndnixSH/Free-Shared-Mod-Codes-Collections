local logic = {timer = {}}

function logic.timer:f1()
    local target = self.prop.target 
    if target and target.caller.state and not target.caller.state:isdead() then
        
        local header = target.body.position - self.owner.body.position
        local distance = tsvector.distance(target.body.position, self.owner.body.position)
        header = header:fdiv(distance)

        if distance <= (target.body.radius + self.owner.body.radius  + 50) or (self.last_header and tsvector.dot(header, self.last_header) < 0) then
        else
            self.owner.body:setvelocity(header:fmul(self.prop.speed or 1000), header)
        end
        
        self.last_header = header
    end
end

return logic
