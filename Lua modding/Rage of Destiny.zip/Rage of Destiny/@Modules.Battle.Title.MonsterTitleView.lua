local SpriteTitleBase = require "Modules.Battle.Title.SpriteTitleBase"
local MonsterTitleView = MonsterTitleView or BaseClass(GameObjFactor, SpriteTitleBase)

function MonsterTitleView:OnLoad()
	self:LoadStart("Battle.PlayerTitleItem")
end

function MonsterTitleView:LoadEnd(obj)
	self.hpSld = self:GetChildComponent(obj, "attribute/CSlider_Hp", "CSlider")
	self.mpSld = self:GetChildComponent(obj, "attribute/CSlider_Mp", "CSlider")
	self.mpSld.gameObject:SetActive(false)
	self.hpSp = self:GetChildComponent(self.hpSld.gameObject, "hp", "CSprite")
	self.hpbackSp = self:GetChildComponent(self.hpSld.gameObject, "hpback", "CSprite")
	self.mpSp = self:GetChildComponent(self.mpSld.gameObject, "Fill Area/Fill", "CSprite")	
end

function MonsterTitleView:OnOpen()
	self:InitInfo()
end

function MonsterTitleView:OnClose()	
end

function MonsterTitleView:OnDestroy()	
end

function MonsterTitleView:InitInfo()
	self:ChangeHp()
	self.hpSp.SpriteName = self.spritedata.prop.camp == CAMP.RED and "lvjianbianxuetiao" or "hongjianbianxuetiao"
end

function MonsterTitleView:ChangeHp()
	local hp_max = self.spritedata.attr.hp_max
	local cur_hp = self.spritedata.attr.hp

	local value = cur_hp / hp_max
	self.hpSp.fillAmount = value
	self.hpbackSp:DOFillAmount(value, 0.5)	
end

function MonsterTitleView:ChangeMp()
	local mp_max = self.spritedata.attr.mp_max
	local cur_mp = self.spritedata.attr.mp
	local value = cur_mp / mp_max
	self.mpSld.value = value
end

function MonsterTitleView:ShowViewTimer()
	-- if self.showTimer then
	-- 	self:RemoveTimer(self.showTimer)
	-- 	self.showTimer = nil
	-- end
	-- self:showview(true)
	-- self.showTimer = self:AddTimer(function ()
	-- 	self:showview(false)
	-- end, 4, 1)
end

function MonsterTitleView:ShowBuff(buffid)
	if buffid then		
		local cfg = ConfigManager.GetConfig("buff_static")

		if cfg[buffid] and cfg[buffid].icon then
			self:_ClearBuff()
			AssetManager.LoadUITexture(AssetManager.UITexture.Buff, buffid, self.buffTex)

			self.buffObj:SetActive(true)

			self.sequence0 = DOTween.Sequence()
			GameUIUtil.SetGroupAlpha(self.buffObj, 1)
			local tween0 = self.buffObj.transform:DOScale(Vector3.New(2.5, 2.5, 2.5), 0.18)
			local tween0_1 = self.buffObj.transform:DOScale(Vector3.one, 0.3)
			self.sequence0:Append(tween0)
			self.sequence0:Append(tween0_1)
			self.sequence0:AppendCallback(function()
				local sequence = DOTween.Sequence()
				local tween1 = self.buffObj.transform:DOScale(Vector3.New(1.3, 1.3, 1.3), 0.5)	
				local tween2 = self.buffObj.transform:DOScale(Vector3.one, 0.5)
				sequence:AppendCallback(function ()
					GameUIUtil.SetGroupAlphaInTime(self.buffObj ,0.4 ,0.5)
					end)
				sequence:Append(tween1)
				sequence:AppendCallback(function ()
					GameUIUtil.SetGroupAlphaInTime(self.buffObj ,1 ,0.5)
					end)			
				sequence:Append(tween2)
				sequence:SetLoops(-1)
				self.buffsequence = sequence
			end)

			if self.icon_time then
				self.bufftimer = self:AddTimer(function ()
					self:_ClearBuff()
				end, self.icon_time, 1)
			end	
		end	
	end	
end

function MonsterTitleView:_ClearBuff()
	GameUIUtil.SetGroupAlpha(self.buffObj, 1)
	self.buffObj:SetActive(false)
	if self.sequence0 then
		self.sequence0:Kill()
		self.sequence0 = nil
	end

	if self.buffsequence then
		self.buffsequence:Kill()
		self.buffsequence = nil
	end

	if self.bufftimer then
		self:RemoveTimer(self.bufftimer)
		self.bufftimer = nil
	end	
end	

function MonsterTitleView:ClearBuff(buffid)
	if buffid then		
		local cfg = ConfigManager.GetConfig("buff_static")
		if cfg[buffid] and cfg[buffid].icon then
			self:_ClearBuff()
		end	
	end	
end

function MonsterTitleView.event.attr:hp(newvalue, oldvalue)
	self:ChangeHp()
end

function MonsterTitleView.event.attr:hp_max(newvalue, oldvalue)
	self:ChangeHp()
end

return MonsterTitleView
 