local EquipDef = {}
	
EquipDef.RaceTips = {
	[1] = {tips = "Common_1007"},
	[2] = {tips = "Common_1008"},
	[3] = {tips = "Common_1009"},
	[4] = {tips = "Common_1010"},
	[5] = {tips = "Common_1011"},
	[6] = {tips = "Common_1012"},
	[7] = {tips = "Common_1013"},
}


EquipDef.NotifyDef ={
	Update_EquipGoods = "Update_EquipGoods",
	Update_Strenthen = "Update_Strenthen",
	Update_Reset = "Update_Reset",
	Update_Reset_Confirm = "Update_Reset_Confirm",
	Update_Reset_Result = "Update_Reset_Result",
	Update_Strenthen_Ids = "Update_Strenthen_Ids",
	Update_EquipAttr_Change = "Update_EquipAttr_Change",
	Update_EnhanceEquip = "Update_EnhanceEquip",
}

EquipDef.EquipTab = 
{
	[1] = {key = "EquipmentHintsView_1001", tab = 1},
	[2] = {key = "EquipmentHintsView_1002", tab = 2},
}

return EquipDef