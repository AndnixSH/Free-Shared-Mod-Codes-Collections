local MazeProxy = MazeProxy or BaseClass(BaseProxy)
local MazeDef = require "Modules.Maze.MazeDef"
local HexMapProxy = require "Modules.HexMap.HexMapProxy"
local MazeGuide = require "Modules.Maze.MazeGuide"

local hexproto = {
    open = 53001,  -- 打开格子
    done = 53002,  -- 完成格子
    rune = 53006,  -- 符文列表
    hero = 53003,  -- 英雄列表
    hero_to_battle = 53011 -- 英雄上阵
}

function MazeProxy:__init()
    MazeProxy.Instance = self
    self:AddProto(53000, self.OnMapInfo) --地图信息
    self:AddProto(53004, self.OnSetHeroList)
    self:AddProto(53005, self.OnDragonLevelUp)
    self:AddProto(53007, self.OnUseDragonBlood)
    self:AddProto(53008, self.OnComplete)
    self:AddProto(53009, self.OnRefreshHero)
    self:AddProto(53010, self.OnMapLevelInfo)
    self:AddProto(53013, self.OnCurrentRewards)

    self.data = { level = 0 }

    self.bShowRedDot2 = true --领地迷宫
    self.data.finishMazeNewbie = false --是否完成副本新手
end

function MazeProxy:__delete()
    MazeProxy.Instance = nil
    self.mapinfo = nil
    self.cells = nil
    self.bShowRedDot = nil
end

function MazeProxy:RequireMapInfo()
    HexMapProxy.Instance:ClearProxy()
    self:SendMessage(53000)
end

function MazeProxy:OnMapInfo(decoder)
    local level, left_time, dragonlv, map_buffer, select_hero_index, factor_Id, battle_count, rune_type, rainbow_egg_count, disable_block = decoder:Decode("I2I4I4s2I2I2I2I2I2I1")
	local reward_add_percent = decoder:Decode("I2")
    local guide = decoder:Decode("I2")
    local guide_list = decoder:DecodeList("I2")
    -- print(level, left_time, dragonlv, #map_buffer, select_hero_index, factor_Id, battle_count, rainbow_egg_count)
    -- print('guide_list', table.dump(guide_list))
    MazeGuide.Init(guide, guide_list)
    self.data.level = level
    self.data.left_time = left_time
    self.data.dragonlv = dragonlv
    self.data.select_hero_index = select_hero_index
    self.data.factor_Id = factor_Id
    self.data.battle_count = battle_count
	local config = self:GetMazeSelectHeroCostByIdx(1)
	self.data.battle_total_count = config.battle_num
    self.data._map_buffer = map_buffer
    self.data.rune_type = rune_type
    self.data.rainbow_egg_count = rainbow_egg_count
    self.data.disable_block = disable_block
	self.data.reward_add_percent = reward_add_percent
	local battle_data = {battle_count = battle_count, battle_total_count = self.data.battle_total_count}
    
    local RedPointDef = require "Modules.RedPoint.RedPointDef"
    local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
    local redDot = self:GetMazeRedDot2()
    RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.Maze, redDot)

    self:ToNotify(self.data, MazeDef.NotifyDef.Update_Maze_Map)
    -- self:_OnMapInfo(level, map_buffer)
    --拿到数据后再进巨龙场景
    self:EnterMazeScene(level)
end

function MazeProxy:GetBattleCount()
	return self.data.battle_count, self.data.battle_total_count
end

function MazeProxy:OnGetActivityInfo()
    return {
        [HEXMAP_INFO.MAZE_LEVEL] = self.data.level 
    }
end

function MazeProxy:_OnMapInfo(level, map_buffer)
    local map_config = self:_GetMapConfig(level)
    local cell_config = self:_GetCellsConfig(level)
    local levelType = map_config.type
    self.data.level_type = levelType

    HexMapProxy.Instance:SetCellProxy(ACTIVITYID.MAZE, self, hexproto)

    local cellinfos, decoder = HexMapProxy.Instance:DecodeCellInfos(map_buffer, cell_config)

    HexMapProxy.Instance:IntMap(map_config, cell_config, {cellinfos = cellinfos, buildshare = { battle_count = self.data.battle_count, disable_block = self.data.disable_block, rainbow_egg_count = self.data.rainbow_egg_count, reward_add_percent = self.data.reward_add_percent }})
    self:ToNotify(self.data, MazeDef.NotifyDef.Update_Maze_Info,
		{ level = self.data.level, left_time = self.data.left_time, dragonlv = self.data.dragonlv, 
		select_hero_index = self.data.select_hero_index, factor_Id = self.data.factor_Id, levelType = levelType,
		rune_type = self.data.rune_type, battle_count = self.data.battle_count, battle_total_count = self.data.battle_total_count})
    self:ToNotify(self.data, MazeDef.NotifyDef.Update_Maze_Rainbow_Egg, { count = self.data.rainbow_egg_count})

    local lastBattleCell = HexMapProxy.Instance:GetBattleCell()
    if lastBattleCell then
        if map_config.class == MazeDef.CopyClass.Normal then
            local cell = HexMapProxy.Instance:GetCell(lastBattleCell)
            if cell and cell.build and cell.build.static.type == HEXMAP_BUILD.RUNE then -- 符文自动打开
                HexMapProxy.Instance:Operate(lastBattleCell)
            end
        end
        HexMapProxy.Instance:SetBattleCell(nil)
    end

    HexMapProxy.Instance:CheckBattle()

    MazeGuide.Notify("level_start")
end

function MazeProxy:InitMap()
    self:_OnMapInfo(self.data.level, self.data._map_buffer)
end

function MazeProxy:AddGuideStep(step)
    local encoder = NetEncoder.New()
    encoder:Encode("I2", step)
    self:SendMessage(53012, encoder)
end

function MazeProxy:RequireCurrentRewards()
    self:SendMessage(53013)
end

function MazeProxy:OnCurrentRewards(decoder)
    local rewards = decoder:DecodeList("I4I4", true)
    self:ToNotify(self.data,MazeDef.NotifyDef.OnCurrentRewards, {rewards=rewards})
end

function MazeProxy:SetHeroList()
    self:SendMessage(53004)
end

function MazeProxy:OnSetHeroList(decoder)
    local select_hero_index = decoder:Decode("I2")

    if select_hero_index > 0 then
        local heroUids = decoder:DecodeList("I4")
        -- print("OnSetHeroList select_hero_index==", select_hero_index, table.dump(heroUids))
        self:ToNotify(self.data, MazeDef.NotifyDef.Update_Set_HeroList_Result, {select_hero_index = select_hero_index, heroUids = heroUids})
        -- MazeGuide.Notify("hero_select")
    end
end

-- 刷新英雄选择列表
function MazeProxy:RefreshHeroList()
    self:SendMessage(53009)
end

function MazeProxy:OnRefreshHero(decoder)
    local result, selectidx, factor_Id = decoder:Decode("I1I2I2")
    -- print("result, selectidx=", result, selectidx)
    if result == 0 then
        self:ToNotify(self.data, MazeDef.NotifyDef.Maze_Select_Index, {selectidx = selectidx, factor_Id = factor_Id})
    end
end

function MazeProxy:GetDragonLevel()
    return self.data.dragonlv
end

function MazeProxy:GetRuneType()
    return self.data.rune_type
end

function MazeProxy:GetLevelType()
    return self.data.level_type
end

function MazeProxy:UpGradeDragonLevel()
    self:SendMessage(53005)
end

function MazeProxy:OnDragonLevelUp(decoder)
    local result = decoder:Decode("I1")
    if result == 0 then
        local dragonlv = decoder:Decode("I2")
        self.data.dragonlv = dragonlv
        self:ToNotify(self.data, MazeDef.NotifyDef.Update_Dragon_Level, {dragonlv = dragonlv})
    else
    end
    GameLogicTools.ShowErrorCode(53005, result)
end

function MazeProxy:_GetMapConfig(level)
    local config = ConfigManager.GetConfig("data_maze")
    return config[level]
end

function MazeProxy:_GetCellsConfig(level)
    local config = ConfigManager.GetConfig("data_maze_cell_" .. level)
    return config
end

function MazeProxy:_GetBuildConfig(level, cellid)
    local cell_config = self:_GetCellsConfig(level)
    local cellcfg = cell_config[cellid]
    if cellcfg and cellcfg.build then
        local build_config = ConfigManager.GetConfig("data_cell_build")
        return build_config[cellcfg.build]
    end
end

function MazeProxy:GetDragonBallConfig(dragonlv)
    local config = ConfigManager.GetConfig("data_dragonball")
    return config[dragonlv]
end

--龙珠最大等级
function MazeProxy:GetMaxDragonLevel()
    local config = ConfigManager.GetConfig("data_dragonball")
    return #config
end

--配置英雄数据
function MazeProxy:GetMazeHeroByIdx(idx)
    local config = ConfigManager.GetConfig("data_maze_hero")
    return config[idx]
end

function MazeProxy:GetMazeSelectHeroCostByIdx(idx)
    local config = ConfigManager.GetConfig("data_maze_common")
    return config[idx]
end

function MazeProxy:GetEnemyFactorConfigByIdx(idx)
    local config = ConfigManager.GetConfig("data_enemy_factor")
    return config[idx]
end

--升到n级总共需要拥有迷宫龙珠数量
function MazeProxy:GetTotalExpByDragonLv(toLv)
    local config = self:GetDragonBallConfig(toLv)
    return config.total_exp
end

function MazeProxy:Send53007(num)
    local encoder = NetEncoder.New()
    encoder:Encode("I1", num)
    self:SendMessage(53007, encoder)
end

function MazeProxy:OnUseDragonBlood(decoder)
    local result = decoder:Decode("I1")
    if result == 0 then
        local LanguageManager = require "Common.Mgr.Language.LanguageManager"
        GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord("Msgtips_hexmap_1017"))
    else
        GameLogicTools.ShowErrorCode(53007, result)
    end
    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.DragonBloodView)
end

function MazeProxy:OnComplete(decoder)
    local level = decoder:Decode("I1")
    local rewards = decoder:DecodeList("I4I4", true)
    self.data.mazeComplete = true
    self:ToNotify(self.data,MazeDef.NotifyDef.Maze_Complete, {level=level, rewards=rewards})
    MazeGuide.Notify("level_end")

    local RedPointDef = require "Modules.RedPoint.RedPointDef"
    local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
    local redDot = self:GetMazeRedDot2()
    RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.Maze, redDot)
end

function MazeProxy:GetMapLevelInfo()
    self:SendMessage(53010)
end

function MazeProxy:OnMapLevelInfo(decoder)
    local level, complete, reward_add_percent = decoder:Decode("I2I1I2")
    self.data.level = level
    self.data.mazeComplete = complete == 1 and true or false
	self.data.reward_add_percent = reward_add_percent
    -- print("OnMapLevelInfo=", self.data.level, complete)
    local RedPointDef = require "Modules.RedPoint.RedPointDef"
    local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
    local redDot = self:GetMazeRedDot2()
    RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.Maze, redDot)
    
    self:ToNotify(self.data, MazeDef.NotifyDef.Update_Maze_Level)
end

function MazeProxy:SetMazeCacheRedDot2(bactive)
    if self.bShowRedDot2 ~= bactive then
        self.bShowRedDot2 = bactive
        local RedPointDef = require "Modules.RedPoint.RedPointDef"
        local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
        local redDot = self:GetMazeRedDot2()
        --print("redDot=====", redDot)
        RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.Maze, redDot)
    end
end

function MazeProxy:GetMazeCacheRedDot2()
    return self.bShowRedDot2
end

function MazeProxy:GetMazeRedDot2()
    local ModuleManager = require "Common.Mgr.UI.ModuleManager"
    local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
    local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.MazeView, false)
    local redDot = 0

    local map_config = self:_GetMapConfig(self.data.level)
    local levelType = map_config.type
    --print("self.data.level==", self.data.level, self:GetMazeCacheRedDot2())
    --小于6未结算
    if bopen and not self.data.mazeComplete and self:GetMazeCacheRedDot2() then
        redDot = 1
        -- if MazeDef.LevelType.Easter == levelType and self:GetMazeCacheRedDot2() then
        --     redDot = 1
        -- elseif MazeDef.LevelType.Difficulty == levelType then
        --     if ((self.data.level - 10) <= 6) and self:GetMazeCacheRedDot2() then
        --         redDot = 1
        --     end
        -- elseif MazeDef.LevelType.Normal == levelType then
        --     if self.data.level <= 6 and self:GetMazeCacheRedDot2() then
        --         redDot = 1
        --     end
        -- end
    end
    return redDot
end

function MazeProxy:RequireEnterMazeScene()
    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.NetworkDelayView)
    self:RequireMapInfo()
end

function MazeProxy:EnterMazeScene(level)
    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.NetworkDelayView)
    local SceneManager = require "Modules.Scene.SceneManager"
    local SceneDef = require "Modules.Scene.SceneDef"
    SceneManager.Instance:EnterScene(SceneDef.SceneType.Maze, level) 
end

function MazeProxy:FinishMazeDungenNewbie(stepId, bFinish, func)
    local MazeGuide = require "Modules.Maze.MazeGuide"
    local step_complete = MazeGuide.IsStepFinish(stepId)
    if not step_complete then
        self:SetMazeDungenNewbie(bFinish)
        self.data.newbie_stepId = stepId
        self.data.newbie_callback = func
    end
end

function MazeProxy:GetMazeDungenNewbie()
    return self.data.finishMazeNewbie
end

function MazeProxy:SetMazeDungenNewbie(bFinish)
    self.data.finishMazeNewbie = bFinish
end

function MazeProxy:IsShowMazeFinishView()
    local bFinish = self:GetMazeDungenNewbie()
    return bFinish, self.data.newbie_stepId, self.data.newbie_callback
end

function MazeProxy:CrossDay()
	self:SetMazeCacheRedDot2(true)
end

function MazeProxy:HasRewardAddPercent()
	return (self:GetRewardAddPercent() > 0) and (not self.data.mazeComplete)
end

function MazeProxy:GetRewardAddPercent()
	return self.data and self.data.reward_add_percent and self.data.reward_add_percent or 0
end

function MazeProxy:GetRewardAddPercentStr()
	if self:HasRewardAddPercent() then
		return GameLogicTools.FormatAddPercent(self.data.reward_add_percent)
	end
	return ""
end

return MazeProxy