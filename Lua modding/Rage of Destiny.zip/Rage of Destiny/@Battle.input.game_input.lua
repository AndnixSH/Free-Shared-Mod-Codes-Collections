--local game = require "Battle.game.game"
local sprite_input = nil

-- 操作
local operation = { _speed = 1 }
-- 暂停信息
local pauseinfo = { bpause = false }

local game_input = {}

local function bmessage(message, ...)
    if global and global.gamer then
        global.gamer.bmessage(message, ...)
    end
end

function game_input.process(time, deltaTime)

    if sprite_input then
        sprite_input.process()
    end

    if operation._handler then
        operation._handler.process()
    end

    if pauseinfo.bpause then
        pauseinfo.bpause = false
        bmessage("RenderPause", pauseinfo.reason)
    end

    if pauseinfo.duration then
        pauseinfo.duration = pauseinfo.duration - deltaTime * operation._speed
        if pauseinfo.duration <= 0 then
            operation.resume(pauseinfo.reason)
            pauseinfo.duration = nil
            pauseinfo.reason = nil
        end
    end

end

function game_input.dispose()
    if sprite_input then
        sprite_input.dispose()
    end
    pauseinfo = { bpause = false }
    if operation._record then
        operation._record:dispose()
        operation._record = nil
    end
    operation._handler = nil
end


function operation.speed(speed)
    operation._speed = speed

    local game = require "Battle.game.game"
    game.speed(speed)

    bmessage("RenderSpeed", speed)
end

function operation.jump(speed)
    global.service.eventslots:unloadtag("view")
    bmessage("RenderEnable", false)

    local game = require "Battle.game.game"
    game.speed(speed or 200)
end

function operation.restart()

end

function operation.start(report)
    pauseinfo.bpause = false
    pauseinfo.reason = nil
    if report and report.framestr then
        local input_handler = require "Battle.input.input_handler"
        operation._handler = input_handler
        operation._handler.start(report.framestr)
    else
        local input_record = require "Battle.input.input_record"
        operation._record = input_record
        operation._record.start()
    end

    if GameConfig.ISEDITOR then
        sprite_input = require "Battle.input.sprite_input"
    end
end

function operation.resume(reason)
    bmessage("RenderResume", reason)

    local game = require "Battle.game.game"
    game.resume()

    pauseinfo.bpause = false
end

function operation.pause(reason)
    local game = require "Battle.game.game"
    game.pause()

    pauseinfo.bpause = true
    pauseinfo.reason = reason
end

function operation.render_pause(reason)
    pauseinfo.bpause = true
    pauseinfo.reason = reason
end

function operation.remove_render_views()
    bmessage("RemoveRenderViews")
end

function operation.auto(bauto)
    local game = require "Battle.game.game"
    game.sendevent("set_auto_fire", CAMP.RED, bauto)
    game.sendevent("set_auto_fire", CAMP.BLUE, true)

    if operation._record then
        operation._record.add(bauto and 100 or 101)
    end
end

function operation.use_skill(spriteid, slot)
    local game = require "Battle.game.game"
    game.sendevent("fire_slot", spriteid, slot)

    if operation._record then
        local spriteobj = global.service.pool:get_obj(spriteid)
        if spriteobj and spriteobj.prop.stance then
            operation._record.add(spriteobj.prop.stance)
        end
    end
end

function operation.settle(wincamp, total_time)
    local game = require "Battle.game.game"
    game.over()

    if operation.onsettle then
        operation.onsettle(wincamp, total_time)
    end
end

game_input.operation = operation

return game_input