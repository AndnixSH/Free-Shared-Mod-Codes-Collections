------TaskPoolItem------------
local ObjPoolRender = require "Core.Implement.UI.Class.ObjPoolRender"
local ObjPoolItem = require "Core.Implement.UI.Class.ObjPoolItem"
local TaskPoolItem = TaskPoolItem or BaseClass(ObjPoolItem)
function TaskPoolItem:Load(obj)
	self.go = obj
	self.tweenRoot = self:GetChild(self.go, "tweenRoot")
	self.tweenRoot:SetActive(false)
	self.taskProgress = self:GetChildComponent(self.tweenRoot, "CLabel_num", "CLabel")
	self.contentLab2 = self:GetChildComponent(self.tweenRoot, "CLabel_num/CLabel_task", "CLabel")
	self.contentLab = self:GetChildComponent(self.tweenRoot, "CLabel_task", "CLabel")
	self.finishObj = self:GetChild(self.tweenRoot, "sprite_complete")
end


function TaskPoolItem:SetData(data)
	self.data = data
	self.finishObj:SetActive(self.data.isComplete)
	self.taskProgress.text = self.data.progress
	self.contentLab.text = self:GetWord(self.data.content)
	self.contentLab2.text = self:GetWord(self.data.content)
end

function TaskPoolItem:ReSetState()
	local fromPos = Vector3.New(-180, 0, 0)
	
	self.tweenRoot.transform.localPosition = fromPos
end

function TaskPoolItem:StartTween()
	local toPos = Vector3.New(0, 0, 0)
	local interval = 0.3
	local duration = 0.6
	if self.sequence then
		self.sequence:Kill()
		self.sequence = nil
	end
	self:ReSetState()
	self.sequence = DOTween.Sequence()
	self.sequence:AppendInterval((self.data.index-1)*interval)
	self.sequence:AppendCallback(function()
		self.tweenRoot:SetActive(true)
	end)
	local tween = self.tweenRoot.transform:DOLocalMove(toPos, duration)
	self.sequence:Append(tween)
end

function TaskPoolItem:ShowItem()
	self.tweenRoot:SetActive(true)
end

function TaskPoolItem:Close()
	if self.sequence then
		self.sequence:Kill()
		self.sequence = nil
	end
end

return TaskPoolItem