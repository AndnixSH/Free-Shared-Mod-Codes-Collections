local AutoBattleDef = require "Modules.AutoBattle.AutoBattleDef"


local AutoBattleProxy = AutoBattleProxy or BaseClass(BaseProxy)

function AutoBattleProxy:__init()
	AutoBattleProxy.Instance = self

	self.data = {}
	self.data.activitys_Infos = {}
end

function AutoBattleProxy:__delete()
	self.data.activitys_Infos = nil
	self.data = nil
end

function AutoBattleProxy:GetAutoBattleStatusKey()
	local key = AutoBattleDef.AutoStatusKey .. RoleInfoModel.uid
	return key
end

--设置自动推图状态
function AutoBattleProxy:SetAutoBattleStatus(status)
	local key = self:GetAutoBattleStatusKey()
	PlayerPrefs.SetInt(key, status)
end

--获取自动推图状态
function AutoBattleProxy:GetAutoBattleStatus()
	local key = self:GetAutoBattleStatusKey()
	local status = PlayerPrefs.GetInt(key, 0)
	return status
end

--自动推图开始战斗
function AutoBattleProxy:StartGame(activity_id, tower_type, enemyid)
	if activity_id == ACTIVITYID.MAINLINE then
		--主线
		local CampaignProxy = require "Modules.Campaign.CampaignProxy"
		CampaignProxy.Instance:Send51011(enemyid)
	elseif activity_id == ACTIVITYID.TOWER and tower_type then
		--爬塔
		local TowerProxy = require "Modules.Tower.TowerProxy"
		TowerProxy.Instance:Send52006(tower_type)
	end

end

--检查是否需要取消自动推图
function AutoBattleProxy:CheckCancelAutoBattle(activity_id, bWin)
	local NewbieManager = require "Modules.Newbie.NewbieManager"
	local NewbieProxy = require "Modules.Newbie.NewbieProxy"
	local CampaignProxy = require "Modules.Campaign.CampaignProxy"
	local RoleInfoProxy = require "Modules.RoleInfo.RoleInfoProxy"

	if activity_id == ACTIVITYID.TOWER then
		return (not bWin)
	elseif activity_id ~= ACTIVITYID.MAINLINE then
		return false
	end

	--前两章失败需要返回主界面引导特殊引导
	local bSpecail_newbie = false
	local cfg = CampaignProxy.Instance:GetMainLineCfgById(RoleInfoModel.mainlineid)
	if cfg.chapter <= 2 and bWin == false then
		bSpecail_newbie = true
	end

	--是否需要返回主界面进行引导
	local bNewbie = NewbieProxy.Instance:NewbieBackMainView(RoleInfoModel.mainlineid)
	
	local bLevelUp = false

	--local _data = RoleInfoProxy.Instance:GetAccountUpgradeData()  --是否升级
	--if _data then
		--bLevelUp = true
	--end

	local bPassChapter = CampaignProxy.Instance:IsPassToNextChapter() --是否通关章节
	local bCancel = (bNewbie == true or bLevelUp == true or bPassChapter == true or bSpecail_newbie == true) and true or false
	return bCancel or (not bWin)
end


return AutoBattleProxy