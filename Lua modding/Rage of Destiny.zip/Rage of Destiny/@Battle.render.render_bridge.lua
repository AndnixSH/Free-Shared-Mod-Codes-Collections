local SpriteInterface = CS.LJY.NX.NxSpriteProxy
local GameInterface = CS.GameInterface
local SpriteDebug = CS.LJY.NX.SpriteDebug
local RangeDebug = CS.RangeDebug
local isEditor = CS.UnityEngine.Application.isEditor
local render_area = require "Battle.render.render_area"

local SPRITE_DEBUG_CAMP = {
    [CAMP.RED] = SpriteDebug(1, 0, 0),
    [CAMP.BLUE] = SpriteDebug(0, 0, 1),
}
local SPRITE_DEBUG_TYPE = {
    [SPRITE_TYPE.BULLET] = SpriteDebug(1, 1, 0),
}
local SPRITE_DEBUG_DEAD = SpriteDebug(0, 1, 0)

local bridge = {}

function bridge.CreateGame(maptype, centerx, centery, sizex, sizey)
    GameInterface.CreateGame(maptype, centerx, centery, sizex, sizey)
end

function bridge.UpdateGame(time, tick)
    GameInterface.UpdateGame(time, tick)
end

function bridge.DestroyGame()
    GameInterface.DestroyGame()
end

function bridge.CreateSprite(spritetype, pushmask, px, py, hx, hy, height, radius, weight)
    local csbody, csspriteid = GameInterface.CreateSprite(spritetype, pushmask, px, py, hx, hy, height, radius, weight)
end

function bridge.AddSprite(csspriteid, spritetype)
    GameInterface.AddSprite(csspriteid, spritetype)
end

function bridge.RemoveSprite(csspriteid)
    GameInterface.RemoveSprite(csspriteid)
end

function bridge.PauseSprite(csspriteid)
    SpriteInterface.Pause(csspriteid)
end

function bridge.ResumeSprite(csspriteid)
    SpriteInterface.Resume(csspriteid)
end

function bridge.SetSpriteDebug(csspriteid, spritetype, camp, toremove)
    local debug = SPRITE_DEBUG_TYPE[spritetype] or SPRITE_DEBUG_CAMP[camp]
    if debug then
        SpriteInterface.SetDebugInfo(csspriteid, debug)
    end
end

function bridge.RemoveActor(csspriteid)
    SpriteInterface.SetDebugInfo(csspriteid, SPRITE_DEBUG_DEAD)
end

function bridge.AddDraw(rangetype, centerx, centery, headerx, headery, range1, range2)
    if isEditor then
        RangeDebug.AddDraw(rangetype, centerx, centery, headerx, headery, range1, range2)
    end
end


function bridge.RenderPause(reason)
    render_area.pause(reason)
end

function bridge.RenderResume(reason)
    render_area.resume(reason)
end

function bridge.RenderSpeed(speed)
    render_area.speed(speed)
end

function bridge.RenderEnable(enable)
    render_area.setenable(enable)
end

function bridge.RemoveRenderViews()
    local view_manager = require "Battle.render.view_manager"
    view_manager.removeall()
end

function bridge.CreateDir(dir)
    local CSDirectory = CS.System.IO.Directory
    if not CSDirectory.Exists(dir) then
        CSDirectory.CreateDirectory(dir);
    end
end

return bridge