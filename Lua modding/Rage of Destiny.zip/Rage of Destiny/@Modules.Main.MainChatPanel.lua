
local ClistRender = require "Core.Implement.UI.Class.ClistRender"
local ClistItem = require "Core.Implement.UI.Class.ClistItem"
local ChatDef = require "Modules.Chat.ChatDef"
local ChatProxy = require "Modules.Chat.ChatProxy"
local RoleInfoDef =require "Modules.RoleInfo.RoleInfoDef"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local ObjPoolRender = require "Core.Implement.UI.Class.ObjPoolRender"
local ObjPoolItem = require "Core.Implement.UI.Class.ObjPoolItem"
local RoleInfoProxy = require "Modules.RoleInfo.RoleInfoProxy"
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"
local ContentItem = ContentItem or BaseClass(ClistItem)
function ContentItem:Load(obj)
  self.content=self:GetChildComponent(obj,"label2","CEmoLabel")
  self.sexSpr=self:GetChildComponent(obj,"sex","CSprite")
  self.data=false
end

function ContentItem:SetData(data)
	self.data=data
	if data.sex == RoleInfoDef.Sex.Boy then
		self.sexSpr.SpriteName= "nanshengtubiao"
		--nan
	elseif data.sex == RoleInfoDef.Sex.Girl then
		--nv
		self.sexSpr.SpriteName= "nvshengtubiao"
	elseif data.sex == RoleInfoDef.Sex.Hide then
		self.sexSpr.SpriteName= "baomitubiao"
	end
	
	if ChatProxy.Instance:IsBigExpression(data.content) then
		local str = string.format("%s:[%s]",data.nickname,LanguageManager.Instance:GetWord(ChatDef.CommonDef.Expression))
		self.content.text=string.gsub(str,":","：",1)
	else
		local limit_count=36
		local content =  data.content
		if data.content == "enter_guild_tips!" then
			content = string.format(LanguageManager.Instance:GetWord(ChatDef.CommonDef.AddGuildTips),data.nickname)
		elseif data.content == "exist_guild_tips!" then
			content = string.format(LanguageManager.Instance:GetWord(ChatDef.CommonDef.ExistGuildTips),data.nickname)
		elseif data.content == "agree_friend_tips!" then
			content = string.format(LanguageManager.Instance:GetWord(ChatDef.CommonDef.AgreeFriendTips))
		end
		local len,str=ChatProxy.Instance:CaculateStrCount(content,limit_count)
		if len >= limit_count then
			local str = data.nickname..":"..str.."…"
			self.content.text=string.gsub(str,":","：",1)
		else
			local str = string.format("%s:%s",data.nickname,content)
			self.content.text=string.gsub(str,":","：",1)
		end
	end
end


function ContentItem:OnSelect(index)
    
    
end
function ContentItem:DeSelect(idx)
    
   
end

function ContentItem:Destroy()

end

local TitleItem = TitleItem or BaseClass(ObjPoolItem)
function TitleItem:Load(obj)

	self.selectobj=self:GetChild(obj,"select")
	self.root = self:GetChild(obj,"root")
	self.effect = UIEffectItem.New("UI_Chat_newmessage", self.root)
	self.effect:Close()
	self.data =false
end

function TitleItem:SetData(data)
	self.data = data
end
function TitleItem:SetSelect(index)
	if self.data.id == index  then
		self.selectobj:SetActive(true)
		-- if self.effect then
		-- 	self.effect:Close()
		-- end
	else
		self.selectobj:SetActive(false)
	end
end

function TitleItem:ShowEffect(args)

	if args.type == self.data.type  then
		GameObjTools.SetDepth(self.root,args.depth )
		if self.effect then
			self.effect:Open()
		end
	end

end

function TitleItem:UpdateDepth(depth)
	GameObjTools.SetDepth(self.root,depth)
end

function TitleItem:Hideffect(args)
	if args.type == self.data.type  then
		if self.effect then
			self.effect:Close()
		end
	end
end

function TitleItem:OnSelect(index)
    
    
end

function TitleItem:OnSelect(index)
    
    
end
function TitleItem:DeSelect(idx)
    
   
end

function TitleItem:Destroy()
	if self.effect then
		self.effect:Destroy()
	end
end
local MainChatPanel = MainChatPanel or BaseClass(GameObjFactor,TimerFactor)
function MainChatPanel:__init(go)
	self.go = go
	self.titledata={}
	self.index=1
	self.moveX=0
	self.nameList={"shijie","bendi","gonghui","juntuan","siliao"}
	self:Load(go)	
end
function MainChatPanel:Load(obj)
	self.rect = self:GetComponent(obj, "RectTransform")
	self.rectPosition = self.rect.anchoredPosition
	self.chatObj = self:GetChild(obj, "CButton_openchat")

	local btn=self:GetChildComponent(obj,"CButton_openchat","CButton")
	btn:AddClick(function ( )

		if RoleInfoProxy.Instance:HasEditNickName() == 0 then
			LuaLayout.Instance:OpenWidget(UIWidgetNameDef.ChangeNameView)
		else
			local key
			if self.titledata[self.index].type  < ChatDef.ChatType.chat_Private then
				key=ChatProxy.Instance:GetKeyById(self.titledata[self.index].type)
			else
				local privatelist=ChatProxy.Instance:GetPrivatePlayerList()
				key=ChatProxy.Instance:GetKeyById(self.titledata[self.index].type,privatelist[#privatelist])
			end
			if ChatProxy.Instance:IsTheKeyExist(key) then
				ChatProxy.Instance:SetChatSelectKey(key)
			else
				ChatProxy.Instance:SetChatSelectKey(ChatDef.Chat_Key[1])
			end
			UIOperateManager.Instance:OpenWidget(AppFacade.Chat)
		end
		
	end)

	local drag=self:GetChildComponent(obj,"CButton_openchat/cdrag","CDrag")
	drag:AddEndDrag(function (data)
		local index = self.index
		if self.moveX < 0 then
			--向左
			index = index + 1
			if index > #self.titledata then
				index = #self.titledata
			end
		elseif self.moveX > 0 then
			--向右
			index = index -1
			if index < 1 then
				index = 1
			end
		end
		self.moveX=0
		self:AddSelectOneTitle(index)
		--self.listRender2:SelectIndex(self.index)
	end)
	drag:AddDrag(function (data)
		
		self.moveX = self.moveX + data.delta.x
	end)
	
	local Clist = self:GetChildComponent(obj, "CList_content","CList")
	self.listRender = ClistRender.New()
	self.listRender:Load(Clist, ContentItem)
	

	local item=self:GetChild(obj,"CSprite_Back/CLayoutItem/item1")
    item:SetActive(false)
	self.listRender2 = ObjPoolRender.New()
    self.listRender2:Load(item, item.transform.parent, TitleItem)

	self.iconSpr=self:GetChildComponent(obj,"CSprite_Back/channellogo/CSprite_world","CSprite")

	self.depth = 0
end
function MainChatPanel:Chat_UpdateSelectTitle()
	self:UpdateView()
end

function MainChatPanel:Chat_UpdateTitleList(data)
	if data.btopoperator then
		--置顶 取消置顶操作不需要更新
		return
	end
	if self.titledata[self.index]  then
		if data.cur_change_titleData.id == self.titledata[self.index].type or
		 (data.cur_change_titleData.id >= ChatDef.ChatType.chat_Private and self.titledata[self.index].type == ChatDef.ChatType.chat_Private ) then
			local twodatalist={}
			if data.delete then
				self:UpdateContentList(twodatalist)
				return 
			end
			if data.cur_change_titleData.list then
				for i=#data.cur_change_titleData.list ,1,-1 do
					local item=data.cur_change_titleData.list[i]
					if item.uin > 0 and item.content ~= "enter_guild_tips!" and item.content ~= "exist_guild_tips!" then
						if #twodatalist < 3 then
							table.insert(twodatalist,1,data.cur_change_titleData.list[i])
						else
							break
						end
					end
				end
			end
			self:UpdateContentList(twodatalist)
			
		end
	end
	--显示新消息特效
	self:ShowNewsEffect(data.titlelist)
end
function MainChatPanel:ShowNewsEffect(titlelist)
	for _ , v in ipairs(titlelist or {} ) do
		local type = v.id
		local key 
		if v.id < ChatDef.ChatType.chat_Private then
			key = ChatProxy.Instance:GetKeyById(v.id)
		else
			type = ChatDef.ChatType.chat_Private
			key = ChatProxy.Instance:GetKeyById(ChatDef.ChatType.chat_Private,v.player)
		end
		local unreadnum=ChatProxy.Instance:GetChatUnReadNum(key)
		if unreadnum > 0 then
			if type ~= self.titledata[self.index].type then
				self.listRender2:ExecuteMethod("ShowEffect",{type = type,depth = self.depth + 1} )
			else
				local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.ChatRootView)
				if view and not view:IsOpen() then
					self.listRender2:ExecuteMethod("ShowEffect",{type = type,depth = self.depth + 1} )
				end
			end
		end
	end
end
function MainChatPanel:AddSelectOneTitle(index)
	if self.index ~= index then

		self.index=index
		self:ChangeTitle(index)
		self.listRender2:ExecuteMethod("SetSelect",self.index)

	end
end

function MainChatPanel:ChangeTitle(index)
	local data
	if index == #self.titledata then
		local privatelist=ChatProxy.Instance:GetPrivatePlayerList()
		table.sort(privatelist,
        function(a, b) --排序
            return a.timestamp < b.timestamp
		end)
		local player=privatelist[#privatelist]
		if player then
			data=ChatProxy.Instance:GetOnePrivateChatInfo(player.uin)
		end
		self.iconSpr.SpriteName=self.nameList[5]
	else
		if index == ChatDef.ChatType.chat_World then
			local channelid=0
			channelid,data=ChatProxy.Instance:GetChatWorldInfo()
			
		elseif index == ChatDef.ChatType.chat_Local then
			data=ChatProxy.Instance:GetLocalChatInfo()
		elseif index == ChatDef.ChatType.chat_Guild then
			data=ChatProxy.Instance:GetGuilChatInfo()
		elseif index == ChatDef.ChatType.chat_Army then
			data=ChatProxy.Instance:GetArmyChatInfo()
		end
		self.iconSpr.SpriteName=self.nameList[index]
	end
	local sequence = DOTween.Sequence()
	local tween1 = self.iconSpr.transform:DOScale(Vector3.New(1.2,1.2,1.2), 0.2):SetEase(Ease.InBack)
	local tween2 = self.iconSpr.transform:DOScale(Vector3.New(1,1,1), 0.2):SetEase(Ease.OutBack)
	sequence:Append(tween1)
	sequence:Append(tween2)
	sequence:SetAutoKill()
	local twodatalist={}
	if data  then
		for i=#data ,1,-1 do
			if data[i].uin > 0 and data[i].content ~= "enter_guild_tips!" and data[i].content ~= "exist_guild_tips!" then
				if #twodatalist < 3 then
					table.insert(twodatalist,1,data[i])
				else
					break
				end
			end
		end
	end
    self:UpdateContentList(twodatalist)
end

function MainChatPanel:UpdateContentList(data)
	self.listRender:ClearData()
	self.listRender:AppendDataList(data,"")
	if self.delaytimer then
		self:RemoveTimer(self.delaytimer)
		self.delaytimer=false
	end
	self.delaytimer=self:AddTimer(function ()
		self.listRender:GotoIndex(#data,true)
	end, 0.02, 1)
	
end
function MainChatPanel:UpdateNewEffect(data)
	self.listRender2:ExecuteMethod("Hideffect",{type = data.type} )
end

function MainChatPanel:UpdateView()
	self.titledata={}
	local data=ChatProxy.Instance:GetChatInfoForMainView()
	if not data then
		return
	end
	for i =1,#data do

		if data[i].id < ChatDef.ChatType.chat_Private then
			table.insert(self.titledata,{id=i,type=data[i].id})
		end
		
	end
	table.insert(self.titledata,{id=#self.titledata + 1,type=ChatDef.ChatType.chat_Private})
	
	local key=ChatProxy.Instance:GetChatSelectKey()
	self.listRender2:ReleaseAll()
	self.listRender2:GetList(self.titledata)
	local index = 1
	self.index = 0
	if key == "" then
		index=1
		
	else
		local id=ChatProxy.Instance:GetIdByKey(key)
		if type(id) == "number" then
			for k , v in ipairs(self.titledata) do
				if v and v.type == id then
					index = k
					break
				end
			end
			if id >= ChatDef.ChatType.chat_Private then
				index = #self.titledata
			end
		else
			index =#self.titledata
		end
		
		
	end
	self.listRender2:ExecuteMethod("SetSelect",index)
	self:AddSelectOneTitle(index)
	--显示新消息特效
	self:ShowNewsEffect(data)
end

function MainChatPanel:Open()
	self.depth = UILayerTool.GetCurrentDepth()
	local ChatProxy = require "Modules.Chat.ChatProxy"
	ChatProxy.Instance:Send31003()
	self:StartOpenTween()
	self:UpdateView()
end	

function MainChatPanel:Close()
	if self.opensequence then
		self.opensequence:Kill()
		self.opensequence = nil
	end		
	if self.delaytimer then
		self:RemoveTimer(self.delaytimer)
		self.delaytimer=false
	end
end	

function MainChatPanel:Destroy()

	self.listRender:ClearData()
	self.listRender:Destroy()
	self.listRender2:ReleaseAll()
	if self.delaytimer then
		self:RemoveTimer(self.delaytimer)
		self.delaytimer=false
	end
end

function MainChatPanel:StartOpenTween()	
	self.rect.anchoredPosition = Vector2.New(self.rectPosition.x, self.rectPosition.y - 100)
	local tween1 = self.rect:DOAnchorPosY(self.rectPosition.y + 10, 0.2)
	local tween2 = self.rect:DOAnchorPosY(self.rectPosition.y, 0.2)

	local sequence = DOTween.Sequence()
	sequence:Append(tween1)
	sequence:Append(tween2)
	self.opensequence = sequence
end

function MainChatPanel:SetChatObjDepth()
	 
	local curDepth = UILayerTool.GetNextDepth(2)
	self.listRender2:ExecuteMethod("UpdateDepth",curDepth - 2)
end


return MainChatPanel