local logic = template({}, "sprite.buff.buff_timemerge")

function logic:ontinterval(level)
    self:_changemp()
end

function logic:onshorten(rate)
    local left = self:countleft()
    if left and left > 0 then
        self:_changemp(left, rate)
    end
end

function logic:_changemp(count, rate)
    local target, attrtarget, percent, attr, value, bsct = table.unpack(self.static.args_script[1])
    value = value * self:getlevel()
    count = count or 1
    rate = rate or 1000
    local fromobj = self.buff:getfromobj() or self.owner
    local targetobj = self:gettargetobj(target)
    local attrtargetobj = self:gettargetobj(attrtarget)
    local damage_table =  {fromobj = fromobj, toobj = targetobj, value = 0, buffid = self.static.id}
    if percent == 1 then
        local attrname = CONST.ATTR[attr]
        local value = self:amendment(value)
        value = tsmath.rate(attrtargetobj.attr[attrname], value) * count
        value = tsmath.rate(value, rate)
        damage_table.value = value
        targetobj.caller.mp:buff_change(value, fromobj, bsct)
    else
        local value = self:amendment(value)
        damage_table.value = value
        targetobj.caller.mp:buff_change(value, fromobj, bsct)
    end
    fromobj:sendmessage(eventdef.buff_mp_change, damage_table)
end

return logic
