-- 地精喽啰
local conf = {skill = {}, buff = {}}

--7141 普攻
conf.skill[714101] = {
    action = {
        default = {
            {trigger.time, {0}, caller.view.active, "attack01" },
            {trigger.time, {500}, caller.skill.cast, script.static("id")},
            {trigger.time, {1000} },
        },
    },
}

return conf