
local MarqueeMediator = MarqueeMediator or BaseClass(StdMediator)
function MarqueeMediator:OnEnterScenceFrist()
end

function MarqueeMediator:OnEnterScenceEnd()
	local MarqueeProxy = require "Modules.Marquee.MarqueeProxy"
	local SceneManager = require "Modules.Scene.SceneManager"
	local SceneDef = require "Modules.Scene.SceneDef"
	local enterSceneType = SceneManager.Instance.enterSceneType
	if enterSceneType ~= SceneDef.SceneType.Main then
		MarqueeProxy.Instance:SetMarqueeShowActive(false)
		LuaLayout.Instance:CloseWidget(UIWidgetNameDef.MarqueeView)
	else
		MarqueeProxy.Instance:SetMarqueeShowActive(true)
		MarqueeProxy.Instance:ClearMarqueeInfos()
	end
end

return MarqueeMediator