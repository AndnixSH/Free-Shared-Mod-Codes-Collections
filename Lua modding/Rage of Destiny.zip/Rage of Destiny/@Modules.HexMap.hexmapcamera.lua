local render_camera = require "Battle.render.camera.render_camera"

local hexmapcamera = {}

local function reset()
    hexmapcamera._following = false
    hexmapcamera._enable_input = true
    hexmapcamera._attach_effect = nil
end


function hexmapcamera.init()
    reset()
    render_camera.free_trunk_strategy()
    -- print('hexmapcamera.init')
end

function hexmapcamera.destroy()
    reset()
    render_camera.free_trunk_strategy()
    render_camera.free_face_strategy()
    render_camera.remove_story_line_camera()
    hexmapcamera.detach_effect()
    -- print('hexmapcamera.destroy')
end

function hexmapcamera.info(offset, edge)
    render_camera.set_story_line_camera_info(offset, edge)
end

function hexmapcamera.start(position)
    render_camera.set_story_line_camera(position)
end

function hexmapcamera.enable_input(enable)
    if enable ~= hexmapcamera._enable_input then
        hexmapcamera._enable_input = enable
        render_camera.enable_story_line_input(enable)
        -- print("enable_input", enable, debug.traceback())
    end
end

-- 跟随移动物体 马车/子弹等
function hexmapcamera.start_face_follower(canchor)
    if not hexmapcamera._following then
        hexmapcamera._following = true
        render_camera.face_story_line_camera(canchor)
        -- print("face_story_line_camera", debug.traceback())
    end
end

function hexmapcamera.stop_face_follower()
    if hexmapcamera._following then
        hexmapcamera._following = false
        render_camera.free_face_strategy()
        -- print("free_face_strategy", debug.traceback())
    end
end

function hexmapcamera.set_target_position(position, speed)
    hexmapcamera.stop_face_follower()
    render_camera.set_story_line_target_position(position.x, position.y, position.z, speed)
    -- print('set_target_position', position, debug.traceback())
end

function hexmapcamera.attach_effect(prefab_id)
    hexmapcamera.detach_effect()

    if prefab_id then
        local map_effect_model = require "Modules.HexMap.map_effect_model"
        local bone_camera_anchor = require "Battle.render.anchor.bone_camera_anchor"
        local anchor = bone_camera_anchor.New()
        hexmapcamera._attach_effect = map_effect_model.New(anchor, prefab_id)
    end
end

function hexmapcamera.detach_effect()
    if hexmapcamera._attach_effect then
        hexmapcamera._attach_effect:release()
        hexmapcamera._attach_effect = nil
    end
end

function hexmapcamera.attach_mask()
    local hexmaprender = require "Modules.HexMap.hexmaprender"
    hexmapcamera._mask_effect = hexmaprender.start_view_args({type = 11, prefab_id = "Eff_24003_mask", position = Vector3.zero })
end

function hexmapcamera.detach_mask()
    if hexmapcamera._mask_effect then
        local hexmaprender = require "Modules.HexMap.hexmaprender"
        hexmaprender.stop_view(hexmapcamera._mask_effect)
        hexmapcamera._mask_effect = nil
    end
end


return hexmapcamera