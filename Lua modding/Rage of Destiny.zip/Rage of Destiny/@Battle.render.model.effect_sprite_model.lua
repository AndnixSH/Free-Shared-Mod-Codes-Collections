local base_sprite_model = require "Battle.render.model.base_sprite_model"
local effect_sprite_model = BaseClass(base_sprite_model)

local cEffectSpriteModel = CS.LJY.NX.EffectSpriteModel

function effect_sprite_model:__init(anchor, model_name, layer, callback)
    self.anchor = anchor
    if not layer then
        self.cmodel = cEffectSpriteModel(anchor.canchor, model_name)
    else
        if not callback then
            self.cmodel = cEffectSpriteModel(anchor.canchor, model_name, layer)
        else
            self.cmodel = cEffectSpriteModel(anchor.canchor, model_name, layer, callback)
        end
    end

end

return effect_sprite_model