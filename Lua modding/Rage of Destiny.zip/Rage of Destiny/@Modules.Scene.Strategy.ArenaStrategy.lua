local AudioManager = require "Common.Mgr.Audio.AudioManager"
local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"
local SceneProxy = require "Modules.Scene.SceneProxy"
local ArenaProxy = require "Modules.Arena.ArenaProxy"
local BasicBattleStrategy = require "Modules.Scene.Strategy.BasicBattleStrategy"
local ArenaStrategy = ArenaStrategy or BaseClass(BasicBattleStrategy)

local _wincamp = nil
local _playerlist = nil
local _restart = false
local sceneid=2801
function ArenaStrategy:OnLoad()

   -- LuaLayout.Instance:OpenWidget(UIWidgetNameDef.NetworkDelayView)
    self:LoadScene(sceneid)  --测试
end

-- function ArenaStrategy:Destroy()
--     self:UnloadScene()
-- end

function ArenaStrategy:OnStartEntry()
    -- print("------->>OnStartEntry",table.dump(self.args))
    _restart = false
    _wincamp = nil
    _playerlist = self.args[1]
    local key=10011 --测试
    local cfg=SceneProxy.Instance:GetSceneCfgById(sceneid)
    if cfg and cfg.prefab_id then
        key = cfg.battle_key
    end
    local gameprop = {rawplayers = _playerlist.playerlist,config_key =key}     
    self:StartGame()
    --战斗内暂停界面显示
    local view=LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleStopView)
    if view then
        view.data={activityid=ACTIVITYID.ARENA}
        view:OpenView()
    end
    --AudioManager.PlayBGM("battle_arena_bg")
    --LuaLayout.Instance:CloseWidget(UIWidgetNameDef.NetworkDelayView)
end

function ArenaStrategy:OnGetConfigKey()
    local key=10011 --测试
    local cfg=SceneProxy.Instance:GetSceneCfgById(sceneid)
    if cfg and cfg.prefab_id then
        key = cfg.battle_key
    end
    return key
end

function ArenaStrategy:OnStartGame()	   
    
end
function ArenaStrategy:OnReportSettleGame(wincamp)
    local BattleProxy = require "Modules.Battle.BattleProxy"
    BattleProxy.Instance:EscGame()
end

function ArenaStrategy:OnSettleGame(wincamp,rewards, buffer_str)
    _wincamp = wincamp 
    --print("-----------------ArenaStrategy----------OnSettleGame--------------------------------")
    if #rewards > 0 then
        --print("OnSettleGame==rewards==",table.dump(rewards))
        local rewardlist={}
        --local enemyid, towerid = string.unpack(">I4I4", buffer_str)
        for _, v in ipairs(rewards) do
            if v then
                local item={}
                item.goodsid=v[1]
                item.goodsnum=v[2]
                table.insert(rewardlist,item)
               
            end
        end
        GameLogicTools.ShowGetItemView(rewardlist,1,function (  )
            self:SettleGame(buffer_str)
        end)
    else
        self:SettleGameDelayTime(function()
        
            self:SettleGame(buffer_str)
        end)
        
    end
    
end

function ArenaStrategy:SettleGame(buffer_str)
    local data=false

    if buffer_str ~= "" then
        data={}
        local chanllege_times = 0
        data.rank, data.my_diff_rank,data.enemy_uin, data.my_points, data.my_diff_points, data.enemy_points, data.enemy_diff_points,data.record_id,chanllege_times = string.unpack(">I2i2I4I2i2I2i2I2I2",buffer_str)
        
        local IGGSdkDef = require "Modules.IGGSdk.IGGSdkDef"
        local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
        local count = chanllege_times
        if IGGSdkDef.AFEventArena[count] then
            IGGSdkProxy.Instance:Track(IGGSdkDef.AFEventArena[count])
        end    
        --print("SettleGame------------------=",table.dump(data))
    end
    local view=LuaLayout.Instance:GetWidget(UIWidgetNameDef.ArenaBattleSettlementView)
    if view then
        view.wincamp = _wincamp
        view.battleType = self.strategycfg.activityid
        view.args =data
        --view.enemy_id = args[5]
        --view.enemyData = args[6]
        view:OpenView()
    end
    
end

function ArenaStrategy:ClearData()
     
end

function ArenaStrategy:OnDestroyGame()
    self:UnloadScene()
    -- print("ArenaStrategy OnDestroyGame=============")
    self:ClearData()
    
    if ArenaProxy.Instance:GetEnterFromPage() ~= - 1 then
        local SceneManager = require "Modules.Scene.SceneManager"
        local SceneDef = require "Modules.Scene.SceneDef"
        local enter_page = UIWidgetNameDef.ArenaChallengeView
        if ArenaProxy.Instance:GetEnterFromPage() == 2 then
            enter_page = UIWidgetNameDef.ArenaRecordView
        end
        SceneManager.Instance:EnterScene(SceneDef.SceneType.Main, {UIWidgetNameDef.ArenaView,enter_page})
    end
end

function ArenaStrategy:OnRestartGame()
    self:Destroy() 
end

function ArenaStrategy:OnGamePrepared()

    local breport =self.args[2].breport
    local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.ArenaBattleView)
    if view then
        view.breport= breport
        view:OpenView()
    end
    --LuaLayout.Instance:OpenWidget(UIWidgetNameDef.ArenaBattleView)  
end


function ArenaStrategy:OnRequireSettle(result, gameprop, total_time)

    local settlestr = self:GetSettleStr()
    local bufferstr = string.pack(">I4s2I4",self.args[2].enemy_uin or 0, settlestr, total_time)
    self:RequireNetworkSettle(self.strategycfg.activityid, result, bufferstr)
end

return ArenaStrategy