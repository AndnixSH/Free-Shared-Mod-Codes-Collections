-- 罗珊-燃情舞娘
local conf = { skill = {}, buff = {}, bullet = {} }

-- 燃情火种（普攻）——远程丢出燃情火种，对最近的敌人造成70%攻击力的伤害。

conf.skill[130601] = {
    action = {
        default = {
            {trigger.time, {0}, action.active, script.prop('active'), },
            {trigger.time, {500}, caller.body.addchild, script.prop('bullet_type'), scriptcommon.bullet_trace,  script.prop('bullet_args')},
            --{trigger.time, {500}, action.cast, },
            -- {trigger.time, {0}, action.addstartbuff},
            {trigger.time, {500} },
        },
    },
    event = {
        {scriptevent.onstart, onfire = function(self)
            local randomid = tsmath.random(2)
            self.prop.bullet_type =  {typeid = (130600 + randomid)}
            self.prop.bullet_args = {speed = 10000, duration = 2000, rangeid = 130601}
            self.prop.active = ("attack0"..randomid)
        end},
        
        {scriptevent.onend, onfire = function(self)
            self.caller.buff:add(130601)
        end}
    }
}


-- 燃情火种（普攻2形态）治疗队友或者伤害敌人
conf.skill[130651] = script.composite {
    main ={
        action = {
            default = {
                {trigger.time, {0}, action.active_random, {"spell_02"}, },
                {trigger.time, {866},},
                {trigger.time, script.prop('casttime'), action.message, "130651_cast"},
                {trigger.time, {500} },
            },
        },
        event ={
            {scriptevent.onstart, onfire = function(self)
                local friendbullet = {130651,130652,130653,130653}
                local enemybullet = {130621,130622,130623,130624}
                local slotlevel = self.caller.skill:getslotlevel(SKILL.SLOT.SKILL3)
                local bullet_count = slotlevel >= 3 and 4 or 3
                self.prop.bullet_id_friend = friendbullet[slotlevel]
                self.prop.bullet_id_enemy = enemybullet[slotlevel]
                self.prop.casttime = {0,100, bullet_count}
            end},

            {"130651_cast", onfire = function(self)
                local ifheal = #self.action:range(130651) >= 1 and tsmath.random_match(700) or false -- 没有其他队友则全部发射伤害子弹
                local typeid = ifheal and 130621 or 130622
                local rangeid = ifheal and self.prop.bullet_id_friend or self.prop.bullet_id_enemy
                local castid = rangeid
                self.prop.bullet_args = {speed = 12000, duration = 2000, rangeid = rangeid, castid = castid}
                -- self.action:addchild({typeid = typeid}, "bullet")
                self.caller.body:addchild({typeid = typeid}, scriptcommon.bullet_trace, self.prop.bullet_args)
            end},
                
            {scriptevent.onend, onfire = function(self)
                self.caller.skill:changeslot(SKILL.SLOT.NORMAL, 130601)
            end}
        },
    },
    bullet = {
        event = {
            {scriptevent.onstart, onfire = function(self)
                self.caller.body:addscript(scriptcommon.bullet_trace, self.prop.bullet_args)
            end},
            {eventdef.sprite_collide, onfire = function(self,target)
            end},
        },
    }
}

-- 漫天花火 "冲向最密集的敌人区域热舞，扬起漫天花火，每隔0.5s对范围内的敌人造成n%攻击力的伤害，持续2秒，舞蹈期间自己免疫所有伤害与控制效果，结束后自身归位，命中的敌人有50%的概率在未来3秒内无法使用任何攻击和技能。

conf.skill[130611] = {
    action = {
        default = {
            {trigger.time, {0},             action.active, "spell_01_start", caller.skill.pause, 1000},
            {trigger.time, {500},           action.addstartbuff },
            {trigger.close_select, {stopdis = 700, speed = 30000, duration = 500}, caller.body.stop },
            -- {trigger.time, {0}, action.active, "spell_01_start", },
            {trigger.time, {200},           action.active, "spell_01_loop",},
            {trigger.time, {100,1000,3},    action.cast, },
            {trigger.time, {0},             action.active, "spell_01_end",},
            {trigger.time, {0},             caller.body.setposition, script.prop("position")},
            {trigger.time, {1700} },
        },
    },
    event = {
        {scriptevent.onstart, onfire = function(self)
            self.prop.position = self.owner.body.position
        end },
        {eventdef.skill_damage, onfire = function(self, damage_table)
            if damage_table.source.castid == self.static.id then
                for _, friend in ipairs(self.action:range(SKILL.RANGEID.FRIENDS_CLOSE_MID)) do
                    friend.caller.hp:heal(damage_table.value, self.owner)
                end
            end
        end },
        {scriptevent.onend, onfire = function(self)
            self.caller.buff:removelist({130612,130613})
        end }
    }
}

-- 2级：伤害提升至n%攻击力
-- 3级：持续时间延长至4秒
conf.skill[130612] = conf.skill[130611]
conf.skill[130613] = conf.skill[130611]


-- 治愈热舞 罗珊每普攻3下后，下次普攻会变为向随机的3名英雄发射3颗火种，
-- 命中友军回复其n%攻击力的生命，命中敌人造成m%攻击力的伤害
conf.skill[130621] = {
    event = {
        {scriptevent.onstart, onfire = function(self)
            self.prop.count = self.prop.skill_lv >= 2 and 2 or 3
        end },
        {eventdef.buff_start, onfire = function(self,buffid)
            if buffid == 130601 and self.caller.buff:getlevel(buffid) == self.prop.count then
                self.caller.skill:changeslot(SKILL.SLOT.NORMAL, 130651)
                self.caller.buff:remove(130601)
            end
        end},
    },  
}

-- 2级：治疗量提升至n%攻击力，伤害量提升至m%攻击力
conf.skill[130622] = conf.skill[130621]
-- 3级：发射的火种增加至5颗
conf.skill[130623] = conf.skill[130621]
-- 4级：治疗量提升至n%攻击力，伤害量提升至m%攻击力
conf.skill[130624] = conf.skill[130621]


-- 幻舞迷踪

-- 罗珊受到伤害时，瞬移至随机目标身后，优先选择友军英雄，
-- 在落点处产生力场，力场内的友军目标每0.5s回复n%攻击力的生命，敌军目标每0.5s损失m%攻击力的血量，持续x秒
conf.skill[130631] = script.composite {
    main = {
        action = {
            default = {
                {trigger.time, {0}, action.active,"spell_03"},
                {trigger.time, {500}, caller.skill.blink_select, -1600, 130671},
                {trigger.time, {10}, action.addchild, {typeid = 999999}, "bullet_single"},
                {trigger.time, {0}}
            }
        },
        event = {
            {scriptevent.onstart,onfire = function(self)
                local slotlevel = self.caller.skill:getslotlevel(SKILL.SLOT.SKILL4)
                self.prop.healid = slotlevel == 2 and 130674 or 130673
                self.prop.damageid = 130672
            end},
        },
        check = {
            event = {
                {eventdef.hp_change, onfire = function (self, value)
                    if value < 0 then
                        self.action:checksucc()
                    end
                end},
            }
        }
    },
    bullet_single = {
        action = {
            default = {
                {trigger.time, {0}, action.active, "130631"},
                {trigger.time, {500,1000, 4}, action.cast, script.prop("healid"), action.cast, script.prop("damageid")}, -- 留下旋涡
                --{define = script.equal("ultimatelevel", 1), trigger.time, {0}, action.cast, 130312},
                {trigger.time, {1000}, caller.body.destroy},
            },
            event = {
            },
        },
    },
}
conf.skill[130632] = conf.skill[130631]

return conf