local CampaignMediator = CampaignMediator or BaseClass(StdMediator)
local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"
local CampaignProxy = require "Modules.Campaign.CampaignProxy"

function CampaignMediator:OnEnterLoadingEnd()
    if SceneManager.Instance.sceneType == SceneDef.SceneType.Main then
        local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.CampaignView)
        if view:IsOpen() then
            view:ShowOpenTween()
        end
    end
end

function CampaignMediator:OnEnterScenceFirst()
    self:DelayExecute(function()
        CampaignProxy.Instance:Send51000()
    end)
end

function CampaignMediator:OnEnterScenceEnd()
    if SceneManager.Instance.sceneType == SceneDef.SceneType.Main then
        CampaignProxy.Instance:Send51005()
    end
end

return CampaignMediator