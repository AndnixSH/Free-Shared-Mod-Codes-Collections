local logic = {}

function logic:onbreak()
    return self.owner.buff and self.owner.buff.immune_dead
end

function logic:onenter(time)
end

function logic:onupdate(time, tick)
    if self.owner.buff and self.owner.buff.immune_dead then
        return STATE_STATUS.SUSPEND
    end
    return STATE_STATUS.OVER
end

return logic