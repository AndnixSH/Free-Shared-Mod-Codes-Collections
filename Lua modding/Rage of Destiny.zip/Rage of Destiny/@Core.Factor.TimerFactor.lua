-- 定时器抽象类
TimerFactor = TimerFactor or BaseClass()

local Timer =  require "Common.Util.Timer"

function TimerFactor:__init( )
	self.handles = {}
end

function TimerFactor:__delete()
	for i = #self.handles , 1 , -1 do
		self:RemoveTimer( self.handles[i] )
	end
end

function TimerFactor:CloseAllTimer()
	for i = #self.handles , 1 , -1 do
		self:RemoveTimer( self.handles[i] )
	end
end

function TimerFactor:AddTimer( func , duration , loop , scale )
	loop = loop or -1
	duration = duration or 1
	local timer = Timer.New( func , duration , loop , scale )
	table.insert( self.handles , timer )
	-- TimerMgr.Add( timer )
	timer:Start()
	return timer
end

function TimerFactor:RemoveTimer(timer)
	timer:Stop()
	for i = #self.handles ,1 , -1 do
		if self.handles[i]== timer then
			table.remove(self.handles  , i)
		end
	end
end