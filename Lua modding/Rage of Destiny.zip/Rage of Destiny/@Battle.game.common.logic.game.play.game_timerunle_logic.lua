local logic = { timer = {}, event = { game = {} } }

function logic:oncreate()
    self.current_time = self.static.duration
    self.wincamp = nil
    self.bprepare = false
    self.bpause = false
end

function logic.timer:t1000(time, tick)

    if not self.bprepare  or self.bpause then return end

    self.current_time = self.current_time - tick
    self.current_time = self.current_time < 0 and 0 or self.current_time
    self:sendmessage(eventdef.gametime, self.current_time)

    if not self.wincamp and self.current_time == 0 then
        self:settlewin(CAMP.BLUE)
    end
end

function logic.event.game:gameprepared()
    self.bprepare = true
end

function logic.event.game:gametime_pause()
    self.bpause = true
end

function logic.event.game:gametime_resume()
    self.bpause = false
end

function logic.event.game:gameclear(camp)
    if not self.wincamp then
        local oppsite = self.area:getoppsitecamp(camp)
        self:settlewin(oppsite)
    end
end

function logic:settlewin(camp)
    self.wincamp = camp
    self:sendmessage(eventdef.gamesettle, camp)
    local winners = self.area:getactors(camp)
    for _, actor in ipairs(winners) do
        actor.caller.view:start_active("win")
    end
    self.timer:delay(self.static.settle[camp].duration, self._settlewin)
    
end

function logic:_settlewin()
    local game_input = require "Battle.input.game_input"
    game_input.operation.settle(self.wincamp, global.service.time.time)
end

return logic