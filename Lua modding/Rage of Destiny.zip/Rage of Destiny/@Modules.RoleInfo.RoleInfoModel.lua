RoleInfoModel = {
    uid = 0,
    guserid = 0,
    logintoken = "",
    battletoken = nil,
    nickname = "",
    sex = 0,
    headicon = 0,
    frameicon = 0,
    level = 0,
    viplevel = 0,
    player_exp = 0,
    coin = 0,
    diamond = 0,
    hero_exp = 0,    -- 英雄经验
    hero_essence = 0,   -- 英雄粉尘
    vip_exp = 0,    -- vip经验
    medals_valor = 0,   -- 日常币
    guild_coin = 0,    -- 公会币
    hero_coin = 0,    -- 遣散币
    labyrinth_token = 0, -- 迷宫币
    challenger_coin = 0, -- 竞技币
    twisted_sigil = 0, -- 梦境币
    companion_points = 0, -- 友情币
    common_scrolls = 0,-- 普通抽奖券
    faction_scrolls = 0, -- 种族抽奖券
    stargze_scrolls = 0,  -- 占星券
    heroic_merit = 0,  -- 迷宫活跃
    inv_essence = 0, --水晶币
    dragon_ball = 0, -- 龙珠
    crash = 0,    -- 现金
    mobilize_point = 0,--命运总动员积分
    
    timeonline = 0,
    servertime = 0,
    zone_id = 0,
    server_id = 0,
    player_id = 0, -- for sdk login
    tradeuid = "", -- for sdk login
    mainnewbieid = 0, --主界面的引导id
    mainlineid = 1, --主线关卡id
    current_section = 1, --当前章节

    token = "",

    serverTimeZone = 0, --服务器时区
    is_open_rating = 0, --是否打开过评星
}

-- 货币类型
CURRENCY_TYPE = {
    crash = 0,    -- 现金
    diamond = 1,    -- 钻石
    coin = 2,    -- 金币
    player_exp = 3,    -- 账号经验
    hero_exp = 4,    -- 英雄经验
    vip_exp = 5,    -- vip经验
    medals_valor = 6,   -- 日常币
    guild_coin = 7,    -- 公会币
    hero_coin = 8,    -- 遣散币
    labyrinth_token = 9, -- 迷宫币
    challenger_coin = 10, -- 竞技币
    twisted_sigil = 11, -- 梦境币
    companion_points = 12, -- 友情币
    heroic_merit = 13,  -- 迷宫活跃
    inv_essence = 14, -- 水晶币
    dragon_ball = 15, -- 迷宫龙珠
    recruit_merit = 16,-- 新兵训练活跃
    tree_exp = 17,
    mobilize_point = 18, --命运总动员积分
}

CURRENCY_TYPE_GOODID = {
    [CURRENCY_TYPE.diamond] = 701001,
    [CURRENCY_TYPE.coin] = 702001,
    [CURRENCY_TYPE.player_exp] = 703001,
    [CURRENCY_TYPE.hero_exp] = 704001,
    [CURRENCY_TYPE.vip_exp] = 705001,
    [CURRENCY_TYPE.medals_valor] = 706001,
    [CURRENCY_TYPE.guild_coin] = 707001,
    [CURRENCY_TYPE.hero_coin] = 708001,
    [CURRENCY_TYPE.labyrinth_token] = 709001,
    [CURRENCY_TYPE.challenger_coin] = 710001,
    [CURRENCY_TYPE.twisted_sigil] = 711001,
    [CURRENCY_TYPE.companion_points] = 712001,
    [CURRENCY_TYPE.heroic_merit] = 713001,
    [CURRENCY_TYPE.inv_essence] = 714001,
    [CURRENCY_TYPE.dragon_ball] = 715001,
    [CURRENCY_TYPE.recruit_merit] = 718001,
    [CURRENCY_TYPE.tree_exp] = 720001,
    [CURRENCY_TYPE.mobilize_point] = 721001,
}

CURRENCY_TYPE_SPRITENAME = {
    [CURRENCY_TYPE.diamond] = "zuanshi",
    [CURRENCY_TYPE.coin] = "jinbi",
    [CURRENCY_TYPE.player_exp] = "zhanghaojingyan",
    [CURRENCY_TYPE.hero_exp] = "yingxiongjingyan",
    [CURRENCY_TYPE.vip_exp] = "vipex",
    [CURRENCY_TYPE.medals_valor] = "zuanshi",
    [CURRENCY_TYPE.guild_coin] = "gonghuibi",
    [CURRENCY_TYPE.hero_coin] = "qiansanbi",
    [CURRENCY_TYPE.labyrinth_token] = "migongbi",
    [CURRENCY_TYPE.challenger_coin] = "jingjibi",
    [CURRENCY_TYPE.twisted_sigil] = "zuanshi",
    [CURRENCY_TYPE.companion_points] = "shuijing",
    [CURRENCY_TYPE.heroic_merit] = "zuanshi",
    [CURRENCY_TYPE.recruit_merit] = "zuanshi",
    [CURRENCY_TYPE.tree_exp] = "T_water",
    [CURRENCY_TYPE.mobilize_point] = "",
}
