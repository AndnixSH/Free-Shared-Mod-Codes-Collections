
local factory = {}

function factory:init()
    self._service = global.service
    self._loader_service = {}
end

local function error_readonly_handler(t, k, v)
    error(string.format("attempt to update a read-only table [ key = %s, value = %s ]", k, v))
end

function factory:createlogic(obj, typeid, static, prop, template)

    if obj._dirty then
        global.debug.warning("obj已经脏了你还在create", obj, typeid, debug.traceback())
        -- return
    end

    local instance = { typeid = typeid }
    if static then
        instance.static = {}
        setmetatable(instance.static, { __index = static, __newindex = error_readonly_handler, __metatable = false })
    end
    if prop then
        instance.prop = {}
        for k, v in pairs(prop) do
            instance.prop[k] = v
        end
    end
    if template then
        setmetatable(instance, { __index = template, __tostring = template.tostring })
    end
    self:load(instance, obj)
    self._service.pool:add_logic(obj, instance, typeid)
    return instance
end

function factory.destroylogic(logic, immediate)
    if logic._dirty then return end
    logic._dirty = true
    if immediate then
        factory._destroylogic(logic)
    else
        factory._service.frame:afterframe(factory._destroylogic, logic)
    end
end

function factory.sendmessage(logic, eventkey, ...)
    logic.owner:sendmessage(eventkey, ...)
end

function factory.callmessage(logic, eventkey, ...)
    return logic.owner:callmessage(eventkey, ...)
end

function factory._createlogic(logic, typeid, prop)
    return logic.owner:createlogic(typeid, prop)
end

function factory.setprop(logic, prop)
    logic.prop = logic.prop or {}
    for k, v in pairs(prop) do
        logic.prop[k] = v
    end
end

function factory._destroylogic(logic)
    local owner = logic.owner
    factory:unload(logic, owner)
    factory._service.pool:remove_logic(owner, logic, logic.typeid)
    logic.owner = nil
end

function factory._valid(logic)
    return not logic._dirty
end

function factory:addloader(name, service, isassign)
    table.insert(self._loader_service, { name = name, service = service, isassign = isassign } )
end

function factory:load(logic_class, owner)

    for _, loader in ipairs(self._loader_service) do
        if loader.isassign then
            logic_class[loader.name] = loader.service
        elseif logic_class[loader.name] then
            logic_class[loader.name] = loader.service:load(logic_class[loader.name], logic_class, owner)
        end
    end
    
    logic_class.owner = owner
    logic_class.time = self._service.time
    logic_class.emitter = self._service.eventslots:getemitter()
    logic_class.caller = owner.caller
    logic_class.destroy = self.destroylogic
    logic_class.sendmessage = self.sendmessage
    logic_class.callmessage = self.callmessage
    logic_class.createlogic = self._createlogic
    logic_class.setprop = self.setprop
    logic_class.service = self._service
    logic_class.valid = self._valid
    if logic_class.oncreate then
        logic_class:oncreate()
    end
end

function factory:unload(logic_class, owner)

    for _, loader in ipairs(self._loader_service) do
        if loader.isassign then
            -- logic_class[loader.name] = nil
        elseif logic_class[loader.name] then
            loader.service:unload(logic_class[loader.name], logic_class, owner)
            -- logic_class[loader.name] = nil
        end
    end

    if logic_class.ondestroy then
        logic_class:ondestroy()
    end

    for _, loader in ipairs(self._loader_service) do
        if loader.isassign then
            logic_class[loader.name] = nil
        elseif logic_class[loader.name] then
            if loader.service.after_unload then
                loader.service:after_unload(logic_class[loader.name], logic_class, owner)
            end
            logic_class[loader.name] = nil
        end
    end
    
    logic_class.owner = nil
    logic_class.time = nil
    logic_class.emitter = nil
    logic_class.caller = nil
    logic_class.destroy = nil
    logic_class.sendmessage = nil
    logic_class.callmessage = nil
    logic_class.createlogic = nil
    logic_class.setprop = nil
    logic_class.service = nil
end

function factory:dispose()
    self._service = nil
    self._loader_service = nil
end

return factory