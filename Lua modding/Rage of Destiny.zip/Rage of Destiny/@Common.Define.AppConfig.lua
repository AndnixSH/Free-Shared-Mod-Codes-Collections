AppConfig = {
    ISALONE = false,
    SystemOpen = false, --true:开启全部系统
    IsLoginCheck = true,
    IsOpenNewbie = true, --true:开启新手引导 false:屏蔽引导
    IsOpenTranslate = true,--true,开启聊天翻译, false 屏蔽聊天翻译
    OpenTranslate_Ver = "1.1.0"
}