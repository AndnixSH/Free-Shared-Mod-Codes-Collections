
local NPCDialogueProxy = BaseClass(BaseProxy)

function NPCDialogueProxy:__init()
    NPCDialogueProxy.Instance = self

end

function NPCDialogueProxy:__delete()
    NPCDialogueProxy.Instance = nil
end

function NPCDialogueProxy:GetCfgById(id)
    local config=ConfigManager.GetConfig("data_guide")
    if config then
        return config[id]
    end
end


return NPCDialogueProxy