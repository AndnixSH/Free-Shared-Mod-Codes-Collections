--[[
-- added by wsh @ 2017-12-18
-- string扩展工具类，对string不支持的功能执行扩展
--]]

local unpack = unpack or table.unpack

-- 字符串分割
-- @split_string：被分割的字符串
-- @pattern：分隔符，可以为模式匹配
-- @init：起始位置
-- @plain：为true禁用pattern模式匹配；为false则开启模式匹配

-- local function split(split_string, pattern, search_pos_begin, plain)
-- 	assert(type(split_string) == "string")
-- 	assert(type(pattern) == "string" and #pattern > 0)
-- 	search_pos_begin = search_pos_begin or 1
-- 	plain = plain or true
-- 	local split_result = {}

-- 	while true do
-- 		local find_pos_begin, find_pos_end = string.find(split_string, pattern, search_pos_begin, plain)
-- 		if not find_pos_begin then
-- 			break
-- 		end
-- 		local cur_str = ""
-- 		if find_pos_begin > search_pos_begin then
-- 			cur_str = string.sub(split_string, search_pos_begin, find_pos_begin - 1)
-- 		end
-- 		split_result[#split_result + 1] = cur_str
-- 		search_pos_begin = find_pos_end + 1
-- 	end

-- 	if search_pos_begin < string.len(split_string) then
-- 		split_result[#split_result + 1] = string.sub(split_string, search_pos_begin)
-- 	else
-- 		split_result[#split_result + 1] = ""
-- 	end

-- 	return split_result
-- end

local function split(str, pattern)
	if str == nil or str == "" or pattern == nil then return nil end
	local result = {}
	for match in (str .. pattern):gmatch("(.-)"..pattern) do
		table.insert(result, match)
	end
	return result
end

-- 字符串连接
local function join(join_table, joiner)
	if #join_table == 0 then
		return ""
	end

	local fmt = "%s"
	for i = 2, #join_table do
		fmt = fmt .. joiner .. "%s"
	end

	return string.format(fmt, unpack(join_table))
end

-- 是否包含
-- 注意：plain为true时，关闭模式匹配机制，此时函数仅做直接的 “查找子串”的操作
local function contains(target_string, pattern, plain)
	plain = plain or true
	local find_pos_begin, find_pos_end = string.find(target_string, pattern, 1, plain)
	return find_pos_begin ~= nil
end

-- 以某个字符串开始
local function startswith(target_string, start_pattern, plain)
	plain = plain or true
	local find_pos_begin, find_pos_end = string.find(target_string, start_pattern, 1, plain)
	return find_pos_begin == 1
end

-- 以某个字符串结尾
local function endswith(target_string, start_pattern, plain)
	plain = plain or true
	local find_pos_begin, find_pos_end = string.find(target_string, start_pattern, -#start_pattern, plain)
	return find_pos_end == #target_string
end

-- 根据长度截断字符串并以end_str补充结尾
local function cutstr(str, cut_len, end_str)
	local result = str
	local strLen = utf8.len(str)
	if cut_len < 1 or cut_len >= strLen then
		print("cut_len 输入长度非法")
		return result
	end
	local offsetIndex = utf8.offset(str, cut_len + 1) - 1
	local cutStr = string.sub(str, 1, offsetIndex)
	result = cutStr .. end_str
	return result
end

local function isEmpty(str)
	return str == nil or str == string.Empty or str == ""
end

--改变一些逻辑中定义好的文本, str中匹配符的(int)key 如果在后续的对应args则替换
--ps str = [utc]2[/utc], utcargs = {[2] = 123}, return str = 123
-- function regmatchstr(str, utcargs)
	
-- 	--时间戳转换 [utc] [/utc]
-- 	local utcstr = str
-- 	-- local idx = 1
-- 	for s in string.gmatch(utcstr, "%[utc](%d+)%[/utc]") do
-- 		local key = '%[utc]'..s..'%[/utc]'
-- 		-- str = string.gsub(str, key, os.date("%Y/%m/%d %H:%M:%S", s))
-- 		-- str = string.gsub(str, key, utcargs[idx])
-- 		-- idx = idx + 1
-- 		if tonumber(s) and utcargs[tonumber(s)] then
-- 			str = string.gsub(str, key, utcargs[tonumber(s)])
-- 		end	
-- 	end
-- 	return str
-- end

--改变一些逻辑中定义好的文本, str中匹配符的(int)key 如果在后续的对应args则替换
--args_list:list => args
--args[0] = key, args[{>0..}] = value
--eg: str = abc[utc]2[/utc]abc, args = {[0] = "utc",[2] = 123}, return str = abc123abc
local function regmatchstr(str, args_list)
	for _, args in ipairs(args_list) do
		local left = "%["..args[0].."]"
		local right = "%[/"..args[0].."]"
		local regkey = left.."(%d+)"..right
		for s in string.gmatch(str, regkey) do
			local key = left..s..right
			if tonumber(s) and args[tonumber(s)] then
				str = string.gsub(str, key, args[tonumber(s)])
			end	
		end		
	end
	return str
end

string.split = split
string.join = join
string.contains = contains
string.startswith = startswith
string.endswith = endswith
string.cutstr = cutstr
string.isEmpty = isEmpty
string.regmatchstr = regmatchstr