eventmdf = 
{
    private = "private",  -- 自己
    public = "public",    -- 所有人的  fromobj
    excludeself = "excludeself",  -- 除了自己  fromobj
}

eventslot = {
    sprite = "sprite",
    game = "game",
    attr = "attr",
    script = "script",
}

eventdef = 
{
    --[[*******************精灵事件*******************]]
    -- 技能
    skill_eva           = "skill_eva",                     -- 技能闪避（闪避了其他人的伤害）
    skill_immune        = "skill_immune",                  -- 技能免疫（免疫了其他人的伤害）
    suffer_immune       = "suffer_immune",                 -- 技能免疫（免疫了其他人的伤害）
    before_skill_damage = "before_skill_damage",           -- 技能伤害前   damage_table { fromobj, toobj, damage_type, source = { slotid, castid, castobj  }  }
    check_skill_damage  = "check_skill_damage",            -- 检查技能伤害 同skill_damage
    skill_damage        = "skill_damage",                  -- 技能伤害    damage_table { fromobj, toobj, value, crit, damage_type, source = { slotid, castid, castobj  }  }
    skill_heal          = "skill_heal",                    -- 技能治疗    heal_table { fromobj, toobj, value, source = { slotid, castid, castobj  }  }
    before_skill_heal   = "before_skill_heal",             -- 技能治疗前    heal_table { fromobj, toobj, value, source = { slotid, castid, castobj  }  }
    skill_leach         = "skill_leach",                   -- 技能吸血
    skill_hit           = "skill_hit",                     -- 技能击中
    skill_end           = "skill_end",                     -- 技能结束
    skill_cast          = "skill_cast",                    -- 技能选取
    skill_choose        = "skill_choose",                  -- 技能选取_v2
    skill_pause_end     = "skill_pause_end",               -- 技能暂停结束
    slot_status_change  = "slot_status_change",            -- 槽位状态改变
    slot_use            = "slot_use",                      -- 使用槽位
    slot_charge_interupt= "slot_charge_interupt",          -- 充能打断

    -- buff
    buff_shorten        = "buff_shorten",                  -- buff引爆（被引爆者发出） damage_table { fromobj, toobj, value, buffid, crit }
    buff_heal           = "buff_heal",                     -- buff治疗（buff来源发出） damage_table { fromobj, toobj, value, buffid, crit }
    buff_damage         = "buff_damage",                   -- buff伤害（buff来源发出） damage_table { fromobj, toobj, value, buffid, crit }
    buff_mp_change      = "buff_mp_change",                   -- buff伤害（buff来源发出） damage_table { fromobj, toobj, value, buffid}
    buff_start          = "buff_start",                    -- buff开始（buff受击者发出）
    buff_stop           = "buff_stop",                     -- buff结束
    buff_disperse       = "buff_disperse",                 -- buff驱散   { fromobj, toobj, count, disperse_list = { buffid, bufftype } }
    buff_resist         = "buff_resist",                   -- buff抵抗   { buffid, config }

    -- 其他
    sprite_dead         = "sprite_dead",                   -- 精灵死亡
    sprite_collide      = "sprite_collide",                -- 精灵碰撞
    sprite_block        = "sprite_block",                  -- 精灵碰强
    bullet_move_end     = "bullet_move_end",               -- 子弹移动结束
    bullet_move_pause   = "bullet_move_pause",             -- 子弹移动暂停
    monster_dead        = "monster_dead",                  -- 怪物死亡
    hp_change           = "hp_change",                     -- 血量改变
    spd_change          = "spd_change",                    
    atkspd_change       = "atkspd_change",
    spellspd_change     = "spellspd_change",
    movspd_change       = "movspd_change",
    before_suffer_start = "before_suffer_start",           -- 开始suffer前
    suffer_start        = "suffer_start",                  -- 开始suffer
    suffer_end          = "suffer_end",                    -- 结束suffer
    child_add           = "child_add",                     -- 添加孩子  spriteobj
    child_remove        = "child_remove",                  -- 移除孩子  spriteobj
    summon_add          = "summon_add",                    -- 添加召唤物  spriteobj
    summon_remove       = "summon_remove",                 -- 移除召唤物  spriteobj
    suffer_move_start   = "suffer_move_start",             -- 开始suffer移动
    suffer_move_end     = "suffer_move_end",               -- 结束suffer移动
    fake_dead_start     = "fake_dead_start",               -- 假死开始
    fake_dead_end       = "fake_dead_end",                 -- 假死结束

    -- 表现
    start_active        = "start_active",                  -- 播放acitve
    show_view           = "show_view",                     -- 显示精灵
    hide_view           = "hide_view",                     -- 隐藏精灵
    show_title_view     = "show_title_view",                     -- 显示精灵血条
    hide_title_view     = "hide_title_view",                     -- 隐藏精灵血条
    damagesct           = "damagesct",                     -- SCT显示
    add_model           = "add_model",                     -- 添加模型
    remove_model        = "remove_model",                  -- 移除模型
    add_active_model    = "add_active_model",              -- 添加active模型
    add_color           = "add_color",                     -- 添加颜色
    remove_color        = "remove_color",                  -- 移除颜色
    add_rim_color       = "add_rim_color",                 -- 添加外发光颜色
    remove_rim_color    = "remove_rim_color",              -- 移除外发光颜色
    add_icon            = "add_icon",                      -- 添加图标
    remove_icon         = "remove_icon",                   -- 移除图标
    add_sound           = "add_sound",                     -- 添加音效
    remove_sound        = "remove_sound",                  -- 移除音效
    add_special_state   = "add_special_state",             -- 添加特殊效果
    remove_special_state= "remove_special_state",          -- 移除特效效果
    start_replace_model = "start_replace_model",           -- 开始替换模型
    stop_replace_model  = "stop_replace_model",            -- 结束替换模型
    set_layer           = "set_layer",
    reset_layer         = "reset_layer",
    --[[*******************精灵事件*******************]]






    --[[*******************玩法事件*******************]]
    gametime_pause      = "gametime_pause",                -- 时间暂停 
    gametime_resume     = "gametime_resume",               -- 时间恢复
    gameclear           = "gameclear",                     -- 玩法胜负
    gameround           = "gameround",                     -- 玩法回合
    gameprepared        = "gameprepared",                  -- 玩法准备完毕 { brecord }
    gametime            = "gametime",                      -- 游戏时间
    gamesettle          = "gamesettle",                    -- 玩法结算
    camera_adjust       = "camera_adjust",                 -- 摄像机调整
    camera_adjust_start = "camera_adjust_start",           -- 摄像机调整开始
    camera_lift         = "camera_lift",                   -- 摄像机抬升
    camera_strategy     = "camera_strategy",               -- 摄像机策略
    --[[*******************玩法事件*******************]]
}