-- 坚木卫士·巴奥（树人）
local conf ={ skill = {}, buff = {}, bullet = {} }

-- 鞭笞（普攻）——两段攻击动作，随机调用，每段造成120%攻击力的伤害
conf.skill[310201] = {
    action = {
        default = {
            {trigger.time, {0}, caller.view.active_random, { "attack01", "attack02" }, },
            {trigger.time, {1000}, action.cast, },
            {trigger.time, {500} },
        },
    },
}
-- 进化后普攻升级为远程攻击造成150%攻击力的伤害
conf.skill[310251] = {
    action = {
        default = {
            {trigger.time, {0}, caller.view.active, "attack03", },
            {trigger.time, {1300}, caller.body.addchild, {typeid = 310251}, scriptcommon.bullet_parabola, {height = 2000, duration = 500, rangeid = 310251, castid = 310251} },
            {trigger.time, {300} },
        },
    },
}

-- 森罗密布（必杀技）——生成藤刺向四周逐波散开，三段伤害，每段造成70%攻击力的伤害；进化状态下，额外附带小幅击退效果
conf.skill[310211] = script.composite {
    main = {
        action = {
            default = {
                {trigger.time, {0}, caller.view.active, "spell_01", caller.skill.pause, 1500 },
                -- {define = script.equal("castid", 0), trigger.time, {0}, caller.view.active, "spell_01", caller.skill.pause, 1500 },
                -- {define = script.equal("castid", 1), trigger.time, {0}, caller.view.active, "spell_02_spell01", caller.skill.pause, 1500 },
                -- {trigger.time, {1400}, action.cast, script.prop('castid')},
                {trigger.time, {2000}, action.addchild, script.prop('bullet_type'), "bullet"},
                {trigger.time, {1000} },

                },
        },
        event = {
            {scriptevent.onstart, onfire = function(self)
                self.prop.castid = self.caller.buff:contains(310222) and self.static.id + 50 or self.static.id
                self.prop.evolution = self.caller.buff:contains(310222) and 1 or 0
                self.prop.bullet_type = {typeid = 999999, position = self.owner.body.position}
            end}
        },
        check = function(self)
            return #self.action:range() > 0
        end
    },
    bullet = {
        action = {
            default = {
                {trigger.time, {0}, caller.view.active, "310211"},
                {trigger.time, {100}, action.cast, script.prop('castid')},
                {trigger.time, {1300}, caller.body.destroy},
            }
        },
        event = {
            
        },
    }
    
}
-- 伤害提升至150%攻击力
conf.skill[310212] = conf.skill[310211]
-- 伤害提升至180%攻击力
conf.skill[310213] = conf.skill[310211]


-- 每场战斗使用一次，血量低于30%时，巴奥扎根于地下，一段时间后完成进化，期间免疫伤害，血量回复至最大生命值75%并在原地扎根。扎根后，攻击力提高30%，普攻变为全屏远程攻击。
-- 2级：进化后具备超强的自我回复能力，每秒恢复5%已损失的生命值
-- 3级：扎根后免疫控制效果
-- 4级：进化后回血速度提升至每秒6%的已损失生命值

conf.skill[310221] = {
    action = {
        default = {
            {trigger.time, {0}, caller.view.active, "spell_02_start" },
            {trigger.time, {0}, action.addstartbuff },
            {trigger.time, {0}, caller.view.replace_active, "spell_01", "spell_02_spell01", }, 
            {trigger.time, {0}, caller.view.replace_active, "spell_03", "spell_02_spell03", },
            {trigger.time, {2700} },
        },
    },
    event = {
        { scriptevent.onend, onfire = function (self)
            local add = tsmath.rate(self.owner.attr.hp_max, 750) - self.owner.attr.hp
            self.owner.attr.mov = 0
            self.owner.attr.immune_suffer = 1
            self.caller.hp:heal(add, self.owner)
            self.caller.buff:add(310222)        -- 扎根后，攻击力提高30%
            self.caller.buff:add(310221)        -- 增加conf.buff
            self.caller.body:setweight(999)
            self.caller.skill:changeslot(SKILL.SLOT.NORMAL, 310251)
            self.caller.buff:add_state('used')
            self.caller.view:replace_active("stand","spell_02_stand")
        end }
    },
    check = function (self)
        return self.owner.attr.hp <= tsmath.rate(self.owner.attr.hp_max, 300) and not self.caller.buff:contains_state("used") 
    end
}
conf.buff[3102230] = {
    event = {
        { scriptevent.ontimer,time = {1000,1000}, onfire = function (self)
            local slot3level = self.caller.skill:getslotlevel(SKILL.SLOT.SKILL3)
            local heal_rate = ({0, 50, 50, 60})[slot3level]
            local value = tsmath.rate(self.owner.attr.hp_max - self.owner.attr.hp, heal_rate)
            self.caller.hp:heal(value, self.owner)
            if slot3level >= 2 then
                local targets = self.action:range(SKILL.RANGEID.FRIEND_LOW_HP_HERO)
                for _, target in ipairs(targets) do
                    target.caller.hp:heal(value, self.owner)
                    break
                end
            end
        end },
    },
}
conf.buff[3102250] =conf.buff[3102230]

conf.skill[310222] = conf.skill[310221]
conf.skill[310223] = conf.skill[310221]
conf.skill[310224] = conf.skill[310221]

-- 缠绕术（常规技能2）——缠绕自身周围目标，对其造成120%攻击力的伤害，并使其无法攻击5s
conf.skill[310231] = {
    action = {
        default = {
            {trigger.time, {0}, caller.view.active, "spell_03", },
            {trigger.time, {1000}, action.cast },
            {trigger.time, {0}, action.addstartbuff},
            {trigger.time, {500} },
        },
    },        
    check = function(self)
        return #self.action:range() > 0
    end
}

conf.skill[310232] = conf.skill[310231]

return conf
