local HeroItem = require "Core.Implement.UI.Class.HeroItem"
-- local RelationItem = require "Core.Implement.UI.Class.RelationItem"
local BattleRelationItem = require "Core.Implement.UI.Class.BattleRelationItem"
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"
local UISpriteView = require "Core.Implement.UI.Class.UISpriteView"

local BattleProxy = require "Modules.Battle.BattleProxy"
local HeroProxy = require "Modules.Hero.HeroProxy"
local CampaignProxy = require "Modules.Campaign.CampaignProxy"
local TowerProxy = require "Modules.Tower.TowerProxy"
local ProArenaBattlePanel=require "Modules.Battle.Select.ProArenaBattlePanel"
local BattleSelectHeroItemPanel = require "Modules.Battle.Select.BattleSelectHeroItemPanel"
local SelectTweenPanel = require "Modules.Battle.Select.SelectTweenPanel"
local NewbieWidget = require "Core.Implement.UI.Widgets.NewbieWidget"
local ObjPoolRender = require "Core.Implement.UI.Class.ObjPoolRender"
local ObjPoolItem = require "Core.Implement.UI.Class.ObjPoolItem"
local HexMapProxy = require "Modules.HexMap.HexMapProxy"
local BattleDef = require "Modules.Battle.BattleDef"
local CToggleRender = require "Core.Implement.UI.Class.CToggleRender"
local MercenaryProxy = require "Modules.Mercenary.MercenaryProxy"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local CampaignDef = require "Modules.Campaign.CampaignDef"

local BattleSelectView = BattleSelectView or LuaWidgetClass(NewbieWidget)
function BattleSelectView:__init()
	self.activityid = nil
	self.enemylist = nil
	self.args = nil      --{enemyid, towerid}
	self.heroinfos = nil
	self.enemyinfos = nil
	self.enemyid = nil
	self.panelstr = nil
	self.select_enemy_index = 1
	self.defaultTeams = {}
end

function BattleSelectView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Battle.BattleSelectView",self.LoadEnd)
end

function BattleSelectView:LoadEnd(obj)
	self:SetGo(obj)

	self.relationTopObj = self:GetChild(self.go, "RelationTop")

	self.selectTweenPanel = SelectTweenPanel.New(obj)
	self.battleSelectHeroItemPanel = BattleSelectHeroItemPanel.New(obj)
	self.battleSelectHeroItemPanel:SetOtherTeamGetFunc(function()
			return self:GetOtherTeamHeroList()
		end)
	self.battleSelectHeroItemPanel:SetRemoveTeamHeroFunc(function(herodata)
			return self:RemoveTeamHero(herodata)
		end)
	self.battleSelectHeroItemPanel:SetFilterSameRoleIDHeroFunc(function(teams)
			return self:FilterSameRoleIDHero(teams)
		end)

	self.leftHeroItemObj = self:GetChild(self.go, "Skill_left")
	
    --right
    self.righPaneltObj = self:GetChild(self.go, "right")

	--right
	self.rightObj = self:GetChild(obj, "Skill_right")
	self.rightItemList = {}
	for i=1,5 do
		local item = {}
		local itemObj = self:GetChild(obj, "Skill_right/CButton_hero"..i)
		self:InitHeroItem(item, itemObj, i)
		self.rightItemList[i] = item

		local btn = self:GetComponent(itemObj, "CButton")
		btn:AddClick(function ()
			self:OnClickShowBoss(item)
		end)		
	end
	-- self.rightRelationItem = RelationItem.New(self:GetChild(obj, "TopPanel/jiban2/fill"))
	self.rightRelationItem = BattleRelationItem.New(self:GetChild(obj, "Relation2/fillnew2"), CAMP.RED, 1, self.relationTopObj)
	
	self.battleBtn = self:GetChildComponent(obj, "bottom/CButton_begin", "CButton")
	self.battleBtn:AddClick(function ()
		self:OnClickBattle()
		self:OnTriggerClickBtn(self.battleBtn)
	end)	
	self.passBtn = self:GetChildComponent(obj, "bottom/CButton_pass", "CButton")

	self.closeBtn = self:GetChildComponent(obj, "CButton_close", "CButton")
	self.closeBtn:AddClick(function ()
		if self:IsMultiEnemy() and CampaignProxy.Instance:HasPassOneEnemy(RoleInfoModel.mainlineid) then
			GameLogicTools.ShowConfirmById2(51, function (value)
					if value then
						CampaignProxy.Instance:ClearPassState(RoleInfoModel.mainlineid)
						self:CloseView()
					end
				end)
		else
			self:CloseView()
		end
	end)	

	self.runeObj = self:GetChild(obj, "TopPanel/jiban1/rune")

	self.relationBtn_2 = self:GetChildComponent(obj, "Relation2/fillnew2", "CButton")
	self.relationBtn_2:AddClick(function ()
		self:OnClickRelation(self.rightItemList)
	end)
	self.battleBtnEffect = UIEffectItem.New("UI_Campaign_begin1", self.battleBtn.gameObject)

	self.leftfightBtn = self:GetChildComponent(obj, "TopPanel/jiban1/power", "CButton")
	self.leftfightBtn:AddClick(function ()
		GameLogicTools.ShowLabelTips("unity_tips_1009", self.leftfightBtn.transform.position)
	end)

	self.rightfightBtn = self:GetChildComponent(obj, "TopPanel/jiban2/power", "CButton")
	self.rightfightBtn:AddClick(function ()
		GameLogicTools.ShowLabelTips("unity_tips_1010", self.rightfightBtn.transform.position)
	end)

	--tips
	self.tipsInfoObj = self:GetChild(self.righPaneltObj, "info")
	self.tipsObj = self:GetChild(self.tipsInfoObj, "tips")
	self.tipsBtn = self:GetChildComponent(self.tipsInfoObj, "CButton_info", "CButton")
	self.tipsBtn:AddClick(function ()
		self.tipsObj:SetActive(true)
		self:SetDepth(self.tipsObj , self:GetNextDepth())
		self:OnTriggerClickBtn(self.tipsBtn)
	end)
	self.itemboxcollider = self:GetChildComponent(self.tipsObj, "Black", "CBoxCollider")
   	self.itemboxcollider:AddClick(function(go)
   	    self.tipsObj:SetActive(false)
   	    self:SetDepth(self.tipsObj, 0)
   	end)

   	--fight
   	self.rightFightLbl = self:GetChildComponent(obj, "TopPanel/jiban2/power/COutline_num", "CImageLabel")

   	--info
   	self.titleLbl = self:GetChildComponent(obj, "TopPanel/title/CLabel_title", "CLabel")

	-- self.teamBtn = self:GetChildComponent(obj, "bottom/CButton_team", "CButton")
	-- self.teamBtn:AddClick(function ()		
	-- 	GameLogicTools.ShowMsgTips(self:GetWord("Common_1033"))
	-- end)

	self.backObj = self:GetChild(obj, "CTexture_back")
	self.backEffect = UIEffectItem.New("UI_BattleSelect_back", self.backObj)

	self.bossInfoObj = self:GetChild(obj, "BossInfo")
	self.bossraceSp = self:GetChildComponent(self.bossInfoObj, "title/CSprite_race", "CSprite")
	self.bossnameLbl = self:GetChildComponent(self.bossInfoObj, "title/name", "CLabel")
	self.bossqualityTex = self:GetChildComponent(self.bossInfoObj, "quality", "CTexture")
	-- self.bossTex = self:GetChildComponent(self.bossInfoObj, "CTexture_boss", "CTexture")
	self.uiSpriteView = UISpriteView.New(self:GetChild(self.bossInfoObj ,"SpriteView"))

	self.artifactBtn = self:GetChildComponent(obj, "bottom/CButton_artifact", "CButton")
	self.artifactSp = self:GetChildComponent(obj, "bottom/CButton_artifact/sprite1", "CSprite")
	self.artifact_bshow = false
	self.artifactSp.SpriteName = "shenqi2"
	self.artifactBtn:AddClick(function()
		if self.artifact_bshow == false then
			self.artifact_bshow = true
			if self.activityid == ACTIVITYID.HIGHARENA or self.activityid == ACTIVITYID.ARENA then
				GameLogicTools.ShowMsgTips(self:GetWord("ArenaView_1045"))
			end
		else
			self.artifact_bshow = false
			if self.activityid == ACTIVITYID.HIGHARENA or self.activityid == ACTIVITYID.ARENA then
				GameLogicTools.ShowMsgTips(self:GetWord("ArenaView_1046"))
			end
		end
		self.artifactSp.SpriteName = self.artifact_bshow == true and "shenqi1" or "shenqi2" 
		self.battleSelectHeroItemPanel:ShowArtifactEquip(self.artifact_bshow)
	end)


	self.ProArenaBattlePanel=ProArenaBattlePanel.New(obj)

	self.bShowTeam = false
	self.teamBtn = self:GetChildComponent(self.go, "bottom/CButton_team", "CButton")
	self.teamBtn:AddClick(function ()
		if self.args.lockHero then
			GameLogicTools.ShowMsgTips("MainlineMultiple_1003")
			return
		end
		if not self.bShowTeam then
			self.bShowTeam = true
			if self:IsMultiEnemy() then
				if self.togRender then
					self.togRender.go:SetActive(false)
				end
			end			
			self.battleSelectHeroItemPanel:ShowTeamObj()
			if self.activityid == ACTIVITYID.HIGHARENA then
				self.ProArenaBattlePanel:OnClickTeamBtn()
			end
		else
			self.bShowTeam = false
			if self:IsMultiEnemy() then
				if self.togRender then
					self.togRender.go:SetActive(true)
				end
			end
			self.battleSelectHeroItemPanel:ReShowHeroList()
			if self.activityid == ACTIVITYID.HIGHARENA then
				self.ProArenaBattlePanel:OnClickTeamBtn()
			end
		end
	end)	

	self.topTipsPanelObj = self:GetChild(self.go, "TopPanel/TipsPanel")
	self.topTipsPanelObj:SetActive(false)
	
	self.multiEnemyObj = self:GetChild(self.go, "teaminfo")
	self:InitSelectEnemyContent(self.multiEnemyObj)

	self:SetStep(0)
end

function BattleSelectView:InitSelectEnemyContent(obj)
	self.changeMultiTeamBtn = self:GetChildComponent(obj, "CSprite_changeteam", "CButton")
	self.changeMultiTeamBtn:AddClick(function ()
		self:OpenExchangeTeamView()
	end)
	
	self.fightNumLabel = self:GetChildComponent(obj, "CLabel_team", "CLabel")
	self.togRenderList = {}
	
	local MAX = CampaignDef.Const.MAX_ENEMY_NUM
	for i = 2, MAX do
		local togObj = self:GetChild(obj, "CHorizontalItem_team" .. i)
		local togGroup = self:GetComponent(togObj, "CToggleGroup")
		local togRender = CToggleRender.New()
		togRender:Load(togGroup)
		togRender:AddSelect(function(index)
			self:OnSelectEnemyTogChange(index)
		end)
		
		for n = 1, i do
			togRender:Add()
			togRender:UpdateLabel(n, tostring(n))
		end
		
		self.togRenderList[i] = togRender
	end
end

function BattleSelectView:SetAllMultiEnemyTog()
	self.multiEnemyObj:SetActive(self:IsMultiEnemy())
	self.passBtn.gameObject:SetActive(false)
	if self:IsMultiEnemy() then
		local enemys = self:GetAllEnemy()
		local num = #enemys
		self.fightNumLabel.text = LanguageManager.Instance:GetWord("MainlineMultiple_1001", num)
		
		self.togRender = self.togRenderList[num]
		
		for key,tog in pairs(self.togRenderList) do
			tog.go:SetActive(key == num)
		end
		
		for i, enemyid in ipairs(enemys) do
			local pass = CampaignProxy.Instance:GetPassState(RoleInfoModel.mainlineid, enemyid)
			self.togRender:SetFlag(i, pass)
		end
	end
end

function BattleSelectView:OnSelectEnemyTogChange(index)
	local enemyids = self:GetAllEnemy()
	
	local herolist, rolelist = self.battleSelectHeroItemPanel:GetDefaultSelectHeroList()
	self.defaultTeams[self.select_enemy_index] = herolist
	
	for i,enemyid in ipairs(enemyids) do
		if i ~= self.select_enemy_index then
			local team = self.defaultTeams[i]
			for k,herouid in ipairs(team) do
				if herouid > 0 then
					for j,now_hero_uid in ipairs(herolist) do
						if herouid == now_hero_uid then
							team[k] = 0
							break
						end
					end
				end
			end
		end
	end
	
	self.select_enemy_index = index
	local enemyid = enemyids[index]
	self.battlePanel:SetEnemy(enemyid)
	self.args[1] = enemyid
	
	local pass = CampaignProxy.Instance:GetPassState(RoleInfoModel.mainlineid, enemyid)
	self.passBtn.gameObject:SetActive(pass)
	self.passBtn.IsEnabled = not pass
	self.battleBtn.gameObject:SetActive(not pass)
	
	local enemylist = GameLogicTools.GetEnemyList(enemyid)
	local encoder = NetEncoder.New()
	local encoder = BattleProxy.Instance:_EncodeEnemyInfo(enemylist, encoder, true)
	
	local decoder = NetDecoder.New(encoder.buffer, 1)
	self.enemyinfos = BattleProxy.Instance:_DecodeEnemyInfo(decoder)
	self:UpdateInfo()
end

function BattleSelectView:OnClickRelation(itemlist)
	local list = {}
	for idx, item in pairs(itemlist) do
		if item.herocfgid ~= 0 then
			table.insert(list, item.herocfgid)
		end 
	end
	UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 3, list, CAMP.RED)
end

function BattleSelectView:OnOpen()
	self:AutoRegister()
	self:SetDepth(self.backObj, self.canvasDepth - 1)
	self:SetModelDepth(self.backObj, -300)
	self:SetModelDepth(self.tipsInfoObj, 600)
	
	self.battleBtn.gameObject:SetActive(true)
	self.bShowTeam = false
	self:UpdateInfo()
	self.battleBtnEffect:Open()
	self.backEffect:Open()
	self.selectTweenPanel:Open()
	self:ShowPanel()
	--self:SetDepth(self.righPaneltObj, self:GetNextDepth())
	self:SetDepth(self.leftHeroItemObj, self:GetNextDepth())

	if self.activityid == ACTIVITYID.HIGHARENA then
		local func=function (defaultTeam,enermyTeam,callback  )
			-- self.args.callback=callback --操作英雄后回调 高阶切换队伍需要更新锁的状态
			-- self.args.arenaChange = true
			-- self.battleSelectHeroItemPanel:Open(defaultTeam, self.heroinfos, self.activityid, self.args)
			if self.bShowTeam then
				self.battleSelectHeroItemPanel:ArenaChangeTeam(defaultTeam, self.heroinfos, self.activityid, self.args)
				self.battleSelectHeroItemPanel:UpdateFormationInfo()
			else
				self.args.callback=callback --操作英雄后回调 高阶切换队伍需要更新锁的状态
				self.args.arenaChange = true
				self.battleSelectHeroItemPanel:Open(defaultTeam, self.heroinfos, self.activityid, self.args)
			end

			self.enemyinfos=enermyTeam
			self:ShowEnemyTeam()
		end
		self.battleSelectHeroItemPanel:AddClearBtnCallBack(function (  )
			GameLogicTools.ShowConfirmById(38, function(bValue)
				if bValue then
					self.battleSelectHeroItemPanel:OnClickClearBtn()
				end
			end)
		end)
		self.ProArenaBattlePanel:Open(self.battleSelectHeroItemPanel,1,2,func)
		self.ProArenaBattlePanel:ShowRightGroupObj()
	elseif self.activityid == ACTIVITYID.ARENA then
		self.battleSelectHeroItemPanel:AddClearBtnCallBack(function (  )
			GameLogicTools.ShowConfirmById(38, function(bValue)
				if bValue then
					self.battleSelectHeroItemPanel:OnClickClearBtn()
				end
			end)
		end)
	end
	
	self:SetAllMultiEnemyTog()
	if self:IsMultiEnemy() then
		self:InitMultiEnemyInfo()
	end

	BattleProxy.Instance:StopGame()
	self:RegisterNewbieData()
end

function BattleSelectView:InitMultiEnemyInfo()
	self.defaultTeams = {}
	local enemys = self:GetAllEnemy()
	local pass_map = {}
	for i, enemyid in ipairs(enemys) do
		if CampaignProxy.Instance:GetPassState(RoleInfoModel.mainlineid, enemyid) then
			pass_map[enemyid] = true
		end
	end
	self.select_enemy_index = table.indexof(enemys, self.args[1])

	local herouid_map = {}
	local role_id_map = {}
	for enemyid,v in pairs(pass_map) do
		local index = table.indexof(enemys, enemyid)
		local team = self:GetDefaultTeam({enemyid, RoleInfoModel.mainlineid})
		self.defaultTeams[index] = self:FilterMultiTeam(team, herouid_map, role_id_map)
	end

	if not self.defaultTeams[self.select_enemy_index] then
		--把当前选中队伍先记录
		local team = self:GetDefaultTeam({self.args[1], RoleInfoModel.mainlineid})
		self.defaultTeams[self.select_enemy_index] = self:FilterMultiTeam(team, herouid_map, role_id_map)
	end

	for i,enemyid in ipairs(enemys) do
		if (not pass_map[enemyid]) or (i == self.select_enemy_index) then
			local team = self:GetDefaultTeam({enemyid, RoleInfoModel.mainlineid})
			self.defaultTeams[i] = self:FilterMultiTeam(team, herouid_map, role_id_map)
		end
	end

	self.togRender:SelectIndex(self.select_enemy_index)
end

function BattleSelectView:FilterMultiTeam(team, herouid_map, role_id_map)
	for i,herouid in ipairs(team) do
		if herouid > 0 then
			if herouid_map[herouid] then
				team[i] = 0
			else
				herouid_map[herouid] = true
				local herodata = self:_GetHeroDataByUid(herouid)
				if herodata and (not role_id_map[herodata.roleid]) then
					role_id_map[herodata.roleid] = true
				else
					team[i] = 0
				end
			end
		end
	end
	return team
end

function BattleSelectView:IsMultiEnemy()
	if self.activityid == ACTIVITYID.MAINLINE then
		return CampaignProxy.Instance:HasExtraEnemy(RoleInfoModel.mainlineid)
	end
	return false
end

function BattleSelectView:GetAllEnemy()
	if self.activityid == ACTIVITYID.MAINLINE then
		return CampaignProxy.Instance:GetAllEnemy(RoleInfoModel.mainlineid)
	end
	return self.args and {self.args[1]}
end

--注册新手引导数据
function BattleSelectView:RegisterNewbieData()
	local NewbieDef = require "Modules.Newbie.NewbieDef"
    local NewbieManager = require "Modules.Newbie.NewbieManager"
    local NewbieProxy = require "Modules.Newbie.NewbieProxy"

	if self.activityid then
		if self.activityid == ACTIVITYID.MAINLINE then
			for _newbie_id, _step in pairs(NewbieDef.MainlineBattleBtn) do
				self:RegisterButton(self.battleBtn, _newbie_id, _step)
			end

			local _newbie_id, _step = self:CheckNormalNpcMainDialog()
		    if _newbie_id and _step then
		        self:RegisterNpcDialog(_newbie_id, _step)
		    end 
		end
	end

	local newbieid, step = NewbieProxy.Instance:GetNewbieIdAndStep(NewbieDef.CampRelation)
	if newbieid and step then
		local mainlineid = RoleInfoModel.mainlineid
		local cfg = NewbieManager.Instance:GetNewbieStepConfig(newbieid, step)
		if cfg then
			if cfg.parama.mainlineid == mainlineid then
				self:RegisterButton(self.tipsBtn, newbieid, step)
			end
		end
	end
end

function BattleSelectView:CheckNormalNpcMainDialog()
    local NewbieDef = require "Modules.Newbie.NewbieDef"
    local NewbieManager = require "Modules.Newbie.NewbieManager"
    local newbieid, step
    local main_dialogs = NewbieDef.DialogTrigger.BattleNetSelectView
    local mainlineid = RoleInfoModel.mainlineid
    for _newbie_id, _step in pairs(main_dialogs) do
        local cfg = NewbieManager.Instance:GetNewbieStepConfig(_newbie_id, _step)
        if cfg and cfg[1] then
            if cfg[1].parama.mainlineid == mainlineid then
                newbieid, step = _newbie_id, _step
                break
            end
        end
    end
    return newbieid, step
end

function BattleSelectView:OnClose()	
	self:AutoUnRegister()
	self.artifact_bshow = false
	self.battleBtnEffect:Close()
	self.selectTweenPanel:Close()
	local SceneManager = require "Modules.Scene.SceneManager"
	if SceneManager.Instance:InMain() then
		BattleProxy.Instance:ContinusGame()
	end
	self.rightRelationItem:Close()
	self.backEffect:Close()	
	self.uiSpriteView:Close()
	self.battleSelectHeroItemPanel:Close()
	if self.activityid == ACTIVITYID.HIGHARENA then
		self.ProArenaBattlePanel:Close()
	elseif self.activityid == ACTIVITYID.STORYLINE then
		local hexmapcamera = require "Modules.HexMap.hexmapcamera"
		hexmapcamera.enable_input(true)
	end
	self.select_enemy_index = 1
	self.defaultTeams = {}
	self:UnRegisterNewbie()
end

function BattleSelectView:OnDestroy()
	self:AutoUnRegister()
	self.artifact_bshow = false
	if self.battleBtnEffect then
		self.battleBtnEffect:Destroy()
		self.battleBtnEffect = nil
	end
	self.selectTweenPanel:Destroy()

	self.rightRelationItem:Destroy()

	if self.backEffect then
		self.backEffect:Destroy()
		self.backEffect = nil
	end
	self.uiSpriteView:Close()
	self.battleSelectHeroItemPanel:Destroy()
	if self.activityid == ACTIVITYID.HIGHARENA then
		self.ProArenaBattlePanel:Destroy()
	end
	self:UnRegisterNewbie()
end

function BattleSelectView:InitHeroItem(item, obj, index)
	item.obj = obj
	item.localPosition = obj.transform.localPosition
	item.heroid = 0
	item.herocfgid = 0
	item.index = index

	item.lvLbl = self:GetChildComponent(obj, "lv", "CLabel")
	item.headTex = self:GetChildComponent(obj, "Viewport/CTexture_head", "CTexture")
	item.raceSp = self:GetChildComponent(obj, "CSprite_race", "CSprite")
	
	item.rankFrameSp = self:GetChildComponent(obj, "frame", "CSprite")
	item.rankFramePlusSp1 = self:GetChildComponent(item.rankFrameSp.gameObject, "CSprite_1", "CSprite")
	item.rankFramePlusSp2 = self:GetChildComponent(item.rankFrameSp.gameObject, "CSprite_2", "CSprite")
	item.rankBackSp = self:GetChildComponent(obj, "sprite", "CSprite")
	item.raceBackSp = self:GetChildComponent(obj, "CSprite_raceback", "CSprite")
 
	item.exclusiveSp = self:GetChildComponent(obj, "CSprite_Sig", "CSprite")

	item.starObj = self:GetChild(obj, "star")

	item.starItem = self:GetChild(item.starObj, "CHorizontalItem/item1")

    item.starPoolRender = ObjPoolRender.New()
    item.starPoolRender:Load(item.starItem, item.starItem.transform.parent, ObjPoolItem)	


end

function BattleSelectView:UpdateInfo()
	self.topTipsPanelObj:SetActive(false)
	self.runeObj:SetActive(false)
	local defaultTeam = self:InitMyTeam()
	self.args.lockHero = false
	if self:IsMultiEnemy() then
		if CampaignProxy.Instance:GetPassState(RoleInfoModel.mainlineid, self.args[1]) then
			self.args.lockHero = true
		end
	end
	self.battleSelectHeroItemPanel:Open(defaultTeam, self.heroinfos, self.activityid, self.args, self.artifact_bshow)

	if self.activityid == ACTIVITYID.STORYLINE then
		local hexmapcamera = require "Modules.HexMap.hexmapcamera"
		hexmapcamera.enable_input(false)
	end

	self:ShowEnemyTeam()
end

function BattleSelectView:ShowPanel()
	local panel = require ("Modules.Battle.Select."..self.panelstr)
	self.battlePanel = panel.New(self.go, self.args)
	self.battlePanel:Open()
end

function BattleSelectView:GetDefaultTeam(args)
	local team = BattleProxy.Instance:GetDefaultTeam(self.activityid, args)
	return self:FilterSameRoleIDHero(team)
end

function BattleSelectView:InitMyTeam()
	local defaultTeam = BattleProxy.Instance:GetDefaultTeam(self.activityid, self.args)	 --{enemyid, towerid}
	
	if self:IsMultiEnemy() then
		if self.defaultTeams and (#self.defaultTeams > 0) then
			defaultTeam = self.defaultTeams[self.select_enemy_index]
		end
	end
	
	--print("InitMyTeam=====", self.activityid, table.dump(defaultTeam))
	if self.activityid == ACTIVITYID.MAINLINE then
		defaultTeam = self:GetMainLineSpecialDefaultTeam(defaultTeam)
	elseif self.activityid == ACTIVITYID.MAZE or self.activityid == ACTIVITYID.STORYLINE or self.activityid == ACTIVITYID.ACTIVITY then
		local newherolist = {}
		for _, heroid in ipairs(defaultTeam) do
			local newheroid = heroid
			if heroid ~= 0 then
				for _, heroinfo in ipairs(self.heroinfos) do
					if heroid == heroinfo.fromuid then
						newheroid = heroinfo.herouid or 0 --用herouid初始化
						break
					end
				end
			end
			table.insert(newherolist, newheroid)
		end
		defaultTeam = newherolist
	end
	
	defaultTeam = self:FilterSameRoleIDHero(defaultTeam)
	return defaultTeam
end

function BattleSelectView:FilterSameRoleIDHero(defaultTeam)
	local role_id_map = {}
	for i, heroid in ipairs(defaultTeam) do
		if heroid ~= 0 then
			local herodata = self:_GetHeroDataByUid(heroid)
			if herodata and herodata.roleid then
				if not role_id_map[herodata.roleid] then
					role_id_map[herodata.roleid] = true
				else
					--有相同roleid
					defaultTeam[i] = 0
				end
			else
				defaultTeam[i] = 0
			end
		end
	end
	return defaultTeam
end

function BattleSelectView:_GetHeroDataByUid(herouid)
	for _, herodata in ipairs(self.heroinfos) do
		if herodata.herouid == herouid then
			return herodata
		end
	end
end

function BattleSelectView:GetMainLineSpecialDefaultTeam(defaultTeam)
	local team = defaultTeam
	local mainlinecfg = CampaignProxy.Instance:GetMainLineCfgById(RoleInfoModel.mainlineid)
	if mainlinecfg and mainlinecfg.defaultTeam then
		for i, roleid in ipairs(mainlinecfg.defaultTeam) do
			local herodata = HeroProxy.Instance:GetHighestPowerHeroByRoleid(roleid)
			if herodata then
				team[i] = herodata.herouid
			end
		end
	end
	return team
end

function BattleSelectView:ShowBoss(data)
	self.rightObj:SetActive(false)
	self.bossInfoObj:SetActive(true)	
	local herocfg = HeroProxy.Instance:GetRoleCfgByConfigId(data.roleid)
	self.bossraceSp.SpriteName = string.format("zhenying_%s", herocfg.race)

	-- print("BattleSelectView:ShowBoss", self.activityid)
	if self.activityid == ACTIVITYID.GUILD_BOSS then
		local GuildDef = require "Modules.Guild.GuildDef"
		local GuildProxy = require "Modules.Guild.GuildProxy"
		local nowBossType, diff, stage = GuildProxy.Instance:GetNowBossProgress()
		self.bossnameLbl.text = string.format("%s(%s)", self:GetWord(herocfg.name), self:GetWord(GuildDef.LanguageKey.GuildBossView9, diff))
	elseif self.activityid == ACTIVITYID.GUILD_CHAOS then
		local GuildProxy = require "Modules.Guild.GuildProxy"
		local chaosRoomLv = GuildProxy.Instance:GetChaosRoomLv(true)
		self.bossnameLbl.text = string.format("%s(%s)", self:GetWord(herocfg.name), string.format("<color=#5bd494>%s</color>", self:GetWord("Common_1001", chaosRoomLv)))
	else
		self.bossnameLbl.text = string.format("%s(%s)", self:GetWord(herocfg.name), self:GetWord("Common_1001", data.level))
	end
	
	local spritecfg = HeroProxy.Instance:GetSpriteConfigeById(herocfg.id)
	self.uiSpriteView:SetModel(spritecfg.prefab_ui_id[1])

	local rankinfo = HeroProxy.Instance:GetRankInfoCfgById(data.rank)
	AssetManager.LoadUITexture(AssetManager.UITexture.BossQuality, rankinfo.bossbottom, self.bossqualityTex)
end

function BattleSelectView:ShowEnemyTeam()	
	self.rightObj:SetActive(true)
	self.bossInfoObj:SetActive(false)

	local bboss = false
	local teamlist = self.enemyinfos
	for _ ,data in pairs(teamlist) do
		if data.boss and data.boss.attribute == 1 then
			self:ShowBoss(data)
			bboss = true
			break
		end	
	end
	
	for idx, item in ipairs(self.rightItemList) do
		local enemyinfo = nil
		for _, _info in pairs(self.enemyinfos) do
			if _info.stance == idx then
				enemyinfo = _info
				break
			end
		end
		if enemyinfo then
			item.heroid = enemyinfo.roleid
			item.herocfgid = enemyinfo.roleid
			item.equips = enemyinfo.equips
			item.tree_info = enemyinfo.tree_info
			local cfg = HeroProxy.Instance:GetRoleCfgByConfigId(enemyinfo.roleid)
			self:UpdateEnemyTeamInfo(item, cfg, enemyinfo, bboss)

			if bboss then
				self.uiSpriteView:AddClick(function ()
					self:OnClickShowBoss(item)
				end)
			end
		else
			self:UpdateEnemyTeamInfo(item, nil, nil, bboss)	
		end
	end		
end


function BattleSelectView:UpdateEnemyTeamInfo(item, cfg, data, bboss)
	if cfg then		
		item.obj:SetActive(true)
		item.level = data.level
		item.rank = data.rank
		item.position = data.boss and data.boss.coordinate or nil
		if not bboss then
			--item.lvLbl.text = self:GetWord("Common_1001", data.level)
			if data.prop then
				--服务器传了属性(pvp 敌方羁绊 等属性)，则直接计算战力
				local prop = {}
				for _, v in ipairs(data.prop) do
					if v then
						local attrname = CONST.ATTR[v[1]]
						prop[attrname] = v[2]
					end
				end
				item.prop = prop
			end
			
			item.level = data.level
			item.crystalLevel = data.crystalLevel
			item.lvLbl.text = HeroProxy.Instance:GetHeroLevelString(nil, data)

			item.raceSp.SpriteName = string.format("zhenying_%s", cfg.race)
			local rankinfo = HeroProxy.Instance:GetRankInfoCfgById(item.rank)
			local ColorTools = require "Common.Util.ColorTools"
			item.raceBackSp.color = ColorTools.RichText2Color(rankinfo.raceback1)

			item.rankBackSp.SpriteName = rankinfo.skillframe

			if rankinfo.skillangle then
				item.rankFrameSp.gameObject:SetActive(true)
				item.rankFrameSp.SpriteName = rankinfo.skillangle or ""
				item.rankFramePlusSp1.SpriteName = rankinfo.frameangle or ""
				item.rankFramePlusSp2.SpriteName = rankinfo.frameangle or ""
			else
				item.rankFrameSp.gameObject:SetActive(false)
			end

			local spritecfg = HeroProxy.Instance:GetSpriteConfigeById(cfg.id)
			AssetManager.LoadUITexture(AssetManager.UITexture.HeroPk, spritecfg.prefab_id[1], item.headTex)
		
			item.starObj:SetActive(true)
			item.starPoolRender:ReleaseAll()
			item.starObj:SetActive(rankinfo.star > 0 and true or false)
			for i=1,rankinfo.star do
				item.starPoolRender:Get({})
			end
		end	
	else		
		item.obj:SetActive(false)
		item.herocfgid = 0
	end	
	item.exclusiveSp.gameObject:SetActive(false)
	self:SetRelationInfo(self.rightRelationItem, self.rightItemList, self.rightFightLbl)
end

function BattleSelectView:SaveDefaultTeam()
	local herolist, rolelist = self.battleSelectHeroItemPanel:GetDefaultSelectHeroList()
	if self:IsMultiEnemy() then
		self.defaultTeams[self.select_enemy_index] = herolist
	end
	
	if self.activityid == ACTIVITYID.MAZE or self.activityid == ACTIVITYID.STORYLINE  or self.activityid == ACTIVITYID.ACTIVITY then
		local newherolist = {}
		for _, heroid in ipairs(herolist) do
			local newheroid = heroid
			if heroid ~= 0 then
				for _, heroinfo in ipairs(self.heroinfos) do
					if heroid == heroinfo.herouid then
						newheroid = heroinfo.fromuid or 0 -- 用fromuid存盘
						break
					end
				end
			end
			table.insert(newherolist, newheroid)
		end
		herolist = newherolist
	end
	BattleProxy.Instance:SetDefaultTeam(self.activityid, herolist, self.args)  --{enemyid, towerid}
end

function BattleSelectView:SetRelationInfo(relationItem, itemlist, fightLbl)	
	local list = {}
	local herodatas = {}
	local fight2 = 0
	for idx, item in pairs(itemlist) do
		if item.herocfgid ~= 0 then
			table.insert(list, item.herocfgid)
			table.insert(herodatas, {roleid = item.herocfgid, herouid = item.heroid, rank = item.rank, level = BattleProxy.Instance:GetHeroLv(item, self.activityId, true), 
				equips = item.equips, tree_info = item.tree_info})
			if item.prop then

				local ff = HeroProxy.Instance:GetAttrFight(item.prop)
				fight2 = fight2 + ff
			end
		end 
	end
	relationItem:SetData(list)
	
	if fight2 ~= 0 then --服务器传了属性(pvp 敌方羁绊 等属性)，则直接计算战力
		fightLbl.Text = GameLogicTools.GetNumStr(fight2)
	else
		local fightFactor = self:GetEnemyFightFactor()
		local str, fight = HeroProxy.Instance:GetHeroFight(herodatas)
		fightLbl.Text = GameLogicTools.GetNumStr(math.floor(fight * (1 + fightFactor / 1000)))
	end
end

function BattleSelectView:GetEnemyFightFactor()
	local fightFactor = 0
	--if (self.activityid == ACTIVITYID.MAINLINE) or (self.activityid == ACTIVITYID.TOWER) or (self.activityid == ACTIVITYID.MAZE) then
	if BattleDef.AddEnemyFightFactorType[self.activityid] then
		local enemyid = self.args[1]
		if self.activityid == ACTIVITYID.MAZE then
			enemyid = HexMapProxy.Instance:GetBattleEnemyID()
		end
		local enemyCfg = GameLogicTools.GetEnemyCfg(enemyid)
		fightFactor = (enemyCfg and enemyCfg.fight_factor) or 0
	end
	return fightFactor
end

function BattleSelectView:ShowGameInfo()
	if self.activityid == ACTIVITYID.MAINLINE then
		local mainlinecfg = CampaignProxy.Instance:GetMainLineCfgById(RoleInfoModel.mainlineid)
		self.titleLbl.text = string.format("%s-%s", mainlinecfg.chapter, mainlinecfg.section)--self:GetWord("MainLineCommon_1001", string.format("%s-%s", mainlinecfg.chapter, mainlinecfg.section))

	elseif self.activityid == ACTIVITYID.TOWER then
		local towerCfg = TowerProxy.Instance:GetTowerCfgById(self.args[2])  --{enemyid, towerid}
		self.titleLbl.text = self:GetWord("TowerCommon_1001", towerCfg.layer)
	end	
end

function BattleSelectView:OnClickShowBoss(item)
	local cfg = HeroProxy.Instance:GetRoleCfgByConfigId(item.herocfgid)
	local strContent = self:GetWord(cfg.tips, item.level)
	GameLogicTools.ShowLabelTips(strContent, item.obj.transform.position)
end


function BattleSelectView:OnClickBattle()		
	local list = self.battleSelectHeroItemPanel:GetBattleHeroList()

	if not next(list) then
		return GameLogicTools.ShowMsgTips("msgtips_battle_1005")
	end

	self:SaveDefaultTeam()
	self:SaveMultiTeam()
	if self.activityid == ACTIVITYID.HIGHARENA then
		self.ProArenaBattlePanel:StartGame(self.battlePanel,self.enemyinfos)
	else
		self.battlePanel:StartGame(list, self.enemyinfos)
	end
end

function BattleSelectView:SaveMultiTeam()
	if self:IsMultiEnemy() then
		local enemys = self:GetAllEnemy()
		for i,enemyid in ipairs(enemys) do
			if enemyid ~= self.args[1] then
				BattleProxy.Instance:SetDefaultTeam(self.activityid, self.defaultTeams[i], {enemyid, RoleInfoModel.mainlineid})  --{enemyid, mainlineid}
			end
		end
		return
	end
end

function BattleSelectView.EvtNotify.Newbie.data:Newbie_Notify(data, args)
	self.battleSelectHeroItemPanel:Newbie_Notify(args)
end

function BattleSelectView.EvtNotify.Formation.data:Fromations_Info(data, args)
	self.battleSelectHeroItemPanel:UpdateFormationInfo()
end

function BattleSelectView.EvtNotify.Formation.data:Formation_Add_Formation(data, args)
	self.battleSelectHeroItemPanel:UpdateFormationInfo(false)
end

function BattleSelectView.EvtNotify.Formation.data:FormationName_Change(data, args)
	local index, name = args.index, args.name
	self.battleSelectHeroItemPanel:UpdateItemName(index, name)
end

function BattleSelectView.EvtNotify.Formation.data:Formation_Info_Change(data, args)
	self.battleSelectHeroItemPanel:UpdateFormationInfo(false)
end

function BattleSelectView.EvtNotify.Formation.data:Formation_Top_Change(data, args)
	self.infos = args.formation_infos
	self.battleSelectHeroItemPanel:ShowTeamObj(false)
end

function BattleSelectView.EvtNotify.Formation.data:Formation_Delete_Change(data, args)
	self.infos = args.formation_infos
	self.battleSelectHeroItemPanel:ShowTeamObj(false)
end

function BattleSelectView.EvtNotify.Hero.data:LevelUpHero(data , args)
	self.battleSelectHeroItemPanel:UpdateHeroInfoByLevelUp(args)
end

function BattleSelectView.EvtNotify.Crystal.data:UpdateCrystal(data, args)
	self.battleSelectHeroItemPanel:UpdateHeroInfoByCrystalLevelUp(data)
end

--英雄穿卸装备
function BattleSelectView.EvtNotify.Hero.data:UpdateHeroEquip(data, args)
	self.battleSelectHeroItemPanel:UpdateHeroInfoByEquip(args)
end

--装备升级升阶重置等等
function BattleSelectView.EvtNotify.Equip.data:Update_EquipGoods(data, goodsId)
	self.battleSelectHeroItemPanel:UpdateHeroInfoByEquip({goodsId = goodsId})
end

function BattleSelectView:GetHeroCList()
	local clist1, clist2 = self.battleSelectHeroItemPanel:GetHeroCList()
	return clist1, clist2
end

--刷新迷宫符文显示数据
function BattleSelectView.EvtNotify.HexMap.data:Update_Rune_List(data, args)
	if self.battlePanel and self.battlePanel["UpdateRuneObjDate"] then
		self.battlePanel["UpdateRuneObjDate"](self.battlePanel, args, self.heroinfos)

		local fightPercent = self.battlePanel:GetRuneFightPercent()
		self.battleSelectHeroItemPanel:SetRuneFight(fightPercent)
	end
end

function BattleSelectView:GetArenaSelectInfos()
	local curIndex, infos
	if self.activityid == ACTIVITYID.HIGHARENA then
		curIndex = self.ProArenaBattlePanel.curIndex
		infos = self.ProArenaBattlePanel:GetMyFormations()
	end
	return curIndex, infos
end

function BattleSelectView:ReplaceProArenaFormations(roleIdDic)
	if self.activityid == ACTIVITYID.HIGHARENA then
		self.ProArenaBattlePanel:ReplaceFormations(roleIdDic)
	end
end

function BattleSelectView:GetOtherTeamHeroList()
	if self:IsMultiEnemy() then
		local select_heros = {}
		local select_herouid_map = {}
		local select_hero_roleid_map = {}
		local enemys = self:GetAllEnemy()
		for i,team in ipairs(self.defaultTeams) do
			if self.select_enemy_index ~= i then
				local pass = CampaignProxy.Instance:GetPassState(RoleInfoModel.mainlineid, enemys[i])
				for _, heroid in ipairs(team) do
					if heroid > 0 then
						local bhireHero = MercenaryProxy.Instance:CheckIsHireHero(heroid)
						local herodata = self:_GetHeroDataByUid(heroid)
						if herodata then
							local item = {pass = pass, teamid = i, heroid = heroid, fromuid = heroid, bhireHero = bhireHero, herocfgid = herodata.roleid, roleid = herodata.roleid}
							table.insert(select_heros, item)
							select_herouid_map[heroid] = item
							if (not select_hero_roleid_map[herodata.roleid]) or item.pass then
								select_hero_roleid_map[herodata.roleid] = item
							end
						end
					end
				end
			end
		end
		return select_heros, select_herouid_map, select_hero_roleid_map
	end
	return {}, {}, {}
end

function BattleSelectView:RemoveTeamHero(herodata)
	if herodata and herodata.teamid then
		if self.defaultTeams then
			local team = self.defaultTeams[herodata.teamid]
			if team then
				for i,herouid in ipairs(team) do
					if herouid == herodata.heroid then
						team[i] = 0
					else
						local hero = self:_GetHeroDataByUid(herouid)
						if hero and (hero.roleid == herodata.roleid) then
							team[i] = 0
						end
					end
				end
			end
		end
	end
end

function BattleSelectView:OpenExchangeTeamView()
	if self:IsMultiEnemy() then
		local herolist = self.battleSelectHeroItemPanel:GetDefaultSelectHeroList()
		self.defaultTeams[self.select_enemy_index] = herolist
		
		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleTeamChangeView)
		if view then
			view.activity_id = self.activityid
			view.level_id = self.args[2]
			
			local teams = {}
			local enemys = self:GetAllEnemy()
			for i,enemyid in ipairs(enemys) do
				local pass = CampaignProxy.Instance:GetPassState(self.args[2], enemyid)
				local heroinfos = {}
				for stance,herouid in ipairs(self.defaultTeams[i]) do
					if herouid > 0 then
						local herodata = self:_GetHeroDataByUid(herouid)
						if herodata then
							herodata.stance = stance
							table.insert(heroinfos, herodata)
						end
					end
				end
				
				local encoder = NetEncoder.New()
				local encoder = BattleProxy.Instance:_EncodeHeroInfo(heroinfos, encoder, true)

				local decoder = NetDecoder.New(encoder.buffer, 1)
				local decode_hero_list = BattleProxy.Instance:_DecodeHeroInfo(decoder)
				
				local new_hero_infos = {}
				for k, v in pairs(decode_hero_list) do
					new_hero_infos[v.stance] = {empty = false, hero = v}
				end
				for stance,v in ipairs(self.defaultTeams[i]) do
					if not new_hero_infos[stance] then
						new_hero_infos[stance] = {empty = true}
					end
				end
				
				local item = {lock = pass, enemyid = enemyid, heroInfos = new_hero_infos}
				table.insert(teams, item)
			end
			view.default_teams = teams
			
			view.callback = function(index_list)
				self:ExchangeTeam(index_list)
			end
			
			view:OpenView()
		end
	end
end

function BattleSelectView:ExchangeTeam(index_list)
	local list = {}
	for i,v in ipairs(index_list) do
		table.insert(list, self.defaultTeams[v])
	end
	self.defaultTeams = list
	
	self:UpdateInfo()
end

return BattleSelectView