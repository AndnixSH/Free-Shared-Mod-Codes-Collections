local UISpriteBase = require "Core.Implement.UI.Class.UISpriteBase"
local _modelcfg = ConfigManager.GetConfig("data_mod_offset")

local UISpriteView = BaseClass(UISpriteBase)
function UISpriteView:OnOpen()
    if _modelcfg[self.resName] then
        local modelcfg = _modelcfg[self.resName]
        self.model:model_localrotate(0, modelcfg.rotate, 0)
        if modelcfg.offset then
            self.model:model_localposition(modelcfg.offset[1], modelcfg.offset[2], modelcfg.offset[3])
        end
        self.model:model_scale(modelcfg.size * self.viewScale)
    else
        self.model:model_scale(self.viewScale)
    end
end

--function UISpriteView:SetExModel(resName)
--    resName = string.format("%s_ex", resName)
--    self:SetModel(resName)
--end

return UISpriteView