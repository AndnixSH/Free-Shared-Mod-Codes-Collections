local SceneDef = require "Modules.Scene.SceneDef"
local SceneMediator = require "Modules.Scene.SceneMediator"

local SceneManager = SceneManager or BaseClass()
function SceneManager:__init()
    SceneManager.Instance = self
    --self:SceneEventInit()
    self.First = true
    self.lastSceneType = 0        --上一个加载的类型
    self.sceneType = 0            --加载结束后的类型
    self.enterSceneType = 0        --加载开始的类型
    self.curloadType = nil
    self.data = {}

    self.loadedScene = {
        [AssetManager.LoadSceneType.Always] = { sceneName = "", sceneObject = nil },
        [AssetManager.LoadSceneType.Temp] = { sceneName = "", sceneObject = nil },
        [AssetManager.LoadSceneType.Never] = { sceneName = "", sceneObject = nil },
    }
end

function SceneManager:__delete(self)
    SceneManager.Instance = nil
end

function SceneManager:EnterScene(sceneType, ...)
    --场景没有加载完,不能切场景
    if self.sceneType ~= self.enterSceneType then
        return
    end

    local args = {...}
    
    local ScreenShotter = require "Common.Util.ScreenShotter"
    ScreenShotter.Capture(function()
        self.enterSceneType = sceneType
        SceneConstruct.InitScene(sceneType, table.unpack(args))
    end)


end

function SceneManager:EnterSceneFast(sceneType, ...)
    --场景没有加载完,不能切场景
    if self.sceneType ~= self.enterSceneType then
        return
    end

    self.enterSceneType = sceneType
    SceneConstruct.InitScene(sceneType, ...)

end

function SceneManager:CleanCurScene()
    SceneConstruct.CleanSceneByType(self.sceneType)
end

function SceneManager:RecoverScene()
    self.enterSceneType = self.sceneType
end

--场景事件派发
function SceneManager:SendFacedeNotify(notifyDef)
    local SceneProxy = require "Modules.Scene.SceneProxy"
    SceneProxy.Instance:SendFacedeNotify(notifyDef)
end

function SceneManager:SceneEventInit()
    self:SendFacedeNotify(SceneDef.NotifyDef.Scene_Enter_Init)
end

function SceneManager:SceneEventFirst()
    self:SendFacedeNotify(SceneDef.NotifyDef.Scene_Enter_First)
end

function SceneManager:SceneEventStart()
    SceneConstruct.StartLoadScene()

    if self.First and (self.enterSceneType == SceneDef.SceneType.Main or self.enterSceneType == SceneDef.SceneType.Battle) then
        self:SceneEventFirst()
    end
    self:SendFacedeNotify(SceneDef.NotifyDef.Scene_Enter_Start)
end

function SceneManager:SceneEventEnd()
    self.lastSceneType = self.sceneType
    self.sceneType = self.enterSceneType
    self:SendFacedeNotify(SceneDef.NotifyDef.Scene_Enter_End)
    if self.First and self.enterSceneType == SceneDef.SceneType.Main then
        self.First = false
    end
end

function SceneManager:SceneLoadingEnd()
    self:SendFacedeNotify(SceneDef.NotifyDef.Scene_Loading_End)
end

function SceneManager:SceneEventFree()
    self:SendFacedeNotify(SceneDef.NotifyDef.Scene_Enter_Clear)
end

--是否联网战斗
function SceneManager:IsNetBattle()
    return self.enterSceneType == SceneDef.SceneType.Battle
end

--是否本地战斗
function SceneManager:IsLocalBattle()
    return (self.enterSceneType == SceneDef.SceneType.Newbie or
            self.enterSceneType == SceneDef.SceneType.Train)
end

--在战斗中
function SceneManager:InBattle()
    return (self.enterSceneType == SceneDef.SceneType.MainLineBattle or
					self.enterSceneType == SceneDef.SceneType.TowerBattle or
                    self.enterSceneType == SceneDef.SceneType.MazeBattle or
                    self.enterSceneType == SceneDef.SceneType.StoryLineBattle or
                    self.enterSceneType == SceneDef.SceneType.ArenaBattle or
                    self.enterSceneType == SceneDef.SceneType.HighArenaBattle
    )
end

--在主界面
function SceneManager:InMain()
    return self.sceneType == SceneDef.SceneType.Main and self.enterSceneType == SceneDef.SceneType.Main
end

function SceneManager:GetLastSceneType()
    return self.lastSceneType
end

function SceneManager:GetCurSceneType()
    return self.sceneType
end

function SceneManager:LoadScene(resName, sceneLoadType, callBack)
    sceneLoadType = sceneLoadType or AssetManager.LoadSceneType.Never
    --print("------->>resName, sceneLoadType", resName, sceneLoadType)
    self.curloadType = sceneLoadType
    if sceneLoadType == AssetManager.LoadSceneType.Always then
        local loadedSceneName = self.loadedScene[sceneLoadType].sceneName
        if loadedSceneName ~= resName then
            if not string.isEmpty(loadedSceneName) then
                local scene = self.loadedScene[sceneLoadType].scene
                self.loadedScene[sceneLoadType].sceneObject = nil
                self.loadedScene[sceneLoadType].scene = nil
                AssetManager.UnloadScene(scene)
            end

            AssetManager.LoadScene(resName, function(scene)
                AssetManager.activeSceneName = resName
                self.loadedScene[sceneLoadType].sceneName = resName
                self.loadedScene[sceneLoadType].sceneObject = AssetManager.GetActiveSceneRootObject()
                self.loadedScene[sceneLoadType].scene = scene
                if callBack then
                    callBack()
                end
            end)
        else
            local sceneObject = self.loadedScene[sceneLoadType].sceneObject
            if sceneObject then
                sceneObject:SetActive(true)
            end
            AssetManager.SetActiveScene(resName)
            if callBack then
                callBack()
            end
        end
    elseif sceneLoadType == AssetManager.LoadSceneType.Temp then
        local loadedSceneName = self.loadedScene[sceneLoadType].sceneName
        if loadedSceneName ~= resName then
            if not string.isEmpty(loadedSceneName) then
                local scene = self.loadedScene[sceneLoadType].scene
                self.loadedScene[sceneLoadType].sceneObject = nil
                self.loadedScene[sceneLoadType].scene = nil
                AssetManager.UnloadScene(scene)
            end

            --if self.loadedScene[AssetManager.LoadSceneType.Always] and resName == self.loadedScene[AssetManager.LoadSceneType.Always].sceneName then
            --	local sceneObject = self.loadedScene[AssetManager.LoadSceneType.Always].sceneObject
            --	self.loadedScene[sceneLoadType].sceneName = resName
            --	self.loadedScene[sceneLoadType].sceneObject = sceneObject
            --	if sceneObject then
            --		sceneObject:SetActive(true)
            --	end
            --	AssetManager.SetActiveScene(resName)
            --	if callBack then
            --		callBack()
            --	end
            --else
            AssetManager.LoadScene(resName, function(scene)
                AssetManager.activeSceneName = resName
                self.loadedScene[sceneLoadType].sceneName = resName
                self.loadedScene[sceneLoadType].sceneObject = AssetManager.GetActiveSceneRootObject()
                self.loadedScene[sceneLoadType].scene = scene
                if callBack then
                    callBack()
                end
            end)

            local always_scene = self.loadedScene[AssetManager.LoadSceneType.Always]
            if always_scene and always_scene.sceneObject then
                always_scene.sceneObject:SetActive(false)
            end
            --end
        else
            local sceneObject = self.loadedScene[sceneLoadType].sceneObject
            if sceneObject then
                sceneObject:SetActive(true)
            end
            AssetManager.SetActiveScene(resName)
            if callBack then
                callBack()
            end

            local always_scene = self.loadedScene[AssetManager.LoadSceneType.Always]
            if always_scene and always_scene.sceneObject then
                always_scene.sceneObject:SetActive(false)
            end
        end
    elseif sceneLoadType == AssetManager.LoadSceneType.Never then
        AssetManager.LoadScene(resName, function(scene)
            AssetManager.activeSceneName = resName
            self.loadedScene[sceneLoadType].sceneName = resName
            self.loadedScene[sceneLoadType].scene = scene
            if callBack then
                callBack()
            end
        end)
        local always_scene = self.loadedScene[AssetManager.LoadSceneType.Always]
        if always_scene and always_scene.sceneObject then
            always_scene.sceneObject:SetActive(false)
        end
    end
end

function SceneManager:SetCurSceneActive(bactive)
    if not self.curloadType then return end
    local load_scene = self.loadedScene[self.curloadType]
    if load_scene and load_scene.sceneObject then
        -- print('SetCurSceneActive', bactive, self.curloadType, load_scene.sceneObject, debug.traceback())
        load_scene.sceneObject:SetActive(bactive)
    end
end

function SceneManager:UnloadScene(resName, sceneLoadType)
    sceneLoadType = sceneLoadType or AssetManager.LoadSceneType.Never

    if sceneLoadType == AssetManager.LoadSceneType.Always or sceneLoadType == AssetManager.LoadSceneType.Temp then
        local sceneObject = self.loadedScene[sceneLoadType].sceneObject
        if sceneObject then
            sceneObject:SetActive(false)
        end
    elseif sceneLoadType == AssetManager.LoadSceneType.Never then
        local scene = self.loadedScene[sceneLoadType].scene
        if scene then
            AssetManager.UnloadScene(scene)
        end
    end
end

-- 强制卸载场景
function SceneManager:UnloadSceneForce(sceneLoadType)
    local scene = self.loadedScene[sceneLoadType].scene
    if scene then
        AssetManager.UnloadScene(scene)
        self.loadedScene[sceneLoadType] = { sceneName = "", sceneObject = nil }
    end
end

function SceneManager:UnLoadAllScene()
    for sceneLoadType, scene_info in pairs(self.loadedScene) do
        local scene = scene_info.scene
        if scene then
            AssetManager.UnloadScene(scene)
        end
        self.loadedScene[sceneLoadType] = { sceneName = "", sceneObject = nil }
    end
end


return SceneManager