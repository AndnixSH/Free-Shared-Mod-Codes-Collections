local hangup_drop_anchor = hangup_drop_anchor or BaseClass()

local cHangupDropAnchor = CS.LJY.NX.HangupDropAnchor

function hangup_drop_anchor:__init(x, y, z, endx, endy, endz, delay, acceleration, speed, index, callback)
    self.canchor = cHangupDropAnchor(x, y, z, endx, endy, endz, delay, acceleration, speed, index, callback)
end

function hangup_drop_anchor:__delete()
    self.canchor = nil
end

return hangup_drop_anchor