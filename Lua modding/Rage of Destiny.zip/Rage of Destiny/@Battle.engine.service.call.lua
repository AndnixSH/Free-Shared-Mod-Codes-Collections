local call = { _call_list = {} }
local DEFAULT_TAG = "__default__"
_G.caller = {}

function call:add(tag, source, methodname, context)
    source.caller[tag] = source.caller[tag] or { context = context }
    source.caller[tag][methodname] = function (self, ...)
        return self.context.call[methodname](self.context, ...)
    end
    if not caller[tag] then caller[tag] = {} end
    if not caller[tag][methodname] then
        caller[tag][methodname] = function (_source, ...)
            if _source._dirty then
                global.debug.warning("obj已经脏了你还在call", _source, tag, methodname, debug.traceback())
            end
            local _tag = _source.caller[tag]
            if _tag and _tag[methodname] then
                -- gamelog.debug(string.format("%s call %s.%s", _source, tag, methodname), ...)
                return _tag[methodname](_tag, ...)
            else
                global.debug.warning(string.format("can not find call.%s.%s at %s", tag, methodname, _source))
            end
        end
        metafunc.classify("caller", caller[tag][methodname])
    end
end

function call:remove_source(tag, source)
    source.caller[tag] = nil
end

function call:load(tb, context, source)
    for methodname, handler in pairs(tb) do
        if type(handler) == "function" then
            self:add(tb.tag or DEFAULT_TAG, source, methodname, context)
        end
    end
    return tb
end

function call:unload(tb, context, source)
    -- self:remove_source(tb.tag or DEFAULT_TAG, source)
end

function call:after_unload(tb, context, source)
    self:remove_source(tb.tag or DEFAULT_TAG, source)
end

function call:dump()
end

function call:dispose()
end

return call