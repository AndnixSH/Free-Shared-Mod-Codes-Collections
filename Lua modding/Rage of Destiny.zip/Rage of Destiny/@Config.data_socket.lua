ConfigManager.InitConfig(
        "data_socket",
        {
            [1] = { name = "debug_3", ip = "192.168.0.111", port = 18002, part_id = 3},
            [2] = { name = "debug", ip = "192.168.0.111", port = 18000, part_id = 1},
            [3] = { name = "debug_2", ip = "192.168.0.111", port = 18001, part_id = 2},
            [4] = { name = "luqi", ip = "192.168.0.113", port = 18000 },
            [5] = { name = "xiaochang", ip = "192.168.0.110", port = 18000 },
            [6] = { name = "liqiang", ip = "192.168.0.119", port = 18000 },
            [7] = { name = "lilin", ip = "192.168.0.173", port = 18000},
            [8] = { name = "liucailin", ip = "192.168.0.174", port = 18000},
            [9] = { name = "liangyehong", ip = "192.168.0.115", port = 18000},
            [10] = { name = "release", ip = "192.168.0.118", port = 18000},
            [11] = { name = "外网", ip = "120.79.21.251", port = 18000},
            [12] = { name = "mengfei", ip = "192.168.0.126", port = 18000},
			[13] = { name = "huangzhaopeng", ip = "192.168.0.142", port = 18000},
            [14] = { name = "debug_4", ip = "192.168.0.111", port = 18003, part_id = 4},
        }
)
