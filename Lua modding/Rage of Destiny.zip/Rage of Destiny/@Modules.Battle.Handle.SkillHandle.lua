local BattleProxy = require "Modules.Battle.BattleProxy"
local HeroProxy = require "Modules.Hero.HeroProxy"

local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"
local BattleBaseClass = require "Core.Implement.UI.Class.BattleBaseClass"
local ObjPoolRender = require "Core.Implement.UI.Class.ObjPoolRender"
local ObjPoolItem = require "Core.Implement.UI.Class.ObjPoolItem"
local GameUIUtil = CS.GameUIUtil

local AudioManager = require "Common.Mgr.Audio.AudioManager"
local NewbieWidget = require "Core.Implement.UI.Widgets.NewbieWidget"

local BattleDef = require "Modules.Battle.BattleDef"
local MercenaryProxy = require "Modules.Mercenary.MercenaryProxy"

--无限时长buff
local Buff_Max_Live_Time = 1000000
--最大显示buff图标个数
local Buff_Max_Show_Count = 4
--buff 图标
local Buff_Groups = {
	[1] = 1,
	[2] = 1,
	[3] = 1,
	[4] = 1,
	[5] = 1,
	[6] = 1,
	[7] = 1,
	[8] = 1,
}

local SkillItem = SkillItem or LuaEventClass(ObjPoolItem, BattleBaseClass, NewbieWidget)
function SkillItem:Load(obj)
	--tween
	self.tweenObj = self:GetChild(obj, "CButton_skill")
	self.backObj = self:GetChild(obj, "CButton_skill/backObj")
	self.extweenObj = self:GetChild(obj, "CButton_skill/ex_skill")
	self.backTweenObj = self:GetChild(self.extweenObj, "back")
	self.lightTweenObj = self:GetChild(self.extweenObj, "CSprite_light")
	self.texTweenObj = self:GetChild(self.extweenObj, "Viewport/CTexture_head")
	self.texTweenTex = self:GetChildComponent(self.extweenObj, "Viewport/CTexture_head", "CTexture")
	self.backPosy = self.backTweenObj.transform.localPosition.y
	self.texPosy = self.texTweenObj.transform.localPosition.y
	self.lightPosy = self.lightTweenObj.transform.localPosition.y

	self.skillBtn = self:GetComponent(obj, "CButton")
	self.skillBtn:AddClick(function()
		if BattleProxy.Instance:IsStop() then
			BattleProxy.Instance:ContinusGame()
		end
		if not BattleProxy.Instance:IsReportBattle() then
			self:User_Skill()
			self:OnTriggerClickBtn(self.skillBtn)
		end
	end)
	-- self.skillBtn = self:GetChildComponent(obj, "CButton_skill", "CButton")
	-- self.skillBtn:AddClick(function ()
	-- 	if BattleProxy.Instance:IsStop() then
	-- 		BattleProxy.Instance:ContinusGame()
	-- 	end
	-- 	self:User_Skill()
	-- end)

	self.alpha = 0.7

	self.hpSp = self:GetChildComponent(self.backObj, "attribute/NewCSlider_Hp/icon", "CSprite")
	self.mpSp = self:GetChildComponent(self.backObj, "attribute/NewCSlider_Mp/icon", "CSprite")

	self.hpbackSp = self:GetChildComponent(self.backObj, "attribute/NewCSlider_Hp/back", "CSprite")
	self.headTex = self:GetChildComponent(self.backObj, "Viewport/CTexture_head", "CTexture")

	self.buffItems = {}
	self.buffItemObj = self:GetChild(obj, "CButton_skill/buffItemObj")
	local horizontalItem = self:GetChild(self.buffItemObj, "CHorizontalItem")
	for i=1,4 do
		local item = {}
		item.obj = self:GetChild(horizontalItem, string.format("item%d", i))
		item.sprite = self:GetChildComponent(item.obj, "sprite", "CSprite")
		table.insert(self.buffItems, item)
	end

	self.hireFriendHeroFlag = self:GetChild(self.backObj, "hireHeroFlag")
	self.hireFriendHeroFlag:SetActive(false)
	
	self.hireSystemHeroFlag = self:GetChild(self.backObj, "hiresystemHeroFlag")
	self.hireSystemHeroFlag:SetActive(false)

	self.rankBackSp = self:GetChildComponent(self.backObj, "sprite", "CSprite")
	self.frameSp = self:GetChildComponent(self.backObj, "frame", "CSprite")
	self.raceBackSp = self:GetChildComponent(self.backObj, "CSprite_raceback", "CSprite")

	self.raceSp = self:GetChildComponent(self.backObj, "CSprite_race", "CSprite")

	self.starObj = self:GetChild(self.backObj, "star")
	local starItem = self:GetChild(self.starObj, "CHorizontalItem/item1")
    self.starPoolRender = ObjPoolRender.New()
    self.starPoolRender:Load(starItem, starItem.transform.parent, ObjPoolItem)	

	self:InitEffect()
end

function SkillItem:SetData(spriteid)
	self.buff_show_count = 0
	self.buff_id_dics = {}
	self:ResetBuffIcon()

	GameObjTools.SetGray(self.go, false, true)

	GameUIUtil.SetGroupAlpha(self.backObj, self.alpha)
	GameUIUtil.SetGroupAlpha(self.extweenObj, self.alpha)
	
	local depth = self:GetNextDepth()
	self:SetDepth(self.tweenObj, depth)
	local depth = self:GetNextDepth()

	self.skillEffect_2:SetOrderLayer(depth)
	self.skillEffect_4:SetOrderLayer(depth)
	self.skillEffect_3:SetOrderLayer(depth)
	self.skillEffect_1:SetOrderLayer(depth)

	self.go:SetActive(true)
	self.spriteid = spriteid
	self.spritedata = BattleProxy.Instance:GetSprite(spriteid)
	-- print("self.spritedata===", table.dump(self.spritedata.prop), self.spritedata.prop.hire_hero_type, table.dump(self.spritedata))
	self:InitAttr()
	self:UpdateInfo()
	
	self:RegisterSpriteEvent(self.spriteid)
	self:PullSpriteEvent(self.spriteid)
end	

function SkillItem:InitEffect()
	self.skillEffect_2 = UIEffectItem.New("UI_Battle_skill2", self.tweenObj)   --上  大招特效 上
	self.skillEffect_4 = UIEffectItem.New("UI_Battle_skill2_2_m", self.tweenObj)  --上 蓄力状态特效 上
	-- self.skillEffect_2:SetLocalPosition(0, -12, 0)
	-- self.skillEffect_4:SetLocalPosition(0, -12, 0)

	self.skillEffect_1 = UIEffectItem.New("UI_Battle_skill1", self.tweenObj)
	self.skillEffect_3 = UIEffectItem.New("UI_BattleView_skill3", self.tweenObj)	

	self.skillEffect_5 = UIEffectItem.New("UI_Battle_skill2d", self.go) --低下  大招特效底下
	self.skillEffect_6 = UIEffectItem.New("UI_Battle_skill2_2d_m", self.go) --低下  蓄力狀態底下
	self.skillEffect_5:SetLocalPosition(0, 12, 0)

end

function SkillItem:ClearEffect(bdestroy)
	if bdestroy then
		self.skillEffect_1:Destroy()
		self.skillEffect_2:Destroy()
		self.skillEffect_3:Destroy()
		self.skillEffect_5:Destroy()

		self.skillEffect_1 = nil
		self.skillEffect_2 = nil
		self.skillEffect_3 = nil	
		self.skillEffect_5 = nil
	
	else
		self.skillEffect_1:Close()
		self.skillEffect_2:Close()
		self.skillEffect_3:Close()
		self.skillEffect_5:Close()

	end	
	self:ClearChangeEffect(bdestroy)
end

function SkillItem:Close()
	self:UnRegisterSpriteEvent()
	self:ClearSKillTween()
	self:ClearEffect(true)
	if self.delayGuildSeq then
		self.delayGuildSeq:Kill()
		self.delayGuildSeq = nil
	end
	self.buff_id_dics = {}
	self.buff_show_count = 0
end

function SkillItem:UpdateInfo()
	-- self.heroName.text = self:GetWord(self.spritedata.static.name)
	local hireHero = self.spritedata.prop.hire_hero_type == BattleDef.Hire_Hero_Type.Hire_Hero and true or false
	local hireFriendHero = MercenaryProxy.Instance:CheckIsHireHero(self.spritedata.prop.fromuid or 0)
	self.hireFriendHeroFlag:SetActive(hireHero and hireFriendHero)
	self.hireSystemHeroFlag:SetActive(hireHero and (not hireFriendHero))
	
	local spritecfg = HeroProxy.Instance:GetSpriteConfigeById(self.spritedata.static.id)
	AssetManager.LoadUITexture(AssetManager.UITexture.HeroPk, spritecfg.prefab_id[1], self.headTex)
	AssetManager.LoadUITexture(AssetManager.UITexture.HeroPk, spritecfg.prefab_id[1], self.texTweenTex)

	local herocfg = HeroProxy.Instance:GetRoleCfgByConfigId(self.spritedata.static.id)
	if herocfg then
		self.raceSp.SpriteName = "zhenying_" .. herocfg.race
	end

	local rankinfo = HeroProxy.Instance:GetRankInfoCfgById(self.spritedata.prop.rank)
	local ColorTools = require "Common.Util.ColorTools"

	if rankinfo then
		self.raceBackSp.color = ColorTools.RichText2Color(rankinfo.raceback1)
		self.rankBackSp.SpriteName = rankinfo.skillframe
	end

	if rankinfo and rankinfo.skillangle then
		self.frameSp.gameObject:SetActive(true)
		self.frameSp.SpriteName = rankinfo.skillangle or ""
	else
		self.frameSp.gameObject:SetActive(false)
	end

	self.starObj:SetActive(true)
	self.starPoolRender:ReleaseAll()
	if rankinfo then
		self.starObj:SetActive(rankinfo.star > 0 and true or false)
		for i=1,rankinfo.star do
			self.starPoolRender:Get({})
		end
	end

end

function SkillItem:User_Skill()
	if self.enable then  
		BattleProxy.Instance:UserSkill(self.spriteid)
	end		
end

function SkillItem:ClearSKillTween()
	if self.userSkillTween then
		self.userSkillTween:Kill()
		self.userSkillTween = nil
	end	

	if self.activeSkillTween then
		self.activeSkillTween:Kill()
		self.activeSkillTween = nil
	end

	self.extweenObj:SetActive(false)
	self.backObj:SetActive(true)
	self.buffItemObj:SetActive(true)
	self.backTweenObj.transform.localPosition = Vector2.New(self.backTweenObj.transform.localPosition.x, self.backPosy)
	self.texTweenObj.transform.localPosition = Vector2.New(self.texTweenObj.transform.localPosition.x, self.texPosy)
	self.lightTweenObj.transform.localPosition = Vector2.New(self.lightTweenObj.transform.localPosition.x, self.lightPosy)

	self.tweenObj.transform.localPosition = Vector2.zero
	self.tweenObj.transform.localScale = Vector3.New(1, 1, 1)
end

function SkillItem:UserSKillTweenStart()
	self:ClearSKillTween()
	self:ClearEffect()

	--初始化动画参数
	local moveY = 10
	self.lightTweenObj.transform.localPosition = Vector2.New(self.lightTweenObj.transform.localPosition.x, self.lightPosy + moveY)
	self.backTweenObj.transform.localPosition = Vector2.New(self.backTweenObj.transform.localPosition.x, self.backPosy + moveY)
	self.texTweenObj.transform.localPosition = Vector2.New(self.texTweenObj.transform.localPosition.x, self.texPosy - moveY)
	self.backObj:SetActive(false)
	self.buffItemObj:SetActive(false)
	self.extweenObj:SetActive(true)

	--开始动画	
	local tween0 = self.lightTweenObj.transform:DOLocalMoveY(self.lightPosy, 0.3)
	local tween1 = self.backTweenObj.transform:DOLocalMoveY(self.backPosy, 0.3)
	local tween2 = self.texTweenObj.transform:DOLocalMoveY(self.texPosy, 0.8)
	tween2:SetEase(Ease.OutCirc)
	local tween3 = self.tweenObj.transform:DOScaleX(0, 0.2)
	local tween4 = self.tweenObj.transform:DOScaleX(1, 0.2)

	local sequence = DOTween.Sequence()
	sequence:Append(tween2)
	sequence:Append(tween3)
	sequence:AppendCallback(function ()
		self.extweenObj:SetActive(false)
		self.backObj:SetActive(true)
		self.buffItemObj:SetActive(false)
	end)
	sequence:Append(tween4)
	sequence:AppendCallback(function ()
		self:ClearSKillTween()
		-- GameUIUtil.SetGroupAlpha(self.go, self.alpha)
		GameUIUtil.SetGroupAlpha(self.backObj, self.alpha)
		GameUIUtil.SetGroupAlpha(self.extweenObj, self.alpha)
		self:ChangeSkillTween()
	end)

	self.userSkillTween = sequence

	self.skillEffect_3:Play()

	AudioManager.PlaySoundByKey("battleskillopen_view")
end

function SkillItem:ActiveSkillTween()
	self:ClearSKillTween()	
	local moveY = 10
	self.activeSkillTween = self.tweenObj.transform:DOLocalMoveY(moveY, 0.2)
	-- GameUIUtil.SetGroupAlpha(self.go, 1)
	GameUIUtil.SetGroupAlpha(self.backObj, 1)
	GameUIUtil.SetGroupAlpha(self.extweenObj, 1)

	self.skillEffect_1:Play()
	self.skillEffect_2:Open()
	self.skillEffect_5:Open()

	AudioManager.PlaySoundByKey("battleskilltips_view")
end

function SkillItem:ClearChangeEffect(bdestroy)
	if bdestroy then
		self.skillEffect_4:Destroy()
		self.skillEffect_6:Destroy()
		self.skillEffect_4 = nil
		self.skillEffect_6 = nil
	else
		self.skillEffect_4:Close()
		self.skillEffect_6:Close()
	end
end

function SkillItem:ChangeSkillTween()
	if self.status == SKILL.SLOT_STATUS.CHARGE then
		self.enable = true
		self.skillEffect_4:Open()
		self.skillEffect_6:Open()
	end	
end

function SkillItem:ActiveSkillInfo(enable)
	self:ClearChangeEffect()

	self.enable = enable
	if self.enable then
		self:ActiveSkillTween()
	elseif self.userSkillTween == nil then
		self:ClearSKillTween()
		self:ClearEffect()
		self:ChangeSkillTween()
	end	
end

--attr
function SkillItem:InitAttr()	
	self:ChangeHp()
	self:ChangeMp()
end

function SkillItem:ChangeHp()
	local hp_max = self.spritedata.attr.hp_max
	local cur_hp = self.spritedata.attr.hp

	local value = cur_hp / hp_max
	self.hpSp.fillAmount = value
	self.hpbackSp:DOFillAmount(value, 0.5)	
end

function SkillItem:ChangeMp()
	local mp_max = self.spritedata.attr.mp_max
	local cur_mp = self.spritedata.attr.mp
	local value = cur_mp / mp_max
	self.mpSp.fillAmount = value
end

function SkillItem.event.attr:hp(newvalue, oldvalue)
	self:ChangeHp()
end

function SkillItem.event.attr:hp_max(newvalue, oldvalue)
	self:ChangeHp()
end

function SkillItem.event.attr:mp(newvalue, oldvalue)
	self:ChangeMp()
end

function SkillItem.event.attr:mp_max(newvalue, oldvalue)
	self:ChangeMp()
end

--注册新手引导数据
function SkillItem:RegisterNewbieData()
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	self:RegisterButton(self.skillBtn, NewbieDef.NewbieConst.ReleaseSkill, 1)
end

--接释放大招引导
function SkillItem:ReceiveNewbie(slotid, statue)
	if slotid == SKILL.SLOT.ULTIMATE and statue == SKILL.SLOT_STATUS.ENABLE then
		local NewbieManager = require "Modules.Newbie.NewbieManager"
		local NewbieDef = require "Modules.Newbie.NewbieDef"
		local NewbieProxy = require "Modules.Newbie.NewbieProxy"
		local bSkillGuild = false
		local newbie_id, newbie_step = NewbieManager.Instance:GetCurNewbieIdStep() --释放大招引导
		local _newbie_id, _newbie_step = NewbieProxy.Instance:GetNewbieIdAndStep(NewbieDef.AutoSkillTrigger)
		if newbie_id == NewbieDef.NewbieConst.ReleaseSkill and newbie_step == 1 then
			--释放大招
			bSkillGuild = true
		elseif _newbie_id == newbie_id and _newbie_step == newbie_step then
			--怒气满才出发自动释放大招引导
			BattleProxy.Instance:StopGame(false)
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleView)
			if view and view:IsOpen() then
				view:RegisterAutoSkillBtn()
			end
		end
		
		if bSkillGuild then
			BattleProxy.Instance:StopGame(false)
			if self.delayGuildSeq then
				self.delayGuildSeq:Kill()
				self.delayGuildSeq = nil
			end
			self.delayGuildSeq = DOTween.Sequence()
			self.delayGuildSeq:AppendInterval(0.5)
			self.delayGuildSeq:AppendCallback(function()
				self:RegisterNewbieData()
			end)
		end
	end
end

function SkillItem:IsAlive()
	return self.spritedata and self.spritedata.attr and self.spritedata.attr.hp and (self.spritedata.attr.hp > 0)
end

--需要添加蓄力状态表现
function SkillItem.event.sprite:slot_status_change(slotid, status)	
	if SKILL.SLOT.ULTIMATE == slotid then
		self:ReceiveNewbie(slotid, status)	
		self.status = status
		local active = (status == SKILL.SLOT_STATUS.ENABLE) and self:IsAlive()
		self:ActiveSkillInfo(active)
	end	
end

function SkillItem.event.sprite:slot_use(slotid)
	if SKILL.SLOT.ULTIMATE == slotid then
		self:UserSKillTweenStart()
		BattleProxy.Instance:UserSkillSuccess(self.spriteid)
	end	
end

function SkillItem.event.sprite:sprite_dead()
    self:ClearSKillTween()
    GameObjTools.SetGray(self.go, true, true)
    -- GameUIUtil.SetGroupAlpha(self.go, self.alpha)
    GameUIUtil.SetGroupAlpha(self.backObj, self.alpha)
	GameUIUtil.SetGroupAlpha(self.extweenObj, self.alpha)
    self:ClearEffect()
    self:ResetBuffIcon()
end

function SkillItem.event.sprite:buff_start(buff_id)
	local bupdate = self:InsertBuffDic(buff_id)
	self:UpdateBuffItem(bupdate)
end

function SkillItem.event.sprite:buff_stop(buff_id)
	local bupdate = self:RemoveBuffDic(buff_id)
	self:UpdateBuffItem(bupdate)
end

function SkillItem.event.sprite:fake_dead_start()
	GameObjTools.SetGray(self.go, true, true)
end

function SkillItem.event.sprite:fake_dead_end()
	GameObjTools.SetGray(self.go, false, true)
end

function SkillItem:ResetBuffIcon()
	for i,item in ipairs(self.buffItems) do
		item.obj:SetActive(false)
	end
end

function SkillItem:GetBuffConfigBuId(buff_id)
	local cfg = ConfigManager.GetConfig("buff_static")
	return cfg[buff_id]
end

--buff图标
function SkillItem:UpdateBuffItem(bupdate)
	if bupdate then
		local itemInfos = {}
		for _goup_type, info in pairs(self.buff_id_dics) do
			for _buff_id, _buffItem in pairs(info) do
				local item = {}
				item.direction_type = _buffItem.direction_type
				item.left_time = (_buffItem.startTime+_buffItem.buff_time) - Time.time
				item.grou_type = _buffItem.grou_type
				item.sprite_name = string.format("bufficon_%d", _buffItem.grou_type) --BUFF.GROUP[_buffItem.grou_type]
				table.insert(itemInfos, item)
			end
		end

		table.sort(itemInfos, function(a, b)
			if a.direction_type == b.direction_type then
				return a.left_time < b.left_time
			else
				return a.direction_type < b.direction_type
			end
		end)

		for i,item in ipairs(self.buffItems) do
			if itemInfos[i] then
				item.obj:SetActive(true)
				item.sprite.SpriteName = itemInfos[i].sprite_name
			else
				item.obj:SetActive(false)
			end
		end

	end
end

function SkillItem:InsertBuffDic(buff_id)
	local bchange = false
	local bshow, groups, direction_type = self:CheckShowBuffIcon(buff_id)
	if bshow then
		for i,_type in ipairs(groups) do
			if self.buff_id_dics[_type] then
				if self.buff_id_dics[_type][buff_id] then
					local buffItem = self:GetBuffItemInfo(buff_id, _type, direction_type)
					self.buff_id_dics[_type][buff_id] = buffItem
					bchange = true
				else
					local breplace = true
					for _buff_id,_buffItem in pairs(self.buff_id_dics[_type]) do
						local buff_time = self:GetBuffTime(_buff_id)
						local left_time = (_buffItem.startTime+_buffItem.buff_time) - Time.time
						local new_buff_time = self:GetBuffTime(buff_id)
						if new_buff_time <= left_time then
							breplace = false
							break
						end
					end

					if breplace then
						local buffItem = self:GetBuffItemInfo(buff_id, _type, direction_type)
						self.buff_id_dics[_type][buff_id] = buffItem
						bchange = true
					end
				end
			else
				if self.buff_show_count < Buff_Max_Show_Count then
					self.buff_id_dics[_type] = {}
					local buff_time = self:GetBuffTime(buff_id)
					local buffItem = self:GetBuffItemInfo(buff_id, _type, direction_type)
					self.buff_id_dics[_type][buff_id] = buffItem
					self.buff_show_count = self.buff_show_count + 1
					bchange = true
				else
					local new_buff_time = self:GetBuffTime(buff_id)
					local buffItem = self:GetBuffItemInfo(buff_id, _type, direction_type)
					local replace_group_type, replace_buff_id
					local relace_time
					for _group_type,info in pairs(self.buff_id_dics) do
						for _buff_id,_buffItem in pairs(info) do
							local left_time = (_buffItem.startTime+_buffItem.buff_time) - Time.time
							if relace_time then
								if left_time < relace_time then
									left_time = relace_time
									replace_group_type, replace_buff_id = _group_type, _buff_id
								end
							else
								relace_time = left_time
								replace_group_type, replace_buff_id = _group_type, _buff_id
							end
						end
					end
					if replace_group_type and replace_buff_id then
						self.buff_id_dics[replace_group_type] = nil
						if self.buff_id_dics[_type] and self.buff_id_dics[_type][buff_id] then
							self.buff_id_dics[_type][buff_id] = buffItem
							bchange = true
						end
					end
				end
			end
		end
		
	end

	return bchange
end

function SkillItem:RemoveBuffDic(buff_id)
	local bchange = false
	local bshow, groups = self:CheckShowBuffIcon(buff_id)
	if bshow then
		for _, _type in pairs(groups) do
			if self.buff_id_dics[_type] then
				self.buff_id_dics[_type] = nil
				self.buff_show_count = self.buff_show_count - 1
				bchange = true
			end
		end
	end

	return bchange
end

function SkillItem:GetBuffItemInfo(buff_id, _type, direction_type)
	local buff_time = self:GetBuffTime(buff_id)
	local buffItem = {startTime = Time.time, buff_time = buff_time, grou_type = _type, direction_type = direction_type}
	return buffItem
end

--buff时长
function SkillItem:GetBuffTime(buff_id)
	local buff_time
	local cfg = self:GetBuffConfigBuId(buff_id)
	if cfg then
		if cfg.time_script then
			local delay,interval,count = table.unpack(cfg.time_script)
			if not count then
				buff_time = Buff_Max_Live_Time
			else
				buff_time = delay+interval*count
			end
		else
			buff_time = Buff_Max_Live_Time
		end
		buff_time = buff_time / 1000
	end
	return buff_time
end


--delay,interval,count count没有配，也是无限时长的，没有time_script也是无限时长
--是否需要显示buff图标
function SkillItem:CheckShowBuffIcon(buff_id)
	local bshow = false
	local groups= {}
	local direction_type = 1
	local cfg = self:GetBuffConfigBuId(buff_id)
	if cfg and cfg.group then
		for i,_type in ipairs(cfg.group) do
			if Buff_Groups[_type] then
				bshow = true
				table.insert(groups, _type)
				direction_type = cfg.type
			end
		end
	end
	return bshow, groups, direction_type
end

-------------------
local SkillHandle = SkillHandle or BaseClass(GameObjFactor)
function SkillHandle:__init(obj)
	self.go = obj
	self:InitObj(obj)
end	

function SkillHandle:InitObj(obj)
	self.rect = self:GetComponent(obj, "RectTransform")
	self.rectPosition = self.rect.anchoredPosition

	self.itemObj = self:GetChild(obj, "CHorizontalItem/item1")
	self.poolRender = ObjPoolRender.New()
	self.poolRender:Load(self.itemObj, self.itemObj.transform.parent, SkillItem)
end

function SkillHandle:Open(data)
	self:UpdateInfo(data)
	self:StartOpenTween()
end

function SkillHandle:Close()
	self.poolRender:ReleaseAll()
	if self.opensequence then
		self.opensequence:Kill()
		self.opensequence = nil
	end	

	if self.skilleffect then
		self.skilleffect:Destroy()
		self.skilleffect = nil
	end			
end

function SkillHandle:Destroy()
	self.poolRender:ReleaseAll()

	if self.skilleffect then
		self.skilleffect:Destroy()
		self.skilleffect = nil
	end	
end	

function SkillHandle:StartOpenTween()	
	self.rect.anchoredPosition = Vector2.New(0, self.rectPosition.y)
	local tween1 = self.rect:DOAnchorPosX(self.rectPosition.x - 10, 0.3)
	local tween2 = self.rect:DOAnchorPosX(self.rectPosition.x, 0.2)

	local sequence = DOTween.Sequence()
	sequence:Append(tween1)
	sequence:Append(tween2)
	self.opensequence = sequence
end

function SkillHandle:UpdateInfo(data)
	self.poolRender:ReleaseAll()

	local spritelist = BattleProxy.Instance:GetSpriteList(CAMP.RED)
	if spritelist then
		for _, spriteid in ipairs(spritelist) do
			if data and data.activityid then
				if data.activityid == ACTIVITYID.TRIAL then
					--试玩只显示试玩英雄得卡牌
					local sprite_data=BattleProxy.Instance:GetSprite(spriteid)
					if sprite_data then
						if sprite_data.typeid == data.roleid then
							local item = self.poolRender:Get(spriteid) 
						end
					end
				else
					local item = self.poolRender:Get(spriteid) 
				end
			else
				local item = self.poolRender:Get(spriteid) 
			end
		end
	end

	if not self.skilleffect then
		self.skilleffect = UIEffectItem.New("ui_battle_spell01", self.go)
	end		
end

--放大招
function SkillHandle:OnUserSkill(spriteid)
	-- local position = UILayerTool.GetSpriteScreenPos(spriteid)
	-- self.skilleffect:SetLocalPosition(position.x, position.y, position.z)
	--self.skilleffect:Play()
end

return SkillHandle