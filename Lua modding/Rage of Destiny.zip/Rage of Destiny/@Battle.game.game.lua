local game = {_mod_status = -1}

local gameengine = nil
local gameobj = nil
local LOGIC_TICK = 50           ---------1000/每秒帧频20
local current_time = 0
local current_frame = 0
local total_time = 0
local floor = math.floor
local bpause = false
local bover = false
local speed = 1
local bridge = nil

function game.init(engine, engineargs, gameargs, _bridge)
    gameengine = engine
    engine:init()
    engine:initmodules(engineargs)
    engine:initmodules(gameargs)
    bridge = _bridge
end

function game.setglobal(key, value)
    global[key] = value
end

function game.start(game_path, gameid, activityid, seed, gameprop)

    global.game = { gameid = gameid, activityid = activityid }
    global.gamer = game
    game._mod_status = -1
    total_time = 0
    current_time = 0
    current_frame = 0
    bover = false

    gamelog.start()
    tsmath.seed(seed or 0)

    local gamename = "game"..gameid
    local config_path = string.format("%s.%s.config.", game_path, gamename)
    local status, cfg = pcall(require, config_path .. string.format("%s_config", gamename))
    if not status then
        print("没有配置玩法"..gameid, cfg)
    end
    local gamecfg = cfg[1]
    LOGIC_TICK = gamecfg.tick or LOGIC_TICK
    global.service.time.tick = LOGIC_TICK
    if cfg.loadconfig then
        cfg.loadconfig()
    end
    gameobj = global.service.obj_factory:addobj(0, gameid, gameprop, "game")
    local area = keyconfig(gameobj.prop.config_key, gamecfg.area)
    assert(area,  string.format("找不到area配置,config_key:%s",gameobj.prop.config_key))
    local maptype, centerx, centery, sizex, sizey = table.unpack(area)
    game.bmessage("CreateGame", maptype, centerx, centery, sizex, sizey)

    global.service.area:setbattleside(maptype, tsvector.new(centerx, centery), sizex, sizey or sizex)
    global.service.sprite:setcallback()

    game._load(game_path, "common", gameobj)
    game._load(game_path, gamename, gameobj)
    game._addlogics(gameobj, cfg[2])
    game._addfixlogics(gameobj)

    game.speed(1)
    game.resume()


end

-- b一个事件
function game.bmessage(message, ...)
    if bridge and bridge[message] then
        bridge[message](...)
    end
end

function game.restart()
    
end

function game.sendevent(eventkey, ...)
    global.service.eventslots:getslot("game"):send(gameobj, eventkey, ...)
end

function game._load(game_path, gameid, gameobj)

    local logic_path = string.format("%s.%s.logic.", game_path, gameid)

    if logic_path then
        local logic_factory = global.service.logic_factory
        global.service.requirer:register_search_path(logic_path)
    end

end

function game._addlogics(gameobj, logiccfg)
    local configkey = gameobj.prop.config_key
    global.array.sort_iter(logiccfg, function (type, static)
        local template = global.service.requirer:require(type)
        local _static = {}
        for key, value in pairs(static) do
            _static[key] = keyconfig(configkey, value)
        end
        global.service.logic_factory:createlogic(gameobj, type, _static, nil, template)
    end)
end

local FIXLOGICS = {
    "game.basic.game_input_logic"
}

function game._addfixlogics(gameobj)
    for i, type in ipairs(FIXLOGICS) do
        local template = global.service.requirer:require(type)
        global.service.logic_factory:createlogic(gameobj, type, nil, nil, template)
    end
end

function game.pause()
    bpause = true
end

function game.resume()
    bpause = false
end

function game.over()
    bover = true
end

function game.speed(_speed)
    speed = _speed
end

function game.getstate()
    return { bover = bover, bpause = bpause, speed = speed, current_frame = current_frame, total_time = total_time, current_time = current_time }
end

function game.setmodstatus(status)
    game._mod_status = status
end

function game.getbmod()
    if game._mod_status < 0 then
        return true
    end
    return false
end

function game.process(time, tick)
    if bpause then return end
    current_time = current_time + tick
    total_time = total_time + tick
    local speedtick = LOGIC_TICK / 1000 / speed
    while current_time >= speedtick and not bover do
        game.fixprocess(current_frame * LOGIC_TICK, LOGIC_TICK)
        current_frame = current_frame + 1
        current_time = current_time - speedtick
    end
end

function game.fixprocess(time, tick)
    if bpause or bover then return end
    gameengine:process(time, tick)
    game.bmessage("UpdateGame", time, tick)
    gameengine:process_late(time, tick)
end

function game.simulateprocess(time, tick)
    time = floor(time * 1000)
    tick = floor(tick * 1000)
    game.fixprocess(time,tick)
end

function game.stop()
    game.pause()
end

function game.dispose()
    game.stop()
    if gameobj then
        gameobj:destroy(true)
    end
    if gameengine then
        gameengine:dispose()
        gameengine = nil
    end
    gameobj = nil
    game.bmessage("DestroyGame")
end

return game