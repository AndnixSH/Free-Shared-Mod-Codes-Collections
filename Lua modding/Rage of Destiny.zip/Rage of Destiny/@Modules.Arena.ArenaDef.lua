local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
local RedPointDef = require "Modules.RedPoint.RedPointDef"
local ArenaDef = {}
ArenaDef.NotifyDef =
{
    Arena_Request="Arena_Request",
    Arena_ListRequest="Arena_ListRequest",
    Arena_Records="Arena_Records",
    Arena_RecordsRed="Arena_RecordsRed",
    Arena_ChallengeList="Arena_ChallengeList",
    Arena_UpdateDefenseList="Arena_UpdateDefenseList",
    Arena_UpdateHasGetCoin="Arena_UpdateHasGetCoin",
    Arena_UpdateRecordsDetail="Arena_UpdateRecordsDetail",
    Arena_UpdatePlayerDefenceHeros="Arena_UpdatePlayerDefenceHeros",
}

ArenaDef.CommonDef={

    RefreshTips="ArenaView_1001",--%s天%s小时
    RefreshTips1="ArenaView_1002",--%s小时%s分

    ArenaTitle="ArenaView_1003",--竞技场
    ArenaRank="ArenaView_1004",

    HightArenaTitle="ArenaView_1005",--%s小时%s分
    HightArenaRank="ArenaView_1006",

    UnOpen="ArenaView_1007",
    FreeChanllege="ArenaView_1008",
    Chanllege="ArenaView_1009",
    NoRank="ArenaView_1010",

    BuyGoodsSuccess="ArenaView_1011",

    TeamCannotEmpty="ArenaView_1012",
    SetDefenceSuccess="ArenaView_1013",

    PleaseChooseUpHero="ArenaView_1014",
    Hour="ArenaView_1015",
    GetCoinTips="ArenaView_1016",

    PlayVideoTips="ArenaView_1017", --对手无上阵英雄，我方不战而胜

    Victory = "ArenaView_1036",
    Fail = "ArenaView_1037",

    NoCoin = "ArenaView_1039"
}

ArenaDef.RedPointId =
{
    RedPointDef.Id.List_NormalArena,
    RedPointDef.Id.List_ProArena,
}

ArenaDef.RoomType={
    Arena=1,
    HighArena=2,
}

ArenaDef.Views={

    [1]=UIWidgetNameDef.ArenaView,
    [2]=UIWidgetNameDef.ProArenaView,
}

ArenaDef.SystemOpenType={

    [1]=ModuleOpenDef.SystemOpenType.ArenaEntranceView,
    [2]=ModuleOpenDef.SystemOpenType.ProArenaEntranceView,
}

ArenaDef.ArenaCoinGoodsId=
{
    [1]=502001,
    [2]=502002,
} --竞技入场券

ArenaDef.ProRankSprName=
{
    [1]="zuiqiangwangzhe",
    [20]="zuanshi",
    [50]="baijin",
    [100]="huangjin",
    [150]="baiyin",
    [200]="qingtong",
}
return ArenaDef
