local render_camera = {_field_of_view = 0, _enable_3d_camera = true}

local cRenderCameraAdapt = CS.LJY.NX.RenderCameraAdapt

function render_camera.pause()
    cRenderCameraAdapt.Pause()
end

function render_camera.resume()
    cRenderCameraAdapt.Resume()
end

function render_camera.speed(speed_rate)
    cRenderCameraAdapt.Speed(speed_rate)
end

function render_camera.enable_3d_camera(enable)
    if enable == render_camera._enable_3d_camera then
        return
    end
    if not enable then
        cRenderCameraAdapt.Enable3DCamera(false)
    else
        render_camera._reset_camera_culling_mask()
    end
    render_camera._enable_3d_camera = enable
end

function render_camera._reset_camera_culling_mask()
    cRenderCameraAdapt.ResetCameraCullingMask()
end

function render_camera.add_fadeIn_component(time)
    cRenderCameraAdapt.AddFadeInComponent(time)
end

function render_camera.disable_fadeIn_component()
    cRenderCameraAdapt.DisableFadeInComponent()
end

function render_camera.destroy_fadeIn_component()
    cRenderCameraAdapt.DestroyFadeInComponent()
end

function render_camera.create_effect_camera()
    cRenderCameraAdapt:CreateEffectCamera()
end

function render_camera.destroy_effect_camera()
    cRenderCameraAdapt:DestroyEffectCamera()
end

function render_camera.set_camera_field_of_view(field_of_view)
    field_of_view = field_of_view or render_camera._field_of_view
    cRenderCameraAdapt.SetCameraFieldOfView(field_of_view)
    render_camera._field_of_view = field_of_view
end

function render_camera.set_camera_background_color(red, green, blue, alpha)
    cRenderCameraAdapt.SetCameraBackgroundColor(red, green, blue, alpha)
    render_camera._background_color = { red, green, blue, alpha }
end

function render_camera.get_camera_background_color()
    local c = render_camera._background_color
    if c then
        return { red = c[1], green = c[2], blue = c[3], alpha = c[4] }
    end
end

function render_camera.set_camera_transform(camera_params)
    local pos_x = camera_params.x
    local pos_y = camera_params.y
    local pos_z = camera_params.z
    local pitch = camera_params.pitch
    local yaw = camera_params.yaw
    local roll = camera_params.roll

    cRenderCameraAdapt.SetCameraTransform(pos_x, pos_y, pos_z, pitch, yaw, roll)
end

function render_camera.free_trunk_strategy()
    cRenderCameraAdapt.FreeTrunkStrategy()
end

function render_camera.free_branch_strategy()
    cRenderCameraAdapt.FreeBranchStrategy()
end

function render_camera.free_face_strategy()
    cRenderCameraAdapt.FreeFaceStrategy()
end

function render_camera.set_bone_trunk_strategy(obj, camera_params)
    --local parent_obj
    local bone = camera_params.bone
    local speed = 15

    if camera_params.fogSpeed then
        local beginStartDistance = camera_params.beginDistance[1]
        local beginEndDistance = camera_params.beginDistance[2]
        local endStartDistance = camera_params.endDistance[1]
        local endEndDistance = camera_params.endDistance[2]
        local fogSpeed = camera_params.fogSpeed

        cRenderCameraAdapt.SetBoneTrunkStrategy(
                obj,
            bone,
            beginStartDistance,
            beginEndDistance,
            endStartDistance,
            endEndDistance,
            fogSpeed,
            speed
        )
    else
        cRenderCameraAdapt.SetBoneTrunkStrategy(obj, bone, speed)
    end
end

function render_camera.set_drama_trunk_strategy(bone_name, total_time, action)
    if not bone_name then
        return
    end
    cRenderCameraAdapt.SetDramaCameraStrategy(bone_name, total_time, action)
end

function render_camera.set_adjust_trunk_strategy(camera_params)
    local x = camera_params.x
    local y = camera_params.y
    local z = camera_params.z

    local pitch = camera_params.pitch
    local yaw = camera_params.yaw
    local roll = camera_params.roll

    local delayTime = camera_params.delayTime or 0

    local xMinBoundValue = camera_params.xMinBoundValue
    local xMaxBoundValue = camera_params.xMaxBoundValue

    local yMinBoundValue = camera_params.yMinBoundValue
    local yMaxBoundValue = camera_params.yMaxBoundValue

    local zMinBoundValue = camera_params.zMinBoundValue
    local zMaxBoundValue = camera_params.zMaxBoundValue

    local horizontalMod = camera_params.horizontalMod
    local zoomMod = camera_params.zoomMod
    local smoothTime = camera_params.smoothTime
    local speed = camera_params.speed

    cRenderCameraAdapt.SetAdjustTrunkStrategy(
        x,
        y,
        z,
        pitch,
        yaw,
        roll,
        xMinBoundValue,
        xMaxBoundValue,
        yMinBoundValue,
        yMaxBoundValue,
        zMinBoundValue,
        zMaxBoundValue,
        horizontalMod,
        zoomMod,
        smoothTime,
        speed,
        delayTime
    )
end

function render_camera.set_adjust_offset(x, z, distance, speed)
    cRenderCameraAdapt.SetAdjustOffset(x, z, distance, speed)
end

function render_camera.set_hero_show_camera(camera_info)
    local hero_target_x = camera_info[1]
    local hero_target_y = camera_info[2]
    local hero_target_z = camera_info[3]
    local camera_target_x = camera_info[4]
    local camera_target_y = camera_info[5]
    local camera_target_z = camera_info[6]
    local field_of_view = 28
    local offset_y = camera_info[7] or 1.6
    local rotate_x = 6
    local distance = camera_info[8] or 3
    local zoom_min = 2.3
    local zoom_max = 4.1
    local up_max = 1.8
    local up_min = 1

    render_camera.set_camera_field_of_view(field_of_view)
    cRenderCameraAdapt.SetHeroShowTrunkStrategy(
        hero_target_x,
        hero_target_y,
        hero_target_z,
        camera_target_x,
        camera_target_y,
        camera_target_z,
        offset_y,
        rotate_x,
        distance,
        zoom_min,
        zoom_max,
        up_max,
        up_min
    )
end

function render_camera.enable_hero_show_input(enable)
    if enable == nil then
        enable = true
    end
    cRenderCameraAdapt.SetHeroShowInputEnable(enable)
end


function render_camera.set_world_map_camera(camera_info)
    local field_of_view = 60
    local x = camera_info[1]
    local y = camera_info[2]
    local z = camera_info[3]
    local pitch = camera_info[4]
    local yaw = camera_info[5]
    local roll = camera_info[6]
    local x_min = -25.5
    local x_max = 7.5
    local y_min =1
    local y_max = 3.25 --28.5
    local speed = 8

    render_camera.set_camera_field_of_view(field_of_view)
    cRenderCameraAdapt.SetWorldMapTrunkStrategy(x, y, z, pitch, yaw, roll, x_min, x_max, y_min, y_max, speed)
end

function render_camera.enable_world_map_input(enable)
    if enable == nil then
        enable = true
    end
    cRenderCameraAdapt.SetWorldMapInputEnable(enable)
end

function render_camera.set_world_map_target_position(x, y, z)
    if not x or not y or not z then
        return
    end

    local speed = 5

    cRenderCameraAdapt.SetWorldMapTargetPosition(x, y, z, speed)
end

function render_camera.set_story_line_camera_info(offset, edge, speed, field_of_view)
    local offset_x, offset_y, offset_z = table.unpack(offset)
    local x_min, x_max, y_min, y_max, z_min, z_max = table.unpack(edge)
    render_camera._story_line_camera = { offset = { x = offset_x, y = offset_y, z = offset_z }, 
                                        edge = {x_min = x_min, x_max = x_max, y_min = y_min, y_max = y_max, z_min = z_min, z_max = z_max }, 
                                        speed = speed or 15, 
                                        field_of_view = field_of_view or 34.5 }
    -- print("_story_line_camera", table.dump(render_camera._story_line_camera))
end

function render_camera.set_story_line_camera(position)
    
    local conf = render_camera._story_line_camera
    if not conf then return end

    local x = position.x
    local y = position.y
    local z = position.z

    local offset, edge = conf.offset, conf.edge

    render_camera.set_camera_field_of_view(conf.field_of_view)
    cRenderCameraAdapt.SetStoryLineTrunkStrategy(x, y, z, offset.x, offset.y, offset.z, edge.x_min, edge.x_max, edge.y_min, edge.y_max, edge.z_min, edge.z_max, conf.speed)
end

function render_camera.remove_story_line_camera()
    render_camera._story_line_camera = nil
end

function render_camera.enable_story_line_input(enable)
    if enable == nil then
        enable = true
    end
    cRenderCameraAdapt.SetStoryLineInputEnable(enable)
end

function render_camera.set_story_line_target_position(x, y, z, speed)
    if not x or not y or not z then
        return
    end

    local conf = render_camera._story_line_camera
    if not conf then return end

    local offset_x = conf.offset.x
    local offset_y = conf.offset.y
    local offset_z = conf.offset.z

    cRenderCameraAdapt.SetStoryLineTargetPosition(x, y, z, offset_x, offset_y, offset_z, speed)
end

function render_camera.get_story_line_target_position()

    local conf = render_camera._story_line_camera
    if not conf then return Vector3.zero end

    local offset_x = conf.offset.x
    local offset_y = conf.offset.y
    local offset_z = conf.offset.z

    local result = cRenderCameraAdapt.GetStoryLineTargetPosition()
    return Vector3.New(result.x - offset_x, result.y - offset_y, result.z - offset_z)
end

function render_camera.face_story_line_camera(anchor)
    if anchor then

        local conf = render_camera._story_line_camera
        if not conf then return end
        
        local offset, edge = conf.offset, conf.edge

        local offset_x = offset.x
        local offset_y = offset.y
        local offset_z = offset.z

        local x_min = edge.x_min
        local x_max = edge.x_max
        local z_min = edge.z_min
        local z_max = edge.z_max

        cRenderCameraAdapt.FaceStoryLineCamera(anchor, offset_x, offset_y, offset_z, x_min, x_max, z_min, z_max)
    end
end

--function render_camera.set_transform_camera_strategy(x, y, z, offset_x, offset_y, offset_z, speed, action)
--    x = x or 0
--    y = y or 0
--    z = z or 0
--
--    action = action or function()
--        print("-----------------------------------")
--    end
--
--    offset_x = offset_x or 0
--    offset_y = offset_y or 6
--    offset_z = offset_z or -2.9
--
--    cRenderCameraAdapt.SetTransformCameraStrategy(x, y, z, offset_x, offset_y, offset_z, speed, action)
--end
--
--function render_camera.set_position_camera_strategy(x, y, z, offset_x, offset_y, offset_z, speed, action)
--    x = x or 0
--    y = y or 0
--    z = z or 0
--
--    action = action or function()
--        print("-----------------------------------")
--    end
--
--    offset_x = offset_x or 0
--    offset_y = offset_y or 5.5
--    offset_z = offset_z or -2.9
--
--    cRenderCameraAdapt.SetPositionCameraStrategy(x, y, z, offset_x, offset_y, offset_z, speed, action)
--end

function render_camera.set_shake_camera(camera_info)
    local offsetX = camera_info[1] or 0
    local offsetY = camera_info[2] or 0
    local offsetZ = camera_info[3] or 0
    local cycleTime = camera_info[4] or 0
    local cycleCount = camera_info[5] or 0

    cRenderCameraAdapt.SetShakeCameraStrategy(offsetX, offsetY, offsetZ, cycleTime, cycleCount)
end

-- 震屏开关 type 1 战斗外 2 战斗内
function render_camera.set_shake_enable(type, enable)

    if type == 1 then
        cRenderCameraAdapt.SetMergeEnable("ShakeBranch", enable)
    elseif type == 2 then
        cRenderCameraAdapt.SetMergeEnable("Shake", enable)
    end
end

function render_camera.add_transparent_control(gameobject)
    cRenderCameraAdapt.AddTransparentControl(gameobject)
end

function render_camera.remove_transparent_control()
    cRenderCameraAdapt.RemoveTransparentControl()
end

function render_camera.set_shdow_type(shadow_type)
    cRenderCameraAdapt.SetShadowType(shadow_type)
end

function render_camera.set_input_enable(enable)
    if enable == nil then
        enable = true
    end

    cRenderCameraAdapt.SetInputEnable(enable)
end

return render_camera
