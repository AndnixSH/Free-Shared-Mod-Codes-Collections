local MainDef = require "Modules.Main.MainDef"
local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
local RedPointDef = require "Modules.RedPoint.RedPointDef"
local MallDef = require "Modules.Mall.MallDef"

ConfigManager.InitConfig("data_modules", {
	---------------界面Root-----------
	["ViewRoot"] = 
	{
		[UIWidgetNameDef.HeroRootView] = {
			[1] = { view = UIWidgetNameDef.HeroListView, title = "HeroRoot_1001", normalicon = "yingxiong_1" ,selecticon = "yingxiong_1", redDot_key = RedPointDef.Id.HeroTab, back = nil,norIconGray = true},
			[2] = { view = UIWidgetNameDef.HeroTeamListView, title = "HeroRoot_1002", normalicon = "biandui_1" ,selecticon = "biandui_1", redDot_key = "", back = nil,norIconGray = true},
			[3] = { view = UIWidgetNameDef.HeroBookListView, title = "HeroRoot_1003", normalicon = "tujian_1" ,selecticon = "tujian_1", redDot_key = "", back = nil,norIconGray = true},
		},
		
		[UIWidgetNameDef.FriendRootView] = {
			[1] = {view = UIWidgetNameDef.ApplyfriendView, title = "FriendView_1046", normalicon = "applyfriendlogo" ,selecticon = "applyfriendlogo", back = nil,norIconGray = true, redPointId = RedPointDef.Id.FriendApply},
			[2] = {view = UIWidgetNameDef.AddfriendView, title = "FriendView_1001", normalicon = "addfriendlogo" ,selecticon = "addfriendlogo", back = nil,norIconGray = true},
			[3] = {view = UIWidgetNameDef.BlacklistView, title = "FriendView_1003", normalicon = "heimingdanlogo" ,selecticon = "heimingdanlogo", back = nil,norIconGray = true},
		},
		
		[UIWidgetNameDef.GuildRootView] = {
			[1] = {view = UIWidgetNameDef.ApplyGuildView, title = "GuildView_1001", normalicon = "gonghuituijian" ,selecticon = "gonghuituijian", back = nil,norIconGray = true},
			[2] = {view = UIWidgetNameDef.GuildCreateView, title = "GuildView_1002", normalicon = "chuangjiangonghui" ,selecticon = "chuangjiangonghui", back = nil,norIconGray = true},
		},
		
		[UIWidgetNameDef.MercRootView] = {
			[1] = {view = UIWidgetNameDef.MercApplyView, title = "FriendView_1047", normalicon = "addfriendlogo" ,selecticon = "addfriendlogo", redDot_key = RedPointDef.Id.HireHeroApply, back = nil,norIconGray = true},
			[2] = {view = UIWidgetNameDef.MercSendInoView, title = "FriendView_1014", normalicon = "addfriendlogo" ,selecticon = "addfriendlogo", back = nil,norIconGray = true},
		},
		
		
	},
	----------通用全屏设置---------
	["FullScreenOption"] = 
	{
		--注:isOpen 打开界面(true 替换系统配置, false 只更新信息); background 背景图; viewName 文字图标; bShowPhone 电池图标; titleType:标题类型 titleType =4 与 itleType =1 一样，只是改变了位置
		-- property {{物品id,icon,badd}} 监听货币信息 fulleffect false/true ; 
		-- propertyinfo： spacing 间距; position 位置; backicon 货币背景图片 plusicon 跳转背景图片 backSize 背景图尺寸 backPosition 背景图位置	
		[UIWidgetNameDef.HeroRootView] = 
		{
			isOpen = true, background = "Tex_Bg_8", viewName = "FullScreen_1001", fulleffect = "UI_Common_back",titleType = 1,
			property= {}
		},
		[UIWidgetNameDef.HeroView] = 
		{
			isOpen = true, background = "", viewName = "FullScreen_1001",
			property= {{702001,"jinbi",false},{701001,"zuanshi",false},{704001,"yingxiongjingyan",false},{690001,"fenchen",false},}
		},
		[UIWidgetNameDef.HeroNewView] = 
		{
			isOpen = true, background = "", viewName = "FullScreen_1001",titleType = 2,
			property= {{702001,"jinbi",false},{701001,"zuanshi",false},{704001,"yingxiongjingyan",false},{690001,"fenchen",false},}
		},
		[UIWidgetNameDef.BagRootView] = 
		{
			isOpen = true, background = "Tex_Bg_8", viewName = "FullScreen_1002",fulleffect = "UI_Common_back",titleType = 1,
			property= {{702001,"jinbi",false},{701001,"zuanshi",false},}
		},				
		[UIWidgetNameDef.TowerChallengeView] = 
		{
			isOpen = true, background = "Tex_Bg_8", titleType=2,
			property= {}
		},
		[UIWidgetNameDef.TowerEntranceView] = 
		{
			isOpen = true, background = "Tex_Bg_8", viewName = "FullScreen_1003",fulleffect = "UI_Common_back",titleType = 2,
			property= {}
		},		
		[UIWidgetNameDef.EquipmentEnhanceView] =
		{
			isOpen = true, background = "Tex_Bg_8", viewName = "FullScreen_1004", fulleffect = "UI_Common_back",
			property= {}
		},
		[UIWidgetNameDef.EquipmentStrengthenView] =
		{
			isOpen = true, background = "Tex_Bg_17", viewName = "FullScreen_1005",
			property= {}
		},
		[UIWidgetNameDef.ExclusiveStrengthenView] =
		{
			isOpen = true, background = "Tex_Bg_12", viewName = "FullScreen_1004",titleType = 2,
			property= {}
		},
		[UIWidgetNameDef.ArtifactStrengthenView] =
		{
			isOpen = true, background = "Tex_Bg_12", viewName = "FullScreen_1015",titleType = 2,
			property= {}
		},
		[UIWidgetNameDef.CrystalView] =
		{
			isOpen = true, background = "", viewName = "FullScreen_1006",titleType = 2,
			property= {{714001,"shuijing",false},{701001,"zuanshi",false},},
			explainContentId=7,
		},
		[UIWidgetNameDef.TempleView] =
		{
			isOpen = true, background = "", viewName = "FullScreen_1007",titleType = 2,
			property= {},
			explainContentId=8,
		},	
		[UIWidgetNameDef.CardPortalView] =
		{
			isOpen = true, background = "", viewName = "FullScreen_1008",titleType = 2,
			property= {{701001,"zuanshi",false},{691001,"putongchoujiangquan",false},{692001,"zhongzuchoujiangquan",false},{712001,"smallheart",false},}
		},
		[UIWidgetNameDef.CardStarView] =
		{
			isOpen = true, background = "", viewName = "MainCommon_1017",titleType = 2,
			property= {{701001,"zuanshi",false},{693001,"zhanxingquan",false},}
		},
		[UIWidgetNameDef.CampaignProgressView] =
		{
			isOpen = true, background = "",titleType = 2,
			property= {}
		},	
		[UIWidgetNameDef.MazeView] =
		{
			isOpen = true, background = "",titleType = 2,
			property= {}
		},	
		[UIWidgetNameDef.StoreView] = 
		{
			isOpen = true, background = "Tex_Bg_8", viewName = "FullScreen_1009", fulleffect = "UI_Common_back",titleType = 1,
			property= {{702001,"jinbi",false},{701001,"zuanshi",false},}
		},	
		[UIWidgetNameDef.StoryLineView] =
		{
			isOpen = true, background = "", fulleffect = "UI_Common_back",titleType = 2,
			property= {}
		},
		[UIWidgetNameDef.StoryLineRootView] =
		{
			isOpen = true, background = "Tex_Bg_8", viewName = "FullScreen_1010",fulleffect = "UI_Common_back",
			property= {},explainContentId=4
		},

		[UIWidgetNameDef.RealmView] =
		{
			isOpen = true, background = "", fulleffect = "UI_Common_back",titleType = 2,
			property= {}
		},

		[UIWidgetNameDef.FountainView] =
		{
			isOpen = true, background = "Tex_Bg_8", viewName = "FullScreen_1011", fulleffect = "UI_Common_back",titleType = 1,
			property= {},explainContentTb = {9,10,11}
		},
		[UIWidgetNameDef.MainTaskView] =
		{
			isOpen = true, background = "Tex_Bg_8", viewName = "FullScreen_1012",fulleffect = "UI_Common_back",
			property= {}
		},
		[UIWidgetNameDef.HomePageView] = 
		{
			isOpen = true, background = "Tex_Bg_8", viewName = "FullScreen_1013",fulleffect = "UI_Common_back",
			property= {{702001,"jinbi",false},{701001,"zuanshi",false},}
		},
		[UIWidgetNameDef.OtherPlayerInfolView] = 
		{
			isOpen = true, background = "Tex_Bg_8", viewName = "FullScreen_1013",fulleffect = "UI_Common_back",
			property= {}
		},
		[UIWidgetNameDef.WorldMapRootView] = 
		{
			isOpen = true, background = "", viewName = "FullScreen_1014",titleType = 2,
			property= {}
		},

		[UIWidgetNameDef.ArenaEntranceView] = 
		{
			isOpen = true, background = "Tex_Bg_8", viewName = "FullScreen_1016",titleType = 1,
			property= {}
		},
		[UIWidgetNameDef.ArenaView] = 
		{
			isOpen = true, background = "Tex_Bg_8", viewName = "ArenaView_1003",titleType = 1,
			property= {}
		},
		[UIWidgetNameDef.ProArenaView] = 
		{
			isOpen = true, background = "Tex_Bg_8", viewName = "FullScreen_1017",titleType = 1,
			property= {}
		},
		[UIWidgetNameDef.FriendlListView] = 
		{
			isOpen = true, background = "Tex_Bg_8", viewName = "FullScreen_1018",
			property= {}
		},

		[UIWidgetNameDef.ChatRootView] = 
		{
			isOpen = true, background = "Tex_Bg_8", viewName = "FullScreen_1019",
			property= {}
		},
		[UIWidgetNameDef.RelationMenuRootView] = 
		{
			isOpen = true, background = "Tex_Bg_8", viewName = "FullScreen_1020",
			property= {}, explainContentTb = {12,14},
		},

		[UIWidgetNameDef.GuildRootView] = 
		{
			isOpen = true, background = "Tex_Guild_create", viewName = "FullScreen_1021", fulleffect = "UI_Common_back",
			property= {}, backgroundPos = Vector2.New(-25, 0)
		},

		[UIWidgetNameDef.GuildBossView] = 
		{
			isOpen = true, background = "Tex_Bg_GuildBoss", viewName = "FullScreen_1022", fulleffect = "UI_Common_back",titleType = 2,
			property= {}, explainContentId = 6
		},

		[UIWidgetNameDef.GuildChaosView] = 
		{
			isOpen = true, background = "Tex_Bg_Chaos", viewName = "Chaos_view_1001", fulleffect = "UI_Common_back",titleType = 2,
			property= {}, explainContentId = 15
		},
		
		[UIWidgetNameDef.GuildHallView] = 
		{
			isOpen = true, background = "Tex_Guild_create", viewName = "FullScreen_1023", fulleffect = "UI_Common_back",
			property= {}, backgroundPos = Vector2.New(-25, 0)
		},

		[UIWidgetNameDef.GuildInformationView] = 
		{
			isOpen = true, background = "Tex_Guild_create", viewName = "FullScreen_1024", fulleffect = "UI_Common_back",
			property= {}, backgroundPos = Vector2.New(-25, 0)
		},

		[UIWidgetNameDef.GuildEntranceView] = 
		{
			isOpen = true, background = "Tex_Guild_create", viewName = "FullScreen_1024", fulleffect = "UI_Common_back",
			property= {}, backgroundPos = Vector2.New(-25, 0)
		},
		[UIWidgetNameDef.RankListView] = 
		{
			isOpen = true, background = "Tex_Bg_8", viewName = "FullScreen_1025", titleType = 1,
			property= {},explainContentId=5
		},
		[UIWidgetNameDef.RankListInfoView] = 
		{
			isOpen = true, background = "", viewName = "FullScreen_1025", titleType = 1,
			property= {}
		},

		[UIWidgetNameDef.MallRootView] = 
		{
			isOpen = true, background = "Tex_Bg_13", viewName = "FullScreen_1026",titleType = 4,
			property= {{701001,"zuanshi",false}}, back2Sp4Name = "anniu_fanhui3",
		},

		[UIWidgetNameDef.SupplyDepotView] = 
		{
			isOpen = true, background = "", viewName = "MainCommon_1010", titleType = 2,
			property= {}
		},
		[UIWidgetNameDef.VipView] = 
		{
			isOpen = true, background = "Tex_Bg_13", viewName = "MainCommon_1033", titleType = 1,
			property= {}
		},
		[UIWidgetNameDef.ActivityRootView] = 
		{
			isOpen = true, background = "", viewName = "", titleType = 4,
			property= {}
		},
		[UIWidgetNameDef.ShareChargeView] = 
		{
			isOpen = true, background = "Tex_Herotips_race2", viewName = "Activityinfo_1017", titleType = 2,
			property= {}
		},
		[UIWidgetNameDef.RealmRootView] = 
		{
			isOpen = true, background = "Tex_Bg_Realm", viewName = "MainCommon_1011",
			property= {},explainContentId=13
		},

		[UIWidgetNameDef.MobilizeView] = 
		{
			isOpen = true, background = "Tex_Mobilize_ditu", viewName = "Activityinfo_2001_1",
			property= {},
		},
	},
	--------系统图标界面-----
	["SystemItem"] = 
	{
		[1] = {label = "Main_1001", icon = "2_1", view = UIWidgetNameDef.MainTaskView, systemOpenType = ModuleOpenDef.SystemOpenType.MainTaskView, gotoParama = {AppFacade.Task},redDotType = MainDef.MainRedDotType.Task, sound = "bottom_view"},
		[2] = {label = "Main_1002", icon = "2_2", view = UIWidgetNameDef.BagRootView, systemOpenType = ModuleOpenDef.SystemOpenType.BagRootView, gotoParama = {AppFacade.Bag}, redDotType = MainDef.MainRedDotType.Bag, sound = "bag_open"},
		[3] = {label = "Main_1003", icon = "2_3", view = UIWidgetNameDef.MailView, systemOpenType = ModuleOpenDef.SystemOpenType.MailView, gotoParama = {AppFacade.Mail},redDotType =MainDef.MainRedDotType.Mail, sound = "mail_list_open"},
		[4] = {label = "Main_1004", icon = "2_4", view = UIWidgetNameDef.FriendlListView, systemOpenType = ModuleOpenDef.SystemOpenType.FriendlListView, gotoParama = {AppFacade.Friend}, redDotType =MainDef.MainRedDotType.Friend, sound = "bottom_view"},
	},
	--------活动图标界面-----
	["ActivityItem"] =
	{
		[1] = {label = "Activityinfo_1027",index = 1, icon = "3_6",parama = {AppFacade.SettingMenu,1}}, --新闻页临时入口
		[2] = {label = "Activityinfo_1017",index = 2,icon = "3_5",redpointId = RedPointDef.Id.Activity_Share,parama = {AppFacade.Activity,3}}, --分享
		[3] = {label = "Activityinfo_1020",index = 3, icon = "3_4",redpointId = RedPointDef.Id.HatharalComingEnter, parama = {AppFacade.Activity,6}}, --首充任意
		[4] = {label = "Activityinfo_1019",index = 5, icon = "3_3", redpointId = RedPointDef.Id.StageClearChargeEnter,parama = {AppFacade.Activity,5}}, --冲关奖励
		[5] = {label = "Activityinfo_1016",index = 6, icon = "3_2", redpointId = RedPointDef.Id.New_Player_Enter,parama = {AppFacade.Activity,2}}, --新手任务
		[6] = {label = "Activityinfo_1015",index = 7, icon = "3_1", redpointId = RedPointDef.Id.Seven_Login_Enter,parama = {AppFacade.Activity,1}}, --新手登录
		[7] = {label = "Activityinfo_1030",index = 4, icon = "3_7",redpointId = RedPointDef.Id.HeroComingEnter, parama = {AppFacade.Activity,7}}, 
		[8] = {label = "Activity_summer_1002",index = 8, icon = "New7activity",redpointId = RedPointDef.Id.Events_Seven_Login, parama = {AppFacade.CycleActivity,1,1}}, 
		[9] = {label = "Activity_Login_Earth_1001",index = 9, icon = "3_8",redpointId = RedPointDef.Id.Events_Seven_Login_Two, parama = {AppFacade.CycleActivity,2,2}}, 
		[10] = {label = "Activity_Elven_1017",index = 10, icon = "3_9",redpointId = RedPointDef.Id.HeroComingEnter_Two,parama = {AppFacade.Activity,8}}, 
		[11] = {label = "ActivitySquareNine_1018",index = 11, icon = "LadiesParty",redpointId = RedPointDef.Id.Nine_Grid,parama = {AppFacade.CycleActivity,3,3}}, 
		[12] = {label = "Activityinfo_2001",index = 12, icon = "3_10",redpointId = RedPointDef.Id.MobilizeEnter,parama = {AppFacade.Mobilize,1}},
		[13] = {label = "Main_1007",index = 13, icon = "1_3", redpointId = RedPointDef.Id.Activity,parama = {AppFacade.Activity,10}}, --首充任意
	},

	--------主界面左侧活动图标界面-----
	["LeftActivityItem"] =
	{
		[1] = {label = "Main_1005",index = MainDef.LeftActivityType.Mall,icon = "1_1", parama = {AppFacade.Mall,1}}, --商城
		[2] = {label = "Main_1006",index = MainDef.LeftActivityType.FirstCharge,icon = "1_2",parama = {AppFacade.Mall,2}}, --首充
		[3] = {label = "MallLimitView1",index = MainDef.LeftActivityType.Sail,icon = "1_5",parama = {AppFacade.Mall,1,MallDef.RootType.Limit,MallDef.LimitType.Sail}}, --起航
		[4] = {label = "MallDaily1",index = MainDef.LeftActivityType.DailySupply,icon = "1_6",parama = {AppFacade.Mall,6}}, --每日补给
	},

	--任务跳转  
	["TaskInterface"] = 
	{
		[1] = {},
		[2] = {appFacade = "Tower", systemOpenType = ModuleOpenDef.SystemOpenType.TowerEntranceView_0, parama = {2}},
		[3] = {appFacade = "Maze", systemOpenType = ModuleOpenDef.SystemOpenType.MazeView},
		[4] = {appFacade = "Arena", systemOpenType = ModuleOpenDef.SystemOpenType.ArenaEntranceView, parama = {0}}, --直接打开竞技场
		[5] = {appFacade = "Crystal", systemOpenType = ModuleOpenDef.SystemOpenType.CrystalView, parama = {4}},
		[6] = {appFacade = "CardPortal", systemOpenType = ModuleOpenDef.SystemOpenType.CardPortView, parama = {1}},
		[7] = {appFacade = "CardPortal", systemOpenType = ModuleOpenDef.SystemOpenType.CardPortView, parama = {1}},
		[8] = {appFacade = "Hero", systemOpenType = ModuleOpenDef.SystemOpenType.HeroRootView, parama = {8}},
		[9] = {appFacade = "Temple", systemOpenType = ModuleOpenDef.SystemOpenType.TempleView, parama = {3}},
		[10] = {},
		[11] = {appFacade="Store", systemOpenType = ModuleOpenDef.SystemOpenType.StoreView, parama = {1}},
		[12] = {appFacade = "Friend", systemOpenType = ModuleOpenDef.SystemOpenType.FriendlListView, parama = {}}, --好友界面
		[13] = {},
		[14] = {appFacade="Guild", systemOpenType = ModuleOpenDef.SystemOpenType.GuildRootView, parama = {1}},
		[15] = {appFacade="Guild", systemOpenType = ModuleOpenDef.SystemOpenType.GuildRootView, parama = {1}},--打开公会界面
		[16] = {appFacade="SupplyDepot", systemOpenType = ModuleOpenDef.SystemOpenType.SupplyDepotView, parama = {}},--SupplyDepotView
		[17] = {appFacade = "RoleInfo"}, --个人主页
		[20] = {appFacade = "Hero", systemOpenType = ModuleOpenDef.SystemOpenType.FountainView, parama = {9, 2}},
	},
})