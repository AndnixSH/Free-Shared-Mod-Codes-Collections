local CheatProxy = LoginProxy or BaseClass(BaseProxy)

function CheatProxy:__init(name)
    CheatProxy.Instance = self

    self:AddProto(11000, self.On11000)
end

function CheatProxy:Send11000(content)
    local encoder = NetEncoder.New()
    encoder:Encode("s2", content)
    self:SendMessage(11000, encoder)
end

function CheatProxy:On11000(decoder)
    local result = decoder:Decode("I1")
    print("----->>GM Send result", result)
end

function CheatProxy:SendZone10000()
    self:SendMessage(10000, nil, "chat")
end

function CheatProxy:SendGlb10000()
    self:SendMessage(10000, nil, "compete")
end

return CheatProxy