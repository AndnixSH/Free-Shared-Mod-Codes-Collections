local LanguageUtil = require "First.Util.LanguageUtil"
local LanguageDef = require "Common.Mgr.Language.LanguageDef"

local LanguageManager = LanguageManager or BaseClass()
function LanguageManager:__init()
    LanguageManager.Instance = self    
    LanguageUtil.Init() --热更新后, 异步重新加载一遍
end

function LanguageManager:GetWord(key, ...)
	local str = LanguageUtil.GetWord(key)
	if {...} and next({...}) then
		return string.format(str ,...)
	else
		return str
	end
end

function LanguageManager:ChangeLanguage(id)
	local data = LanguageDef.LanguageType[id]
	
	local curId = self:GetCurLanguageIdx()
	if not data or curId == id then return end
	
	PlayerPrefs.SetInt(LanguageUtil.GetLanguageIdxStr(), data.id)
	PlayerPrefs.SetString(LanguageUtil.GetLanguageDesStr(), data.des)
	PlayerPrefs.SetString(LanguageUtil.GetLanguageGameIdStr(), data.gameid)
	
	LanguageUtil.Init()
	
	local isEditor = CS.UnityEngine.Application.isEditor
	if isEditor then
	    local SceneManager = require "Modules.Scene.SceneManager"
	    local SceneDef = require "Modules.Scene.SceneDef"
	    SceneManager.Instance:EnterScene(SceneDef.SceneType.Login, true)
	else    
		CS.UnityEngine.Application.Quit()
	end
end

function LanguageManager:GetCurLanguageIdx()
	return LanguageUtil.GetLanguageIdx()
end

function LanguageManager:GetCurLanguageDes()
	return LanguageUtil.GetLanguageDes()
end

function LanguageManager:IsCurLanguageEnglish()
	local idx = self:GetCurLanguageIdx()
	return idx == 3
end

function LanguageManager:GetCurLanguageData()
	local idx = self:GetCurLanguageIdx()
	local data = LanguageDef.LanguageType[idx]
	return data
end

function LanguageManager:TranslateChildLabel(obj)
	local labels = GameObjTools.GetComponentsInChildren(obj, "CLabel")
	for _, label in pairs(labels) do
		local text = label.text
		if string.startswith(text, "#") then
			local key = string.sub(text, 2)
			label.text = self:GetWord(key)
		end
		local state = PlayerPrefs.GetInt("mx_GM_UI", 0)
		if state == 1 then
			label.text = ""
		end
	end
end

--多语言 Atlas
function LanguageManager:TranslateChildSprite(obj)
	--local sprites = GameObjTools.GetComponentsInChildren(obj, "CSprite")
	--for _, sprite in pairs(sprites) do
	--	local atlas = sprite.Atlas
	--	if atlas and not IsNull(atlas) then
	--		local atlas_name = atlas.name
	--		local strs = string.split(atlas_name, "_")
	--		if #strs >= 2 then
	--			local module_name, language_flag = strs[1], strs[2]  --Battle_English
	--			local sprite_name = sprite.SpriteName or ""
	--			local language_des = LanguageUtil.GetLanguageDes()
	--			local atlasName = string.format("%s_%s", module_name, language_des)
	--			local sprite_path = string.format("%s.%s.%s", module_name, atlasName, sprite_name)
	--			-- print("module_name ====", module_name, language_flag, sprite_name, language_des, sprite_path)
	--			sprite.Path = sprite_path
	--		end
	--	end
	--end
end

return LanguageManager