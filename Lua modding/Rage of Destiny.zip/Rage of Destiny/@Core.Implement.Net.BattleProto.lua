local BattleDef = require "Modules.Battle.BattleDef"

local _battleProtoData = {}
local BattleProto = BaseClass()

function BattleProto:_EncodeHeroInfo(heroinfos, encoder)
	encoder:Encode("I2", #heroinfos)
	for _, heroinfo in ipairs(heroinfos) do
		encoder:Encode("I4", heroinfo.herouid)
		encoder:Encode("I4", heroinfo.fromuid)
		encoder:Encode("I2", heroinfo.fromtype)
		encoder:Encode("I4", heroinfo.roleid)
		encoder:Encode("I2", heroinfo.level)
		encoder:Encode("I2", heroinfo.rank)
		encoder:Encode("I4", heroinfo.curskin)
		local crystalLevel = heroinfo.crystalLevel and heroinfo.crystalLevel or 0
		encoder:Encode("I2", crystalLevel)
		encoder:Encode("I2", heroinfo.stance)
		encoder:Encode("I2", heroinfo.hire_hero_type or BattleDef.Hire_Hero_Type.Normal)
		encoder:Encode("s2", heroinfo.nickname or "")
		encoder:Encode("I2", heroinfo.sex or 0)
		encoder:EncodeList("I4I1", heroinfo.equips)
		encoder:EncodeList("I2I4", heroinfo.prop) 
		encoder:EncodeList("I2", heroinfo.tree_info)
	end
	return encoder
end

--encodeCrystalLevel暂时只用在多队推图
function BattleProto:_EncodeEnemyInfo(enemyinfos, encoder, encodeCrystalLevel)
	encoder:Encode("I2", #enemyinfos)
	for _, enemyinfo in ipairs(enemyinfos) do
		encoder:Encode("I4", enemyinfo.roleid or enemyinfo.role)
		encoder:Encode("I2", enemyinfo.level)
		encoder:Encode("I2", enemyinfo.rank)
		encoder:Encode("I2", enemyinfo.curskin or 0)
		encoder:Encode("I4", enemyinfo.stance or 0)
		encoder:Encode("I2", enemyinfo.exclusive or 0)
		if encodeCrystalLevel and (encodeCrystalLevel == true) then
			encoder:Encode("I2", enemyinfo.crystalLevel or 0)
		end
		encoder:EncodeList("I4I1", enemyinfo.equips or {})
		encoder:EncodeList("I2I4", enemyinfo.prop or {})
		encoder:EncodeList("I2", enemyinfo.tree_info or {})
	end	
	return encoder
end

function BattleProto:_DecodeHeroInfo(decoder)
	local heroinfos = {}
	local count = decoder:Decode("I2")
	for i=1, count do
		local heroinfo = {}
		heroinfo.herouid = decoder:Decode("I4")
		heroinfo.fromuid = decoder:Decode("I4")
		heroinfo.fromtype = decoder:Decode("I2")
		heroinfo.roleid = decoder:Decode("I4")
		heroinfo.level = decoder:Decode("I2")
		heroinfo.rank = decoder:Decode("I2")
		heroinfo.curskin = decoder:Decode("I4")
		local crystalLevel = decoder:Decode("I2")
		if crystalLevel >= heroinfo.level then
			local HeroProxy = require "Modules.Hero.HeroProxy"
			crystalLevel = HeroProxy.Instance:GetHeroMaxLevelByRoleId(crystalLevel, heroinfo.roleid)
			heroinfo.crystalLevel = crystalLevel
		else
			heroinfo.crystalLevel = nil
		end
		heroinfo.stance = decoder:Decode("I2")
		heroinfo.hire_hero_type = decoder:Decode("I2")
		heroinfo.nickname = decoder:Decode("s2")
		heroinfo.sex = decoder:Decode("I2")
		heroinfo.equips = decoder:DecodeList("I4I1", true)
		heroinfo.prop = decoder:DecodeList("I2I4", true)
		heroinfo.tree_info = decoder:DecodeList("I2")
		table.insert(heroinfos, heroinfo)
	end
	return heroinfos
end


function BattleProto:_DecodeHeroInfoDetail(decoder)
	local heroinfos = {}
	local count = decoder:Decode("I2")
	for i=1, count do
		local heroinfo = {}
		heroinfo.herouid = decoder:Decode("I4")
		heroinfo.fromuid = decoder:Decode("I4")
		heroinfo.fromtype = decoder:Decode("I2")
		heroinfo.roleid = decoder:Decode("I4")
		heroinfo.level = decoder:Decode("I2")
		heroinfo.rank = decoder:Decode("I2")
		heroinfo.curskin = decoder:Decode("I4")
		local crystalLevel = decoder:Decode("I2")
		if crystalLevel >= heroinfo.level then
			local HeroProxy = require "Modules.Hero.HeroProxy"
			crystalLevel = HeroProxy.Instance:GetHeroMaxLevelByRoleId(crystalLevel, heroinfo.roleid)
			heroinfo.crystalLevel = crystalLevel
		else
			heroinfo.crystalLevel = nil
		end
		heroinfo.stance = decoder:Decode("I2")
		heroinfo.hire_hero_type = decoder:Decode("I2")
		heroinfo.nickname = decoder:Decode("s2")
		heroinfo.sex = decoder:Decode("I2")
		heroinfo.fight = decoder:Decode("I4")
		
		heroinfo.equips = decoder:DecodeList("I4I1", true)
		heroinfo.prop = decoder:DecodeList("I2I4", true)
		heroinfo.tree_info = decoder:DecodeList("I2")
		
		local attr_infos = decoder:DecodeList("I2I4", true)
		local total_attr = {}
		for i,attr in ipairs(attr_infos) do
			total_attr[CONST.ATTR[attr[1]]] = attr[2]
		end
		heroinfo.total_attr = total_attr
		heroinfo.skill_list = decoder:DecodeList("I4")
		heroinfo.equip_buff_list = decoder:DecodeList("I4")
		heroinfo.tree_buff_list = decoder:DecodeList("I4")
		
		table.insert(heroinfos, heroinfo)
	end
	return heroinfos
end

function BattleProto:_DecodeEnemyInfo(decoder)
	local enemyinfos = {}
	local count = decoder:Decode("I2")
	for i=1, count do
		local enemyinfo = {}
		enemyinfo.roleid = decoder:Decode("I4")
		enemyinfo.level = decoder:Decode("I2")
		enemyinfo.rank = decoder:Decode("I2")
		enemyinfo.curskin = decoder:Decode("I2")
		enemyinfo.stance = decoder:Decode("I4")
		enemyinfo.exclusive = decoder:Decode("I2")
		local crystalLevel = decoder:Decode("I2")
		if crystalLevel >= enemyinfo.level and enemyinfo.roleid > 0 then
			local HeroProxy = require "Modules.Hero.HeroProxy"
			crystalLevel = HeroProxy.Instance:GetHeroMaxLevelByRoleId(crystalLevel, enemyinfo.roleid)
			enemyinfo.crystalLevel = crystalLevel
		else
			enemyinfo.crystalLevel = nil
		end
		enemyinfo.equips = decoder:DecodeList("I4I1", true)
		enemyinfo.prop = decoder:DecodeList("I2I4", true)
		enemyinfo.tree_info = decoder:DecodeList("I2")
		table.insert(enemyinfos, enemyinfo)
	end
	return enemyinfos
end

function BattleProto:_DecodeEnemyInfoDetail(decoder)
	local enemyinfos = {}
	local count = decoder:Decode("I2")
	for i=1, count do
		local enemyinfo = {}
		enemyinfo.roleid = decoder:Decode("I4")
		enemyinfo.level = decoder:Decode("I2")
		enemyinfo.rank = decoder:Decode("I2")
		enemyinfo.curskin = decoder:Decode("I2")
		enemyinfo.stance = decoder:Decode("I4")
		enemyinfo.exclusive = decoder:Decode("I2")
		local crystalLevel = decoder:Decode("I2")
		if crystalLevel >= enemyinfo.level and enemyinfo.roleid > 0 then
			local HeroProxy = require "Modules.Hero.HeroProxy"
			crystalLevel = HeroProxy.Instance:GetHeroMaxLevelByRoleId(crystalLevel, enemyinfo.roleid)
			enemyinfo.crystalLevel = crystalLevel
		else
			enemyinfo.crystalLevel = nil
		end
		enemyinfo.fight = decoder:Decode("I4")
		enemyinfo.equips = decoder:DecodeList("I4I1", true)
		enemyinfo.prop = decoder:DecodeList("I2I4", true)
		enemyinfo.tree_info = decoder:DecodeList("I2")
		
		local attr_infos = decoder:DecodeList("I2I4", true)
		local total_attr = {}
		for i,attr in ipairs(attr_infos) do
			total_attr[CONST.ATTR[attr[1]]] = attr[2]
		end
		enemyinfo.total_attr = total_attr
		enemyinfo.skill_list = decoder:DecodeList("I4")
		enemyinfo.equip_buff_list = decoder:DecodeList("I4")
		enemyinfo.tree_buff_list = decoder:DecodeList("I4")
		
		table.insert(enemyinfos, enemyinfo)
	end
	return enemyinfos
end

-- 更新boss信息
function BattleProto:_UpdateEnemyInfo(enemyinfos, enemyid)
	if not enemyid then return end
	local config = ConfigManager.GetConfig("data_enemy")
	if not config[enemyid] then return end
	local enemycfg = config[enemyid]
	for _,enemyinfo in ipairs(enemyinfos) do
		local enemydata = enemycfg["enemy"..enemyinfo.stance]
		if enemydata then
			if enemycfg.boss.location == enemyinfo.stance then
				enemyinfo.boss = enemycfg.boss
			end
		end
	end
end

--共鸣水晶等级
function BattleProto:CheckCrystalLevel(heroinfo)
	local _level = heroinfo.level
	if heroinfo.crystalLevel then
		_level = heroinfo.crystalLevel > 1 and heroinfo.crystalLevel or heroinfo.level
	elseif heroinfo.crystallevel then
		_level = heroinfo.crystallevel > 1 and heroinfo.crystallevel or heroinfo.level
	end
	return _level
end

-- 生成战斗内角色列表
function BattleProto:_GeneratePlayerList(heroinfos, enemyinfos, activityid)
	local BattleProxy = require "Modules.Battle.BattleProxy"
	local GuildProxy = require "Modules.Guild.GuildProxy"
	local HeroProxy = require "Modules.Hero.HeroProxy"

	local playlist = {}
	
	local hero_role_id_list = {}
	for _, heroinfo in ipairs(heroinfos) do
		table.insert(hero_role_id_list, heroinfo.roleid)
	end
	local relation_add_attr = HeroProxy.Instance:GetFormationRelationAttr(hero_role_id_list)
	
	for _, heroinfo in ipairs(heroinfos) do
		local _level
		if activityid == ACTIVITYID.GUILD_CHAOS then
			_level = heroinfo.level
		else
			_level = self:CheckCrystalLevel(heroinfo)
		end

		-- print("BattleProto:_GeneratePlayerList heroinfo", _level)
		-- print(table.dump(heroinfo))

		local tab = BattleProxy.Instance:GetGamePlayerTable(
			heroinfo.herouid, heroinfo.roleid, CAMP.RED, _level, heroinfo.rank, 
			heroinfo.stance, nil, heroinfo.prop, heroinfo.equips, heroinfo.hire_hero_type, 
			heroinfo.nickname, heroinfo.fromuid, heroinfo.tree_info, activityid, 
			heroinfo.total_attr, heroinfo.fight, heroinfo.skill_list, heroinfo.equip_buff_list, 
			heroinfo.tree_buff_list, relation_add_attr)
		
		playlist[heroinfo.stance] = tab
		-- print(table.dump(tab))
	end

	local enemy_hero_role_id_list = {}
	for _, enemyinfo in ipairs(enemyinfos) do
		table.insert(enemy_hero_role_id_list, enemyinfo.roleid)
	end
	local enemy_relation_add_attr = HeroProxy.Instance:GetFormationRelationAttr(enemy_hero_role_id_list)
	
	for _, enemyinfo in ipairs(enemyinfos) do
		local position = nil
		if enemyinfo.boss and enemyinfo.boss.coordinate then
			position = enemyinfo.boss.coordinate
		end
		local _level 
		if activityid == ACTIVITYID.GUILD_CHAOS then
			_level = enemyinfo.level
		else
			_level = self:CheckCrystalLevel(enemyinfo)
		end

		-- print("BattleProto:_GeneratePlayerList enemyinfos", _level)
		-- print(table.dump(enemyinfo))

		local tab = BattleProxy.Instance:GetGamePlayerTable(
			0, enemyinfo.roleid, CAMP.BLUE, _level, enemyinfo.rank, 
			enemyinfo.stance, position, enemyinfo.prop, enemyinfo.equips, nil,
			nil, nil, enemyinfo.tree_info, activityid, 
			enemyinfo.total_attr, enemyinfo.fight, enemyinfo.skill_list, enemyinfo.equip_buff_list, 
			enemyinfo.tree_buff_list, enemy_relation_add_attr)
		
		playlist[enemyinfo.stance + 5] = tab
		-- print(table.dump(tab))
	end
	return playlist
end

function BattleProto:GenerateBattleInfo(activityid, heroinfos, enemyinfos, battlearg, customarg)
	local BattleProxy = require "Modules.Battle.BattleProxy"
	
	local _battleargs = {}
	for k,v in pairs(battlearg) do
		_battleargs[k] = v
	end

	if (not BattleProxy.Instance:IsReportBattle()) then
		for k,v in pairs(enemyinfos) do
			v.prop = {}
		end
	end
	
	local playerlist = self:_GeneratePlayerList(heroinfos, enemyinfos, activityid)
	_battleargs.playerlist = playerlist
	
	BattleProxy.Instance:EntryBattleScene(activityid, _battleargs, customarg)
end

--替代方法GenerateBattleInfo  迷宫crystallevel字段默认是1...
function BattleProto:GenerateBattleInfo_2(activityid, seed, heroinfos, enemyinfos, enemyid, ...)
	self:_UpdateEnemyInfo(enemyinfos, enemyid)
	local playlist = self:_GeneratePlayerList(heroinfos, enemyinfos, activityid)
	local BattleProxy = require "Modules.Battle.BattleProxy"
	BattleProxy.Instance:EntryBattleScene_2(activityid, playlist, seed, ...)
end

--[[ 
	result,
	camps = {
		{roleid, level, rank, stance, record = {damage, bharm, heal, dead}}, -- camp1
		{roleid, level, rank, stance, record = {damage, bharm, heal, dead}}, -- camp2
	}
]]
function BattleProto:DecodeSettleData(decoder)

	local settledata = {}
	local result, settlestr = decoder:Decode("I1s2")
	settledata.result = result
	settledata.camps = {}

	local decoder = NetDecoder.New(settlestr, 1)
	local campcount = decoder:Decode("I2")
	for i=1,campcount do
		local spritedatas = {}
		local spritecont = decoder:Decode("I2")
		for j=1,spritecont do
			local roleid, level, rank, stance = decoder:Decode("I4I2I2I1")
			local damage, bharm, heal = decoder:Decode("I4I4I4")
			local dead = decoder:Decode("I1")
			local record = { damage = damage, bharm = bharm, heal = heal, dead = dead == 1}
			local data = { roleid = roleid, level = level, rank = rank, stance = stance, record = record }
			table.insert(spritedatas, data)
		end
		table.insert(settledata.camps, spritedatas)
	end

	return settledata
end

-------------------------------------------------------------------------------------

function BattleProto:AddPreBattle(activityid, func)
	_battleProtoData.prebattle = _battleProtoData.prebattle or {}
	local list = _battleProtoData.prebattle
	list[activityid] = {owner = self, func = func}
end

function BattleProto:AddSetBattle(activityid, func)
	_battleProtoData.setbattle = _battleProtoData.setbattle or {}
	local list = _battleProtoData.setbattle
	list[activityid] = {owner = self, func = func}	
end

function BattleProto:AddStartBattle(activityid, func)
	_battleProtoData.startbattle = _battleProtoData.startbattle or {}
	local list = _battleProtoData.startbattle
	list[activityid] = {owner = self, func = func}		
end

function BattleProto:AddAutoPreBattle(activityid, func)
	_battleProtoData.autoPrebattle = _battleProtoData.autoPrebattle or {}
	local list = _battleProtoData.autoPrebattle
	list[activityid] = {owner = self, func = func}
end

function BattleProto:CallPreBattle(decoder)
	local activityid = decoder:Decode("I2")
	local activityproto = _battleProtoData.prebattle or {}
	if activityproto[activityid] then
		activityproto[activityid].func(activityproto[activityid].owner, decoder, activityid)
	end
end

function BattleProto:CallStartBattle(decoder, extra)
	local activityid, seed = decoder:Decode("I2I4")
	local activityproto = _battleProtoData.startbattle or {}
	if activityproto[activityid] then
		activityproto[activityid].func(activityproto[activityid].owner, decoder, seed, activityid, extra)
	end
end

function BattleProto:CallAutoPreBattle(decoder)
	local activityid = decoder:Decode("I2")
	--print("CallAutoPreBattle===>>", activityid)
	local activityproto = _battleProtoData.autoPrebattle or {}
	if activityproto[activityid] then
		activityproto[activityid].func(activityproto[activityid].owner, decoder, activityid)
	end
end

function BattleProto:OnPreBattle(decoder, activityid)
	local heroinfos = self:_DecodeHeroInfo(decoder)
	local enemyinfos = self:_DecodeEnemyInfo(decoder)
	local bufferstr = decoder:Decode("s2")

	local buffer_args = nil
	if self.OnPreBattleBuffer then
		buffer_args = self:OnPreBattleBuffer(bufferstr)
	end

	if buffer_args then
		if buffer_args.enemyid then
			self:_UpdateEnemyInfo(enemyinfos, buffer_args.enemyid)
			self._cache_enemyid = buffer_args.enemyid
		end
		if buffer_args.view then
			UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 10, activityid, heroinfos, enemyinfos, buffer_args.view.name, buffer_args.view.args)
		end
	end

end


function BattleProto:OnAutoPreBattle(decoder, activityid)
	local MercenaryProxy = require "Modules.Mercenary.MercenaryProxy"
	local BattleDef = require "Modules.Battle.BattleDef"
	local heroinfos = self:_DecodeHeroInfo(decoder)
	local enemyinfos = self:_DecodeEnemyInfo(decoder)
	local bufferstr = decoder:Decode("s2")

	local buffer_args = nil
	if self.OnPreBattleBuffer then
		buffer_args = self:OnPreBattleBuffer(bufferstr)
	end

	if buffer_args then
		if buffer_args.enemyid then
			self:_UpdateEnemyInfo(enemyinfos, buffer_args.enemyid)
			self._cache_enemyid = buffer_args.enemyid
		end
	end
	-- print("OnAutoPreBattle============", activityid, table.dump(heroinfos), table.dump(enemyinfos))
	
	local subtype = 0
	local defaultTeam = {0,0,0,0,0}
	local isMultiEnemy = false
	if activityid == ACTIVITYID.MAINLINE then
		--主线
		local BattleProxy = require "Modules.Battle.BattleProxy"
		local CampaignProxy = require "Modules.Campaign.CampaignProxy"
		local enemy_id, mainlineid = string.unpack(">I4I4", bufferstr)
		defaultTeam = BattleProxy.Instance:GetDefaultTeam(activityid, {enemy_id, mainlineid})
		isMultiEnemy = CampaignProxy.Instance:HasExtraEnemy(mainlineid)
	elseif activityid == ACTIVITYID.TOWER then
		--爬塔
		local TowerProxy = require "Modules.Tower.TowerProxy"
		local BattleProxy = require "Modules.Battle.BattleProxy"
		local enemy_id, tower_id = string.unpack(">I4I4", bufferstr)
		local tower_cfg = TowerProxy.Instance:GetTowerCfgById(tower_id)
		defaultTeam = BattleProxy.Instance:GetDefaultTeam(activityid, {enemy_id, tower_id})
		subtype = tower_cfg.type

	end
	
	if isMultiEnemy then
		--自动挂机多队推图移除重复英雄
		local BattleProxy = require "Modules.Battle.BattleProxy"
		local CampaignProxy = require "Modules.Campaign.CampaignProxy"
		local now_enemy_id, mainlineid = string.unpack(">I4I4", bufferstr)
		local enemys = CampaignProxy.Instance:GetAllEnemy(mainlineid)
		for i,enemyid in ipairs(enemys) do
			if enemyid ~= now_enemy_id then
				local team = BattleProxy.Instance:GetDefaultTeam(activityid, {enemyid, mainlineid})
				for k,herouid in ipairs(team) do
					if herouid > 0 then
						for j,now_hero_uid in ipairs(defaultTeam) do
							if herouid == now_hero_uid then
								team[k] = 0
								break
							end
						end
					end
				end
				BattleProxy.Instance:SetDefaultTeam(activityid, team, {enemyid, mainlineid})
			end
		end
	end

	local bbattle = MercenaryProxy.Instance:CheckHireHeroBattle(activityid, subtype)
	local _hero_infos = {}
	for i,herouid in ipairs(defaultTeam) do
		if herouid ~= 0 then
			for k,_info in ipairs(heroinfos) do
				if _info.herouid == herouid then
					_info.stance = i
					if _info.hire_hero_type == BattleDef.Hire_Hero_Type.Hire_Hero then
						if bbattle then
							table.insert(_hero_infos, _info)
						end
					else
						table.insert(_hero_infos, _info)
					end
				end
			end
		end
	end
		
	if activityid == ACTIVITYID.MAINLINE then
		local CampaignProxy = require "Modules.Campaign.CampaignProxy"
		local BattleProxy = require "Modules.Battle.BattleProxy"

		CampaignProxy.Instance:Send51007(_hero_infos, enemyinfos, bufferstr)
	elseif activityid == ACTIVITYID.TOWER then
		local TowerProxy = require "Modules.Tower.TowerProxy"
		TowerProxy.Instance:Send52002(_hero_infos, enemyinfos, bufferstr)
	end
end

function BattleProto:OnStartBattle(decoder, seed, activityid, extra)
	-- print("BattleProto:OnStartBattle", activityid)

	local BattleProxy = require "Modules.Battle.BattleProxy"
	local heroinfos = self:_DecodeHeroInfoDetail(decoder)
	-- 战报特殊处理
	-- 判断extra.report则为战报播放，把英雄的herouid设置成0，
	-- 以便调用BattleProxy:GetGamePlayerTable生成战斗数据的时候去读配置表而不是读英雄背包
	if extra and extra.report then
		BattleProxy.Instance:SetIsReport(true)
		for _, heroinfo in pairs(heroinfos) do
			heroinfo.herouid = 0
		end
	else
		BattleProxy.Instance:SetIsReport(false)
	end
	-- 战报特殊处理
	local enemyinfos = self:_DecodeEnemyInfoDetail(decoder)

	local bufferstr = decoder:Decode("s2")
	if self._cache_enemyid then
		self:_UpdateEnemyInfo(enemyinfos, self._cache_enemyid)
	end
	
	local playerlist = self:_GeneratePlayerList(heroinfos, enemyinfos, activityid)
	
	local battlearg = { playerlist = playerlist, seed = seed, extra = extra  }
	local customarg = nil
	if self.OnStartBattleBuffer then
		customarg = self:OnStartBattleBuffer(bufferstr, heroinfos, enemyinfos)
	end
	-- print(table.dump(playerlist))
	
	BattleProxy.Instance:SaveLocalGame(activityid, battlearg, customarg)
	BattleProxy.Instance:EntryBattleScene(activityid, battlearg, customarg)
end

return BattleProto
