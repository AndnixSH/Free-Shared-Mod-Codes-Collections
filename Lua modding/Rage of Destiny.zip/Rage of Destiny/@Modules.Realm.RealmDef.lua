local RealmDef = {}

RealmDef.NotifyDef = {
   UpdateActivityInfo = "UpdateActivityInfo",
   UpdateActivityTitle = "UpdateActivityTitle",
   Activity_Complete = "Activity_Complete",
}

RealmDef.CommonDef={
    Copy_Unopen = "RealmView_1001",
    CountTime = "RealmView_1002",
    CountTime2 = "RealmView_1003",
}

RealmDef.BigTitleList={
  [1] = {"MainCommon_1011",13},
}

RealmDef.ToggleList={
  {"Realm_Name_1003_1"},
  {"位面幻境"},
  {"位面幻境"},
  {"位面幻境"},
  {"位面幻境"},
  {"位面幻境"},
}
return RealmDef