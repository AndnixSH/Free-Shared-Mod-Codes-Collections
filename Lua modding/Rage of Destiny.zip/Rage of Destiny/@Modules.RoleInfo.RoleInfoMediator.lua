local SdkEventProxy = require "Modules.Sdk.SdkEventProxy"

RoleInfoMediator = RoleInfoMediator or BaseClass(StdMediator)

function RoleInfoMediator:__init()
	RoleInfoMediator.Instance = self
end

function RoleInfoMediator:OnEnterScenceFirst()
	SdkEventProxy.Instance:Send10033()
end

function RoleInfoMediator:OnEnterScence()	
end

function RoleInfoMediator:OnEnterLoadingEnd()
end	

return RoleInfoMediator