local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
local RedPointDef = require "Modules.RedPoint.RedPointDef"
local AudioManager = require "Common.Mgr.Audio.AudioManager"
local GuildProxy = require "Modules.Guild.GuildProxy"
local HeroProxy = require "Modules.Hero.HeroProxy"
local DateFormatUtil = require "Common.Util.DateFormatUtil"

local GuildEntranceView = GuildEntranceView or LuaWidgetClass()

function GuildEntranceView:__init()
end

function GuildEntranceView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Guild.GuildEntranceView", self.LoadEnd)
end

function GuildEntranceView:LoadEnd(obj)
	self:SetGo(obj)
	self:InitUI()
	self:SetStep(0)
end

function GuildEntranceView:InitUI()
	self.guildHallBtn = self:GetChildComponent(self.go, "GuildLobby", "CButton")
	self.guildBossBtn = self:GetChildComponent(self.go, "GuildBoss", "CButton")
	self.guildChaosBtn = self:GetChildComponent(self.go, "GuildChaos", "CButton")
	self.guildStoreBtn = self:GetChildComponent(self.go, "GuildStore", "CButton")
	self.guildNotOpenBtn = self:GetChildComponent(self.go, "GuildPlzWait", "CButton")

	self.guildChaosInfoObj = self:GetChild(self.go, "GuildChaos/info")
	self.guildChaosLockObj = self:GetChild(self.go, "GuildChaos/lock")
	self.guildChaosNameLb = self:GetChildComponent(self.go, "GuildChaos/info/CLabel_name", "CLabel")
	self.guildChaosTimeLb = self:GetChildComponent(self.go, "GuildChaos/info/CLabel_time", "CLabel")
	self.guildChaosHeadTex = self:GetChildComponent(self.go, "GuildChaos/info/bosshead", "CTexture")

	self.guildHallBtn:AddClick(function()
		LuaLayout.Instance:OpenWidget(UIWidgetNameDef.GuildHallView)
	end)
	self.guildBossBtn:AddClick(function()
		LuaLayout.Instance:OpenWidget(UIWidgetNameDef.GuildBossView)
	end)
	self.guildChaosBtn:AddClick(function()
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
    	local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"

		local isOpen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.GuildChaosView, true)
		if isOpen then
			LuaLayout.Instance:OpenWidget(UIWidgetNameDef.GuildChaosView)
		end
	end)
	self.guildStoreBtn:AddClick(function()
		local StoreDef = require "Modules.Store.StoreDef"
		UIOperateManager.Instance:OpenWidget(AppFacade.Store, StoreDef.StoreType.guild)
		
		GuildProxy.Instance:StopGuildBgm()
        local StoreProxy = require "Modules.Store.StoreProxy"
        StoreProxy.Instance:SetCallBack(function (  )
            GuildProxy.Instance:PlayGuildBgm()
            StoreProxy.Instance:SetCallBack(false)
        end)
	end)
	self.guildNotOpenBtn:AddClick(function()
		GameLogicTools.ShowMsgTips(self:GetWord("Common_1033"))
	end)

	--红点
   	RedPointProxy.Instance:BindNode(RedPointDef.Id.GuildBoss, self:GetChild(self.go, "GuildBoss/red"))
   	RedPointProxy.Instance:BindNode(RedPointDef.Id.GuildChaos, self:GetChild(self.go, "GuildChaos/red"))
end

function GuildEntranceView:OnOpen()
	GuildProxy.Instance:PlayGuildBgm()
	self:AutoRegister()

	GuildProxy.Instance:Send70200()
end

function GuildEntranceView:OnClose()
	GuildProxy.Instance:StopGuildBgm()
	self:PlayTerritorySound()
	self:AutoUnRegister()

	self:StopTimer()
end

function GuildEntranceView:OnDestroy()
	GuildProxy.Instance:StopGuildBgm()
	self:AutoUnRegister()
end

--关闭领地音效
function GuildEntranceView:PlayTerritorySound()
	local TerritoryProxy = require "Modules.Territory.TerritoryProxy"
	TerritoryProxy.Instance:GoBack()
end

function GuildEntranceView:UpdateView()
end

function GuildEntranceView:StopTimer()
	if self.chaosTimer then
		self:RemoveTimer(self.chaosTimer)
		self.chaosTimer = nil
	end
end

function GuildEntranceView.EvtNotify.Guild.data:UpdateChaosInfo(data)
	local ModuleManager = require "Common.Mgr.UI.ModuleManager"
    local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"

    local isOpen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.GuildChaosView, false)
   	if isOpen then
   		local bossId = GuildProxy.Instance:GetChaosNowBossId()
   		local roleId = GuildProxy.Instance:GetChaosBossRoleId(bossId)
   		local roleConfig = HeroProxy.Instance:GetRoleCfgByConfigId(roleId)

   		--名字
   		self.guildChaosNameLb.text = self:GetWord(roleConfig.name)

   		--倒计时
		self:StopTimer()
		self.leftTime = GuildProxy.Instance:GetChaosLastSettleTime() + GuildProxy.Instance:GetChaosRefreshTime() - RoleInfoModel.servertime
		-- print(table.dump(DateFormatUtil.Date("*t", GuildProxy.Instance:GetChaosLastSettleTime())))
		-- print(GuildProxy.Instance:GetChaosRefreshTime())
		-- print(table.dump(DateFormatUtil.Date("*t", RoleInfoModel.servertime)))
		local timeFunc = function ()
			self.leftTime = self.leftTime - 1
			if self.leftTime < 0 then
				self.leftTime = GuildProxy.Instance:GetChaosRefreshTime()
			end
			self.guildChaosTimeLb.text = DateFormatUtil.formatHMS2(self.leftTime)
		end
		self.chaosTimer = self:AddTimer(timeFunc)
		timeFunc()

   		--头像
   		AssetManager.LoadUITexture(AssetManager.UITexture.BossIcon, roleId, self.guildChaosHeadTex)

   		self.guildChaosInfoObj:SetActive(true)
   		self.guildChaosLockObj:SetActive(false)
   	else
   		self.guildChaosInfoObj:SetActive(false)
   		self.guildChaosLockObj:SetActive(true)
   	end
end

return GuildEntranceView