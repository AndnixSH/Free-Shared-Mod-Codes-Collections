
local gameinfo = { 
    seed = 0,        -- 种子
    sceneid = 9999,   -- 场景id
    config_key = 99991,-- 参见data_battle_key
}



local default_camp = {
    { roleid = 1101, level = 220, rank = 7 },
    { roleid = 2101, level = 220, rank = 7 },
    { roleid = 2201, level = 220, rank = 7 },
    { roleid = 1302, level = 220, rank = 7 },
    { roleid = 1303, level = 22, rank = 7 },
}

local camp_list = {

    [1] = default_camp,

    [2] = { -- 沙虫boss
            { roleid = 7181, level = 240, rank = 7 },
    },
    [3] = { -- 红龙boss
            { roleid = 7382, level = 40, rank = 7 },
    },
    [4] = { -- 单人
        { roleid = 2101, level = 240, rank = 7 },
        { roleid = 2101, level = 200, rank = 7 },
        { roleid = 2202, level = 200, rank = 7 },
        { roleid = 2101, level = 200, rank = 7 },
        { roleid = 4301, level = 200, rank = 7 },
    },
   [5] = { -- 单人
        { roleid = 1202, level = 240, rank = 7 },
        { roleid = 4302, level = 240, rank = 7 },
    },
    
}




return { gameinfo = gameinfo, camp_list = camp_list, camp1 = 4, camp2 = 1 }