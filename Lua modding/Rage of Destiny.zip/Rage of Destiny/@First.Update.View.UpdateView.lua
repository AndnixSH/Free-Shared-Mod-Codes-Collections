local cs_coroutine = require "First.Util.cs_coroutine"
local UIPoolManager = CS.LJY.NX.UIPoolManager
local cAssetLoaderAdapter = CS.LJY.NX.AssetLoaderAdapter
local GameObject = CS.UnityEngine.GameObject
local Mathf = CS.UnityEngine.Mathf
local Application = CS.UnityEngine.Application
local LanguageUtil = require "First.Util.LanguageUtil"
local FrameUpdateMgr = require "First.Util.FrameUpdateMgr"
local _dotStr = { "", ".", "..", "...", "...." }
local _dotNum = 0
local _dotTick = 0

local STANDARD_WIDTH = 1334
local STANDARD_HEIGHT = 750
local STANDARD_RATE = STANDARD_WIDTH / STANDARD_HEIGHT --标准分辨率比

local UpdateView = {}
UpdateView.UpdateState = {
    None = 0,
    InitConfig = 1,
    RequireConfig = 2,
    CheckVersion = 3,
    UpdateBundle = 4,
    EntryGame = 5,
}
function UpdateView:New()
    self.uiroot = GameObject.Find("UIRoot")
    local rect = self.uiroot:GetComponent(typeof(CS.UnityEngine.RectTransform))
    local scaler = self.uiroot:GetComponent(typeof(CS.UnityEngine.UI.CanvasScaler))
    if rect and scaler then
        local Screen = CS.UnityEngine.Screen
        if STANDARD_RATE > Screen.width / Screen.height then
            scaler.matchWidthOrHeight = 0
        else
            scaler.matchWidthOrHeight = 1
        end
    end

    self:OnLoad()
end

function UpdateView:OnLoad()
    UIPoolManager.Instance:LoadUIPrefab("Update.UpdateView", function(obj)
        self:LoadEnd(obj)
    end)
end

function UpdateView:LoadEnd(obj)
    --init go
    obj.transform:SetParent(self.uiroot.transform, false)

    self.logeTexObj = obj.transform:Find("LOGO")
    self.logeTex = self.logeTexObj:GetComponent(typeof(CS.CTexture))

    self.percentageObj = obj.transform:Find("label/percentageLbl").gameObject
    self.percentageLbl = self.percentageObj:GetComponent(typeof(CS.CLabel))

    self.showObj = obj.transform:Find("label/tipsLbl").gameObject
    self.showLbl = self.showObj:GetComponent(typeof(CS.CLabel))

    self.progressObj = obj.transform:Find("label/progressLbl").gameObject
    self.progressObj:SetActive(false)
    self.progressLbl = self.progressObj:GetComponent(typeof(CS.CLabel))

    self.versionObj = obj.transform:Find("label/versionLbl").gameObject
    self.versionLbl = self.versionObj:GetComponent(typeof(CS.CLabel))

    local iconObj = obj.transform:Find("CSlider_New/icon").gameObject
    self.iconSpr = iconObj:GetComponent(typeof(CS.CSprite))

    self.ticketObj = obj.transform:Find("CButton_New").gameObject
    self.ticketObj:SetActive(false)
    self.ticketActive = false
    local ticketBtn = self.ticketObj:GetComponent(typeof(CS.CButton))
    ticketBtn:AddClick(function()
        if SystemConfig.isIGGPlatform() then
            --打开客服
            local cIGGSdkInterface = CS.LJY.NX.IGGSdkInterface
            cIGGSdkInterface.OpenTSH()
        end
    end)

    local ticketLabObj = obj.transform:Find("CButton_New/label").gameObject
    local ticketLab = ticketLabObj:GetComponent(typeof(CS.CLabel))
    ticketLab.text = LanguageUtil.GetWord("LineSupport_1001")

    self.progressRoot = obj.transform:Find("CSlider_New").gameObject
    self.progressLabRoot = obj.transform:Find("label").gameObject
    self.loginVersionRoot = obj.transform:Find("versionLbl").gameObject
    self.loginVersionLbl = self.loginVersionRoot:GetComponent(typeof(CS.CLabel))

    self.go = obj
    self.percentageLbl.text = '0%'
    self.iconSpr.fillAmount = 0
    self:OnOpen()
end

function UpdateView:ShowLogoTex()
    local str = LanguageUtil.GetLanguageDes()
    local tex_path = string.format("Background.Tex_%s_logo", str)
    if str == "Jianti" then
        tex_path = "Background.Tex_English_logo"
    end
    self.logeTex.Path = tex_path
end

function UpdateView:OnOpen()
    self.go:SetActive(true)
    self:ShowLogoTex()
    self:SetProrgressObjActive(true)
    self:SetVersionContent(false, "")
    self.target = 0 
    self.value = 0
    self:SetUpdateState(self.state, self.target, self.value)

    FrameUpdateMgr.Add(self)
end

function UpdateView:Close()
    self.go:SetActive(false)
    self.target = 0 
    self.value = 0
    FrameUpdateMgr.Remove(self)
end

function UpdateView:Destroy()
    self.logeTex:Clear()
    FrameUpdateMgr.Remove(self)
    GameObject.Destroy(self.go)

    cAssetLoaderAdapter.UnLoadUIAssetBundle("Update.UpdateView")
    self.go = nil
end

function UpdateView:SetUpdateState(state, target, value)
    self.state = state
    self.target = target or 0
    self.value = value or 0
    self.showStr = ""
    self.speed = (self.target - self.value) / 60

    if not self.go then
        return
    end

    if self.state == UpdateView.UpdateState.None then
        self.percentageLbl.text = ""
        self.showLbl.text = ""
        self.progressLbl.text = ""
        self.versionLbl.text = tostring(Application.version) 

    elseif self.state == UpdateView.UpdateState.InitConfig then
        self.showStr = LanguageUtil.GetWord("UpdateView_1001")
        self.versionLbl.text = tostring(Application.version)
    elseif self.state == UpdateView.UpdateState.RequireConfig then
        self.showStr = LanguageUtil.GetWord("UpdateView_1002")
        --print("--------------SetUpdateState-----------------",Application.version)
        self.versionLbl.text = tostring(Application.version).."_"..tostring(SystemConfig.ResVersion)
        self:ShowTSHButtonActive(true)
    elseif self.state == UpdateView.UpdateState.CheckVersion then
        self.showStr = LanguageUtil.GetWord("UpdateView_1003")

    elseif self.state == UpdateView.UpdateState.UpdateBundle then
        self.showStr = LanguageUtil.GetWord("UpdateView_1004")
        self.progressObj:SetActive(true)
    elseif self.state == UpdateView.UpdateState.EntryGame then
        self.showStr = LanguageUtil.GetWord("UpdateView_1005")
    end
    self.showLbl.text = self.showStr
end

--客服按钮
function UpdateView:ShowTSHButtonActive(bActive)
    if SystemConfig.isIGGPlatform() then
        local SdkManager = require "First.Sdk.SdkManager"
        if SdkManager.IsSdkInitSus() then
            if self.ticketActive ~= bActive then
                --print("self.ticketActive===", self.ticketActive, bActive)
                self.ticketObj:SetActive(bActive)
                self.ticketActive = bActive
            end
        end
    end
end

function UpdateView:SetProrgressObjActive(bActive)
    if self.progressRoot then
        self.progressRoot:SetActive(bActive)
    end

    if self.progressLabRoot then
        self.progressLabRoot:SetActive(bActive)
    end
end

function UpdateView:SetVersionContent(bActive, str)
    if self.loginVersionRoot then
        self.loginVersionRoot:SetActive(bActive)
    end

    if self.loginVersionLbl then
        self.loginVersionLbl.text = str
    end
end

function UpdateView:FrameUpdate(time, deltaTime)
    if self.go then
        if self.state == UpdateView.UpdateState.UpdateBundle then
            self:CheckUpdateState()
        elseif self.state ~= UpdateView.UpdateState.None then
            self:CheckOtherState(time, deltaTime)
        end

        if self.state ~= UpdateView.UpdateState.None and 
            self.state ~= UpdateView.UpdateState.InitConfig then
                self:ShowTSHButtonActive(true)
        end
    end
end

function UpdateView:CheckUpdateState()
    local UpdateDownload = require "First.Update.UpdateDownload"
    local downFileNum, downFileCount, curProgress, countProgress, downProgress = UpdateDownload.GetDownloadProgress()
    self.progressLbl.text = string.format("%s  %.2fM/%.2fM", LanguageUtil.GetWord("UpdateView_1006"),
            (curProgress + downProgress) / 1024 / 1024, countProgress / 1024 / 1024)

    local value = Mathf.Clamp(math.floor((curProgress + downProgress) / countProgress * 100 + 0.5), 0, 100)
    self.percentageLbl.text = string.format("%d%%", math.floor(value))
    self.iconSpr.fillAmount = value / 100
end

function UpdateView:CheckOtherState(time, deltaTime)
    if self.showStr ~= "" then
        --_dotTick = deltaTime + _dotTick
        --if _dotTick > 0.5 then
        --    _dotTick = 0
        --    _dotNum = math.fmod(_dotNum + 1, #_dotStr)
        --end
        --
        --self.showLbl.text = string.format("%s%s", self.showStr, _dotStr[_dotNum + 1])
    end
    
    if self.target > self.value and self.value < 1 then
        local showValue = Mathf.Clamp((self.value) * 100, 0, 100)
        self.percentageLbl.text = math.floor(showValue) .. '%'
        self.iconSpr.fillAmount = self.value
        self.value = self.value + self.speed
    elseif self.value >= 1 then
        self.percentageLbl.text = '100%'
        self.iconSpr.fillAmount = 1
    elseif self.target <= self.value then
        self.percentageLbl.text = math.floor(self.target * 100) .. '%'
        self.iconSpr.fillAmount = self.target
    end
    self.versionLbl.text = tostring(Application.version).."_"..tostring(SystemConfig.ResVersion)
end

return UpdateView