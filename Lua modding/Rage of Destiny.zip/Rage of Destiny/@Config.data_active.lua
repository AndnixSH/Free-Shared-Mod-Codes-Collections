ConfigManager.InitConfig("data_active", {
--  动画时间标准	floatingdown 1 /原时间
        --  floatingup	原时间 / 0.2
        --  hit	原时间 / 0.4
        --  liedown	原时间 / 0.8
        --  getup	1 / 原时间
        --  liehit	原时间 / 0.7

        --  以上算式得出的倍率为speed参数，强行将动画变速为固定时间，详细见美术资源清单表
-- 


-- --  圣光
-- 1111011 萨姬亚(陷阵之锤)-正式
    ["1101"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "scenes_1101_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.4, name = "Death", speed = 1},
            {type = "shader", time = 2.4, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3.167, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.233, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1, name = "FloatingDown", speed = 0.8},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 2.833, name = "Attack", speed = 1},
            {type = "effect", time = 0.4, duration = 1.5, name = "skill_110101_route1", bone = "", speed = 1},
            {type = "audio", time = 0.1, duration = 1.5, name = "JN-1101-110101-1", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "effect", time = 0.8, duration = 1.5, name = "skill_110101_route2", bone = "", speed = 1},
            {type = "audio", time = 0.7, duration = 1.5, name = "JN-1101-110101-4", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "effect", time = 1.3, duration = 2, name = "skill_110101_route3", bone = "", speed = 1},
            {type = "audio", time = 1.4, duration = 2, name = "JN-1101-110101-3", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3.4, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "skill_110111_route1", bone = "RightWeaponPos", speed = 1},
            {type = "audio", time = 0, duration = 4, name = "JN-1101-110111-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            {type = "effect", time = 0, duration = 3.4, name = "skill_110111_route2", bone = "RightWeaponPos", speed = 1},
            --  {type = "effect", time = 0, duration = 3.4, name = "skill_110111_route3_m", bone = "RightWeaponPos", speed = 1},
            --  {type = "camera", time = 1.134, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.24;0;0.1;3"}
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 2.667, name = "skill_110121_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1.6, name = "JN-1101-110121-1", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "effect", time = 0, duration = 2.667, name = "skill_110121_route1_shou", bone = "RightWeaponPos", speed = 1},        
        },
        ["spell_03_start"] = {
            {type = "anim", time = 0, duration = 1.2, name = "Spell_03_Begin", speed = 1},
            {type = "effect", time = 0, duration = 1.2, name = "skill_110131_route1", bone = "Bip001 Prop2", speed = 1,is_coexist =true},
            {type = "audio", time = 0, duration = 3, name = "JN-1101-110131", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist =true},
        },
        ["spell_03_loop"] = {
            {type = "anim", time = 0, duration = 3.3, name = "Spell_03_Loop", speed = 1},
            {type = "effect", time = 0, duration = 10, name = "skill_110131_route2", bone = "Bip001 Prop2", speed = 1},
            --  {type = "effect", time = 0, duration = 3.3, name = "skill_110131_route3", bone = "Bip001 Prop2", speed = 1},
        },
        ["spell_03_end"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Spell_03_End", speed = 1},   
            -- {type = "effect", time = 0, duration = 1.4, name = "skill_110133_route1", bone = "", speed = 1, is_coexist = true},
        },
        ["spell_03_end2"] = {
            {type = "anim", time = 0, duration = 1.4, name = "Spell_03_End02", speed = 1},   
            {type = "effect", time = 0, duration = 1.4, name = "skill_110133_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1.4, name = "JN-1101-10005-1", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_04"] = {
            {type = "anim", time = 0, duration = 3.167, name = "Spell_04", speed = 1},
        },
    },
    -- 萨姬亚(陷阵之锤)高模
        ["1101_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 8.233, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 11, name = "scenes_1101_appearance_01", bone = "", speed = 1 , is_coexist = true},
                {type = "effect", time = 0, duration = 11, name = "scenes_1101_appearance_02", bone = "RightWeaponPos", speed = 1 , is_coexist = true},
                {type = "effect", time = 0, duration = 11, name = "scenes_1101_appearance_03", bone = "LeftWeaponPos", speed = 1 , is_coexist = true},
                {type = "camera", time = 0, duration = 8.7, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 1.333, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 8.1, name = "Pose02", speed = 1}, 
                {type = "effect", time = 0, duration = 11, name = "scenes_1101_pose02_01", bone = "", speed = 1 , is_coexist = true},
                {type = "effect", time = 0, duration = 11, name = "scenes_1101_pose02_02", bone = "ChestPos", speed = 1 , is_coexist = true},  
                {type = "effect", time = 0, duration = 11, name = "scenes_1101_pose02_03", bone = "RightWeaponPos", speed = 1 , is_coexist = true},  

            },
        },


-- 1111021 卡马尔(血色斗士)-正式
    ["1102"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "scenes_1102_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.9, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Death", speed = 1},
            {type = "shader", time = 1.3, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 1.867, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.9, name = "Hit", speed = 1.75},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.2, name = "LieHit", speed = 0.44},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.433, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.233, name = "FloatingDown", speed = 0.533},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 0.967, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 0.8, name = "GetUp", speed = 0.8},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 2.767, name = "Attack", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_110201_route1", bone = "", speed = 1},
            {type = "audio", time = 0.2, duration = 1, name = "JN-1102-110201-1", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "effect", time = 1.2, duration = 0.8, name = "skill_110201_route2", bone = "", speed = 1},
            {type = "audio", time = 0.9, duration = 1, name = "JN-1102-110201-2", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "effect", time = 2, duration = 0.7, name = "skill_110201_route3", bone = "", speed = 1},
            {type = "audio", time = 1.8, duration = 1, name = "JN-1102-110201-3", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "skill_110211_route1", bone = "", speed = 1},
            {type = "effect", time = 1.584, duration = 2, name = "skill_110211_route2", bone = "", speed = 1,is_coexist = true},
            {type = "audio", time = 0, duration = 3, name = "JN-1102-110211", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            {type = "camera", time = 1.584, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.24;0;0.1;3"}
        },
        ["spell_02_start"] = {
            {type = "anim", time = 0, duration = 0.133, name = "Spell_02_Begin", speed = 1},
        },
        ["spell_02_loop"] = {
            {type = "anim", time = 0, duration = 3, name = "Spell_02_Loop", speed = 1},
            {type = "effect", time = 0, duration = 10, name = "skill_110221_route1_m", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 3, name = "JN-1102-110221-1", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_02_loop4"] = {
            {type = "anim", time = 0, duration = 3, name = "Spell_02_Loop", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_110221_route2_m", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 3, name = "JN-1102-110221-2", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_02_end"] = {
            {type = "anim", time = 0, duration = 0.2, name = "Spell_02_End", speed = 1},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.267, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 1.267, name = "skill_110231_route1", bone = "Bone042", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_110231_route2", bone = "Bip001", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-1102-110231", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_04"] = {
            {type = "anim", time = 0, duration = 2.833, name = "Spell_04", speed = 1},
        },
    },
    -- 卡马尔(血色斗士)高模
        ["1102_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 7.7, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 9, name = "scenes_1102_appearance", bone = "", speed = 1 , is_coexist = true},
                {type = "camera", time = 0, duration = 8.2, name = "bone", params = "camera_bone;2.3;4.1;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 1.667, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 4.167, name = "Pose02", speed = 1},
                {type = "effect", time = 0, duration = 9, name = "scenes_1102_pose02", bone = "", speed = 1 , is_coexist = true},
            },
        },
    -- 卡马尔(血色斗士)精英怪01
        ["1152"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 4.133, name = "Appearance", speed = 1},
            },
            ["attack01"] = {
                {type = "anim", time = 0, duration = 2.767, name = "Attack", speed = 1},
                {type = "effect", time = 0, duration = 1, name = "skill_110201_route1", bone = "", speed = 1},
                {type = "effect", time = 1.1, duration = 0.8, name = "skill_110201_route2", bone = "", speed = 1},
                {type = "effect", time = 2, duration = 0.7, name = "skill_110201_route3", bone = "", speed = 1},
            },
            ["born_battle"] = {
                {type = "anim", time = 0, duration = 1.5, name = "Born", speed = 1},
                --  {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
                {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
            },
            ["born_hangup"] = {
                {type = "anim", time = 0, duration = 1.667, name = "Stand", speed = 1},
                {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
                {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
            },
            ["dead"] = {
                {type = "anim", time = 0, duration = 1.133, name = "Death", speed = 1},
                {type = "shader", time = 1.3, name = "Death", duration = 1.5, params = ""},
            },
            ["dizzy"] = {
                {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
            },
            ["floatingdown"] = {
                {type = "anim", time = 0, duration = 1.233, name = "FloatingDown", speed = 0.533},
            },
            ["floatingup"] = {
                {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
            },
            ["freeze"] = {
                {type = "anim", time = 0, duration = 0.433, name = "Freeze", speed = 1},
            },
            ["getup"] = {
                {type = "anim", time = 0, duration = 2.467, name = "GetUp", speed = 1},
            },
            ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
            ["hit"] = {
                {type = "anim", time = 0, duration = 0.9, name = "Hit", speed = 2},
            },
            ["liehit"] = {
                {type = "anim", time = 0, duration = 0.067, name = "LieHit", speed = 1.55},
            },
            ["lost"] = {
                {type = "anim", time = 0, duration = 2, name = "Lost", speed = 1},
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2, name = "Pose", speed = 1},
            },
            ["run"] = {
                {type = "anim", time = 0, duration = 0.9, name = "Run", speed = 1},
            },
            ["spell_01"] = {
                {type = "anim", time = 0, duration = 3.5, name = "Spell_01", speed = 1},
                {type = "effect", time = 0, duration = 1, name = "skill_110211_route1", bone = "", speed = 1},
                {type = "effect", time = 1.669, duration = 1, name = "skill_110211_route2", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 2, name = "JN-1102-110211", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
            ["spell_02_start"] = {
                {type = "anim", time = 0, duration = 0.133, name = "Spell_02_Begin", speed = 1},
            },
            ["spell_02_end"] = {
                {type = "anim", time = 0, duration = 0.2, name = "Spell_02_End", speed = 1},
            },
            ["spell_02_loop"] = {
                {type = "anim", time = 0, duration = 3, name = "Spell_02_Loop", speed = 1},
                {type = "effect", time = 0, duration = 3, name = "skill_110221_route1_m", bone = "", speed = 1},
            },
            ["spell_02_loop4"] = {
                {type = "anim", time = 0, duration = 3, name = "Spell_02_Loop", speed = 1},
                {type = "effect", time = 0, duration = 3, name = "skill_110221_route2_m", bone = "", speed = 1},
            },
            ["spell_03"] = {
                {type = "anim", time = 0, duration = 1.267, name = "Spell_03", speed = 1},
                {type = "effect", time = 0, duration = 1.267, name = "skill_110231_route1", bone = "Bone042", speed = 1},
                {type = "effect", time = 0, duration = 1, name = "skill_110231_route2", bone = "Bip001", speed = 1},
            },
            ["spell_04"] = {
                {type = "anim", time = 0, duration = 2.833, name = "Spell_04", speed = 1},
            },
            ["stand"] = {
                {type = "anim", time = 0, duration = 1.667, name = "Stand", speed = 1},
            },
            ["win"] = {
                {type = "anim", time = 0, duration = 1.867, name = "Win", speed = 1},
                {type = "effect", time = 0, duration = 1.867, name = "scenes_1102_born", bone = "", speed = 1},
            },
        },
    -- 卡马尔(血色斗士)精英怪02
        ["1161"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 4.133, name = "Appearance", speed = 1},
            },
            ["attack01"] = {
                {type = "anim", time = 0, duration = 2.767, name = "Attack", speed = 1},
                {type = "effect", time = 0, duration = 1, name = "skill_110201_route1", bone = "", speed = 1},
                {type = "effect", time = 1.1, duration = 0.8, name = "skill_110201_route2", bone = "", speed = 1},
                {type = "effect", time = 2, duration = 0.7, name = "skill_110201_route3", bone = "", speed = 1},
            },
            ["dead"] = {
                {type = "anim", time = 0, duration = 1.133, name = "Death", speed = 1},
                {type = "shader", time = 1.3, name = "Death", duration = 0.5, params = ""},
            },
            ["dizzy"] = {
                {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
            },
            ["floatingdown"] = {
                {type = "anim", time = 0, duration = 0.23, name = "FloatingDown", speed = 1},
            },
            ["floatingup"] = {
                {type = "anim", time = 0, duration = 0.8, name = "FloatingUp", speed = 1},
            },
            ["freeze"] = {
                {type = "anim", time = 0, duration = 0.433, name = "Freeze", speed = 1},
            },
            ["getup"] = {
                {type = "anim", time = 0, duration = 2.467, name = "GetUp", speed = 1},
            },
            ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
            ["hit"] = {
                {type = "anim", time = 0, duration = 0.9, name = "Hit", speed = 2},
            },
            ["liehit"] = {
                {type = "anim", time = 0, duration = 0.067, name = "LieHit", speed = 1.55},
            },
            ["lost"] = {
                {type = "anim", time = 0, duration = 2, name = "Lost", speed = 1},
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2, name = "Pose", speed = 1},
            },
            ["run"] = {
                {type = "anim", time = 0, duration = 0.9, name = "Run", speed = 1},
            },
            ["spell_01"] = {
                {type = "anim", time = 0, duration = 3.5, name = "Spell_01", speed = 1},
                {type = "effect", time = 0, duration = 1, name = "skill_110211_route1", bone = "", speed = 1},
                {type = "effect", time = 1.669, duration = 1, name = "skill_110211_route2", bone = "", speed = 1},
            },
            ["spell_02_start"] = {
                {type = "anim", time = 0, duration = 0.133, name = "Spell_02_Begin", speed = 1},
            },
            ["spell_02_end"] = {
                {type = "anim", time = 0, duration = 0.2, name = "Spell_02_End", speed = 1},
            },
            ["spell_02_loop"] = {
                {type = "anim", time = 0, duration = 3, name = "Spell_02_Loop", speed = 1},
                {type = "effect", time = 0, duration = 3, name = "skill_110221_route1_m", bone = "", speed = 1},
            },
            ["spell_02_loop4"] = {
                {type = "anim", time = 0, duration = 3, name = "Spell_02_Loop", speed = 1},
                {type = "effect", time = 0, duration = 3, name = "skill_110221_route2_m", bone = "", speed = 1},
            },
            ["spell_03"] = {
                {type = "anim", time = 0, duration = 1.267, name = "Spell_03", speed = 1},
                {type = "effect", time = 0, duration = 1.267, name = "skill_110231_route1", bone = "Bone042", speed = 1},
                {type = "effect", time = 0, duration = 1, name = "skill_110231_route2", bone = "Bip001", speed = 1},
            },
            ["spell_04"] = {
                {type = "anim", time = 0, duration = 2.833, name = "Spell_04", speed = 1},
            },
            ["stand"] = {
                {type = "anim", time = 0, duration = 1.667, name = "Stand", speed = 1},
            },
            ["win"] = {
                {type = "anim", time = 0, duration = 2, name = "Win", speed = 1},
            },
        },

-- 1111031 鲍德维克(护国元帅)-正式
    ["1103"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.733, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.7, name = "scenes_1101_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.733, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.9, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.4, name = "Death", speed = 1},
            {type = "shader", time = 1.3, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 1.867, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.9, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.067, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.433, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 0.8, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 0.23, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 2.467, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 0.933, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_110301_route1", bone = "", speed = 1},
            {type = "audio", time = 0.2, duration = 1, name = "JN-1103-110301", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 0.933, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_110302_route1", bone = "", speed = 1},
            {type = "audio", time = 0.2, duration = 1, name = "JN-1103-110302", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 3.5, name = "skill_110311_route1", bone = "", speed = 1},
            --  {type = "camera", time = 0.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.24;0;0.1;3"},
            --  {type = "camera", time = 1.3, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3"},
            {type = "camera", time = 2.1, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"},
            --  {type = "camera", time = 3, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;10"},
            {type = "audio", time = 0, duration = 4, name = "JN-1103-110311", speed = 1, volume = 0.8, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
            -- {type = "shader", time = 0, name = "Scale", duration = 3, params = "0.5;0.2;1.5", is_coexist = true}--duration 变身时间，0.5初始状态时间，0.2变回来的时间，比例倍数
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 1.467  , name = "Spell_02", speed = 1},
            {type = "audio", time = 0, duration = 5, name = "JN-1103-110311", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "effect", time = 1, duration = 1.5, name = "skill_110321_route1", bone = "", speed = 1,is_coexist = true},
            {type = "effect", time = 0, duration = 1.5, name = "skill_110321_route2", bone = "RightWeaponPos", speed = 1},
        },

    },
    -- 鲍德维克(护国元帅)高模
        ["1103_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 5.3, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 6, name = "scenes_1103_appearance", bone = "", speed = 1 },
                {type = "effect", time = 0, duration = 5, name = "scenes_1103_appearance_02", bone = "RightWeaponPos", speed = 1 },
                {type = "camera", time = 0, duration = 5.8, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2.333, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 2.333, name = "Pose02", speed = 1},
                {type = "effect", time = 0, duration = 11, name = "scenes_1103_pose02", bone = "", speed = 1 , is_coexist = true},

            },
        },
-- 1111041 雷克托(重钢统帅)-非正式
    ["1104"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.733, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.7, name = "scenes_1101_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.733, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.9, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.4, name = "Death", speed = 1},
            {type = "shader", time = 1.3, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 1.867, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.9, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.067, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.433, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 0.8, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 0.23, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 2.467, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 0.933, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_110301_route1", bone = "", speed = 1},
            {type = "audio", time = 0.2, duration = 1, name = "JN-1103-110301", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 0.933, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_110302_route1", bone = "", speed = 1},
            {type = "audio", time = 0.2, duration = 1, name = "JN-1103-110302", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 3.5, name = "skill_110311_route1", bone = "", speed = 1},
            --  {type = "camera", time = 0.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.24;0;0.1;3"},
            --  {type = "camera", time = 1.3, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3"},
            {type = "camera", time = 2.1, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"},
            --  {type = "camera", time = 3, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;10"},
            {type = "audio", time = 0, duration = 4, name = "JN-1103-110311", speed = 1, volume = 0.8, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
            -- {type = "shader", time = 0, name = "Scale", duration = 3, params = "0.5;0.2;1.5", is_coexist = true}--duration 变身时间，0.5初始状态时间，0.2变回来的时间，比例倍数
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 1.467  , name = "Spell_02", speed = 1},
            {type = "audio", time = 0, duration = 5, name = "JN-1103-110311", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "effect", time = 1, duration = 1.5, name = "skill_110321_route1", bone = "", speed = 1,is_coexist = true},
            {type = "effect", time = 0, duration = 1.5, name = "skill_110321_route2", bone = "RightWeaponPos", speed = 1},
        },

    },
    -- 雷克托(重钢统帅)高模
        ["1103_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 5.3, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 6, name = "scenes_1103_appearance", bone = "", speed = 1 },
                {type = "effect", time = 0, duration = 5, name = "scenes_1103_appearance_02", bone = "RightWeaponPos", speed = 1 },
                {type = "camera", time = 0, duration = 5.8, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2.333, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 2.333, name = "Pose02", speed = 1},
                {type = "effect", time = 0, duration = 11, name = "scenes_1103_pose02", bone = "", speed = 1 , is_coexist = true},

            },
        },

-- 1112011 托尔丁(巨兽猎手)-正式
    ["1201"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "scenes_1101_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
            --  {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.033, name = "Death", speed = 1},
            {type = "shader", time = 2.4, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 2.833, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 1, name = "Hit", speed = 2.5},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.62},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.233, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.133, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.4, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_120101_route1", bone = "", speed = 1},    --   枪口火焰烟雾特效
            {type = "effect", time = 0.3, duration = 1, name = "skill_120101_route2", bone = "RightWeaponPos", speed = 1},  --   子弹壳飞溅特效
            {type = "audio", time = 0.3, duration = 1, name = "JN-1201-120101", speed = 1, volume = 0.6, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 4.133, name = "Spell_01", speed = 1},
            {type = "effect", time = 0.6, duration = 2, name = "skill_120111_route1", bone = "RightWeaponPos", speed = 1},   --  瞄准时枪中心聚集起光束
            {type = "effect", time = 2.5, duration = 1, name = "skill_120111_route3", bone = "", speed = 1},   --   枪口火焰烟雾特效
            {type = "camera", time = 0.8, duration = 1.6, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;16"},
            {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"},
            {type = "audio", time = 0, duration = 4, name = "JN-1201-120111", speed = 1, volume = 1.2, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 3.633, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 2.5, name = "skill_120131_route1", bone = "LeftHandPos", speed = 1},   --   “悬赏令”起手特效
            {type = "audio", time = 0, duration = 1.23, name = "JN-1201-120131", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist=true},
            {type = "audio", time = 1.23, duration = 1.13, name = "JN-1201-120131-hit", speed = 0.5, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist=true},
        },
    },
    -- 1112011托尔丁(巨兽猎手)高模
        ["1201_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 5.733, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 5.3, name = "scenes_1201_appearance_01", bone = "RightHandPos", speed = 1 },
                {type = "effect", time = 0, duration = 5.3, name = "scenes_1201_appearance_02", bone = "", speed = 1 },
                {type = "camera", time = 0, duration = 6.2, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2.1, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 6.433, name = "Pose02", speed = 1}, 
                --  {type = "effect", time = 0, duration = 11, name = "scenes_1201_pose02", bone = "", speed = 1 , is_coexist = true},

            },
        },

-- 1112021 伊丽莎白(劲爆魔女)-正式
    ["1202"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Born", speed = 1},
            --  {type = "effect", time = 0, duration = 1.5, name = "scenes_1202_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.033, name = "Death", speed = 1},
            {type = "shader", time = 2.4, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 2.833, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 1, name = "Hit", speed = 2.5},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.62},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.233, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.267, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.233, name = "FloatingDown", speed = 1.233},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.4, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 5, name = "skill_120201_route1", bone = "LeftHandPos", speed = 1, is_coexist = true},   
            {type = "audio", time = 0, duration = 1.6, name = "JN-1202-120201", speed = 0.8, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.4, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 5, name = "skill_120202_route1", bone = "RightHandPos", speed = 1, is_coexist = true}, 
            {type = "audio", time = 0, duration = 1.6, name = "JN-1202-120201", speed = 0.8, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 4, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_120211_route1", bone = "", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 3, name = "skill_120211_route2", bone = "", speed = 1, is_coexist = true},   
            {type = "effect", time = 0, duration = 4, name = "skill_120211_route3", bone = "MouthPos", speed = 1},  
            {type = "audio", time = 0, duration = 2, name = "JN-1202-120211-begin", speed = 1, volume = 0.8, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            --  {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 2, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_120221_route1", bone = "", speed = 1},
            {type = "audio", time = 0.7, duration = 1.5, name = "JN-1202-120221", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Spell_03", speed = 0.7},
            {type = "effect", time = 0, duration = 1, name = "skill_120231_route1", bone = "MouthPos", speed = 1, is_coexist = true},
            {type = "effect", time = 0.2, duration = 2, name = "skill_120231_route2", bone = "", speed = 1, is_coexist = true,},
            {type = "audio", time = 0, duration = 1.2, name = "JN-1202-120231", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_03_end"] = {
            {type = "anim", time = 0, duration = 1.33, name = "Spell_03_End", speed = 1},
            {type = "effect", time = 0.7, duration = 3, name = "skill_120231_route3", bone = "MouthPos", speed = 1, is_coexist = true},   
            {type = "audio", time = 0, duration = 0.7, name = "JN-1202-120231-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_04_start"] = {
            {type = "anim", time = 0, duration = 1.2, name = "Spell_04_Begin", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_120241_route1", bone = "", speed = 1, is_coexist = true},  
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-ZZG-10004-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_04_loop"] = {
            {type = "anim", time = 0, duration = 15, name = "Spell_04_Loop", speed = 1.5},
            {type = "effect", time = 0, duration = 15, name = "skill_120241_route2_m", bone = "", speed = 1.5,}, 
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-ZZG-10004-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    -- 1112021伊丽莎白(劲爆魔女)高模
        ["1202_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 4.767, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 6, name = "scenes_1202_appearance", bone = "", speed = 1 },
                {type = "camera", time = 0, duration = 5.3, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max


            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2.1, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 6.433, name = "Pose02", speed = 1}, 
                --  {type = "effect", time = 0, duration = 11, name = "scenes_11202_pose02", bone = "", speed = 1 , is_coexist = true},

            },
        },

-- 1112031 布维尔(花剑怪侠)-正式  
    ["1203"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "scenes_1203_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.033, name = "Death", speed = 1},
            {type = "shader", time = 2.4, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 2.833, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 1, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.233, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.233, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.4, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_120301_route1", bone = "", speed = 1},    --   枪口火焰烟雾特效
            {type = "audio", time = 0, duration = 1.5, name = "JN-1203-120301", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.4, name = "Attack02", speed = 1},
            {type = "effect", time = 0.33, duration = 1, name = "skill_120302_route1", bone = "", speed = 1},    --   枪口火焰烟雾特效
            {type = "audio", time = 0, duration = 1.5, name = "JN-1203-120302", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 4.133, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "skill_120311_route1", bone = "", speed = 1},   
            {type = "effect", time = 0, duration = 4, name = "skill_120311_route2", bone = "", speed = 1},  
            {type = "audio", time = 0, duration = 4, name = "JN-1203-120311", speed = 1, volume = 0.6, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},

        },
        ["spell_02"] = {
            --  {type = "anim", time = 0, duration = 0.967, name = "Spell_02", speed = 1},
            --  {type = "effect", time = 0, duration = 1, name = "skill_120321_route1", bone = "", speed = 1},
            --  {type = "audio", time = 0, duration = 0.7, name = "JN-1203-120321", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
   
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 3, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_120331_route1", bone = "LeftHandPos", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 3, name = "skill_120331_route2", bone = "", speed = 1, is_coexist = true}, 
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-ZZG-10004-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        }, 
        ["spell_04_start"] = {
            {type = "anim", time = 0, duration = 3.633, name = "Spell_04_Begin", speed = 1},
            {type = "effect", time = 0, duration = 3.6, name = "skill_120341_route1", bone = "", speed = 1},   
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-ZZG-10004-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_04_end"] = {
            {type = "anim", time = 0, duration = 3.633, name = "Spell_04_End", speed = 1},
            {type = "effect", time = 0, duration = 3.2, name = "skill_120341_route2", bone = "", speed = 1}, 
            {type = "effect", time = 0, duration = 4, name = "skill_120341_route3", bone = "", speed = 1},  
            {type = "audio", time = 0, duration = 3, name = "JN-1203-120341", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    -- 1112031布维尔(花剑怪侠)高模
        ["1203_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 4.567, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 4.57, name = "scenes_1203_appearance", bone = "", speed = 1 },
                {type = "camera", time = 0, duration = 5, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2.1, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 6.433, name = "Pose02", speed = 1}, 
                --  {type = "effect", time = 0, duration = 11, name = "scenes_1203_pose02", bone = "", speed = 1 , is_coexist = true},

            },
        },

-- 1112041 朱塞佩(黑街顽首)-正式 
    ["1204"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 2.5, name = "scenes_1204_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
            --  {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.033, name = "Death", speed = 1},
            {type = "shader", time = 2.4, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 2.833, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 1, name = "Hit", speed = 2.5},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.233, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.267, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.267, name = "FloatingDown", speed = 0.88},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_120401_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1.5, name = "JN-1204-120401", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_120401_route2", bone = "", speed = 1},  
            {type = "audio", time = 0, duration = 1.5, name = "JN-1204-120401", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3.5, name = "Spell_01", speed = 1},
            {type = "effect", time = 0.6, duration = 1, name = "skill_120411_route1", bone = "", speed = 1},   
            {type = "effect", time = 0, duration = 2, name = "skill_120411_route2", bone = "", speed = 1},
            {type = "audio", time = 1, duration = 1.5, name = "JN-1204-120411", speed = 0.8, volume = 0.8, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            --  {type = "camera", time = 1.05, duration = 0.6, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;10"},
            {type = "camera", time = 1.8, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3" },
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 1.767, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_120421_route1", bone = "", speed = 1}, 
            {type = "audio", time = 0.1, duration = 1.7, name = "JN-1204-120421", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
    
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.933, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 1.45, name = "skill_120431_route1", bone = "", speed = 1},   
            {type = "audio", time = 0, duration = 1, name = "JN-1204-120431", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    -- 1112041朱塞佩(黑街顽首)高模
        ["1204_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 7.333, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 7.333, name = "scenes_1204_appearance_01", bone = "", speed = 1 },
                {type = "effect", time = 0, duration = 7.333, name = "scenes_1204_appearance_02", bone = "Bip001 Pelvis", speed = 1 },
                {type = "camera", time = 0, duration = 7.8, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 6, name = "Pose02", speed = 1}, 
                --  {type = "effect", time = 0, duration = 11, name = "scenes_1204_pose02", bone = "", speed = 1 , is_coexist = true},

            },
        },

-- 1112051 巴克(暗巷歹徒)-正式
    ["1205"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Born", speed = 1},
            --  {type = "effect", time = 0, duration = 1.5, name = "scenes_1205_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.033, name = "Death", speed = 1},
            {type = "shader", time = 2.4, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 2.833, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 1, name = "Hit", speed = 1.8},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.233, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.333, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.133, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack01", speed = 1},
            {type = "effect", time = 0.23, duration = 1, name = "skill_120501_route1", bone = "", speed = 1},    
            --  {type = "audio", time = 0.7, duration = 1.5, name = "JN-3202-320201", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack02", speed = 1},
            {type = "effect", time = 0.2, duration = 1, name = "skill_120502_route1", bone = "", speed = 1},    
            --  {type = "audio", time = 0.7, duration = 1.5, name = "JN-3202-320201", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_120511_route2_01", bone = "RightWeaponPos", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_120511_route2_01", bone = "LeftWeaponPos", speed = 1},         
            {type = "audio", time = 0, duration = 4, name = "JN-1205-120511", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 0.567, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "skill_120511_route1", bone = "", speed = 1,is_coexist = true},

            -- {type = "audio", time = 0, duration = 4, name = "JN-ZZG-10002-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 0.9, name = "Spell_01_End", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_120511_route2", bone = "", speed = 1}, 
            {type = "effect", time = 0, duration = 2, name = "skill_120511_route3", bone = "", speed = 1},  
            -- {type = "audio", time = 0, duration = 4, name = "JN-ZZG-10002-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
 
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 1.433, name = "Spell_02", speed = 1},
            {type = "effect", time = 0.3, duration = 2, name = "skill_120521_route1", bone = "", speed = 1},  
            --  {type = "effect", time = 1.1, duration = 2, name = "skill_120521_route3", bone = "", speed = 1},  
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-ZZG-10004-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    -- 1112051巴克(暗巷歹徒)高模
        ["1205_ex"] = {
            ["appearance"] = {
                {type = "camera", time = 0, duration = 2, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
                {type = "anim", time = 0, duration = 2, name = "Appearance", speed = 1},
                -- {type = "effect", time = 0, duration = 5.3, name = "scenes_1205_appearance_01", bone = "RightHandPos", speed = 1 },
                -- {type = "effect", time = 0, duration = 2.5, name = "scenes_1205_appearance_02", bone = "", speed = 1 },
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2.1, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 6.433, name = "Pose02", speed = 1}, 
                {type = "effect", time = 0, duration = 11, name = "scenes_1205_pose02", bone = "", speed = 1 , is_coexist = true},

            },
        },

-- 1113011 因娜拉(奥法贤者)-正式
    ["1301"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 0.933, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "scenes_1301_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.733, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.333, name = "Death", speed = 1},
            {type = "shader", time = 2.333, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.677, name = "LieHit", speed = 1.48},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.033, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 1.333, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 0.267, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Attack", speed = 1},
            {type = "effect", time = 0, duration = 1.333, name = "skill_130101_route1", bone = "Bip001 L Hand", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-1301-130101", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Spell_01_Attack", speed = 1},
            {type = "effect", time = 0, duration = 1.333, name = "skill_130102_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 5, name = "JN-1301-10002-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 2.333, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0, duration = 2.333, name = "skill_130111_route1", bone = "", speed = 1},
            --  {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;20"},
            {type = "camera", time = 1.133, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;6"},
            {type = "audio", time = 0, duration = 4, name = "JN-1301-130111", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["spell_01_stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Spell_01_Stand", speed = 1},
        },
        ["spell_01_run"] = {
            {type = "anim", time = 0, duration = 0.733, name = "Spell_01_Stand", speed = 1},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Spell_01_End", speed = 1},
        },
        ["spell_02_start"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Spell_02_Begin", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_130121_route1", bone = "RighthandPos", speed = 1, is_coexist = true},
            {type = "audio", time = 0, duration = 1.5, name = "JN-1301-10002-2", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_02_loop"] = {
            {type = "anim", time = 0, duration = 3, name = "Spell_02_Loop", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_130121_route2", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 4, name = "JN-1301-10003-1", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_02_loop2"] = {
            {type = "anim", time = 0, duration = 3, name = "Spell_02_Loop", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_130123_route3", bone = "RighthandPos", speed = 1},
            {type = "audio", time = 0, duration = 4, name = "JN-1301-10003-1", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_02_end"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Spell_02_End", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_130121_route3", bone = "RightWeaponPos", speed = 1},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 2.333, name = "skill_130131_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 3, name = "JN-1301-10004-1", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_04"] = {
            {type = "anim", time = 0, duration = 1.833, name = "Spell_04", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "skill_130141_route1", bone = "LeftWeaponPos", speed = 1},
            {type = "audio", time = 0.3, duration = 2, name = "JN-1301-10005-1", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
    }, 
    -- 因娜拉(奥法贤者)高模
        ["1301_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 8, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 10, name = "scenes_1301_appearance_01", bone = "", speed = 1 , is_coexist = true},
                {type = "effect", time = 0, duration = 10, name = "scenes_1301_appearance_02", bone = "Bip001 L Finger01", speed = 1 , is_coexist = true},
                {type = "camera", time = 0, duration = 8.5, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 1.333, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 3.967, name = "Pose02", speed = 1},
            },
        },

-- 1113021 勒芙蕾丝(乱匠天才)-正式
    ["1302"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 2.933, name = "Born", speed = 1},
            -- {type = "effect", time = 0, duration = 1.5, name = "scenes_1301_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.267, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Death", speed = 1},
            {type = "shader", time = 2.333, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 2.167, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.667, name = "Hit", speed = 1.8},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.667, name = "LieHit", speed = 1.48},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.033, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.267, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Attack01", speed = 1},
            {type = "audio", time = 0, duration = 1.2, name = "JN-1303-130321-Begin", speed = 0.8, volume = 0.4, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},

            
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.867, name = "Attack02", speed = 1},
            {type = "audio", time = 0, duration = 1.2, name = "JN-1303-130321-Begin", speed = 0.8, volume = 0.4, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},

        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_130211_route1", bone = "", speed = 1,is_coexist = true},
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 2.5, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_130211_route2", bone = "", speed = 1,},
            {type = "audio", time = 0, duration = 4, name = "JN-1302-130211", speed = 1, volume = 0.7, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
            {type = "audio", time = 0, duration = 1, name = "JN-1302-130211-throw", speed = 1, volume = 0., bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
            {type = "audio", time = 0.2, duration = 1, name = "JN-1302-130211-throw", speed = 1, volume = 0.6, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
            {type = "audio", time = 0.4, duration = 1, name = "JN-1302-130211-throw", speed = 1, volume = 0.6, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
            {type = "audio", time = 0.6, duration = 1, name = "JN-1302-130211-throw", speed = 1, volume = 0.6, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
            {type = "audio", time = 0.6, duration = 1, name = "JN-1302-130211-throw", speed = 1, volume = 0.6, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
            {type = "audio", time = 0.8, duration = 1, name = "JN-1302-130211-throw", speed = 1, volume = 0.6, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
            {type = "audio", time = 1.0, duration = 1, name = "JN-1302-130211-throw", speed = 1, volume = 0.6, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
            {type = "audio", time = 1.2, duration = 1, name = "JN-1302-130211-throw", speed = 1, volume = 0.6, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
            {type = "audio", time = 1.4, duration = 1, name = "JN-1302-130211-throw", speed = 1, volume = 0.6, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
            {type = "audio", time = 1.6, duration = 1, name = "JN-1302-130211-throw", speed = 1, volume = 0.6, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
            {type = "camera", time = 0, duration = 3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.05;60" },
            --  {type = "audio", time = 0, duration = 4, name = "JN-1301-10002-1", speed = 0.88, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 1.367, name = "Spell_01_End", speed = 1},
            {type = "camera", time = 0, duration = 0.5, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.05;10" },
            --  {type = "effect", time = 0, duration = 2.333, name = "skill_130211_route1", bone = "", speed = 1},
            --  {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.08;0;0.1;20"},
            --  {type = "camera", time = 1.133, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3"},
            --  {type = "audio", time = 0, duration = 4, name = "JN-1301-10002-1", speed = 0.88, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 1.4, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_130221_route2", bone = "", speed = 1, is_coexist = true },
            {type = "effect", time = 0, duration = 2, name = "skill_130221_route3", bone = "", speed = 1, is_coexist = true },
            {type = "audio", time = 0, duration = 1.5, name = "JN-1302-130221", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            {type = "audio", time = 1, duration = 1, name = "JN-1302-130201-hit", speed = 0.8, volume = 0.4, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

        },
    }, 
    -- 勒芙蕾丝(乱匠天才)高模
        ["1302_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 5.067, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 5.5, name = "scenes_1302_appearance", bone = "", speed = 1 , is_coexist = true},
                {type = "camera", time = 0, duration = 5.5, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 1.333, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 4.067, name = "Pose02", speed = 1},
            },
        },

-- 1113031 洁西卡(激流魔女)-正式
    ["1303"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 0.933, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "scenes_1303_born", bone = "bone39", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.733, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.333, name = "Death", speed = 1},
            {type = "shader", time = 2.333, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Hit", speed = 2.25},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.677, name = "LieHit", speed = 1.48},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.033, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.267, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 0.933, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_130301_route1", bone = "", speed = 1},
            {type = "audio", time = 0.3, duration = 1, name = "JN-1303-130301", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_130302_route1 ", bone = "", speed = 1},
            {type = "audio", time = 0.3, duration = 1, name = "JN-1303-130301", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 7, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_130311_route1", bone = "", speed = 1},
            {type = "effect", time = 2, duration = 3, name = "skill_130311_route2", bone = "", speed = 1},
            --  {type = "camera", time = 1.6, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3",is_coexist = true},
            {type = "camera", time = 2.6, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.8;0;0.1;3",is_coexist = true},
            {type = "camera", time = 2.9, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.5;0;0.1;10",is_coexist = true},
            {type = "audio", time = 0, duration = 1.8, name = "JN-1303-130311", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
            {type = "audio", time = 1.2, duration = 4, name = "JN-1303-130311-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 6.5, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 2.5, name = "skill_130321_route1", bone = "", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "skill_130321_route2", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1.5, name = "JN-1303-130321", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 6.5, name = "Spell_02", speed = 1},
            {type = "audio", time = 0, duration = 3.8, name = "JN-1303-130331-Begin", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
    }, 
    -- 洁西卡(湍流少女)高模
        ["1303_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 7.367, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 8, name = "scenes_1303_appearance_01", bone = "", speed = 1 },
                {type = "effect", time = 0, duration = 20, name = "scenes_1303_appearance_02", bone = "", speed = 1 },
                {type = "camera", time = 0, duration = 7.4, name = "bone", params = "camera_bone;1.5;3.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

                -- {type = "effect", time = 0, duration = 10, name = "scenes_1301_appearance_02", bone = "Bip001 L Finger01", speed = 1 , is_coexist = true},
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 8, name = "Pose", speed = 1},
                {type = "effect", time = 0, duration = 8, name = "scenes_1303_pose_01", bone = "Bone163", speed = 1},
                
                
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 2, name = "Pose02", speed = 1},
                {type = "effect", time = 0, duration = 6, name = "scenes_1303_pose_02", bone = "", speed = 1},
            },
        },
    --  杰西卡水鲛弹
    ["130322"] = {
            ["130322_start"] = {
                {type = "effect", time = 0, duration = 8, name = "skill_130321_route2_start", bone = "", speed = 1 , is_= true},
                -- {type = "effect", time = 0, duration = 10, name = "scenes_1301_appearance_02", bone = "Bip001 L Finger01", speed = 1 , is_coexist = true},
            },
            --  ["130322_loop"] = {
            --      --  {type = "effect", time = 0, duration = 8, name = "skill_130321_route2_start", bone = "", speed = 1 , is_= true},
            --      {type = "effect", time = 0, duration = 8, name = "skill_130321_route2_loop", bone = "", speed = 1 , is_coexist = true},
            --  },
            ["130322_end"] = {
                {type = "effect", time = 0, duration = 6, name = "skill_130321_route2_end", bone = "", speed = 1 , is_coexist = true},
            },
        },

-- 1113041 沃顿(圣光牧师)-正式
    ["1304"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Stand", speed = 1},
            --  {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.9, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 0.867, name = "Death", speed = 1},
            {type = "shader", time = 0.867, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 2.967, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.3, name = "LieHit", speed = 0.67},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.033, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.267, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 0.733, name = "FloatingDown", speed = 1.36},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 0.967, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 0.733, name = "GetUp", speed = 0.733},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.6, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_130401_route1", bone = "LeftWeaponPos", speed = 1},
            -- {type = "audio", time = 0.3, duration = 1, name = "JN-1301-10001-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 1.233, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_130411_route1", bone = "RightHandPos", speed = 1},
            {type = "effect", time = 0, duration = 1.23, name = "skill_130411_route2", bone = "LeftWeaponPos", speed = 1},
            -- {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.08;0;0.1;20"},
            -- {type = "camera", time = 1.133, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3"},
            {type = "audio", time = 0, duration = 4, name = "JN-1101-110131", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 6, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 0, duration = 6, name = "skill_130411_route3", bone = "LeftWeaponPos", speed = 1 },
            -- {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.08;0;0.1;20"},
            -- {type = "camera", time = 1.133, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3"},
            -- {type = "audio", time = 0, duration = 4, name = "JN-1301-10002-1", speed = 0.88, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 0.167, name = "Spell_01_End", speed = 1},
            {type = "effect", time = 0, duration = 0.167, name = "skill_130411_route4", bone = "LeftWeaponPos", speed = 1},
            -- {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.08;0;0.1;20"},
            -- {type = "camera", time = 1.133, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3"},
            -- {type = "audio", time = 0, duration = 4, name = "JN-1301-10002-1", speed = 0.88, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 1.267, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 1.3, name = "skill_130421_route1", bone = "LeftWeaponPos", speed = 1, is_coexist = true },
            {type = "effect", time = 0, duration = 1.3, name = "skill_130421_route2", bone = "", speed = 1, is_coexist = true },
            -- {type = "audio", time = 0, duration = 1.5, name = "JN-1301-10002-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
    }, 
    -- 沃顿(圣光牧师)高模
        ["1304_ex"] = {
            ["appearance"] = {
                {type = "camera", time = 0, duration = 1.667, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
                {type = "anim", time = 0, duration = 1.667, name = "Appearance", speed = 1},
                -- {type = "effect", time = 0, duration = 10, name = "scenes_1301_appearance_01", bone = "", speed = 1 , is_coexist = true},
                -- {type = "effect", time = 0, duration = 10, name = "scenes_1301_appearance_02", bone = "Bip001 L Finger01", speed = 1 , is_coexist = true},
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 1.667, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 1.667, name = "Pose02", speed = 1},
            },
        },

-- 1113051 马耶罗(豪琴孤狼)-正式
    ["1305"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "scenes_1305_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Stand", speed = 1},
            --  {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.9, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 0.867, name = "Death", speed = 1},
            {type = "shader", time = 0.867, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 2.967, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.3, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.033, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.233, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 0.967, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 0.733, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.6, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_130501_route1", bone = "LeftWeaponPos", speed = 1},
             {type = "audio", time = 0, duration = 1.5, name = "JN-1305-130501", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = false},
        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0, duration = 0.833, name = "skill_130511_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1.09, name = "JN-1305-130511", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_130511_route2", bone = "LeftWeaponPos", speed = 1},
            {type = "audio", time = 0, duration = 1.26, name = "JN-1305-130511-attack1", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["spell_01_loop_02"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 0, duration = 0.5, name = "skill_130511_route2", bone = "LeftWeaponPos", speed = 3, is_coexist = true},
            {type = "audio", time = 0, duration = 1.26, name = "JN-1305-130511-attack4", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["spell_01_loop_03"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 0, duration = 0.5, name = "skill_130511_route2", bone = "LeftWeaponPos", speed = 3, is_coexist = true},
            {type = "audio", time = 0, duration = 1.26, name = "JN-1305-130511-attack2", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Spell_01_End", speed = 1},
            {type = "effect", time = 0.5, duration = 1.133, name = "skill_130511_route3", bone = "LeftWeaponPos", speed = 1},
            {type = "camera", time = 0.5, duration = 0.5, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;5"},
            {type = "audio", time = 0, duration = 4, name = "JN-1305-130511-attack3", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 2.067, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_130521_route1", bone = "", speed = 1, is_coexist = true },
            {type = "effect", time = 0, duration = 2, name = "skill_130521_route2", bone = "LeftWeaponPos", speed = 1, is_coexist = true },
            {type = "audio", time = 0, duration = 1.5, name = "JN-1305-130521", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = false},
            },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Spell_03", speed = 1},
            --  {type = "effect", time = 0, duration = 1.6, name = "skill_130521_route1", bone = "LeftWeaponPos", speed = 1, is_coexist = true },
            -- {type = "audio", time = 0, duration = 1.5, name = "JN-1301-10002-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
    },
    -- 马耶罗(豪琴孤狼)高模
        ["1305_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 6.467, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 6.467, name = "scenes_1305_appearance_01", bone = "", speed = 1 ,},
                {type = "effect", time = 0, duration = 6.467, name = "scenes_1305_appearance_02", bone = "LeftWeaponPos", speed = 1 , },
                {type = "camera", time = 0, duration = 7, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 3.2, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 5.467, name = "Pose02", speed = 1},
                {type = "effect", time = 0, duration = 9, name = "scenes_1305_pose02", bone = "LeftWeaponPos", speed = 1 , is_coexist = true},
            },
        },

-- 1113061 罗珊(燃情舞娘)-正式
    ["1306"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            --  {type = "anim", time = 0, duration = 1.667, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.9, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 0.867, name = "Death", speed = 1},
            {type = "shader", time = 0.867, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 2.967, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Hit", speed = 1.75},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.3, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.033, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 0.967, name = "LieDown", speed = 0.856},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1.433, name = "GetUp", speed = 1.433},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.6, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_130601_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-1301-130102", speed = 1, volume = 0.7, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.733, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_130602_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-1301-130102", speed = 1, volume = 0.7, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},

        },
        -- ["spell_01"] = {
        --     {type = "anim", time = 0, duration = 1, name = "Spell_01", speed = 1},
        --     {type = "effect", time = 0.5, duration = 1.5, name = "skill_130611_route1", bone = "", speed = 1},
        --     {type = "audio", time = 0, duration = 4, name = "JN-3301-330141", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        -- },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 1, name = "Spell_01_Begin ", speed = 1},
            {type = "effect", time = 0.5, duration = 1.5, name = "skill_130611_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 0.5, name = "JN-1306-130631", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
            {type = "audio", time = 0, duration = 4, name = "JN-1306-130611-Hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 6, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 0, duration = 6, name = "skill_130611_route2_m", bone = "", speed = 1 },
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Spell_01_End", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_130631_route3", bone = "", speed = 1, is_coexist = true },
            --  {type = "audio", time = 0, duration = 4, name = "JN-1306-130631", speed = 0.88, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 2.4, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 2.5, name = "skill_130621_route1", bone = "", speed = 1, is_coexist = true },
            -- {type = "audio", time = 0, duration = 1.5, name = "JN-1301-10002-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Spell_01_End", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_130631_route1", bone = "", speed = 1, is_coexist = true },
            {type = "audio", time = 0, duration = 4, name = "JN-1306-130631", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},

        },            

    }, 
    -- 罗珊(燃情舞娘)高模
        ["1306_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 3.2, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 10, name = "scenes_1306_appearance", bone = "", speed = 1 , is_coexist = true},
                {type = "camera", time = 0, duration = 3.7, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
                -- {type = "effect", time = 0, duration = 10, name = "scenes_1301_appearance_02", bone = "Bip001 L Finger01", speed = 1 , is_coexist = true},
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 1.667, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 1.667, name = "pose2", speed = 1},
            },
        },


-- -- 

-- --  蛮荒
-- 1121011 卡奥斯(裂地蛮蹄)-正式
    ["2101"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Born", speed = 1},
            {type = "effect", time = 0, duration =2.5 , name = "scenes_2101_born", bone = "", speed = 1 , is_coexist = true},
            --  {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Death", speed = 1},
            {type = "shader", time = 2.2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3.067, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.867, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.267, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.3, name = "FloatingDown", speed = 1.3},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_210101_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 2, name = "JN-1102-110201-1", speed = 1, volume = 0.8, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_210102_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 2, name = "JN-1102-110201-1", speed = 0.8, volume = 0.8, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 1.967, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "skill_210111_route1", bone = "", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_210111_route3", bone = "RightWeaponPos", speed = 1},
            --  {type = "camera", time = 0.6, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"},
            {type = "audio", time = 0, duration = 2.07, name = "JN-2101-210111", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "audio", time = 2.07, duration = 3.5, name = "JN-2101-210111-run", speed = 0.8, volume = 1, bloop = true, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 3.333, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "skill_210121_route1", bone = "", speed = 1},
            {type = "effect", time = 0, duration = 2.5, name = "skill_210121_route2", bone = "", speed = 1},
            {type = "camera", time = 1.3, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"},
            {type = "audio", time = 0, duration = 2.5, name = "JN-2101-210121", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_210131_route1", bone = "RightFootPos", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_210131_route2", bone = "", speed = 1, is_coexist = true},
            {type = "camera", time = 0.7, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3"},
            {type = "audio", time = 0, duration = 2.7, name = "JN-2101-210131", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    -- 卡奥斯(裂地蛮蹄)高模
        ["2101_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 5.3, name = "Appearance", speed = 1},
                --  {type = "effect", time = 0, duration = 4, name = "scenes_2101_appearance", bone = "", speed = 1 , is_coexist = true},
                {type = "effect", time = 0.75, duration = 3, name = "scenes_2101_appearance_01", bone = "", speed = 1 , is_coexist = true},
                {type = "effect", time = 2, duration = 3, name = "scenes_2101_appearance_02", bone = "", speed = 1 , is_coexist = true},
                {type = "effect", time = 2, duration = 3, name = "scenes_2101_appearance_03", bone = "", speed = 1 , is_coexist = true},
                {type = "camera", time = 0, duration = 5.8, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
            },
        ["pose"] = {
                {type = "anim", time = 0, duration = 2.667, name = "Pose", speed = 1},
            },
        ["pose2"] = {
                {type = "anim", time = 0, duration = 7.633, name = "Pose02", speed = 1},
                {type = "effect", time = 0.86, duration = 3, name = "scenes_2101_pose02", bone = "", speed = 1 , is_coexist = true},
            },
        },

-- 1121021 多鲁克(兽人蛮兵)-正式
    ["2102"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Stand", speed = 1},
            --  {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 0.933, name = "Death", speed = 1},
            {type = "shader", time = 2.2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 0.67},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.333, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 0.767, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1.367, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 0.8, name = "GetUp", speed = 0.8},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_210201_route1", bone = "", speed = 1, is_coexist = true},
            --  {type = "audio", time = 0, duration = 2, name = "JN-4302-430201-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.1, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_210202_route1", bone = "", speed = 1, is_coexist = true},
            --  {type = "audio", time = 0, duration = 2, name = "JN-4302-430201-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 0.933, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0.58, duration = 1.5, name = "skill_210211_route1", bone = "", speed = 1, is_coexist = true},
            {type = "camera", time = 0.6, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;3" }

        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 0.4, name = "Spell_01_Loop", speed = 1},
            {type = "audio", time = 0, duration = 1.1, name = "JN-2102-210211", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            --  {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3", is_coexist = true},
        },
        ["Spell_01_end"] = {
            {type = "anim", time = 0, duration = 0.667, name = "Spell_01_End", speed = 1},
            {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;3"}
        },
    },
    -- 多鲁克(兽人蛮兵)高模
        ["2102_ex"] = {
            ["appearance"] = {
                {type = "camera", time = 0, duration = 1.667, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
                {type = "anim", time = 0, duration = 1.667, name = "Appearance", speed = 1},
                 -- {type = "effect", time = 0, duration = 4, name = "scenes_2201_appearance", bone = "", speed = 1 , is_coexist = true},
            },
            ["pose"] = {
                    {type = "anim", time = 0, duration = 1.667, name = "Pose", speed = 1},
                },
            ["pose2"] = {
                    {type = "anim", time = 0, duration = 1.667, name = "Pose02", speed = 1},
                },
            },
-- 1121031 贝福特(钢轧狂徒)-正式
    ["2103"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 2.5, name = "scenes_2103_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Stand", speed = 1},
            --  {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Death", speed = 1},
            {type = "shader", time = 2.2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3.067, name = "Win", speed = 1},
        },
        ["empty"] = {
                {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.867, name = "Hit", speed = 2.5},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.85},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.233, name = "FloatingDown", speed =1.3},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.467, name = "Attack01", speed = 1},
            {type = "effect", time = 0.633, duration = 0.54, name = "skill_210301_route1", bone = "", speed = 1},
            {type = "audio", time = 0.633, duration = 1.2, name = "JN-2103-210301", speed = 1.1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.567, name = "Attack02", speed = 1},
            {type = "effect", time = 0.633, duration = 0.54, name = "skill_210302_route1", bone = "", speed = 1},
            {type = "audio", time = 0.633, duration = 1.2, name = "JN-2103-210302", speed = 1, volume = 0.4, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3.3, name = "Spell_01", speed = 1},
            {type = "effect", time = 0.97, duration = 3, name = "skill_210311_route1", bone = "", speed = 1},
            {type = "effect", time = 3, duration = 1.5, name = "buff_210311", bone = "", speed = 1,is_coexist= true},
            {type = "audio", time = 0.7, duration = 2.1, name = "JN-2103-210311", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            -- {type = "audio", time = 2.6, duration = 1.8, name = "Boss-7382-738221-hit", speed = 0.8, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
            {type = "camera", time = 2.6, duration = 0.5, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;5"}

        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 3, name = "Spell_02", speed = 1},
            {type = "effect", time = 1.24, duration = 1.5, name = "skill_210321_route1", bone = "RightWeaponPos", speed = 1},
            {type = "audio", time = 0, duration = 5, name = "JN-2103-210321", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Spell_03", speed = 1},
            {type = "audio", time = 0.2, duration = 1.8, name = "JN-2103-210331", speed = 1, volume = 0.7, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            -- {type = "camera", time = 1.2, duration = 0.5, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;5"}
         
        },
        ["spell_04"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Spell_04", speed = 1},
            {type = "effect", time = 2.4, duration = 1, name = "skill_210351_route1", bone = "ChestPos", speed = 1},
            --  {type = "effect", time = 2.57, duration = 1, name = "skill_210352_route2", bone = "", speed = 1},
            {type = "effect", time = 2.37, duration = 2, name = "skill_210352_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1.8, name = "JN-2103-210351", speed = 1, volume = 0.7, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},


        },
    },
    -- 贝福特(钢轧狂徒)高模
     ["2103_ex"] = {
        ["appearance"] = {
            {type = "anim", time = 0, duration = 5.833, name = "Appearance", speed = 1},
            {type = "effect", time = 4.75, duration = 0.75, name = "scenes_2103_appearance_01", bone = "", speed = 1 , is_coexist = false},
            {type = "effect", time = 3.05, duration = 0.42, name = "scenes_2103_appearance_02", bone = "", speed = 1 , is_coexist = false},
            {type = "effect", time = 4.4, duration = 1.2, name = "scenes_2103_appearance_03", bone = "", speed = 1 , is_coexist = false},
            {type = "effect", time = 0.35, duration = 0.63, name = "scenes_2103_appearance_04", bone = "", speed = 1 , is_coexist = false},
            {type = "effect", time = 4.5, duration = 0.7, name = "scenes_2103_appearance_06", bone = "RightWeaponPos", speed = 1 , is_coexist = false},
            {type = "camera", time = 0, duration = 6.3, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
        },
        ["pose"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Pose", speed = 1},
        },
        ["pose2"] = {
            {type = "anim", time = 0, duration = 7.633, name = "Pose02", speed = 1},
        },
        },
-- 1121041 阿拉沃(暗鳞暴徒)-正式
    ["2104"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 3.333, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "scenes_2104_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.6, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.033, name = "Death", speed = 1},
            {type = "shader", time = 2.2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3, name = "Win", speed = 1},
        },
        ["empty"] = {
                {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 1.033, name = "Hit", speed = 2.58},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.233, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.267, name = "Attack01", speed = 1},
            {type = "effect", time = 0.63, duration = 1, name = "skill_210401_route1", bone = "", speed = 1},
            {type = "audio", time = 0.63, duration = 2, name = "JN-2104-210401", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.267, name = "Attack02", speed = 1},
            {type = "effect", time = 0.63, duration = 1, name = "skill_210402_route1", bone = "", speed = 1},
            {type = "audio", time = 0.63, duration = 2, name = "JN-2104-210401", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

            
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3.4, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 3.4, name = "skill_210411_route1", bone = "", speed = 1},
            {type = "effect", time = 2.4, duration = 2, name = "skill_210412_route1", bone = "", speed = 1},
            {type = "audio", time = 0.5, duration = 3.4, name = "JN-2104-210411", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            {type = "camera", time = 2.4, duration = 0.3, name = "shake", params = "0;1;0;0.1;3"},
        },
        ["spell_02_start"] = {
            {type = "anim", time = 0, duration = 0.533, name = "Spell_02_Begin", speed = 1},
            {type = "effect", time = 0, duration = 2.4, name = "skill_210422_route1", bone = "Eyepos", speed = 1},
            {type = "audio", time = 0, duration = 3.4, name = "JN-2104-210421", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_02_loop_01"] = {
            {type = "anim", time = 0, duration = 10, name = "Spell_02_Loop1", speed = 1},
            {type = "effect", time = 0, duration = 2.4, name = "skill_210421_route1", bone = "", speed = 1},

        },
        ["spell_02_stop"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Spell_02_02", speed = 1},

        },
        ["spell_02_loop_02"] = {
            {type = "anim", time = 0, duration = 10, name = "Spell_02_Loop2", speed = 1},
            {type = "effect", time = 0, duration = 2.4, name = "skill_210421_route1", bone = "", speed = 1},

        },
        ["spell_02_end"] = {
            {type = "anim", time = 0, duration = 0.667, name = "Spell_02_End", speed = 1},

        },
    },
    -- 阿拉沃(暗鳞暴徒)高模
        ["2104_ex"] = {
        ["appearance"] = {
            {type = "anim", time = 0, duration = 7.5, name = "Appearance", speed = 1},
            {type = "effect", time = 1.7, duration = 1.5, name = "scenes_2104_appearance", bone = "", speed = 1 , is_coexist = true},
            {type = "camera", time = 0, duration = 8, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

        },
        ["pose"] = {
                {type = "anim", time = 0, duration = 2.4, name = "Pose", speed = 1},
        },
        ["pose2"] = {
                {type = "anim", time = 0, duration = 2.4, name = "Pose02", speed = 1},
        },
        },
-- 1121051 伽罗格(钢鬃岩卫)-正式
    ["2105"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 2.33, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "scenes_2105_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Death", speed = 1},
            {type = "shader", time = 2.2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3.067, name = "Win", speed = 1},
        },
        ["empty"] = {
                {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.867, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.267, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.233, name = "FloatingDown", speed =1.3},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1.267, name = "GetUP", speed = 1.267},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.3, name = "Attack_01", speed = 1},
            {type = "effect", time = 0.63, duration = 1, name = "skill_210501_route1", bone = "", speed = 1},
            {type = "audio", time = 0.63, duration = 1, name = "JN-2105-210501", speed = 1, volume = 0.7, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.6, name = "Attack_02", speed = 1},
            {type = "effect", time = 0.6, duration = 1, name = "skill_210502_route1", bone = "", speed = 1},
            {type = "audio", time = 0.6, duration = 1, name = "JN-2105-210501", speed = 1, volume = 0.7, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 0.667, name = "Spell_01_Begin", speed = 1},
            {type = "audio", time = 0, duration = 2, name = "JN-2105-210511-begin", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},

        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 10, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 0, duration = 10, name = "skill_210511_loop", bone = "", speed = 1},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 1.867, name = "Spell_01_End", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "skill_210511_route", bone = "", speed = 1},
            {type = "camera", time = 0, duration = 0.5, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;5"},
            {type = "audio", time = 0, duration = 2, name = "JN-2105-210511-attack", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},

        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 3.467, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "skill_210521_route1", bone = "", speed = 1},
            {type = "effect", time = 2.4, duration = 4, name = "skill_210521_route2", bone = "", speed = 1},
            {type = "camera", time = 2.4, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.4;0;0.1;3"},  
            {type = "audio", time = 0.6, duration = 5, name = "JN-2105-210521", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["spell_03_start"] = {
            {type = "anim", time = 0, duration = 1.033, name = "Spell_03_Begin", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "skill_210531_route", bone = "", speed = 1,is_coexist = true},

            
        },
        ["spell_03_loop"] = {
            {type = "anim", time = 0, duration = 5, name = "Spell_03_Loop", speed = 1},
        },
    },
    -- 伽罗格(钢鬃岩卫)高模
     ["2105_ex"] = {
        ["appearance"] = {
            {type = "anim", time = 0, duration = 5.733, name = "Appearance", speed = 1},
            {type = "effect", time = 0, duration = 6, name = "scenes_2105_appearance_01", bone = "", speed = 1 , is_coexist = false},
            {type = "camera", time = 0, duration = 6.2, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

        },
        ["pose"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Pose", speed = 1},
        },
        ["pose2"] = {
            {type = "anim", time = 0, duration = 7.633, name = "Pose02", speed = 1},
        },
        },
-- 1122011 戈尔(潜影血爪)-正式
    ["2201"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.433, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_2201_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.033, name = "Death", speed = 1},
            {type = "shader", time = 2.2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.767, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.2, name = "LieHit", speed = 0.44},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 0.533, name = "FloatingDown", speed = 0.533},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 0.533, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 0.8, name = "GetUp", speed = 0.8},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.733, name = "Attack", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_220101_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 2, name = "JN-2201-220101", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "effect", time = 0.34, duration = 1, name = "skill_220101_route2", bone = "", speed = 1},
            {type = "audio", time = 0.34, duration = 2, name = "JN-2201-220102", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            --  {type = "effect", time = 1.11, duration = 1, name = "skill_220101_route3", bone = "", speed = 1},
            --  {type = "audio", time = 1.11, duration = 2, name = "JN-2201-220103", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 0.9, name = "Attack02", speed = 1},
            {type = "effect", time = 0.2, duration = 1, name = "skill_220101_route3", bone = "", speed = 1},
            {type = "audio", time = 0.2, duration = 2, name = "JN-2201-220103", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 2.333, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 2.333, name = "skill_220111_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 6, name = "JN-2201-220111", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            -- {type = "shader", time = 2.333, name = "Death",   duration = 0.5, params = "0.025"},
            -- {type = "shader", time = 4.383, name = "Born", duration = 0.5, params = "0.025", is_coexist = true}
            -- {type = "shader", time = 2.333, name = "Hide", duration = 2.35, params = ""},
            --  {type = "camera", time = 0.9, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3"},
            --  {type = "camera", time = 1.3, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.05;0;0.1;10"},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 0.733, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_220121_route1", bone = "", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 1.5, name = "skill_220121_route2", bone = "", speed = 1, is_coexist = true},
            {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3", is_coexist = true},
            {type = "audio", time = 0, duration = 1, name = "JN-2201-220121", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.933, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 0.7, name = "skill_220131_route2", bone = "", speed = 1},
            {type = "effect", time = 0.37, duration = 0.7, name = "skill_220131_route1", bone = "", speed = 1},
            {type = "effect", time = 0.633, duration = 0.7, name = "skill_220131_route2", bone = "", speed = 1},
            {type = "effect", time = 0.97, duration = 0.7, name = "skill_220131_route1", bone = "", speed = 1},
            
            --  {type = "effect", time = 1.3, duration = 0.7, name = "skill_220131_route2", bone = "", speed = 1},
            {type = "audio", time = 0.1, duration = 4, name = "JN-2201-220131", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    -- 戈尔(潜影血爪)高模
        ["2201_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 3.5, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 4, name = "scenes_2201_appearance", bone = "", speed = 1 , is_coexist = true},
                {type = "camera", time = 0, duration = 4, name = "bone", params = "camera_bone;2.3;4.1;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

            },
        ["pose"] = {
                {type = "anim", time = 0, duration = 1.667, name = "Pose", speed = 1},
            },
        ["pose2"] = {
                {type = "anim", time = 0, duration = 3.633, name = "Pose02", speed = 1},
            },
        },
    -- 戈尔(潜影血爪)精英怪
        ["2251"] = {
            ["attack01"] = {
                {type = "anim", time = 0, duration = 1.833, name = "Attack", speed = 1},
            },
            ["born_battle"] = {
                {type = "anim", time = 0, duration = 1.433, name = "Born", speed = 1},
                {type = "effect", time = 0, duration = 1, name = "scenes_2201_born", bone = "", speed = 1 , is_coexist = true},
                -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
                -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
            },
            ["born_hangup"] = {
                {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
                {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
                -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
                {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
            },
            ["dead"] = {
                {type = "anim", time = 0, duration = 2.033, name = "Death", speed = 1},
                {type = "shader", time = 2.2, name = "Death", duration = 1.5, params = ""},
            },
            ["dizzy"] = {
                {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            },
            ["floatingdown"] = {
                {type = "anim", time = 0, duration = 1.233, name = "FloatingDown", speed = 0.533},
            },
            ["floatingup"] = {
                {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
            },
            ["getup"] = {
                {type = "anim", time = 0, duration = 0.8, name = "GetUp", speed = 1},
            },
            --  ["freeze"] = {
            --      {type = "anim", time = 0, duration = 0.167, name = "Freeze", speed = 1},
            --  },
            ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
            ["hit"] = {
                {type = "anim", time = 0, duration = 0.767, name = "Hit", speed = 2},
            },
            ["liehit"] = {
                {type = "anim", time = 0, duration = 0.2, name = "LieHit", speed = 1.55},
            },
            --  ["lost"] = {
            --      {type = "anim", time = 0, duration = 2.1, name = "Lost", speed = 1},
            --  },
            --  ["pose"] = {
            --      {type = "anim", time = 0, duration = 2.667, name = "Pose", speed = 1},
            --  },
            ["run"] = {
                {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
            },
            ["spell_01"] = {
                {type = "anim", time = 0, duration = 2.333, name = "Spell_01", speed = 1},
                -- {type = "shader", time = 2.333, name = "Death", duration = 0.5, params = "0.025"},
                -- {type = "shader", time = 4.383, name = "Born", duration = 0.5, params = "0.025", is_coexist = true}
                {type = "shader", time = 2.833, name = "Hide", duration = 2.35, params = ""},
                {type = "camera", time = 0.9, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3"},
                {type = "camera", time = 1.3, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.05;0;0.1;10"}

            },
            ["spell_02"] = {
                {type = "anim", time = 0, duration = 0.733, name = "Spell_02", speed = 1},
            },
            ["spell_03"] = {
                {type = "anim", time = 0, duration = 1.933, name = "Spell_03", speed = 1},
            },
            --  ["spell_04"] = {
            --      {type = "anim", time = 0, duration = 1.8, name = "Spell_04", speed = 1},
            --  },
            ["stand"] = {
                {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
            },
            --  ["win"] = {
            --      {type = "anim", time = 0, duration = 3, name = "Win", speed = 1},
            --  },
        },

-- 1122021 卡丽(血灵之翼)-正式
    ["2202"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 3, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_220241_route1", bone = "", speed = 1 , is_coexist = true},
            {type = "effect", time = 0, duration = 3, name = "skill_220231_route1", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
            --  {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.067, name = "Death", speed = 1},
            {type = "shader", time = 2.2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 2.933, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 1, name = "Hit", speed = 2.5},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.167, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 0.8, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.8, name = "Attack01", speed = 1},
            --  {type = "effect", time = 0.5, duration = 1, name = "skill_220201_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1.21, name = "JN-2202-220201", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Attack02", speed = 1},
            --  {type = "effect", time = 0.5, duration = 1, name = "skill_220202_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1.21, name = "JN-2202-220201", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 2.5, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 2.5, name = "skill_220211_route1", bone = "", speed = 1,is_coexist = true},
            {type = "camera", time = 1.06, duration = 0.5, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1.2;0;0.1;5"},
            {type = "audio", time = 0, duration = 3, name = "JN-2202-220211", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "audio", time = 0, duration = 2.5, name = "JN-2202-220211-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 1.67, name = "skill_220231_route1", bone = "", speed = 1},
            --  {type = "effect", time = 0, duration = 1.67, name = "skill_220231_route2", bone = "ChestPos", speed = 1},
            {type = "audio", time = 0.1, duration = 4, name = "JN-2202-220231", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_04_start"] = {
            {type = "anim", time = 0, duration = 1.833, name = "Spell_04_Begin", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_220241_route1", bone = "", speed = 1},
            --  {type = "camera", time = 0.4, duration = 0.5, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;5"},
            {type = "audio", time = 0.1, duration = 4, name = "JN-2202-220241", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_04_loop"] = {
            {type = "anim", time = 0, duration = 1.833, name = "Spell_04_Loop", speed = 1},
            --  {type = "effect", time = 0, duration = 1, name = "skill_220241_route1", bone = "", speed = 1},
            --  {type = "camera", time = 0.4, duration = 0.5, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;5"},
        },
        ["spell_04_end"] = {
            {type = "anim", time = 0, duration = 1.833, name = "Spell_04_End", speed = 1},
            --  {type = "effect", time = 0, duration = 1, name = "skill_220241_route1", bone = "", speed = 1},
            --  {type = "camera", time = 0.4, duration = 0.5, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;5"},
        },
    },
    -- 卡丽(血灵之翼)高模
        ["2202_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 5.5, name = "Appearance", speed = 1},
                {type = "effect", time = 2, duration = 2, name = "scenes_2202_appearance_01", bone = "", speed = 1 },
                {type = "effect", time = 0, duration = 2.5, name = "scenes_2202_appearance_02", bone = "PelvisPos", speed = 1 },
                {type = "camera", time = 0, duration = 6, name = "bone", params = "camera_bone;1.5;4.0;1;2"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

            },
            ["pose"] = {
                    {type = "anim", time = 0, duration = 1.333, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 3.667, name = "Pose02", speed = 1},
                {type = "effect", time = 0, duration = 9, name = "scenes_2202_pose02", bone = "ChestPos", speed = 1 , is_coexist = true},
            },
        },

-- 1122031 希莱雅(边陲之矛)-正式
    ["2203"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 2.433, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 3.5, name = "scenes_2203_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.6, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.033, name = "Death", speed = 1},
            {type = "shader", time = 2.2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.767, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.133, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.267, name = "Attack01", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-2203-220301", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 1.867, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_220311_route1", bone = "", speed = 1},
            {type = "effect", time = 0.4, duration = 2.5, name = "skill_220311_route2", bone = "", speed = 1,is_coexist=true},
            {type = "effect", time = 1.4, duration = 2.5, name = "skill_220311_route3", bone = "", speed = 1,is_coexist=true},
            {type = "effect", time = 0.2, duration = 3, name = "skill_220311_route4", bone = "", speed = 1,is_coexist=true},
            --  {type = "effect", time = 0, duration = 2, name = "skill_220311_route5", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 4, name = "JN-2203-220311", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist= true},


        },
    },
    -- 希莱雅(边陲之矛)高模
        ["2203_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 4.3, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 4, name = "scenes_2203_appearance1", bone = "", speed = 1 },
                {type = "effect", time = 0, duration = 4, name = "scenes_2203_appearance2", bone = "", speed = 1 },
                {type = "camera", time = 0, duration = 5, name = "bone", params = "camera_bone;1.5;4.1;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
            },
            ["pose"] = {
                    {type = "anim", time = 0, duration = 2.4, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                    {type = "anim", time = 0, duration = 2.4, name = "Pose02", speed = 1},
            },
        },
-- 1122041 帖纳伦(烈风乌骓)-正式
    ["2204"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 3.333, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "scenes_2204_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Death", speed = 1},
            {type = "shader", time = 2.2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3.067, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.867, name = "Hit", speed = 1.25},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.26},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.4, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 0.9, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1.333, name = "GetUp", speed = 1.333},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.2, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_220401_route1", bone = "", speed = 1},
            {type = "audio", time = 0.7, duration = 1, name = "JN-3201-10001-2", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.267, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_220402_route1", bone = "", speed = 1},
            {type = "audio", time = 0.6, duration = 1, name = "JN-3201-10001-2", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3.2, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 2.6, name = "skill_220411_route1", bone = "", speed = 1},
            --  {type = "audio", time = 0, duration = 1.5, name = "JN-3201-10006-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            --  {type = "audio", time = 0, duration = 2, name = "JN-3201-10002-1", speed = 2, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            --  {type = "audio", time = 1.5, duration = 1, name = "JN-3201-10002-2", speed = 2, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            --  {type = "audio", time = 1.6, duration = 1, name = "JN-3201-10002-2", speed = 2, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            --  {type = "audio", time = 1.7, duration = 1, name = "JN-3201-10002-2", speed = 2, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            --  {type = "audio", time = 1.8, duration = 1, name = "JN-3201-10002-2", speed = 2, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            --  {type = "audio", time = 1.9, duration = 1, name = "JN-3201-10002-2", speed = 2, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            {type = "audio", time = 0, duration = 5, name = "JN-2204-220411", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 2.5, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "skill_220421_route1", bone = "", speed = 1},
            {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3"},
            {type = "audio", time = 0, duration = 3, name = "JN-2204-220421", speed = 1.2, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true}, 
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.933, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "skill_220431_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 5, name = "JN-2204-220431", speed = 1, volume = 1.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

        },
    },
    -- 帖纳伦(半人马女射手)高模
        ["2204_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 4.7, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 4.7, name = "scenes_2204_appearance_01", bone = "", speed = 1 },
                {type = "camera", time = 0, duration = 5.2, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
            },
            ["pose"] = {
                    {type = "anim", time = 0, duration = 1.467, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                    {type = "anim", time = 0, duration = 4.1, name = "Pose02", speed = 1},
            },
        },
-- 1122051 乌列尔（午夜凶兽）-非正式
    ["2205"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 3.333, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "scenes_2204_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Death", speed = 1},
            {type = "shader", time = 2.2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3.067, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.867, name = "Hit", speed = 1.25},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.26},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.4, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 0.9, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1.333, name = "GetUp", speed = 1.333},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.2, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_220401_route1", bone = "", speed = 1},
            {type = "audio", time = 0.7, duration = 1, name = "JN-3201-10001-2", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.267, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_220402_route1", bone = "", speed = 1},
            {type = "audio", time = 0.6, duration = 1, name = "JN-3201-10001-2", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3.2, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 2.6, name = "skill_220411_route1", bone = "", speed = 1},
            --  {type = "audio", time = 0, duration = 1.5, name = "JN-3201-10006-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            --  {type = "audio", time = 0, duration = 2, name = "JN-3201-10002-1", speed = 2, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            --  {type = "audio", time = 1.5, duration = 1, name = "JN-3201-10002-2", speed = 2, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            --  {type = "audio", time = 1.6, duration = 1, name = "JN-3201-10002-2", speed = 2, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            --  {type = "audio", time = 1.7, duration = 1, name = "JN-3201-10002-2", speed = 2, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            --  {type = "audio", time = 1.8, duration = 1, name = "JN-3201-10002-2", speed = 2, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            --  {type = "audio", time = 1.9, duration = 1, name = "JN-3201-10002-2", speed = 2, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            {type = "audio", time = 0, duration = 5, name = "JN-2204-220411", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 2.5, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "skill_220421_route1", bone = "", speed = 1},
            {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3"},
            {type = "audio", time = 0, duration = 3, name = "JN-2204-220421", speed = 1.2, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true}, 
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.933, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "skill_220431_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 5, name = "JN-2204-220431", speed = 1, volume = 1.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

        },
    },
    -- 帖纳伦(半人马女射手)高模
        ["2205_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 4.7, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 4.7, name = "scenes_2204_appearance_01", bone = "", speed = 1 },
                {type = "camera", time = 0, duration = 5.2, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
            },
            ["pose"] = {
                    {type = "anim", time = 0, duration = 1.467, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                    {type = "anim", time = 0, duration = 4.1, name = "Pose02", speed = 1},
            },
        },
-- 1123011 巴尔金(异界炎徒)-正式
    ["2301"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 3.333, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 2.5, name = "scenes_2301_born", bone = "", speed = 1 , is_coexist = true},
            --  {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.933, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.6, name = "Death", speed = 1},
            {type = "shader", time = 2.2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3.333, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.233, name = "FloatingDown", speed = 0.75},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.567, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_230101_route1", bone = "RightWeaponPos", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-2301-230101", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_230102_route1", bone = "LeftWeaponPos", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-2301-230101", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0, duration = 0.8, name = "skill_230111_route1", bone = "LeftHandPos", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 0.8, name = "skill_230111_route1_1", bone = "RightHandPos", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 0.8, name = "skill_230111_route2", bone = "", speed = 1, is_coexist = true},
            {type = "audio", time = 0, duration = 6, name = "JN-2301-230111-Begin", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 4, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 0, duration = 4.2, name = "skill_230111_route3", bone = "", speed = 1 },
            {type = "audio", time = 0, duration = 4, name = "JN-2301-230111-Loop", speed = 0.8, volume = 1, bloop = true, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 1.1, name = "Spell_01_End", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-2301-230111-attack", speed = 0.8, volume = 1, bloop = true, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            {type = "effect", time = 0, duration = 1, name = "skill_230111_route5", bone = "", speed = 1},
            {type = "camera", time = 0.2, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1.2;0;0.1;3"},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.4, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_230131_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1.5, name = "JN-2301-230131-Begin", speed = 0.8, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP ,is_coexist = true},
            {type = "audio", time = 0.5, duration = 1.5, name = "JN-2301-230131-Loop", speed = 1, volume = 1, bloop = true, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
    },
    -- 巴尔金(异界炎徒)高模
        ["2301_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 3.8, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 4, name = "scenes_2301_appearance01", bone = "", speed = 1 },
                {type = "effect", time = 0, duration = 4, name = "scenes_2301_appearance02", bone = "", speed = 1 },
                {type = "camera", time = 0, duration = 5.3, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
            },
            ["pose"] = {
                    {type = "anim", time = 0, duration = 1.467, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                    {type = "anim", time = 0, duration = 4.1, name = "Pose02", speed = 1},
            },
        },

-- 1123021 拉佐玛(异界雷婆)-正式
    ["2302"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 3.333, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "scenes_2302_born", bone = "RightWeaponPos", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
            --  {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.933, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.6, name = "Death", speed = 1},
            {type = "shader", time = 2.2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3.333, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.567, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.233, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.633, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_230201_route1", bone = "RightWeaponPos", speed = 1},
            {type = "audio", time = 0.5, duration = 2, name = "JN-3201-10003-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.633, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_230201_route1", bone = "RightWeaponPos", speed = 1},
            {type = "audio", time = 0.3, duration = 2, name = "JN-3201-10003-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3, name = "Spell_01", speed = 1},
            {type = "effect", time = 0.8, duration = 4, name = "skill_230211_route1", bone = "RightWeaponPos", speed = 1, is_coexist = true},
            {type = "audio", time = 0, duration = 6, name = "JN-2302-230211", speed = 1, volume = 0.7, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 1.63, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_230221_route1", bone = "RightWeaponPos", speed = 1},
            -- {type = "audio", time = 0.1, duration = 4, name = "JN-BR-10003-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    -- 拉佐玛(异界雷婆)高模
        ["2302_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 5.167, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 6, name = "scenes_2302_appearance_01", bone = "", speed = 1, },
                {type = "effect", time = 0, duration = 6, name = "scenes_2302_appearance_02", bone = "RightWeaponPos", speed = 1,},

                {type = "camera", time = 0, duration = 5.7, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
                --  {type = "effect", time = 0, duration = 6, name = "scenes_2302_appearance_02", bone = "RightWeaponPos", speed = 1, is_coexist = true },
            },
            ["pose"] = {
                    {type = "anim", time = 0, duration = 1.467, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                    {type = "anim", time = 0, duration = 4.1, name = "Pose02", speed = 1},
            },
        },

-- 1123031 洛卡卡(鼠人祭师)-正式
    ["2303"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.567, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.933, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.6, name = "Death", speed = 1},
            {type = "shader", time = 2.2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3.333, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Hit", speed = 2.5},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.233, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1.5, name = "GetUp", speed = 1.5},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1.533, name = "skill_230301_route1", bone = "RightWeaponPos", speed = 1},
            {type = "audio", time = 0.66, duration = 1, name = "JN-1301-10002-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 1.533, name = "skill_230301_route1", bone = "RightWeaponPos", speed = 1},
            {type = "audio", time = 0.8, duration = 1, name = "JN-1301-10002-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 4.333, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 4.333, name = "skill_230311_route1", bone = "RightWeaponPos", speed = 1, is_coexist = true},
            {type = "audio", time = 0, duration = 6, name = "JN-2303-230311", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 2, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_230321_route1", bone = "", speed = 1},
            -- {type = "audio", time = 0.1, duration = 4, name = "JN-BR-10003-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    -- 洛卡卡(鼠人祭师)高模
        ["2303_ex"] = {
            ["appearance"] = {
                {type = "camera", time = 0, duration = 2, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
                {type = "anim", time = 0, duration = 2, name = "Appearance", speed = 1},
            },
            ["pose"] = {
                    {type = "anim", time = 0, duration = 1.467, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                    {type = "anim", time = 0, duration = 4.1, name = "Pose02", speed = 1},
            },
        },
-- 1123041 卡纳耶娃(丰饶牧首)-正式、
    ["2304"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 3.333, name = "Born", speed = 1},
            -- {type = "effect", time = 0, duration = 2.5, name = "scenes_2304_born", bone = "", speed = 1 , is_coexist = true},
            --  {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.933, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.6, name = "Death", speed = 1},
            {type = "shader", time = 2.2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3.333, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.233, name = "FloatingDown", speed = 0.75},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "skill_230401_route1", bone = "", speed = 1},
            -- {type = "effect", time = 0, duration = 1.5, name = "skill_230401_route2", bone = "group019", speed = 1},
            -- {type = "audio", time = 0, duration = 1, name = "JN-2304-230401", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 2, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_230402_route1", bone = "", speed = 1},
            -- {type = "effect", time = 0, duration = 1.5, name = "skill_230401_route2", bone = "group019", speed = 1},
            -- {type = "audio", time = 0, duration = 1, name = "JN-2304-230401", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 2.167, name = "Spell_01", speed = 1},
            {type = "camera", time = 1.5,   duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3",is_coexist=true},
            {type = "effect", time = 0, duration = 3, name = "skill_230411_route1", bone = "", speed = 1,is_coexist = true},
            {type = "effect", time = 0, duration = 4, name = "skill_230411_route2", bone = "RightFingerPos", speed = 1,is_coexist = true},
            {type = "audio", time = 0, duration = 6, name = "JN-2304-230411", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 2.167, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_230421_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 6, name = "JN-2304-230422", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            -- {type = "camera1", time = 0.2, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1.2;0;0.1;3"},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.433, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_230431_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 6, name = "JN-2304-230431", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
    },
    -- 卡纳耶娃(丰饶牧首)高模
        ["2304_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 7, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 7, name = "scenes_2304_appearance_01", bone = "", speed = 1 },
                {type = "effect", time = 0, duration = 6, name = "scenes_2304_appearance_02", bone = "RightHandPos", speed = 1 },
                {type = "effect", time = 0, duration = 6, name = "scenes_2304_appearance_02", bone = "LeftHandPos", speed = 1 },
                {type = "camera", time = 0, duration = 9.8, name = "bone", params = "camera_bone;2.0;3.5;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
            },
            ["pose"] = {
                    {type = "anim", time = 0, duration = 1.467, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                    {type = "anim", time = 0, duration = 4.1, name = "Pose02", speed = 1},
            },
        },
    -- 治疗图腾
        ["8007"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 1.167, name = "Born", speed = 1},
                {type = "camera", time = 0,   duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3",is_coexist=true},
                {type = "effect", time = 0, duration = 2, name = "common_appearance", bone = "", speed = 1, is_coexist = true },
                {type = "audio", time = 0, duration = 6, name = "JN-2304-230421", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            },
            ["stand"] = {
                {type = "anim", time = 0, duration = 1.067, name = "Stand", speed = 1},
            },
            ["dead"] = {
                {type = "anim", time = 0, duration = 1.2, name = "Death", speed = 1},
                {type = "shader", time = 1, name = "Death", duration = 0.5, params = ""},
            },
        },
    -- 嘲讽图腾
        ["8008"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 1.167, name = "Born", speed = 1},
                {type = "camera", time = 0,   duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3",is_coexist=true},
                {type = "effect", time = 0, duration = 2, name = "common_appearance", bone = "", speed = 1, is_coexist = true },
                {type = "audio", time = 0, duration = 6, name = "JN-2304-230421", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            },
            ["stand"] = {
                {type = "anim", time = 0, duration = 1.067, name = "Stand", speed = 1},
            },
            ["dead"] = {
                {type = "anim", time = 0, duration = 1.2, name = "Death", speed = 1},
                {type = "shader", time = 1, name = "Death", duration = 0.5, params = ""},
            },
            ["dead_ex"] = {
                {type = "anim", time = 0, duration = 1.2, name = "Death", speed = 1},
                {type = "shader", time = 1, name = "Death", duration = 0.5, params = ""},
            },
        },
-- -- 

-- --  自然
-- 1131011 克拉通(晶岩原核)-正式
    ["3101"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_3201_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.2, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.633, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.867, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.333, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.233, name = "FloatingDown", speed =1.3},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1.033, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.8, name = "Attack01", speed = 1},
            {type = "effect", time = 0.93, duration = 2, name = "skill_310101_route1", bone = "", speed = 1,is_coexist = true},
            {type = "audio", time = 0.93, duration = 3.6, name = "JN-3101-310101", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.867, name = "Attack02", speed = 1},
            {type = "effect", time = 0.83, duration = 2, name = "skill_310102_route1", bone = "", speed = 1,is_coexist = true},
            {type = "audio", time = 0.83, duration = 4, name = "JN-3101-310101", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_310111_route1", bone = "", speed = 1 , is_coexist = true},
            {type = "audio", time = 0, duration = 11 , name = "JN-3101-310111", speed = 1, volume = 1.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            {type = "camera", time = 1.7,   duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3",is_coexist=true},
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 20, name = "Spell_01_Loop", speed = 1},
            {type = "camera", time = 0.4,   duration = 10, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.08;0;0.1;100"},
            --  {type = "camera", time = 10,   duration = 5, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.0.04;0;0.1;50",is_coexist=true},
            --  {type = "effect", time = 0, duration = 20, name = "skill_310111_route2", bone = "LeftWeaponPos", speed = 1 , is_coexist = true},
            --  {type = "audio", time = 0, duration = 5, name = "JN-3201-10006-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 0.633, name = "Spell_01_End", speed = 1},
            
            -- {type = "audio", time = 0, duration = 5, name = "JN-3201-10006-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 2, name = "Spell_02", speed = 1},
            {type = "effect", time = 0.63, duration = 1.5, name = "skill_310121_route1", bone = "", speed = 1},
            {type = "effect", time = 0.33, duration = 2, name = "skill_310121_route2", bone = "LeftHandPos", speed = 1},
            {type = "effect", time = 0.33, duration = 2, name = "skill_310121_route2", bone = "RightHandPos", speed = 1},
            {type = "audio", time = 0.33, duration = 1.13, name = "JN-3101-310121", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.467, name = "stand", speed = 1},
            {type = "effect", time = 0, duration = 1.3, name = "skill_310131_route1", bone = "", speed = 1  , is_coexist = true},
            {type = "effect", time = 0, duration = 1.3, name = "skill_310131_route4", bone = "", speed = 1  , is_coexist = true},-- 碎开
            {type = "effect", time = 4.70, duration = 3, name =  "skill_310131_route2", bone = "", speed = 1 , is_coexist = true},
            {type = "effect", time = 1, duration = 5, name =  "skill_310131_route3", bone = "", speed = 1  , is_coexist = true},
            {type = "effect", time = 1, duration = 5, name =  "skill_310131_route5", bone = "", speed = 1 , is_coexist = true},-- 重组
            {type = "effect", time = 1.05, duration = 5, name =  "skill_310131_route6", bone = "", speed = 1 , is_coexist = true},-- 重组  
            {type = "audio", time = 0, duration = 3.23, name = "JN-3101-310131", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_03_stand"] = {
            {type = "anim", time = 0, duration = 2.067, name = "Spell03_stand", speed = 0.7},
            {type = "audio", time = 0, duration = 1, name = "JN-3101-310131-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    -- 克拉通(人形泰坦)高模
        ["3101_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 8.3, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 7, name = "scenes_3101_appearance_01", bone = "", speed = 1 },
                {type = "effect", time = 6.1, duration = 3, name = "scenes_3101_appearance_02", bone = "Bone001", speed = 1 },
                {type = "camera", time = 0, duration = 8.8, name = "bone", params = "camera_bone;2.8;4.5;1;2.0"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2.677, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 8, name = "Pose02", speed = 1},
                {type = "effect", time = 0, duration = 8, name = "scenes_3101_pose02_01", bone = "", speed = 1 },
            },
        },

-- 1131021 巴奥(坚木卫士)-正式
    ["3102"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "scenes_3102_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["spell_02_stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Spell_02_Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.067, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1.1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "Getup", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 2, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_310201_route1", bone = "", speed = 1},
            {type = "audio", time = 1, duration = 1, name = "JN-3102-310221-attack", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.83, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 1.83, name = "skill_310202_route1", bone = "", speed = 1},
            {type = "audio", time = 1, duration = 1, name = "JN-3102-310221-attack", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },       
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 3.72, name = "skill_310211_route1", bone = "", speed = 1},
            --  {type = "effect", time = 2.8, duration = 5, name = "skill_310211_route2", bone = "", speed = 1 , is_coexist = true},
            {type = "audio", time = 0, duration = 2, name = "JN-3102-310211", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            {type = "audio", time = 2, duration = 1, name = "JN-3102-310211-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            -- {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"},
        },
        ["spell_02_start"] = {
            {type = "anim", time = 0, duration = 2.76, name = "Spell_02_Begin", speed = 1},
            {type = "effect", time = 0, duration = 2.76, name = "skill_310221_route1", bone = "", speed = 1, is_coexist = true},
            {type = "audio", time = 0, duration = 2, name = "JN-3102-310221", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_02_stand"] = {
            {type = "anim", time = 0, duration = 2, name = "Spell_02_Stand", speed = 1},
            -- {type = "audio", time = 0, duration = 5, name = "JN-3201-10006-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["attack03"] = {
            {type = "anim", time = 0, duration = 1.63, name = "Attack03", speed = 1},
            {type = "effect", time = 0, duration = 1.63, name = "skill_310203_route1", bone = "", speed = 1},
            {type = "audio", time = 1, duration = 1, name = "JN-3102-310221-attack", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["Spell_02_end"] = {
            {type = "anim", time = 0, duration = 2, name = "Spell_02_End", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_310203_route2", bone = "", speed = 1 , is_coexist = true},
            -- {type = "audio", time = 0, duration = 5, name = "JN-3201-10006-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_02_spell01"] = {
            {type = "anim", time = 0, duration = 3, name = "Spell_02_Spell01", speed = 1},
             --  {type = "effect", time = 0, duration = 3, name = "skill_310203_route3", bone = "", speed = 1 , is_coexist = true},
            {type = "effect", time = 0, duration = 2.76, name = "skill_310221_route1", bone = "", speed = 1 , is_coexist = true},
            -- {type = "audio", time = 0, duration = 5, name = "JN-3201-10006-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_02_spell03"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Spell_02_Spell03", speed = 1},
            --  {type = "effect", time = 0, duration = 1.7, name = "skill_310203_route4", bone = "", speed = 1},
            {type = "effect", time = 0, duration = 1.76, name = "skill_310231_route1", bone = "", speed = 1 , is_coexist = true},
            -- {type = "audio", time = 0, duration = 5, name = "JN-3201-10006-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.76, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 1.76, name = "skill_310231_route1", bone = "", speed = 1 , is_coexist = true},
          {type = "audio", time = 0.5, duration = 5, name = "JN-3102-310231", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

         },

     },
    -- 巴奥(坚木卫士)高模
        ["3102_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 7.833, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 6, name = "scenes_3102_appearance_01", bone = "", speed = 1 },
                {type = "camera", time = 0, duration = 8.5, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
                --  {type = "effect", time = 0, duration = 6, name = "scenes_3102_appearance_02", bone = "", speed = 1 },
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2.667, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 2.667, name = "Pose02", speed = 1},
            },
        },

-- 1131031 兰黛(精灵卫士)-正式
    ["3103"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_3201_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1.1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 0.867, name = "GetUp", speed = 0.867},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_310301_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-1203-120302", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 2.867, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 1.36, name = "skill_310311_route1", bone = "", speed = 1 ,},
            {type = "effect", time = 0, duration = 3, name = "skill_310311_route2", bone = "", speed = 1 ,},
            --  {type = "camera", time = 1, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.12;0;0.1;5"},
            --  {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.12;0;0.1;3"},
            {type = "camera", time = 2.0, duration = 0.5, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.5;0;0.1;3"},
             {type = "audio", time = 0.5, duration = 3, name = "JN-3103-310311", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    -- 兰黛(精灵卫士)高模
        ["3103_ex"] = {
            ["appearance"] = {
                {type = "camera", time = 0, duration = 0, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
                {type = "anim", time = 0, duration = 3.233, name = "Appearance", speed = 1},
                --  {type = "effect", time = 0, duration = 5, name = "scenes_3103_appearance", bone = "", speed = 1 , is_coexist = true},
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 1.667, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 3.133, name = "Pose02", speed = 1},
            },
        },
-- 1131041 波萨达(深海鳞卫)-正式
    ["3104"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Born", speed = 1},
            -- {type = "effect", time = 0, duration =2.5 , name = "scenes_3104_born", bone = "", speed = 1 , is_coexist = true},
            --  {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Death", speed = 1},
            {type = "shader", time = 2.2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3.067, name = "Win", speed = 1},
        }, 
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.867, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.267, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.3, name = "FloatingDown", speed = 1.3},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1.7, name = "skill_310401_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 2, name = "JN-3104-310401", speed = 1, volume = 0.8, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "skill_310401_route2", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 2, name = "JN-3104-310402", speed = 0.8, volume = 0.8, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3.2, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 3.2, name = "skill_310411_route1", bone = "", speed = 1},
            -- {type = "effect", time = 0, duration = 1, name = "skill_310411_route2", bone = "RightWeaponPos", speed = 1},
            --  {type = "camera", time = 0.6, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"},
            {type = "audio", time = 0, duration = 3.2, name = "JN-3104-310411-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "audio", time = 1, duration = 5, name = "JN-3104-310411-2", speed = 1, volume = 1, bloop = false,tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist= true},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 3.9, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 3.9, name = "skill_310421_route", bone = "", speed = 1},
            -- {type = "effect", time = 0, duration = 2.5, name = "skill_310421_route2", bone = "", speed = 1},
            -- {type = "camera", time = 1.3, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"},
            {type = "audio", time = 0, duration = 3.9, name = "JN-3104-310421", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 2.233, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 2.223, name = "skill_310431_route1", bone = "RightFootPos", speed = 1},
            -- {type = "camera", time = 0.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3"},
            {type = "audio", time = 0, duration = 9, name = "JN-3104-310431", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist= true},
        },
    },
    -- 波萨达(深海鳞卫)高模
        ["3104_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 6.3, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 6, name = "scenes_3104_appearance_01", bone = "", speed = 1 , is_coexist = true},
                -- {type = "effect", time = 2, duration = 3, name = "scenes_3104_appearance_02", bone = "", speed = 1 , is_coexist = true},
                -- {type = "effect", time = 2, duration = 3, name = "scenes_3104_appearance_03", bone = "", speed = 1 , is_coexist = true},
                {type = "camera", time = 0, duration = 5.8, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
            },
        ["pose"] = {
                {type = "anim", time = 0, duration = 2.667, name = "Pose", speed = 1},
            },
        ["pose2"] = {
                {type = "anim", time = 0, duration = 7.633, name = "Pose02", speed = 1},
                -- {type = "effect", time = 0.86, duration = 3, name = "scenes_3104_pose02", bone = "", speed = 1 , is_coexist = true},
            },
        },
-- 1132011 碧伦丝(卫林之箭)-正式
    ["3201"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_3201_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.467, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.467, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.867, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.833, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Hit", speed = 2.8},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.267, name = "LieHit", speed = 0.59},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.333, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.233, name = "FloatingDown", speed = 0.867},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 0.867, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 0.9, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.8, name = "Attack01", speed = 1},
            {type = "audio", time = 0, duration = 1.8, name = "JN-3201-10001-1", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "effect", time = 0, duration = 1.8, name = "skill_320101_route2", bone = "RightWeaponPos", speed = 1},
            {type = "effect", time = 0, duration = 5, name = "skill_320101_route", bone = "", speed = 1},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 2.9, name = "Spell_02", speed = 1},
            {type = "audio", time = 0, duration = 2.9, name = "JN-3201-10002-1", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "effect", time = 0.6, duration = 1.2, name = "skill_320102_route2", bone = "RightWeaponPos", speed = 1},
            {type = "effect", time = 0.2, duration = 5, name = "skill_320102_route", bone = "", speed = 1},
            
        },
        ["attack03"] = {
            {type = "anim", time = 0, duration = 2.9, name = "Spell_02", speed = 1},
            {type = "audio", time = 0, duration = 2.9, name = "JN-3201-10003-1", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "effect", time = 0.6, duration = 1.2, name = "skill_320103_route2", bone = "RightWeaponPos", speed = 1},
            {type = "effect", time = 0.4, duration = 5, name = "skill_320103_route", bone = "", speed = 1},
        },
        ["attack04"] = {
            {type = "anim", time = 0, duration = 2.9, name = "Spell_03", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-3201-10004-1", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "effect", time = 0.65, duration = 1.2, name = "skill_320104_route2", bone = "RightWeaponPos", speed = 1},
            {type = "effect", time = 0.2, duration = 5, name = "skill_320104_route", bone = "", speed = 1},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3.2, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 5, name = "skill_320111_route", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 5, name = "JN-3201-10006-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
    },
    -- 碧伦斯(卫林之箭)高模
        ["3201_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 3.667, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 5, name = "scenes_3201_appearance", bone = "", speed = 1 , is_coexist = true},
                {type = "effect", time = 0, duration = 5, name = "scenes_3201_appearance_02", bone = "RightWeaponPos", speed = 1 , is_coexist = true},
                {type = "camera", time = 0, duration = 4.2, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 1.667, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 3.133, name = "Pose02", speed = 1},
            },
        },
    -- 碧伦斯(卫林之箭)精英怪01
        ["3251"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 1.533, name = "Appearance", speed = 1},
            },
            ["attack01"] = {
                {type = "anim", time = 0, duration = 1.8, name = "Attack01", speed = 1},
                {type = "effect", time = 0, duration = 1.8, name = "skill_320101_route2", bone = "RightWeaponPos", speed = 1},
                --  {type = "audio", time = 0, duration = 1.8, name = "JN-3201-10001-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
                {type = "effect", time = 0, duration = 1.8, name = "skill_320101_route", bone = "", speed = 1},
            },
            ["attack02"] = {
                {type = "anim", time = 0, duration = 2.9, name = "Attack02", speed = 1},
                {type = "effect", time = 0, duration = 2.9, name = "skill_320102_route2", bone = "RightWeaponPos", speed = 1},
                --  {type = "audio", time = 0, duration = 3, name = "JN-3201-10003-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
                {type = "effect", time = 0, duration = 3.5, name = "skill_320102_route", bone = "", speed = 1},
            },
            ["attack03"] = {
                {type = "anim", time = 0, duration = 2.9, name = "Attack02", speed = 1},
                {type = "effect", time = 0, duration = 2.9, name = "skill_320103_route2", bone = "RightWeaponPos", speed = 1},
                --  {type = "audio", time = 0, duration = 2.9, name = "JN-3201-10002-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
                {type = "effect", time = 0, duration = 3.5, name = "skill_320103_route", bone = "", speed = 1},
            },
            ["attack04"] = {
                {type = "anim", time = 0, duration = 2.9, name = "Attack02", speed = 1},
                {type = "effect", time = 0, duration = 2.9, name = "skill_320104_route2", bone = "RightWeaponPos", speed = 1},
                --  {type = "audio", time = 0, duration = 2.9, name = "JN-3201-10004-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
                {type = "effect", time = 0, duration = 3.5, name = "skill_320104_route", bone = "", speed = 1},
            },
            ["born_battle"] = {
                {type = "anim", time = 0, duration = 1.5, name = "Born", speed = 1},
                {type = "effect", time = 0, duration = 1.6, name = "scenes_3201_born", bone = "", speed = 1 , is_coexist = true},
                -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
            },
            ["born_hangup"] = {
                {type = "anim", time = 0, duration = 1.467, name = "Stand", speed = 1},
                {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
                {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
            },
            ["dead"] = {
                {type = "anim", time = 0, duration = 1.833, name = "Death", speed = 1},
                {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
            },
            ["dizzy"] = {
                {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
            },
            ["floatingdown"] = {
                {type = "anim", time = 0, duration = 1.233, name = "FloatingDown", speed = 0.867},
            },
            ["floatingup"] = {
                {type = "anim", time = 0, duration = 0.333, name = "FloatingUp", speed = 1},
            },
            ["freeze"] = {
                {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
            },
            ["getup"] = {
                {type = "anim", time = 0, duration = 0.9, name = "GetUp", speed = 1},
            },
            ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
                {type = "anim", time = 0, duration = 1.133, name = "Hit", speed = 2},
            },
            ["liehit"] = {
                {type = "anim", time = 0, duration = 0.267, name = "LieHit", speed = 1.55},
            },
            ["lost"] = {
                {type = "anim", time = 0, duration = 1.333, name = "Lost", speed = 1},
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 1, name = "Pose", speed = 1},
            },
            ["run"] = {
                {type = "anim", time = 0, duration = 0.867, name = "Run", speed = 1},
            },
            ["spell_01"] = {
                {type = "anim", time = 0, duration = 3.2, name = "Spell_01", speed = 1},
                {type = "effect", time = 0, duration = 5, name = "skill_320111_route", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 5, name = "JN-3201-10006-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
            ["stand"] = {
                {type = "anim", time = 0, duration = 1.467, name = "Stand", speed = 1},
            },
            ["win"] = {
                {type = "anim", time = 0, duration = 3, name = "Win", speed = 1},
                {type = "effect", time = 0, duration = 3, name = "scenes_3201_born", bone = "", speed = 1},
            },
        },

-- 1132021 赫拉尔(密林之刺)-正式
    ["3202"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_3201_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.5, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.9, name = "Hit", speed = 2.25},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.267, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.367, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_320201_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-3202-320201", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.567, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_320201_route2", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-3202-320201", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack03"] = {
            {type = "anim", time = 0, duration = 1.367, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_320202_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-3202-320201", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack04"] = {
            {type = "anim", time = 0, duration = 1.567, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_320202_route2", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-3202-320201", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 6, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 8, name = "skill_320211_route1", bone = "", speed = 1,},
            {type = "effect", time = 0, duration = 6, name = "skill_320211_route4", bone = "", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_320211_route2", bone = "RightHandPos", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_320211_route3", bone = "LeftHandPos", speed = 1},
            {type = "camera", time = 1.7, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;3"},
            {type = "camera", time = 2.1, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;3"},
            {type = "camera", time = 2.3, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;3"},
            {type = "camera", time = 2.7, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3"},
            {type = "camera", time = 3.4, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"},
            {type = "audio", time = 0.42, duration = 4.5, name = "JN-3202-320211", speed = 1, volume = 0.8, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 1.833, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 1.84, name = "skill_320221_route1", bone = "", speed = 1},
            {type = "effect", time = 0.76, duration = 1.5, name = "skill_320221_route2", bone = "", speed = 1, is_coexist = true},
            {type = "audio", time = 0, duration = 1.18, name = "JN-3202-320221", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 2.433, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 2.5, name = "skill_320231_route1", bone = "", speed = 1, is_coexist = true},
            {type = "camera", time = 0.9, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;3"},
            {type = "audio", time = 0, duration = 1.1, name = "JN-3202-320231", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    -- 赫拉尔(密林之刺)高模
        ["3202_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 4, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 6, name = "scenes_3202_appearance_01", bone = "", speed = 1 },
                {type = "effect", time = 0, duration = 6, name = "scenes_3202_appearance_02", bone = "LeftWeaponPos", speed = 1 },
                {type = "camera", time = 0, duration = 4.5, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 5.933, name = "Pose02", speed = 1},
            },
        },
-- 1132031 法林(探林巡者)-正式
    ["3203"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Born", speed = 1},
             {type = "effect", time = 0, duration = 2.5, name = "scenes_3203_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
            --  {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["spell_02_stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Spell_02_Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3, name = "Win", speed = 1},
        },
        ["empty"] = {
                {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Hit", speed = 1.67},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.467, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.233, name = "FloatingDown", speed = 1.2},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1.1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hold"] = {
            {type = "anim", time = 0, duration = 1, name = "Hold", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 2, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_320301_route", bone = "", speed = 1},
            {type = "audio", time = 0.6, duration = 1, name = "JN-3203-320301", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.83, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 1.83, name = "skill_320301_route", bone = "", speed = 1},
            {type = "audio", time = 0.6, duration = 1, name = "JN-3203-320301", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },   
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 2.467, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "skill_320311_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1.9, name = "JN-3203-320311", speed = 0.8, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 6, name = "Spell_01_Loop", speed = 1},
            --  {type = "audio", time = 2, duration = 1, name = "JN-3102-310211-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 3, name = "Spell_01_End", speed = 1},
            {type = "effect", time = 2.94, duration = 0.9, name = "skill_320311_route2", bone = "", speed = 1},
            --  {type = "audio", time = 2, duration = 1, name = "JN-3102-310211-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 3.1, name = "Spell_02", speed = 1},
            --  {type = "effect", time = 0, duration = 1.5, name = "skill_320331_route", bone = "ChestPos", speed = 1, is_coexist = true},
            {type = "audio", time = 0.3, duration = 4, name = "JN-3203-320321", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            },
        },
 -- 法林(探林巡者)高模
    ["3203_ex"] = {
        ["appearance"] = {
            {type = "anim", time = 0, duration = 4.667, name = "Appearance", speed = 1},
            {type = "effect", time = 0, duration = 4.667, name = "scenes_3203_appearance_01", bone = "", speed = 1 },
            {type = "camera", time = 0, duration = 4.7, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
            --  {type = "effect", time = 0, duration = 6, name = "scenes_3202_appearance_02", bone = "LeftWeaponPos", speed = 1 },
        },
        ["pose"] = {
            {type = "anim", time = 0, duration = 2, name = "Pose", speed = 1},
        },
        ["pose2"] = {
            {type = "anim", time = 0, duration = 5.933, name = "Pose02", speed = 1},
        },
    }, 
-- 1133011 若菲奈(秘野妖精)-正式
    ["3301"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.367, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_3201_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 2.5, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Hit", speed = 1.25},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.667, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.333, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.233, name = "FloatingDown", speed = 0.733},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 0.567, name = "LieDown", speed = 0.6},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 0.7, name = "GetUp", speed = 0.7},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1.133, name = "skill_330101_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-3301-330101", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 3, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_330102_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-3301-330101", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_330111_route1", bone = "RightWeaponPos", speed = 1 ,},
            {type = "audio", time = 0, duration = 4, name = "JN-3301-330111", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 1.467, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_330111_route2", bone = "", speed = 1, is_coexist = true },
            --  {type = "effect", time = 0, duration = 3.5, name = "skill_330111_route3", bone = "", speed = 1, is_coexist = true },
            {type = "audio", time = 3, duration = 1.14, name = "JN-3301-330111-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 1.8, name = "Spell_01_End", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_330111_route4", bone = "", speed = 1, is_coexist = true },
            --  {type = "camera", time = 0.07, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;3"},
            --  {type = "audio", time = 0, duration = 1, name = "JN-3301-330111", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 1.733, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_330121_route1", bone = "", speed = 1, },
            {type = "effect", time = 0, duration = 2, name = "skill_330121_route2", bone = "", speed = 1, is_coexist = true },
            --  {type = "effect", time = 0, duration = 2, name = "skill_330121_route3", bone = "ChestPos", speed = 1, is_coexist = true },
            {type = "audio", time = 0, duration = 1.5, name = "JN-3301-330121", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            -- {type = "audio", time = 1.5, duration = 1.5, name = "JN-3301-330121-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.2, name = "Spell_03", speed = 1},
            --  {type = "effect", time = 0, duration = 1, name = "skill_330131_route1", bone = "", speed = 1, },
            {type = "effect", time = 0, duration = 2, name = "skill_330131_route2", bone = "RightWeaponPos", speed = 1,is_coexist=true },
            {type = "audio", time = 0, duration = 1.5, name = "JN-3301-330131", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "audio", time = 1.06, duration = 5, name = "JN-3301-330131-hit", speed = 1, volume = 0.2, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true,}       
        },
        ["spell_04_start"] = {
            {type = "anim", time = 0, duration = 0.367, name = "Spell_04_Begin", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "skill_330141_route1", bone = "", speed = 1 ,is_coexist = true},
        },
        ["spell_04_loop"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Spell_04_Loop", speed = 1},
        },
        ["spell_04_end"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Spell_04_End", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "skill_330141_route2", bone = "", speed = 0.5 ,is_coexist = true},
        },
    },
    -- 若菲奈(野灵仙童)高模
        ["3301_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 9, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 10, name = "scenes_3301_appearance1", bone = "", speed = 1 },
                {type = "effect", time = 0, duration = 3, name = "scenes_3301_appearance2", bone = "Bip001 Spine1", speed = 1 },
                {type = "effect", time = 0, duration = 8, name = "scenes_3301_appearance3", bone = "Bone031", speed = 1 },
                {type = "camera", time = 0, duration = 9.5, name = "bone", params = "camera_bone;2.0;3.8;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 6, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 4.333, name = "Pose02", speed = 1},
                {type = "effect", time = 0, duration = 4.333, name = "scenes_3301_pose02", bone = "Bone031", speed = 1 },

            },
        },
-- 1133021 拉波尔(黑潮司祭)-正式
    ["3302"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.367, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "scenes_3302_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
            --  {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 2.5, name = "Win", speed = 1},
        },
        ["empty"] = {
                {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
            },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Hit", speed = 2.5},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.667, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.133, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.033, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 0.567, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 3, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_330201_route1", bone = "", speed = 1},

        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 3, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_330201_route2", bone = "", speed = 1},
        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_330211_route1", bone = "RightWeaponPos", speed = 1 ,},
            --  {type = "effect", time = 0.633, duration = 1, name = "skill_330111_route2", bone = "", speed = 1, is_coexist = true },
            {type = "audio", time = 0, duration = 9, name = "JN-3302-330211", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 5, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_330211_route1", bone = "RightWeaponPos", speed = 1 ,},
            --  {type = "effect", time = 0, duration = 3, name = "skill_330111_route3", bone = "", speed = 1, is_coexist = true },
            --  {type = "audio", time = 3, duration = 1.14, name = "JN-3301-330111-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 0.633, name = "Spell_01_End", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_330211_route1", bone = "RightWeaponPos", speed = 1 ,},
            --  {type = "effect", time = 0.17, duration = 2, name = "skill_330111_route4", bone = "", speed = 1, is_coexist = true },
            --  {type = "camera", time = 0.07, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;3"},
            --  {type = "audio", time = 0, duration = 1, name = "JN-3301-330111", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 1.733, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_330221_route1", bone = "", speed = 1, },
            --  {type = "audio", time = 0, duration = 1.11, name = "JN-3301-330121", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 拉波尔(黑潮司祭)高模
        ["3302_ex"] = {
            ["appearance"] = {
                {type = "camera", time = 0, duration = 2, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
                {type = "anim", time = 0, duration = 2.5, name = "Appearance", speed = 1},

            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 1.333, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 1, name = "Pose02", speed = 1},
            },
     },
-- 1133031 鲁齐亚诺(星穹贤兽)-正式
    ["3303"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.367, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "scenes_3303_born", bone = "ChestPos", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 2.5, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Hit", speed = 2.5},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.667, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.333, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.5, name = "FloatingDown", speed = 1.5},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1.333, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1.4, name = "GetUp", speed = 1.4},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "skill_330301_route1", bone = "Bip001 R Hand", speed = 1},
            {type = "audio", time = 0, duration = 2, name = "JN-3303-330301", speed = 1.3, volume = 0.8, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist= true},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 3, name = "Attack02", speed = 1},
            --  {type = "effect", time = 0, duration = 3, name = "skill_330302_route1", bone = "", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "skill_330301_route1", bone = "Bip001 L Hand", speed = 1},
            {type = "audio", time = 0, duration = 2, name = "JN-3303-330301", speed = 1.3, volume = 0.8, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist= true},
        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Spell_01_Begin", speed = 1},
            --  {type = "effect", time = 0, duration = 1, name = "skill_330311_route1", bone = "RightWeaponPos", speed = 1 ,},
            --  {type = "effect", time = 0.633, duration = 1, name = "skill_330311_route2", bone = "", speed = 1, is_coexist = true },
            {type = "audio", time = 0, duration = 4, name = "JN-3301-330101", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 10, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 0, duration = 10, name = "buff_330311_m", bone = "HeadPos", speed = 1, },
            --  {type = "audio", time = 3, duration = 1.14, name = "JN-3303-330311-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 1.8, name = "Spell_01_End", speed = 1},
            --  {type = "effect", time = 0.17, duration = 2, name = "skill_330311_route4", bone = "", speed = 1, is_coexist = true },
            --  {type = "camera", time = 0.07, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;3"},
            --  {type = "audio", time = 0, duration = 1, name = "JN-3303-330311", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 1.733, name = "Spell_02", speed = 1},
            --  {type = "effect", time = 0, duration = 1, name = "skill_330321_route1", bone = "", speed = 1, },
            --  {type = "effect", time = 0, duration = 2, name = "skill_330321_route2", bone = "", speed = 1, is_coexist = true },
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.2, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_330331_route1", bone = "", speed = 1, },
            --  {type = "effect", time = 0, duration = 2, name = "skill_330331_route2", bone = "", speed = 1, },
            {type = "audio", time = 0, duration = 3, name = "JN-3303-330331", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

        },
        ["Mis_01"] = {
            {type = "audio", time = 0, duration = 3, name = "JN-3303-330351", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["Mis_02"] = {
            {type = "audio", time = 0, duration = 3, name = "JN-3303-330352", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["Mis_02"] = {
            {type = "audio", time = 0, duration = 3, name = "JN-3303-330353", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
    },
    -- 露琪亚诺 (枭兽法师)高模
        ["3303_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 6.6, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 7, name = "scenes_3303_appearance_01", bone = "", speed = 1 },
                {type = "effect", time = 0, duration = 5, name = "scenes_3303_appearance_02", bone = "Bip001", speed = 1 },
                {type = "camera", time = 0, duration = 7.1, name = "bone", params = "camera_bone;2.3;4.4;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

                --  {type = "effect", time = 0, duration = 8, name = "scenes_3303_appearance3", bone = "Bone031", speed = 1 },

            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 1.333, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 1, name = "Pose02", speed = 1},
            },
        },
-- 1133041 艾萝莎(愈世森灵)-正式
    ["3304"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.367, name = "Born", speed = 1},
            {type = "effect", time = 0.2, duration = 1.6, name = "scenes_3201_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 2.5, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.667, name = "LieHit", speed = 1.26},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.4, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.4, name = "FloatingDown", speed = 1.4},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 0.567, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1.733, name = "GetUp", speed = 1.733},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.4, name = "Attack01", speed = 1},
            --  {type = "effect", time = 0, duration = 1.4, name = "skill_330401_route1", bone = "RightWeaponPos", speed = 1},
            {type = "audio", time = 0, duration = 2, name = "JN-1301-130101", speed = 1.1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.4, name = "Attack02", speed = 1},
            --  {type = "effect", time = 0, duration = 1.4, name = "skill_330401_route1", bone = "RightWeaponPos", speed = 1},
            {type = "audio", time = 0, duration = 2, name = "JN-1301-130101", speed = 1.1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 1.967, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0.633, duration = 2, name = "skill_330411_route1", bone = "", speed = 1, is_coexist = true },
            {type = "audio", time = 0, duration = 5, name = "JN-3304-330411", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Spell_01_Loop", speed = 1},
            --  {type = "effect", time = 0, duration = 10, name = "skill_330411_route2", bone = "", speed = 1, },
            {type = "effect", time = 0, duration = 3, name = "skill_330411_route4", bone = "", speed = 1, is_coexist = true},

            --  {type = "audio", time = 3, duration = 1.14, name = "JN-3304-330411-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 2.967, name = "Spell_01_End", speed = 1},
            --  {type = "effect", time = 0.17, duration = 2, name = "skill_330411_route4", bone = "", speed = 1, is_coexist = true },
            --  {type = "camera", time = 0.07, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;3"},
            --  {type = "audio", time = 0, duration = 1, name = "JN-3304-330411", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 3.333, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_330421_route", bone = "", speed = 1, },
            --  {type = "effect", time = 0, duration = 2, name = "skill_330421_route2", bone = "", speed = 1, is_coexist = true },
            --  {type = "audio", time = 0, duration = 1.11, name = "JN-3304-330421", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 2.833, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_330431_route", bone = "", speed = 1, },
            {type = "audio", time = 1, duration = 2.833, name = "JN-3304-330431", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
    },
    -- 艾萝莎(愈世森灵)高模
        ["3304_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 6.467, name = "Appearance", speed = 1},
                {type = "effect", time = 1.56, duration = 5, name = "scenes_3304_appearance_01", bone = "", speed = 1 },
                {type = "effect", time = 4.1, duration = 5, name = "scenes_3304_appearance_02", bone = "LeftWeaponPos", speed = 1 },
                {type = "camera", time = 0, duration = 7, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max


            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 6, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 6, name = "Pose02", speed = 1},
            },
        },
-- 1133051 莎弗(颂乱诗羚)-正式
    ["3305"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.367, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 3.5, name = "scenes_3305_born", bone = "Bone095", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 2.5, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Hit", speed = 1.66},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.667, name = "LieHit", speed = 1.48},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.333, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.267, name = "FloatingDown", speed = 0.79},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 0.567, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1.867, name = "GetUp", speed = 1.867},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_330501_route", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 2, name = "JN-3305-330501", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 4.133, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_330511_route1", bone = "", speed = 1 ,},
            {type = "audio", time = 0, duration = 4, name = "JN-3305-330511", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 2.167, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_330421_route", bone = "", speed = 1, },
            {type = "audio", time = 0, duration = 2, name = "JN-3305-330501", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 3.4, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 3.4, name = "skill_330531_route", bone = "", speed = 1, },
            {type = "audio", time = 0, duration = 3, name = "JN-3305-330531", speed = 1, volume = 0.6, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    -- 莎弗(颂乱诗羚)高模
        ["3305_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 5.867, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 4, name = "scenes_3305_appearance_01", bone = "", speed = 1 },
                {type = "effect", time = 0, duration = 6.6, name = "scenes_3305_appearance_02", bone = "Bip001 Prop1", speed = 1 },
                {type = "effect", time = 0, duration = 2, name = "scenes_3305_appearance_03", bone = "LeftHandPos", speed = 1 },
                {type = "effect", time = 0, duration = 2, name = "scenes_3305_appearance_04", bone = "RightHandPos", speed = 1 },
                {type = "effect", time = 0, duration = 4, name = "scenes_3305_appearance_05", bone = "Bip001 Spine", speed = 1 },
                {type = "camera", time = 0, duration = 6.3, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 1.333, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 1, name = "Pose02", speed = 1},
            },
        },

-- -- 

-- --  亡灵 
-- 1141011 瓦迪斯(亡国骨王)-正式
    ["4101"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 3.333, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "scenes_4101_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 2, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 2, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.4, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3.233, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.667, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.167, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 0.9, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.6, name = "Attack01", speed = 1},
            {type = "effect", time = 0.55, duration = 1, name = "skill_410101_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1.6, name = "JN-1101-110101-1", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Attack02", speed = 1},
            {type = "effect", time = 0.45, duration = 1, name = "skill_410102_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1.6, name = "JN-1101-110101-1", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 2.5, name = "Spell_01", speed = 1},
            --  {type = "effect", time = 0.3, duration = 1, name = "skill_410111_route1", bone = "", speed = 1},
            {type = "effect", time = 1.5, duration = 1.5, name = "skill_410111_route2", bone = "RightHandPos", speed = 1},
            {type = "effect", time = 1.7, duration = 1, name = "skill_410111_route3", bone = "", speed = 1},
            {type = "camera", time = 0, duration = 1.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;20"},
            {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3"},
            {type = "audio", time = 0, duration = 3.08, name = "JN-4101-410111", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "audio", time = 2, duration = 1, name = "JN-4101-410121-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 1.367, name = "Spell_02", speed = 1},
            {type = "effect", time = 0.5, duration = 2, name = "skill_410121_route1", bone = "", speed = 1 , is_coexist = true},
            {type = "audio", time = 0, duration = 1, name = "JN-4101-410121", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "audio", time = 1, duration = 1, name = "JN-4101-410121-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Spell_03", speed = 1},
            --  {type = "effect", time = 0.35, duration = 1, name = "skill_410131_route1", bone = "", speed = 1},
            {type = "camera", time = 0.4, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;3"},
            {type = "audio", time = 0, duration = 5, name = "JN-4101-410131-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist=true},
        },
    },
    -- 瓦迪斯(亡国骨王)高模
        ["4101_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 8.033, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 8, name = "scenes_4101_appearance_01", bone = "", speed = 1},
                {type = "effect", time = 0, duration = 10, name = "scenes_4101_appearance_02", bone = "", speed = 1, is_coexist = true},
                {type = "camera", time = 0, duration = 8.5, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2.167, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 5.867, name = "Pose02", speed = 1},
                {type = "effect", time = 0, duration = 9, name = "scenes_4101_pose02_01", bone = "", speed = 1 , is_coexist = true},
            },
        },
    -- 持剑骷髅
        ["8002"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 1.167, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 2, name = "common_appearance", bone = "", speed = 1, is_coexist = true },
                {type = "audio", time = 0, duration = 5, name = "JN-4101-410121-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

            },
            ["stand"] = {
                {type = "anim", time = 0, duration = 1.067, name = "Stand", speed = 1},
            },
            ["run"] = {
                {type = "anim", time = 0, duration = 0.8, name = "Run", speed = 1},
            },
            ["dead"] = {
                {type = "anim", time = 0, duration = 1.2, name = "Death", speed = 1},
                {type = "shader", time = 1, name = "Death", duration = 0.5, params = ""},
                {type = "effect", time = 0, duration = 2, name = "skill_410151_route1", bone = "", speed = 1},
            },
            ["empty"] = {
                {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
            },
            ["hit"] = {
                {type = "anim", time = 0, duration = 0.567, name = "Hit", speed = 2},
            },
            ["dizzy"] = {
                {type = "anim", time = 0, duration = 1.133, name = "Dizzy", speed = 1},
            },
            ["attack"] = {
                {type = "anim", time = 0, duration = 1.133, name = "Attack", speed = 1},
                {type = "effect", time = 0.3, duration = 1.133, name = "skill_123002_route1", bone = "", speed = 1},
            },
            ["spell"] = {
                {type = "anim", time = 0, duration = 1.4, name = "Spell_01", speed = 1},
                {type = "effect", time = 0.6, duration = 1.8, name = "skill_123002_route2", bone = "", speed = 1},
            },
        },
    -- 持斧骷髅
        ["8003"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 1.533, name = "Appearance", speed = 1 },
                {type = "effect", time = 0, duration = 2, name = "common_appearance", bone = "", speed = 1, is_coexist = true},
                {type = "audio", time = 0, duration = 5, name = "JN-4101-410121-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

            },
            ["stand"] = {
                {type = "anim", time = 0, duration = 1.067, name = "Stand", speed = 1},
            },
            ["run"] = {
                {type = "anim", time = 0, duration = 0.8, name = "Run", speed = 1},
            },
            ["dead"] = {
                {type = "anim", time = 0, duration = 1.2, name = "Death", speed = 1},
                {type = "shader", time = 1, name = "Death", duration = 0.5, params = ""},
                {type = "effect", time = 0, duration = 2, name = "skill_410151_route1", bone = "", speed = 1},
            },
            ["empty"] = {
                {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
            },
            ["hit"] = {
                {type = "anim", time = 0, duration = 0.567, name = "Hit", speed = 2},
            },
            ["dizzy"] = {
                {type = "anim", time = 0, duration = 1.133, name = "Dizzy", speed = 1},
            },
            ["attack"] = {
                {type = "anim", time = 0, duration = 1.5, name = "Attack", speed = 1},
                {type = "effect", time = 0, duration = 1.8, name = "skill_123003_route1", bone = "", speed = 1},
            },
            ["spell"] = {
                {type = "anim", time = 0, duration = 1.133, name = "Spell_01", speed = 1},
                -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
            },
        },
    -- 持弓骷髅
        ["8004"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 1.533, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 2, name = "common_appearance", bone = "", speed = 1, is_coexist = true },
                {type = "audio", time = 0, duration = 5, name = "JN-4101-410121-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

            },
            ["stand"] = {
                {type = "anim", time = 0, duration = 0.533, name = "Stand", speed = 1},
            },
            ["run"] = {
                {type = "anim", time = 0, duration = 1.067, name = "Run", speed = 1},
            },
            ["dead"] = {
                {type = "anim", time = 0, duration = 1.2, name = "Death", speed = 1},
                {type = "shader", time = 1, name = "Death", duration = 0.5, params = ""},
                {type = "effect", time = 0, duration = 2, name = "skill_410151_route1", bone = "", speed = 1},
            },
            ["empty"] = {
                {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
            },
            ["hit"] = {
                {type = "anim", time = 0, duration = 0.567, name = "Hit", speed = 2},
            },
            ["dizzy"] = {
                {type = "anim", time = 0, duration = 1.133, name = "Dizzy", speed = 1},
            },
            ["attack"] = {
                {type = "anim", time = 0, duration = 1, name = "Attack", speed = 1},
                -- {type = "effect", time = 0, duration = 1.8, name = "skill_123004_route1", bone = "", speed = 1},
            },
        },

-- 1141021 提米(食尸恶鬼)-正式
    ["4102"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.767, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 2, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 2, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.4, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3.233, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.467, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1., name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 0.9, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 2.267, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.6, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_410201_route1", bone = "", speed = 1},
            {type = "audio", time = 0.55, duration = 1.8, name = "JN-2201-220101", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_410202_route1", bone = "", speed = 1},
            {type = "audio", time = 0.55, duration = 3, name = "JN-2201-220102", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 4, name = "Spell01", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "skill_410211_route1", bone = "", speed = 1},
            --  {type = "camera", time = 0, duration = 1.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;20"},
            {type = "camera", time = 0.3, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3"},
            {type = "audio", time = 0, duration = 3, name = "JN-4102-410211", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            {type = "audio", time = 0.5, duration = 3, name = "JN-4102-410211-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

        },
    },
    -- 提米(食尸恶鬼)高模
        ["4102_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 4.167, name = "Appearance", speed = 1},
                -- {type = "effect", time = 0, duration = 8, name = "scenes_4102_appearance_01", bone = "", speed = 1},
                -- {type = "effect", time = 0, duration = 4.167, name = "scenes_4102_appearance_02", bone = "", speed = 1, is_coexist = true},
                {type = "camera", time = 0, duration = 4.7, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2.167, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 5.867, name = "Pose02", speed = 1},
            },
        },


-- 1141031 迪特里克(生化悍将)-正式
    ["4103"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },  
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.467, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1.1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Attack01", speed = 1},
            {type = "effect", time = 0.56, duration = 2, name = "skill_410301_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1.8, name = "JN-7182-718201", speed = 0.8, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Attack02", speed = 1},
            {type = "effect", time = 0.36, duration = 2, name = "skill_410302_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1.8, name = "JN-3101-310111-hit", speed = 0.8, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3.267, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 3.27, name = "skill_410311_route2", bone = "", speed = 1},
            {type = "effect", time = 0.8, duration = 3.27, name = "skill_410311_route1", bone = "", speed = 1},
            {type = "camera", time = 0.8, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3"},
            {type = "audio", time = 0.7, duration = 1.8, name = "JN-7182-718201", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "audio", time = 1.8, duration = 5, name = "JN-7182-718211", speed = 0.8, volume = 0.8, bloop = false, is_coexist = true },

        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 2.5, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 3.27, name = "skill_410321_route1", bone = "", speed = 1},
            {type = "effect", time = 0, duration = 3.27, name = "skill_410321_route2", bone = "", speed = 1},
            {type = "audio", time = 0.4, duration = 5, name = "JN-7182-718211", speed = 1, volume = 0.8, bloop = false, is_coexist = true },
            {type = "audio", time = 1.5, duration = 5, name = "JN-7182-718211", speed = 0.7, volume = 0.8, bloop = false, is_coexist = true },
            {type = "camera", time = 1.3, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3"},
        },
        ["spell_03_start"] = {
            {type = "anim", time = 0, duration = 1.6, name = "Spell_03_Begin", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-4101-410121", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist=true},

        },
        ["spell_03_loop"] = {
            {type = "anim", time = 0, duration = 1.6, name = "Spell_03_Loop", speed = 1},
        },
        ["spell_03_end"] = {
            {type = "anim", time = 0, duration = 1.6, name = "Spell_03_End", speed = 1},
        },
    },    
    -- 迪特里克（暗夜魅影）高模
    ["4103_ex"] = {
        ["appearance"] = {
            {type = "anim", time = 0, duration = 8.033, name = "Appearance", speed = 1},
            {type = "effect", time = 0, duration = 20, name = "scenes_4103_appearance_01", bone = "", speed = 1 , is_coexist = true},
            {type = "effect", time = 0, duration = 20, name = "scenes_4103_appearance_02", bone = "", speed = 1 , is_coexist = true},
            {type = "effect", time = 0, duration = 20, name = "scenes_4103_appearance_03", bone = "Right Hand Pos", speed = 1 , is_coexist = true},
            {type = "camera", time = 0, duration = 8.5, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
        },
        ["pose"] = {
            {type = "anim", time = 0, duration = 2.067, name = "Pose", speed = 1},
        },
        ["pose2"] = {
            {type = "anim", time = 0, duration = 2.067, name = "Pose02", speed = 1},
            {type = "effect", time = 0, duration = 9, name = "scenes_4103_pose02", bone = "", speed = 1 , is_coexist = true},

        },
    },
-- 1141041 奥赫布(虫巢暴君)-正式  
    ["4104"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.767, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 2, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 2, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.4, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3.233, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.467, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1., name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 0.9, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 2.267, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.33, name = "Attack01", speed = 1},
            {type = "effect", time = 0.4, duration = 2, name = "skill_410401_route1", bone = "", speed = 1},
            --  {type = "audio", time = 0, duration = 0.46, name = "JN-3201-10001-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Attack02", speed = 1},
            {type = "effect", time = 0.5, duration = 2, name = "skill_410402_route1", bone = "", speed = 1},
            --  {type = "audio", time = 0, duration = 0.4, name = "JN-3201-10003-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 0.867, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "skill_410411_route1", bone = "", speed = 1},
            {type = "effect", time = 0.6, duration = 1.7, name = "skill_410411_route2", bone = "", speed = 1,is_coexist = true},
            {type = "audio", time = 0, duration = 6, name = "JN-4104-410411-begin", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 4, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 0, duration = 10, name = "skill_410411_route3_m", bone = "", speed = 1},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 1.6, name = "Spell_01_End", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "skill_410411_route2", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1.5, name = "JN-4104-410411-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, },
            {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.5;0;0.1;3"},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 4, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "skill_410421_route1", bone = "", speed = 1},

        },
    },
    -- 奥赫布(虫巢暴君)高模
        ["4104_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 6.7, name = "Appearance", speed = 1},
                {type = "effect", time = 0.9, duration = 8, name = "scenes_4104_appearance_01", bone = "", speed = 1},
                {type = "effect", time = 0, duration = 10, name = "scenes_4104_appearance_02", bone = "MouthPos", speed = 1, is_coexist = true},
                {type = "camera", time = 0, duration = 7.2, name = "bone", params = "camera_bone;2.4;6.0;1;4.0"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 1.933, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 1.933, name = "Pose02", speed = 1},
            },
        },

-- 1142011 维尔加(弑君魅影)-正式
    ["4201"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Born", speed = 1},
            -- {type = "effect", time = 0, duration = 1.6, name = "scenes_4201_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },  
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.467, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1.1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_420101_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1.8, name = "JN-1203-120302", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_420102_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 3, name = "JN-1203-120302", speed = 0.8, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0, duration = 0.5, name = "skill_420111_route1", bone = "LeftHandPos", speed = 1 ,},
            {type = "effect", time = 0, duration = 0.5, name = "skill_420111_route1", bone = "RightHandPos", speed = 1 },
            {type = "audio", time = 0, duration = 3, name = "JN-4201-420111", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 0.333, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_420111_route2", bone = "", speed = 1 , is_coexist = true},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 0.667, name = "Spell_01_End", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_420111_route3", bone = "", speed = 1 , is_coexist = true},
            {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 2, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_420121_route1", bone = "", speed = 1},
            {type = "camera", time = 1.2, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3"},
            {type = "audio", time = 0, duration = 5, name = "JN-4201-420121", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "audio", time = 0, duration = 5, name = "JN-4201-420121-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_03_start"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Spell_03_Begin", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_420131_route2", bone = "", speed = 1 , is_coexist = true},
            {type = "audio", time = 0.7, duration = 1, name = "JN-4201-420131", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_03_end"] = {
            {type = "anim", time = 0, duration = 0.033, name = "Spell_03_End", speed = 1},
            -- {type = "audio", time = 0, duration = 5, name = "JN-3201-10006-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_03_end2"] = {
            {type = "anim", time = 0, duration = 0.9, name = "Spell_03_End02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_420131_route3", bone = "", speed = 1, is_coexist = true},
            -- {type = "audio", time = 0, duration = 5, name = "JN-3201-10006-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
    },
    -- 维尔加（暗夜魅影）高模
        ["4201_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 5, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 5, name = "scenes_4201_appearance", bone = "", speed = 1 },
                {type = "camera", time = 0, duration = 5.5, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 1.667, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 2.667, name = "Pose02", speed = 1},
                {type = "effect", time = 0, duration = 5, name = "scenes_4201_pose02", bone = "", speed = 1 },

            },
        },

-- 1142021 莫妮卡(猎魔舞姬)-正式
    ["4202"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 0.9, name = "Born", speed = 1},
            -- {type = "effect", time = 0, duration = 1.6, name = "scenes_4202_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.867, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.867, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.667, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.033, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 2.933, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 1.75},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.633, name = "LieHit", speed = 1.40},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.333, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 0.933, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Attack01", speed = 1},
            {type = "effect", time = 0.27, duration = 1, name = "skill_420201_route1", bone = "RightWeaponPos", speed = 1},
            {type = "audio", time = 0, duration = 1.8, name = "JN-4202-420201", speed = 1, volume = 0.7, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 0.867, name = "Attack02", speed = 1},
            {type = "effect", time = 0.2, duration = 1, name = "skill_420201_route1", bone = "LeftWeaponPos", speed = 1},
            {type = "audio", time = 0, duration = 3, name = "JN-4202-420201", speed = 1, volume = 0.7, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack03"] = {
            {type = "anim", time = 0, duration = 1.4, name = "Attack03", speed = 1},
            {type = "effect", time = 0.4, duration = 1, name = "skill_420203_route1", bone = "RightWeaponPos", speed = 1},
            {type = "effect", time = 0.4, duration = 1, name = "skill_420203_route1", bone = "LeftWeaponPos", speed = 1},
            --  {type = "camera", time = 0.8, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;3"},
            -- {type = "audio", time = 0, duration = 3, name = "JN-3201-10003-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 0.7, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0.54, duration = 1, name = "skill_420211_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 5, name = "JN-4202-420211", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 1.267, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 0, duration = 1.267, name = "skill_420211_route2", bone = "", speed = 1},
            --  {type = "camera", time = 0, duration = 1.2, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;24"},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 0.333, name = "Spell_01_End", speed = 1},
            {type = "effect", time = 0, duration = 0.333, name = "skill_420211_route3", bone = "", speed = 1}, 
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 2, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_420221_route1", bone = "", speed = 1},
            {type = "effect", time = 0.8, duration = 1, name = "skill_420221_route2", bone = "RightWeaponPos", speed = 1 },
            {type = "camera", time = 1.2, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;3"},
            {type = "audio", time = 0.84, duration = 1, name = "JN-4202-420221", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
    },
    -- 莫妮卡（猎魔倩影）高模
        ["4202_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 6.867, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 5, name = "scenes_4202_appearance", bone = "", speed = 1 },
                {type = "camera", time = 0, duration = 7.5, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 1.867, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 1.867, name = "Pose02", speed = 1},
            },
        },
    -- 召唤物影狼-正式
        ["8001"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 0.533, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 1.5, name = "scenes_123001_born", bone = "", speed = 1, is_coexist = true},
                {type = "audio", time = 0, duration = 5, name = "JN-4202-420201-call", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            },
            ["stand"] = {
                {type = "anim", time = 0, duration = 0.533, name = "Stand", speed = 1},
            },
            ["run"] = {
                {type = "anim", time = 0, duration = 0.467, name = "Run", speed = 1},
            },
            ["dead"] = {
                {type = "anim", time = 0, duration = 0.667, name = "Death", speed = 1},
                {type = "shader", time = 1, name = "Death", duration = 0.1, params = ""},
                --  {type = "effect", time = 0, duration = 1, name = "scenes_123001_death", bone = "", speed = 1 , is_coexist = true},
            },
            ["empty"] = {
                {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
            },
            ["hit"] = {
                {type = "anim", time = 0, duration = 0.3, name = "Hit", speed = 2},
            },
            ["dizzy"] = {
                {type = "anim", time = 0, duration = 0.533, name = "Dizzy", speed = 1},
            },
            --  ["floatingup"] = {
            --      {type = "anim", time = 0, duration = 0.467, name = "FloatingUp", speed = 1},
            --  },
            --  ["floatingdown"] = {
            --      {type = "anim", time = 0, duration = 1, name = "FloatingDown", speed = 1},
            --  },
            --  ["liedown"] = {
            --      {type = "anim", time = 0, duration = 1.1, name = "LieDown", speed = 1},
            --  },
            ["attack"] = {
                {type = "anim", time = 0, duration = 0.533, name = "Attack", speed = 0.5},
                --  {type = "effect", time = 0, duration = 1, name = "skill_420101_route1", bone = "", speed = 1},
                -- {type = "audio", time = 0, duration = 1.8, name = "JN-3201-10001-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
-- 1142031 门托(石像哨卫)-正式
    ["4203"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.767, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 2, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 2, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.4, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3.233, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Hit", speed = 2.5},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.167, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 0.9, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Attack01", speed = 1},
             {type = "effect", time = 0, duration = 1.5, name = "skill_420301_route1", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1.8, name = "JN-3201-10001-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Attack02", speed = 1},
             {type = "effect", time = 0 ,duration = 1.5, name = "skill_420301_route1", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1.8, name = "JN-3201-10001-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3.067, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_420311_route1", bone = "", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_420311_route2", bone = "Bip001 Head", speed = 1},
            {type = "camera", time = 1.3, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.5;0;0.1;5"},
            {type = "audio", time = 0, duration = 5, name = "JN-4203-420311", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 2.524, name = "Spell_02", speed = 0.7},
            {type = "effect", time = 0.43, duration = 2.57, name = "skill_420321_route2", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 5, name = "JN-3201-10006-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
    },
    -- 门托(石像哨卫)高模
        ["4203_ex"] = {
            ["appearance"] = {
                {type = "camera", time = 0, duration = 2, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
                {type = "anim", time = 0, duration = 2.5, name = "Appearance", speed = 1},
                --  {type = "effect", time = 0, duration = 10, name = "scenes_4203_appearance_02", bone = "", speed = 1, is_coexist = true},
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2.167, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 5.867, name = "Pose02", speed = 1},
            },
        },

-- 1142041 萨卡森(邪火骷髅)-正式
    ["4204"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },  
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.467, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1.1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Attack01", speed = 1},
            {type = "effect", time = 0.43, duration = 1, name = "skill_420401_route1", bone = "", speed = 1},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Attack02", speed = 1},
            {type = "effect", time = 0.43, duration = 0.5, name = "skill_420402_route1", bone = "", speed = 1},
        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 0.667, name = "Spell_01_Begin", speed = 1},
            --  {type = "effect", time = 0.3, duration = 1, name = "skill_420411_route2", bone = "", speed = 1 ,},
            {type = "effect", time = 0.3, duration = 1, name = "skill_420411_route1", bone = "", speed = 1 },
            {type = "effect", time = 0.3, duration = 1, name = "skill_420411_route3", bone = "", speed = 1 },
            {type = "audio", time = 0, duration = 1.8, name = "JN-4204-420411-begin", speed = 1, volume = 0.7, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 0.333, name = "Spell_01_Loop", speed = 1},
            --  {type = "effect", time = 0, duration = 1, name = "skill_420411_route2", bone = "", speed = 1 , is_coexist = true},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Spell_01_End", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "skill_420411_route4", bone = "", speed = 1 , is_coexist = true},
            {type = "audio", time = 0, duration = 2, name = "JN-4204-420411-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            --  {type = "camera", time = 0.67, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
        },

        ["spell_02_start"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Spell_02_Begin", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_420421_route1", bone = "", speed = 1 , is_coexist = true},
            {type = "audio", time = 0, duration = 1.8, name = "JN-4204-420421-begin", speed = 1, volume = 0.7, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_02_end"] = {
            {type = "anim", time = 0, duration = 1.43, name = "Spell_02_End", speed = 1},
            {type = "effect", time = 0.33, duration = 5, name = "skill_420421_route2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "audio", time = 0, duration = 3, name = "JN-4204-420421-hit", speed = 1, volume = 0.7, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
    },
    -- 萨卡森 - (邪火骷髅)高模
        ["4204_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 4.967, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 5, name = "scenes_4204_appearance_01", bone = "", speed = 1 , },
                {type = "camera", time = 0, duration = 5.2, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 2, name = "Pose02", speed = 1},
            },
        },
-- 1142051 施佩林(诡秘小丑)-非正式
    ["4205"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },  
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.467, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1.1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Attack01", speed = 1},
            {type = "effect", time = 0.35, duration = 0.55, name = "skill_420501_route1", bone = "", speed = 1},
            {type = "audio", time = 0.35, duration = 1, name = "JN-4205-420501", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Attack02", speed = 1},
            {type = "effect", time = 0.3, duration = 0.55, name = "skill_420502_route1", bone = "", speed = 1},
            {type = "audio", time = 0.3, duration = 1, name = "JN-4205-420502", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 0.667, name = "Spell_01_Begin", speed = 1},
            --  {type = "effect", time = 0.3, duration = 1, name = "skill_420411_route2", bone = "", speed = 1 ,},
            {type = "effect", time = 0.3, duration = 1, name = "skill_420511_route1", bone = "", speed = 1, is_coexist = true},
            {type = "audio", time = 0, duration = 3, name = "JN-4205-420511-begin", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 0.333, name = "Spell_01_Loop", speed = 1},
            --  {type = "effect", time = 0, duration = 1, name = "skill_420411_route2", bone = "", speed = 1 , is_coexist = true},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Spell_01_End", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_420511_route2", bone = "", speed = 1, is_coexist = true},
            --  {type = "camera", time = 0.67, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
        },
        ["spell_02_start"] = {
            {type = "effect", time = 0, duration = 1.8, name = "skill_420521_route1", bone = "", speed = 1 , is_coexist = true},
            {type = "audio", time = 0, duration = 2, name = "JN-4205-420521-begin", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            --  {type = "camera", time = 0.67, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
        },
        ["spell_02_end"] = {
            {type = "effect", time = 0, duration = 1.35, name = "skill_420521_route2", bone = "", speed = 1 , is_coexist = true},
             {type = "audio", time = 0, duration = 2, name = "JN-4205-420521-end", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            {type = "anim", time = 0, duration = 1.067, name = "Attack01", speed = 1},
            --  {type = "camera", time = 0.67, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
        },
        ["spell_03_start"] = {
            {type = "anim", time = 0, duration = 1.233, name = "Spell_03_Begin", speed = 1},
            -- {type = "effect", time = 0, duration = 1, name = "skill_420421_route1", bone = "", speed = 1 , is_coexist = true},
            -- {type = "audio", time = 0, duration = 1.8, name = "JN-4204-420421-begin", speed = 1, volume = 0.7, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_03_end"] = {
            {type = "anim", time = 0, duration = 0.733, name = "Spell_03_End", speed = 1},
            -- {type = "effect", time = 0.33, duration = 5, name = "skill_420421_route2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            -- {type = "audio", time = 0, duration = 3, name = "JN-4204-420421-hit", speed = 1, volume = 0.7, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
    },
    ["8009"] = {
        ["appearance"] = {
                {type = "anim", time = 0, duration = 1.167, name = "Spell_01_End", speed = 1},
                -- {type = "effect", time = 0, duration = 2, name = "skill_420511_route2", bone = "", speed = 1, is_coexist = true },
                {type = "audio", time = 0, duration = 3, name = "JN-4205-420511-end", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
                {type = "shader", time = 0, name = "Desaturate", duration = 99, params = "0.75;0.7;131;2;149", is_coexist = true},
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2, name = "Death", speed = 1},
            {type = "effect", time = 1.73, duration = 5, name = "skill_420512_route1", bone = "", speed = 1,is_coexist=true},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
            {type = "audio", time = 0, duration = 3, name = "JN-4205-420511-boom", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            {type = "audio", time = 2, duration = 1, name = "JN-1301-10002-3", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },  
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.467, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1.1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Attack01", speed = 1},
            {type = "effect", time = 0.43, duration = 1, name = "skill_420501_route1", bone = "", speed = 1},
            {type = "audio", time = 0.35, duration = 1, name = "JN-4205-420501", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Attack02", speed = 1},
            {type = "effect", time = 0.43, duration = 0.5, name = "skill_420502_route1", bone = "", speed = 1},
            {type = "audio", time = 0.3, duration = 1, name = "JN-4205-420502", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_02_start"] = {
            {type = "effect", time = 0, duration = 1.8, name = "skill_420521_route1", bone = "", speed = 1 , is_coexist = true},
            --  {type = "camera", time = 0.67, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
        },
        ["spell_02_end"] = {
            {type = "effect", time = 0, duration = 1.35, name = "skill_420521_route2", bone = "", speed = 1 , is_coexist = true},
            {type = "anim", time = 0, duration = 1.067, name = "Attack01", speed = 1},
            --  {type = "camera", time = 0.67, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
        },
    },
    ["8010"] = {
        ["appearance"] = {
                {type = "anim", time = 0, duration = 1.167, name = "Spell_01_End", speed = 1},
                -- {type = "effect", time = 0, duration = 2, name = "skill_420511_route2", bone = "", speed = 1, is_coexist = true },
                {type = "audio", time = 0, duration = 5, name = "JN-4205-420511-end", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
                {type = "shader", time = 0, name = "Desaturate", duration = 99, params = "0.75;0.7;131;2;149", is_coexist = true},
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
            {type = "audio", time = 0, duration = 2, name = "JN-4205-420511-boom", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            {type = "audio", time = 2, duration = 1, name = "JN-1301-10002-3", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            {type = "effect", time = 1.73, duration = 5, name = "skill_420512_route1", bone = "", speed = 1,is_coexist=true},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },  
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.467, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1.1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Attack01", speed = 1},
            {type = "effect", time = 0.43, duration = 1, name = "skill_420501_route1", bone = "", speed = 1},
            {type = "audio", time = 0.35, duration = 1, name = "JN-4205-420501", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Attack02", speed = 1},
            {type = "effect", time = 0.43, duration = 0.5, name = "skill_420502_route1", bone = "", speed = 1},
            {type = "audio", time = 0.3, duration = 1, name = "JN-4205-420502", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_02_start"] = {
            {type = "effect", time = 0, duration = 1.8, name = "skill_420521_route1", bone = "", speed = 1 , is_coexist = true},
            --  {type = "camera", time = 0.67, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
        },
        ["spell_02_end"] = {
            {type = "effect", time = 0, duration = 1.35, name = "skill_420521_route2", bone = "", speed = 1 , is_coexist = true},
            {type = "anim", time = 0, duration = 1.067, name = "Attack01", speed = 1},
            --  {type = "camera", time = 0.67, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
        },
    },

    -- 斯佩林 - (诡秘小丑)高模
        ["4205_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 6.733, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 6.733, name = "scenes_4205_appearance_01", bone = "", speed = 1 , },
                {type = "effect", time = 0, duration = 6.733, name = "scenes_4205_appearance_02", bone = "RightFootPos", speed = 1 , },
                {type = "camera", time = 0, duration = 6.733, name = "bone", params = "camera_bone;1.8;3;1;1.6"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 2, name = "Pose02", speed = 1},
            },
        },
-- 1143011 班恩(返世梦魇)-正式
    ["4301"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 3.333, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_4301_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.6, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.4, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1.833, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack01", speed = 1},
            {type = "effect", time = 0.16, duration = 1, name = "skill_430101_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 3, name = "JN-4301-430101", speed = 1, volume = 0.7, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack02", speed = 1},
            {type = "effect", time = 0.33, duration = 1, name = "skill_430102_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 3, name = "JN-4301-430101", speed = 1, volume = 0.7, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 5, name = "skill_430111_route3", bone = "", speed = 1},
            --  {type = "effect", time = 1.3, duration = 1.07, name = "skill_430111_route2", bone = "RightWeaponPos", speed = 1},
            {type = "audio", time = 0, duration = 5, name = "JN-4301-430111", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            -- {type = "audio", time = 3, duration = 3, name = "JN-4301-430111-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "camera", time = 1.02, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3"},

        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.767, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_430131_route1", bone = "RightWeaponPos", speed = 1},
            --  {type = "effect", time = 0, duration = 2, name = "skill_430131_route2", bone = "", speed = 1},
            --  {type = "audio", time = 0, duration = 5, name = "JN-4301-430131-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_04"] = {
            {type = "anim", time = 0, duration = 2.333, name = "Spell_04", speed = 1},
            {type = "effect", time = 0, duration = 2.333, name = "skill_430141_route1", bone = "LeftWeaponPos", speed = 1},
            {type = "effect", time = 0.5, duration = 2.333, name = "skill_430141_route2", bone = "", speed = 1},
            {type = "effect", time = 0, duration = 2.333, name = "skill_430141_route3", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 2, name = "JN-4301-430141", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,},
            {type = "audio", time = 2, duration = 1., name = "JN-4301-430141-shoot", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "audio", time = 2.5, duration = 1, name = "JN-4301-430141-shoot", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "audio", time = 3, duration = 1, name = "JN-4301-430141-shoot", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "audio", time = 3.5, duration = 1, name = "JN-4301-430141-shoot", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "audio", time = 4, duration = 1, name = "JN-4301-430141-shoot", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
    },
    -- 班恩(往生隐者)高模
        ["4301_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 8.37, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 9, name = "scenes_4301_appearance_01", bone = "", speed = 1 },
                {type = "camera", time = 0, duration = 8.8, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 1.667, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 4.133, name = "Pose02", speed = 1},
            },
        },

-- 1143021 保卢斯(屠魂督军)-正式
    ["4302"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 3.367, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 3.5, name = "scenes_4302_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 2, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 2, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.933, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.3, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 2.2, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.667, name = "LieHit", speed = 1.48},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.267, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.1, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_430201_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1.8, name = "JN-4302-430201-1", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 2.133, name = "Attack02", speed = 1},
            {type = "effect", time = 0.66, duration = 1, name = "skill_430202_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 3, name = "JN-4302-430201-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 3.5, name = "skill_430211_route1", bone = "", speed = 1, is_coexist = true},
            {type = "effect", time = 0.2, duration = 5, name = "skill_430211_route1_m", bone = "", speed = 1, is_coexist = true},
            {type = "effect", time = 1.4, duration = 2, name = "skill_430211_route2", bone = "", speed = 1, is_coexist = true},
            {type = "camera", time = 0.8, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3" },
            --  {type = "camera", time = 1.5, duration = 1.1, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;11" },
            {type = "audio", time = 0, duration = 3, name = "JN-4302-430211", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "audio", time = 1, duration = 5, name = "JN-4302-430211-loop", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 4.033, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_430221_route1", bone = "LeftWeaponPos", speed = 1},
            --  {type = "effect", time = 0.25, duration = 2, name = "skill_430221_route2", bone = "", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "skill_430221_route3", bone = "", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "", bone = "", speed = 1},
            {type = "camera", time = 3, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3" },
            {type = "audio", time = 0, duration = 3, name = "JN-4302-430221", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_430231_route1", bone = "", speed = 1, is_coexist = true},
            {type = "effect", time = 0.63, duration = 2, name = "skill_430231_route2", bone = "", speed = 1, is_coexist = true},
            --  {type = "camera", time = 0.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3" },
            {type = "audio", time = 0, duration = 1, name = "JN-4302-430231", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
    },
    -- 保卢斯(猎魂督军)高模
        ["4302_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 5, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 5, name = "scenes_4302_appearance_01", bone = "", speed = 1 },
                {type = "effect", time = 0, duration = 5, name = "scenes_4302_appearance_02", bone = "", speed = 1 },
                {type = "camera", time = 0, duration = 5.5, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 5.833, name = "Pose02", speed = 1},
            },
        },

-- 1143031 茨维娅(判罪怨魂)-正式 
    ["4303"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 2.833, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 2.5, name = "scenes_4303_born", bone = "", speed = 1 ,is_coexist=true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 2, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 2, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.933, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.3, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 2.2, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Hit", speed = 1.75},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.667, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.267, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.1, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1.5, name = "GetUp", speed = 1.5},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 2, name = "Attack01", speed = 1},
            {type = "effect", time = 0.97, duration = 2, name = "skill_430301_route1", bone = "", speed = 1},
            {type = "audio", time = 0.8, duration = 1, name = "JN-4303-430301", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 2, name = "Attack02", speed = 1},
            {type = "effect", time = 0.87, duration = 1, name = "skill_430302_route1", bone = "", speed = 1},
            {type = "audio", time = 0.7, duration = 1, name = "JN-4303-430302", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 4.167, name = "Spell_01", speed = 1},
            {type = "effect", time = 0.2, duration = 3.5, name = "skill_430311_route1", bone = "", speed = 1, is_coexist = true},
            {type = "effect", time = 1, duration = 4.2, name = "skill_430311_route2", bone = "", speed = 1, is_coexist = true},
            --  {type = "effect", time = 1.4, duration = 2, name = "skill_430311_route2", bone = "", speed = 1, is_coexist = true},
            --  {type = "camera", time = 0.8, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3" },
            --  {type = "camera", time = 1.5, duration = 1.1, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;11" },
            -- {type = "audio", time = 0.5, duration = 1, name = "JN-1102-110221-1", speed = 0.6, volume = 1, bloop = true, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            -- {type = "audio", time = 1, duration = 2.4, name = "JN-1102-110221-1", speed = 0.8, volume = 1, bloop = true, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true}, 
            -- {type = "audio", time = 3.2, duration = 0.8, name = "JN-1102-110221-1", speed = 0.7, volume = 1, bloop = true, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},       
            -- {type = "audio", time = 0.5, duration = 1, name = "JN-4303-430311", speed = 0.8, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},  
            {type = "audio", time = 0, duration = 4.167, name = "JN-4303-430311", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},     
            -- {type = "audio", time = 3.2, duration = 4.167, name = "JN-4303-430311", speed = 0.7, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},     
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 1.933, name = "Spell_02", speed = 1},
            --  {type = "effect", time = 0.2, duration = 4, name = "skill_430321_route1", bone = "", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "skill_430321_route2", bone = "LeftHandPos", speed = 1},
            --  {type = "camera", time = , duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3" },
            {type = "audio", time = 0.5, duration = 5, name = "JN-4303-430321", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            {type = "audio", time = 0.5, duration = 5, name = "JN-4303-430322", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            {type = "audio", time = 1, duration = 5, name = "JN-4303-430321-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},         
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 1.867, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "skill_430331_route1", bone = "LeftHandPos", speed = 1, },
            --  {type = "camera", time = 0.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3" },
            {type = "audio", time = 0.5, duration = 5, name = "JN-4303-430331", speed = 0.8, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
    },
    -- 茨维娅(判罪怨魂)高模
        ["4303_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 5.3, name = "Appearance", speed = 1},
                {type = "effect", time = 1.7, duration = 3, name = "scenes_4303_appearance", bone = "", speed = 1 },
                {type = "camera", time = 0, duration = 5.8, name = "bone", params = "camera_bone;1.5;4.0;1;1.8"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 2, name = "Pose02", speed = 1},
            }
        },

-- -- 
-- --  众神
-- 1151011 拉马努金（遗时之砾）-非正式
    ["5101"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3, name = "Win", speed = 1},
            {type = "effect", time = 0, duration = 5, name = "scenes_5201_win", bone = "", speed = 1 ,},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },  
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.467, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1.1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Attack01", speed = 1},
            {type = "effect", time = 0.2, duration = 1, name = "skill_520101_route1", bone = "", speed = 1},
            {type = "effect", time = 0.5, duration = 1, name = "skill_520101_route2", bone = "", speed = 1},
            {type = "effect", time = 1, duration = 1, name = "skill_520101_route3", bone = "", speed = 1},
            {type = "audio", time = 0.2, duration = 2, name = "JN-5201-520101", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "audio", time = 0.5, duration = 2, name = "JN-5201-520102", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "audio", time = 1, duration = 2, name = "JN-5201-520103", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0.2, duration = 1, name = "skill_520111_route1", bone = "", speed = 1},
            {type = "audio", time = 0.2, duration = 2, name = "JN-5201-520111-Begin", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 0.333, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "skill_520111_route2", bone = "", speed = 1, is_coexist = true},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 0.667, name = "Spell_01_End", speed = 1},
            {type = "effect", time = 0.2, duration = 1, name = "skill_520111_route3", bone = "", speed = 1},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 2, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_520121_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 2, name = "JN-5201-520121", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            --  {type = "effect", time = 0.64, duration = 1, name = "skill_520121_route2", bone = "", speed = 1},
            --  {type = "effect", time = 1.76, duration = 1.5, name = "skill_520121_route3", bone = "", speed = 1},
            --  {type = "camera", time = 1.4, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.5;0;0.1;3"},
        },
        ["spell_03_start"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Spell_03_Begin", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "skill_520131_route1", bone = "", speed = 1,is_coexist = true},
            {type = "audio", time = 0, duration = 4, name = "JN-5201-520131", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist=true},
            --  {type = "effect", time = 1.95, duration = 1, name = "skill_520131_route3", bone = "", speed = 1},
            --  {type = "effect", time = 2, duration = 2, name = "skill_520131_route4", bone = "", speed = 1},
        },
        ["spell_03_loop"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Spell_03_Loop", speed = 1},
        },
        ["spell_03_end"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Spell_03_End", speed = 1},
            {type = "camera", time = 0.4, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"},
        },
    },
    -- 拉马努金（遗时之砾）高模
        ["5201_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 6, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 5, name = "scenes_5201_appearance_01", bone = "", speed = 1 ,},
                {type = "effect", time = 4.3, duration = 1.5, name = "scenes_5201_appearance_02", bone = "RightHandPos", speed = 1 ,},
                {type = "effect", time = 4.3, duration = 1.5, name = "scenes_5201_appearance_03", bone = "LeftHandPos", speed = 1 , },
                {type = "camera", time = 0, duration = 6.5, name = "bone", params = "camera_bone;1.5;2.3;1;1.4"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 4.333, name = "Pose02", speed = 1},
            },
        },
-- 1152011 艾法拉(净世之锋)-正式
    ["5201"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3, name = "Win", speed = 1},
            {type = "effect", time = 0, duration = 5, name = "scenes_5201_win", bone = "", speed = 1 ,},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },  
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.467, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1.1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Attack01", speed = 1},
            {type = "effect", time = 0.2, duration = 1, name = "skill_520101_route1", bone = "", speed = 1},
            {type = "effect", time = 0.5, duration = 1, name = "skill_520101_route2", bone = "", speed = 1},
            {type = "effect", time = 1, duration = 1, name = "skill_520101_route3", bone = "", speed = 1},
            {type = "audio", time = 0.2, duration = 2, name = "JN-5201-520101", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "audio", time = 0.5, duration = 2, name = "JN-5201-520102", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "audio", time = 1, duration = 2, name = "JN-5201-520103", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0.2, duration = 1, name = "skill_520111_route1", bone = "", speed = 1},
            {type = "audio", time = 0.2, duration = 2, name = "JN-5201-520111-Begin", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 0.333, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "skill_520111_route2", bone = "", speed = 1, is_coexist = true},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 0.667, name = "Spell_01_End", speed = 1},
            {type = "effect", time = 0.2, duration = 1, name = "skill_520111_route3", bone = "", speed = 1},
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 2, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_520121_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 2, name = "JN-5201-520121", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            --  {type = "effect", time = 0.64, duration = 1, name = "skill_520121_route2", bone = "", speed = 1},
            --  {type = "effect", time = 1.76, duration = 1.5, name = "skill_520121_route3", bone = "", speed = 1},
            --  {type = "camera", time = 1.4, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.5;0;0.1;3"},
        },
        ["spell_03_start"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Spell_03_Begin", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "skill_520131_route1", bone = "", speed = 1,is_coexist = true},
            {type = "audio", time = 0, duration = 4, name = "JN-5201-520131", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist=true},
            --  {type = "effect", time = 1.95, duration = 1, name = "skill_520131_route3", bone = "", speed = 1},
            --  {type = "effect", time = 2, duration = 2, name = "skill_520131_route4", bone = "", speed = 1},
        },
        ["spell_03_loop"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Spell_03_Loop", speed = 1},
        },
        ["spell_03_end"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Spell_03_End", speed = 1},
            {type = "camera", time = 0.4, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"},
        },
    },
    -- 艾法拉（净世之锋）高模
        ["5201_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 6, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 5, name = "scenes_5201_appearance_01", bone = "", speed = 1 ,},
                {type = "effect", time = 4.3, duration = 1.5, name = "scenes_5201_appearance_02", bone = "RightHandPos", speed = 1 ,},
                {type = "effect", time = 4.3, duration = 1.5, name = "scenes_5201_appearance_03", bone = "LeftHandPos", speed = 1 , },
                {type = "camera", time = 0, duration = 6.5, name = "bone", params = "camera_bone;1.5;2.3;1;1.4"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 4.333, name = "Pose02", speed = 1},
            },
        },
-- 1152021 梵雅娜(轮回之光)-正式75
    ["5202"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "shader", time = 1.2, name = "Death", duration = 0.3, params = ""},
            {type = "anim", time = 0, duration = 3, name = "Win", speed = 1},
            {type = "effect", time = 1.1, duration = 7, name = "scenes_5202_win", bone = "", speed = 1 ,is_coexist = true},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },  
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.467, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 1.1, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_520201_route1", bone = "LeftHandPos", speed = 1},
            -- {type = "effect", time = 1, duration = 1, name = "skill_520201_route3", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-1301-130102", speed = 1, volume = 0.7, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_520201_route2", bone = "", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_520201_route3", bone = "", speed = 1},
            -- {type = "effect", time = 1, duration = 1, name = "skill_520201_route3", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 2, name = "JN-5202-520202", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["attack03"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Attack03", speed = 1},
            {type = "effect", time = 0.5, duration = 2, name = "skill_520201_route4", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 2, name = "JN-5202-520203", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            -- {type = "effect", time = 0.5, duration = 1, name = "skill_520201_route2", bone = "", speed = 1},
            -- {type = "effect", time = 1, duration = 1, name = "skill_520201_route3", bone = "", speed = 1},
        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 2.033, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_520211_route1", bone = "", speed = 1},
            {type = "effect", time = 0.5, duration = 1.6, name = "skill_520211_route2", bone = "ChestPos", speed = 1},
            {type = "effect", time = 0.5, duration = 1.6, name = "skill_520211_route3", bone = "", speed = 1},
            {type = "camera", time = 0.7, duration = 0.5, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;5" },
            {type = "audio", time = 0, duration = 5, name = "JN-5202-520211-begin", speed = 1, volume = 4, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 0.333, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "skill_520211_route4", bone = "ChestPos", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 4, name = "skill_520211_route5", bone = "ChestPos", speed = 1, is_coexist = true},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 0.667, name = "Spell_01_End", speed = 1},
            {type = "audio", time = 0, duration = 5, name = "JN-5202-520211-end", speed = 1, volume = 4, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
            -- {type = "effect", time = 0.2, duration = 1, name = "skill_520211_route3", bone = "", speed = 1},
        },
        ["spell_02_start"] = {
            {type = "anim", time = 0, duration = 2.1, name = "Spell_02_Begin", speed = 1},
            {type = "effect", time = 0, duration = 2.1, name = "skill_520221_route", bone = "RightWeaponPos", speed = 1},
            -- {type = "audio", time = 0, duration = 2, name = "JN-5202-520221", speed = 1, volume = 4, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},

        },
        ["spell_02_loop"] = {
            {type = "anim", time = 0, duration = 2.1, name = "Spell_02_Loop", speed = 1},
            -- {type = "effect", time = 0, duration = 1, name = "skill_520221_route1", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 2, name = "JN-5202-520221", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            --  {type = "effect", time = 0.64, duration = 1, name = "skill_520221_route2", bone = "", speed = 1},
            --  {type = "effect", time = 1.76, duration = 1.5, name = "skill_520221_route3", bone = "", speed = 1},
            --  {type = "camera", time = 1.4, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.5;0;0.1;3"},
        },
        ["spell_02_end"] = {
            {type = "anim", time = 0, duration = 2.1, name = "Spell_02_End", speed = 1},
        },
        ["spell_03_start"] = {
            {type = "anim", time = 0, duration = 2.5, name = "Spell_03_Begin", speed = 1},
            -- {type = "effect", time = 1.5, duration = 1, name = "skill_520231_route1", bone = "", speed = 1},
            -- {type = "effect", time = 1.36, duration = 2.3, name = "skill_520231_route2", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 4, name = "JN-5202-520231", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist=true},
            --  {type = "effect", time = 1.95, duration = 1, name = "skill_520231_route3", bone = "", speed = 1},
            --  {type = "effect", time = 2, duration = 2, name = "skill_520231_route4", bone = "", speed = 1},
        },
        ["spell_03_loop"] = {
            {type = "anim", time = 0, duration = 5, name = "Spell_03_Loop", speed = 1},
            {type = "audio", time = 0, duration = 5, name = "JN-5202-520231", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            -- {type = "effect", time = 0, duration = 1.5, name = "skill_520231_route3", bone = "", speed = 1,},

        },
        ["spell_03_end"] = {
            {type = "anim", time = 0, duration = 1.833, name = "Spell_03_End", speed = 1, is_coexist=true},
            {type = "effect", time = 0, duration = 1.5, name = "skill_520231_route4", bone = "ChestPos", speed = 1},
            {type = "camera", time = 0.4, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"},
            {type = "audio", time = 0, duration = 3, name = "JN-5202-520232", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["spell_04_start"] = {
            {type = "anim", time = 0, duration = 2.1, name = "Spell_04_Begin", speed = 1},
            {type = "effect", time = 0, duration = 2.1, name = "skill_520221_route", bone = "RightWeaponPos", speed = 1},
            {type = "audio", time = 0, duration = 3, name = "JN-5202-520221", speed = 1, volume =1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist= true},

        },
        ["spell_04_loop"] = {
            {type = "anim", time = 0, duration = 2.1, name = "Spell_04_Loop", speed = 1},
            --  {type = "effect", time = 0.64, duration = 1, name = "skill_520221_route2", bone = "", speed = 1},
            --  {type = "effect", time = 1.76, duration = 1.5, name = "skill_520221_route3", bone = "", speed = 1},
            --  {type = "camera", time = 1.4, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.5;0;0.1;3"},
        },
        ["spell_04_end"] = {
            {type = "anim", time = 0, duration = 2.1, name = "Spell_04_End", speed = 1},
        },
    },
    -- 梵雅娜
        ["5202_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 7, name = "Appearance", speed = 1},
                {type = "effect", time = 3.03, duration = 5, name = "scenes_5202_appearance_01", bone = "RightHandPos", speed = 1 ,},
                {type = "effect", time = 3.67, duration = 5, name = "scenes_5202_appearance_02", bone = "RightWeaponPos", speed = 1 ,},
                {type = "effect", time = 4.63, duration = 5, name = "scenes_5202_appearance_03", bone = "", speed = 1 , },
                {type = "effect", time = 5.23, duration = 5, name = "scenes_5202_appearance_04", bone = "", speed = 1 , },
                {type = "effect", time = 5.23, duration = 5, name = "scenes_5202_appearance_05", bone = "ChestPos", speed = 1 , },
                {type = "camera", time = 0, duration = 6.5, name = "bone", params = "camera_bone;1;1.8;0.8;1.3"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 4.6, name = "Pose02", speed = 1},
                {type = "effect", time = 0, duration = 4.6, name = "scenes_5202_pose02", bone = "LeftWeaponPos", speed = 1},
                {type = "effect", time = 0, duration = 4.6, name = "scenes_5202_pose02_1", bone = "", speed = 1},
            },
        },
-- --  恶魔
-- 1161011 墨索斯(罪渊蚀主)-正式
    ["6101"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.767, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 2, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 2, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.4, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3.233, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.667, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.167, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 0.9, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.6, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "skill_610101_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-6101-610101", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "skill_610102_route1", bone = "", speed = 1},  
            {type = "audio", time = 0, duration = 1, name = "JN-6101-610102", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
          
        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 2, name = "Spell_01_Begin", speed = 1},
            {type = "camera", time = 1.6, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.5;0;0.1;5"},
            {type = "effect", time = 0, duration = 1, name = "skill_610111_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 2, name = "JN-6101-610111-begin", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 2.5, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_610111_route2", bone = "", speed = 1},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 2.5, name = "Spell_01_End", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_610111_route3", bone = "", speed = 1},
        },
         ["spell_02"] = {
            {type = "anim", time = 0, duration = 1.367, name = "Spell_02", speed = 1},
            {type = "camera", time = 0.7, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.5;0;0.1;5"},
            {type = "audio", time = 0, duration = 2, name = "JN-6101-610111-begin", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "effect", time = 0, duration = 3, name = "skill_610121_route1", bone = "", speed = 1,is_coexist = true},

        },
        ["spell_03_start"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Spell_03_Begin", speed = 1},
            --  {type = "effect", time = 0, duration = 3, name = "skill_610131_route1", bone = "", speed = 1,is_coexist = true},
        },
        ["spell_03_loop"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Spell_03_Loop", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_610131_route1", bone = "", speed = 1},
        },
        ["spell_03_end"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Spell_03_End", speed = 1},
            {type = "effect", time = 1, duration = 3, name = "skill_610131_route2", bone = "", speed = 1, is_coexist = true},
        },
        ["spell_03_end_02"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Spell_03_End_02", speed = 1},
        },
    },  
    -- 墨索斯(罪渊蚀主)-正式高模
        ["6101_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 6.933, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 8, name = "scenes_6101_appearance_01", bone = "", speed = 1},
                {type = "effect", time = 6.57, duration = 10, name = "scenes_6101_appearance_02", bone = "", speed = 1, is_coexist = true},
                {type = "camera", time = 0, duration = 7.4, name = "bone", params = "camera_bone;1.8;2.8;1;1.6"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max

            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2.067, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 2.067, name = "Pose02", speed = 1},
                {type = "effect", time = 0, duration = 9, name = "scenes_6101_pose02", bone = "", speed = 1 , is_coexist = true},
            },
        },
-- 1163011 拉欢娜(猩红女皇)-正式
    ["6301"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.767, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 2, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 2, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.4, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3.233, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.667, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.167, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 0.9, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.867, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "skill_630101_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1.5, name = "JN-6301-630101", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 2.0, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "skill_630102_route1", bone = "", speed = 1},  
            {type = "audio", time = 0, duration = 1.5, name = "JN-6301-630102", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 5.333, name = "Spell_01", speed = 1},
            -- {type = "camera", time = 1.6, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.5;0;0.1;5"},
            {type = "effect", time = 0, duration = 5, name = "skill_630111_route1", bone = "", speed = 1},
            {type = "audio", time = 3.5, duration = 7.5, name = "JN-6301-630111", speed = 1, volume = 0.8, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
            {type = "audio", time = 0, duration = 6, name = "JN-6301-630111-music", speed = 1, volume = 0.8, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "audio", time = 3, duration = 6, name = "JN-6301-630111-voice", speed = 1, volume = 0.8, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},


        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 2.767, name = "Spell_02", speed = 1},
            -- {type = "camera", time = 0.7, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.5;0;0.1;5"},
            {type = "audio", time = 0, duration = 3.5, name = "JN-6301-630121", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "effect", time = 0, duration = 3, name = "skill_630121_route1", bone = "", speed = 1},

        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 2.267, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_630131_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 3, name = "JN-6301-630131", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
    },
    -- 拉欢娜(猩红女皇)-正式高模
        ["6301_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 6.567, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 7, name = "scenes_6301_appearance_01", bone = "", speed = 1},
                -- {type = "effect", time = 6.57, duration = 10, name = "scenes_6101_appearance_02", bone = "", speed = 1, is_coexist = true},
                {type = "camera", time = 0, duration = 7, name = "bone", params = "camera_bone;0.8;2;0.6;1"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2.067, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 2.067, name = "Pose02", speed = 1},
                -- {type = "effect", time = 0, duration = 9, name = "scenes_6301_pose02", bone = "", speed = 1 , is_coexist = true},
            },
        },
-- 1163021 费尔察克(极寒之灾)-正式
    ["6302"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 1.767, name = "Born", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            -- {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            {type = "anim", time = 0, duration = 2, name = "Stand", speed = 1},
            {type = "effect", time = 0, duration = 1.6, name = "scenes_battle_born", bone = "", speed = 1 , is_coexist = true},
            {type = "shader", time = 0, name = "Born", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 2, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.4, name = "Death", speed = 1},
            {type = "shader", time = 2, name = "Death", duration = 1.5, params = ""},
        },
        ["win"] = {
            {type = "anim", time = 0, duration = 3.233, name = "Win", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.667, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2, name = "Dizzy", speed = 1},
        },
        ["freeze"] = {
            {type = "anim", time = 0, duration = 0.05, name = "Freeze", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.167, name = "FloatingDown", speed = 1},
        },
        ["liedown"] = {
            {type = "anim", time = 0, duration = 0.9, name = "LieDown", speed = 1},
        },
        ["getup"] = {
            {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.867, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "skill_630201_route1", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1.5, name = "JN-6302-630201", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 2.0, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 1.5, name = "skill_630202_route1", bone = "", speed = 1},  
            -- {type = "audio", time = 0, duration = 1.5, name = "JN-6302-630202", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 5.333, name = "Spell_01", speed = 1},
            -- {type = "camera", time = 1.6, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.5;0;0.1;5"},
            {type = "effect", time = 0, duration = 3.5, name = "skill_630211_route1", bone = "RightWeaponPos", speed = 1},
            {type = "effect", time = 0, duration = 3.5, name = "skill_630211_route1", bone = "LeftWeaponPos", speed = 1},
            {type = "effect", time = 0, duration = 5, name = "skill_630211_route2", bone = "", speed = 1},

        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 2.767, name = "Spell_02", speed = 1},
            -- {type = "camera", time = 0.7, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.5;0;0.1;5"},
            -- {type = "audio", time = 0, duration = 3.5, name = "JN-6302-630221", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "effect", time = 0, duration = 3, name = "skill_630221_route1", bone = "RightWeaponPos", speed = 1},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 2.267, name = "Spell_03", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_630231_route1", bone = "RightWeaponPos", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_630231_route1", bone = "LeftWeaponPos", speed = 1},
            {type = "audio", time = 0, duration = 3, name = "JN-6302-630231", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["spell_04_start"] = {
            {type = "effect", time = 0, duration = 3, name = "skill_630241_route1", bone = "", speed = 1},
        },
        ["spell_04_loop"] = {
            {type = "effect", time = 0, duration = 3, name = "skill_630241_route1", bone = "", speed = 1},
        },
        ["spell_04_end"] = {
            {type = "effect", time = 0, duration = 3, name = "skill_630241_route2", bone = "", speed = 1},
        },
        ["spell_04_end_02"] = {
            {type = "effect", time = 0, duration = 3, name = "skill_630241_route2", bone = "", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_630241_route3", bone = "", speed = 1},
        },
    },
    -- 拉欢娜(猩红女皇)-正式高模
        ["6302_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 6.567, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 7, name = "scenes_6302_appearance_01", bone = "", speed = 1},
                -- {type = "effect", time = 6.57, duration = 10, name = "scenes_6101_appearance_02", bone = "", speed = 1, is_coexist = true},
                {type = "camera", time = 0, duration = 7, name = "bone", params = "camera_bone;0.8;2;0.6;1"},-- 分别对应的是镜头推进min 镜头推进max 镜头抬高min 镜头抬高max
            },
            ["pose"] = {
                {type = "anim", time = 0, duration = 2.067, name = "Pose", speed = 1},
            },
            ["pose2"] = {
                {type = "anim", time = 0, duration = 2.067, name = "Pose02", speed = 1},
                -- {type = "effect", time = 0, duration = 9, name = "scenes_6302_pose02", bone = "", speed = 1 , is_coexist = true},
            },
        },
-- 1162011 小怪-地狱恶犬
    ["6201"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.733, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.767, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.133, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.367, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_220101_route1", bone = "", speed = 1},
        },
    },
-- 1162021 小怪-地狱恶犬
    ["6202"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.733, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.767, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.133, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.367, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 1162031 小怪-地狱恶犬
    ["6203"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.733, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.767, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.133, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.367, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 1162041 小怪-地狱恶犬
    ["6204"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.733, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.767, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.133, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.367, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 1161021 小怪-受困囚徒
    ["6102"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.733, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.767, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.133, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 1161031 小怪-受困囚徒（异色1）
    ["6103"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.733, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.767, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.133, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },

-- 1161041 小怪-受困囚徒(异色2)
    ["6104"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.733, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.767, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.133, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- --    -- --
-- --  小怪
-- 121031 小怪-神庙守卫（银色）
    ["7161"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --   {type = "anim", time = 0, duration = 0.7, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 0.433, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 0.6, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121032 小怪-神庙守卫（金色）
    ["7162"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --   {type = "anim", time = 0, duration = 0.7, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 0.433, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 0.6, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121033 小怪-神庙守卫（岩浆色）
    ["7163"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.7, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.2, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 0.433, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 0.6, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121034 小怪-变异魔蜥
    ["7164"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 1, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.333, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.667, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2.167, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.167, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.067, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121035 小怪-变异魔蜥(异色1)
    ["7165"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 1, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.333, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.667, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2.167, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.167, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.067, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121036 小怪-变异魔蜥(异色2)
    ["7166"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        -- ["appearance"] = {
        --     {type = "anim", time = 0, duration = 1, name = "Appearance", speed = 1},
        -- },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 2.333, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.833, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.667, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2.167, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.167, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.067, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121011 小怪-霜狼
    ["7111"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.533, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 0.533, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 10.467, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 0.667, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.3, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.333, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 0.533, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 0.833, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 0.667, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 0.533, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121012 小怪-霜狼(异色1)
    ["7112"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.533, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 0.533, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 10.467, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 0.667, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.3, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.333, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 0.533, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 0.833, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 0.667, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 0.533, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121013 小怪-霜狼(异色2)
    ["7113"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.533, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 0.533, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 10.467, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 0.667, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.3, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.333, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 0.533, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 0.833, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 0.667, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 0.533, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121021 小怪-暗巷歹徒
    ["7121"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.267, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 0.833, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack01", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack02", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121022 小怪-暗巷歹徒(异色1)
    ["7122"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.267, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 0.833, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack01", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack02", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121023 小怪-暗巷歹徒(异色2)
    ["7123"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.267, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 0.833, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack01", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack02", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121021 小怪-暗影蜘蛛
    ["7131"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        -- ["appearance"] = {
        --     {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        -- },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.267, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 0.833, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack02", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121022 小怪-暗影蜘蛛(异色1)
    ["7132"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        -- ["appearance"] = {
        --     {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        -- -- },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.267, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 0.833, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack02", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121023 小怪-暗影蜘蛛(异色2)
    ["7133"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        -- ["appearance"] = {
        --     {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        -- },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.267, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 0.833, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack02", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121041 小怪-地精喽啰
    ["7141"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.733, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.767, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.133, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Attack01", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121042 小怪-地精喽啰（异色1）
    ["7142"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.733, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.767, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.133, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Attack01", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121043 小怪-地精喽啰（异色2）
    ["7143"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.733, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.767, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.133, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Attack01", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 123010 小怪-剑骷髅战士
    ["8012"] = {
        -- ["appearance"] = {
        --     {type = "anim", time = 0, duration = 1.167, name = "Appearance", speed = 1},
        --     {type = "effect", time = 0, duration = 2, name = "common_appearance", bone = "", speed = 1, is_coexist = true },
        --     --  {type = "audio", time = 0, duration = 5, name = "JN-4101-410121-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

        -- },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.2, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death", duration = 0.5, params = ""},
            {type = "effect", time = 0, duration = 2, name = "skill_410151_route1", bone = "", speed = 1},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
            },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.567, name = "Hit", speed = 2},
            },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Dizzy", speed = 1},
            },
        ["attack"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack", speed = 1},
            {type = "effect", time = 0.3, duration = 1, name = "skill_123002_route1", bone = "", speed = 1},
            },
        ["spell"] = {
            {type = "anim", time = 0, duration = 1.4, name = "Spell_01", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
            },
        },
-- 123011 小怪-剑骷髅战士
    ["8022"] = {
        -- ["appearance"] = {
        --     {type = "anim", time = 0, duration = 1.167, name = "Appearance", speed = 1},
        --     {type = "effect", time = 0, duration = 2, name = "common_appearance", bone = "", speed = 1, is_coexist = true },
        --     --  {type = "audio", time = 0, duration = 5, name = "JN-4101-410121-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

        -- },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.2, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death", duration = 0.5, params = ""},
            {type = "effect", time = 0, duration = 2, name = "skill_410151_route1", bone = "", speed = 1},
        },
        ["empty"] = {
        {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.567, name = "Hit", speed = 2},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Dizzy", speed = 1},
        },
        ["attack"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack", speed = 1},
            {type = "effect", time = 0.3, duration = 1, name = "skill_123002_route1", bone = "", speed = 1},
        },
        ["spell"] = {
            {type = "anim", time = 0, duration = 1.4, name = "Spell_01", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 123012 小怪-锤骷髅战士
    ["8013"] = {
        -- ["appearance"] = {
        --     {type = "anim", time = 0, duration = 1.167, name = "Appearance", speed = 1},
        --     {type = "effect", time = 0, duration = 2, name = "common_appearance", bone = "", speed = 1, is_coexist = true },
        --     --  {type = "audio", time = 0, duration = 5, name = "JN-4101-410121-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

        -- },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Stand", speed = 1},
            },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Run", speed = 1},
            },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.2, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death", duration = 0.5, params = ""},
            {type = "effect", time = 0, duration = 2, name = "skill_410151_route1", bone = "", speed = 1},
            },
        ["empty"] = {
        {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
            },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.567, name = "Hit", speed = 2},
            },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Dizzy", speed = 1},
            },
        ["attack"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_123002_route1", bone = "", speed = 1},
            },
        ["spell"] = {
            {type = "anim", time = 0, duration = 1.4, name = "Spell_01", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
            },
    },
-- 123013 小怪-锤骷髅战士
    ["8023"] = {
        -- ["appearance"] = {
        --     {type = "anim", time = 0, duration = 1.167, name = "Appearance", speed = 1},
        --     {type = "effect", time = 0, duration = 2, name = "common_appearance", bone = "", speed = 1, is_coexist = true },
        --     --  {type = "audio", time = 0, duration = 5, name = "JN-4101-410121-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

        -- },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Stand", speed = 1},
            },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Run", speed = 1},
            },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.2, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death", duration = 0.5, params = ""},
            {type = "effect", time = 0, duration = 2, name = "skill_410151_route1", bone = "", speed = 1},
            },
        ["empty"] = {
        {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
            },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.567, name = "Hit", speed = 2},
            },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Dizzy", speed = 1},
            },
        ["attack"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_123002_route1", bone = "", speed = 1},
            },
        ["spell"] = {
            {type = "anim", time = 0, duration = 1.4, name = "Spell_01", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
            },
    },
-- 123014 小怪-弓骷髅战士
    ["8014"] = {
        -- ["appearance"] = {
        --     {type = "anim", time = 0, duration = 1.167, name = "Appearance", speed = 1},
        --     {type = "effect", time = 0, duration = 2, name = "common_appearance", bone = "", speed = 1, is_coexist = true },
        --     --  {type = "audio", time = 0, duration = 5, name = "JN-4101-410121-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

        -- },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Stand", speed = 1},
            },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Run", speed = 1},
            },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.2, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death", duration = 0.5, params = ""},
            {type = "effect", time = 0, duration = 2, name = "skill_410151_route1", bone = "", speed = 1},
            },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
            },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.567, name = "Hit", speed = 2},
            },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Dizzy", speed = 1},
            },
        ["attack"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack", speed = 1},
            --  {type = "effect", time = 0, duration = 1, name = "skill_123002_route1", bone = "", speed = 1},
            },
        ["spell"] = {
            {type = "anim", time = 0, duration = 1.4, name = "Spell_01", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
            },
    },
-- 123015 小怪-弓骷髅战士
    ["8024"] = {
        -- ["appearance"] = {
        --     {type = "anim", time = 0, duration = 1.167, name = "Appearance", speed = 1},
        --     {type = "effect", time = 0, duration = 2, name = "common_appearance", bone = "", speed = 1, is_coexist = true },
        --     --  {type = "audio", time = 0, duration = 5, name = "JN-4101-410121-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},

        -- },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.067, name = "Stand", speed = 1},
            },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.8, name = "Run", speed = 1},
            },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.2, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death", duration = 0.5, params = ""},
            {type = "effect", time = 0, duration = 2, name = "skill_410151_route1", bone = "", speed = 1},
            },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
            },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.567, name = "Hit", speed = 2},
            },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Dizzy", speed = 1},
            },
        ["attack"] = {
            {type = "anim", time = 0, duration = 1, name = "Attack", speed = 1},
            --  {type = "effect", time = 0, duration = 1, name = "skill_123002_route1", bone = "", speed = 1},
            },
        ["spell"] = {
            {type = "anim", time = 0, duration = 1.4, name = "Spell_01", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
            },
    },
-- 121081 小怪-受困囚徒
    ["7151"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.733, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.767, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.133, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121082 小怪-受困囚徒（异色1）
    ["7152"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.733, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.767, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.133, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121083 小怪-受困囚徒（异色2）
    ["7153"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.733, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.767, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.133, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121091 小怪-地狱恶犬
    ["7171"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.733, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.767, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.133, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.367, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121091 小怪-地狱恶犬（异色1）
    ["7172"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.733, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.767, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.133, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 121091 小怪-地狱恶犬（异色2）
    ["7173"] = {
        ["born_battle"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        ["born_hangup"] = {
            -- {type = "shader", time = 0, name = "Hide", duration = 0.3, params = "", is_coexist = true},
            {type = "shader", time = 0, name = "Born_Mon", duration = 0.5, params = "0.04", is_coexist = true}
        },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.733, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 1.7, name = "Death", speed = 1},
            {type = "shader", time = 1, name = "Death_Mon", duration = 0.5, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.767, name = "Hit", speed = 2},
        },
        ["liehit"] = {
            {type = "anim", time = 0, duration = 0.8, name = "LieHit", speed = 1.55},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["floatingup"] = {
            {type = "anim", time = 0, duration = 0.233, name = "FloatingUp", speed = 1},
        },
        ["floatingdown"] = {
            {type = "anim", time = 0, duration = 1.133, name = "FloatingDown", speed = 1},
        },
        ["getup"] = {
                {type = "anim", time = 0, duration = 1, name = "GetUp", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Attack", speed = 1},
            -- {type = "effect", time = 0, duration = 1.8, name = "skill_716101_route1", bone = "", speed = 1},
        },
    },
-- 透明怪
    ["9001"] = {
        ["born_battle"] = {
                    },
        ["born_hangup"] = {
                    },
        --  ["appearance"] = {
        --      {type = "anim", time = 0, duration = 0.433, name = "Appearance", speed = 1},
        --  },
        ["stand"] = {
                    },
        ["run"] = {
                    },
        ["dead"] = {
                    },
        ["empty"] = {
        },
        ["hit"] = {
                    },
        ["liehit"] = {
                    },
        ["dizzy"] = {
                    },
        ["floatingup"] = {
                    },
        ["floatingdown"] = {
                    },
        ["getup"] = {
                        },
        ["attack01"] = {
                    },
    },
-- -- 

-- --  Boss
-- 122011 雪地BOSS-冰霜巨人
    ["7182"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 8, name = "Appearance", speed = 1},
            {type = "audio", time = 0, duration = 7, name = "Boss-7182-appearance_01", speed = 1, volume = 1, bloop = false,is_coexist = true},
            --  {type = "effect", time = 0, duration = 7, name = "scenes_7381_appearance01", bone = "", speed = 1},
            -- {type = "effect", time = 0, duration = 7, name = "scenes_7381_appearance02", bone = "LeftWeaponPos", speed = 1},
            -- {type = "effect", time = 0, duration = 8, name = "scenes_7381_appearance03", bone = "LeftHandPos", speed = 1},
            -- {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance04", bone = "RightHandPos", speed = 1, is_coexist = true},
            --  {type = "effect", time = 4.57, duration = 5, name = "scenes_7381_appearance05", bone = "LeftWeaponPos", speed = 1},
            --  {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance06", bone = "ChestPos", speed = 1, is_coexist = true},
            --  {type = "effect", time = 5.4, duration = 5, name = "scenes_7381_appearance07", bone = "", speed = 1},
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 4.033, name = "Death", speed = 1},
            {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Run", speed = 1},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 2.333, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_718201_route1", bone = "", speed = 1},
            {type = "audio", time = 1, duration = 1.667, name = "JN-7182-718201", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 2.467, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_718202_route1", bone = "", speed = 1},
            {type = "audio", time = 1, duration = 1.667, name = "JN-7182-718201", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3, name = "Spell_01", speed = 1},
            --  {type = "effect", time = 0, duration = 2, name = "skill_718211_route1", bone = "", speed = 1, is_coexist = true},          
            {type = "effect", time = 0, duration = 1.5, name = "skill_718211_route2", bone = "Bip001 R Toe0", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 2, name = "skill_718211_route3", bone = "", speed = 1, is_coexist = true},
            {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
            {type = "camera", time = 1.2, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1;0;0.1;5", is_coexist = true},
            {type = "audio", time = 1.2, duration = 5, name = "JN-7182-718211", speed = 1, volume = 1, bloop = false, is_coexist = true },

        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 3.5, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_718221_route1", bone = "", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 1, name = "skill_718221_route2", bone = "", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 3.5, name = "skill_718221_route3", bone = "", speed = 1, is_coexist = true},
            {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
            {type = "camera", time = 1.4, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1;0;0.1;5", is_coexist = true},
            --  {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
            {type = "audio", time = 1, duration = 1, name = "JN-7182-718221", speed = 1, volume = 1, bloop = false, is_coexist = true },
            {type = "audio", time = 1.1, duration = 3, name = "JN-7182-718221-Hit", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
    },
    -- 冰霜巨人界面展示模型
        ["7182_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 8.233, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 8, name = "scenes_7182_appearance_01", bone = "", speed = 1 },
            },
            ["stand"] = {
                {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
            },
        },
-- 122031 荒漠BOSS-雷神巨像
    ["7381"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 7, name = "Appearance", speed = 1},
            {type = "audio", time = 0, duration = 7, name = "YY-BOSS-10001-1", speed = 0.88, volume = 1, bloop = false,is_coexist = true},
            -- {type = "effect", time = 0, duration = 7, name = "scenes_7381_appearance01", bone = "EyePos", speed = 1},
            -- {type = "effect", time = 0, duration = 7, name = "scenes_7381_appearance02", bone = "LeftWeaponPos", speed = 1},
            -- {type = "effect", time = 0, duration = 8, name = "scenes_7381_appearance03", bone = "LeftHandPos", speed = 1},
            -- {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance04", bone = "RightHandPos", speed = 1, is_coexist = true},
            {type = "effect", time = 4.57, duration = 5, name = "scenes_7381_appearance05", bone = "LeftWeaponPos", speed = 1},
            {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance06", bone = "ChestPos", speed = 1, is_coexist = true},
            {type = "effect", time = 5.4, duration = 5, name = "scenes_7381_appearance07", bone = "", speed = 1},
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 4.033, name = "Death", speed = 1},
            {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Attack_01", speed = 1},
            {type = "effect", time = 0, duration = 1.667, name = "skill_738101_route1", bone = "LeftWeaponPos", speed = 1},
            --  {type = "audio", time = 0, duration = 1.667, name = "JN-LS-10001-1", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Attack_01", speed = 1},
            {type = "effect", time = 0, duration = 1.667, name = "skill_738101_route1", bone = "LeftWeaponPos", speed = 1},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3.967, name = "Spell_01", speed = 1},
            {type = "effect", time = 1, duration = 1.5, name = "skill_738111_route1", bone = "ChestPos", speed = 1},
            {type = "effect", time = 1.77, duration = 1.5, name = "skill_738111_route2", bone = "", speed = 1},
            {type = "effect", time = 1.77, duration = 1.5, name = "skill_738111_route3", bone = "ChestPos", speed = 1},
            {type = "camera", time = 0, duration = 1.5, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;15"},
            {type = "camera", time = 1.8, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1.6;0;0.1;3"},
            {type = "audio", time = 0, duration = 6.5, name = "JN-LS-10002-1", speed = 1.3, volume = 1, bloop = false},
        },
        --  ["spell_01_start"] = {
        --      {type = "anim", time = 0, duration = 3.933, name = "Spell_01_Begin", speed = 1},
        --      {type = "effect", time = 1, duration = 1.5, name = "skill_738111_route1", bone = "ChestPos", speed = 1},
        --      {type = "effect", time = 1.77, duration = 1.5, name = "skill_738111_route2", bone = "", speed = 1},
        --      {type = "effect", time = 1.77, duration = 1.5, name = "skill_738111_route3", bone = "ChestPos", speed = 1},
        --      {type = "camera", time = 0, duration = 1.5, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;15"},
        --      {type = "camera", time = 1.8, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1.6;0;0.1;3"},
        --      {type = "audio", time = 0, duration = 6.5, name = "JN-LS-10002-1", speed = 1.3, volume = 1, bloop = false},
        --  },
        --  ["spell_01_loop"] = {
        --      {type = "anim", time = 0, duration = 5, name = "Spell_01_Loop", speed = 1},
        --      {type = "effect", time = 0, duration = 5, name = "skill_738121_route2", bone = "", speed = 1},
        --  },
        --  ["spell_01_run"] = {
        --      {type = "anim", time = 0, duration = 5, name = "Spell_01_Run", speed = 1},
        --      {type = "effect", time = 0, duration = 5, name = "skill_738121_route2", bone = "", speed = 1},
        --  },
        --  ["spell_01_end"] = {
        --      {type = "anim", time = 0, duration = 1.167, name = "Spell_01_End", speed = 1},
        --  },
        ["spell_02_start"] = {
            {type = "anim", time = 0, duration = 1.833, name = "Spell_02_Begin", speed = 1},
            {type = "effect", time = 0, duration = 5, name = "skill_738121_route1", bone = "", speed = 1, is_coexist = true},
            {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
            {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
            {type = "audio", time = 0, duration = 5, name = "JN-LS-10003-1", speed = 1, volume = 1, bloop = false, is_coexist = true },
            {type = "audio", time = 1.7, duration = 5, name = "JN-LS-10003-2", speed = 1, volume = 0.5, bloop = false, is_coexist = true},
        },
        ["spell_02_loop"] = {
            {type = "anim", time = 0, duration = 5, name = "Spell_02_Loop", speed = 1},
            {type = "effect", time = 0, duration = 5, name = "skill_738121_route2", bone = "", speed = 1},
        },
        ["spell_02_end"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Spell_02_End", speed = 1},
        },
    },
    -- 雷神巨像界面展示模型
        ["7381_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 8.233, name = "Appearance", speed = 1},
            },
            ["stand"] = {
                {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
            },
        },
-- 122032 荒漠BOSS-魔化沙虫j
    ["7181"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 5.9, name = "Appearance", speed = 1},
            {type = "effect", time = 0, duration = 8, name = "scenes_7181_appearance_01", bone = "", speed = 1, is_coexist = true },
            {type = "effect", time = 0, duration = 6, name = "scenes_7181_appearance_02", bone = "MouthPos", speed = 1 },
            {type = "audio", time = 0, duration = 7, name = "Boss-7181-appearance1", speed = 1, volume = 1, bloop = false,is_coexist = true},
            -- {type = "effect", time = 0, duration = 7, name = "scenes_7381_appearance02", bone = "LeftWeaponPos", speed = 1},
            -- {type = "effect", time = 0, duration = 8, name = "scenes_7381_appearance03", bone = "LeftHandPos", speed = 1},
            -- {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance04", bone = "RightHandPos", speed = 1, is_coexist = true},
            -- {type = "effect", time = 4.57, duration = 5, name = "scenes_7381_appearance05", bone = "LeftWeaponPos", speed = 1},
            -- {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance06", bone = "ChestPos", speed = 1, is_coexist = true},
            -- {type = "effect", time = 5.4, duration = 5, name = "scenes_7381_appearance07", bone = "", speed = 1},
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Stand", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 4, name = "Death", speed = 1},
            {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 2.9, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_718101_route1", bone = "", speed = 1, is_coexist = true},
            {type = "audio", time = 0, duration = 3, name = "Boss-7181-718101", speed = 1, volume = 1, bloop = false,},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 2.833, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_718102_route1", bone = "", speed = 1, is_coexist = true},
            {type = "audio", time = 0, duration = 3, name = "Boss-7181-718101", speed = 1, volume = 1, bloop = false,},

        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_718111_route1", bone = "", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 4, name = "skill_718111_route2", bone = "", speed = 1, is_coexist = true},
            -- {type = "effect", time = 1.77, duration = 1.5, name = "skill_738111_route3", bone = "ChestPos", speed = 1},
            -- {type = "camera", time = 0, duration = 1.5, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;15"},
            -- {type = "camera", time = 1.8, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1.6;0;0.1;3"},
            -- {type = "audio", time = 0, duration = 6.5, name = "JN-LS-10002-1", speed = 1.3, volume = 1, bloop = false},
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 0.667, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 1, duration = 2, name = "skill_718111_route3", bone = "", speed = 1, is_coexist = true},
            -- {type = "effect", time = 1.77, duration = 1.5, name = "skill_738111_route2", bone = "", speed = 1},
            -- {type = "effect", time = 1.77, duration = 1.5, name = "skill_738111_route3", bone = "ChestPos", speed = 1},
            -- {type = "camera", time = 0, duration = 1.5, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;15"},
            -- {type = "camera", time = 1.8, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1.6;0;0.1;3"},
            -- {type = "audio", time = 0, duration = 6.5, name = "JN-LS-10002-1", speed = 1.3, volume = 1, bloop = false},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Spell_01_End", speed = 1},
            {type = "camera", time = 0, duration = 0.5, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;3"},
            {type = "audio", time = 0, duration = 1, name = "Boss-7181-718111-hit", speed = 1.3, volume = 1, bloop = false},
            {type = "effect", time = 0, duration = 3, name = "skill_718111_route4", bone = "", speed = 1},
        },
        ["spell_02_start"] = {
            {type = "anim", time = 0, duration =0.667, name = "Spell_02_Begin", speed = 1},
            -- {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
            -- {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
            {type = "audio", time = 0, duration = 6, name = "Boss-7181-718121", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["spell_02_loop"] = {
            {type = "anim", time = 0, duration = 0.333, name = "Spell_02_Loop", speed = 1},
            -- {type = "effect", time = 0, duration = 5, name = "skill_738121_route2", bone = "", speed = 1},
        },
        ["spell_02_loop02"] = {
            {type = "anim", time = 0, duration = 3.5, name = "Spell_02_Loop02", speed = 1},
            {type = "effect", time = 0, duration = 1.84, name = "skill_718121_route2", bone = "MouthPos", speed = 1,},
            {type = "effect", time = 0, duration = 1.5, name = "skill_718121_route2_1", bone = "", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_718121_route5", bone = "", speed = 1},
        },
        ["spell_02_end"] = {
            {type = "anim", time = 0, duration = 2.6, name = "Spell_02_End", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_718121_route1", bone = "MouthPos", speed = 1,},
            {type = "effect", time = 0, duration = 3, name = "skill_718121_route3", bone = "MouthPos", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 6, name = "skill_718121_route4", bone = "MouthPos", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 5, name = "skill_718121_route6", bone = "", speed = 1, is_coexist = true},
        },
    },
    -- 魔化沙虫界面展示模型
        ["7181_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 8.233, name = "Appearance", speed = 1},
            },
            ["stand"] = {
                {type = "anim", time = 0, duration = 2.667, name = "Stand", speed = 1},
            },
        },

-- 122041 森林BOSS-元祖蛇蜥
    ["7383"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 7, name = "Appearance", speed = 1},
            {type = "audio", time = 0, duration = 8, name = "Boss-7383-appearance_01", speed = 1, volume = 1, bloop = false,is_coexist = true},
            --  {type = "effect", time = 0, duration = 7, name = "scenes_7381_appearance01", bone = "EyePos", speed = 1},
            --  -- {type = "effect", time = 0, duration = 7, name = "scenes_7381_appearance02", bone = "LeftWeaponPos", speed = 1},
            --  -- {type = "effect", time = 0, duration = 8, name = "scenes_7381_appearance03", bone = "LeftHandPos", speed = 1},.0.
            --  -- {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance04", bone = "RightHandPos", speed = 1, is_coexist = true},
            --  {type = "effect", time = 4.57, duration = 5, name = "scenes_7381_appearance05", bone = "LeftWeaponPos", speed = 1},
            --  {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance06", bone = "ChestPos", speed = 1, is_coexist = true},
            --  {type = "effect", time = 5.4, duration = 5, name = "scenes_7381_appearance07", bone = "", speed = 1},
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 4.033, name = "Death", speed = 1},
            {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 2.033, name = "Attack01", speed = 1},
            {type = "effect", time = 1.33, duration = 1.27, name = "skill_738301_route1", bone = "MouthPos", speed = 1},
            {type = "audio", time = 1.33, duration = 1.667, name = "JN-7383-718301", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 2, name = "Attack02", speed = 1},
            {type = "effect", time = 1.17, duration = 0.97, name = "skill_738303_route1", bone = "MouthPos02", speed = 1},
            {type = "audio", time = 1.17, duration = 1.667, name = "JN-7383-718301", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["attack03"] = {
            {type = "anim", time = 0, duration = 2, name = "Attack03", speed = 1},
            {type = "effect", time = 1.17, duration = 1.04, name = "skill_738303_route1", bone = "MouthPos03", speed = 1},
            {type = "audio", time = 1.17, duration = 1.667, name = "JN-7383-718301", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3.86, name = "Spell_01", speed = 1},
            {type = "effect", time = 2.2, duration = 2.53, name = "skill_738311_route1", bone = "MouthPos", speed = 1, },
            {type = "effect", time = 2.2, duration = 2.53, name = "skill_738312_route1", bone = "MouthPos02", speed = 1, },
            {type = "effect", time = 2.2, duration = 2.53, name = "skill_738313_route1", bone = "MouthPos03", speed = 1, },
            {type = "camera", time = 2.2, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;10"},
            --  {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
            {type = "audio", time = 2.2, duration = 5, name = "JN-7383-718311", speed = 0.8, volume = 1, bloop = false, is_coexist = true },
        },

        ["spell_02"] = {
            {type = "anim", time = 0, duration = 4.4, name = "Spell_02", speed = 1},
            {type = "effect", time = 1.83, duration = 2.53, name = "skill_738321_route1", bone = "MouthPos", speed = 1,},
            {type = "effect", time = 2.19, duration = 2.23, name = "skill_738322_route1", bone = "MouthPos02", speed = 1,},
            {type = "effect", time = 2.43, duration = 3.13, name = "skill_738323_route1", bone = "MouthPos03", speed = 1,},
            {type = "effect", time = 2.66, duration = 2.53, name = "skill_738321_route1", bone = "MouthPos", speed = 1,},
            {type = "effect", time = 2.93, duration = 2.23, name = "skill_738322_route1", bone = "MouthPos02", speed = 1, },
            {type = "effect", time = 3.20, duration = 3.13, name = "skill_738323_route1", bone = "MouthPos03", speed = 1, },
            --  {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
            --  {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
            {type = "audio", time = 1.83, duration = 5, name = "JN-7383-738321", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },

        ["spell_03"] = {
            {type = "anim", time = 0, duration = 3.5, name = "Spell_03", speed = 1},
            {type = "effect", time = 0.5, duration = 0.82, name = "skill_738331_route1", bone = "MouthPos02", speed = 1,},
            --  {type = "effect", time = 0.82, duration = 5, name = "skill_738331_route2", bone = "", speed = 1, is_coexist = true},
            --  {type = "effect", time = 0, duration = 5, name = "skill_738332_route2", bone = "", speed = 1, is_coexist = true},

        },
        ["spell_04"] = {
            {type = "anim", time = 0, duration = 3.5, name = "Spell_04", speed = 1},
            {type = "effect", time = 0.5, duration = 0.82, name = "skill_738331_route1", bone = "MouthPos", speed = 1, },
            --  {type = "effect", time = 0.82, duration = 5, name = "skill_738331_route2", bone = "", speed = 1, is_coexist = true},
            --  {type = "effect", time = 0, duration = 5, name = "skill_738332_route2", bone = "", speed = 1, is_coexist = true},

        },
        ["spell_05"] = {
            {type = "anim", time = 0, duration = 3.5, name = "Spell_05", speed = 1},
            {type = "effect", time = 0.5, duration = 0.82, name = "skill_738331_route1", bone = "MouthPos03", speed = 1,},
            --  {type = "effect", time = 0.82, duration = 5, name = "skill_738331_route2", bone = "", speed = 1, is_coexist = true},
            --  {type = "effect", time = 0, duration = 5, name = "skill_738332_route2", bone = "", speed = 1, is_coexist = true},

        },
        
    },
    -- 元祖蛇蜥界面展示模型
        ["7383_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 8.233, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 8, name = "scenes_7383_appearance_01", bone = "", speed = 1 },

            },
            ["stand"] = {
                {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
            },
        },
-- 122051 五色龙BOSS-红龙
    ["7382"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 9.567, name = "Appearance", speed = 1},
            {type = "audio", time = 0, duration = 9, name = "Boss-7382-appearance1", speed = 1, volume = 1, bloop = false,is_coexist = true},
            {type = "effect", time = 4.3, duration = 2, name = "scenes_7382_appearance_01", bone = "", speed = 1 },
            {type = "effect", time = 6.17, duration = 2.5, name = "scenes_7382_appearance_02", bone = "MouthPos", speed = 1, is_coexist = true},
        },
        ["born_battle02"] = {
            {type = "anim", time = 0, duration = 9.567, name = "Appearance02", speed = 1},
            -- {type = "audio", time = 0, duration = 9, name = "Boss-7382-appearance2", speed = 1, volume = 1, bloop = false,is_coexist = true},
            {type = "effect", time = 5.54, duration = 2, name = "scenes_7382_appearance_01", bone = "", speed = 1},
            {type = "effect", time = 7.6, duration = 2.5, name = "scenes_7382_appearance_02", bone = "MouthPos", speed = 1},
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.467, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 5.167, name = "Death", speed = 1},
            {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 1.2, name = "Hit", speed = 2},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Dizzy", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 3.167, name = "Attack", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_738201_route1", bone = "MouthPos", speed = 1},
            {type = "camera", time = 1.1, duration = 1.8, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.1;0;0.1;18" },
            {type = "audio", time = 0, duration = 2, name = "Boss-7382-738201", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 1.633, name = "Spell_01_Begin", speed = 0.7},
            {type = "effect", time = 0.5, duration = 5, name = "skill_738211_route1", bone = "", speed = 1, is_coexist = true},
            {type = "audio", time = 0, duration = 1, name = "Boss-7382-738211", speed = 1, volume = 1, bloop = false, },
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 1.6, name = "Spell_01_Loop", speed = 1},
            {type = "audio", time = 0, duration = 15, name = "Boss-7382-738211-loop", speed = 1, volume = 1, bloop = true,is_coexist = true},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Spell_01_End", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_738211_route5", bone = "", speed = 1},
            {type = "camera", time = 0.3, duration = 0.5, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1.2;0;0.1;5" },
            {type = "audio", time = 0, duration = 1, name = "Boss-7382-738211-hit", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 3.067, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_738221_route1", bone = "", speed = 1 },
            {type = "effect", time = 0, duration = 3, name = "skill_738221_route2", bone = "MouthPos", speed = 1 },
            {type = "effect", time = 1.8, duration = 3, name = "skill_738221_route3", bone = "", speed = 1 },
            {type = "audio", time = 0, duration = 5, name = "Boss-7382-738221", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
    },
    -- 红龙界面展示模型
        ["7382_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 10.667, name = "Appearance", speed = 1},
            },
            ["stand"] = {
                {type = "anim", time = 0, duration = 2.667, name = "Stand", speed = 1},
            },
        },
    -- 红龙召唤物龙蛋
        ["8005"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 0.333, name = "Stand", speed = 1},
                {type = "effect", time = 0, duration = 1, name = "skill_123005_route1", bone = "", speed = 1, is_coexist = true },

            },
            ["stand"] = {
                {type = "anim", time = 0, duration = 0.333, name = "Stand", speed = 1},

            },
            ["dead"] = {
                {type = "anim", time = 0, duration = 0.333, name = "Death", speed = 1},
                {type = "shader", time = 0, name = "Death", duration = 0.3, params = ""},
                {type = "effect", time = 0.3, duration = 1.5, name = "skill_123005_route3", bone = "", speed = 1, is_coexist = true },

            },
        },

-- 122052 五色龙BOSS-洞窟红龙
    ["7384"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 9.033, name = "Appearance02", speed = 1},
            {type = "audio", time = 0, duration = 9, name = "Boss-7382-appearance2", speed = 1, volume = 1, bloop = false,is_coexist = true},
            {type = "effect", time = 5.7, duration = 2.5, name = "scenes_7382_appearance02_01", bone = "MouthPos", speed = 1},
        },
        ["born_battle02"] = {
            {type = "anim", time = 0, duration = 9.567, name = "Appearance02", speed = 1},
            -- {type = "audio", time = 0, duration = 7, name = "YY-BOSS-10001-1", speed = 0.88, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            {type = "effect", time = 5.54, duration = 2, name = "scenes_7382_appearance_01", bone = "", speed = 1},
            {type = "effect", time = 7.6, duration = 2.5, name = "scenes_7382_appearance_02", bone = "MouthPos", speed = 1},
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.467, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 5.167, name = "Death", speed = 1},
            {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 1.2, name = "Hit", speed = 2},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Dizzy", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 3.167, name = "Attack", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_738201_route1", bone = "MouthPos", speed = 1},
            {type = "camera", time = 1.1, duration = 1.8, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.1;0;0.1;18" },
            -- {type = "audio", time = 0, duration = 1.667, name = "JN-LS-10001-1", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 1.633, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_738211_route1", bone = "", speed = 1, is_coexist = true},
            -- {type = "audio", time = 0, duration = 5, name = "JN-LS-10003-1", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 1.6, name = "Spell_01_Loop", speed = 1},
            -- {type = "effect", time = 0, duration = 5, name = "skill_738121_route2", bone = "", speed = 1},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Spell_01_End", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_738211_route5", bone = "", speed = 1},
            {type = "camera", time = 0.3, duration = 0.5, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1.2;0;0.1;5" },
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 3.067, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_738221_route1", bone = "", speed = 1 },
            {type = "effect", time = 0, duration = 3, name = "skill_738221_route2", bone = "MouthPos", speed = 1 },
            {type = "effect", time = 2.34, duration = 3, name = "skill_738221_route3", bone = "", speed = 1, is_coexist = true },
            -- {type = "audio", time = 0, duration = 5, name = "JN-LS-10003-1", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
    },
    -- 红龙界面展示模型
        ["7384_ex"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 10.667, name = "Appearance", speed = 1},
            },
            ["stand"] = {
                {type = "anim", time = 0, duration = 2.667, name = "Stand", speed = 1},
            },
        },
    -- 红龙召唤物龙蛋
        ["8005"] = {
            ["appearance"] = {
                {type = "anim", time = 0, duration = 0.333, name = "Stand", speed = 1},
                {type = "effect", time = 0, duration = 1, name = "skill_123005_route1", bone = "", speed = 1, is_coexist = true },
            },
            ["stand"] = {
                {type = "anim", time = 0, duration = 0.333, name = "Stand", speed = 1},
            },
            ["dead"] = {
                {type = "anim", time = 0, duration = 0.333, name = "Death", speed = 1},
                {type = "shader", time = 0, name = "Death", duration = 0.3, params = ""},
                {type = "effect", time = 0.3, duration = 1.5, name = "skill_123005_route3", bone = "", speed = 1, is_coexist = true },
            },
        },
-- 122201 公会BOSS-地精奴隶主
    ["7385"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 7, name = "Appearance", speed = 1},
            {type = "audio", time = 0, duration = 7, name = "Boss-7385-appearance_01", speed = 1, volume = 1, bloop = false, is_coexist = true},
            {type = "effect", time = 0, duration = 3, name = "scenes_7385_appearance_01", bone = "", speed = 1},
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 4.033, name = "Death", speed = 1},
            {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
        },
        ["empty"] = {
                {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Run", speed = 1},
            -- {type = "effect", time = 0, duration = 10, name = "skill_738521_route", bone = "", speed = 3,},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 2.333, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_738501_route", bone = "LeftWeaponPos", speed = 1},
            {type = "audio", time = 1, duration = 2.333, name = "JN-7385-738501", speed = 0.8 ,volume = 0.8, bloop = false, is_coexist = true },
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 4, name = "Spell_01", speed = 1},
            {type = "effect", time = 0, duration = 4, name = "skill_738511_route1", bone = "Bone013", speed = 1, is_coexist = false},
            {type = "effect", time = 0, duration = 4, name = "skill_738511_route2", bone = "", speed = 1, is_coexist = false},
            {type = "camera", time = 1, duration = 3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.05;60" , is_coexist = false},               
            --  {type = "effect", time = 0, duration = 1.5, name = "skill_738511_route2", bone = "Bip001 R Toe0", speed = 1, is_coexist = true},
            {type = "audio", time = 0, duration = 5, name = "JN-7385-738511", speed = 1, volume = 1, bloop = false, is_coexist = true },

        },
        ["spell_02_start"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Spell_02_Begin", speed = 1},
            --  {type = "audio", time = 0, duration = 1, name = "JN-7385-738501", speed = 1 ,volume = 0.8, bloop = false, is_coexist = true },
            --  {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
            --  {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
            --  {type = "audio", time = 0, duration = 5, name = "JN-LS-10003-1", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["spell_02_loop"] = {
                {type = "anim", time = 0, duration = 5, name = "Spell_02_Loop", speed = 3},
                {type = "effect", time = 0, duration = 10, name = "skill_738521_route", bone = "", speed = 3,},
                --  {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
                --  {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
                -- {type = "audio", time = 0, duration = 30, name = "JN-7385-738521", speed = 0.7, volume = 0.4, bloop = true, },
                -- {type = "audio", time = 0.1, duration = 30, name = "JN-7385-738521", speed = 0.7, volume = 0.4, bloop = true, },

            },
        },
-- 122202 公会BOSS-矮人构造物
    ["7183"] = {
    ["born_battle"] = {
        {type = "anim", time = 0, duration = 7, name = "Appearance", speed = 1},
        {type = "audio", time = 0, duration = 7, name = "Boss-7183-appearance_01", speed = 1, volume = 1, bloop = false,is_coexist = true},
        {type = "effect", time = 0, duration = 4, name = "scenes_7183_appearance_01", bone = "", speed = 1},
        {type = "effect", time = 0, duration = 5, name = "scenes_7183_appearance_02", bone = "Bone003", speed = 1},
    },
    ["stand"] = {
        {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
    },
    ["dead"] = {
        {type = "anim", time = 0, duration = 4.033, name = "Death", speed = 1},
        {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
    },
    ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
    },
    ["run"] = {
        {type = "anim", time = 0, duration = 1.133, name = "Run", speed = 1},
    },
    ["hit"] = {
        {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
    },
    ["dizzy"] = {
        {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
    },
    ["attack01"] = {
        {type = "anim", time = 0, duration = 2.067, name = "Attack01", speed = 1},
        {type = "effect", time = 0, duration = 2, name = "skill_718301_route1", bone = "RightWeaponPos", speed = 1},
        {type = "audio", time = 0, duration = 1.667, name = "JN-7183-718301", speed = 1, volume = 1, bloop = false, is_coexist = true },
    },
    ["attack02"] = {
        {type = "anim", time = 0, duration = 2.2, name = "Attack02", speed = 1},
        {type = "effect", time = 0.88, duration = 2, name = "bullet_718301", bone = "", speed = 1},
        {type = "audio", time = 0, duration = 1.667, name = "JN-7183-718301", speed = 1, volume = 1, bloop = false, is_coexist = true },
    },
    ["spell_01"] = {
        {type = "anim", time = 0, duration = 3.5, name = "Spell_01", speed = 1},
        {type = "effect", time = 0, duration = 10, name = "skill_718311_route1", bone = "", speed = 1, },          
        {type = "camera", time = 1.5, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.1;0;0.1;10"},
        --  {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
        {type = "audio", time = 1.5, duration = 5, name = "JN-7183-718311", speed = 1, volume = 1, bloop = false, is_coexist = true },

    },
    ["spell_02"] = {
        {type = "anim", time = 0, duration = 4.2, name = "Spell_02", speed = 1},
        {type = "effect", time = 0, duration = 3.8, name = "skill_718321_route1", bone = "", speed = 1, is_coexist = true},
        --  {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
        {type = "camera", time = 2, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;15"},
        {type = "audio", time = 2, duration = 5, name = "JN-7183-718321", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
    },
    --  矮人构造物召唤物炸弹
        ["8006"] = {
            ["appearance"] = {
                --  {type = "anim", time = 0, duration = 0.533, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 1, name = "skill_718321_route2", bone = "", speed = 1, is_coexist = true},
            },

            --  ["attack01"] = {
            --      {type = "effect", time = 0, duration = 0.5, name = "skill_718321_route3", bone = "", speed = 1, is_coexist = true},
            --  },

            ["dead"] = {
                --  {type = "anim", time = 0, duration = 4.033, name = "Death", speed = 1},
                {type = "effect", time = 0, duration = 4, name = "skill_718321_route4", bone = "", speed = 1, is_coexist = true},
                {type = "camera", time = 2, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;3"},
                {type = "shader", time = 0, name = "Death", duration = 0, params = ""},
            },

            ["spell_01"] = {
                --  {type = "anim", time = 0, duration = 3.5, name = "Spell_01", speed = 1},
                {type = "effect", time = 0, duration = 1.5, name = "skill_718321_route4", bone = "", speed = 1, is_coexist = true},          
            },

        },
-- 122203 公会BOSS- 虚空领主
    ["7386"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 7, name = "Appearance", speed = 1},
            -- {type = "audio", time = 0, duration = 7, name = "Boss-7183-appearance_01", speed = 1, volume = 1, bloop = false,is_coexist = true},
            {type = "effect", time = 0, duration = 4, name = "scenes_7386_appearance_01", bone = "WeaponPos", speed = 1},
            {type = "effect", time = 2.03, duration = 5, name = "scenes_7386_appearance_02", bone = "MouthPos", speed = 1},
            {type = "effect", time = 2.03, duration = 5, name = "scenes_7386_appearance_03", bone = "Bone006", speed = 1},
            {type = "effect", time = 2.03, duration = 5, name = "scenes_7386_appearance_04", bone = "Bone010", speed = 1},
            {type = "effect", time = 0.63, duration = 5, name = "scenes_7386_appearance_05", bone = "ChestPos", speed = 1},
            {type = "effect", time = 0.67, duration = 5, name = "scenes_7386_appearance_06", bone = "LeftHandPos", speed = 1},
            {type = "effect", time = 0.67, duration = 5, name = "scenes_7386_appearance_06", bone = "RightHandPos", speed = 1},
            {type = "effect", time = 4.46, duration = 5, name = "scenes_7386_appearance_07", bone = "", speed = 1},
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 4.033, name = "Death", speed = 1},
            {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
        },
        ["empty"] = {
                {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Run", speed = 1},
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 2.067, name = "Attack01", speed = 1},
            {type = "effect", time = 0.76, duration = 2, name = "skill_738601_route1", bone = "WeaponPos", speed = 1},
            -- {type = "audio", time = 0, duration = 1.667, name = "JN-7183-718301", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 2.2, name = "Attack02", speed = 1},
            {type = "effect", time = 0.7, duration = 2, name = "skill_738601_route1", bone = "WeaponPos", speed = 1},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Spell_01", speed = 1},
            {type = "effect", time = 1.2, duration = 2, name = "skill_738611_route1", bone = "", speed = 1},
        },
        ["spell_02_start"] = {
            {type = "anim", time = 0, duration = 1.833, name = "Spell_02_Begin", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_738621_route1", bone = "LeftHandPos", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_738621_route1", bone = "RightHandPos", speed = 1},
        },
        ["spell_02_loop"] = {
            {type = "anim", time = 0, duration = 4.2, name = "Spell_02_Loop", speed = 1},
        },
        ["spell_02_end"] = {
            {type = "anim", time = 0, duration = 4.2, name = "Spell_02_End", speed = 1},
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 2.33, name = "Spell_03", speed = 1},
            {type = "effect", time = 0.9, duration = 2, name = "skill_738631_route1", bone = "", speed = 1},
        },
    },
-- 122202 主线BOSS-机甲守卫
    ["7184"] = {
    ["born_battle"] = {
        {type = "anim", time = 0, duration = 7, name = "Appearance", speed = 1},
        {type = "audio", time = 0, duration = 7, name = "Boss-7183-appearance_01", speed = 1, volume = 1, bloop = false,is_coexist = true},
        {type = "effect", time = 0, duration = 4, name = "scenes_7183_appearance_01", bone = "", speed = 1},
        {type = "effect", time = 0, duration = 5, name = "scenes_7183_appearance_02", bone = "Bone003", speed = 1},
    },
    ["stand"] = {
        {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
    },
    ["dead"] = {
        {type = "anim", time = 0, duration = 4.033, name = "Death", speed = 1},
        {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
    },
    ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
    },
    ["run"] = {
        {type = "anim", time = 0, duration = 1.133, name = "Run", speed = 1},
    },
    ["hit"] = {
        {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
    },
    ["dizzy"] = {
        {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
    },
    ["attack01"] = {
        {type = "anim", time = 0, duration = 2.067, name = "Attack01", speed = 1},
        {type = "audio", time = 0, duration = 1.667, name = "JN-7183-718301", speed = 1, volume = 1, bloop = false, is_coexist = true },
    },
    ["attack02"] = {
        {type = "anim", time = 0, duration = 2.2, name = "Attack02", speed = 1},
        {type = "effect", time = 0.88, duration = 2, name = "bullet_718301", bone = "", speed = 1},
        --  {type = "effect", time = 0, duration = 2, name = "skill_718302_route1", bone = "LeftWeaponPos", speed = 1},
        {type = "audio", time = 0, duration = 1.667, name = "JN-7183-718301", speed = 1, volume = 1, bloop = false, is_coexist = true },
    },
    ["spell_01"] = {
        {type = "anim", time = 0, duration = 3.5, name = "Spell_01", speed = 1},
        {type = "effect", time = 0, duration = 10, name = "skill_718311_route1", bone = "", speed = 1, },          
        {type = "camera", time = 1.5, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.1;0;0.1;10"},
        --  {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
        {type = "audio", time = 1.5, duration = 5, name = "JN-7183-718311", speed = 1, volume = 1, bloop = false, is_coexist = true },

    },
    ["spell_02"] = {
        {type = "anim", time = 0, duration = 4.2, name = "Spell_02", speed = 1},
        {type = "effect", time = 0, duration = 3.8, name = "skill_718321_route1", bone = "", speed = 1, is_coexist = true},
        --  {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
        {type = "camera", time = 2, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;15"},
        {type = "audio", time = 2, duration = 5, name = "JN-7183-718321", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
    },
    --  矮人构造物召唤物炸弹
        ["8006"] = {
            ["appearance"] = {
                --  {type = "anim", time = 0, duration = 0.533, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 1, name = "skill_718321_route2", bone = "", speed = 1, is_coexist = true},
            },

            --  ["attack01"] = {
            --      {type = "effect", time = 0, duration = 0.5, name = "skill_718321_route3", bone = "", speed = 1, is_coexist = true},
            --  },

            ["dead"] = {
                --  {type = "anim", time = 0, duration = 4.033, name = "Death", speed = 1},
                {type = "effect", time = 0, duration = 4, name = "skill_718321_route5", bone = "", speed = 1, is_coexist = true},
                {type = "camera", time = 2, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;3"},
                {type = "shader", time = 0, name = "Death", duration = 0.5, params = ""},
            },

            ["spell_01"] = {
                --  {type = "anim", time = 0, duration = 3.5, name = "Spell_01", speed = 1},
                {type = "effect", time = 0, duration = 1.5, name = "skill_718321_route4", bone = "", speed = 1, is_coexist = true},          
            },

        },
-- 122202 主线BOSS-洞窟守卫
    ["7185"] = {
    ["born_battle"] = {
        {type = "anim", time = 0, duration = 7, name = "Appearance", speed = 1},
        {type = "audio", time = 0, duration = 7, name = "Boss-7183-appearance_01", speed = 1, volume = 1, bloop = false,is_coexist = true},
        {type = "effect", time = 0, duration = 4, name = "scenes_7183_appearance_01", bone = "", speed = 1},
        {type = "effect", time = 0, duration = 5, name = "scenes_7183_appearance_02", bone = "Bone003", speed = 1},
    },
    ["stand"] = {
        {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
    },
    ["dead"] = {
        {type = "anim", time = 0, duration = 4.033, name = "Death", speed = 1},
        {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
    },
    ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
    },
    ["run"] = {
        {type = "anim", time = 0, duration = 1.133, name = "Run", speed = 1},
    },
    ["hit"] = {
        {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
    },
    ["dizzy"] = {
        {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
    },
    ["attack01"] = {
        {type = "anim", time = 0, duration = 2.067, name = "Attack01", speed = 1},
        {type = "audio", time = 0, duration = 1.667, name = "JN-7183-718301", speed = 1, volume = 1, bloop = false, is_coexist = true },
    },
    ["attack02"] = {
        {type = "anim", time = 0, duration = 2.2, name = "Attack02", speed = 1},
        {type = "effect", time = 0.88, duration = 2, name = "bullet_718301", bone = "", speed = 1},
        --  {type = "effect", time = 0, duration = 2, name = "skill_718302_route1", bone = "LeftWeaponPos", speed = 1},
        {type = "audio", time = 0, duration = 1.667, name = "JN-7183-718301", speed = 1, volume = 1, bloop = false, is_coexist = true },
    },
    ["spell_01"] = {
        {type = "anim", time = 0, duration = 3.5, name = "Spell_01", speed = 1},
        {type = "effect", time = 0, duration = 10, name = "skill_718311_route1", bone = "", speed = 1, },          
        {type = "camera", time = 1.5, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.1;0;0.1;10"},
        --  {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
        {type = "audio", time = 1.5, duration = 5, name = "JN-7183-718311", speed = 1, volume = 1, bloop = false, is_coexist = true },

    },
    ["spell_02"] = {
        {type = "anim", time = 0, duration = 4.2, name = "Spell_02", speed = 1},
        {type = "effect", time = 0, duration = 3.8, name = "skill_718321_route1", bone = "", speed = 1, is_coexist = true},
        --  {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
        {type = "camera", time = 2, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;15"},
        {type = "audio", time = 2, duration = 5, name = "JN-7183-718321", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
    },
    --  矮人构造物召唤物炸弹
        ["8006"] = {
            ["appearance"] = {
                --  {type = "anim", time = 0, duration = 0.533, name = "Appearance", speed = 1},
                {type = "effect", time = 0, duration = 1, name = "skill_718321_route2", bone = "", speed = 1, is_coexist = true},
            },

            --  ["attack01"] = {
            --      {type = "effect", time = 0, duration = 0.5, name = "skill_718321_route3", bone = "", speed = 1, is_coexist = true},
            --  },

            ["dead"] = {
                --  {type = "anim", time = 0, duration = 4.033, name = "Death", speed = 1},
                {type = "effect", time = 0, duration = 4, name = "skill_718321_route5", bone = "", speed = 1, is_coexist = true},
                {type = "camera", time = 2, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;3"},
                {type = "shader", time = 0, name = "Death", duration = 0.5, params = ""},
            },

            ["spell_01"] = {
                --  {type = "anim", time = 0, duration = 3.5, name = "Spell_01", speed = 1},
                {type = "effect", time = 0, duration = 1.5, name = "skill_718321_route4", bone = "", speed = 1, is_coexist = true},          
            },

        },


-- -- -- -- 
-- 7401 魔化沙虫
    ["7401"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 5.9, name = "Appearance", speed = 1},
            {type = "effect", time = 0, duration = 8, name = "scenes_7181_appearance_01", bone = "", speed = 1, is_coexist = true },
            {type = "effect", time = 0, duration = 6, name = "scenes_7181_appearance_02", bone = "MouthPos", speed = 1 },
            {type = "audio", time = 0, duration = 7, name = "Boss-7181-appearance1", speed = 1, volume = 1, bloop = false,is_coexist = true},
            -- {type = "effect", time = 0, duration = 7, name = "scenes_7381_appearance02", bone = "LeftWeaponPos", speed = 1},
            -- {type = "effect", time = 0, duration = 8, name = "scenes_7381_appearance03", bone = "LeftHandPos", speed = 1},
            -- {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance04", bone = "RightHandPos", speed = 1, is_coexist = true},
            -- {type = "effect", time = 4.57, duration = 5, name = "scenes_7381_appearance05", bone = "LeftWeaponPos", speed = 1},
            -- {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance06", bone = "ChestPos", speed = 1, is_coexist = true},
            -- {type = "effect", time = 5.4, duration = 5, name = "scenes_7381_appearance07", bone = "", speed = 1},
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Stand", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 4, name = "Death", speed = 1},
            {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 2.9, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_718101_route1", bone = "", speed = 1, is_coexist = true},
            {type = "audio", time = 0, duration = 3, name = "Boss-7181-718101", speed = 1, volume = 1, bloop = false,},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 2.833, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_718102_route1", bone = "", speed = 1, is_coexist = true},
            {type = "audio", time = 0, duration = 3, name = "Boss-7181-718101", speed = 1, volume = 1, bloop = false,},

        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_718111_route1", bone = "", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 4, name = "skill_718111_route2", bone = "", speed = 1, is_coexist = true},
            -- {type = "effect", time = 1.77, duration = 1.5, name = "skill_738111_route3", bone = "ChestPos", speed = 1},
            -- {type = "camera", time = 0, duration = 1.5, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;15"},
            -- {type = "camera", time = 1.8, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1.6;0;0.1;3"},
            -- {type = "audio", time = 0, duration = 6.5, name = "JN-LS-10002-1", speed = 1.3, volume = 1, bloop = false},
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 0.667, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 1, duration = 2, name = "skill_718111_route3", bone = "", speed = 1, is_coexist = true},
            -- {type = "effect", time = 1.77, duration = 1.5, name = "skill_738111_route2", bone = "", speed = 1},
            -- {type = "effect", time = 1.77, duration = 1.5, name = "skill_738111_route3", bone = "ChestPos", speed = 1},
            -- {type = "camera", time = 0, duration = 1.5, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;15"},
            -- {type = "camera", time = 1.8, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1.6;0;0.1;3"},
            -- {type = "audio", time = 0, duration = 6.5, name = "JN-LS-10002-1", speed = 1.3, volume = 1, bloop = false},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Spell_01_End", speed = 1},
            {type = "camera", time = 0, duration = 0.5, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;3"},
            {type = "audio", time = 0, duration = 1, name = "Boss-7181-718111-hit", speed = 1.3, volume = 1, bloop = false},
            {type = "effect", time = 0, duration = 3, name = "skill_718111_route4", bone = "", speed = 1},
        },
        ["spell_02_start"] = {
            {type = "anim", time = 0, duration =0.667, name = "Spell_02_Begin", speed = 1},
            -- {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
            -- {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
            {type = "audio", time = 0, duration = 6, name = "Boss-7181-718121", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["spell_02_loop"] = {
            {type = "anim", time = 0, duration = 0.333, name = "Spell_02_Loop", speed = 1},
            -- {type = "effect", time = 0, duration = 5, name = "skill_738121_route2", bone = "", speed = 1},
        },
        ["spell_02_loop02"] = {
            {type = "anim", time = 0, duration = 3.5, name = "Spell_02_Loop02", speed = 1},
            {type = "effect", time = 0, duration = 1.84, name = "skill_718121_route2", bone = "MouthPos", speed = 1,},
            {type = "effect", time = 0, duration = 1.5, name = "skill_718121_route2_1", bone = "", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_718121_route5", bone = "", speed = 1},
        },
        ["spell_02_end"] = {
            {type = "anim", time = 0, duration = 2.6, name = "Spell_02_End", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_718121_route1", bone = "MouthPos", speed = 1,},
            {type = "effect", time = 0, duration = 3, name = "skill_718121_route3", bone = "MouthPos", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 6, name = "skill_718121_route4", bone = "MouthPos", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 5, name = "skill_718121_route6", bone = "", speed = 1, is_coexist = true},
        },
    },
-- 7402 雪地BOSS-冰霜巨人
    ["7402"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 8, name = "Appearance", speed = 1},
            {type = "audio", time = 0, duration = 7, name = "Boss-7182-appearance_01", speed = 1, volume = 1, bloop = false,is_coexist = true},
            --  {type = "effect", time = 0, duration = 7, name = "scenes_7381_appearance01", bone = "", speed = 1},
            -- {type = "effect", time = 0, duration = 7, name = "scenes_7381_appearance02", bone = "LeftWeaponPos", speed = 1},
            -- {type = "effect", time = 0, duration = 8, name = "scenes_7381_appearance03", bone = "LeftHandPos", speed = 1},
            -- {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance04", bone = "RightHandPos", speed = 1, is_coexist = true},
            --  {type = "effect", time = 4.57, duration = 5, name = "scenes_7381_appearance05", bone = "LeftWeaponPos", speed = 1},
            --  {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance06", bone = "ChestPos", speed = 1, is_coexist = true},
            --  {type = "effect", time = 5.4, duration = 5, name = "scenes_7381_appearance07", bone = "", speed = 1},
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 4.033, name = "Death", speed = 1},
            {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Run", speed = 1},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 2.333, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_718201_route1", bone = "", speed = 1},
            {type = "audio", time = 1, duration = 1.667, name = "JN-7182-718201", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 2.467, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_718202_route1", bone = "", speed = 1},
            {type = "audio", time = 1, duration = 1.667, name = "JN-7182-718201", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3, name = "Spell_01", speed = 1},
            --  {type = "effect", time = 0, duration = 2, name = "skill_718211_route1", bone = "", speed = 1, is_coexist = true},          
            {type = "effect", time = 0, duration = 1.5, name = "skill_718211_route2", bone = "Bip001 R Toe0", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 2, name = "skill_718211_route3", bone = "", speed = 1, is_coexist = true},
            {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
            {type = "camera", time = 1.2, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1;0;0.1;5", is_coexist = true},
            {type = "audio", time = 1.2, duration = 5, name = "JN-7182-718211", speed = 1, volume = 1, bloop = false, is_coexist = true },

        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 3.5, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_718221_route1", bone = "", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 1, name = "skill_718221_route2", bone = "", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 3.5, name = "skill_718221_route3", bone = "", speed = 1, is_coexist = true},
            {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
            {type = "camera", time = 1.4, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1;0;0.1;5", is_coexist = true},
            --  {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
            {type = "audio", time = 1, duration = 1, name = "JN-7182-718221", speed = 1, volume = 1, bloop = false, is_coexist = true },
            {type = "audio", time = 1.1, duration = 3, name = "JN-7182-718221-Hit", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
    },
-- 7403 主线BOSS-机甲守卫
    ["7403"] = {
    ["born_battle"] = {
        {type = "anim", time = 0, duration = 7, name = "Appearance", speed = 1},
        {type = "audio", time = 0, duration = 7, name = "Boss-7183-appearance_01", speed = 1, volume = 1, bloop = false,is_coexist = true},
        {type = "effect", time = 0, duration = 4, name = "scenes_7183_appearance_01", bone = "", speed = 1},
        {type = "effect", time = 0, duration = 5, name = "scenes_7183_appearance_02", bone = "Bone003", speed = 1},
    },
    ["stand"] = {
        {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
    },
    ["dead"] = {
        {type = "anim", time = 0, duration = 4.033, name = "Death", speed = 1},
        {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
    },
    ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
    },
    ["run"] = {
        {type = "anim", time = 0, duration = 1.133, name = "Run", speed = 1},
    },
    ["hit"] = {
        {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
    },
    ["dizzy"] = {
        {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
    },
    ["attack01"] = {
        {type = "anim", time = 0, duration = 2.067, name = "Attack01", speed = 1},
        {type = "audio", time = 0, duration = 1.667, name = "JN-7183-718301", speed = 1, volume = 1, bloop = false, is_coexist = true },
    },
    ["attack02"] = {
        {type = "anim", time = 0, duration = 2.2, name = "Attack02", speed = 1},
        {type = "effect", time = 0.88, duration = 2, name = "bullet_718301", bone = "", speed = 1},
        --  {type = "effect", time = 0, duration = 2, name = "skill_718302_route1", bone = "LeftWeaponPos", speed = 1},
        {type = "audio", time = 0, duration = 1.667, name = "JN-7183-718301", speed = 1, volume = 1, bloop = false, is_coexist = true },
    },
    ["spell_01"] = {
        {type = "anim", time = 0, duration = 3.5, name = "Spell_01", speed = 1},
        {type = "effect", time = 0, duration = 10, name = "skill_718311_route1", bone = "", speed = 1, },          
        {type = "camera", time = 1.5, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.1;0;0.1;10"},
        --  {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
        {type = "audio", time = 1.5, duration = 5, name = "JN-7183-718311", speed = 1, volume = 1, bloop = false, is_coexist = true },

    },
    ["spell_02"] = {
        {type = "anim", time = 0, duration = 4.2, name = "Spell_02", speed = 1},
        {type = "effect", time = 0, duration = 3.8, name = "skill_718321_route1", bone = "", speed = 1, is_coexist = true},
        --  {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
        {type = "camera", time = 2, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;15"},
        {type = "audio", time = 2, duration = 5, name = "JN-7183-718321", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
    },
-- 7404 荒漠BOSS-雷神巨像
    ["7404"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 7, name = "Appearance", speed = 1},
            {type = "audio", time = 0, duration = 7, name = "YY-BOSS-10001-1", speed = 0.88, volume = 1, bloop = false,is_coexist = true},
            -- {type = "effect", time = 0, duration = 7, name = "scenes_7381_appearance01", bone = "EyePos", speed = 1},
            -- {type = "effect", time = 0, duration = 7, name = "scenes_7381_appearance02", bone = "LeftWeaponPos", speed = 1},
            -- {type = "effect", time = 0, duration = 8, name = "scenes_7381_appearance03", bone = "LeftHandPos", speed = 1},
            -- {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance04", bone = "RightHandPos", speed = 1, is_coexist = true},
            {type = "effect", time = 4.57, duration = 5, name = "scenes_7381_appearance05", bone = "LeftWeaponPos", speed = 1},
            {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance06", bone = "ChestPos", speed = 1, is_coexist = true},
            {type = "effect", time = 5.4, duration = 5, name = "scenes_7381_appearance07", bone = "", speed = 1},
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 4.033, name = "Death", speed = 1},
            {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Attack_01", speed = 1},
            {type = "effect", time = 0, duration = 1.667, name = "skill_738101_route1", bone = "LeftWeaponPos", speed = 1},
            --  {type = "audio", time = 0, duration = 1.667, name = "JN-LS-10001-1", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Attack_01", speed = 1},
            {type = "effect", time = 0, duration = 1.667, name = "skill_738101_route1", bone = "LeftWeaponPos", speed = 1},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3.967, name = "Spell_01", speed = 1},
            {type = "effect", time = 1, duration = 1.5, name = "skill_738111_route1", bone = "ChestPos", speed = 1},
            {type = "effect", time = 1.77, duration = 1.5, name = "skill_738111_route2", bone = "", speed = 1},
            {type = "effect", time = 1.77, duration = 1.5, name = "skill_738111_route3", bone = "ChestPos", speed = 1},
            {type = "camera", time = 0, duration = 1.5, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;15"},
            {type = "camera", time = 1.8, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1.6;0;0.1;3"},
            {type = "audio", time = 0, duration = 6.5, name = "JN-LS-10002-1", speed = 1.3, volume = 1, bloop = false},
        },
        --  ["spell_01_start"] = {
        --      {type = "anim", time = 0, duration = 3.933, name = "Spell_01_Begin", speed = 1},
        --      {type = "effect", time = 1, duration = 1.5, name = "skill_738111_route1", bone = "ChestPos", speed = 1},
        --      {type = "effect", time = 1.77, duration = 1.5, name = "skill_738111_route2", bone = "", speed = 1},
        --      {type = "effect", time = 1.77, duration = 1.5, name = "skill_738111_route3", bone = "ChestPos", speed = 1},
        --      {type = "camera", time = 0, duration = 1.5, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;15"},
        --      {type = "camera", time = 1.8, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1.6;0;0.1;3"},
        --      {type = "audio", time = 0, duration = 6.5, name = "JN-LS-10002-1", speed = 1.3, volume = 1, bloop = false},
        --  },
        --  ["spell_01_loop"] = {
        --      {type = "anim", time = 0, duration = 5, name = "Spell_01_Loop", speed = 1},
        --      {type = "effect", time = 0, duration = 5, name = "skill_738121_route2", bone = "", speed = 1},
        --  },
        --  ["spell_01_run"] = {
        --      {type = "anim", time = 0, duration = 5, name = "Spell_01_Run", speed = 1},
        --      {type = "effect", time = 0, duration = 5, name = "skill_738121_route2", bone = "", speed = 1},
        --  },
        --  ["spell_01_end"] = {
        --      {type = "anim", time = 0, duration = 1.167, name = "Spell_01_End", speed = 1},
        --  },
        ["spell_02_start"] = {
            {type = "anim", time = 0, duration = 1.833, name = "Spell_02_Begin", speed = 1},
            {type = "effect", time = 0, duration = 5, name = "skill_738121_route1", bone = "", speed = 1, is_coexist = true},
            {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
            {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
            {type = "audio", time = 0, duration = 5, name = "JN-LS-10003-1", speed = 1, volume = 1, bloop = false, is_coexist = true },
            {type = "audio", time = 1.7, duration = 5, name = "JN-LS-10003-2", speed = 1, volume = 0.5, bloop = false, is_coexist = true},
        },
        ["spell_02_loop"] = {
            {type = "anim", time = 0, duration = 5, name = "Spell_02_Loop", speed = 1},
            {type = "effect", time = 0, duration = 5, name = "skill_738121_route2", bone = "", speed = 1},
        },
        ["spell_02_end"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Spell_02_End", speed = 1},
        },
    },
-- 7405 五色龙BOSS-红龙
    ["7405"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 9.567, name = "Appearance", speed = 1},
            {type = "audio", time = 0, duration = 9, name = "Boss-7382-appearance1", speed = 1, volume = 1, bloop = false,is_coexist = true},
            {type = "effect", time = 4.3, duration = 2, name = "scenes_7382_appearance_01", bone = "", speed = 1 },
            {type = "effect", time = 6.17, duration = 2.5, name = "scenes_7382_appearance_02", bone = "MouthPos", speed = 1, is_coexist = true},
        },
        ["born_battle02"] = {
            {type = "anim", time = 0, duration = 9.567, name = "Appearance02", speed = 1},
            -- {type = "audio", time = 0, duration = 9, name = "Boss-7382-appearance2", speed = 1, volume = 1, bloop = false,is_coexist = true},
            {type = "effect", time = 5.54, duration = 2, name = "scenes_7382_appearance_01", bone = "", speed = 1},
            {type = "effect", time = 7.6, duration = 2.5, name = "scenes_7382_appearance_02", bone = "MouthPos", speed = 1},
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.467, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 5.167, name = "Death", speed = 1},
            {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 1.2, name = "Hit", speed = 2},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Dizzy", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 3.167, name = "Attack", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_738201_route1", bone = "MouthPos", speed = 1},
            {type = "camera", time = 1.1, duration = 1.8, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.1;0;0.1;18" },
            {type = "audio", time = 0, duration = 2, name = "Boss-7382-738201", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 1.633, name = "Spell_01_Begin", speed = 0.7},
            {type = "effect", time = 0.5, duration = 5, name = "skill_738211_route1", bone = "", speed = 1, is_coexist = true},
            {type = "audio", time = 0, duration = 1, name = "Boss-7382-738211", speed = 1, volume = 1, bloop = false, },
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 1.6, name = "Spell_01_Loop", speed = 1},
            {type = "audio", time = 0, duration = 15, name = "Boss-7382-738211-loop", speed = 1, volume = 1, bloop = true,is_coexist = true},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Spell_01_End", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_738211_route5", bone = "", speed = 1},
            {type = "camera", time = 0.3, duration = 0.5, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1.2;0;0.1;5" },
            {type = "audio", time = 0, duration = 1, name = "Boss-7382-738211-hit", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 3.067, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_738221_route1", bone = "", speed = 1 },
            {type = "effect", time = 0, duration = 3, name = "skill_738221_route2", bone = "MouthPos", speed = 1 },
            {type = "effect", time = 1.8, duration = 3, name = "skill_738221_route3", bone = "", speed = 1 },
            {type = "audio", time = 0, duration = 5, name = "Boss-7382-738221", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
    },
-- 7406 森林BOSS-元祖蛇蜥
    ["7406"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 7, name = "Appearance", speed = 1},
            {type = "audio", time = 0, duration = 8, name = "Boss-7383-appearance_01", speed = 1, volume = 1, bloop = false,is_coexist = true},
            --  {type = "effect", time = 0, duration = 7, name = "scenes_7381_appearance01", bone = "EyePos", speed = 1},
            --  -- {type = "effect", time = 0, duration = 7, name = "scenes_7381_appearance02", bone = "LeftWeaponPos", speed = 1},
            --  -- {type = "effect", time = 0, duration = 8, name = "scenes_7381_appearance03", bone = "LeftHandPos", speed = 1},.0.
            --  -- {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance04", bone = "RightHandPos", speed = 1, is_coexist = true},
            --  {type = "effect", time = 4.57, duration = 5, name = "scenes_7381_appearance05", bone = "LeftWeaponPos", speed = 1},
            --  {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance06", bone = "ChestPos", speed = 1, is_coexist = true},
            --  {type = "effect", time = 5.4, duration = 5, name = "scenes_7381_appearance07", bone = "", speed = 1},
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 4.033, name = "Death", speed = 1},
            {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 2.033, name = "Attack01", speed = 1},
            {type = "effect", time = 1.33, duration = 1.27, name = "skill_738301_route1", bone = "MouthPos", speed = 1},
            {type = "audio", time = 1.33, duration = 1.667, name = "JN-7383-718301", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 2, name = "Attack02", speed = 1},
            {type = "effect", time = 1.17, duration = 0.97, name = "skill_738303_route1", bone = "MouthPos02", speed = 1},
            {type = "audio", time = 1.17, duration = 1.667, name = "JN-7383-718301", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["attack03"] = {
            {type = "anim", time = 0, duration = 2, name = "Attack03", speed = 1},
            {type = "effect", time = 1.17, duration = 1.04, name = "skill_738303_route1", bone = "MouthPos03", speed = 1},
            {type = "audio", time = 1.17, duration = 1.667, name = "JN-7383-718301", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3.86, name = "Spell_01", speed = 1},
            {type = "effect", time = 2.2, duration = 2.53, name = "skill_738311_route1", bone = "MouthPos", speed = 1, },
            {type = "effect", time = 2.2, duration = 2.53, name = "skill_738312_route1", bone = "MouthPos02", speed = 1, },
            {type = "effect", time = 2.2, duration = 2.53, name = "skill_738313_route1", bone = "MouthPos03", speed = 1, },
            {type = "camera", time = 2.2, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;10"},
            --  {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
            {type = "audio", time = 2.2, duration = 5, name = "JN-7383-718311", speed = 0.8, volume = 1, bloop = false, is_coexist = true },
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 4.4, name = "Spell_02", speed = 1},
            {type = "effect", time = 1.83, duration = 2.53, name = "skill_738321_route1", bone = "MouthPos", speed = 1,},
            {type = "effect", time = 2.19, duration = 2.23, name = "skill_738322_route1", bone = "MouthPos02", speed = 1,},
            {type = "effect", time = 2.43, duration = 3.13, name = "skill_738323_route1", bone = "MouthPos03", speed = 1,},
            {type = "effect", time = 2.66, duration = 2.53, name = "skill_738321_route1", bone = "MouthPos", speed = 1,},
            {type = "effect", time = 2.93, duration = 2.23, name = "skill_738322_route1", bone = "MouthPos02", speed = 1, },
            {type = "effect", time = 3.20, duration = 3.13, name = "skill_738323_route1", bone = "MouthPos03", speed = 1, },
            --  {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
            --  {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
            {type = "audio", time = 1.83, duration = 5, name = "JN-7383-738321", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["spell_03"] = {
            {type = "anim", time = 0, duration = 3.5, name = "Spell_03", speed = 1},
            {type = "effect", time = 0.2, duration = 0.82, name = "skill_738331_route1", bone = "MouthPos02", speed = 1,},
            --  {type = "effect", time = 0.82, duration = 5, name = "skill_738331_route2", bone = "", speed = 1, is_coexist = true},
            --  {type = "effect", time = 0, duration = 5, name = "skill_738332_route2", bone = "", speed = 1, is_coexist = true},

        },
        ["spell_04"] = {
            {type = "anim", time = 0, duration = 3.5, name = "Spell_04", speed = 1},
            {type = "effect", time = 0.2, duration = 0.82, name = "skill_738331_route1", bone = "MouthPos", speed = 1, },
            --  {type = "effect", time = 0.82, duration = 5, name = "skill_738331_route2", bone = "", speed = 1, is_coexist = true},
            --  {type = "effect", time = 0, duration = 5, name = "skill_738332_route2", bone = "", speed = 1, is_coexist = true},

        },
        ["spell_05"] = {
            {type = "anim", time = 0, duration = 3.5, name = "Spell_05", speed = 1},
            {type = "effect", time = 0.2, duration = 0.82, name = "skill_738331_route1", bone = "MouthPos03", speed = 1,},
            --  {type = "effect", time = 0.82, duration = 5, name = "skill_738331_route2", bone = "", speed = 1, is_coexist = true},
            --  {type = "effect", time = 0, duration = 5, name = "skill_738332_route2", bone = "", speed = 1, is_coexist = true},

        },
        
    },
-- -- -- --
-- 7501 魔化沙虫
    ["7501"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 5.9, name = "Appearance", speed = 1},
            {type = "effect", time = 0, duration = 8, name = "scenes_7181_appearance_01", bone = "", speed = 1, is_coexist = true },
            {type = "effect", time = 0, duration = 6, name = "scenes_7181_appearance_02", bone = "MouthPos", speed = 1 },
            {type = "audio", time = 0, duration = 7, name = "Boss-7181-appearance1", speed = 1, volume = 1, bloop = false,is_coexist = true},
            -- {type = "effect", time = 0, duration = 7, name = "scenes_7381_appearance02", bone = "LeftWeaponPos", speed = 1},
            -- {type = "effect", time = 0, duration = 8, name = "scenes_7381_appearance03", bone = "LeftHandPos", speed = 1},
            -- {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance04", bone = "RightHandPos", speed = 1, is_coexist = true},
            -- {type = "effect", time = 4.57, duration = 5, name = "scenes_7381_appearance05", bone = "LeftWeaponPos", speed = 1},
            -- {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance06", bone = "ChestPos", speed = 1, is_coexist = true},
            -- {type = "effect", time = 5.4, duration = 5, name = "scenes_7381_appearance07", bone = "", speed = 1},
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Stand", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 4, name = "Death", speed = 1},
            {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 2.9, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_718101_route1", bone = "", speed = 1, is_coexist = true},
            {type = "audio", time = 0, duration = 3, name = "Boss-7181-718101", speed = 1, volume = 1, bloop = false,},
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 2.833, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_718102_route1", bone = "", speed = 1, is_coexist = true},
            {type = "audio", time = 0, duration = 3, name = "Boss-7181-718101", speed = 1, volume = 1, bloop = false,},

        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Spell_01_Begin", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_718111_route1", bone = "", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 4, name = "skill_718111_route2", bone = "", speed = 1, is_coexist = true},
            -- {type = "effect", time = 1.77, duration = 1.5, name = "skill_738111_route3", bone = "ChestPos", speed = 1},
            -- {type = "camera", time = 0, duration = 1.5, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;15"},
            -- {type = "camera", time = 1.8, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1.6;0;0.1;3"},
            -- {type = "audio", time = 0, duration = 6.5, name = "JN-LS-10002-1", speed = 1.3, volume = 1, bloop = false},
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 0.667, name = "Spell_01_Loop", speed = 1},
            {type = "effect", time = 1, duration = 2, name = "skill_718111_route3", bone = "", speed = 1, is_coexist = true},
            -- {type = "effect", time = 1.77, duration = 1.5, name = "skill_738111_route2", bone = "", speed = 1},
            -- {type = "effect", time = 1.77, duration = 1.5, name = "skill_738111_route3", bone = "ChestPos", speed = 1},
            -- {type = "camera", time = 0, duration = 1.5, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;15"},
            -- {type = "camera", time = 1.8, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1.6;0;0.1;3"},
            -- {type = "audio", time = 0, duration = 6.5, name = "JN-LS-10002-1", speed = 1.3, volume = 1, bloop = false},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 1.533, name = "Spell_01_End", speed = 1},
            {type = "camera", time = 0, duration = 0.5, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;3"},
            {type = "audio", time = 0, duration = 1, name = "Boss-7181-718111-hit", speed = 1.3, volume = 1, bloop = false},
            {type = "effect", time = 0, duration = 3, name = "skill_718111_route4", bone = "", speed = 1},
        },
        ["spell_02_start"] = {
            {type = "anim", time = 0, duration =0.667, name = "Spell_02_Begin", speed = 1},
            -- {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
            -- {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
            {type = "audio", time = 0, duration = 6, name = "Boss-7181-718121", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["spell_02_loop"] = {
            {type = "anim", time = 0, duration = 0.333, name = "Spell_02_Loop", speed = 1},
            -- {type = "effect", time = 0, duration = 5, name = "skill_738121_route2", bone = "", speed = 1},
        },
        ["spell_02_loop02"] = {
            {type = "anim", time = 0, duration = 3.5, name = "Spell_02_Loop02", speed = 1},
            {type = "effect", time = 0, duration = 1.84, name = "skill_718121_route2", bone = "MouthPos", speed = 1,},
            {type = "effect", time = 0, duration = 1.5, name = "skill_718121_route2_1", bone = "", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_718121_route5", bone = "", speed = 1},
        },
        ["spell_02_end"] = {
            {type = "anim", time = 0, duration = 2.6, name = "Spell_02_End", speed = 1},
            {type = "effect", time = 0, duration = 1, name = "skill_718121_route1", bone = "MouthPos", speed = 1,},
            {type = "effect", time = 0, duration = 3, name = "skill_718121_route3", bone = "MouthPos", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 6, name = "skill_718121_route4", bone = "MouthPos", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 5, name = "skill_718121_route6", bone = "", speed = 1, is_coexist = true},
        },
    },
-- 7502 雪地BOSS-冰霜巨人
    ["7502"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 8, name = "Appearance", speed = 1},
            {type = "audio", time = 0, duration = 7, name = "Boss-7182-appearance_01", speed = 1, volume = 1, bloop = false,is_coexist = true},
            --  {type = "effect", time = 0, duration = 7, name = "scenes_7381_appearance01", bone = "", speed = 1},
            -- {type = "effect", time = 0, duration = 7, name = "scenes_7381_appearance02", bone = "LeftWeaponPos", speed = 1},
            -- {type = "effect", time = 0, duration = 8, name = "scenes_7381_appearance03", bone = "LeftHandPos", speed = 1},
            -- {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance04", bone = "RightHandPos", speed = 1, is_coexist = true},
            --  {type = "effect", time = 4.57, duration = 5, name = "scenes_7381_appearance05", bone = "LeftWeaponPos", speed = 1},
            --  {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance06", bone = "ChestPos", speed = 1, is_coexist = true},
            --  {type = "effect", time = 5.4, duration = 5, name = "scenes_7381_appearance07", bone = "", speed = 1},
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 4.033, name = "Death", speed = 1},
            {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.133, name = "Run", speed = 1},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 2.333, name = "Attack01", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_718201_route1", bone = "", speed = 1},
            {type = "audio", time = 1, duration = 1.667, name = "JN-7182-718201", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 2.467, name = "Attack02", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_718202_route1", bone = "", speed = 1},
            {type = "audio", time = 1, duration = 1.667, name = "JN-7182-718201", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3, name = "Spell_01", speed = 1},
            --  {type = "effect", time = 0, duration = 2, name = "skill_718211_route1", bone = "", speed = 1, is_coexist = true},          
            {type = "effect", time = 0, duration = 1.5, name = "skill_718211_route2", bone = "Bip001 R Toe0", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 2, name = "skill_718211_route3", bone = "", speed = 1, is_coexist = true},
            {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
            {type = "camera", time = 1.2, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1;0;0.1;5", is_coexist = true},
            {type = "audio", time = 1.2, duration = 5, name = "JN-7182-718211", speed = 1, volume = 1, bloop = false, is_coexist = true },

        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 3.5, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 2, name = "skill_718221_route1", bone = "", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 1, name = "skill_718221_route2", bone = "", speed = 1, is_coexist = true},
            {type = "effect", time = 0, duration = 3.5, name = "skill_718221_route3", bone = "", speed = 1, is_coexist = true},
            {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
            {type = "camera", time = 1.4, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1;0;0.1;5", is_coexist = true},
            --  {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
            {type = "audio", time = 1, duration = 1, name = "JN-7182-718221", speed = 1, volume = 1, bloop = false, is_coexist = true },
            {type = "audio", time = 1.1, duration = 3, name = "JN-7182-718221-Hit", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
    },
-- 7503 主线BOSS-机甲守卫
    ["7503"] = {
    ["born_battle"] = {
        {type = "anim", time = 0, duration = 7, name = "Appearance", speed = 1},
        {type = "audio", time = 0, duration = 7, name = "Boss-7183-appearance_01", speed = 1, volume = 1, bloop = false,is_coexist = true},
        {type = "effect", time = 0, duration = 4, name = "scenes_7183_appearance_01", bone = "", speed = 1},
        {type = "effect", time = 0, duration = 5, name = "scenes_7183_appearance_02", bone = "Bone003", speed = 1},
    },
    ["stand"] = {
        {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
    },
    ["dead"] = {
        {type = "anim", time = 0, duration = 4.033, name = "Death", speed = 1},
        {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
    },
    ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
    },
    ["run"] = {
        {type = "anim", time = 0, duration = 1.133, name = "Run", speed = 1},
    },
    ["hit"] = {
        {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
    },
    ["dizzy"] = {
        {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
    },
    ["attack01"] = {
        {type = "anim", time = 0, duration = 2.067, name = "Attack01", speed = 1},
        {type = "audio", time = 0, duration = 1.667, name = "JN-7183-718301", speed = 1, volume = 1, bloop = false, is_coexist = true },
    },
    ["attack02"] = {
        {type = "anim", time = 0, duration = 2.2, name = "Attack02", speed = 1},
        {type = "effect", time = 0.88, duration = 2, name = "bullet_718301", bone = "", speed = 1},
        --  {type = "effect", time = 0, duration = 2, name = "skill_718302_route1", bone = "LeftWeaponPos", speed = 1},
        {type = "audio", time = 0, duration = 1.667, name = "JN-7183-718301", speed = 1, volume = 1, bloop = false, is_coexist = true },
    },
    ["spell_01"] = {
        {type = "anim", time = 0, duration = 3.5, name = "Spell_01", speed = 1},
        {type = "effect", time = 0, duration = 10, name = "skill_718311_route1", bone = "", speed = 1, },          
        {type = "camera", time = 1.5, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.1;0;0.1;10"},
        --  {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
        {type = "audio", time = 1.5, duration = 5, name = "JN-7183-718311", speed = 1, volume = 1, bloop = false, is_coexist = true },

    },
    ["spell_02"] = {
        {type = "anim", time = 0, duration = 4.2, name = "Spell_02", speed = 1},
        {type = "effect", time = 0, duration = 3.8, name = "skill_718321_route1", bone = "", speed = 1, is_coexist = true},
        --  {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
        {type = "camera", time = 2, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;15"},
        {type = "audio", time = 2, duration = 5, name = "JN-7183-718321", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
    },
-- 7504 荒漠BOSS-雷神巨像
    ["7504"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 7, name = "Appearance", speed = 1},
            {type = "audio", time = 0, duration = 7, name = "YY-BOSS-10001-1", speed = 0.88, volume = 1, bloop = false,is_coexist = true},
            -- {type = "effect", time = 0, duration = 7, name = "scenes_7381_appearance01", bone = "EyePos", speed = 1},
            -- {type = "effect", time = 0, duration = 7, name = "scenes_7381_appearance02", bone = "LeftWeaponPos", speed = 1},
            -- {type = "effect", time = 0, duration = 8, name = "scenes_7381_appearance03", bone = "LeftHandPos", speed = 1},
            -- {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance04", bone = "RightHandPos", speed = 1, is_coexist = true},
            {type = "effect", time = 4.57, duration = 5, name = "scenes_7381_appearance05", bone = "LeftWeaponPos", speed = 1},
            {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance06", bone = "ChestPos", speed = 1, is_coexist = true},
            {type = "effect", time = 5.4, duration = 5, name = "scenes_7381_appearance07", bone = "", speed = 1},
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 4.033, name = "Death", speed = 1},
            {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Attack_01", speed = 1},
            {type = "effect", time = 0, duration = 1.667, name = "skill_738101_route1", bone = "LeftWeaponPos", speed = 1},
            --  {type = "audio", time = 0, duration = 1.667, name = "JN-LS-10001-1", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 1.667, name = "Attack_01", speed = 1},
            {type = "effect", time = 0, duration = 1.667, name = "skill_738101_route1", bone = "LeftWeaponPos", speed = 1},
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3.967, name = "Spell_01", speed = 1},
            {type = "effect", time = 1, duration = 1.5, name = "skill_738111_route1", bone = "ChestPos", speed = 1},
            {type = "effect", time = 1.77, duration = 1.5, name = "skill_738111_route2", bone = "", speed = 1},
            {type = "effect", time = 1.77, duration = 1.5, name = "skill_738111_route3", bone = "ChestPos", speed = 1},
            {type = "camera", time = 0, duration = 1.5, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;15"},
            {type = "camera", time = 1.8, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1.6;0;0.1;3"},
            {type = "audio", time = 0, duration = 6.5, name = "JN-LS-10002-1", speed = 1.3, volume = 1, bloop = false},
        },
        --  ["spell_01_start"] = {
        --      {type = "anim", time = 0, duration = 3.933, name = "Spell_01_Begin", speed = 1},
        --      {type = "effect", time = 1, duration = 1.5, name = "skill_738111_route1", bone = "ChestPos", speed = 1},
        --      {type = "effect", time = 1.77, duration = 1.5, name = "skill_738111_route2", bone = "", speed = 1},
        --      {type = "effect", time = 1.77, duration = 1.5, name = "skill_738111_route3", bone = "ChestPos", speed = 1},
        --      {type = "camera", time = 0, duration = 1.5, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;15"},
        --      {type = "camera", time = 1.8, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1.6;0;0.1;3"},
        --      {type = "audio", time = 0, duration = 6.5, name = "JN-LS-10002-1", speed = 1.3, volume = 1, bloop = false},
        --  },
        --  ["spell_01_loop"] = {
        --      {type = "anim", time = 0, duration = 5, name = "Spell_01_Loop", speed = 1},
        --      {type = "effect", time = 0, duration = 5, name = "skill_738121_route2", bone = "", speed = 1},
        --  },
        --  ["spell_01_run"] = {
        --      {type = "anim", time = 0, duration = 5, name = "Spell_01_Run", speed = 1},
        --      {type = "effect", time = 0, duration = 5, name = "skill_738121_route2", bone = "", speed = 1},
        --  },
        --  ["spell_01_end"] = {
        --      {type = "anim", time = 0, duration = 1.167, name = "Spell_01_End", speed = 1},
        --  },
        ["spell_02_start"] = {
            {type = "anim", time = 0, duration = 1.833, name = "Spell_02_Begin", speed = 1},
            {type = "effect", time = 0, duration = 5, name = "skill_738121_route1", bone = "", speed = 1, is_coexist = true},
            {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
            {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
            {type = "audio", time = 0, duration = 5, name = "JN-LS-10003-1", speed = 1, volume = 1, bloop = false, is_coexist = true },
            {type = "audio", time = 1.7, duration = 5, name = "JN-LS-10003-2", speed = 1, volume = 0.5, bloop = false, is_coexist = true},
        },
        ["spell_02_loop"] = {
            {type = "anim", time = 0, duration = 5, name = "Spell_02_Loop", speed = 1},
            {type = "effect", time = 0, duration = 5, name = "skill_738121_route2", bone = "", speed = 1},
        },
        ["spell_02_end"] = {
            {type = "anim", time = 0, duration = 1.167, name = "Spell_02_End", speed = 1},
        },
    },
-- 7505 五色龙BOSS-红龙
    ["7505"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 9.567, name = "Appearance", speed = 1},
            {type = "audio", time = 0, duration = 9, name = "Boss-7382-appearance1", speed = 1, volume = 1, bloop = false,is_coexist = true},
            {type = "effect", time = 4.3, duration = 2, name = "scenes_7382_appearance_01", bone = "", speed = 1 },
            {type = "effect", time = 6.17, duration = 2.5, name = "scenes_7382_appearance_02", bone = "MouthPos", speed = 1, is_coexist = true},
        },
        ["born_battle02"] = {
            {type = "anim", time = 0, duration = 9.567, name = "Appearance02", speed = 1},
            -- {type = "audio", time = 0, duration = 9, name = "Boss-7382-appearance2", speed = 1, volume = 1, bloop = false,is_coexist = true},
            {type = "effect", time = 5.54, duration = 2, name = "scenes_7382_appearance_01", bone = "", speed = 1},
            {type = "effect", time = 7.6, duration = 2.5, name = "scenes_7382_appearance_02", bone = "MouthPos", speed = 1},
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 1.467, name = "Run", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 5.167, name = "Death", speed = 1},
            {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 1.2, name = "Hit", speed = 2},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 2.667, name = "Dizzy", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 3.167, name = "Attack", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_738201_route1", bone = "MouthPos", speed = 1},
            {type = "camera", time = 1.1, duration = 1.8, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.1;0;0.1;18" },
            {type = "audio", time = 0, duration = 2, name = "Boss-7382-738201", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["spell_01_start"] = {
            {type = "anim", time = 0, duration = 1.633, name = "Spell_01_Begin", speed = 0.7},
            {type = "effect", time = 0.5, duration = 5, name = "skill_738211_route1", bone = "", speed = 1, is_coexist = true},
            {type = "audio", time = 0, duration = 1, name = "Boss-7382-738211", speed = 1, volume = 1, bloop = false, },
        },
        ["spell_01_loop"] = {
            {type = "anim", time = 0, duration = 1.6, name = "Spell_01_Loop", speed = 1},
            {type = "audio", time = 0, duration = 15, name = "Boss-7382-738211-loop", speed = 1, volume = 1, bloop = true,is_coexist = true},
        },
        ["spell_01_end"] = {
            {type = "anim", time = 0, duration = 1.5, name = "Spell_01_End", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_738211_route5", bone = "", speed = 1},
            {type = "camera", time = 0.3, duration = 0.5, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;1.2;0;0.1;5" },
            {type = "audio", time = 0, duration = 1, name = "Boss-7382-738211-hit", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["spell_02"] = {
            {type = "anim", time = 0, duration = 3.067, name = "Spell_02", speed = 1},
            {type = "effect", time = 0, duration = 3, name = "skill_738221_route1", bone = "", speed = 1 },
            {type = "effect", time = 0, duration = 3, name = "skill_738221_route2", bone = "MouthPos", speed = 1 },
            {type = "effect", time = 1.8, duration = 3, name = "skill_738221_route3", bone = "", speed = 1 },
            {type = "audio", time = 0, duration = 5, name = "Boss-7382-738221", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
    },
-- 7506 森林BOSS-元祖蛇蜥
    ["7506"] = {
        ["born_battle"] = {
            {type = "anim", time = 0, duration = 7, name = "Appearance", speed = 1},
            {type = "audio", time = 0, duration = 8, name = "Boss-7383-appearance_01", speed = 1, volume = 1, bloop = false,is_coexist = true},
            --  {type = "effect", time = 0, duration = 7, name = "scenes_7381_appearance01", bone = "EyePos", speed = 1},
            --  -- {type = "effect", time = 0, duration = 7, name = "scenes_7381_appearance02", bone = "LeftWeaponPos", speed = 1},
            --  -- {type = "effect", time = 0, duration = 8, name = "scenes_7381_appearance03", bone = "LeftHandPos", speed = 1},.0.
            --  -- {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance04", bone = "RightHandPos", speed = 1, is_coexist = true},
            --  {type = "effect", time = 4.57, duration = 5, name = "scenes_7381_appearance05", bone = "LeftWeaponPos", speed = 1},
            --  {type = "effect", time = 4.17, duration = 7, name = "scenes_7381_appearance06", bone = "ChestPos", speed = 1, is_coexist = true},
            --  {type = "effect", time = 5.4, duration = 5, name = "scenes_7381_appearance07", bone = "", speed = 1},
        },
        ["stand"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Stand", speed = 1},
        },
        ["dead"] = {
            {type = "anim", time = 0, duration = 4.033, name = "Death", speed = 1},
            {type = "shader", time = 4, name = "Death", duration = 1, params = ""},
        },
        ["empty"] = {
            {type = "anim", time = 0, duration = 0.5, name = "Empty", speed = 1},
        },
        ["desaturate"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
            {type = "shader", time = 0, name = "Desaturate", duration = 10, params = "0.4;0.7;0;243;213"}
        },
        ["hit"] = {
            {type = "anim", time = 0, duration = 0.7, name = "Hit", speed = 2},
        },
        ["dizzy"] = {
            {type = "anim", time = 0, duration = 1.333, name = "Dizzy", speed = 1},
        },
        ["attack01"] = {
            {type = "anim", time = 0, duration = 2.033, name = "Attack01", speed = 1},
            {type = "effect", time = 1.33, duration = 1.27, name = "skill_738301_route1", bone = "MouthPos", speed = 1},
            {type = "audio", time = 1.33, duration = 1.667, name = "JN-7383-718301", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["attack02"] = {
            {type = "anim", time = 0, duration = 2, name = "Attack02", speed = 1},
            {type = "effect", time = 1.17, duration = 0.97, name = "skill_738303_route1", bone = "MouthPos02", speed = 1},
            {type = "audio", time = 1.17, duration = 1.667, name = "JN-7383-718301", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["attack03"] = {
            {type = "anim", time = 0, duration = 2, name = "Attack03", speed = 1},
            {type = "effect", time = 1.17, duration = 1.04, name = "skill_738303_route1", bone = "MouthPos03", speed = 1},
            {type = "audio", time = 1.17, duration = 1.667, name = "JN-7383-718301", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },
        ["spell_01"] = {
            {type = "anim", time = 0, duration = 3.86, name = "Spell_01", speed = 1},
            {type = "effect", time = 2.2, duration = 2.53, name = "skill_738311_route1", bone = "MouthPos", speed = 1, },
            {type = "effect", time = 2.2, duration = 2.53, name = "skill_738312_route1", bone = "MouthPos02", speed = 1, },
            {type = "effect", time = 2.2, duration = 2.53, name = "skill_738313_route1", bone = "MouthPos03", speed = 1, },
            {type = "camera", time = 2.2, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.3;0;0.1;10"},
            --  {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
            {type = "audio", time = 2.2, duration = 5, name = "JN-7383-718311", speed = 0.8, volume = 1, bloop = false, is_coexist = true },
        },

        ["spell_02"] = {
            {type = "anim", time = 0, duration = 4.4, name = "Spell_02", speed = 1},
            {type = "effect", time = 1.83, duration = 2.53, name = "skill_738321_route1", bone = "MouthPos", speed = 1,},
            {type = "effect", time = 2.19, duration = 2.23, name = "skill_738322_route1", bone = "MouthPos02", speed = 1,},
            {type = "effect", time = 2.43, duration = 3.13, name = "skill_738323_route1", bone = "MouthPos03", speed = 1,},
            {type = "effect", time = 2.66, duration = 2.53, name = "skill_738321_route1", bone = "MouthPos", speed = 1,},
            {type = "effect", time = 2.93, duration = 2.23, name = "skill_738322_route1", bone = "MouthPos02", speed = 1, },
            {type = "effect", time = 3.20, duration = 3.13, name = "skill_738323_route1", bone = "MouthPos03", speed = 1, },
            --  {type = "camera", time = 0, duration = 1, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;15"},
            --  {type = "camera", time = 1.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.6;0;0.1;3"},
            {type = "audio", time = 1.83, duration = 5, name = "JN-7383-738321", speed = 1, volume = 1, bloop = false, is_coexist = true },
        },

        ["spell_03"] = {
            {type = "anim", time = 0, duration = 3.5, name = "Spell_03", speed = 1},
            {type = "effect", time = 0.5, duration = 0.82, name = "skill_738331_route1", bone = "MouthPos02", speed = 1,},
            --  {type = "effect", time = 0.82, duration = 5, name = "skill_738331_route2", bone = "", speed = 1, is_coexist = true},
            --  {type = "effect", time = 0, duration = 5, name = "skill_738332_route2", bone = "", speed = 1, is_coexist = true},

        },
        ["spell_04"] = {
            {type = "anim", time = 0, duration = 3.5, name = "Spell_04", speed = 1},
            {type = "effect", time = 0.5, duration = 0.82, name = "skill_738331_route1", bone = "MouthPos", speed = 1, },
            --  {type = "effect", time = 0.82, duration = 5, name = "skill_738331_route2", bone = "", speed = 1, is_coexist = true},
            --  {type = "effect", time = 0, duration = 5, name = "skill_738332_route2", bone = "", speed = 1, is_coexist = true},

        },
        ["spell_05"] = {
            {type = "anim", time = 0, duration = 3.5, name = "Spell_05", speed = 1},
            {type = "effect", time = 0.5, duration = 0.82, name = "skill_738331_route1", bone = "MouthPos03", speed = 1,},
            --  {type = "effect", time = 0.82, duration = 5, name = "skill_738331_route2", bone = "", speed = 1, is_coexist = true},
            --  {type = "effect", time = 0, duration = 5, name = "skill_738332_route2", bone = "", speed = 1, is_coexist = true},

        },
        
    },
-- -- -- --
--  透明子弹
    ["999999"] = {
    -- 1204 朱塞佩
        -- 1204朱塞佩炸药桶
            ["120422"] = {
            {type = "effect", time = 0, duration = 6, name = "bullet_120421", bone = "", speed = 1},
            },
        -- 1204朱塞佩炸药桶闪
            ["120423"] = {
            {type = "effect", time = 0, duration = 6, name = "skill_120421_route3", bone = "", speed = 1},
            },
        -- 1204朱塞佩炸药桶爆炸特效
            ["120421"] = {
            {type = "effect", time = 0, duration = 1.5, name = "skill_120421_route2", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 2, name = "JN-2301-230111-hit", speed = 0.7, volume = 0.8, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3"},  
            },
        -- 1204朱塞佩烟雾
            --  ["120431"] = {
            --  --  {type = "effect", time = 0, duration = 1.5, name = "skill_120431_route2", bone = "", speed = 1, is_coexist = true},
            --  },
        -- 1204朱塞佩烟雾循环
            ["120432"] = {
            {type = "effect", time = 0, duration = 10, name = "skill_120431_route3_m", bone = "", speed = 1.2},
            },
        -- 1204朱塞佩大招爆炸效果
            ["120411"] = {
            {type = "audio", time = 0, duration = 2, name = "Boss-7382-738221-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3"},  
            {type = "effect", time = 0, duration = 4, name = "skill_120411_hit", bone = "", speed = 1},
            },
    -- 1301 勒芙蕾丝
            -- 1302毒药瓶残留表现
        ["130221"] = {
            {type = "effect", time = 0, duration = 4, name = "skill_130221_route4_m", bone = "", speed = 1},

        },
        -- 生命药瓶残留表现
        ["130231"] = {
            {type = "effect", time = 0, duration = 4, name = "skill_130231_route1_m", bone = "", speed = 1},

        },
    -- 1303 杰西卡大招
        -- 1302毒药瓶残留表现
        ["130311"] = {
            {type = "effect", time = 0, duration = 4, name = "skill_130311_route2", bone = "", speed = 1},

        },
    -- 1306 舞娘立场效果
        ["130631"] = {
        {type = "effect", time = 0, duration = 4, name = "skill_130631_route2_m", bone = "", speed = 1},
        },
    -- 2201 豹人
        -- 2201犬影牙
        ["220111"] = {
            {type = "effect", time = 0, duration = 1.5, name = "skill_220111_route2", bone = "", speed = 1},
        },
        ["220112"] = {
            {type = "effect", time = 0, duration = 1.5, name = "skill_220111_route3", bone = "", speed = 1},
        },
        ["220113"] = {
            {type = "effect", time = 0, duration = 1.5, name = "skill_220111_route4", bone = "", speed = 1},
        },
        -- 2201扑袭
        ["220121"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_220121_route1", bone = "", speed = 1},
        },

    -- 1101 正义审判
        ["110121"] = {
            {type = "effect", time = 0, duration = 2.3, name = "skill_110121_route2", bone = "", speed = 1},
            {type = "camera", time = 1, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.18;0;0.1;3"}
        },
    -- 1301 魔术师奥术飞弹觉醒后
        ["130101"] = {
            {type = "effect", time = 0, duration = 2.3, name = "bullet_130102", bone = "", speed = 1},
            {type = "camera", time = 0.13, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.18;0;0.1;3"}
        },
        ["130102"] = {
            {type = "effect", time = 0, duration = 2.3, name = "skill_130102_hit", bone = "", speed = 1},
            {type = "camera", time = 0.13, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.18;0;0.1;3"},
            {type = "audio", time = 0, duration = 1, name = "JN-1301-10002-3", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
        },
        
    -- 1305 马耶罗
        ["130511"] = {
            {type = "effect", time = 0.533, duration = 1.133, name = "skill_130511_route4", bone = "", speed = 1},
        },

    -- 2101 卡奥斯地表残留
        ["210122"] = {
            {type = "effect", time = 0, duration = 12, name = "skill_210121_route3_m", bone = "", speed = 1},
            -- {type = "camera", time = 0.6, duration = 0.3, name = "shake", params = "0;1;0;0.1;3"},
            -- {type = "audio", time = 0, duration = 1.2, name = "JN-LS-10003-2", speed = 1, volume = 1, bloop = false},
        },
    -- 2103 贝福特
        ["210331"] = {        --   贝福特普攻受击特效（蛮荒系）      
            {type = "audio", time = 0, duration = 1, name = "JN-2103-210331-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            -- {type = "effect", time = 0, duration = 1.5, name = "skill_410311_route2", bone = "", speed = 1},
            {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.5;0;0.1;3"},
        },  
    -- 2202 卡丽 龙卷风
        ["220241"] = {
            {type = "effect", time = 0, duration = 12, name = "bullet_220241", bone = "", speed = 1},
            -- {type = "camera", time = 0.6, duration = 0.3, name = "shake", params = "0;1;0;0.1;3"},
            -- {type = "audio", time = 0, duration = 1.2, name = "JN-LS-10003-2", speed = 1, volume = 1, bloop = false},
        },
    -- 2204 帖纳伦
        ["220411"] = {  -- 魔箭之雨
            {type = "effect", time = 0, duration = 12, name = "bullet_220411", bone = "", speed = 1.5},
            {type = "audio", time = 0, duration = 5, name = "JN-2204-220411-hit", speed = 1, volume = 0.4, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            -- {type = "audio", time = 0, duration = 1.2, name = "JN-LS-10003-2", speed = 1, volume = 1,bloop = false},
        },
        ["220421"] = {  -- 魔箭之雨
            {type = "effect", time = 0, duration = 12, name = "bulllet_220421", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1.2, name = "JN-LS-10003-2", speed = 1, volume = 1,bloop = false},
        },
        ["220431"] = {  -- 魔魂之界显现
            {type = "effect", time = 0, duration = 1, name = "skill_220431_route2", bone = "", speed = 1,is_coexist = true},
            -- {type = "audio", time = 0, duration = 1.2, name = "JN-LS-10003-2", speed = 1, volume = 1, bloop = false},
        },
        ["220432"] = {  -- 魔魂之界循环
            {type = "effect", time = 0, duration = 12, name = "skill_220431_route2_m", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1.2, name = "JN-LS-10003-2", speed = 1, volume = 1, bloop = false},
        },


        ["800821"] = {
            {type = "audio", time = 0, duration = 1.5, name = "JN-2304-230431-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "effect", time = 0, duration = 2, name = "skill_230451_hit", bone = "", speed = 1},
        },
    -- 2301 巴尔金
        -- 2301巴尔金致命炎爆（大）
            ["230111"] = {
            {type = "effect", time = 0, duration = 5, name = "skill_230111_route4", bone = "", speed = 1},
            {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1.2;0;0.1;3"},
            {type = "audio", time = 0, duration = 2, name = "JN-2301-230111-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        -- 2301巴尔金致命炎爆（小）
            ["230112"] = {
                {type = "effect", time = 0, duration = 5, name = "skill_230111_route6", bone = "", speed = 1},
                {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3"},
                {type = "audio", time = 0, duration = 2, name = "JN-2301-230111-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        -- 2301巴尔金致命炎爆（中）
            ["230113"] = {
                {type = "effect", time = 0, duration = 5, name = "skill_230111_route6", bone = "", speed = 1},
                {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3"},
                {type = "audio", time = 0, duration = 2, name = "JN-2301-230111-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
    -- 2302 拉佐玛天雷
        ["230211"] = {
        {type = "effect", time = 0, duration = 5, name = "skill_230211_route2", bone = "", speed = 1},
        {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3"},  
        {type = "audio", time = 0, duration = 5, name = "JN-2302-230211-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true },
        },

    -- 2303 洛卡卡
        -- 2303洛卡卡火瀑
            ["230321"] = {
                {type = "effect", time = 0, duration = 0.8, name = "skill_230321_route3", bone = "", speed = 1},
                {type = "camera", time = 0, duration = 2, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3"},
            --  {type = "audio", time = 0, duration = 2, name = "JN-2301-230111-hit", speed = 1, volume = 1, bloop = false},
            },  
            -- 2303洛卡卡流星火雨
            ["230311"] = {           
                -- {type = "camera", time = 0.2, duration = 2, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3"},
                {type = "audio", time = 0, duration = 1, name = "JN-2303-230311-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
                {type = "effect", time = 0, duration = 2, name = "bullet_230311", bone = "", speed = 1, is_coexist= true},
            }, 
    -- 2304 卡纳耶娃
        ["230401"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_230401", bone = "", speed = 1, is_coexist = true},
            {type = "audio", time = 0, duration = 1, name = "JN-2304-230401", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

        },
    -- 3101 克拉通
        ["310121"] = {           --   人形泰坦过肩摔被抛落地灰尘受击特效（元素-自然）
                {type = "effect", time = 0, duration = 3, name = "skill_310121_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-3101-310121-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
                {type = "camera", time = 0.6, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3"},
            },
    -- 3102 巴奥荆棘
        ["310211"] = {
            {type = "effect", time = 0, duration = 3, name = "skill_310211_route2", bone = "", speed = 1 , is_coexist = true},
            {type = "camera", time = 0, duration = 0.3, name = "shake", params = "0;1;0;0.1;3"},
            --  {type = "audio", time = 0, duration = 1.2, name = "JN-LS-10003-2", speed = 1, volume = 1, bloop = false},
        }, 
    -- 3104 波萨达鲨鱼
        ["310411"] = {
            {type = "effect", time = 0, duration = 5, name = "skill_310411_route2", bone = "", speed = 1 ,},
            {type = "camera", time = 1.2, duration = 1, name = "shake", params = "0;1;0;0.1;5"},
        }, 
        ["310431"] = {
            {type = "effect", time = 0, duration = 6, name = "skill_310431_route2", bone = "", speed = 1 ,},
            -- {type = "camera", time = 0, duration = 0.3, name = "shake", params = "0;1;0;0.1;3"},
            --  {type = "audio", time = 0, duration = 1.2, name = "JN-LS-1000asd3-2", speed = 1, volume = 1, bloop = false},
        }, 
    -- 3201 碧伦斯
        -- 3201碧伦斯鹰隼箭
        ["320111"] = {
            {type = "effect", time = 0, duration = 5, name = "skill_320111_hit", bone = "", speed = 1},
            {type = "audio", time = 0.2, duration = 2, name = "JN-3201-10006-3", speed = 1, volume = 0.6, bloop = false, tag = 1, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP, is_coexist = true},
            --  {type = "camera", time = 0.315, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.18;0;0.1;3"}
            {type = "camera", time = 0.315, duration = 1.5, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.5;0;0.1;3"},
        },       
    -- 3302 拉波尔酸雨
        ["330211_start"] = {
            {type = "effect", time = 0, duration = 1.5, name = "skill_330212_route1", bone = "", speed = 1,is_coexist = true},
            --  {type = "camera", time = 0, duration = 2, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3"},
            --  {type = "audio", time = 0, duration = 2, name = "JN-2301-230111-hit", speed = 1, volume = 1, bloop = false},
            },  
        ["330211_loop"] = {
            {type = "effect", time = 0, duration = 5, name = "skill_330212_route_m", bone = "", speed = 1,is_coexist = true},
            --  {type = "camera", time = 0, duration = 2, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3"},
            --  {type = "audio", time = 0, duration = 2, name = "JN-2301-230111-hit", speed = 1, volume = 1, bloop = false},
        }, 
        ["330211_end"] = {
            {type = "effect", time = 0, duration = 2, name = "skill_330212_route3", bone = "", speed = 1},
        --  {type = "camera", time = 0, duration = 2, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3"},
        --  {type = "audio", time = 0, duration = 2, name = "JN-2301-230111-hit", speed = 1, volume = 1, bloop = false},
        }, 
        ["330202"] = {
            {type = "effect", time = 0, duration = 2, name = "skill_330202_hit", bone = "", speed = 1},
        --  {type = "camera", time = 0, duration = 2, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3"},
        --  {type = "audio", time = 0, duration = 2, name = "JN-2301-230111-hit", speed = 1, volume = 1, bloop = false},
        }, 
    -- 3303 枭兽群星集束
        ["330311"] = {
            {type = "effect", time = 0, duration = 2, name = "skill_330311_route1", bone = "", speed = 1},
            {type = "camera", time = 0.2, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3",is_coexist = true},
            {type = "audio", time = 0, duration = 1, name = "JN-3301-330111-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },  
        ["330312"] = {
            {type = "effect", time = 0, duration = 2, name = "skill_330311_route2", bone = "", speed = 1},
            {type = "camera", time = 0.2, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3",is_coexist = true},
            {type = "audio", time = 0, duration = 1, name = "JN-3301-330111-1", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        }, 
        ["330313"] = {
            {type = "effect", time = 0, duration = 2, name = "skill_330311_route3", bone = "", speed = 1},
            {type = "camera", time = 0.2, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3",is_coexist = true},
            {type = "audio", time = 0, duration = 1, name = "JN-1101-110111-2", speed = 1.2, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        }, 

    -- 3303 鲁齐亚诺传送门
        ["330331"] = {           
        {type = "effect", time = 0, duration = 2, name = "skill_330331_route2", bone = "", speed = 1},
        --  {type = "audio", time = 0, duration = 1, name = "JN-2203-220301-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },    
        ["330332"] = {        --  巨手战士大招地面效果
            {type = "effect", time = 0, duration = 5, name = "skill_410311_route3", bone = "", speed = 1,is_coexist = true},
            {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3"},
            {type = "audio", time = 0, duration = 5, name = "JN-7182-718211", speed = 0.8, volume = 0.8, bloop = false, is_coexist = true },
        },
    -- 3304 小鹿
        -- 必杀技
        ["330411"] = {
            {type = "effect", time = 0, duration = 99, name = "skill_330411_route2", bone = "", speed = 1 },
        },
        --  龙卷风
        ["330421"] = {
            {type = "effect", time = 0, duration = 99, name = "bullet_330421", bone = "", speed = 1 },
            {type = "audio", time = 0, duration = 2, name = "JN-2202-220241", speed = 1, volume = 0.4, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        --  生命之泉
        ["330431"] = {
            {type = "effect", time = 0, duration = 99, name = "skill_330432_route_m", bone = "", speed = 1 },
        },
        ["330431_born"] = {
            {type = "effect", time = 0, duration = 2, name = "skill_330432_route2", bone = "", speed = 1, is_coexist = true },
        },
        ["330431_dead"] = {
            {type = "effect", time = 0, duration = 2, name = "skill_330432_route2", bone = "", speed = 1, is_coexist = true },
        },
    -- 3305 莎弗草地
        ["330511"] = {
            {type = "effect", time = 0, duration = 10, name = "skill_330511_route2_m", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1.2, name = "JN-3305-330511-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    -- 4103 巨手战士地面效果
        ["410311"] = {        --  巨手战士大招地面效果
            {type = "effect", time = 0, duration = 5, name = "skill_410311_route3", bone = "", speed = 1,is_coexist = true},
            {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.75;0;0.1;3"},

        },
    -- 4202 莫妮卡影狼自爆
        ["420233"] = {        --  巨手战士大招地面效果
            {type = "effect", time = 0, duration = 2.5, name = "scenes_123001_death", bone = "", speed = 1 , is_coexist = true},
        },
    -- 4204 骷髅刺客子弹
        ["420411"] = {
            {type = "effect", time = 0, duration = 2, name = "skill_420411_hit", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-4104-410411-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    -- 4205 斯佩林小丑棺材
        ["420511"] = {     --烟雾
            {type = "effect", time = 0, duration = 2, name = "skill_420511_route2", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1, name = "JN-4104-410411-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["420531"] = {    --棺材
            {type = "effect", time = 0, duration = 2, name = "skill_420531_route1", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 4, name = "JN-4205-420531", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["420541"] = {    --魂魄升天
            {type = "effect", time = 0, duration = 2, name = "skill_420541_route1", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 3, name = "JN-4205-420511-boom", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    -- 4301 班恩邪恶进化
        ["430111"] = {
            {type = "effect", time = 0, duration = 5, name = "skill_430111_hit", bone = "", speed = 1},
            {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 1.2, name = "JN-LS-10003-2", speed = 1, volume = 1, bloop = false},
        },
    -- 4302 保卢斯大招范围伤害
        ["430212"] = {
            {type = "effect", time = 0, duration = 12, name = "skill_430212_route1_m", bone = "", speed = 1},
            -- {type = "camera", time = 0.6, duration = 0.3, name = "shake", params = "0;1;0;0.1;3"},
            -- {type = "audio", time = 0, duration = 1.2, name = "JN-LS-10003-2", speed = 1, volume = 1, bloop = false},
        },
    -- 5201 艾法拉
        ["520111"] = {
            {type = "effect", time = 0, duration = 4, name = "skill_520111_route2", bone = "", speed = 1},
            {type = "camera", time = 1.3, duration = 0.3, name = "shake", params = "0;1;0;0.1;3"},
            {type = "audio", time = 0, duration = 4, name = "JN-5201-520111-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["520121"] = {
            {type = "effect", time = 0, duration = 3, name = "skill_520121_hit", bone = "", speed = 1},
        },
        ["520131"] = {
            {type = "effect", time = 0, duration = 2.5, name = "skill_520131_route2", bone = "", speed = 1, is_coexist = true},
        },
    -- 5202 梵雅娜
        ["520221"] = {
            {type = "effect", time = 0, duration = 3, name = "skill_520221_hit", bone = "", speed = 1, is_coexist = true},        
            {type = "audio", time = 0, duration = 2, name = "JN-5202-520222", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "camera", time = 0, duration = 0.3, name = "shake", params = "0;0.5;0;0.1;3", is_coexist = true},

        },
        ["520222"] = {
            {type = "effect", time = 0, duration = 4, name = "skill_520221_hit3", bone = "", speed = 1, is_coexist = true},
        },
        ["520223"] = {
            {type = "effect", time = 0, duration = 3, name = "skill_520221_hit4", bone = "", speed = 1, is_coexist = true},
            {type = "camera", time = 0, duration = 4.5, name = "shake", params = "0;0.3;0;0.1;15", is_coexist = true},



        },
    -- 6101 墨索斯    
        -- 6101虚境黑洞不断旋转的黑洞特效
        ["610111"] = {
            {type = "effect", time = 0, duration = 6, name = "skill_610112_route1_m", bone = "", speed = 1},
            -- {type = "camera", time = 0.6, duration = 0.3, name = "shake", params = "0;1;0;0.1;3"},
            {type = "audio", time = 0, duration = 6, name = "JN-6101-610111-bullet", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
        ["610112"] = {
            {type = "effect", time = 0, duration = 3, name = "skill_610112_route2", bone = "", speed = 1},
            {type = "camera", time = 0, duration = 0.3, name = "shake", params = "0;1;0;0.1;3"},
            {type = "audio", time = 0, duration = 3, name = "JN-6101-610111-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    -- 6301 拉欢娜
        ["630111"] = {      
            {type = "effect", time = 0, duration = 2.5, name = "skill_630111_route2", bone = "", speed = 1},
             {type = "audio", time = 0, duration = 3, name = "JN-6301-630111-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    -- 6302 费尔察克
        ["630211"] = {     -- 寒风 
            {type = "effect", time = 0, duration = 15, name = "skill_630211_route3_m", bone = "", speed = 1},
        },
        ["630212"] = {     -- 冰封 
            {type = "effect", time = 0, duration = 15, name = "skill_630211_route4_m", bone = "", speed = 1},
        },
        ["630221"] = {      
            {type = "effect", time = 0, duration = 2, name = "skill_630221_hit", bone = "", speed = 1},
        },
        ["630251"] = {      
            {type = "effect", time = 0, duration = 2, name = "skill_630251_route1", bone = "", speed = 1},
        },
    -- Boss -- 7382红龙死亡烈焰空中盘旋无伤害表现
        ["738211"] = {
            {type = "effect", time = 0, duration = 12, name = "skill_738211_route4", bone = "", speed = 1},
            -- {type = "camera", time = 0.6, duration = 0.3, name = "shake", params = "0;1;0;0.1;3"},
            -- {type = "audio", time = 0, duration = 1.2, name = "JN-LS-10003-2", speed = 1, volume = 1, bloop = false},
        },


    -- Boss -- 魔化沙虫钻地表现
        ["718111"] = {
            {type = "effect", time = 0, duration = 2, name = "skill_718111_route3", bone = "", speed = 1},
            {type = "camera", time = 0, duration = 3, name = "shake", tag = ACTIVE_TAG.CAMP2, params = "0;0.2;0;0.1;200", is_coexist = true},
            -- {type = "audio", time = 0, duration = 1.2, name = "JN-LS-10003-2", speed = 1, volume = 1, bloop = false},
        },
    -- Boss -- 7383元祖蛇蜥毒液表现
        ["738311"] = {
            {type = "effect", time = 0, duration = 2, name = "skill_738311_route2", bone = "", speed = 0.5},
            -- {type = "audio", time = 0, duration = 1.2, name = "JN-LS-10003-2", speed = 1, volume = 1, bloop = false},
        },
    -- Boss -- 7183矮人构造物炸弹
        ["718311"] = {
            {type = "effect", time = 0, duration = 2, name = "bullet_718312", bone = "", speed = 1},
            --  {type = "audio", time = 0, duration = 1.2, name = "Boss-7382-738221-hit", speed = 1, volume = 1, bloop = false},
        },
    -- Boss -- 雷神冲击
        ["738121"] = {
            {type = "effect", time = 0, duration = 5, name = "skill_738121_hit", bone = "", speed = 1},
            {type = "camera", time = 0.6, duration = 0.3, name = "shake", params = "0;1;0;0.1;3"},

        },
    -- Boss -- 虚空领主
        --扩散
            ["738611"] = {
                {type = "effect", time = 0, duration = 10, name = "skill_738611_route3", bone = "", speed = 1},
                -- {type = "camera", time = 0.6, duration = 0.3, name = "shake", params = "0;1;0;0.1;3"},

            },
        --雷云
            ["738621"] = {
                {type = "effect", time = 0, duration = 10, name = "bullet_738621", bone = "", speed = 1},
                -- {type = "camera", time = 0.6, duration = 0.3, name = "shake", params = "0;1;0;0.1;3"},

            },
    -- 801003 符文 巨龙之怒
        ["801003"] = {
            {type = "effect", time = 0, duration = 5, name = "runeskill_1003", bone = "", speed = 1},
            {type = "camera", time = 0.2, duration = 0.3, name = "shake", params = "0;0.3;0;0.1;3"},
        },
    -- 801023 符文 怒波狂浪
        ["801023"] = {
            {type = "effect", time = 0, duration = 5, name = "runeskill_1023", bone = "", speed = 1},
            {type = "camera", time = 1, duration = 0.3, name = "shake", params = "0;0.3;0;0.1;3"},
        },
    },
    
--  综合子弹 
    ["120101"] = {          -- 托尔丁普攻子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["120111"] = {          -- 托尔丁狙击子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["120201"] = {          -- 老奶奶普攻子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["120202"] = {          -- 老奶奶普攻子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["120211"] = {          -- 老奶奶喷气炸弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            {type = "audio", time = 0, duration = 1.5, name = "JN-1202-120211-bullet", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["120221"] = {          -- 老奶奶火力全开子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["120401"] = {          -- 朱塞佩普攻子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["120411"] = {          -- 朱塞佩大招子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["120421"] = {          -- 朱塞佩炸药桶子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["120431"] = {          -- 朱塞佩烟雾弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["130101"] = {          -- 奥术飞弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["130201"] = {          -- 抛物线子弹抛物线(毒药瓶)
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["130211"] = {          -- 抛物线子弹抛物线(能量药水瓶)
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["130212"] = {          -- 抛物线子弹抛物线(扳手)
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["130231"] = {          -- 抛物线子弹抛物线(生命药水瓶)
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["130251"] = {          -- 超级药水子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["130301"] = {          -- 杰西卡普攻
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["130302"] = {          -- 杰西卡普攻
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["130311"] = {          -- 杰西卡水龙卷
        ["bullet_start"] = {
            --  {type = "audio", time = 0, duration = 1, name = "JN-1303-130311-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["130321"] = {          -- 杰西卡水鲛弹子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            {type = "audio", time = 0, duration = 1, name = "JN-1303-130321-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["130322"] = {          -- 杰西卡水鲛弹头顶
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "audio", time = 0, duration = 1, name = "JN-1303-130321-Begin", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["130401"] = {          -- 沃顿圣击子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["130501"] = {          -- 马耶罗普攻子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["130521"] = {          -- 马耶罗大音符1
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["130522"] = {          -- 马耶罗大音符2
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["130523"] = {          -- 马耶罗大音符3
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["130601"] = {          -- 舞娘普攻子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 1, name = "JN-1301-130102", speed = 1, volume = 0.7, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
    },
    ["130621"] = {          -- 舞娘治疗子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["130622"] = {          -- 舞娘技能伤害子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            {type = "audio", time = 0, duration = 1, name = "JN-1301-130102", speed = 1, volume = 0.7, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP,is_coexist = true},
        },
    },
    ["210111"] = {          -- 卡奥斯牛子弹
        ["bullet_start"] = {
            {type = "camera", time = 0, duration = 2, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.1;0;0.1;20"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["210211"] = {          -- 多鲁克回旋镖子弹左
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["210212"] = {          -- 多鲁克回旋镖子弹右
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["210331"] = {          -- 贝福特抓钩
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["220201"] = {          -- 鹰身女妖飓风子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["220241"] = {          -- 鹰身女妖龙卷风子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["220301"] = {          -- 希莱雅矛子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["220401"] = {          -- 帖纳伦普攻子弹
        ["bullet_start"] = {
            --  {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10002-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["230121"] = {          -- 巴尔金子弹旋转
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["230122"] = {          -- 巴尔金子弹射出
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            {type = "audio", time = 0, duration = 1, name = "JN-2301-230121", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["230301"] = {          -- 洛卡卡普攻子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["310251"] = {          -- 巴奥进化后的普攻子弹（抛物线）
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["320101"] = {          -- 碧伦丝绿弓子弹
        ["bullet_start"] = {
            {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["320151"] = {          -- 碧伦丝火焰子弹
        ["bullet_start"] = {
            {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10002-2", speed = 1, volume = 0.1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["320161"] = {          -- 碧伦丝雷电子弹
        ["bullet_start"] = {
            {type = "audio", time = 0, duration = 1, name = "JN-3201-10003-2", speed = 1, volume = 0.2, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["320171"] = {          -- 碧伦丝雷火箭子弹
        ["bullet_start"] = {
            {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10003-2", speed = 1, volume = 0.2, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["320221"] = {          -- 男刺客普攻子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["320301"] = {          -- 法林普攻子弹
        ["bullet_start"] = {
            {type = "audio", time = 0, duration = 1, name = "JN-3203-320301-bullet", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["320311"] = {          -- 法林大回旋表子弹
        ["bullet_start"] = {
            {type = "audio", time = 0, duration = 5, name = "JN-3203-320311-bullet", speed = 1, volume = 1, bloop = true, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["330101"] = {          -- 皮克精普攻子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["330201"] = {          -- 拉波儿普攻子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["330501"] = {          -- 羊蹄人普攻子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["330521"] = {          -- 羊蹄人红子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["330522"] = {          -- 羊蹄人蓝子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["330523"] = {          -- 羊蹄人绿子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },

    ["800401"] = {          -- 瓦迪斯召唤物骷髅弓箭手 普通子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["800402"] = {          -- 瓦迪斯召唤物骷髅弓箭手 火子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["410331"] = {          -- 瓦迪斯召唤物骷髅弓箭手 火子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["410332"] = {          -- 瓦迪斯召唤物骷髅弓箭手 火子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["420201"] = {          -- 提夫林射手普攻子弹
        ["bullet_start"] = {
            -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
            -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["420202"] = {          -- 提夫林射手普攻子弹 适配第三发位置
        ["bullet_start"] = {
        -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
        -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["420221"] = {          -- 提夫林射手2技能子弹
        ["bullet_start"] = {
        -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
        -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["420231"] = {          -- 提夫林射手3技能子弹
        ["bullet_start"] = {
        -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
        -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["420411"] = {          -- 邪火骷髅火球
        ["bullet_start"] = {
            {type = "audio", time = 0, duration = 2, name = "JN-4204-420411-loop", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["430101"] = {          -- 邪术师普攻子弹
        ["bullet_start"] = {
        -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
        -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["430131"] = {          -- 邪术师符咒子弹
        ["bullet_start"] = {
        -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
        -- {type = "audio", time = 0, duration = 0.7, name = "JN-3201-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["430141"] = {          -- 邪术师乌鸦子弹盘旋
        ["bullet_start"] = {
        -- {type = "camera", time = 2.5, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"}
        {type = "audio", time = 0, duration = 0.7, name = "JN-4301-430141", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    ["430142"] = {          -- 班恩乌鸦射出子弹
        ["bullet_start"] = {
            {type = "audio", time = 0, duration = 0.7, name = "JN-4301-430141-shoot", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
--  受击特效（1-圣光）
    -- 1101 萨姬亚    
        ["9110101"] = {           --   锤子
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_110101_route_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-1101-110101-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
                },
        },
        ["9110111"] = {        --   萨姬亚受击特效
            ["hit"] = {        
                {type = "effect", time = 0, duration = 2, name = "skill_110111_route3_m", bone = "", speed = 1,is_coexist = true},
                --  {type = "camera", time = 0, duration = 0.3, name = "shake", params = "0;0.5;0;0.1;3"},
            -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9110121"] = {        --   萨姬亚受击特效
            ["hit"] = {        
                {type = "effect", time = 0, duration = 2, name = "skill_110121_hit", bone = "", speed = 0.7,is_coexist = true},
                {type = "camera", time = 0, duration = 0.3, name = "shake", params = "0;0.8;0;0.1;6"},
            -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9110131"] = {        --   萨姬亚受击特效
            ["hit"] = {        
            {type = "effect", time = 0, duration = 2, name = "skill_110131_route3", bone = "", speed = 0.7,is_coexist = true},
            {type = "camera", time = 0, duration = 0.3, name = "shake", params = "0;0.8;0;0.1;6"},
            -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9110133"] = {           --   圣光打击
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_110121_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-1101-110121-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 1102 卡马尔
        ["9110201"] = {           --   烈血斩
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_110201_hit1", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-1102-110201-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9110221"] = {           --   旋龙杀
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_110201_hit1", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-1102-110201-hit", speed = 1, volume = 0.1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 1103 鲍德维克
        ["9110301"] = {           --   鲍德维克受击特效
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_110301_hit", bone = "", speed = 1},
                -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 1201 托尔丁
        ["9120101"] = {           --   拔枪射击
            ["hit"] = {       
                {type = "effect", time = 0, duration = 1, name = "skill_120101_hit", bone = "", speed = 1},
                --  {type = "audio", time = 0, duration = 1, name = "JN-1201-120101-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9120111"] = {           --   死神狙杀
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_120111_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-1201-120111-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        -- ["109"] = {           --   发现猎物
        --     ["hit"] = {
        --         {type = "effect", time = 0, duration = 1.5, name = "skill_120121_hit", bone = "", speed = 1},
        --         -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        --     },
        -- },
        ["9120112"] = {           --   死神狙杀120152
            ["hit"] = {
                {type = "effect", time = 0, duration = 2, name = "skill_120111_route2", bone = "HeadPos", speed = 1},
                -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 1202 伊丽莎白
        ["9120201"] = {           --   拔枪射击
            ["hit"] = {       
                {type = "effect", time = 0, duration = 1, name = "skill_120101_hit", bone = "", speed = 1},
                --  {type = "audio", time = 0, duration = 1, name = "JN-1201-120101-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9120211"] = {        --   喷气炸弹受击特效
            ["hit"] = {        
                {type = "camera", time = 0, duration = 0.3, name = "shake", params = "0;0.5;0;0.1;3"},
                {type = "effect", time = 0, duration = 3, name = "skill_120211_route4", bone = "", speed = 1,is_coexist = true},
            {type = "audio", time = 0, duration = 1.5, name = "JN-1202-120211-hit", speed = 1, volume = 0.8, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9120221"] = {        --   霹雳手雷受击特效
            ["hit"] = {        
                {type = "effect", time = 0, duration = 1, name = "skill_120221_hit", bone = "", speed = 1},
                -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 1203 布维尔
        ["9120301"] = {        --   西洋剑客普攻伤害受击特效
            ["hit"] = {        
                {type = "effect", time = 0, duration = 1, name = "skill_120301_hit", bone = "", speed = 1},
                -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9120311"] = {        --   布维尔决斗特效
            ["hit"] = {        
                    {type = "effect", time = 0, duration = 2, name = "skill_120311_route2", bone = "", speed = 1},
                },
        },
        ["9120341"] = {        --   西洋剑客到我登场伤害受击特效
            ["hit"] = {        
                {type = "effect", time = 0, duration = 1, name = "skill_120341_hit", bone = "", speed = 1},
                -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 1204 朱塞佩
        ["9120401"] = {        --   朱塞佩普攻受击特效
            ["hit"] = {        
                {type = "effect", time = 0, duration = 1, name = "skill_120401_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-1204-120401-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 1205 巴克
        ["9120501"] = {        --   刃击受击特效
            ["hit"] = {        
                {type = "effect", time = 0, duration = 1, name = "skill_120501_hit", bone = "", speed = 1},
                -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9120511"] = {        --   割喉受击特效
            ["hit"] = {        
                {type = "effect", time = 0, duration = 1, name = "skill_120511_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-1203-120301", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9120521"] = {        --   肾击受击特效
            ["hit"] = {        
                {type = "effect", time = 0, duration = 1, name = "skill_120521_hit", bone = "", speed = 1},
                -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 1301 因娜拉
        ["9130101"] = {           --   普攻 震荡波
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_130101_hit", bone = "", speed = 1},
                --  {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9130121"] = {           --   瓦解射线  
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_130121_hit", bone = "", speed = 1},
            },
        },
    -- 1302 勒芙蕾丝
        ["9130201"] = {           --   毒药瓶破碎与液体溅射受击特效
                ["hit"] = {
                {type = "effect", time = 0, duration = 2, name = "skill_130201_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-1302-130201-hit", speed = 0.8, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
                },
        },
        ["9130211"] = {           --   能量药水瓶破碎与液体溅射受击特效
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_130211_hit", bone = "", speed = 1},
                -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9130212"] = {           --   扳手子弹击打受击特效
            ["hit"] = { 
                {type = "effect", time = 0, duration = 1, name = "skill_130212_hit", bone = "", speed = 1},
                -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9130231"] = {           --   生命药水子弹击打受击特效
            ["hit"] = { 
                {type = "effect", time = 0, duration = 1, name = "skill_130231_hit", bone = "", speed = 1},
                -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9130251"] = {           --   超级药水子弹击打受击特效
            ["hit"] = {
                {type = "effect", time = 0, duration = 2, name = "skill_130251_hit", bone = "", speed = 1},
                -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 1303 杰西卡
        ["9130301"] = {           --   洁西卡普通攻击受击特效
            ["hit"] = {        
                {type = "effect", time = 0, duration = 1, name = "skill_130301_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-1303-130301-hit", speed = 1, volume = 0.1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 1304 沃顿
        ["9130401"] = {           --   沃顿普攻受击特效
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_130401_hit", bone = "", speed = 1},
                -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        
        },
    -- 1305 马耶罗
        ["9130501"] = {        --   马耶罗普攻伤害受击特效
            ["hit"] = {        
                {type = "effect", time = 0, duration = 1, name = "skill_130501_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-1305-130521-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9130521"] = {        --   马耶罗大音符伤害受击特效
            ["hit"] = {        
                {type = "effect", time = 0, duration = 1, name = "skill_130521_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-1305-130521-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9130531"] = {        --   马耶罗大音符伤害受击特效
            ["hit"] = {        
                {type = "effect", time = 0, duration = 1, name = "skill_130301_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-1305-130531", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 1306 罗珊 舞娘
        ["9130601"] = {        --   舞娘普攻受击特效
            ["hit"] = {        
                {type = "effect", time = 0, duration = 1, name = "skill_130601_hit", bone = "", speed = 1},
                -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9130621"] = {        --   舞娘热舞飞扬治疗受击特效
            ["hit"] = {        
            {type = "effect", time = 0, duration = 1, name = "skill_130621_hit", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-1306-130621-heal", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9130622"] = {        --   舞娘热舞飞扬伤害受击特效
            ["hit"] = {        
                {type = "effect", time = 0, duration = 1, name = "skill_130622_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-3301-330101-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    ["117"] = {           --   治疗受击特效
        ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_110111_route4_m", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
        },
    },
    --

    
--  受击特效（2-蛮荒）
    -- 2101 卡奥斯
        ["9210101"] = {           --   斧头武器受击特效
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_210101_hit", bone = "", speed = 1},
                -- {type = "audio", time = 0, duration = 1, name = "JN-BR-10001-4", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9210111"] = {           --   野牛撞击的受击特效
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_210111_hit", bone = "", speed = 1},
                --  {type = "audio", time = 0, duration = 1, name = "JN-1101-110101-2", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["205"] = {           --   拳脚受击特效
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_210131_hit", bone = "", speed = 1},
                --  {type = "audio", time = 0, duration = 1, name = "JN-1101-110101-2", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },

    -- 2102 多鲁克
        ["9210201"] = {           --   多鲁克普通斧子受击特效（蛮荒系）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_210201_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-1102-110201-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9210211"] = {           --   多鲁克特殊斧子受击特效（蛮荒系）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_210211_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-1102-110201-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 2103 贝福特
        ["9210301"] = {        --   贝福特普攻受击特效（蛮荒系） 
            ["hit"] = {      
            {type = "effect", time = 0, duration = 2, name = "skill_210301_hit", bone = "", speed = 1},
            }, 
        }, 
        ["9210331"] = {        --   贝福特普攻受击特效（蛮荒系） 
            ["hit"] = {      
            {type = "effect", time = 0, duration = 2, name = "skill_210301_hit", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-2103-210331-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            }, 
        }, 
        ["9210331"] = {        --   贝福特普攻受击特效（蛮荒系） 
            ["hit"] = {      
            {type = "audio", time = 0, duration = 1, name = "JN-2103-210331-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.5;0;0.1;3"},
            }, 
        }, 
        ["9210321"] = {        --   贝福特电锯受击特效（蛮荒系） 
            ["hit"] = {      
            {type = "effect", time = 0, duration = 2, name = "skill_210321_hit_m", bone = "", speed = 1},
            --  {type = "audio", time = 0, duration = 1, name = "JN-2203-220301-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            }, 
        },
    -- 2104 阿拉沃
        ["9210401"] = {        --   阿拉沃受击特效（蛮荒系） 
            ["hit"] = {      
            {type = "effect", time = 0, duration = 1, name = "skill_210401_hit", bone = "", speed = 1},
            --  {type = "audio", time = 0, duration = 1, name = "JN-2203-220301-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            }, 
        }, 
        ["9210411"] = {        --   阿拉沃受击特效（蛮荒系） 
            ["hit"] = {      
            {type = "effect", time = 0, duration = 1, name = "skill_120401_hit", bone = "", speed = 1},
            --  {type = "audio", time = 0, duration = 1, name = "JN-2203-220301-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            }, 
        }, 
    -- 2105 伽罗格
        ["9210501"] = {        --   伽罗格普攻受击特效（蛮荒系） 
            ["hit"] = {      
            {type = "effect", time = 0, duration = 2, name = "skill_210501_hit", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1, name = "JN-3101-310121-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            }, 
        }, 
        ["9210521"] = {        --   伽罗格五连受击特效（蛮荒系） 
            ["hit"] = {      
            {type = "effect", time = 0, duration = 2, name = "skill_210521_hit", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1, name = "JN-3101-310121-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            }, 
        }, 
        ["9210531"] = {        --   伽罗格肩撞受击特效（蛮荒系） 
            ["hit"] = {      
            {type = "effect", time = 0, duration = 2, name = "skill_210531_hit", bone = "", speed = 1},
            {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3"},
            {type = "audio", time = 0, duration = 1, name = "JN-3101-310121-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            }, 
        }, 
    -- 2201 戈尔
        ["9220101"] = {           --   爪子（豹人普攻受击）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_220101_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-2201-220101-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9220111"] = {           --   爪子（豹人犬影牙受击）
            ["hit"] = {
                {type = "effect", time = 0.1, duration = 1, name = "skill_220111_hit", bone = "", speed = 1},
                {type = "camera", time = 0, duration = 1, name = "shake", params = "0;0.3;0;0.1;5"},
                --  {type = "audio", time = 0, duration = 2, name = "JN-BR-10004-2", speed = 1, volume = 0.6, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 2202 卡丽
        ["9220201"] = {           --   卡丽飓风子弹受击特效（蛮荒系）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_220201_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-2202-220201-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9220241"] = {           --   卡丽龙卷风子弹受击特效（蛮荒系）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_220241_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-2202-220201-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9220224"] = {        --   卡丽血回特效（蛮荒系） 
            ["hit"] = {      
            {type = "effect", time = 0, duration = 3, name = "buff_130411", bone = "", speed = 1,is_coexist=true},
            --  {type = "audio", time = 0, duration = 1, name = "JN-2203-220301-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            }, 
        }, 
    -- 2203 希莱雅
        ["9220301"] = {           --   希莱雅矛子弹受击特效（蛮荒系）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_220301_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-2203-220301-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 2204 贴纳伦
        ["9220401"] = {        --   帖纳伦普攻受击特效（蛮荒系） 
            ["hit"] = {      
            {type = "effect", time = 0, duration = 2, name = "skill_220401_hit", bone = "", speed = 1},
            --  {type = "audio", time = 0, duration = 1, name = "JN-2203-220301-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            }, 
        }, 
        ["9220411"] = {        --   帖纳伦大招受击特效（蛮荒系） 
            ["hit"] = {      
            {type = "effect", time = 0, duration = 2, name = "skill_220411_hit", bone = "", speed = 1},
            --  {type = "audio", time = 0, duration = 1, name = "JN-2203-220301-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            }, 
        }, 
    -- 2301 巴尔金
        ["9230101"] = {           --   巴尔金普攻受击特效（蛮荒系）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_230101_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-2301-230101-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9230102"] = {           --   巴尔金普攻受击特效（蛮荒系）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_230102_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-2301-230101-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9230121"] = {           --   巴尔金火球受击特效（蛮荒系）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_230121_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-2301-230121-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 2302 拉佐玛
        ["9230201"] = {        --   雷婆受击特效（蛮荒系） 
            ["hit"] = {      
            {type = "effect", time = 0, duration = 1, name = "skill_230201_hit", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-3201-10003-3", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            }, 
        }, 
    -- 2303 洛卡卡
        ["9230301"] = {        --   洛卡卡普攻子弹受击特效（蛮荒系）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_230301_hit", bone = "", speed = 1},
                --  {type = "audio", time = 0, duration = 1, name = "JN-2203-220301-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9230312"] = {        --   洛卡卡大招子弹受击特效（蛮荒系） 
            ["hit"] = {      
            {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.5;0;0.1;3"},
            {type = "effect", time = 0, duration = 2, name = "skill_230311_hit", bone = "", speed = 1},
            --  {type = "audio", time = 0, duration = 1, name = "JN-2203-220301-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            }, 
        }, 
    -- 2304 卡纳耶娃
        ["9230401"] = {        --   
            ["hit"] = {
                -- {type = "effect", time = 0, duration = 3, name = "skill_230401_hit", bone = "", speed = 1, is_coexist = true},
            },
        },
        ["9230421"] = {        --   小鹿泉水受击特效（元素-自然）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_330433_route", bone = "", speed = 1},
                -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
                },
        },
        ["9230461"] = {        --   大招强化涌泉图腾
            ["hit"] = {
                {type = "effect", time = 0, duration = 3, name = "buff_230411", bone = "", speed = 1},
                -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
                },
        },
        ["9230462"] = {        --   大招强化涌泉图腾
            ["hit"] = {
                {type = "effect", time = 0, duration = 3, name = "buff_230412", bone = "", speed = 1},
                -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
                },
        },
    --
--  受击特效（3-自然）
    --  3101 石头人受击特效综合
        ["9310101"] = {           --   人形泰坦普攻受击特效右手动作对应受击（元素-自然）
            ["hit"] = {
                {type = "effect", time = 0, duration = 2, name = "skill_310101_hit", bone = "", speed = 1},
                --  {type = "audio", time = 0, duration = 1, name = "JN-3301-330111-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["313"] = {           --   人形泰坦普攻受击特效左手动作对应受击（元素-自然）
            ["hit"] = {
                {type = "effect", time = 0, duration = 2, name = "skill_310102_hit", bone = "", speed = 1},
                --  {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9310111"] = {           --   人形泰坦万夫莫开盾牌碰撞攻击受击特效（元素-自然）
            ["hit"] = {
                {type = "effect", time = 0, duration = 2, name = "skill_310111_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-3101-310111-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    --  3102 树人受击特效综合
        ["9310201"] = {           --   巴奥拳脚受击特效（元素-自然）
            ["hit"] = {
            {type = "effect", time = 0, duration = 1.5, name = "skill_310201_hit", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9310211"] = {           --   巴奥森林密布受击特效（元素-自然）
            ["hit"] = {
            {type = "effect", time = 0, duration = 1.5, name = "skill_310211_hit", bone = "", speed = 1},
            --  {type = "audio", time = 0, duration = 1, name = "JN-3102-310211-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9310202"] = {           --   树苗爆炸受击特效（元素-自然）
            ["hit"] = {
            {type = "effect", time = 0, duration = 1.5, name = "skill_310221_hit", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-3101-310121-hit", speed = 0.5, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    --  3103 兰黛
        ["9310301"] = {           --   兰黛受击特效（元素-自然）
            ["hit"] = {
            {type = "effect", time = 0, duration = 1.5, name = "skill_310301_hit", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    --  3104 波萨达受及特效综合
        ["9310401"] = {           --   波萨达受击特效（元素-自然）
            ["hit"] = {
            {type = "effect", time = 0, duration = 1.5, name = "skill_310401_hit", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },   
        ["9310421"] = {           --   波萨达深海种技受击特效（元素-自然）
            ["hit"] = {
            {type = "effect", time = 0, duration = 1.5, name = "skill_310421_hit", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },   
    --  3201 碧伦丝受击特效综合
        ["9320101"] = {           --   自然箭矢受及特效
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_320101_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-3201-10001-3", speed = 1, volume = 0.8, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

            },
        },
        ["9320121"] = {           --   雷箭受击特效0.8s
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_320102_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-3201-10003-3", speed = 1, volume = 0.8, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9320122"] = {           --   雷箭受击特效 0.6s
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_320102_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-3201-10003-3", speed = 1, volume = 0.6, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9320131"] = {           --   火焰箭受击特效
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_320103_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 5, name = "JN-3201-10002-3", speed = 1, volume = 0.7, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9320151"] = {           --   雷火箭受击特效  0.8s      
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_320104_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 5, name = "JN-3201-10004-3", speed = 1, volume = 0.8, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9320152"] = {           --   雷火箭受击特效 0.6s
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_320104_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 5, name = "JN-3201-10004-3", speed = 1, volume = 0.6, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    --  3202 赫拉受击特效综合
        ["9320231"] = {           --   藤条长鞭环绕成一个圆圈、聚合、被拉至身前特效（做成受击显示）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_320231_route2", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-3202-320232-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9320202"] = {           --   刀剑光效-自然元素
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_320202_hit", bone = "", speed = 1},
                -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9320201"] = {           --   刀剑光效-自然元素
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_320201_hit", bone = "", speed = 1},
                -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["308"] = {           --   聚合时撞击受击特效（该英雄非普攻都可以共用）（蓝色爆炸效果）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_320221_hit", bone = "", speed = 1},
            },
        },
        ["9320231"] = {           --   有“冰霜之力”注入后长鞭攻击特殊受击特效、套索聚合时撞击受击特效
            ["hit"] = {
                {type = "effect", time = 0, duration = 0.5, name = "skill_320231_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-3202-320211-2", speed = 1, volume = 0.8, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
             },
        },
    
    --  3203 法林受击特效综合
        ["9320301"] = {        --   法林普攻受击特效（元素-自然）
            ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_320301_hit", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-3203-320301-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9320311"] = {        --   法林勇气旋风受击特效（元素-自然）
            ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_320311_hit", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-3203-320301-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9320321"] = {        --   法林密林吹箭受击特效（元素-自然）
            ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_320321_hit", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9320331"] = {        --   法林秘密巧技受击特效（元素-自然）
            ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_320331_hit", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    --  3301 若菲奈
        ["9330101"] = {           --   元素子弹受击特效（元素-自然）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_330101_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-3301-330101-hit", speed = 1, volume = 0.2, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },

    --  3302 鱼人受击特效综合
        ["9330201"] = {        --   拉波尔普攻受击特效（元素-自然）
            ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_330201_hit", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9330211"] = {        --   拉波尔酸雨受击特效（元素-自然）
            ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_330211_hit", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1, name = "JN-3302-330211-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9330221"] = {        --   拉波尔污水喷泉受击特效（元素-自然）
            ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_330221_hit", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },

    --  3304 露琪亚诺
        ["9330301"] = {        --   鲁齐亚诺普攻受击特效（元素-自然）
            ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_330301_hit", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9330321"] = {        --   鲁齐亚诺日蚀受击特效（元素-自然）
            ["hit"] = {
            {type = "effect", time = 0, duration = 2, name = "skill_330321_hit", bone = "", speed = 1},
            {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3"},
            -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    --  3304 小鹿受击特效综合a
        ["9330401"] = {        --   小鹿普攻受击特效（元素-自然）
            ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_330401_hit", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 0.5, name = "JN-3301-330101-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9330421"] = {        --   小鹿龙卷风受击特效（元素-自然）
            ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_330421_hit", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9330411"] = {        --   小鹿治疗受击特效（元素-自然）
            ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_330411_route3", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9330421"] = {        --   小鹿净化之风受击特效（元素-自然）
            ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_330421_hit", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9330431"] = {        --   小鹿泉水受击特效（元素-自然）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_330433_route", bone = "", speed = 1},
                -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
                },
        },
    --  3305 莎弗受击特效综合
        ["9330501"] = {        --   莎弗受击特效（元素-自然）
            ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_330501_hit", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1, name = "JN-1301-10001-2", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    
    --

    
--  受击特效（4-暗影）
    -- 4101 瓦迪斯
        ["9410101"] = {           --  刀光受击特效（暗影系）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_410101_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-3201-10002-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

            },
        },
        ["9410111"] = {           --  刀光受击特效（暗影系么，特效稍微大些、厚重些与普攻区分开）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_410111_hit", bone = "", speed = 1},
            },
        },
        ["9410121"] = {           --  通用召唤物受击特效（暗影系）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_410121_hit", bone = "", speed = 1},
            },
        },
    -- 4102 提米
        ["9410201"] = {           --  “恶灵漩涡”一个超大圆形区域灵魂不断旋转特效受击特效
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_410201_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-4302-430211-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9410211"] = {        --  通用召唤物受击特效（暗影系）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_410211_hit", bone = "", speed = 1},
            },
        },
    -- 4103 迪特里克
        --  ["9410311"] = {        --  巨手战士第二段受击
        --      ["hit"] = {
        --          {type = "effect", time = 0, duration = 3.27, name = "skill_410311_route2", bone = "", speed = 1},
        --          {type = "audio", time = 0, duration = 2, name = "JN-3101-310111-hit", speed = 0.7, volume = 1, bloop = false},
        --      },
        --  },
        ["9410301"] = {        --  巨手战士二技能
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_410321_hit", bone = "", speed = 1},
            },
        },
    -- 4104 奥赫布
        ["9410401"] = {        --  奥赫布普攻
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_410401_hit", bone = "", speed = 1},
            },
        },
    -- 4201 维尔加
        ["9420101"] = {           --   影舞
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_420101_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-3202-320201-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9420111"] = {           --   暗影处决
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_420111_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-4201-420111-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9420131"] = {           --   招架
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_420131_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-1101-110101-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 4202 莫妮卡
        ["9420201"] = {           --   弩箭子弹受击特效（弩箭-暗影）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_420201_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-3201-10001-3", speed = 0.5, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9420211"] = {           --   “魔灵之箭”子弹受击特效（暗影）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_420201_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-3201-10001-3", speed = 0.5, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9420231"] = {           --  “魔魂箭”子弹特效击中溅射受击特效（暗影系）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_420231_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-3201-10001-3", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9420241"] = {           --  “影狼”撕咬受击特效（暗影系）
            ["hit"] = {         
                {type = "effect", time = 0, duration = 1, name = "skill_123001_hit", bone = "", speed = 1},
            },
        },
    -- 4203 门托
        ["9420301"] = {           --   弩箭子弹受击特效（弩箭-暗影）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_420201_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-3201-10001-3", speed = 0.5, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },    
        ["9420321"] = {        --  激光受击特效（暗影系）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_420321_hit", bone = "", speed = 1},
            },
        },
    -- 4204 萨卡森
        ["9420401"] = {        
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_420401_hit", bone = "", speed = 1},
            },
        },
        ["9420411"] = {        
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_420411_hit", bone = "", speed = 1},
            },
        },
    -- 4205 施佩林
            ["9420501"] = {        
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_420501_hit", bone = "", speed = 1},
            },
        },
    -- 4301 班恩
        ["9430101"] = {           --   邪术子弹受击特效        
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_430101_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-4301-430101-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9430131"] = {           --   虚弱印记受击特效
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_430131_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-4301-430131-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

            },
        },
        ["9430141"] = {           --   暗影鸦雀受击特效
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_430141_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-4301-430141-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9430151"] = {           --   班恩专武爆炸受击特效
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_430151_hit", bone = "", speed = 1},
                {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;1;0;0.1;3"},
            },
        },
    -- 4302 保卢斯
        ["9430201"] = {           --  长矛、盾牌普攻攻击受击特效（暗影）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_430201_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-4302-430201-1-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9430231"] = {           --  盾牌攻击受击特效（暗影）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_430202_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-4302-430201-2-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["415"] = {           --  “恶灵吞噬”全屏幕漂浮持续特效受击特效
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_430211_hit", bone = "", speed = 1},
            },
        },
        ["417"] = {           --  保卢斯长武器攻击受击特效（暗影）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_430221_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-4302-430221-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["418"] = {           --  盾牌气浪受击特效（暗影系）
            ["hit"] = {
                {type = "effect", time = 0, duration = 2, name = "skill_430231_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-4302-430231-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 4303 茨维娅
        ["9430301"] = {        --  茨维娅大招受击特效（暗影系）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_430301_hit", bone = "", speed = 1},
            },
        },
        ["9430311"] = {        --  茨维娅大招受击特效（暗影系）
            ["hit"] = {
                {type = "effect", time = 0, duration = 2, name = "skill_430311_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 2, name = "JN-4303-430311-hit", speed = 1, volume = 0.5, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

            },
        },
        ["9430321"] = {        --   茨维娅骨牢震屏
            ["hit"] = {
                {type = "camera", time = 0.4, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.3;0;0.1;3" },

            },
        },
        ["9430331"] = {        --  灵魂吸取受击特效（暗影系）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_430331_route2", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 2, name = "JN-4303-430331-buff", speed = 0.7, volume = 1, bloop = false},

            },
        },
        ["9430332"] = {        --  灵魂吸取受击特效（暗影系）
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_430331_route2", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 2, name = "JN-4303-430331-hit", speed = 0.7, volume = 1, bloop = false},

            },
        },

    --


--  受击特效（5-众神）
    -- 5201 艾法拉
        ["9520101"] = {           --   艾法拉受击特效        
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_520101_hit", bone = "", speed = 1},
                --  {type = "audio", time = 0, duration = 1, name = "JN-4301-430101-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9520121"] = {           --   艾法拉受击特效        
            ["hit"] = {
                 {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.5;0;0.1;3"},
                 {type = "effect", time = 0, duration = 1, name = "skill_520101_hit", bone = "", speed = 1},
            },
        },
        --
    -- 5202 梵雅娜
        ["9520201"] = {
            ["hit"] = {
                {type = "effect", time = 0, duration = 2, name = "skill_520101_hit", bone = "", speed = 1},
                --  {type = "audio", time = 0, duration = 1, name = "JN-1101-110111-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9520221"] = {   
            ["hit"] = {
                 {type = "camera", time = 0, duration = 0.3, name = "shake", tag = ACTIVE_TAG.CAMP1, params = "0;0.5;0;0.1;3"},
                 {type = "effect", time = 0, duration = 1.5, name = "skill_520221_hit", bone = "", speed = 1},

            },
        },
        ["9520241"] = {   
            ["hit"] = {
                {type = "effect", time = 0, duration = 1.5, name = "buff_110331", bone = "", speed = 1},
                --  {type = "audio", time = 0, duration = 1, name = "JN-1101-110111-2", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},

            },
        },
        --
    
--  受击特效（6-恶魔）
    -- 6101 墨索斯
        ["9610101"] = {           --   墨索斯邪恶利刃受击特效        
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_610101_hit", bone = "", speed = 1},
                --  {type = "audio", time = 0, duration = 1, name = "JN-4301-430101-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9610201"] = {           --   墨索斯邪恶利刃受击特效        
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_610102_hit", bone = "", speed = 1},
                --  {type = "audio", time = 0, duration = 1, name = "JN-4301-430101-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9610111"] = {           --   墨索斯虚境黑洞受击特效        
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_610111_hit", bone = "", speed = 1},
                --  {type = "audio", time = 0, duration = 1, name = "JN-4301-430101-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 6102 小怪囚徒
        ["9610201"] = {              
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_620101_hit", bone = "", speed = 1},
                --  {type = "audio", time = 0, duration = 1, name = "JN-4301-430101-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 6201 小怪囚徒
        ["9620101"] = {           --   墨索斯邪恶利刃受击特效        
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_620101_hit", bone = "", speed = 1},
                --  {type = "audio", time = 0, duration = 1, name = "JN-4301-430101-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 6301 拉欢娜
        ["9630101"] = {
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_630101_hit", bone = "", speed = 1},
                --  {type = "audio", time = 0, duration = 1, name = "JN-4301-430101-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9630131"] = {      
            ["hit"] = {
                {type = "effect", time = 0, duration = 2.0, name = "skill_630131_hit", bone = "", speed = 1},
                {type = "audio", time = 0, duration = 1, name = "JN-6301-630131-hit", speed = 1, volume = 1, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
    -- 6302 费尔察克
        ["9630201"] = {
            ["hit"] = {
                {type = "effect", time = 0, duration = 1, name = "skill_630201_hit", bone = "", speed = 1},
                --  {type = "audio", time = 0, duration = 1, name = "JN-4301-430101-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9630221"] = {
            ["hit"] = {
                {type = "effect", time = 0, duration = 2, name = "skill_630201_hit", bone = "", speed = 1},
                --  {type = "audio", time = 0, duration = 1, name = "JN-4301-430101-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
        ["9630231"] = {
            ["hit"] = {
                {type = "effect", time = 0, duration = 3, name = "bullet_630231", bone = "", speed = 1},
                --  {type = "audio", time = 0, duration = 1, name = "JN-4301-430101-hit", speed = 1, volume = 0.3, bloop = false, tag = ACTIVE_TAG.CAMP1 & ACTIVE_TAG.NOHANGUP},
            },
        },
--  Boss受击部分
    ["701"] = {        --  雷神巨像通用受击
        ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_738101_hit", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1.2, name = "JN-LS-10001-1", speed = 1, volume = 0.5, bloop = false},
        },
    },
    ["702"] = {        --  红龙普攻喷火受击特效
        ["hit"] = {
            --  {type = "effect", time = 0, duration = 3, name = "skill_738201_hit", bone = "", speed = 1},
            --  {type = "audio", time = 0, duration = 1.2, name = "Boss-7382-738201-hit", speed = 1, volume = 1, bloop = false},
        },
    },
    ["703"] = {        --  红龙大炎爆术火球受击特效
        ["hit"] = {
            {type = "effect", time = 0, duration = 2, name = "skill_738221_hit", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 2, name = "Boss-7382-738221-hit", speed = 0.8, volume = 1, bloop = false,is_coexist = true},
            {type = "camera", time = 0, duration = 0.6, name = "shake", params = "0;0.3;0;0.1;6"},

        },
    },
    ["704"] = {        --  魔化沙虫通用受击特效
        ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_718101_hit", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1.2, name = "JN-LS-10001-2", speed = 1, volume = 1, bloop = false},
        },
    },
    ["705"] = {        --  元诅蛇蜥普通攻击受击特效
        ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_738301_hit", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 2, name = "JN-7383-738301-hit", speed = 1, volume = 1, bloop = false},
        },
    },
    ["706"] = {        --  元诅蛇蜥死亡轰炸受击特效
        ["hit"] = {
            {type = "audio", time = 0, duration = 2, name = "JN-7383-738301-hit", speed = 1, volume = 1, bloop = false},
            {type = "camera", time = 0, duration = 0.3, name = "shake", params = "0;0.3;0;0.1;3"},
            {type = "effect", time = 0, duration = 2, name = "skill_738321_hit", bone = "", speed = 1},
        },
    },
    ["707"] = {        --  冰霜巨人普攻受击特效
        ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_718201_hit", bone = "", speed = 1},
        {type = "audio", time = 0, duration = 1.2, name = "JN-LS-10001-2", speed = 1, volume = 1, bloop = false},
        },  
    },
    ["708"] = {        --  冰霜巨人山崩地裂受击特效
        ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_718221_hit", bone = "", speed = 1},
            {type = "audio", time = 0, duration = 1.2, name = "JN-7182-718321", speed = 1, volume = 1, bloop = false},
            {type = "camera", time = 0, duration = 0.3, name = "shake", params = "0;0.3;0;0.1;6"},

        },
    },
    ["9738501"] = {     --  地精BOSS普攻受击
        ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_738501_hit", bone = "", speed = 1},
            -- {type = "audio", time = 0, duration = 1.2, name = "JN-LS-10001-2", speed = 1, volume = 1, bloop = false},
        },
    },
    ["9738511"] = {     --  地精BOSS大招受击
        ["hit"] = {
        {type = "effect", time = 0, duration = 1, name = "skill_738511_hit", bone = "", speed = 1},
        -- {type = "audio", time = 0, duration = 1.2, name = "JN-LS-10001-2", speed = 1, volume = 1, bloop = false},
        },
    },
    ["9718301"] = {     --  泰坦普攻受击
        ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_718301_hit", bone = "", speed = 1},
        -- {type = "audio", time = 0, duration = 1.2, name = "JN-LS-10001-2", speed = 1, volume = 1, bloop = false},
        },
    },
    ["9718311"] = {     --  泰坦大招受击
        ["hit"] = {
        {type = "audio", time = 0, duration = 1.2, name = "JN-2301-230111-hit", speed = 1, volume = 0.5, bloop = false},
        {type = "camera", time = 0, duration = 0.3, name = "shake", params = "0;0.3;0;0.1;3"},
        {type = "effect", time = 0, duration = 5, name = "skill_718311_hit", bone = "", speed = 1, is_coexist=true},


        },
    },
    ["9738601"] = {     --  虚空领主普通攻击
        ["hit"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_738601_hit", bone = "", speed = 1},
        -- {type = "audio", time = 0, duration = 1.2, name = "JN-LS-10001-2", speed = 1, volume = 1, bloop = false},
        },
    },
    ["9738621"] = {     --  虚空领主闪电
        ["hit"] = {
            {type = "effect", time = 0, duration = 2, name = "bullet_738622", bone = "", speed = 1},
            {type = "camera", time = 0.6, duration = 0.3, name = "shake", params = "0;1;0;0.1;3"},
        -- {type = "audio", time = 0, duration = 1.2, name = "JN-LS-10001-2", speed = 1, volume = 1, bloop = false},
        },
    },
--  Buff类表现
    ["220141"] = {
        ["hit"] = {
            {type = "effect", time = 0, duration = 3, name = "skill_220141_route1_m", bone = "", speed = 1},
        },
    },

--  子弹拖尾部分
    ["bullet_120101_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_120101_tail", bone = "", speed = 1},
        },
    },
    ["bullet_120111_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_120111_tail", bone = "", speed = 1},
        },
    },
    ["bullet_120201_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_120201_tail", bone = "", speed = 1},
        },
    },
    ["bullet_120211_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_120211_tail", bone = "", speed = 1},
        },
    },
    ["bullet_120221_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_120221_tail", bone = "", speed = 1},
        },
    },
    ["bullet_120241_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_120241_tail", bone = "", speed = 1},
        },
    },
    ["bullet_120401_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 1, name = "bullet_120401_tail", bone = "", speed = 1},
        },
    },
    ["bullet_120411_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 1, name = "bullet_120411_tail", bone = "", speed = 1},
        },
    },
    ["bullet_120421_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 1, name = "bullet_120421_tail", bone = "", speed = 1},
        },
    },
    ["bullet_120431_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_120431_tail", bone = "", speed = 1},
        },
    },
    ["bullet_130101_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 1, name = "bullet_130101_tail", bone = "", speed = 1},
        },
    },
    ["bullet_130201_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_130201_tail", bone = "", speed = 1},
        },
    },
    ["bullet_130211_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_130211_tail", bone = "", speed = 1},
        },
    },
    ["bullet_130212_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_130212_tail", bone = "", speed = 1},
        },
    },
    ["bullet_130231_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_130231_tail", bone = "", speed = 1},
        },
    },
    ["bullet_130251_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_130251_tail", bone = "", speed = 1},
        },
    },
    ["bullet_130321_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 1, name = "bullet_130321_tail", bone = "", speed = 1},
        },
    },
    ["bullet_130521_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_130521_tail", bone = "", speed = 1},
        },
    },
    ["bullet_130522_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_130522_tail", bone = "", speed = 1},
        },
    },
    ["bullet_130523_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_130523_tail", bone = "", speed = 1},
        },
    },
    ["bullet_130531_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_130531_tail", bone = "", speed = 1},
        },
    },
    ["bullet_210211_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_210211_tail", bone = "", speed = 1},
        },
    },
    ["bullet_220301_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 0.2, name = "bullet_220301_tail", bone = "", speed = 1},
        },
    },
    ["bullet_220302_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 1, name = "bullet_220302_tail", bone = "", speed = 1},
        },
    },
    ["bullet_220421_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 5, name = "bullet_220421_tail", bone = "", speed = 1},
        },
    },
    ["bullet_220422_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 5, name = "bullet_220422_tail", bone = "", speed = 1},
        },
    },
    ["bullet_230221_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 1, name = "bullet_230221_tail", bone = "", speed = 1},
        },
    },
    ["bullet_320101_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 0.2, name = "bullet_320101_tail", bone = "", speed = 1},
        },
    },
    ["bullet_320102_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_320102_tail", bone = "", speed = 1},
        },
    },
    ["bullet_320103_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_320103_tail", bone = "", speed = 1},
        },
    },
    ["bullet_320104_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_320104_tail", bone = "", speed = 1},
        },
    },
    ["bullet_330101_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_330101_tail", bone = "", speed = 1},
        },
    },
    ["bullet_330301_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_330301_tail", bone = "", speed = 1},
        },
    },
    ["bullet_330401_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_330401_tail", bone = "", speed = 1},
        },
    },
    ["bullet_330501_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_330501_tail", bone = "", speed = 1},
        },
    },
    ["bullet_330521_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_330521_tail", bone = "", speed = 1},
        },
    },
    ["bullet_330522_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_330522_tail", bone = "", speed = 1},
        },
    },
    ["bullet_330523_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_330523_tail", bone = "", speed = 1},
        },
    },
    ["bullet_410331_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_410331_tail", bone = "", speed = 1},
        },
    },
    ["skill_420411_route2_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_420411_route2_tail", bone = "", speed = 1},
        },
    },
    ["bullet_430331_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_430331_route3", bone = "", speed = 1},
        },
    },
    ["bullet_123004_route2_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 3, name = "bullet_123004_route2_tail", bone = "", speed = 1},
        },
    },
    ["bullet_520241_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 1, name = "bullet_520241_tail", bone = "", speed = 1},
        },
    },
    ["skill_738611_route2_tail"] = {
        ["tail"] = {
            {type = "effect", time = 0, duration = 1, name = "skill_738611_route2_tail", bone = "", speed = 1},
        },
    },
    ["UI_1111031"] = {
        ["idle01"] = {
            {type = "spine", time = 0, duration = 3, name = "idle01", isLoop = true, layer = 0, speed = 1},
        },
        ["idle02"] = {
            {type = "spine", time = 0, duration = 3, name = "idle02", isLoop = true, layer = 0, speed = 1},
        }
    },

    ["UI_1113011"] = {
        ["idle01"] = {
            {type = "spine", time = 0, duration = 3, name = "idle01", isLoop = true, layer = 0, speed = 1},
        },
        ["idle02"] = {
            {type = "spine", time = 0, duration = 3, name = "idle02", isLoop = true, layer = 0, speed = 1},
        }
    },    

    ["UI_BattleSettlement_win1"] = {
        ["idle"] = {
            {type = "spine", time = 0, duration = 3, name = "idle", isLoop = false, layer = 0, speed = 1},
        },
        ["idle01"] = {
            {type = "spine", time = 0, duration = 3, name = "idle01", isLoop = true, layer = 0, speed = 1},
        }
    }, 

    ["UI_BattleSettlement_lose1"] = {
        ["idle"] = {
            {type = "spine", time = 0, duration = 3, name = "idle", isLoop = false, layer = 0, speed = 1},
        },
        ["idle01"] = {
            {type = "spine", time = 0, duration = 3, name = "idle01", isLoop = true, layer = 0, speed = 1},
        }
    },

--  科多兽马车
    ["cart"] = {
        ["stand"] = {
            {type = "anim", time = 0, duration = 1, name = "Stand", speed = 1},
        },
        ["run"] = {
            {type = "anim", time = 0, duration = 0.6, name = "Run", speed = 1},
        },
    },

    ["nuche"] = {
        ["stand"] = {
            {type = "anim", time = 0, duration = 0.667, name = "nuche_daiji01", speed = 1},
        },
        ["stand2"] = {
            {type = "anim", time = 0, duration = 0.367, name = "nuche_daiji02", speed = 1},
        },
        ["attack"] = {
            {type = "anim", time = 0, duration = 1.5, name = "nuche_gongji", speed = 1},
        },
    },

    ["UI_1113031_push"] = {
        ["animation"] = {
            {type = "spine", time = 0, duration = 5.3, name = "idle", isLoop = true, layer = 0, speed = 1},
        },
    }, 
--UI部分
    ["UI_MallConfirm3_3"] = {
        ["Born"] = {
            {type = "spine", time = 0, duration = 2, name = "Born", isLoop = false, layer = 0, speed = 1},
            {type = "spine", time = 2, duration = 3, name = "idle", isLoop = true, layer = 0, speed = 1},
        },
    },
    ["UI_MallConfirm3_2"] = {
        ["Born"] = {
            {type = "spine", time = 0, duration = 2, name = "Born", isLoop = false, layer = 0, speed = 1},
            {type = "spine", time = 2, duration = 3, name = "idle", isLoop = true, layer = 0, speed = 1},
        },
    },
    ["UI_MallConfirm3_1"] = {
        ["Born"] = {
            {type = "spine", time = 0, duration = 2, name = "Born", isLoop = false, layer = 0, speed = 1},
            {type = "spine", time = 2, duration = 3, name = "ilde", isLoop = true, layer = 0, speed = 1},
        },
    },
    ["UI_Chaos_story"] = {
        ["Born"] = {
            {type = "spine", time = 0, duration = 2.8, name = "Born", isLoop = false, layer = 0, speed = 1},
            {type = "spine", time = 2.8, duration = 4, name = "idle", isLoop = true, layer = 0, speed = 1},
        },
    },
    ["rongyandimian"] = {
        ["LavaGround1"] = {
            {type = "shader", time = 0, duration = 0.75 ,name = "LavaGround1"},
        },
        ["LavaGround2"] = {
            {type = "shader", time = 0, duration = 0.75, name = "LavaGround2"},
        },
    },
    ["LavaPillar_02"] = {
        ["Death_Build"] = {
            {type = "shader", time = 0, duration = 3, name = "Death_Build"},
        },
        ["Born_Build"] = {
            {type = "shader", time = 0, duration = 3, name = "Born_Build"},
        },
    },
})
