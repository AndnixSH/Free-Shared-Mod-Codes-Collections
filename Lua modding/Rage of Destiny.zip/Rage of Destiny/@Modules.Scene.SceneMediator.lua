local SceneMediator = SceneMediator or BaseClass(StdMediator)

function SceneMediator:OnLuaNotify(data, strEvent, args, strContext)
end

return SceneMediator