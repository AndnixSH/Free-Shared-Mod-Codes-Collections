local ArenaMediator = ArenaMediator or BaseClass(StdMediator)
local AudioManager = require "Common.Mgr.Audio.AudioManager"
function ArenaMediator:OnEnterScenceInit()
    
end

function ArenaMediator:OnEnterScenceStart()	
end

function ArenaMediator:OnEnterScenceFirst()

   
    self:DelayExecute(function()
        local ArenaProxy = require "Modules.Arena.ArenaProxy"
	    ArenaProxy.Instance:Send55000()
	end)
end

function ArenaMediator:OnEnterScenceEnd()
end

function ArenaMediator:OnEnterLoadingEnd()

    local SceneManager = require "Modules.Scene.SceneManager"
    local SceneDef = require "Modules.Scene.SceneDef"
    if SceneManager.Instance:GetCurSceneType() == SceneDef.SceneType.ArenaBattle or SceneManager.Instance:GetCurSceneType() == SceneDef.SceneType.HighArenaBattle then
        AudioManager.PlayBGM("battle_arena_bg")
    end
end
return ArenaMediator