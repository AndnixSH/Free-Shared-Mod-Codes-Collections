local propmt = {    

    __newindex = function (self, k, v)
        self._prop[k] = v
        if not self._setter[k] then
            local setter_name = "_prop_"..k
            self._setter[k] = self._context[setter_name]
            if not self._setter[k] then
                print(string.format("找不到回调方法格式为_prop_%s", k))
            end
        end

        if self._brefresh and self._setter then
            self._setter[k](self._context, v)
        end
    end,
}

local prop_refresher = {}

function prop_refresher.new(context)
    local prop = { _prop = {}, _brefresh = false, _context = context, _setter = {} }
    return setmetatable(prop, propmt)
end

function prop_refresher.refresh(prop)
    for k, v in pairs(prop._prop) do
        if prop._setter[k] then
            prop._setter[k](prop._context, v)
        end
    end
    prop._brefresh = true
end

return prop_refresher