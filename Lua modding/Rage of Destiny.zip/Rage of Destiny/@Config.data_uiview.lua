ConfigManager.InitConfig("data_uiview", {
	--classpath 代码路径; parentname 父节点; panelname 挂点; showtype 打开类型; prefabpath 资源路径(暂不用);level 等级打开; bnotautoclose 是否允许自动关闭 ,bautodepth 自动设置层级

	--login
	[UIWidgetNameDef.LoginView] = { widgetpath = "Modules.Login.LoginView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.AnnouncementView] = { widgetpath = "Modules.Login.AnnouncementView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.LoginNoticeView] = { widgetpath = "Modules.Login.LoginNoticeView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.MaintenanceView] = { widgetpath = "Modules.Login.MaintenanceView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	
	--cheat
	[UIWidgetNameDef.CheatView] = { widgetpath = "Modules.Cheat.CheatView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.CheatCameraAdjustView] = { widgetpath = "Modules.Cheat.CheatCameraAdjustView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.CheatGMBtnView] = { widgetpath = "Modules.Cheat.CheatGMBtnView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	--loading
	[UIWidgetNameDef.LoadingView] = { widgetpath = "Modules.Loading.LoadingView", parentname = UIWidgetNameDef.Root_liveAllway, panelname = UIWidgetNameDef.LiveAllwayPanel, showtype = LayoutShowType.CoexistClose, bautodepth = false},
	[UIWidgetNameDef.LoadingCommonView] = { widgetpath = "Modules.Loading.LoadingCommonView", parentname = UIWidgetNameDef.Root_liveAllway, panelname = UIWidgetNameDef.LiveAllwayPanel, showtype = LayoutShowType.CoexistClose, bautodepth = false},
	[UIWidgetNameDef.NetworkDelayView] = { widgetpath = "Modules.Loading.NetworkDelayView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose, bautodepth = false},
	[UIWidgetNameDef.ReconnectView] = { widgetpath = "Modules.Loading.ReconnectView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose, bautodepth = false},
	[UIWidgetNameDef.BlackLoadingView] = { widgetpath = "Modules.Loading.BlackLoadingView", parentname = UIWidgetNameDef.Root_liveAllway, panelname = UIWidgetNameDef.LiveAllwayPanel, showtype = LayoutShowType.CoexistClose, bautodepth = false},
	
	--common
	[UIWidgetNameDef.MsgTipsView] = { widgetpath = "Modules.Common.Msg.MsgTipsView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ContentTipsView] = { widgetpath = "Modules.Common.Msg.ContentTipsView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose,bautodepth = false},
	[UIWidgetNameDef.ContentPageTipsView] = { widgetpath = "Modules.Common.Msg.ContentPageTipsView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose,bautodepth = false},
	[UIWidgetNameDef.LabelTipsView] = { widgetpath = "Modules.Common.Msg.LabelTipsView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GetItemView] = { widgetpath = "Modules.Common.GetItem.GetItemView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ItemDropView] = { widgetpath = "Modules.Common.GetItem.ItemDropView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.FullScreenView] = { widgetpath = "Modules.Common.FullScreen.FullScreenView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose, bautodepth = false, destroytype = LayoutDestroyType.Close},
	[UIWidgetNameDef.CostConfirmView] = { widgetpath = "Modules.Common.Msg.CostConfirmView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose, bautodepth = false},
	[UIWidgetNameDef.ItemTipsView] = { widgetpath = "Modules.Common.Msg.ItemTipsView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ItemEquipTipsView] = { widgetpath = "Modules.Common.Msg.ItemEquipTipsView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ItemBoxTipsView] = { widgetpath = "Modules.Common.Msg.ItemBoxTipsView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.ItemLableView] = { widgetpath = "Modules.Common.Msg.ItemLableView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.HeroTipsView] = { widgetpath = "Modules.Common.Msg.HeroTipsView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.FastshopView] = { widgetpath = "Modules.Common.Msg.FastshopView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ConfirmTipsView] = { widgetpath = "Modules.Common.Msg.ConfirmTipsView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.NewConfirmView] = { widgetpath = "Modules.Common.Msg.NewConfirmView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose,bnotautoclose = true, bautodepth = false},
	[UIWidgetNameDef.BlockView] = { widgetpath = "Modules.Common.BlockView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.UniWebView] = { widgetpath = "Modules.Common.Msg.UniWebView", parentname = UIWidgetNameDef.Root_IGG, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose,bautodepth = false},
	--main
	[UIWidgetNameDef.MainView] = { widgetpath = "Modules.Main.MainView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose, destroytype = LayoutDestroyType.Close},
	[UIWidgetNameDef.CampaignView] = { widgetpath = "Modules.Campaign.CampaignView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose, destroytype = LayoutDestroyType.Close},
	
	--battle
	[UIWidgetNameDef.BattleView] = { widgetpath = "Modules.Battle.BattleView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.BattleRecordView] = { widgetpath = "Modules.Battle.BattleRecordView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.BattleRecordListView] = { widgetpath = "Modules.Battle.BattleRecordListView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.BattleSelectView] = { widgetpath = "Modules.Battle.Select.BattleSelectView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose, closetype = LayoutCloseType.Pop },	
	[UIWidgetNameDef.BattleSettlementView] = { widgetpath = "Modules.Battle.BattleSettlementView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.BattleSettlement2View] = { widgetpath = "Modules.Battle.BattleSettlement2View", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.BattleRelationView] = { widgetpath = "Modules.Battle.BattleRelationView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.BattleWordView] = { widgetpath = "Modules.Battle.BattleWordView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose, bautodepth = false, destroytype = LayoutDestroyType.Close},
	[UIWidgetNameDef.BattleReadyView] = { widgetpath = "Modules.Battle.Select.BattleReadyView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.BattleNetSelectView] = { widgetpath = "Modules.Battle.Select.BattleNetSelectView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose, closetype = LayoutCloseType.Pop },	
	[UIWidgetNameDef.ArenaBattleSelectView] = { widgetpath = "Modules.Battle.Select.ArenaBattleSelectView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.ArenaBattleSettlementView] = { widgetpath = "Modules.Battle.ArenaBattleSettlementView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.ArenaBattleView] = { widgetpath = "Modules.Battle.ArenaBattleView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ProArenaBattleSelectView] = { widgetpath = "Modules.Battle.Select.ProArenaBattleSelectView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ProArenaBattleSettlementView] = { widgetpath = "Modules.Battle.ProArenaBattleSettlementView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ProArenaBattleView] = { widgetpath = "Modules.Battle.ProArenaBattleView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.BattleStopView] = { widgetpath = "Modules.Battle.BattleStopView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.BattleHeroInfoView] = { widgetpath = "Modules.Battle.BattleHeroInfoView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.BattleGuildBossView] = { widgetpath = "Modules.Battle.BattleGuildBossView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.BattleGuildChaosView] = { widgetpath = "Modules.Battle.BattleGuildChaosView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.BattleTeamChangeView] = { widgetpath = "Modules.Battle.Select.BattleTeamChangeView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
		
	--Campaign
	[UIWidgetNameDef.BossInfoView] = { widgetpath = "Modules.Campaign.BossInfoView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.BoxRewardView] = { widgetpath = "Modules.Campaign.HangUp.BoxRewardView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.FastRewardView] = { widgetpath = "Modules.Campaign.HangUp.FastRewardView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.CampaignProgressView] = { widgetpath = "Modules.Campaign.CampaignProgressView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.WinFormationView] = { widgetpath = "Modules.Campaign.WinFormationView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	

	--hero
	[UIWidgetNameDef.HeroRootView] = { widgetpath = "Modules.Hero.HeroRootView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose, closetype = LayoutCloseType.Pop},
	[UIWidgetNameDef.HeroTeamListView] = { widgetpath = "Modules.Formation.HeroTeamListView", parentname = UIWidgetNameDef.HeroRootView, panelname = UIWidgetNameDef.HeroRootPanel, showtype = LayoutShowType.CoexistClose, bautodepth = false},
	[UIWidgetNameDef.HeroListView] = { widgetpath = "Modules.Hero.HeroListView", parentname = UIWidgetNameDef.HeroRootView, panelname = UIWidgetNameDef.HeroRootPanel, showtype = LayoutShowType.CoexistClose, bautodepth = false},
	[UIWidgetNameDef.HeroView] = { widgetpath = "Modules.Hero.HeroView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.HeroAttrView] = { widgetpath = "Modules.Hero.HeroAttrView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.SkillTipsView] = { widgetpath = "Modules.Hero.SkillTipsView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose, bautodepth = false},
	[UIWidgetNameDef.HeroUpgradeView] = { widgetpath = "Modules.Hero.HeroUpgradeView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.UpgradeConfirmView] = { widgetpath = "Modules.Hero.UpgradeConfirmView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.AutoUpgradeView] = { widgetpath = "Modules.Hero.AutoUpgradeView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.FountainView] = { widgetpath = "Modules.Hero.Fountain.FountainView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.RetireConfirmView] = { widgetpath = "Modules.Hero.Fountain.RetireConfirmView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.HeroNewView] = { widgetpath = "Modules.Hero.HeroNewView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ItemQuickUseView] = { widgetpath = "Modules.Hero.ItemQuickUseView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},

	[UIWidgetNameDef.HeroBookListView] = { widgetpath = "Modules.Hero.HeroBookListView", parentname = UIWidgetNameDef.HeroRootView, panelname = UIWidgetNameDef.HeroRootPanel, showtype = LayoutShowType.CoexistClose, bautodepth = false},
	[UIWidgetNameDef.HeroStoryView] = { widgetpath = "Modules.Hero.HeroStoryView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose},
	--bag
	[UIWidgetNameDef.BagRootView] = { widgetpath = "Modules.Bag.BagRootView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.BagItemsellView] = { widgetpath = "Modules.Bag.BagItemsellView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.BagItemConfirmView] = { widgetpath = "Modules.Bag.BagItemConfirmView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.BagItemChoosingConfirmView] = { widgetpath = "Modules.Bag.BagItemChoosingConfirmView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.BagChoiceOneChestView] = { widgetpath = "Modules.Bag.BagChoiceOneChestView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},

	--tower
	[UIWidgetNameDef.TowerEntranceView] = { widgetpath = "Modules.Tower.TowerEntranceView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose, closetype = LayoutCloseType.Pop},
	[UIWidgetNameDef.TowerChallengeView] = { widgetpath = "Modules.Tower.TowerChallengeView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.TowerRankView] = { widgetpath = "Modules.Tower.TowerRankView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	--equip
	[UIWidgetNameDef.EquipmentWearView] = { widgetpath = "Modules.Equip.EquipmentWearView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.EquipmentTipsView] = { widgetpath = "Modules.Equip.EquipmentTipsView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.EquipmentEnhanceView] = { widgetpath = "Modules.Equip.EquipmentEnhanceView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.EquipmentStrengthenView] = { widgetpath = "Modules.Equip.EquipmentStrengthenView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.EquipmentResetView] = { widgetpath = "Modules.Equip.EquipmentResetView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.StrengthenSuccessView] = { widgetpath = "Modules.Equip.StrengthenSuccessView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.EquipmentHintsView] = { widgetpath = "Modules.Equip.EquipmentHintsView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ExclusiveTipsView] = { widgetpath = "Modules.Equip.ExclusiveTipsView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ExclusiveStrengthenView] = { widgetpath = "Modules.Equip.ExclusiveStrengthenView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ExclusiveSuccessView] = { widgetpath = "Modules.Equip.ExclusiveSuccessView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ExclusiveUnlockView] = { widgetpath = "Modules.Equip.ExclusiveUnlockView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	
	[UIWidgetNameDef.ArtifactInfoView] = { widgetpath = "Modules.Equip.ArtifactInfoView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ArtifactStrengthenView] = { widgetpath = "Modules.Equip.ArtifactStrengthenView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ArtifactSuccessView] = { widgetpath = "Modules.Equip.ArtifactSuccessView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ArtifactTipsView] = { widgetpath = "Modules.Equip.ArtifactTipsView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ArtifactWearView] = { widgetpath = "Modules.Equip.ArtifactWearView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	--playerInfo
	[UIWidgetNameDef.HomePageView] = { widgetpath = "Modules.RoleInfo.HomePageView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.PlayerInfoView] = { widgetpath = "Modules.RoleInfo.PlayerInfoView", parentname = UIWidgetNameDef.HomePageView, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose,bautodepth=false},
    [UIWidgetNameDef.CustomizeView] = { widgetpath = "Modules.RoleInfo.CustomizeView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.SexView] = { widgetpath = "Modules.RoleInfo.SexView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ChangeNameView] = { widgetpath = "Modules.RoleInfo.ChangeNameView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.SignatureView] = { widgetpath = "Modules.RoleInfo.SignatureView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.LineUpView] = { widgetpath = "Modules.RoleInfo.LineUpView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.OtherPlayerInfolView] = { widgetpath = "Modules.RoleInfo.OtherPlayerInfolView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.RedeemCodeView] = { widgetpath = "Modules.RoleInfo.RedeemCodeView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.AccountUpgradeView] = { widgetpath = "Modules.RoleInfo.AccountUpgradeView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose,bautodepth=false},
	
	--hexmap
	[UIWidgetNameDef.HexMapView] = { widgetpath = "Modules.HexMap.HexMapView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.HexHeroView] = { widgetpath = "Modules.HexMap.HexHeroView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.HexStrangeAltarView] = { widgetpath = "Modules.HexMap.HexStrangeAltarView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.HeroHireView] = { widgetpath = "Modules.HexMap.HeroHireView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.EnemyInfoView] = { widgetpath = "Modules.HexMap.EnemyInfoView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.HexStoreView] = { widgetpath = "Modules.HexMap.HexStoreView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.HexMapFlyIconTitleView] = { widgetpath = "Modules.HexMap.HexMapFlyIconTitleView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.HexNPCDialogueView] = { widgetpath = "Modules.HexMap.HexNPCDialogueView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.HexNPCLogView] = { widgetpath = "Modules.HexMap.HexNPCLogView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.RuneChooseView] = { widgetpath = "Modules.HexMap.RuneChooseView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.RuneListView] = { widgetpath = "Modules.HexMap.RuneListView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.RuneListChooseView] = { widgetpath = "Modules.HexMap.RuneListChooseView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.StoryLineSuccessView] = { widgetpath = "Modules.HexMap.StoryLineSuccessView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.HexBuildView] = { widgetpath = "Modules.HexMap.HexBuildView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},		
	[UIWidgetNameDef.EnemyBuffView] = { widgetpath = "Modules.HexMap.EnemyBuffView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.HexPortalView] = { widgetpath = "Modules.HexMap.HexPortalView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.MazeStorySuccessView] = { widgetpath = "Modules.HexMap.MazeStorySuccessView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	

	--maze
	[UIWidgetNameDef.MazeView] = { widgetpath = "Modules.Maze.MazeView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	-- [UIWidgetNameDef.MazeHeroSelectView] = { widgetpath = "Modules.Maze.MazeHeroSelectView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.MazeLevelView] = { widgetpath = "Modules.Maze.MazeLevelView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.MazeHeroSelectNewView] = { widgetpath = "Modules.Maze.MazeHeroSelectNewView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.DragonBloodView] = { widgetpath = "Modules.Maze.DragonBloodView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.MazeEnemyInfoView] = { widgetpath = "Modules.Maze.MazeEnemyInfoView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	

	--CrystalView
	[UIWidgetNameDef.CrystalView] = { widgetpath = "Modules.Crystal.CrystalView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.CrystalSelectView] = { widgetpath = "Modules.Crystal.CrystalSelectView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},		
	[UIWidgetNameDef.CrystalRemoveHeroView] = { widgetpath = "Modules.Crystal.CrystalRemoveHeroView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},		
	[UIWidgetNameDef.CrystalUpgradeView] = { widgetpath = "Modules.Crystal.CrystalUpgradeView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},		
	[UIWidgetNameDef.CrystalUpgradeConfirmView] = { widgetpath = "Modules.Crystal.CrystalUpgradeConfirmView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},		
	[UIWidgetNameDef.CrystalAddHeroView] = { widgetpath = "Modules.Crystal.CrystalAddHeroView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},			
	[UIWidgetNameDef.CrystalLevelView] = { widgetpath = "Modules.Crystal.CrystalLevelView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},			
	
	--TempleView
	[UIWidgetNameDef.TempleView] = { widgetpath = "Modules.Temple.TempleView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},		
	[UIWidgetNameDef.AutoAscendView] = { widgetpath = "Modules.Temple.AutoAscendView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},		
	[UIWidgetNameDef.SoulUnfuseConfirmView] = { widgetpath = "Modules.Temple.SoulUnfuseConfirmView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},		
	[UIWidgetNameDef.TempleConfirmView] = { widgetpath = "Modules.Temple.TempleConfirmView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},			
	[UIWidgetNameDef.TempleSuccessView] = { widgetpath = "Modules.Temple.TempleSuccessView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},			

	--CardPortal
	[UIWidgetNameDef.CardPortalView] = { widgetpath = "Modules.CardPortal.CardPortalView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},		
	[UIWidgetNameDef.CardPortalSwitchView] = { widgetpath = "Modules.CardPortal.CardPortalSwitchView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},		
	[UIWidgetNameDef.CardPortalTipsView] = { widgetpath = "Modules.CardPortal.CardPortalTipsView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},		
	[UIWidgetNameDef.CardPortalWishView] = { widgetpath = "Modules.CardPortal.CardPortalWishView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},		
	[UIWidgetNameDef.RaceCardView] = { widgetpath = "Modules.CardPortal.RaceCardView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},		
	[UIWidgetNameDef.RefreshWhiteView] = { widgetpath = "Modules.CardPortal.RefreshWhiteView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},		
	[UIWidgetNameDef.CardPortalSkipView] = { widgetpath = "Modules.CardPortal.CardPortalSkipView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.CardStarView] = { widgetpath = "Modules.CardPortal.CardStarView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.CardStarChooseView] = { widgetpath = "Modules.CardPortal.CardStarChooseView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.CardStarSetView] = { widgetpath = "Modules.CardPortal.CardStarSetView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.CardStarTipsView] = { widgetpath = "Modules.CardPortal.CardStarTipsView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
   
	--MailView
	[UIWidgetNameDef.MailView] = { widgetpath = "Modules.Mail.MailView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.MailDetailView] = { widgetpath = "Modules.Mail.MailDetailView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},


	--Store
	[UIWidgetNameDef.StoreView] = { widgetpath = "Modules.Store.StoreView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.StoreHintsView] = { widgetpath = "Modules.Store.StoreHintsView", parentname = UIWidgetNameDef.StoreView, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.StoreGoodsHeroHintsView] = { widgetpath = "Modules.Store.StoreHintsView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
		
	--StoryLine
	[UIWidgetNameDef.StoryLineView] = { widgetpath = "Modules.StoryLine.StoryLineView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.StoryLineRootView] = { widgetpath = "Modules.StoryLine.StoryLineRootView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.StoreLineHintsView] = { widgetpath = "Modules.StoryLine.StoreLineHintsView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.StoryLineMenuView] = { widgetpath = "Modules.StoryLine.StoryLineMenuView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.StoreLineConditionView] = { widgetpath = "Modules.StoryLine.StoreLineConditionView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	
	

	--world
	[UIWidgetNameDef.WorldMapRootView] = { widgetpath = "Modules.WorldMap.WorldMapRootView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.ChapterDecView] = { widgetpath = "Modules.WorldMap.ChapterDecView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.WorldMapRootView, showtype = LayoutShowType.CoexistClose},
	--task
	[UIWidgetNameDef.MainTaskView] = { widgetpath = "Modules.Task.MainTaskView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.TaskStageRewardView] = { widgetpath = "Modules.Task.TaskStageRewardView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	

	--npc
	[UIWidgetNameDef.NPCDialogueView] = { widgetpath = "Modules.NPCDialogue.NPCDialogueView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.NPCLogView] = { widgetpath = "Modules.NPCDialogue.NPCLogView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},

	--territory
	[UIWidgetNameDef.TerritoryView] = { widgetpath = "Modules.Territory.TerritoryView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose,bautodepth=false},
	[UIWidgetNameDef.FieldView] = { widgetpath = "Modules.Territory.FieldView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose,bautodepth=false},
	
	--arena
	[UIWidgetNameDef.ArenaEntranceView] = { widgetpath = "Modules.Arena.ArenaEntranceView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose, closetype = LayoutCloseType.Pop},
	[UIWidgetNameDef.ArenaView] = { widgetpath = "Modules.Arena.ArenaView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose, closetype = LayoutCloseType.Pop},
	[UIWidgetNameDef.ArenaRewardView] = { widgetpath = "Modules.Arena.ArenaRewardView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ArenaRecordView] = { widgetpath = "Modules.Arena.ArenaRecordView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ArenaChallengeView] = { widgetpath = "Modules.Arena.ArenaChallengeView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ProArenaView] = { widgetpath = "Modules.Arena.ProArenaView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ProArenaRecordView] = { widgetpath = "Modules.Arena.ProArenaRecordView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ProArenaChallengeView] = { widgetpath = "Modules.Arena.ProArenaChallengeView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ProArenaDefendTeamView] = { widgetpath = "Modules.Arena.ProArenaDefendTeamView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ProArenaTeamChangeView] = { widgetpath = "Modules.Arena.ProArenaTeamChangeView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ProArenaBattleRecordView] = { widgetpath = "Modules.Arena.ProArenaBattleRecordView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},

	[UIWidgetNameDef.FriendlListView] = { widgetpath = "Modules.Friend.FriendlListView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.FriendRootView] = { widgetpath = "Modules.Friend.FriendRootView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.AddfriendView] = { widgetpath = "Modules.Friend.AddfriendView", parentname = UIWidgetNameDef.FriendRootView, panelname = UIWidgetNameDef.FriendRootPanel, showtype = LayoutShowType.CoexistClose, bautodepth = false},
	[UIWidgetNameDef.ApplyfriendView] = { widgetpath = "Modules.Friend.ApplyfriendView", parentname = UIWidgetNameDef.FriendRootView, panelname = UIWidgetNameDef.FriendRootPanel, showtype = LayoutShowType.CoexistClose,bautodepth = false},
	[UIWidgetNameDef.BlacklistView] = { widgetpath = "Modules.Friend.BlacklistView", parentname = UIWidgetNameDef.FriendRootView, panelname = UIWidgetNameDef.FriendRootPanel, showtype = LayoutShowType.CoexistClose,bautodepth = false},

	--newbie
	[UIWidgetNameDef.NewbieDialogView] = { widgetpath = "Modules.Newbie.NewbieDialogView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose, bautodepth = false},
	[UIWidgetNameDef.NewbieWeakGuildView] = { widgetpath = "Modules.Newbie.NewbieWeakGuildView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose, bautodepth = false},
	[UIWidgetNameDef.NewbieFingerView] = { widgetpath = "Modules.Newbie.NewbieFingerView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose, bautodepth = false},
	[UIWidgetNameDef.NewbieSignalView] = { widgetpath = "Modules.Newbie.NewbieSignalView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.NewbieNpcDialogueView] = { widgetpath = "Modules.Newbie.NewbieNpcDialogueView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose, bautodepth = false},	
	[UIWidgetNameDef.NewbieCertificateView] = { widgetpath = "Modules.Newbie.NewbieCertificateView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},	
	[UIWidgetNameDef.NewbieNormalNpcDialogView] = { widgetpath = "Modules.Newbie.NewbieNormalNpcDialogView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose, bautodepth = false},
	[UIWidgetNameDef.NewbieSpecialWeakView] = { widgetpath = "Modules.Newbie.NewbieSpecialWeakView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.NewbieDramaView] = { widgetpath = "Modules.Newbie.NewbieDramaView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.NewMaskView] = { widgetpath = "Modules.Newbie.NewMaskView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose, closetype = LayoutCloseType.Pop, bautodepth = false},

	--chat
	[UIWidgetNameDef.ChatRootView] = { widgetpath = "Modules.Chat.ChatRootView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ChatView] = { widgetpath = "Modules.Chat.ChatView", parentname = UIWidgetNameDef.ChatRootView, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose, bautodepth = false},
	[UIWidgetNameDef.PindaoRootView] = { widgetpath = "Modules.Chat.PindaoRootView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ReportView] = { widgetpath = "Modules.Chat.ReportView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},


	[UIWidgetNameDef.RelationView] = { widgetpath = "Modules.Relation.RelationView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.MyAidView] = { widgetpath = "Modules.Relation.MyAidView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.RelationMenuRootView] = { widgetpath = "Modules.Relation.RelationMenuRootView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.RelationMenuView] = { widgetpath = "Modules.Relation.RelationMenuView", parentname = UIWidgetNameDef.RelationMenuRootView, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose, bautodepth = false},
	[UIWidgetNameDef.RelationHeroView] = { widgetpath = "Modules.Relation.RelationHeroView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.RelationforeverView] = { widgetpath = "Modules.Relation.RelationforeverView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},


	--tree
	[UIWidgetNameDef.RelationTreeView] = {widgetpath = "Modules.Tree.RelationTreeView", parentname = UIWidgetNameDef.RelationMenuRootView, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose, bautodepth = false},
	[UIWidgetNameDef.WaterReceiveView] = {widgetpath = "Modules.Tree.WaterReceiveView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},

	--GuildBoss
	[UIWidgetNameDef.GuildBossChallengeRewardView] = { widgetpath = "Modules.Guild.GuildBossChallengeRewardView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildBossRankView] = { widgetpath = "Modules.Guild.GuildBossRankView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildBossResultView] = { widgetpath = "Modules.Guild.GuildBossResultView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildBossRewardView] = { widgetpath = "Modules.Guild.GuildBossRewardView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildBossView] = { widgetpath = "Modules.Guild.GuildBossView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildBossBattleSettlementView] = { widgetpath = "Modules.Battle.GuildBossBattleSettlementView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},

	--GuildChaos
	[UIWidgetNameDef.GuildChaosNextView] = { widgetpath = "Modules.Guild.GuildChaosNextView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildChaosRecordView] = { widgetpath = "Modules.Guild.GuildChaosRecordView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildChaosStoryView] = { widgetpath = "Modules.Guild.GuildChaosStoryView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildChaosView] = { widgetpath = "Modules.Guild.GuildChaosView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildChaosBattleSettlementView] = { widgetpath = "Modules.Battle.GuildChaosBattleSettlementView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildChaosTopView] = { widgetpath = "Modules.Guild.GuildChaosTopView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildChaosRankView] = { widgetpath = "Modules.Guild.GuildChaosRankView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildChaosBehindView] = { widgetpath = "Modules.Guild.GuildChaosBehindView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},

	--Guild
	[UIWidgetNameDef.GuildRootView] = { widgetpath = "Modules.Guild.GuildRootView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ApplyGuildView] = { widgetpath = "Modules.Guild.ApplyGuildView", parentname = UIWidgetNameDef.GuildRootView, panelname = UIWidgetNameDef.GuildRootPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildCreateView] = { widgetpath = "Modules.Guild.GuildCreateView", parentname = UIWidgetNameDef.GuildRootView, panelname = UIWidgetNameDef.GuildRootPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildApplyView] = { widgetpath = "Modules.Guild.GuildApplyView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildEditorView] = { widgetpath = "Modules.Guild.GuildEditorView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildHallView] = { widgetpath = "Modules.Guild.GuildHallView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildInformationView] = { widgetpath = "Modules.Guild.GuildInformationView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildLogoView] = { widgetpath = "Modules.Guild.GuildLogoView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildNameView] = { widgetpath = "Modules.Guild.GuildNameView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildNoticeView] = { widgetpath = "Modules.Guild.GuildNoticeView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildRecordView] = { widgetpath = "Modules.Guild.GuildRecordView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildSetView] = { widgetpath = "Modules.Guild.GuildSetView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildEntranceView] = { widgetpath = "Modules.Guild.GuildEntranceView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildLableView] = { widgetpath = "Modules.Guild.GuildLableView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.GuildlTipsView] = { widgetpath = "Modules.Guild.GuildlTipsView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},

	--Formation
	[UIWidgetNameDef.BattleTeamView] = { widgetpath = "Modules.Formation.BattleTeamView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.FormationChangeNameView] = { widgetpath = "Modules.Formation.FormationChangeNameView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.BattleFormationMenuView] = { widgetpath = "Modules.Formation.BattleFormationMenuView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},

	--SupplyDepot
	[UIWidgetNameDef.SupplyDepotDispatchView] = { widgetpath = "Modules.SupplyDepot.SupplyDepotDispatchView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.SupplyDepotLevelUpView] = { widgetpath = "Modules.SupplyDepot.SupplyDepotLevelUpView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.SupplyDepotLevelView] = { widgetpath = "Modules.SupplyDepot.SupplyDepotLevelView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.SupplyDepotShipView] = { widgetpath = "Modules.SupplyDepot.SupplyDepotShipView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.SupplyDepotQuickDispatchView] = { widgetpath = "Modules.SupplyDepot.SupplyDepotQuickDispatchView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.SupplyDepotView] = { widgetpath = "Modules.SupplyDepot.SupplyDepotView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	
	--rank
	[UIWidgetNameDef.RankListView] = { widgetpath = "Modules.RankList.RankListView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.RankListInfoView] = { widgetpath = "Modules.RankList.RankListInfoView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.RankListTipsView] = { widgetpath = "Modules.RankList.RankListTipsView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	
	--Mall
	[UIWidgetNameDef.MallRootView] = { widgetpath = "Modules.Mall.MallRootView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.MallNormalView] = { widgetpath = "Modules.Mall.MallNormalView", parentname = UIWidgetNameDef.MallRootView, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.MallLimitView] = { widgetpath = "Modules.Mall.MallLimitView", parentname = UIWidgetNameDef.MallRootView, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.MallMonthCardView] = { widgetpath = "Modules.Mall.MallMonthCardView", parentname = UIWidgetNameDef.MallRootView, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.MallConfirmView] = { widgetpath = "Modules.Mall.MallConfirmView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.MallConfirm2View] = { widgetpath = "Modules.Mall.MallConfirm2View", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.MallConfirm3View] = { widgetpath = "Modules.Mall.MallConfirm3View", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.MallConfirm4View] = { widgetpath = "Modules.Mall.MallConfirm4View", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.MallFirstChargeView] = { widgetpath = "Modules.Mall.MallFirstChargeView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.MallPushView] = { widgetpath = "Modules.Mall.MallPushView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.MallPassView] = { widgetpath = "Modules.Mall.MallPassView", parentname = UIWidgetNameDef.MallRootView, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.MallPassPointView] = { widgetpath = "Modules.Mall.MallPassPointView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.MallSelfView] = { widgetpath = "Modules.Mall.MallSelfView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.MallDailySupplyView] = { widgetpath = "Modules.Mall.MallDailySupplyView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},

	--mercenary
	[UIWidgetNameDef.MercApplyListView] = { widgetpath = "Modules.Mercenary.MercApplyListView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.MercRootView] = { widgetpath = "Modules.Mercenary.MercRootView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.MercApplyView] = { widgetpath = "Modules.Mercenary.MercApplyView", parentname = UIWidgetNameDef.MercRootView, panelname = UIWidgetNameDef.MercRootViewPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.MercSendInoView] = { widgetpath = "Modules.Mercenary.MercSendInoView", parentname = UIWidgetNameDef.MercRootView, panelname = UIWidgetNameDef.MercRootViewPanel, showtype = LayoutShowType.CoexistClose},
	
    --setting
	[UIWidgetNameDef.SettingMenuView] = { widgetpath = "Modules.SettingMenu.SettingMenuView", parentname = UIWidgetNameDef.HomePageView, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose,bautodepth=false},
	[UIWidgetNameDef.ChooseView] = { widgetpath = "Modules.SettingMenu.ChooseView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.SecondChooseView] = { widgetpath = "Modules.SettingMenu.SecondChooseView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.ServiceView] = { widgetpath = "Modules.SettingMenu.ServiceView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.SystemsettingView] = { widgetpath = "Modules.SettingMenu.SystemsettingView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	
	--Vip
	[UIWidgetNameDef.VipView] = { widgetpath = "Modules.Vip.VipView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	--跑马灯
	-- [UIWidgetNameDef.MarqueeView] = { widgetpath = "Modules.Marquee.MarqueeView", parentname = UIWidgetNameDef.Root_top, panelname = UIWidgetNameDef.TopPanel, showtype = LayoutShowType.CoexistClose,bautodepth=false},


	--activity
	[UIWidgetNameDef.ActivityRootView] = { widgetpath = "Modules.Activity.ActivityRootView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.SevenDaysCheckinView] = { widgetpath = "Modules.Activity.SevenDaysCheckinView", parentname = UIWidgetNameDef.ActivityRootView, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose,bautodepth=false},
	[UIWidgetNameDef.FreshmanTrainView] = { widgetpath = "Modules.Activity.FreshmanTrainView", parentname = UIWidgetNameDef.ActivityRootView, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose,bautodepth=false},
	[UIWidgetNameDef.HeroGatheringView] = { widgetpath = "Modules.Activity.HeroGatheringView", parentname = UIWidgetNameDef.ActivityRootView, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose,bautodepth=false},
	[UIWidgetNameDef.StageClearChargeView] = { widgetpath = "Modules.Activity.StageClearChargeView", parentname = UIWidgetNameDef.ActivityRootView, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose,bautodepth=false},
	[UIWidgetNameDef.HatharalComingView] = { widgetpath = "Modules.Activity.HatharalComingView", parentname = UIWidgetNameDef.ActivityRootView, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose,bautodepth=false},
	[UIWidgetNameDef.HatharalComingMainView] = { widgetpath = "Modules.Activity.HatharalComingMainView", parentname = UIWidgetNameDef.ActivityRootView, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose,bautodepth=false},
	[UIWidgetNameDef.ShareChargeView] = { widgetpath = "Modules.Activity.ShareChargeView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose},
	[UIWidgetNameDef.HeroComingView] = { widgetpath = "Modules.Activity.HeroComingView", parentname = UIWidgetNameDef.ActivityRootView, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose,bautodepth=false},
	[UIWidgetNameDef.HeroComingMainView] = { widgetpath = "Modules.Activity.HeroComingMainView", parentname = UIWidgetNameDef.ActivityRootView, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose,bautodepth=false},
	[UIWidgetNameDef.ActivityOverView] = { widgetpath = "Modules.Activity.ActivityOverView", parentname = UIWidgetNameDef.ActivityRootView, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose,bautodepth=false},

	--realm
	[UIWidgetNameDef.RealmRootView] = { widgetpath = "Modules.Realm.RealmRootView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose },
	[UIWidgetNameDef.RealmView] = { widgetpath = "Modules.Realm.RealmView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose },


	--cycleactivity
	[UIWidgetNameDef.CycleSevendaysCheckinView] = { widgetpath = "Modules.CycleActivity.CycleSevendaysCheckinView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose },
	[UIWidgetNameDef.CycleSevenLoginTypeTwoView] = { widgetpath = "Modules.CycleActivity.CycleSevenLoginTypeTwoView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose },
	[UIWidgetNameDef.EventsNineBoxView] = { widgetpath = "Modules.CycleActivity.EventsNineBoxView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose },
	[UIWidgetNameDef.NineBoxtaskView] = { widgetpath = "Modules.CycleActivity.NineBoxtaskView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose },


	[UIWidgetNameDef.MobilizeView] = { widgetpath = "Modules.Mobilize.MobilizeView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose },
	[UIWidgetNameDef.MobilizeMallView] = { widgetpath = "Modules.Mobilize.MobilizeMallView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose },
	[UIWidgetNameDef.MobilizeTaskView] = { widgetpath = "Modules.Mobilize.MobilizeTaskView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose },
	[UIWidgetNameDef.MobilizeBattleSelectView] = { widgetpath = "Modules.Battle.MobilizeBattleSelectView", parentname = UIWidgetNameDef.Root_normal, panelname = UIWidgetNameDef.NormalPanel, showtype = LayoutShowType.CoexistClose },
})