local GameUIUtil = CS.GameUIUtil
local AudioManager = require "Common.Mgr.Audio.AudioManager"
local NewbieWidget = require "Core.Implement.UI.Widgets.NewbieWidget"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"

local CToggleRender = CToggleRender or BaseClass(GameObjFactor, NewbieWidget)
--[[
	tweenOption :
	1:左边消失
	2:右边消失
	3:上边消失
	4:下边消失
]]	
local TweenOption = 
{	
	None = 0,
	Left = 1,
	Right = 2,
	Top = 3,
	Bottom = 4,
}

function CToggleRender:Load(ctoggleGroup, tweenOption,bneedopentween)
	self.ctoggleGroup = ctoggleGroup
	self.ctoggleGroup.toggleRender.gameObject:SetActive(false)
	self.ctoggleGroup:AddSelect(function (index)	
		self:_OnSelect(index)
	end)	
	self.go = ctoggleGroup.gameObject
	self.initPos = self.go.transform.localPosition

	self.selectIdx = nil
	self.toglist = {}

	self.locklist = {}
	self.viewopenlist = {}

	self.tweenOption = tweenOption or TweenOption.None
	self.bNeedOpenTween=bneedopentween
end

--redObjPath:红点路径
function CToggleRender:Add(redObjPath)
	local curCount = self.ctoggleGroup.toggleList.Count
	local tog = self.ctoggleGroup:Add(curCount, "")		
	self.ctoggleGroup:SetVisible(curCount, true)

	local togItem = {}
	tog.Sound = ""
	togItem.toggle = tog
	togItem.selectObj = self:GetChild(tog.gameObject, "select")
	self.initPosX=tog.gameObject.transform.localPosition.x-200
	togItem.selBackSp = self:GetChildComponent(togItem.selectObj, "CSprite_back", "CSprite")
	togItem.selIconSp = self:GetChildComponent(togItem.selectObj, "CSprite_icon", "CSprite")
	togItem.selLbl = self:GetChildComponent(togItem.selectObj, "CLabel_label", "CLabel")

	togItem.normalObj = self:GetChild(tog.gameObject, "normal")
	togItem.norBackSp = self:GetChildComponent(togItem.normalObj, "CSprite_back", "CSprite")
	togItem.norIconSp = self:GetChildComponent(togItem.normalObj, "CSprite_icon", "CSprite")
	togItem.norLbl = self:GetChildComponent(togItem.normalObj, "CLabel_label", "CLabel")

	togItem.redObj = self:GetChild(tog.gameObject, redObjPath and redObjPath or "CSprite_red")
	togItem.redNumLbl = self:GetChildComponent(tog.gameObject, "CSprite_red/CLabel_pointNum", "CLabel")
	togItem.flagSp = self:GetChildComponent(tog.gameObject, "CSprite_flag", "CSprite")
	if not togItem.flagSp then
		togItem.flagSp = self:GetChildComponent(tog.gameObject, "CSprite_gou", "CSprite")
	end
	togItem.lockObj = self:GetChild(tog.gameObject, "CSprite_Lock")

	--init
	togItem.selectObj:SetActive(false)
	togItem.selInitPos = togItem.selectObj.transform.localPosition

	togItem.normalObj:SetActive(true)
	togItem.norInitPos = togItem.normalObj.transform.localPosition
	togItem.checkBox = self:GetComponent(tog.gameObject, "CCheckBox")
	table.insert(self.toglist, togItem)	
end

function CToggleRender:ToggleChangeInfo(lastIndex ,index)
	AudioManager.PlaySoundByKey("ctoggle_show1")
	if lastIndex == index then
		return	
	end
		
	if lastIndex and self.toglist[lastIndex] then
		local togItem = self.toglist[lastIndex]
		self:ShowClickTween(togItem, false, function ()
			togItem.selectObj:SetActive(false)
			togItem.normalObj:SetActive(true)
		end)
	end
	
	if index and self.toglist[index] then
		local togItem = self.toglist[index]
		self:ShowClickTween(togItem, true, function ()
			togItem.selectObj:SetActive(true)
			togItem.normalObj:SetActive(false)
		end)
	end	
end

function CToggleRender:ShowNewOpenTween()
	if self.bNeedOpenTween then
		--暂时只适用于左边
		local sequence = DOTween.Sequence()
		local dis=200
		local time=0.2
		local delaytime = 0.1
		for k,v in ipairs(self.toglist) do
			v.toggle.transform.localPosition=Vector3.New(self.initPosX,v.toggle.transform.localPosition.y,v.toggle.transform.localPosition.z)
			local xx=self.initPosX+dis
			local tween = v.toggle.transform:DOLocalMoveX(xx, time)
			tween:SetEase(Ease.OutBack)
			sequence:Insert(delaytime * (k-1), tween)
		end
		sequence:SetAutoKill()
	end
end

function CToggleRender:ShowClickTween(togItem, bSelect, func)
	if self.tweenOption == TweenOption.None then 
		if func then
			func()	
		end	
		return
	end

	local time = 0.2
	local move = 50
	local showInitPos = bSelect and togItem.selInitPos or togItem.norInitPos
	local hideInitPos = bSelect and togItem.norInitPos or togItem.selInitPos

	local hideToPos = bSelect and togItem.norInitPos or togItem.selInitPos

	local showObj = bSelect and togItem.selectObj or togItem.normalObj
	local hideObj = bSelect and togItem.normalObj or togItem.selectObj
	
	local offvec = nil
	--init
	if self.tweenOption == TweenOption.Left then	
		offvec = Vector2.New(-move, 0)

	elseif self.tweenOption == TweenOption.Right then
		offvec = Vector2.New(move, 0)

	elseif self.tweenOption == TweenOption.Top then
		offvec = Vector2.New(0, move)

	elseif self.tweenOption == TweenOption.Bottom then
		offvec = Vector2.New(0, -move)
	else
		if func then
			func()	
		end	
		return		
	end

	showObj:SetActive(true)
	hideObj:SetActive(true)
	showObj.transform.localPosition = showInitPos + offvec
	hideObj.transform.localPosition = hideInitPos
	hideToPos = hideInitPos + offvec

	GameUIUtil.SetGroupAlpha(showObj ,0)
	GameUIUtil.SetGroupAlpha(hideObj ,1)	

	--start
	GameUIUtil.SetGroupAlphaInTime(showObj, 1, time)
	GameUIUtil.SetGroupAlphaInTime(hideObj, 0, time)

	if bSelect then
		local tween = showObj.transform:DOLocalMove(showInitPos, time)	
		tween:OnComplete(function ()
			if func then
				func()	
			end	
		end)	
		hideObj.transform.localPosition = hideToPos
	else
		local tween = hideObj.transform:DOLocalMove(hideToPos, time)	
		tween:OnComplete(function ()
			if func then
				func()	
			end	
		end)	
		showObj.transform.localPosition = showInitPos		
	end	
end

function CToggleRender:ShowOpenTween()
	local move = 100
	local offvec = nil
	local time = 0.5

	if self.tweenOption == TweenOption.Left then	
		offvec = Vector2.New(-move, 0)

	elseif self.tweenOption == TweenOption.Right then
		offvec = Vector2.New(move, 0)

	elseif self.tweenOption == TweenOption.Top then
		offvec = Vector2.New(0, move)

	elseif self.tweenOption == TweenOption.Bottom then
		offvec = Vector2.New(0, -move)
	else
		return	
	end	

	GameUIUtil.SetGroupAlpha(self.go ,0)
	self.go.transform.localPosition = self.initPos + offvec

	GameUIUtil.SetGroupAlphaInTime(self.go ,1 ,time)	
	self.go.transform:DOLocalMove(self.initPos, time)	
end

--内部接口
function CToggleRender:_OnSelect(index)
	local curindex = index + 1
	if next(self.viewopenlist) then
		if not self.viewopenlist[curindex] then
			local str = LanguageManager.Instance:GetWord("Common_1033")
			 GameLogicTools.ShowMsgTips(str)
			self:SelectIndex(self.selectIdx)
			return
		elseif self.locklist[curindex] then
			if type(self.locklist[curindex]) == "int" then
				local str = LanguageManager.Instance:GetWord("Common_1034", self.locklist[curindex])
				GameLogicTools.ShowMsgTips(str)
			elseif type(self.locklist[curindex]) == "string" then
				GameLogicTools.ShowMsgTips(self.locklist[curindex])
			end
			self:SelectIndex(self.selectIdx)
			return
		end	
	end
	self:ToggleChangeInfo(self.selectIdx, curindex)
	self.selectIdx = curindex
	if self.onSelect then
		self.onSelect(curindex)
	end	
	if self.onNewbieClick then
		local togItem = self.toglist[self.selectIdx]
		self.onNewbieClick.func(togItem.toggle)
	end	
end

--外部接口
function CToggleRender:GetRedObj(idx)
	return self.toglist[idx].redObj
end

function CToggleRender:SetRed(idx, isShow, num)
	if self.toglist[idx] then
		if self.toglist[idx].redObj and not self.locklist[idx] then
			self.toglist[idx].redObj:SetActive(isShow)
			if num and self.toglist[idx].redNumLbl then
				self.toglist[idx].redNumLbl.gameObject:SetActive(true)
				self.toglist[idx].redNumLbl.text = num
			end	
		end
	end	
end

function CToggleRender:SetFlag(idx, isShow, spriteName)
	if self.toglist[idx] then
		if self.toglist[idx].flagSp then
			self.toglist[idx].flagSp.gameObject:SetActive(isShow)
			if spriteName then
				self.toglist[idx].flagSp.SpriteName = spriteName
			end
		end
	end
end

function CToggleRender:UpdateLabel(idx,label)
	if self.toglist[idx] then
		local togItem = self.toglist[idx]
		if label then
			local str = LanguageManager.Instance:GetWord(label)
			togItem.norLbl.text = str
			togItem.selLbl.text = str
		end	
	end
end

function CToggleRender:UpdateIcon(idx,icon,selecticon)
	if self.toglist[idx] then
		local togItem = self.toglist[idx]
		if icon then
			togItem.norIconSp.SpriteName = icon
			
		end
		if selecticon then
			togItem.selIconSp.SpriteName = selecticon
		end	
	end
end

function CToggleRender:SetNormalInfo(idx, label, icon, back, norIconGray)
	if self.toglist[idx] then
		local togItem = self.toglist[idx]
		if label then
			local str = LanguageManager.Instance:GetWord(label)
			togItem.norLbl.text = str
		end	
		if icon then
			togItem.norIconSp.SpriteName = icon
			-- if norIconGray ~= nil then
				
			-- end
			
		end
		
		if norIconGray == false then
			togItem.norIconSp.Gray = false
		else
			togItem.norIconSp.Gray = true
		end
		
		if back then
			togItem.norBackSp.SpriteName = back
		end	
	end	
end

function CToggleRender:SetSelectInfo(idx, label, icon, back)
	if self.toglist[idx] then
		local togItem = self.toglist[idx]
		if label then
			local str = LanguageManager.Instance:GetWord(label)
			togItem.selLbl.text = str
		end	
		if icon then
			togItem.selIconSp.SpriteName = icon
		end	
		if back then
			togItem.selBackSp.SpriteName = back
		end	
	end	
end

function CToggleRender:SetNewbie(idx, newbieid, step)
	if self.toglist[idx] then
		local togItem = self.toglist[idx]
		self.onNewbieClick = {}
		self:RegisterToggle(togItem.toggle, newbieid, step, self.onNewbieClick)
	end	
end

function CToggleRender:SetLock(idx, locknum)
	self.locklist[idx] = locknum
	if self.toglist[idx] then
		local togItem = self.toglist[idx]
		if togItem.lockObj then
			togItem.lockObj:SetActive(locknum)
		end
	end	
end

function CToggleRender:SetViewOpen(idx, bshow)
	self.viewopenlist[idx] = bshow
end

function CToggleRender:SelectIndex(idx)
	self.ctoggleGroup.SelectIndex = idx - 1
	self:_OnSelect(idx - 1)	
end


function CToggleRender:AddSelect(func)
	self.onSelect = func	
end

--itemIdxList :{1,2} 需要显示的标签 顺序标签
function CToggleRender:ShowToggleItemLists(itemIdxList)
	for i,v in ipairs(self.toglist) do
		local bactive = false
		for _, _value in ipairs(itemIdxList) do
			if i == _value then
				bactive = true
				break
			end
		end
		v.toggle.gameObject:SetActive(bactive)
	end
end

function CToggleRender:SetEnabled(idx, enabled)
	if self.toglist[idx] then
		if self.toglist[idx].checkBox then
			self.toglist[idx].checkBox.enabled = enabled
		end
	end
end

--外部接口
function CToggleRender:GeLockObj(idx)
	return self.toglist[idx].lockObj
end

return CToggleRender
