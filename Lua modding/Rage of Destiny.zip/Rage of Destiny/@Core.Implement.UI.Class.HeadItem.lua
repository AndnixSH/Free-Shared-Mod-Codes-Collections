local RoleInfoProxy = require "Modules.RoleInfo.RoleInfoProxy"
local RoleInfoDef =require "Modules.RoleInfo.RoleInfoDef"
local HeadItem = HeadItem or BaseClass(GameObjFactor)

function HeadItem:__init(go)
	self.go = go
	self.callback=false
	self:Load(go)
end

function HeadItem:Load(obj)
	self.nameLbl = self:GetChildComponent(obj, "CLabel_name", "CLabel")
	self.levelLbl = self:GetChildComponent(obj, "lv/CLabel_lv", "CLabel")
	self.fightLbl = self:GetChildComponent(obj, "power/COutline_num", "CImageLabel")
	self.CTexture_head=self:GetChildComponent(obj, "CTexture_head", "CTexture")
	self.CTexture_frame=self:GetChildComponent(obj, "CTexture_frame", "CTexture")
	self.CSprite_head=self:GetChildComponent(obj, "btn/sprite", "CSprite")
	self.sexSpr=self:GetChildComponent(obj,"sex/male","CSprite")
	self.btn = self:GetChildComponent(obj,"CTexture_head/btn", "CButton")
	self.btn:AddClick(function ()
		self:OnClick()
	end)
	self.redDotObj = self:GetChild(obj,"redpiont")
	
end

function HeadItem:BindRedDot(id)
	
	if id then
		local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
		local RedPointDef = require "Modules.RedPoint.RedPointDef"
		RedPointProxy.Instance:BindNode(id,self.redDotObj)
	end
end

function HeadItem:SetHeadOnClickCallBack(callback)
	self.callback=callback
end
-- data: {nickname, sex, headIcon/headicon, frameIcon, level, fight, roleid}
function HeadItem:SetData(data)
	self.nameLbl.text = data.nickname
	self.levelLbl.text = data.level
	
	self:UpdateFight(data.fight);
	self:UpdateSex(data.sex)
	self:UpdatePhoto(data)
	self:UpdatePhotoFrame(data.frameicon or data.frameIcon) --容错处理，因为frameicon or frameIcon都有在用
	self:UpdateSprite(data.roleid)
end

function HeadItem:UpdateFight(fight)
	local fightStr
	if type(fight) == "number" then
		fightStr = GameLogicTools.GetNumStr(fight)
	else
		fightStr = fight
	end
	self.fightLbl.Text = fightStr
end

function HeadItem:OnClick()
	if self.callback then
		self.callback()
	end
end

function HeadItem:UpdateNickName(nickname)
	self.nameLbl.text = nickname
end

function HeadItem:UpdateLevel(level)
	self.levelLbl.text =level
end

function HeadItem:UpdateSex(sex)
	if self.sexSpr then
		if sex == RoleInfoDef.Sex.Boy then
            self.sexSpr.SpriteName= "nanshengtubiao"
            --nan
        elseif sex == RoleInfoDef.Sex.Girl then
            --nv
            self.sexSpr.SpriteName= "nvshengtubiao"
        elseif sex == RoleInfoDef.Sex.Hide then
            self.sexSpr.SpriteName= "baomitubiao"
        end
	end
end

function HeadItem:UpdatePhoto(data)
	if type(data) ~= "table" then
		if self.CTexture_head then
			local icon=RoleInfoProxy.Instance:GetPhotoIconNameById(RoleInfoModel.headicon)
			AssetManager.LoadUITexture(AssetManager.UITexture.Head, icon ,self.CTexture_head)
		end
		return
	end
	local _headIcon = data.headicon ~= nil and data.headicon or data.headIcon
	if _headIcon then
		local icon=RoleInfoProxy.Instance:GetPhotoIconNameById(_headIcon)
		if icon then
			if self.CTexture_head then
				AssetManager.LoadUITexture(AssetManager.UITexture.Head, icon ,self.CTexture_head)
			end
		else
			AssetManager.LoadUITexture(AssetManager.UITexture.Head, "Head_"..tostring(_headIcon) ,self.CTexture_head)
		end
		
	else
		if data.roleid then
			local HeroProxy = require "Modules.Hero.HeroProxy"
			local cfg = HeroProxy.Instance:GetRoleCfgByConfigId(data.roleid)
			if cfg and cfg.head_id and self.CTexture_head then
		        AssetManager.LoadUITexture(AssetManager.UITexture.Head, cfg.head_id ,self.CTexture_head)
			end
		elseif data.role and (type(data.role) == "number") then
			local HeroProxy = require "Modules.Hero.HeroProxy"
			local cfg = HeroProxy.Instance:GetRoleCfgByConfigId(data.role)
			if cfg and cfg.head_id and self.CTexture_head then
				AssetManager.LoadUITexture(AssetManager.UITexture.Head, cfg.head_id ,self.CTexture_head)
			end
			if cfg and cfg.name then
				local LanguageManager = require "Common.Mgr.Language.LanguageManager"
				self.nameLbl.text = LanguageManager.Instance:GetWord(cfg.name)
			end
		else
			if self.CTexture_head then
				local icon=RoleInfoProxy.Instance:GetPhotoIconNameById(RoleInfoModel.headicon)
				AssetManager.LoadUITexture(AssetManager.UITexture.Head, icon ,self.CTexture_head)
			end
		end
	end
end

function HeadItem:UpdatePhotoFrame(photoframeid)
	if photoframeid then
	    local icon=RoleInfoProxy.Instance:GetPhotoFrameIconNameById(photoframeid)
		if self.CTexture_frame then
	        AssetManager.LoadUITexture(AssetManager.UITexture.Frame, icon ,self.CTexture_frame)
	    end	
	end
end

function HeadItem:UpdateSprite(roleid)
	if self.CSprite_head and roleid then
		local HeroProxy = require "Modules.Hero.HeroProxy"
		local spritecfg = HeroProxy.Instance:GetSpriteConfigeById(roleid)
		self.CSprite_head.SpriteName = spritecfg.prefab_id[1]
	end
end

function HeadItem:Close()
end

function HeadItem:Destroy()
	self.go=false
	self.nameLbl=false
	self.levelLbl=false
	self.fightLbl=false
	self.btn=false
end

return HeadItem