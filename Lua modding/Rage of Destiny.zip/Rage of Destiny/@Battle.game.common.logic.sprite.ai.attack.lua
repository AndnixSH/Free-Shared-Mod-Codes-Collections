local state = {}

function state:onbreak()
    if self.caller.state:canattack() then
        local slotid = self.caller.skill:findslotheader()
        return slotid ~= nil
    end
end


function state:onupdate()

    if self.caller.state:canattack() then
        local slotid, vel, header = self.caller.skill:findslotheader()

        if slotid and vel then
            self.caller.skill:stopcurrent()
            self.owner.body:setvelocity(vel:fmul(self.owner.attr.mov))
            if vel.x == 0 and vel.y == 0 then -- 速度为0表示停止移动 发动技能
                if header then
                    self.owner.body:setheader(header)
                end
                self.caller.skill:fire(slotid)
            end
            return STATE_STATUS.SUSPEND
        else
            -- 会导致技能的移动停止先注释
            -- self.owner.body:setvelocity(tsvector.zero)
        end
    end

    return STATE_STATUS.OVER

end


return state