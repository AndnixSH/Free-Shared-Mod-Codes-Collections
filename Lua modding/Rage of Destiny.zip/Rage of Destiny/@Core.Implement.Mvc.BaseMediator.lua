BaseMediator = BaseMediator or BaseClass(NxFaceProxyDataEvt)

local Timer = require "Common.Util.Timer"
local SceneDef = require "Modules.Scene.SceneDef"
StdMediator = StdMediator or BaseClass(NxProxyDataEvtFactor)
function StdMediator:__init()	
	self:RegisterFacade()
end

function StdMediator:__delete()
	self:UnRegisterFacade()
end

function StdMediator:ListNotificationInterests()
	return {AppFacade.Scene, table.unpack(self:SubListNotificationInterests())}
end

function StdMediator:SubListNotificationInterests()
	return {}
end

function StdMediator:RegisterFacade()
	local notifyList = self:ListNotificationInterests() or {}
	for _, proxyName in pairs(notifyList) do
		local proxyIns = faceProxyList[proxyName]
		if proxyIns and proxyIns.data then
			self:RegisterLuaNotify(proxyIns.data, proxyName)
		end	
	end	
end

function StdMediator:UnRegisterFacade()
	local notifyList = self:ListNotificationInterests() or {}
	for _, proxyName in pairs(notifyList) do
		local proxyIns = faceProxyList[proxyName]
		if proxyIns and proxyIns.data then
			self:UnRegisterLuaNotify(proxyIns.data, proxyName)
		end	
	end
end

function StdMediator:OnLuaNotify(data, strEvent, args)
	self:OnLuaNotifyForScene(data, strEvent, args)
	self:OnLuaNotifyForSubList(data, strEvent, args)
end

function StdMediator:OnLuaNotifyForScene(data, strEvent, args)
	if strEvent == AppFacade.Scene then
		if args == SceneDef.NotifyDef.Scene_Enter_End then
			self:OnEnterScenceEnd()

		elseif args == SceneDef.NotifyDef.Scene_Enter_Start then
			self:OnEnterScenceStart()

		elseif args == SceneDef.NotifyDef.Scene_Enter_First then
			self:OnEnterScenceFirst()

		elseif args == SceneDef.NotifyDef.Scene_Loading_End	then
			self:OnEnterLoadingEnd()

		elseif args == SceneDef.NotifyDef.Scene_Enter_Init then
			self:OnEnterScenceInit()
		end
	end
end

function StdMediator:OnEnterScenceStart()
end

function StdMediator:OnEnterScenceEnd()
end

function StdMediator:OnEnterScenceFirst()
end

function StdMediator:OnEnterLoadingEnd()
end

function StdMediator:OnEnterScenceInit()
end

function StdMediator:DelayExecute(func)
	local seconds = math.random() * 3
	Timer.New(func, seconds, 1):Start()
end

function StdMediator:OnLuaNotifyForSubList(data, strEvent, args)
end