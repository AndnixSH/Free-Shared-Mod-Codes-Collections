local game_view = require "Battle.render.view.base_game_view"

local render_camera = require "Battle.render.camera.render_camera"
local SceneProxy = require "Modules.Scene.SceneProxy"

local bone_camera_anchor = require "Battle.render.anchor.bone_camera_anchor"
local effect_sprite_model = require "Battle.render.model.effect_sprite_model"

--local AmbientMode = CS.UnityEngine.Rendering.AmbientMode
local RenderSettings = CS.UnityEngine.RenderSettings
local FogMode = CS.UnityEngine.FogMode

local main_line_game_view = game_view()

function main_line_game_view:__init()
end

function main_line_game_view:__delete()

end

function main_line_game_view:on_start()
    local cfg = SceneProxy.Instance:GetSceneCfgById(self.game_info.sceneid)    
    if not cfg then
        print("main line config is nil, please check out ...")
        return
    end
    local scenecfg = cfg.mainline
    if scenecfg.camera then
        local red = scenecfg.camera[1]
        local green = scenecfg.camera[2]
        local blue = scenecfg.camera[3]
        local alpha = scenecfg.camera[4]
        render_camera.set_camera_background_color(red, green, blue, alpha)
    end

    --render_camera.set_target_trunk_strategy(scenecfg.camera)
    --render_camera.set_breathe_camera_strategy(scenecfg.camera)

    if scenecfg.fogColor then
        RenderSettings.fog = true
        RenderSettings.fogColor = Color.New(scenecfg.fogColor[1] / 255 , scenecfg.fogColor[2] / 255, scenecfg.fogColor[3] / 255) --Color.white -- {255, 255, 255}
        RenderSettings.fogMode = FogMode.Linear

        if scenecfg.fogDistance then
            RenderSettings.fogStartDistance = scenecfg.fogDistance[1]
            RenderSettings.fogEndDistance = scenecfg.fogDistance[2]
        end

        --if scenecfg.ambientLight then
        --    RenderSettings.ambientMode = AmbientMode.Flat
        --    RenderSettings.ambientLight = Color.New(scenecfg.ambientLight[1] / 255, scenecfg.ambientLight[2] / 255, scenecfg.ambientLight[3] / 255)
        --end
    end

    if cfg.weather and type(cfg.weather) == 'string' then
        local anchor = bone_camera_anchor.New()
        self.weather_effect = effect_sprite_model.New(anchor, cfg.weather)
    end
end

function main_line_game_view:on_end()
    render_camera.free_trunk_strategy()

    if self.weather_effect then
        self.weather_effect:release()
        self.weather_effect:DeleteMe()
        self.weather_effect = nil
    end
end

function main_line_game_view.event.sprite.public:skill_hit(_, hitid, position, header, height)
    self:on_skill_hit(hitid, position, header, height)
end

function main_line_game_view.event.game:camera_adjust(offsetx, offsety, rate)
    --print('camera_adjust', offsetx, offsety, rate)
    render_camera.set_adjust_offset(offsetx / 1000, offsety / 1000, rate, 10)
end

function main_line_game_view.event.game:camera_lift(lift)
    --render_camera.set_adjust_offset(0, 0, lift, 10)
end

function main_line_game_view.event.game:camera_strategy(strategy, args)
    --print('recv_strategy', strategy, table.dump(args))

    if strategy == CAMERA_STRATEGY.BONE then
        --render_camera.free_trunk_strategy()
        self:set_bone_camera(args)
    elseif strategy == CAMERA_STRATEGY.ADJUST then
        self:set_adjust_camera(args)
    elseif strategy == CAMERA_STRATEGY.TRANSFORM then
        self:set_transform_camera(args)
    end
end

function main_line_game_view:set_bone_camera(args)
    if args.fieldOfView then
        render_camera.set_camera_field_of_view(args.fieldOfView)
    end

    if args.bone == "cameraPos" then
        local rootObj = AssetManager.GetActiveSceneRootObject()
        local camera_position_obj = GameObjTools.GetChild(rootObj, "cameraPos")
        if camera_position_obj then
            --camera_position_obj:SetActive(false)
            render_camera.set_bone_trunk_strategy(camera_position_obj, args)
            --camera_position_obj:SetActive(true)
        end
    elseif args.bone == "cameraBossPos/cam" then
        local rootObj = AssetManager.GetActiveSceneRootObject()
        local camera_position_obj = GameObjTools.GetChild(rootObj, "cameraBossPos/cam")
        if camera_position_obj then
            --camera_position_obj:SetActive(false)
            render_camera.set_bone_trunk_strategy(camera_position_obj, args)
            --camera_position_obj:SetActive(true)
        end
    end
end

function main_line_game_view:set_adjust_camera(args)
    if next(args) ~= nil then
        render_camera.free_trunk_strategy()
        render_camera.set_adjust_trunk_strategy(args)
    end
end

function main_line_game_view:set_transform_camera(args)
    local rootObj = AssetManager.GetActiveSceneRootObject()
    local camera_position_obj = GameObjTools.GetChild(rootObj, "cameraPos")
    if camera_position_obj then
        camera_position_obj:SetActive(false)
    end

    if args.fieldOfView then
        render_camera.set_camera_field_of_view(args.fieldOfView)
    end

    local transform = { x = args.x, y = args.y, z = args.z, pitch = args.pitch, yaw = args.yaw, roll = args.roll}

    render_camera.set_camera_transform(transform)
end

return main_line_game_view