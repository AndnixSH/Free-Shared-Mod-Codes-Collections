ConfigManager.InitConfig('data_mall_grow', {
[1]={id=1,item_id=1,grid_type=1,gift_ids={2001}, buy_limit={{0,20,1},}, tog_name="Mall_Grow_1001",back_pic="Tex_Mall_chengzhang1",slogen_pic="chengzhang"},
[2]={id=2,item_id=2,conditions={{1,752,}}, grid_type=1,gift_ids={2002}, buy_limit={{0,20,1},}, tog_name="Mall_Grow_1006",back_pic="Tex_Mall_chengzhang1_2",back2_pic="Tex_Mall_chengzhang4_2",slogen_pic="chengzhang2"},
})