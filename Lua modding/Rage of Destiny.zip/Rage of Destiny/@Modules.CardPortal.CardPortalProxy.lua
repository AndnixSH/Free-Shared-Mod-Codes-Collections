local CardPortalDef= require "Modules.CardPortal.CardPortalDef"
local HeroProxy = require "Modules.Hero.HeroProxy"
local BagProxy = require "Modules.Bag.BagProxy"
local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
local RedPointDef = require "Modules.RedPoint.RedPointDef"
local ModuleManager = require "Common.Mgr.UI.ModuleManager"
local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
local CardPortalProxy = CardPortalProxy or BaseClass(BaseProxy)

function CardPortalProxy:__init(name)
	CardPortalProxy.Instance = self
	self.goodsKeyValue = {
		[1] = {691001, 1, 10, "putongchoujiangquan"}, --普通卷轴{物品id, 单抽数量，10抽数量，物品图标}
		[2] = {692001, 1, 10, "zhongzuchoujiangquan"}, --种族卷轴
		[4] = {693001, 1, 10, "putongchoujiangquan"}, --占星卷轴
	}
	self.raceCardId = 302020  --自选种族卡
	self.normalOneDrawDiamond = 300 --普通单抽消耗钻石
	self.normalTenDrawDiamond = 2700 --普通十抽消耗钻石
	self.companionOneDrawPoint = 10 --友情单抽消耗友情点
	self.companionTenDrawPoint = 100 --友情单抽消耗友情点

	self.GoodsNum = {} --记录一下当前的抽卡各种券的数量
	self.data = {}
	self.data.cacheRedDot = {}
	self:AddProto(12000, self.On12000)
	self:AddProto(12001, self.On12001)
	self:AddProto(12002, self.On12002)
	self:AddProto(12003, self.On12003)
	self:AddProto(12004, self.On12004)

	self:AddProto(12005, self.On12005)
	self:AddProto(12006, self.On12006)
end

function CardPortalProxy:__delete()
	self.data = nil
end

--抽卡相关信息
function CardPortalProxy:Send12000()
	-- print("Send11000==")
	self:SendMessage(12000)
end

function CardPortalProxy:On12000(decoder)
	local draw_Card_total_times = decoder:Decode("I2")-- 普通和种族抽卡总次数
	local cur_flesh_faction = decoder:Decode("I1")  --当前处于刷新期间种族卡池, 不随着切换种族而改变
	local cur_faction = decoder:Decode("I1")   --当前种族卡池
	local faction_list =decoder:DecodeList("I1")  --当前拥有种族卡池列表
	local draw_cart_infos = {}  --各种抽卡次数信息
	local count= decoder:Decode("I2") 
	for i=1,count do
		draw_cart_infos[decoder:Decode("I1")] = decoder:Decode("I2")  --key:1普通抽 2种族抽 3友情点抽  value:当天次数
	end
	local wish_hero_lists = {} --心愿单列表  只会发有的过来
	count = decoder:Decode("I2")
	for i=1,count do
		local race = decoder:Decode("I1")
		wish_hero_lists[race] = {}
		local heroinfo_count = decoder:Decode("I2")
		for i=1,heroinfo_count do
			local pos,roleid = decoder:Decode("I1I4")
			wish_hero_lists[race][pos] = roleid
		end
	end
	
	self.data.draw_Card_total_times = draw_Card_total_times
	self.data.cur_flesh_faction = cur_flesh_faction
	self.data.cur_faction = cur_faction
	self.data.faction_list = faction_list
	self.data.draw_cart_infos = draw_cart_infos
	self.data.wish_hero_lists = wish_hero_lists
	-- print("当前种族===", cur_faction)
	-- print("拥有种族卡列表===", table.dump(faction_list))
	-- print("心愿单列表===", table.dump(wish_hero_lists))
	self:ToNotify(self.data, CardPortalDef.Notify.Update_CardPortal_Infos)
	
	-- print("CardPortalProxy:On12000", table.dump(self.data))

	--红点
	self:UpdateCardRedPoint()
end

--抽卡
function CardPortalProxy:Send12001(_type)
	local encoder = NetEncoder.New()
	encoder:Encode("I1", _type)
	self:SendMessage(12001, encoder)
	print("CardPortalProxy:Send12001", _type)
end

function CardPortalProxy:GetRandomReward(list)
	local count = #list
	if count >= 2 then
		math.randomseed(tostring(os.time()):reverse():sub(1, count)) --设置时间种子
	end
	--math.randomseed(tostring(os.time()):reverse():sub(1, 7)) --设置时间种子
	local tb = {}
	while #tb < count do 
		local istrue = false
		local num = math.random( 1,count )
		if #tb ~= nil then
			for i = 1 ,#tb do
				if tb[i] == num then
					istrue = true
				end
			end
		end
		if istrue == false then
			table.insert( tb, num )
		end
	end
	local _list = {}
	for i = 1,count do
		_list[i] = list[tb[i]]
	end
	return _list
end

function CardPortalProxy:On12001(decoder)
	local result = decoder:Decode("I1")
	if result == 0 then
		local _draws_card_sub_type = decoder:Decode("I1")
		local goods_list = decoder:DecodeList("I4") --英雄列表
		local rewards = {}  --额外奖励列表
		local rewards_count = decoder:Decode("I2")
		for i=1,rewards_count do
			local item = {}
			item.goodsTypeId,item.goodsCount = decoder:Decode("I4I2")
			table.insert(rewards, item)
		end
		local retire_goods_list = decoder:DecodeList("I4I2", true)
		local retire_goods = {}
		for i,v in ipairs(retire_goods_list) do
			table.insert(retire_goods, {goodsTypeId = v[1], goodsCount = v[2]})
		end

		if _draws_card_sub_type == CardPortalDef.DrawType.companion_ten or _draws_card_sub_type == CardPortalDef.DrawType.normal_ten or
		_draws_card_sub_type == CardPortalDef.DrawType.faction_ten or _draws_card_sub_type == CardPortalDef.DrawType.stargaze_ten then
			if #goods_list >= 2 then
				goods_list = self:GetRandomReward(goods_list)
			end
			if #rewards >= 2 then
				rewards = self:GetRandomReward(rewards)
			end
		end

		local new_hero_infos = decoder:DecodeList("I4I4I2I2", true)

		self:ToNotify(self.data, CardPortalDef.Notify.GetNewHeroInfos, {newheros = new_hero_infos})

		self:ToNotify(self.data, CardPortalDef.Notify.Update_Draw_Card, {herolist = goods_list, awardlist = rewards, retire_goods_list = retire_goods, draws_card_sub_type=_draws_card_sub_type})
		
		print("--->>_draws_card_sub_type", _draws_card_sub_type)
		print("获得英雄列表==", table.dump(goods_list))
		print("额外奖励列表==", table.dump(rewards))
		print("遣散奖励列表==", table.dump(retire_goods))
	else
		-- print("抽卡失败 result=", result)
	end
	
	GameLogicTools.ShowErrorCode(12001, result)
end

--切换种族卡池
function CardPortalProxy:Send12002(faction)
	local encoder = NetEncoder.New()
	encoder:Encode("I1", faction)
	-- print("Send11002==", faction)
	self:SendMessage(12002, encoder)
end

function CardPortalProxy:On12002(decoder)
	local result = decoder:Decode("I1")
	-- print("On11002==", result)
	GameLogicTools.ShowErrorCode(12002, result)
end

function CardPortalProxy:Send12003(faction, handle, position, roleid)
	-- print("Send11003==", faction, handle, position, roleid)
	local encoder = NetEncoder.New()
	encoder:Encode("I1BI1I4", faction, handle, position, roleid)
	self:SendMessage(12003, encoder)
end

function CardPortalProxy:On12003(decoder)
	local result = decoder:Decode("I1")
	-- print("On11003==", result)
	GameLogicTools.ShowErrorCode(12003, result)
end

function CardPortalProxy:On12004(decoder)
	local draw_cart_infos = {}  --各种抽卡次数信息
	local draw_Card_total_times = decoder:Decode("I2")-- 普通和种族抽卡总次数
	local count= decoder:Decode("I2") 
	for i=1,count do
		draw_cart_infos[decoder:Decode("I1")] = decoder:Decode("I2")  --key:1普通抽 2种族抽 3友情点抽  value:当天次数
	end
	-- print("==On12004====", draw_Card_total_times, table.dump(draw_cart_infos))
	self:ToNotify(self.data, CardPortalDef.Notify.Update_Draw_Card_Data, {draw_Card_total_times = draw_Card_total_times, draw_cart_infos = draw_cart_infos})
end

------config--------
function CardPortalProxy:GetDrawCardProgressConfig()
	local config = ConfigManager.GetConfig("data_card_progress")
	return config
end

function CardPortalProxy:GetDrawCardProbabilityConfig()
	local config = ConfigManager.GetConfig("data_card_probability")
	return config
end

function CardPortalProxy:CheckIsNewHero(heroId)
	local config = ConfigManager.GetConfig("data_common").cardportal_new
	if config.value1 then
		for k,value in pairs(config.value1) do
			if heroId == value then
				--已经获得了就不显示 new标识
				return HeroProxy.Instance:IsNewHero(heroId)
			end
		end
	end
	return false
end

function CardPortalProxy:CheckIsNewRaceHero(race)
	
	local config = ConfigManager.GetConfig("data_common").cardportal_new
	if config.value1 then
		for k,value in pairs(config.value1) do
			local heroCfg = HeroProxy.Instance:GetRoleCfgByConfigId(value)
			if heroCfg and heroCfg.race == race then
				--已经获得了就不显示 new标识
				if  HeroProxy.Instance:IsNewHero(value) then
					return true
				end
			end
		end
	end
	return false
end

function CardPortalProxy:GetPerStageCount(totalCount)
	local cfg = self:GetDrawCardProgressConfig()
	local allCount = 0
	local config = {}
	local type = 1
	if totalCount and totalCount >= 500 then
		type = 2
	end
	for k,v in ipairs(cfg) do
		if v.type == type and v.progress > allCount then
			allCount = v.progress
			table.insert(config, v)
		end
	end
	table.sort(config, function(a, b)
		return a.progress < b.progress
	end)

	local stageCounts = {}
	for i,v in ipairs(config) do
		local stage = v.progress
		if config[i-1] then
			stage = v.progress - config[i-1].progress
		end
		table.insert(stageCounts, stage)
	end
	return allCount, config, stageCounts
end

--阶段奖励相关信息
function CardPortalProxy:GetProgressConfigByCount(totalCount)
	local _totalCount = totalCount
	local cur_count, allCount = 0, 0
	local stageAllCount, config, stageCounts = self:GetPerStageCount(totalCount)

	local t1,t2 = math.modf(_totalCount/stageAllCount)
	if t1 ~= 0 then
		_totalCount = _totalCount - t1*stageAllCount
	end
	local flag = true
	local idx = 1
	while flag do
		if _totalCount >= stageCounts[idx] then
			_totalCount = _totalCount - stageCounts[idx]
			idx = idx + 1
		else
			cur_count = _totalCount
			allCount = stageCounts[idx]
			flag = false
		end
		-- print("lastProgress===", idx, lastProgress, _totalCount, cur_count, allCount)
	end
	return cur_count, allCount, config[idx], idx
end

--startValue:初始值  endValue:最新值     
function CardPortalProxy:GetProgressAnimInfo(startValue, endValue)
	local cur_count, allCount, config, index = self:GetProgressConfigByCount(startValue)
	local _allCount, _configs, _stageCounts = self:GetPerStageCount()
	local _startValue = startValue
	local _addValue = endValue - _startValue
	
	local flag = true
	local infos = {}
	while flag do

		local total_count = _stageCounts[index]

		local _count = total_count - cur_count
		if _addValue >= _count then
			table.insert(infos, {cur_count, total_count, total_count, index})
			_addValue = _addValue - _count
			cur_count = 0
			if _configs[index+1] then
				index = index + 1
			else
				index = 1
			end
		else
			-- _addValue  有可能 等于 0
			table.insert(infos, {cur_count, cur_count+_addValue, total_count, index})
			flag = false
		end
	end
	return infos
end

--更新抽卡红点
function CardPortalProxy:UpdateCardRedPoint()

	local bopen2 = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.CardPortView,false)
	if not bopen2 then
		return
	end
	local ins = RedPointProxy.Instance
	local normalOne = self:IsEnoughGoods(CardPortalDef.DrawCardType.Normal, true)
	local normalTen = self:IsEnoughGoods(CardPortalDef.DrawCardType.Normal, false)
	local factionOne = self:IsEnoughGoods(CardPortalDef.DrawCardType.Faction, true)
	local factionTen = self:IsEnoughGoods(CardPortalDef.DrawCardType.Faction, false)
	local companionOne = self:IsEnoughCost(CardPortalDef.DrawCardType.Companion, true)
	local companionTen = self:IsEnoughCost(CardPortalDef.DrawCardType.Companion, false)

	local starGazeOne = self:IsEnoughGoods(CardPortalDef.DrawCardType.StarGaze, true)
	local starGazeTen = self:IsEnoughGoods(CardPortalDef.DrawCardType.StarGaze, false)

	--ins:SetNodeNum(RedPointDef.Id.CardPortalNormalOne, normalOne and 1 or 0)
	ins:SetNodeNum(RedPointDef.Id.CardPortalNormalTen, normalTen and 1 or 0)
	--ins:SetNodeNum(RedPointDef.Id.CardPortalFactionOne, factionOne and 1 or 0)
	ins:SetNodeNum(RedPointDef.Id.CardPortalFactionTen, factionTen and 1 or 0)
	--ins:SetNodeNum(RedPointDef.Id.CardPortalCompanionOne, companionOne and 1 or 0)
	ins:SetNodeNum(RedPointDef.Id.CardPortalCompanionTen, companionTen and 1 or 0)

	local value = (normalTen or factionTen or companionTen  ) and 1 or 0
	ins:SetNodeNum(RedPointDef.Id.CardPortal_2, value)

	local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.CardStarView,false)
	--ins:SetNodeNum(RedPointDef.Id.CardStarOne,starGazeOne and 1 or 0)
	ins:SetNodeNum(RedPointDef.Id.CardStarTen,starGazeTen and 1 or 0)
	ins:SetNodeNum(RedPointDef.Id.CardStar, (starGazeTen and bopen) and 1 or 0)

	local showstarred = RedPointProxy.Instance:GetNodeNum(RedPointDef.Id.CardStar) > 0 and true or false
	
	local showred = RedPointProxy.Instance:GetNodeNum(RedPointDef.Id.CardPortal_2) > 0 and true or false

	--心愿单红点
	local showwishlistred = false
	local CampaignProxy = require "Modules.Campaign.CampaignProxy"
	local open = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.CardWishPool,false)
	
	if RoleInfoModel.mainlineid >= 41 then
		showwishlistred = self:CheckShowWishListRedDot()
		ins:SetNodeNum(RedPointDef.Id.CardPortalWishList, showwishlistred and 1 or 0)
	end

	local rednum2 = RedPointProxy.Instance:GetNodeNum(RedPointDef.Id.CardPortNewHero_2)
	local value = (showred or showstarred or showwishlistred or (rednum2 > 0 and bopen)) and 1 or 0
	ins:SetNodeNum(RedPointDef.Id.CardPortal, value)

	value = BagProxy.Instance:GetItemCountByID(self.raceCardId)
	ins:SetNodeNum(RedPointDef.Id.CardPortalRaceCard, value)
end

function CardPortalProxy:CheckShowWishListRedDot()
	local showred = PlayerPrefs.GetInt(RoleInfoModel.guserid.."wishlist")
	local rednum = RedPointProxy.Instance:GetNodeNum(RedPointDef.Id.CardPortNewHero)
	if showred  == 1 and rednum == 0 then
		return false
	else
		return true
	end
end

function CardPortalProxy:SetShowWishListRedDot(value)
	PlayerPrefs.SetInt(RoleInfoModel.guserid.."wishlist",value)

	local rednum = RedPointProxy.Instance:GetNodeNum(RedPointDef.Id.CardPortNewHero)
    if rednum > 0 then
		local config = ConfigManager.GetConfig("data_common").cardportal_new
		if config.value1 then
			for k,value in pairs(config.value1) do
				PlayerPrefs.SetInt(RoleInfoModel.guserid.."cardport_newhero_"..tostring(value),1)
			end
		end
		RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.CardPortNewHero,0)
    end
	RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.CardPortalWishList,0)
	local showstarred = RedPointProxy.Instance:GetNodeNum(RedPointDef.Id.CardStar) > 0 and true or false
	local showred = RedPointProxy.Instance:GetNodeNum(RedPointDef.Id.CardPortal_2) > 0 and true or false

	local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.CardStarView,false)
	local rednum2 = RedPointProxy.Instance:GetNodeNum(RedPointDef.Id.CardPortNewHero_2)
	local value = (showred or showstarred  or (rednum2 > 0  and bopen) ) and 1 or 0
	RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.CardPortal, value)
end

function CardPortalProxy:CheckHasShowNewHeroRed(value)
	return PlayerPrefs.GetInt(RoleInfoModel.guserid.."cardport_newhero_"..tostring(value))
end

function CardPortalProxy:SetShowCardStarChooseRedDot(value)
	local config = ConfigManager.GetConfig("data_common").cardportal_new
	if config.value1 then
		for k,value in pairs(config.value1) do
			PlayerPrefs.SetInt(RoleInfoModel.guserid.."cardport_newhero_"..tostring(value),1)
		end
	end
	
	RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.CardPortNewHero_2,0)
	local showstarred = RedPointProxy.Instance:GetNodeNum(RedPointDef.Id.CardStar) > 0 and true or false
	local showred = RedPointProxy.Instance:GetNodeNum(RedPointDef.Id.CardPortal_2) > 0 and true or false

	local rednum = RedPointProxy.Instance:GetNodeNum(RedPointDef.Id.CardPortNewHero)
	local value = (showred or showstarred  or rednum > 0  ) and 1 or 0
	RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.CardPortal, value)
end

function CardPortalProxy:UpdateWishListRedDot()

	--心愿单红点
	local showwishlistred = false
	if RoleInfoModel.mainlineid >= 41 then
		showwishlistred = self:CheckShowWishListRedDot()
		RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.CardPortalWishList, showwishlistred and 1 or 0)
		if showwishlistred then
			RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.CardPortal, 1)
		end
		
	end
end

--是否有足够的道具消耗
function CardPortalProxy:IsEnoughGoods(drawCardType, isOne)
	local config = self.goodsKeyValue[drawCardType]
	if config then
		local nowCount = BagProxy.Instance:GetItemCountByID(config[1])
		if not self.GoodsNum[config[1]] then
			self.GoodsNum[config[1]] = nowCount
		else
			if nowCount > self.GoodsNum[config[1]] then
				--RedPointProxy.Instance:SetHideState(RedPointDef.Id.CardPortal,false)
				if drawCardType == CardPortalDef.DrawCardType.StarGaze then
					RedPointProxy.Instance:SetHideState(RedPointDef.Id.CardStar,false)
				else
					RedPointProxy.Instance:SetHideState(RedPointDef.Id.CardPortal_2,false)
				end
			end
			self.GoodsNum[config[1]] = nowCount
		end
		local needCount = isOne and config[2] or config[3]
		if nowCount >= needCount then
			return true
		end
	end
	return false
end

--是否有足够的消耗(钻石、道具、友情点) isOne:是否单抽
function CardPortalProxy:IsEnoughCost(drawCardType, isOne)
	local isEnoughCost = false
	local isEnoughGoods = false
	if drawCardType == CardPortalDef.DrawCardType.Normal then --消耗钻石或道具
		if self:IsEnoughGoods(drawCardType, isOne) then --优先消耗道具
			isEnoughCost = true
			isEnoughGoods = true
		else
			local nowCount = RoleInfoModel.diamond
			local needCount = isOne and self.normalOneDrawDiamond or self.normalTenDrawDiamond
			if nowCount >= needCount then
				isEnoughCost = true
				isEnoughGoods = false
			end
		end
	elseif drawCardType == CardPortalDef.DrawCardType.Faction then --消耗道具
		if self:IsEnoughGoods(drawCardType, isOne) then
			isEnoughCost = true
			isEnoughGoods = true
		end
	elseif drawCardType == CardPortalDef.DrawCardType.Companion then --消耗友情点
		local nowCount = RoleInfoModel.companion_points
		local companionId = 1
		if not self.GoodsNum[companionId] then
			self.GoodsNum[companionId] = nowCount
		else
			if nowCount > self.GoodsNum[companionId] then
				--RedPointProxy.Instance:SetHideState(RedPointDef.Id.CardPortal,false)
				RedPointProxy.Instance:SetHideState(RedPointDef.Id.CardPortal_2,false)
			end
			self.GoodsNum[companionId] = nowCount
		end
		local needCount = isOne and self.companionOneDrawPoint or self.companionTenDrawPoint
		if nowCount >= needCount then
			isEnoughCost = true
			isEnoughGoods = false
		end
	end
	return isEnoughCost, isEnoughGoods
end

function CardPortalProxy:GetDrawCardAmount(_type)
	local BagProxy = require "Modules.Bag.BagProxy"
	local goodsCount = BagProxy.Instance:GetItemCountByID(self.goodsKeyValue[_type][1])
	return goodsCount or 0
end

function CardPortalProxy:GetCardStarGoodsData()
	local goodsdata={}
	local cfg=ConfigManager.GetConfig("data_common")
	if cfg then
		local data=cfg.cardstar_item 
		local goods=data and data.value1 or {}
		if goods then
			for _, v in ipairs(goods) do
				if v then
					table.insert(goodsdata,v)
				end
			end
		end
	end
	return goodsdata
end

function CardPortalProxy:Send12005()
	--请求占星所设置的英雄
	self:SendMessage(12005)
	--self:On12005(nil)
end

function CardPortalProxy:On12005(decoder)
	local roleid =decoder:Decode("I4")
	print("On12005 -->", roleid)

	--local hero=HeroProxy.Instance:GetRoleCfgByConfigId(roleid)
	if not self.data.cardstar then
		self.data.cardstar={}
	end
	self.data.cardstar.roleid=roleid
	self:UpdateCardRedPoint()
	self:ToNotify(self.data,CardPortalDef.Notify.Update_CardStar_SetHero,{roleid=roleid})
end

function CardPortalProxy:GetCardStarCurSetHero()

	if self.data.cardstar then
		return self.data.cardstar.roleid
	end
	
end

function CardPortalProxy:Send12006(roleid)
	--设置占星英雄
	if roleid > 0 and roleid ~= self.data.cardstar.roleid then
		local encoder = NetEncoder.New()
		encoder:Encode("I4", roleid)
		self:SendMessage(12006, encoder)
	end
	--self:On12006(nil,roleid)
end

function CardPortalProxy:On12006(decoder)
	local result,roleid = decoder:Decode("I1I4")
	print("On12006 -->", result, roleid)
	if result == 0 then
		LuaLayout.Instance:CloseWidget(UIWidgetNameDef.CardStarChooseView)
		local view =LuaLayout.Instance:GetWidget(UIWidgetNameDef.CardStarSetView)
		local data={}
		data.curroleid=roleid
		data.lastroleid=self.data.cardstar.roleid
		if view then
			
			view.data=data
			view:OpenView()
		end
		if not self.data.cardstar then
			self.data.cardstar={}
		end
		self.data.cardstar.roleid=roleid
		self:ToNotify(self.data,CardPortalDef.Notify.Update_CardStar_SetHero,{roleid=roleid})
	else
		GameLogicTools.ShowErrorCode(12006, result)
	end
end

function CardPortalProxy:Send12007()
	--占星1连抽
	self:SendMessage(12007)
	self:On12007(nil)
end

function CardPortalProxy:On12007(decoder)
	local result =0-- decoder:Decode("I1")
	local goodslist=decoder:DecodeList("I4I4")
	if result == 0 then
		local goodsInfos={}
		for i,info in ipairs(goodslist) do
            table.insert(goodsInfos, {goodsid = info[1], goodsnum = info[2]})
        end
		GameLogicTools.ShowGetItemView(goodsInfos,4)
	else
		GameLogicTools.ShowErrorCode(12007, result)
	end
end

function CardPortalProxy:Send12008()
	--占星10连抽
	self:SendMessage(12008)
	self:On12008(nil)
end

function CardPortalProxy:On12008(decoder)
	local result =0-- decoder:Decode("I1")
	local goodslist=decoder:DecodeList("I4I4")
	if result == 0 then
		local goodsInfos={}
		for i,info in ipairs(goodslist) do
            table.insert(goodsInfos, {goodsid = info[1], goodsnum = info[2]})
        end
		GameLogicTools.ShowGetItemView(goodsInfos,4)
	else
		GameLogicTools.ShowErrorCode(12008, result)
	end
end

function CardPortalProxy:GetCardStarChooseHeroData()
	if self.data.cardstar and  self.data.cardstar.data then
		return self.data.cardstar.data
	end
	local ownherodata = HeroProxy.Instance:GetHeroDataList()
    local ownheros = {}
    for _ , v in ipairs(ownherodata) do
        if not ownheros[v.roleid] then
            ownheros[v.roleid] = v.rank
        else
            if ownheros[v.roleid] < v.rank then
                ownheros[v.roleid] = v.rank
            end
        end
    end

	local heros=HeroProxy.Instance:GetHeroConfige()
	local data={}
	for _, v in pairs( heros) do
		if v.rank_min == 5 and v.race ~= 7 then
			local Item={}
			Item.roleid=v.id
			Item.goodsid=v.goods_id
			Item.rank = ownheros[v.id]
			Item.new= self:CheckIsNewHero(v.id)
			Item.race=v.race
			table.insert(data,Item)
		end
	end
	table.sort(data,function (a,b  )
		return a.roleid > b.roleid 
	end)
	if not self.data.cardstar then
		self.data.cardstar={}
	end
	self.data.cardstar.data=data
	return data
end

function CardPortalProxy:GetCardStarChooseHeroDataByRace(race)
	if not  self.data.cardstar or not   self.data.cardstar.data then
		local data=self:GetCardStarChooseHeroData()
	end
	if race == 0 then
		return self.data.cardstar.data
	end
	local data={}
	for _,v in ipairs(self.data.cardstar.data) do
		if v.race == race then
			table.insert(data,v)
		end
	end
	return data
end

function CardPortalProxy:GetCardStarPercentData()
	local cfg=ConfigManager.GetConfig("data_common")
	local percent_data={}
	if cfg then
		local data=cfg.cardstar_percent 
		local datalist=data and data.value1 or {}
		for k= 1 , #datalist do
			local item=datalist[k]
			if datalist[k] then
				if k == 1 then
					if self.data.cardstar and self.data.cardstar.roleid then
						local cfg=HeroProxy.Instance:GetRoleCfgByConfigId(self.data.cardstar.roleid)
						if cfg then
							local goodsid=cfg.goods_id 
							local hero={}
							hero.roleid=self.data.cardstar.roleid
							hero.rank=cfg.rank_min
							hero.level=1
							table.insert(percent_data,{goods={goodsid,item[2]},percent=item[3]/100,hero=hero})
						end
					end
				else
					table.insert(percent_data,{goods={item[1],item[2]},percent=item[3]/100})
				end
			end
		end
	end
	return percent_data
end

function CardPortalProxy:GetCurrentPage()
	
	return PlayerPrefs.GetInt(tostring(RoleInfoModel.guserid).."CardPortal_Page")
end
function CardPortalProxy:SetCurrentPage(page)
	-- page 0 为抽卡，1为占星
	PlayerPrefs.SetInt(tostring(RoleInfoModel.guserid).."CardPortal_Page",page)
end

--抽卡场景预加载
function CardPortalProxy:GetCardPortal_PreLoaderRes()
	local res_list = {}  --{{"res", 1}, ...}

	local insert_func = function(key_values)
		for k,_res in pairs(key_values) do
			if type(_res) == "table" then
				table.insert(res_list, {_res[1], _res[2]})
			else
				table.insert(res_list, {_res, 1})				
			end
		end
	end

	insert_func(CardPortalDef.PreLoaderRes.FlashEffects)
	insert_func(CardPortalDef.PreLoaderRes.BeamEffects)
	insert_func(CardPortalDef.PreLoaderRes.RaceEffects)
	insert_func(CardPortalDef.PreLoaderRes.StandModels_Res)

	table.insert(res_list, {CardPortalDef.PreLoaderRes.NormalEffects, 1})
	table.insert(res_list, {CardPortalDef.PreLoaderRes.CompanionEffects, 1})
	table.insert(res_list, {CardPortalDef.PreLoaderRes.Progress_effect_name_Res, 1})

	return res_list
end

return CardPortalProxy