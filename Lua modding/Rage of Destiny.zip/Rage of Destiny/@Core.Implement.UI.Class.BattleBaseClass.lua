--需要在 LuaEventClass 下继承

local BattleBaseClass = BattleBaseClass or BaseClass()

--精灵事件
function BattleBaseClass:RegisterSpriteEvent(spriteid)
    if global then
        local spriteobj = global.service.pool:get_obj(spriteid)
        if spriteobj then
            global.service.eventslots:load(self.event, self, spriteobj, "view")
        else
            error("RegisterSpriteEvent ===>  spriteobj is null, spriteid:", spriteid)
        end    
    end    
end

function BattleBaseClass:UnRegisterSpriteEvent()
    if global then
        global.service.eventslots:unload(self.event, self)
    end    
end

function BattleBaseClass:PullSpriteEvent(spriteid)
    if global and self.event.attr then
        local spriteobj = global.service.pool:get_obj(spriteid)
        if spriteobj and spriteobj.attr then        
            global.service.propchange:pull(self.event.attr, self, spriteobj.attr)
        else
            error("PullSpriteEvent ===>  spriteobj is null, spriteid:", spriteid)
        end 
    end    
end

--全局事件
function BattleBaseClass:RegisterBattleGlobalEvent()
    if global and GameConfig.RENDER_ENABLE then
        local gameobj = global.service.area:getgameobj()
        global.service.eventslots:load(self.event, self, gameobj, "view") 
    end
end

function BattleBaseClass:UnRegisterBattleGlobalEvent()
    if global then
        global.service.eventslots:unload(self.event, self)
    end
end

return BattleBaseClass

