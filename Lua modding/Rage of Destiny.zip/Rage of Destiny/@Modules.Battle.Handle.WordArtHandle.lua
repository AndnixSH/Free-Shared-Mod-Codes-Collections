local TweenTools =  require "Common.Util.TweenTools"
local ColorTools = require "Common.Util.ColorTools"	
local GameUIUtil = CS.GameUIUtil
local HtmlUtil = CS.HtmlUtil

local ObjPoolRender = require "Core.Implement.UI.Class.ObjPoolRender"
local ObjPoolItem = require "Core.Implement.UI.Class.ObjPoolItem"
local BattleProxy = require "Modules.Battle.BattleProxy"
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"

local WordPoolItem = WordPoolItem or BaseClass(ObjPoolItem)
function WordPoolItem:Load(obj)
	self.objRect = self:GetComponent(obj, "RectTransform")
	self.imageLbl = self:GetComponent(obj, "CImageLabel")
	self.richlabel = self:GetComponent(obj, "CRichLabel")
	self.label = self:GetComponent(obj, "CLabel")
	self.outline = self:GetComponent(obj, "Outline")
	self.wordSp = self:GetComponent(obj, "CSprite")
end

function WordPoolItem:SetData(data)
	self.go:SetActive(true)

	self.data = data
	self.originPos = data.originPos 
	self.dicY_offset = data.dicY_offset
	self.tarPos = Vector3.New(data.originPos.x, data.originPos.y, 0)
	self.objRect.localPosition = self.tarPos
	self.objRect.localScale = Vector2.New(data.scale, data.scale)
	GameUIUtil.SetGroupAlpha(self.go, 1)
end	

function WordPoolItem:Close()
	self.bclose = true
	GameUIUtil.SetGroupAlpha(self.go, 0)
end

function WordPoolItem:SetRichLabel(label, outline)
	if self.richlabel then
		self.richlabel.HtmlText = label
		if outline then
			self.outline.effectColor = ColorTools.RichText2Color(outline)
		end	
	end	
end

function WordPoolItem:SetLabel(label, outline)
	if self.label then
		self.label.text = label
		if outline then
			self.outline.effectColor = ColorTools.RichText2Color(outline)
		end	
	end	
end

function WordPoolItem:SetImageLabel(label, value)
	if self.imageLbl then
		self.imageLbl.Text = label		
	end
end

function WordPoolItem:SetWordSprite(spritename, value)
	if self.wordSp then
		self.wordSp.SpriteName = spritename		
	end	
end

function WordPoolItem:SetKillNumSprite(spritename, value)
	self:SetWordSprite(spritename)
	if self.wordSp then
		self.effect = UIEffectItem.New("UI_View_Kill_" .. value, self.wordSp.gameObject)
		self.effect:Open()
	end
end

function WordPoolItem:GetTweenTime(origin_value)
	local speed = BattleProxy.Instance:GetGameSpeed()
	local time = math.min((speed-1), 0) * origin_value
	time = origin_value - time
	return time
end

--快速向上飞
function WordPoolItem:StartTween1() -- 普攻
	local tween = {
		-- 放大	
		self.objRect:DOScale(self.data.scale * 1.3, self:GetTweenTime(0.1)),
		-- 上移
		self.objRect:DOAnchorPosY(self.tarPos.y + (70-self.dicY_offset), self:GetTweenTime(0.2)),
		-- 缩放
		self.objRect:DOScale(self.data.scale, self:GetTweenTime(0.2))
	}
	
	tween[1]:SetEase(Ease.OutQuint)
	-- tween[2]:SetEase(Ease.InQuart)
	-- tween[3]:SetEase(Ease.InQuint)

	local sequence = DOTween.Sequence()
	-- sequence:AppendInterval(0.05)
	sequence:Append(tween[1])
	sequence:AppendInterval(self:GetTweenTime(0.1))
	sequence:AppendCallback(function ()
		if not self.bclose then
			GameUIUtil.SetGroupAlphaInTime(self.go, 0, self:GetTweenTime(0.3))
		end
	end)		
	sequence:Append(tween[2])
	sequence:Join(tween[3])
	sequence:AppendCallback(function ()
		self:Release()
	end)
end

--Q弹然后快速向上
function WordPoolItem:StartTween2() -- 暴击
	local tween = {
		-- 放大	
		self.objRect:DOScale(self.data.scale * 1.5, self:GetTweenTime(0.2)),
		-- 上移
		self.objRect:DOAnchorPosY(self.tarPos.y + 60-self.dicY_offset, self:GetTweenTime(0.3)),
		-- 缩放
		self.objRect:DOScale(self.data.scale, self:GetTweenTime(0.1))
	}
	
	tween[1]:SetEase(Ease.OutQuint)
	-- tween[2]:SetEase(Ease.InQuart)
	-- tween[3]:SetEase(Ease.InQuint)

	local sequence = DOTween.Sequence()
	-- sequence:AppendInterval(0.05)
	sequence:Append(tween[1])
	sequence:AppendInterval(self:GetTweenTime(0.15))
	sequence:AppendCallback(function ()
		if not self.bclose then
			GameUIUtil.SetGroupAlphaInTime(self.go, 0, self:GetTweenTime(0.3))
		end
	end)		
	sequence:Append(tween[2])
	sequence:Join(tween[3])
	sequence:AppendCallback(function ()
		self:Release()
	end)
end

--放大缩小后缓慢向上
function WordPoolItem:StartTween3()	-- 治疗
	--上移
	local tween1 = self.objRect:DOAnchorPosY(self.tarPos.y + 70-self.dicY_offset, self:GetTweenTime(1))
	tween1:OnComplete(function ()
		self:Release()
	end)

	--放大在缩小
	local sequence = DOTween.Sequence()
	-- local tween2 = self.objRect:DOScale(self.data.scale * 1.3, 0.1)
	local tween3 = self.objRect:DOScale(self.data.scale * 1, self:GetTweenTime(0.1))
	-- sequence:Append(tween2)
	-- sequence:AppendInterval(0.1)
	sequence:Append(tween3)
	sequence:AppendInterval(self:GetTweenTime(0.1))

	--渐变
	GameUIUtil.SetGroupAlphaInTime(self.go, 0, self:GetTweenTime(1))
end

--直接向上
function WordPoolItem:StartTween4()
	local tween = self.go.transform:DOAnchorPosY(self.tarPos.y + 60-self.dicY_offset, self:GetTweenTime(0.5))
	tween:OnComplete(function ()
		self:Release()
	end)	
end

-- --放大后渐变消失
	-- function WordPoolItem:StartTween5()	
	-- 	self.objRect.localScale = Vector3.zero

	-- 	local sequence = DOTween.Sequence()
	-- 	local tween1 = self.objRect:DOScale(self.data.scale, self:GetTweenTime(0.5))
	-- 	sequence:Append(tween1)
	-- 	sequence:AppendInterval(self:GetTweenTime(0.2))
	-- 	sequence:AppendCallback(function ()
	-- 		if not self.bclose then
	-- 			GameUIUtil.SetGroupAlphaInTime(self.go, 0, self:GetTweenTime(1))
	-- 		end
	-- 	end)
	-- 	sequence:AppendInterval(self:GetTweenTime(0.2))
	-- 	sequence:AppendCallback(function ()
	-- 		self:Release()
	-- 	end)
-- end
function WordPoolItem:StartTween5() -- 新状态类飘字动画
	local tween = {
		-- 放大	
		self.objRect:DOScale(self.data.scale * 1.3, self:GetTweenTime(0.2)),
		-- 上移
		self.objRect:DOAnchorPosY(self.tarPos.y + (10-self.dicY_offset), self:GetTweenTime(0.2)),
		-- 缩放
		self.objRect:DOScale(self.data.scale, self:GetTweenTime(0.2))
	}
	
	tween[1]:SetEase(Ease.OutQuint)
	-- tween[2]:SetEase(Ease.InQuart)
	-- tween[3]:SetEase(Ease.InQuint)

	local sequence = DOTween.Sequence()
	-- sequence:AppendInterval(0.05)
	sequence:Append(tween[1])
	sequence:AppendInterval(self:GetTweenTime(0.2))
	sequence:AppendCallback(function ()
		if not self.bclose then
			GameUIUtil.SetGroupAlphaInTime(self.go, 0, self:GetTweenTime(0.5))
		end
	end)		
	sequence:Append(tween[2])
	sequence:Join(tween[3])
	sequence:AppendCallback(function ()
		self:Release()
	end)
end

--放大后渐变消失
function WordPoolItem:StartTween6()	-- 护盾
	--上移
	local tween1 = self.objRect:DOAnchorPosY(self.tarPos.y + 70-self.dicY_offset, self:GetTweenTime(0.8))
	tween1:OnComplete(function ()
		self:Release()
	end)

	--放大在缩小
	local sequence = DOTween.Sequence()
	-- local tween2 = self.objRect:DOScale(self.data.scale * 1.3, 0.1)
	local tween3 = self.objRect:DOScale(self.data.scale * 1, self:GetTweenTime(0.1))
	-- sequence:Append(tween2)
	-- sequence:AppendInterval(0.1)
	sequence:Append(tween3)
	sequence:AppendInterval(self:GetTweenTime(0.1))

	--渐变
	GameUIUtil.SetGroupAlphaInTime(self.go, 0, self:GetTweenTime(0.8))
end

function WordPoolItem:StartTween7()	-- 普攻
	--上移
	local tween1 = self.objRect:DOAnchorPosY(self.tarPos.y + 60-self.dicY_offset, self:GetTweenTime(0.5))
	tween1:OnComplete(function ()
		self:Release()
	end)
	--渐变
	GameUIUtil.SetGroupAlphaInTime(self.go ,0 ,self:GetTweenTime(0.5))	
end


function WordPoolItem:StartTween8(callback) -- 新状态类飘字动画
	local tween = {
		-- 放大	
		self.objRect:DOScale(self.data.scale * 1.3, self:GetTweenTime(0.2)),
		-- 上移
		self.objRect:DOAnchorPosY(self.tarPos.y + (10-self.dicY_offset), self:GetTweenTime(0.3)),
		-- 缩放
		self.objRect:DOScale(self.data.scale, self:GetTweenTime(0.2))
	}
	
	tween[1]:SetEase(Ease.OutQuint)
	-- tween[2]:SetEase(Ease.InQuart)
	-- tween[3]:SetEase(Ease.InQuint)

	local sequence = DOTween.Sequence()
	-- sequence:AppendInterval(0.05)
	sequence:Append(tween[1])
	sequence:AppendInterval(self:GetTweenTime(0.3))
	sequence:AppendCallback(function ()
		if self.bclose then
			if callback then
				callback()
			end
		else
			GameUIUtil.SetGroupAlphaInTime(self.go, 0, self:GetTweenTime(0.5))
		end
	end)		
	sequence:Append(tween[2])
	sequence:Join(tween[3])
	sequence:AppendCallback(function ()
		if callback then
			callback()
		end
		self:Release()
	end)
end

function WordPoolItem:StartKillNumTween()
	self:StartTween8(function()
			if self.effect then
				self.effect:Destroy()
				self.effect = nil
			end
		end)
end

-----------------------------------------------------------------
local _wordInfoDic = nil
local _wordSendDic = nil
local _wordSendTime = 0.15 --精灵飘字间隔 每0.15秒飘每种状态字飘一次
local _wordSendCount = 0
local _wordSendMaxCount = 10 --每_wordSendTime秒每个精灵飘字的最大数量
local _wordHangUpMaxCount = 5 --挂机每_wordSendTime秒每个精灵飘字的最大数量

--对于 DAMAGE_STATE 的扩展, 某State事件对应N种飘字类型
local WordTypeExtend = 
{
	--DAMAGE_STATE.HP
	Recover = 101, --回复
	Hurt_Blue = 102, --伤害 敌方
	Crits = 103, --暴击
	Hurt_Red = 104,  --伤害 己方

	--DAMAGE_STATE.SLD
	Block = 301, --格挡

	--DAMAGE_STATE.KILL
	KillNum = 601, --连杀数
	
	BUFF_ATK = 801, --ATK
}

local WordArtHandle = WordArtHandle or BaseClass(GameObjFactor)
function WordArtHandle:__init(obj)
	self.go = obj
	self:InitObj(obj)
end
--暴击 能量 治疗 护盾 普工状态类 连杀
function WordArtHandle:InitObj(obj)
	self:InitDic()
	self.critsObj = self:GetChild(obj, "wordItem/critsroot/crits") --1
	self.labelObj = self:GetChild(obj, "wordItem/labelroot/label")
	self.sldObj = self:GetChild(obj, "wordItem/sldroot/sld")  --4
	self.mpObj = self:GetChild(obj, "wordItem/mproot/mp")   --2
	self.hurtBlueObj = self:GetChild(obj, "wordItem/hurt_blueroot/hurt_blue") --5
	self.hurtRedObj = self:GetChild(obj, "wordItem/hurt_redroot/hurt_red")  --5
	self.recoverObj = self:GetChild(obj, "wordItem/recoverroot/recover")  --3
	self.wordSpObj = self:GetChild(obj, "wordItem/wordspriteroot/wordsprite")  --5
	self.killNumObj = self:GetChild(obj, "wordItem/wordspriteKillNumroot/wordspriteKillNum")  --6
	self.buffAtkObj = self:GetChild(obj, "wordItem/StateBuffroot/StateBuff")  --5

	self.wordPoolRenders = {}
	self:InitWordItem(self.critsObj, WordTypeExtend.Crits)
	self:InitWordItem(self.hurtBlueObj, WordTypeExtend.Hurt_Blue)
	self:InitWordItem(self.hurtRedObj, WordTypeExtend.Hurt_Red)
	self:InitWordItem(self.recoverObj, WordTypeExtend.Recover)
	self:InitWordItem(self.sldObj, DAMAGE_STATE.SLD)
	self:InitWordItem(self.mpObj, DAMAGE_STATE.MP)
	self:InitWordItem(self.wordSpObj, DAMAGE_STATE.IMMUNE)
	self:InitWordItem(self.wordSpObj, DAMAGE_STATE.NOHIT)
	self:InitWordItem(self.wordSpObj, DAMAGE_STATE.KILL)
	self:InitWordItem(self.wordSpObj, WordTypeExtend.Block)
	self:InitWordItem(self.killNumObj, WordTypeExtend.KillNum)	--连杀
	self:InitWordItem(self.wordSpObj, DAMAGE_STATE.CHARM)
	self:InitWordItem(self.buffAtkObj, WordTypeExtend.BUFF_ATK)
end	

function WordArtHandle:InitWordItem(obj, state)
	local poolRender = nil
	for _, data in pairs(self.wordPoolRenders) do
		if data.itemobj == obj then
			poolRender = data.poolRender
			break
		end	
	end
	if not poolRender then
	    poolRender = ObjPoolRender.New()
	    poolRender:Load(obj, obj.transform.parent, WordPoolItem, false)
	end
	self.wordPoolRenders[state] = {poolRender = poolRender, itemobj = obj, info = _wordInfoDic[state]}
end

function WordArtHandle:InitDic()
	_wordSendDic = {}
	if not _wordInfoDic then
		_wordInfoDic = {}
		_wordInfoDic[WordTypeExtend.Crits] = {offset = {50,60}, dicY_offset = -20, scale = 0.7, tweenFunc = "StartTween2", InitFunc = "SetImageLabel"} 	--暴击
		_wordInfoDic[WordTypeExtend.Hurt_Blue] = {offset = {0, 40}, dicY_offset = 0, scale = 0.6, tweenFunc = "StartTween1", InitFunc = "SetImageLabel"} 		--敌方伤害 
		_wordInfoDic[WordTypeExtend.Hurt_Red] = {offset = {0, 40}, dicY_offset = 0, scale = 0.6, tweenFunc = "StartTween1", InitFunc = "SetImageLabel"} 		--己方伤害
		_wordInfoDic[WordTypeExtend.Recover] = {offset = {0, 40}, dicY_offset = 0, scale = 0.5, tweenFunc = "StartTween3", InitFunc = "SetImageLabel"} 	--回复
		_wordInfoDic[DAMAGE_STATE.SLD] = {offset = {0, 40}, dicY_offset = 0, scale = 0.5, tweenFunc = "StartTween6", InitFunc = "SetImageLabel"} 		--护盾
		_wordInfoDic[DAMAGE_STATE.MP] = {offset = {0, 10}, dicY_offset = 0, scale = 0.8, tweenFunc = "StartTween3", InitFunc = "SetImageLabel"} 			--能量
		_wordInfoDic[DAMAGE_STATE.IMMUNE] = {offset = {0, 120}, dicY_offset = 0, scale = 0.6, tweenFunc = "StartTween5", InitFunc = "SetWordSprite", word = "SCT_1007", SpriteName= "Immunity_"}		--免疫
		_wordInfoDic[DAMAGE_STATE.NOHIT] = {offset = {0, 120}, dicY_offset = 0, scale = 0.6, tweenFunc = "StartTween5", InitFunc = "SetWordSprite", word = "SCT_1006", SpriteName= "Parry_"}		--Miss
		_wordInfoDic[DAMAGE_STATE.KILL] = {offset = {0, 135}, dicY_offset = 0, scale = 0.8, tweenFunc = "StartTween5", InitFunc = "SetWordSprite", word = "SCT_1012", SpriteName= "Fury_"}		--击杀
		_wordInfoDic[WordTypeExtend.Block] = {offset = {0, 120}, dicY_offset = 0, scale = 0.6, tweenFunc = "StartTween5", InitFunc = "SetWordSprite", word = "SCT_1001", SpriteName= "Block_"}	--阻挡
		_wordInfoDic[WordTypeExtend.KillNum] = {offset = {0, 175}, dicY_offset = 0, scale = 0.7, tweenFunc = "StartKillNumTween", InitFunc = "SetKillNumSprite"}	--连杀
		_wordInfoDic[DAMAGE_STATE.CHARM] = {offset = {0, 120}, dicY_offset = 0, scale = 0.6, tweenFunc = "StartTween5", InitFunc = "SetWordSprite", word = "SCT_1006", SpriteName= "Charm_"}		--魅惑
		_wordInfoDic[WordTypeExtend.BUFF_ATK] = {offset = {0, 120}, dicY_offset = 0, scale = 0.6, tweenFunc = "StartTween5", InitFunc = "SetImageLabel"}	--ATK
	end	
end

function WordArtHandle:Open()
	--层级排列
	self:ShowWordObjActive(true)
	GameObjTools.SetDepth(self.hurtBlueObj.transform.parent.gameObject, self:GetNextDepth())
	GameObjTools.SetDepth(self.hurtRedObj.transform.parent.gameObject, self:GetNextDepth())
	GameObjTools.SetDepth(self.wordSpObj.transform.parent.gameObject, self:GetNextDepth())
	GameObjTools.SetDepth(self.buffAtkObj.transform.parent.gameObject, self:GetNextDepth())
	GameObjTools.SetDepth(self.sldObj.transform.parent.gameObject, self:GetNextDepth())
	GameObjTools.SetDepth(self.recoverObj.transform.parent.gameObject, self:GetNextDepth())
	GameObjTools.SetDepth(self.mpObj.transform.parent.gameObject, self:GetNextDepth())
	GameObjTools.SetDepth(self.killNumObj.transform.parent.gameObject, self:GetNextDepth())
	GameObjTools.SetDepth(self.critsObj.transform.parent.gameObject, self:GetNextDepth())
end

function WordArtHandle:Close()
end

function WordArtHandle:Destroy()
	for k, value in pairs(self.wordPoolRenders) do
		if value.poolRender then
			value.poolRender:ReleaseAll()
		end
	end
end

function WordArtHandle:ShowWordObjActive(bActives)
	self.go:SetActive(bActives)
end

function WordArtHandle:FrameUpdate(time, deltaTime)
	if self.sendTime == nil or ( (time - self.sendTime) > _wordSendTime ) then
		self.sendTime = time
		self:StartSendWord()
	end	
end

--解决同帧发多条消息位置重叠问题
function WordArtHandle:InsertWordSendList(toid, state, notify)
	if not self:CheckInsert(state) then return end

	if not _wordSendDic[toid] then
		_wordSendDic[toid] = {}
	end	
	if not _wordSendDic[toid][state] then
		_wordSendDic[toid][state] = {bodd_number = false, notify = {}} --bodd_number 是否是奇数
	end	

	-- table.insert(_wordSendDic[toid][state], notify)
	_wordSendDic[toid][state].bodd_number = _wordSendDic[toid][state].bodd_number == false and true or false 
	if notify.dicY_offset ~= 0 then
		if not _wordSendDic[toid][state].bodd_number then
			notify.position = Vector3.New(notify.position.x, notify.position.y+notify.dicY_offset, notify.position.z)
		end
	end

	table.insert(_wordSendDic[toid][state].notify, notify)
end

function WordArtHandle:IsHangUpBattle()
	if global and global.game.gameid == GAMEPLAYID.HANGUP then
		return true
	end
	return false
end

function WordArtHandle:GetSendMaxCount()
	if self:IsHangUpBattle() then
		return _wordHangUpMaxCount
	else
		return _wordSendMaxCount
	end
end

function WordArtHandle:CheckInsert(state)
	if global and global.game.gameid == GAMEPLAYID.HANGUP then
		if state == WordTypeExtend.Recover or
			state == WordTypeExtend.Hurt_Blue or
			state == WordTypeExtend.Hurt_Red or
			state == WordTypeExtend.Crits or
			state == DAMAGE_STATE.MP or
			state == DAMAGE_STATE.SLD or
			state == DAMAGE_STATE.CHARM or
			state == WordTypeExtend.BUFF_ATK
			then
			return true
		else
			return false
		end	
	else	
		return true
	end	
end	

function WordArtHandle:StartSendWord()
	--先整合
	for spriteid, sprite_state in pairs(_wordSendDic) do		
		for state, notify_data in pairs(sprite_state) do		
			if state == WordTypeExtend.Recover and #notify_data.notify > 0 then
				local newnotify = {}
				for _,notify in ipairs(notify_data.notify) do
					newnotify.spriteid = notify.spriteid
					newnotify.state = notify.state			
					newnotify.position = notify.position
					newnotify.tocamp = notify.tocamp
					newnotify.func = notify.func
					if newnotify.args == nil then
						newnotify.args = notify.args
					else
						newnotify.args[1] = newnotify.args[1] + notify.args[1]
					end	
				end
				_wordSendDic[spriteid][state].notify = {newnotify}
			end
		end
	end	

	--后发送 
	-- local count = 0
	for _, sprite_state in pairs(_wordSendDic) do
		local count = 0
		for _, notify_data in pairs(sprite_state) do
			if #notify_data.notify > 0 then
				if count >= self:GetSendMaxCount() then
					return	
				else
					count = count + 1
					local info = notify_data.notify[1]
					info.func(self, info.position, info.tocamp, info.state, info.args)
					table.remove(notify_data.notify, 1)
					--全部都移除掉，重置奇偶状态,奇偶用来做y轴偏移
					if #notify_data.notify == 0 then
						notify_data.bodd_number = false
					end
				end	
			end	
		end

	end
end

function WordArtHandle:WordEventNotify(fromid, toid, tocamp, state, ...)
	local wordlist = self:CreateWordList(fromid, toid, tocamp, state, ...)
	for _, info in pairs(wordlist) do
		if self.wordPoolRenders[info.state] then
			local wordInfo = self.wordPoolRenders[info.state].info
			if wordInfo then
				local from_position = UILayerTool.GetSpriteScreenPos(info.fromspriteid)
				local to_position = UILayerTool.GetSpriteScreenPos(info.spriteid)
				if from_position and to_position then
					-- local func = function ()
					-- 	self:UpdateWord(position, tocamp, info.state, args)
					-- end
					local position = self:CheckPosition(from_position, to_position, info.state)
					local notify = {}
					notify.args = {...}
					notify.spriteid = info.spriteid
					notify.state = info.state			
					notify.position = position
					notify.tocamp = tocamp
					notify.func = self.UpdateWord
					notify.dicY_offset = wordInfo.dicY_offset --同一类型连续飘字，Y轴相对原始位置偏移

					self:InsertWordSendList(info.spriteid, info.state, notify)
				end		
			end	
		end
	end	
end

--飘字位置
function WordArtHandle:CheckPosition(from_position, to_position, state)
	local position = Vector3.New(to_position.x, to_position.y, 0)
	local wordInfo
	if self.wordPoolRenders[state] then
		wordInfo = self.wordPoolRenders[state].info
		position = Vector3.New(to_position.x + wordInfo.offset[1], to_position.y + wordInfo.offset[2], 0)

		--伤害和暴击在受到伤害的对立方飘
		if state == WordTypeExtend.Hurt_Blue or state == WordTypeExtend.Hurt_Red or state == WordTypeExtend.Crits then
			local direction = to_position.x - from_position.x >= 0 and 1 or -1 --1:受到伤害方在右边 -1受到伤害方在左边
			local offset_x =  direction == 1 and wordInfo.offset[1] or wordInfo.offset[1]*(-1)
			local offset_y = wordInfo.offset[2]
			position = Vector3.New(to_position.x + offset_x, to_position.y + offset_y, 0)
		end

	end
	return position
end

function WordArtHandle:CreateWordList(fromid, toid, tocamp, state, ...)
	local list = {}

	local args = {...}
	if state == DAMAGE_STATE.HP then
		local value = args[1]
		local bcrits = args[2]
		if bcrits == true then
			state = WordTypeExtend.Crits
		elseif value > 0 then
			state = WordTypeExtend.Recover
		elseif value < 0 then
			state = tocamp == CAMP.RED and WordTypeExtend.Hurt_Red or WordTypeExtend.Hurt_Blue
			--print("tocamp===", WordTypeExtend.Hurt_Red, WordTypeExtend.Hurt_Blue, tocamp, state)
		end
		table.insert(list, {fromspriteid = fromid, spriteid = toid, state = state})
	elseif state == DAMAGE_STATE.SLD then
		local value = args[1]
		table.insert(list, {fromspriteid = fromid, spriteid = toid, state = state})
		--格挡不需要了
		-- if value < 0 then
		-- 	table.insert(list, {fromspriteid = fromid, spriteid = toid, state = WordTypeExtend.Block})
		-- end	
	elseif state == DAMAGE_STATE.KILL then
		local killnum = args[1]	or 0
		if killnum >= 2 then
			table.insert(list, {fromspriteid = fromid, spriteid = toid, state = WordTypeExtend.KillNum})
		end	
		table.insert(list, {fromspriteid = fromid, spriteid = toid, state = state})
	elseif state == WordTypeExtend.BUFF_ATK then
		local buff_id = args[1]
		if buff_id then
			local buff_cfg = self:GetBuffConfigBuId(buff_id)
			if buff_cfg and buff_cfg.group and buff_cfg.group[1] then
				local sprite_name = BUFF.SHOW_ATK_GROUP[buff_cfg.group[1]]
				if sprite_name then
					table.insert(list, {fromspriteid = fromid, spriteid = toid, state = state})
				end
			end
		end
	else
		table.insert(list, {fromspriteid = fromid, spriteid = toid, state = state})
	end	
	return list
end

function WordArtHandle:UpdateWord(position, tocamp, state, args)
	local value = args[1]
	local poolRender = nil
	local wordInfo = nil
	if self.wordPoolRenders[state] then
		poolRender = self.wordPoolRenders[state].poolRender
		wordInfo = self.wordPoolRenders[state].info
	end

	if poolRender and wordInfo then
		local worditem = poolRender:Get({originPos = position, offset = wordInfo.offset, scale = wordInfo.scale, dicY_offset = wordInfo.dicY_offset})
		worditem[wordInfo.InitFunc](worditem, self:GetLabel(state, value, wordInfo, tocamp), value)
		worditem[wordInfo.tweenFunc](worditem)
	end
end

function WordArtHandle:GetLabel(state, value, wordInfo, tocamp)
	local plus = value and tonumber(value) > 0
	--数值 状态
	if state == WordTypeExtend.Recover then
		value = self:GetValueStr(value)
		return value
	elseif state == WordTypeExtend.Hurt_Blue then
		--敌方
		value = self:GetValueStr(value)
		return value
	elseif state == WordTypeExtend.Hurt_Red then
		--我方
		value = self:GetValueStr(value)
		return value
	elseif state == WordTypeExtend.Crits then
		value = self:GetValueStr(value)
		return value
	elseif state == DAMAGE_STATE.MP then
		value = self:GetValueStr(value)	
		return 'I'..value
	elseif state == DAMAGE_STATE.SLD then
		local str = tonumber(value) > 0 and "I" or "B"
		if math.abs(value) > 100000000 then
			value = string.format("%s%sM", plus and "+" or "-", math.modf(math.abs(value) / 1000000))
		elseif math.abs(value) > 100000 then
			value = string.format("%s%sK", plus and "+" or "-", math.modf(math.abs(value) / 1000))
		end
		return str .. value
	elseif state == WordTypeExtend.KillNum then
		-- local str = HtmlUtil.Img("UIBattleFont.UIBattleFont_Jianti.Kill_"..math.floor(value))
		local str = string.format("Kill_%s", math.floor(value))
		return str
	elseif state == WordTypeExtend.BUFF_ATK then
		local buff_id = value
		if buff_id then
			local buff_cfg = self:GetBuffConfigBuId(buff_id)
			if buff_cfg and buff_cfg.group and buff_cfg.group[1] then
				local sprite_name = BUFF.SHOW_ATK_GROUP[buff_cfg.group[1]]
				if sprite_name then
					return sprite_name[tocamp]
				end
			end
		end
		return ""
	else
		--特殊状态, 区分敌我
		local str = ""
		if state == DAMAGE_STATE.KILL or state == DAMAGE_STATE.IMMUNE or --击杀--免疫--格挡--闪避
			state == WordTypeExtend.Block or state == DAMAGE_STATE.NOHIT or state == DAMAGE_STATE.CHARM then  
				str = string.format("%s%d", wordInfo.SpriteName, tocamp)
		end
		return str
	end
end

function WordArtHandle:GetValueStr(value)
	if math.abs(value) >= 100000000 then
		value = string.format("%sM", math.modf(math.abs(value) / 1000000))			
	elseif math.abs(value) >= 100000 then
		value = string.format("%sK", math.modf(math.abs(value) / 1000))
	else
		value = math.abs(value)
	end
	return value
end

function WordArtHandle:GetBuffConfigBuId(buff_id)
	local cfg = ConfigManager.GetConfig("buff_static")
	return cfg[buff_id]
end

return WordArtHandle
