ConfigManager.InitConfig('data_push', {
[10001]={id=10001,title="push_title_10001",type=1,subtype=1,time=-1,info_tips="push_info_10001"},
[10002]={id=10002,title="push_title_10002",type=1,subtype=2,time=-1,info_tips="push_info_10002"},
[20001]={id=20001,title="push_title_20001",type=3,subtype=1,time=43200,info_tips="push_info_20001"},
[20002]={id=20002,title="push_title_20002",type=3,subtype=2,time=86400,info_tips="push_info_20002"},
})