local Timer = require "Common.Util.Timer"
local Application = CS.UnityEngine.Application
local RuntimePlatform = CS.UnityEngine.RuntimePlatform
local IGGSdkProxy = IGGSdkProxy or BaseClass(BaseProxy)

require "Modules.IGGSdk.IGGSdkCallback"
local LoginProxy = require "Modules.Login.LoginProxy"

local cIGGSdkInterface = CS.LJY.NX.IGGSdkInterface

function IGGSdkProxy:__init()
    IGGSdkProxy.Instance = self
    self.data = {}
end

function IGGSdkProxy:__delete()
    IGGSdkProxy.Instance = nil
    self.data = nil
    if self.serverTimer then
        self.serverTimer:Stop()
        self.serverTimer = nil
    end
end

function IGGSdkProxy:StartMaintenaceTimer()
    self:ClearMaintenaceTimer()
    self.data.serverTime = SystemConfig.ServerTime
    self.serverTimer = Timer.New(function()
        self.data.serverTime = self.data.serverTime + 1
    end, 1, -1)
    self.serverTimer:Start()
end

function IGGSdkProxy:ClearMaintenaceTimer()
    if self.serverTimer then
        self.serverTimer:Stop()
        self.serverTimer = nil
    end
end

function IGGSdkProxy:RefreshAppconfig()
    -- local benter = self:check_enter_game()
    -- if benter then
    --     -- local iggid, accesskey = self.iggSession:GetIGGId(), self.iggSession:GetAccesskey()
    --     -- LoginProxy.Instance:start_get_account(iggid, accesskey)
    --     self:quick_login()
    -- end
    local cIGGSdkInterface = CS.LJY.NX.IGGSdkInterface
    cIGGSdkInterface.LoadUpdateAppconf()
end

--igg 快速登陸检测
function IGGSdkProxy:Quick_Login_Game()
    local benter = self:check_enter_game()
    if benter then
        self:quick_login()
    end
end

--igg 快速登陸
function IGGSdkProxy:quick_login()
    cIGGSdkInterface.QuickLogin()
end

-- session验证过期 处理
function IGGSdkProxy:invalidate_current_session()
    cIGGSdkInterface.InvalidateCurrentSession()
end

-- 设想玩家基础信息
function IGGSdkProxy:SetPlayerInfo(uin, nickname, level, server_id, server_line_id)

    local uin, player_name, player_level = uin, nickname or "", level or 1
    cIGGSdkInterface.SetPlayerInfo(uin, player_name, player_level)

    local server_id, server_line_id = server_id or 0, server_line_id or "0"
    cIGGSdkInterface.SetServerInfo(server_id, server_line_id)
end

--初始化商品信息 登录成功后调用
function IGGSdkProxy:Startup()
    cIGGSdkInterface.Startup()
end

--获取当前账号的限购情况
function IGGSdkProxy:GetPurchaseLimit()
    return cIGGSdkInterface.GetPurchaseLimit()
end

--购买或者订阅
function IGGSdkProxy:PayOrSubscribeTo(item, charId, serverId)
    return cIGGSdkInterface.PayOrSubscribeTo(item, charId, serverId)
end

function IGGSdkProxy:show_manager()
    cIGGSdkInterface.ShowManager()
end

function IGGSdkProxy:show_relogin(relogin_type)
    cIGGSdkInterface.ShowRelogin(relogin_type)
end

--白名单检查
function IGGSdkProxy:CheckWhiteIdList()
    local bWhiteId = false
    if not SystemConfig.AppConfig then
        return bWhiteId
    end
    local cur_client = SystemConfig.AppConfig.clientIp

    local logincfg = SystemConfig.AppConfig.rawString["LoginBox"]
    if logincfg then
        local whiteListStatus = logincfg["whiteListStatus"]
        local whiteListIp = logincfg["whiteListIp"]
        if whiteListStatus and whiteListIp then
            if whiteListStatus == "1" then
                local iplist = string.split(whiteListIp, ",")
                if iplist and next(iplist) then
                    for k, value in pairs(iplist) do
                        if value == cur_client then
                            bWhiteId = true
                            break
                        end
                    end
                end
            end
        end
    end
    return bWhiteId
end

--版本号检查
function IGGSdkProxy:CheckVersionNum(cfg_version, cur_Version)
    local bforce = false
    if cfg_version and cur_Version then
        local cfg_versionArgs = string.split(cfg_version .. ".", "%.")
        local cur_version_Args = string.split(cur_Version .. ".", "%.")
        for i = 1, math.max(#cfg_versionArgs, #cur_version_Args) do
            --local _cfg_Version, _cur_version = tonumber(cfg_VersionArgs[i]), tonumber(cur_version_Args[i])
            --if _cfg_Version and _cur_version and _cfg_Version > _cur_version then
            --    bforce = true
            --    break
            --end
            local _cfg_version = tonumber(cfg_versionArgs[i]) or 0
            local _cur_version = tonumber(cur_version_Args[i]) or 0
            if _cfg_version ~= _cur_version then
                return _cfg_version > _cur_version and true or false
            end
        end
    end
    return bforce
end

--是否提审
function IGGSdkProxy:CheckIsAuditVersion()
    local isAudit = false
    local logincfg = SystemConfig.AppConfig.rawString["LoginBox"]
    if logincfg then
        if logincfg['nextVersionCheck'] == "1" then -- 开启审核开关
            local nextVersion = logincfg["nextVersion"] -- 正在审核的版本
            if nextVersion and nextVersion ~= "" then
                isAudit = nextVersion == Application.version
            end
        end
    end
    return isAudit
end

--强更检查
function IGGSdkProxy:CheckVersion()
    local bforce, contentStr = false
    local logincfg = SystemConfig.AppConfig.rawString["LoginBox"]
    local messagecfg = SystemConfig.AppConfig.rawString["Messages"]
    if messagecfg and messagecfg["content"] then
        contentStr = messagecfg["content"]["forceUpdate"] or ""
    end
    if logincfg then
        local forceVersion = logincfg["forceVersion"]
        if forceVersion and forceVersion ~= "" then
            local version = Application.version
            bforce = self:CheckVersionNum(forceVersion, version)
        end
    end
    -- print("CheckVersion===", SystemConfig.ResVersion, Application.version, bforce, contentStr)
    return bforce, contentStr
end

--提更检查
function IGGSdkProxy:CheckRemindVersion()
    local bforce, maintenanceAwardNum = false, 0
    local logincfg = SystemConfig.AppConfig.rawString["LoginBox"]
    if logincfg then
        local _Version = logincfg["version"]
        maintenanceAwardNum = logincfg["maintenanceAwardNum"] or 0
        if _Version and _Version ~= "" then
            local version = Application.version
            bforce = self:CheckVersionNum(_Version, version)
        end
    end
    -- print("CheckRemindVersion======", bforce, maintenanceAwardNum)
    return bforce, maintenanceAwardNum

end

--登录公告[utc][0][/utc] ttttt [utc][1][/utc]
function IGGSdkProxy:CheckLoginNotice()
    local serverTime = SystemConfig.ServerTime
    local bshow, contentStr = false, ""

    local iggzone = -5
    local DateFormatUtil = require "Common.Util.DateFormatUtil"
    local logincfg = SystemConfig.AppConfig.rawString["LoginBox"]
    local messagecfg = SystemConfig.AppConfig.rawString["Messages"]

    if logincfg then
        if logincfg["showLoginPop"] and logincfg["showLoginPop"] ~= "0" then
            if logincfg["startTime"] and logincfg["startTime"] ~= "" and
                    logincfg["endTime"] and logincfg["endTime"] ~= "" then
                local startTimeStr = logincfg["startTime"]
                local endTimeStr = logincfg["endTime"]
                local endTime = DateFormatUtil.ZoneDate2TimeStamp(endTimeStr, iggzone)
                local startTime = DateFormatUtil.ZoneDate2TimeStamp(startTimeStr, iggzone)
                if serverTime >= startTime and serverTime < endTime then
                    if messagecfg and messagecfg["content"] then
                        contentStr = self:regmatchstr(messagecfg["content"].login, { { ["key"] = "utc", [0] = DateFormatUtil.changeLocalZonebyStr(startTimeStr, iggzone),
                                                                                       [1] = DateFormatUtil.changeLocalZonebyStr(endTimeStr, iggzone) } })
                    end
                    bshow = true
                end
            end
        end
    end
    -- print("CheckLoginNotice========", bshow, contentStr)
    return bshow, contentStr
end

--是否弹维护
function IGGSdkProxy:CheckShowMaintain()
    local bshow = false
    local contentStr = ""
    local timeLeft = 0

    local iggzone = -5
    local DateFormatUtil = require "Common.Util.DateFormatUtil"
    local updatecfg = SystemConfig.AppConfig.rawString["Update"]
    local logincfg = SystemConfig.AppConfig.rawString["LoginBox"]
    local messagecfg = SystemConfig.AppConfig.rawString["Messages"]

    local bMainTainIn = SystemConfig.AppConfig.MainTainIn.isMaintain
    local startTime = SystemConfig.AppConfig.MainTainIn.startTime
    local endTime = SystemConfig.AppConfig.MainTainIn.endTime
    local startTimeStr = SystemConfig.AppConfig.MainTainIn.startTimeStr
    local endTimeStr = SystemConfig.AppConfig.MainTainIn.endTimeStr

    if bMainTainIn and self.data.serverTime >= startTime and self.data.serverTime <= endTime then
        if messagecfg and messagecfg["content"] and messagecfg["content"]["maintain"] then
            contentStr = self:regmatchstr(messagecfg["content"]["maintain"], { { ["key"] = "utc", [0] = DateFormatUtil.changeLocalZonebyStr(startTimeStr, iggzone),
                                                                                 [1] = DateFormatUtil.changeLocalZonebyStr(endTimeStr, iggzone) } })
        end
        bshow = true
        timeLeft = endTime - self.data.serverTime
    end

    -- print("bshow, contentStr, timeLeft===", bshow, contentStr, timeLeft)
    return bshow, contentStr, timeLeft
end

function IGGSdkProxy:regmatchstr(str, args_list)
    for _, args in ipairs(args_list) do
        local left = "%[" .. args["key"] .. "]"
        local right = "%[/" .. args["key"] .. "]"
        local regkey = left .. "(%d+)" .. right
        for s in string.gmatch(str, regkey) do
            local key = left .. s .. right
            if tonumber(s) and args[tonumber(s)] then
                str = string.gsub(str, key, args[tonumber(s)])
            end
        end
    end
    return str
end

function IGGSdkProxy:check_enter_game()
    local benter = true

    if AppConfig.IsLoginCheck ~= nil and AppConfig.IsLoginCheck == false then
        return benter
    end

    --local isAudit = self:CheckIsAuditVersion()
    --SystemConfig.IsAuditVersion = isAudit

    -- local bWhiteId = self:CheckWhiteIdList()
    -- if bWhiteId then
    --     benter = true
    --     return benter
    -- end

    --local DateFormatUtil = require "Common.Util.DateFormatUtil"
    --local updatecfg = SystemConfig.AppConfig.rawString["Update"]
    --local logincfg = SystemConfig.AppConfig.rawString["LoginBox"]

    --提更
    local bnextVersion = self:CheckRemindVersion()
    if bnextVersion then
        LuaLayout.Instance:OpenWidget(UIWidgetNameDef.AnnouncementView)
        benter = false
        return benter
    end

    --公告
    local bnotice, loginContentStr = self:CheckLoginNotice()
    if bnotice then
        local LoginNoticeView = require "Modules.Login.LoginNoticeView"
        LoginNoticeView.Show(loginContentStr, function(bValue)
            --点击任何按钮都是 登录游戏
            self:quick_login()
            LuaLayout.Instance:CloseWidget(UIWidgetNameDef.LoginNoticeView)

        end, "LoginNoticeView_1001", "LoginNoticeView_1002")
        benter = false
        return benter
    end

    return benter
end

function IGGSdkProxy:GetRegistrationKey(iggid)
    local IGGSdkDef = require "Modules.IGGSdk.IGGSdkDef"
    local key = IGGSdkDef.RegistrationEventKey .. iggid
    return key
end
function IGGSdkProxy:GetRegistrationKeyValue(key)
    local value = PlayerPrefs.GetInt(key, 0)
    return value
end
function IGGSdkProxy:SetRegistrationKeyValue(key, value)
    PlayerPrefs.SetInt(key, value)
end

function IGGSdkProxy:RegistrationEvent(iggid)
    local key = self:GetRegistrationKey(iggid)
    local value = self:GetRegistrationKeyValue(key)
    if value == 0 then
        local IGGSdkDef = require "Modules.IGGSdk.IGGSdkDef"
        local rapidjson = require "rapidjson"
        local p = {
            [IGGSdkDef.SecondEventParam.CompleteRegistrationMethod] = "guest",
        }
        local json_str = rapidjson.encode(p)
        self:Track(IGGSdkDef.SecondEventName.CompleteRegistration, json_str)

        self:SetRegistrationKeyValue(key, 1)
    end
end

--快速登录成功
function IGGSdkProxy:OnLoginSuccess(iggSession)
    self.iggSession = iggSession
    self:Startup()
    self.iggid, self.accesskey = iggSession:GetIGGId(), iggSession:GetAccesskey()
    LoginProxy.Instance:start_get_account(self.iggid, self.accesskey)

    --注册事件
    --self:RegistrationEvent(self.iggid)
end

--快速登录失败
function IGGSdkProxy:OnLoginFail()
end

-- 账号禁止操作的处理（如：封号）弹窗处理
function IGGSdkProxy:OnAccountNotAllowOperation()
    -- print("OnAccountNotAllowOperation====================")
    -- GameLogicTools.ShowConfirmById(28, function(bvalue)
    -- 	if bvalue then
    -- 		Application.Quit()
    -- 	end
    -- end)
end

function IGGSdkProxy:sdk_igg_login_fail()
    if SystemConfig.isIGGPlatform() then
    end
end

--auth fail  登陆失败
function IGGSdkProxy:Sdk_Login_Auth_Fail(args)
    if SystemConfig.isIGGPlatform() then
        local IGGSdkDef = require "Modules.IGGSdk.IGGSdkDef"
        if args.reloginType == IGGSdkDef.ReloginType.Expire or
                args.reloginType == IGGSdkDef.ReloginType.Kick then
            self:ShowRelogin(args.reloginType)
        else
            Application.Quit()
        end
    end
end

function IGGSdkProxy:ShowRelogin(reloginType)
    -- print("IGGSdkProxy ShowRelogin=============>>", reloginType)
    local IGGSdkDef = require "Modules.IGGSdk.IGGSdkDef"
    if reloginType == IGGSdkDef.ReloginType.Expire or
            reloginType == IGGSdkDef.ReloginType.Kick then

        local parenWidget = LuaLayout.Instance:GetWidget(UIWidgetNameDef.Root_IGG)
        if parenWidget and parenWidget.go then
            local managerAccount = GameObjTools.GetChild(parenWidget.go, "AccountUIProfileManagementPanelYellowG")
            if managerAccount then
                managerAccount:SetActive(false)
            end
        end

        local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.LoginView)
        if view then
            view.bLoginType = false
            view:OpenView()
        end

        cIGGSdkInterface.ShowRelogin(reloginType)
    end
end

--游戏评分(留意一下igg预设之间的层级关系有没有错乱)
function IGGSdkProxy:ShowAppRating(useWebFeedback)
    if SystemConfig.isIGGPlatform() then
        cIGGSdkInterface.ShowAppRating(useWebFeedback)
    end
end

-- jsonStr: ""
function IGGSdkProxy:Track(name, jsonStr)
    -- print("IGGSdkProxy:Track", name)
    
    if SystemConfig.isIGGPlatform() then
        jsonStr = jsonStr or ""
        cIGGSdkInterface.Track(name, jsonStr)
    end
end

--账号管理
function IGGSdkProxy:ShowManager()

    if SystemConfig.isIGGPlatform() then
        cIGGSdkInterface.ShowManager()
    end
end

--获取虚拟货币
function IGGSdkProxy:SendEarnVirtualCurrency(currencyName, currency, value)
    if SystemConfig.isIGGPlatform() then
        cIGGSdkInterface.SendEarnVirtualCurrency(currencyName, currency, value)
    end
end

--消耗虚拟货币
function IGGSdkProxy:SendSpendVirtualCurrency(content, contentId, contentType, value, itemName)
    if SystemConfig.isIGGPlatform() then
        cIGGSdkInterface.SendSpendVirtualCurrency(content, contentId, contentType, value, itemName)
    end
end

--展示游戏协议列表
function IGGSdkProxy:ShowAssignedAgreements()
    if SystemConfig.isIGGPlatform() then
        cIGGSdkInterface.ShowAssignedAgreements()
    end
end

--展示游戏协议列表
function IGGSdkProxy:IntendToTerminate()
    if SystemConfig.isIGGPlatform() then
        cIGGSdkInterface.IntendToTerminate()
    end
end

--请求所有配置的游戏协议, 结果通过callbak返回
function IGGSdkProxy:RequestAssignedAgreements()
    if SystemConfig.isIGGPlatform() then
        cIGGSdkInterface.RequestAssignedAgreements()
    end
end

--提交问题
function IGGSdkProxy:OpenTicket()
    if SystemConfig.isIGGPlatform() then
        cIGGSdkInterface.OpenTicket()
    end
end

--终止已签署的协议列表
function IGGSdkProxy:IntendToTerminate()

    if SystemConfig.isIGGPlatform() then
        cIGGSdkInterface.IntendToTerminate()
    end
end

function IGGSdkProxy:ShowUniWebView(uri)
    if uri == "" then
        return
    end
    if SystemConfig.isIGGPlatform() then
        local UniWebView = require "Modules.Common.Msg.UniWebView"
        UniWebView.ShowUniWebView(uri)
    end
end

--打开TSH
function IGGSdkProxy:OpenTSH()
    if SystemConfig.isIGGPlatform() then
        cIGGSdkInterface.OpenTSH()
    end
end

function IGGSdkProxy:InformAsap()
    if SystemConfig.isIGGPlatform() then
        cIGGSdkInterface.InformAsap()
    end
end

function IGGSdkProxy:InformKindly()
    if SystemConfig.isIGGPlatform() then
        cIGGSdkInterface.InformKindly()
    end
end

--打开TSH弹窗
function IGGSdkProxy:ShowTSHPanel()
    if SystemConfig.isIGGPlatform() then
        cIGGSdkInterface.ShowTSHPanel()
    end
end

---sourceLanuage 源语言类型 可传null
---targetLanguage 翻译目标语言类型 一定要传！！！ IGGSdkDef.Language_Code
---inputText 需要翻译的文字内容
function IGGSdkProxy:TranslateText(sourceLanuage, targetLanguage, inputText)
    if SystemConfig.isIGGPlatform() then
        print("-------TranslateText-------",inputText)
        cIGGSdkInterface.TranslateText(sourceLanuage, targetLanguage, inputText)
    end
end


--举报
function IGGSdkProxy:Report(iggid, nickname, content) --string
    if SystemConfig.isIGGPlatform() then
        cIGGSdkInterface.Report(iggid, nickname, content)
    end
end

function IGGSdkProxy:FacebookShareLink(url, contentTitle, contentDescription, pictureurl)
    if SystemConfig.isIGGPlatform() then
        url = SystemConfig.AppConfig.rawString.PageLink.download
        if not string.isEmpty(url) then
            local LanguageUtil = require "First.Util.LanguageUtil"
            local gameid = LanguageUtil.GetLanguageGameId()
            url = string.format(url, gameid)
        else
            url = "https://play.google.com/store/apps/details?id=com.igg.android.rageofdestiny"
            if Application.platform == RuntimePlatform.Android then
                url = "https://play.google.com/store/apps/details?id=com.igg.android.rageofdestiny"
            elseif Application.platform == RuntimePlatform.IPhonePlayer then
                url = "https://apps.apple.com/us/app/rage-of-destiny/id1549142434"
            end
        end

        contentTitle = ""
        contentDescription = ""
        pictureurl = ""
        --Application.OpenURL(url)
        cIGGSdkInterface.FacebookShareLink(url, contentTitle, contentDescription, pictureurl)
    end
end

function IGGSdkProxy:RequestSSOTokenForWeb(tag)
    if SystemConfig.isIGGPlatform() then
        cIGGSdkInterface.RequestSSOTokenForWeb(tag)
    end
end

function IGGSdkProxy:GetSSOToken()
    if SystemConfig.isIGGPlatform() then
        return cIGGSdkInterface.GetSSOToken()
    end
    return ""
end

--加入公会事件
function IGGSdkProxy:SendJoinGroup(guild_id)
    if SystemConfig.isIGGPlatform() then
        cIGGSdkInterface.SendJoinGroup(tostring(guild_id))
    end
end

--升级事件
function IGGSdkProxy:SendLevelUp(character, level)
    if SystemConfig.isIGGPlatform() then
        cIGGSdkInterface.SendLevelUp(character, level)
    end
end

--引导开始事件
function IGGSdkProxy:SendTutorialBegin()
    if SystemConfig.isIGGPlatform() then
        cIGGSdkInterface.SendTutorialBegin()
    end
end

--引导结束事件
function IGGSdkProxy:SendTutorialComplete(content, contentId, success)
    if SystemConfig.isIGGPlatform() then
        cIGGSdkInterface.SendTutorialComplete(content, contentId, success)
    end
end

return IGGSdkProxy