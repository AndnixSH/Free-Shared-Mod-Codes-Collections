local base_sprite_model = require "Battle.render.model.base_sprite_model"
local monster_sprite_model = BaseClass(base_sprite_model)

local cMonsterSpriteModel = CS.LJY.NX.MonsterSpriteModel

function monster_sprite_model:__init(anchor, model_name)
    self.anchor = anchor
    self.cmodel = cMonsterSpriteModel(anchor.canchor, model_name)
end

return monster_sprite_model