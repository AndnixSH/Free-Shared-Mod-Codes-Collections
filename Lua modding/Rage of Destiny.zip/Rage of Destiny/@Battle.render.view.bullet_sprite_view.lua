local sprite_view_class = require "Battle.render.view.base_sprite_view"

local effect_sprite_model = require "Battle.render.model.effect_sprite_model"
local tail_effect_sprite_model = require "Battle.render.model.tail_effect_sprite_model"
--local sprite_center_anchor = require "Battle.render.anchor.sprite_center_anchor"
local sprite_follow_anchor = require "Battle.render.anchor.sprite_follow_anchor"
local render_camera = require "Battle.render.camera.render_camera"

local bullet_sprite_view = sprite_view_class()
local active_config = faceConfig["data_active"]

function bullet_sprite_view:__init()
end

function bullet_sprite_view:create()
    local data = global.service.readonly:reader(self.sprite_id)
    if not data or not data.body then
        print("the bullet sprite_id data is nil", self.sprite_id)
        return
    end

    local body_anchor = sprite_follow_anchor.New(self.sprite_id)
    if data.body.has_tail then
        self.body = tail_effect_sprite_model.New(body_anchor, data.body.prefab_id[1])
    else
        self.body = effect_sprite_model.New(body_anchor, data.body.prefab_id[1])
    end

    if data.body.tailing_id and data.body.tailing_id[1] then
        local view_manager = require "Battle.render.view_manager"
        view_manager.on_bullet_tail(data.body.tailing_id[1], self.sprite_id)
    end

    self.is_show = true
end

function bullet_sprite_view:release()
    if self.body then
        self.body:release()
        self.body:DeleteMe()
        self.body = nil
    end
    self.is_show = false
end

function bullet_sprite_view:show()
    if self.is_show then
        return
    end

    if self.body then
        self.body:show_model()
    end
    self.is_show = true
end

function bullet_sprite_view:hide()
    if not self.is_show then
        return
    end

    if self.body then
        self.body:hide_model()
    end
    self.is_show = false
end

function bullet_sprite_view.event.sprite:start_active(active_name, speed, tag)
    local view_manager = require "Battle.render.view_manager"
    if not view_manager.show_active then
        return
    end

    local bullet_active_info = active_config[tostring(self.config_id)]
    if not bullet_active_info then
        return
    end

    if not bullet_active_info[active_name] then
        return
    end

    speed = speed and speed / 1000 or 1
    tag = tag or 0
    if not self.body then
        return
    end

    if self.active_name ~= active_name then
        self.body:start_active(string.format("%s_%s", self.config_id, active_name), speed * self.global_speed, tag)
        self.active_name = active_name
        self.active_speed = speed
    end
end

function bullet_sprite_view.event.sprite:camera_active(params)
    if params then
        render_camera.shake_camera_strategy(params)
    end
end

function bullet_sprite_view:speed_active()
    if self.body and self.active_name then
        --self.body:set_active_speed(self.global_speed * self.active_speed)
    end
end

return bullet_sprite_view

