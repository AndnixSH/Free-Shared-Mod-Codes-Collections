local input_record = {}
local _record = {}

function input_record.start()
    _record = {}
end

function input_record.dispose()
    _record = {}
end

function input_record.add(inputid)
    local f = global.service.time.frame
    table.insert(_record, {frame = f, inputid = inputid})
end

function input_record.serialize()
    local encoder = NetEncoder.New()
    encoder:Encode("I2", #_record)
    for i, record in ipairs(_record) do
        encoder:Encode("I4I1", record.frame, record.inputid)
    end
    -- print("serialize", table.dump(_record), encoder.buffer)
    return encoder.buffer
end


return input_record