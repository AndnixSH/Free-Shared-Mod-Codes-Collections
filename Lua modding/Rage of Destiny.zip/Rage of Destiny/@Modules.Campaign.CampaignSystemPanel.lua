local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"
local MainDef = require "Modules.Main.MainDef"
local TerritoryProxy = require "Modules.Territory.TerritoryProxy"
local NewbieWidget = require "Core.Implement.UI.Widgets.NewbieWidget"
local CampaignSystemPanel = CampaignSystemPanel or BaseClass(GameObjFactor, TimerFactor, NewbieWidget)
function CampaignSystemPanel:__init(go)
	self.go = go
	self:Load(go)	
end
function CampaignSystemPanel:Load(obj)	
	self.rect = self:GetComponent(obj, "RectTransform")
	self.rectPosition = self.rect.anchoredPosition	

	self.heroBtn = self:GetChildComponent(obj, "CHorizontalItem/item3", "CButton")
	self.heroRedDot = self:GetChild(self.heroBtn.gameObject, "CSprite_redpoint")
	self.heroBtn:AddClick(function ()		
		self:OnClickHero()
		self:OnTriggerClickBtn(self.heroBtn)
	end)

	self.outdoorsBtn = self:GetChildComponent(obj, "CHorizontalItem/item2", "CButton")
	self.outdoorsBtn.gameObject:SetActive(false)
	self.outdoorsBtn:AddClick(function ()		
		-- GameLogicTools.ShowMsgTips(self:GetWord("Common_1033"))
		UIOperateManager.Instance:OpenWidget(AppFacade.Maze)
	end)

	self.territoryBtn = self:GetChildComponent(obj, "CHorizontalItem/item1", "CButton")
	self.territoryRed = self:GetChild(self.territoryBtn.gameObject, "CSprite_redpoint")
	self.territoryRed:SetActive(false)
	self.territoryBtn:AddClick(function ()
		self:OpenTerritorView()
	end)
	
	self.mainBtn = self:GetChildComponent(obj, "CHorizontalItem/item4", "CButton")
	self.mainBtn:AddClick(function ()
		self:CloseTerritorView()
		self:OnTriggerClickBtn(self.mainBtn)
		-- self:SetMainBtnDepth(0)
	end)


	self.btnbackObj_1 = self:GetChild(self.heroBtn.gameObject, "CSprite_black")
	self.btnbackObj_2 = self:GetChild(self.outdoorsBtn.gameObject, "CSprite_black")
	self.btnbackObj_3 = self:GetChild(self.territoryBtn.gameObject, "CSprite_black")
	self.btnbackObj_4 = self:GetChild(self.mainBtn.gameObject, "CSprite_black")

	self.btnGrays = {}
	self.grayObj1 = self:GetChild(obj, "CHorizontalItem/item1/CSprite_gray1")
	self.grayObj2 = self:GetChild(obj, "CHorizontalItem/item2/CSprite_gray2")
	self.grayObj3 = self:GetChild(obj, "CHorizontalItem/item3/CSprite_gray3")
	self.grayObj4 = self:GetChild(obj, "CHorizontalItem/item4/CSprite_gray4")
	table.insert(self.btnGrays, self.grayObj1)
	table.insert(self.btnGrays, self.grayObj2)
	table.insert(self.btnGrays, self.grayObj3)
	table.insert(self.btnGrays, self.grayObj4)

	self.btnParents = {}
	table.insert(self.btnParents, self.territoryBtn.gameObject) --领地
	table.insert(self.btnParents, self.outdoorsBtn.gameObject)  --迷宫
	table.insert(self.btnParents, self.heroBtn.gameObject)  --英雄
	table.insert(self.btnParents, self.mainBtn.gameObject)  --战役

	self.btnEffectNames = {
		"UI_Campaign_castle", --领地
		"UI_Campaign_darkforest",  --迷宫
		"UI_Campaign_hero",  --英雄
		"UI_Campaign_campaign",  --战役
	}

	self.btnEffects = {}
end

function CampaignSystemPanel:CloseTerritorView()
	TerritoryProxy.Instance:SetTerritoryOpenState(false)
	LuaLayout.Instance:CloseWidget(UIWidgetNameDef.TerritoryView)
	self.territoryBtn.gameObject:SetActive(true)
	local view= LuaLayout.Instance:GetWidget(UIWidgetNameDef.CampaignView)
	if view then
		view:SetMiddleAndLeftObjShowState(true)
	end
	local AudioManager = require "Common.Mgr.Audio.AudioManager"
	AudioManager.PlayBGM("main_bg")
end

function CampaignSystemPanel:OpenTerritorView()
	local ModuleManager = require "Common.Mgr.UI.ModuleManager"
	local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
	local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.TerritoryView)
	if bopen then
		TerritoryProxy.Instance:SetTerritoryOpenState(true,UIWidgetNameDef.TerritoryView)
		self:OnTriggerClickBtn(self.territoryBtn)		
	end
end

function CampaignSystemPanel:UpdateDepth(depth)
	local nextdepth = depth
	for i,_effect in ipairs(self.btnEffects) do
		_effect:SetOrderLayer(nextdepth)
		_effect:SetOrderLayer(nextdepth)
		_effect:SetOrderLayer(nextdepth)
		_effect:SetOrderLayer(nextdepth)
	end
	
	nextdepth = nextdepth+2
	self:SetDepth(self.btnbackObj_4, nextdepth)
	self:SetDepth(self.btnbackObj_1, nextdepth)
	self:SetDepth(self.btnbackObj_2, nextdepth)
	self:SetDepth(self.btnbackObj_3, nextdepth)

	self:SetSystemRedDotDepth(nextdepth)
end

function CampaignSystemPanel:SetMainBtnShowState(showMainBtn)
	if showMainBtn then
		self.mainBtn.gameObject:SetActive(true)
		self.territoryBtn.gameObject:SetActive(false)
		self:RegisterMainBtn()
	else
		self.mainBtn.gameObject:SetActive(false)
		self.territoryBtn.gameObject:SetActive(true)
		self:SetTerritoryRedDot()
	end
	if not showMainBtn then
		self:RegisterNewbieData()
	end
end

--注册引导数据
function CampaignSystemPanel:RegisterNewbieData()
	local mainlineid = RoleInfoModel.mainlineid
	local NewbieManager = require "Modules.Newbie.NewbieManager"

	self:RegisterButton(self.heroBtn, 10005, 1)

	local cfg1 = NewbieManager.Instance:GetNewbieStepConfig(10006, 1) --主线1-13引导点击领地 按钮
	if cfg1 and cfg1.parama.mainlineid and cfg1.parama.mainlineid == mainlineid then
		self:RegisterButton(self.territoryBtn, 10006, 1)
	end

	local cfg2 = NewbieManager.Instance:GetNewbieStepConfig(10007, 1) --主线2-4引导点击领地 按钮
	if cfg2 and cfg2.parama.mainlineid and cfg2.parama.mainlineid == mainlineid then
		self:RegisterButton(self.territoryBtn, 10007, 1)
	end	
end

--添加点击战役引导
function CampaignSystemPanel:RegisterMainBtn()
	local NewbieManager = require "Modules.Newbie.NewbieManager"
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	local cur_newbie_id, cur_newbie_step = NewbieManager.Instance:GetCurNewbieId()
	if cur_newbie_id == 10006 and cur_newbie_step == 6 then
		self:RegisterButton(self.mainBtn, 10006, 6)
		if self.delaytimer1 then
			self:RemoveTimer(self.delaytimer1)
			self.delaytimer1 = nil
		end
		self.delaytimer1 = self:AddTimer(function( ... )
			self:SetMainBtnDepth(NewbieDef.NewbieDepths.NewbieBtn+1)
		end, 0.5, 1)
	end
end

function CampaignSystemPanel:SetMainBtnDepth(depth)
	local NewbieManager = require "Modules.Newbie.NewbieManager"
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	local cur_newbie_id, cur_newbie_step = NewbieManager.Instance:GetCurNewbieId()
	if cur_newbie_id == 10006 and cur_newbie_step == 6 then
		self:SetDepth(self.mainBtn.gameObject,  depth)
	end
end

function CampaignSystemPanel:DelayRegisterNewbieData()
	self:ClearNewbieTimer()
	self.delaytimer = self:AddTimer(function()
		if self.territoryBtn.gameObject.activeSelf == true then
			self:RegisterNewbieData()
		elseif self.mainBtn.gameObject.activeSelf == true then
			self:RegisterMainBtn()
		end
	end, 0.4, 1)
end

function CampaignSystemPanel:ClearNewbieTimer()
	if self.delaytimer then
		self:RemoveTimer(self.delaytimer)
		self.delaytimer = nil
	end
	if self.delaytimer1 then
		self:RemoveTimer(self.delaytimer1)
		self.delaytimer1 = nil
	end
end

function CampaignSystemPanel:Open()
	self:DelayRegisterNewbieData()

	self:ShowSystemBtnGray()

	self:StartOpenTween()
	local depth = self:GetNextDepth()
	self:SetDepth(self.btnbackObj_1, depth)
	self:SetDepth(self.btnbackObj_2, depth)
	self:SetDepth(self.btnbackObj_3, depth)
	
	
	self:SetSystemRedDotDepth(depth)

	self:ShowBtnTween()

	local depth2 = self:GetNextDepth()
	self:SetDepth(self.btnbackObj_4, depth2)
	if self.btnEffects[4] then
		self.btnEffects[4]:SetOrderLayer(depth)
	end

	local MazeProxy = require "Modules.Maze.MazeProxy"
	local bshow = MazeProxy.Instance:GetMazeCacheRedDot2()
	if bshow then
		MazeProxy.Instance:GetMapLevelInfo()
	end

	local TowerProxy = require "Modules.Tower.TowerProxy"
	local bshow = TowerProxy.Instance:GetTowerRedDotStatus()
	if bshow then
		TowerProxy.Instance:Send52000()
	end

	self:SetTerritoryRedDot()
end

function CampaignSystemPanel:SetSystemRedDotDepth(depth)
	self:SetDepth(self.heroRedDot, depth)
	self:SetDepth(self.territoryRed, depth)
	UILayerTool.UpdateCanvases()
end

--设置迷宫红点状态
function CampaignSystemPanel:SetTerritoryMazeRedDotStatus()
	local MazeProxy = require "Modules.Maze.MazeProxy"
	local bactive = MazeProxy.Instance:GetMazeRedDot2()
	if not bactive then
		MazeProxy.Instance:SetMazeCacheRedDot2(false)
	end

	self:SetTerritoryRedDot()
end

--设置爬塔红点状态
function CampaignSystemPanel:SetTerritoryTowerRedDotStatus()
	local TowerProxy = require "Modules.Tower.TowerProxy"
	local bactive = TowerProxy.Instance:GetTowerRedDot()
	if not bactive then
		TowerProxy.Instance:SetTowerRedDotStatus(false)
	end

	self:SetTerritoryRedDot()

end

function CampaignSystemPanel:SetTerritoryRedDot()
	local redDotCount = TerritoryProxy.Instance:GetRootRedDot()
	self.territoryRed:SetActive(redDotCount > 0 and true or false)
end

function CampaignSystemPanel:ShowSystemBtnGray()
	local ModuleManager = require "Common.Mgr.UI.ModuleManager"
	local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
	local gray1 = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.TerritoryView, false)  --领地
	local gray2 = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.MazeView, false)  --迷宫
	local gray3 = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.HeroRootView, false)  --英雄图标
	local gray4 = true

	self.bOpens = {}
	table.insert(self.bOpens, gray1)
	table.insert(self.bOpens, gray2)
	table.insert(self.bOpens, gray3)
	table.insert(self.bOpens, gray4)
	for i,bOpen in ipairs(self.bOpens) do
		if bOpen then
			if self.btnEffects[i] then
				self.btnEffects[i]:Destroy()
				self.btnEffects[i] = nil
			end
			local btnEffect = UIEffectItem.New(self.btnEffectNames[i], self.btnParents[i])
			self.btnEffects[i] = btnEffect
			self.btnEffects[i]:Open()
		else
			if self.btnEffects[i] then
				self.btnEffects[i]:Destroy()
				self.btnEffects[i] = nil
			end
		end

		self.btnGrays[i]:SetActive(self.bOpens[i] == false and true or false)
	end
end

function CampaignSystemPanel:Close()
	if self.opensequence then
		self.opensequence:Kill()
		self.opensequence = nil
	end		

	self:CloseAllTimer()
	for i,_effect in ipairs(self.btnEffects) do
		_effect:Close()
	end
	self:ClearNewbieTimer()
end	

function CampaignSystemPanel:Destroy()
	self:CloseAllTimer()
	for i,_effect in ipairs(self.btnEffects) do
		_effect:Destroy()
	end
	self.btnEffects = nil
	self:ClearNewbieTimer()
end

function CampaignSystemPanel:StartOpenTween()	
	self.rect.anchoredPosition = Vector2.New(self.rectPosition.x, self.rectPosition.y - 100)
	local tween1 = self.rect:DOAnchorPosY(self.rectPosition.y + 10, 0.2)
	local tween2 = self.rect:DOAnchorPosY(self.rectPosition.y, 0.2)

	local sequence = DOTween.Sequence()
	sequence:Append(tween1)
	sequence:Append(tween2)
	self.opensequence = sequence
end

function CampaignSystemPanel:ShowBtnTween()
	self.selectidx = 1
	self:AddTimer(function ()
		local selectidx = self.selectidx + 1
		if selectidx > 3 then
			selectidx = 1
		end
		if self.bOpens[selectidx] and self.btnEffects[i] then
			self.btnEffects:ResetPlay()
		end
		self.selectidx = selectidx
	end,10)
end

function CampaignSystemPanel:ShowRedDot(type, num)
	if type == MainDef.MainRedDotType.Hero then
		if self.bOpens[3] then
			self.heroRedDot:SetActive(num>0 and true or false)
		end
	end
end

--onclick
function CampaignSystemPanel:OnClickHero()
	UIOperateManager.Instance:OpenWidget(AppFacade.Hero, 8)
	-- LuaLayout.Instance:OpenWidget(UIWidgetNameDef.HeroRootView)
end

return CampaignSystemPanel