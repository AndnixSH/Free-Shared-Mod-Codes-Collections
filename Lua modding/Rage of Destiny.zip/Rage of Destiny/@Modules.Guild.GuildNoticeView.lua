
local GuildProxy = require "Modules.Guild.GuildProxy"
local GuildDef = require "Modules.Guild.GuildDef"

local WordFilter=require "Common.Util.WordFilter"

local GuildNoticeView = GuildNoticeView or LuaWidgetClass()

function GuildNoticeView:__init()
	self.tweenOption = {bScale = true}
end

function GuildNoticeView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Guild.GuildNoticeView", self.LoadEnd)
end

function GuildNoticeView:LoadEnd(obj)
	self:SetGo(obj)
	self:InitUI()
	self:SetStep(0)
end

function GuildNoticeView:InitUI()
	self.closeBtn = self:GetChildComponent(self.go, "root/content/close", "CButton")
	self.closeBtn:AddClick(function()
		self:CloseView()
	end)

	self.cancelBtn = self:GetChildComponent(self.go, "root/content/cancel", "CButton")
	self.cancelBtn:AddClick(function()
		self:CloseView()
	end)

	self.confirmBtn = self:GetChildComponent(self.go, "root/content/confirm", "CButton")
	self.confirmBtn:AddClick(function()
		local checkNameResult = GuildProxy.Instance:CheckContentInput(self.textInput.text, GuildDef.ContentInputType.GuildNoticeType)
		if checkNameResult == 0 then
			GuildProxy.Instance:Send70011(self.textInput.text)
			self:CloseView()
		else
		end	
	end)

	self.textInput = self:GetChildComponent(self.go, "root/content/notice/CInput_Notice", "CTextInput")
	self.textInput:AddChange(function(value)
		local str = value
		local bmask, replace_str = WordFilter.checkNameMaskWords(value)
		if bmask then
			str = replace_str
		end
		local lenth, content = GameLogicTools.CheckContentLength(str, GuildDef.Parama.Guild_Notice_Max_Char)
		self.textInput.text = content
	end)
	self.originPos = self.go.transform.localPosition
	self.offsetHeigh = -88
	self.highestY = self.originPos.y
	self.bResetPox = false

end

function GuildNoticeView:OnClose()
	self:EndFrame()
end

function GuildNoticeView:OnDestroy()
	self:EndFrame()
end
--notice
function GuildNoticeView:OnOpen()
	self.highestY = self.originPos.y
	self.bResetPox = false

	self.textInput.text = self.notice or ""
	self:StartFrame()
end

function GuildNoticeView:FrameUpdate()
    local isEditor = Application.isEditor
    if not isEditor then
        local curPosY = GameLogicTools.AdjustObjPosY(self.go, self.originPos, self.offsetHeigh, self.textInput.isFocused, self.bResetPox)
    	if curPosY > self.highestY then
    		self.highestY = curPosY
    	end
    	self.bResetPox = (curPosY < self.highestY) and true or false    
    end
end

return GuildNoticeView