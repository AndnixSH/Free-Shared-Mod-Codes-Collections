local base_game_view = BaseClass()

function base_game_view:__init(game_info)
    self.game_info = game_info
    self.game_id = game_info.gameid

    self.is_show = true
    self.hit_model = {}

    local render_area = require "Battle.render.render_area"
    self.global_speed = render_area.global_speed
    local gameobj = global.service.area:getgameobj()

    if GameConfig.RENDER_ENABLE then
        global.service.eventslots:load(self.event, self, gameobj, "view")
    end
end

function base_game_view:__delete()
    self.hit_model = nil
    global.service.eventslots:unload(self.event, self)
end

function base_game_view:show()
    self.is_show = true
end

function base_game_view:hide()
    self.is_show = false
end

-- hittable {key,hitid,tag,reset}
function base_game_view:on_skill_hit(hittable, position, header, height)
    local view_manager = require "Battle.render.view_manager"
    if not view_manager.show_active then
        return
    end
    local empty_active_model = require "Battle.render.model.empty_active_model"
    local simple_anchor = require "Battle.render.anchor.simple_anchor"

    local anchor = simple_anchor.New(position.x / 1000, height / 1000, position.y / 1000, header.x, header.y)

    local key = hittable.key
    self.hit_model[key] = empty_active_model.New(anchor)
    local hitid, tag = hittable.hitid, hittable.tag
    self.hit_model[key]:start_active(string.format("%s_hit", hitid), self.global_speed, tag, function()
        self.hit_model[key]:release()
        self.hit_model[key]:DeleteMe()
        self.hit_model[key] = nil
    end)
    if hittable.reset then
        self.hit_model[key]:set_layer(LAYERS.EFFECT)
    end
end

function base_game_view:on_reset_hit()
    if self.hit_model then
        for _, v in pairs(self.hit_model) do
            if v.reset_layer then
                v:reset_layer()
            end
        end
    end
end

function base_game_view:on_bullet_tail(tail_id, sprite_id)
    local view_manager = require "Battle.render.view_manager"
    if not view_manager.show_active then
        return
    end
    local empty_active_model = require "Battle.render.model.empty_active_model"
    --local sprite_frame_anchor = require "Battle.render.anchor.sprite_frame_anchor"
    local bullet_tail_anchor = require "Battle.render.anchor.bullet_tail_anchor"

    local anchor = bullet_tail_anchor.New(sprite_id)
    local model = empty_active_model.New(anchor)
    model:start_active(string.format("%s_tail", tail_id), self.global_speed, 0, function()
        model:release()
        model:DeleteMe()
    end)
end

local dynamictable = nil 
dynamictable = function (t)
    return setmetatable(t or {},
        {
            __index = function(t, k)
                if not rawget(t, k) then
                    rawset(t, k, dynamictable())
                    return rawget(t, k)
                end
                return rawget(t, k)
            end
        }
    )
end

local base_game_view_class = function(...)
    local class = BaseClass(base_game_view, ...)
    class.event = dynamictable()
    return class
end

return base_game_view_class