local RankListDef = {}

RankListDef.NotifyDef = {
   Update_RankEntrance = "Update_RankEntrance",
   Update_RankList = "Update_RankList",
   Update_RewardList = "Update_RewardList",
   UpdateTitleName="UpdateTitleName"
}

RankListDef.CommonDef={
    
    EmptyHead_NickName="RankListDef_1001",
    Tower_Layer="RankListDef_1002",
    NoRank="RankListDef_1003",
    NoReach="RankListDef_1004",
    NoChallage="RankListDef_1005",
    NoReward="RankListDef_1006",
    
}
RankListDef.RewardTips={
    
    [101] = "RankListDef_1015",
    [102] = "RankListDef_1016",
    [103] = "RankListDef_1017",
    [104] = "RankListDef_1018",
    [200] = "RankListDef_1019",
    [300] = "RankListDef_1020",
}

RankListDef.TitleName={
    [101] = "RankListDef_1007",
    [102] = "RankListDef_1009",
    [103] = "RankListDef_1008",
    [104] = "RankListDef_1010",
    [200] = "RankListDef_1011",
    [300] = "RankListDef_1012",
}

RankListDef.Btn={
    [1] = "RankListDef_1013",
    [2] = "RankListDef_1014",
}
RankListDef.BtnIconSprName={
    [1] = "bangdan",
    [2] = "jiangli",
}
RankListDef.RankType={
    lightbearers_ladder = 1,-- 圣光
    maulers_ladder = 2,-- 蛮荒
    wilders_laddder = 3,-- 自然
    graveborn_ladder = 4,-- 暗影
    stage_progression_ladder = 5,
    tower_progression_ladder = 6,
    tower_progression_ladder_1 = 7,
    tower_progression_ladder_2 = 8,
    tower_progression_ladder_3 = 9,
    tower_progression_ladder_4 = 10,
}

RankListDef.RankTypeID={
    [1] = 101,
    [2] = 102,
    [3] = 103,
    [4] = 104,
    [5] = 200,
    [6] = 300,
    [7] = 301,
    [8] = 302,
    [9] = 303,
    [10] = 304,
}

RankListDef.BgName={
    [1] = "Tex_Herotips_race1",
    [2] = "Tex_Herotips_race2",
    [3] = "Tex_Herotips_race3",
    [4] = "Tex_Herotips_race4",
    [5] = "Tex_Rank_mainline",
    [6] = "Tex_Rank_tower",
}
RankListDef.TexName={
    [1] = "1111011",
    [2] = "1122011",
    [3] = "1132031",
    [4] = "1143011",
    [5] = "1111031",
    [6] = "1141011",
}

RankListDef.heroTexPos={
    [1] = {pos=Vector3.New(507.1,-45.7,0),rotate=Vector3.New(0,0,0),scale=Vector3.New(0.9,0.9,0.9)},
    [2] = {pos=Vector3.New(548,-20.2,0),rotate=Vector3.New(0,0,0),scale=Vector3.New(0.7,0.7,0.7)},
    [3] = {pos=Vector3.New(479,-84,0),rotate=Vector3.New(0,0,0),scale=Vector3.New(0.9,0.9,0.9)},
    [4] = {pos=Vector3.New(528,-59,0),rotate=Vector3.New(0,180,0),scale=Vector3.New(0.8,0.8,0.8)},
    [5] = {pos=Vector3.New(576.4,-61.5,0),rotate=Vector3.New(0,180,0),scale=Vector3.New(0.7,0.7,0.7)},
    [6] = {pos=Vector3.New(493.5,-17.83,0),rotate=Vector3.New(0,0,0),scale=Vector3.New(0.7,0.7,0.7)},
}

RankListDef.Reward_State={
   HasGet = 0 ,
   UnGet = 1,
   CanNotGet = 2,
}
return RankListDef