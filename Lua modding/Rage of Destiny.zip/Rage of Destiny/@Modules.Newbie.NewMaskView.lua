local NewbieDef = require "Modules.Newbie.NewbieDef"
local NewMaskView = NewMaskView or LuaWidgetClass()

function NewMaskView:__init()
	
end


function NewMaskView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Newbie.NewMaskView", self.LoadEnd)
end

function NewMaskView:LoadEnd(obj)
	self:SetGo(obj)

	self:SetStep(0)
end

function NewMaskView:OnOpen()
	self.go:SetActive(true)
	
	self:SetDepth(self.go, NewbieDef.NewbieDepths.NewbieMask)

	self:AutoTimerClose()
end

function NewMaskView:AutoTimerClose()
	self:ClearCloseTimer()
	local delayTime = 1
	self.closeTimer = self:AddTimer(function( ... )
		self:CloseView()
	end, delayTime, 1)
end

function NewMaskView:ClearCloseTimer()
	if self.closeTimer then
		self:RemoveTimer(self.closeTimer)
		self.closeTimer = nil
	end
end

function NewMaskView:OnClose()
	self:ClearCloseTimer()
end

function NewMaskView:OnDestroy()
	self:ClearCloseTimer()
end

return NewMaskView