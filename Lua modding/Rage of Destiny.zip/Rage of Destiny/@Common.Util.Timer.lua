-- 定时器
local Timer = Timer or BaseClass()

local TimerMgr = require "Common.Mgr.TimerMgr"

local Time = Time

function Timer:__init(func, duration, loop, scale)
	self:Reset(func, duration, loop, scale)
end

function Timer:Reset(func, duration, loop, scale)
	self.duration = duration
	self.loop = loop or 1
	self.scale = scale
	self.func = func
	self.time = duration
	self.running = false
	self.count = Time.frameCount + 1
end

function Timer:Start(pre_timer)
	self.time = pre_timer or self.duration
	self.running = true
	TimerMgr.Add(self)
end

function Timer:IsRunning()
	return self.running
end

function Timer:Stop()
	self.running = false
	TimerMgr.Remove(self)
end

function Timer:Update()
	if not self.running then
		return
	end
	local delta = self.scale and Time.deltaTime or Time.unscaledDeltaTime
	self.time = self.time - delta

	if self.time <= 0 and Time.frameCount > self.count then
		self.func()

		if self.loop > 0 then
			self.loop = self.loop - 1
			self.time = self.time + self.duration
		end

		if self.loop == 0 then
			self:Stop()
		elseif self.loop < 0 then
			self.time = self.time + self.duration
		end
	end
end

return Timer
