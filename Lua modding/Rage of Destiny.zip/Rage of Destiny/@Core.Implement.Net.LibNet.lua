LibNet = {
	DecodeHeader = function(buffer)
		return string.unpack(">I4I4", buffer)
	end,
	EncodeHeader = function(svrid, cmd)
		return string.pack(">I4I4", svrid, cmd)
	end
}

NetDecoder = NetDecoder or BaseClass()
function NetDecoder:__init(buffer, pos)
	self.buffer = buffer
	self.pos = pos
	self.fmt = { ">", "" }
end
function NetDecoder:Decode(fmt)
	self.fmt[2] = fmt
	fmt = table.concat(self.fmt)
	self.fmt[2] = ""
	local data = { string.unpack(fmt, self.buffer, self.pos) }
	self.pos = data[#data]
	return table.unpack(data, 1, #data - 1)
end

function NetDecoder:DecodeList(fmt, istable)
	self.fmt[2] = fmt
	fmt = table.concat(self.fmt)
	local data = { string.unpack(">I2" , self.buffer ,self.pos) }
	local listlength = table.unpack(data)
	self.pos = data[#data]
	local t = {}
	if istable then
		for i = 1,listlength do
			local data = { string.unpack(fmt, self.buffer, self.pos) }
			t[i] = { table.unpack(data, 1, #data - 1) }
			self.pos = data[#data]
		end
	else
		for i = 1,listlength do
			local data = { string.unpack(fmt, self.buffer, self.pos) }
			t[i] = string.unpack(fmt, self.buffer, self.pos)
			self.pos = data[#data]
		end
	end
	self.fmt[2] = ""
	return t
end

NetEncoder = NetEncoder or BaseClass()
function NetEncoder:__init()
	self.buffer = nil
	self.list = {}
	self.fmt = { ">", "" }
end

function NetEncoder:Encode(fmt, ...)
	self.fmt[2] = fmt
	fmt = table.concat(self.fmt)
	self.fmt[2] = ""
	self.list[#self.list + 1] = string.pack(fmt, ...)
	self.buffer = table.concat(self.list)
	buff = self.buffer
	
end

function NetEncoder:EncodeList(fmt,list)
	if type(list[1]) == "table" then
		istable = true
		self.list[#self.list + 1] = string.pack(">I2",#list)
		self.fmt[2] = fmt
		fmt = table.concat(self.fmt)
		for i = 1,#list do
			self.list[#self.list + 1] = string.pack(fmt,table.unpack(list[i]))
		end
		self.fmt[2] = ""
		self.buffer = table.concat(self.list)
		buff = self.buffer
	else
		istable = false
		self.list[#self.list + 1] = string.pack(">I2",#list)
		self.fmt[2] = fmt
		fmt = table.concat(self.fmt)
		for i = 1,#list do
			self.list[#self.list + 1] = string.pack(fmt,list[i])
		end
		self.fmt[2] = ""
		self.buffer = table.concat(self.list)
		buff = self.buffer
	end
end
