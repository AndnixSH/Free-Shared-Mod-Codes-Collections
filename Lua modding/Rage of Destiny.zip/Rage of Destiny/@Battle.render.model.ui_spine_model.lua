local ui_spine_model = BaseClass()

local cUISpineModel = CS.LJY.NX.UISpineModel

function ui_spine_model:__init(anchor, assetName, callback)
    self.anchor = anchor

    if self.anchor then
        self.cmodel = cUISpineModel(self.anchor.canchor, assetName, callback)
    else
        self.cmodel = cUISpineModel(nil, assetName, callback)
    end
end

function ui_spine_model:release()
    if self.cmodel then
        self.cmodel:Release()
        self.cmodel = nil
    end

    if self.anchor then
        self.anchor:DeleteMe()
        self.anchor = nil
    end
end

function ui_spine_model:get_game_item_model()
    return self.cmodel
end

function ui_spine_model:get_game_object()
    if self.cmodel then
        return self.cmodel.gameItem
    end
end

function ui_spine_model:start_active(active_name)
    if self.cmodel then
        self.cmodel:StartActive(active_name)
    end
end

function ui_spine_model:set_parent(trans)
    if self.cmodel then
        self.cmodel:SetParent(trans)
    end
end

function ui_spine_model:model_rotate(x, y, z)
    if self.cmodel then
        self.cmodel:ModelRotate(x or 0, y or 0, z or 0)
    end
end

function ui_spine_model:model_localposition(x, y, z)
    if self.cmodel then
        self.cmodel:ModelLocalPosition(x or 0, y or 0, z or 0)
    end
end

function ui_spine_model:model_position(x, y, z)
    if self.cmodel then
        self.cmodel:ModelPosition(x or 0, y or 0, z or 0)
    end
end

function ui_spine_model:model_scale(scale)
    if self.cmodel then
        self.cmodel:ModelScale(scale)
    end
end

function ui_spine_model:showmodel()
    if self.cmodel then
        self.cmodel:ShowModel()
    end
end

function ui_spine_model:hidemodel()
    if self.cmodel then
        self.cmodel:HideModel()
    end
end

return ui_spine_model