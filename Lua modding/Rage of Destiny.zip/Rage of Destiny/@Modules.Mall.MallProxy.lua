local MallDef = require "Modules.Mall.MallDef"
local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
local RedPointDef = require "Modules.RedPoint.RedPointDef"
local isEditor = Application.isEditor
local CampaignProxy = require "Modules.Campaign.CampaignProxy"
local DateFormatUtil = require "Common.Util.DateFormatUtil"
local Timer = require "Common.Util.Timer"
local IGGSdkDef = require "Modules.IGGSdk.IGGSdkDef"
local rapidjson = require "rapidjson"
local BagProxy = require "Modules.Bag.BagProxy"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local Application = CS.UnityEngine.Application
local RuntimePlatform = CS.UnityEngine.RuntimePlatform

local MallProxy = MallProxy or BaseClass(BaseProxy)

function MallProxy:__init(name)
	MallProxy.Instance = self

	self.data = {}

	--sdk相关
	self.data.products = {} --key:pcid value:IGGGameItem
	self.data.rechargeEventConfig = { --key:充值金额*1000 value:事件名
		[990] = "RECHARGE_0_99",
		[1990] = "RECHARGE_1_99",
		[2990] = "RECHARGE_2_99",
		[3990] = "RECHARGE_3_99",
		[4990] = "RECHARGE_4_99",
		[9990] = "RECHARGE_9_99",
		[14990] = "RECHARGE_14_99",
		[19990] = "RECHARGE_19_99",
		[24990] = "RECHARGE_24_99",
		[29990] = "RECHARGE_29_99",
		[49990] = "RECHARGE_49_99",
		[99990] = "RECHARGE_99_99",
	}
	self.data.giftEventConfig = { --key:礼包id value:事件名
		[1851] = "RECHARGE_SAIL1851",
		[2013] = "RECHARGE_MONTHCARD2013",
		[2014] = "RECHAGE_SUPERMONTHCARD2013",
	}

	self.data.malls = {} --key:type value:对应商城
	self.data.dailyChoicenessTimes = 0 --日礼包精选的当前刷新次数
	self.data.chooseGifts = {} --自选礼包 key:礼包id value:{选择了第几个道具}
	self.data.monthCards = {} --月卡 key:月卡id value:月卡信息
	self.data.growConStates = {} --key:成长礼包条件id value:领取状态
	self.data.regTime = 0 --创号时间
	self.data.monthCardRecordStates = {} --key:月卡id value:离线时的状态
	self.data.monthCardRecordFlags = {} --key:月卡id value:是否设置了过期提示(登录仅出现一次)
	self.data.monthCardRecordTimers = {} --key:月卡id value:过期倒计时Timer
	self.data.pushGifts = {} --key:礼包id value:pushGift
	self.data.isEnterScenceFirst = true --是否首次进入场景
	self.data.isReceiveData = false --是否接收到数据
	self.data.newPushMallItem = nil --新的推送礼包
	self.data.pushTimer = nil --推送礼包计时器
	self.data.newGrowTips = false --新的成长礼包提示
	self.data.dailySupplys = {} --每日补给 key:id value:每日补给信息

	self:AddProto(72000, self.On72000)
	self:AddProto(72001, self.On72001)
	self:AddProto(72002, self.On72002)
	self:AddProto(72003, self.On72003)
	self:AddProto(72006, self.On72006)
	self:AddProto(72007, self.On72007)
	self:AddProto(72008, self.On72008)
	self:AddProto(72010, self.On72010)
	self:AddProto(72011, self.On72011)
	self:AddProto(72012, self.On72012)
	self:AddProto(72013, self.On72013)
	self:AddProto(72014, self.On72014)
end

function MallProxy:__delete()
	if self.data.pushTimer then
		self.data.pushTimer:Stop()
		self.data.pushTimer = nil
	end
	self.data = nil
end

--日礼包
function MallProxy:GetDailyConfig()
	local config = ConfigManager.GetConfig("data_mall_daily")
	return config
end

function MallProxy:GetDailyConfigById(id)
	local config = self:GetGemConfig()
	if config[id] then
		return config[id]
	end
end

--周礼包
function MallProxy:GetWeeklyConfig()
	local config = ConfigManager.GetConfig("data_mall_weekly")
	return config
end

function MallProxy:GetWeeklyConfigById(id)
	local config = self:GetGemConfig()
	if config[id] then
		return config[id]
	end
end

--月礼包
function MallProxy:GetMonthlyConfig()
	local config = ConfigManager.GetConfig("data_mall_monthly")
	return config
end

function MallProxy:GetMonthlyConfigById(id)
	local config = self:GetGemConfig()
	if config[id] then
		return config[id]
	end
end

--钻石礼包
function MallProxy:GetGemConfig()
	local config = ConfigManager.GetConfig("data_mall_gem")
	return config
end

function MallProxy:GetGemConfigById(id)
	local config = self:GetGemConfig()
	if config[id] then
		return config[id]
	end
end

--起航礼包
function MallProxy:GetSailConfig()
	local config = ConfigManager.GetConfig("data_mall_sail")
	return config
end

function MallProxy:GetSailConfigById(id)
	local config = self:GetSailConfig()
	if config[id] then
		return config[id]
	end
end

--成长礼包
function MallProxy:GetGrowConfig()
	local config = ConfigManager.GetConfig("data_mall_grow")
	return config
end

function MallProxy:GetGrowConfigById(id)
	local config = self:GetGrowConfig()
	if config[id] then
		return config[id]
	end
end

function MallProxy:GetGrowConConfig()
	local config = ConfigManager.GetConfig("data_mall_grow_condition")
	return config
end

function MallProxy:GetGrowConConfigById(id)
	local config = self:GetGrowConConfig()
	if config[id] then
		return config[id]
	end
end

--月卡礼包
function MallProxy:GetMonthCardConfig()
	local config = ConfigManager.GetConfig("data_mall_monthcard")
	return config
end

--推送礼包
function MallProxy:GetPushConfig()
	local config = ConfigManager.GetConfig("data_mall_push")
	return config
end

function MallProxy:GetPushConConfig()
	local config = ConfigManager.GetConfig("data_mall_push_condition")
	return config
end

function MallProxy:GetPushConConfigById(id)
	local config = self:GetPushConConfig()
	if config[id] then
		return config[id]
	end
end

function MallProxy:GetCustomConfig(id)
	local config = ConfigManager.GetConfig("data_mall_self")
	return config
end

--每日补给礼包
function MallProxy:GetDailySupplyConfig()
	local config = ConfigManager.GetConfig("data_mall_supply")
	return config
end

--通用
function MallProxy:GetConfig(type)
	local config
	if type == MallDef.Type.Daily then
		config = self:GetDailyConfig()
	elseif type == MallDef.Type.Weekly then
		config = self:GetWeeklyConfig()
	elseif type == MallDef.Type.Monthly then
		config = self:GetMonthlyConfig()
	elseif type == MallDef.Type.Gem then
		config = self:GetGemConfig()
	elseif type == MallDef.Type.Sail then
		config = self:GetSailConfig()
	elseif type == MallDef.Type.Grow then
		config = self:GetGrowConfig()
	elseif type == MallDef.Type.MonthCard then
		config = self:GetMonthCardConfig()
	elseif type == MallDef.Type.Push then
		config = self:GetPushConfig()
	elseif type == MallDef.Type.Self then
		config = self:GetCustomConfig()
	elseif type == MallDef.Type.DailySupply then
		config = self:GetDailySupplyConfig()
	end
	return config
end

function MallProxy:GetConfigById(type, id)
	local config = self:GetConfig(type)
	return config[id]
end

--获取限购次数
function MallProxy:GetBuyLimitTimes(type, id)
	local config = self:GetConfigById(type, id)
	local buy_limit = config.buy_limit
	local vipLv = RoleInfoModel.viplevel

	if buy_limit then
		for i=1,#buy_limit do
			local temp = buy_limit[i]
			if vipLv >= temp[1] and vipLv <= temp[2] then
				return temp[3]
			end
		end
	end
end

function MallProxy:GetGiftConfig()
	local config = ConfigManager.GetConfig("data_mall_gift")
	return config
end

function MallProxy:GetGiftConfigById(id)
	local config = self:GetGiftConfig()
	if config[id] then
		return config[id]
	end
end

function MallProxy:GetSailLimitTimeInfo()
	local regTime = self.data.regTime
	local limitTime = ConfigManager.GetConfig("data_common").mall_sail_limit_time.value1[1]
	return regTime, limitTime
end

function MallProxy:GetPermanentMonthCardId()
	return ConfigManager.GetConfig("data_common").mall_permanent_monthcard_id.value1[1]
end

function MallProxy:SetProducts(products)
	self.data.products = products
end

function MallProxy:ClearProducts()
	self.data.products = {}
end

function MallProxy:HasProducts()
	return next(self.data.products) ~= nil 
end

function MallProxy:GetProduct(pcid)
	return self.data.products[pcid]
end

function MallProxy:GetProductPrice(giftId)
	local giftConfig = self:GetGiftConfigById(giftId)
	local pcid = giftConfig.pcid
	local product = self:GetProduct(pcid)
	local priceStr

	if product then
		local purchase = product:GetPurchase()
		local currency = purchase:GetCurrency()
		
		if Application.platform == RuntimePlatform.IPhonePlayer then
			-- local purchaseAmount = purchase:GetPriceByCurrency(currency)
			-- local purchaseCurrency = IGGCurrency.GetDisplayName(currency)
			-- priceStr = purchaseCurrency .. " " .. purchaseAmount

			local code = purchase:GetPlatformPriceCurrencyCode()
			if code then
				priceStr = code .. purchase:GetPlatformCurrencyPrice()
			end
		else
			priceStr = purchase:GetPlatformCurrencyPrice()
		end

		--if not priceStr then
		--	purchase:SetCurrency(IGGCurrency.Currency.RMB)
		--	priceStr = purchase:GetFormattedPrice() .. " " .. purchase:GetCurrencyDisplay()
		--end
	else
		if self:IsFree(giftId) then
			local LanguageManager = require "Common.Mgr.Language.LanguageManager"
			priceStr = LanguageManager.Instance:GetWord(MallDef.LanguageKey.MallNormalView9)
		else
			priceStr = "-"
		end
	end

	if not priceStr then
		priceStr = "-"
	end

	return priceStr
end

--购买礼包(点界面UI的购买按钮时调用,此时还未弹出sdk支付界面)
--点购买时先由服务端判断能否购买,能则弹出sdk购买界面;不能则关闭商城界面
function MallProxy:Buy(giftId)
	self:Send72011(giftId)
end

--购买礼包(弹出sdk支付界面)
function MallProxy:SDKBuy(giftId)
	local giftConfig = self:GetGiftConfigById(giftId)
	local pcid = giftConfig.pcid
	local canBuy = true
	local can_voucher = self:CheckGiftVoucher(giftId)

	if not SystemConfig.isIGGPlatform() or SystemConfig.IsSop then --测试环境 --isEditor
		if can_voucher then
			self:Send72013(giftId)
		else
			local CheatProxy = require "Modules.Cheat.CheatProxy"
			local str = "mallbuy_" .. giftId
			CheatProxy.Instance:Send11000(str)
		end
	else --正式环境
		--检查限购情况
		local purchaseLimit = IGGSdkProxy.Instance:GetPurchaseLimit()
		-- print("MallProxy:Buy aaa", purchaseLimit, pcid, RoleInfoModel.uid)
		if purchaseLimit ~= 0 then
			canBuy = false
			GameLogicTools.ShowMsgTips(MallDef.LanguageKey.MallSdk7)
		end

		--购买
		if canBuy then
			--可以使用代金卷
			if can_voucher then
				self:Send72013(giftId)
			else
				local product = self:GetProduct(pcid)
				if product then
					--屏蔽点击，等购买协议返回或相关sdk接口回调后，再去掉屏蔽
					LuaLayout.Instance:OpenWidget(UIWidgetNameDef.BlockView)
					local value = IGGSdkProxy.Instance:PayOrSubscribeTo(product, RoleInfoModel.uid, RoleInfoModel.server_id)
					-- print("MallProxy:Buy bbb", value, RoleInfoModel.uid, RoleInfoModel.server_id)
				else
					if self:IsFree(giftId) then
						self:Send72009(giftId)
						-- print("MallProxy:Buy ccc")
					end
				end
			end
		end
	end
end

--处理购买提示
function MallProxy:HandleBuyTips(result)
	if result == MallDef.CantBuyGiftReason.Times then
		GameLogicTools.ShowMsgTips(MallDef.LanguageKey.MallRootView4)
	elseif result == MallDef.CantBuyGiftReason.NoExist then
		GameLogicTools.ShowMsgTips(MallDef.LanguageKey.MallRootView5)
	elseif result == MallDef.CantBuyGiftReason.Time then
		GameLogicTools.ShowMsgTips(MallDef.LanguageKey.MallRootView6)
	end
end

--关闭所有商城相关界面
function MallProxy:CloseViews()
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MallRootView)
	if view and view:IsOpen() then
		LuaLayout.Instance:CloseWidget(UIWidgetNameDef.MallConfirmView)
		LuaLayout.Instance:CloseWidget(UIWidgetNameDef.MallConfirm2View)

		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.FullScreenView)
	    if view and view:IsOpen() then
	        view:OnClickClose()
	    end

		--关闭支付界面
		local parenWidget = LuaLayout.Instance:GetWidget(UIWidgetNameDef.Root_IGG)
		if parenWidget then
		    local rootObj = parenWidget.go
		    local obj1 = GameObjTools.GetChild(rootObj, "ModuleMockPanel") 
		    if obj1 then
		        obj1:SetActive(false)
		    end
		end
	end
end

--获取商城
function MallProxy:GetMall(type)
	return self.data.malls[type]
end

--获取商城Item
function MallProxy:GetMallItem(type, id)
	local mall = self:GetMall(type)
	for i=1,#mall do
		local mallItem = mall[i]
		if mallItem.id == id then
			return mallItem
		end
	end
end

--是否存在该礼包
function MallProxy:IsExistGift(giftId)
	local isExist
	local type
	local mallItem

	local malls = self.data.malls
	for i,v in ipairs(malls) do
		for i2,v2 in ipairs(v) do
			if v2.giftId == giftId then
				type = i
				mallItem = v2
				break
			end
		end
	end

	isExist = mallItem ~= nil
	return isExist, type, mallItem
end

--能否购买该礼包
function MallProxy:CanBuyGift(giftId)
	local canBuy = true
	local maxCanBuyTimes = 0 --最大可购买次数,0表示无限制
	local reason = 0 --不可购买的原因

	--检查是否存在该礼包
	local isExist, type, mallItem = self:IsExistGift(giftId)

	if isExist then
		local id = mallItem.id
		local times = mallItem.times

		local config = self:GetConfigById(type, id)
		local grid_type = config.grid_type
		local gift_ids = config.gift_ids
		local buyLimitTimes = self:GetBuyLimitTimes(type, id)

		if grid_type == MallDef.GridType.Sequence then
			maxCanBuyTimes = buyLimitTimes * #gift_ids
		elseif grid_type == MallDef.GridType.Random or grid_type == MallDef.GridType.Choose then
			maxCanBuyTimes = buyLimitTimes	
		end

		if type == MallDef.Type.Push then
			maxCanBuyTimes = 1
		elseif type == MallDef.Type.MonthCard then
			if id == self:GetPermanentMonthCardId() then
				maxCanBuyTimes = 1
			end
		elseif type == MallDef.Type.DailySupply then
			maxCanBuyTimes = 0
		end

		if maxCanBuyTimes ~= 0 then
			if times >= maxCanBuyTimes then
				canBuy = false
				reason = MallDef.CantBuyGiftReason.Times
			end
		end
	else
		canBuy = false
		reason = MallDef.CantBuyGiftReason.NoExist
	end

	--检查礼包
	if isExist and canBuy then
		if type == MallDef.Type.Sail then
			local isSailValid = self:IsSailValid()
			if not isSailValid then
				canBuy = false
				reason = MallDef.CantBuyGiftReason.Time
			end
		elseif type == MallDef.Type.Grow then
			local id = mallItem.id
			local isGrowValid, reason = self:IsGrowValid(id)
			if isGrowValid and reason == MallDef.GrowValidReason.Times then
			else
				canBuy = false
				reason = MallDef.CantBuyGiftReason.Times
			end
		elseif type == MallDef.Type.Push then
			local giftId = mallItem.giftId
			if self:IsPushOverdue(giftId) then
				canBuy = false
				reason = MallDef.CantBuyGiftReason.Time
			end
		elseif type == MallDef.Type.DailySupply then
			local activateId, canGet, hadGet = self:GetActivateDailySupplyInfo()
			if activateId then
				canBuy = false
				reason = MallDef.CantBuyGiftReason.ExistActivateDailySupply
			end
		end
	end

	return canBuy, maxCanBuyTimes, reason, type, mallItem
end

--获取可购买次数(目前仅用于个别礼包的计算)
function MallProxy:GetCanBuyTimes(giftId)
	local canBuyTimes = 0
	local canBuy, maxCanBuyTimes, reason, type, mallItem = self:CanBuyGift(giftId)

	if canBuy then
		local id = mallItem.id
		local times = mallItem.times
		local config = self:GetConfigById(type, id)
		local grid_type = config.grid_type

		if grid_type then
			if grid_type == MallDef.GridType.Sequence then
				local buyLimitTimes = self:GetBuyLimitTimes(type, id)
				canBuyTimes = buyLimitTimes - times % buyLimitTimes
			elseif grid_type == MallDef.GridType.Random then
			elseif grid_type == MallDef.GridType.Choose then
				if type == MallDef.Type.Self then
					local MallCustomProxy = require "Modules.Mall.MallCustomProxy"
					canBuyTimes = MallCustomProxy.Instance:GetCustomLeftTimesById(id)
				end
			end
		end
	end

	return canBuyTimes
end

--是否免费
function MallProxy:IsFree(giftId)
	local config = self:GetGiftConfigById(giftId)
	return config.pcid == "0"
end

--设置新英雄
function MallProxy:SetNewHeros(newHeros)
	self.newHeros = newHeros
end

--获取当前的成长礼包
function MallProxy:GetNowGrow()
	local mallItem
	local config = self:GetConfig(MallDef.Type.Grow)
	local mall = self:GetMall(MallDef.Type.Grow)

	if mall then
		for i,v in ipairs(config) do
			if self:IsGrowValid(i) then
				mallItem = mall[i]
				break
			end
		end
	end

	return mallItem
end

--是否购买了成长礼包
function MallProxy:HadBuyGrow(id)
	local mall = self:GetMall(MallDef.Type.Grow)
	
	if mall then
		local mallItem = mall[id]
		
		if mallItem.times == 1 then
			return true
		else
			return false
		end
	end

	return false
end

--某个成长礼包是否存在
--前面的礼包买完并且奖励都领取完后，达到某个主线关卡后出现
function MallProxy:IsGrowValid(id)
	--检查之前的礼包
	for i=1,id-1 do
		--没购买
		if not self:HadBuyGrow(i) then
			return false
		end

		--奖励未全部领完
		local config = self:GetGrowConConfig()
		for i2,v in ipairs(config) do
			if v.type == i then
				if not self:HadGetGrowCon(v.id) then
					return false
				end
			end
		end
	end

	--检查该礼包
	local config = self:GetConfigById(MallDef.Type.Grow, id)
	local conditions = config.conditions
	if conditions then
		local con = conditions[1]
		local conType = con[1]
		local mainlineId = CampaignProxy.Instance:GetPassMainlineid()
		local isPass = false

		if conType == 1 then
			if mainlineId >= con[2] then
				isPass = true
			end
		end

		if not isPass then
			return false
		end
	end
	
	local mall = self:GetMall(MallDef.Type.Grow)
	if mall then
		local mallItem = mall[id]
		local times = mallItem.times

		if times == 0 then --可购买
			return true, MallDef.GrowValidReason.Times
		elseif times == 1 then
			local config = self:GetGrowConConfig()
			for i,v in ipairs(config) do
				if v.type == id then
					if not self:HadGetGrowCon(v.id) then --奖励未全部领完
						return true, MallDef.GrowValidReason.Goods
					end
				end
			end
		end
	end

	return false
end

--获取成长礼包条件的领取状态
function MallProxy:GetGrowConState(id)
	return self.data.growConStates[id]
end

--客户端状态判定
function MallProxy:GetGrowConState2(id, growId)
	local config = self:GetGrowConConfigById(id)
	local nowMainlineId = CampaignProxy.Instance:GetPassMainlineid()
	local targetMainlineId = config.main_line_id
	-- print("MallProxy:GetGrowConState2", nowMainlineId)

	local hadBuyGrow = self:HadBuyGrow(growId)
	local hadGetGrowCon = self:HadGetGrowCon(id)
	local isPass = nowMainlineId >= targetMainlineId --是否通关

	if not hadBuyGrow then --未购买
		return MallDef.GrowConState2.CantGet
	else --已购买
		if not isPass then --未达到主线条件
			return MallDef.GrowConState2.CantGet
		elseif isPass and not hadGetGrowCon then --可领取
			return MallDef.GrowConState2.CanGet
		elseif isPass and hadGetGrowCon then --已领取
			return MallDef.GrowConState2.HadGet
		end
	end

	return MallDef.GrowConState2.HadGet
end

function MallProxy:GetNewGrowTips()
	return self.data.newGrowTips
end

function MallProxy:SetNewGrowTips(value)
	self.data.newGrowTips = value
end

function MallProxy:CheckNewGrowTips()
	local newGrowTips = self:GetNewGrowTips()
	if newGrowTips then
		self:SetNewGrowTips(false)
		RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.MallLimitGrow2Show, 1)
	end
end

--是否领取了成长礼包条件的奖励
function MallProxy:HadGetGrowCon(id)
	local state = self:GetGrowConState(id)
	return state == MallDef.GrowConState.HadGet
end

--起航礼包是否有效(可购买)
function MallProxy:IsSailValid()
	local regTime, limitTime = self:GetSailLimitTimeInfo()
	if RoleInfoModel.servertime - regTime <= limitTime * 86400 then
		return true
	else
		return false
	end
end

--能否显示起航礼包
function MallProxy:CanShowSail()
	local isSailValid = self:IsSailValid()
	return isSailValid
end

--能否显示成长礼包
function MallProxy:CanShowGrow()
	local mallItem = self:GetNowGrow()
	return mallItem ~= nil
end

function MallProxy:CanShowSelf()
	local MallCustomProxy = require "Modules.Mall.MallCustomProxy"
	return MallCustomProxy.Instance:CheckMallCustomOpen()
end

--能否显示限时商船
function MallProxy:CanShowLimit()
	local canShowSail = self:CanShowSail()
	local canShowGrow = self:CanShowGrow()
	local canShowSelf = self:CanShowSelf()
	local ActivityProxy = require "Modules.Activity.ActivityProxy"
	local ActivityDef = require "Modules.Activity.ActivityDef"
	local finish = ActivityProxy.Instance:CheckActivityFinsh(ActivityDef.toggleType.HappyMonth)
	if not canShowSail and not canShowGrow and not canShowSelf and  finish then
		return false
	else
		return true
	end
end

function MallProxy:GetMonthCard(id)
	return self.data.monthCards[id]
end

--获取月卡每日奖励
function MallProxy:GetMonthCardDailyReward(id)
	local config = self:GetConfigById(MallDef.Type.MonthCard, id)
	local vipLv = RoleInfoModel.viplevel
	local goods = config.daily_goods[vipLv + 1]
	local reward = {}
	
	for i=2,#goods do
		table.insert(reward, goods[i])
	end
	
	return reward
end

--获取月卡信息
--返回状态,剩余时间,每日奖励状态
function MallProxy:GetMonthCardInfo(id)
	local monthCard = self:GetMonthCard(id)
	local buyTime = monthCard.buyTime
	local getTime = monthCard.getTime
	local buyTimes = monthCard.buyTimes
	local config = self:GetConfigById(MallDef.Type.MonthCard, id)
	local permanentMonthCardId = self:GetPermanentMonthCardId()

	local nowTime = RoleInfoModel.servertime == 0 and self.data.serverTime or RoleInfoModel.servertime --RoleInfoModel.servertime返回慢,所以用商城自身协议返回服务器时间
	local endTime
	if buyTimes > 0 then
		if id ~= permanentMonthCardId then --非永久月卡,计算结束时间
			endTime = buyTime + buyTimes * config.time * 86400

			local temp = DateFormatUtil.Date("*t", endTime)
			local year = temp.year
			local month = temp.month
			local day = temp.day
			endTime = DateFormatUtil.Time({year=year, month=month, day=day, hour=0, min=0, sec=0})
		end
	end

	local state
	local leftTime
	local dailyRewardState

	if id == permanentMonthCardId then --永久卡
		if buyTime == 0 then
			state = MallDef.MonthCardState.None
		else
			state = MallDef.MonthCardState.Activate
		end
	else --非永久卡
		if buyTime == 0 then
			state = MallDef.MonthCardState.None
		elseif nowTime >= endTime then
			state = MallDef.MonthCardState.Overdue
		else
			state = MallDef.MonthCardState.Activate
			leftTime = endTime - nowTime
		end
	end

	-- print("MallProxy:GetMonthCardInfo", id)
	-- print("nowTime", table.dump(DateFormatUtil.Date("*t", nowTime)))
	-- print("endTime", table.dump(DateFormatUtil.Date("*t", endTime)))

	if state == MallDef.MonthCardState.Activate then
		if DateFormatUtil.IsSameDay(nowTime, getTime) then
			dailyRewardState = MallDef.MonthCardDailyRewardState.HadGet
		else
			dailyRewardState = MallDef.MonthCardDailyRewardState.CanGet
		end
	else
		dailyRewardState = MallDef.MonthCardDailyRewardState.CantGet
	end

	return state, leftTime, dailyRewardState
end

--显示月卡过期弹窗
function MallProxy:ShowMonthCardOverdue()
	local redPointId
	local configs = self:GetConfig(MallDef.Type.MonthCard)
	local cardNum = #configs

	for i=1,cardNum do
		if i == 1 then
			redPointId = RedPointDef.Id.MallMonthCardMonthOverdue1
		elseif i == 2 then
			redPointId = RedPointDef.Id.MallMonthCardMonthOverdue2
		end
		local num = RedPointProxy.Instance:GetNodeNum(redPointId)
		if num == 1 then
			local func = function ()
				local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MallConfirmView)
				if view then
					view.type = MallDef.Type.MonthCard

					local mall = self:GetMall(MallDef.Type.MonthCard)
					view.mallItem = mall[i]
					view.showOverdue = true
					view:OpenView()
					RedPointProxy.Instance:SetNodeNum(redPointId, 0)
					print("MallProxy:ShowOverdue:", redPointId)
				end
			end
			Timer.New(func, 0.2, 1):Start() --延迟,因为关闭界面后立即打开会失败
			break --依次弹出,每次只出现一个弹窗
		end
	end
end

--显示推送界面
function MallProxy:ShowPushView(giftId)
	local mall = self:GetMall(MallDef.Type.Push)
	if #mall > 0 then
		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MallPushView)
		if giftId then
			view.selectGiftId = giftId
		else
			view.selectIndex = 1
		end
		view:OpenView()
	end
end

--显示推送界面(在指定时机)
function MallProxy:CheckShowPushView(pushConType)
	-- print("MallProxy:CheckShowPushView qqq", pushConType)

	if self.data.newPushMallItem then
		local id = self.data.newPushMallItem.id
		local giftId = self.data.newPushMallItem.giftId
		local config = self:GetConfigById(MallDef.Type.Push, id)
		local type = config.type
		local canShow = false

		if type == pushConType then
			canShow = true
		elseif pushConType == MallDef.PushConType.TowerBase then
			if type >= MallDef.PushConType.TowerBase and type <= MallDef.PushConType.TowerType4 then
				canShow = true
			end
		end

		-- print("MallProxy:CheckShowPushView www", tostring(canShow))

		if canShow then
			self:ShowPushView(giftId)
			self.data.newPushMallItem = nil
		end
	end
end

--显示推送界面(首次登录,需要协议返回和主界面打开时才执行)
function MallProxy:ShowPushViewFirst()
	if self.data.isEnterScenceFirst and self.data.isReceiveData then
		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MainView)
		if view and view:IsOpen() then
			self.data.isEnterScenceFirst = false

			self:CheckPushMallOverdue()
			
			local mall = self:GetMall(MallDef.Type.Push)
			if #mall > 0 then
				self:ShowPushView()
				self:ToNotify(self.data, MallDef.Notify.UpdatePushIcon)
			end
		end
	end
end

function MallProxy:GetPushGift(id)
	return self.data.pushGifts[id]
end

--获取推送礼包剩余时间
function MallProxy:GetPushLeftTime(giftId)
	local giftConfig = self:GetGiftConfigById(giftId)
	local time = giftConfig.time
	local pushGift = self:GetPushGift(giftId)
	local leftTime = 0

	if pushGift then
		local endTime = pushGift.startTime + time
		leftTime = endTime - RoleInfoModel.servertime 
		if leftTime > time then
			leftTime = time
		end
	else
		leftTime = 0
	end

	return leftTime
end

--推送礼包是否过期
function MallProxy:IsPushOverdue(giftId)
	local leftTime = self:GetPushLeftTime(giftId)
	if leftTime > 0 then
		return false
	else
		return true
	end
end

--移除推送礼包
function MallProxy:RemovePush(targetGiftId)
	local pushType = MallDef.Type.Push
	local pushMall = self:GetMall(pushType)

	for i=#pushMall,1,-1 do
		local mallItem = pushMall[i]
		local giftId = mallItem.giftId
		if giftId == targetGiftId then
			print("MallProxy:RemovePush", table.dump(mallItem))

			table.remove(pushMall, i)
			self.data.pushGifts[giftId] = nil

			break
		end
	end
end

--检查推送商城中的过期礼包
function MallProxy:CheckPushMallOverdue()
	local pushType = MallDef.Type.Push
	local pushMall = self:GetMall(pushType)

	if pushMall then
		for i=#pushMall,1,-1 do
			local mallItem = pushMall[i]
			local giftId = mallItem.giftId

			if self:IsPushOverdue(giftId) then
				print("MallProxy:CheckPushMallOverdue:", i, giftId)
				table.remove(pushMall, i)
				self.data.pushGifts[giftId] = nil
			end
		end
	end
end

--越新的礼包越在前面
function MallProxy:SortPush()
	local pushType = MallDef.Type.Push
	local pushMall = self:GetMall(pushType)

	if pushMall then
		table.sort(pushMall, function (a, b)
			local pushGiftA = self:GetPushGift(a.giftId)
			local pushGiftB = self:GetPushGift(b.giftId)
			if pushGiftA and pushGiftB then
				return pushGiftA.startTime > pushGiftB.startTime
			else
				return true
			end
		end)
	end
end

function MallProxy:GetDailySupply(id)
	return self.data.dailySupplys[id]
end

--获取每日补给每日奖励
function MallProxy:GetDailySupplyDailyReward(id)
	local config = self:GetConfigById(MallDef.Type.DailySupply, id)
	local goods = config.daily_goods
	local reward = {}
	
	for i=1,#goods do
		table.insert(reward, goods[i])
	end
	
	return reward
end

--获取每日补给信息
--返回状态,剩余时间,每日奖励状态
function MallProxy:GetDailySupplyInfo(id)
	local dailySupply = self:GetDailySupply(id)
	if not dailySupply then
		return nil, nil, nil
	end
	
	local buyTime = dailySupply.buyTime
	local getTime = dailySupply.getTime
	local buyTimes = dailySupply.buyTimes
	local config = self:GetConfigById(MallDef.Type.DailySupply, id)

	local nowTime = RoleInfoModel.servertime == 0 and self.data.serverTime or RoleInfoModel.servertime --RoleInfoModel.servertime返回慢,所以用商城自身协议返回服务器时间
	local endTime
	if buyTimes > 0 then
		endTime = buyTime + buyTimes * config.time * 86400

		local temp = DateFormatUtil.Date("*t", endTime)
		local year = temp.year
		local month = temp.month
		local day = temp.day
		endTime = DateFormatUtil.Time({year=year, month=month, day=day, hour=0, min=0, sec=0})
	end

	local state
	local leftTime
	local dailyRewardState

	if buyTime == 0 then
		state = MallDef.DailySupplyState.None
	elseif nowTime >= endTime then
		state = MallDef.DailySupplyState.Overdue
	else
		state = MallDef.DailySupplyState.Activate
		leftTime = endTime - nowTime
	end

	-- print("MallProxy:GetDailySupplyInfo", id)
	-- print("nowTime", table.dump(DateFormatUtil.Date("*t", nowTime)))
	-- print("endTime", table.dump(DateFormatUtil.Date("*t", endTime)))

	if state == MallDef.DailySupplyState.Activate then
		if DateFormatUtil.IsSameDay(nowTime, getTime) then
			dailyRewardState = MallDef.DailySupplyDailyRewardState.HadGet
		else
			dailyRewardState = MallDef.DailySupplyDailyRewardState.CanGet
		end
	else
		dailyRewardState = MallDef.DailySupplyDailyRewardState.CantGet
	end

	return state, leftTime, dailyRewardState
end

--获取激活的每日补给信息
function MallProxy:GetActivateDailySupplyInfo()
	local configs = self:GetConfig(MallDef.Type.DailySupply)
	local num = #configs
	local activateId
	local canGet = false
	local hadGet = false

	for i=1,num do
		local state, leftTime, dailyRewardState = self:GetDailySupplyInfo(i)
		if state == MallDef.DailySupplyState.Activate then
			activateId = i
			if dailyRewardState == MallDef.DailySupplyDailyRewardState.CanGet then
				canGet = true
			elseif dailyRewardState == MallDef.DailySupplyDailyRewardState.HadGet then
				hadGet = true
			end
			break
		end
	end

	return activateId, canGet, hadGet
end

function MallProxy:UpdateMainLeftActivity()
	self:ToNotify(self.data, MallDef.Notify.UpdateMainLeftActivity)
end

function MallProxy:UpdateRedPoint()
	--日礼包、周礼包、月礼包
	local types = {MallDef.Type.Daily, MallDef.Type.Weekly, MallDef.Type.Monthly,}
	for i=1,#types do
		local type = types[i]
		local mall = self:GetMall(type)
		for j=1,#mall do
			local mallItem = mall[j]
			local giftId = mallItem.giftId
			local redPointId
			local num

			if type == MallDef.Type.Daily then
				redPointId = RedPointDef.Id.MallNormalDaily
			elseif type == MallDef.Type.Weekly then
				redPointId = RedPointDef.Id.MallNormalWeekly
			elseif type == MallDef.Type.Monthly then
				redPointId = RedPointDef.Id.MallNormalMonthly
			end

			if self:IsFree(giftId) and self:CanBuyGift(giftId) then
				num = 1
			else
				num = 0
			end

			RedPointProxy.Instance:SetNodeNumDynamic(redPointId, mallItem.id, num)
		end
	end

	--成长礼包
	self:UpdateRedPointGrow()

	--月卡
	self:UpdateRedPointMonthCard()

	--每日补给
	self:UpdateRedPointDailySupply()
end

function MallProxy:UpdateRedPointGrow()
	local mallItem = self:GetNowGrow()
	local config = self:GetGrowConConfig()

	if mallItem then
		local id = mallItem.id
			
		for i,v in ipairs(config) do
			local num = 0
			if v.type == id then
				local state = self:GetGrowConState2(v.id, id)
				if state == MallDef.GrowConState2.CanGet then
					num = 1
				end
			end
			RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.MallLimitGrow, v.id, num)
		end

		--成长礼包2出现
		if id == 2 then
			local key = RoleInfoModel.guserid .. "_RedPoint_MallLimitGrow2Show"
			local value = PlayerPrefs.GetInt(key, 0)
			if value == 0 then
				local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MallLimitView)
				if view and view:IsOpen() then
					self:SetNewGrowTips(true)
				else
					RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.MallLimitGrow2Show, 1)
				end
			end
		end
	else --当前不存在成长礼包,清除所有的红点
		for i,v in ipairs(config) do
			RedPointProxy.Instance:SetNodeNumDynamic(RedPointDef.Id.MallLimitGrow, v.id, 0)
		end
	end
end

function MallProxy:UpdateRedPointMonthCard()
	for i,v in ipairs(self.data.monthCards) do
		local state, leftTime, dailyRewardState = self:GetMonthCardInfo(i)
		local redPointId
		local redPointId2
		local num = 0
		local num2 = 0

		if i == 1 then
			redPointId = RedPointDef.Id.MallMonthCardMonthBox1
			redPointId2 = RedPointDef.Id.MallMonthCardMonthOverdue1
		elseif i == 2 then
			redPointId = RedPointDef.Id.MallMonthCardMonthBox2
			redPointId2 = RedPointDef.Id.MallMonthCardMonthOverdue2
		elseif i == 3 then
			redPointId = RedPointDef.Id.MallMonthCardMonthBox3
		end
		
		--每日奖励
		if state == MallDef.MonthCardState.Activate then
			if dailyRewardState == MallDef.MonthCardDailyRewardState.CanGet then
				num = 1
			end
		end
		RedPointProxy.Instance:SetNodeNum(redPointId, num)

		--过期
		if not self.data.monthCardRecordFlags[i] then
			self.data.monthCardRecordFlags[i] = true
			
			local recordState = self.data.monthCardRecordStates[i]
			if recordState == MallDef.MonthCardState.Activate then
				if state == MallDef.MonthCardState.Overdue then
					num2 = 1
				end
			end
			-- print("MallProxy:UpdateRedPointMonthCard 111", recordState, state, self.data.monthCardRecordFlags[i])
			RedPointProxy.Instance:SetNodeNum(redPointId2, num2)
		end

		--过期倒计时
		if self.data.monthCardRecordTimers[i] then
			self.data.monthCardRecordTimers[i]:Stop()
			self.data.monthCardRecordTimers[i] = nil
		end
		if leftTime and leftTime > 0 then
			local t = Timer.New(function ()
				RedPointProxy.Instance:SetNodeNum(redPointId2, 1)
			end, leftTime, 1)
			self.data.monthCardRecordTimers[i] = t
			t:Start()
		end
	end
end

function MallProxy:UpdateRedPointDailySupply()
	local num = 0

	--领取首充奖励后,出现红点(首次)
	local state = self:GetFirstChargeState()
	if state >= MallDef.FirstChargeState.Get_First then
		local key = RoleInfoModel.guserid .. "_RedPoint_MallDailySupplyOpenFirst"
		local value = PlayerPrefs.GetInt(key, 0)
		if value == 0 then
			num = 1
		end
	end

	if num == 0 then
		local activateId, canGet, hadGet = self:GetActivateDailySupplyInfo()
		if canGet then
			num = 1
		end
	end
	
	RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.MallDailySupply, num)
end

function MallProxy:DecoderMallItem(decoder)
	local mallItem = {}
	mallItem.id, mallItem.times, mallItem.giftId = decoder:Decode("I2I4I4")
	return mallItem
end

function MallProxy:DecoderMalls(decoder)
	local malls = {}
	local mallCount = decoder:Decode("I2")
	
	for i=1,mallCount do
		local mall = {}
		local mallItemCount = decoder:Decode("I2")

		for j=1,mallItemCount do
			local mallItem = self:DecoderMallItem(decoder)
			mall[j] = mallItem
		end
				
		malls[i] = mall
	end

	return malls
end

function MallProxy:DecoderMall(decoder)
	local type = decoder:Decode("I1")
	local mallItemCount = decoder:Decode("I2")
	local mall = {}

	for i=1,mallItemCount do
		local mallItem = self:DecoderMallItem(decoder)
		mall[i] = mallItem
	end

	return type, mall
end

function MallProxy:DecoderMonthCards(decoder)
	local count = decoder:Decode("I1")
	local monthCards = {}

	for i=1,count do
		local monthCard = {}
		monthCard.buyTime, monthCard.getTime, monthCard.buyTimes = decoder:Decode("I4I4I4")
		monthCards[i] = monthCard
	end
	
	return monthCards
end

function MallProxy:DecoderPushGift(decoder)
	local pushGift = {}
	pushGift.id, pushGift.startTime = decoder:Decode("I4I4")
	pushGift.reward = decoder:DecodeList("I4I4", true)
	return pushGift
end

function MallProxy:DecoderPushGifts(decoder)
	local count = decoder:Decode("I1")
	local pushGifts = {}

	for i=1,count do
		local pushGift = self:DecoderPushGift(decoder)
		pushGifts[pushGift.id] = pushGift
	end

	return pushGifts
end

function MallProxy:DecoderDailySupplys(decoder)
	local count = decoder:Decode("I1")
	local dailySupplys = {}

	for i=1,count do
		local dailySupply = {}
		dailySupply.buyTime, dailySupply.getTime, dailySupply.buyTimes = decoder:Decode("I4I4I4")
		dailySupplys[i] = dailySupply
	end
	
	return dailySupplys
end

--请求商城信息
function MallProxy:Send72000()
	self:SendMessage(72000)
	-- print("MallProxy:Send72000")
end

function MallProxy:On72000(decoder)
	self.data.malls = self:DecoderMalls(decoder)
	self.data.growConStates = decoder:DecodeList("I1")
	self.data.monthCards = self:DecoderMonthCards(decoder)
	self.data.monthCardRecordStates = decoder:DecodeList("I1")
	self.data.regTime = decoder:Decode("I8")
	self.data.pushGifts = self:DecoderPushGifts(decoder)
	self.data.serverTime = decoder:Decode("I8")
	self.data.dailySupplys = self:DecoderDailySupplys(decoder)

	-- print("MallProxy:On72000", table.dump(self.data.malls))
	-- print(table.dump(self.data.malls[MallDef.Type.Push]))
	-- print(table.dump(self.data.growConStates))
	-- print(table.dump(os.date("*t", self.data.regTime)))
	-- print(table.dump(self.data.monthCardRecordStates))
	-- print(RoleInfoModel.uid)
	-- print(table.dump(self.data.pushGifts))

	-- print(table.dump(self.data.monthCards))
	-- for i,v in ipairs(self.data.monthCards) do
	-- 	local t1 = DateFormatUtil.Date("*t", v.buyTime)
	-- 	local t2 = DateFormatUtil.Date("*t", v.getTime)
	-- 	print(string.format("%d-%d-%d|%d-%d-%d", t1.year, t1.month, t1.day, t2.year, t2.month, t2.day))
	-- end

	-- print(table.dump(self.data.dailySupplys))

	self:UpdateRedPoint()
	self:ToNotify(self.data, MallDef.Notify.UpdateAllMallInfo)

	self.data.isReceiveData = true
	self:ShowPushViewFirst()

	if not self.data.pushTimer then
		self.data.pushTimer = Timer.New(function ()
			self:CheckPushMallOverdue()
		end, 1, -1)
		self.data.pushTimer:Start()
	end
end

--购买
function MallProxy:On72001(decoder)
	local result, giftId = decoder:Decode("I1I4")
	-- print("MallProxy:On72001", result)

	LuaLayout.Instance:CloseWidget(UIWidgetNameDef.BlockView)

	if result == 0 then
		local goodsList = decoder:DecodeList("I4I4", true)
		local type, mall = self:DecoderMall(decoder)
		self.data.monthCards = self:DecoderMonthCards(decoder)
		local isNewHero = decoder:Decode("I1") == 1
		local money = decoder:Decode("I4")
		local eventGiftId = decoder:Decode("I4")
		local isFirstCharge = decoder:Decode("I1")
		self.data.dailySupplys = self:DecoderDailySupplys(decoder)

		--道具
		local goods = {}
		for i=1,#goodsList do
			local temp = {}
			temp.goodsid = goodsList[i][1]
			temp.goodsnum = goodsList[i][2]
			table.insert(goods, temp)
		end
		if type == MallDef.Type.Gem then
			goods = GameLogicTools.HandleRewardMergeNum2(goods)
		end

		if type == MallDef.Type.Push then
			self:RemovePush(giftId)
			LuaLayout.Instance:CloseWidget(UIWidgetNameDef.MallPushView)
			self:ToNotify(self.data, MallDef.Notify.UpdatePushIcon)
		elseif type == MallDef.Type.DailySupply then
			LuaLayout.Instance:CloseWidget(UIWidgetNameDef.MallDailySupplyView)
			self:ToNotify(self.data, MallDef.Notify.UpdateMainLeftActivity)
		end

		self.data.malls[type] = mall

		-- print("MallProxy:On72001", type, table.dump(mall))
		-- print(table.dump(goods))

		self:UpdateRedPoint()
		self:ToNotify(self.data, MallDef.Notify.UpdateMallInfo)

		--奖励放最后显示,处理英雄特效的层级问题
		GameLogicTools.ShowGetItemView(goods, 4, function ()
			if isNewHero then
				GameLogicTools.ShouldShowNewHeroTipsView(goodsList)
			end

			-- if self.newHeros then
			-- 	for i,v in ipairs(self.newHeros) do
			-- 		GameLogicTools.ShowHeroTipsView(v[2], v[3], v[4], false, true, true, function()
			-- 			self.newHeros = nil
			-- 		end)
			-- 	end
			-- end
		end)

		--事件
		if SystemConfig.isIGGPlatform() then
			local jsonStr
			local purchaseAmount = 0
			local purchaseCurrency = ""
			local earnVirtualCurrencyCurrencyName
			local earnVirtualCurrencyCurrency = ""
			local earnVirtualCurrencyValue = 0

			local giftConfig = self:GetGiftConfigById(giftId)
			local pcid = giftConfig.pcid
			local product = self:GetProduct(pcid)

			if product then
				local purchase = product:GetPurchase()
				local currency = purchase:GetCurrency()

				if Application.platform == RuntimePlatform.IPhonePlayer then
					purchaseAmount = tonumber(purchase:GetPlatformCurrencyPrice())
					if purchase.GetIOSPriceCurrencyCode then
						purchaseCurrency = purchase:GetIOSPriceCurrencyCode() --IGGCurrency.GetDisplayName(currency)
					end
				else
					purchaseAmount = purchase:GetGooglePlayPriceAmountMicros() / 1000000.0
					purchaseCurrency = purchase:GetPlatformPriceCurrencyCode() --IGGCurrency.GetDisplayName(currency)
				end

				if not purchaseCurrency then
					purchaseCurrency = "USD"
				end

				local diamondGoodsid = CURRENCY_TYPE_GOODID[CURRENCY_TYPE.diamond]
				local coinGoodsid = CURRENCY_TYPE_GOODID[CURRENCY_TYPE.coin]
				local hasDiamond = false
				local hasCoin = false
				for i=1,#goods do
					local goodsid = goods[i].goodsid
					if goodsid == diamondGoodsid then
						hasDiamond = true
					elseif goodsid == coinGoodsid then
						hasCoin = true
					end
				end
				--优先级:钻石>金币
				if hasDiamond then
					local cfg = BagProxy.Instance:GetGoodsCfgById(diamondGoodsid)
            		local name = LanguageManager.Instance:GetWord(cfg.name)
					earnVirtualCurrencyCurrencyName = name
				elseif hasCoin then
					local cfg = BagProxy.Instance:GetGoodsCfgById(coinGoodsid)
            		local name = LanguageManager.Instance:GetWord(cfg.name)
					earnVirtualCurrencyCurrencyName = name
				end
				earnVirtualCurrencyCurrency = purchaseCurrency
				earnVirtualCurrencyValue = purchaseAmount --purchase:GetUsdPrice()
			end

			--------------------------------------------------------------
			-- local p = {
			-- 	[IGGSdkDef.SecondEventParam.PurchaseAmount] = purchaseAmount,
			-- 	[IGGSdkDef.SecondEventParam.PurchaseCurrency] = purchaseCurrency,
			-- 	-- IGGSdkDef.SecondEventParam.PurchaseParameters = 1,
			-- }
			-- jsonStr = rapidjson.encode(p)
			-- IGGSdkProxy.Instance:Track(IGGSdkDef.SecondEventName.Purchase, jsonStr)

			--------------------------------------------------------------
			if earnVirtualCurrencyCurrencyName then
				-- local p2 = {
				-- 	[IGGSdkDef.SecondEventParam.EarnVirtualCurrencyCurrencyName] = earnVirtualCurrencyCurrencyName,
				-- 	[IGGSdkDef.SecondEventParam.EarnVirtualCurrencyCurrency] = earnVirtualCurrencyCurrency,
				-- 	[IGGSdkDef.SecondEventParam.EarnVirtualCurrencyValue] = earnVirtualCurrencyValue,
				-- }
				-- jsonStr = rapidjson.encode(p2)
				-- IGGSdkProxy.Instance:Track(IGGSdkDef.SecondEventName.EarnVirtualCurrency, jsonStr)
				IGGSdkProxy.Instance:SendEarnVirtualCurrency(earnVirtualCurrencyCurrencyName, earnVirtualCurrencyCurrency, earnVirtualCurrencyValue)
			end

			local rechargeEventName = self.data.rechargeEventConfig[money]
			if rechargeEventName then
				IGGSdkProxy.Instance:Track(rechargeEventName)
			end

			local giftEventName = self.data.giftEventConfig[eventGiftId]
			if giftEventName then
				-- print(giftEventName)
				IGGSdkProxy.Instance:Track(giftEventName)
			end

			if isFirstCharge == 1 then
				IGGSdkProxy.Instance:Track("RECHARGE_ARBIT")
			end
		end

		LuaLayout.Instance:CloseWidget(UIWidgetNameDef.MallConfirmView)
		LuaLayout.Instance:CloseWidget(UIWidgetNameDef.MallConfirm2View)
	else
		self:HandleBuyTips(result)
		self:CloseViews()
	end
end

--刷新日礼包精选
function MallProxy:On72002(decoder)
	local result = decoder:Decode("I1")

	if result == 0 then
	end
end

--设置自选礼包
function MallProxy:On72003(decoder)
	local result = decoder:Decode("I1")

	if result == 0 then
	end
end

--领取月卡每日奖励
function MallProxy:Send72006(id)
	local encoder = NetEncoder.New()
	encoder:Encode("I1", id)
	self:SendMessage(72006, encoder)
end

function MallProxy:On72006(decoder)
	local result = decoder:Decode("I1")

	if result == 0 then
		local id = decoder:Decode("I1")
		self.data.monthCards = self:DecoderMonthCards(decoder)

		local reward = self:GetMonthCardDailyReward(id)
		GameLogicTools.ShowGetItemView2(reward, 4)

		print(table.dump(self.data.monthCards))

		self:UpdateRedPointMonthCard()
		self:ToNotify(self.data, MallDef.Notify.UpdateMallInfo)
	else
		print(result)
	end
end

--请求首充信息
function MallProxy:Send72007()
	self:SendMessage(72007)
end

function MallProxy:On72007(decoder)

	local first_charge_state = decoder:Decode("I1")
	self.data.first_charge_state = first_charge_state
	print("--------first_charge_state--------",first_charge_state)

	if first_charge_state == MallDef.FirstChargeState.UnGet_First then
		LuaLayout.Instance:CloseWidget(UIWidgetNameDef.MallFirstChargeView)
		RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.FirstCharge_First,1)
	elseif first_charge_state == MallDef.FirstChargeState.UnGet_Second then
		RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.FirstCharge_Second,1)
	end
	
	if first_charge_state ~= MallDef.FirstChargeState.UnGet_First then
		RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.FirstCharge_First,0)
	end
	if first_charge_state ~= MallDef.FirstChargeState.UnGet_Second then
		RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.FirstCharge_Second,0)
	end
	self:ToNotify(self.data,MallDef.Notify.Update_First_Charge,first_charge_state)

	self:UpdateRedPointDailySupply()
end

function MallProxy:GetFirstChargeState()
	if self.data and self.data.first_charge_state then
		return self.data.first_charge_state
	end
	return 0
end

--领取首充奖励
function MallProxy:Send72008(type)
	local encoder = NetEncoder.New()
	encoder:Encode("I1", type) -- 1首充任意，2首充648
	self:SendMessage(72008,encoder)
end

function MallProxy:On72008(decoder)
	local result ,type = decoder:Decode("I1I1")

	if result == 0 then
		local isnew = decoder:Decode("I1")
		local cfg =self:GetGiftConfigById(MallDef.FirstCharge_Config_ID[type])
		local rewards =cfg.goods_id or {}
		local rewardlist={}
		for _, v in ipairs(rewards) do
			if v then
				local item={}
				item.goodsid = v[1]
				item.goodsnum = v[2]
				table.insert(rewardlist,item)
			end
		end
		GameLogicTools.ShowGetItemView(rewardlist,1,function (  )
			local HeroProxy = require "Modules.Hero.HeroProxy"
			if cfg then
				for _ , v in ipairs(cfg.goods_id) do
					if HeroProxy.Instance:IsHero(v[1]) then
						local BagProxy = require "Modules.Bag.BagProxy"
						local HeroDef = require "Modules.Hero.HeroDef"
						local goodscfg = BagProxy.Instance:GetGoodsCfgById(v[1])
						local roleid = goodscfg.value[1]
						local rank = goodscfg.value[2] >= HeroDef.Hero_Rank_Enum.purple and HeroDef.Hero_Rank_Enum.purple or goodscfg.value[2]
						if isnew == 1 then
							GameLogicTools.ShowHeroTipsView(roleid, rank, 1, true, true, true, function()
								
							end)
						end
					end
				end
			end
		end)
		local widget= type == 1 and UIWidgetNameDef.MallFirstChargeView or ""
		LuaLayout.Instance:CloseWidget(widget)
	else
		GameLogicTools.ShowErrorCode(72008,result)
	end
end

--购买免费礼包
function MallProxy:Send72009(giftId)
	local encoder = NetEncoder.New()
	encoder:Encode("I4", giftId)
	self:SendMessage(72009, encoder)
end

--领取成长礼包的条件奖励
function MallProxy:Send72010(id)
	local encoder = NetEncoder.New()
	encoder:Encode("I1", id)
	self:SendMessage(72010, encoder)
end

function MallProxy:On72010(decoder)
	local result = decoder:Decode("I1")

	if result == 0 then
		local id = decoder:Decode("I1")
		local config = self:GetGrowConConfigById(id)
		local type = config.type
		local goodsList = config.goods_id
		local configs = self:GetGrowConConfig()
		-- local isAllHadGet = true --奖励是否全部领取了

		--道具
		local goods = {}
		for i=1,#goodsList do
			local temp = {}
			temp.goodsid = goodsList[i][1]
			temp.goodsnum = goodsList[i][2]
			table.insert(goods, temp)
		end
		GameLogicTools.ShowGetItemView(goods, 4)

		self.data.growConStates[id] = MallDef.GrowConState.HadGet

		self:UpdateRedPointGrow()
		self:ToNotify(self.data, MallDef.Notify.UpdateGrowCon)

		-- for i,v in ipairs(configs) do
		-- 	if v.type == type then
		-- 		if not self:HadGetGrowCon(v.id) then
		-- 			isAllHadGet = false
		-- 			break
		-- 		end
		-- 	end
		-- end

		-- if not isAllHadGet then
		-- 	self:ToNotify(self.data, MallDef.Notify.UpdateGrowCon)
		-- else
		-- 	self:ToNotify(self.data, MallDef.Notify.UpdateGrowAllHadGet)
		-- end
	else
		-- print("MallProxy:On72010", result)
	end
end

--查询能否购买该礼包
function MallProxy:Send72011(giftId)
	local encoder = NetEncoder.New()
	encoder:Encode("I4", giftId)
	self:SendMessage(72011, encoder)
end

function MallProxy:On72011(decoder)
	local result = decoder:Decode("I1")
	local giftId = decoder:Decode("I4")

	if result == 0 then
		self:SDKBuy(giftId)
	else
		self:HandleBuyTips(result)
		self:CloseViews()
	end
end

function MallProxy:On72012(decoder)
	local mallItem = self:DecoderMallItem(decoder)
	local pushGift = self:DecoderPushGift(decoder)
	local config = self:GetConfigById(MallDef.Type.Push, mallItem.id)
	local type = config.type

	-- print("MallProxy:On72012", table.dump(mallItem), table.dump(pushGift))

	local mall = self:GetMall(MallDef.Type.Push)
	table.insert(mall, mallItem)

	self.data.pushGifts[pushGift.id] = pushGift

	self.data.newPushMallItem = mallItem

	self:ToNotify(self.data, MallDef.Notify.UpdatePushIcon)

	--生命之树特殊处理
	if type == MallDef.PushConType.Tree then
		self:CheckShowPushView(MallDef.PushConType.Tree)
	end
end

function MallProxy:Send72013(giftId)
	local encoder = NetEncoder.New()
	encoder:Encode("I4", giftId)
	self:SendMessage(72013, encoder)
end

-- function MallProxy:On72013(decoder)
	
-- 	local result = decoder:Decode("I1")
-- 	if result ~= 0 then
-- 		GameLogicTools.ShowMsgTips("Common_1002")
-- 	end
-- end

--领取每日补给每日奖励
function MallProxy:Send72014(id)
	local encoder = NetEncoder.New()
	encoder:Encode("I1", id)
	self:SendMessage(72014, encoder)
end

function MallProxy:On72014(decoder)
	local result = decoder:Decode("I1")

	if result == 0 then
		local id = decoder:Decode("I1")
		self.data.dailySupplys = self:DecoderDailySupplys(decoder)

		local reward = self:GetDailySupplyDailyReward(id)
		GameLogicTools.ShowGetItemView2(reward, 4)

		print(table.dump(self.data.dailySupplys))

		self:UpdateRedPointDailySupply()
		-- self:ToNotify(self.data, MallDef.Notify.UpdateMallInfo)

		LuaLayout.Instance:CloseWidget(UIWidgetNameDef.MallDailySupplyView)
		self:ToNotify(self.data, MallDef.Notify.UpdateMainLeftActivity)
	else
		print(result)
	end
end

-- 用 data_mall_gift 自选礼包类型的Gift_ID 获得里面 可以自选的礼包盒List
function MallProxy:GetCustomGoodsListByCustomGiftID(gift_id)
-- 礼包里 可能第一个或前几个是 固定送的物品，后面几个是自选物品盒，索引跳过固定物品 从自物品盒开始算
	local gift_cfg = self:GetGiftConfigById(gift_id)

	local goods_info_list = gift_cfg.goods_id
	local BagDef = require "Modules.Bag.BagDef"
	local ret = {}
	for _,goods_info in ipairs(goods_info_list) do
		local goods_id = goods_info[1]
		local goods_cfg = self:GetGoodsConfigInfo(goods_id)
		if goods_cfg and goods_cfg.subtype == BagDef.SubType.CustomBox then
			table.insert(ret,goods_id)
		end
	end
	return ret
end

function MallProxy:GetGoodsListByCustomGiftIdAndIndex(gift_id,index)
	local custom_goods_list = self:GetCustomGoodsListByCustomGiftID(gift_id)
	local custom_goods_id = custom_goods_list[index]
	local goods_cfg = self:GetGoodsListByCustomGoodsID(custom_goods_id)
	return goods_cfg.value
end

function MallProxy:GetSelectGoodsInfoByGiftIDAndIndex(gift_id,index,select_index)
	local goods_list = self:GetGoodsListByCustomGiftIdAndIndex(gift_id,index)
	local goods_info = goods_list[select_index]
	local goods_cfg = self:GetGoodsConfigInfo(goods_info[1])
	return goods_cfg
end

function MallProxy:GetGoodsListByCustomGoodsID(custom_goods_id)
	local goods_cfg = self:GetGoodsConfigInfo(custom_goods_id)
	return goods_cfg
end

function MallProxy:GetGoodsConfigInfo(goods_type_id)
    local goods_config = ConfigManager.GetConfig("data_goods")
    return goods_config[goods_type_id]
end

function MallProxy:CheckGiftVoucher(gift_id)
	local giftConfig = self:GetGiftConfigById(gift_id)
	local voucher_id = giftConfig and giftConfig.coupon
	local temp_count = 0

	if voucher_id then
		local BagProxy = require "Modules.Bag.BagProxy"
		temp_count = BagProxy.Instance:GetGoodsCountById(voucher_id)
	end
	return temp_count > 0
end

return MallProxy