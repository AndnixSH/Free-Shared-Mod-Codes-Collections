local SceneManager = require "Modules.Scene.SceneManager"

local BasicSceneStrategy = BasicSceneStrategy or BaseClass()
function BasicSceneStrategy:__init(...)
    self.args = {...}
    self.setcount = -1
    self.strategycfg = nil
end

--检查是否可行
function BasicSceneStrategy:Inspection()
    self:_InspectionSuc()
end

function BasicSceneStrategy:_InspectionSuc()
    SceneManager.Instance:SceneEventStart()
end

function BasicSceneStrategy:_InspectionFail()
    SceneManager.Instance:RecoverScene()
end

function BasicSceneStrategy:Step(step)
    self.setcount = self.setcount - step
    if 0 >= self.setcount then
        SceneManager.Instance:SceneEventEnd()
        self:OnStartEntry()
    end
end

function BasicSceneStrategy:SetStep(count)
    self.setcount = count
    if 0 == self.setcount then
        SceneManager.Instance:SceneEventEnd()
        self:OnStartEntry()
    end
end

--func
function BasicSceneStrategy:SetStrategyCfg(config)
    self.strategycfg = config or {}
end

--先判断scenename有没有， 没有 sceneid 填了就查表
function BasicSceneStrategy:LoadScene(sceneid, scenename)    
    if scenename == nil and sceneid then
        local SceneProxy = require "Modules.Scene.SceneProxy"
        local scenecfg = SceneProxy.Instance:GetSceneCfgById(sceneid)
        scenename = scenecfg.prefab_id
    end

    if scenename and self.strategycfg.loadSceneType then        
        self.sceneid = sceneid
        self.scenename = scenename

        local AssetPreloader = require "Core.Implement.Load.AssetPreloader"
        local data_preload = require "Config.data_preload"
        AssetPreloader.AddLoadList(data_preload.common)

        if self.OnScenePreload then
            self:OnScenePreload(AssetPreloader)
        end

        self:SetStep(2)

        AssetPreloader.Load(function ()
            self:Step(1)
        end)

        SceneManager.Instance:LoadScene(self.scenename, self.strategycfg.loadSceneType, function ()
            self:OnLoadSceneEnd()
            self:Step(1)
        end)
    else
        self:SetStep(0)
    end
end

function BasicSceneStrategy:LoadSceneNoPreload(sceneid, scenename)    
    if scenename == nil and sceneid then
        local SceneProxy = require "Modules.Scene.SceneProxy"
        local scenecfg = SceneProxy.Instance:GetSceneCfgById(sceneid)
        scenename = scenecfg.prefab_id
    end

    if scenename and self.strategycfg.loadSceneType then        
        self.sceneid = sceneid
        self.scenename = scenename

        SceneManager.Instance:LoadScene(self.scenename, self.strategycfg.loadSceneType, function ()
            self:SetStep(0)
        end)
    else
        self:SetStep(0)
    end
end

function BasicSceneStrategy:UnloadScene()
    if self.scenename and self.strategycfg.loadSceneType then
        SceneManager.Instance:UnloadScene(self.scenename, self.strategycfg.loadSceneType)
    end
end

function BasicSceneStrategy:UnloadSceneForce()
    SceneManager.Instance:UnloadSceneForce(self.strategycfg.loadSceneType)
end

function BasicSceneStrategy:OnLoad()
end

function BasicSceneStrategy:OnLoadSceneEnd()
end

function BasicSceneStrategy:OnStartEntry()
end

function BasicSceneStrategy:DefaultOpenWidgets()
end

function BasicSceneStrategy:Destroy()
end
return BasicSceneStrategy
