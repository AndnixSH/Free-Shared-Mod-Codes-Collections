local BattleProto = require "Core.Implement.Net.BattleProto"

local GuildChaosProxy = GuildChaosProxy or BaseClass(BaseProxy, BattleProto)

function GuildChaosProxy:__init()
	GuildChaosProxy.Instance = self

	self:AddProto(70201, self.On70201) -- 准备挑战
	self:AddProto(70202, self.On70202) -- 开始挑战

	self:AddPreBattle(ACTIVITYID.GUILD_CHAOS, self.OnPreBattle) --准备战斗回调
	self:AddSetBattle(ACTIVITYID.GUILD_CHAOS, self.OnSetBattle) --战斗结算回调
	self:AddStartBattle(ACTIVITYID.GUILD_CHAOS, self.OnStartBattle) --战斗开始回调
end

function GuildChaosProxy:__delete()
end

-- 准备挑战
function GuildChaosProxy:Send70201()
    local GuildProxy = require "Modules.Guild.GuildProxy"

    local encoder = NetEncoder.New()
    encoder:Encode("I4", GuildProxy.Instance:GetChaosNowBossId())
    self:SendMessage(70201, encoder)

    local BattleProxy = require "Modules.Battle.BattleProxy"
    BattleProxy.Instance:BattleReadySetStep(ACTIVITYID.GUILD_CHAOS, 1)
end

function GuildChaosProxy:On70201(decoder)
	local result = decoder:Decode("I1")

    if result == 0 then
    elseif result == 1 then
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.GuildEntranceView)
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.GuildChaosView)
    end

	if result ~= 0 then
        local BattleProxy = require "Modules.Battle.BattleProxy"
        BattleProxy.Instance:BattleReadyNextStep(ACTIVITYID.GUILD_CHAOS, 1)
	end
end

-- 开始挑战
function GuildChaosProxy:Send70202(hero_infos, enemy_infos)
    local GuildProxy = require "Modules.Guild.GuildProxy"
    
    -- print("GuildChaosProxy:Send70202")
    -- print(table.dump(hero_infos))
    -- print(table.dump(enemy_infos))

    -- local chaosRoomLv = GuildProxy.Instance:GetChaosRoomLv(false)
    -- for i=1,#hero_infos do
    --     hero_infos[i].chaosRoomLv = chaosRoomLv
    --     hero_infos[i].level = chaosRoomLv
    -- end

    local encoder = NetEncoder.New()
    self:_EncodeHeroInfo(hero_infos, encoder)
    self:_EncodeEnemyInfo(enemy_infos, encoder)
    local bufferstr = string.pack(">I4", GuildProxy.Instance:GetChaosNowBossId())
    encoder:Encode("s2", bufferstr)
    self:SendMessage(70202, encoder)
end

function GuildChaosProxy:On70202(decoder)
	local result = decoder:Decode("I1")
    local time = decoder:Decode("I8")

	print("GuildChaosProxy:On70202", result, time)

    if result == 0 then
        local GuildProxy = require "Modules.Guild.GuildProxy"
        GuildProxy.Instance:SetChaosReportKey(time)
    elseif result == 1 then
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.GuildEntranceView)
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.GuildChaosView)
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.BattleNetSelectView)
    end
end

function GuildChaosProxy:OnPreBattle(decoder)
	local GuildProxy = require "Modules.Guild.GuildProxy"

    local heroinfos = self:_DecodeHeroInfo(decoder)
    local enemyinfos = self:_DecodeEnemyInfo(decoder)
    local bufferstr = decoder:Decode("s2")
    -- local enemyid, mainlineid = string.unpack(">I4I4", bufferstr)
    
    -- print("GuildChaosProxy:OnPreBattleChaos")
    -- print(table.dump(heroinfos))
    -- print(table.dump(enemyinfos))

    local chaosRoomLv = GuildProxy.Instance:GetChaosRoomLv(false)
    for i=1,#heroinfos do
    	heroinfos[i].chaosRoomLv = chaosRoomLv
    	heroinfos[i].level = chaosRoomLv
    end

    local nowRoomId = GuildProxy.Instance:GetChaosNowRoomId()
    local nowRoomConfig = GuildProxy.Instance:GetChaosRoomConfigById(nowRoomId)
   	local enemyinfo = enemyinfos[1]
    enemyinfo.chaosRoomLv = nowRoomConfig.enemy_level
    enemyinfo.level = nowRoomConfig.enemy_level
    enemyinfo.rank = nowRoomConfig.enemy_quality
    enemyinfo.equips = nowRoomConfig.enemy_equip

    local bossId = GuildProxy.Instance:GetChaosNowBossId()
	local bossConfig = GuildProxy.Instance:GetChaosBossConfigById(bossId)
    self:_UpdateEnemyInfo(enemyinfos, bossConfig.enemy)

    --打开备战界面
    UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 10, ACTIVITYID.GUILD_CHAOS, heroinfos, enemyinfos, "BattleGuildChaosPanel", {bossId})
end

function GuildChaosProxy:OnSetBattle()
end

-- function GuildChaosProxy:OnStartBattle(decoder, seed)
-- 	local GuildProxy = require "Modules.Guild.GuildProxy"
	
--     local heroinfos = self:_DecodeHeroInfo(decoder)
--     local enemyinfos = self:_DecodeEnemyInfo(decoder)
    
--     local chaosRoomLv = GuildProxy.Instance:GetChaosRoomLv(false)
--     for i=1,#heroinfos do
--     	heroinfos[i].chaosRoomLv = chaosRoomLv
--     	heroinfos[i].level = chaosRoomLv
--     end

--     local bufferstr = decoder:Decode("s2")
--     -- local enemyid, mainlineid = string.unpack(">I4I4", bufferstr)
--     self:GenerateBattleInfo_2(ACTIVITYID.GUILD_CHAOS, seed, heroinfos, enemyinfos, nil)

--     -- print("GuildChaosProxy:OnStartBattleChaos")
--     -- print(table.dump(heroinfos))
--     -- print(table.dump(enemyinfos))
-- end



-- function GuildChaosProxy:OnPreBattleBuffer(bufferstr)
-- 	local GuildProxy = require "Modules.Guild.GuildProxy"

--     -- local heroinfos = self:_DecodeHeroInfo(decoder)
--     -- local enemyinfos = self:_DecodeEnemyInfo(decoder)
--     -- local bufferstr = decoder:Decode("s2")
--     -- local enemyid, mainlineid = string.unpack(">I4I4", bufferstr)

--     print("GuildChaosProxy:OnPreBattleBuffer")
--     print(table.dump(heroinfos))
--     print(table.dump(enemyinfos))

--     local chaosRoomLv = GuildProxy.Instance:GetChaosRoomLv(false)
--     for i=1,#heroinfos do
--     	heroinfos[i].chaosRoomLv = chaosRoomLv
--     	heroinfos[i].level = chaosRoomLv
--     end

    
--  --    GameLogicTools.GetEnemyList(bossConfig.enemy)

--  --    print()

--     --打开备战界面
--     -- UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 10, ACTIVITYID.GUILD_CHAOS, heroinfos, enemyinfos, "BattleGuildChaosPanel", {})


--     local bossId = GuildProxy.Instance:GetChaosNowBossId()
-- 	local bossConfig = GuildProxy.Instance:GetChaosBossConfigById(bossId)
--     return { enemyid = bossConfig.enemy, view = { name = "BattleGuildChaosPanel", args = {} }}
-- end

-- function GuildChaosProxy:OnSetBattle(decoder)
-- end

function GuildChaosProxy:OnStartBattleBuffer(bufferstr, heroinfos, enemyinfos)
    print("GuildChaosProxy:OnStartBattleBuffer")

    -- local GuildProxy = require "Modules.Guild.GuildProxy"

    -- local heroinfos = self:_DecodeHeroInfo(decoder)
    -- local enemyinfos = self:_DecodeEnemyInfo(decoder)
    -- local bufferstr = decoder:Decode("s2")
    -- local enemyid, mainlineid = string.unpack(">I4I4", bufferstr)
    -- self:GenerateBattleInfo_2(ACTIVITYID.GUILD_CHAOS, seed, heroinfos, enemyinfos, nil)

    -- print(table.dump(heroinfos))
    -- print(table.dump(enemyinfos))

    -- local chaosRoomLv = GuildProxy.Instance:GetChaosRoomLv(false)
    -- for i=1,#heroinfos do
    --     heroinfos[i].chaosRoomLv = chaosRoomLv
    --     heroinfos[i].level = chaosRoomLv
    -- end

    -- local nowRoomId = GuildProxy.Instance:GetChaosNowRoomId()
    -- local nowRoomConfig = GuildProxy.Instance:GetChaosRoomConfigById(nowRoomId)
    -- local enemyinfo = enemyinfos[1]
    -- enemyinfo.chaosRoomLv = nowRoomConfig.enemy_level
    -- enemyinfo.level = nowRoomConfig.enemy_level
    -- enemyinfo.rank = nowRoomConfig.enemy_quality
    -- enemyinfo.equips = nowRoomConfig.enemy_equip

    return {}
end

return GuildChaosProxy