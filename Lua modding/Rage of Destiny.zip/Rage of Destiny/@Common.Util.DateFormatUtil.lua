--module("DateFormatUtil", package.seeall)
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local DateFormatUtil = {}

local function checknumber(value, base)
    return tonumber(value, base) or 0
end

local function checkint(value)
    return math.round(checknumber(value))
end

-- 输入总秒数,输出8天8小时8分钟8秒
function DateFormatUtil.formatToDayAndSencond(totalSeconds)
	local day = checkint(totalSeconds / 3600 / 24)
	local hour = checkint(totalSeconds / 3600 - day * 24)
	local minutes = checkint(totalSeconds / 60 - day * 24 * 60 - hour * 60)
	local seconds = (totalSeconds - hour * 3600) % 60
	local time = ""
	if (day >= 1) then
		time = time .. day .. LanguageManager.Instance:GetWord("DateFormatUtil", 5) -- "天"
	end
	if (hour >= 1) then
		time = time .. hour .. LanguageManager.Instance:GetWord("DateFormatUtil", 6) -- "小时"
	end 
	if (minutes >= 1) then
		time = time .. minutes .. LanguageManager.Instance:GetWord("DateFormatUtil", 11) -- "分钟"
	end
	if(seconds >= 1) then
		time = time .. seconds .. LanguageManager.Instance:GetWord("DateFormatUtil", 8) -- "秒"
	end
	return time
end

-- 输入总秒数,输出 天 小时 分钟 秒
function DateFormatUtil.formatToDayAndSencond2(totalSeconds)
	local day = checkint(totalSeconds / 3600 / 24)
	local hour = checkint(totalSeconds / 3600 - day * 24)
	local minutes = checkint(totalSeconds / 60 - day * 24 * 60 - hour * 60)
	local seconds = (totalSeconds - hour * 3600) % 60
	return day,hour,minutes,seconds
end

function DateFormatUtil.formatToDHMorHMS(totalSeconds)
	totalSeconds = checkint(totalSeconds)
	local day = math.floor(totalSeconds / 86400)
	totalSeconds = totalSeconds % 86400
	local hour = math.floor(totalSeconds / 3600)
	totalSeconds = totalSeconds % 3600
	local minutes = math.floor(totalSeconds / 60)
	local seconds = math.floor(totalSeconds % 60)
	local time = ""

	if (day > 0) then
		time = LanguageManager.Instance:GetWordFormat("DateFormatUtil", 12,day, hour, minutes)
	else
		time = LanguageManager.Instance:GetWordFormat("DateFormatUtil", 13, hour, minutes, seconds)
	end
	return time
end

function DateFormatUtil.formatToMS(totalSeconds)
	local minutes = math.floor(totalSeconds / 60)
	local seconds = totalSeconds % 60
	local time = LanguageManager.Instance:GetWordFormat("DateFormatUtil", 14, minutes, seconds)
	return time
end

-- 输入总秒数,输出8天8小时8分钟
function DateFormatUtil.formatToDayAndMinutes(totalSeconds)
	local day = math.floor(totalSeconds / 3600 / 24)
	local hour = math.floor(totalSeconds / 3600 - day * 24)
	local minutes = math.floor(totalSeconds / 60 - day * 24 * 60 - hour * 60)
	local seconds = (totalSeconds - hour * 3600) % 60
	local time = ""
	if (day >= 1) then
		time = time..day .. LanguageManager.Instance:GetWord("DateFormatUtil", 5) -- "天"
	end
	if (hour >= 1) then
		time = time..hour .. LanguageManager.Instance:GetWord("DateFormatUtil", 6) -- "小时"
	end 
	if (minutes >= 1) then
		time = time..minutes .. LanguageManager.Instance:GetWord("DateFormatUtil", 11) -- "分钟"
	end
	return time
end 

-- 输入总秒数,输出8天 or 8小时 or 8分钟 or 8秒
function DateFormatUtil.formatToDayAndHour(totalSeconds)
	local day = math.floor(totalSeconds / 3600 / 24)
	local hour = math.floor(totalSeconds / 3600 - day * 24)
	local minutes = math.floor(totalSeconds / 60 - day * 24 * 60 - hour * 60)
	local seconds = (totalSeconds - hour * 3600) % 60
	local time = "" 
	if (day >= 1) then
		time = LanguageManager.Instance:GetWordFormat("DateFormatUtil", 15, math.floor(totalSeconds / 3600 / 24)) 
	elseif (hour >= 1) then
		time = LanguageManager.Instance:GetWordFormat("DateFormatUtil", 16, hour)
	elseif (minutes >= 1) then
		time = LanguageManager.Instance:GetWordFormat("DateFormatUtil", 17, minutes)
	elseif (minutes >= 0) then
		time = LanguageManager.Instance:GetWordFormat("DateFormatUtil", 18, seconds)
	end 
	return time
end

-- 输入总秒数,输出8天8小时
function DateFormatUtil.formatToHourAndMinute(totalSeconds)
	local day = math.floor(totalSeconds / 3600 / 24)
	local hour = math.floor(totalSeconds / 3600 - day * 24)
	local minutes = math.floor(totalSeconds / 60 - day * 24 * 60 - hour * 60)
	local seconds = (totalSeconds - hour * 3600) % 60
	local time
	if day >= 1 then
		time = LanguageManager.Instance:GetWordFormat("DateFormatUtil", 19, day, hour) 
	else
		time = LanguageManager.Instance:GetWordFormat("DateFormatUtil", 20, hour, minutes) 
	end
	return time
end

-- 输入总秒数，输出8小时08分08秒
function DateFormatUtil.formatTickToCNTimes(totalSeconds,show00)
	if show00 == nil then show00 = true end
	local hour = math.floor(totalSeconds / 3600)
	local minutes = math.floor((totalSeconds - hour * 3600) / 60)
	local seconds = (totalSeconds - hour * 3600) % 60
	local strTime = ""
	local strHour = LanguageManager.Instance:GetWord("DateFormatUtil", 6) -- "小时"
	if hour == 0 then
		if show00 then
			strTime = string.format("%s%s%s", strTime, "00", strHour)
		else
			strTime = string.format("%s%s%s", strTime, "0", strHour)
		end
	elseif hour < 10 then
		if show00 then
			strTime = string.format("%s%s%s%s", strTime, "0", hour, strHour)
		else
			strTime = string.format("%s%s%s", strTime, hour, strHour)
		end
	else
		strTime = string.format("%s%s%s", strTime, hour, strHour)
	end
	--分钟
	local strFen = LanguageManager.Instance:GetWord("DateFormatUtil", 11)
	if minutes == 0 then
		if show00 then
			strTime = string.format("%s%s%s", strTime, "00", strFen)
		else
			strTime = string.format("%s%s%s", strTime, minutes, strFen)
		end
	elseif minutes < 10 then
		if show00 then
			strTime = string.format("%s%s%s%s", strTime, "0", minutes, strFen)
		else
			strTime = string.format("%s%s%s", strTime, minutes, strFen)
		end
	else
		strTime = string.format("%s%s%s", strTime, minutes, strFen)
	end
	local strSec = LanguageManager.Instance:GetWord("DateFormatUtil", 8)
	if seconds == 0 then
		if show00 then
			strTime = string.format("%s%s%s", strTime, "00", strSec)
		else
			strTime = string.format("%s%s%s", strTime, seconds, strSec)
		end
	elseif seconds < 10 then
		if show00 then
			strTime = string.format("%s%s%s%s", strTime, "0", seconds, strSec)
		else
			strTime = string.format("%s%s%s", strTime, seconds, strSec)
		end
	else
		strTime = string.format("%s%s%s", strTime, seconds, strSec)
	end 
	return strTime
end

-- 输入总秒数，输出00:01:44
function DateFormatUtil.formatTickTime(totalSeconds)
	local hour = math.floor(totalSeconds / 3600)
	local minutes = math.floor((totalSeconds - hour * 3600) / 60)
	local seconds = math.floor((totalSeconds - hour * 3600) % 60)

	local strTime = ""
	if hour < 10 then
		strTime =  "0" .. hour .. ":" -- "小时"
	else 
		strTime = hour .. ":" -- "小时"
	end
	if minutes == 0 then
		strTime = strTime .. "00" .. ":"
	elseif minutes < 10 then
		strTime = strTime .."0" .. minutes .. ":"
	else
		strTime = strTime .. minutes .. ":"
	end
	if seconds == 0 then
		strTime = strTime .. "00" -- "秒"
	elseif seconds < 10 then
		strTime = strTime .."0" .. seconds -- "秒"
	else
		strTime = strTime .. seconds -- "秒"
	end 
	return strTime
end

--输入总秒数， 输出 hour:00:00 or 00:00
function DateFormatUtil.formatTickMinSec(totalSeconds)
	local hour = math.floor(totalSeconds / 3600)
	local minutes = math.floor((totalSeconds - hour * 3600) / 60)
	local seconds = math.floor((totalSeconds - hour * 3600) % 60)
	local strTime = ""
	if hour > 0 and hour < 10 then
		strTime = strTime .. "0" .. hour .. ":"
	elseif hour > 10 then
		strTime = strTime .. hour .. ":" 
	end
	if minutes == 0 then
		strTime = strTime .. "00" .. ":"
	elseif minutes > 0 and minutes < 10 then
		strTime = strTime .. "0" .. minutes .. ":"
	else
		strTime = strTime .. minutes .. ":"
	end
	if seconds == 0 then
		strTime = strTime .. "00"
	elseif seconds < 10 then
		strTime = strTime .. "0" .. seconds
	else
		strTime = strTime .. seconds
	end
	return strTime
end

-- 输出：2015年3月10日
function DateFormatUtil.formatSecToDate(totalSeconds) 
	local date = os.date("*t", totalSeconds)
	local timeString = date.year .. LanguageManager.Instance:GetWord("DateFormatUtil", 21) -- "年"
	local month = date.month
	timeString = timeString..month .. LanguageManager.Instance:GetWord("DateFormatUtil", 22) -- "月"
	local day = date.day
	timeString = timeString..day .. LanguageManager.Instance:GetWord("DateFormatUtil", 23) -- "日"
	return timeString
end
-- 输出：3月10日
function DateFormatUtil.formatSecToDateMD(totalSeconds) 
	local date = os.date("*t", totalSeconds)
	local month = date.month
	local timeString = month .. LanguageManager.Instance:GetWord("DateFormatUtil", 22) -- "月"
	local day = date.day
	timeString = timeString..day .. LanguageManager.Instance:GetWord("DateFormatUtil", 23) -- "日"
	return timeString
end

function DateFormatUtil.secToDateCn(totalSeconds)
	local date = os.date("*t", totalSeconds)
	local timeString = date.year .. LanguageManager.Instance:GetWord("DateFormatUtil", 21) -- "年"
	local month = date.month
	if month < 10 then
		timeString = timeString.."0" .. month .. LanguageManager.Instance:GetWord("DateFormatUtil", 22) -- "月"
	else 
		timeString = timeString..month .. LanguageManager.Instance:GetWord("DateFormatUtil", 22) -- "月"
	end
	local day = date.day
	if day < 10 then
		timeString = timeString .. "0" .. day .. LanguageManager.Instance:GetWord("DateFormatUtil", 23) -- "日"
 	else
		timeString = timeString..day .. LanguageManager.Instance:GetWord("DateFormatUtil", 23) -- "日"
	end
	local hour = date.hour
	if (hour < 10) then
		timeString = timeString .."0" .. hour
 	else
		timeString = timeString..hour
	end
	local minutes = date.min
	if (minutes < 10) then
		timeString = timeString..":0" .. minutes
	else 
		timeString = timeString..":" .. minutes
	end
	return timeString
end

--输入1970 年 1 月 1 日以来的秒数，输出 "2012-10-10 08:08"
function DateFormatUtil.format(totalSeconds)
	local  t = os.date("*t",totalSeconds)
	if t.month < 10 then
		t.month = "0" ..t.month
	end
	if t.day < 10 then
		t.day = "0" ..t.day
	end
	if t.hour < 10 then
		t.hour = "0" ..t.hour
	end
	if t.min < 10 then 
		t.min = "0"..t.min
	end
	local time = t.year .."-" ..t.month .."-" ..t.day .." ".. t.hour ..":" ..t.min
	return time
end

--输入1970 年 1 月 1 日以来的秒数，输出 "2012-10-10 08:08:08"
function DateFormatUtil.formatWithSecond(totalSeconds)
	local t = os.date("*t", totalSeconds)
	if t.sec < 10 then
		t.sec = "0" .. t.sec
	end
	return format(totalSeconds) .. ":" .. t.sec
end

-- 判断是否是今天
function DateFormatUtil.isToday(totalSeconds)
	local curDate = os.date("*t", totalSeconds)
	local nowDate = os.date("*t")
	if (curDate.month == nowDate.month and curDate.day == nowDate.day) then
		return true
	end
	return false
end

--获取周几 1：周日 7：周六
function DateFormatUtil.getCurrWeekDay(totalSeconds)
	local curDate = os.date("*t", totalSeconds)
	return curDate.wday
end

function DateFormatUtil.getDay(totalSeconds)
	local curDate = os.date("*t",totalSeconds)
	return curDate.day
end

function DateFormatUtil.getHour(totalSeconds)
	local curDate = os.date("*t",totalSeconds)
	return curDate.hour
end

-- 输入输入1970 年 1 月 1 日以来的秒数，输出为："今日"或"明日" + "几点"
function DateFormatUtil.getHourData(totalSeconds)
	local curServerDate = os.date("*t", totalSeconds)
	local curLocalDate = os.date("*t")

	local str = ""
	if curServerDate.day == curLocalDate.day then
		str = LanguageManager.Instance:GetWord("DateFormatUtil", 24) .. curServerDate.hour .. LanguageManager.Instance:GetWord("DateFormatUtil", 26) -- "今日xx点"
	else
		str = LanguageManager.Instance:GetWord("DateFormatUtil", 25) .. curServerDate.hour .. LanguageManager.Instance:GetWord("DateFormatUtil", 26) -- "明日xx点"
	end
	return str
end

-- 输入1970 年 1 月 1 日以来的秒数，输出"2012-08-12"
function DateFormatUtil.formatPassDate1(totalSeconds)
	local  t = os.date("*t",totalSeconds)
	return t.year .."-" ..t.month .."-" ..t.day
end

-- 输入1970 年 1 月 1 日以来的秒数，输出"2012.08.12"
function DateFormatUtil.formatPassDate2(totalSeconds)
	local  t = os.date("*t",totalSeconds)
	return t.year .."." ..t.month .."." ..t.day
end

function DateFormatUtil.formatPassDate3(totalSeconds)
	local  t = os.date("*t",totalSeconds)
	local str = ""
	if t.hour < 10 then
		str = str .. "0"
	end
	str = str .. t.hour .. ":"

	if t.min < 10 then
		str = str .. "0"
	end
	str = str .. t.min
	return t.year .."." ..t.month .."." .. t.day .. " " .. str
end

--输入1970 年 1 月 1 日以来的秒数，输出 2012-08-12 08时
function DateFormatUtil.formatPassDate(totalSeconds)
	local  t = os.date("*t",totalSeconds)
	return t.year .."-" ..t.month .."-" ..t.day .. "  " .. t.hour .. "时" 
end

--输入1970 年 1 月 1 日以来的秒数，输出08:08:08小时分钟秒
function DateFormatUtil.formatHours(totalSeconds)
	local  t = os.date("*t",totalSeconds)
	local str = ""
	if t.hour < 10 then
		str = str .. "0"
	end
	str = str .. t.hour .. ":"

	if t.min < 10 then
		str = str .. "0"
	end
	str = str .. t.min .. ":"

	if t.sec < 10 then
		str = str .. "0"
	end
	str = str .. t.sec

	return str
end

--输入时间戳，输出08:08分钟秒
function DateFormatUtil.formatMS(totalSeconds)
	local  t = os.date("*t",totalSeconds)

	local str = string.format("%02d:%02d", t.min, t.sec)

	return str
end

--输入秒数，输出08:08分钟秒
function DateFormatUtil.formatMS2(totalSeconds)
	local min = math.floor(totalSeconds / 60)
	local sec = math.floor(totalSeconds % 60)
	local str = string.format("%02d:%02d", min, sec)
	return str
end

-- 输入时间戳：输出 12:30 ()
function DateFormatUtil.formatHM(totalSeconds)
	local t = os.date("*t",totalSeconds)
	local str = string.format("%02d:%02d", t.hour, t.min)
	return str
end

-- 输入秒数：输出 12:30 ()
function DateFormatUtil.formatHM2(totalSeconds)
	local hour = math.floor(totalSeconds / 3600)
	totalSeconds = totalSeconds % 3600
	local min = math.floor(totalSeconds / 60)
	local str = string.format("%02d:%02d", hour, min)
	return str
end

--输入时间戳，输出08:08:08小时分钟秒
function DateFormatUtil.formatHMS(totalSeconds)
	local t = os.date("*t",totalSeconds)
	local str = string.format("%02d:%02d:%02d", t.hour, t.min, t.sec)
	return str
end

--输入秒数，输出08:08:08小时分钟秒
function DateFormatUtil.formatHMS2(totalSeconds)
	local hour = math.floor(totalSeconds / 3600)

	totalSeconds = totalSeconds % 3600
	local min = math.floor(totalSeconds / 60)

	totalSeconds = totalSeconds % 60
	local sec = math.floor(totalSeconds)

	local str = string.format("%02d:%02d:%02d", hour, min, sec)

	return str
end

-- 到下一个hour点的时间，秒数
function DateFormatUtil.deltaMid(nowTime, hour)
	nowTime = nowTime or -1
	hour = hour or 0

	local nowDate = os.date("*t", nowTime)
	local nextDate = os.date("*t", nowTime)
	nextDate.min = 0
	nextDate.sec = 0
	if (nowDate.hour < hour) then
		nextDate.hour = hour
		nextTime = os.time(nextDate)
	else
		nextDate.hour = 23
		nextTime = os.time(nextDate) + 13 * 60 * 60
	end

	return nextTime - nowTime
end



--月日时分
function DateFormatUtil.formatMonDayHourMin(totalSeconds)
	local  t = os.date("*t", totalSeconds)
	local str = LanguageManager.Instance:GetWordFormat("DateFormatUtil", 27, t.month, t.day, t.hour, t.min)
	return str
end

--月日
function DateFormatUtil.formatMonDay(totalSeconds)
	local  t = os.date("*t", totalSeconds)
	local str = LanguageManager.Instance:GetWordFormat("DateFormatUtil", 28, t.month, t.day, t.hour, t.min)
	return str
end

--福利月签用
function DateFormatUtil.formatMon(totalSeconds)
	local t = os.date("*t", totalSeconds)
	--local str = string.format("%02d",t.month)
	return t
end

--当月的最后一天
function DateFormatUtil.formatMonDayCnt(totalSeconds)
	local t = os.date("*t", totalSeconds)
	local day = os.date("%d", os.time({year = t.year, month = t.month + 1, day = 0}))
	return day
end

--计算两个时间戳差几天(只返回数字，同一天返回0)
function DateFormatUtil.calculateDisDay(time1, time2)
	if (time1 > time2) then
		local time = time1
		time1 = time2
		time2 = time
	end
	local t1 = os.date("*t", time1)
	local t2 = os.date("*t", time2)
	local newTime1 = os.time({year=t1.year, month=t1.month, day=t1.day})
	local newTime2 = os.time({year=t2.year, month=t2.month, day=t2.day})
	local disTime = newTime2 - newTime1
	return math.floor(disTime / 86400)
end

function DateFormatUtil.formatDisDay(time1, tiem2)
	local disDay = DateFormatUtil.calculateDisDay(time1, tiem2)
	if (0 == disDay) then
		return LanguageManager.Instance:GetWord("DateFormatUtil", 29)
	else
		return disDay .. LanguageManager.Instance:GetWord("DateFormatUtil", 30)
	end
end

function DateFormatUtil.formatMonDotDay(totalSeconds)
	local  t = os.date("*t", totalSeconds)
	local str = string.format("%02d.%02d",t.month, t.day, t.hour, t.min)
	return str
end

--输入剩余秒数   输出： 8d or 8h or 8m or 8s
function DateFormatUtil.formatSingleDHMS(totalSeconds) 
	local day = math.floor(totalSeconds / 3600 / 24)
	if day > 0 then return string.format("%dd", day) end
	local hour = math.floor(totalSeconds / 3600 - day * 24)
	if hour > 0 then return string.format("%dh", hour) end
	local minutes = math.floor(totalSeconds / 60 - day * 24 * 60 - hour * 60)
	if minutes > 0 then return string.format("%dm", minutes) end
	local seconds = (totalSeconds - hour * 3600) % 60
	if seconds > 0 then return string.format("%ds", seconds) end
end

--输入时间戳  返回年月日时分秒周
function DateFormatUtil.GetTimeInfo(time)
	local unixTime = time
	local year = tonumber(os.date("%Y", unixTime))
	local month = tonumber(os.date("%m", unixTime))
	local day = tonumber(os.date("%d", unixTime))
	local hour = tonumber(os.date("%H", unixTime))
	local minute = tonumber(os.date("%M", unixTime))
	local second = tonumber(os.date("%S", unixTime))

    --计算周几
    local temmonth = month
    local temyear = year
    if (temmonth == 1 or temmonth == 2) then
    	temmonth = temmonth + 12
    	temyear = temyear - 1
    end
    local c = math.floor(temyear / 100)
    local y = math.floor(temyear - c * 100)
    local week = math.floor(y + math.floor(y / 4) + math.floor(c / 4) - 2 * c + 26 * (temmonth + 1) / 10 + day - 1)
    week = math.fmod((math.fmod(week, 7) + 7), 7)
    week = (week == 0) and 7 or week     
    return {year = year, month = month, day = day, hour = hour, minute = minute, second = second, week = week}   		
end

--输入两个时间搓，输出 3天前 or 3小时前 or 3分钟前 or 1分钟前
function DateFormatUtil.formatDistanceDay(time1, time2)
	local str = ""
	if (time1 > time2) then
		local time = time1
		time1 = time2
		time2 = time
	end
	local disTime = time2 - time1
	local day = math.floor(disTime / 86400)
	if day == 0 then
		local hour = math.floor(disTime / 3600)
		if hour == 0 then
			local min = math.floor(disTime / 60)
			if min == 0 then
				str = LanguageManager.Instance:GetWordFormat("DateFormatUtil", 35, 1)
			else
				str = LanguageManager.Instance:GetWordFormat("DateFormatUtil", 35, min)
			end
		else
			str = LanguageManager.Instance:GetWordFormat("DateFormatUtil", 34, hour)
		end
	else
		if day >= 7 then
			str = LanguageManager.Instance:GetWord("DateFormatUtil", 32)
		else
			str = LanguageManager.Instance:GetWordFormat("DateFormatUtil", 33, day)
		end
	end
	return str
end

 -- 0 小时 8 分
function DateFormatUtil.formatSingleHM(totalSeconds)
	local hour = math.floor(totalSeconds / 3600)
	local minutes = math.floor((totalSeconds - hour * 3600) / 60)
	local seconds = (totalSeconds - hour * 3600) % 60
	local strTime = ""
	strTime = strTime .. hour .. LanguageManager.Instance:GetWord("DateFormatUtil", 6)
	strTime = strTime .. minutes .. LanguageManager.Instance:GetWord("DateFormatUtil", 7)
	return strTime
end

--2019-02-05 10:50
function DateFormatUtil.formatYMDHM(time)
	local str = ""
	local t = os.date("*t", time)
	local month,day,hour,min = t.month,t.day,t.hour,t.min
	if t.month < 10 then
		month = string.format("0%d", t.month)
	end
	if t.day < 10 then
		day = string.format("0%d", t.day)
	end
	if t.hour < 10 then
		hour = string.format("0%d", t.hour)
	end
	if t.min < 10 then
		min = string.format("0%d", t.min)
	end

	local str1 = string.format("%d-%s-%s", t.year, month, day)
	local str2 = string.format("%s:%s", hour, min)
	local str = str1 .. " " .. str2
	return str
end

function DateFormatUtil.formatWeek(time)
	local str = ""
	local t1,t2 = math.modf(time / 86400)
	if t1 == 0 then
		if t2 > 0 then
			str = str .. LanguageManager.Instance:GetWord("DateFormatUtil", 9)
		end
	elseif t1 > 0 then
		str = str .. LanguageManager.Instance:GetWordFormat("DateFormatUtil", 10, t1+1)
	end
	return str
end


function DateFormatUtil.formatDH(time)
	local hour = 167 - (os.time() - time) / 3600
	if hour >= 24 then
		return math.modf(hour / 24) .. LanguageManager.Instance:GetWord("DateFormatUtil", 5)
	elseif hour >= 1 then
		return  math.modf(hour) .. LanguageManager.Instance:GetWord("DateFormatUtil", 6)
	else
		return LanguageManager.Instance:GetWord("DateFormatUtil", 31)
	end
end

--字符串时间转成时间戳 时间格式必须为 2018-08-07 10:43:33
function DateFormatUtil.string2time(timeString)
    if type(timeString) ~= 'string' then error('string2time: timeString is not a string') return 0 end
    local fun = string.gmatch( timeString, "%d+")
    local y = fun() or 0
    if y == 0 then error('timeString is a invalid time string') return 0 end
    local m = fun() or 0
    if m == 0 then error('timeString is a invalid time string') return 0 end
    local d = fun() or 0
    if d == 0 then error('timeString is a invalid time string') return 0 end
    local H = fun() or 0
    if H == 0 then error('timeString is a invalid time string') return 0 end
    local M = fun() or 0
    -- if M == 0 then error('timeString is a invalid time string') return 0 end
    local S = fun() or 0
    -- if S == 0 then error('timeString is a invalid time string') return 0 end
    return os.time({year=y, month=m, day=d, hour=H,min=M,sec=S})
end

local function _GetCurZone()
	return RoleInfoModel.serverTimeZone

	-- local zone = 0
	-- local SdkProxy = require "Modules.Sdk.SdkProxy"
	-- if SdkProxy.Instance:isIGGPlatform() then
	-- 	zone = -5
	-- else
	-- 	--本地所在时区
	-- 	-- local a = os.date('!*t',os.time())--中时区的时间
	--  --    local b = os.date('*t',os.time())
	--  --    local timeZone= (b.hour - a.hour) * 3600 + (b.min - a.min) * 60
	--  --    zone = timeZone / 3600
	--     zone = 8
	-- end	
	-- return zone
end

local function _GetLocalZone()
	return os.difftime(os.time(), os.time(os.date("!*t", os.time()))) /3600
end

--zone时区的时间日期2008-11-11 00:00:00 转换为时间戳(zone时区是否考虑夏令时)
function DateFormatUtil.ZoneDate2TimeStamp(timeStr, zone)
    local time = DateFormatUtil.string2time(timeStr)
	zone = zone or _GetCurZone()
	
    local localZone = _GetLocalZone()
    local offset = localZone - zone
    -- print("ZoneDate2TimeStamp==", time, zone, localZone, offset)
    return time + offset * 3600
end

--根据 当前服务器时间转换: time 本地时间 zone需要转换的时间戳的时间
--例如 本地时区2008-11-11 00:00:00 的时间戳y --5时区2008-11-11 00:00:00 时间戳x
function DateFormatUtil.changeLocalZone(time, zone)
	zone = zone or _GetCurZone()
	
    local localZone = _GetLocalZone()
    local offset = localZone - zone
    return time + offset * 3600 + (os.date("*t", time).isdst and 3600 or 0)
end

--根据 当前服务器时间转换: time 当前服务器时间(必须要为当前世界时间) zone当前服务器时间的时区
--例如 -5时区2008-11-11 00:00:00 时间戳x 转换为 本地8时区2008-11-11 00:00:00 的时间戳y
function DateFormatUtil.changeZone(time, zone)
	zone = zone or _GetCurZone()
    local localZone = _GetLocalZone()
    local offset = localZone - zone
    return time - offset * 3600 + (os.date("*t", time).isdst and -3600 or 0)
end

--转换为本地时区 by string
function DateFormatUtil.changeLocalZonebyStr(str, zone)
	local time = DateFormatUtil.string2time(str)	
	time = DateFormatUtil.changeLocalZone(time, zone)
	return DateFormatUtil.formatYMDHM(time)
end

--转换为本地时区的小时分钟, 忽略天数, 输入 时分11:00 or 时11, 输出11:00
function DateFormatUtil.changeLocalZoneHour(str, zone)
	zone = zone or _GetCurZone()
	local badd = 0
	local fun = string.gmatch(str, "%d+")
	local H = fun() or 0
	local M = fun() or 0	
	local time = H * 3600 + M * 60	

	local totalSeconds = DateFormatUtil.changeLocalZone(time, zone)
	if totalSeconds < 0 then
		totalSeconds = totalSeconds + 24 * 60 * 60
		badd = -1
	elseif totalSeconds >= 24 * 60 * 60 then
		totalSeconds = math.fmod(totalSeconds, 24 * 60 * 60)	
		badd = 1
	end		

	return DateFormatUtil.formatHM2(totalSeconds)
end

--转换为本地时区的小时分钟, 忽略天数, 输入 时分11:00 or 时11, 输出11.5个小时
function DateFormatUtil.changeLocalZoneHour2(str, zone)
	zone = zone or _GetCurZone()
	local badd = 0
	local fun = string.gmatch(str, "%d+")
	local H = fun() or 0
	local M = fun() or 0	
	local time = H * 3600 + M * 60	

	local totalSeconds = DateFormatUtil.changeLocalZone(time, zone)
	if totalSeconds < 0 then
		totalSeconds = totalSeconds + 24 * 60 * 60
		badd = -1
	elseif totalSeconds >= 24 * 60 * 60 then
		totalSeconds = math.fmod(totalSeconds, 24 * 60 * 60)	
		badd = 1
	end	

	local hour = math.floor(totalSeconds / 3600)
	totalSeconds = totalSeconds % 3600
	local min = math.floor(totalSeconds / 60)
	return hour + min / 60, badd
end

function DateFormatUtil.formatDHMSorHMS(totalSeconds)
	local str = ""
	local day = math.floor(totalSeconds/86400)
	local hour = math.floor((totalSeconds-(day*86400)) / 3600)
	local minutes = math.floor((totalSeconds - (day * 86400 + hour * 3600)) / 60)
	local seconds = (totalSeconds - (day * 86400 + hour * 3600)) % 60
	if day > 0 then
		str = str .. day .. LanguageManager.Instance:GetWord("DateFormatUtil", 5)
	end
	if hour < 10 then
		str = str .. "0"
	end
	str = str .. hour .. LanguageManager.Instance:GetWord("DateFormatUtil", 6)
	if minutes < 10 then
		str = str .. "0"
	end
	str = str .. minutes .. LanguageManager.Instance:GetWord("DateFormatUtil", 11)
	if seconds < 10 then
		str = str .. "0"
	end
	str = str .. seconds .. LanguageManager.Instance:GetWord("DateFormatUtil", 8)
	return str
end

--当天剩余时间
function DateFormatUtil.get_the_day_leftTime(totalSeconds)
	local temp = DateFormatUtil.Date("*t", totalSeconds)
	local year = temp.year
	local month = temp.month
	local day = temp.day
	
	local totime = DateFormatUtil.Time({year=year, month=month, day=day, hour=23, min=59, sec=59})
	local time = totime - totalSeconds + 1
	return time
end

--到下周一剩余时间
function DateFormatUtil.get_next_week_start_leftTime(totalSeconds)
	local the_day_lefttime = DateFormatUtil.get_the_day_leftTime(totalSeconds)
 
	local date = DateFormatUtil.Date("*t", totalSeconds)
	
	local week_day = (date.wday - 1) % 7
	if week_day == 0 then
		week_day = 7
	end

	local time = (7-week_day) * 86400

	local week_lefttime = time + the_day_lefttime
	return week_lefttime
end

--到下月一剩余时间
function DateFormatUtil.get_next_month_start_leftTime(totalSeconds)
	local temp = DateFormatUtil.Date("*t", totalSeconds)
	local year = temp.year
	local month = temp.month
	local day = temp.day
	
	local toYear
	local toMonth

	if month == 12 then
		toYear = year + 1
		toMonth = 1
	else
		toYear = year
		toMonth = month + 1
	end

	local totime = DateFormatUtil.Time({year=toYear, month=toMonth, day=1, hour=0, min=0, sec=0})
	local time = totime - totalSeconds + 1
	return time
end

--x天x小时/00:01:44
function DateFormatUtil.formatDHorHMS(totalSeconds,only_day)
	local str = ""
	local day = math.floor(totalSeconds/86400)
	local hour = math.floor((totalSeconds-(day*86400)) / 3600)
	local minutes = math.floor((totalSeconds - (day * 86400 + hour * 3600)) / 60)
	local seconds = (totalSeconds - (day * 86400 + hour * 3600)) % 60

	if(day < 1) then
		str = DateFormatUtil.formatTickTime(totalSeconds)
	else
		str = str .. day .. LanguageManager.Instance:GetWord("FriendView_1011")
		-- if hour < 10 then
		-- 	str = str .. "0"
		-- end
		if not only_day then
			str = str .. hour .. LanguageManager.Instance:GetWord("FriendView_1012")
		end
	end

	return str
end

-- 输入总秒数,输出 7天以上 离线1天 离线1小时 离线1分钟
function DateFormatUtil.formatToOffLine(totalSeconds)
	local day = math.floor(totalSeconds / 3600 / 24)
	local hour = math.floor(totalSeconds / 3600 - day * 24)
	local minutes = math.floor(totalSeconds / 60 - day * 24 * 60 - hour * 60)
	local seconds = (totalSeconds - hour * 3600) % 60
	local time = "" 

	local minStr = LanguageManager.Instance:GetWord("FriendView_1007") --"离线%s分钟"
	local hourStr = LanguageManager.Instance:GetWord("FriendView_1008")--"离线%s小时"
	local dayStr = LanguageManager.Instance:GetWord("FriendView_1009")--"离线%s天"
	local sevenStr = LanguageManager.Instance:GetWord("FriendView_1010")--"7天以上"
	if day >= 7 then
		time = sevenStr
	elseif day >= 1 then
		time = string.format(dayStr, day)
	elseif hour > 0 then
		time = string.format(hourStr, hour)
	elseif minutes >= 1 then
		time = string.format(minStr, minutes)
	else
		time = string.format(minStr, 1)
	end

	return time
end

--2019/02/05 10:50
function DateFormatUtil.formatYMDAndHM(time)
	local t = DateFormatUtil.Date("*t", time)
	local month,day,hour,min = t.month,t.day,t.hour,t.min
	if t.month < 10 then
		month = string.format("0%d", t.month)
	end
	if t.day < 10 then
		day = string.format("0%d", t.day)
	end
	if t.hour < 10 then
		hour = string.format("0%d", t.hour)
	end
	if t.min < 10 then
		min = string.format("0%d", t.min)
	end

	local str1 = string.format("%d/%s/%s", t.year, month, day)
	local str2 = string.format("%s:%s", hour, min)
	local str = str1 .. " " .. str2
	return str, str1, str2
end

--获取服务端时区
function DateFormatUtil.GetServerTimeZone()
	return _GetCurZone() * 3600
end

--获取客户端时区
function DateFormatUtil.GetLocalTimeZone()
    local now = os.time()
    local localTimeZone = os.difftime(now, os.time(os.date("!*t", now)))
    local isdst = os.date("*t", now).isdst
    if isdst then localTimeZone = localTimeZone + 3600 end
    return localTimeZone
end

-- 替代os.date函数，忽略本地时区设置，按服务器时区格式化时间
-- @param format: 同os.date第一个参数
-- @param timestamp:服务器时间戳
function DateFormatUtil.Date(format, timestamp)
	timestamp = timestamp or RoleInfoModel.servertime
    local timeZoneDiff = DateFormatUtil.GetServerTimeZone() - DateFormatUtil.GetLocalTimeZone()
    local value = timestamp + timeZoneDiff
    if value < 0 then
    	value = 0
    end
    return os.date(format, value)
end

-- 替代os.time函数，忽略本地时区设置，返回服务器时区时间戳
-- @param timedata: 服务器时区timedate
function DateFormatUtil.Time(timedate)
    local timeZoneDiff = DateFormatUtil.GetServerTimeZone() - DateFormatUtil.GetLocalTimeZone()
    return os.time(timedate) - timeZoneDiff
end

--是否同一天
function DateFormatUtil.IsSameDay(stampA, stampB)
	local dateA = DateFormatUtil.Date("*t", stampA)
	local dateB = DateFormatUtil.Date("*t", stampB)
	return dateA.day == dateB.day and dateA.month == dateB.month and dateA.year == dateB.year
end

return DateFormatUtil