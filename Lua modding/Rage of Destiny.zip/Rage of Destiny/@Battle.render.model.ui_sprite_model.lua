local ui_sprite_model = BaseClass()

local cUISpriteModel = CS.LJY.NX.UISpriteModel

local cMaterialPropertyBlock = CS.UnityEngine.MaterialPropertyBlock

function ui_sprite_model:__init(anchor, resname, callback, asset_type)
    self.anchor = anchor
    asset_type = AssetType.ACTOR or asset_type
    if self.anchor then
        self.cmodel = cUISpriteModel(self.anchor.canchor, resname, asset_type, callback)
    else
        self.cmodel = cUISpriteModel(nil, resname, asset_type, callback)
    end

    self._renderers = {}
    self._block = nil
end

function ui_sprite_model:release()
    if self.cmodel then
        self.cmodel:Release()
        self.cmodel = nil
    end

    if self.anchor then
        self.anchor:DeleteMe()
        self.anchor = nil
    end

    self._renderers = nil

    if self._block then
        self._block:Clear()
    end
    self._block = nil
end

function ui_sprite_model:get_game_item_model()
    return self.cmodel
end

function ui_sprite_model:get_game_object()
    if self.cmodel then
        return self.cmodel.gameItem
    end
end

function ui_sprite_model:start_active(active_name)
    if self.cmodel then
        self.cmodel:StartActive(active_name)
    end
end

function ui_sprite_model:set_parent(trans)
    if self.cmodel then
        self.cmodel:SetParent(trans)
    end    
end

function ui_sprite_model:model_rotate(x, y, z)
    if self.cmodel then
        self.cmodel:ModelRotate(x or 0, y or 0, z or 0)
    end
end

function ui_sprite_model:model_localrotate(x, y, z)
    if self.cmodel then
        self.cmodel:ModelLocalRotate(x or 0, y or 0, z or 0)
    end
end

function ui_sprite_model:model_localposition(x, y, z)
    if self.cmodel then
        self.cmodel:ModelLocalPosition(x or 0, y or 0, z or 0)
    end
end

function ui_sprite_model:model_position(x, y, z)
    if self.cmodel then
        self.cmodel:ModelPosition(x or 0, y or 0, z or 0)
    end
end

function ui_sprite_model:model_scale(scale)
    if self.cmodel then
        self.cmodel:ModelScale(scale)
    end
end

function ui_sprite_model:showmodel()
    if self.cmodel then
        self.cmodel:ShowModel()
    end
end

function ui_sprite_model:hidemodel()
    if self.cmodel then
        self.cmodel:HideModel()
    end
end

function ui_sprite_model:_get_model_renderer()
    local game_object = self:get_game_object()
    if game_object then
        self._renderers = GameObjTools.GetComponentsInChildren(game_object, "SkinnedMeshRenderer")
    end
end

function ui_sprite_model:disable_rim_color()
    if next(self._renderers) == nil then
        self:_get_model_renderer()
    end

    if not self._block then
        self._block = cMaterialPropertyBlock()
    end

    for _, render in ipairs(self._renderers) do
        self._block:Clear()
        render:GetPropertyBlock(self._block)
        self._block:SetColor("_rimColTint", Color.black)
        render:SetPropertyBlock(self._block)
    end
end

return ui_sprite_model