local AudioManager = require "Common.Mgr.Audio.AudioManager"
local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"
local SceneProxy = require "Modules.Scene.SceneProxy"
local ArenaProxy = require "Modules.Arena.ArenaProxy"
local BasicBattleStrategy = require "Modules.Scene.Strategy.BasicBattleStrategy"
local HighArenaStrategy = HighArenaStrategy or BaseClass(BasicBattleStrategy)

local _wincamp = nil
local _playerlist = nil
local _restart = false
local _enemy_uin=false
local _round=1 -- 局数
local _result=0
local sceneid=2801
function HighArenaStrategy:OnLoad()
   -- LuaLayout.Instance:OpenWidget(UIWidgetNameDef.NetworkDelayView)
   -- local cfg=ArenaProxy.Instance:GetArenaCfg()
    --self:LoadScene(cfg.scene)  
    local isfrist = self.args[2].first
    -- print('isfirst', isfrist)
    if isfrist then
        self:LoadScene(sceneid)
    else
        self:LoadSceneNoPreload(sceneid)
    end
end

function HighArenaStrategy:OnStartEntry()
    -- print("------->>OnStartEntry")
    _restart = false
    _wincamp = nil
    _playerlist = self.args[1]
    local key=10011 --测试
    local cfg=SceneProxy.Instance:GetSceneCfgById(sceneid)
    if cfg and cfg.prefab_id then
        key = cfg.battle_key
    end
    local gameprop = {rawplayers = _playerlist.playerlist,config_key =key,activity_info={round=_round}}     
    
    _enemy_uin=self.args[2].enemy_uin  --OnStartBattle传参过来
    print("--------HighArenaStrategy--_enemy_uin-round--",_enemy_uin ,_round)
    --data.game_result=false
	self:StartGame()
    --战斗内暂停界面显示
    local view=LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleStopView)
    if view then
        view.data={activityid=ACTIVITYID.HIGHARENA}
        view:OpenView()
    end
    --LuaLayout.Instance:CloseWidget(UIWidgetNameDef.NetworkDelayView)
end

function HighArenaStrategy:OnGetConfigKey()
    local key=10011 --测试
    local cfg=SceneProxy.Instance:GetSceneCfgById(sceneid)
    if cfg and cfg.prefab_id then
        key = cfg.battle_key
    end
    return key
end

function HighArenaStrategy:OnStartGame()	   
    
end

function HighArenaStrategy:OnReportSettleGame(wincamp)
    local BattleProxy = require "Modules.Battle.BattleProxy"
    BattleProxy.Instance:EscGame()
end

function HighArenaStrategy:OnSettleGame(wincamp,rewards, buffer_str)
    _wincamp = wincamp 
    if #rewards > 0 then
        local rewardlist={}
        --local enemyid, towerid = string.unpack(">I4I4", buffer_str)
        for _, v in ipairs(rewards) do
            if v then
                local item={}
                item.goodsid=v[1]
                item.goodsnum=v[2]
                table.insert(rewardlist,item)
               
            end
        end
        GameLogicTools.ShowGetItemView(rewardlist,1,function (  )
            self:SettleGame(buffer_str)
        end)
    else
        self:SettleGameDelayTime(function()
        
            self:SettleGame(buffer_str)
        end)
        
    end
    
end

function HighArenaStrategy:SettleGame(buffer_str)
    local data=false

    if buffer_str ~= "" then
        data={}
        
         local result= ArenaProxy.Instance:GetgGameResult()
        --data.game_times,data.game_result[1],data.game_result[2],data.game_result[3]=string.unpack(">I1I1I1I1",buffer_str)
       -- _round= data.game_times + 1
       
        --if data.game_times == 3 then
       
        if ArenaProxy.Instance:GetRound()  == 3 then
        
            
            data.gameresult,data.enermy_rank_id, data.record_id = string.unpack(">I1I2I2",buffer_str)
            --local win_times=0
            --for i=1, #result do
                --if result[i] == 0 then
                    --win_times =win_times +1
                --end
            --end   
            local view=LuaLayout.Instance:GetWidget(UIWidgetNameDef.ProArenaBattleSettlementView)
            if view then
                view.args={}
                view.args.enermyId=_enemy_uin
                view.wincamp = (data.gameresult == 0) and CAMP.RED or CAMP.BLUE
                view.battleType = self.strategycfg.activityid
                view.args.game_result=result
                view.args.enermy_rank_id = data.enermy_rank_id
                view.record_id = data.record_id
                view:OpenView()
            end
       else
            AudioManager.StopBGM()
            _result = result[1]
            local result=ArenaProxy.Instance:SendHighArenaBattleData(ArenaProxy.Instance:GetRound() +1,nil,nil,_enemy_uin)
            if not result  then
                self:OnRequireSettle(0)
            end
            --ArenaProxy.Instance:SendHighArenaBattleData(data.game_times + 1,nil,nil)
       end
    end
end

function HighArenaStrategy:ClearData()
  
end

function HighArenaStrategy:OnDestroyGame()
    self:UnloadScene()
    self:ClearData()
    if ArenaProxy.Instance:GetEnterFromPage() ~= - 1 then
        
        local SceneManager = require "Modules.Scene.SceneManager"
        local SceneDef = require "Modules.Scene.SceneDef"

        local enter_page = UIWidgetNameDef.ProArenaChallengeView
        if ArenaProxy.Instance:GetEnterFromPage() == 2 then
            enter_page = UIWidgetNameDef.ProArenaRecordView
        end
        SceneManager.Instance:EnterScene(SceneDef.SceneType.Main, {UIWidgetNameDef.ProArenaView,enter_page})
    end
    
    -- SceneManager.Instance:EnterScene(SceneDef.SceneType.Main, 
    --     UIWidgetNameDef.ProArenaChallengeView)
end

function HighArenaStrategy:OnRestartGame()
    self:Destroy() 
end

function HighArenaStrategy:OnGamePrepared()

    local breport =self.args[2].breport
    local view=LuaLayout.Instance:GetWidget(UIWidgetNameDef.ProArenaBattleView)
    local result= ArenaProxy.Instance:GetgGameResult()
    local round=ArenaProxy.Instance:GetRound()
    if view then
        view.param={}
        view.param.enermyId=_enemy_uin
        view.param.round=round
        view.param.result=result
        view.breport= breport
        view:OpenView()
    end
end


function HighArenaStrategy:OnRequireSettle(result,isempty)
    

    local round=ArenaProxy.Instance:GetRound()
    
    local settlestr = self:GetSettleStr()
    ArenaProxy.Instance:SetgGameResult(round,result,settlestr)
    if round == 3 then
        local win_times=0
		local battle_round_settle_stat = ArenaProxy.Instance:GetBattleRoundSettleStat()
        local resultdata= ArenaProxy.Instance:GetgGameResult()
        for i=1, #resultdata do
			if not battle_round_settle_stat[i] then
				battle_round_settle_stat[i] = ""
			end
            if resultdata[i] == 0 then
                win_times = win_times +1
            end
        end
		
        local settlestrdata=ArenaProxy.Instance:GetBlueSpriteData()
        for k , settlestr in ipairs(settlestrdata) do
            --敌方数据为空时 不会进行战斗，此时需要捏造数据
            if settlestr == "" then
                local datas = {{}, {}}
                local formation= ArenaProxy.Instance:GetMyUpFormations(k)
                if formation then
                    for _ , hero in ipairs(formation) do
                        if hero then
                            table.insert(datas[1],{roleid = hero.roleid, level =hero.level, rank = hero.rank, stance= hero.stance,damage = 0, bharm = 0 ,heal =0})
                        end
                    end
                end
                settlestrdata[k] =self:GetSettleStr(datas)
            end
        end
        local bufferstr= string.pack(">I1I1I1I1s2s2s2s2s2s2",round,resultdata[1],resultdata[2],resultdata[3],settlestrdata[1],settlestrdata[2],settlestrdata[3],battle_round_settle_stat[1],battle_round_settle_stat[2],battle_round_settle_stat[3])
        self:RequireNetworkSettle(self.strategycfg.activityid,  win_times >=2 and  0 or  1, bufferstr)
    else
        self:SettleGame("sss")
    end
    
end

return HighArenaStrategy