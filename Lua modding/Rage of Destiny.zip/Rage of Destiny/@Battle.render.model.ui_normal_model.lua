local ui_normal_model = BaseClass()

local cUINormalModel = CS.LJY.NX.UINormalModel

function ui_normal_model:__init(anchor, resname, restype, callback)
    self.anchor = anchor
    if resname and restype then
        self.cmodel = cUINormalModel(self.anchor.canchor, resname, restype, callback)
    else
        self.cmodel = cUINormalModel(self.anchor.canchor)
    end
end

function ui_normal_model:load(resname, restype, callback)
    self.cmodel:LoadModel(resname, restype, callback)
end

function ui_normal_model:release()
    if self.cmodel then
        self.cmodel:Release()
        self.cmodel = nil
    end

    if self.anchor then
        self.anchor:DeleteMe()
        self.anchor = nil
    end
end

function ui_normal_model:get_game_item_model()
    return self.cmodel
end

function ui_normal_model:model_rotate(x, y, z)
    if self.cmodel then
        self.cmodel:ModelRotate(x or 0, y or 0, z or 0)
    end
end

function ui_normal_model:model_localposition(x, y, z)
    if self.cmodel then
        self.cmodel:ModelLocalPosition(x or 0, y or 0, z or 0)
    end
end

function ui_normal_model:model_position(x, y, z)
    if self.cmodel then
        self.cmodel:ModelPosition(x or 0, y or 0, z or 0)
    end
end

function ui_normal_model:model_scale(scale)
    if self.cmodel then
        self.cmodel:ModelScale(scale)
    end
end

function ui_normal_model:showmodel()
    if self.cmodel then
        self.cmodel:ShowModel()
    end
end

function ui_normal_model:hidemodel()
    if self.cmodel then
        self.cmodel:HideModel()
    end
end

return ui_normal_model