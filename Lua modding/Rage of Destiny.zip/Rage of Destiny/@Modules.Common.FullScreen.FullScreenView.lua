local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"
local NewbieWidget = require "Core.Implement.UI.Widgets.NewbieWidget"
local TweenTools =  require "Common.Util.TweenTools"

local FullScreenView = FullScreenView or LuaWidgetClass(NewbieWidget)
FullScreenView.fullViewList = {}
FullScreenView.curFullView = nil
FullScreenView.autoUpdateDepth = false
FullScreenView.benable = true

local v2Zero = Vector2.zero
-- fullScreenOption{
--	viewName
--  background 
--  property：{{物品id,icon,badd}}
--  bShowPhone ：nil is true
--  bShowPlayerInfo ：nil is false
--  onclosefunc 
--  fulleffect
--  explainContentId 
-- }

function FullScreenView.PushView(view)
	if view.fullScreenOption and FullScreenView.benable then
		--将上一个view隐藏,实际在luayout里面还是打开的状态
		local lastView =  FullScreenView.fullViewList[#FullScreenView.fullViewList]
		if lastView and lastView.go then
			lastView.fullhide = true
			--lastView:OnClose()
			lastView.go:SetActive(false)
			lastView:OnHideWidgetObj()
			LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ReconnectView)
		end	

		table.insert(FullScreenView.fullViewList, view)
		FullScreenView.curFullView = view
		local fullView = LuaLayout.Instance:GetWidget(UIWidgetNameDef.FullScreenView)		
		if not fullView:IsOpen() then
			fullView:OpenView()
		else
			fullView:UpdateInfo()
			FullScreenView.UpdateDepth()
		end	
		-- local MainProxy = require "Modules.Main.MainProxy"
		-- MainProxy.Instance:OpenFullScreenWidgetNotify(view.wigetName)
	end	
end

function FullScreenView.EraseView(view)
	if view.fullScreenOption and FullScreenView.benable then

		for idx,fullview in pairs(FullScreenView.fullViewList) do
			if fullview == view then
				table.remove(FullScreenView.fullViewList, idx)
				break
			end
		end
		if #FullScreenView.fullViewList == 0 then
			LuaLayout.Instance:CloseWidget(UIWidgetNameDef.FullScreenView)
			FullScreenView.curFullView = nil

			local view1 = LuaLayout.Instance:GetWidget(UIWidgetNameDef.TerritoryView)
			local view2 = LuaLayout.Instance:GetWidget(UIWidgetNameDef.FieldView)
			if view1 and view1:IsOpen() then
			elseif view2 and view2:IsOpen() then
			else
				local MainProxy = require "Modules.Main.MainProxy"
				MainProxy.Instance:ReShowNotify()
			end

			FullScreenView.CloseFullViewStarTween()

		else
			FullScreenView.curFullView = FullScreenView.fullViewList[#FullScreenView.fullViewList]
			
			--将上一个view显示
			if FullScreenView.curFullView and FullScreenView.curFullView.go then
				FullScreenView.curFullView.go:SetActive(true)
				FullScreenView.curFullView.fullhide = false
				FullScreenView.curFullView:OnShowWidgetObj()
				-- FullScreenView.curFullView:OnOpen()
				FullScreenView.UpdateDepth()
				local MainProxy = require "Modules.Main.MainProxy"
				MainProxy.Instance:OpenFullScreenWidgetNotify(FullScreenView.curFullView.wigetName)
			end
			
			local fullView = LuaLayout.Instance:GetWidget(UIWidgetNameDef.FullScreenView)				
			if fullView.state ~= WidgetState.open then
				fullView:OpenView()
			else				
				fullView:UpdateInfo()
			end			
		end	
	end	
end

--关闭全屏界面播放主界面动效
function FullScreenView.CloseFullViewStarTween()
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MainView)
	if view and view:IsOpen() then
		view:ShowOpenTween()
	end	

    view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.CampaignView)
    if view and view:IsOpen() then
        view:ShowOpenTween()
    end
end

function FullScreenView.CloseTween()
	--关闭播放动画
	LuaWidgetFactor.bTween = false
	FullScreenView.benable = false

	if FullScreenView.curFullView then
		FullScreenView.curFullView:CloseView()
		FullScreenView.curFullView = nil
	end	
end
		
function FullScreenView.CloseAllView()	
	--关闭播放动画
	LuaWidgetFactor.bTween = false
	FullScreenView.benable = false

	if FullScreenView.curFullView then
		FullScreenView.curFullView:CloseView()
		FullScreenView.curFullView = nil
	end	
	
	for _,view in pairs(FullScreenView.fullViewList) do
		view.fullhide = nil
		view:CloseView()
	end	
	FullScreenView.fullViewList = {}

	local fullView = LuaLayout.Instance:GetWidget(UIWidgetNameDef.FullScreenView)
	if fullView:IsOpen() then
		fullView:CloseView()
	end		

	FullScreenView.benable = true
	LuaWidgetFactor.bTween = true
end

function FullScreenView.UpdateDepth()
	local curView = FullScreenView.curFullView
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.FullScreenView)
	if view and view:IsOpen() and curView then
		local depth = UILayerTool.GetNextDepth()
		view:SetDepth(view.tweenObj ,curView.canvasDepth + 1)
		view:SetDepth(view.go ,curView.canvasDepth - 1)
		view:SetModelDepth(view.go, curView.modelDepth)
		view:SetModelDepth(view.backTex.gameObject, -999)
		view:SetModelDepth(view.tweenObj, 1000)
	end	
end	

function FullScreenView.UpdateInfoDepth(depth)
	local curView = FullScreenView.curFullView
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.FullScreenView)
	if view and view:IsOpen() and curView then
		view:SetDepth(view.tweenObj, depth)
	end
end

function FullScreenView.UpdateOption(option)
	-- local curView = FullScreenView.curFullView
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.FullScreenView)
	if view and view:IsOpen() then
		view:ShowUpdateOption(option)
	end	
end

--是否打开了全屏View
function FullScreenView.InFullView()
	return (FullScreenView.fullViewList and next(FullScreenView.fullViewList))
end

--property= list: {{1010001, "jinbitubiao", true,{AppFacade.Shop,2}},}}
function FullScreenView.SetProperty(list)
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.FullScreenView)
	if view and view:IsOpen() then
		view:ShowOrHidePropertyItem(list)
	end	
end

--------------------

local GameUIUtil = CS.GameUIUtil

function FullScreenView:OnLoad()
	AssetManager.LoadUIPrefab(self, "UICommon.FullScreenView",self.LoadEnd)
end

function FullScreenView:LoadEnd(obj)
	self:SetGo(obj)

	self.tweenObj = self:GetChild(obj, "info")
	self.tweenRect = self:GetComponent(self.tweenObj, "RectTransform")
	self.toPos = self.tweenRect.anchoredPosition
	self.fromPos = self.tweenRect.anchoredPosition + Vector3.New(0, 100, 0)	

	self.propertyRoot = GameObjTools.GetChild(obj, "info/CHorizontalItem")  
	self.propertyObj = GameObjTools.GetChild(obj, "info/CHorizontalItem/item1")
	self.propertyGroup = GameObjTools.GetComponent(self.propertyRoot, "HorizontalLayoutGroup")
	self.propertyBackRect = self:GetChildComponent(self.propertyObj, "GoldBrick/back", "RectTransform")

	self.propertyList = {}			
	self.propertyObj:SetActive(false)

	self.backTex = self:GetChildComponent(obj ,"background", "CTexture")
	self.backRectTra = self:GetComponent(self.backTex, "RectTransform")

	self.titleTypeObj1 = self:GetChild(obj, "info/type1")
	self.titleTypeObj2 = self:GetChild(obj, "info/type2")
	self.titleTypeObj3 = self:GetChild(obj, "info/type3")
	self.titleTypeObj4 = self:GetChild(obj, "info/type4")

	--self.titleSp1 = self:GetChildComponent(self.titleTypeObj1 ,"title/COutline_title", "CSprite")
	self.titleLab1 = self:GetChildComponent(self.titleTypeObj1 ,"title/COutline_title", "CLabel")
	self.titleCloseBtn1 = self:GetChildComponent(self.titleTypeObj1, "escBtn", "CButton")
	self.titleInfoBtn1 = self:GetChildComponent(self.titleTypeObj1, "title/COutline_title/CButton_info", "CButton")
	self.titleInfoBtn1:AddClick(function()
		if self.option.explainContentTb then
			GameLogicTools.ShowTextById(self.option.explainContentTb[self.explainIndex or 1])
		else
			GameLogicTools.ShowTextById(self.option.explainContentId)
		end
	end)
	self.titleRedDot1=self:GetChild(self.titleTypeObj1,"title/COutline_title/reddot")
	self.titleRedDotLab1=self:GetChildComponent(self.titleTypeObj1,"title/COutline_title/reddot/label","CLabel")

	self.titleCloseBtn1:AddClick(function()
		self:PlayCloseViewSound()
		self:CheckTriggerNewBieClick(1)
		self:OnClickClose() 

	end)

	--self.titleSp2 = self:GetChildComponent(self.titleTypeObj2 ,"title/COutline_title", "CSprite")
	self.titleLab2 = self:GetChildComponent(self.titleTypeObj2 ,"title/COutline_title", "CLabel")
	self.titleInfoBtn2 = self:GetChildComponent(self.titleTypeObj2, "title/COutline_title/CButton_info", "CButton")
	self.titleCloseBtn2 = self:GetChildComponent(self.titleTypeObj2, "escBtn", "CButton")

	self.titleRedDot2=self:GetChild(self.titleTypeObj2,"title/COutline_title/reddot")
	self.titleRedDotLab2=self:GetChildComponent(self.titleTypeObj2,"title/COutline_title/reddot/label","CLabel")

	self.titleCloseBtn2:AddClick(function()
		self:PlayCloseViewSound()
		self:CheckTriggerNewBieClick(2)
		self:OnClickClose() 

	end)

	self.titleInfoBtn2:AddClick(function()
		if self.option.explainContentTb then
			GameLogicTools.ShowTextById(self.option.explainContentTb[self.explainIndex or 1])
		else
			GameLogicTools.ShowTextById(self.option.explainContentId)
		end
	end)

	self.titleLab3 = self:GetChildComponent(self.titleTypeObj3,"title/COutline_title", "CLabel")
	self.titleInfoBtn3 = self:GetChildComponent(self.titleTypeObj3, "title/COutline_title/CButton_info", "CButton")
	self.titleCloseBtn3 = self:GetChildComponent(self.titleTypeObj3, "escBtn", "CButton")
	self.titleRedDot3=self:GetChild(self.titleTypeObj3,"title/COutline_title/reddot")
	self.titleRedDotLab3=self:GetChildComponent(self.titleTypeObj3,"title/COutline_title/reddot/label","CLabel")
	self.titleCloseBtn3:AddClick(function()
		self:PlayCloseViewSound()
		self:CheckTriggerNewBieClick(3)
		self:OnClickClose()

	end)
	self.titleInfoBtn3:AddClick(function()
		if self.option.explainContentTb then
			GameLogicTools.ShowTextById(self.option.explainContentTb[self.explainIndex or 1])
		else
			GameLogicTools.ShowTextById(self.option.explainContentId)
		end
	end)
	
	self.titleLab4 = self:GetChildComponent(self.titleTypeObj4,"title/COutline_title", "CLabel")
	self.titleInfoBtn4 = self:GetChildComponent(self.titleTypeObj4, "title/COutline_title/CButton_info", "CButton")
	self.titleCloseBtn4 = self:GetChildComponent(self.titleTypeObj4, "escBtn", "CButton")
	self.titleRedDot4=self:GetChild(self.titleTypeObj4,"title/COutline_title/reddot")
	self.titleRedDotLab4=self:GetChildComponent(self.titleTypeObj4,"title/COutline_title/reddot/label","CLabel")
	self.titleCloseBtn4:AddClick(function()
		self:PlayCloseViewSound()
		self:CheckTriggerNewBieClick(4)
		self:OnClickClose()

	end)
	self.titleInfoBtn4:AddClick(function()
		GameLogicTools.ShowTextById(self.option.explainContentId)
	end)
	self.back2Sp4 = self:GetChildComponent(self.titleTypeObj4, "escBtn/esc1/back2", "CSprite")

	self.closeBtnList = {}
	table.insert(self.closeBtnList, self.titleCloseBtn1) 
	table.insert(self.closeBtnList, self.titleCloseBtn2)
	table.insert(self.closeBtnList, self.titleCloseBtn3)
	table.insert(self.closeBtnList, self.titleCloseBtn4)


	self.propertyinfo = {}
	self.propertyinfo.position = {}
	self.propertyinfo.position[1] = self.propertyRoot.transform.localPosition.x
	self.propertyinfo.position[2] = self.propertyRoot.transform.localPosition.y
	self.propertyinfo.spacing = self.propertyGroup.spacing
	-- self.propertyinfo.backicon = "di_ziyuanlan"
	-- self.propertyinfo.plusicon = "ziyuanjiahaotubiao"
	self.propertyinfo.backSize = {self.propertyBackRect.sizeDelta.x, self.propertyBackRect.sizeDelta.y}
	self.propertyinfo.backPosition = {self.propertyBackRect.anchoredPosition.x, self.propertyBackRect.anchoredPosition.y}

	self:Step(0)
end

function FullScreenView:CheckTriggerNewBieClick(btnIdx)
	local NewbieManager = require "Modules.Newbie.NewbieManager"
	local cur_newbie, cur_step = NewbieManager.Instance:GetCurNewbieId()

	for i,v in ipairs(self.closeBtnList) do
		if btnIdx == i then
			self:OnTriggerClickBtn(v)
			break
		end
	end

end

--关闭界面音效播放
function FullScreenView:PlayCloseViewSound()
	local AudioManager = require "Common.Mgr.Audio.AudioManager"
	--关闭特殊界面播放特殊音效
	local viewCloseSound = {
		[UIWidgetNameDef.BagRootView] = "bag_close",

	}

	local curView = FullScreenView.curFullView
	if curView and curView.wigetName then
		if viewCloseSound[curView.wigetName] then
			AudioManager.PlaySoundByKey(viewCloseSound[curView.wigetName])
		else
			--通用音效
			AudioManager.PlaySoundByKey("bottom_view")
		end
	end
end

function FullScreenView:RegisterNewbie()
	--关闭按钮有四种样式
	for i,v in ipairs(self.closeBtnList) do
		local _patent = v.gameObject.transform.parent
		if _patent and _patent.gameObject.activeSelf then
			local NewbieDef = require "Modules.Newbie.NewbieDef"
			for _newbie_id, _steps in pairs(NewbieDef.FullScreenClose) do
				for _,_step in ipairs(_steps) do
					self:RegisterButton(v, _newbie_id, _step)
				end
			end
		end
	end
end

function FullScreenView:ShowEscGuide(guideid)
	self:ShowWeakguide(self.titleCloseBtn1, guideid)
	self:ShowWeakguide(self.titleCloseBtn2, guideid)
end

function FullScreenView:OnOpen()
	self.propertys = {}
	self:UpdateInfo()	
	self:AutoRegister()
	FullScreenView.UpdateDepth()
	local MainProxy = require "Modules.Main.MainProxy"
	MainProxy.Instance:OpenFullScreenWidgetNotify(self.wigetName)
end

function FullScreenView:OnClose()
	self:AutoUnRegister()
	self:UnRegisterNewbie()


	if self.bgEffect then
		self.bgEffect:Destroy()
		self.bgEffect = nil
	end		

	--关闭按钮，回退层级，先激活obj，避免设置失效
	self:RevertCloseDepth()

	self.titleRedDot1:SetActive(false)
	self.titleRedDot2:SetActive(false)
	self.titleRedDot3:SetActive(false)
	self.titleRedDot4:SetActive(false)

	self:ClearCoinTween()
	self:ClearGemTween()
	self:ClearExpTween()
	self:ClearCoinTimer()
	self:ClearGemTimer()
	self:ClearExpTimer()

end

function FullScreenView:OnDestroy()
	self:AutoUnRegister()
	-- for _,item in pairs(self.propertyList) do
	-- 	item.effect:Destroy()
	-- 	if item.sequence then
	-- 		item.sequence:Kill()
	-- 		item.sequence = nil
	-- 	end		
	-- end	
	self:ClearePropertyTween()
	self.go:SetActive(false)
	self:UnRegisterNewbie()
	if self.bgEffect then
		self.bgEffect:Destroy()
		self.bgEffect = nil
	end	

	self:ClearCoinTween()
	self:ClearGemTween()
	self:ClearExpTween()
	self:ClearCoinTimer()
	self:ClearGemTimer()
	self:ClearExpTimer()

end

function FullScreenView:OnClickInfoBtn()

end

function FullScreenView:OnClickClose()
	--判断过场动画是否结束
	-- local interludeView = LuaLayout.Instance:GetWidget(UIWidgetNameDef.UIAniView)
	-- if interludeView and interludeView:IsOpen() then return end

	local curView = FullScreenView.curFullView
	if curView then
		self:CloseCallback(curView)
	end	
end


function FullScreenView:CloseCallback(curView)
	if curView.fullScreenOption and curView.fullScreenOption.onclosefunc then 
		curView.fullScreenOption.onclosefunc()
	else	
		curView:CloseView()
	end	
end

function FullScreenView:OnClickItem(data)
	if self:CheckTeamState() and data and data[4] then	
		if type(data[4]) == "table" then
			UIOperateManager.Instance:OpenWidget(data[4][1], data[4][2])
		else
			LuaLayout.Instance:OpenWidget(data[4])				
		end	
	end	
end	

function FullScreenView:OnClickItemTips(data, obj)
	if data and data[1] then
		GameLogicTools.ShowLabelTipsById(data[1], obj.transform.position)
		-- if type(data[1]) == "number" then
		-- 	local pos = obj.transform.localPosition
		-- 	local rootPos = self.propertyRoot.transform.localPosition
		-- 	local  endPosX = (pos.x - math.abs(rootPos.x)) 
		-- 	GameObjTools.ShowItemTips(data[1], obj.transform.position)
		-- end
	end
end

------------------

function FullScreenView:ShowOpenTween()	
	self.tweenRect.anchoredPosition = self.fromPos
	GameUIUtil.SetGroupAlpha(self.tweenObj ,0)
	
	local time = 0.6
	GameUIUtil.SetGroupAlphaInTime(self.tweenObj, 1, time)
	local tween = self.tweenRect:DOAnchorPosY(self.toPos.y, time)
	tween:OnComplete(function ()
		self:RegisterNewbie()
	end)
end

function FullScreenView:ShowCloseTween()
	self.tweenRect.anchoredPosition = self.toPos
	GameUIUtil.SetGroupAlpha(self.tweenObj ,1)

	local time = 0.3
	GameUIUtil.SetGroupAlphaInTime(self.tweenObj, 0, time)
	self.tweenRect:DOAnchorPosY(self.fromPos.y, time)
end

function FullScreenView:UpdateInfo()
	if FullScreenView.curFullView and FullScreenView.curFullView.fullScreenOption then
		self:ShowUpdateOption(FullScreenView.curFullView.fullScreenOption, FullScreenView.curFullView)
	end	
	self:ShowOpenTween()
end

--激活obj设置层级才生效
function FullScreenView:RevertCloseDepth()
	self.titleTypeObj1:SetActive(true)
	self.titleTypeObj2:SetActive(true)
	self.titleTypeObj3:SetActive(true)
	self.titleTypeObj4:SetActive(true)
	self:SetCloseBtnDepth(0)
end

function FullScreenView:ShowUpdateOption(option, curView)
	if not option then return end
	self.option = option
	-- self.titleLbl.text = self:GetWord(option.viewName or "")
	-- self.titleSp.SpriteName = option.viewName or ""
	self:RevertCloseDepth()

	local titleType = option.titleType or 1
	self.titleTypeObj1:SetActive(titleType == 1  and true or false)
	self.titleTypeObj2:SetActive(titleType == 2 and true or false)
	self.titleTypeObj3:SetActive(titleType == 3 and true or false)
	self.titleTypeObj4:SetActive(titleType == 4 and true or false)


	--self.titleSp1.SpriteName = option.viewName or ""
	--self.titleSp2.SpriteName = option.viewName or ""
	self.titleLab1.text = self:GetWord(option.viewName) or ""
	self.titleLab2.text = self:GetWord(option.viewName) or ""
	self.titleLab4.text = self:GetWord(option.viewName) or ""

	self.explainIndex = 1
	if option.explainContentId or option.explainContentTb then
		self.titleInfoBtn1.gameObject:SetActive(titleType == 1  and true or false)
		self.titleInfoBtn2.gameObject:SetActive(titleType == 2 and true or false)
		self.titleInfoBtn4.gameObject:SetActive(titleType == 2 and true or false)
	else
		self.titleInfoBtn1.gameObject:SetActive( false)
		self.titleInfoBtn2.gameObject:SetActive(false)
		self.titleInfoBtn4.gameObject:SetActive(false)
	end

	if self.bgEffect then
		self.bgEffect:Destroy()
		self.bgEffect = nil
	end	

	if option.background and option.background ~= "" then
		local background = string.format("Background.%s", option.background)
		self.backTex.gameObject:SetActive(true)
		AssetManager.LoadUITexture(AssetManager.UITexture.UITex, background, self.backTex, function ()
			if self.backTex and not IsNull(self.backTex) and self.backTex.texture and IsNull(self.backTex.texture) then
				print("-------FullScreenView----AssetManager.LoadUITexture------second load---------")
				AssetManager.LoadUITexture(AssetManager.UITexture.UITex, background, self.backTex, nil, true)
			end
		end)
		
		if option.backgroundPos then
			self.backRectTra.anchoredPosition = option.backgroundPos
		else
			self.backRectTra.anchoredPosition = v2Zero
		end

		if option.fulleffect then
			self.bgEffect = UIEffectItem.New(option.fulleffect, self.backTex.gameObject)
			self.bgEffect:Open()
			self.bgEffect:SetOrderLayer(curView.canvasDepth)
		end			
	else
		self.backTex.gameObject:SetActive(false)
	end	

	if option.bShowExplainIcon then

	end

	if option.property and next(option.property) then
		self:ShowOrHidePropertyItem(option.property)
		self:InitPropertyPosition(option.propertyinfo)
	else
		self:ShowOrHidePropertyItem(false)
	end

	-- print(table.dump(option))

	self.back2Sp4.SpriteName = option.back2Sp4Name and option.back2Sp4Name or "anniu_fanhui2"
end

function FullScreenView:InitPropertyPosition(propertyinfo)
	local info = propertyinfo or self.propertyinfo
	self.propertyRoot.transform.localPosition = Vector2.New(info.position[1], info.position[2])
	self.propertyGroup.spacing = info.spacing 
	for _,item in pairs(self.propertyList) do
		if item.itemObj.activeSelf then
			if info.backicon then
				item.backSp.SpriteName = info.backicon
			end
			if item.addSp then	
				item.addSp.SpriteName = info.plusicon
			end	
			if info.backSize then
				item.backRect.sizeDelta = Vector2.New(info.backSize[1], info.backSize[2])
			end
			if info.backPosition then
				item.backRect.anchoredPosition = Vector2.New(info.backPosition[1], info.backPosition[2])
			end
		end	
	end		
end

function FullScreenView:ShowOrHidePropertyItem(list)
	for _,item in pairs(self.propertyList) do
		item.itemObj:SetActive(false)
	end	
		
	if list then
		self.propertyRoot:SetActive(true)
		self:InitPropertyInfo(list)
		self:ShowPropertyInfo()
		self:SetPropertyDepth(0)
	else
		self.propertyRoot:SetActive(false)	
	end	
end

function FullScreenView:SetPropertyRootActive(isActive)
	self.propertyRoot:SetActive(isActive)
end

function FullScreenView:GetPropertyItem()
	for _,item in pairs(self.propertyList) do
		if not item.itemObj.activeSelf then
			item.itemObj:SetActive(true)
			return item
		end			
	end	

	local item = {}
	local itemObj = GameObjTools.AddChild(self.propertyRoot, self.propertyObj)
	itemObj:SetActive(true)
	item.itemObj = itemObj
	item.tweenObj = self:GetChild(itemObj, "GoldBrick")
	item.iconSp = self:GetChildComponent(itemObj, "GoldBrick/sprite", "CSprite")
	item.numLbl = self:GetChildComponent(itemObj, "GoldBrick/label", "CLabel")
	item.addObj = self:GetChild(itemObj, "GoldBrick/plus")
	item.addBtn = self:GetComponent(item.addObj, "CButton")
	item.addBtn:AddClick(function (go) self:OnClickItem(item.data) end)
	item.tipsBtn = self:GetChildComponent(itemObj, "GoldBrick/CButton_tips", "CButton")
	item.tipsBtn:AddClick(function(go) self:OnClickItemTips(item.data, itemObj) end)
	-- item.effect = UIEffectItem.New("UI_FullScreen_coin", itemObj)
	-- item.effect:SetPosition(34,6, 0)	
	item.redObj = self:GetChild(itemObj, "CSprite_red")
	item.tweenLbl = self:GetChildComponent(itemObj, "GoldBrick/change", "CLabel")
	item.backSp = self:GetChildComponent(itemObj, "GoldBrick/back", "CSprite")
	item.backRect = self:GetChildComponent(itemObj, "GoldBrick/back", "RectTransform")
	item.addSp = self:GetChildComponent(itemObj, "GoldBrick/plus/sprite", "CSprite")
	item.iconSpScale = item.iconSp.gameObject.transform.localScale

	table.insert(self.propertyList, item)
	return item
end

function FullScreenView:InitPropertyInfo(list)
	for _,info in pairs(list) do
		local item = self:GetPropertyItem()
		item.iconSp.SpriteName = info[2]
		item.iconSp:SetNativeSize()
		item.goodsid = info[1]
		item.addObj:SetActive(info[3])
		item.data = info		
	end	
end

function FullScreenView:SetPropertyDepth(depth)
	for _,item in pairs(self.propertyList) do
		if item.itemObj.activeSelf then
			self:SetDepth(item.tweenObj, depth)
			self:SetDepth(item.redObj, depth)
		end	
	end	
end

function FullScreenView:ShowPropertyInfo()
	self:ClearePropertyTween()

	for _,item in pairs(self.propertyList) do
		if item.itemObj.activeSelf then
			self:ShowPropertyTween(item)
		end	
	end
end

function FullScreenView:ClearePropertyTween()
	for k,item in pairs(self.propertyList) do
		if item.numTween then
			item.numTween:Stop()
			item.numTween = nil
		end
		if item.shakeTween then
			item.shakeTween:Kill()
			item.shakeTween = nil
		end
	end
end

function FullScreenView:ShowPropertyTween(item)
	local num = GameLogicTools.GetPropertyByGoodsId(item.goodsid)		
	if self.propertys[item.goodsid] and num > self.propertys[item.goodsid] then
		local time = 1000
		-- item.numTween = RenderUtil.tween(self.propertys[item.goodsid], num, time, function (value)
		-- 	item.numLbl.text = GameLogicTools.GetNumStr(math.floor(value))
		-- end)
		item.numLbl.text = GameLogicTools.GetNumStr(num)
		item.shakeTween = TweenTools.TopShakeObj(item.iconSp.gameObject, 0.1, 0, false, 2)
	else
		item.numLbl.text = GameLogicTools.GetNumStr(num)
	end	
	self.propertys[item.goodsid] = num

	--暂时先写死
	if item.goodsid == 2110001 then
		item.redObj:SetActive(num > 0)
		if num > 0 then
			if not item.sequence then
				item.sequence = TweenTools.ShakeObj(item.tweenObj, 2, 2)
			end	
		else
			if item.sequence then
				item.sequence:Kill()
				item.sequence = nil
				item.tweenObj.transform.eulerAngles = Vector3.zero
			end	
		end	
	else
		item.redObj:SetActive(false)
		if item.sequence then
			item.sequence:Kill()
			item.sequence = nil
			item.tweenObj.transform.eulerAngles = Vector3.zero
		end
	end	
end

-- itemList = {{goodsId = xxx, count = xxx, type = x}， {goodsId = xxx, count = xxx, type= x}} 
function FullScreenView:ShowPropertyEffect(itemlist)
	for _,info in pairs(itemlist) do
		for _,item in pairs(self.propertyList) do
			if info.goodsId == item.goodsid then
				-- item.effect:SetOrderLayer(self:GetCurrentDepth())
				-- item.effect:Play()

				if not AudioManager.IsActivingByKey("money") then
					AudioManager.PlaySoundByKey("money")
				end	

				item.tweenLbl.transform.localPosition = Vector2.New(54.5, -38.6)
				item.tweenLbl.text = '+'..info.count
				item.tweenLbl.gameObject:SetActive(true)
				local tween = item.tweenLbl.transform:DOLocalMoveY(20 ,1)
				tween:OnComplete(function ()					
					item.tweenLbl.text = ""
					item.tweenLbl.gameObject:SetActive(false)					
					end)

			end	
		end
	end
	self:SetPropertyDepth(self:GetCurrentDepth() + 2)
end

function FullScreenView:GetPropertyItemByIndex(index)
	if not self.propertyList then return end
	
	for i,item in ipairs(self.propertyList) do
		if i == index then
			return item
		end	
	end
end

function FullScreenView:GetProperTyItemsByGoodsId(goodsId)
	if not self.propertyList then return end
	for i,item in ipairs(self.propertyList) do
		if item.itemObj.activeSelf then
			if item.goodsid == goodsId then
				return item.iconSp.gameObject.transform.position
			end	
		end
	end
end

function FullScreenView:GetPropertyDataByGoodsId(goodsId)
	if not self.propertyList then return end
	for i,item in ipairs(self.propertyList) do
		if item.itemObj.activeSelf then
			if item.goodsid == goodsId then
				return item
			end
		end
	end
end

function FullScreenView:TargetTweenScale(targetObj, fromVector, toVector, time, total_time, interval, isLoop)
	targetObj.transform.localScale = fromVector

	local targetTween1 = targetObj.transform:DOScale(toVector, time)
	targetTween1:SetEase(Ease.InBack)
	local targetTween2 = targetObj.transform:DOScale(fromVector, time)
	targetTween2:SetEase(Ease.OutBack)
	local targetBagSequence = DOTween.Sequence()
	targetBagSequence:Append(targetTween1)
	targetBagSequence:Append(targetTween2)
	if interval and isLoop then
		targetBagSequence:AppendInterval(interval)
		targetBagSequence:SetLoops(-1)
	end
	return targetBagSequence
end

function FullScreenView:ResetItemScale(goodsId)
	local item = FullScreenView:GetPropertyDataByGoodsId(goodsId)
	if item then
		item.iconSp.gameObject.transform.localScale = item.iconSpScale
	end
end

function FullScreenView:ClearCoinTween()
	if self.coinSeq then
		self.coinSeq:Kill()
		self.coinSeq = nil
	end
	self:ResetItemScale(702001)
end

function FullScreenView:ClearGemTween()
	if self.gemSeq then
		self.gemSeq:Kill()
		self.gemSeq = nil
	end
	self:ResetItemScale(701001)
end

function FullScreenView:ClearExpTween()
	if self.expSeq then
		self.expSeq:Kill()
		self.expSeq = nil
	end
	self:ResetItemScale(703001)
end

function FullScreenView:ClearCoinTimer()
	if self.coinTimer then
		self:RemoveTimer(self.coinTimer)
		self.coinTimer = nil
	end
	self:ResetItemScale(702001)
end

function FullScreenView:ClearGemTimer()
	if self.gemTimer then
		self:RemoveTimer(self.gemTimer)
		self.gemTimer = nil
	end
	self:ResetItemScale(701001)
end

function FullScreenView:ClearExpTimer()
	if self.expTimer then
		self:RemoveTimer(self.expTimer)
		self.expTimer = nil
	end
	self:ResetItemScale(703001)
end

--飞图标 目标缩放
function FullScreenView:FlyItemScaleTween(scaleType, total_time)
	if scaleType == BagDef.FlyIconType.FullScreenCion then
		self:CoinTween(scaleType, total_time, true)
	elseif scaleType == BagDef.FlyIconType.FullScreenGem then
		self:GemTween(scaleType, total_time, true)
	elseif scaleType == BagDef.FlyIconType.FullScreenExp then
		self:ExpTween(scaleType, total_time, true)
	end
end

function FullScreenView:CoinTween(scaleType, total_time, isLoop)
	local toVector = Vector3.New(1.65, 1.65, 1.65)
	local per_time = 0.02
	local interval = 0.02
	self:ClearCoinTween()
	self:ClearCoinTimer()
	local item = self:GetPropertyDataByGoodsId(BagDef.FlyIconTypeGoodsId[scaleType])
	if item then
		local coinObj, coinScale = item.iconSp.gameObject, item.iconSpScale
		self.coinSeq = self:TargetTweenScale(coinObj, coinScale, toVector, per_time, total_time, interval, isLoop)
		self.coinTimer = self:AddTimer(function()
			self:ClearCoinTween()
		end, total_time, 1)
	end
end

function FullScreenView:GemTween(scaleType, total_time, isLoop)
	local toVector = Vector3.New(1.65, 1.65, 1.65)
	local per_time = 0.02
	local interval = 0.02
	self:ClearGemTween()
	self:ClearGemTimer()
	local item = self:GetPropertyDataByGoodsId(BagDef.FlyIconTypeGoodsId[scaleType])
	if item then
		local coinObj, coinScale = item.iconSp.gameObject, item.iconSpScale
		self.gemSeq = self:TargetTweenScale(coinObj, coinScale, toVector, per_time, total_time, interval, isLoop)
		self.gemTimer = self:AddTimer(function()
			self:ClearGemTween()
		end, total_time, 1)
	end
end

function FullScreenView:ExpTween(scaleType, total_time, isLoop)
	local toVector = Vector3.New(1.65, 1.65, 1.65)
	local per_time = 0.02
	local interval = 0.02
	self:ClearExpTween()
	self:ClearExpTimer()
	local item = self:GetPropertyDataByGoodsId(BagDef.FlyIconTypeGoodsId[scaleType])
	if item then
		local coinObj, coinScale = item.iconSp.gameObject, item.iconSpScale
		self.expSeq = self:TargetTweenScale(coinObj, coinScale, toVector, per_time, total_time, interval, isLoop)
		self.expTimer = self:AddTimer(function()
			self:ClearExpTween()
		end, total_time, 1)
	end
end

function FullScreenView:SetCloseBtnDepth(depth)	
	for i,v in ipairs(self.closeBtnList) do
		self:SetDepth(v.gameObject, depth)
	end
end

function FullScreenView:SetObjAlpha(active)
	self.go:SetActive(active)
end

function FullScreenView.EvtNotify.Chat.data:Chat_UpdateFullTitleRedDot(data,args)
	local count=args.redcount
	if count and count > 0 then
		if self.titleTypeObj1.activeSelf then
			self.titleRedDot1:SetActive(true)
			self.titleRedDotLab1.text=tostring(count)
		end
		if self.titleTypeObj2.activeSelf then
			self.titleRedDot2:SetActive(true)
			self.titleRedDotLab2.text=tostring(count)
		end
		if self.titleTypeObj3.activeSelf then
			self.titleRedDot3:SetActive(true)
			self.titleRedDotLab3.text=tostring(count)
		end
		if self.titleTypeObj4.activeSelf then
			self.titleRedDot4:SetActive(true)
			self.titleRedDotLab4.text=tostring(count)
		end
	else
		self.titleRedDot1:SetActive(false)
		self.titleRedDot2:SetActive(false)
		self.titleRedDot3:SetActive(false)
		self.titleRedDot4:SetActive(false)
	end
	
end
--notify
function FullScreenView.EvtNotify.RoleInfo.data:Currency_Change(data,args)
	self:ShowPropertyInfo()
end

function FullScreenView.EvtNotify.Store.data:Currency_Info_Change(data, property)
	self:ShowOrHidePropertyItem(property)
end

function FullScreenView.EvtNotify.Bag.data:Update_Bag()
	self:ShowPropertyInfo()
end

function FullScreenView.EvtNotify.RankList.data:UpdateTitleName( data,name)
	self:UpdateTitleName(name)
end

function FullScreenView.EvtNotify.Activity.data:UpdateTitleName( data,name)
	self:UpdateTitleName(name)
end

function FullScreenView.EvtNotify.Realm.data:UpdateActivityTitle( data,args)
	self:UpdateTitleName(args.name)
	self.option.explainContentId = args.explainContentId
end

function FullScreenView:UpdateTitleName(name)
	self.titleLab1.text = name or ""
	self.titleLab2.text = name or ""
	self.titleLab4.text = name or ""
end

function FullScreenView:UpdateExplainIndex(index)
	self.explainIndex = index or 1
end

function FullScreenView:Updatebackground(bg_name)
	local background = string.format("Background.%s", bg_name)
	AssetManager.LoadUITexture(AssetManager.UITexture.UITex, background, self.backTex)
end

return FullScreenView