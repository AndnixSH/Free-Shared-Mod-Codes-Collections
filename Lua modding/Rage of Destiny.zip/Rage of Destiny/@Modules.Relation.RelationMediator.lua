local RelationMediator = RelationMediator or BaseClass(StdMediator)
local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"
function RelationMediator:OnEnterLoadingEnd()		
	
end
function RelationMediator:OnEnterScenceEnd()
	
end
function RelationMediator:OnEnterScenceFirst()

   
    self:DelayExecute(function()
        
        local ModuleManager = require "Common.Mgr.UI.ModuleManager"
        local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
        local RelationProxy = require "Modules.Relation.RelationProxy"
        RelationProxy.Instance:Send20300()
	end)
end

return RelationMediator