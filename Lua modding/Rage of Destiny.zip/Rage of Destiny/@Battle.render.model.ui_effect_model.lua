local ui_effect_model = BaseClass()

local cUIEffectModel = CS.LJY.NX.UIEffectModel

function ui_effect_model:__init(resname, callback)
    self.cmodel = cUIEffectModel(nil, resname, callback)
end

function ui_effect_model:release()
    if self.cmodel then
        self.cmodel:Release()
        self.cmodel = nil
    end

    if self.anchor then
        self.anchor:DeleteMe()
        self.anchor = nil
    end
end

function ui_effect_model:get_game_item_model()
    return self.cmodel
end

function ui_effect_model:showmodel()
    if self.cmodel then
        self.cmodel:ShowModel()
    end
end

function ui_effect_model:hidemodel()
    if self.cmodel then
        self.cmodel:HideModel()
    end
end

function ui_effect_model:model_rotate(x, y, z)
    if self.cmodel then
        self.cmodel:ModelRotate(x or 0, y or 0, z or 0)
    end
end

function ui_effect_model:model_localposition(x, y, z)
    if self.cmodel then
        self.cmodel:ModelLocalPosition(x or 0, y or 0, z or 0)
    end
end

function ui_effect_model:model_position(x, y, z)
    if self.cmodel then
        self.cmodel:ModelPosition(x or 0, y or 0, z or 0)
    end
end

function ui_effect_model:model_scale(x, y, z)
    if self.cmodel then
        self.cmodel:ModelScale(x, y, z)
    end
end

function ui_effect_model:set_position(parentObj)
    if self.cmodel then
        self.cmodel:ModelSetParent(parentObj)
    end    
end

function ui_effect_model:set_orderLayer(orderlayer)
    if self.cmodel then
        self.cmodel:SetOrderLayer(orderlayer)
    end    
end

function ui_effect_model:set_maskArea(minX, maxX, minY, maxY)
    if self.cmodel then
        self.cmodel:SetMaskArea(minX, maxX, minY, maxY)
    end
end   

function ui_effect_model:do_localMove(tox, toy, toz, duration, callback, snapping)
    if self.cmodel then
        self.cmodel:DOLocalMove(tox, toy, toz, duration, callback, snapping)
    end
end

function ui_effect_model:do_scale(to, duration)
    if self.cmodel then
        self.cmodel:DOScale(to, duration)
    end
end 

return ui_effect_model