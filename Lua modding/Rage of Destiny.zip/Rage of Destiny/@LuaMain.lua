LuaMain = {is_reboot = false}
local main = require "First.LobbyMain"
-- local main = require "Battle.GameMain"
-- local main = require "Test.TestMain"

local function _SetGameParam()
	local Application = CS.UnityEngine.Application
	local isEditor = Application.isEditor
	local Screen = CS.UnityEngine.Screen
	local SleepTimeout = CS.UnityEngine.SleepTimeout
            
    Screen.sleepTimeout = SleepTimeout.NeverSleep
	if isEditor then
        Application.targetFrameRate = 60
	else
		Application.targetFrameRate = 60
 	end
    Application.runInBackground = true
end

-- 整个lua程序的入口类
function LuaMain.Start(checkUpdate)
	_SetGameParam()
    main.Start(checkUpdate)
end

-- 重启
function LuaMain.ReBoot()
    LuaMain.is_reboot = true

    main.Dispose()
    main.Start(false)
end

function LuaMain.Update(time, deltaTime)
    main.Update(time, deltaTime)
end

function LuaMain.ApplicationPause(pause)
    if main.ApplicationPause then
        main.ApplicationPause(pause)
    end
end

function LuaMain.ApplicationFocuse(focus)
    if main.ApplicationFocuse then
        main.ApplicationFocuse(focus)
    end
end

function LuaMain.FixedUpdate(fixedTime, fixedDeltaTime)

end

function LuaMain.OnBackPressed()
    if main.OnBackPressed then
        main.OnBackPressed()
    end
end

function LuaMain.CSpriteAwakeCallback(sprite)
    if main.CSpriteAwakeCallback then
        main.CSpriteAwakeCallback(sprite)
    end
end

function LuaMain.CLabelAwakeCallback(label)
    if main.CLabelAwakeCallback then
        main.CLabelAwakeCallback(label)
    end
end

function LuaMain.CheckNeedToRestartLuaEnv()
	if main.CheckNeedToRestartLuaEnv then
		return main.CheckNeedToRestartLuaEnv()
	end
	return false
end

function LuaMain.Destroy()
    main.Destroy()
end

function LuaMain.Dispose()
    main.Dispose()
end