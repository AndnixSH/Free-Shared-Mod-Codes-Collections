local RealmMediator = RealmMediator or BaseClass(StdMediator)
local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"
local ActivityProxy = require "Modules.Realm.RealmProxy"
function RealmMediator:OnEnterLoadingEnd()		
	
end
function RealmMediator:OnEnterScenceEnd()
	
end
function RealmMediator:OnEnterScenceFirst()

    self:DelayExecute(function ()
        local RealmProxy = require "Modules.Realm.RealmProxy"
        RealmProxy.Instance:Send63000()
    end)
    
end

return RealmMediator