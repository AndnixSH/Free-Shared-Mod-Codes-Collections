local EventCenter = require "Common.Util.EventCenter"
local EventCenterDef = require "Common.Util.EventCenterDef"

local ModuleManager = {}

local openTypeDic

function ModuleManager.GetModuleUIDef(key)
    local config = ConfigManager.GetConfig("data_modules")
    if config[key] then           
        return config[key]
    end
end

function ModuleManager.GetUIViewCfg(widgetDef)
    local config = ConfigManager.GetConfig("data_uiview")
    if config[widgetDef] then           
        return config[widgetDef]
    end
end

--retrun false / openlv
function ModuleManager.GetUIViewIsLock(widgetDef)
    local cfg = ModuleManager.GetUIViewCfg(widgetDef)
    if cfg and cfg.level then
        local curcount = 0
        return curcount < cfg.level and cfg.level or false
    else
        return false
    end
end

--
function ModuleManager.GetUIRootDef(widgetName)
    local option = ModuleManager.GetModuleUIDef("ViewRoot")[widgetName]
    return option
end

--全屏配置
function ModuleManager.GetFullScreenOption(widgetName)
    local option = ModuleManager.GetModuleUIDef("FullScreenOption")[widgetName]
    return option
end

--主界面活动配置
function ModuleManager.GetActivityConfig()
    return ModuleManager.GetModuleUIDef("ActivityItem")
end

--主界面系统配置
function ModuleManager.GetSystemConfig()
    return ModuleManager.GetModuleUIDef("SystemItem")
end

--主界面左侧活动配置
function ModuleManager.GetLeftActivityConfig()
    return ModuleManager.GetModuleUIDef("LeftActivityItem")
end

--系统模块开启条件
function ModuleManager.GetSystemOpenConfig()
    local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
    return ModuleOpenDef.SystemOpen   
end

--获取系统开启条件
function ModuleManager.GetSystemOpenCondition(openType)
    local CampaignProxy = require "Modules.Campaign.CampaignProxy"
    local LanguageUtil = require "First.Util.LanguageUtil"
    local curMainLineId = CampaignProxy.Instance:GetPassMainlineid()  --主线id
    local vip = RoleInfoModel.viplevel--vip等级
    local bopen, open_lv, open_vip, content = true, nil, nil
    local content_msg = ""
    local config = ModuleManager.GetSystemOpenConfig()
    if config[openType] then
        if config[openType].conditions then
            for i,value in ipairs(config[openType].conditions) do
                if value.openMainId and value.vip then
                    bopen = ((curMainLineId >= value.openMainId) and (vip >= value.vip)) and true or false
                    open_vip = value.vip
                    open_lv = value.openMainId
                    break
                elseif value.openMainId then
                    bopen = curMainLineId >= value.openMainId and true or false
                    open_lv = value.openMainId
                    if bopen then break end
                elseif value.vip then
                    bopen = vip >= value.vip and true or false
                    open_vip = value.vip
                    if bopen then break end
                end
            end
        end

        if not bopen then
            if config[openType].tipsType == 1 then
                local ConfirmTipsView = require "Modules.Common.Msg.ConfirmTipsView"
                local name, title, content = config[openType].name, config[openType].title, config[openType].content
                content_msg = LanguageUtil.GetWord(content)
            else
                local content = config[openType].title
                content_msg = LanguageUtil.GetWord(content)
            end            
        end
    end
    return open_lv, open_vip, content_msg
end

--判断系统是否开启  bshowTips:是否弹tips
function ModuleManager.SystemIsOpen(openType, bshowTips, ...)
    local LanguageUtil = require "First.Util.LanguageUtil"
    if AppConfig.ISALONE then
        return true
    elseif AppConfig.SystemOpen then
        -- 本地将AppConfig 文件里的SystemOpen改为true 本地开启
        return true
        
    end
    local bopen = true
    local bshowTips = bshowTips == nil and true or bshowTips
    local parama = {...} --目前都是通过主线id判断
    local config = ModuleManager.GetSystemOpenConfig()

    local CampaignProxy = require "Modules.Campaign.CampaignProxy"
    local curMainLineId = CampaignProxy.Instance:GetPassMainlineid()  --主线id
    -- print("ModuleManager.SystemIsOpen", curMainLineId)

    local vip = RoleInfoModel.viplevel--vip等级
    if config[openType] then
        --敬请期待
        if not config[openType].conditions or not next(config[openType].conditions) then
            bopen = false
            if bshowTips then
                GameLogicTools.ShowMsgTips("Common_1002")  --敬请期待
            end
            return bopen
        end

        if config[openType].conditions then
            for i,value in ipairs(config[openType].conditions) do
                if value.openMainId and value.vip then
                    bopen = ((curMainLineId >= value.openMainId) and (vip >= value.vip)) and true or false
                    break
                elseif value.openMainId then
                    bopen = curMainLineId >= value.openMainId and true or false
                    if bopen then break end
                elseif value.vip then
                    bopen = vip >= value.vip and true or false
                    if bopen then break end
                end
            end
        end
        
        -- --未开启tantips
        if bshowTips and not bopen then
            if config[openType].tipsType == 1 then
                local ConfirmTipsView = require "Modules.Common.Msg.ConfirmTipsView"
                local name, title, content = config[openType].name, config[openType].title, config[openType].content

                name, title, content = LanguageUtil.GetWord(name), LanguageUtil.GetWord(title), LanguageUtil.GetWord(content)
                ConfirmTipsView.ShowConfirmTipsView(name, title, content)
            else
                local content = config[openType].title
                content = LanguageUtil.GetWord(content)
                GameLogicTools.ShowMsgTips(content)
            end
        end

    end

    return bopen
end

--初始化系统开放
function ModuleManager.InitSystemOpen()
    local config = ModuleManager.GetSystemOpenConfig()
    -- local CampaignProxy = require "Modules.Campaign.CampaignProxy"
    -- local curMainLineId = CampaignProxy.Instance:GetPassMainlineid()  --主线id
    -- local vip = RoleInfoModel.viplevel--vip等级

    openTypeDic = {} --key:ModuleOpenDef.SystemOpenType value:true

    for k,v in pairs(config) do
        if ModuleManager.SystemIsOpen(k, false) then
            openTypeDic[k] = true
        end
    end

    -- print("ModuleManager.InitSystemOpen", table.dump(openTypeDic))
end

function ModuleManager.CheckSystemOpen()
    local config = ModuleManager.GetSystemOpenConfig()

    for k,v in pairs(config) do
        --测试
        -- local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
        -- if k == ModuleOpenDef.SystemOpenType.MallDaily then
        --     print(tostring(openTypeDic[k]), tostring(ModuleManager.SystemIsOpen(k, false)))
        -- end

        if not openTypeDic[k] and ModuleManager.SystemIsOpen(k, false) then
            openTypeDic[k] = true
            -- print("ModuleManager.CheckSystemOpen", k)
            EventCenter.Trigger(EventCenterDef.Id.SystemOpen, k)
        end
    end
end

return ModuleManager