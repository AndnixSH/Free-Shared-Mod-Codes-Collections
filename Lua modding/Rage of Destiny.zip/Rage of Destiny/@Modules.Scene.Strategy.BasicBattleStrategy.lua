local BasicSceneStrategy = require "Modules.Scene.Strategy.BasicSceneStrategy"
local BattleBaseClass = require "Core.Implement.UI.Class.BattleBaseClass"

local BattleProxy = require "Modules.Battle.BattleProxy"
local HeroProxy = require "Modules.Hero.HeroProxy"

local main = require "Battle.GameMain"
local _curgameid = nil
local _playerlist = nil
local _wincamp = nil

local BasicBattleStrategy = BasicBattleStrategy or LuaEventClass(BasicSceneStrategy, NxFaceProxyDataEvt, BattleBaseClass, TimerFactor)
function BasicBattleStrategy:Inspection()
    self:RegisterEvent()

    _playerlist = self.args[1]
    if AppConfig.ISALONE then
        self:_InspectionSuc()
    else
        -- self:RequireNetworkStart() --弃用，放在切场景前校验
        self:_InspectionSuc()
    end
end

function BasicBattleStrategy:OnLoad()
    self:SetStep(0)
end

function BasicBattleStrategy:Destroy()
    self:UnRegisterEvent()
    if self.CloseAllTimer then
        self:CloseAllTimer()
    end
    if _curgameid then
        _curgameid = nil
        _playerlist = nil
        _wincamp = nil
        main.Destroy()
        BattleProxy.Instance:SetInBattle(false)
    end
    self:OnDestroyGame()
end

function BasicBattleStrategy:RegisterEvent()
    self:AutoRegister()
end

function BasicBattleStrategy:UnRegisterEvent()
    self:AutoUnRegister()
    self:UnRegisterBattleGlobalEvent()
end

--弃用
--初始化游戏数据给服务器检查(暂时自检通过)
function BasicBattleStrategy:RequireNetworkStart()
    local heroinfos = {}
    for _, player in pairs(_playerlist) do
        if player.camp == CAMP.RED then
            table.insert(heroinfos, { player.roleid, player.stance })
        end
    end

    -- strategy差异化 需要回调给子类
    self:OnRequireEnter(heroinfos)
    -- BattleProxy.Instance:Send50005(_curgameid, heroinfos)
end

--弃用
--发起游戏开始请求
function BasicBattleStrategy:RequireNetworkEnter(activity, ...)
    BattleProxy.Instance:Send50005(activity, ...)
end

--发起游戏结算请求
function BasicBattleStrategy:RequireNetworkSettle(activity, result, ...)
    BattleProxy.Instance:Send50001(activity, result, ...)
end

-- 服务器检查是否可进入回调
function BasicBattleStrategy:OnNetworkStart(result)
    if result == 0 then
        self:_InspectionSuc()
    else
        self:UnRegisterEvent()
        self:_InspectionFail()
    end
end

function BasicBattleStrategy:OnScenePreload(loader)
    local battleargs = self:GetBattleArg()
    if battleargs and battleargs.playerlist then
        local player_list = battleargs.playerlist
        local data_sprite_body = ConfigManager.GetConfig("sprite_body")
        local data_preload = require "Config.data_preload"
        for i, value in pairs(player_list) do
            local roleid = value.roleid
            local conf = data_sprite_body[roleid]
            local key = conf.prefab_id[1]

            loader.AddLoad({ key = key, type = AssetType.ACTOR })
            if data_preload.role[roleid] then
                loader.AddLoadList(data_preload.role[roleid])
            end
        end
    end
end

function BasicBattleStrategy:GetCustomArg()
    return self.args[2]
end

function BasicBattleStrategy:GetBattleArg()
    return self.args[1]
end

--notify
function BasicBattleStrategy.EvtNotify.Battle.data:EnterGame(data, result)
    self:OnNetworkStart(result)
end

function BasicBattleStrategy.EvtNotify.Battle.data:SettleGame(data, args)
    local wincamp = (args.result == 0 and CAMP.RED or CAMP.BLUE)
    self:OnSettleGame(wincamp, args.rewards, args.buffer_str)
end

function BasicBattleStrategy.EvtNotify.Battle.data:RestartGame(data, args)
    if _curgameid then
        _curgameid = nil
        _playerlist = nil
        _wincamp = nil
        main.Destroy()
        BattleProxy.Instance:SetInBattle(false)
    end
    self:OnRestartGame(data, args)
end

--MainStrategy 等待英雄数据回来再次挂机
function BasicBattleStrategy.EvtNotify.Hero.data:UpdateHero(data, args)
    if self.MainStrategy_UpdateHeroInfo then
        self:MainStrategy_UpdateHeroInfo()
    end
end

function BasicBattleStrategy.event.game:gameprepared(parama)
    --是否回放
    BattleProxy.Instance:BattleReport(parama.breport)

    self:OnGamePrepared(parama)
end

--game logic

--BattleProxy:GetGamePlayerTable()
--------------计算用                                                ---玩法用
--playerlist {{heroid = 1, level = 1, rank = 1,                     roleid = cfg.id, prop = {camp = CAMP.BLUE, stance = idx, skill_list = {}}, attr = {},  }}
function BasicBattleStrategy:StartGame(gameprop, seed)
    if not gameprop then
        local battleargs = self:GetBattleArg()
        gameprop = {
            rawplayers = battleargs.playerlist,
            extra = battleargs.extra,
            config_key = self.OnGetConfigKey and self:OnGetConfigKey()
        }
        seed = battleargs.seed
    end
    gameprop.extra = gameprop.extra or {}                 -- 额外信息
    gameprop.activity_info = gameprop.activity_info or {} -- 玩法信息
    gameprop.activity_info.fast_start = gameprop.extra and gameprop.extra.report and gameprop.extra.report.fast_start or false

    --print("BasicBattleStrategy:StartGame", table.dump(gameprop))

    if self.strategycfg.gameid ~= GAMEPLAYID.HANGUP then
        local canAffect = true
        local enemy_id = self.OnGetEnemeyId and self:OnGetEnemeyId()
        if enemy_id then
            local data_enemy = ConfigManager.GetConfig("data_enemy")
            local enemy_config = data_enemy[enemy_id]
            if enemy_config and enemy_config.boss.coordinate then
                canAffect = false
            end
        end

        if canAffect then
            local SettingMenuProxy = require "Modules.SettingMenu.SettingMenuProxy"
            gameprop.activity_info.fast_start = not SettingMenuProxy.Instance:GetSceneStartEffect()
        end
    end

    if not self.strategycfg or not self.strategycfg.gameid or not self.strategycfg.activityid then
        print("<=== strategycfg is null ==>")
        return
    end

    -- 多余的代码
    --for _, player in pairs(gameprop.rawplayers) do
    --    if player.rank and player.level then
    --        player.attr = HeroProxy.Instance:GetHeroAttr(player.roleid, player.rank, player.level)
    --    end
    --end

    if _curgameid then
        main.Destroy()
    end
    self:_StartGame(gameprop, self.strategycfg.gameid, seed)
end

function BasicBattleStrategy:_StartGame(gameprop, gameid, seed)
     --print("<=== StartGame ==>", gameid, self.sceneid, table.dump(gameprop))
    _curgameid = gameid
    _wincamp = nil

    local gameinfo = { gameid = gameid, activityid = self.strategycfg.activityid, seed = seed, sceneid = self.sceneid }
    main.Start(gameinfo, gameprop, BattleProxy.Instance:IsJump())
    if gameid ~= GAMEPLAYID.HANGUP then
        BattleProxy.Instance:SetInBattle(true)
    end

    local game_input = require "Battle.input.game_input"
    local operation = game_input.operation

    operation.onsettle = function(wincamp, total_time)
        _wincamp = wincamp
        BattleProxy.Instance:SetInBattle(false)
        local winresult = (wincamp == CAMP.RED and 0 or 1)
        if gameprop.extra.report then
            if self.OnReportSettleGame then
                self:OnReportSettleGame(_wincamp, total_time)
            else
                print("ERROR!没有实现OnReportSettleGame", self.strategycfg.activityid)
                BattleProxy.Instance:OnSettleGame(winresult, total_time)
            end
        elseif AppConfig.ISALONE then
            BattleProxy.Instance:OnSettleGame(winresult, total_time)
        else
            self:OnRequireSettle(winresult, gameprop, total_time)
        end
    end
    self:RegisterBattleGlobalEvent()
    self:OnStartGame()
end

--战斗结束延迟弹结算界面时间
function BasicBattleStrategy:SettleGameDelayTime(func)
    if self.strategycfg and self.strategycfg.delaytime then
        self:AddTimer(function()
            func()
        end, self.strategycfg.delaytime, 1)
    else
        func()
    end
end

function BasicBattleStrategy:_GetRecordStr()
    local input_record = require "Battle.input.input_record"
    local buffstr = input_record.serialize()
    return buffstr or ""
end

function BasicBattleStrategy:_EncodeSettleData(datas, encoder)
    -- print("encode", table.dump(datas))
    encoder = encoder or NetEncoder.New()
    encoder:Encode("I2", #datas)
    for _, campdata in ipairs(datas) do
        encoder:Encode("I2", #campdata)
        for _, spritedata in ipairs(campdata) do
            encoder:Encode("I4I2I2I1", spritedata.roleid, spritedata.level, spritedata.rank, spritedata.stance)
            encoder:Encode("I4I4I4", spritedata.damage, spritedata.bharm, spritedata.heal)
            encoder:Encode("I1", spritedata.dead and 1 or 0)
        end
    end
    return encoder.buffer
end

function BasicBattleStrategy:GetSettleStr(sd)
    sd = sd or BattleProxy.Instance:GetSettleData()
    local settlestr = self:_EncodeSettleData(sd) or ""
    local framestr = self:_GetRecordStr() or ""
    -- print('settlestr', #settlestr, 'framestr', #framestr)
    return string.pack(">s2s2", settlestr, framestr)
end

--子类继承
function BasicBattleStrategy:OnStartEntry()
    --场景加载结束
end

function BasicBattleStrategy:OnStartGame()
    --游戏加载结束
end

function BasicBattleStrategy:OnRequireEnter(heroinfos)
    --请求进入
    self:RequireNetworkEnter(self.strategycfg.activityid, heroinfos)
end

function BasicBattleStrategy:OnRequireSettle(result)
    --请求结算 0/1: win/lose
    self:RequireNetworkSettle(self.strategycfg.activityid, result)
end

function BasicBattleStrategy:OnSettleGame(wincamp)
    --游戏结算回调
end

function BasicBattleStrategy:OnDestroyGame()
    --游戏摧毁通知
end

function BasicBattleStrategy:OnRestartGame()
    --游戏再来一次
end

function BasicBattleStrategy:OnGamePrepared(parama)
end

return BasicBattleStrategy