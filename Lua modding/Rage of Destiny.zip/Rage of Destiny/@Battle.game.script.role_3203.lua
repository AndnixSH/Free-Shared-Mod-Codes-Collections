
local conf = {skill = {}, buff = {}, bullet = {}}
-- "法林用单手竖着投掷回旋镖攻击最近的敌人，造成N%攻击力的伤害

conf.skill[320301] = script.composite {
    main = {
        action = {
            default = {
                {trigger.time, {0},     action.active_random, { "attack01", "attack02"}, },
                {trigger.time, {600},   action.addchild, {typeid = 320301}, "bullet" },
                --{trigger.time, {500}, action.cast, },
                {trigger.time, {900} },
            },
            hold = {
                {trigger.time, {0},     action.active, "hold" },
                --{trigger.time, {500}, action.cast, },
                {trigger.time, {500}},
            },
        },
        event = {
            { scriptevent.onstart, onfire = function (self)
                local castid_go = self.static.id
                local castid_back = self.caller.buff:get_state("bullet_through") or self.static.id
                local backrate = self.caller.buff:contains_state("bullet_through") and 600 or 0
                local distance = self.static.spell_range[1] + 500 -- 飞行距离直接读表里的释放距离
                self.prop.bullet_args = {distance = distance, duration = 400, castid = {castid_go, castid_back}, speed_multi = 0, backrate = backrate}
            end},

            { "320301_bullet_back", onfire = function (self)
                self.action:run("hold")
            end},
            
            { scriptevent.onend, onfire = function (self)
            end},
        },
    },
    bullet = {
        event = {
            { scriptevent.onstart, onfire = function(self)
                self.caller.body:addscript(scriptcommon.bullet_pullback, self.prop.bullet_args)
            end},
            { eventdef.sprite_collide, onfire = function (self,collideobj)
                if collideobj == self.owner.body.parent then
                    self.owner.body.parent:sendmessage("320301_bullet_back")
                end
            end},
            }
    }
}

--当法林攻击目标时，飞镖有30%的几率穿透敌人，并可以使回旋镖回到自己的手中，回来的过程中造成二次伤害造成70%的伤害

-- "法林以一只脚为中心，双手握着大回旋镖顺时针转三圈，第三圈的时候奋力扔出，使回旋镖在对方人群密集处造成伤害，之后收回每秒造成200%物理伤害。
-- 表现：回旋镖飞行时要求弧形弹道，飞镖在飞行时有外发光便于与普攻做区分。"
-- 2级：伤害量提升
-- 3级：每命中一个目标，后续伤害提升n%，持续m秒
conf.skill[320311] = script.composite {
    main = {
        action = {
            default = {
                {trigger.time, {0},     action.active, "spell_01_start", caller.skill.pause, 1000},
                {trigger.time, {1167},  action.addchild, script.prop("bullet_table"), "bullet" },
                {trigger.time, {0},     action.active, "spell_01_loop"},
                {trigger.time, {7000}},
            },
            hold = {
                {trigger.time, {0}, action.active, "spell_01_end"},
                {trigger.time, {1767},},
                --{trigger.time, {500}, action.cast, },
            },
        },
        event = {
            { scriptevent.onstart, onfire = function (self)
                local castid_go = self.static.id    
                local castid_back = self.static.id
                local targets = self.action:range()
                local pos
                if #targets > 0 then
                    pos = targets[1].body.position
                else
                    self.action:stop()
                    return 
                end

                local degree = 65
                self.prop.castid = self.static.id   
                self.prop.bullet_castid = self.static.id + 50
                self.prop.bullet_args = { duration = 1500, rangeid = castid_go, wait_time = 2000, castid = {castid_go, castid_back}, minspeed = 2000, position = pos, 
                degree = degree, back_speed_rate = 5 ,stop_distance = 500, duration_mul = 1.4}
                self.prop.bullet_table = {typeid = 320311, position = self.owner.body.position + (self.owner.body.header:fmul(1000))}
                self.caller.buff:add_state("320311_use")
            end},


            { "320311_bullet_back", onfire = function (self)
                self.action:run("hold")
            end},

            { scriptevent.onend, onfire = function (self)
                self.caller.buff:remove_state("320311_use")
            end},
            
        },
        check = function(self)
            return not self.caller.buff:contains_state("320311_use")
        end 
    },
    bullet = {
        event = {
            { scriptevent.onstart, onfire = function(self)
                self.caller.body:addscript(scriptcommon.bullet_pullback_curve, self.prop.bullet_args)
                self.prop.child = nil
            end},
            { eventdef.sprite_collide, onfire = function (self,collideobj)
                if collideobj == self.owner.body.parent then
                    self.owner.body.parent:sendmessage("320311_bullet_back")
                end
            end},
            { eventdef.bullet_move_pause, onfire = function (self)
                self.prop.child = self.action:addchild({typeid = 999999, position = self.owner.position}, "bullet_single")
            end},
            { eventdef.sprite_dead, modifer = eventmdf.excludeself, onfire = function (self,fromobj)
                if fromobj == self.owner.body.parent then
                    self.owner:destroy()
                    if self.prop.child then
                        self.prop.child:destroy()
                    end
                end
            end},
        }
    },
    bullet_single = {
        action = {
            default = {
                {trigger.time, {500,500,4}, action.cast, script.prop("bullet_castid")},
                {trigger.time, {1000}, caller.body.destroy},
            }
        }
    },
}
conf.skill[320312] = conf.skill[320311]
conf.skill[320313] = conf.skill[320311]

-- 法林从身上取下竹筒,跳起来在空中2个后空翻以后，在空中快速连续吹4只毒箭袭击随机的4个敌人造成50%物理伤害并附带丛林特制毒素使敌人受到持续伤害
-- 2级：使持续伤害提高到6秒
-- "3级：中毒目标降低生命恢复效果
-- "
-- 4级：伤害量提升至70%

conf.skill[320321] = {
        action = {
            default = {
                {trigger.time, {0},         action.active, "spell_02"},
                {trigger.time, {1167},      action.addchild, {typeid = 320321}, scriptcommon.bullet_trace, script.prop("bullet_args") },
                {trigger.time, {100,100,3}, action.addchild, {typeid = 320321}, scriptcommon.bullet_trace, script.prop("bullet_args") },
                {trigger.time, {1400}},
            },
        },
        event = {
            { scriptevent.onstart, onfire = function (self)
                local rangeid = self.static.id 
                self.prop.bullet_args = {speed = 37000, duration = 2000, rangeid = rangeid}
            end},
        },
}
conf.skill[320322] = conf.skill[320321]
conf.skill[320323] = conf.skill[320321]
conf.skill[320324] = conf.skill[320321]

-- 当法林攻击目标时，飞镖有30%的几率穿透敌人，并可以使回旋镖回到自己的手中，回来的过程中造成二次伤害造成70%的伤害
-- 2级：当回旋镖造成二次伤害时产生击退效果

conf.skill[320331] = {
    action = {
        default = {
             {trigger.time, {0}, action.addstartbuff, },
         },                 
    }, 
    event = {
        {scriptevent.onstart, onfire = function(self)
            self.caller.buff:add_state("bullet_through", self.static.id + 20)
        end},
        {eventdef.skill_damage, onfire = function(self,damage_table)
            
        end},
        
    },
}
conf.skill[320332] = conf.skill[320331]




return conf

