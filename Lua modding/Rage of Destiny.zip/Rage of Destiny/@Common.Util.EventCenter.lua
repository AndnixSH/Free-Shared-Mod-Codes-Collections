local EventCenter = {}
EventCenter.events = {}

local events = EventCenter.events

function EventCenter.Add(key, func)
	if (not events[key]) then
		events[key] = {}
	end

	if (not events[key][func]) then
		events[key][func] = func
	else
		logError("EventCenter.Add Repeat")
	end
end

function EventCenter.Remove(key, func)
	if (events[key] and events[key][func]) then
		events[key][func] = nil
	else
		logError("EventCenter.Remove Not")
	end
end

function EventCenter.Trigger(key, ...)
	if (events[key]) then
		for k, v in pairs(events[key]) do
			v(...)
		end
	end
end

return EventCenter