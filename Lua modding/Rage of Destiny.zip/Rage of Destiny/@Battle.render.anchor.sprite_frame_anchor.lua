local sprite_frame_anchor = BaseClass()

local cSpriteFrameAnchor = CS.LJY.NX.SpriteFrameAnchor

function sprite_frame_anchor:__init(sprite_id)
    self.canchor = cSpriteFrameAnchor(sprite_id)
end

function sprite_frame_anchor:__delete()
    if self.canchor then
        self.canchor = nil
    end
end

return sprite_frame_anchor