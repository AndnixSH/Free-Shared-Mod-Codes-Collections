global = {}

local main = {}

function main:init()
    global = { service = {}, _listservice = {} }
end

function main:initmodules(args)

    local require = require

    local libpaths = args.libpaths  -- _G,全局库
    for _, value in ipairs(libpaths) do
        require(value)
    end

    local corelist = args.corelist  -- global
    if corelist then
        for _, value in ipairs(corelist) do
            local name = assert(value.name)
            local path = assert(value.path)
            global[name] = require(path)
            self:_log("add core", name)
        end
    end

    local servicelist = args.servicelist  -- global.service
    if servicelist then
        for _, value in ipairs(servicelist) do
            local name = assert(value.name)
            local path = assert(value.path)
            local service = require(path)
            global.service[name] = service
            table.insert(global._listservice, service)
            if service.init then
                service:init(value.args)
            end
            self:_log("add service", name, service)
        end
    end

    local loaderlist = args.loaderlist
    local logic_factory = global.service.logic_factory
    if loaderlist then
        for _, value in ipairs(loaderlist) do
            local name = assert(value.name)
            local service = assert(value.service)

            logic_factory:addloader(name, global.service[service], value.isassign)
            self:_log("add loader", name)
        end
    end
end

function main:_log(...)
    -- print(...)
end

function main:process(time, tick)
    global.service.timer:process(time, tick)
end

function main:process_late(time, tick)
    global.service.frame:process_late(time, tick)
    global.service.time:process(time, tick)
end

function main:dispose()
    for _, service in ipairs(global._listservice) do
        if service.dispose then
            service:dispose()
        end
    end
    global = nil
end

return main