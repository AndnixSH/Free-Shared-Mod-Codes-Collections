local HeroMediator = HeroMediator or BaseClass(StdMediator)
local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"
local HeroProxy = require "Modules.Hero.HeroProxy"
function HeroMediator:OnEnterLoadingEnd()
	if SceneManager.Instance.sceneType == SceneDef.SceneType.Main then
		-- local HeroProxy = require "Modules.Hero.HeroProxy"
		-- HeroProxy.Instance:Send20000()
	end		
end

function HeroMediator:OnEnterScenceFirst()
	HeroProxy.Instance:Send20000()
end

function HeroMediator:OnEnterScenceEnd()
	HeroProxy.Instance:Send20012()
end

function HeroMediator:OnEnterScenceInit()
	if SceneManager.Instance.enterSceneType == SceneDef.SceneType.Drama then
		HeroProxy.Instance:Send20000()
	end
end

return HeroMediator