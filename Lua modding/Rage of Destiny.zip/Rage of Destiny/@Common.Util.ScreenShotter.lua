local enable = false

local ScreenShotter = {}
local CSScreenShotter = CS.ScreenShotter
local cpature = nil
local MonoNetPing = nil

local function before_capture()
    if SystemConfig.is_gm then
        if not MonoNetPing then
            local obj = CS.UnityEngine.GameObject.Find("Shell")
            if obj then
                MonoNetPing = obj:GetComponent(typeof(CS.MonoNetPing))
            end
        end
        if MonoNetPing then
            MonoNetPing.enabled = false
        end
    end
end

local function after_capture()
    if SystemConfig.is_gm then
        if MonoNetPing then
            MonoNetPing.enabled = true
        end
    end
end

function ScreenShotter.Enable()
    enable = true
end

function ScreenShotter.Capture(cb)

    if not enable then
        if cb() then cb() end
        return
    end

    if cpature then
        if cb then cb() end
        return 
    end

    before_capture()
    CSScreenShotter.Capture(function (texture)
        -- print('capture', debug.traceback())
        after_capture()
        cpature = texture
        if cb then cb() end
    end)

end

function ScreenShotter.Texture()
    return cpature
end

function ScreenShotter.Clear()
    if cpature then
        CS.UnityEngine.Object.Destroy(cpature)
        cpature = nil
    end
end

return ScreenShotter