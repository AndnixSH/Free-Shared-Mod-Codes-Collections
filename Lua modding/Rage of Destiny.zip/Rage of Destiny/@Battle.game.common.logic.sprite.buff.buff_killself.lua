local logic = { buff = {}, event = service.event() }

function logic:oncreate()
    self.harmcount = 0
    local min,max = table.unpack(self.static.args_script[1])
    self.maxharmcount = tsmath.random(min, max)
end

function logic.event.sprite.public:skill_damage(fromobj, dmgtable)
    if dmgtable.toobj == self.owner then
        self.harmcount = self.harmcount + 1
        self.owner.attr.hp = tsmath.rate(self.owner.attr.hp_max, tsmath.ndiv(self.maxharmcount - self.harmcount, self.maxharmcount))
        -- print('skill_damage', self.harmcount, self.maxharmcount)
        if self.harmcount >= self.maxharmcount then
            self.owner.attr.hp = 0
        end
    end
end

return logic

