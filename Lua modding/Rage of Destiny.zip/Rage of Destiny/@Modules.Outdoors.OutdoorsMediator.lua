local OutdoorsMediator = OutdoorsMediator or BaseClass(StdMediator)
local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"

function OutdoorsMediator:OnEnterLoadingEnd()		
	if SceneManager.Instance.sceneType == SceneDef.SceneType.Main then
	end	
end

function OutdoorsMediator:OnEnterScenceFirst()
end

return OutdoorsMediator