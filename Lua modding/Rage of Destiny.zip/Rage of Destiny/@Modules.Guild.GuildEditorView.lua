local GuildDef = require "Modules.Guild.GuildDef"
local ClistRender = require "Core.Implement.UI.Class.ClistRender"
local ClistItem = require "Core.Implement.UI.Class.ClistItem"
local GuildProxy = require "Modules.Guild.GuildProxy"

-- --最大范围
local root_range =
{
    [1] = -667, --左边x
    [2] = 667, --右边x
    [3] = -375, --下边y
    [4] = 375, --上边y
}

local X_Offset = 0
local Y_Offset = 60


local GuildEditorViewItem = GuildEditorViewItem or BaseClass(ClistItem)

function GuildEditorViewItem:Load(obj)
	self.btn = self:GetComponent(self.go, "CButton")
	self.btn:AddClick(function()
		if self.data then
			--self.data.operate[3] 是方法名
			if self.data.operate[3] then
				self[self.data.operate[3]](self, self.data.guser)
			end
		end
		LuaLayout.Instance:CloseWidget(UIWidgetNameDef.GuildEditorView)
	end)

	self.contentLab = self:GetChildComponent(self.go, "normal/CLabel_label", "CLabel")

end

function GuildEditorViewItem:SetData(data)
	self.data = data
	local operateType, languageKey = self.data.operate[1], self.data.operate[2]
	self.contentLab.text = self:GetWord(languageKey)
end


------------公会相关操作 begin---------------
--公会设置
function GuildEditorViewItem:GuildSetting(to_guser)
	LuaLayout.Instance:OpenWidget(UIWidgetNameDef.GuildSetView)
end
--修改公告
function GuildEditorViewItem:EditorAnnouncement(to_guser)
	LuaLayout.Instance:OpenWidget(UIWidgetNameDef.GuildNoticeView)
end
--入会申请
function GuildEditorViewItem:EnterApply(to_guser)
	LuaLayout.Instance:OpenWidget(UIWidgetNameDef.GuildApplyView)
end
--退出公会
function GuildEditorViewItem:ExitGuild(to_guser)
	GameLogicTools.ShowConfirmById(45, function (bValue)
		if bValue then
			GuildProxy.Instance:Send70003()
		end
	end)
end
--解散公会(公会只有会长一个人时退出公会)
function GuildEditorViewItem:RetireGuild(to_guser)
	GameLogicTools.ShowConfirmById(22, function(value)
		if value then
			GuildProxy.Instance:Send70021()
		end
	end)
	-- GuildProxy.Instance:Send70021()
end

--禅让会长
function GuildEditorViewItem:ExplaceGuild(to_guser)
	local guildInfos = GuildProxy.Instance:GetGuildInfos()
	local toName = ""
	for i,info in ipairs(guildInfos.memberInfos) do
		if info.guser == to_guser then
			toName = info.headItem.nickname
			break
		end
	end
	GameLogicTools.ShowConfirmById(21, function(value)
		if value then
			GuildProxy.Instance:Send70009(to_guser)
		end
	end, toName)
	-- GuildProxy.Instance:Send70009(to_guser)
end
--任命副会长
function GuildEditorViewItem:AppointViceChairman(to_guser)
	GuildProxy.Instance:Send70007(to_guser, GuildDef.Job.ViceChairman)
end
--罢免副会长
function GuildEditorViewItem:RetireViceChairman(to_guser)
	GameLogicTools.ShowConfirmById(56, function (bValue)
		if bValue then
			GuildProxy.Instance:Send70008(to_guser, GuildDef.Job.ViceChairman)
		end
	end, self.data.nickname)
end
--任命无畏之手
function GuildEditorViewItem:AppointFearlessHand(to_guser)
	GuildProxy.Instance:Send70007(to_guser, GuildDef.Job.FearlessHand)
end
--罢免无畏之手
function GuildEditorViewItem:RetireFearlessHand(to_guser)
	GameLogicTools.ShowConfirmById(44, function (bValue)
		if bValue then
			GuildProxy.Instance:Send70008(to_guser, GuildDef.Job.FearlessHand)
		end
	end, self.data.nickname)
end
--举报
function GuildEditorViewItem:GuildReport(to_guser)
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.ReportView)
	if view then
		local data = {}
		data.report_guser = to_guser
		data.nickname = self.data.nickname
		data.uid = self.data.uid
		view.data = data
		view:OpenView()
	end
end

--逐出公会成员
function GuildEditorViewItem:RetireMember(to_guser)
	GameLogicTools.ShowConfirmById(43, function (bValue)
		if bValue then
			GuildProxy.Instance:Send70010(to_guser)
		end
	end, self.data.nickname)
end
------------公会相关操作 end---------------


------------------好友相关操作 begin----------------
--拉黑好友
function GuildEditorViewItem:FriendBlacklist(to_guser)
	local FriendProxy = require "Modules.Friend.FriendProxy"
	FriendProxy.Instance:Send19008(to_guser, 1)
end

--举报好友
function GuildEditorViewItem:FriendReport(to_guser)
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.ReportView)
	if view then
		local data = {}
		data.report_guser = to_guser
		data.nickname = self.data.nickname
		data.uid = self.data.uid
		view.data = data
		view:OpenView()
	end
end

------------------好友相关操作 end----------------


local GuildEditorView = GuildEditorView or LuaWidgetClass()

--operateTables
function GuildEditorView:__init()
	self.perHeight = 64.9
end

function GuildEditorView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Guild.GuildEditorView", self.LoadEnd)
end

function GuildEditorView:LoadEnd(obj)
	self:SetGo(obj)
	self:InitUI()
	self:SetStep(0)
end

function GuildEditorView:InitUI()
	self.backBtn = self:GetChildComponent(self.go, "Black", "CButton")
	self.backBtn:AddClick(function()
		self:CloseView()
	end)
	self.rootObj = self:GetChild(self.go, "RootObj")
	self.backSp = self:GetChildComponent(self.rootObj, "Editor/CSprite_bg", "CSprite")
	self.backTrm = self:GetChildComponent(self.rootObj, "Editor/CSprite_bg", "RectTransform")

	self.origonWidth = self.backTrm.sizeDelta.x

	self.clist = self:GetChildComponent(self.rootObj, "Editor/CList", "CList")
	self.clistRender = ClistRender.New()
	self.clistRender:Load(self.clist, GuildEditorViewItem)
end

function GuildEditorView:OnClose()
end

function GuildEditorView:OnDestroy()
end

function GuildEditorView:OnOpen()
	local count = #self.operateTables
	self.height = self.perHeight * count
	self.clistRender:ClearData()
	self.clistRender:AppendDataList(self.operateTables)
	self.backTrm:DOSizeDelta(Vector2.New(self.origonWidth, self.height), 0.2)
	self:UpdatePosition()
end

function GuildEditorView:UpdatePosition()
	if self.localPosition then
		self.rootObj.transform.localPosition = self.localPosition
	else
		self:SetDirectionPos(self.position)
	end
end

function GuildEditorView:SetDirectionPos(_position)
	self.rootObj.transform.position = _position
	local position = self.rootObj.transform.localPosition
	self.rootObj.transform.localPosition = Vector2.New(position.x, position.y + Y_Offset+self.height, 0)

	-- if (position.y + Y_Offset + self.height) > root_range[4] then
	-- 	self.rootObj.transform.localPosition = Vector2.New(position.x, root_range[4]- Y_Offset, 0)
	-- elseif (position.y + Y_Offset-self.height) < root_range[3] then
	-- 	self.rootObj.transform.localPosition = Vector2.New(position.x, root_range[3]+ Y_Offset+self.height, 0)
	-- else
	-- 	self.rootObj.transform.localPosition = Vector2.New(position.x, root_range[3]+ Y_Offset+self.height, 0)
	-- end

end


return GuildEditorView