local ClistItem = ClistItem or BaseClass(GameObjFactor)

function ClistItem:__init(go)
	self.go = go
	self:Load(go)
	self.index = 0
	self.dataIdx = 0
	self.clist = nil
end

function ClistItem:Load(go)
end

function ClistItem:SetData()
end	 

function ClistItem:OnSelect(index)
end	 

function ClistItem:DeSelect(index)
end	 

function ClistItem:UpdateData(...)
end

function ClistItem:Close(...)
end

function ClistItem:Destroy(...)
end

function ClistItem:ScaleTween(obj, scale, interval)
	local scale = scale or 1.5 
	local defaultVec = Vector3.New(0.8, 0.8, 0.8)
	if obj then
		obj.transform.localScale = defaultVec
		local scaleSeq = DOTween.Sequence()
		local tween1 = obj.transform:DOScale(Vector3.New(scale, scale, scale), 0.2)
		local tween2 = obj.transform:DOScale(Vector3.one, 0.2)
		tween1:SetEase(Ease.InBack)
		tween2:SetEase(Ease.OutBack)
		if interval then
			scaleSeq:AppendInterval(interval)
		end
		scaleSeq:Append(tween1)
		scaleSeq:Append(tween2)
		scaleSeq:AppendCallback(function()
		end)
		return scaleSeq
	end
end


return ClistItem