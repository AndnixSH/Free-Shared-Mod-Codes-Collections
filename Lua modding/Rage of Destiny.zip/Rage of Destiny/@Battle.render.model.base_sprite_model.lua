local base_sprite_model = BaseClass()

local cMaterialPropertyBlock = CS.UnityEngine.MaterialPropertyBlock

function base_sprite_model:__init(anchor, model_name)
    self.anchor = anchor -- lua层封装
    self.cmodel = nil -- C#层model

    self._renderers = {}
    self._block = nil
end

function base_sprite_model:__delete()
    self.anchor = nil
    self.cmodel = nil

    self._renderers = nil

    if self._block then
        self._block:Clear()
    end
    self._block = nil
end

function base_sprite_model:start_active(active_name, speed_rate, tag, callback)
    speed_rate = speed_rate or 1
    tag = tag or 0
    if self.cmodel then
        self.cmodel:StartActive(active_name, speed_rate, tag, callback)
    end
end

function base_sprite_model:stop_active()
    if self.cmodel then
        self.cmodel:StopActive()
    end
end

function base_sprite_model:pause_active()
    if self.cmodel then
        self.cmodel:PauseActive()
    end
end

function base_sprite_model:resume_active()
    if self.cmodel then
        self.cmodel:ResumeActive()
    end
end

function base_sprite_model:set_active_speed(speed_rate)
    if self.cmodel then
        self.cmodel:SpeedActive(speed_rate)
    end
end

function base_sprite_model:pause_anchor()
    if self.cmodel then
        self.cmodel:PauseAnchor()
    end
end

function base_sprite_model:resume_anchor()
    if self.cmodel then
        self.cmodel:ResumeAnchor()
    end
end

function base_sprite_model:show_model()
    if self.cmodel then
        self.cmodel:ShowModel()
    end
end

function base_sprite_model:hide_model()
    if self.cmodel then
        self.cmodel:HideModel()
    end
end

function base_sprite_model:set_layer(layer)
    if self.cmodel and layer then
        self.cmodel:SetLayer(layer)
    end
end

function base_sprite_model:reset_layer()
    if self.cmodel then
        self.cmodel:ResetLayer()
    end
end

function base_sprite_model:get_game_item_model()
    return self.cmodel
end

function base_sprite_model:get_game_object()
    if self.cmodel then
        return self.cmodel.gameItem
    end
end

function base_sprite_model:set_color(color)
    if next(self._renderers) == nil then
        self:_get_model_renderer()
    end

    if not self._block then
        self._block = cMaterialPropertyBlock()
    end

    for _, render in ipairs(self._renderers) do
        self._block:Clear()
        render:GetPropertyBlock(self._block)
        self._block:SetColor("_GlobalColor", color)
        render:SetPropertyBlock(self._block)
    end
end

function base_sprite_model:enable_rim_color(inner_color, inner_power, color, power, intensity)
    --print("-->enable_rim_color")
    if next(self._renderers) == nil then
        self:_get_model_renderer()
    end

    if not self._block then
        self._block = cMaterialPropertyBlock()
    end

    for _, render in ipairs(self._renderers) do
        --local materials = self._renderers_materials[i].materials
        --for j = 0, materials.Length - 1 do
        --    materials[j]:EnableKeyword("_BUFFE_RIM")
        --end

        self._block:Clear()
        render:GetPropertyBlock(self._block)
        self._block:SetFloat("_RimBuff", 1)
        self._block:SetColor("_InnerColor", inner_color);
        self._block:SetFloat("_InnerColorPower", inner_power);
        self._block:SetColor("_RimColor", color)
        self._block:SetFloat("_RimPower", power)
        self._block:SetFloat("_RimIntensity", intensity)
        render:SetPropertyBlock(self._block)
    end
end

function base_sprite_model:disable_rim_color()
    --print("-->> disable_rim_color")
    if next(self._renderers) == nil then
        return
    end

    for i, render in ipairs(self._renderers) do
        --local sharedMaterials = self._renderers_materials[i].sharedMats
        --local materials = self._renderers_materials[i].materials
        --
        --for j = 0, materials.Length - 1 do
        --    materials[j]:DisableKeyword("_BUFFE_RIM")
        --end

        --render.materials = sharedMaterials

        self._block:Clear()
        render:GetPropertyBlock(self._block)
        self._block:SetFloat("_RimBuff", 0)
        --self._block:SetColor("_InnerColor", inner_color);
        --self._block:SetFloat("_InnerColorPower", inner_power);
        --self._block:SetColor("_RimColor", color)
        --self._block:SetFloat("_RimPower", power)
        --self._block:SetFloat("_RimIntensity", intensity)
        render:SetPropertyBlock(self._block)
    end
end

-- 冰冻
function base_sprite_model:frozen()
    if next(self._renderers) == nil then
        self:_get_model_renderer()
    end

    if not self._block then
        self._block = cMaterialPropertyBlock()
    end

    for _, render in ipairs(self._renderers) do
        self._block:Clear()
        render:GetPropertyBlock(self._block)
        self._block:SetFloat("_PetrifyThreshold", 0)
        self._block:SetFloat("_FrozenThreshold", 1)
        render:SetPropertyBlock(self._block)
    end
end

-- 解冻
function base_sprite_model:unfreeze()
    if next(self._renderers) == nil then
        self:_get_model_renderer()
    end

    if not self._block then
        self._block = cMaterialPropertyBlock()
    end

    for _, render in ipairs(self._renderers) do
        self._block:Clear()
        render:GetPropertyBlock(self._block)
        self._block:SetFloat("_FrozenThreshold", 0)
        render:SetPropertyBlock(self._block)
    end
end

-- 石化
function base_sprite_model:petrified()
    if next(self._renderers) == nil then
        self:_get_model_renderer()
    end

    if not self._block then
        self._block = cMaterialPropertyBlock()
    end

    for _, render in ipairs(self._renderers) do
        self._block:Clear()
        render:GetPropertyBlock(self._block)
        self._block:SetFloat("_FrozenThreshold", 0)
        self._block:SetFloat("_PetrifyThreshold", 1)
        render:SetPropertyBlock(self._block)
    end
end

-- 解石化
function base_sprite_model:unpetrified()
    if next(self._renderers) == nil then
        self:_get_model_renderer()
    end

    if not self._block then
        self._block = cMaterialPropertyBlock()
    end

    for _, render in ipairs(self._renderers) do
        self._block:Clear()
        render:GetPropertyBlock(self._block)
        self._block:SetFloat("_PetrifyThreshold", 0)
        render:SetPropertyBlock(self._block)
    end
end

--
function base_sprite_model:crystalized()
    if next(self._renderers) == nil then
        self:_get_model_renderer()
    end

    if not self._block then
        self._block = cMaterialPropertyBlock()
    end

    for _, render in ipairs(self._renderers) do
        self._block:Clear()
        render:GetPropertyBlock(self._block)
        self._block:SetFloat("_CrystalizedThreshold", 1)
        render:SetPropertyBlock(self._block)
    end
end

function base_sprite_model:un_crystalized()
    if next(self._renderers) == nil then
        self:_get_model_renderer()
    end

    if not self._block then
        self._block = cMaterialPropertyBlock()
    end

    for _, render in ipairs(self._renderers) do
        self._block:Clear()
        render:GetPropertyBlock(self._block)
        self._block:SetFloat("_CrystalizedThreshold", 0)
        render:SetPropertyBlock(self._block)
    end
end

function base_sprite_model:_get_model_renderer()
    local game_object = self:get_game_object()
    if game_object then
        self._renderers = GameObjTools.GetComponentsInChildren(game_object, "SkinnedMeshRenderer")

        --self._renderers_materials = {}
        --for i, render in ipairs(self._renderers) do
        --    self._renderers_materials[i] = {}
        --    self._renderers_materials[i].sharedMats = render.sharedMaterials
        --    self._renderers_materials[i].materials = render.materials
        --end
    end
end

function base_sprite_model:release()
    --if next(self._renderers) ~= nil then
    --    for i, render in ipairs(self._renderers) do
    --        local sharedMaterials = self._renderers_materials[i].sharedMats
    --
    --        render.materials = sharedMaterials
    --
    --        self._renderers_materials[i] = nil
    --    end
    --end

    --self._renderers_materials = nil
    self._renderers = nil

    if self.cmodel then
        self.cmodel:Release()
        self.cmodel = nil
    end

    if self.anchor then
        self.anchor:DeleteMe()
        self.anchor = nil
    end
end

return base_sprite_model