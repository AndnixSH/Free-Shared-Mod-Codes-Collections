local RedPointDef = require "Modules.RedPoint.RedPointDef"
local RedPointNode = require "Modules.RedPoint.RedPointNode"
local EventCenter = require "Common.Util.EventCenter"
local EventCenterDef = require "Common.Util.EventCenterDef"
local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"

--1.在RedPointDef中定义节点id，构建对应的树
--2.调用BindNode方法给节点绑定对应的gameObject(如果叶子节点是动态的不好定义的例如英雄id邮件id，则调用BindNodeDynamic)。一般在界面初始化、切换页签等调用
--3.调用SetNodeNum方法设置节点的红点数(如果叶子节点是动态的不好定义的例如英雄id邮件id，则调用SetNodeNumDynamic)。一般在红点数发生变化时调用，例如收到服务端数据时
local RedPointProxy = RedPointProxy or BaseClass(BaseProxy)

function RedPointProxy:__init()
	-- print("RedPointProxy:__init")

	RedPointProxy.Instance = self
	self.nodeDatas = {} --key:id value:node
	self:Init()

	self.listenSystemOpenFunc = function (systemOpenType)
		-- print("RedPointProxy.listenSystemOpenFunc", systemOpenType)

		local node
		for k,v in pairs(RedPointDef.CheckSystemOpen) do
			if v == systemOpenType then
				node = self:GetNode(k)
				break
			end
		end
		if node then
			node:UpdateNum()
		end
	end
	EventCenter.Add(EventCenterDef.Id.SystemOpen, self.listenSystemOpenFunc)
end

function RedPointProxy:__delete()
	-- print("RedPointProxy:__delete")

	EventCenter.Remove(EventCenterDef.Id.SystemOpen, self.listenSystemOpenFunc)
end

function RedPointProxy:Init()
	-- print("RedPointProxy:Init")

	local tree = RedPointDef.Tree
	for k,v in pairs(tree) do
		local parentNode = self:GetNode(k)
		local children = v
		for i=1,#children do
			local childNode = self:GetNode(children[i])
			parentNode:AddChild(childNode)
		end
	end

	--今日不再提醒
	local todayNoShow = RedPointDef.TodayNoShow
	local todayNoShowLen = #todayNoShow
	if todayNoShowLen > 0 then
		--今日时间
		local t = os.date("*t")
		local year, month, day = t.year, t.month, t.day
		-- print(year, month, day)
		
		for i=1,todayNoShowLen do
			local id = todayNoShow[i]
			local value = self:GetTodayNoShowValue(id)
			if value ~= 0 then
				--同一天
				local time = os.date("*t", value)
				-- print(id, table.dump(time))
				if time.year == year and time.month == month and time.day == day then
					local node = self:GetNode(id)
					node:Hide()
				end
			end
		end
	end
end

function RedPointProxy:GetNode(id)
	local node = self.nodeDatas[id]
	if not node then
		node = RedPointNode.New(id)
		self.nodeDatas[id] = node
	end
	return node
end

function RedPointProxy:UpdateNode(id)
	local node = self:GetNode(id)
	node:OnChange()
end

function RedPointProxy:AppendNode(parentId, selfId)
	local id = parentId .. selfId
	local parentNode = self:GetNode(parentId)
	local childNode = self:GetNode(id)
	parentNode:AddChild(childNode)
	return id
end

function RedPointProxy:GetNodeNum(id)
	local node = self:GetNode(id)
	return node.num
end

function RedPointProxy:SetNodeNum(id, num)
	if not id then
		return
	end

	local node = self:GetNode(id)
	node:SetNum(num)
end

--用于动态的叶子节点 parentId:父节点id selfId:自身id
function RedPointProxy:SetNodeNumDynamic(parentId, selfId, num)
	local id = self:AppendNode(parentId, selfId)
	self:SetNodeNum(id, num)
end

--go:红点go
--numComp:数量控件，传则显示数量否则不显示
--func:自定义红点表现的方法，一般不需要传
function RedPointProxy:BindNode(id, go, numComp, func)
	local node = self:GetNode(id)

	if go then
		node.go = go
	else
		CS.UnityEngine.Debug.LogError("RedPointProxy:BindNode go is nil" .. id)
	end
	
	if numComp then
		node.numComp = numComp
	else
		-- CS.UnityEngine.Debug.LogError("RedPointProxy:BindNode numComp is nil" .. id)
	end
	
	if func then
		node.func = func
	end
	
	node:OnChange()
end

--用于动态的叶子节点 parentId:父节点id selfId:自身id
function RedPointProxy:BindNodeDynamic(parentId, selfId, go, numComp, func)
	local id = self:AppendNode(parentId, selfId)
	self:BindNode(id, go, numComp, func)
end

function RedPointProxy:CheckClickHide(id, isTodayNoShow)
	local node = self:GetNode(id)
	node:CheckClickHide(isTodayNoShow)
end

function RedPointProxy:SetHideState(id,state)
	local node = self:GetNode(id)
	node:SetHideState(state)
end

function RedPointProxy:GetTodayNoShowKey(id)
	return RoleInfoModel.guserid .. "_RedPoint_" .. id
end

function RedPointProxy:GetTodayNoShowValue(id)
	local key = self:GetTodayNoShowKey(id)
	return PlayerPrefs.GetInt(key, 0)
end

function RedPointProxy:SetTodayNoShowValue(id, value)
	local key = self:GetTodayNoShowKey(id)
	value = value or os.time()
	PlayerPrefs.SetInt(key, value)
end

function RedPointProxy:Print()
	print("RedPointProxy:Print Start")
	for k,v in pairs(self.nodeDatas) do
		print(k, v.num)
	end
	print("RedPointProxy:Print End")
end

function RedPointProxy:PrintNode(id)
	print("RedPointProxy:PrintNode Start")
	local node = self:GetNode(id)
	print(id, node.num)
	while (node.parent) do
		node = node.parent
		print(node.id, node.num)
	end
	print("RedPointProxy:PrintNode End")
end

function RedPointProxy:PrintChildrenNode(id)
	print("RedPointProxy:PrintChildrenNode Start")
	local node = self:GetNode(id)
	print("node:", id, node.num)
	for k,v in pairs(node.children) do
		print(v.id, v.num)
	end
	print("RedPointProxy:PrintChildrenNode End")
end

return RedPointProxy