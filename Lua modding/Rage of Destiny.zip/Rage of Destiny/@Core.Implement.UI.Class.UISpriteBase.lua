local SpriteUIModel = require "Battle.render.model.ui_sprite_model"
local UISpriteBase = BaseClass(GameObjFactor, TimerFactor)

local _initialScale = 0.45 --根据ui框和模型大小自己手动算的一个值
function UISpriteBase:__init(obj, ishigh)
    if not obj then
        print("obj is nil:", debug.traceback())
        return
    end
    self.go = obj
    self:OnLoad(self.go)

    self.ishigh = false
    if ishigh then
        self.ishigh = ishigh
    end
end

function UISpriteBase:OnLoad(obj)
    self.rootObj = self:GetChild(self.go, "root")
    self.rect = self:GetComponent(self.go, "RectTransform")
    self.viewScale = math.floor(self.rect.sizeDelta.y * _initialScale)

    self.backDrag = self:GetChildComponent(self.go, "back", "CDrag")
    self.backDrag:AddDrag(function(data)
        self:OnDrag(data)
    end)
    self.backDrag:AddEndDrag(function(data)
        self:OnDragEnd(data)
    end)

    self.backBtn = self:GetChildComponent(self.go, "back", "CButton")
    self.backBtn:AddClick(function(data)
        self:OnClick()
    end)

    self.onDragCallBack = nil
    self.onClickCallBack = nil

    self:SetDepth(400)
    self:SetEulerAngles(0, 0, 0)
    self.bCanDrag = false
    self.spriteDepth = 0
end

function UISpriteBase:DestroyModel()
    if self.model then
        self.model:release()
        self.model = nil
    end
end

--加载模型入口
function UISpriteBase:SetModel(resName, roleid, active)
    if tostring(resName) == tostring(self.resName) then
        return
    end
    self.resName = tostring(resName)
    self.roleid = roleid

    if active then
        local activeName = self.roleid and string.format("%s_%s", self.roleid, active) or string.format("%s_%s" ,self.resName ,active)
        self.activeName = activeName
    end

    if self.model then
        self:DestroyModel()
    end
    self.model = SpriteUIModel.New(nil, self.resName, function(gameItemModel)
        -- local position = self.rootObj.transform.position
        gameItemModel:ModelPosition(0, 0, 0)
        gameItemModel:SetParent(self.rootObj.transform)
        gameItemModel:HideModel()
        self:AddTimer(function()
            self:LoadEnd()
        end, 0.1, 1)
    end)
end

function UISpriteBase:LoadEnd()
    self.go:SetActive(true)
    self:OnOpen()
    self.model:showmodel()

    if self.ishigh then
        self.model:disable_rim_color()
    end

    if self.activeName then
        self.model:start_active(self.activeName, 1)
    end
end

function UISpriteBase:Close()
    self.go:SetActive(false)
    self:DestroyModel()
    self.resName = ""
    self:CloseAllTimer()
end

function UISpriteBase:Destroy()
    self.resName = ""
    self:Close()
end

function UISpriteBase:DestroyModel()
    if self.model then
        self.model:release()
        self.model = nil
    end
end

function UISpriteBase:OnOpen()
end

--根节点设置
--z轴渲染
function UISpriteBase:SetDepth(depth)
    self:SetModelDepth(self.rootObj, depth)
end

--设置四元数
function UISpriteBase:SetQuaternion(rot)
	self.rootObj.transform.rotation = rot	
end

--设置欧拉
function UISpriteBase:SetEulerAngles(x, y, z)
    self.rootObj.transform.localEulerAngles = Vector3.New(x, y, z)
end

function UISpriteBase:Rotate(x, y, z)
	self.rootObj.transform:Rotate(Vector3.New(x,y,z))	
end

function UISpriteBase:SetViewScale(scale)
	self.go.transform.localScale = scale
end

function UISpriteBase:ShowOrHideView(bshow)
	self.go:SetActive(bshow)
end

function UISpriteBase:IsCanDrag(bcan)
	self.bCanDrag = bcan
end

function UISpriteBase:StartActive(active ,fltSpeed)
    fltSpeed = fltSpeed or 1
	if self.model and active then
		local activeName = self.roleid and string.format("%s_%s" ,self.roleid ,active) or string.format("%s_%s" ,self.resName ,active)
        self.activeName = activeName
        self.model:start_active(activeName, fltSpeed)
	end		
end

function UISpriteBase:StopActive()
	if self.model then
		self.model:stop_active()
	end
end

function UISpriteBase:PauseActive()
	if self.model then
		self.model:pause_active()
	end
end

function UISpriteBase:ResumeActive()
	if self.model then
		self.model:resume_active()
	end
end

--onclick
function UISpriteBase:OnClick()
    if self.isDrag then
        return
    end

    if self.onClickCallBack then
        self.onClickCallBack()
    end
end

function UISpriteBase:OnDrag(data)
    if self.bCanDrag == false then
        return
    end
    self.isDrag = true
    self:Rotate(0 , -data.delta.x ,0)
    if self.onDragCallBack then
    	self.onDragCallBack(-data.delta.x)
    end
end

function UISpriteBase:OnDragEnd()
    if self.bCanDrag == false then
        return
    end
    self.isDrag = false
end

--callback
function UISpriteBase:AddClick(func)
    self.onClickCallBack = func
end

function UISpriteBase:AddDrag(func)
    self.onClickCallBack = func
end

return UISpriteBase