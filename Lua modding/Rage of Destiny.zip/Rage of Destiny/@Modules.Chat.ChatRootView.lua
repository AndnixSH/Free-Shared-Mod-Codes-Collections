local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local ClistRender = require "Core.Implement.UI.Class.ClistRender"
local ClistItem = require "Core.Implement.UI.Class.ClistItem"
local ChatDef= require "Modules.Chat.ChatDef"
local HeadItem = require "Core.Implement.UI.Class.HeadItem"
local ChatProxy= require "Modules.Chat.ChatProxy"
local GameUIUtil=CS.GameUIUtil
local ChatItem = ChatItem or BaseClass(ClistItem)

function ChatItem:Load(obj)
	self.len=-165
	 self.dis=-165
     self.go=self:GetChild(obj,"item")
	 self.data=false
	 self.player=self:GetChild(self.go,"normal/player")
	 self.headItemClass=HeadItem.New(self:GetChild(self.player,"Headitem"))
	 self.selectObj=self:GetChild(self.go,"select")
	 self.titleLab=self:GetChildComponent(self.go,"normal/CLabel_label","CLabel")
	 self.icon=self:GetChildComponent(self.go,"normal/CSprite_icon","CSprite")
	 self.redDot=self:GetChild(self.go,"normal/CSprite_red")
	 self.btnObj=self:GetChild(self.go,"CSprite_zhidingshanchudi")
	 self.CLabel_rednumlab=self:GetChildComponent(self.go,"normal/CSprite_red/CLabel_rednumlab","CLabel")
	 self.topspr=self:GetChildComponent(self.btnObj,"CButton_zhiding/sprite","CSprite")
	 self.dec=self:GetChildComponent(self.go,"normal/dec","CLabel")
	 self.text2=self:GetChild(self.go,"normal/Text2")
    --  self.cBaseRender=self:GetComponent(obj,"CBaseRender")
	self.zhidingbtn=self:GetChildComponent(self.btnObj,"CButton_zhiding","CButton")
	self.zhidingbtn:AddClick(function ( )

		if self.data.topFunc then
			self.data.topFunc(self.data)
		end
    end)
    
    self.deletebtn=self:GetChildComponent(self.btnObj,"CButton_shanchu","CButton")
	self.deletebtn:AddClick(function ( )
        if self.data.deleteFunc then
			self.data.deleteFunc(self.data)
		end
	end)
	--self.redDot:SetActive(false)

	local dragobj = self:GetComponent(self.go, "CDrag")
	dragobj:AddBeginDrag(function (data)
		self:OnDragStart(data,self)
		if self.data.draglist then
			self.data.draglist(1,data)
		end
	end)
	dragobj:AddEndDrag(function (data)
		self:OnDragEnd(data, self)
		if self.data.draglist then
			self.data.draglist(2,data)
		end
	end)
	dragobj:AddDrag(function (data)
		self:OnDrag(data,self)
		if self.data.draglist then
			self.data.draglist(3,data)
		end
	end)
	self.moveX=0
	self.initPos=self.go.transform.localPosition
end

function ChatItem:OnDragStart(data, item)
	if self.data.dragcallback  then
		self.btnObj:SetActive(true)
		local key=ChatProxy.Instance:GetKeyById(self.data.id,self.data.player)
		self.data.dragcallback(key,data)
	end
end

function ChatItem:OnDrag(data, item)

	if self.moveX >= self.dis and self.moveX <= 0 then
		self.moveX = self.moveX + data.delta.x
		if self.moveX < self.dis then
			self.moveX=self.dis
		end
		if self.moveX > 0 then
			self.moveX =0
		end
		self.go.transform.localPosition=Vector3.New(self.moveX+self.initPos.x,self.initPos.y,self.initPos.z)
		if data.delta.x  == 0 then
			if self.data.dragcallback  then
				self.data.dragcallback(nil,data)
			end
		end
	end
	
end

function ChatItem:OnDragEnd(data, item)
	
	
	if self.moveX <= self.dis /2 then
		self.moveX =self.dis
		self.go.transform:DOLocalMoveX(self.initPos.x+self.dis,0.2)
		if self.data.dragcallback  then
			local key=ChatProxy.Instance:GetKeyById(self.data.id,self.data.player)
			self.data.dragcallback(key,true)
		end
		
		self.data.isdragbtn=true
	else
		self.moveX =0
		self.go.transform:DOLocalMoveX(self.initPos.x,0.2):OnComplete(function ()
			
			self.btnObj:SetActive(false)
		end)
		
	end
end

function ChatItem:SetData(data)
 
    self.data=data
    --  self.fun=data.fun
	--  self.heroItemClass:SetData(data.data)
	self.player:SetActive(false)
	self.icon.gameObject:SetActive(true)
	self.titleLab.gameObject:SetActive(true)
	self.deletebtn.gameObject:SetActive(true)
	self.redDot.transform.localPosition=Vector3.New(-130.97,21.20007,0)
	self.dis=self.len
	self.icon.Gray=true
	if data.id == ChatDef.ChatType.chat_World then
		self.dis=self.len/2
		self.deletebtn.gameObject:SetActive(false)
		self.icon.SpriteName="shijie"
		self.titleLab.text=LanguageManager.Instance:GetWord(ChatDef.CommonDef.Chat_World)..tostring(data.channelid)
	elseif data.id == ChatDef.ChatType.chat_Local then
		self.dis=self.len/2
		self.deletebtn.gameObject:SetActive(false)
		self.icon.SpriteName="bendi"
		self.titleLab.text=LanguageManager.Instance:GetWord(ChatDef.CommonDef.Chat_Local)
	elseif data.id == ChatDef.ChatType.chat_Army then
		self.icon.SpriteName="juntun"
		self.titleLab.text=LanguageManager.Instance:GetWord(ChatDef.CommonDef.Chat_Army)
	elseif data.id == ChatDef.ChatType.chat_Guild then
		self.icon.SpriteName="gonghui"
		self.titleLab.text=data.guilname
	elseif data.id >= ChatDef.ChatType.chat_Private then
		self.redDot.transform.localPosition=Vector3.New(-136,21.20007,0)
		self.player:SetActive(true)
		self.icon.gameObject:SetActive(false)
		self.titleLab.gameObject:SetActive(false)
		self.headItemClass:SetData(data.player)
	end
	local key=ChatProxy.Instance:GetKeyById(data.id,data.player)
	local topstate=ChatProxy.Instance:GetChatTopState(key)
	if topstate > 0 then
		self.topspr.transform.localEulerAngles = Vector3.New(0,0,180)
	else
		self.topspr.transform.localEulerAngles = Vector3.New(0,0,0)
	end
	if self.data.isdragbtn then
		self.moveX=self.dis
		self.go.transform.localPosition=Vector3.New(self.initPos.x+self.dis,self.initPos.y,self.initPos.z)
	else
		self.go.transform.localPosition=Vector3.New(self.initPos.x,self.initPos.y,self.initPos.z)
	end
	

	local unreadnum=ChatProxy.Instance:GetChatUnReadNum(key)
	local headstr=""
	if unreadnum > 0 then
		self.redDot:SetActive(true)
		self.CLabel_rednumlab.text=tostring(unreadnum)
		headstr=string.format("[%s%s]",unreadnum,LanguageManager.Instance:GetWord(ChatDef.CommonDef.Count))
	else
		self.redDot:SetActive(false)
	end
	self.dec.text=headstr..data.newInfo
end
function ChatItem:ResetBtnPos(cukey)
	self.data.isdragbtn=false
	local key=ChatProxy.Instance:GetKeyById(self.data.id,self.data.player)
	
	if cukey ~= key then

		self.moveX=0
		self.go.transform:DOLocalMoveX(self.initPos.x,0.2):OnComplete(function ()
			
			self.btnObj:SetActive(false)
		end)
	end
	
end
function ChatItem:UpdateSelectDepth(depth)
	
	-- GameObjTools.SetDepth(self.selectObj,depth -1)

	
	-- GameObjTools.SetDepth(self.titleLab.gameObject,depth )
	-- GameObjTools.SetDepth(self.text2,depth )
end

function ChatItem:UpdateTitleNewInfo(cukey)

	local key=ChatProxy.Instance:GetKeyById(self.data.id,self.data.player)
	if cukey == key then
		self.dec.text=self.data.newInfo
	end
	
end

function ChatItem:OnSelect(index)
    
	--self.heroItemClass:SetSelectItem(true)
	self.redDot:SetActive(false)
	self.icon.Gray=false
	self.dec.text=self.data.newInfo
end
function ChatItem:DeSelect(index)
	self.moveX = 0
	self.icon.Gray=true
    --self.heroItemClass:SetSelectItem(false)
end

function ChatItem:Destroy()
    self.go=false
    self.data=false
    self.heroItemClass=false
end

local ChatRootView = ChatRootView or LuaWidgetClass()
function ChatRootView:__init()
	self.fullScreenOption = { onclosefunc = function () self:ReleaseRoleRootPage() end }
end

function ChatRootView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Chat.ChatRootView",self.LoadEnd)
	GameUIUtil.LoadEmoPrefab("EMoji.CEmoji")
end

function ChatRootView:LoadEnd(obj)
	self.curDragKey=0
	self.index=0
	self:SetGo(obj)
	self:Init(obj)
	self:SetStep(0)
end

function ChatRootView:Init(obj)

	self.leftObj=self:GetChild(obj,"Left")
	self.chatList=self:GetChildComponent(obj, "Left/CList","CList")
	self.listRender = ClistRender.New()
    self.listRender:Load(self.chatList, ChatItem)
	self.listRender:AddSelect(function(item, index)
        self:AddSelectOneItem(item, index)
	end) 

	self.listRender:AddDeSelect(function(item, index)
        self:AddDeSelectOneItem(item, index)
    end)
end
function ChatRootView:AddSelectOneItem(item,index)

	if self.index ~= index then
		self.index=index
		--local depth=UILayerTool.GetNextDepth()
		--item:UpdateSelectDepth(depth)
	end
	local key=ChatProxy.Instance:GetKeyById(item.data.id,item.data.player)
	ChatProxy.Instance:SetChatSelectKey(key)
	ChatProxy.Instance:UpdateSelectTitle()
	self:UpdateRightContentList(key)
end


function ChatRootView:AddDeSelectOneItem(item,index)
    

end

function ChatRootView:OnOpen()
	self:AutoRegister()
	--ChatProxy.Instance:Send70000()
	ChatProxy.Instance:Send31003()
	ChatProxy.Instance:Send31005()
	self.index=0
end

function ChatRootView:OnHideWidgetObj()
	self:AutoUnRegister()
end

function ChatRootView:OnShowWidgetObj()
	self:AutoRegister()
	ChatProxy.Instance:Send31003()
	--ChatProxy.Instance:UpdateTotalUnReadNum()
end

function ChatRootView:UpdateRightContentList(key)

	--
	if key == "" then
		LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ChatView)
	else
		local selectindex=ChatProxy.Instance:GetIndexByKey(key)
		self.listRender:SelectIndex(selectindex or 1)
		local view=LuaLayout.Instance:GetWidget(UIWidgetNameDef.ChatView)
		if view then
			--view:SetData({selectindex=selectindex})
			if view:IsOpen() then
				view:UpdateView()
			else
				view:OpenView()
			end
		end
	end
	
end

function ChatRootView:UpdateView(data)
    
	self.listRender:ClearData()
	if data  then
		local func=function ( key, bendrag)
			if key then
				if bendrag then
					self.curDragKey=key
				else
					self.listRender:ExecuteMethod("ResetBtnPos",key)
				end
			end
		end
		local draglist =function (drag,data  )
			if drag == 1 then
				self.chatList:OnBeginDrag(data)
			elseif drag == 2 then
				self.chatList:OnEndDrag(data)
			else
				self.chatList:OnDrag(data)
			end
		end
		for i,v in pairs(data) do
			v.dragcallback=func
			v.draglist = draglist
			v.isdragbtn=false
			-- if ChatProxy.Instance:GetKeyById(v.id,v.player) == self.curDragKey then
			-- 	v.isdragbtn=true
			-- else
			-- 	v.isdragbtn=false
			-- end
		end
		self.listRender:AppendDataList(data,"")
		-- local depth=UILayerTool.GetNextDepth(2)
		-- self.listRender:ExecuteMethod("UpdateSelectDepth",depth)
    else
        --没有数据
    end
end

function ChatRootView.EvtNotify.Chat.data:Chat_Request(data,titltlist)

	self:UpdateView(titltlist)
	local key=ChatProxy.Instance:GetChatSelectKey()
	if key == "" then
		if #titltlist > 0 then
			self:UpdateRightContentList( ChatProxy.Instance:GetKeyById(titltlist[1].id,titltlist[1].player))
		else
			LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ChatView)
		end
	else
		self:UpdateRightContentList(key)
	end
	self:AddTimer(function()
		ChatProxy.Instance:UpdateTotalUnReadNum()
	end, 0.3, 1)
	
end
function ChatRootView.EvtNotify.Chat.data:Chat_UpdateCurContentList(data,list)
	local key=ChatProxy.Instance:GetChatSelectKey()
	self.listRender:ExecuteMethod("UpdateTitleNewInfo",key)
end

function ChatRootView.EvtNotify.Chat.data:Chat_UpdateTitleList(data,info)

	self:UpdateView(info.titlelist)
	local key=ChatProxy.Instance:GetChatSelectKey()
	if info.delete then
		if  key == "" then
			if #info.titlelist == 0 then
				LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ChatView)
			else
				
				local id=info.titlelist[1].id
				local key=ChatProxy.Instance:GetKeyById(id,info.titlelist[1].player)
				self:UpdateRightContentList(key)
				ChatProxy.Instance:SetChatSelectKey(key)
			end
			return
		end
	end
	local chang_key = ChatProxy.Instance:GetKeyById(info.cur_change_titleData.id,info.cur_change_titleData.player)
	if chang_key == key then
		--当前频道信息发生变化
		local selectindex=ChatProxy.Instance:GetIndexByKey(key)
		self.listRender:SelectIndex(selectindex or 1)
		local view=LuaLayout.Instance:GetWidget(UIWidgetNameDef.ChatView)
		if view then
			view:SetData({selectindex=selectindex})
		end
	end
	
end


function ChatRootView:ReleaseRoleRootPage()
	local bDestory=false
	ChatProxy.Instance:SetChatSelectKey("")
	LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ChatView,bDestory)
	LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ChatRootView,bDestory)
end

function ChatRootView:OnClose()
	self.curDragKey=""
	self.index=0
	ChatProxy.Instance:HideTotalRedNum()
	self:AutoUnRegister()
end

function ChatRootView:OnDestroy()
	
	self:AutoUnRegister()
	self.listRender:ClearData()
    self.listRender:Destroy()
end

return ChatRootView
