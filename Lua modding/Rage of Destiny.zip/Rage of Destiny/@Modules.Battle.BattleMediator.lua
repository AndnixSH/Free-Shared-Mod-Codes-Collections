local BattleMediator = BattleMediator or BaseClass(StdMediator)
local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"

function BattleMediator:OnEnterLoadingEnd()
end

function BattleMediator:OnEnterScenceFirst()
end

return BattleMediator