local tinsert = table.insert

local PUSH_MASK = {
    [SPRITE_TYPE.PLAYER] = 7,
    [SPRITE_TYPE.MONSTER] = 7,
    [SPRITE_TYPE.PROP] = 7,
    [SPRITE_TYPE.BULLET] = 0,
}

local function str_sprite_list(sprites)
    local t = {}
    for i, sprite in ipairs(sprites) do
        table.insert(t, tostring(sprite))
    end
    return table.concat(t, ", ")
end

-- 处理精灵的创建，选取
local area = {
    _all_actor = {},
    _camp_actor = {},
    _camp_player = {},
    _camp_player_id = {},
}

function area:init()
end

function area:dispose()
    self._all_actor = {} -- 全体
    self._camp_actor = {} -- 分阵营全体
    self._camp_player = {} -- 分阵营英雄
    self._camp_player_id = {}
end

function area:getplayeruids(camp)
    return self._camp_player_id[camp] or {}
end

function area:getplayers(camp)
    return self._camp_player[camp] or {}
end

function area:getactors(camp)
    return self._camp_actor[camp] or {}
end

function area:getallactors()
    return self._all_actor or {}
end

function area:getgameobj()
    return global.service.pool:get_obj(0)
end

function area:remove_actor(spriteobj)
    local camp = spriteobj.prop.camp
    global.array.remove(self._all_actor, spriteobj)
    if camp then
        if self._camp_actor[camp] then
            global.array.remove(self._camp_actor[camp], spriteobj)
        end
        if self._camp_player[camp] and spriteobj.body.spritetype == SPRITE_TYPE.PLAYER then
            global.array.remove(self._camp_player[camp], spriteobj)
        end
    end
    spriteobj.body:setpushmask(-1)
    global.gamer.bmessage("RemoveActor", spriteobj.uid)
end

function area:remove_all()
    for i, actor in ipairs(self._all_actor) do
        actor:destroy()
    end
    self:dispose()
end

function area:create_configsprite(typeid, position, header, prop)
    local body = self:_get_config("sprite_body", typeid)
    assert(body, "没有配置sprite_body:"..typeid)
    local spritetype = body.spritetype
    if body.offset then
        local forward, right = body.offset[1], body.offset[2]
        if forward and forward ~= 0 then
            position = position + header:fmul(forward)
        end
        if right and right ~= 0 then
            position = position + tsvector.rotate(header, -90):fmul(right)
        end
    end
    local static = self:_getsprite_static(spritetype, typeid)
    local spriteobj = area._createsprite(spritetype, PUSH_MASK[spritetype], typeid, position, header, body.height or 0, body.radius or 500, body.weight or 0, body.top or 0, body.prefab_id, static, prop)
    spriteobj.body.tailing_id = body.tailing_id--todo 要改
    spriteobj.body.has_tail = body.has_tail--todo 要改
    if spritetype == SPRITE_TYPE.PLAYER or spritetype == SPRITE_TYPE.MONSTER then
        area:_create_role_sprite(spriteobj)
    end

    global.service.sprite:addsprite(spriteobj.uid, spritetype)
    return spriteobj
end

function area:_addtocamp(camp, spriteobj, type)
    tinsert(self._all_actor, spriteobj)
    self._camp_actor[camp] = self._camp_actor[camp] or {}
    tinsert(self._camp_actor[camp], spriteobj)
    if type == SPRITE_TYPE.PLAYER then
        self._camp_player[camp] = self._camp_player[camp] or {}
        tinsert(self._camp_player[camp], spriteobj)
    end
    self._camp_player_id[camp] = self._camp_player_id[camp] or {}
    tinsert(self._camp_player_id[camp], spriteobj.uid)
end

function area:_setspritedebug(spriteobj)
    global.gamer.bmessage("SetSpriteDebug", spriteobj.uid, spriteobj.body.spritetype, spriteobj.prop.camp)
end

function area:_get_config(configname, typeid)
    local config = global.service.config:get(configname)
    if config then
        return config[typeid]
    end
end

local function sprite_tostring(sprite)
    local name = sprite.prop.name or (sprite.static and sprite.static.name)
    return string.format("uid:%d camp:%s name:%s", sprite.uid, sprite.prop.camp, name or sprite.typeid)
end

function area._createsprite(spritetype, pushmask, typeid, position, header, height, radius, weight, top, prefab_id, static, prop)
    local spriteobj = global.service.sprite:createsprite(spritetype, pushmask, typeid, position, header, height, radius, weight, top, prefab_id, static, prop)
    spriteobj.tostring = sprite_tostring
    spriteobj:createlogic("sprite.basic.sprite_body_logic")
    spriteobj:createlogic("sprite.basic.sprite_view_logic")
    area:_setspritedebug(spriteobj)
    return spriteobj
end

function area:create_sprite(createvo)
    local spritetype =  assert(createvo.spritetype)
    local pushmask = PUSH_MASK[spritetype]
    return area._createsprite(spritetype, pushmask, createvo.typeid, createvo.position, createvo.header, createvo.height, createvo.radius, createvo.weight, createvo.top, createvo.prefab_id, createvo.static, createvo.prop)
end

function area:_getsprite_static(spritetype, typeid)
    local cfgname = nil
    if spritetype == SPRITE_TYPE.PLAYER then
        cfgname = "hero_static"
    elseif spritetype == SPRITE_TYPE.MONSTER then
        cfgname = "monster_static"
    end
    if cfgname then
        local static = area:_get_config(cfgname, typeid)
        if not static then
            global.debug.warning(string.format("%s中没有配置%s", cfgname, typeid))
        end
        return static
    end
end

-- 创建角色类精灵
function area:_create_role_sprite(spriteobj)

    local spritetype, typeid = spriteobj.body.spritetype, spriteobj.typeid
    if spriteobj.prop.camp then
        self:_addtocamp(spriteobj.prop.camp, spriteobj, spritetype)
    else
        global.debug.warning(string.format("创建%s的prop中没有阵营信息", typeid))
    end

    local attr = self:_get_config("role_attr", typeid)
    if attr then
        spriteobj.attr = global.service.propchange:tabletrack("attr", spriteobj)
        for k, v in pairs(attr) do
            spriteobj.attr[k] = v
        end
    else
        global.debug.warning(string.format("role_attr中没有配置%s", typeid))
    end

    spriteobj.buff = {}
    spriteobj.record = {}
    return spriteobj

end

local function oppsitecamp(camp)
    if camp == CAMP.RED then
        return CAMP.BLUE
    elseif camp == CAMP.BLUE then
        return CAMP.RED
    else
        error(string.format("阵营%s没有对立阵营", camp))
    end
end

function area:getoppsitecamp(camp)
    return oppsitecamp(camp)
end

local target_select = 
{
    [SKILL.TARGET.ENEMY] = function(self, caster)
        return self._camp_actor[oppsitecamp(caster.prop.camp)]
    end,

    [SKILL.TARGET.ENEMY_HERO] = function(self, caster)
        -- return self._camp_player[oppsitecamp(caster.prop.camp)]
        local results = {}
        local actors = self._camp_actor[oppsitecamp(caster.prop.camp)] or {}
        for i, actor in ipairs(actors) do
            if actor.body.spritetype == SPRITE_TYPE.PLAYER or (actor.body.spritetype == SPRITE_TYPE.MONSTER and actor.static.type == MONSTER_TYPE.BOSS) then
                tinsert(results, actor)
            end
        end
        return results
    end,

    [SKILL.TARGET.FRIEND] = function(self, caster)
        return self._camp_actor[caster.prop.camp]
    end,

    [SKILL.TARGET.FRIEND_HERO] = function(self, caster)
        -- return self._camp_player[caster.prop.camp]
        local results = {}
        local actors = self._camp_actor[caster.prop.camp] or {}
        for i, actor in ipairs(actors) do
            if actor.body.spritetype == SPRITE_TYPE.PLAYER or (actor.body.spritetype == SPRITE_TYPE.MONSTER and actor.static.type == MONSTER_TYPE.BOSS) then
                tinsert(results, actor)
            end
        end
        return results
    end,

    [SKILL.TARGET.FRIEND_SUMMON] = function (self, caster)
        local actors = self._camp_actor[caster.prop.camp] or {}
        local results = {}
        for _, actor in ipairs(actors) do
            if actor.body.spritetype == SPRITE_TYPE.MONSTER and actor.static.type == MONSTER_TYPE.NORMAL then
                table.insert(results, actor)
            end
        end
        return results
    end,

    [SKILL.TARGET.ENEMY_SUMMON] = function (self, caster)
        local actors = self._camp_actor[oppsitecamp(caster.prop.camp)] or {}
        local results = {}
        for _, actor in ipairs(actors) do
            if actor.body.spritetype == SPRITE_TYPE.MONSTER and actor.static.type == MONSTER_TYPE.NORMAL then
                table.insert(results, actor)
            end
        end
        return results
    end,

    [SKILL.TARGET.ALL] = function(self, caster)
        return self._all_actor
    end,

    [SKILL.TARGET.SELF] = function(self, caster)
        return { caster.body.parent or caster }
    end,
}

-- 选择生效目标
function area:select_target(caster, targetid)

    local taunt = caster.caller.taunt
    if not taunt and caster.body.parent then
        taunt = caster.body.parent.caller.taunt
    end

    if taunt and #taunt:get() > 0 then -- 被嘲讽
        return taunt:get()
    end

    return self:_select_target(caster, targetid)
end

function area:_select_target(caster, targetid)
    local select = target_select[targetid]
    if select then
        return select(self, caster)
    else
        global.debug.warning(string.format("错误的生效目标%s", targetid))
        return {}
    end
end

-- 过滤目标
function area:filter_target(caster, target, filterid, ...)
    local filter = rangelib.target_filter[filterid]
    if filter then
        return filter(self, caster, target, ...)
    else
        global.debug.warning("错误的生效目标过滤", filterid)
        return false
    end
end

local battleside = {}

function area:setbattleside(maptype, center, sizex, sizey)
    local size = tsvector.new(sizex, sizey / 2)
    battleside._maptype = maptype
    battleside._center = center
    battleside._sizex = sizex
    battleside._sizey = sizey
    battleside._bottomleft = center - tsvector.new(sizex / 2, sizey / 2)
    battleside._topright = center + tsvector.new(sizex / 2, sizey / 2)
    battleside[CAMP.RED] = tsmath.create_normalrect(tsvector.new(center.x - sizex / 2, center.y - sizey / 2), size)
    battleside[CAMP.BLUE] = tsmath.create_normalrect(tsvector.new(center.x - sizex / 2, center.y), size)
end

-- 获取中心点
function area:getbattlecenter()
    return battleside._center.x, battleside._center.y
end

-- 获取xy
function area:getbattlesize()
    return battleside._sizex, battleside._sizey
end

-- 获取对角线长度
function area:getbattldiagonal()
    if battleside._maptype == 1 then   -- circle
        return battleside._sizex
    elseif battleside._maptype == 2 then  -- rect
        return battleside._sizex
    end
end

function area:getbattleside(camp)
    return battleside[camp]
end

function area:gettag(camp)
    local gameid = global.game.gameid
    local campflag = (camp == CAMP.RED) and ACTIVE_BIT.CAMP1 or ACTIVE_BIT.CAMP2
    local sceneflag = (gameid == GAMEPLAYID.HANGUP) and ACTIVE_BIT.HANGUP or ACTIVE_BIT.NOHANGUP
    local tag = campflag | sceneflag
    return tag
end

function area:getsidepos(camp, x, y)
    x = tsmath.clamp(x, 0, 1000) / 1000
    y = tsmath.clamp(y, 0, 1000) / 1000

    local sx, sy = battleside._sizex, battleside._sizey / 2
    local px = battleside._center.x - sx / 2
    local py = battleside._center.y
    local pos = nil
    
    if camp == CAMP.BLUE then
        pos = tsvector.new(px + x * sx, py + y * sy)
    elseif camp == CAMP.RED then
        pos = tsvector.new(px + sx - tsmath.abs(x * sx), py - tsmath.abs(y * sy))
    end

    return pos
end

function area:torelativepos(position)
    local x = tsmath.clamp(position.x, 0, 1000) / 1000
    local y = tsmath.clamp(position.y, 0, 1000) / 1000

    local sx, sy = battleside._sizex, battleside._sizey
    local px = battleside._center.x - sx / 2
    local py = battleside._center.y - sy / 2
    return tsvector.new(px + x * sx, py + y * sy)
end

function area:isvalidpos(position, radius)
    radius = radius or 0
    if battleside._maptype == 1 then   -- circle
        return tsvector.distance_less(position, battleside._center, tsmath.floor(battleside._sizex / 2) + radius)
    elseif battleside._maptype == 2 then  -- rect
        local x, y = position.x, position.y
        local bl, tr = battleside._bottomleft, battleside._topright
        return x - radius > bl.x and y - radius > bl.y and x + radius < tr.x and y + radius < tr.y
    end
    return true
end

function area:_get_target_filter(caster, target)
    if target.buff then
        if target.buff.immune_select then
            return false
        end
        if target.buff.immune_enemy_select and target.prop.camp ~= caster.prop.camp then
            return false
        end
    end
    return true
end

-- 获得生效目标
function area:_get_targets(caster, targetlist)

    -- 1 获得一个范围
    local targets = self:select_target(caster, targetlist[1])
    local results = {}
    if targets then
        for i, targetobj in ipairs(targets) do

            if self:_get_target_filter(caster, targetobj) then -- 是否能被选中
                local bfilter = true

                for i = 2, #targetlist do
                    local target = targetlist[i]
                    local targetid = target
                    if type(target) == "table" then
                        targetid = target[1]
                    end

                    -- 2 过滤掉不满足的
                    if targetid ~= target then
                        bfilter = self:filter_target(caster, targetobj, targetid, table.unpack(target, 2, #target))
                    else
                        bfilter = self:filter_target(caster, targetobj, targetid)
                    end

                    if not bfilter then
                        break
                    end
                end

                if bfilter then
                    table.insert(results, targetobj)
                end

            end
        end
    end

    return results
end

function area:simple_find_targets(caster, targetid, targetfilter, num)

    local targets = self:_select_target(caster, targetid)

    local results = {}
    if targets then
        for i, targetobj in ipairs(targets) do

            local bfilter = true

            if targetfilter then
                local filterid = targetfilter
                if type(targetfilter) == "table" then
                    filterid = targetfilter[1]
                end

                -- 2 过滤掉不满足的
                bfilter = self:filter_target(caster, targetobj, filterid, filterid ~= targetfilter and table.unpack(targetfilter, 2, #targetfilter))
            end

            if bfilter then
                table.insert(results, targetobj)
            end

        end
    end

    local result_count = #results

    if num and num > 0 and result_count > 0 then
        if num > result_count then num = result_count end
        results = tsrandom.select(results, num)
    end

    return results
end

-- 选取一个
function area:_select_one(caster, targets, select)
    local selectid = select[1]
    if selectid == SKILL.SELECT.ALL then
        return targets[1]
    elseif selectid == SKILL.SELECT.RANDOM then
        return targets[tsmath.random(#targets)]
    else
        local _select_filter = rangelib.selecter.getfilter(select)
        if _select_filter then

            local last = nil
            local select = nil
            for _, target in ipairs(targets) do
                local new = _select_filter(last, target, caster)
                if new then
                    last = new
                    select = target
                end
            end
            return select
        else
            global.debug.warning("错误的选取" .. table.unpack(select))
            return targets[1]
        end
    end
end

-- 选取列表
function area:_select_list(caster, targets, select, num)

    local selectid = select[1]

    if selectid == SKILL.SELECT.RANDOM then
        return tsmath.random_select(targets, num)
    else
        local results = {}

        if selectid ~= SKILL.SELECT.ALL then

            local _compare_filter = rangelib.comparer.getfilter(select, caster)
            if _compare_filter then
                table.sort(targets, _compare_filter)
            else
                global.debug.warning("错误的排序" .. selectid)
            end
        end

        for i = 1, num do
            table.insert(results, targets[i])
        end
        return results
    end
end

-- range过滤
function area:_range_list(caster, targets, center, header, range_table)

    if range_table.area == SKILL.RANGE.ALL then
        return targets
    end

    local filter = rangelib.range_filter[range_table.area]
    local range1, range2 = nil, nil
    local area_args = self:getargs(range_table.area_args)
    if area_args then
        range1, range2 = area_args[1], area_args[2]
    end

    if not filter then
        global.debug.warning(string.format("错误的技能范围%s", range_table.area))
        return targets
    else
        if GameConfig.DEBUGDRAW and GameConfig.DEBUGDRAW.range then
            global.gamer.bmessage("AddDraw", range_table.area, center.x, center.y, header.x, header.y, range1, range2)
        end
    end

    local _helper = nil
    if range_table.area == SKILL.RANGE.RECT then
        _helper = tsmath.create_rect(center, header, range1, range2)
    elseif range_table.area == SKILL.RANGE.RECT_CENTER then
        _helper = tsgeometry.create_rect_center(center, header, range1, range2)
    elseif range_table.area == SKILL.RANGE.ENEMY_SIDE then
        _helper = caster.prop.camp == CAMP.RED and battleside[CAMP.BLUE] or battleside[CAMP.RED]
    elseif range_table.area == SKILL.RANGE.FRIEND_SIDE then
        _helper = caster.prop.camp == CAMP.RED and battleside[CAMP.RED] or battleside[CAMP.BLUE]
    end

    local results = {}

    for _, target in ipairs(targets) do
        if filter(center, header, target, range1, range2, _helper) then
            table.insert(results, target)
        end
    end

    return results
end

-- 选取阶段，只选取一个目标，作为是否要位移过去依据  step:SKILL.TARGET -> SKILL.TARGET_FILTER -> SKILL.SELECT(1)
function area:select(caster, target_table)

    local _select = nil

    for _, target in ipairs(target_table) do

        -- 1. gettargets
        local _targets = self:_get_targets(caster, target[1])
        -- 2. doselect
        if #_targets > 0 then
            local _select = self:_select_one(caster, _targets, target[2])
            if _select then
                return _select
            end
        end
    end

end

-- 生效阶段，选取一个列表，作为cast   step:SKILL.TARGET -> SKILL.TARGET_FILTER -> SKILL.RANGE -> SKILL.SELECT(num)
function area:range(caster, center, header, range_table)

    local num = self:getargs(range_table.num)

    for _, target in ipairs(range_table.target) do

        -- 1. gettargets
        local _targets = self:_get_targets(caster, target[1])
        -- 2. dorange
        _targets = self:_range_list(caster, _targets, center, header, range_table)
        local targetcount = #_targets
        -- 3. doselect
        if targetcount > 0 then

            num = num or targetcount
            num = num > targetcount and targetcount or num
            if num == 1 then
                local _select = self:_select_one(caster, _targets, target[2])
                if _select then
                    return { _select }
                end
            else
                local _select = self:_select_list(caster, _targets, target[2], num)
                if #_select > 0 then
                    return _select
                end
            end
        end
    end

    return {}
end

-- 修正
function area:amendment_multi(caster, target, tomodify, amendment_cond, amendment_config)

    local can = true
    if amendment_cond then
        local amend_cond, rnd = table.unpack(amendment_cond)
        if not rnd or tsmath.random_match(rnd) then
            local targetid, filterid = amend_cond[1], amend_cond[2]
            local sprite = targetid == 1 and caster or target
            can = self:filter_target(caster, sprite, filterid, table.unpack(amend_cond, 3, #amend_cond))
        else
            can = false
        end
    end

    if can then
        return self:_amendment_multi(caster, target, tomodify, amendment_config)
    end

    return tomodify

end

function area:_amendment_multi(caster, target, tomodify, amendment_config)
    for _, amendconfig in ipairs(amendment_config) do
        local amendid, amendtprop = amendconfig[1], amendconfig[2]
        local func = rangelib.amendment[amendid]
        if func then
            if amendtprop == 0 then
                tomodify = func(caster, target, tomodify, table.unpack(amendconfig, 3, #amendconfig))
            else
                local prop = AMENDMENT.PROP[amendtprop]
                if prop then
                    if tomodify[prop] then
                        tomodify[prop] = func(caster, target, tomodify[prop], table.unpack(amendconfig, 3, #amendconfig))
                    else
                        global.debug.warning("要修正的值没有包含属性", amendtprop)
                    end
                else
                    global.debug.error("不支持的修正属性", amendtprop)
                end
            end
        else
            global.debug.error("不支持的修正ID", amendid)
        end
    end
    return tomodify
end

function area:getargs(args)
    if args then
        return global.game.gameid == GAMEPLAYID.HANGUP and args[2] or args[1]
    end
end


--[[ collide ]]
function area:collide_sprite(sprite)
    local actors = self:getallactors()
    local radius = sprite.body.radius
    local position = sprite.body.position
    for _, actor in ipairs(actors) do
        if tsvector.distance_less_equal(position, actor.body.position, radius + actor.body.radius) then
            return actor
        end
    end
end

function area:collide_block(sprite)
    return not self:isvalidpos(sprite.body.position, sprite.body.radius)
end

function area:collidecheck(logic)
    local cs = self:collide_sprite(logic.owner)
    if cs and logic.sprite.onhitsprite then
        logic.sprite.onhitsprite(logic, cs)
    end
    -- local cb = self:collide_block(logic.owner)
    -- if cb and logic.sprite.onhitblock then
    --     logic.sprite.onhitblock(logic)
    -- end
end
--[[ collide ]]
return area