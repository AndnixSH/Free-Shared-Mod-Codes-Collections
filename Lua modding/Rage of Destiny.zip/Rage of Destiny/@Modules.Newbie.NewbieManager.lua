local NewbieDef = require "Modules.Newbie.NewbieDef"

local NewbieManager = NewbieManager or BaseClass()
function NewbieManager:__init()
	NewbieManager.Instance = self
	self.cfg = ConfigManager.GetConfig("data_newbie")
	self.newbieData = {}

	self.inNewbie = false
	self.curNewbieid = 0
	self.curStep = 0
	self.countStep = 0
	self.curNewbieCfg = nil
	self.lastCompleteNewbieid = 0
	self.sendedBeginEvent = false
end

function NewbieManager:StartNewbie(newbieid, bforce)
	-- print("=== StartNewbie ===", newbieid, bforce, self.curNewbieid, self.curStep, self.countStep, debug.traceback())
	
	local NewbieProxy = require "Modules.Newbie.NewbieProxy"

	if not bforce then
		if AppConfig.ISALONE then 
			return 
		elseif not NewbieProxy.Instance:IsNeedGuild(NewbieDef.NewbieConst.NotNewbie) then
			return
		elseif not NewbieProxy.Instance:IsNeedGuild(newbieid) then	
			return
		elseif not NewbieProxy.Instance:NewbieIsReady() then
			return
		elseif self.inNewbie and (self.curNewbieid ~= newbieid or (self.curNewbieid == newbieid and self.curStep > 1) ) then
			return		
		end
	end
	
 	if self.cfg.newbie[newbieid] then
 		self.curNewbieid = newbieid
 		self.inNewbie = true
 		self.countStep = #self.cfg.newbie[newbieid]
 		self.curStep = 1
 		self.curNewbieCfg = self.cfg.newbie[newbieid]
 		
 		NewbieProxy.Instance:Send18001(newbieid, NewbieDef.State.Accept)

 		self:StartStep(self.curStep)
 		self:FireBaseEvent(newbieid, NewbieDef.State.Accept)
 	end	
end 

--显示引导界面
function NewbieManager:ShowNewbieTypeView(newbieid, step)
	local NewbieProxy = require "Modules.Newbie.NewbieProxy"
	if AppConfig.ISALONE then 
		return nil
	elseif not NewbieProxy.Instance:IsNeedGuild(NewbieDef.NewbieConst.NotNewbie) then
		return nil
	elseif not NewbieProxy.Instance:IsNeedGuild(newbieid) then	
		-- print("ShowNewbieTypeView========", newbieid, table.dump(NewbieProxy.Instance.newbieList))
		return nil
	elseif not NewbieProxy.Instance:NewbieIsReady() then
		return nil
	end

	local bStart = self:CheckStartCondition(newbieid, step)
	if not bStart then
		return nil
	end

	local bShow = false
	if self.cfg.newbie[newbieid] and self.cfg.newbie[newbieid][step] then
		local curNewbieCfg = self.cfg.newbie[newbieid][step]

		if curNewbieCfg.type == NewbieDef.NewbieType.Forceguide then
			self:ShowForceGuildView(newbieid, step, curNewbieCfg)
			bShow = true
		elseif curNewbieCfg.type == NewbieDef.NewbieType.Weakguide then
			self:ShowWeakGuildView(newbieid, step, curNewbieCfg)
			bShow = true
		elseif curNewbieCfg.type == NewbieDef.NewbieType.NewHero then
			self:ShowNewHeroView(newbieid, step, curNewbieCfg)
			bShow = true
		elseif curNewbieCfg.type == NewbieDef.NewbieType.Dialog then
			self:ShowDialogView(newbieid, step, curNewbieCfg)
			bShow = true
		elseif curNewbieCfg.type == NewbieDef.NewbieType.None then

		end

	end
	return bShow
end

--修復还没达到条件就弹引导
function NewbieManager:CheckStartCondition(newbieid, step)
	local bStart = true
	if self.cfg.newbie[newbieid] and self.cfg.newbie[newbieid][step] then
		local curNewbieCfg = self.cfg.newbie[newbieid][step]
		if curNewbieCfg then
			local mainlineid = RoleInfoModel.mainlineid

			local NewbieProxy = require "Modules.Newbie.NewbieProxy"
			local nextChapterId = NewbieProxy.Instance:GetNewbiePassToMainlineid()
			--需要用到已通过关卡id来判断的引导，都是在挑战按钮显示下一章节的时候弹的引导用这个关卡id来判断
			if NewbieDef.NextChaptherNewbie[newbieid] then
				for i,_step in ipairs(NewbieDef.NextChaptherNewbie[newbieid]) do
					if _step == step then
						mainlineid = nextChapterId
						break
					end
				end
			end

			local _mainline_id = nil
			if curNewbieCfg.type == NewbieDef.NewbieType.Forceguide then
				local cfg = self.cfg.forceguide[curNewbieCfg.id]
				if cfg.parama and cfg.parama.mainlineid then
					_mainline_id = cfg.parama.mainlineid
				end
			elseif curNewbieCfg.type == NewbieDef.NewbieType.Weakguide then
				local cfg = self.cfg.weakguide[curNewbieCfg.id]
				if cfg.parama and cfg.parama.mainlineid then
					_mainline_id = cfg.parama.mainlineid
				end
			elseif curNewbieCfg.type == NewbieDef.NewbieType.NewHero then
			elseif curNewbieCfg.type == NewbieDef.NewbieType.Dialog then
				local cfg = self.cfg.normal_dialog[curNewbieCfg.id]
				if cfg and cfg[1] and cfg[1].parama and cfg[1].parama.mainlineid then
					_mainline_id = cfg[1].parama.mainlineid
				end
			elseif curNewbieCfg.type == NewbieDef.NewbieType.None then
			end
			-- print("CheckStartCondition=============", newbieid, step, _newbie_id, _step, nextChapterId, mainlineid, _mainline_id, debug.traceback())
			if _mainline_id then
				if mainlineid < _mainline_id then
					bStart = false
				end
			end
		end
	end
	return bStart
end

--强引导view
function NewbieManager:ShowForceGuildView(newbieid, step, curNewbieCfg)
	-- print("ShowForceGuildView=======", newbieid, step, table.dump(self.newbieData))
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.NewbieDialogView)
	local registerData = self:GetNewbieData(newbieid, step)
	if view and not view:IsOpen() and registerData then
		local parama = {}
		parama.selectObj = registerData.obj
		parama.cfg = self.cfg.forceguide[curNewbieCfg.id]
		parama.newbieid = newbieid
		local NewbieDialogView = require "Modules.Newbie.NewbieDialogView"
		NewbieDialogView.ShowView(parama)
	end
end

function NewbieManager:ShowForceGuildCheckView(newbieid, step, curNewbieCfg)
	local cfg = self.cfg.forceguide[curNewbieCfg.id]
	if cfg then
		local guildView = LuaLayout.Instance:GetWidget(cfg.view) 
		if guildView then
			if (not guildView:IsOpen()) or (guildView:IsOpen() and guildView.fullhide) then
				self.ClearNewbie()
				return
			end
		end
	end

	self:ShowForceGuildView(newbieid, step, curNewbieCfg)
end

--弱引导
function NewbieManager:ShowWeakGuildView(newbieid, step, curNewbieCfg)
	-- print("ShowWeakGuildView=======", newbieid, step)
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.NewbieWeakGuildView)
	local registerData = self:GetNewbieData(newbieid, step)
	if view and not view:IsOpen() and registerData then 
		local parama = {}
		parama.selectObj = registerData.obj
		parama.cfg = self.cfg.weakguide[curNewbieCfg.id]
		parama.newbieid = newbieid
		local NewbieWeakGuildView = require "Modules.Newbie.NewbieWeakGuildView"
		NewbieWeakGuildView.ShowView(parama)
	end
end

function NewbieManager:ShowWeakGuildCheckView(newbieid, step, curNewbieCfg)
	local cfg = self.cfg.weakguide[curNewbieCfg.id]
	if cfg then
		local guildView = LuaLayout.Instance:GetWidget(cfg.view)
		if guildView then
			if (not guildView:IsOpen()) or (guildView:IsOpen() and guildView.fullhide) then
				self:ClearNewbie()
				return
			end 
		end
	end
	self:ShowWeakGuildView(newbieid, step, curNewbieCfg)
end

--弹新英雄界面
function NewbieManager:ShowNewHeroView(newbieid, step, curNewbieCfg)
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.HeroTipsView)
	local registerData = self:GetNewbieData(newbieid, step)
	if view and not view:IsOpen() and registerData then
		local NewbieProxy = require "Modules.Newbie.NewbieProxy"
		if newbieid then
			NewbieProxy.Instance:Send18002(newbieid)
		end
		GameLogicTools.ShowHeroTipsView(registerData.roleid, registerData.rank, registerData.level, false, false, true)
	end

end

--对话框引导
function NewbieManager:ShowDialogView(newbieid, step, curNewbieCfg)
	local registerData = self:GetNewbieData(newbieid, step)
	local cfg = self.cfg.normal_dialog[curNewbieCfg.id]
	if registerData and cfg and #cfg > 0 then
		if cfg[1].view and cfg[1].view ~= nil then
			local view = LuaLayout.Instance:GetWidget(cfg[1].view)
			if view and view:IsOpen() then
				if cfg[1] and cfg[1].bForceGuide == false then
					--弱引导的话出现即完成
					local NewbieProxy = require "Modules.Newbie.NewbieProxy"
					NewbieProxy.Instance:Send18002(newbieid)
				else
				end
				
				local NewbieNormalNpcDialogView = require "Modules.Newbie.NewbieNormalNpcDialogView"
				local parama = {}
				parama.infos = cfg
				parama.callback = function()
					self:NextStep()
				end
				NewbieNormalNpcDialogView.ShowView(parama)
			end
		end
	end
end

--对话框引导，特殊引导 一些特殊系统第一次进入弹, 手动弹(目前只支持一步)
function NewbieManager:ShowSpecialDialogView(newbieid, step)
	local bOpen = false
	step = 1 --(目前只支持一步)
	local NewbieProxy = require "Modules.Newbie.NewbieProxy"
	local newbie_cfg = NewbieProxy.Instance:GetNewbieTaskCfgById(newbieid)
	if newbie_cfg and newbie_cfg[step] then
		if newbie_cfg[step].type == NewbieDef.NewbieType.Dialog then
			local cfg = NewbieProxy.Instance:GetNormalDialogTipsById(newbie_cfg[step].id)
			if cfg then 
				local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.NewbieNormalNpcDialogView)
				if view and not view:IsOpen() then
					local NewbieNormalNpcDialogView = require "Modules.Newbie.NewbieNormalNpcDialogView"
					local parama = {}
					parama.infos = cfg
					parama.callback = function()
						NewbieProxy.Instance:NormalNpcDialogCloseNotify(newbieid)
					end
					NewbieNormalNpcDialogView.ShowView(parama)
					--打开就完成了
					NewbieProxy.Instance:Send18001(newbieid, NewbieDef.State.Complete)
					bOpen = true
				end
			end
		end
	end
	return bOpen
end

--return 是否跳过继续引导
function NewbieManager:ShowNewbieType(newbieid, step)
	if self.cfg.newbie[newbieid] and self.cfg.newbie[newbieid][step] then
		local curNewbieCfg = self.cfg.newbie[newbieid][step]

		if curNewbieCfg.type == NewbieDef.NewbieType.Dialogue then
			local guidecfg = self.cfg.dialogue[curNewbieCfg.id]
			if guidecfg then
				if curNewbieCfg.id == 0 then
					-- self:NextStep()
					return true
				else	
					if next(guidecfg) then
						local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.NewbieNoticeView)
						if view and not view:IsOpen() then
							view.contexts = guidecfg
							if guidecfg[1].delay then
								local RenderUtil = require "Battle.Implement.Render.RenderUtil"
								RenderUtil.delay(guidecfg[1].delay, function (tweenObj, time, topos)											
										view:OpenView()
									end)
							else
								view:OpenView()
							end
						end
					end	
				end	
			end

		elseif curNewbieCfg.type == NewbieDef.NewbieType.Context then
			local guidecfg = self.cfg.context[curNewbieCfg.id]

		elseif curNewbieCfg.type == NewbieDef.NewbieType.Battle then
			local guidecfg = self.cfg.battle[curNewbieCfg.id]
			if guidecfg then
				if guidecfg.activity or guidecfg.type then
					local gamecfg = nil
					if guidecfg.activity then
						gamecfg = guidecfg

					elseif guidecfg.type then
						local RoomProxy = require "Modules.Room.RoomProxy"
						local activityData = RoomProxy.Instance:GetActivityDataByType(guidecfg.type)
						if activityData then
							local data_activity = ConfigManager.GetConfig("data_activity")
							local config = data_activity[activityData.activityid]
							gamecfg = guidecfg[config.game_id]
						end	
					else
						return	
					end	

					local SceneManager = require "Modules.Scene.SceneManager"
					local SceneDef = require "Modules.Scene.SceneDef"

					if gamecfg and gamecfg.players then
			            local data_activity = ConfigManager.GetConfig("data_activity")
			            local config = data_activity[gamecfg.activity]

						local gameplay = getgameplay(config.game_id)
						gameplay.players = gamecfg.players

						for idx,data in ipairs(gameplay.players) do
							if data.playerid == 1 then
								data.roleid = RoleInfoModel.selectheroid
								data.name = RoleInfoModel.nickname								
							else
								data.brobot = 1
							end	
						end
						SceneManager.Instance:EnterScene(SceneDef.SceneType.Newbie, gamecfg.activity, 1)
					end
				else
					SceneManager.Instance:EnterScene(SceneDef.SceneType.Main)	
				end	
			end	
		elseif curNewbieCfg.type == NewbieDef.NewbieType.Forceguide then
			local guidecfg = self.cfg.forceguide[curNewbieCfg.id]
			if guidecfg then
				local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.NewbieTipsView)
				local data = self:GetNewbieData(newbieid, step)
				if view and not view:IsOpen() and data then
					view.selectObj = data.obj
					view.spriteview = data.spriteview
					view.data = guidecfg
					view:OpenView()
				end
			end			

		elseif curNewbieCfg.type == NewbieDef.NewbieType.Weakguide then
			local guidecfg = self.cfg.weakguide[curNewbieCfg.id]
			if guidecfg then
				local data = self:GetNewbieData(newbieid, step)
				if data then
					self:ShowWeakguide(curNewbieCfg.id, data.obj, data.spriteview, true)
				end	
			end
				
		elseif curNewbieCfg.type == NewbieDef.NewbieType.View then	
			local guidecfg = self.cfg.view[curNewbieCfg.id]
			if guidecfg.view then
				LuaLayout.Instance:OpenWidget(guidecfg.view)

			elseif curNewbieCfg.id == 0 then
				LuaLayout.Instance:CloseWidget(UIWidgetNameDef.NetworkDelayView)
				LuaLayout.Instance:OnlyMainView()
			end	
			return guidecfg and guidecfg.continue
		end		
	end	
end

function NewbieManager:ShowTask(id)
	local text = nil
	local guidecfg = self.cfg.task[id]
	if guidecfg then
		text = guidecfg.text
	end	
	
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.NewbiepayView)
	if view and view:IsOpen() then
		view:ShowTaskTips(text)
	end		
end

function NewbieManager:ShowChat(id)
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.NewbieBigtipsView)

	local guidecfg = id and self.cfg.chat[id] or nil
	if guidecfg then		
		view.data = guidecfg
		if view:IsOpen() then
			view:UpdateInfo(guidecfg)
		else	
			view:OpenView()
		end
	else
		if view:IsOpen() then
			view:CloseView()
		end	
	end	
end

function NewbieManager:ShowWeakguide(id, obj, spriteview, bguild)
	local guidecfg = self.cfg.weakguide[id]
	if guidecfg then
		if guidecfg.view then
			local view = LuaLayout.Instance:GetWidget(guidecfg.view)
			if not view:IsOpen() or (view:IsOpen() and view.fullhide)then
				NewbieManager.Instance:ClearNewbie()
				return
			end	
		end	

		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.NewbieWeakTipsView)
		if view and not view:IsOpen() then
			view.selectObj = obj
			view.spriteview = spriteview
			view.data = guidecfg
			view.bguild = bguild 
			view:OpenView()
			return true
		end
	end	
	return false	
end

function NewbieManager:ShowForceguide(id, obj, spriteview)
	local guidecfg = self.cfg.forceguide[id]
	if guidecfg then
		if guidecfg.view then
			local view = LuaLayout.Instance:GetWidget(guidecfg.view)
			if not view:IsOpen() or (view:IsOpen() and view.fullhide)then
				NewbieManager.Instance:ClearNewbie()
				return
			end	
		end	
		
		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.NewbieTipsView)
		if view and not view:IsOpen() then
			view.selectObj = obj
			view.spriteview = spriteview
			view.data = guidecfg
			view:OpenView()
			return true
		end
	end		
	return false
end

function NewbieManager:StartStep(step)
	-- print("=== StartStep ====", self.curNewbieid, step, self.countStep, table.dump(self.newbieData), debug.traceback())

	if step > self.countStep then
		self:CompleteNewbie()
		return
	end

	if not self.curNewbieCfg or not self.curNewbieCfg[step] then return end

	local curNewbieCfg = self.curNewbieCfg[step]
	local NewbieProxy = require "Modules.Newbie.NewbieProxy"

	local bcontinue = self:ShowNewbieTypeView(self.curNewbieid, step)
	-- print("bcontinue===========", bcontinue)
	if not bcontinue then
		return
	end

	--针对某些特殊强引导做处理，比如强引导到某一步就算完成
	if curNewbieCfg.bComplete then
		NewbieProxy.Instance:Send18002(self.curNewbieid)
	end
	-- print("=== StartStep ====", self.curNewbieid, step, self.countStep, debug.traceback())
	NewbieProxy.Instance:NewBieNotify(self.curNewbieid, self.curStep)  --可用于释放大招 引导

	if self.curStep > self.countStep then
		self:CompleteNewbie()

	--界面引导则继续	
	-- elseif bcontinue then
	-- 	self:NextStep()
	end
end	

function NewbieManager:NextStep()
	--print("=== NextStep ====", self.curNewbieid, self.curStep, self.countStep, debug.traceback())
	--local count = self:GetNewbieStepIndex(self.curNewbieid, self.curStep)
	--print("---->>", count)
	if self.curNewbieid ~= 0 and self.curStep ~= 0 then
		if SystemConfig.isIGGTestPlatform() then
			--local SdkProxy = require "Modules.Sdk.SdkProxy"
			--local SdkDef = require "Modules.Sdk.SdkDef"
			--local count = self:GetNewbieStepIndex(self.curNewbieid, self.curStep)
			--local param = {}
			--param.step = count
			--SdkProxy.Instance:sdk_logevent(SdkDef.firebase_event.Tutorial, param)
		end
		local NewbieProxy = require "Modules.Newbie.NewbieProxy"
		local newbie_cfg = NewbieProxy.Instance:GetNewbieTaskCfgById(self.curNewbieid)
		if newbie_cfg and newbie_cfg[self.curStep] then
			local newbie_step_infos = newbie_cfg[self.curStep]
			NewbieProxy.Instance:SendPoint(newbie_step_infos.id)
		end
	end

	if SystemConfig.isIGGPlatform() then
		self:AFEventComplete(self.curNewbieid, self.curStep)
	end

	if self.curStep > self.countStep then 
		self:CompleteNewbie()
	else
		self.curStep = self.curStep + 1
		self:StartStep(self.curStep)	
	end
end

--新手引导AFEvent
function NewbieManager:AFEventComplete(curNewbieid, curStep)
	local IGGSdkDef = require "Modules.IGGSdk.IGGSdkDef"
	local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"

	for newbieid, infos in pairs(IGGSdkDef.AFEventNewBie) do
		if newbieid == curNewbieid and infos[curStep] then
			IGGSdkProxy.Instance:Track(infos[curStep])
		end
	end

end

--firebase事件 start
function NewbieManager:FireBaseEvent(newbie_id, state)
    --完成新手
    -- local _fireBaseEvent = {
    --     [10001] = {}, --完成上阵
    --     [90001] = {}, --大招新手引导
    --     [10006] = {}, --完成升级
    -- }
	local IGGSdkDef = require "Modules.IGGSdk.IGGSdkDef"
	local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
    local _fireBase_startEvent = 10001 --触发完成上阵 开始
    local _fireBase_endEvent = 10014  --新手引导完成 结束

	if (newbie_id == _fireBase_startEvent and state == NewbieDef.State.Accept) then
		if not self.sendedBeginEvent then
			self.sendedBeginEvent = true
			IGGSdkProxy.Instance:SendTutorialBegin()
		end
	elseif (newbie_id == _fireBase_endEvent and state == NewbieDef.State.Complete) then
		local LanguageManager = require "Common.Mgr.Language.LanguageManager"
		local content = LanguageManager.Instance:GetWord("Activity_Elven_1009")
		IGGSdkProxy.Instance:SendTutorialComplete(content, _fireBase_endEvent, true)
	end
end

function NewbieManager:ContinuStep()
end

function NewbieManager:CompleteNewbie(newbieid)
	-- print("=== CompleteNewbie ====", newbieid or self.curNewbieid, debug.traceback())
	newbieid = newbieid or self.curNewbieid
	if newbieid ~= 0 then
		local NewbieProxy = require "Modules.Newbie.NewbieProxy"
		NewbieProxy.Instance:Send18001(newbieid, NewbieDef.State.Complete)
		self.lastCompleteNewbieid = newbieid
		self:FireBaseEvent(newbieid, NewbieDef.State.Complete)
	end
	self:ClearNewbie()
end

function NewbieManager:ClearNewbie()
	-- print("=== ClearNewbie ===", debug.traceback())
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.NewbieDialogView)
	if view and view:IsOpen() then
		view:CloseView()
	end

	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.NewbieWeakGuildView)
	if view and view:IsOpen() then
		view:CloseView()
	end
	
	self.inNewbie = false
	self.curNewbieid = 0
	self.curStep = 0
	self.countStep = 0
	self.curNewbieCfg = nil	
end

function NewbieManager:RegisterData(newbieid, step, data)
	self.newbieData[newbieid] = self.newbieData[newbieid] or {}
	self.newbieData[newbieid][step] = data
	-- print("RegisterData")
end

function NewbieManager:GetNewbieData(newbieid, step)
	if self.newbieData[newbieid] and self.newbieData[newbieid][step] then
		return self.newbieData[newbieid][step]
	end	
end

--获取当前引导步骤配置
function NewbieManager:GetCurNewbieStepConfig()
	if self.curNewbieCfg ~= nil then
		if self.curNewbieCfg[self.curStep] then
			local guildType = self.curNewbieCfg[self.curStep].type
			local guildId = self.curNewbieCfg[self.curStep].id
			if guildType == NewbieDef.NewbieType.Forceguide then
				return self.cfg.forceguide[guildId], guildType					
			elseif guildType == NewbieDef.NewbieType.Weakguide then
				return self.cfg.weakguide[guildId], guildType	
			elseif guildType == NewbieDef.NewbieType.NewHero then
				return self.cfg.newhero[guildId], guildType	
			elseif guildType == NewbieDef.NewbieType.Dialog then
				--对话框的配置比较特殊，一步里配置了多条对话
				return self.cfg.normal_dialog[guildId], guildType	
			end
		end
	end
end

--获取引导步骤配置
function NewbieManager:GetNewbieStepConfig(newbieid, step)
	if self.cfg.newbie[newbieid] and self.cfg.newbie[newbieid][step] then
		local cfg =  self.cfg.newbie[newbieid][step]
		if cfg.type == NewbieDef.NewbieType.Forceguide then
			if self.cfg.forceguide[cfg.id] then
				return self.cfg.forceguide[cfg.id], cfg.type
			end
		elseif cfg.type == NewbieDef.NewbieType.Weakguide then
			if self.cfg.weakguide[cfg.id] then
				return self.cfg.weakguide[cfg.id], cfg.type
			end
		elseif cfg.type == NewbieDef.NewbieType.NewHero then
			if self.cfg.newhero[cfg.id] then
				return self.cfg.newhero[cfg.id], cfg.type
			end
		elseif cfg.type == NewbieDef.NewbieType.Dialog then
			--对话框的配置比较特殊，一步里配置了多条对话
			if self.cfg.normal_dialog[cfg.id] then
				return self.cfg.normal_dialog[cfg.id], cfg.type
			end
		end
	end
end

--当前引导id ，步骤
function NewbieManager:GetCurNewbieId()
	return self.curNewbieid, self.curStep
end

function NewbieManager:InTrigger()
	local NewbieProxy = require "Modules.Newbie.NewbieProxy"
	-- print("self.curNewbieid, self.curStep=======", self.curNewbieid, self.curStep, table.dump(NewbieProxy.Instance.newbieList))
	if not NewbieProxy.Instance:IsNeedGuild(NewbieDef.NewbieConst.NotNewbie) then
		return false
	else
		return ((self.curNewbieid > 0) and (self.curStep > 0)) and true or false
	end	
end

function NewbieManager:IsNewbieViewOnOpen()
	
	if (self.curNewbieid == 0) or (self.curStep == 0) then
		return false
	end

	local newbie_status = ((self.curNewbieid > 0) and (self.curStep > 1)) and true or false
	if newbie_status == true then
		return true
	end

	local newbie_views = {
		UIWidgetNameDef.NewbieDialogView,
		UIWidgetNameDef.NewbieWeakGuildView,
		UIWidgetNameDef.NewbieFingerView,
		UIWidgetNameDef.NewbieSignalView,
		UIWidgetNameDef.NewbieNpcDialogueView,
		UIWidgetNameDef.NewbieCertificateView,
		UIWidgetNameDef.NewbieNormalNpcDialogView,
		UIWidgetNameDef.NewbieSpecialWeakView,

	}

	local bOpen = false
	for k,widget_name in pairs(newbie_views) do
		local view = LuaLayout.Instance:GetWidget(widget_name)
		if view and view:IsOpen() then
			bOpen = true 
			break
		end
	end

	if bOpen then
		return true
	end
	return false
end

function NewbieManager:ClearAllData()
	self.newbieData = {}	
end

--获取当前引导
function NewbieManager:GetCurNewbieIdStep()
	return self.curNewbieid, self.curStep
end

--newbieid任务是否完成
function NewbieManager:NewbieIsComplete(newbieid)
	local NewbieProxy = require "Modules.Newbie.NewbieProxy"
	local newbieList = NewbieProxy.Instance.newbieList
	if newbieList[newbieid] and newbieList[newbieid] == NewbieDef.State.Complete then
		return true
	end

end

--
function NewbieManager:TriggerNewbie()
	if not self:bInitTrigger() then return end
	
	--自动触发检测
	local NewbieProxy = require "Modules.Newbie.NewbieProxy"
	local newbieList = NewbieProxy.Instance.newbieList
	
	for newbieid, lastNewbies in pairs(NewbieDef.TriggerDef) do
		if newbieList[newbieid] ~= NewbieDef.State.Complete then
			local bTrigger = true
			for _,lastid in pairs(lastNewbies) do
				if newbieList[lastid] ~= NewbieDef.State.Complete then
					bTrigger = false
				end 	
			end
			-- print("TriggerNewbie=============", newbieid, table.dump(newbieList))
			if bTrigger then
				self:StartNewbie(newbieid)
				return true
			end	
		end	
	end

	return false
end

function NewbieManager:IsNeedNewbie()
	local NewbieProxy = require "Modules.Newbie.NewbieProxy"
	local newbieList = NewbieProxy.Instance.newbieList

	for newbieid, lastNewbies in pairs(NewbieDef.TriggerDef) do
		if newbieList[newbieid] ~= NewbieDef.State.Complete then
			local bTrigger = true
			for _,lastid in pairs(lastNewbies) do
				if newbieList[lastid] ~= NewbieDef.State.Complete then
					bTrigger = false
				end 	
			end		
			if bTrigger then
				return true
			end	
		end	
	end	

	return false
end

--是否已初始化了新手引导列表
function NewbieManager:bInitTrigger()
	local NewbieProxy = require "Modules.Newbie.NewbieProxy"
	return NewbieProxy.Instance.data.binit
end

function NewbieManager:GetNewbieAllStep(newbieid)
	if NewbieDef.TriggerDef[newbieid] and self.cfg.newbie[newbieid] then
		return #self.cfg.newbie[newbieid]
	end
end

function NewbieManager:GetNewbieStepCount(newbieid, count)
	if NewbieDef.TriggerDef[newbieid] and #NewbieDef.TriggerDef[newbieid] > 0 then
		for _, _newbieid in pairs(NewbieDef.TriggerDef[newbieid]) do
			count = count + self:GetNewbieAllStep(_newbieid)
			count = self:GetNewbieStepCount(_newbieid, count)
		end
		return count
	else
		return count
	end
end

--当前引导是整个引导中第几步  Tutorial
function NewbieManager:GetNewbieStepIndex(newbieid, step)
	local count = 0
	count = self:GetNewbieStepCount(newbieid, count)

	count = count + step

	return count
end

--程序控制引导步骤进行下一步newbielist:{[newbieid] = step,...}
function NewbieManager:AutoHandleNewbieStep(newbielist)
	local newbie_id, newbie_step = self:GetCurNewbieId()
	if newbielist[newbie_id] and newbielist[newbie_id] == newbie_step then
		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.NewbieDialogView)
		if view and view:IsOpen() then
			view:CloseView()
		end

		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.NewbieWeakGuildView)
		if view and view:IsOpen() then
			view:CloseView()
		end			
		self:NextStep()
		return true
	end
	return false
end

return NewbieManager