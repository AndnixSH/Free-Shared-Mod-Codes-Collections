local game_view = require "Battle.render.view.base_game_view"

local render_camera = require "Battle.render.camera.render_camera"

local effect_sprite_model = require "Battle.render.model.effect_sprite_model"
local simple_anchor = require "Battle.render.anchor.simple_anchor"
local hangup_drop_anchor = require "Battle.render.anchor.hangup_drop_anchor"
local bone_camera_anchor = require "Battle.render.anchor.bone_camera_anchor"

local SceneProxy = require "Modules.Scene.SceneProxy"

--local AmbientMode = CS.UnityEngine.Rendering.AmbientMode
local RenderSettings = CS.UnityEngine.RenderSettings
local FogMode = CS.UnityEngine.FogMode

local hang_up_game_view = game_view()

local hang_up_reward_effect = {
    [1] = {name = "131001", position = {5.94, 0.38, 9.52}},
    [2] = {name = "131002", position = {5.816, 0.621, 9.431}},
    [3] = {name = "131003", position = {5.74, 0.615, 9.39}},
    [4] = {name = "131004", position = {6, 0.812, 9.437}},
    [5] = {name = "131005", position = {6, 0.725, 9.321}},
    [6] = {name = "131006", position = {6, 0.772, 9.256}},
}

function hang_up_game_view:__init()
    self.drop_box_index = 0
    self.drop_effect_count = 0
    self.drop_effect_index = 0
    self.drop_effects = {}
end

function hang_up_game_view:__delete()

end

function hang_up_game_view:on_start()
    local cfg = SceneProxy.Instance:GetSceneCfgById(self.game_info.sceneid)
    
    if not cfg then
        print("hang up config is nil, please check out ...")
        return
    end
    local scenecfg = cfg.hangup
    -- render_camera.set_camera_position(21, 17.25, -10, 35.451, -36.87, 0, 18)

    -- camera background color
    if scenecfg.camera then
        --local field_of_view = scenecfg.camera[7]
        --render_camera.set_camera_field_of_view(field_of_view)

        local red = scenecfg.camera[1]
        local green = scenecfg.camera[2]
        local blue = scenecfg.camera[3]
        local alpha = scenecfg.camera[4]
        render_camera.set_camera_background_color(red, green, blue, alpha)

        --render_camera.set_camera_transform(scenecfg.camera)
    end

    -- scene fog color
    if scenecfg.fogColor then
        RenderSettings.fog = true
        RenderSettings.fogColor = Color.New(scenecfg.fogColor[1] / 255 , scenecfg.fogColor[2] / 255, scenecfg.fogColor[3] / 255) --Color.white -- {255, 255, 255}
        RenderSettings.fogMode = FogMode.Linear

        if scenecfg.fogDistance then
            RenderSettings.fogStartDistance = scenecfg.fogDistance[1]
            RenderSettings.fogEndDistance = scenecfg.fogDistance[2]
        end

        --if scenecfg.ambientLight then
            --RenderSettings.ambientMode = AmbientMode.Flat
            --RenderSettings.ambientLight = Color.New(scenecfg.ambientLight[1] / 255, scenecfg.ambientLight[2] / 255, scenecfg.ambientLight[3] / 255)
        --end
    end

    local rootObj = AssetManager.GetActiveSceneRootObject()
    local camera_position_obj = GameObjTools.GetChild(rootObj, "cameraPos")
    if camera_position_obj then
        camera_position_obj:SetActive(false)
    end

    local camera_boss_position_obj = GameObjTools.GetChild(rootObj, "cameraBossPos/cam")
    if camera_boss_position_obj then
        camera_boss_position_obj:SetActive(false)
    end

    self.drop_position = scenecfg.drop --Vector3.New(scenecfg.drop[1], scenecfg.drop[2], scenecfg.drop[3])

    if cfg.weather and type(cfg.weather) == 'string' then
        local anchor = bone_camera_anchor.New()
        self.weather_effect = effect_sprite_model.New(anchor, cfg.weather)
    end
end

function hang_up_game_view:on_end()
    if self.drop_effects then
        for index, effect in pairs(self.drop_effects) do
            effect:release()
            self.drop_effects[index] = nil
        end
    end

    if self.hangup_reward_effect then
        self.hangup_reward_effect:release()
        self.hangup_reward_effect:DeleteMe()
        self.hangup_reward_effect = nil
    end

    if self.weather_effect then
        self.weather_effect:release()
        self.weather_effect:DeleteMe()
        self.weather_effect = nil
    end

    self.drop_effect_count = 0
    self.drop_effect_index = 0
    self.drop_effects = {}

    render_camera.free_trunk_strategy()
end

function hang_up_game_view:on_hangup_reward(hangup_time)
    --print("===================>>hangup_time", hangup_time)
    local minute = hangup_time / 60
    local effect_name
    if minute < 10 then
        effect_name = hang_up_reward_effect[1].name
        self.drop_box_index = 1
    elseif minute < 60 then
        effect_name = hang_up_reward_effect[2].name
        self.drop_box_index = 2
    elseif minute < 180 then
        effect_name = hang_up_reward_effect[3].name
        self.drop_box_index = 3
    elseif minute < 360 then
        effect_name = hang_up_reward_effect[4].name
        self.drop_box_index = 4
    elseif minute < 720 then
        effect_name = hang_up_reward_effect[5].name
        self.drop_box_index = 5
    else
        effect_name = hang_up_reward_effect[6].name
        self.drop_box_index = 6
    end

    if effect_name then
        if self.hangup_reward_effect then
            self.hangup_reward_effect:release()
            self.hangup_reward_effect = nil
        end

        local anchor = simple_anchor.New(6, 0, 10, 0, -1)
        self.hangup_reward_effect = effect_sprite_model.New(anchor, effect_name)
    end
end

function hang_up_game_view.event.sprite.public:skill_hit(_, hitid, position, header, height)
    self:on_skill_hit(hitid, position, header, height)
end

local effect_names = {"scenes_battle_coin1", "scenes_battle_coin2", "scenes_battle_exp1", "scenes_battle_exp2",}
function hang_up_game_view.event.sprite.public:monster_dead(_, position, monster_type)
    if not self.is_show then
        return
    end

    if self.drop_effect_count > 20 then
        return
    end

    local random_num = math.random(1, 10000)
    if random_num > 5000 then
        return
    end

    local effect_name
    if monster_type == MONSTER_TYPE.ELITE then
        effect_name = "scenes_battle_coinandexp"
    else
        local random_index = math.random(1, 4)
        effect_name = effect_names[random_index]
    end

    if effect_name then
        self.drop_effect_count = self.drop_effect_count + 1
        self.drop_effect_index = self.drop_effect_index + 1
        local effect_index = string.format("index_%d", self.drop_effect_index)
        if self.drop_box_index == 0 then
            self.drop_box_index = 1
        end
        local drop_target_position = hang_up_reward_effect[self.drop_box_index].position
        if drop_target_position then
            local anchor = hangup_drop_anchor.New(position.x / 1000, 0, position.y / 1000, drop_target_position[1], drop_target_position[2], drop_target_position[3], 2.8, 10, 60, effect_index, function(index)
                if self.drop_effects then
                    local model = self.drop_effects[index]
                    if model then
                        model:release()
                        self.drop_effects[index] = nil
                        self.drop_effect_count = self.drop_effect_count - 1
                    end
                end
            end)
            self.drop_effects[effect_index] = effect_sprite_model.New(anchor, effect_name)
        end
    end

end

function hang_up_game_view.event.game:camera_adjust(offsetx, offsety, rate)
    --print('camera_adjust', offsetx, offsety, rate)
    render_camera.set_adjust_offset(offsetx / 1000, offsety / 1000, rate, 10)
end

function hang_up_game_view.event.game:camera_strategy(strategy, args)
    if strategy == CAMERA_STRATEGY.TRANSFORM then
        self:set_transform_camera(args)
    elseif strategy == CAMERA_STRATEGY.ADJUST then
        self:set_adjust_camera(args)
    end
end

function hang_up_game_view:set_transform_camera(args)
    if args.fieldOfView then
        render_camera.set_camera_field_of_view(args.fieldOfView)
    end

    if next(args) ~= nil then
        render_camera.free_trunk_strategy()
        render_camera.set_camera_transform(args)
    end
end

function hang_up_game_view:set_adjust_camera(args)
    if next(args) ~= nil then
        render_camera.set_adjust_trunk_strategy(args)
    end
end
return hang_up_game_view