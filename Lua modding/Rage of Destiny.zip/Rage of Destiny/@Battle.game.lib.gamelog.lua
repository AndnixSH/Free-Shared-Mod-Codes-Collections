gamelog = {
    type = GameConfig.LOG,
    filter_sprite_list = {},
    logfile = nil,
}

function gamelog.start()
    gamelog.curlv = 0
    gamelog.maxlv = 1
    if gamelog.type == 2 then
        logfile = io.open("gamelog.txt", 'w')
    end
end

function gamelog.setlevel(lv)
    if lv then
        if lv == 0 then
            gamelog.type = 0
        elseif gamelog.type == 0 then
            gamelog.type = 1
        end
        gamelog.maxlv = lv 
    end
    return gamelog
end

function gamelog.level(lv)
    if lv then gamelog.curlv = lv end
    return gamelog
end

local function tstring(split, ...)
    local t = {}
    for i, v in ipairs({ ... }) do
        table.insert(t, tostring(v))
    end
    return table.concat(t, split)
end

local function log(...)
    if gamelog.type == 1 then
        print(...)
    elseif gamelog.type == 2 then
        logfile:write(tstring(" ", ...))
        logfile:write("\n")
        logfile:flush()
    end
    gamelog.level(0)
end

local function canlog(spriteobj)

    if gamelog.type == 0 or gamelog.curlv > gamelog.maxlv  then return false end

    if spriteobj then
        for i, spriteid in ipairs(gamelog.filter_sprite_list) do
            if spriteid == spriteobj.uid then
                return true
            end
        end
        return false
    else
        return true
    end
end

function gamelog.trace(...)
    print(tstring(", ", ...), debug.traceback())
end

function gamelog.debug(...)
    print(string.format("【f:%d t:%d】", global.service.time.frame, global.service.time.time), ...)
end

function gamelog.debugtrace(...)
    print(string.format("【f:%d t:%d】 %s", global.service.time.frame, global.service.time.time, tstring(", ", ...)), debug.traceback())
end

function gamelog.addspritelog(id)
    local list = gamelog.filter_sprite_list
    for i, spriteid in ipairs(list) do
        if id == spriteid then
            return gamelog
        end
    end
    table.insert(list, id)
    return gamelog
end

function gamelog.removespritelog(id)
    local list = gamelog.filter_sprite_list
    for i = #list, 1, -1 do
        if id == list[i] then
            table.remove(list, i)
        end
    end
    return gamelog
end

function gamelog.time()
    return global.service.time.time
end

function gamelog.write(...)
    if canlog() then
        log(string.format("【t:%d】", gamelog.time()), ...)
    end
end

function gamelog.sprite(obj, ...)
    if canlog(obj) then
        log(string.format("【t:%d (%s)】", gamelog.time(), obj), ...)
    end
end

function gamelog.spriteto(from, to, ...)
    if canlog(from) then
        log(string.format("【t:%d (%s)->(%s)】", gamelog.time(), from, to), ...)
    end
end

function gamelog.stop()
    if logfile then
        logfile:flush()
        logfile:close()
    end
    gamelog.filter_sprite_list = {}
end

return gamelog