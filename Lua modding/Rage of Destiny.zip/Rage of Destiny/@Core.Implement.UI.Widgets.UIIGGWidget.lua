local UIIGGWidget = UITopWidget or BaseClass(LuaBasicWidget)
function UIIGGWidget:OnLoad()
    local obj = GameObject(UIWidgetNameDef.Root_IGG)
    GameObjTools.AddComponent(obj,"RectTransform")
    self:LoadEnd(obj)
end

function UIIGGWidget:LoadEnd(obj)
    self:SetGo(obj)
    self:AddPanel(UIWidgetNameDef.IGGPanel)

    self:Step(0)
end

function UIIGGWidget:OnOpen()
    self:SetDepth(self.go ,11100)
    self:SetModelDepth(self.go, 20000)
end

return UIIGGWidget