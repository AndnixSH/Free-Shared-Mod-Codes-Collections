local cs_coroutine = require "First.Util.cs_coroutine"
local FrameUpdateMgr = require "First.Util.FrameUpdateMgr"
local isEditor = CS.UnityEngine.Application.isEditor
local CSScreenShotter = CS.ScreenShotter
local GameObject =  CS.UnityEngine.GameObject

require "First.Util.StringUtil"
require "First.Util.TableUtil"
require "First.SystemConfig"

-- 大厅lua程序的入口类
local LobbyMain = {}
local updateView = require "First.Update.View.UpdateView"
local _benterGame = false
local _TimeMsg = nil
local _cheatview = nil
local _needToRestart = false
local _bCheckUpdate = true

function GetUpdateView()
    return updateView
end

function LobbyMain.Start(checkUpdate)
	_bCheckUpdate = (false ~= checkUpdate)
	
    print("Lobby Start", os.date("%Y-%m-%d %H:%M:%S", os.time()))
    cs_coroutine.start(function()
        --init language
        local LanguageUtil = require "First.Util.LanguageUtil"
		updateView:New()
        coroutine.yield(LanguageUtil.Init())
		updateView:SetUpdateState(updateView.UpdateState.None, 0.05, 0)

        --init systemconfig
		updateView:SetUpdateState(updateView.UpdateState.InitConfig, 0.3, 0.05)
			
        coroutine.yield(SystemConfig.Init())
        coroutine.yield(CS.UnityEngine.WaitForSeconds(0.05))

        local UpdateMananger = require "First.Update.UpdateMananger"
        coroutine.yield(UpdateMananger.GetLocalVersionInfo()) --显示版本号

        updateView:SetUpdateState(updateView.UpdateState.RequireConfig, 0.5, 0.3)
        local SdkManager = require "First.Sdk.SdkManager"
        coroutine.yield(SdkManager.Init())
        coroutine.yield(CS.UnityEngine.WaitForSeconds(0.05))
        local func = function()
			if _bCheckUpdate then
	            updateView:SetUpdateState(updateView.UpdateState.CheckVersion, 0.7, 0.5)
	            UpdateMananger.SetCompleteCallBack(LobbyMain.StartPreLoad)
	            return cs_coroutine.start(function()
	                coroutine.yield(UpdateMananger.Init())
	            end)
			else
				LobbyMain.StartPreLoad(false)	
			end
        end
        coroutine.yield(SdkManager.CheckForceVersionCondition(func))
        -- coroutine.yield(SdkManager.CheckForceVersionCondition())
        if not SdkManager.IsLoad_Appcfg_End() then
            --长时间等待Appconfig，弹窗退游戏
            local ConfirmView = require "First.Update.View.ConfirmView"
            local content = string.format(LanguageUtil.GetWord("confirm_tips_1001"))
            ConfirmView.Show(content, function()
                Application.Quit()
            end, nil, nil, "Common_1004", 1, "Common_1006")
        else
            -- if not SdkManager.IsForceUpdate() then
            --     --checkupdate
            --     updateView:SetUpdateState(updateView.UpdateState.CheckVersion, 1, 0.9)
            --     UpdateMananger.SetCompleteCallBack(LobbyMain.StartPreLoad)
            --     coroutine.yield(UpdateMananger.Init())
            -- end
        end

    end)
end

function LobbyMain.StartPreLoad(restart)
	print("Update Finish", os.time())
	if restart and SystemConfig.RestartAfterUpdate then
		print("准备重启LUA虚拟机")
		CSScreenShotter.Capture(function (texture)
				local uiroot = GameObject.Find("UIRoot")
				local bg = GameObject("UpdateScreenShotterBg")
				local tex = bg.AddComponent(bg, typeof(CS.CTexture))
				tex.texture = texture
				local rootRect = uiroot:GetComponent("Transform")
				bg:GetComponent("Transform").sizeDelta = CS.UnityEngine.Vector2(rootRect.rect.width, rootRect.rect.height)
				bg.transform:SetParent(uiroot.transform, false)
				
				local SdkManager = require "First.Sdk.SdkManager"
				SdkManager.Dispose()
				updateView:Destroy()
                --local UIPoolManager = CS.LJY.NX.UIPoolManager
                --UIPoolManager.Instance:ClearUITextureCache()
				_needToRestart = true
			end)
	else
		local uiroot = GameObject.Find("UIRoot")
		local bg = uiroot.transform:Find("UpdateScreenShotterBg")
		if bg then
			GameObject.Destroy(bg.gameObject)
		end
		
    	local AssetLoaderAdapter = CS.LJY.NX.AssetLoaderAdapter
	    AssetLoaderAdapter.LoadLuaAssetAssetBundle(false, function()
	        LobbyMain.GameStart()
	    end)
	end
end

--开始游戏
function LobbyMain.GameStart()
    updateView:SetUpdateState(updateView.UpdateState.EntryGame, 1, 0.7)

    require "Common.Global.Global"

    local LanguageManager = require "Common.Mgr.Language.LanguageManager"
    LanguageManager.New()
    UILayerTool.Init()
    ModulesInit()

    _benterGame = true
    local SceneManager = require "Modules.Scene.SceneManager"
    local SceneDef = require "Modules.Scene.SceneDef"
    if SceneManager.Instance then
        SceneManager.Instance:EnterScene(SceneDef.SceneType.Login, function()
            -- if updateView then
            --     updateView:Destroy()
            -- end
            if updateView then
                updateView:SetProrgressObjActive(false)
                local version_str = tostring(Application.version) .. "_" .. tostring(SystemConfig.ResVersion)
                updateView:SetVersionContent(true, version_str)
            end
        end)
    end
end

function LobbyMain.SdkCallbackEvent(args)
    if _benterGame then
        local SdkProxy = require "Modules.Sdk.SdkProxy"
        SdkProxy.Instance:OnSdkCallbackEvent(args)
    else
        local SdkManager = require "First.Sdk.SdkManager"
        SdkManager.OnSdkCallbackEvent(args)
    end
end

function LobbyMain.Update(time, deltaTime)
    FrameUpdateMgr.Update(time, deltaTime)
    if _benterGame then
        Time:SetFrameCount()
        Time:SetDeltaTime(deltaTime, deltaTime)

        if _TimeMsg then
            _TimeMsg.ToUpdate()
        else
            _TimeMsg = require "Common.Mgr.TimerMgr"
        end

        if _cheatview then
            _cheatview.OnKeyBoardClick()
        else
            _cheatview = require "Modules.Cheat.CheatView"
        end
    end
end

function LobbyMain.FixedUpdate(fixedTime, fixedDeltaTime)
    if _benterGame then
        Time:SetFixedDelta(fixedDeltaTime)
    end
end

function LobbyMain.Destroy()
    --[[print("Lobby Destroy")
    if _benterGame then
        local main = require "Battle.GameMain"
        main.Dispose()
    end
    ]]
end

function LobbyMain.Dispose()
    local cGameNetWork = CS.LJY.NX.GameNetWork.Instance
    --cGameNetWork.HandleTcpBuffer = nil
    cGameNetWork:Close()

	if _benterGame then
    	LuaLayout.Instance:DisposeAllWidget()
		
		for proxy_name, proxy in pairs(faceProxyList) do
			proxy:DeleteMe()
		end
		faceProxyList = {}
		
		local render_arena = require "Battle.render.render_area"
		render_arena.dispose()
		
		AssetManager.ClearUITexture()
        AssetManager.DestroyPoolUIPrefab()
	end

    if _TimeMsg then
        _TimeMsg:RemoveAll()
    end
	
	if updateView then
		updateView:Destroy()
	end
end

function LobbyMain.OnBackPressed()
    local SceneManager = require "Modules.Scene.SceneManager"
    local SceneDef = require "Modules.Scene.SceneDef"
    local sceneType = SceneManager.Instance:GetCurSceneType()
    if sceneType > SceneDef.SceneType.Login then
        if sceneType == SceneDef.SceneType.Main or sceneType == SceneDef.SceneType.DrawCard or
                sceneType == SceneDef.SceneType.Crystal or sceneType == SceneDef.SceneType.Hero or
                sceneType == SceneDef.SceneType.Temple or sceneType == SceneDef.SceneType.CardStar
                or sceneType == SceneDef.SceneType.Maze or sceneType == SceneDef.SceneType.StoryLine 
                or sceneType == SceneDef.SceneType.Activity then
            local SettingProxy = require "Modules.Setting.SettingProxy"
            SettingProxy.Instance:EscView()
        end
    end
end

function LobbyMain.ApplicationPause(pause)
    if pause and _benterGame and not isEditor then
        if global and global.game.gameid ~= GAMEPLAYID.HANGUP then
            local BattleProxy = require "Modules.Battle.BattleProxy"
            BattleProxy.Instance:StopGame()
        end
    end

    if _benterGame and not isEditor then
        local LoginProxy = require "Modules.Login.LoginProxy"
        LoginProxy.Instance:ApplicationPause(pause)
    end
end

function LobbyMain.ApplicationFocuse(focus)
    if not focus and _benterGame and not isEditor then
        if global and global.game.gameid ~= GAMEPLAYID.HANGUP then
            local BattleProxy = require "Modules.Battle.BattleProxy"
            BattleProxy.Instance:StopGame()
        end
    end
end

function LobbyMain.CSpriteAwakeCallback(sprite)
    if sprite then
        local LanguageUtil = require "First.Util.LanguageUtil"
        LanguageUtil.TranslateSprite(sprite)
    end
end

function LobbyMain.CLabelAwakeCallback(label)
    if label then
        local LanguageUtil = require "First.Util.LanguageUtil"
        LanguageUtil.ChangeLabelFont(label)
        LanguageUtil.TranslateLabel(label)
    end
end

function LobbyMain.CheckNeedToRestartLuaEnv()
	return _needToRestart
end

return LobbyMain