local simple_anchor = simple_anchor or BaseClass()

local CSimpleAnchor = CS.LJY.NX.SimpleAnchor

function simple_anchor:__init(x, y, z, r_x, r_y, r_z)
    if not r_z then
        self.canchor = CSimpleAnchor(x, y, z, r_x, r_y)
    else
        self.canchor = CSimpleAnchor(x, y, z, r_x, r_y, r_z)
    end
end

function simple_anchor:__delete()
    self.canchor = nil
end

return simple_anchor