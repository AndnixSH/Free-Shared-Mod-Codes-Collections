local logic = {}

function logic:onbreak()
    return self.owner.attr.hp == 0
end

function logic:onenter(time)
    self:sendmessage(eventdef.sprite_dead)
end

function logic:onupdate(time, tick)
    return self.owner.attr.hp > 0 and STATE_STATUS.OVER or STATE_STATUS.SUSPEND
end

return logic