local UISpineBase = BaseClass()

local ui_spine_model = require "Battle.render.model.ui_spine_model"

function UISpineBase:__init(parentObj)
    assert(parentObj ~= nil, "the spine parent obj is not be null")
    self.parentObj = parentObj

    self.load_end = false
    self.is_open = false
end

function UISpineBase:SetModel(assetName, transform_info, active, loadEndCallback)
    if tostring(assetName) == tostring(self.assetName) then
        return
    end
    self.assetName = tostring(assetName)
    self.transform_info = transform_info

    if active then
        self.activeName = string.format("%s_%s", self.assetName, active)
        --self.activeName = activeName
    end

    self.model = ui_spine_model.New(nil, self.assetName, function(gameItemModel)
        self.gameItemModel = gameItemModel
        gameItemModel:ModelPosition(0, 0, 0)
        if self.parentObj then
            gameItemModel:SetParent(self.parentObj.transform)
        end
        gameItemModel:HideModel()
        self.load_end = true
        self:LoadEnd()
			
		if loadEndCallback then
			loadEndCallback()
		end
    end)

    self:LoadEnd()
end

function UISpineBase:LoadEnd()
    if self.model and self.load_end then
        self:Open()
    end
end

function UISpineBase:Open()
    if not self.is_open then
        if self.transform_info then
            if self.transform_info.position then
                self.model:model_localposition(self.transform_info.position[1], self.transform_info.position[2], self.transform_info.position[3])
            end

            if self.transform_info.scale then
                self.model:model_scale(self.transform_info.scale)
            end

            if self.transform_info.rotation then
                self.model:model_rotate(0, self.transform_info.rotation, 0)
            end
        end
        self.model:showmodel()
        if self.activeName then
            self.model:start_active(self.activeName)
        end
        self:OnOpen()
        self.is_open = true
    end
end

function UISpineBase:StartActive(active, fltSpeed)
    fltSpeed = fltSpeed or 1
    if self.model and active then
        local activeName = string.format("%s_%s", self.assetName, active)
        self.activeName = activeName
        self.model:start_active(activeName, fltSpeed)
    end
end

function UISpineBase:Close()
    if self.is_open then
        self.is_open = false
        self:OnClose()
        self.model:hidemodel()
    end
end

function UISpineBase:Destroy()
    if self.model then
        self.model:release()
        self.model = nil
    end
    self:OnDestroy()

    self.gameItemModel = nil
end

function UISpineBase:Release()
    self.assetName = ""
    self.is_open = false
    self.load_end = false
    if self.model then
        self.model:release()
        self.model = nil
    end
end

function UISpineBase:OnOpen()

end

function UISpineBase:OnClose()

end

function UISpineBase:OnDestroy()

end

return UISpineBase