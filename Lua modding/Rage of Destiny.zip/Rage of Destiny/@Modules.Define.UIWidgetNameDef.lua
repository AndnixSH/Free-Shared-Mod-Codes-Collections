
UIWidgetNameDef =
{
	UIRoot = "UIRoot",
	Root_normal = "Root_normal",
	Root_liveAllway = "Root_liveAllway",
	Root_top = "Root_top",
	Root_IGG = "Root_IGG",

	UIRootPanel = "UIRoot_NormalPanel",
	NormalPanel = "UINormal_NormalPanel",
	LiveAllwayPanel = "UILiveAllway_NormalPanel",
	TopPanel = "UITop_NormalPanel",
	IGGPanel = "UIRoot_IGGPanel",
	
	--common
	MsgTipsView = "MsgTipsView",
	ContentTipsView	= "ContentTipsView",
	ContentPageTipsView = "ContentPageTipsView",
	LabelTipsView = "LabelTipsView",
	GetItemView = "GetItemView",
	ItemDropView = "ItemDropView",
	FullScreenView = "FullScreenView",
	CostConfirmView = "CostConfirmView",
	ItemTipsView = "ItemTipsView",
	ItemEquipTipsView = "ItemEquipTipsView",
	ItemLableView = "ItemLableView",
	HeroTipsView = "HeroTipsView",
	FastshopView="FastshopView",
	ConfirmTipsView = "ConfirmTipsView",
	NewConfirmView = "NewConfirmView",
	UniWebView = "UniWebView",
	ItemQuickUseView = "ItemQuickUseView",
	BlockView = "BlockView",

	--cheat
	CheatView = "CheatView",
	CheatCameraAdjustView = "CheatCameraAdjustView",
	CheatGMBtnView = "CheatGMBtnView",
	
	--loading
	LoadingView = "LoadingView",
	LoadingCommonView = "LoadingCommonView",
	NetworkDelayView = "NetworkDelayView",
	ReconnectView = "ReconnectView",
	BlackLoadingView = "BlackLoadingView",
	
	--login
	LoginView = "LoginView",
	AnnouncementView = "AnnouncementView",
	LoginNoticeView = "LoginNoticeView",
	MaintenanceView = "MaintenanceView",

	--Main
	MainView = "MainView",
	CampaignView = "CampaignView",
	
	--battle
	BattleView = "BattleView",
	ArenaBattleView = "ArenaBattleView",
	BattleRecordView = "BattleRecordView",
	BattleSelectView = "BattleSelectView",
	BattleNetSelectView = "BattleNetSelectView",
	BattleSettlementView = "BattleSettlementView",
	BattleSettlement2View = "BattleSettlement2View",
	BattleRelationView = "BattleRelationView",
	BattleWordView = "BattleWordView",
	BattleReadyView = "BattleReadyView",
	ArenaBattleSelectView="ArenaBattleSelectView",
	ArenaBattleSettlementView="ArenaBattleSettlementView",
	ProArenaBattleSelectView="ProArenaBattleSelectView",
	ProArenaBattleSettlementView="ProArenaBattleSettlementView",
	ProArenaBattleView="ProArenaBattleView",
	BattleStopView = "BattleStopView",
	BattleHeroInfoView = "BattleHeroInfoView",
	BattleGuildBossView = "BattleGuildBossView",
	BattleGuildChaosView = "BattleGuildChaosView",
	BattleTeamChangeView = "BattleTeamChangeView",

	--Campaign
	BossInfoView = "BossInfoView",
	BoxRewardView = "BoxRewardView",
	FastRewardView = "FastRewardView",
	CampaignProgressView = "CampaignProgressView",
	WinFormationView = "WinFormationView",
	BattleRecordListView = "BattleRecordListView",

	--hero
	HeroRootPanel = "HeroRootPanel",
	HeroRootView = "HeroRootView",
	HeroListView = "HeroListView",
	HeroView = "HeroView",
	HeroAttrView = "HeroAttrView",
	SkillTipsView = "SkillTipsView",
	HeroUpgradeView = "HeroUpgradeView",
	UpgradeConfirmView = "UpgradeConfirmView",
	AutoUpgradeView = "AutoUpgradeView",
	ExclusiveUnlockView = "ExclusiveUnlockView",
	HeroNewView = "HeroNewView",
	HeroBookListView="HeroBookListView",
	HeroStoryView="HeroStoryView",

	--fountain
	FountainView = "FountainView",
	RetireConfirmView = "RetireConfirmView",

	--bag
	BagRootView = "BagRootView",
	BagItemsellView = "BagItemsellView",
	BagItemConfirmView = "BagItemConfirmView",
	BagItemChoosingConfirmView = "BagItemChoosingConfirmView",
	BagChoiceOneChestView = "BagChoiceOneChestView",
	ItemBoxTipsView = "ItemBoxTipsView",

	-- tower
	TowerEntranceView = "TowerEntranceView",
	TowerChallengeView = "TowerChallengeView",

	--equip
	EquipmentWearView = "EquipmentWearView",
	EquipmentTipsView = "EquipmentTipsView",
	EquipmentEnhanceView = "EquipmentEnhanceView",
	EquipmentStrengthenView = "EquipmentStrengthenView",
	StrengthenSuccessView= "StrengthenSuccessView",
	EquipmentResetView = "EquipmentResetView",
	EquipmentHintsView = "EquipmentHintsView",
	ExclusiveTipsView = "ExclusiveTipsView",
	ExclusiveStrengthenView= "ExclusiveStrengthenView",
	ExclusiveSuccessView = "ExclusiveSuccessView",
	ArtifactInfoView = "ArtifactInfoView",
	ArtifactTipsView = "ArtifactTipsView",
	ArtifactStrengthenView = "ArtifactStrengthenView",
	ArtifactSuccessView = "ArtifactSuccessView",
	ArtifactWearView = "ArtifactWearView",

	--player
	HomePageView = "HomePageView",
	PlayerInfoView = "PlayerInfoView",
    CustomizeView = "CustomizeView",
	SexView = "SexView",
	ChangeNameView="ChangeNameView",
	SignatureView="SignatureView",
	LineUpView="LineUpView",
	OtherPlayerInfolView="OtherPlayerInfolView",
	RedeemCodeView="RedeemCodeView",
	AccountUpgradeView="AccountUpgradeView",
	
	--hexmap
	HexMapView = "HexMapView",
	HexHeroView = "HexHeroView",
	HexStrangeAltarView = "HexStrangeAltarView",
	HeroHireView = "HeroHireView",
	EnemyInfoView = "EnemyInfoView",
	HexStoreView = "HexStoreView",
	HexMapFlyIconTitleView = "HexMapFlyIconTitleView",
	HexNPCDialogueView="HexNPCDialogueView",
	HexNPCLogView="HexNPCLogView",
	RuneChooseView="RuneChooseView",
	RuneListView="RuneListView",
	RuneListChooseView="RuneListChooseView",
	DragonBloodView="DragonBloodView",
	HexBuildView = "HexBuildView",
	EnemyBuffView = "EnemyBuffView",
	HexPortalView = "HexPortalView",
	MazeStorySuccessView = "MazeStorySuccessView",

	--maze
	MazeView = "MazeView",
	MazeHeroSelectView = "MazeHeroSelectView",
	MazeLevelView = "MazeLevelView",
	MazeHeroSelectNewView = "MazeHeroSelectNewView",
	MazeEnemyInfoView = "MazeEnemyInfoView",

	--Crystal
	CrystalView = "CrystalView",
	CrystalSelectView = "CrystalSelectView",
	CrystalRemoveHeroView = "CrystalRemoveHeroView",
	CrystalUpgradeView = "CrystalUpgradeView",
	CrystalUpgradeConfirmView = "CrystalUpgradeConfirmView",
	CrystalAddHeroView = "CrystalAddHeroView",
	CrystalLevelView = "CrystalLevelView",
	RefreshWhiteView = "RefreshWhiteView",
	CardPortalSkipView = "CardPortalSkipView",

	--TempleView
	TempleView = "TempleView",
	AutoAscendView = "AutoAscendView",
	SoulUnfuseConfirmView = "SoulUnfuseConfirmView",
	TempleConfirmView = "TempleConfirmView",
	TempleSuccessView = "TempleSuccessView",

	--CardPord
	CardPortalView = "CardPortalView",
	CardPortalSwitchView = "CardPortalSwitchView",
	CardPortalTipsView = "CardPortalTipsView",
	CardPortalWishView = "CardPortalWishView",
	RaceCardView = "RaceCardView",
	CardStarView="CardStarView",
	CardStarChooseView="CardStarChooseView",
	CardStarSetView="CardStarSetView",
	CardStarTipsView="CardStarTipsView",

	--Mail
	MailView="MailView",
	MailDetailView="MailDetailView",

	--Store
	StoreView="StoreView",
	StoreHintsView="StoreHintsView",
	StoreGoodsHeroHintsView="StoreGoodsHeroHintsView",

	--StoryLine
	StoryLineView = "StoryLineView",
	StoryLineRootView="StoryLineRootView",
	StoreLineHintsView="StoreLineHintsView",
	StoryLineMenuView="StoryLineMenuView",
	StoreLineConditionView="StoreLineConditionView",
	StoryLineSuccessView="StoryLineSuccessView",
	
	--world
	WorldMapRootView="WorldMapRootView",
    ChapterDecView="ChapterDecView",

	--task--
	MainTaskView = "MainTaskView",
	TaskStageRewardView = "TaskStageRewardView",

	--npc
	NPCDialogueView="NPCDialogueView",
	NPCLogView="NPCLogView",

	--territory
	TerritoryView="TerritoryView",
	FieldView="FieldView",

	--arena
	ArenaEntranceView="ArenaEntranceView",
	ArenaView="ArenaView",
	ArenaRewardView="ArenaRewardView",
	ArenaRecordView="ArenaRecordView",
	ArenaChallengeView="ArenaChallengeView",
	ProArenaView="ProArenaView",
	ProArenaChallengeView="ProArenaChallengeView",
	ProArenaRecordView="ProArenaRecordView",
	ProArenaDefendTeamView="ProArenaDefendTeamView",
	ProArenaTeamChangeView="ProArenaTeamChangeView",
	ProArenaBattleRecordView="ProArenaBattleRecordView",
	--friend
	FriendlListView = "FriendlListView",
	FriendRootView = "FriendRootView",
	FriendRootPanel = "FriendRootPanel",
	AddfriendView = "AddfriendView",
	ApplyfriendView = "ApplyfriendView",
	BlacklistView = "BlacklistView",

	--newbie
	NewbieDialogView = "NewbieDialogView",
	NewbieWeakGuildView = "NewbieWeakGuildView",
	NewbieFingerView = "NewbieFingerView",
	NewbieSignalView = "NewbieSignalView",
	NewbieNpcDialogueView = "NewbieNpcDialogueView",
	NewbieCertificateView = "NewbieCertificateView",
	NewbieNormalNpcDialogView = "NewbieNormalNpcDialogView",
	NewbieSpecialWeakView = "NewbieSpecialWeakView",
	NewbieDramaView = "NewbieDramaView",
	NewMaskView = "NewMaskView",

	--chat
	ChatRootView="ChatRootView",
	ChatView="ChatView",
	PindaoRootView="PindaoRootView",
	ReportView = "ReportView",

	--Relation
	RelationView="RelationView",
	MyAidView="MyAidView",
	RelationMenuRootView="RelationMenuRootView",
	RelationMenuView="RelationMenuView",
	RelationHeroView="RelationHeroView",
	RelationforeverView="RelationforeverView",

	--Tree
	RelationTreeView = "RelationTreeView",
	WaterReceiveView = "WaterReceiveView",

	--Guild
	GuildRootPanel = "GuildRootPanel",
	GuildRootView = "GuildRootView",
	ApplyGuildView = "ApplyGuildView",
	GuildCreateView = "GuildCreateView",
	GuildApplyView = "GuildApplyView",
	GuildEditorView = "GuildEditorView",
	GuildHallView = "GuildHallView",
	GuildInformationView = "GuildInformationView",
	GuildLogoView = "GuildLogoView",
	GuildNameView = "GuildNameView",
	GuildNoticeView = "GuildNoticeView",
	GuildRecordView = "GuildRecordView",
	GuildSetView = "GuildSetView",
	GuildEntranceView = "GuildEntranceView",
	GuildLableView = "GuildLableView",
	GuildlTipsView = "GuildlTipsView",

	GuildBossChallengeRewardView = "GuildBossChallengeRewardView",
	GuildBossRankView = "GuildBossRankView",
	GuildBossResultView = "GuildBossResultView",
	GuildBossRewardView = "GuildBossRewardView",
	GuildBossView = "GuildBossView",
	GuildBossBattleSettlementView = "GuildBossBattleSettlementView",

	GuildChaosNextView = "GuildChaosNextView",
	GuildChaosRecordView = "GuildChaosRecordView",
	GuildChaosStoryView = "GuildChaosStoryView",
	GuildChaosView = "GuildChaosView",
	GuildChaosBattleSettlementView = "GuildChaosBattleSettlementView",
	GuildChaosTopView = "GuildChaosTopView",
	GuildChaosRankView = "GuildChaosRankView",
	GuildChaosBehindView = "GuildChaosBehindView",

	HeroTeamListView = "HeroTeamListView",
	BattleTeamView = "BattleTeamView",
	FormationChangeNameView = "FormationChangeNameView",
	BattleFormationMenuView = "BattleFormationMenuView",

	--SupplyDepot
	SupplyDepotDispatchView = "SupplyDepotDispatchView",
	SupplyDepotLevelUpView = "SupplyDepotLevelUpView",
	SupplyDepotLevelView = "SupplyDepotLevelView",
	SupplyDepotShipView = "SupplyDepotShipView",
	SupplyDepotQuickDispatchView = "SupplyDepotQuickDispatchView",
	SupplyDepotView = "SupplyDepotView",

	--雇佣兵
	MercRootViewPanel = "MercRootViewPanel",
	MercRootView = "MercRootView",
	MercApplyView = "MercApplyView",
	MercSendInoView = "MercSendInoView",
	MercApplyListView = "MercApplyListView",

	--rank
	RankListView = "RankListView",
	RankListInfoView = "RankListInfoView",
	RankListTipsView = "RankListTipsView",
	TowerRankView = "TowerRankView",

	--setting
	SettingMenuView = "SettingMenuView",
	ChooseView = "ChooseView",
	SecondChooseView = "SecondChooseView",
	ServiceView = "ServiceView",
	SystemsettingView = "SystemsettingView",

	--Mall
	MallRootView = "MallRootView",
	MallNormalView = "MallNormalView",
	MallLimitView = "MallLimitView",
	MallMonthCardView = "MallMonthCardView",
	MallConfirmView = "MallConfirmView",
	MallConfirm2View = "MallConfirm2View",
	MallConfirm3View = "MallConfirm3View",
	MallConfirm4View = "MallConfirm4View",
	MallFirstChargeView = "MallFirstChargeView",
	MallPushView = "MallPushView",
	MallPassView = "MallPassView",
	MallPassPointView = "MallPassPointView",
	MallSelfView = "MallSelfView",
	MallDailySupplyView = "MallDailySupplyView",

	--Vip
	VipView = "VipView",

	--Marquee
	MarqueeView = "MarqueeView",

	--Activity
	ActivityRootView = "ActivityRootView",
	SevenDaysCheckinView = "SevenDaysCheckinView",
	FreshmanTrainView = "FreshmanTrainView",
	HeroGatheringView = "HeroGatheringView" ,
	StageClearChargeView = "StageClearChargeView",
	HatharalComingView = "HatharalComingView",
	HatharalComingMainView = "HatharalComingMainView",
	ShareChargeView = "ShareChargeView",
	HeroComingView = "HeroComingView",
	HeroComingMainView = "HeroComingMainView",
	ActivityOverView = "ActivityOverView",

	--位面幻境
	RealmRootView = "RealmRootView",
	RealmView = "RealmView",

	--轮循活动
	CycleSevendaysCheckinView = "CycleSevendaysCheckinView",
	CycleSevenLoginTypeTwoView = "CycleSevenLoginTypeTwoView",
	EventsNineBoxView = "EventsNineBoxView",
	NineBoxtaskView = "NineBoxtaskView",

	--命运总动员
	MobilizeView = "MobilizeView",
	MobilizeMallView = "MobilizeMallView",
	MobilizeTaskView = "MobilizeTaskView",
	MobilizeBattleSelectView = "MobilizeBattleSelectView",
}
