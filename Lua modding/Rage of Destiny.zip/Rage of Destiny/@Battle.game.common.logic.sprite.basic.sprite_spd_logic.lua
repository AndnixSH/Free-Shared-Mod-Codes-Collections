local logic = { timer = {} }

function logic:oncreate()
    self._spd_diff = nil
    self._atkspd_diff = nil
    self._spellspd_diff = nil
    self._movspd = self.owner.attr.mov
end

function logic.timer:f1(time, tick)

    local attr = self.owner.attr

    local spd_diff = attr.spd - tsmath.rate(attr.spd_d, 700)
    if spd_diff ~= self._spd_diff then
        self._spd_diff = spd_diff
        local _spd_rate = tsmath.clamp(1000 - self._spd_diff * CONST.SPD.A, CONST.SPD.B, CONST.SPD.C)
        self:sendmessage(eventdef.spd_change, _spd_rate)
        -- print("spd_change", _spd_rate)

        self._atkspd_diff = attr.atkspd_rate - attr.atkspd_rate_d
        self:_setatkspd(attr)
        self._spellspd_diff = attr.spellspd_rate - attr.spellspd_rate_d
        self:_setspellspd(attr)
        self:_setmov(attr)

    end

    local atkspd_diff = attr.atkspd_rate - attr.atkspd_rate_d
    if atkspd_diff ~= self._atkspd_diff then
        self._atkspd_diff = atkspd_diff
        self:_setatkspd(attr)
    end

    local spellspd_diff = attr.spellspd_rate - attr.spellspd_rate_d
    if spellspd_diff ~= self._spellspd_diff then
        self._spellspd_diff = spellspd_diff
        self:_setspellspd(attr)
    end

end

function logic:_setatkspd(attr)
    local _spd_rate = tsmath.clamp(1000 + self._atkspd_diff + self._spd_diff * CONST.SPD.A, CONST.SPD.B, CONST.SPD.C)
    self:sendmessage(eventdef.atkspd_change, _spd_rate)
    -- print("atkspd_change", _spd_rate)
end

function logic:_setspellspd(attr)
    local _spd_rate = tsmath.clamp(1000 + self._spellspd_diff + self._spd_diff * CONST.SPD.A, CONST.SPD.B, CONST.SPD.C)
    self:sendmessage(eventdef.spellspd_change, _spd_rate)
    -- print("spellspd_change", _spd_rate)
end

function logic:_setmov(attr)
    local _spd_rate = tsmath.clamp(1000 + self._spd_diff * CONST.SPD.A, CONST.SPD.B, CONST.SPD.C)
    attr.mov = tsmath.rate(self._movspd, _spd_rate)
    self:sendmessage(eventdef.movspd_change, _spd_rate)
    -- print("movspd_change", _spd_rate, attr.mov)
end

return logic