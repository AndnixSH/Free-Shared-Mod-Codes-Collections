local requirer = { _serach_path = {}, _kvp = {} }

-- 注册require搜索路径
function requirer:register_search_path(path)
    table.insert(self._serach_path, path)
end

-- 根据名字require
function requirer:require(path)
    local result = self._kvp[path]
    local error = nil
    if not result then
        for _, _path in ipairs(self._serach_path) do
            local status, ret = pcall(require, _path .. path)
            if status then
                result = ret
                self._kvp[path] = result
                break
            else
                error = error or ""
                error = error .. '\n' .. ret
            end
        end
    end
    if not result then
        global.debug.warning("找不到路径：", path, error)
    end
    return result
end

function requirer:dispose()
    -- print(global.debug.table(self._serach_path))
    self._serach_path = {}
    self._kvp = {}
end

return requirer