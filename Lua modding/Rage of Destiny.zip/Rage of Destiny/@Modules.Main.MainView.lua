local MainActivityPanel = require "Modules.Main.MainActivityPanel"
local MainSystemPanel = require "Modules.Main.MainSystemPanel"
local MainInfoPanel = require "Modules.Main.MainInfoPanel"
local MainChatPanel = require "Modules.Main.MainChatPanel"
local MainMarqueePanel = require "Modules.Main.MainMarqueePanel"
local MainLeftActivityPanel = require "Modules.Main.MainLeftActivityPanel"
local GameUIUtil=CS.GameUIUtil
local AudioManager = require "Common.Mgr.Audio.AudioManager"
local TouchRender = require "Core.Implement.UI.Class.TouchRender"
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"

local MainDef = require "Modules.Main.MainDef"

local Input = CS.UnityEngine.Input
local isEditor = CS.UnityEngine.Application.isEditor
local RuntimePlatform = CS.UnityEngine.RuntimePlatform
local KeyCode = CS.UnityEngine.KeyCode
local MainView = MainView or LuaWidgetClass()
function MainView:__init()
end

function MainView:OnLoad()
	GameUIUtil.LoadEmoPrefab("EMoji.CEmoji")
	
	AssetManager.LoadUIPrefab(self, "Main.MainView", self.LoadEnd)

	-- if LanguageManager.Instance:IsCurLanguageEnglish() then
	-- 	AssetManager.LoadUIAtlas(self, "UICommon.UICommon_English", self.LoadAtlasEnd)
	-- else
	-- 	self:Step(1)
	-- end
end

function MainView:LoadEnd(obj)
	self:SetGo(obj)

	self.mainActivityPanel = MainActivityPanel.New(self:GetChild(obj, "left"))
	self.mainLeftActivityPanel = MainLeftActivityPanel.New(self:GetChild(obj, "leftnew"))
	self.mainSystemPanel = MainSystemPanel.New(self:GetChild(obj, "right"))
	self.mainInfoPanel = MainInfoPanel.New(self:GetChild(obj, "top/head"))
	self.mainMarqueePanel = MainMarqueePanel.New(self:GetChild(obj, "TipsPanel"))

	self.clickEffectList = {}
	self.touchRender = TouchRender.New()
	self.touchRender:SetClickCallback(function (position)
		self:OnTouchClick(position)
	end)

	self:SetStep(0)
end

function MainView:LoadAtlasEnd()
	self:Step(1)
end

function MainView:InitDepth()
	UILayerTool.InitDepth()
	local autoZDepth = UILayerTool.GetNextZDepth()
	local autoCanveDepth = UILayerTool.GetNextDepth()
	GameObjTools.SetDepth(self.go, autoCanveDepth)
	GameObjTools.SetModelDepth(self.go, autoZDepth)
end

function MainView:UpdateDepth(depth)
	local autoZDepth = UILayerTool.GetNextZDepth()
	local autoCanveDepth = depth
	GameObjTools.SetDepth(self.go, depth)
	-- GameObjTools.SetModelDepth(self.go, autoZDepth)
	autoCanveDepth=autoCanveDepth+1
	self.mainActivityPanel:UpdateDepth(autoCanveDepth)
	self.mainSystemPanel:UpdateDepth(autoCanveDepth)
	self.mainLeftActivityPanel:UpdateDepth(autoCanveDepth)
end


function MainView:OnOpen()
	self:AutoRegister()

	self:InitDepth()
	self:UpdateInfo()
	
	self.mainActivityPanel:Open()
	self.mainLeftActivityPanel:Open()
	self.mainSystemPanel:Open()
	self.mainInfoPanel:Open()
	self.mainMarqueePanel:Open()

	self.touchRender:Start()

	self:OpenGMView()

	--商城推送礼包
    local MallProxy = require "Modules.Mall.MallProxy"
    local MallDef = require "Modules.Mall.MallDef"
    MallProxy.Instance:ShowPushViewFirst() --首次登录
    MallProxy.Instance:CheckShowPushView(MallDef.PushConType.Mainline) --指定时机
end
function MainView:OnClose()
	self:AutoUnRegister()

	self.mainActivityPanel:Close()
	self.mainLeftActivityPanel:Close()
	self.mainSystemPanel:Close()
	self.mainInfoPanel:Close()

	self.touchRender:Stop()
    for _,effectitem in pairs(self.clickEffectList) do
        effectitem:Close()
	end	
	self.mainMarqueePanel:Close()
end

function MainView:OnDestroy()
	self:AutoUnRegister()
	
	self.mainActivityPanel:Destroy()
	self.mainLeftActivityPanel:Destroy()
	self.mainSystemPanel:Destroy()
	self.mainInfoPanel:Destroy()

	self.touchRender:Stop()
    for _,effectitem in pairs(self.clickEffectList) do
        effectitem:Destroy()
    end
	self.clickEffectList = {}
	self.mainMarqueePanel:Destroy()
end

function MainView:OpenGMView()
	if SystemConfig.is_gm then
		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.CheatGMBtnView)
		if view then
			view.gmTab = 1
			view:OpenView()
		end
	end
end

function MainView:ShowOpenTween()	
	self.mainActivityPanel:StartOpenTween()
	self.mainLeftActivityPanel:StartOpenTween()
	self.mainSystemPanel:StartOpenTween()
	self.mainInfoPanel:StartOpenTween()
end

function MainView:UpdateInfo()
	local TerritoryProxy = require "Modules.Territory.TerritoryProxy"
	if TerritoryProxy.Instance:IsTerritoryOpen() then
		--self.stopPlayMusic = false
	else
		AudioManager.PlayBGM("main_bg")
	end
	
end

function MainView:GetClickEffect()
    for _,effectitem in pairs(self.clickEffectList) do
        if not effectitem:IsOpen() then
            return effectitem
        end    
    end
    local effect = UIEffectItem.New("UI_common_click" ,self.go)
    table.insert(self.clickEffectList, effect)
    return effect
end

function MainView:FlyItemScaleTween(scaleType, total_time)
	self.mainInfoPanel:FlyItemScaleTween(scaleType, total_time)
end

--onclick
function MainView:OnTouchClick(position)
	local SettingMenuProxy = require "Modules.SettingMenu.SettingMenuProxy"
	local SettingMenuDef = require "Modules.SettingMenu.SettingMenuDef"
	local state = SettingMenuProxy.Instance:GetSystemState(SettingMenuDef.Systerm_Option_Key[SettingMenuDef.Systerm_Option_Type.ClickEffect])
	if state == 1 then
		local effectitem = self:GetClickEffect()
		effectitem:SetLocalPosition(position.x, position.y, 0)
		effectitem:SetOrderLayer(9999)
		effectitem:Play()
	end
end

function MainView.EvtNotify.Main.data:ReShow()
	AudioManager.PlayBGM("main_bg")
end

function MainView.EvtNotify.Activity.data:UpdateSevenLogin()

	self.mainActivityPanel:Open()
end

function MainView.EvtNotify.RoleInfo.data:RoleInfo_Update()

	self.mainInfoPanel:UpdateLevelAndExp()
end
function MainView.EvtNotify.RoleInfo.data:NickName_Update()

	self.mainInfoPanel:UpdateNickName()
	local RoleInfoDef =require "Modules.RoleInfo.RoleInfoDef"
	GameLogicTools.ShowMsgTips(self:GetWord(RoleInfoDef.CommonDef.NameModifySuccess))
    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ChangeNameView)
end
--notify
function MainView.EvtNotify.RoleInfo.data:Currency_Change(data)
    self.mainInfoPanel:ShowCurrency()
end

function MainView.EvtNotify.RoleInfo.data:PhotoFrame_Update()
	local photoframeid=RoleInfoModel.frameicon
	self.mainInfoPanel:UpdatePhotoFrame(photoframeid)
end

function MainView.EvtNotify.RoleInfo.data:Photo_Update()
	local data={}
	data.headicon=RoleInfoModel.headicon
	self.mainInfoPanel:UpdatePhoto(data)
end

function MainView.EvtNotify.Hero.data:UpdateHero(data, args)
    self.mainInfoPanel:UpdateInfo()
end

function MainView.EvtNotify.Bag.data:Open_Bag(data, args)
	self.mainInfoPanel:UpdateInfo()
end

--更新红点
function MainView.EvtNotify.Main.data:UpdateRedDot(data, args)
    self:ShowRedDot(args.type, args.rednum)
end

function MainView.EvtNotify.Mall.data:Update_First_Charge(data,state)
	self.mainLeftActivityPanel:UpdateInfo()
end

function MainView.EvtNotify.Mall.data:UpdateMainLeftActivity(data)
	self.mainLeftActivityPanel:UpdateInfo()
end

function MainView.EvtNotify.Activity.data:ActivityEnd(data,args)
	local index = args.index or 0
	self.mainActivityPanel:UpdateBtn(index)
end

function MainView.EvtNotify.CycleActivity.data:CycleActivityEnd(data,args)
	local index = args.index or 0
	self.mainActivityPanel:UpdateBtn(index)
end

function MainView:ShowRedDot(type, rednum)
	self.mainSystemPanel:ShowRedDot(type, rednum)

end

function MainView:SetChatObjDepth()
end

function MainView:GetMarqueePanelRect()
	local x, y = self.mainMarqueePanel:GetCanvasRect()
	return x, y
end

function MainView.EvtNotify.Marquee.data:UpdateMarqueeInfo(data, args)
	self.mainMarqueePanel:UpdateMarqueeInfo()
end

function MainView.EvtNotify.Marquee.data:UpdateMarqueeType(data, args)
	self.mainMarqueePanel:UpdateMarqueeType()
end

function MainView.EvtNotify.Marquee.data:CloseMarquee(data, args)
	self.mainMarqueePanel:CloseMarquee()
end

function MainView.EvtNotify.Mall.data:UpdatePushIcon(data)
	self.mainLeftActivityPanel:UpdateInfo()
end

function MainView.EvtNotify.Mobilize.data:Update_Mobilize_Btn(data,show)
	self.mainActivityPanel:Update_Mobilize_Btn(show)
end
-- function MainView:FrameUpdate()
--     self:DoUIFit(self.rightobj,self.rightobjInitPos)
-- end

return MainView