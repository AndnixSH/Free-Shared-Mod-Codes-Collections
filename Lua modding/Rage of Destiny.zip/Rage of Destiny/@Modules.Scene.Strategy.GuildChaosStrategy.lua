local AudioManager = require "Common.Mgr.Audio.AudioManager"
local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"
local BattleProxy = require "Modules.Battle.BattleProxy"
local BasicBattleStrategy = require "Modules.Scene.Strategy.BasicBattleStrategy"
local GuildChaosStrategy = GuildChaosStrategy or BaseClass(BasicBattleStrategy)
local GuildProxy = require "Modules.Guild.GuildProxy"
local GuildDef = require "Modules.Guild.GuildDef"

local bossId
local config
local oldMaxDamage --进入场景前的最高伤害
local oldRank --进入场景前的段位
local oldHonourRank --进入场景前的全服排名

local isNewRecord --是否新记录(打出更高的伤害)
local nowDamage --本次伤害

--加载场景
function GuildChaosStrategy:OnLoad()
    -- print("GuildChaosStrategy:OnLoad")

    local isPlayLastReport = GuildProxy.Instance:GetIsPlayLastReport()

    if isPlayLastReport then
        bossId = GuildProxy.Instance:GetChaosLastBossId()
    else
        bossId = GuildProxy.Instance:GetChaosNowBossId()
    end

    config = GuildProxy.Instance:GetChaosBossConfigById(bossId)
    oldMaxDamage = GuildProxy.Instance:GetChaosMaxDamage()
    oldRank = GuildProxy.Instance:GetChaosNowRank(bossId)
    oldHonourRank = GuildProxy.Instance:GetChaosHonourRankInfo()
    self:LoadScene(config.scence)
end

-- 带入战斗信息
function GuildChaosStrategy:OnStartEntry()
    -- print("GuildChaosStrategy:OnStartEntry")

    GuildProxy.Instance:SetChaosRequireSettle(false)

    local battleargs = self:GetBattleArg()
    local config_key = self:OnGetConfigKey()

    local isPlayLastReport = GuildProxy.Instance:GetIsPlayLastReport()
    local otherRoomId = GuildProxy.Instance:GetChaosOtherRoomId()
    local roomid

    if otherRoomId then
        roomid = otherRoomId
    elseif isPlayLastReport then
        roomid = GuildProxy.Instance:GetChaosLastRoomId()
    else
        roomid = GuildProxy.Instance:GetChaosNowRoomId()
    end
    -- print("roomid:", roomid)

    local gameprop = {
        rawplayers = battleargs.playerlist,
        config_key = config_key,
        activity_info = { roomid = roomid },
        extra = battleargs.extra
    }

    self:StartGame(gameprop, battleargs.seed)
    
    local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleStopView)
    if view then
        view.data = {activityid = ACTIVITYID.GUILD_CHAOS}
        view:OpenView()
    end
end

function GuildChaosStrategy:OnGetConfigKey()
    return BattleProxy.Instance:GetConfigKey(config.scence, config.enemy)
end

function GuildChaosStrategy:OnStartGame()
    AudioManager.PlayBGM("battle_story_bg")
end

function GuildChaosStrategy:OnSettleGame(wincamp, rewards, buffer_str)
    self:SettleGameDelayTime(function()
        -- print(wincamp)
        -- print(table.dump(rewards))
        -- print(buffer_str)

        local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildChaosBattleSettlementView)
        if view then
            view.wincamp = 1 --固定显示玩家胜利
            view.isNewRecord = isNewRecord
            view.nowDamage = nowDamage
            view.oldRank = oldRank
            view.oldHonourRank = oldHonourRank
            view:OpenView()
        end

        -- UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 2, wincamp, self.strategycfg.activityid)
    end)
end

function GuildChaosStrategy:OnDestroyGame()
    -- print("GuildChaosStrategy:OnDestroyGame")

    self:UnloadScene()

    local SceneManager = require "Modules.Scene.SceneManager"
    local SceneDef = require "Modules.Scene.SceneDef"
    local openviews = {UIWidgetNameDef.GuildEntranceView, UIWidgetNameDef.GuildChaosView}

    local reportOpenViews = GuildProxy.Instance:GetReportOpenViews()
    if reportOpenViews then
        for i,v in ipairs(reportOpenViews) do
            table.insert(openviews, v)
        end
        GuildProxy.Instance:ClearReportOpenViews()
    end

    SceneManager.Instance:EnterScene(SceneDef.SceneType.Main, openviews)

    GuildProxy.Instance:SetIsPlayLastReport(false)

    GuildProxy.Instance:ClearChaosOtherRoomId()

    GuildProxy.Instance:SetChaosRequireSettle(false)
end

function GuildChaosStrategy:OnRestartGame()
    self:Destroy()
end

function GuildChaosStrategy:OnGamePrepared()
    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.BattleView)
    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.BattleGuildChaosView)
end

-- 请求结算
function GuildChaosStrategy:OnRequireSettle(result, gameprop, total_time)
    GuildProxy.Instance:SetChaosRequireSettle(true)

    local damage = 0
    local BattleProxy = require "Modules.Battle.BattleProxy"
    local spritelist = BattleProxy.Instance:GetSpriteList(CAMP.BLUE)
    for _, spriteid in ipairs(spritelist) do
        local sprite = BattleProxy.Instance:GetSprite(spriteid)
        if sprite then
            damage = sprite.record.bharm
            -- damage = sprite.attr.hp_max - sprite.attr.hp
            break
        end
    end

    -- damage = 123456789123 --测试

    if damage > oldMaxDamage then
        isNewRecord = true
        GuildProxy.Instance:SetChaosMaxDamage(damage)
    else
        isNewRecord = false
    end

    damage = math.max(damage, 1) --需求:只要结算,伤害至少为1,使玩家可以有排名
    nowDamage = damage
    print("GuildChaosStrategy:OnRequireSettle", damage, bossId)

    local settlestr = self:GetSettleStr()
    local bufferstr = string.pack(">I8I4s2I4", damage, bossId, settlestr, total_time)
    self:RequireNetworkSettle(self.strategycfg.activityid, result, bufferstr)
end

function GuildChaosStrategy:OnReportSettleGame(wincamp)
    print("GuildChaosStrategy:OnReportSettleGame")
    
    if GuildProxy.Instance:GetChaosClickRecord() then
        GuildProxy.Instance:SetChaosClickRecord(false)
        self:OnSettleGame()
    else
        BattleProxy.Instance:EscGame()
    end
end

function GuildChaosStrategy:OnGetEnemeyId()
    return config.enemy
end

return GuildChaosStrategy