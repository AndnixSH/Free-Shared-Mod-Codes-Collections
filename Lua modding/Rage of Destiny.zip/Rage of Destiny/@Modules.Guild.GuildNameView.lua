local GuildProxy = require "Modules.Guild.GuildProxy"
local GuildDef = require "Modules.Guild.GuildDef"
local WordFilter=require "Common.Util.WordFilter"

local GuildNameView = GuildNameView or LuaWidgetClass()

function GuildNameView:__init()
	self.tweenOption = {bScale = true}
end

function GuildNameView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Guild.GuildNameView", self.LoadEnd)
end

function GuildNameView:LoadEnd(obj)
	self:SetGo(obj)
	self.rootObj = self:GetChild(self.go, "root")
	self.closeBtn = self:GetChildComponent(self.rootObj, "content/close", "CButton")
	self.closeBtn:AddClick(function()
		self:CloseView()
	end)

	self.nameInput = self:GetChildComponent(self.rootObj, "content/notice/CInput_Notice", "CTextInput")
	self.nameInput:AddChange(function(value)
		local lenth, content = GameLogicTools.CheckContentLength(value, GuildDef.Parama.Guild_Name_Max_Char)
		self.nameInput.text = content
	end)

	self.cancleBtn = self:GetChildComponent(self.rootObj, "content/cancel", "CButton")
	self.confirmBtn = self:GetChildComponent(self.rootObj, "content/confirm", "CButton")

	self.cancleBtn:AddClick(function()
		self:CloseView()
	end)

	self.confirmBtn:AddClick(function()
		self:CheckInput()
	end)

	self.countLab = self:GetChildComponent(self.rootObj, "GoldBrick/label", "CLabel")
	
	self.originPos = self.go.transform.localPosition
	self.offsetHeigh = -13
	self.highestY = self.originPos.y
	self.bResetPox = false

	self:SetStep(0)
end

function GuildNameView:CheckInput()
	if RoleInfoModel.diamond < GuildDef.Parama.Guild_Change_GuildName_Diamond then
		GameLogicTools.ShowConfirmById(2)
	else
		local checkNameResult = GuildProxy.Instance:CheckContentInput(self.nameInput.text, GuildDef.ContentInputType.GuildNameType)
		if checkNameResult == 0 then
			GuildProxy.Instance:Send70014(self.nameInput.text)
			self:CloseView()
		else
		end
	end
end

function GuildNameView:OnClose()
	self:EndFrame()
end

function GuildNameView:OnDestroy()
	self:EndFrame()
end

function GuildNameView:OnOpen()
	self.highestY = self.originPos.y
	self.bResetPox = false
	self:UpdateView()
	self:StartFrame()
end

function GuildNameView:UpdateView()
	self.nameInput.text = ""

	local needCount = GuildDef.Parama.Guild_Change_GuildName_Diamond
	local curCount = RoleInfoModel.diamond
	self.countLab.text = GuildDef.Parama.Guild_Change_GuildName_Diamond
	self.countLab.color = needCount > curCount and Color.red or Color.white
end

function GuildNameView:FrameUpdate()
    local isEditor = Application.isEditor
    if not isEditor then
        local curPosY = GameLogicTools.AdjustObjPosY(self.go, self.originPos, self.offsetHeigh, self.nameInput.isFocused, self.bResetPox)
    	if curPosY > self.highestY then
    		self.highestY = curPosY
    	end
    	self.bResetPox = (curPosY < self.highestY) and true or false    
    end
end

return GuildNameView