LuaLayout = LuaLayout or BaseClass()
LuaLayout.Instance = nil
local ModuleManager = require "Common.Mgr.UI.ModuleManager"
--LuaLayout = LuaLayout or BaseClass()
--LuaLayout = {}

function LuaLayout:__init()
    self.listinfo = {}
    LuaLayout.Instance = self
end

function LuaLayout:__delete()
end

LayoutShowType = {}
LayoutShowType.CoexistClose = 1 --并存 & close
LayoutShowType.CoexistDestroy = 2 --并存 & destroy
LayoutShowType.MonopolizeClose = 3 --独占 & close
LayoutShowType.MonopolizeDestroy = 4 --独占 & destroy

LayoutCloseType = {}
LayoutCloseType.Pop = 1
LayoutCloseType.Push = 2
LayoutCloseType.PopPush = 3

LayoutDestroyType = {}
LayoutDestroyType.Close = 1

function LuaLayout:RegisterWidget(widgetname, widgetPath, parentname, panelname, showType, bnotautoclose)
    if nil ~= self.listinfo[widgetname] then --Negative
        return false
    end
    self.listinfo[widgetname] = {}
    self.listinfo[widgetname].parentname = parentname
    self.listinfo[widgetname].panelname = panelname

    self.listinfo[widgetname].widgetPath = widgetPath
    self.listinfo[widgetname].widget = nil

    self.listinfo[widgetname].bnotautoclose = bnotautoclose

    self.listinfo[widgetname].bopen = false
     -- the state save in here
    self.listinfo[widgetname].showType = showType
    return true
end

function LuaLayout:RegisterWidgetByCfg(widgetname, cfg)
    self:RegisterWidget(widgetname, cfg.widgetpath, cfg.parentname, cfg.panelname, cfg.showType, cfg.bnotautoclose)
end

--get the widget by the widgetname
function LuaLayout:GetWidget(widgetname)
    if self.listinfo[widgetname] then
        self:CheckWidgetInit(widgetname)  

        return self.listinfo[widgetname].widget
    end
    return nil
end

--get the widgetname by the widget
function LuaLayout:GetWidgetName(widget)
    for widgetname, info in pairs(self.listinfo) do
        if info.widget == widget then
            return widgetname
        end
    end
    return nil
end

--get the LayoutInfo by the widget
function LuaLayout:GetLayoutInfo(widget)
    for widgetname, info in pairs(self.listinfo) do
        if info.widget == widget then
            return info
        end
    end
    return nil
end

--new function
function LuaLayout:GetWidgetInfo(widgetname)
    if nil ~= self.listinfo[widgetname] then
        return self.listinfo[widgetname]
    end
    return nil
end

function LuaLayout:OpenWidget(widgetname)
    if self.listinfo[widgetname] then
        self:CheckWidgetInit(widgetname)

        if not self.listinfo[widgetname].bopen then
            self.listinfo[widgetname].bopen = true
            self.listinfo[widgetname].widget:Open()
            if
                self.listinfo[widgetname].showType == LayoutShowType.MonopolizeClose or
                    self.listinfo[widgetname].showType == LayoutShowType.MonopolizeDestroy
             then
                for k, v in pairs(self.listinfo) do
                    if
                        (k ~= widgetname) and v.panelname == (self.listinfo[widgetname].panelname) and
                            (v.showType == LayoutShowType.MonopolizeClose or
                                v.showType ~= LayoutShowType.MonopolizeDestroy) and
                            v.bopen
                     then
                        -- v.widget:close()
                        self:CloseWidget(k)
                    end
                end
            end
            -- if isUpdatePanel then
            self:UpdatePanel(widgetname)
        -- end
            return true
        end
    else
        error(widgetname.. "is nil")    
    end
    return false
end

-- widgetname需要关闭wiget ， need_destroy是否需要destroy
function LuaLayout:CloseWidget(widgetname, need_destroy) --incomplete
    if self.listinfo[widgetname] then
        self:CheckWidgetInit(widgetname)

        if self.listinfo[widgetname].bopen then
            self.listinfo[widgetname].bopen = false
            self.listinfo[widgetname].widget:Close()
            local viewcfg = ModuleManager.GetUIViewCfg(widgetname)
            if viewcfg and viewcfg.closetype then
                if viewcfg.closetype == LayoutCloseType.Pop then
                    UIOperateManager.Instance:PopOperate()
                end
            end

            if
                need_destroy or self.listinfo[widgetname].showType == LayoutShowType.MonopolizeDestroy or
                    self.listinfo[widgetname].showType == LayoutShowType.CoexistDestroy
             then
                self.listinfo[widgetname].widget:Destroy()
            end
            -- if isUpdatePanel then
            self:UpdatePanel(widgetname)
        -- end
        end
    end
end

function LuaLayout:DestroyWidget(widgetname)
    self:CheckWidgetInit(widgetname)

    if self.listinfo[widgetname] then
        if self.listinfo[widgetname].bopen then
            self.listinfo[widgetname].bopen = false
            -- self.listinfo[widgetname].widget:Close()
        end
        self.listinfo[widgetname].widget:Destroy()
        self.listinfo[widgetname].widget:DeleteMe()
        self.listinfo[widgetname].widget = nil
    end
end

function LuaLayout:CheckWidgetInit(widgetname)
    if self.listinfo[widgetname] and self.listinfo[widgetname].widget == nil then
        local class = require(self.listinfo[widgetname].widgetPath)
        self.listinfo[widgetname].widget = class.New()
    end 
    return true
end

--
function LuaLayout:OnOpenPanel(widget, panelname)
    local widget_name = self:GetWidgetName(widget)
    for widgetname, info in pairs(self.listinfo) do
        if (info.parentname == widget_name) and (info.panelname == panelname) then
            self:OpenWidget(widgetname)
        end
    end
end

function LuaLayout:OnClosePanel(widget, panelname)
    local parentname = self:GetWidgetName(widget)
    for widgetname, info in pairs(self.listinfo) do
        if (info.parentname == parentname) and (info.panelname == panelname) then
            self:CloseWidget(widgetname)
        end
    end
end

--Attach or Detach Panel
function LuaLayout:UpdatePanel(widgetname)
    local isUpdatePanel = false
    local panelwidget = nil
    local parentwidget = nil

    local widgetinfo = self:GetWidgetInfo(widgetname)
    if nil ~= widgetinfo.parentname then
        parentwidget = self:GetWidget(widgetinfo.parentname)
        if parentwidget then
            panelwidget = parentwidget:GetPanel(widgetinfo.panelname)
        end
        if panelwidget then
            isUpdatePanel = true
        end
    end

    if isUpdatePanel then
        for widget_name, info in pairs(self.listinfo) do
            if widgetinfo.panelname == info.panelname and info.bopen then
                panelwidget.isopen = true
                return
            end
        end
        panelwidget.isopen = false
    end
end

--是否独立view, 独立view要自己手动控制, 不参与批处理
function LuaLayout:IsIndependentView(info)
    if (info.parentname == UIWidgetNameDef.UIRoot or info.parentname == "" or info.parentname == UIWidgetNameDef.Root_liveAllway  ) then
        return true
    else
        return false
    end        
end

--logic
function LuaLayout:CloseAllWidget()
    --关闭播放动画
    LuaWidgetFactor.bTween = false
    for name, info in pairs(self.listinfo) do
        if info.bopen then
            if not self:IsIndependentView(info) then
                self:CloseWidget(name)
            end    
        end
    end

    LuaWidgetFactor.bTween = true
end

--判断是否打开了 没有返回键功能的 界面
function LuaLayout:InNotAutoView()
    for name, info in pairs(self.listinfo) do
        if info.bopen and info.bnotautoclose and name ~= UIWidgetNameDef.MainView and name ~= UIWidgetNameDef.FullScreenView then
            return true    
        end
    end    
end

function LuaLayout:IsMainPage(info)
    if info.widget then
        if info.widget.wigetName == UIWidgetNameDef.ItemDropView or info.widget.wigetName == UIWidgetNameDef.CampaignView or
            info.widget.wigetName == UIWidgetNameDef.BattleWordView or info.widget.wigetName == UIWidgetNameDef.CheatGMBtnView or
            info.widget.wigetName == UIWidgetNameDef.MainView or info.widget.wigetName == UIWidgetNameDef.TerritoryView or
            info.widget.wigetName == UIWidgetNameDef.FieldView or info.widget.wigetName == UIWidgetNameDef.FullScreenView 
            or info.widget.wigetName == UIWidgetNameDef.MsgTipsView then
            return true
        end
    end
    return false
end

function LuaLayout:IsWidgetChild(info)
    if (info.parentname == UIWidgetNameDef.UIRoot or info.parentname == "" or info.parentname == UIWidgetNameDef.Root_liveAllway or info.parentname == UIWidgetNameDef.Root_top
        or  info.parentname == UIWidgetNameDef.Root_normal or info.parentname == UIWidgetNameDef.Root_IGG) then
        return false
    else
        return true
    end    
end

function LuaLayout:IsFullScreenView(info)
    if info.widget then
        if  info.widget.wigetName == UIWidgetNameDef.FullScreenView then
            return true
        end
    end
    return false    
end

function LuaLayout:IsShowWebView(info)
    
    if info.widget then
        if  info.widget.wigetName == UIWidgetNameDef.UniWebView then
            return true
        end
    end
    return false   
end
function LuaLayout:SceneUIView(info)
    if info.widget then
        if  info.widget.wigetName == UIWidgetNameDef.HexMapView or  info.widget.wigetName == UIWidgetNameDef.NewbieSignalView
        or info.widget.wigetName == UIWidgetNameDef.HexMapFlyIconTitleView or info.widget.wigetName == UIWidgetNameDef.HexNPCDialogueView then
            return true
        end
    end
    return false
end

function LuaLayout:IsShowRooTIGG()
    local show = false
    local parenWidget = LuaLayout.Instance:GetWidget(UIWidgetNameDef.Root_IGG)
    if parenWidget and parenWidget.go then
        local trans = parenWidget.go.transform
        for i=1,trans.childCount do
            
            local obj = trans:GetChild(i-1)
            if obj and obj.gameObject.activeSelf then
                if obj.gameObject.name == UIWidgetNameDef.UniWebView then
                    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.UniWebView)
                else
                    obj.gameObject:SetActive(false)
                end
                show = true
            end
        end
    end
    return show
end

--关闭所有非主界面,非全屏界面的窗口
function LuaLayout:CloseAllPopupView()
    local show = self:IsShowRooTIGG()
    if not show then
        local bclose = false --是否关闭了界面
        for name, info in pairs(self.listinfo) do
            if info.bopen and not info.bnotautoclose then
                if (info.widget and info.widget.fullScreenOption == nil) then
                    if not self:IsIndependentView(info) and not self:IsMainPage(info) and not self:IsWidgetChild(info) and not self:IsFullScreenView(info) and not self:SceneUIView(info) then
                        self:CloseWidget(name)
                        bclose = true
                    end    
                end    
            end
        end
        return bclose
    else
        return true
    end
   
end

--返回主界面
function LuaLayout:OnlyMainView()
    for name, info in pairs(self.listinfo) do
        if not self:IsIndependentView(info) then
            if info.bopen and name ~= UIWidgetNameDef.MainView then
                self:CloseWidget(name)   
            end
        end
    end
end

function LuaLayout:DestroyAllWidget()
    local UINormalWidget = require "Core.Implement.UI.Widgets.UINormalWidget"
    local UITopWidget = require "Core.Implement.UI.Widgets.UITopWidget"
    local panelList = {}
    
    for name, info in pairs(self.listinfo) do
        if not self:IsIndependentView(info) then
            if info.widget then
                for panelName, var in pairs(info.widget.listpanel) do
                    panelList[panelName] = var
                end
                local viewcfg = ModuleManager.GetUIViewCfg(name)
                if viewcfg and viewcfg.destroytype and viewcfg.destroytype == LayoutDestroyType.Close then
                    self:CloseWidget(name)
                else
                    self:DestroyWidget(name)
                end
            end    
        end
    end

    for name, info in pairs(self.listinfo) do
        if panelList[info.panelname] then
            if viewcfg and viewcfg.destroytype and viewcfg.destroytype == LayoutDestroyType.Close then
                self:CloseWidget(name)
            else
                self:DestroyWidget(name)
            end
        end
    end
end

function LuaLayout:DisposeAllWidget()
    local panelList = {}

    for name, info in pairs(self.listinfo) do
        if not self:IsIndependentView(info) then
            if info.widget then
                for panelName, var in pairs(info.widget.listpanel) do
                    panelList[panelName] = var
                end
                self:DestroyWidget(name)
            end
        end
    end

    for name, info in pairs(self.listinfo) do
        if panelList[info.panelname] then
            self:DestroyWidget(name)
        end
    end
    --self.listinfo = nil
end

function LuaLayout:ReOpenAllWidget()
    local panelList = {}
    --断线重连，重新open 普通节点ui
    for name, info in pairs(self.listinfo) do
        if info.parentname == UIWidgetNameDef.Root_normal and info.panelname == UIWidgetNameDef.NormalPanel then
            if info.widget then
                for panelName, var in pairs(info.widget.listpanel) do
                    panelList[panelName] = var
                end
                local view = self:GetWidget(name)
                if view and view:IsOpen() then
                    view:OnOpen()
                end    
            end    
        end
    end

    for name, info in pairs(self.listinfo) do
        if panelList[info.panelname] then
            local view = self:GetWidget(name)
            if view and view:IsOpen() then
                view:OnOpen()
            end            
        end
    end    
end
