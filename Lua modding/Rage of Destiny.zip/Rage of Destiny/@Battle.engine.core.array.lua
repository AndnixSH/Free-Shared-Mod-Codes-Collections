local array = {}

function array.removeby(obj, rm_func, ...)
    if type(obj) ~= "table" or type(rm_func) ~= "function" then
        return
    end

    local length = 0
    length = #obj
    local index, r_index = 1, 1
    while index <= length do
        local v = obj[index]
        obj[index] = nil
        if not rm_func(v, ...) then
            obj[r_index] = v
            r_index = r_index + 1
        end

        index = index + 1
    end
end

function array.removeby_fast(obj, rm_func, rm_func_arg)
    
    local length = 0
    length = #obj
    local index, r_index = 1, 1
    while index <= length do
        local v = obj[index]
        obj[index] = nil
        if not rm_func(v, rm_func_arg) then
            obj[r_index] = v
            r_index = r_index + 1
        end

        index = index + 1
    end
end

function array.remove(obj, element)
    
    local length = 0
    length = #obj
    local index, r_index = 1, 1
    while index <= length do
        local v = obj[index]
        obj[index] = nil
        if element ~= v then
            obj[r_index] = v
            r_index = r_index + 1
        end

        index = index + 1
    end
end

function array.duplicate(obj)
    local tb_note = {} --使指向行为与原表一致
    local copy_func
    copy_func = function(obj)
        if type(obj) ~= "table" then
            return obj
        elseif tb_note[obj] then
            return tb_note[obj]
        end

        local dup = {}
        tb_note[obj] = dup
        for k, v in pairs(obj) do
            dup[copy_func(k)] = copy_func(v)
        end
        setmetatable(dup, getmetatable(obj))
        return dup
    end

    return copy_func(obj)
end

function array.tostring(obj)
    local tb_note = {} --防止相同表转换多次
    local function serialize(value)
        if tb_note[value] then
            return tb_note[value]
        elseif type(value) == "number" then
            return string.format("%d", value) --%a
        elseif type(value) == "string" then
            return string.format("%q", value) --5.3.3版本后可以使用%q转化number,nil,boolean
        elseif type(value) == "table" then
            local str = "{"
            local index_tb = array.getsortedindexlist(value)
            for _, v in ipairs(index_tb) do
                str = str .. "[" .. serialize(v) .. "]=" .. serialize(value[v]) .. ","
            end
            local mt = getmetatable(value)
            if mt then str = str .. "[\"metatable\"]=" .. serialize(mt) .. "," end
            str = str .. "}"

            tb_note[value] = str
            return str
        else
            return tostring(value)
        end
    end

    return serialize(obj)
end

function array.print(obj)
    print(array.tostring(obj))
end

local type_value = {["number"] = 1, ["string"] = 2, ["userdata"] = 3, ["function"] = 4, ["table"] = 5 }
function array.getsortedindexlist(obj)
    local index_tb = {}
    for k in pairs(obj) do
        table.insert(index_tb, k)
    end

    local sort_func = function(a, b)
        local type_a = type_value[type(a)]
        local type_b = type_value[type(b)]
        if type_a ~= type_b then
            return type_a < type_b
        else
            if type_a == 1 or type_a == 2 then
                return a < b
            elseif type_a == 5 then
                return array.getlen(a) < array.getlen(b)
            else
                return false
            end
        end
    end

    table.sort(index_tb, function(a, b) return sort_func(a, b) end)
    return index_tb
end

function array.getlen(obj)
    local count = 0
    for k, v in pairs(obj) do
        count = count + 1
    end

    return count
end

function array.show(obj)
    for k, v in pairs(obj) do
        print(k, v)
    end
    local mt = getmetatable(obj)
    if mt then
        print("metatable", mt)
    end
end

function array.sort_iter(tableunsort, iterfunc)
    assert(iterfunc)
    local keylist = {}
    for k, _ in pairs(tableunsort) do
        table.insert(keylist, k)
    end
    table.sort(keylist)
    for _, v in ipairs(keylist) do
        iterfunc(v, tableunsort[v])
    end
end

return array