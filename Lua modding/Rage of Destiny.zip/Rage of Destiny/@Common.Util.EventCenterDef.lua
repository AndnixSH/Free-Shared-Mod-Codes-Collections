local EventCenterDef = {}

EventCenterDef.Id =
{
	SystemOpen = "SystemOpen", --系统开放
}

return EventCenterDef