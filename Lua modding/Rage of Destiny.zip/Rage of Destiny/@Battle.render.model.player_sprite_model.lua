local base_sprite_model = require "Battle.render.model.base_sprite_model"
local player_sprite_model = BaseClass(base_sprite_model)

local cMaterialPropertyBlock = CS.UnityEngine.MaterialPropertyBlock
local cPlayerSpriteModel = CS.LJY.NX.PlayerSpriteModel

function player_sprite_model:__init(anchor, model_name)
    self.cmodel = cPlayerSpriteModel(anchor.canchor, model_name)
end

function player_sprite_model:__delete()
end

-- 轮回
function player_sprite_model:rebirth()
    --print("player_sprite_model --> rebirth")
    if next(self._renderers) == nil then
        self:_get_model_renderer()
    end

    if not self._block then
        self._block = cMaterialPropertyBlock()
    end

    local red = 255 / 255
    local green = 221 / 255
    local blue = 95 / 255

    local color = Color.New(red, green, blue)

    for _, render in ipairs(self._renderers) do
        self._block:Clear()
        render:GetPropertyBlock(self._block)
        self._block:SetColor("_GlobalColor", color)
        self._block:SetFloat("_AddiFxThreshold", 1)
        render:SetPropertyBlock(self._block)
    end
end

function player_sprite_model:grace()
    --print("player_sprite_model --> grace")
    if next(self._renderers) == nil then
        self:_get_model_renderer()
    end

    if not self._block then
        self._block = cMaterialPropertyBlock()
    end

    for _, render in ipairs(self._renderers) do
        self._block:Clear()
        render:GetPropertyBlock(self._block)
        self._block:SetFloat("_AddiFxThreshold", 1)
        render:SetPropertyBlock(self._block)
    end
end

function player_sprite_model:un_rebirth()
    --print("player_sprite_model --> un_rebirth")
    if next(self._renderers) == nil then
        self:_get_model_renderer()
    end

    if not self._block then
        self._block = cMaterialPropertyBlock()
    end

    for _, render in ipairs(self._renderers) do
        self._block:Clear()
        render:GetPropertyBlock(self._block)
        self._block:SetColor("_GlobalColor", Color.white)
        self._block:SetFloat("_AddiFxThreshold", 0)
        render:SetPropertyBlock(self._block)
    end
end

function player_sprite_model:un_grace()
    --print("player_sprite_model --> grace")
    if next(self._renderers) == nil then
        self:_get_model_renderer()
    end

    if not self._block then
        self._block = cMaterialPropertyBlock()
    end

    for _, render in ipairs(self._renderers) do
        self._block:Clear()
        render:GetPropertyBlock(self._block)
        self._block:SetFloat("_AddiFxThreshold", 0)
        render:SetPropertyBlock(self._block)
    end
end

return player_sprite_model