local bullet = {timer = {},sprite = {}}

-- rangeid, speed, duration, castid, target, targets
function bullet:oncreate()
    
    self.curtime = 0
    self._casted = self.prop.nodamage or false
    self.burn_range = self.prop.burn_range or false

    if self.prop.targets then
        self.targets = self.prop.targets
        self.target = self.targets[1]
    elseif self.prop.target then
        self.target = self.prop.target
        self.targets = { self.target }
    elseif self.prop.rangeid then
        local targets = self.owner.body.parent.caller.skill:range(self.prop.rangeid)
        if #targets > 0 then
            self.target = targets[1]
            self.targets = targets
        end
    else
        global.debug.warning("bullettrace请正确配置targets或者target或者rangeid")
    end
        
    if self.target then
        local target_mid =  tsmath.floor(self.target.body.top * 2 / 3) + self.target.body.height
        if target_mid ~= 0 then
            local ver = target_mid - self.owner.body.height

            local hor = tsvector.distance(self.target.body.position, self.owner.body.position)
            local duration = tsmath.ndiv(hor, self.prop.speed or 1000)
            local upspeed = tsmath.ndiv(ver, duration)

            if upspeed ~= 0 then
                self.owner.body:setupspeed(upspeed)
            end
        
        end
    else
        self:destroy()
    end

end

function bullet.timer:f1(time, tick)

    self.curtime = self.curtime + tick
    if self.target and self.target.caller.state and not self.target.caller.state:isdead() then

        local header = self.target.body.position - self.owner.body.position
        local distance = tsvector.distance(self.target.body.position, self.owner.body.position)
        header = header:fdiv(distance)

        if distance <= (self.target.body.radius + self.owner.body.radius  + 50) or (self.last_header and tsvector.dot(header, self.last_header) < 0) then
            self:_cast_targets()
            self:sendmessage(eventdef.sprite_collide, self.target)
            self:destroy()
        else
            self.owner.body:setvelocity(header:fmul(self.prop.speed or 1000), header)
        end
        
        self.last_distance = distance
        self.last_header = header
    else
        self:destroy()
        return 
    end

    if self.prop.duration and self.curtime >= self.prop.duration then
        self:_cast_targets()
        self:destroy()
    end

end

-- function bullet.sprite:onhitsprite(spritobj)
--     if spritobj == self.target and self:valid() then
--         self:_cast_targets()
--         self:sendmessage(eventdef.sprite_collide, spritobj)
--         self:destroy()
--     end
-- end

function bullet.sprite:onhitblock()
    self:_cast_targets()
    self:destroy()
end

function bullet:ondestroy()
    self.owner:destroy()
end

function bullet:_warn(...)
    global.debug.warning("追踪子弹", ...)
end

function bullet:_cast_targets()
    if self.targets and not self._casted then
        local caster = self.owner.body.parent
        local targets = {}
        local _checklist = {}

        for key, target in ipairs(self.targets) do
            if not _checklist[target] and target.caller.state and not target.caller.state:isdead() then
                table.insert(targets, target)
                _checklist[target] = true
            end
        end

        if self.burn_range and caster.prop.camp  then
            local _targets = self.service.area:getactors(self.service.area:getoppsitecamp(caster.prop.camp))
            for _,target in ipairs(_targets) do
                if not _checklist[target] and tsvector.distance(self.owner.body.position, target.body.position) <= self.burn_range + target.body.radius then
                    table.insert(targets, target)
                    _checklist[target] = true
                end
            end
        end

        if caster.caller.skill then
            caster.caller.skill:cast(self.prop.castid or self.prop.rangeid, caster, targets)
            self._casted = true
        end
    end
end

return bullet
