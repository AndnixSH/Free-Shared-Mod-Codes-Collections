local AudioManager = require "Common.Mgr.Audio.AudioManager"
local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"
local SceneProxy = require "Modules.Scene.SceneProxy"
local HexMapProxy = require "Modules.HexMap.HexMapProxy"
local render_camera = require "Battle.render.camera.render_camera"

local BasicBattleStrategy = require "Modules.Scene.Strategy.BasicBattleStrategy"
local HexMapBattleStrategy = HexMapBattleStrategy or BaseClass(BasicBattleStrategy)

local activeback = 
{
    [ACTIVITYID.MAZE] = SceneDef.SceneType.Maze,
    [ACTIVITYID.STORYLINE] = SceneDef.SceneType.StoryLine,
    [ACTIVITYID.ACTIVITY] = SceneDef.SceneType.Activity,
}

local _wincamp = nil
local _playerlist = nil
local _restart = false
local _towercfg = nil
local _background_color = nil
function HexMapBattleStrategy:OnLoad()
    _background_color = render_camera.get_camera_background_color()
    self.activity_info = self.args[2]
    self:LoadScene(self.activity_info.sceneid)
end

function HexMapBattleStrategy:OnStartEntry()
    _restart = false
    _wincamp = nil
    local battle_info = self.args[1]
    
    local info = self.activity_info
    local gameprop = {rawplayers = battle_info.playerlist, config_key = info.config_key, 
        rune_list = info.rune_list, record = info.record, rune_flags = info.rune_flags, 
        activity_info = info.activity_info }
    self:StartGame(gameprop, battle_info.seed)
    HexMapProxy.Instance:SetBattleState(true)
    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.BattleStopView)  --战斗内暂停界面显示
end

function HexMapBattleStrategy:OnStartGame()	   
    AudioManager.PlayBGM("battle_story_bg")
end

function HexMapBattleStrategy:OnSettleGame(wincamp, rewards, buffer_str)
    _wincamp = wincamp
    self:SettleGameDelayTime(function()
        UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 2, _wincamp, self.strategycfg.activityid)
    end)
end

function HexMapBattleStrategy:ClearData()
    if _wincamp == CAMP.RED then
        
    end 
end

function HexMapBattleStrategy:OnGetEnemeyId()
    return HexMapProxy.Instance:GetEnemeyId()
end

function HexMapBattleStrategy:OnDestroyGame()
    self:UnloadScene()

    self:ClearData()

    HexMapProxy.Instance:SetBattleState(false)
    --local SceneManager = require "Modules.Scene.SceneManager"
    if self.strategycfg.activityid == ACTIVITYID.MAZE then
        -- local scenetype = activeback[self.strategycfg.activityid]
        -- SceneManager.Instance:EnterScene(scenetype) 
        UIOperateManager.Instance:OpenWidget(AppFacade.Maze)
    elseif self.strategycfg.activityid == ACTIVITYID.STORYLINE then
        local StoryLineProxy = require "Modules.StoryLine.StoryLineProxy"
        local entercopyid = StoryLineProxy.Instance:GetEnterCopyId()
        StoryLineProxy.Instance:RequireMapInfo(entercopyid, true)
    elseif self.strategycfg.activityid == ACTIVITYID.ACTIVITY then
        local RealmProxy = require "Modules.Realm.RealmProxy"
        local entercopyid = RealmProxy.Instance:GetEnterCopyId()
        RealmProxy.Instance:Send63002(entercopyid, true)
    end

    if _background_color then
        render_camera.set_camera_background_color(_background_color.red,_background_color.green,_background_color.blue,_background_color.alpha)
    end
    
end

function HexMapBattleStrategy:OnRestartGame()
    HexMapProxy.Instance:SetBattleRestartCell(self.activity_info.cellid)
    local BattleProxy = require "Modules.Battle.BattleProxy"
    BattleProxy.Instance:EscGame()
end

function HexMapBattleStrategy:OnGamePrepared()
    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.BattleView)  
end


function HexMapBattleStrategy:OnRequireSettle(result, gameprop, total_time)

    local BattleProxy = require "Modules.Battle.BattleProxy"
    local record = { totalkill = 0 }

    local encoder = NetEncoder.New()

    encoder:Encode("I2", self.activity_info.cellid)
    HexMapProxy.Instance:SetBattleCell(self.activity_info.cellid)

    local camp_red = {}
    local spritelist = BattleProxy.Instance:GetSpriteList(CAMP.RED)
    for _, spriteid in ipairs(spritelist) do
        local sprite = BattleProxy.Instance:GetSprite(spriteid)
        if sprite and sprite.prop and sprite.prop.sid then
            local hprate = 0
            if result == 0 and sprite.attr.hp_max > 0 then
                hprate = result == 1 and 0 or math.floor(sprite.attr.hp / sprite.attr.hp_max * 1000)
            end
            local mprate = 0
            if result == 0 and sprite.attr.mp_max > 0 then
                mprate = result == 1 and 0 or math.floor(sprite.attr.mp / sprite.attr.mp_max * 1000)
            end
            table.insert(camp_red, {sprite.prop.sid,3,hprate,6,mprate})
            record.totalkill = record.totalkill + sprite.record.kill
        else
            -- print("hexmap red sprite is nil spriteid:", spriteid)
        end
    end

    -- print("camp_red", table.dump(camp_red))
    encoder:EncodeList("I4I2I4I2I4", camp_red)

    local camp_blue = {}
    local spritelist = BattleProxy.Instance:GetSpriteList(CAMP.BLUE)
    for _, spriteid in ipairs(spritelist) do
        local sprite = BattleProxy.Instance:GetSprite(spriteid)
        if sprite and sprite.prop and sprite.prop.stance then
            local hprate = 0
            if sprite.attr.hp_max > 0 then
                hprate = math.floor(sprite.attr.hp / sprite.attr.hp_max * 1000)
            end
            local mprate = 0
            if sprite.attr.mp_max > 0 then
                mprate = math.floor(sprite.attr.mp / sprite.attr.mp_max * 1000)
            end
            table.insert(camp_blue, {sprite.prop.stance,3,hprate,6,mprate})
        else
            -- print("hexmap blue sprite is nil spriteid:", spriteid)
        end
    end

    -- print("camp_blue", table.dump(camp_blue))
    encoder:EncodeList("I4I2I4I2I4", camp_blue)
    encoder:Encode("I2", record.totalkill)
    -- print("record", table.dump(record))

    local buffer = encoder.buffer
	
	local battle_encoder = NetEncoder.New()
	battle_encoder:Encode("s2", buffer)
	
	local settlestr = self:GetSettleStr()
	battle_encoder:Encode("s2I4", settlestr, total_time)
	
    local bufferstr = battle_encoder.buffer
    -- print("cellid", self.activity_info.cellid, #bufferstr)
    self:RequireNetworkSettle(self.strategycfg.activityid, result, bufferstr)
end

return HexMapBattleStrategy