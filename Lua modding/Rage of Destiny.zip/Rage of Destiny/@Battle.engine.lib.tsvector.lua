local setmetatable = setmetatable
--[[
local NUM_BITS = 64
local sqrt1 = function (value)

    if value < 0 then
        return nil
    end

    local num = value
    local result = 0
    
    local bit = 1 << (NUM_BITS - 2)

    while bit > num do
        bit = bit >> 2
    end

    for i=0,1 do
        while bit ~= 0 do
            if num >= (result + bit) then
                num = num - (result + bit)
                result = (result >> 1) + bit
            else
                result = result >> 1
            end
            bit = bit >> 2
        end

        if i == 0 then
            if num > ((1 << (NUM_BITS / 2)) - 1) then
                num = num - result
                num = (num << (NUM_BITS / 2)) - 2147483648
                result = (result << (NUM_BITS / 2)) + 2147483648
            else
                num = num << (NUM_BITS / 2)
                result = result << (NUM_BITS / 2)
            end

            bit = 1 << (NUM_BITS / 2 - 2)

        end
    end

    if num > result then
        result = result + 1
    end
    return result
end
]]

local unit = 1000
local sqrt = math.sqrt
local floor = math.floor
local acos = tsmath.acos
--local acos = math.acos
local tunpack = table.unpack


local scaleunit = function (value)
    return floor(value * unit)
end


tsvector = {}
local _getter = {}

tsvector.__index = function(t, k)
    local var = rawget(tsvector, k)
    if var ~= nil then
        return var
    end

    var = rawget(_getter, k)
    if var ~= nil then
        return var(t)
    end
end

tsvector.__call = function(t, x, y)
    return setmetatable({x = floor(x) or 0, y = floor(y) or 0}, tsvector)
end

function tsvector.new(x, y)
    return setmetatable({x = floor(x) or 0, y = floor(y) or 0}, tsvector)
end

function tsvector.make(tb)
    return tsvector.new(tunpack(tb))
end

function tsvector.newscale(x, y)
    return setmetatable({x = scaleunit(x) or 0, y = scaleunit(y) or 0}, tsvector)
end

function tsvector:set(x, y)
    self.x = x or 0
    self.y = y or 0
end

function tsvector:get()
    return self.x, self.y
end

function tsvector:sqr_magnitude()
    return self.x * self.x + self.y * self.y
end

function tsvector:fmul(n)
    return (n / 1000) * self
end

function tsvector:fdiv(n)
    return self / (n / 1000) 
end

function tsvector:magnitude()
    return floor(sqrt(self.x * self.x + self.y * self.y))
end

function tsvector.normalize(v)
    local x = v.x
    local y = v.y
    local magnitude = sqrt(x * x + y * y)

    if magnitude == 0 then
        return tsvector.new(0, 0)
    else
        return tsvector.newscale(x / magnitude, y / magnitude)
    end
end

function tsvector.dot(lhs, rhs)
    return lhs.x * rhs.x + lhs.y * rhs.y
end

function tsvector.reflect(dir, normal)
	local dx = dir.x
	local dy = dir.y
	local nx = floor(normal.x)
	local ny = floor(normal.y)
	local s = -2 * (dx * nx + dy * ny)

	return setmetatable({x = s * nx + dx, y = s * ny + dy}, tsvector)
end

function tsvector.angle(from, to)
	local x1,y1 = from.x, from.y
	local d = sqrt(x1 * x1 + y1 * y1)

	if d > 1e-5 then
		x1 = x1/d
		y1 = y1/d
	else
		x1,y1 = 0,0
	end

	local x2,y2 = to.x, to.y
	d = sqrt(x2 * x2 + y2 * y2)

	if d > 1e-5 then
		x2 = x2/d
		y2 = y2/d
	else
		x2,y2 = 0,0
	end

	d = x1 * x2 + y1 * y2

	if d < -1 then
		d = -1
	elseif d > 1 then
		d = 1
	end

    local td = fp.new(d)
	--return floor(acos(td._value) * 57.29578)
    return acos(td._value)
end

local deg2rad = math.pi / 180

-- degree负数顺时针，正数逆时针
function tsvector.rotate(v, degrees)

    if degrees == 0 then return v:clone() end

    local sin = fp.set(tsmath.sin(degrees));
    local cos = fp.set(tsmath.cos(degrees));

    --local sin = fp.new(math.sin(degrees * deg2rad));
    --local cos = fp.new(math.cos(degrees * deg2rad));

    local tx = fp.set(v.x);
    local ty = fp.set(v.y);
    local x = (cos * tx) - (sin * ty);
    local y = (sin * tx) + (cos * ty);
    return tsvector.new(x._value, y._value)
end

function tsvector.scale(a, b)
    return setmetatable({x = a.x * b.x, y = a.y * b.y}, tsvector)
end

function tsvector.distance(a, b)
    return floor(sqrt(tsvector.distance_squared(a, b)))
end

function tsvector.distance_squared(a, b)
    return (a.x - b.x) ^ 2 + (a.y - b.y) ^ 2
end

function tsvector.distance_less(a, b)
    return (a.x - b.x) ^ 2 + (a.y - b.y) ^ 2
end

function tsvector.distance_less(a, b, d)
    return tsvector.distance_squared(a, b) < (d * d)
end

function tsvector.distance_less_equal(a, b, d)
    return tsvector.distance_squared(a, b) <= (d * d)
end

function tsvector.distance_greater(a, b, d)
    return tsvector.distance_squared(a, b) > (d * d)
end

function tsvector.distance_greater_equal(a, b, d)
    return tsvector.distance_squared(a, b) > (d * d)
end

function tsvector.project(vector, onnormal)
    local len_normal = onnormal:magnitude()
    local d = tsvector.dot(vector, onnormal) / len_normal
    return onnormal:fmul(d)
end

function tsvector:clone()
	return setmetatable({x = self.x, y = self.y}, tsvector)
end

function tsvector.lerp(a, b, t)
	if t < 0 then
		t = 0
	elseif t > 1 then
		t = 1
	end

    return setmetatable({x = a.x + floor((b.x - a.x) * t), y = a.y + floor((b.y - a.y) * t)}, tsvector)
end

function tsvector.lerp_unclamped(a, b, t)
    return setmetatable({x = a.x + (b.x - a.x) * t, y = a.y + (b.y - a.y) * t}, tsvector)
end

tsvector.__tostring = function(self)
    return string.format("(%d,%d)", self.x, self.y)
end

tsvector.__div = function(va, d)
    return setmetatable({x = floor(va.x / d), y = floor(va.y / d)}, tsvector)
end

tsvector.__mul = function(a, d)
    if type(d) == "number" then
        return setmetatable({x = floor(a.x * d), y = floor(a.y * d)}, tsvector)
    else
        return setmetatable({x = floor(a * d.x), y = floor(a * d.y)}, tsvector)
    end
end

tsvector.__add = function(a, b)
    return setmetatable({x = a.x + b.x, y = a.y + b.y}, tsvector)
end

tsvector.__sub = function(a, b)
    return setmetatable({x = a.x - b.x, y = a.y - b.y}, tsvector)
end

tsvector.__unm = function(v)
    return setmetatable({x = -v.x, y = -v.y}, tsvector)
end

tsvector.__eq = function(a, b)
    return a.x == b.x and a.y == b.y
end

_getter.up = function()
    return setmetatable({x = 0, y = 1}, tsvector)
end
_getter.right = function()
    return setmetatable({x = 1, y = 0}, tsvector)
end
_getter.zero = function()
    return setmetatable({x = 0, y = 0}, tsvector)
end
_getter.one = function()
    return setmetatable({x = 1, y = 1}, tsvector)
end

_getter.magnitude = tsvector.magnitude
_getter.normalized = tsvector.normalize
_getter.sqr_magnitude = tsvector.sqr_magnitude

setmetatable(tsvector, tsvector)

return tsvector
