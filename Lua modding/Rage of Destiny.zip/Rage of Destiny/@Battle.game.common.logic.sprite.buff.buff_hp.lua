local logic = template({}, "sprite.buff.buff_timemerge")

function logic:ontinterval(level)
    self:_changehp()
end

function logic:onshorten(rate)
    local left = self:countleft()
    if left and left > 0 then
        local damage_table = self:_changehp(left, rate)
        damage_table.toobj:sendmessage(eventdef.buff_shorten, damage_table)
    end
end

function logic:_changehp(count, rate)
    local target, attrtarget, percent, attr, value = table.unpack(self.static.args_script[1])
    value = value * self:getlevel()
    count = count or 1
    rate = rate or 1000
    local fromobj = self.buff:getfromobj() or self.owner
    local targetobj = self:gettargetobj(target)
    local attrtargetobj = self:gettargetobj(attrtarget)

    local changevalue = nil

    if percent == 1 then
        local attrname = CONST.ATTR[attr]
        local value = self:amendment(value)
        changevalue = tsmath.rate(attrtargetobj.attr[attrname], value) * count
        changevalue = tsmath.rate(changevalue, rate)
    else
        changevalue = self:amendment(value)
    end

    local damage_table =  {fromobj = fromobj, toobj = targetobj, value = changevalue, buffid = self.static.id, toobj_original_hp = targetobj.attr.hp}
    if changevalue > 0 then
        targetobj.caller.hp:heal(changevalue, fromobj)
        fromobj:sendmessage(eventdef.buff_heal,damage_table)
    else
        targetobj.caller.hp:change(changevalue, fromobj)
        fromobj:sendmessage(eventdef.buff_damage,damage_table)
    end
    return damage_table
end

return logic
