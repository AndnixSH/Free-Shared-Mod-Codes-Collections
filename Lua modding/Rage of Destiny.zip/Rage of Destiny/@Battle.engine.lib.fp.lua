fp = {}

local unit = 1000

function fp.fromfloat(value)
    return math.floor(value * unit)
end

local floor = function(value)
    return math.floor(value)
end

local toint = function(value)
    return floor(value * unit)
end


function fp.new(value)
    -- print('new fp', value)
    return setmetatable({ _value = toint(value or 0) }, fp)
end

function fp.set(_value)
    return setmetatable({ _value = _value or 0 }, fp)
end

function fp:tofloat()
    return self._value / unit
end

-- 待测试，不同平台上表现
function fp.sqrt(v)
   return fp.new(math.sqrt(v._value / unit))
end

fp.__add = function(a, b)
    -- if type(a) == "number" then a = fp.new(a) end
    -- if type(b) == "number" then b = fp.new(b) end
    return setmetatable({ _value = a._value + b._value }, fp)
end

fp.__sub = function(a, b)
    -- if type(a) == "number" then a = fp.new(a) end
    -- if type(b) == "number" then b = fp.new(b) end
    return setmetatable({ _value = a._value - b._value }, fp)
end

fp.__mul = function(a, b)
    -- if type(a) == "number" then a = fp.new(a) end
    -- if type(b) == "number" then b = fp.new(b) end
    return setmetatable({ _value =  floor(a._value * b._value / unit) }, fp)
end

fp.__div = function(a, b)
    -- if type(a) == "number" then a = fp.new(a) end
    -- if type(b) == "number" then b = fp.new(b) end
    return setmetatable({ _value = toint(a._value / b._value) }, fp)
end

fp.__unm = function(v)
    return setmetatable({ _value = -v._value }, fp)
end

fp.__eq = function(a, b)
    return a._value == b._value
end

fp.__lt = function(a, b)
    -- if type(a) == "number" then a = fp.new(a) end
    -- if type(b) == "number" then b = fp.new(b) end
    return a._value < b._value
end

fp.__le = function(a, b)
    -- if type(a) == "number" then a = fp.new(a) end
    -- if type(b) == "number" then b = fp.new(b) end
    return a._value <= b._value
end

fp.__tostring = function(self)
    -- return string.format("%.3f", self._value / unit)
    return tostring(self._value)
end

fp.__call = function (t, value)
    return fp.new(value)
end

setmetatable(fp,fp)

fp.zero = fp(0)

return fp