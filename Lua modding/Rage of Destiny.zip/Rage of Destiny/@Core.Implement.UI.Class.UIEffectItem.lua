local Timer = require "Common.Util.Timer"
local UIEffectModel = require "Battle.render.model.ui_effect_model"
local UIEffectItem = UIEffectItem or BaseClass(GameObjFactor)

local EffectState = {
    Init = 0,
    Open = 1,
    Close = 2,
    Destroy = 3,
}

function UIEffectItem:__init(resName, parentObj, maskArea)
    self.state = EffectState.Init
    self.maskArea = maskArea
    self.delaySetMaskArea = false
    self.model = UIEffectModel.New(resName, function (gameItemModel)
        gameItemModel:ModelSetParent(parentObj)
        self:InitEffect(gameItemModel)
    end)
    self.effectCfg = ConfigManager.GetConfig("data_effect", false)[resName]

    if self.maskArea and self.delaySetMaskArea then
        self:SetMaskArea(self.maskArea.x, self.maskArea.y, self.maskArea.z, self.maskArea.w)
    end
end

function UIEffectItem:InitEffect(gameItemModel)
    -- if self.localpos then
    --     self:SetLocalPosition(self.localpos.x, self.localpos.y, self.localpos.z)
    -- end 
    -- if self.pos then
    --     self:SetPosition(self.pos.x, self.pos.y, self.pos.z)
    -- end
    -- if self.scale then
    --     self:SetScale(self.scale.x, self.scale.y, self.scale.z)
    -- end  
    -- if self.orderlayer then
    --     self:SetOrderLayer(self.orderlayer)
    -- end 
    if self.localpos then
        gameItemModel:ModelLocalPosition(self.localpos.x, self.localpos.y, self.localpos.z)
    end 
    if self.pos then
        gameItemModel:ModelPosition(self.pos.x, self.pos.y, self.pos.z)
    end
    if self.scale then
        gameItemModel:ModelScale(self.scale.x, self.scale.y, self.scale.z)
    end  
    if self.orderlayer then
        gameItemModel:SetOrderLayer(self.orderlayer)
    end  
    if self.callbackfunc then
        self.callbackfunc()
        self.callbackfunc = nil
    end
    if self.maskArea then
        if self.model then
            self:SetMaskArea(self.maskArea.x, self.maskArea.y, self.maskArea.z, self.maskArea.w)
        else
            self.delaySetMaskArea = true
        end
    end
end

function UIEffectItem:SetMaskArea(minX, maxX, minY, maxY)
    if self.model then
        self.model:set_maskArea(minX, maxX, minY, maxY)
    end
end

function UIEffectItem:__delete()
    if self.model then
        self.model:Destroy()
        self.model = nil
    end

    self.localpos = nil
    self.pos = nil 
    self.scale = nil
    self.orderlayer = nil   
end

--重新播放,没有延迟关闭
function UIEffectItem:ResetPlay()
    self:Close()
    self:Open()    
end

--播放完销毁(有bug，不要用，用下面的PlayOnce)
function UIEffectItem:OnlyOnePlay(time)
    self:Open()
    if self.effectCfg then
        local time = time or self.effectCfg.duration
        if time and time > 0 then
            self.timer = Timer.New(function() self:Destroy() end, time / 1000, 1)
            self.timer:Start()
        end
    end    
end

-- 只播放一次就销毁
function UIEffectItem:PlayOnce(duration)
    self:Open()
    if duration and duration > 0 then
        local timer = Timer.New(function() self:Destroy() end, duration, 1)
        timer:Start()
    end
end

--有延迟关闭
function UIEffectItem:Play(time, callback)
    self.callbackfunc = function ( ... )
        self:Play(time)
    end

    self:Open()
    if self.effectCfg or time then
        local time = time or self.effectCfg.duration
        if time and time > 0 then
            self.timer = Timer.New(function() 
                self:Close()
                if callback then
                    callback()
                end  
            end, time / 1000, 1)
            
            self.timer:Start()                 
        end     
    end
end

function UIEffectItem:Open()
    self.callbackfunc = function ( ... )
        self:Open()
    end

    if self.timer then
       self.timer:Stop()
       self.timer = nil 
    end

    if self.model then
        self.state = EffectState.Open
        self.model:showmodel()
    end
end

function UIEffectItem:Close()
    if self.timer then
       self.timer:Stop()
       self.timer = nil 
    end

    if self.model then
        self.state = EffectState.Close
        self.model:hidemodel()
    end

    if self.callbackfunc then
        self.callbackfunc = nil
    end  
end

function UIEffectItem:IsOpen()
    return self.model and self.state == EffectState.Open
end

function UIEffectItem:Destroy()
    if self.timer then
       self.timer:Stop()
       self.timer = nil 
    end
    
    if self.model then
        self.state = EffectState.Destroy
        self.model:release()
        self.model = nil
    end 

    if self.callbackfunc then
        self.callbackfunc = nil
    end 
end

function UIEffectItem:SetPosition(x, y, z)
    self.pos = {x = x, y = y, z = z}
    if self.model then
        self.model:model_position(x, y, z)
    end    
end

function UIEffectItem:SetLocalPosition(x, y, z)
    self.localpos = {x = x, y = y, z = z}
    if self.model then
        self.model:model_localposition(x, y, z)
    end    
end

function UIEffectItem:SetRotation(x, y, z) 
    if self.model then
        self.model:model_rotate(x, y, z)
    end
end

function UIEffectItem:SetScale(x, y, z)
    self.scale = {x = x, y = y, z = z}
    if self.model then
        self.model:model_scale(x, y, z)
    end
end

function UIEffectItem:SetOrderLayer(orderlayer)
    self.orderlayer = orderlayer
    if self.model then
        self.model:set_orderLayer(orderlayer)
    end
end

function UIEffectItem:DOLocalMove(tox, toy, toz, duration, callback, snapping)
    snapping = snapping or false
    if self.model then
        self.model:do_localMove(tox, toy, toz, duration, callback, snapping)
    end
end

function UIEffectItem:DOScale(to, duration)
    if self.model then
        self.model:do_scale(to, duration)
    end
end

return UIEffectItem
