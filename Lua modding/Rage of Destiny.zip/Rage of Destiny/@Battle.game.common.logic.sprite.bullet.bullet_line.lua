local bullet = { timer = {}, sprite = {}, call = service.call(calldef.skill) }

function bullet:oncreate()
    self.curcollide = nil
end

function bullet:ondestroy()
    self.owner:destroy()
end

function bullet:getcollide()
    return self.curcollide
end

function bullet.call:range(rangeid)
    local parent = self.owner.body.parent
    if parent and parent.caller.skill then
        return parent.caller.skill:range(rangeid, self.owner)
    end
end

function bullet.timer:f1()
    self.service.area:collidecheck(self)
end

function bullet.call:cast(castid)
    local parent = self.owner.body.parent
    if parent and parent.caller.skill then
        return parent.caller.skill:cast(castid, self.owner)
    end
end

function bullet.sprite:onhitsprite(spritobj)
    if spritobj.prop.camp == self.owner.prop.camp or spritobj.body.spritetype == self.owner.body.spritetype or self._dirty then return end
    if spritobj ~= self.curcollide then
        self.curcollide = spritobj
        self:sendmessage(eventdef.sprite_collide, spritobj)
    end
end

function bullet.sprite:onhitblock()
    self:destroy()
end

return bullet