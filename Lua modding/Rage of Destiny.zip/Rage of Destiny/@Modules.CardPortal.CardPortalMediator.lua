local CardPortalMediator = CardPortalMediator or BaseClass(StdMediator)

function CardPortalMediator:OnEnterScenceFirst()	
	local CardPortalProxy = require "Modules.CardPortal.CardPortalProxy"
	if AppConfig.ISALONE then
	else
		CardPortalProxy.Instance:Send12000()
	end
end

return CardPortalMediator