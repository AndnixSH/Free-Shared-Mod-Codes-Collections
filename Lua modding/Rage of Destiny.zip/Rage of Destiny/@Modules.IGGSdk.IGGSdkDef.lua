local IGGSdkDef = {
    ReloginType = {
        Expire = 0,
        Kick = 1
    },

    -- 限购信息
    IGGPaymentPurchaseLimitation = {
        None = 0, --无
        User = 1, --账号被限制购买
        Device = 2, --设备被限制购买
        Both = 3, --账号和设备都被限制购买
        RunOutOfQuota = 4 --已超出购买配额
    },

    ReloginType = {
    	Expire = 0, --Accesskey过期
    	Kick = 1,   --被顶号

    	Other = 100 --其他 
    },

    --跟任务走
    AFEventTaskId = {
        [340002] = "RECEIVE_GOLD20K",
        [340003] = "RECEIVE_GOLD50K",
        [340004] = "RECEIVE_GOLD100K",
        [328006] = "REACH_HEROLV60",
        [328008] = "REACH_HEROLV80",
        [328009] = "REACH_HEROLV90",
        [328010] = "REACH_HEROLV100",
        [328011] = "REACH_HEROLV110",
        [328012] = "REACH_HEROLV120",
        [328013] = "REACH_HEROLV130",
        [328014] = "REACH_HEROLV140",
        [328015] = "REACH_HEROLV150", --英雄升级到xx级


        [107001] = "COMPLETE_ATONETOWER_1",  --挑战赎罪之塔1次
        [314003] = "COMPLETE_DRAGONSDEN_1",  --通关巨龙巢穴第6层1次
        [158001] = "COMPLETE_DWARFTREASURY_1",  --挑战公会Boss1次

    },

    --获得图鉴英雄数量
    AFEventHero = {
        [5] = "HIRE_HERO5",
        [10] = "HIRE_HERO10",
        [15] = "HIRE_HERO15",
        [20] = "HIRE_HERO20",
        [25] = "HIRE_HERO25",
        [30] = "HIRE_HERO30",
    },

    --X个英雄达到Y级（例如3个英雄达到60级）
    AFEventHeroLv = {
        [60] = {
            [3] = "REACH_3HEROLV60",
            [5] = "REACH_5HEROLV60",
        },
        [80] = {
            [2] = "REACH_2HEROLV80",
            [5] = "REACH_5HEROLV80",
        },
        [100] = {
            [2] = "REACH_2HEROLV100",
            [5] = "REACH_5HEROLV100",
        },
    },

    AFEventMallPass = {
        [1] = "RECHARGE_ROYALPASS",
        [2] = "RECHARGE_DRAGONPASS",
        [3] = "RECHARGE_CHAOSPASS",
    },
   
    --完成新手
    AFEventNewBie = {
        [10001] = {[4] = "GUIDE_DEPLOY"}, --完成上阵
        [90001] = {[1] = "GUIDE_SKILL"}, --大招新手引导
        [10006] = {[4] = "GUIDE_LEVELUP"}, --完成升级
        [10015] = {[1] = "GUIDE_LAST"}, --完成所有强制新手引导
    },

	--完成章节
	AFEventCampaign = {
		[1] = "COMPLETE_CAMPAIGN_1", --完成第一章所有关卡
		[2] = "COMPLETE_CAMPAIGN_2",
		[3] = "COMPLETE_CAMPAIGN_3",
		[4] = "COMPLETE_CAMPAIGN_4",
		[5] = "COMPLETE_CAMPAIGN_5",
		[6] = "COMPLETE_CAMPAIGN_6",
		[7] = "COMPLETE_CAMPAIGN_7",
		[8] = "COMPLETE_CAMPAIGN_8",
		[9] = "COMPLETE_CAMPAIGN_9",
		[10] = "COMPLETE_CAMPAIGN_10",
		[11] = "COMPLETE_CAMPAIGN_11",
		[12] = "COMPLETE_CAMPAIGN_12",
		[13] = "COMPLETE_CAMPAIGN_13",
	},

    --账号升级
    AFEventPlayerLevel = {
        {10,"PLAYER_LEVEL_10"},
        {15,"PLAYER_LEVEL_15"},
        {20,"PLAYER_LEVEL_20"},
        {25,"PLAYER_LEVEL_25"},
        {30,"PLAYER_LEVEL_30"},
        {35,"PLAYER_LEVEL_35"},
        {40,"PLAYER_LEVEL_40"},
        {45,"PLAYER_LEVEL_45"},
        {50,"PLAYER_LEVEL_50"},
        {53,"PLAYER_LEVEL_53"},
        {57,"PLAYER_LEVEL_57"},
        {64,"PLAYER_LEVEL_64"},
        {70,"PLAYER_LEVEL_70"},
    },

    --竞技场
    AFEventArena = {
        [1] = "COMPLETE_ARENA_1",
        [5] = "COMPLETE_ARENA_5",
        [20] = "COMPLETE_ARENA_20",
    },

    --剧情副本
    AFEventStoryLine = {
        [1] = "COMPLETE_ETERNALBATTLEFIELD_1",
    },
	
	--领取挂机次数
	AFEventHangUp = {
		[1] = "RECEIVE_AUTOAFK_1",
		[2] = "RECEIVE_AUTOAFK_2",
		[3] = "RECEIVE_AUTOAFK_3",
		[4] = "RECEIVE_AUTOAFK_4",
		[5] = "RECEIVE_AUTOAFK_5",
		[6] = "RECEIVE_AUTOAFK_6",
		[7] = "RECEIVE_AUTOAFK_7",
		[8] = "RECEIVE_AUTOAFK_8",
		[9] = "RECEIVE_AUTOAFK_9",
		[10] = "RECEIVE_AUTOAFK_10",
	},
	
	--点击商城图标
	AFEventClickMallIcon = {
		[1] = "CLICK_MALLICON_1",
	},

    --VIP
    AFEventVIP = {flag = "ACCOUNT_VIP_LV",max = 10},--1 - 10

    --是否需要再次弹出评星界面
    AppRatingKey = "Show_AppRating_",
    --加入公会事件
    JoinGroupEventKey = "JoinGroupEventKey_",
    --注册事件
    RegistrationEventKey = "RegistrationEventKey_",

    SecondEventName = {
        Purchase = "igg_purchase",
        CompleteRegistration = "igg_complete_registration",
        LevelUp = "igg_level_up",
        TutorialBegin = "igg_tutorial_begin",
        TutorialComplete = "igg_tutorial_complete",
        JoinGroup = "igg_join_group",
        -- UnlockedAchievement = "igg_unlock_achievement",
        -- AdClick = "igg_ad_click",
        -- AdImpression = "igg_ad_impression",
        EarnVirtualCurrency = "igg_earn_virtual_currency",
        SpendVirtualCurrency = "igg_spend_virtual_currency",
    },
    
    SecondEventParam = {
        PurchaseAmount = "igg_purchase_amount",
        PurchaseCurrency = "igg_purchase_currency",
        PurchaseParameters = "igg_purchase_parameters",
        CompleteRegistrationMethod = "igg_complete_registration_method",
        LevelUpCharacter = "igg_level_up_character",
        LevelUpLevel = "igg_level_up_level",
        TutorialCompleteContent = "igg_tutorial_complete_content",
        TutorialCompleteContentId = "igg_tutorial_complete_content_id",
        TutorialCompleteSuccess = "igg_tutorial_complete_success",
        TutorialCompleteUserId = "igg_tutorial_complete_user_id",
        JoinGroupGroupId = "igg_join_group_group_id",
        -- UnlockAchievementAchievementId = "igg_unlock_achievement_achievement_id",
        -- AdClickAdType = "igg_ad_click_ad_type",
        -- AdImpressionAdType = "igg_ad_impression_ad_type",
        EarnVirtualCurrencyCurrencyName = "igg_earn_virtual_currency_currencyname",
        EarnVirtualCurrencyCurrency = "igg_earn_virtual_currency_currency",
        EarnVirtualCurrencyValue = "igg_earn_virtual_currency_value",
        SpendVirtualCurrencyContent = "igg_spend_virtual_currency_content",
        SpendVirtualCurrencyContentId = "igg_spend_virtual_currency_content_id",
        SpendVirtualCurrencyContentType = "igg_spend_virtual_currency_content_type",
        SpendVirtualCurrencyValue = "igg_spend_virtual_currency_value",
        SpendVirtualCurrencyItemName = "igg_spend_virtual_currency_item_name",
    },

    -- 语言代码表
    Language_Code = {
        "sq",--	阿尔巴尼亚语
        "ar",--	阿拉伯语
        "am",--	阿姆哈拉语
        "az",--	阿塞拜疆语
        "ga",--	爱尔兰语
        "et",--	爱沙尼亚语
        "eu",--	巴斯克语
        "be",--	白俄罗斯语
        "bg",--	保加利亚语
        "is",--	冰岛语
        "pl",--	波兰语
        "bs",--	波斯尼亚语
        "fa",--	波斯语
        "af",--	布尔语(南非荷兰语)
        "da",--	丹麦语
        "de",--	德语
        "ru",--	俄语
        "fr",--	法语
        "tl",--	菲律宾语
        "fi",--	芬兰语
        "fy",--	弗里西语
        "km",--	高棉语
        "ka",--	格鲁吉亚语
        "gu",--	古吉拉特语
        "kk",--	哈萨克语
        "ht",--	海地克里奥尔语
        "ko",--	韩语
        "ha",--	豪萨语
        "nl",--	荷兰语
        "ky",--	吉尔吉斯语
        "gl",--	加利西亚语
        "ca",--	加泰罗尼亚语
        "cs",--	捷克语
        "kn",--	卡纳达语
        "co",--	科西嘉语
        "hr",--	克罗地亚语
        "ku",--	库尔德语
        "la",--	拉丁语
        "lv",--	拉脱维亚语
        "lo",--	老挝语
        "lt",--	立陶宛语
        "lb",--	卢森堡语
        "ro",--	罗马尼亚语
        "mg",--	马尔加什语
        "mt",--	马耳他语
        "mr",--	马拉地语
        "ml",--	马拉雅拉姆语
        "ms",--	马来语
        "mk",--	马其顿语
        "mi",--	毛利语
        "mn",--	蒙古语
        "bn",--	孟加拉语
        "my",--	缅甸语
        "hmn",--	苗语
        "xh",--	南非科萨语
        "zu",--	南非祖鲁语
        "ne",--	尼泊尔语
        "no",--	挪威语
        "pa",--	旁遮普语
        "pt",--	葡萄牙语
        "ps",--	普什图语
        "ny",--	齐切瓦语
        "ja",--	日语
        "sv",--	瑞典语
        "sm",--	萨摩亚语
        "sr",--	塞尔维亚语
        "st",--	塞索托语
        "si",--	僧伽罗语
        "eo",--	世界语
        "sk",--	斯洛伐克语
        "sl",--	斯洛文尼亚语
        "sw",--	斯瓦希里语
        "gd",--	苏格兰盖尔语
        "ceb",--	宿务语
        "so",--	索马里语
        "tg",--	塔吉克语
        "te",--	泰卢固语
        "ta",--	泰米尔语
        "th",--	泰语
        "tr",--	土耳其语
        "cy",--	威尔士语
        "ur",--	乌尔都语
        "uk",--	乌克兰语
        "uz",--	乌兹别克语
        "es",--	西班牙语
        "iw",--	希伯来语
        "el",--	希腊语
        "haw",--	夏威夷语
        "sd",--	信德语
        "hu",--	匈牙利语
        "sn",--	修纳语
        "hy",--	亚美尼亚语
        "ig",--	伊博语
        "it",--	意大利语
        "yi",--	意第绪语
        "hi",--	印地语
        "su",--	印尼巽他语
        "id",--	印尼语
        "jw",--	印尼爪哇语
        "en",--	英语
        "yo",--	约鲁巴语
        "vi",--	越南语
        "zh-CN",--	中文
        "sq",--	阿尔巴尼亚语
        "ar",--	阿拉伯语
        "am",--	阿姆哈拉语
        "az",--	阿塞拜疆语
        "ga",--	爱尔兰语
        "et",--	爱沙尼亚语
        "eu",--	巴斯克语
        "be",--	白俄罗斯语
        "bg",--	保加利亚语
        "is",--	冰岛语
        "pl",--	波兰语
        "bs",--	波斯尼亚语
        "fa",--	波斯语
        "af",--	布尔语(南非荷兰语)
        "zh-TW",--	中文(繁体)
    },
	
	ShowRatingViewMainlineID = 39,
	
	ShowInformViewMainlineID = 25,
}


return IGGSdkDef