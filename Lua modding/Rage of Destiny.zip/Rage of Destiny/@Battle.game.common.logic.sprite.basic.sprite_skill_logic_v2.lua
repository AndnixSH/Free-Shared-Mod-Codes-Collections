local logic = { call = service.call(calldef.skill), timer = {}, event = service.event() }

local slotmt = {
    __tostring = function(self)
        return string.format("slotid:%d skillid:%d", self.id, self.skillid)
    end
}

function logic:oncreate()
    self.owner.record.castcnt = 0 -- cast次数
    self._slot_dict = {}
    self._slot_cd_cost_dict = {} -- 备份原cd表
    self._sort_slots = {} -- 已按优先级排序的主动技能列表
    self._passive_slots = {} -- 被动列表
    self._curslot = nil
    self._fireslotid = nil  -- 瞬时触发的slotid
    self._skillid2slotid = {}
    self._amendment_list = {}
    
    local prop_skill_list = self.owner.prop.skill_list

    if not prop_skill_list or #prop_skill_list == 0 then
        global.debug.warning(self.owner, "技能列表为空")
        return 
    end

    local skill_priority = self.owner.static.skill_priority
    local skill_break = self.owner.static.skill_break

    local skill_list = {}
    for slot, skillid in ipairs(prop_skill_list) do
        if skillid ~= 0 then
            table.insert(skill_list, { skillid = skillid, slot = slot, order = skill_priority[slot], cbreak = skill_break[slot] })
        else
            -- print('skill not exist', slot)
        end
    end
    table.sort(skill_list, function (a, b) return a.order < b.order end)
    -- global.debug.printtable(skill_list)

    local curorder = 1
    for _, skillobj in ipairs(skill_list) do
        if self.call.equip(self, skillobj.slot, skillobj.skillid, skillobj.order > 0 and curorder or skillobj.order, skillobj.cbreak) then
            if skillobj.order > 0 then
                curorder = curorder + 1
            end
        end
    end
    -- global.debug.printtable(self._sort_slots)

end

------------------------------CALL------------------------------

function logic.call:equip(slotid, skillid, order, cbreak)
    local script_table = self.service.scriptengine_v2:loadscripttable("role_"..self.owner.typeid, "skill", skillid)
    if script_table then
        self._skillid2slotid[skillid] = slotid
        local static = self:getconfig(skillid)
        local skill_logic = self.service.scriptengine_v2:create(self.owner, script_table, nil, static)
        local spell_range = self.service.area:getargs(static.spell_range)
        local slot = { id = slotid, enbale = false, charging = false, bactive = true, active_cnt = 0, cd = static.start_cd, spell_range = spell_range, order = order, level = skillid % 10, spd_type = static.spd_type,
        mp_cost = static.mp_cost, cd_cost = static.cd, skillid = static.id, skill = skill_logic, target = static.range.target, cbreak = cbreak, immune_suffer = static.immune_suffer == 1 }
        setmetatable(slot, slotmt)
        self._slot_dict[slotid] = slot
        self._slot_cd_cost_dict[slotid] = slot.cd_cost
        if order > 0 then
            self._sort_slots[order] = slot
        else -- 被动技能
            table.insert(self._passive_slots, slot)
            if slot.cd_cost == 0 then
                global.debug.warning("嗷~！您配置了一个cd为0的被动技能，请检查下是否真的要这样做哦，技能信息:", slot)
            end
            slot.skill.cbend = function ()
                if self:valid() then
                    slot.skill:stop()
                    gamelog.level(1).sprite(self.owner, "skill_stop", slot)
                    self:sendmessage(eventdef.skill_end, slot.skillid)
                end
            end
        end
        return slot
    else
        global.debug.warning("不存在技能脚本"..skillid)
    end
end

function logic.call:setslotcharge(slotid, charging)
    local slot = self._slot_dict[slotid]
    if slot then
        slot.charging = charging
        if charging then
            slot._start_charge_time = self.time.time
        end
        self:_notify_slot_status_change(slot)
    end
end

function logic.call:getslotcharge(slotid)
    local slot = self._slot_dict[slotid]
    if slot then
        return slot.charging
    end
end

function logic.call:getactiveslot()
    if self._curslot then
        return self._curslot.id 
    end
end

function logic.call:changeslot(slotid, skillid)
    local oldslot = self._slot_dict[slotid]
    if oldslot then
        local oldspeed = nil
        if oldslot.skill then
            oldspeed = oldslot.skill:getspeed()
            if oldslot.skill.destroy then
                oldslot.skill:destroy()
            end
        end
        local newslot = self.call.equip(self, slotid, skillid, oldslot.order, oldslot.cbreak)
        if self._curslot and self._curslot.id == slotid then
            self._curslot = newslot
        end
        if oldspeed then
            newslot.skill:setspeed(oldspeed)
        end
        -- print("changeslot", slotid, skillid, newslot.skillid)
    end
end

function logic.call:getcurslotspeed()
    if self._curslot then
        return self._curslot.skill:getspeed()
    end
end

function logic.call:stopcurrent()
    if self._curslot then
        self._curslot.skill:stop()
    end
end

-- 设置槽位cd
function logic.call:setslotcd(slotid, cd)
    local slot = self._slot_dict[slotid]
    if slot then
        slot.cd = tsmath.max(cd, 0)
    end
end

-- 改变槽位cd
function logic.call:changeslotcd(slotid, add)
    local slot = self._slot_dict[slotid]
    if slot then
        slot.cd = tsmath.max(slot.cd + add, 0)
    end
end

-- 改变槽位总cd
function logic.call:changecdcost(slotid, add)
    local slot = self._slot_dict[slotid]
    if slot then
        slot.cd_cost = tsmath.max(slot.cd_cost + add, 0)
    end
end

-- 返回当前cd
function logic.call:getslotcd(slotid)
    local slot = self._slot_dict[slotid]
    if slot then
        return slot.cd
    end
end

-- 返回总cd
function logic.call:getslotcdcost(slotid)
    local slot = self._slot_dict[slotid]
    if slot then
        return slot.cd_cost
    end
end

-- 设置槽位是否激活, @param bactive:是否激活 slotlist:槽位列表
function logic.call:setslotactive(bactive, slotlist)
    for _, slotid in ipairs(slotlist) do
        local slot = self._slot_dict[slotid]
        if slot then
            slot.bactive = bactive
        end
    end
end

-- 设置槽位是否激活
function logic.call:addslotactive(add, slotlist)
    for _, slotid in ipairs(slotlist) do
        local slot = self._slot_dict[slotid]
        if slot then
            slot.active_cnt = slot.active_cnt + add
            slot.bactive = slot.active_cnt >= 0
        end
    end
end

function logic.call:getslot(slotid)
    return self._slot_dict[slotid]
end

-- 获取槽位等级
function logic.call:getslotlevel(slotid)
    local slot = self._slot_dict[slotid]
    return slot and slot.level or 0
end

function logic.call:toslotid(skillid)
    return self._skillid2slotid[skillid]
end

--todo
function logic.call:findslotheader()
    local activeslot = nil
    for _, slot in ipairs(self._sort_slots) do
        if self:_canfire(slot) then
            activeslot = slot
            break
        end
    end
    if activeslot then
        if activeslot.spell_range == 0 then
            return activeslot.id, tsvector.zero
        elseif activeslot.target then
            local target = self:_select_target(activeslot.target)
            if not target then return nil end

            local targetpos = target.body.position
            local mypos = self.owner.body.position
            local dis = activeslot.spell_range + target.body.radius
            -- print('dis', self.owner.prop.name, target.prop.name, tsvector.distance(targetpos, mypos), dis)
            if tsvector.distance_less_equal(targetpos, mypos, dis) then
                return activeslot.id, tsvector.zero, (targetpos - mypos).normalized
            else
                return activeslot.id, (targetpos - mypos).normalized
            end
        else
            global.debug.warning(string.format("%s 没有配置range.target", activeslot))
        end
    end

    return nil
end

function logic:_select_target(target)
    return self.service.area:select(self.owner, target)
end

-- 打断规则
function logic:_canfire(slot)

    if slot.enbale and self:_isauto(slot) and self:_is_satisfy(slot) then
        return not self._curslot or slot.cbreak > self._curslot.cbreak
    end

    return false
end

function logic:_is_satisfy(slot)
    if slot.skill and slot.skill.satisfy and not slot.skill:satisfy(slot) then
        return false
    end
    return true
end

function logic:_isauto(slot)
    if slot.id == SKILL.SLOT.ULTIMATE then
        return self.service.area:getgameobj().caller.input:getauto(self.owner.prop.camp)
    else
        return true
    end
end

function logic.call:targetfire(slotid)
    local slot = self.caller.skill:getslot(slotid)
    if slot and slot.spell_range ~= 0 then
        local target = self:_select_target(slot.target)
        if target then
            local targetpos = target.body.position
            local mypos = self.owner.body.position
            self.owner.body:setheader((targetpos - mypos).normalized)
        end
    end

    self.caller.skill:fire(slotid)
end

function logic.call:fire(slotid)

    local slot = self._slot_dict[slotid]
    if not slot then
        global.debug.warning(string.format("在槽位%d上找不到对应的技能", slotid))
        return
    end
    
    if slot.charging then
        self.caller.skill:setslotcharge(slot.id, false)
        local time_pass = 0
        if slot._start_charge_time then
            time_pass = self.time.time - slot._start_charge_time
            slot._start_charge_time = nil
        end
        self:sendmessage(eventdef.slot_charge_interupt, time_pass)
        return
    end

    if not slot.enbale then return end

    self._fireslotid = slotid
end


-- @return sprite[] 技能选取生效目标
function logic.call:range(rangeid, castobj)

    if not rangeid then
        global.debug.error(self.owner, "rangeid为空")
        return {}
    end
    local config = self:getconfig(rangeid)
    if not config then
        global.debug.error(string.format("castid %s 没有配表", rangeid))
        return {}
    end
    local range_table = config.range
    castobj = castobj or self.owner
    local targetobj = castobj
    if range_table.pos == 1 and castobj == self.owner then -- 生效位置是目标
        targetobj = self:_select_target(range_table.target) or castobj
    end

    local center = targetobj.body.position
    local header = targetobj.body.header

    local targets = self.service.area:range(castobj, center, header, range_table)

    return targets
end

-- @return sprite[] 技能选取并释放
function logic.call:cast(castid, castobj, targets)

    if not castid then
        global.debug.error(self.owner, "castid为空")
        return {}
    end
    local config = self:getconfig(castid)
    if not config then
        global.debug.error(string.format("castid %s 没有配表", castid))
        return {}
    end
    castobj = castobj or self.owner
    if config.cast.attack_mp_add then
        self.owner.caller.mp:cast_change(config.cast.attack_mp_add)
    end

    targets = targets or self.caller.skill:range(castid, castobj)
    if #targets > 0 then
        self.owner.record.castcnt = self.owner.record.castcnt + 1
    end
    for _, toobj in ipairs(targets) do

        if toobj:valid() then
            local cast_table = { final_rate = 1000 }
            for k, v in pairs(config.cast) do -- copy
                cast_table[k] = v
            end
            if cast_table.amendment then
                cast_table = self.service.area:amendment_multi(self.owner, toobj, cast_table, cast_table.amendment_cond, cast_table.amendment)
            end
            if self._amendment_list[config.slotid] then
                for _, amendment_table in ipairs(self._amendment_list[config.slotid]) do
                    cast_table = self.service.area:amendment_multi(self.owner, toobj, cast_table, amendment_table.amendment_cond, amendment_table.amendment)
                end
            end

            if self:_checkhit(self.owner, toobj, cast_table) then

                toobj:sendmessage(eventdef.skill_choose, self.owner, cast_table, { slotid = config.slotid, castid = castid, castobj = castobj })

                local suffer_table = self.service.area:getargs(cast_table.suffer)
                -- 目标受击
                if toobj.caller.suffer and suffer_table then
                    toobj.caller.suffer:add(self.owner, castobj, suffer_table)
                end

                -- 目标buff
                if cast_table.buff then
                    for _, buff_pair in ipairs(cast_table.buff) do
                        local buffid, prob = table.unpack(buff_pair)
                        if toobj.caller.buff and tsmath.random_match(prob) then
                            toobj.caller.buff:add(buffid, self.owner)
                        end
                    end
                end
            end
        end
    end

    return targets

end

function logic.call:add_amendment(slotid, amendment_table)
    self._amendment_list[slotid] = self._amendment_list[slotid] or {}
    table.insert(self._amendment_list[slotid], amendment_table)
end

function logic.call:remove_amendment(slotid, amendment_table)
    local amendment_list = self._amendment_list[slotid]
    if amendment_list then
        for i, value in ipairs(amendment_list) do
            if value == amendment_table then
                table.remove(amendment_list, i)
                break
            end
        end
    end
end

-- 检查是技能否能命中
function logic:_checkhit(fromobj, toobj, cast_table)

    local dmgtype = SKILL.DAMAGE_TYPE.PHYSICS
    if fromobj.static.class == HERO_CLASS.MENTALITY then
        dmgtype = SKILL.DAMAGE_TYPE.MAGIC
    end

    -- 1. 判断该次技能是否未命中
    local hit = true
    if fromobj.prop.camp ~= toobj.prop.camp and dmgtype ~= SKILL.DAMAGE_TYPE.MAGIC and cast_table.must_hit == 0 and not fromobj.buff.must_hit and not toobj.buff.must_bhit then
        if toobj.buff.must_eva then
            hit = false
        else
            local hit_prob = CONST.HIT.A + (fromobj.attr.hit - toobj.attr.eva) / CONST.HIT.B - toobj.attr.eva_rate
            hit = tsmath.random_match(hit_prob)
        end
    end
    -- 未命中
    if not hit then
        self.caller.view:battlesct(fromobj, toobj, DAMAGE_STATE.NOHIT)
        toobj:sendmessage(eventdef.skill_eva)
        return false
    end
    
    -- 2. 判断该次技能伤害是否被免疫，目标处于无敌的情况
    local immune = toobj.buff.invincible
    -- 免疫
    if immune then
        self.caller.view:battlesct(fromobj, toobj, DAMAGE_STATE.IMMUNE)
        toobj:sendmessage(eventdef.skill_immune)
        return false
    end
    
    return true
end

function logic:getconfig(configid)
    return self.service.config:get("skill_static")[configid]
end

local function canpause(sprite)
    return global.game.gameid ~= GAMEPLAYID.HANGUP and
        global.game.activityid ~= ACTIVITYID.ARENA and
        global.game.activityid ~= ACTIVITYID.HIGHARENA and
        global.game.activityid ~= ACTIVITYID.LEGEND_ARENA and
        (sprite.prop.camp == CAMP.RED or sprite.static.type == MONSTER_TYPE.BOSS)
end

function logic.call:is_skill_pause()
    return self._skill_pause
end

-- 暂停游戏，除了自己
function logic.call:pause(duration, rangeid, targetpause)

    if canpause(self.owner) then

        duration = duration or 3000
        local game_input = require "Battle.input.game_input"
        local sprite_list = { self.owner.uid }
        local sprite_set = { [self.owner.uid] = true }

        if rangeid then
            local targets = type(rangeid) == "number" and self.caller.skill:range(rangeid) or rangeid
            for _, target in ipairs(targets) do
                table.insert(sprite_list, target.uid)
                if targetpause then
                    sprite_set[target.uid] = true
                end
            end
        end

        local reason = {duration = duration / 1000,  spriteid = sprite_list}
        local area = self.service.area
        local pause_list = {}

        local objs = self.service.pool:get_allobjs()
        for _, obj in ipairs(objs) do
            if obj.body then
                local pobj = obj.body.parent or obj
                if not sprite_set[pobj.uid] then
                    self.service.sprite:pause_sprite(obj)
                    table.insert(pause_list, obj)
                end
            end
        end

        for _, uid in ipairs(sprite_list) do
            local obj = self.service.pool:get_obj(uid)
            if obj and sprite_set[obj.uid] then
                self.service.sprite:resume_sprite(obj)
            end
        end
        game_input.operation.render_pause(reason)

        local gameobj = area:getgameobj()
        gameobj:sendmessage(eventdef.gametime_pause)
        self._skill_pause = true

        self.timer:delay(duration, function ()

            self._skill_pause = false
            local objs = self.service.pool:get_allobjs()
            for _, obj in ipairs(pause_list) do
                self.service.sprite:resume_sprite(obj)
            end
            game_input.operation.resume(reason)
            gameobj:sendmessage(eventdef.gametime_resume)
            self.owner:sendmessage(eventdef.skill_pause_end)
        end)
    end

end

-- 闪现到选定目标 @param direction 朝向
function logic.call:blink_select(direction, castid)
    local range_target = nil
    if castid then
        range_target = self:getconfig(castid).range.target
    elseif self._curslot then
        range_target = self._curslot.target
    end
    assert(range_target)
    local target = self:_select_target(range_target)
    if target then
        local d = tsmath.nmul(direction or 1000, target.body.radius + self.owner.body.radius)
        local topos = target.body.position + target.body.header:fmul(d)
        if not self.service.area:isvalidpos(topos, self.owner.body.radius) then
            topos = target.body.position - target.body.header:fmul(d)
        end
        self.owner.body:setposition(topos)
        self.owner.body:setheader((target.body.position - topos).normalized)
    end
end

function logic.call:blink_target(target, direction)
    local d = tsmath.nmul(direction or 1000, target.body.radius + self.owner.body.radius)
    local topos = target.body.position + target.body.header:fmul(d)
    if not self.service.area:isvalidpos(topos, self.owner.body.radius) then
        topos = target.body.position - target.body.header:fmul(d)
    end
    self.owner.body:setposition(topos)
    self.owner.body:setheader((target.body.position - topos).normalized)
end

-- 添加开始buff
function logic.call:addstartbuff(castid)
    local castid = assert(castid)

    local config = self:getconfig(castid)
    if not config then
        global.debug.error(string.format("castid %s 没有配表", castid))
        return
    end

    if config.start_buff then
        for _, buff_pair in ipairs(config.start_buff) do
            local buffid, prob = table.unpack(buff_pair)
            if tsmath.random_match(prob) then
                self.owner.caller.buff:add(buffid)
            end
        end
    end
end

function logic.call:getslotdict()
    return self._slot_dict
end

------------------------------CALL------------------------------
function logic.event.sprite:spd_change(spdrate)
    -- print("spd_change", spdrate, self.owner.uid)
    for _, slot in ipairs(self._sort_slots) do
        slot.cd = tsmath.rate(slot.cd, spdrate)
        slot.cd_cost = tsmath.rate(self._slot_cd_cost_dict[slot.id], spdrate)
    end
    for _, slot in ipairs(self._passive_slots) do
        slot.cd = tsmath.rate(slot.cd, spdrate)
        slot.cd_cost = tsmath.rate(self._slot_cd_cost_dict[slot.id], spdrate)
    end
end

function logic.event.sprite:atkspd_change(spdrate)
    -- print("atkspd_change", spdrate, self.owner.uid)
    for _, slot in ipairs(self._sort_slots) do
        if logic._batkskill(slot.spd_type, slot.id) then
            slot.skill:setspeed(spdrate)
        end
    end
    for _, slot in ipairs(self._passive_slots) do
        if logic._batkskill(slot.spd_type, slot.id) then
            slot.skill:setspeed(spdrate)
        end
    end
end

function logic._batkskill(spd_type, slotid)
    return spd_type == 1 or spd_type == 3
end

function logic.event.sprite:spellspd_change(spdrate)
    -- print("spellspd_change", spdrate, self.owner.uid)
    for _, slot in ipairs(self._sort_slots) do
        if logic._bspellskill(slot.spd_type, slot.id) then
            slot.skill:setspeed(spdrate)
        end
    end
    for _, slot in ipairs(self._passive_slots) do
        if logic._bspellskill(slot.spd_type, slot.id) then
            slot.skill:setspeed(spdrate)
        end
    end
end

function logic._bspellskill(spd_type, slotid)
    return spd_type == 2 or spd_type == 3
end

function logic.timer:f1(time, tick)
    local curmp = self.owner.attr.mp
    for _, slot in ipairs(self._sort_slots) do
        if slot.cd > 0 then
            slot.cd = slot.cd - tick
            if slot.cd < 0 then slot.cd = 0 end
        end
        local _enbale = slot.enbale
        slot.enbale = slot.bactive and slot.cd == 0 and slot.mp_cost <= curmp and slot.skill:check()
        if _enbale ~= slot.enbale then
            self:_notify_slot_status_change(slot)
        end
    end
    for _, slot in ipairs(self._passive_slots) do
        if slot.cd > 0 then
            slot.cd = slot.cd - tick
        end
        if slot.cd <= 0 and slot.skill:check() and not slot.skill:isrun() then
            slot.cd = slot.cd_cost
            local scriptprop = {fromobj = self.owner, info = {level = slot.level, slotid = slot.id}, skill_lv = slot.level}
            slot.skill:start(scriptprop, scriptprop)
            gamelog.level(1).sprite(self.owner, "skill_start", slot)
        end
    end
end

function logic:_notify_slot_status_change(slot)
    local status = slot.enbale and SKILL.SLOT_STATUS.ENABLE or SKILL.SLOT_STATUS.DISABLE
    if slot.charging then
        status = SKILL.SLOT_STATUS.CHARGE
    end
    self:sendmessage(eventdef.slot_status_change, slot.id, status)
end

------------------------------状态机------------------------------
function logic:onbreak()
    return self._fireslotid
end

function logic:onenter(time)
    self._curslot = self._slot_dict[self._fireslotid]
    self._fireslotid = nil
    self.caller.mp:change(-self._curslot.mp_cost)
    self._curslot.cd = self._curslot.cd_cost
    self:sendmessage(eventdef.slot_use, self._curslot.id)
    gamelog.level(1).sprite(self.owner, "skill_start", self._curslot)
    self._curslot.skill:start({skill_lv = self._curslot.level}, {fromobj = self.owner, info = {level = self._curslot.level, slotid = self._curslot.id}})
    if self._curslot.immune_suffer then
        self.owner.attr.immune_suffer = self.owner.attr.immune_suffer + 1
    end
end

function logic:onupdate(time, tick)
    return self._curslot.skill:isrun() and STATE_STATUS.SUSPEND or STATE_STATUS.OVER
end

function logic:onexit()
    self._curslot.skill:stop()
    if self._curslot.immune_suffer then
        self.owner.attr.immune_suffer = self.owner.attr.immune_suffer - 1
    end
    gamelog.level(1).sprite(self.owner, "skill_stop", self._curslot)
    self:sendmessage(eventdef.skill_end, self._curslot.skillid)
    self._curslot = nil
end
------------------------------状态机------------------------------
return logic