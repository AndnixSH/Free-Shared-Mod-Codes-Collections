local logic = { timer = {}, call = service.call(calldef.body) }

function logic:oncreate()
    self.born_weight = self.owner.body.weight
end

function logic.timer:f1(time, tick)
    self.owner.body:clearpositon()
    self.owner.body:update(tick)
end

-- 移动
function logic.call:move(speed)
    local header = self.owner.body.header
    self.owner.body:setvelocity(header:fmul(speed))
end

-- 移动到
function logic.call:moveto(position, speed)
    local header = (position - self.owner.body.position).normalized
    self.owner.body:setvelocity(header:fmul(speed))
    local distance = tsvector.distance(position, self.owner.body.position)
    local duration = tsmath.ndiv(distance, speed)
    self.timer:delay(duration, function ()
        self.owner.body:setvelocity(tsvector.zero)
    end)
end

-- 停止移动
function logic.call:stop()
    self.owner.body:setvelocity(tsvector.zero)
end

-- 设置朝向
function logic.call:setheader(header)
    if header then
        self.owner.body:setheader(header)
    end
end

-- 设置朝向
function logic.call:setheader_towards(target)
    local targetpos = target.body.position
    local mypos = self.owner.body.position
    self.owner.body:setheader((targetpos - mypos).normalized)
end

-- 设置位置
function logic.call:setposition(position)
    self.owner.body:setposition(position)
end

-- 设置重量
function logic.call:setweight(weight)
    self.owner.body:setweight(weight)
end

function logic.call:resetweight()
    if self.born_weight then
        self.owner.body:setweight(self.born_weight)
    end
end

-- 创建子物体 create_table:{position,header,degree}
function logic.call:addchild(create_table, script, script_args)

    local position = create_table.position or self.owner.body.position
    local relative = create_table.relative
    if relative then
        if relative == RELATIVE.MAP then
            position = self.service.area:torelativepos(position)
        elseif relative == RELATIVE.SELF then
            local forward, right = position.y, position.x
            local header = self.owner.body.header
            position = self.owner.body.position
            if forward and forward ~= 0 then
                position = position + header:fmul(forward)
            end
            if right and right ~= 0 then
                position = position + tsvector.rotate(header, -90):fmul(right)
            end
        end
    end
    local header = create_table.header or self.owner.body.header
    local prop = { camp = self.owner.prop.camp }
    if create_table.degree then
        header = tsvector.rotate(header, create_table.degree)
    end

    local sprite = self.service.area:create_configsprite(assert(create_table.typeid), position, header, prop)
    sprite.body:setparent(self.owner)

    if create_table.height then
        sprite.body:setheight(create_table.height)
    end

    if script then
        sprite.caller.body:addscript(script, script_args)
    end

    self:sendmessage(eventdef.child_add, sprite)

    return sprite
end

-- 创建脚本 @param 脚本，脚本参数
function logic.call:addscript(script, args)
    local _script = self.service.scriptengine_v2:create(self.owner, script)
    _script:start(args)
end

-- 添加logic
function logic.call:addlogic(typeid, prop)
    self.owner:createlogic(typeid, prop)
end

-- 添加logic，不会重复添加
function logic.call:checklogic(typeid, prop)
    self.owner:checklogic(typeid, prop)
end

function logic.call:removelogic(typeid)
    self.owner:destroylogic(typeid)
end

-- debug打印
function logic.call:debug(...)
    gamelog.debug(self.owner, ...)
end

-- 暂停编辑器
function logic.call:debugbreak(...)
    gamelog.debug(...)
    global.debug.pause()
end

-- 发送消息
function logic.call:sendmessage(eventname, ...)
    self:sendmessage(eventname, ...)
end

-- 销毁自己
function logic.call:destroy()
    local parent = self.owner.body.parent
    if parent then
        parent:sendmessage(eventdef.child_remove, self.owner)
    end
    self.owner:destroy()
end

return logic