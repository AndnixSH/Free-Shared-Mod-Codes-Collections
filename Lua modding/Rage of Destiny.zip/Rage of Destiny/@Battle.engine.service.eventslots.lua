local _eventslot = class({})

local event_modifier = 
{
    private = 1,
    public = 2,
    excludeself = 3,
}

function _eventslot:constructor(name)
    self.name = name
    self._eventlist = {}
end

function _eventslot:add(eventkey, handler, context, source, modifierkey)
    self._eventlist[eventkey] = self._eventlist[eventkey] or {}
    table.insert(self._eventlist[eventkey], { handler = handler, context = context, source = source, 
                                                modifier = modifierkey and event_modifier[modifierkey] or event_modifier.private })
end

local rmfunc = function (handlerobj, handler, context)
    return handlerobj.handler == handler and handlerobj.context == context
end

function _eventslot:remove(eventkey, handler, context)
    local slot = self._eventlist[eventkey]
    if not slot then return end
    global.array.removeby(slot, rmfunc, handler, context)
    if #slot == 0 then self._eventlist[eventkey] = nil end
end

function _eventslot:broadcast(eventkey, ...)
    local slot = self._eventlist[eventkey]
    if slot then
        for _, handlerobj in ipairs(slot) do
            handlerobj.handler(handlerobj.context, ...)
        end
    end
end

function _eventslot:broadcastfrom(eventkey, fromobj, ...)
    local slot = self._eventlist[eventkey]
    if slot then
        for _, handlerobj in ipairs(slot) do
            if handlerobj.modifier == event_modifier.private then
                if fromobj == handlerobj.source then 
                    handlerobj.handler(handlerobj.context, ...) -- 非public且发送者是自己
                end
            elseif handlerobj.modifier == event_modifier.public then
                handlerobj.handler(handlerobj.context, fromobj, ...)
            elseif handlerobj.modifier == event_modifier.excludeself then
                if fromobj ~= handlerobj.source then
                    handlerobj.handler(handlerobj.context, fromobj, ...)
                end
            end
        end
    end
end

function _eventslot:callfrom(eventkey, fromobj, ...)
    local slot = self._eventlist[eventkey]
    local result = nil
    if slot then
        for _, handlerobj in ipairs(slot) do
            local _result = nil
            if handlerobj.modifier == event_modifier.private then
                if fromobj == handlerobj.source then 
                    _result = handlerobj.handler(handlerobj.context, ...) -- 非public且发送者是自己
                end
            elseif handlerobj.modifier == event_modifier.public then
                _result = handlerobj.handler(handlerobj.context, fromobj, ...)
            elseif handlerobj.modifier == event_modifier.excludeself then
                if fromobj ~= handlerobj.source then
                    _result = handlerobj.handler(handlerobj.context, fromobj, ...)
                end
            end
            if _result ~= nil then 
                result = _result -- 替换
            end
        end
    end
    return result
end

function _eventslot:send(to, eventkey, ...)
    local slot = self._eventlist[eventkey]
    if slot then
        for _, handlerobj in ipairs(slot) do
            if to == handlerobj.source then
                handlerobj.handler(handlerobj.context, ...)
            end
        end
    end
end

function _eventslot:dispose()
    self._eventlist = {}
end



local eventslots = { _slots = {}, _slotdict = {}, _slotnames = {}, _tageventlist = {}, _unloadtag = {} }

local sortfunc = function(x, y) return x[1] < y[1] end

local function geteventobjs(evnttable)
    local keylist = {}
    for k, v in pairs(evnttable) do
        local t = type(v)
        if t == "table" then
            for fk, fv in pairs(v) do
                if type(fv) == "function" then
                    table.insert(keylist, {fk,fv,k})
                else
                    error("wrong event type", fk)
                end
            end
        elseif t == "function" then
            table.insert(keylist, {k,v})
        else
            error("wrong event type", k)
        end
    end
    table.sort(keylist, sortfunc)
    return keylist
end

function eventslots:init(slotlist)
    for _, name in ipairs(slotlist) do
        self:createslot(name)
    end
end

function eventslots:createslot(name)
    local slot = _eventslot(name)
    table.insert(self._slots, slot)
    table.insert(self._slotnames, name)
    self._slotdict[name] = slot
end

function eventslots:getslot(name)
    return self._slotdict[name]
end

function eventslots:getemitter()
    return self._slotdict
end

function eventslots:load(tb, context, source, tag)

    if tag and self._unloadtag[tag] then
        return tb
    end

    for _, slotname in ipairs(self._slotnames) do
        local events = tb[slotname]
        if events then
            local eventobjs = geteventobjs(events)
            if tag then
                self._tageventlist[tag] = self._tageventlist[tag] or {}
                table.insert(self._tageventlist[tag], { eventobjs = eventobjs, context = context, slotname = slotname })
            end
            for _, eventobj in ipairs(eventobjs) do
                self:getslot(slotname):add(eventobj[1], eventobj[2], context, source, eventobj[3])
            end
        end
    end
    return tb
end

function eventslots:unload(tb, context, source)
    for _, slotname in ipairs(self._slotnames) do
        local events = tb[slotname]
        if events then
            local eventobjs = geteventobjs(events)
            for _, eventobj in ipairs(eventobjs) do
                self:getslot(slotname):remove(eventobj[1], eventobj[2], context)
            end
        end
    end
end

function eventslots:unloadtag(tag)
    self._unloadtag[tag] = true
    local eventlist = self._tageventlist[tag]
    if eventlist then
        for _, tageventobj in ipairs(eventlist) do
            for _, eventobj in ipairs(tageventobj.eventobjs) do
                self:getslot(tageventobj.slotname):remove(eventobj[1], eventobj[2], tageventobj.context)
            end
        end
    end
end

function eventslots:dump()
    for i, slot in ipairs(self._slots) do
        global.debug.info("eventslots."..slot.name.."._eventlist", global.debug.table(slot._eventlist))
    end
end

function eventslots:dispose()
    for i, slot in ipairs(self._slots) do
        slot:dispose()
    end
    self._slots = {}
    self._slotdict = {}
    self._slotnames = {}
    self._tageventlist = {}
    self._unloadtag = {}
end

return eventslots