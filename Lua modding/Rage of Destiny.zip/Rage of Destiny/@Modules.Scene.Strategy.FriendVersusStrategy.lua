local AudioManager = require "Common.Mgr.Audio.AudioManager"
local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"
local CampaignProxy = require "Modules.Campaign.CampaignProxy"
local RoleInfoProxy = require "Modules.RoleInfo.RoleInfoProxy"
local BattleProxy = require "Modules.Battle.BattleProxy"
local BasicBattleStrategy = require "Modules.Scene.Strategy.BasicBattleStrategy"
local FriendVersusStrategy = FriendVersusStrategy or BaseClass(BasicBattleStrategy)


local _wincamp = nil
local _playerlist = nil
local _restart = false
function FriendVersusStrategy:OnLoad()

    self:LoadScene(2001)  --友谊战 测试场景
end

function FriendVersusStrategy:OnStartEntry()
    _restart = false
    _wincamp = nil

    local battle_info = self.args[1]
    _playerlist = battle_info.playerlist

    local config_key = 10011
    local gameprop = {rawplayers = _playerlist, config_key = config_key}
	self:StartGame(gameprop, battle_info.seed)

    local view=LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleStopView)
    if view then
        view.data={activityid = ACTIVITYID.FRIEND_VERSUS}
        view:OpenView()
    end
end

function FriendVersusStrategy:OnStartGame()	   
    AudioManager.PlayBGM("battle_arena_bg")
end

function FriendVersusStrategy:OnSettleGame(wincamp, rewards, buffer_str)
	_wincamp = wincamp
    self:SettleGameDelayTime(function()
        UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 2, _wincamp, self.strategycfg.activityid)
    end)
end

function FriendVersusStrategy:ClearMainLine()
end

function FriendVersusStrategy:OnDestroyGame()
    self:UnloadScene()
    self:ClearMainLine()

    local SceneManager = require "Modules.Scene.SceneManager"
    local SceneDef = require "Modules.Scene.SceneDef"
    SceneManager.Instance:EnterScene(SceneDef.SceneType.Main)
end

function FriendVersusStrategy:OnRestartGame()
    self:Destroy()
end

function FriendVersusStrategy:OnGamePrepared()
    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.BattleView)  
end

function FriendVersusStrategy:OnRequireSettle(result)
    -- print("FriendVersusStrategy:OnRequireSettle", result)

    if result == 0 then --胜利
    end

    local settlestr = self:GetSettleStr()
    local bufferstr = string.pack(">s2", settlestr)
    self:RequireNetworkSettle(self.strategycfg.activityid, result, bufferstr)
end

return FriendVersusStrategy