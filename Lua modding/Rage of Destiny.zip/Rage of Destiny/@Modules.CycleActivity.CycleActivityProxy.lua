
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local ModuleManager = require "Common.Mgr.UI.ModuleManager"
local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
local RedPointDef = require "Modules.RedPoint.RedPointDef"
local HeroDef = require "Modules.Hero.HeroDef"
local CycleActivityProxy = CycleActivityProxy or BaseClass(BaseProxy)
local CycleActivityDef = require "Modules.CycleActivity.CycleActivityDef"

function CycleActivityProxy:__init()
    CycleActivityProxy.Instance = self
    self:AddProto(64000, self.On64000) --七日登录
    self:AddProto(64001, self.On64001) 
    self:AddProto(64002, self.On64002) 
    self:AddProto(64003, self.On64003)
    self:AddProto(64004, self.On64004)
    self.seven_login_max_days = 7
    self.data = {}
    self.data.events = {}
end

function CycleActivityProxy:__delete()
    CycleActivityProxy.Instance = nil
end

function CycleActivityProxy:GetSeveLoginConfig(id)

    if id == CycleActivityDef.Events_Type.Seven_Login_One then
        return ConfigManager.GetConfig("data_events_7dayslogin")
    elseif id == CycleActivityDef.Events_Type.Seven_Login_Two then
        return ConfigManager.GetConfig("data_events_7days")
    end
end

function CycleActivityProxy:GetEventsTimeConfig()

    return ConfigManager.GetConfig("data_events_time")
end

function CycleActivityProxy:GetNineGridConfig(id)

    if id == CycleActivityDef.Events_Type.Nine_Grid_One then
        return ConfigManager.GetConfig("data_events_sudoku")
    end
end

function CycleActivityProxy:GetNineGridBoxConfig(id)

    if id == CycleActivityDef.Events_Type.Nine_Grid_One then
        return ConfigManager.GetConfig("data_events_sudoku_reward")
    end
end

function CycleActivityProxy:GetEventsStartTime(id)
    if not self.data.events[id] then
        return nil
    end
    return self.data.events[id].starttime
end

function CycleActivityProxy:GetEventsEndTime(id)

    if not self.data.events[id] then
        return nil
    end
    local curtime = RoleInfoModel.servertime
    local startime = self.data.events[id].starttime or 0
    local endtime = self.data.events[id].endtime or 0
    
    if os.difftime(startime,curtime)  > 0 then
        --活动未开启
        return nil
    end
    if os.difftime(endtime,curtime) < 0 then
        return 0
    end
    return endtime
end

function CycleActivityProxy:Send64000()
    self:SendMessage(64000)
end

function CycleActivityProxy:RequestUpdateRedDot()
    if self.data.events then
        for _ , v in ipairs(CycleActivityDef.NineGridIdList) do
            local _id = v
            if self.data.events[_id] then
                --九宫格类型活动活动没有结束期间切换场景后需请求红点
                if not self:CheckActivityFinished(_id) then
                    self:Send64000()
                    break
                end
            end
        end
    end
end

function CycleActivityProxy:CheckActivityFinished(id)

    local endtime = self:GetEventsEndTime(id)
    local finish = true
    if endtime and endtime > 0 then
        local ModuleManager = require "Common.Mgr.UI.ModuleManager"
        if   ModuleManager.SystemIsOpen(CycleActivityDef.SystemOpen[id],false) then
            finish = false
        end
    end
    return finish
end

function CycleActivityProxy:On64000(decoder)

    local count = decoder:Decode("I1")
    for i = 1,count do
        local id,starttime,endtime = decoder:Decode("I1I4I4")
        local has_get_reward_days = decoder:DecodeList("I1")
        local un_get_reward_days = decoder:DecodeList("I1")
        self.data.events[id] = {}
        self.data.events[id].starttime = starttime
        self.data.events[id].endtime = endtime
        self.data.events[id].has_get_reward_days = has_get_reward_days
        self.data.events[id].un_get_reward_days = un_get_reward_days
        self:UpdateRedDot(id)
        --print("---On64000----------",id,table.dump(self.data.events[id]))
    end

    local count2 = decoder:Decode("I1")
    for i = 1,count2 do
        local id,starttime,endtime,num = decoder:Decode("I1I4I4I1")
        local has_get_reward_days = decoder:DecodeList("I1")
        local has_get_box_reward_id = decoder:DecodeList("I1")
        local task_progress = {}
        for ii = 1,num do
            local progress = decoder:DecodeList("I4")
            table.insert(task_progress,progress)
        end
        --print("---On64000----------",id,table.dump(task_progress))
        self.data.events[id] = {}
        self.data.events[id].starttime = starttime
        self.data.events[id].endtime = endtime
        self.data.events[id].has_get_reward_days = has_get_reward_days
        self.data.events[id].has_get_box_reward_id = has_get_box_reward_id
        self.data.events[id].task_progress = task_progress 
       
        self:UpdateNineGridRedDot(id)
    end

    self:ToNotify(self.data,CycleActivityDef.NotifyDef.Update_Seven_Login,{})
end

function CycleActivityProxy:GetNineGridState(id,gridid)
    local config = self:GetNineGridConfig(id)
    local state = CycleActivityDef.Reward_State.CannotGet
    if config[gridid] and self.data.events[id] then
        local v = config[gridid]
        local tasktype = v.type
        local data = v.value
        local targetvalue = data[#data]
        local cur_data = self.data.events[id].task_progress[tasktype]
        local curvalue = 0 
        local _type = #data > 1 and data[1] or 1
        curvalue = self.data.events[id].task_progress[tasktype][_type]
        local hasget = false
        for _ , taskid in ipairs(self.data.events[id].has_get_reward_days) do
            if taskid == gridid then
                hasget = true
                state = CycleActivityDef.Reward_State.HasGet
                break
            end
        end
        if curvalue >= targetvalue then
            if not hasget then
                state = CycleActivityDef.Reward_State.UnGet
            end
        end
    end
    return state
end

function CycleActivityProxy:GetNineGridProgress(id,gridid)
    local config = self:GetNineGridConfig(id)
    local progress = 0
    local curvalue = 0 
    local targetvalue = 0
    if config[gridid] and self.data.events[id] then
        local v = config[gridid]
        local tasktype = v.type
        local data = v.value
        targetvalue = data[#data]
        local cur_data = self.data.events[id].task_progress[tasktype]
       
        local _type = #data > 1 and data[1] or 1
        curvalue = self.data.events[id].task_progress[tasktype][_type]
        if curvalue >= targetvalue then
            progress = 1
        else
            progress = curvalue / targetvalue
        end
    end
    return progress ,curvalue >= targetvalue and targetvalue or curvalue ,targetvalue
end

function CycleActivityProxy:GetNineGridBoxState(id,boxid)
    local box_reward_config = self:GetNineGridBoxConfig(id)
    local state = CycleActivityDef.Reward_State.CannotGet
    if box_reward_config[boxid] then
        local v = box_reward_config[boxid]
        local hasget = false
        for _ , _id in ipairs(self.data.events[id].has_get_box_reward_id) do
            if _id == boxid then
                hasget = true
                state = CycleActivityDef.Reward_State.HasGet
                break
            end
        end
        if not hasget then
            local sudoku_id = v.sudoku_id
            if sudoku_id then
                local finish = true
                for _, taskid in ipairs(sudoku_id) do
                    local has = false
                    for _ , _id in ipairs(self.data.events[id].has_get_reward_days) do
                        if taskid == _id then
                            has = true
                            break
                        end
                    end
                    if not has then
                        finish = false
                        break
                    end
                end
                if finish then
                    state = CycleActivityDef.Reward_State.UnGet
                end
            else
                --最后大宝箱
                local config = self:GetNineGridConfig(id)
                if #self.data.events[id].has_get_reward_days == #config then
                    state = CycleActivityDef.Reward_State.UnGet
                end
            end
        end
    end
    return state
end

function CycleActivityProxy:GetNineGridFinalBoxReward(id)
    local box_reward_config = self:GetNineGridBoxConfig(id)
    if box_reward_config then
        local boxid = #box_reward_config
        return box_reward_config[boxid].goods_id[1]
    end
end

function CycleActivityProxy:GetNineGridBoxProgress(id,boxid)
    local box_reward_config = self:GetNineGridBoxConfig(id)
    local progress = 0
    local num = 0
    local targetnum = 0
    if box_reward_config[boxid] then
        local v = box_reward_config[boxid]
        local hasget = false
        for _ , _id in ipairs(self.data.events[id].has_get_box_reward_id) do
            if _id == boxid then
                hasget = true
                progress = 1
                if v.sudoku_id then
                    num = #v.sudoku_id
                    targetnum = num
                end
                break
            end
        end
        if not hasget then
            local sudoku_id = v.sudoku_id
            if sudoku_id then
                targetnum = #sudoku_id
                for _, taskid in ipairs(sudoku_id) do
                    local has = false
                    for _ , _id in ipairs(self.data.events[id].has_get_reward_days) do
                        if taskid == _id then
                            num = num + 1
                        end
                    end
                end
                progress = num / #sudoku_id
            else
                --最后大宝箱
                local config = self:GetNineGridConfig(id)
                num = #self.data.events[id].has_get_reward_days
                targetnum =  #config
                progress = num / targetnum
            end
        end
    end
    return progress ,num, targetnum
end

function CycleActivityProxy:UpdateNineGridRedDot(id)
    local bopen = ModuleManager.SystemIsOpen(CycleActivityDef.SystemOpen[id],false)
    if bopen then
        if self.data and self.data.events[id] and self.data.events[id].task_progress then
            local config = self:GetNineGridConfig(id)
            for _, v in ipairs(config) do
               
                local state = self:GetNineGridState(id,v.id)
                local showred = false
                if state == CycleActivityDef.Reward_State.UnGet then
                    showred = true
                end
                RedPointProxy.Instance:SetNodeNumDynamic(CycleActivityDef.RedPointIdList[id],tostring(v.id),showred and 1 or 0)
            end

            local box_reward_config = self:GetNineGridBoxConfig(id)
            if box_reward_config then
                for _,v in ipairs(box_reward_config) do
                    local state = self:GetNineGridBoxState(id,v.id)
                    local showred = false
                    if state == CycleActivityDef.Reward_State.UnGet then
                        showred = true
                    end
                    RedPointProxy.Instance:SetNodeNumDynamic(CycleActivityDef.RedPointIdList[id],tostring("box"..v.id),showred and 1 or 0)
                end
            end
        end
    end
end

function CycleActivityProxy:GetNineGridHasFinishTaskNum(id)
    local num = 0
    local config = self:GetNineGridConfig(id)
    local maxnum = #config
    if self.data.events[id] and self.data.events[id].has_get_reward_days then
        num = #self.data.events[id].has_get_reward_days
    end
    return num,maxnum
end

function CycleActivityProxy:GetNineGridItemList(id)
    local config = self:GetNineGridConfig(id)
    local list = {}
    for _ , v in ipairs(config) do
        local item = {}
        item.index = v.id
        item.state = self:GetNineGridState(id,v.id)
        item.typeid = id
        item.parentredId = CycleActivityDef.RedPointIdList[id]
        table.insert(list,item)
    end
    return list
end

function CycleActivityProxy:GetNineBoxItemList(id)
    local config = self:GetNineGridBoxConfig(id)
    local list = {}
    for _ , v in ipairs(config) do
        local item = {}
        item.index = v.id
        item.state = self:GetNineGridBoxState(id,v.id)
        item.progress = 1-self:GetNineGridBoxProgress(id,v.id)
        item.typeid = id
        item.parentredId = CycleActivityDef.RedPointIdList[id]
        table.insert(list,item)
    end
    return list
end

function CycleActivityProxy:GetFinalBoxGetState(id)
    local config = self:GetNineGridBoxConfig(id)
    local state = CycleActivityDef.Reward_State.CannotGet
    if config then
        state = self:GetNineGridBoxState(id, #config)
    end
    return state
end

function CycleActivityProxy:GetTaskIdTypeByTaskId(id,type,taskid)
    local tasktype = 1
    local grid_config = self:GetNineGridConfig(id)
    if type ==  CycleActivityDef.NineGridRewardType.Grid then
        
        if grid_config[taskid] then
            tasktype = grid_config[taskid].type or 1
        end
    elseif type ==  CycleActivityDef.NineGridRewardType.Box then
        local config = self:GetNineGridBoxConfig(id)
        if config[taskid] and config[taskid].sudoku_id then
            local data = config[taskid].sudoku_id
            local lookid = data[1]
            for _ , _id in ipairs(data) do
                local state = self:GetNineGridState(id,_id)
                if state == CycleActivityDef.Reward_State.CannotGet then
                    lookid = _id
                    break
                end
            end
            tasktype = grid_config[lookid].type or 1
        end
    end
    return tasktype
end

function CycleActivityProxy:GetTaskFinishedStateByTaskId(id,type,taskid)
    local state = CycleActivityDef.Reward_State.CannotGet
    if type ==  CycleActivityDef.NineGridRewardType.Grid then
        state = self:GetNineGridState(id,taskid)
    elseif type ==  CycleActivityDef.NineGridRewardType.Box then
        state = self:GetNineGridBoxState(id,taskid)
    end
    return state
end

function CycleActivityProxy:GetTaskDecById(id,type,taskid)
    if type ==  CycleActivityDef.NineGridRewardType.Grid then
        --格子
        local config = self:GetNineGridConfig(id)
        local cfg = config[taskid]
        if cfg then
            local type = cfg.type
            local value = cfg.value
            local str = ""
            if type == CycleActivityDef.Nine_Grid_Task_Type.ChallengeInSingleBattle then
                str = string.format(LanguageManager.Instance:GetWord(CycleActivityDef.CommonDef["Nine_Grid_Type"..tostring(type)]),value[2],LanguageManager.Instance:GetWord(HeroDef.Profession[value[1]]) ,value[3])
            elseif type == CycleActivityDef.Nine_Grid_Task_Type.CollectHero then
                str = string.format(LanguageManager.Instance:GetWord(CycleActivityDef.CommonDef["Nine_Grid_Type"..tostring(type)]),value[2],LanguageManager.Instance:GetWord(HeroDef.ShowRaceWord[value[1]].nohero))
            else
                str = string.format(LanguageManager.Instance:GetWord(CycleActivityDef.CommonDef["Nine_Grid_Type"..tostring(type)]),value[1])
            end
            local progress ,curvalue,targetvalue = self:GetNineGridProgress(id,taskid)
            return str,progress ,curvalue,targetvalue 
        end
    elseif type ==  CycleActivityDef.NineGridRewardType.Box then
        --宝箱
        local config = self:GetNineGridBoxConfig(id)
        local cfg = config[taskid]
        if cfg then
            local value = cfg.sudoku_id
            local str1 = ""
            for k = 1,#value do
                str1 = str1..tostring(value[k])
                if k ~= #value then
                    str1 = str1.."、"
                end
            end
            local str = LanguageManager.Instance:GetWord(CycleActivityDef.CommonDef.Nine_Box_Tips2) 
            local progress ,curvalue,targetvalue  = self:GetNineGridBoxProgress(id,taskid)
            return string.format(str,str1) ,progress ,curvalue,targetvalue 
        end
    end
    return ""
end

function CycleActivityProxy:GetNineGridRewardList(id,type,taskid)
    local reward = {}
    local state = CycleActivityDef.Reward_State.CannotGet
    if type ==  CycleActivityDef.NineGridRewardType.Grid then
        local config = self:GetNineGridConfig(id)
        if config[taskid] then
            reward = config[taskid].goods_id
        end
        state = self:GetNineGridState(id,taskid)
    elseif type ==  CycleActivityDef.NineGridRewardType.Box then
        --宝箱
        local config = self:GetNineGridBoxConfig(id)
        if config[taskid]  then
            reward = config[taskid].goods_id
        end
        state = self:GetNineGridBoxState(id,taskid)
    end
    return reward , state
end

function CycleActivityProxy:GetBoxesIdByGridId(id,gridid)

    local boxids = {}
    local config = self:GetNineGridBoxConfig(id)
    for _ , cfg in ipairs(config) do
        local value = cfg.sudoku_id
        if value then
            for k = 1,#value do
                if value[k] == gridid then
                    table.insert(boxids,cfg.id)
                end
            end
        end
    end
    return boxids
end

function CycleActivityProxy:UpdateRedDot(id)
    
    local bopen = ModuleManager.SystemIsOpen(CycleActivityDef.SystemOpen[id],false)
    if bopen then
        if self.data and self.data.events[id] and self.data.events[id].un_get_reward_days then
            local config = self:GetSeveLoginConfig(id)
            local count = #self.data.events[id].un_get_reward_days
            for k, v in ipairs(self.data.events[id].has_get_reward_days) do
                RedPointProxy.Instance:SetNodeNumDynamic(CycleActivityDef.RedPointIdList[id],tostring(v),0)
            end
            for _, v in ipairs(self.data.events[id].un_get_reward_days) do
                RedPointProxy.Instance:SetNodeNumDynamic(CycleActivityDef.RedPointIdList[id],tostring(v),1)
            end
            
            if #config >  self.seven_login_max_days then
                if #self.data.events[id].has_get_reward_days == (#config - 1) then
                    RedPointProxy.Instance:SetNodeNumDynamic(CycleActivityDef.RedPointIdList[id],tostring(#config),1)
                else
                    RedPointProxy.Instance:SetNodeNumDynamic(CycleActivityDef.RedPointIdList[id],tostring(#config),0)
                end
            end
        end
    end
 end

function CycleActivityProxy:GetOneRewardState(id,day)
    if self.data and self.data.events[id] then
        if self.data.events[id].has_get_reward_days and self.data.events[id].un_get_reward_days then
            for _, v in ipairs(self.data.events[id].has_get_reward_days) do
                if v == day then
                    return CycleActivityDef.Reward_State.HasGet
                end
            end
            for _, v in ipairs(self.data.events[id].un_get_reward_days) do
                if v == day then
                    return CycleActivityDef.Reward_State.UnGet
                end
            end
        end
    end
    return CycleActivityDef.Reward_State.CannotGet
end
function CycleActivityProxy:GetSevenLoginItemList(id)
    local list = {}
    if id == CycleActivityDef.Events_Type.Seven_Login_One then
        local config = self:GetSeveLoginConfig(id)
        for k , v in ipairs(config) do
            if k ~= #config then
                 local item = {}
                 item.id = v.id
                 item.goods_id = v.goods_id or {}
                 item.eventid = id
                 item.state = self:GetOneRewardState(id,v.id)
                 table.insert(list,item)
            end
        end
        table.sort( list, function ( a,b )
            return a.id < b.id
        end )
    elseif id == CycleActivityDef.Events_Type.Seven_Login_Two then
        list = self:GetSevenTwoRewards(id)
    elseif id == CycleActivityDef.Events_Type.Nine_Grid_One then

    end
    return list
end
function CycleActivityProxy:GetFirstCannotGetDay(id)
    local days = {}
    if self.data and self.data.events[id] then
        if self.data.events[id].has_get_reward_days and self.data.events[id].un_get_reward_days then
            for k, v in ipairs(self.data.events[id].has_get_reward_days) do
                table.insert(days,v)
            end
            for _, v in ipairs(self.data.events[id].un_get_reward_days) do
                table.insert(days,v)
            end
            table.sort( days, function ( a,b )
                return a < b
            end )
        end
    end
   
    local first_cannot_get_day = #days == 0 and 1 or (days[#days]+1)
    if id == CycleActivityDef.Events_Type.Seven_Login_Two then
        local config = self:GetSeveLoginConfig(id)
        for k = 1, #config do
            if not days[k] or days[k] ~= k then
                first_cannot_get_day = k
                break
            end
        end
    end
    return first_cannot_get_day
end
function CycleActivityProxy:GetSevenLoginCost()
    local config = ConfigManager.GetConfig("data_common").events_seven_login_cost
    local cost = 100
    if config.value1 then
		cost = config.value1[1]
	end
    return cost
end

function CycleActivityProxy:GetNineGridCost()
    local config = ConfigManager.GetConfig("data_common").events_ninebox_cost
    local cost = 200
    if config.value1 then
		cost = config.value1[1]
	end
    return cost
end

function CycleActivityProxy:GetSevenSignCost()
    local config = ConfigManager.GetConfig("data_common").events_newseven_login_cost
    local cost = 100
    if config.value1 then
		cost = config.value1[1]
	end
    return cost
end

function CycleActivityProxy:GetSevenTwoRewards(id)
    local rewards_list = {}
    local first_cannot_get_day = self:GetFirstCannotGetDay(id)
    local config = self:GetSeveLoginConfig(id)
    if config then
        for _ ,v in ipairs(config) do
            if v then
                local item = {}
                item.id = v.id or 0
                item.goods_id = v.goods_id or {}
                item.state = self:GetOneRewardState(id,v.id)
                item.first_cannot_get_day = first_cannot_get_day
                item.redpointparentid = RedPointDef.Id.Events_Seven_Login_Two
                item.type = 2--循环七日活动
                item.activity_id = CycleActivityDef.Events_Type.Seven_Login_Two
                table.insert(rewards_list,item)
            end
        end
    end
    table.sort( rewards_list, function ( a,b )

        if a.state == b.state then
            return a.id < b.id
        else
            return a.state < b.state
        end
    end )
    return rewards_list
end
function CycleActivityProxy:GetSevenRewardProgress(id)
    if not self.data.events[id] then
        return nil,nil ,nil 
    end
    local config = self:GetSeveLoginConfig(id)
    return #self.data.events[id].has_get_reward_days , #config ,#self.data.events[id].un_get_reward_days
end

function CycleActivityProxy:Send64001(id,day)

    -- 七日登录领取
    local encoder = NetEncoder.New()
    encoder:Encode("I1I1",id,day)
    self:SendMessage(64001,encoder)

end

function CycleActivityProxy:On64001(decoder)

    local result,id,day = decoder:Decode("I1I1I1")
    if result == 0 then
        local isnewhero = decoder:Decode("I1")
        local config = self:GetSeveLoginConfig(id)
        if self.data.events[id] and config then
            local rewards =config[day].goods_id or {}
            local rewardlist={}
            for _, v in ipairs(rewards) do
                if v then
                    local item={}
                    item.goodsid = v[1]
                    item.goodsnum = v[2]
                    table.insert(rewardlist,item)
                end
            end
            local depth = UILayerTool.GetNextDepth(2) --不然层级会与当前特效一样
            GameLogicTools.ShowGetItemView(rewardlist,1,function (  )
                if isnewhero == 1 then
                    GameLogicTools.ShouldShowNewHeroTipsView(rewards)
                end
                
            end)
            for k , v in ipairs(self.data.events[id].un_get_reward_days) do
                if v and v == day then
                    table.remove(self.data.events[id].un_get_reward_days,k)
                    break
                end
            end
            table.insert(self.data.events[id].has_get_reward_days,day)

            if #self.data.events[id].has_get_reward_days == #config then
                self:CycleActivityEnd(id)
                LuaLayout.Instance:CloseWidget(UIWidgetNameDef.CycleSevenLoginTypeTwoView)
            end
        end
        self:UpdateRedDot(id)
    else
        GameLogicTools.ShowErrorCode(64001,result)
    end
    self:ToNotify(self.data,CycleActivityDef.NotifyDef.Update_Seven_Login,{update = true})
end

function CycleActivityProxy:Send64002(id)

    local encoder = NetEncoder.New()
    encoder:Encode("I1",id)
    self:SendMessage(64002,encoder)

end

function CycleActivityProxy:On64002(decoder)
    local result,id = decoder:Decode("I1I1")
    if result == 0 then
        local isnewhero = decoder:Decode("I1")
        local config = self:GetSeveLoginConfig(id)
        local day = #config
        local rewards =config[day].goods_id or {}
        local rewardlist={}
        for _, v in ipairs(rewards) do
            if v then
                local item={}
                item.goodsid = v[1]
                item.goodsnum = v[2]
                table.insert(rewardlist,item)
            end
        end
        
        GameLogicTools.ShowGetItemView(rewardlist,1,function (  )
            if isnewhero == 1 then
                GameLogicTools.ShouldShowNewHeroTipsView(rewards)
            end
            
        end)
        table.insert(self.data.events[id].has_get_reward_days,day)
        self:UpdateRedDot(id)
        self:CycleActivityEnd(id)
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.CycleSevendaysCheckinView)
    else
        GameLogicTools.ShowErrorCode(64002,result)
    end
end


function CycleActivityProxy:Send64003(id ,type ,taskid)
    --九宫格领取 ，id 活动id，type格子，宝箱，taksid 领取的奖励id
    local encoder = NetEncoder.New()
    encoder:Encode("I1I1I1",id,type,taskid)
    self:SendMessage(64003,encoder)
end

function CycleActivityProxy:On64003(decoder)
    local result,id,type,taskid = decoder:Decode("I1I1I1I1")
    if result == 0 then
        local isnewhero = decoder:Decode("I1")
        local rewards = self:GetNineGridRewardList(id,type,taskid)
        local rewardlist={}
        for _, v in ipairs(rewards) do
            if v then
                local item={}
                item.goodsid = v[1]
                item.goodsnum = v[2]
                table.insert(rewardlist,item)
            end
        end
        if type == CycleActivityDef.NineGridRewardType.Grid then
            table.insert(self.data.events[id].has_get_reward_days,taskid)
        end
        GameLogicTools.ShowGetItemView(rewardlist,1,function (  )
            if isnewhero == 1 then
                GameLogicTools.ShouldShowNewHeroTipsView(rewards)
            end
            if type == CycleActivityDef.NineGridRewardType.Grid then
                self:ToNotify(self.data,CycleActivityDef.NotifyDef.Update_Seven_Login,{update = true,taskid = taskid,type = type})
            end
            
        end)
        if type == CycleActivityDef.NineGridRewardType.Box then
            local config = self:GetNineGridBoxConfig(id)
            table.insert(self.data.events[id].has_get_box_reward_id,taskid)
            if #self.data.events[id].has_get_box_reward_id == #config then
                self.data.events[id].endtime = 0
                LuaLayout.Instance:CloseWidget(UIWidgetNameDef.EventsNineBoxView)

                self:CycleActivityEnd(id)
            end
            self:ToNotify(self.data,CycleActivityDef.NotifyDef.Update_Seven_Login,{update = true,taskid = taskid,type = type})
        end
        self:UpdateNineGridRedDot(id)
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.NineBoxtaskView)
    else
        if result == 6 then
            --提示活动关闭
            GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord(CycleActivityDef.CommonDef.Nine_Grid_Tips3))
        else
            GameLogicTools.ShowErrorCode(64003,result)
        end
        
    end
end

function CycleActivityProxy:Send64004(id ,taskid)
    --钻石购买
    local encoder = NetEncoder.New()
    encoder:Encode("I1I1",id,taskid)
    self:SendMessage(64004,encoder)
end

function CycleActivityProxy:CycleActivityEnd(id)
    local activeCfg = ModuleManager.GetActivityConfig()
    local index = 0
    for _ , v in ipairs(activeCfg) do
        local parama = v.parama
        if parama and parama[1] and parama[2]then
            if parama[1] == AppFacade.CycleActivity then
                if parama[2] == id then
                    index = v.index
                    break
                end
            end
        end
    end
    self:ToNotify(self.data,CycleActivityDef.NotifyDef.CycleActivityEnd,{index = index})
end

function CycleActivityProxy:On64004(decoder)
    local result,id,taskid = decoder:Decode("I1I1I1")
    if result == 0 then
        if id == CycleActivityDef.Events_Type.Seven_Login_One then
            local new_hero_list = decoder:DecodeList("I4")
            local days = decoder:DecodeList("I1")
            local config = self:GetSeveLoginConfig(id)
            if self.data.events[id] and config then
                local rewardlist={}
                for _ ,day in ipairs(days) do
                    local rewards =config[day].goods_id or {}
                    for _, v in ipairs(rewards) do
                        if v then
                            local item={}
                            item.goodsid = v[1]
                            item.goodsnum = v[2]
                            table.insert(rewardlist,item)
                        end
                    end

                    for k , v in ipairs(self.data.events[id].un_get_reward_days) do
                        if v and v == day then
                            table.remove(self.data.events[id].un_get_reward_days,k)
                            break
                        end
                    end
                    table.insert(self.data.events[id].has_get_reward_days,day)
                end
                local depth = UILayerTool.GetNextDepth(2) --不然层级会与当前特效一样
                GameLogicTools.ShowGetItemView(rewardlist,1,function (  )
                    if #new_hero_list > 0 then
                        local goodslist = {}
                        for _ , goods_type_id in ipairs(new_hero_list) do
                            table.insert(goodslist,{goods_type_id,1})
                        end
                        GameLogicTools.ShouldShowNewHeroTipsView(goodslist)
                    end
                    
                end)
            end
            self:ToNotify(self.data,CycleActivityDef.NotifyDef.Update_Seven_Login,{update = true})
            self:UpdateRedDot(id)
        end
    else
        GameLogicTools.ShowErrorCode(64004,result)
    end
end

return CycleActivityProxy