local BattleRelationItem = require "Core.Implement.UI.Class.BattleRelationItem"
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"
local GoodsItem = require "Core.Implement.UI.Class.GoodsItem"
local BattleSelectHeloPanel = require "Modules.Battle.Select.BattleSelectHeloPanel"
local AudioManager = require "Common.Mgr.Audio.AudioManager"
local HeroProxy = require "Modules.Hero.HeroProxy"
local BagProxy = require "Modules.Bag.BagProxy"
local EquipProxy = require "Modules.Equip.EquipProxy"
local TowerProxy = require "Modules.Tower.TowerProxy"
local NewbieWidget = require "Core.Implement.UI.Widgets.NewbieWidget"
local ObjPoolRender = require "Core.Implement.UI.Class.ObjPoolRender"
local ObjPoolItem = require "Core.Implement.UI.Class.ObjPoolItem"
local BattleSelectViewFormationPanel = require "Modules.Battle.Select.BattleSelectViewFormationPanel"
local FormationProxy = require "Modules.Formation.FormationProxy"
local RoleInfoDef = require "Modules.RoleInfo.RoleInfoDef"
local BattleDef = require "Modules.Battle.BattleDef"
local MercenaryProxy = require "Modules.Mercenary.MercenaryProxy"
local MercenaryDef = require "Modules.Mercenary.MercenaryDef"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local BattleProxy = require "Modules.Battle.BattleProxy"

local BattleSelectHeroItemPanel = BattleSelectHeroItemPanel or BaseClass(GameObjFactor, NewbieWidget)

function BattleSelectHeroItemPanel:__init(obj)
	self.go = obj
	self:InitUI()
end

function BattleSelectHeroItemPanel:InitUI()
	self.relationTopObj = self:GetChild(self.go, "RelationTop")

	self.leftHeroItemObj = self:GetChild(self.go, "Skill_left")
	self.rightHeroListObj = self:GetChild(self.go, "right")
	self.topPanelObj = self:GetChild(self.go, "TopPanel")
	self.bottomObj = self:GetChild(self.go, "bottom")
	self.titleObj=self:GetChild(self.topPanelObj,"title")
	self.relation1Obj = self:GetChild(self.go, "Relation1")
	self.bTitltObjActive=false

	self.rightTeamObj = self:GetChild(self.go, "right_team")
	self.battleSelectViewFormationPanel = BattleSelectViewFormationPanel.New(self.rightTeamObj)
	self.battleSelectViewFormationPanel:AddCallBack(function(bselect, formation_count, formations, index, bselectHero, replaceRoleIdDic)
		self:OnTeamClickItem(bselect, formation_count, formations, index, bselectHero, replaceRoleIdDic)
	end)
	self.bShowTeam = false
	self.teamBtn = self:GetChildComponent(self.bottomObj, "CButton_team", "CButton")
	self.teamSp = self:GetChildComponent(self.teamBtn.gameObject, "sprite1", "CSprite")
	self.showTeamEffect = UIEffectItem.New("UI_Battle_team", self.teamSp.gameObject)
	self.showTeamEffect:Close()
	self.showTeamEffect:SetLocalPosition(30, -15)
	-- self.teamBtn:AddClick(function ()	
	-- 	if not self.bShowTeam then	
	-- 		self:ShowTeamObj()
	-- 	else
	-- 		self:ReShowHeroList()
	-- 	end
	-- end)	

	self.heroListPanel = BattleSelectHeloPanel.New(self.rightHeroListObj)
	self.heroListPanel:AddPoolItemClickFunc(function(class, index, state)
		self:OnClickPoolIdx(class, index, state)
	end)

	self.heroListPanel:AddRaceItemClickFunc(function(index)
		self:OnClickRace(index)
	end)

	--left
	self.leftEffectList = {}
	self.leftItemList = {}
	self.leftStandObjList = {}
	self.leftStandCopyList = {}
	self.leftSelectStandObjList = {}
	for i=1,5 do
		local item = {}
		local itemObj = self:GetChild(self.leftHeroItemObj, "CButton_hero"..i)
		self:InitHeroItem(item, itemObj, i)
		local drag = self:GetComponent(itemObj, "CDrag")
		drag:AddBeginDrag(function (data)
			if self.args.lockHero then
				GameLogicTools.ShowMsgTips("MainlineMultiple_1003")
				return
			end
			self:OnDragStart(data, item)
		end)
		drag:AddEndDrag(function (data)
			self:OnDragEnd(data, item)
		end)
		drag:AddDrag(function (data)
			self:OnDrag(data, item)
		end)
		item.drag = drag		
		item.targetSp = self:GetChildComponent(itemObj, "sprite", "CSprite")
		self.leftItemList[i] = item
			
		local btn = self:GetChildComponent(itemObj, "sprite", "CButton")
		item.btn = btn
		btn:AddClick(function ()
			if self.args.lockHero then
				GameLogicTools.ShowMsgTips("MainlineMultiple_1003")
				return
			end
			if not item.isNewbieItem then
				if item.isLeaveFormationNewbie then
					item.drag.dragAble = true
					self:ResetLeftCopyItemDepth(0)
					self:BtnClick(item.itemBtn)
				end
					
				if self.bshow_artifact then
					if item.artifactId > 0 then
						local ArtifactInfoView = require "Modules.Equip.ArtifactInfoView"
						local parama = {goodsId = item.artifactId, goodsTypeId = item.artifactGoodsId,
							goodsCount = 1, goodsEnhanceGrade = item.artifactGrade, heroTypeId = item.herocfgid, heroUid = item.heroid}
						ArtifactInfoView.ShowView(parama)
					else
						local languageKey = "unity_tips_1020"
						GameLogicTools.ShowMsgTips(self:GetWord(languageKey))
					end
				else
					self:OnClickItem(item)
				end
			end
		end)

		self.leftStandObjList[i] = self:GetChild(self.leftHeroItemObj, string.format("position/%s/sprite", i))
		self.leftStandCopyList[i] = self:GetChild(self.leftHeroItemObj, string.format("position/%s/spriteCopy", i))
		self.leftSelectStandObjList[i] = self:GetChild(self.leftHeroItemObj, string.format("position/%s/sprite_select", i))
		self.leftEffectList[i] = UIEffectItem.New("UI_Battle_skill1", self.leftStandObjList[i])
	end

	--下阵
	self.clearBtn = self:GetChildComponent(self.bottomObj, "CButton_off", "CButton")
	self.clearBtn:AddClick(function()
		if self.args.lockHero then
			GameLogicTools.ShowMsgTips("MainlineMultiple_1003")
			return
		end
		if self.clearBtnCallBack then
			self.clearBtnCallBack()
		else
			self:OnClickClearBtn()
		end
	end)

	--上阵
	self.defaultBtn = self:GetChildComponent(self.bottomObj, "CButton_on", "CButton")
	self.defaultBtn:AddClick(function()
		if self.args.lockHero then
			GameLogicTools.ShowMsgTips("MainlineMultiple_1003")
			return
		end
		if self.defaultInfos then
			
			if self.args and self.args.callback then
				self.args.callback(2)
			end
			self:InitItemInfo(self.defaultInfos)
			self:ShowTeamView()
			self:UpdateFormationTeamInfo()
			self.heroListPanel:UpdateHeroItemExecuteMethod("SetState", self.leftItemList)
		end
	end)

	self.leftRelationItem = BattleRelationItem.New(self:GetChild(self.relation1Obj, "fillnew1"), CAMP.BLUE, 1, self.relationTopObj)

	self.relationBtn_1 = self:GetChildComponent(self.relation1Obj, "fillnew1", "CButton")
	self.relationBtn_1:AddClick(function()
		self:OnClickRelation(self.leftItemList)
	end)

	self.leftFightLbl = self:GetChildComponent(self.topPanelObj, "jiban1/power/COutline_num", "CImageLabel")
end

function BattleSelectHeroItemPanel:AddClearBtnCallBack(func)
	self.clearBtnCallBack = func
end

function BattleSelectHeroItemPanel:OnClickClearBtn()
	self:ClearTeam()
	self.heroListPanel:UpdateHeroItemExecuteMethod("SetState", self.leftItemList)
	if self.args and self.args.callback then
		self.args.callback(3)
	end
end

function BattleSelectHeroItemPanel:GetLeftFormation()
	local defaultinfos = {}
	local formation_count = 0
	local formations = {}
	for i,item in ipairs(self.leftItemList) do
		if item.heroid > 0 and item.index > 0 then
			formations[item.index] = item.heroid
			formation_count = formation_count + 1
		end
		table.insert(defaultinfos, item.heroid > 0 and item.heroid or 0)
	end
	return formation_count, formations, defaultinfos
end

function BattleSelectHeroItemPanel:InitHeroItem(item, obj, index)
	item.obj = obj
	item.localPosition = obj.transform.localPosition
	item.heroid = 0
	item.herocfgid = 0
	item.index = index
	
	--神器相关
	item.bartifact = false
	item.artifactId = 0
	item.artifactGoodsId = 0
	item.artifactGrade = 0

	item.itemBtn = self:GetComponent(obj, "CButton")
	item.lvLbl = self:GetChildComponent(obj, "lv", "CLabel")
	item.headTex = self:GetChildComponent(obj, "Viewport/CTexture_head", "CTexture")
	item.raceSp = self:GetChildComponent(obj, "CSprite_race", "CSprite")
	-- item.rankBackTex = self:GetChildComponent(obj, "sprite", "CTexture")
	-- item.rankFrameTex = self:GetChildComponent(obj, "frame", "CTexture")
	
	item.rankFrameSp = self:GetChildComponent(obj, "frame", "CSprite")
	item.rankFramePlusSp1 = self:GetChildComponent(item.rankFrameSp.gameObject, "CSprite_1", "CSprite")
	item.rankFramePlusSp2 = self:GetChildComponent(item.rankFrameSp.gameObject, "CSprite_2", "CSprite")
	item.rankBackSp = self:GetChildComponent(obj, "sprite", "CSprite")
	item.raceBackSp = self:GetChildComponent(obj, "CSprite_raceback", "CSprite")

	item.exclusiveSp = self:GetChildComponent(obj, "CSprite_Sig", "CSprite")
	item.starObj = self:GetChild(obj, "star")
	item.starItem = self:GetChild(item.starObj, "CHorizontalItem/item1")

    item.starPoolRender = ObjPoolRender.New()
    item.starPoolRender:Load(item.starItem, item.starItem.transform.parent, ObjPoolItem)	

    item.artifactBack = self:GetChild(obj, "GoodsItemblack")
	item.artifactObj = self:GetChild(obj, "GoodsItem")
	item.artifactClass = GoodsItem.New(item.artifactObj)

	--雇佣兵相关
	item.bhireHero = false
	item.hireFriendHeroObj = self:GetChild(obj, "hireHeroObj")
	item.hireFriendHeroObj:SetActive(false)
	item.hireName = self:GetChildComponent(item.hireFriendHeroObj, "CSprite_sex/CLabel_nickname", "CLabel")
	item.hireOtherHeroObj = self:GetChild(obj, "hiresystemHeroObj")
	if item.hireOtherHeroObj then
		item.hireOtherHeroObj:SetActive(false)
	end
end

function BattleSelectHeroItemPanel:Close()
	self.heroListPanel:Close()
	self.leftRelationItem:Close()
	if self.bTitltObjActive then
		self.bTitltObjActive=false
		self.titleObj:SetActive(true)
	end
	self.battleSelectViewFormationPanel:Close()
	self.clearBtnCallBack = false
	self:StopHeroSound()
	
	self.showTeamEffect:Close()
end

function BattleSelectHeroItemPanel:Destroy()
	self.heroListPanel:Destroy()
	self.leftRelationItem:Destroy()

	for _, effect in pairs(self.leftEffectList) do
		effect:Destroy()
	end
	self.battleSelectViewFormationPanel:Destroy()
	self.clearBtnCallBack = false
	self:StopHeroSound()
end

function BattleSelectHeroItemPanel:OnDragStart(data, item)
	self.selectItem = nil
	local trans = item.obj.transform
	trans:SetAsLastSibling()
	for _, leftitem in pairs(self.leftItemList) do
		-- leftitem.targetSp.raycastTarget = item.index == leftitem.index and true or false
		leftitem.targetSp.raycastTarget = false
	end	
	AudioManager.PlaySoundByKey("battleselecttip_view")

	if item.isNewbieItem then
		local bPosNewbie = self:IsHeroPositionNewbie()
		if bPosNewbie then
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.NewbieDialogView)
			if view and view:IsOpen() then
				view:SetObjActive(false)
			end
		end
	end
end
	
function BattleSelectHeroItemPanel:OnDrag(data, item)
	local selectItem = nil
	for idx, targetObj in pairs(self.leftStandObjList) do
		if targetObj == data.pointerEnter or self.leftStandCopyList[idx] == data.pointerEnter then
			selectItem = self.leftItemList[idx]
			self.leftSelectStandObjList[idx]:SetActive(true)
		else
			self.leftSelectStandObjList[idx]:SetActive(false)
		end	
	end
	
	if selectItem then
		if selectItem ~= self.selectItem then
			if self.selectItem then
				self.selectItem.obj.transform.localPosition = self.selectItem.localPosition
			end	
			selectItem.obj.transform.localPosition = item.localPosition
		end
	else
		if self.selectItem then
			self.selectItem.obj.transform.localPosition = self.selectItem.localPosition
		end					
	end	
	self.selectItem = selectItem
end

--英雄站位引导 代码控制
function BattleSelectHeroItemPanel:IsHeroPositionNewbie()
	local bNewbie = false
	local NewbieManager = require "Modules.Newbie.NewbieManager"
	local NewbieProxy = require "Modules.Newbie.NewbieProxy"
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	local cur_newbie_id = NewbieManager.Instance.curNewbieid
	local cur_newbie_step = NewbieManager.Instance.curStep
	if NewbieDef.SelectHeroPosTrigger[cur_newbie_id] and
		cur_newbie_step == NewbieDef.SelectHeroPosTrigger[cur_newbie_id] then
			bNewbie = true
	end
	return bNewbie
end
--英雄站位引导 代码控制
function BattleSelectHeroItemPanel:AutoHandleHeroPosNewbie(item)
	local bNewbie = self:IsHeroPositionNewbie()
	if bNewbie then
		self:ResetLeftCopyItemDepth(0)
		if item.isNewbieItem then
			self:SetDepth(item.obj, 0)
			self:BtnClick(item.itemBtn)
		end	
	end
end

--tuodrag
function BattleSelectHeroItemPanel:OnDragEnd(data, item)
	self:AutoHandleHeroPosNewbie(item)

	local trans = item.obj.transform
	trans.localPosition = item.localPosition
	for idx, leftitem in pairs(self.leftItemList) do
		leftitem.targetSp.raycastTarget = true
		self.leftSelectStandObjList[idx]:SetActive(false)
	end	

	if self.selectItem then
		self.selectItem.obj.transform.localPosition = self.selectItem.localPosition

		local selectHeroid = self.selectItem.heroid
		local configid = self.selectItem.herocfgid

		self.selectItem.heroid = item.heroid
		self.selectItem.herocfgid = item.herocfgid
		item.heroid = selectHeroid
		item.herocfgid = configid

		self:UpdateTeamInfo(self.selectItem, self.selectItem.heroid)
		self:UpdateTeamInfo(item, selectHeroid)
		self:UpdateFormationTeamInfo()
		if self.leftEffectList[self.selectItem.index] then
			self.leftEffectList[self.selectItem.index]:Play()
		end	

		self.selectItem = nil
		AudioManager.PlaySoundByKey("battleselecttop_view")
	end	

end

function BattleSelectHeroItemPanel:OnClickPoolIdx(class, index, state)
	--print("index============", index, state)
	if state == 0 then
		for idx, item in ipairs(self.leftItemList) do
			if item.heroid == 0 then
				item.heroid = class.data.herouid
				item.herocfgid = class.cfg.id
				self:PlayHeroSound(item.herocfgid) --播放英雄语音
				self:UpdateTeamInfo(item, item.heroid)

				self.heroListPanel:UpdateHeroItemExecuteMethod("SetState", self.leftItemList)
				if self.args and self.args.callback then
					self.args.callback(nil)
				end
				if self.leftEffectList[idx] then
					self.leftEffectList[idx]:Play()
				end
				self:UpdateFormationTeamInfo()
				return
			end	
		end
		GameLogicTools.ShowMsgTips("msgtips_battle_1003")
	elseif state == 1 then
		for idx, item in ipairs(self.leftItemList) do
			if item.heroid == class.data.herouid then
				item.heroid = 0
				item.herocfgid = 0
				self:StopHeroSound()
				self:UpdateTeamInfo(item, item.heroid)
			end	
		end
		self:UpdateFormationTeamInfo()
		self.heroListPanel:UpdateHeroItemExecuteMethod("SetState", self.leftItemList)
		if self.args and self.args.callback then
			self.args.callback(nil)
		end
	elseif state == 2 then
		if class.data.hireHeroState == 1 then
			local str = MercenaryProxy.Instance:Update_Reflesh_HireHero_Time()
			GameLogicTools.ShowMsgTips(str)
		elseif class.data.hireHeroState == 2 then
			GameLogicTools.ShowMsgTips(MercenaryDef.LanguageKey.MercenaryKey7)
		else
			if not self:CheckSwapTeam(class, index) then
				GameLogicTools.ShowMsgTips("msgtips_battle_1004")
			end
		end
	end
end

function BattleSelectHeroItemPanel:CheckSwapTeam(class, index)
	local otherTeamList, herouid_map, roleid_map = self:GetOtherTeamList()
	if #otherTeamList > 0 then
		local hero = herouid_map[class.data.herouid]
		if not hero then
			hero = roleid_map[class.data.roleid]
		end
		if hero and (not hero.pass) then
			if self:IsFullTeam() then
				GameLogicTools.ShowMsgTips("msgtips_battle_1003")
			else
				local cfg = self:_GetHeroCfgByUid(hero.heroid)
				if cfg then
					GameLogicTools.ShowConfirmById2(53, function(bvalue)
						if bvalue then
							self:RemoveTeamHero(hero)
							self:OnClickPoolIdx(class, index, 0)
						end
					end, LanguageManager.Instance:GetWord(cfg.name), hero.teamid)
				end
				--GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord("MainlineMultiple_1002", hero.teamid))
			end
			return true
		end
	end
	return false
end

function BattleSelectHeroItemPanel:IsFullTeam()
	for idx, item in ipairs(self.leftItemList) do
		if item.heroid == 0 then
			return false
		end
	end
	return true
end

function BattleSelectHeroItemPanel:OnClickRace(index)
	self:ShowHeroList(index)
end

function BattleSelectHeroItemPanel:OnClickItem(item)
	item.heroid = 0
	item.herocfgid = 0
	self:StopHeroSound()
	self:UpdateTeamInfo(item, item.heroid)
	self.heroListPanel:UpdateHeroItemExecuteMethod("SetState", self.leftItemList)	
	if self.args and self.args.callback then
		self.args.callback(nil)
	end
	self:UpdateFormationTeamInfo()
end

function BattleSelectHeroItemPanel:OnClickRelation(itemlist)
	local list = {}
	for idx, item in pairs(itemlist) do
		if item.herocfgid ~= 0 then
			table.insert(list, item.herocfgid)
		end 
	end
	UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 3, list, CAMP.BLUE)
end

--设置初始数据  defaultinfos:左侧默认上阵数据{heroid = 0, herocfgid = 0}   heroinfos:右侧英雄列表数据  activityid :玩法id  args:玩法相关参数
function BattleSelectHeroItemPanel:Open(defaultinfos, heroinfos, activityid, args)
	self.rune_rate = 0
	self.bShowTeam = false
	self.rightHeroListObj:SetActive(true)
	self.rightTeamObj:SetActive(false)
	self.teamSp.SpriteName = "biandui1"
	self.heroListPanel:Open(args)
	self:SetDefaultData(defaultinfos, heroinfos, activityid, args)
	self:InitItemInfo(self.defaultInfos)
	self:ShowTeamView()
	self:SetRaceInfo()
	self:SpecialHandle(activityid)
end

--监听英雄升级用
function BattleSelectHeroItemPanel:UpdateHeroInfoByLevelUp(args)
	if args and args.herouid then
		for k,info in ipairs(self.heroInfos) do
			if info.fromuid == args.herouid then
				info.level = args.level
				break
			end
		end
	end
	--更新右侧英雄列表
	self:ShowHeroList(self.select_race)
	--更新左侧
	self:ShowTeamView()
	--更新战力
end

--监听共鸣水晶改变用
function BattleSelectHeroItemPanel:UpdateHeroInfoByCrystalLevelUp(data)
	local target_level = data.crystaldata.level
	local bchange = false
	for k,info in ipairs(self.heroInfos) do
		if info.crystalLevel then
			if target_level == info.crystalLevel then
				break
			else
				info.crystalLevel = target_level
				bchange = true
			end
		end
	end
	-- 所有共鸣水晶的改变都会更新过来,不一定是水晶升级所以需区分一下
	if bchange then
		--更新右侧英雄列表
		self:ShowHeroList(self.select_race)
		--更新左侧
		self:ShowTeamView()
	end
end

--监听装备改变用
function BattleSelectHeroItemPanel:UpdateHeroInfoByEquip(args)

	local changeEquip = function (equips,heroinfo)
		heroinfo.equips = {}
		for i,v in pairs(equips) do
			local pos = v[1]
			local equipid = v[2]
			local equipInfo = BagProxy.Instance:GetGoodsInfoById(equipid)
			if equipInfo then
				table.insert(heroinfo.equips,{equipInfo.goodsTypeId , equipInfo.goodsEnhanceGrade})
			end

			-- 必须是有序表 因为要用于协议传输(decodeList)
			-- if equipInfo then
			-- 	heroinfo.equips[pos] = heroinfo.equips[pos] or {}
			-- 	heroinfo.equips[pos][1] = equipInfo.goodsTypeId
			-- 	heroinfo.equips[pos][2] = equipInfo.goodsEnhanceGrade
			-- end
		end
	end

	if args and args.herouid then
		for k,info in ipairs(self.heroInfos) do
			if info.fromuid == args.herouid then
				changeEquip(args.equips, info)
				break
			end
		end
	end

	if args and args.goodsId then
		local equipInfo = BagProxy.Instance:GetGoodsInfoById(args.goodsId)
		if equipInfo and equipInfo.equippedHeroId then
			for k,info in ipairs(self.heroInfos) do
				if info.fromuid == equipInfo.equippedHeroId then
					local rawHeroData = HeroProxy.Instance:GetHeroDataByUid(info.fromuid)
					changeEquip(rawHeroData.equips, info)
					break
				end
			end
		end
	end
	--更新右侧英雄列表
	--self:ShowHeroList(self.select_race)
	--更新左侧
	self:ShowTeamView()
	--更新战力
end

--高级竞技场打开编队列表时 切换下一队
function BattleSelectHeroItemPanel:ArenaChangeTeam(defaultinfos, heroinfos, activityid, args)
	self:SetDefaultData(defaultinfos, heroinfos, activityid, args)
	self:InitItemInfo(self.defaultInfos)
	self:ShowTeamView()
	self:SpecialHandle(activityid)
end

function BattleSelectHeroItemPanel:ResetData(defaultinfos)
	self.leftRelationItem:Close()
	self:SetDefaultData(defaultinfos, self.heroInfos, self.activityId, self.args)
end

function BattleSelectHeroItemPanel:SpecialHandle(activityid)
	if activityid == ACTIVITYID.ARENA or activityid == ACTIVITYID.HIGHARENA then
		if self.titleObj.activeSelf then
			self.bTitltObjActive=true
			self.titleObj:SetActive(false)
		end
	else
		self.bTitltObjActive=false
	end
end

function BattleSelectHeroItemPanel:GetActivityIdAndSubType()
	local activityId, subtype = self.activityId, 0
	if activityId == ACTIVITYID.TOWER then
		local cfg = TowerProxy.Instance:GetTowerCfgById(self.args[2])
		if cfg then 
			subtype = cfg.type
		end
	end
	return activityId, subtype
end

--过滤不需要上阵的雇佣英雄(hireFriendHeroNum为多队推图编队过滤)
function BattleSelectHeroItemPanel:FilterHireHero(defaultinfos, hireFriendHeroNum)
	local _defaultinfos = {0,0,0,0,0}
	for i,v in ipairs(_defaultinfos) do
		if not defaultinfos[i] then
			defaultinfos[i] = v
		end
	end

	local activityId, subtype = self:GetActivityIdAndSubType()
	
	local canHireFriendHeroNum = MercenaryProxy.Instance:GetHireHeroCanBattleNum(activityId, subtype)
	local nowHireFriendHeroNum = hireFriendHeroNum and hireFriendHeroNum or 0
	for i,value in ipairs(defaultinfos) do
		local herodata = self:_GetHeroDataByUid(value)
		if herodata then
			if herodata.hire_hero_type == BattleDef.Hire_Hero_Type.Hire_Hero then
				local isFriendHireHero = MercenaryProxy.Instance:CheckIsHireHero(herodata.fromuid or herodata.herouid)
				if isFriendHireHero then
					if(canHireFriendHeroNum > nowHireFriendHeroNum) then
						nowHireFriendHeroNum = nowHireFriendHeroNum + 1
						_defaultinfos[i] = value
					end
				else
					_defaultinfos[i] = value
				end
			else
				_defaultinfos[i] = value
			end
		end
	end
	return _defaultinfos
end

function BattleSelectHeroItemPanel:SetDefaultData(defaultinfos, heroinfos, activityid, args, bshow_artifact)
	defaultinfos = defaultinfos or {0,0,0,0,0}
	self.heroInfos = heroinfos or {}
	--print("self.heroInfos===", table.dump(self.heroInfos))
	self.activityId = activityid or 0 
	self.args = args or {}
	self.bshow_artifact = bshow_artifact or false
	self.defaultInfos = self:FilterHireHero(defaultinfos)
	self.heroListPanel:ClearData()
end

function BattleSelectHeroItemPanel:ShowTeamObj()
	self.bShowTeam = true
	self.rightTeamObj:SetActive(self.bShowTeam)
	self.rightHeroListObj:SetActive(self.bShowTeam == false and true or false)
	self:ChangeTeamSpState(self.bShowTeam)
	FormationProxy.Instance:Send20400()
end

function BattleSelectHeroItemPanel:ReShowHeroList()
	self.bShowTeam = false
	self.battleSelectViewFormationPanel:Close()
	self.rightTeamObj:SetActive(self.bShowTeam)
	self.rightHeroListObj:SetActive(self.bShowTeam == false and true or false)
	self:ChangeTeamSpState(self.bShowTeam)
	local formation_count, formationdic, defaultinfos = self:GetLeftFormation()
	self.rune_rate = 0
	self:SetDefaultData(defaultinfos, self.heroInfos, self.activityId, self.args)
	self:SetRaceInfo()
	self:SpecialHandle(self.activityId)
end

function BattleSelectHeroItemPanel:ChangeTeamSpState(bShowTeam)
	if bShowTeam then
		self.teamSp.SpriteName = "biandui2"
		self.showTeamEffect:Open()
	else
		self.teamSp.SpriteName = "biandui1"
		self.showTeamEffect:Close()
	end
end

function BattleSelectHeroItemPanel:UpdateFormationInfo(notTween)
	if self.bShowTeam == true then
		local formation_count, formationdic = self:GetLeftFormation()
		local formationInfos = FormationProxy.Instance:GetFormationInfos()
		self.battleSelectViewFormationPanel:Open(formation_count, formationdic, formationInfos, self.heroInfos, notTween, self.activityId , self.towerType, self.getOtherTeamList)
	end
end

function BattleSelectHeroItemPanel:UpdateItemName(index, name)
	self.battleSelectViewFormationPanel:UpdateItemName(index, name)
end

-- type :1普通编队  2 特殊编队
function BattleSelectHeroItemPanel:OnTeamClickItem(bselect, formation_count, formations, index, bselectHero, replaceRoleIdDic)
	if bselect then return end
	if self.args.lockHero then
		GameLogicTools.ShowMsgTips("MainlineMultiple_1003")
		return
	end
	
	local _func = function(new_formations)
		if self.activityId == ACTIVITYID.HIGHARENA or self.activityId == ACTIVITYID.ARENA then
			--竞技场有上阵过英雄
			local ArenaProxy = require "Modules.Arena.ArenaProxy"
			ArenaProxy.Instance:ReplaceProArenaFormations(replaceRoleIdDic)
		end
		
		local formations = self:FilterHireHero(new_formations)
		local defaultInfos = {}
		local effectIdxs = {}
		for i=1,5 do
			table.insert(defaultInfos, formations[i] ~= nil and formations[i] or 0)
			if formations[i] then
				table.insert(effectIdxs, i)
			end
		end
		self.defaultInfos = defaultInfos
		self:InitItemInfo(self.defaultInfos)
		self:ShowTeamView()

		for i,idx in ipairs(effectIdxs) do
			if self.leftEffectList[idx] then
				self.leftEffectList[idx]:Close()
				self.leftEffectList[idx]:Play()
			end
		end
		self:UpdateFormationTeamInfo(index)
	end

	if self.activityId == ACTIVITYID.TOWER and self.towerType and self.towerType ~= 0 then
		if not self:CheckTowerFormationTeam(formations) then
			GameLogicTools.ShowMsgTips(self:GetWord("TowerFaction_1001"))
			return
		end
	end

	if not self:CheckReplaceOtherTeam(formations, _func) then
		if bselectHero then 
			GameLogicTools.ShowConfirmById(33, function(bValue)
				if bValue then
					_func(formations)
				end
			end)
		else
			_func(formations)
		end
	end
end

--多队推图替换编队英雄
function BattleSelectHeroItemPanel:CheckReplaceOtherTeam(formations, func)
	local other_team_heros, other_team_hero_map, other_team_hero_roleid_map = self:GetOtherTeamList()
	if #other_team_heros > 0 then
		local need_to_replace = false
		local same_hero_map = {}
		for k,id in pairs(formations) do
			if id then
				local herodata = self:_GetHeroDataByUid(id)
				if herodata then
					local hero = other_team_hero_map[id]
					if not hero then
						hero = other_team_hero_roleid_map[herodata.roleid]
					end
					if hero then
						same_hero_map[k] = hero
						need_to_replace = true
					end
				end
			end
		end
		if need_to_replace then
			GameLogicTools.ShowConfirmById2(54, function(bvalue)
					self:ReplaceOtherTeam(other_team_heros, formations, same_hero_map, bvalue, func)
				end)
			--GameLogicTools.ShowMsgTips("MainlineMultiple_1007")
		end
		return need_to_replace
	end
	return false
end

--多队推图编队替换英雄
function BattleSelectHeroItemPanel:ReplaceOtherTeam(other_team_heros, formations, same_hero_map, replace_same, func)
	local formation_count, formationdic, defaultinfos = self:GetLeftFormation()
	
	local hireFriendHeroNum = 0
	for i,hero in pairs(other_team_heros) do
		if hero.bhireHero then
			local isFriendHireHero = MercenaryProxy.Instance:CheckIsHireHero(hero.fromuid or hero.heroid)
			if isFriendHireHero then
				hireFriendHeroNum = hireFriendHeroNum + 1
			end
		end
	end
	
	for i,herouid in pairs(formations) do
		local same_hero = same_hero_map[i]
		if same_hero then
			if replace_same and (not same_hero.pass) then
				self:RemoveTeamHero(same_hero)
				defaultinfos[i] = same_hero.heroid
			end
		else
			defaultinfos[i] = formations[i]
		end
	end
	
	func(self:FilterSameRoleIDHero(self:FilterHireHero(defaultinfos, hireFriendHeroNum)))
end

--检查种族塔 编队选择合法性(是否包括其他种族)
function BattleSelectHeroItemPanel:CheckTowerFormationTeam(formations)
	for stance,uid in ipairs(formations) do
		local herocfg = HeroProxy.Instance:GetHeroCfgByUid(uid)
		if herocfg and herocfg.race ~= self.towerType then
			return false
		end
	end
	return true
end

function BattleSelectHeroItemPanel:UpdateFormationTeamInfo(index)
	-- print("UpdateFormationTeamInfo=========", index, self.battleSelectViewFormationPanel:IsOpen())
	if self.battleSelectViewFormationPanel:IsOpen() then
		local formation_count, formationdic = self:GetLeftFormation()
		local formationInfos = FormationProxy.Instance:GetFormationInfos()
		self.battleSelectViewFormationPanel:SetData(formation_count, formationdic, formationInfos, self.heroInfos, index, self.activityId)
	end
end

--清除上阵信息
function BattleSelectHeroItemPanel:ClearTeam()
	for idx, item in ipairs(self.leftItemList) do
		item.heroid = 0
		item.herocfgid = 0
		self:UpdateTeamInfo(item, item.heroid)
	end		
	self:UpdateFormationTeamInfo()
end

--设置初始队伍信息, 默认上阵
function BattleSelectHeroItemPanel:InitItemInfo(defaultTeam)
	local mercenaryCount = 0 --上阵的佣兵数量

	for idx, item in ipairs(self.leftItemList) do
		item.heroid = tonumber(defaultTeam[idx])
		local cfg = self:_GetHeroCfgByUid(item.heroid)

		if cfg then
			item.herocfgid = cfg.id
		else
			item.herocfgid = 0
			item.heroid = 0
		end

		if self.activityId == ACTIVITYID.GUILD_CHAOS then --混沌裂隙处理:只能上一个佣兵
			if MercenaryProxy.Instance:CheckIsHireHero(item.heroid) then
				if mercenaryCount == 0 then
					mercenaryCount = mercenaryCount + 1
				else
					item.herocfgid = 0
					item.heroid = 0
				end
			end
		end
	end
end

--更新神器显示
function BattleSelectHeroItemPanel:ShowArtifactEquip(bshow)
	self.bshow_artifact = bshow
	self:ShowTeamView()
end

--显示队伍信息
function BattleSelectHeroItemPanel:ShowTeamView()
	for idx, item in ipairs(self.leftItemList) do
		self:UpdateTeamInfo(item, item.heroid)
	end
end

function BattleSelectHeroItemPanel:UpdateTeamInfo(item, heroid)
	local NewbieDef = require "Modules.Newbie.NewbieDef"

	if heroid and heroid ~=0 then
		local herodata = self:_GetHeroDataByUid(item.heroid)
		local rawHeroData = HeroProxy.Instance:GetHeroDataByUid(herodata.fromuid or item.heroid)
		local cfg = self:_GetHeroCfgByUid(item.heroid)
		item.obj:SetActive(true)

		item.drag.dragAble = not self.args.lockHero
		
		item.level = rawHeroData and rawHeroData.level or herodata.level
		item.fromuid = herodata.fromuid or item.heroid

		item.tree_info = herodata.tree_info

		item.crystalLevel = rawHeroData and rawHeroData.crystalLevel or herodata.crystalLevel
		
		if self.activityId == ACTIVITYID.GUILD_CHAOS then
			local GuildProxy = require "Modules.Guild.GuildProxy"
			local chaosRoomLv = GuildProxy.Instance:GetChaosRoomLv(false)
			item.lvLbl.text = string.format("<color=#5bd494>%s</color>", LanguageManager.Instance:GetWord("Common_1001", chaosRoomLv))
		else
			item.lvLbl.text = HeroProxy.Instance:GetHeroLevelString(nil, nil, item.crystalLevel or item.level)
		end
		
		item.raceSp.SpriteName = string.format("zhenying_%s", cfg.race)			
		item.rank = herodata.rank

		local rankinfo = HeroProxy.Instance:GetRankInfoCfgById(item.rank)
		local ColorTools = require "Common.Util.ColorTools"
		item.raceBackSp.color = ColorTools.RichText2Color(rankinfo.raceback1)
		
		item.rankBackSp.SpriteName = rankinfo.skillframe
		
		if rankinfo.skillangle then
			item.rankFrameSp.gameObject:SetActive(true)
			item.rankFrameSp.SpriteName = rankinfo.skillangle or ""
			-- item.rankFramePlusSp1.SpriteName = rankinfo.frameangle or ""
			-- item.rankFramePlusSp2.SpriteName = rankinfo.frameangle or ""
		else
			item.rankFrameSp.gameObject:SetActive(false)
		end

		local spritecfg = HeroProxy.Instance:GetSpriteConfigeById(cfg.id)
		AssetManager.LoadUITexture(AssetManager.UITexture.HeroPk, spritecfg.prefab_id[1], item.headTex)

		item.starObj:SetActive(true)
		item.starPoolRender:ReleaseAll()
		item.starObj:SetActive(rankinfo.star > 0 and true or false)
		for i=1,rankinfo.star do
			item.starPoolRender:Get({})
		end

		--暂时没有equips数据，通过uid 英雄列表查找
		local _herodata = HeroProxy.Instance:GetHeroDataByUid(herodata.fromuid or item.heroid)
		local _equips = nil
		if _herodata and _herodata.equips then
			_equips = _herodata.equips
		end
		--专属装备外框
		item.exclusiveSp.gameObject:SetActive(false)
		local exclusiveId = EquipProxy.Instance:GetExclusiveEquipGoodsId(_equips)
		if exclusiveId then
			local cfg = BagProxy.Instance:GetGoodsCfgById(exclusiveId)
			if cfg then
				local equipRankCfg = EquipProxy.Instance:GetEquipQualityColorByQuality(cfg.quality)
				if equipRankCfg and equipRankCfg.exclusivesig and item.exclusiveSp then
					item.exclusiveSp.gameObject:SetActive(true)
					item.exclusiveSp.SpriteName = string.format("zhuanshu%d", equipRankCfg.exclusivesig)
				end
			end	
		end	

		item.artifactObj:SetActive(false)
		item.artifactBack:SetActive(false)
		item.bartifact = false
		item.artifactId = 0
		item.artifactGoodsId = 0
		item.artifactGrade = 0
		local artifactId = EquipProxy.Instance:GetArtifactEquip(_equips)
		if self.bshow_artifact and artifactId then
			local infos = BagProxy.Instance:GetItemByID(artifactId)
			if infos then
				item.bartifact = true
				item.artifactId = artifactId
				item.artifactGoodsId = infos.goodsTypeId
				item.artifactGrade = infos.goodsEnhanceGrade
				item.artifactObj:SetActive(true)
				item.artifactBack:SetActive(true)
				local info = EquipProxy.Instance:ConstructionArtifactItemInfo(nil, infos.goodsTypeId, nil, infos.goodsEnhanceGrade)
				local goodsInfo = {infos.goodsTypeId, nil, info}
				item.artifactClass:SetData(table.unpack(goodsInfo))
			end
		end
		
		local roleid, newbie_id, newbie_step = self:RegisterHeroNewbieData(NewbieDef.SelectHeroPosTrigger)
		local depth = roleid ~= nil and NewbieDef.NewbieDepths.NewbieBtn or 0
		self:ResetLeftCopyItemDepth(depth)
		
		item.isNewbieItem = false
		if roleid == herodata.roleid then
			item.isNewbieItem = true
			self:RegisterButton(item.itemBtn, newbie_id, newbie_step)
		end
		
		item.isLeaveFormationNewbie = false
		if not item.isNewbieItem then
			roleid, newbie_id, newbie_step = self:RegisterHeroNewbieData(NewbieDef.SelectFormationHeroTrigger)
			self:ResetLeftCopyItemDepth(roleid ~= nil and NewbieDef.NewbieDepths.NewbieBtn or depth)
			if roleid == herodata.roleid then
				item.isLeaveFormationNewbie = true
				item.drag.dragAble = false
				self:RegisterButton(item.itemBtn, newbie_id, newbie_step)
			end
		end

		--雇佣兵相关
		item.bhireHero = herodata.hire_hero_type == BattleDef.Hire_Hero_Type.Hire_Hero and true or false
		local friendHireHero = MercenaryProxy.Instance:CheckIsHireHero(item.fromuid)
		item.hireFriendHeroObj:SetActive(item.bhireHero and friendHireHero)
		if item.hireOtherHeroObj then
			item.hireOtherHeroObj:SetActive(item.bhireHero and (not friendHireHero))
		end
		if item.bhireHero then
			item.hireName.text = herodata.nickname
			-- item.hireSex.SpriteName = RoleInfoDef.SexSpriteName[herodata.sex]
		end
	else		
		item.isNewbieItem = false
		item.isLeaveFormationNewbie = false
		item.obj:SetActive(false)
		self:ResetLeftCopyItemDepth(0)
	end

	self:SetRelationInfo(self.leftRelationItem, self.leftItemList, self.leftFightLbl)
	
	self:IsShowRedDot()
	for idx, item in ipairs(self.leftItemList) do
		if item.heroid ~= 0 then
			self.clearBtn.gameObject:SetActive(true)
			self.defaultBtn.gameObject:SetActive(false)
			return
		end	
	end	
	self.clearBtn.gameObject:SetActive(false)
	self.defaultBtn.gameObject:SetActive(true)
end

function BattleSelectHeroItemPanel:ResetLeftCopyItemDepth(depth)
	for idx,obj in pairs(self.leftStandCopyList) do
		self:SetDepth(obj, depth)
	end
end

function BattleSelectHeroItemPanel:SetRelationInfo(relationItem, itemlist, fightLbl)	
	local herodatas, list = self:GetSelectHeroDataList(itemlist)
	relationItem:SetData(list)
	-- print("BattleSelectHeroItemPanel:SetRelationInfo", table.dump(herodatas))
	local fightstr, fight = HeroProxy.Instance:GetHeroFight(herodatas, true)
	--迷宫符文百分比
	fight = fight * (1 + self.rune_rate)

	fightLbl.Text = GameLogicTools.GetNumStr(fight)
end

function BattleSelectHeroItemPanel:GetSelectHeroDataList(itemlist)
	local list = {}
	local herodatas = {}
	for idx, item in pairs(itemlist) do
		if item.herocfgid ~= 0 then
			table.insert(list, item.herocfgid)
			local level = BattleProxy.Instance:GetHeroLv(item, self.activityId, false)
			local herodata = self:_GetHeroDataByUid(item.heroid)
			local tree_info = self:_GetHeroTreeInfo(item)
			local equips = nil
			if herodata then
				equips = herodata.equips --{equip_typeid, grade}
			end
			table.insert(herodatas, {roleid = item.herocfgid, herouid = item.heroid,  fromuid = item.fromuid, rank = item.rank or 1, level = level or 1, 
			equips=equips , tree_info = tree_info})
		end
	end
	
	return herodatas, list
end

--雇佣兵的树数据需要分情况判断，玩法雇佣兵读表，好友雇佣兵 用自己的
function BattleSelectHeroItemPanel:_GetHeroTreeInfo(item)
	if item.bhireHero then
		local role_id = item.herocfgid
		local friendHireHero = MercenaryProxy.Instance:CheckIsHireHero(item.fromuid)
		if friendHireHero then
			local TreeProxy = require "Modules.Tree.TreeProxy"
			local main_tree_lv = TreeProxy.Instance:GetTreeMainLv()
			local branch_tree_lv = TreeProxy.Instance:GetTreeBranchLvByRoleId(role_id)
			return {main_tree_lv,branch_tree_lv}
		else
			return item.tree_info
		end
	end
end

function BattleSelectHeroItemPanel:SetRuneFight(rune_rate)
	local herodatas = self:GetSelectHeroDataList(self.leftItemList)
	
	local fightstr, fight = HeroProxy.Instance:GetHeroFight(herodatas,true)
	self.rune_rate =  rune_rate/100

	local addfight = fight * self.rune_rate
	local showFight = fight + addfight
	self.leftFightLbl.Text = GameLogicTools.GetNumStr(showFight)
end

function BattleSelectHeroItemPanel:IsShowRedDot()
	local show=false
	for idx, item in ipairs(self.leftItemList) do
		if item.heroid == 0 then
			show=true
		end 
	end	
	if self.args and self.args.callback then

		local id=0
		if show then
			id=1
		end
		self.args.callback(id)
	end
end

function BattleSelectHeroItemPanel:CleartDefaultHeroData()
	self.defaultInfos = {0,0,0,0,0}
end
function BattleSelectHeroItemPanel:BackDefaultHeroData(data)
	self.defaultInfos = data
end

function BattleSelectHeroItemPanel:SetState(methodstr,list)
	self.heroListPanel:UpdateHeroItemExecuteMethod(methodstr, {list=list,leftItemList=self.leftItemList})
end

--种族显示
function BattleSelectHeroItemPanel:SetRaceInfo()
	if self.activityId == ACTIVITYID.TOWER then
		local towerCfg = TowerProxy.Instance:GetTowerCfgById(self.args[2])  --args: {enemyid, towerid}
		local towertype = towerCfg.type
		self.towerType = towertype
		self.heroListPanel:OnClickRace(towertype, towertype~=0)
	else		
		local raceIdx = self.heroListPanel:GetCurRaceIdx()
		self.heroListPanel:OnClickRace(0, false)
	end	
end

--更新右侧英雄列表
function BattleSelectHeroItemPanel:ShowHeroList(race)
	if race == 0 then race = nil end
	self.select_race = race
	local list = self:_GetHeroDataListByRace(race)
	self.heroListPanel:SetHeroListData(list, race, self.activityId)
	self.heroListPanel:UpdateHeroItemExecuteMethod("SetState", self.leftItemList)
	if self.args and self.args.callback then
		self.args.callback(nil)
	end
end


----------config------
function BattleSelectHeroItemPanel:GetBattleHeroList()
	local list = {}
	for idx, item in ipairs(self.leftItemList) do
		if item.heroid ~= 0 then
			local heroinfo = self:_GetHeroDataByUid(item.heroid)
			heroinfo.stance = idx
			table.insert(list, heroinfo)
		end 
	end	

	return list
end

function BattleSelectHeroItemPanel:GetDefaultSelectHeroList()
	local herolist = {0,0,0,0,0}
	local rolelist = {0,0,0,0,0}

	for idx, item in ipairs(self.leftItemList) do
		if self.activityId == ACTIVITYID.MAZE or self.activityId == ACTIVITYID.STORYLINE or self.activityId == ACTIVITYID.ACTIVITY then
			--迷宫血量不为0才设置
			local herodata = self:_GetHeroDataByUid(item.heroid)
			if herodata and herodata.prop then
				local active = self:GetHeroHpIsActive(herodata.prop)
				if active then
					herolist[idx] = item.heroid
				end
			end
		else
			herolist[idx] = item.heroid
		end
		rolelist[idx] = item.herocfgid
	end

	return herolist, rolelist
end

--英雄是否存活
function BattleSelectHeroItemPanel:GetHeroHpIsActive(props)
	local active = false
	for k,_prop in pairs(props) do
		if CONST.ATTR[_prop[1]] == "hp" and _prop[2] > 0 then
			active = true
			break
		end
	end
	return active
end

function BattleSelectHeroItemPanel:_GetHeroCfgByUid(herouid)
	for _, herodata in ipairs(self.heroInfos) do
		if herodata.herouid == herouid then
			local cfg = HeroProxy.Instance:GetRoleCfgByConfigId(herodata.roleid)
			return cfg
		end	
	end
end

function BattleSelectHeroItemPanel:_GetHeroDataByUid(herouid)
	for _, herodata in ipairs(self.heroInfos) do
		if herodata.herouid == herouid then
			return herodata
		end	
	end	
end

--注册新手引导数据 上阵英雄引导
function BattleSelectHeroItemPanel:RegisterBattleNewbieData()
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	local NewbieManager = require "Modules.Newbie.NewbieManager"
	local cur_newbie_id, cur_newbie_step = NewbieManager.Instance:GetCurNewbieId()
	--上阵英雄引导 列表[newbie_id] = {newbie_step}
	local newbie_lists = {}
	if NewbieDef.SelectHeroTrigger[cur_newbie_id] then
		for k,_step in pairs(NewbieDef.SelectHeroTrigger[cur_newbie_id]) do
			local step_confg = NewbieManager.Instance:GetNewbieStepConfig(cur_newbie_id, _step)
			if step_confg and step_confg.parama then
				if step_confg.parama.roleid then
					newbie_lists[step_confg.parama.roleid] = {cur_newbie_id, _step}
				elseif step_confg.parama.roleids then
					--英雄多选一
					local roleids = step_confg.parama.roleids
					for i, roleid in ipairs(roleids) do
						newbie_lists[roleid] = {cur_newbie_id, _step}
					end
				end
			end
		end
	end
	return newbie_lists
end

--注册新手引导数据 引导英雄站位或下阵英雄
function BattleSelectHeroItemPanel:RegisterHeroNewbieData(tab)
	local NewbieManager = require "Modules.Newbie.NewbieManager"
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	local cur_newbie_id, cur_newbie_step = NewbieManager.Instance:GetCurNewbieId()
	
	if tab[cur_newbie_id] and
		cur_newbie_step == tab[cur_newbie_id] then

		local step_config = NewbieManager.Instance:GetCurNewbieStepConfig()
		if step_config and step_config.parama and step_config.parama.roleid then
			return step_config.parama.roleid, cur_newbie_id, cur_newbie_step
		end
	end
end

function BattleSelectHeroItemPanel:_GetHeroDataListByRace(race)
	local newbie_lists = self:RegisterBattleNewbieData()
	local register_step = {}
	--print("newbie_lists=", table.dump(newbie_lists))
	local newlist = {}

	local activityId, subtype = self:GetActivityIdAndSubType()
	local bbattle = MercenaryProxy.Instance:CheckHireHeroBattle(activityId, subtype)
	local canHireFriendHeroNum = MercenaryProxy.Instance:GetHireHeroCanBattleNum(activityId, subtype)
	for _, info in pairs(self.heroInfos) do
		local cfg = HeroProxy.Instance:GetRoleCfgByConfigId(info.roleid)
		if cfg and (not race or cfg.race == race) then
			info.bselect = false
			info.bcant = true
			info.lockHero = self.args.lockHero

			--是否是雇佣兵
			info.bhireHero = info.hire_hero_type == BattleDef.Hire_Hero_Type.Hire_Hero and true or false
			info.hireHeroState = 0 --雇佣兵英雄状态 0可以被使用  1该玩法已被使用过，不允许使用多次 2不可以上阵多个雇佣兵
			if not bbattle and info.bhireHero then
				info.hireHeroState = 1
			end
			info.canHireFriendHeroNum = canHireFriendHeroNum
			
			info.leftItemList = self.leftItemList
			info.GetOtherTeamList = function()
				return self:GetOtherTeamList()
			end
			--是否是新手标识
			info.isNewbieItem = nil
			if newbie_lists[info.roleid] then
				local newbie_id = newbie_lists[info.roleid][1]
				local newbie_step = newbie_lists[info.roleid][2]
				if not register_step[newbie_step] then
					info.isNewbieItem = {newbie_id, newbie_step}
					register_step[newbie_step] = true
				end
			end

			table.insert(newlist, info)
		end	
	end
	--sort
	local hero_dict = HeroProxy.Instance:GetHeroDataDict()
	table.sort(newlist, function (a,b)

		local a_hero_data = hero_dict[a.fromuid]
		local b_hero_data = hero_dict[b.fromuid]

		local a_crystalLevel = a_hero_data and a_hero_data.crystalLevel or a.crystalLevel
		local b_crystalLevel = b_hero_data and b_hero_data.crystalLevel or b.crystalLevel

		local level_1 = a_crystalLevel or (a_hero_data and a_hero_data.level or a.level)
		local level_2 = b_crystalLevel or (b_hero_data and b_hero_data.level or b.level)
		local rank_1 = a.rank
		local rank_2 = b.rank
		local fight_1 = HeroProxy.Instance:GetHeroBaseFight(a.roleid)
		local fight_2 = HeroProxy.Instance:GetHeroBaseFight(b.roleid)

		if level_1 == level_2 then
			if rank_1 == rank_2 then
				if fight_1 == fight_2 then
					return a.roleid < b.roleid
				else
					return 	fight_1 > fight_2
				end
			else
				return rank_1 > rank_2	
			end	
		else
			return level_1 > level_2
		end	
	end)

	return newlist		
end

function BattleSelectHeroItemPanel:GetOtherTeamList()
	if self.getOtherTeamList then
		return self.getOtherTeamList()
	end
	return {}, {}, {}
end

function BattleSelectHeroItemPanel:SetOtherTeamGetFunc(func)
	self.getOtherTeamList = func
end

function BattleSelectHeroItemPanel:RemoveTeamHero(herodata)
	if self.removeOtherTeamHero then
		self.removeOtherTeamHero(herodata)
	end
end

function BattleSelectHeroItemPanel:SetRemoveTeamHeroFunc(func)
	self.removeOtherTeamHero = func
end

function BattleSelectHeroItemPanel:FilterSameRoleIDHero(teams)
	if self.filterSameRoleIDHeroFunc then
		return self.filterSameRoleIDHeroFunc(teams)
	end
	return teams
end

function BattleSelectHeroItemPanel:SetFilterSameRoleIDHeroFunc(func)
	self.filterSameRoleIDHeroFunc = func
end

function BattleSelectHeroItemPanel:Newbie_Notify(args)
	self.heroListPanel:Newbie_Notify(args)
end

function BattleSelectHeroItemPanel:GetHeroCList( ... )
	return self.heroListPanel:GetHeroCList()
end

function BattleSelectHeroItemPanel:PlayHeroSound(roleId)
	local AudioManager = require "Common.Mgr.Audio.AudioManager"
	local idx = 1
	idx = math.random(1,4)
	local sound_name = string.format("%d_show%d", roleId, idx)
	if self.hero_sound_name then
		AudioManager.StopSoundByKey(self.hero_sound_name)
	end
	self.hero_sound_name = sound_name
	-- print("PlayHeroSound sound_name===", sound_name)
	AudioManager.PlaySoundByKey(sound_name)
end

function BattleSelectHeroItemPanel:StopHeroSound()
	local AudioManager = require "Common.Mgr.Audio.AudioManager"
	if self.hero_sound_name then
		AudioManager.StopSoundByKey(self.hero_sound_name)
	end
end

return BattleSelectHeroItemPanel