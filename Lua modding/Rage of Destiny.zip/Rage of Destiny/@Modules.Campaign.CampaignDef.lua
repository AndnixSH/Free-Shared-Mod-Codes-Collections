local CampaignDef = {}
CampaignDef.NotifyDef =
{
	ShowHangUp = "ShowHangUp",
	GetHangUpReward = "GetHangUpReward",
	ShowFastHangUp = "ShowFastHangUp",
	GetFastHangUpReward = "GetFastHangUpReward",
	UpdateMainlineReportInfoMembers = "UpdateMainlineReportInfoMembers",
	NotifyBoxRewardViewClose = "NotifyBoxRewardViewClose",
}

CampaignDef.LanguageKey = 
{
	FriendKey = "<color=#b1f278>好友</color>",
	GuildKey = "<color=#80cded>公会成员</color>",
}

CampaignDef.Const =
{
	BattleClickGuideTime = 10, --提示点击挑战首领计时器时间
	BattleClickGuideChapter = {--提示点击挑战首领章节
		[1] = 1,
		[2] = 1,
		},
	MAX_ENEMY_NUM = 5,
}

return CampaignDef