local BagDef = {}
BagDef.BagTabType = 
{
    [1] = {key = "GoodType_1001", icon = "all", goodsType = {1,2,3,4,5,6,7}, tab =1},
    [2] = {key = "GoodType_1002", icon = "soulstone", goodsType = {3},tab =2},
    [3] = {key = "GoodType_1003", icon = "equipment", goodsType = {1,2},tab =3},
    [4] = {key = "GoodType_1004", icon = "item", goodsType = {4,5,6,7},tab =4},
}

--待改，改成type + subtype 拼接语言包key, 不用开配置了
BagDef.GoodsTypeDesc =
{

    [1]= {type =1, subtype =111, key = "Goodsubtype_2001"},
    [2]= {type =1, subtype =112, key = "Goodsubtype_2002"},
    [3]= {type =1, subtype =113, key = "Goodsubtype_2003"},
    [4]= {type =1, subtype =121, key = "Goodsubtype_2004"},
    [5]= {type =1, subtype =122, key = "Goodsubtype_2005"},
    [6]= {type =1, subtype =123, key = "Goodsubtype_2006"},
    [7]= {type =1, subtype =131, key = "Goodsubtype_2007"},
    [8]= {type =1, subtype =132, key = "Goodsubtype_2008"},
    [9]= {type =1, subtype =133, key = "Goodsubtype_2009"},
    [10]= {type =1, subtype =141, key = "Goodsubtype_2010"},
    [11]= {type =1, subtype =142, key = "Goodsubtype_2011"},
    [12]= {type =1, subtype =143, key = "Goodsubtype_2012"},


    [13]= {type =2, subtype =200, key = "Goodsubtype_2200"},
    [14]= {type =2, subtype =220, key = "Goodsubtype_2220"},    

    [15]= {type =3, subtype =301, key = "Goodsubtype_1002"},
    [16]= {type =3, subtype =302, key = "Goodsubtype_1002"},
    [17]= {type =3, subtype =303, key = "Goodsubtype_1004"},
    [18]= {type =3, subtype =304, key = "Goodsubtype_1004"},
    [19]= {type =3, subtype =310, key = "Goodsubtype_1002"},
    [20]= {type =3, subtype =311, key = "Goodsubtype_1002"},
    [21]= {type =3, subtype =320, key = "Goodsubtype_1002"},

    [22]= {type =4, subtype =401, key = "Goodsubtype_1005"},
    [23]= {type =4, subtype =402, key = "Goodsubtype_1006"},
    [24]= {type =4, subtype =403, key = "Goodsubtype_1005"},
    [25]= {type =4, subtype =404, key = "Goodsubtype_1005"},
    [26]= {type =4, subtype =405, key = "Goodsubtype_1005"},
    [27]= {type =4, subtype =411, key = "Goodsubtype_1005"},
    [28]= {type =4, subtype =412, key = "Goodsubtype_1005"},    
    [29]= {type =5, subtype =501, key = "Goodsubtype_1005"},

    [30]= {type =6, subtype =601, key = "Goodsubtype_1005"},
    [31]= {type =6, subtype =602, key = "Goodsubtype_1008"},
    [32]= {type =6, subtype =603, key = "Goodsubtype_1008"},
    [33]= {type =6, subtype =690, key = "Goodsubtype_1005"},
    [34]= {type =6, subtype =691, key = "Goodsubtype_1005"},
    [35]= {type =6, subtype =692, key = "Goodsubtype_1005"},
    [36]= {type =6, subtype =693, key = "Goodsubtype_1005"},    
    [37]= {type =7, subtype =700, key = "Goodsubtype_1005"},

    [38]= {type =7, subtype =701, key = "Goodsubtype_1009"},
    [39]= {type =7, subtype =702, key = "Goodsubtype_1009"}, 
    [40]= {type =7, subtype =703, key = "Goodsubtype_1009"}, 
    [41]= {type =7, subtype =704, key = "Goodsubtype_1009"}, 
    [42]= {type =7, subtype =705, key = "Goodsubtype_1009"}, 
    [43]= {type =7, subtype =706, key = "Goodsubtype_1009"},   
    [44]= {type =7, subtype =707, key = "Goodsubtype_1009"}, 
    [45]= {type =7, subtype =708, key = "Goodsubtype_1009"},
    [46]= {type =7, subtype =709, key = "Goodsubtype_1009"},
    [47]= {type =7, subtype =710, key = "Goodsubtype_1009"}, 
    [48]= {type =7, subtype =711, key = "Goodsubtype_1009"},
    [49]= {type =7, subtype =712, key = "Goodsubtype_1009"},
    [50]= {type =7, subtype =713, key = "Goodsubtype_1009"},
    [51]= {type =7, subtype =714, key = "Goodsubtype_1009"},
    [52]= {type =7, subtype =715, key = "Goodsubtype_1009"},

    [53]= {type =6, subtype =604, key = "Goodsubtype_1008"},
    [54]= {type =6, subtype =605, key = "Goodsubtype_1008"},

    [55]= {type =1, subtype =114, key = "Goodsubtype_2001"},
    [56]= {type =1, subtype =115, key = "Goodsubtype_2002"},
    [58]= {type =1, subtype =116, key = "Goodsubtype_2003"},
    [59]= {type =1, subtype =124, key = "Goodsubtype_2004"},
    [60]= {type =1, subtype =125, key = "Goodsubtype_2005"},
    [61]= {type =1, subtype =126, key = "Goodsubtype_2006"},
    [62]= {type =1, subtype =134, key = "Goodsubtype_2007"},
    [63]= {type =1, subtype =135, key = "Goodsubtype_2008"},
    [64]= {type =1, subtype =136, key = "Goodsubtype_2009"},
    [65]= {type =1, subtype =144, key = "Goodsubtype_2010"},
    [66]= {type =1, subtype =145, key = "Goodsubtype_2011"},
    [67]= {type =1, subtype =146, key = "Goodsubtype_2012"},

    [68]= {type =3, subtype =305, key = "Goodsubtype_1004"},
    [69]= {type =6, subtype =696, key = "Goodsubtype_1005"},
    [70]= {type =7, subtype =721, key = "Goodsubtype_1005"},    

}

BagDef.NotifyDef =
{
    Update_Bag = "Update_Bag",
    Open_Bag = "Open_Bag" ,
    Update_Special_Tool = "Update_Special_Tool",
    UseGoods = "UseGoods",
}

--物品类型
BagDef.BagType = 
{
    Basic_Equip = 1, --基础装备
    Advanced_Equip =2, --专属、神器装备
    Soul_Stones = 3,  --灵魂石
    Equip_Item = 4, --装备道具
    System_Item = 5, --系统道具
    Gift_Item = 6,  --礼包道具
    Res_Item = 7, --资源道具
}


--获得途径
BagDef.GetWayDef =
{
}

--物品subtype
BagDef.SubType = 
{

    --基础装备随机转换装备类
    Basic_Equip_Random114 = 114,
    Basic_Equip_Random115 = 115,
    Basic_Equip_Random116 = 116,
    Basic_Equip_Random124 = 124,
    Basic_Equip_Random125 = 125,
    Basic_Equip_Random126 = 126,
    Basic_Equip_Random134 = 134,
    Basic_Equip_Random135 = 135,
    Basic_Equip_Random136 = 136,
    Basic_Equip_Random144 = 144,
    Basic_Equip_Random145 = 145,
    Basic_Equip_Random146 = 146,

    Equip_Exclusive = 200,   --专属装备
    Equip_Artifacts = 220,   --神器装备
    Equip_Enhance = 404, -- 装备_强化石
    Elite_Hero_Card = 310, -- 精英英雄卡
    Rare_Hero_Card = 311, -- 稀有英雄卡 
    Hero_Stone = 301, --灵魂石
    Hero_Fragment = 320, --英雄碎片
    Rune_Stone_one = 411, --t1符文石
    Rune_Stone_tow = 412, --t2符文石
    Race_Hero_Card = 302, --种族卡
    Hero_Choice_Card = 303, --种族自选英雄卡
    Hero_Choice_Card_On_Bag = 305, --背包种族自选英雄卡
    Upgrade_StonesT1 = 411, --T1进阶石石
    Upgrade_StonesT2 = 412, --T2进阶石石
    DiamondBox = 602,       --钻石包厢(使用可以兑换成钻石)  固定物品宝箱
    TimeLinessTool = 601,   --金币 粉尘 英雄经验 (小时)
    RandomItemChest = 603, --随机物品宝箱
    OneChest = 604,          --物品选择宝箱(选择一个)
    AwardBox = 605,          --物品选择宝箱(选择多个)
    CustomBox = 606,         --定制宝箱
}

--使用类型
BagDef.UseType = 
{
    DiamondBox = 1, --钻石宝箱  subtype = 602
    Dust = 2,-- 金币 粉尘 英雄经验 小时  subtype = 601
    SoulStones = 3, --灵魂石  subtype = 301
    AwardBox = 4, --宝箱  subtype = 604
    RandomHero = 5, --随机英雄类型 subtype = 302

}

--物品tips展示类型
BagDef.GoodsTipsType = 
{
    EquipTips = {1,2}, --装备物品表大类型
    NormalTips = {3,4,5,6},  --普通tips大类型
    CurrencyTips = {7}, --货币大类型
}

BagDef.RandomEquipSubeType = {
    [BagDef.SubType.Basic_Equip_Random114] = 1,
    [BagDef.SubType.Basic_Equip_Random115] = 1,
    [BagDef.SubType.Basic_Equip_Random116] = 1,

    [BagDef.SubType.Basic_Equip_Random124] = 1,
    [BagDef.SubType.Basic_Equip_Random125] = 1,
    [BagDef.SubType.Basic_Equip_Random126] = 1,

    [BagDef.SubType.Basic_Equip_Random134] = 1,
    [BagDef.SubType.Basic_Equip_Random135] = 1,
    [BagDef.SubType.Basic_Equip_Random136] = 1,

    [BagDef.SubType.Basic_Equip_Random144] = 1,
    [BagDef.SubType.Basic_Equip_Random145] = 1,
    [BagDef.SubType.Basic_Equip_Random146] = 1,

}

BagDef.EquipT1T2Type = {
    T1 = 10,
    T2 = 11,
}

BagDef.FlyIconType = {
    FullScreenCion = 1, --全屏界面金币
    FullScreenGem = 2,
    FullScreenExp = 3,
    MainViewCion = 4, --主界面面金币
    MainViewGem = 5,
    MainViewExp = 6,
}

BagDef.FlyIconTypeGoodsId = {
    [BagDef.FlyIconType.FullScreenCion] = 702001, --全屏界面金币
    [BagDef.FlyIconType.FullScreenGem] = 701001,
    [BagDef.FlyIconType.FullScreenExp] = 703001,
    [BagDef.FlyIconType.MainViewCion] = 702001, --主界面面金币
    [BagDef.FlyIconType.MainViewGem] = 701001,
    [BagDef.FlyIconType.MainViewExp] = 703001,
}

BagDef.DropType = 
{
    Exp = 0,
    Coin = 1,
    Gem = 2,
    Goods = 3,
}

BagDef.FullViewFlyIconTypeGoodsId = {
    [BagDef.FlyIconType.FullScreenCion] = BagDef.DropType.Coin, --全屏界面金币
    [BagDef.FlyIconType.FullScreenGem] = BagDef.DropType.Gem,
    [BagDef.FlyIconType.FullScreenExp] = BagDef.DropType.Exp,
}

BagDef.MainViewFlyIconTypeGoodsId = {
    [BagDef.FlyIconType.MainViewCion] = BagDef.DropType.Coin, --主界面面金币
    [BagDef.FlyIconType.MainViewGem] = BagDef.DropType.Gem,
    [BagDef.FlyIconType.MainViewExp] = BagDef.DropType.Exp,
}

-- 传说以上品质
BagDef.HighQuality = 9

-- 1:力量 2：敏捷 3：智力
--分别属性这三个 类型的 Subtype
BagDef.ClassSubType = {
    [1] = {
        [111] = true,
        [121] = true,
        [131] = true,
        [141] = true,
    },
    [2] = {
        [112] = true,
        [122] = true,
        [132] = true,
        [142] = true,
    },
    [3] = {
        [113] = true,
        [123] = true,
        [133] = true,
        [143] = true,
    },
}

BagDef.ClassGoodsId = {
    [1] = {
        [403011] = true,
        [403012] = true,
    },
    [2] = {
        [403021] = true,
        [403022] = true,
    },
    [3] ={
        [403031] = true,
        [403032] = true,
    },
}
















return BagDef