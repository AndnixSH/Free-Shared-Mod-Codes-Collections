local AudioManager = require "Common.Mgr.Audio.AudioManager"
local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"
local BattleProxy = require "Modules.Battle.BattleProxy"
local BasicBattleStrategy = require "Modules.Scene.Strategy.BasicBattleStrategy"
local GuildBossStrategy = GuildBossStrategy or BaseClass(BasicBattleStrategy)
local GuildProxy = require "Modules.Guild.GuildProxy"
local GuildDef = require "Modules.Guild.GuildDef"

local nowBossType
local diff
local stage
local config
local isPass --是否通关(boss血量为0)
local isWin --是否胜利
local isNewRecord --是否新记录
local newDiff
local newStage

local clientHpRate

--加载场景
function GuildBossStrategy:OnLoad()
    local args = self:GetCustomArg()

    -- print("GuildBossStrategy:OnLoad")
    -- print(table.dump(args))

    nowBossType = args[1]
    diff = args[2]
    stage = args[3]
    config = GuildProxy.Instance:GetBossConfigByDiff(nowBossType, diff)
    
    self:LoadScene(config.scence)
end

-- 带入战斗信息
function GuildBossStrategy:OnStartEntry()
    -- print("GuildBossStrategy:OnStartEntry")

    self:StartGame()
    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.BattleStopView) --战斗内暂停界面显示
end

function GuildBossStrategy:OnGetConfigKey()
    return BattleProxy.Instance:GetConfigKey(config.scence, config.enemy)
end

function GuildBossStrategy:OnStartGame()
    AudioManager.PlayBGM("battle_story_bg")
end

function GuildBossStrategy:OnSettleGame(wincamp, rewards, buffer_str)
    self:SettleGameDelayTime(function()
        local gameResult, hpRate = string.unpack(">I1I4", buffer_str)
        print("GuildBossStrategy:OnSettleGame", wincamp, gameResult, hpRate)
        -- print(table.dump(rewards))
        -- print(buffer_str)

        local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildBossBattleSettlementView)
        if view then
            view.isVerifySuccess = clientHpRate == hpRate
            view.wincamp = wincamp
            view.bossType = nowBossType
            view.diff = diff
            view.stage = stage
            view.isPass = isPass
            view.isWin = isWin
            view.isNewRecord = isNewRecord
            view.newDiff = newDiff
            view.newStage = newStage
            view.battleType = self.strategycfg.activityid
            view:OpenView()
        end

        -- UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 2, wincamp, self.strategycfg.activityid)
    end)
end

function GuildBossStrategy:OnDestroyGame()
    self:UnloadScene()

    local SceneManager = require "Modules.Scene.SceneManager"
    local SceneDef = require "Modules.Scene.SceneDef"
    local openviews = {UIWidgetNameDef.GuildEntranceView, UIWidgetNameDef.GuildBossView}
    if GuildProxy.Instance:GetBossReportRank() then
        GuildProxy.Instance:SetBossReportRank(false)
        table.insert(openviews, UIWidgetNameDef.GuildBossRankView)
    end 
    SceneManager.Instance:EnterScene(SceneDef.SceneType.Main, openviews)

    --动画标记
    if newDiff and diff then --播放战报时，newDiff会为nil
        GuildProxy.Instance:SetBossIsNewDiff(newDiff > diff)
    end
end

function GuildBossStrategy:OnRestartGame()
    self:Destroy()
end

function GuildBossStrategy:OnGamePrepared()
    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.BattleView)
    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.BattleGuildBossView) 
end

-- 请求结算
function GuildBossStrategy:OnRequireSettle(result, gameprop, total_time)
    -- local encoder = NetEncoder.New()

    local boss_hp_rate = 0
    local BattleProxy = require "Modules.Battle.BattleProxy"
    local spritelist = BattleProxy.Instance:GetSpriteList(CAMP.BLUE)
    for _, spriteid in ipairs(spritelist) do
        local sprite = BattleProxy.Instance:GetSprite(spriteid)
        if sprite then
            boss_hp_rate = math.floor(sprite.attr.hp / sprite.attr.hp_max * 100)
            break
        end
    end

    -- print("type", nowBossType, "boss_hp_rate", boss_hp_rate)

    -- encoder:Encode("I2I4", nowBossType, boss_hp_rate)
    -- local bufferstr = encoder.buffer

    --计算进度
    local nowDiff = diff
    local nowStage = stage
    local maxDiff = GuildProxy.Instance:GetBossMaxDiff(nowBossType)
    if boss_hp_rate == 0 then --通关
        if nowDiff < maxDiff then
            nowDiff = nowDiff + 1
            nowStage = 0
        elseif nowDiff == maxDiff then
            nowStage = 10
        end
    else
        nowStage = math.floor((100 - boss_hp_rate) / 10)
    end
    if nowStage < 0 then
        nowStage = 0
    end

    GuildProxy.Instance:SetNowBossProgress(nowBossType, nowDiff, nowStage)
    
    isPass = boss_hp_rate == 0
    isWin = result == 0
    if (nowDiff > diff) or (nowDiff == diff and nowStage > stage) then
        isNewRecord = true
    else
        isNewRecord = false
    end
    newDiff = nowDiff
    newStage = nowStage
    clientHpRate = boss_hp_rate
    print("GuildBossStrategy:OnRequireSettle", nowDiff, nowStage, result, clientHpRate)

    local settlestr = self:GetSettleStr()
    local bufferstr = string.pack(">I2I4s2I4", nowBossType, boss_hp_rate, settlestr, total_time)
    self:RequireNetworkSettle(self.strategycfg.activityid, result, bufferstr)
end

function GuildBossStrategy:OnReportSettleGame(wincamp)
    BattleProxy.Instance:EscGame()
end

function GuildBossStrategy:OnGetEnemeyId()
    return config.enemy
end

return GuildBossStrategy