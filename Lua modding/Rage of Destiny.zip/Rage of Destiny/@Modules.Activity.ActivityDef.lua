local ActivityDef = {}
local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
local RedPointDef = require "Modules.RedPoint.RedPointDef"
ActivityDef.NotifyDef = {
   
    UpdateSevenLogin = "UpdateSevenLogin",
    Update_Reward_State = "Update_Reward_State",
    UpdateTitleName = "UpdateTitleName",
    UpdateNewPlayerInfo = "UpdateNewPlayerInfo",
    GetStageReward = "GetStageReward",
    DoFlyCoinAni = "DoFlyCoinAni",

    UpdateHeroGatheringInfo = "UpdateHeroGatheringInfo",
    UpdateStageClearChargeInfo = "UpdateStageClearChargeInfo",
    UpdateHatharalComingInfo = "UpdateHatharalComingInfo",
    DoHatharalComingFlyIcon = "DoHatharalComingFlyIcon",
    UpdateShareRed = "UpdateShareRed",

    Update_Happy_Month_Info = "Update_Happy_Month_Info",

    ActivityEnd = "ActivityEnd",
}

ActivityDef.CommonDef={
  Days = "Activityinfo_1007",
  CountTime = "Activityinfo_1008",

  New_Player_Day = "Activityinfo_1009",
  New_Player_InActive_Tips = "Activityinfo_1010",
  Hero_Gathering_Progress = "Activityinfo_1011",

  StageClearCharge_Progress = "Activityinfo_1012",
  ExpireTips = "Activityinfo_1005",

  HatharalComingTips = "Activityinfo_1013",
  HatharalComingTips2 ="Activityinfo_1014",

  Share_Cancel = "Activity_share_1007",
  Share_Faild = "Activity_share_1008",
  Share_Success = "Activity_share_1009"
}

ActivityDef.toggleType={
  Seven_Login = 1,
  New_Player = 2,
  Share = 3,
  HeroGathering = 4,
  StageClearCharge = 5,
  HatharalComing = 6,
  HeroComing = 7,--此处一定要配
  HeroComing2 = 8,--此处一定要配
  HappyMonth = 9,--女王狂欢祭
  News = 10,--活动一览
}

ActivityDef.HeroComingId={
  [1] = 7 , --id
  [2] = 8 , --id
}

ActivityDef.HeroComingSlogan =
{
  [7] = "Hc3",
  [8] = "Hc5",
}
ActivityDef.HeroComingSlogan2 =
{
  [7] = "Hc4",
  [8] = "Hc6",
}

ActivityDef.HeroComingSpinePostion =
{
  [7] = {-223,-777.6},
  [8] = {-223,-721},
}

ActivityDef.HeroComingRedPointId =
{
  [7] = RedPointDef.Id.HeroComing,
  [8] = RedPointDef.Id.HeroComing_Two,
}
ActivityDef.HeroComingEnterRedPointId =
{
  [7] = RedPointDef.Id.HeroComingEnter,
  [8] = RedPointDef.Id.HeroComingEnter_Two,
}


ActivityDef.Btn={ --此处一定要配
  [ActivityDef.toggleType.Seven_Login] = "Activityinfo_1015",
  [ActivityDef.toggleType.New_Player] = "Activityinfo_1016",
  [ActivityDef.toggleType.Share] = "Activityinfo_1017",
  [ActivityDef.toggleType.HeroGathering] = "Activityinfo_1018",
  [ActivityDef.toggleType.StageClearCharge] = "Activityinfo_1019",
  [ActivityDef.toggleType.HatharalComing] = "Activityinfo_1020",
  [ActivityDef.toggleType.HeroComing] = "Activityinfo_1030",
  [ActivityDef.toggleType.HeroComing2] = "Activity_Elven_1017",
  [ActivityDef.toggleType.HappyMonth] = "",
  [ActivityDef.toggleType.News] = "activityover_title_1001",
}

ActivityDef.SystemOpenType={
  [ActivityDef.toggleType.Seven_Login] = ModuleOpenDef.SystemOpenType.Activity_Seven_Login,
  [ActivityDef.toggleType.New_Player] = ModuleOpenDef.SystemOpenType.Activity_New_Player,
  [ActivityDef.toggleType.StageClearCharge] = ModuleOpenDef.SystemOpenType.Activity_StageClearCharge,
  [ActivityDef.toggleType.HatharalComing] = ModuleOpenDef.SystemOpenType.Activity_HatharalComing,
  [ActivityDef.toggleType.HeroComing] = ModuleOpenDef.SystemOpenType.Activity_HatharalComing,
  [ActivityDef.toggleType.HeroComing2] = ModuleOpenDef.SystemOpenType.Activity_HatharalComing,
  [ActivityDef.toggleType.Share] = ModuleOpenDef.SystemOpenType.Activity_Share,
  [ActivityDef.toggleType.HappyMonth] = ModuleOpenDef.SystemOpenType.HappyMonthPanel,
}



ActivityDef.BGName={--此处一定要配
  [ActivityDef.toggleType.Seven_Login] = "Tex_Herotips_race3",
  [ActivityDef.toggleType.New_Player] = "Tex_Herotips_race1",
  [ActivityDef.toggleType.HeroGathering] = "Tex_Rank_tower",
  [ActivityDef.toggleType.StageClearCharge] = "Tex_Herotips_race2",
  [ActivityDef.toggleType.HatharalComing] = "Tex_Herotips_race3",
  [ActivityDef.toggleType.HeroComing] = "Tex_Herotips_race4",
  [ActivityDef.toggleType.HeroComing2] = "Tex_Herotips_race1",
  [ActivityDef.toggleType.News] = "Tex_Bg_8",
}


ActivityDef.ToggleIcon={--此处一定要配
  [ActivityDef.toggleType.Seven_Login] = "7dayspage",
  [ActivityDef.toggleType.New_Player] = "xinbingpage",
  [ActivityDef.toggleType.HeroGathering] = "jijiepage",
  [ActivityDef.toggleType.StageClearCharge] = "chongguanpage",
  [ActivityDef.toggleType.HatharalComing] = "jinglingpage",
  [ActivityDef.toggleType.HeroComing] = "evilpage",
  [ActivityDef.toggleType.HeroComing2] = "elvenpage",
  [ActivityDef.toggleType.News] = "Activityoverview",
}


ActivityDef.OpenViews={
  [ActivityDef.toggleType.Seven_Login] = UIWidgetNameDef.SevenDaysCheckinView,
  [ActivityDef.toggleType.New_Player] = UIWidgetNameDef.FreshmanTrainView,
  [ActivityDef.toggleType.Share] = "",
  [ActivityDef.toggleType.HeroGathering] = UIWidgetNameDef.HeroGatheringView,
  [ActivityDef.toggleType.StageClearCharge] = UIWidgetNameDef.StageClearChargeView,
  [ActivityDef.toggleType.HatharalComing] = UIWidgetNameDef.HatharalComingView,
  [ActivityDef.toggleType.HeroComing] = UIWidgetNameDef.HeroComingView,
  [ActivityDef.toggleType.HeroComing2] = UIWidgetNameDef.HeroComingView,
  [ActivityDef.toggleType.News] = UIWidgetNameDef.ActivityOverView,
}

ActivityDef.Hero_Gathering_OpenViews={
  {AppFacade.Temple,3},
  {AppFacade.Store},
  {AppFacade.CardPortal},
}

ActivityDef.Reward_State ={
   UnGet = 0,
   CannotGet = 1,
   HasGet= 2,
}
--新兵训练
ActivityDef.New_Player_Train_Task_Type = {
  Give_Friend_Point = 1, --赠送友情点
  Get_Normal_Task_Point = 2,--获得日常任务点数
  Finish_Chapter_Level = 3,--完成章节
  Share_Drawcard_Or_New_Hero =4,--分享抽卡或新英雄
  Take_Part_In_Guild=5,--参加公会矮人宝库
  Enhance_Equip_Level=6,--提升装备强化等级
  Arena_Chanllage=7,--在竞技场挑战
  Finish_Trade_Order=8,--完成贸易订单
  Win_In_Dragon=9,--在巨龙洞窟中击败敌人
  Use_Quick_Hangup=10,--使用快速挂机
  Resolve_Normal_Hero =11,--分解普通英雄
  Call_Elite_Up_Hero = 12,--召唤精英品质以上英雄
  Buy_Goods=13,--商店购买次数达到
  Crystal_Level=14,--共鸣水晶等级到达
  Temple_Enhance_Hero = 15,--在大圣堂进阶英雄
  Crystal_Up_Hero=16,--共鸣水晶上阵英雄
}

ActivityDef.New_Player_Train_Stage_GoodsId = 718001

ActivityDef.New_Player_Train_OpenViews = {
  [ActivityDef.New_Player_Train_Task_Type.Give_Friend_Point] = {AppFacade.Friend},
  [ActivityDef.New_Player_Train_Task_Type.Get_Normal_Task_Point] = {AppFacade.Task,2},
  --[ActivityDef.New_Player_Train_Task_Type.Share_Drawcard_Or_New_Hero] = {AppFacade.CardPortal},
  [ActivityDef.New_Player_Train_Task_Type.Enhance_Equip_Level] = {AppFacade.Hero,8},
  [ActivityDef.New_Player_Train_Task_Type.Arena_Chanllage] = {AppFacade.Arena},
  [ActivityDef.New_Player_Train_Task_Type.Finish_Trade_Order] = {AppFacade.SupplyDepot},
  [ActivityDef.New_Player_Train_Task_Type.Win_In_Dragon] = {AppFacade.Maze},
  [ActivityDef.New_Player_Train_Task_Type.Resolve_Normal_Hero] = {AppFacade.Hero,9,2},
  [ActivityDef.New_Player_Train_Task_Type.Call_Elite_Up_Hero] = {AppFacade.CardPortal},
  [ActivityDef.New_Player_Train_Task_Type.Buy_Goods] = {AppFacade.Store},
  [ActivityDef.New_Player_Train_Task_Type.Crystal_Level] = {AppFacade.Crystal,4},
  [ActivityDef.New_Player_Train_Task_Type.Temple_Enhance_Hero] = {AppFacade.Temple,3},
  [ActivityDef.New_Player_Train_Task_Type.Crystal_Up_Hero] = {AppFacade.Crystal,4},
}

ActivityDef.New_Player_Train_OpenCondition = {
  [ActivityDef.New_Player_Train_Task_Type.Give_Friend_Point] = ModuleOpenDef.SystemOpenType.FriendlListView,
  [ActivityDef.New_Player_Train_Task_Type.Get_Normal_Task_Point] = ModuleOpenDef.SystemOpenType.MainTaskView,
  [ActivityDef.New_Player_Train_Task_Type.Share_Drawcard_Or_New_Hero] = ModuleOpenDef.SystemOpenType.CardPortView,
  [ActivityDef.New_Player_Train_Task_Type.Enhance_Equip_Level] = ModuleOpenDef.SystemOpenType.HeroRootView,
  [ActivityDef.New_Player_Train_Task_Type.Take_Part_In_Guild] = ModuleOpenDef.SystemOpenType.GuildRootView,
  [ActivityDef.New_Player_Train_Task_Type.Arena_Chanllage] = ModuleOpenDef.SystemOpenType.ArenaEntranceView,
  [ActivityDef.New_Player_Train_Task_Type.Finish_Trade_Order] = ModuleOpenDef.SystemOpenType.SupplyDepotView,
  [ActivityDef.New_Player_Train_Task_Type.Win_In_Dragon] = ModuleOpenDef.SystemOpenType.MazeView,
  [ActivityDef.New_Player_Train_Task_Type.Use_Quick_Hangup] = ModuleOpenDef.SystemOpenType.QuickHangUp,
  [ActivityDef.New_Player_Train_Task_Type.Resolve_Normal_Hero] = ModuleOpenDef.SystemOpenType.FountainView,
  [ActivityDef.New_Player_Train_Task_Type.Call_Elite_Up_Hero] = ModuleOpenDef.SystemOpenType.CardPortView,
  [ActivityDef.New_Player_Train_Task_Type.Buy_Goods] = ModuleOpenDef.SystemOpenType.StoreView,
  [ActivityDef.New_Player_Train_Task_Type.Crystal_Level] = ModuleOpenDef.SystemOpenType.CrystalView,
  [ActivityDef.New_Player_Train_Task_Type.Temple_Enhance_Hero] = ModuleOpenDef.SystemOpenType.TempleView,
  [ActivityDef.New_Player_Train_Task_Type.Crystal_Up_Hero] = ModuleOpenDef.SystemOpenType.CrystalView,
}


--精灵王降临
ActivityDef.HatharalComing_Task_Type = {
  Hero_Leve_Up = 1, --将一名英雄升级到10级
  Get_Hang_Up_Coin = 2,--从挂机中累计获得10000枚金币
  Finish_Tower_Layer = 3,--通关赎罪之塔20层
  Login_Game_Days = 4,--登录2天
  Get_Hero_Nums = 5,--获得20个英雄
  Win_Arena_Times = 6,--取得15场竞技场胜利
  Up_Hero_Rank_Yellow = 7,--将一名英雄升阶到史诗品阶
  StoryLine_One = 8,--通关时空战场第1章-光复卫城
  Crystal_Open_Position =9,--命运水晶开启5个英雄槽位
  Finish_Dragon = 10,--通关巨龙巢穴第6层3次
  Vip_Level = 11,--冒险家等级到达40级
  Finish_Trade_Order = 12,--贸易航线完成订单
  Guild_BOSS = 13,--= 击败3阶公会普通boss
  StoryLine_Two = 14,--通关时空战场第2章-光复卫城
  StoryLine_Third= 15,--通关时空战场第3章-光复卫城
  StoryLine_Four= 16,--通关时空战场第4章-光复卫城
  StoryLine_Five = 17,--通关时空战场第2章-光复卫城
  StoryLine_Six= 18,--通关时空战场第3章-光复卫城
  StoryLine_Seven= 19,--通关时空战场第4章-光复卫城
}

ActivityDef.HatharalComing_OpenViews = {
  [ActivityDef.HatharalComing_Task_Type.Hero_Leve_Up] = {AppFacade.Hero,8},
  [ActivityDef.HatharalComing_Task_Type.Finish_Tower_Layer] = {AppFacade.Tower,2},
  [ActivityDef.HatharalComing_Task_Type.Get_Hero_Nums] = {AppFacade.CardPortal},
  [ActivityDef.HatharalComing_Task_Type.Win_Arena_Times] = {AppFacade.Arena,1},
  [ActivityDef.HatharalComing_Task_Type.Up_Hero_Rank_Yellow] ={AppFacade.Temple,3},
  [ActivityDef.HatharalComing_Task_Type.StoryLine_One] = {AppFacade.StoryLine},
  [ActivityDef.HatharalComing_Task_Type.Crystal_Open_Position] =  {AppFacade.Crystal,4},
  [ActivityDef.HatharalComing_Task_Type.Finish_Dragon] = {AppFacade.Maze},
  [ActivityDef.HatharalComing_Task_Type.Finish_Trade_Order] = {AppFacade.SupplyDepot},
  [ActivityDef.HatharalComing_Task_Type.Guild_BOSS] = {AppFacade.Guild},
  [ActivityDef.HatharalComing_Task_Type.StoryLine_Two] = {AppFacade.StoryLine},
  [ActivityDef.HatharalComing_Task_Type.StoryLine_Third] = {AppFacade.StoryLine},
  [ActivityDef.HatharalComing_Task_Type.StoryLine_Four] = {AppFacade.StoryLine},
  [ActivityDef.HatharalComing_Task_Type.StoryLine_Five] = {AppFacade.StoryLine},
  [ActivityDef.HatharalComing_Task_Type.StoryLine_Six] = {AppFacade.StoryLine},
  [ActivityDef.HatharalComing_Task_Type.StoryLine_Seven] = {AppFacade.StoryLine},
}

ActivityDef.HatharalComing_OpenCondition = {
  [ActivityDef.HatharalComing_Task_Type.Hero_Leve_Up] = ModuleOpenDef.SystemOpenType.HeroRootView,
  [ActivityDef.HatharalComing_Task_Type.Finish_Tower_Layer] = ModuleOpenDef.SystemOpenType.TowerEntranceView_0,
  [ActivityDef.HatharalComing_Task_Type.Get_Hero_Nums] = ModuleOpenDef.SystemOpenType.CardPortView,
  [ActivityDef.HatharalComing_Task_Type.Win_Arena_Times] = ModuleOpenDef.SystemOpenType.ArenaEntranceView,
  [ActivityDef.HatharalComing_Task_Type.Up_Hero_Rank_Yellow] = ModuleOpenDef.SystemOpenType.TempleView,
  [ActivityDef.HatharalComing_Task_Type.StoryLine_One] = ModuleOpenDef.SystemOpenType.StoryLine_Copy_1,
  [ActivityDef.HatharalComing_Task_Type.Crystal_Open_Position] = ModuleOpenDef.SystemOpenType.CrystalView,
  [ActivityDef.HatharalComing_Task_Type.Finish_Dragon] = ModuleOpenDef.SystemOpenType.MazeView,
  [ActivityDef.HatharalComing_Task_Type.Finish_Trade_Order] = ModuleOpenDef.SystemOpenType.SupplyDepotView,
  [ActivityDef.HatharalComing_Task_Type.Guild_BOSS] = ModuleOpenDef.SystemOpenType.GuildRootView,
  [ActivityDef.HatharalComing_Task_Type.StoryLine_Two] = ModuleOpenDef.SystemOpenType.StoryLine_Copy_2,
  [ActivityDef.HatharalComing_Task_Type.StoryLine_Third] = ModuleOpenDef.SystemOpenType.StoryLine_Copy_3,
  [ActivityDef.HatharalComing_Task_Type.StoryLine_Four] = ModuleOpenDef.SystemOpenType.StoryLine_Copy_4,
  [ActivityDef.HatharalComing_Task_Type.StoryLine_Five] = ModuleOpenDef.SystemOpenType.StoryLine_Copy_5,
  [ActivityDef.HatharalComing_Task_Type.StoryLine_Six] = ModuleOpenDef.SystemOpenType.StoryLine_Copy_6,
  [ActivityDef.HatharalComing_Task_Type.StoryLine_Seven] = ModuleOpenDef.SystemOpenType.StoryLine_Copy_7,
}

ActivityDef.Seven_LoginIn_Hero = {373304,372203}

ActivityDef.HappyMonth_GiftId = 2061
return ActivityDef