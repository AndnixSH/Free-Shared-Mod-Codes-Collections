local LoginDef = require "Modules.Login.LoginDef"
local Timer = require "Common.Util.Timer"
local crypt = require "crypt"
local md5 = require "First.Util.md5"
local rapidjson = require "rapidjson"
local httputil = require "Common.Util.httputil"
local ChatProxy = require "Modules.Chat.ChatProxy"
local IGGSdkDef = require "Modules.IGGSdk.IGGSdkDef"
local DateFormatUtil = require "Common.Util.DateFormatUtil"

local Application = CS.UnityEngine.Application
local cGameNetWork = CS.LJY.NX.GameNetWork.Instance
--local cTime = CS.UnityEngine.Time
--local cIGGSdkInterface = CS.LJY.NX.IGGSdkInterface

local LoginProxy = LoginProxy or BaseClass(BaseProxy)
function LoginProxy:__init()
    LoginProxy.Instance = self
    self.socketInfo = nil

    self.data = {}

    self.data.isreconnecting = false --是否正在断线重连
    self.data.isreconnect = false --是否是断线重连回来
    self.data.serverhost = ""
    self.data.serverport = 0
    self.data.account = nil

    self.data.fPauseTime = 0

    self:AddProto(1030, self.On1030)
    self:AddProto(10000, self.On10000)
    self:AddProto(10001, self.On10001)
    self:AddProto(10018, self.On10018) --心跳包

    self.heartbeatlist = {}
    self.data.delayOpenDelay = 10 --1030到10001 用时超过15秒后转菊花
    self.data.delayTipsTime = 20 --1030到10001 用时超过30秒后弹提示，退出游戏
    self.data.delayTime = 0
end

function LoginProxy:__delete()
    self:ClearLoginTimer()

    self.data = nil
    LoginProxy.Instance = nil
end

function LoginProxy:Send1030()
    local encoder = NetEncoder.New()
    encoder:Encode("I4", RoleInfoModel.uid)
    encoder:Encode("I4", SystemConfig.AgentID)
    encoder:Encode("I4", RoleInfoModel.player_id or 0)
    encoder:Encode("I4", self:get_package_id())
    encoder:Encode("s2", RoleInfoModel.logintoken)
    self:SendMessage(1030, encoder)

    self:ClearDelayTimer()
    self._delayTimer = Timer.New(function()
        self.data.delayTime = self.data.delayTime + 1
        if self.data.delayTime == self.data.delayOpenDelay then
            LuaLayout.Instance:OpenWidget(UIWidgetNameDef.ReconnectView)
        elseif self.data.delayTime >= self.data.delayTipsTime then
            LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ReconnectView)
            GameLogicTools.ShowConfirmById(36, function()
                Application.Quit()
            end)
            self:ClearDelayTimer()
        end
    end, 1, -1)
    self._delayTimer:Start()
end

function LoginProxy:On1030(decoder)
    local code, subcocde, time = decoder:Decode("I4I4I4")
    self.data.code = code
    --print("------On1030---------", code)
    if code == LoginDef.LoginCode.OK then
        local addres = decoder:DecodeList("I4s2s2", true)
        self:SetServerAddresInfo(addres)
        --print("------>>", table.dump(addres))
        self:Send10000()
    elseif code == LoginDef.LoginCode.POP_BY_ANOTHER then
        self:OnPopByAnother()
    elseif code == LoginDef.LoginCode.AUTH_FAIL then
        self:OnAuthFail()
    elseif code == LoginDef.LoginCode.KICKED then
        if subcocde == 0 then
            self:OnKICKED()
        elseif subcocde == 1 then
            self:OnBan()
        end
    elseif code == LoginDef.LoginCode.INVALID then
        --连接超时
        self:INVALID()
    end
end

-- 验证失败
function LoginProxy:OnAuthFail()
    cGameNetWork:Close()
    -- GameLogicTools.ShowConfirmById(29, function(bvalue)
    self:ToNotify(self.data, LoginDef.NotifyDef.Sdk_Login_Auth_Fail, { reloginType = IGGSdkDef.ReloginType.Expire })
    -- end)
end

-- 被人顶号
function LoginProxy:OnPopByAnother()
    cGameNetWork:Close()
    self:ClearHeartbeat()
    if SystemConfig.isIGGPlatform() then
        local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
        IGGSdkProxy.Instance:ShowRelogin(IGGSdkDef.ReloginType.Kick)
    else
        GameLogicTools.ShowConfirmById(17, function()
            --被人顶号
            Application.Quit()
        end)
    end

    -- local SceneManager = require "Modules.Scene.SceneManager"
    -- local SceneDef = require "Modules.Scene.SceneDef"
    -- local sceneType = SceneManager.Instance:GetCurSceneType()
    -- if SceneDef.SceneType.Login == sceneType then
    --     GameLogicTools.ShowConfirmById(17, function()
    --         --被人顶号
    --         local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
    --         IGGSdkProxy.Instance:ShowRelogin(IGGSdkDef.ReloginType.Kick)
    --     end)
    -- else
    --     GameLogicTools.ShowConfirmById(17, function()
    --         --被人顶号
    --         Application.Quit()
    --     end)
    -- end
end

--踢人
function LoginProxy:OnKICKED()
    cGameNetWork:Close()
    self:ClearHeartbeat()
    -- GameLogicTools.ShowConfirmById(30, function(bvalue)
    --     Application.Quit()
    -- end)
    self:ShowConfirmView(30, function(bvalue)
        Application.Quit()
    end)
end

function LoginProxy:OnBan()
    cGameNetWork:Close()
    self:ClearHeartbeat()
    -- GameLogicTools.ShowConfirmById(27, function(bvalue)
    --     Application.Quit()
    -- end)
    self:ShowConfirmView(27, function(bvalue)
        Application.Quit()
    end)
end

function LoginProxy:INVALID()
    local SceneManager = require "Modules.Scene.SceneManager"
    local SceneDef = require "Modules.Scene.SceneDef"
    local bBattle = SceneManager.Instance:InBattle()
    local curScene = SceneManager.Instance:GetCurSceneType()
    if bBattle then
        return
    end

    cGameNetWork:Close()
    self:ClearHeartbeat()
    if curScene == SceneDef.SceneType.Login then
        GameLogicTools.ShowConfirmById(37, function()
            Application.Quit()
        end)
    else
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ReconnectView)
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.NetworkDelayView)
        GameLogicTools.ShowConfirmById(1, function(ok)
            if ok then
                self.data.code = 0
                self:StartReconnect()
            else
                LuaMain.ReBoot()
            end
        end)
    end
end

--在登陆界面的部分特殊弹窗，需要去掉黑色遮罩，让后面的tsh按钮被点到
--27, 29, 30
function LoginProxy:ShowConfirmView(id, callback)
    local SceneManager = require "Modules.Scene.SceneManager"
    local SceneDef = require "Modules.Scene.SceneDef"
    local curScene = SceneManager.Instance:GetCurSceneType()
    if curScene == SceneDef.SceneType.Login then
        local config = ConfigManager.GetConfig("data_tips").confirm_tips[id]
        if config then
            local ConfirmView = require "First.Update.View.ConfirmView"
            local LanguageUtil = require "First.Util.LanguageUtil"      
            local content = string.format(LanguageUtil.GetWord(config.strContent))
            ConfirmView.Show(content, callback, config.strLeft, config.strRight, config.strMiddle, config.type, config.strTitle, config.bclose,id, config.depth, config.bclickBack, false)
        end 
    else
        GameLogicTools.ShowConfirmById(id, callback)
    end
end

function LoginProxy:Send10000()
    local encoder = NetEncoder.New()
    encoder:Encode("s2", (SystemConfig.ResVersion ~= "") and SystemConfig.ResVersion or Application.version)
    self:SendMessage(10000, encoder)
end

function LoginProxy:On10000(decoder)
    local result, bgm = decoder:Decode("BB")
    if bgm == 0 then
        SystemConfig.is_gm = true
    else
        SystemConfig.is_gm = false
    end
    --版本号过低提示
    if result == 2 then
        -- GameLogicTools.ShowConfirmById(14, function(bvalue)
        --     CS.UnityEngine.Application.Quit()
        --     end)
        -- return
    end
    self:Send10001()
end

function LoginProxy:Send10001()
    self:SendMessage(10001)
end

function LoginProxy:On10001(decoder)
    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ReconnectView)
    self:ClearDelayTimer()

    self:SendHeartbeat()
end

--心跳包
function LoginProxy:SendHeartbeat()
    table.insert(self.heartbeatlist, os.time())
    self:Send10018()
    self.heartbeatTimer = Timer.New(function()
        if #self.heartbeatlist >= 6 then
            self:OnTcpConnectFail(2)
        else
            table.insert(self.heartbeatlist, os.time())
            self:Send10018()
        end
    end, 5, -1)
    self.heartbeatTimer:Start()
end

function LoginProxy:ClearHeartbeat()
    if self.heartbeatTimer then
        self.heartbeatTimer:Stop()
        self.heartbeatTimer = nil
    end

    self.heartbeatlist = {}

    if self.servertimer then
        self.servertimer:Stop()
        self.servertimer = nil
    end

    ChatProxy.Instance:RemoveChatHearbeat()
end

function LoginProxy:ClearLoginTimer()
    if self.heartbeatTimer then
        self.heartbeatTimer:Stop()
        self.heartbeatTimer = nil
    end

    if self.servertimer then
        self.servertimer:Stop()
        self.servertimer = nil
    end

    if self._delayTimer then
        self._delayTimer:Stop()
        self._delayTimer = nil
    end
end

function LoginProxy:ClearDelayTimer()
    if self._delayTimer then
        self._delayTimer:Stop()
        self._delayTimer = nil
    end
    self.data.delayTime = 0
end

function LoginProxy:Send10018()
    self:SendMessage(10018)
end

function LoginProxy:On10018(decoder)
    table.remove(self.heartbeatlist, 1)
    self:SetServerTime(decoder:Decode("I4"))
	
    if not self.servertimer then
        self.servertimer = Timer.New(
                function()
					self:SetServerTime(RoleInfoModel.servertime + 1)
                end, 1, -1)
        self.servertimer:Start()
    end
end

function LoginProxy:SetServerTime(serverTime)
	local lastServerTime = RoleInfoModel.servertime
	RoleInfoModel.servertime = serverTime
	if not DateFormatUtil.IsSameDay(lastServerTime, RoleInfoModel.servertime) then
		self:SendFacedeNotify(LoginDef.NotifyDef.Cross_Day)
	end
end

--------------------------------
function LoginProxy:OnTcpConnectSuc()
    print("connect server suc!")
    self:Send1030()
    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ReconnectView)
    if self.reconnecttimer then
        self.reconnecttimer:Stop()
        self.reconnecttimer = nil
    end
    if self.data.isreconnecting then
        self.data.isreconnect = true
        self.data.isreconnecting = false
    else
        self.data.isreconnect = false
    end

    --商城推送礼包(超时后连接成功，则弹出)
    if self.data.isReconnectTimeout then
        local MallProxy = require "Modules.Mall.MallProxy"
        MallProxy.Instance:ShowPushView()
    end
    self.data.isReconnectTimeout = false
end

function LoginProxy:OnTcpConnectFail(state)
    --print("connect server fail state:", state, self.data.isreconnecting, self.data.isreconnect)

    if state ~= 4 then
        if self.data.isreconnecting then
            self.data.isreconnecting = false
        else
            self:StartReconnect()
        end
    end
end

function LoginProxy:StartReconnect()
    --local SceneManager = require "Modules.Scene.SceneManager"
    local BattleProxy = require "Modules.Battle.BattleProxy"
    local in_battle = BattleProxy.Instance:IsInBattle()
    --print("--in_battle", in_battle)
    if in_battle then --战斗场景不进行断线重连
        return
    end

    --1030返回error code失败不重连
    if self.data.code == LoginDef.LoginCode.AUTH_FAIL or self.data.code == LoginDef.LoginCode.POP_BY_ANOTHER or
            self.data.code == LoginDef.LoginCode.SHUTDOWN or self.data.code ==  self.data.code == LoginDef.LoginCode.KICKED then
        print("self.data.code", self.data.code)
        return
    end
    --if self.data.code ~= 0 then
    --    print("self.data.code", self.data.code)
    --    return
    --end

    self:ClearHeartbeat()

    self:ClearDelayTimer()
    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.ReconnectView)
    local reconnecttimes = 0
    if self.reconnecttimer then
        self.reconnecttimer:Stop()
        self.reconnecttimer = nil
    end

    self.reconnecttimer = Timer.New(function()
        if reconnecttimes > 10 then
            self:ReconnectTimeout()
        else
            if not self.data.isreconnecting then
                reconnecttimes = reconnecttimes + 1
                self:Reconnect()
            end
        end
    end, 0.5, -1)
    self.reconnecttimer:Start()
end

function LoginProxy:ReconnectTimeout()
    print("ReconnectTimeout -----")
    if self.reconnecttimer then
        self.reconnecttimer:Stop()
        self.reconnecttimer = nil
    end
    self.data.isReconnectTimeout = true

    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.ReconnectView)

    --重连30次都不成功, 弹窗提示
    GameLogicTools.ShowConfirmById(1, function(ok)
        if ok then
            self:StartReconnect()
        else
            --Application.Quit()
            LuaMain.ReBoot()
        end
    end)
end

function LoginProxy:Reconnect()
    --print("LoginProxy----------------->>Reconnect")
    self.data.isreconnecting = true
    if self.data.serverhost and self.data.serverport then
        cGameNetWork:ConnectTcpSocket(self.data.serverhost, self.data.serverport,
                function()
                    self:OnTcpConnectSuc()
                end,
                function(state)
                    self:OnTcpConnectFail(state)
                end)
    end
end

-------------------------------------http------------
function LoginProxy:start_login(username, password, part_id)
    local p = {
        ["account"] = username,
        ["password"] = password,
    }

    local params = {}
    params.access_token = self:cms_encrypt(rapidjson.encode(p))
    local baseUrl = SystemConfig.Router
    local url = baseUrl .. LoginDef.api.login

    print("------------start_login------------", url, part_id)
    httputil.post_error(url, params, function(text)
        local t = rapidjson.decode(text)
        if not t then
            print("------------sdk_login failed------------")
            self:ToNotify(self.data, LoginDef.NotifyDef.sdk_igg_login_fail)
            return
        end
        print("------------sdk_login suc------------", table.dump(t))
        self:sdk_login_suc(t, part_id)
    end)
end

function LoginProxy:sdk_login_suc(data, part_id)
    part_id = part_id or 1
    if data.code == 0 then
        self:start_get_account(data.msg.player_id, data.msg.token, data.msg.tick, part_id)
    else
        GameLogicTools.ShowMsgTips(string.format("ErrorCode:%s msg:%s", data.code, data.msg))
        self:ToNotify(self.data, LoginDef.NotifyDef.sdk_igg_login_fail)
    end
end

function LoginProxy:start_get_account(id, token, tick, server_id)

    if RoleInfoModel.severdata then

        server_id = RoleInfoModel.severdata.server_id
        print("------start_get_account----server_id--------", server_id)
    end
    local params = {}
    params.player_id = id
    params.token = token
    params.tick = tick or os.time()
    params.version = string.format("%s_%s", Application.version, SystemConfig.ResVersion or "0")
    params.part = server_id   --非必选参数，更换服务器的时候才需要
    params.deviceid = ""

    local SdkProxy = require "Modules.Sdk.SdkProxy"
    local cKungfuInstance = CS.LJY.NX.KungfuInstance
    if SdkProxy.Instance:isIGGPlatform() and cKungfuInstance then
        local udid = cKungfuInstance.Get().UDID
        params.deviceid = udid
    end

    RoleInfoModel.player_id = id
    RoleInfoModel.token = token
    --print("--------player_id------------",id)

    self.data.account = { player_id = id, token = token }

    local baseUrl = SystemConfig.Router
    local url = baseUrl .. LoginDef.api.get_token .. self:get_package_id()
    print("------------start request server info------------", url, server_id, table.dump(params))
    httputil.post_error(url, params, function(text)
        local t = rapidjson.decode(text)
        if not t then
            print("------------start request server info failed ------------")
            self:ToNotify(self.data, LoginDef.NotifyDef.sdk_igg_login_fail)
            return
        end
        print("------------start request server info suc ------------", table.dump(t))
        self:get_token_suc(t)
    end)
end

function LoginProxy:get_token_suc(data)
    if data then
        if data.code == 0 then
            if data.user and data.user.is_ban and data.user.is_ban == 1 then
                -- GameLogicTools.ShowConfirmById(27, function(bvalue)
                --     self:ToNotify(self.data, LoginDef.NotifyDef.Sdk_Login_Auth_Fail, {reloginType = IGGSdkDef.ReloginType.Other})
                -- end)
                self:ShowConfirmView(27, function(bvalue)
                    self:ToNotify(self.data, LoginDef.NotifyDef.Sdk_Login_Auth_Fail, { reloginType = IGGSdkDef.ReloginType.Other })
                end)
                return
            end

            RoleInfoModel.uid = tonumber(data.user.uin)
            if SystemConfig.isIGGTestPlatform() then
                local SdkProxy = require "Modules.Sdk.SdkProxy"
                SdkProxy.Instance:sdk_setuserid(RoleInfoModel.uid)
            end
            RoleInfoModel.logintoken = data.user.serverToken
            RoleInfoModel.tradeuid = data.user.trade_uin

            local zone_id, part_id = data.user.zone, data.user.part
            RoleInfoModel.zone_id = zone_id or 0
            RoleInfoModel.server_id = part_id or 0

            self.data.sdkData = {
                cache = data.user.sdkData.cache or 0, --int
                iggid = data.user.sdkData.iggid or 0, --int
                version = data.user.sdkData.version or "", --string
                lifecycle = data.user.sdkData.iggid or 0, --int
                deviceid = data.user.sdkData.deviceid or "", --string
            }

            self.socketInfo = { name = "", ip = data.conn_host, ports = data.conn_port }  --ports:端口列表

            self:ToNotify(self.data, LoginDef.NotifyDef.Sdk_Login_Suc)
        elseif data.code == 1 or data.code == 9 then
            -- 登录失败
            -- GameLogicTools.ShowConfirmById(29, function(bvalue)
            --     self:ToNotify(self.data, LoginDef.NotifyDef.Sdk_Login_Auth_Fail, {reloginType = IGGSdkDef.ReloginType.Other})
            -- end)
            self:ShowConfirmView(29, function(bvalue)
                self:ToNotify(self.data, LoginDef.NotifyDef.Sdk_Login_Auth_Fail, { reloginType = IGGSdkDef.ReloginType.Other })
            end)
        elseif data.code == 910 then
            -- token过期
            local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
            IGGSdkProxy.Instance:invalidate_current_session()  --将账号设置为过期
            -- GameLogicTools.ShowConfirmById(26, function(bvalue)
            self:ToNotify(self.data, LoginDef.NotifyDef.Sdk_Login_Auth_Fail, { reloginType = IGGSdkDef.ReloginType.Expire })
            -- end)
        elseif data.code == 911 then
            --被封
        else
            -- GameLogicTools.ShowConfirmById(29, function(bvalue)
            --     self:ToNotify(self.data, LoginDef.NotifyDef.Sdk_Login_Auth_Fail, {reloginType = IGGSdkDef.ReloginType.Other})
            -- end)
            self:ShowConfirmView(29, function(bvalue)
                self:ToNotify(self.data, LoginDef.NotifyDef.Sdk_Login_Auth_Fail, { reloginType = IGGSdkDef.ReloginType.Other })
            end)
        end
    end
end

function LoginProxy:GetServerTcpSocket()
    local ip, port, name
    if not SystemConfig.IsDebug then
        local SdkProxy = require "Modules.Sdk.SdkProxy"
        if self:Is_WLan_Release() then
            if self.socketInfo then
                ip = self.socketInfo.ip
                port = tonumber(self.socketInfo.ports[1])
                name = self.socketInfo.name
            end
            --igg
        elseif SdkProxy.Instance:isIGGPlatform() then
            if self.socketInfo then
                ip = self.socketInfo.ip
                port = tonumber(self.socketInfo.ports[1])
                name = self.socketInfo.name
            end
            --自己后台返回的地址
        elseif self.socketInfo then
            ip = self.socketInfo.ip
            port = tonumber(self.socketInfo.ports[1])
            name = self.socketInfo.name
        end
    else
        --local LoginProxy = require "Modules.Login.LoginProxy"
        if RoleInfoModel.severdata then
            ip = RoleInfoModel.severdata.server_addr
            name = RoleInfoModel.severdata.name
            port = tonumber(RoleInfoModel.severdata.server_port[1])
        end

    end
    return ip, port, name
end

function LoginProxy:SetLoginInfo(ip, port, name)
    if self:GetServerTcpSocket() then
        ip, port, name = self:GetServerTcpSocket()
    end

    self.data.serverhost = ip
    self.data.serverport = port
    self.data.servername = name
    RoleInfoModel.severdata = nil
end

function LoginProxy:start_connect(ip, port, name)
    self:SetLoginInfo(ip, port, name)

    -- print(string.format("connect server start: name:%s ip:%s port:%s", self.data.servername, self.data.serverhost, self.data.serverport))
    if self.data.serverhost and self.data.serverport then
        cGameNetWork:ConnectTcpSocket(self.data.serverhost, self.data.serverport,
                function()
                    self:OnTcpConnectSuc()
                end,
                function(state)
                    self:OnTcpConnectFail(state)
                end)
    end
end

function LoginProxy:get_package_id()
    local SdkProxy = require "Modules.Sdk.SdkProxy"
    local isIgg = SdkProxy.Instance:isIGGPlatform()
    if isIgg then
        local LanguageUtil = require "First.Util.LanguageUtil"
        local game_id = LanguageUtil.GetLanguageGameId()
        local igg_package_id = LanguageUtil.GetAgentPackageIDByGameId(game_id)
        if igg_package_id then
            return igg_package_id
        else
            return 20001
        end
    else
        return SystemConfig.AgentPackageID
    end
end

function LoginProxy:GetIsReconnect()
    return self.data.isreconnect
end

function LoginProxy:SetIsReconnect(isreconnect)
    self.data.isreconnect = isreconnect
end

function LoginProxy:cms_encrypt(str)
    str = string.gsub(str, "%s+", "")
    str = crypt.base64encode(str)
    str = string.gsub(str, "=", "|")
    local n = math.random(1, 9)
    local key = string.sub(md5.sumhexa(os.time()), 1, n)
    str = key .. str .. n

    str = crypt.base64encode(str)
    str = string.gsub(str, "=", "|")
    n = math.random(1, 9)
    key = string.sub(md5.sumhexa(os.time()), 1, n)
    str = n .. str .. key
    return str
end

--外网 release
function LoginProxy:Is_WLan_Release()
    if SystemConfig.isIGGTestPlatform() and SystemConfig.CurAppType == SystemConfig.AppType.Release and SystemConfig.CurAppWeb == SystemConfig.AppWeb.Wlan then
        return true
    end
    return false
end

function LoginProxy:SendBuryingPoint(location)
    if not location then
        return
    end

    local params = {}
    params.trade_uin = RoleInfoModel.tradeuid
    params.uin = RoleInfoModel.uid
    params.package = SystemConfig.AgentPackageID
    params.location = location

    local baseUrl = SystemConfig.Router
    local url = baseUrl .. "/single/burying_point"
    print("------------send burying point------------", table.dump(params), url)
    httputil.post(url, params, function(text)
    end)
end

function LoginProxy:GetServerInfos()
    return self.data.serverhost, self.data.serverport
end

function LoginProxy:ApplicationPause(pause)
    --print("ApplicationPause -->", pause, os.time())
    if self.data.bPause ~= pause then
        self.data.bPause = pause
        if not self.data.bPause then
            if os.time() - self.data.fPauseTime > 300 then
                --print("ApplicationPause > 300秒 --> reconnect")
                cGameNetWork:Close()
                self:ClearHeartbeat()
                LuaLayout.Instance:OpenWidget(UIWidgetNameDef.ReconnectView)
                self:Reconnect()
            --elseif not cGameNetWork:CheckConnect() then
            --    print("ApplicationPause disconnect --> reconnect")
            --    cGameNetWork:Close()
            --    self:ClearHeartbeat()
            --    self:Reconnect()
            end
        end
    end
    self.data.fPauseTime = os.time()
end

function LoginProxy:GMLogin(uin)
    RoleInfoModel.uid = 1111368959
    SystemConfig.AgentID = 1
    RoleInfoModel.player_id = 1078580914

    self.data.serverhost = "connectserver17.rod.igotgames.net"
    self.data.serverport = 18001
    self.data.servername = "17"

    RoleInfoModel.uid = tonumber(1111368959)
    RoleInfoModel.logintoken = "f7717f7e9bbcd62285d4b6fc1c1c001b"
    RoleInfoModel.tradeuid = 1078580914

    local zone_id, part_id = 1, 17
    RoleInfoModel.zone_id = zone_id or 0
    RoleInfoModel.server_id = part_id or 0

    cGameNetWork:ConnectTcpSocket(self.data.serverhost, self.data.serverport,
            function()
                self:OnTcpConnectSuc()
            end,
            function(state)
                self:OnTcpConnectFail(state)
            end)
end

return LoginProxy
