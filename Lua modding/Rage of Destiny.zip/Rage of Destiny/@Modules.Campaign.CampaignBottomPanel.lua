local CampaignProxy = require "Modules.Campaign.CampaignProxy"
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"
local MainDef = require "Modules.Main.MainDef"
local NewbieManager = require "Modules.Newbie.NewbieManager"
local NewbieDef = require "Modules.Newbie.NewbieDef"
local NewbieWidget = require "Core.Implement.UI.Widgets.NewbieWidget"
local ModuleManager = require "Common.Mgr.UI.ModuleManager"
local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
local TerritoryProxy = require "Modules.Territory.TerritoryProxy"
local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
local RedPointDef = require "Modules.RedPoint.RedPointDef"
local GameUIUtil = CS.GameUIUtil

local CampaignBottomPanel = CampaignBottomPanel or BaseClass(GameObjFactor, TimerFactor, NewbieWidget)

function CampaignBottomPanel:__init(obj)
	--打开对应界面
	self.openWidgetFuncKey = {
		[1] = {"OpenTerritoryView"},  --领地
		[2] = {"OpenJourneyView"},  --OpenJourneyView
		[3] = {"OpenHeroRootView"},  --英雄
		[4] = {"OpenCampaignView"},  --战役
		[5] = {"OpenChatRootView"},  --聊天
	}

	--等级开启
	self.systemOpenKey = {
		[1] = {ModuleOpenDef.SystemOpenType.TerritoryView},  --领地
		[2] = {ModuleOpenDef.SystemOpenType.Journey},  --征途
		[3] = {ModuleOpenDef.SystemOpenType.HeroRootView},  --英雄
		[4] = {ModuleOpenDef.SystemOpenType.Campaign},  --战役
		[5] = {ModuleOpenDef.SystemOpenType.ChatRootView},  --聊天
	}
	--领地 战役 征途
	self.openSpecialViews = {
		[1] = {},
		[2] = {},
		[4] = {},
	}

	--聊天 英雄  选中页签的时候默认选中上一个self.openSpecialViews的页签
	self.openNormalViews = {
		[3] = {},
		[5] = {},
	}

	self.go = obj
	self:Load(obj)
end

function CampaignBottomPanel:Load(obj)
	self.rect = self:GetComponent(obj, "RectTransform")
	self.rectPosition = self.rect.anchoredPosition

	self.horizonalObj = self:GetChild(obj, "CHorizontalItem")
	self.btnItems = {}
	for i=1,5 do
		local item = {}
		local obj = self:GetChild(self.horizonalObj, string.format("item%d", i))
		local btn = self:GetComponent(obj, "CButton")
		btn:AddClick(function()
			self:OnClickBtn(i)
			if i == 3 or i == 4 then
				--特殊引导手动关闭写死
				LuaLayout.Instance:CloseWidget(UIWidgetNameDef.NewbieSpecialWeakView)
				local NewbieProxy = require "Modules.Newbie.NewbieProxy"
				local NewbieDef = require "Modules.Newbie.NewbieDef"
				NewbieProxy.Instance:TriggerSpecailNewbie(NewbieDef.NewbieConst.MainlineFailBack, 4)
			end

			--
			LuaLayout.Instance:CloseWidget(UIWidgetNameDef.MallPushView)
		end)
		item.cBtn = btn
		item.obj = obj
		item.normalObj = self:GetChild(obj, "CSprite_normal")
		item.selectObj = self:GetChild(obj, "CSprite_select")
		item.grayObj = self:GetChild(obj, "CSprite_gray1")
		item.redDotObj = self:GetChild(obj, "CSprite_redpoint")
		if item.redDotObj then
			item.redDotObj:SetActive(false)
		end
		table.insert(self.btnItems, item)
	end

	RedPointProxy.Instance:BindNode(RedPointDef.Id.Territory, self.btnItems[1].redDotObj)
	RedPointProxy.Instance:BindNode(RedPointDef.Id.Journey, self.btnItems[2].redDotObj)
	RedPointProxy.Instance:BindNode(RedPointDef.Id.Hero, self.btnItems[3].redDotObj)
end

function CampaignBottomPanel:Open()
	self.curSelect = 4
	self:SelectItem(self.curSelect)
	self:DelayRegisterNewbieData()
	local MazeProxy = require "Modules.Maze.MazeProxy"
	local bshow = MazeProxy.Instance:GetMazeCacheRedDot2()
	if bshow then
		MazeProxy.Instance:GetMapLevelInfo()
	end

	local TowerProxy = require "Modules.Tower.TowerProxy"
	local bshow = TowerProxy.Instance:GetTowerRedDotStatus()
	if bshow then
		TowerProxy.Instance:Send52000()
	end

	self:SetTerritoryRedDot()
	self:SetFieldRedDot()
	self:UpdateBtnState()
end

function CampaignBottomPanel:Close()
	self:ClearNewbieTimer()
	self:UnRegisterNewbie()
end

function CampaignBottomPanel:Destroy()
	self:ClearNewbieTimer()
	self:UnRegisterNewbie()
end

--野外红点
function CampaignBottomPanel:SetFieldRedDot()
end

--领地红点
function CampaignBottomPanel:SetTerritoryRedDot()
end

--notify刷新红点
function CampaignBottomPanel:ShowRedDot(type, num)
	-- if type == MainDef.MainRedDotType.Hero then
	-- 	local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.HeroRootView, false)
	-- 	if bopen then
	-- 		self.btnItems[3].redDotObj:SetActive(num>0 and true or false) --英雄
	-- 	end
	-- end
end

function CampaignBottomPanel:StartOpenTween()

end

--从其他场景回到主界面打开的是1:领地还是4:战役还是2征途
function CampaignBottomPanel:SceneToMainSceneSelectItem(index)
	if index == 4 then
		self:RegisterNewbieData()
	elseif index == 1 then
		self:RegisterNewbieData()
	elseif index == 2 then
	end
	self:SelectItem(index)
	self:SetTerritoryRedDot()
end

function CampaignBottomPanel:OnClickBtn(index)
	if self.openWidgetFuncKey[index] then
		local funcName = self.openWidgetFuncKey[index][1]
		if self[funcName] then
			local bopen = self[funcName](self, index)
			if bopen then
				if self.openNormalViews[index] then
					self:SelectItem(self.specialIndex~=nil and self.specialIndex or 4)
				else
					self:SelectItem(index)
				end
			end
		end
	end
end

function CampaignBottomPanel:SelectItem(index)
	self.curSelect = index
	for i,item in ipairs(self.btnItems) do
		item.selectObj:SetActive(index == i and true or false)
		item.normalObj:SetActive(index ~= i and true or false)
	end
	if self.openSpecialViews[index] then
		self.specialIndex = index
	end
end

--迷宫引导结束后引导点击战役（特殊引导，需要手动关闭界面）
function CampaignBottomPanel:OpenMazeCompleteNewbie()
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	local NewbieProxy = require "Modules.Newbie.NewbieProxy"
	NewbieProxy.Instance:ShowMazeCompleteWeakNewbie(self.btnItems[4].cBtn)
end

--打开特殊引导
function CampaignBottomPanel:OpenSpecialNewbie()
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	local NewbieProxy = require "Modules.Newbie.NewbieProxy"
	NewbieProxy.Instance:StartSpecialNewbie(true, self.btnItems[3].cBtn, NewbieDef.NewbieConst.MainlineFailBack, 3)
end

--注册引导数据
function CampaignBottomPanel:RegisterNewbieData()
	local mainlineid = RoleInfoModel.mainlineid
	local NewbieManager = require "Modules.Newbie.NewbieManager"
	local NewbieDef = require "Modules.Newbie.NewbieDef"
	for _newbie_id, _steps in pairs(NewbieDef.CampaignBottom) do
		for i,infos in ipairs(_steps) do
			local cfg1 = NewbieManager.Instance:GetNewbieStepConfig(_newbie_id,infos[1]) --主线1-13引导点击领地 按钮
			if cfg1 and cfg1.parama and cfg1.parama.mainlineid and cfg1.parama.mainlineid == mainlineid then
				self:RegisterButton(self.btnItems[infos[2]].cBtn, _newbie_id, infos[1])
			end
		end
	end

	self:OpenSpecialNewbie()
end

function CampaignBottomPanel:DelayRegisterNewbieData()
	self:ClearNewbieTimer()
	self.delaytimer = self:AddTimer(function()
		self:RegisterNewbieData()
	end, 0.4, 1)
end

function CampaignBottomPanel:ClearNewbieTimer()
	if self.delaytimer then
		self:RemoveTimer(self.delaytimer)
		self.delaytimer = nil
	end
end


--打开聊天
function CampaignBottomPanel:OpenChatRootView()
	UIOperateManager.Instance:OpenWidget(AppFacade.Chat)
end
--打开领地
function CampaignBottomPanel:OpenTerritoryView()
	local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.TerritoryView)
	if bopen then
		TerritoryProxy.Instance:SetTerritoryOpenState(true,UIWidgetNameDef.TerritoryView)
		self:OnTriggerClickBtn(self.btnItems[1].cBtn)
    end
	return bopen
end

--返回战役
function CampaignBottomPanel:OpenCampaignView(needToOpenViews)
	TerritoryProxy.Instance:SetTerritoryOpenState(false)
	LuaLayout.Instance:CloseWidget(UIWidgetNameDef.TerritoryView)
	LuaLayout.Instance:CloseWidget(UIWidgetNameDef.FieldView)
	local render_area = require "Battle.render.render_area"
	render_area.show()
	local view= LuaLayout.Instance:GetWidget(UIWidgetNameDef.CampaignView)
	if view then
		view:SetMiddleAndLeftObjShowState(true)
	end
	local AudioManager = require "Common.Mgr.Audio.AudioManager"
	AudioManager.PlayBGM("main_bg")
	self:OnTriggerClickBtn(self.btnItems[4].cBtn)
	
	if needToOpenViews and (type(needToOpenViews) == "table") then
		for i, v in ipairs(needToOpenViews) do
			LuaLayout.Instance:OpenWidget(v)
		end
	end
	
	return true
end
--打开征途
function CampaignBottomPanel:OpenJourneyView()
	local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.Journey)
	if bopen then
		--打开征途界面
		TerritoryProxy.Instance:SetTerritoryOpenState(true,UIWidgetNameDef.FieldView)
		self:OnTriggerClickBtn(self.btnItems[2].cBtn)
		-- LuaLayout.Instance:CloseWidget(UIWidgetNameDef.TerritoryView)
		-- LuaLayout.Instance:OpenWidget(UIWidgetNameDef.FieldView)
		-- local view= LuaLayout.Instance:GetWidget(UIWidgetNameDef.CampaignView)
		-- if view then
		-- 	view:SetMiddleAndLeftObjShowState(false)
		-- end
	end
	return bopen
end
--打开英雄
function CampaignBottomPanel:OpenHeroRootView()
	local ModuleManager = require "Common.Mgr.UI.ModuleManager"
	local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
	local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.HeroRootView)
	if bopen then
		UIOperateManager.Instance:OpenWidget(AppFacade.Hero, 8)
		TerritoryProxy.Instance:OpenOtherWidget()
	end
	
	self:OnTriggerClickBtn(self.btnItems[3].cBtn)
	return bopen
end


function CampaignBottomPanel:PlaySound()

end

function CampaignBottomPanel:UpdateBtnState()
	if self.btnItems then
		for i, btn in ipairs(self.btnItems) do
			if btn.cBtn then
				if btn.cBtn.gameObject.activeSelf then
					local open = ModuleManager.SystemIsOpen(self.systemOpenKey[i][1], false)
					btn.cBtn.OpenButtonEffect = open
					GameUIUtil.SetGroupAlpha(btn.normalObj, open and 1 or 0.4)
				end
			end
		end
	end
end

return CampaignBottomPanel