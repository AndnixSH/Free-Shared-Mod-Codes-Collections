local SdkProxy = require "Modules.Sdk.SdkProxy"
local SocketListPanel = require "Modules.Login.SocketListPanel"
local LoginPanelView = require "Modules.Login.LoginPanelView"
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"
local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"

local LoginView = LoginView or LuaWidgetClass()

local LoginProxy = require "Modules.Login.LoginProxy"

function LoginView:__init()
    self.bLoginType = true  --是否在登陆打开界面
end

function LoginView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Login.LoginView",self.LoadEnd)
end
    
function LoginView:LoadEnd(obj)
	self:SetGo(obj)

	self.socketPanel = SocketListPanel.New(self:GetChild(obj, "Combo"))
	self.loginPanelView = LoginPanelView.New(self:GetChild(obj, "LoginPanel"))

    self.versionLab = self:GetChildComponent(self.go, "Vision", "CLabel")
    self.versionLab.text = tostring(Application.version).."_"..tostring(SystemConfig.ResVersion) --(SystemConfig.ResVersion ~= "") and SystemConfig.ResVersion or Application.version
	
    self.tshBtn = self:GetChildComponent(self.go, "CButton_New", "CButton")
    self.tshBtn.gameObject:SetActive(false)
    self.tshBtn:AddClick(function()
        local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
        IGGSdkProxy.Instance:OpenTSH()
    end)

    self.loginBkObj = self:GetChild(self.go, "bg")
    self.loginBkObj:SetActive(false)
    self.logeTex = self:GetChildComponent(self.loginBkObj, "LOGO", "CTexture")
    self:SetStep(0)
end

function LoginView:ShowTSHButtonActive(bActive)
    if SystemConfig.isIGGPlatform() then
        local SdkManager = require "First.Sdk.SdkManager"
        if SdkManager.IsSdkInitSus() then
            self.tshBtn.gameObject:SetActive(bActive)
        end
    end
end

function LoginView:ShowLogoTex()
    local LanguageUtil = require "First.Util.LanguageUtil"
    local str = LanguageUtil.GetLanguageDes()
    local tex_path = string.format("Background.Tex_%s_logo", str)
    if str == "Jianti" then
        tex_path = "Background.Tex_English_logo"
    end
    self.logeTex.Path = tex_path
end

function LoginView:OnOpen()
	self:AutoRegister()
    -- self.backEffect:Open()
    self.socketPanel:Open()

    if self.bLoginType then
	   self.loginPanelView:Open()
    end
    --登陆时打开 隐藏背景;  重新登陆时显示背景
    self.loginBkObj:SetActive(self.bLoginType == false and true or false)
    self:ShowTSHButtonActive(self.bLoginType == false and true or false)
    self:ShowLogoTex()
    local AudioManager = require "Common.Mgr.Audio.AudioManager"
    AudioManager.PlayBGM("login_bg")
end

function LoginView:ShowPanelActive()
    self.loginPanelView:ShowPanelActive()
end

function LoginView:OnClose()
    self.bLoginType = false
    self.loginPanelView:Close()
    self.socketPanel:Close()
	self:AutoUnRegister()
end

function LoginView:OnDestroy()
    self.bLoginType = false
    self.loginPanelView:Destroy()
    self.socketPanel:Destroy()
	self:AutoUnRegister()
end

function LoginView:LoginServer()
	local ip, port, name 
	local selectData = self.socketPanel.selectData
	if selectData then
		ip, port, name = selectData.ip, selectData.port, selectData.name
	end
	LoginProxy.Instance:start_connect(ip, port, name)
end

function LoginView:GetSocketPanelPartId()
    local part_id = nil
    if self.socketPanel.selectData then
        part_id = self.socketPanel.selectData.part_id
    end
    part_id = part_id or 1
    return part_id
end





------------EvtNotify------------
function LoginView.EvtNotify.Sdk.data:sdk_igg_login_fail()
    print("sdk igg login fail -> relogin")
    if SystemConfig.isIGGTestPlatform() then
        self:ShowPanelActive()
    elseif SystemConfig.isIGGPlatform() then
        IGGSdkProxy.Instance:sdk_igg_login_fail()
    end

    -- if SdkProxy.Instance:isIGGPlatform() then
    --     self.lastLoginType = self:GetIggLast_Login_Type()
    --     local str = self:GetIggLast_Login_TypeStr(self.lastLoginType)
    --     self.iggBtnLab1.text = str
    --     self.iggObj:SetActive(true)
    -- end
end

-- auth fail
function LoginView.EvtNotify.Login.data:Sdk_Login_Auth_Fail(data, args)
    print("token auth failed -> relogin")
    if SystemConfig.isIGGTestPlatform() then
        self:ShowPanelActive()
    elseif SystemConfig.isIGGPlatform() then
        IGGSdkProxy.Instance:Sdk_Login_Auth_Fail(args)
    end

    -- if SdkProxy.Instance:isIGGPlatform() then
    --     self.lastLoginType = self:GetIggLast_Login_Type()
    --     local str = self:GetIggLast_Login_TypeStr(self.lastLoginType)
    --     self.iggBtnLab1.text = str
    --     SdkProxy.Instance:igg_login_session_invalidate()
    --     self.iggObj:SetActive(true)
    -- end
end

function LoginView.EvtNotify.Login.data:Sdk_Login_Suc()
    if self.loginPanelView then
        self.loginPanelView:sdk_login_suc()

        self.issdkloginsuc = true
        self:LoginServer()
    end
end



return LoginView
