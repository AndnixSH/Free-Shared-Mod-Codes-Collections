local logic = template({}, "sprite.buff.buff_timemerge")

function logic.timer:f1()
    if self.addvalue and self.owner.attr.sld == 0 then
        self.buff:stop()
    end
end

function logic:ontstart(level)

    local addvalue = 0
    local target, attrtarget, percent, attr, value = table.unpack(self.static.args_script[1])

    local targetobj = self:gettargetobj(target)
    local attrtargetobj = self:gettargetobj(attrtarget)
    if percent == 1 then
        local attrname = CONST.ATTR[attr]
        local value = self:amendment(value)
        addvalue = tsmath.rate(attrtargetobj.attr[attrname], value)
    else
        addvalue = self:amendment(value)
    end
    self.addvalue = (self.addvalue or 0) + addvalue
    targetobj.caller.hp:change_sld(addvalue)
    
    -- print("tstart", self.addvalue, self.owner.attr.sld)
end

function logic:ontstop(level)
    self.caller.hp:change_sld(-tsmath.min(self.addvalue, self.owner.attr.sld), true)

    -- print("tend", self.addvalue, self.owner.attr.sld)

end

return logic