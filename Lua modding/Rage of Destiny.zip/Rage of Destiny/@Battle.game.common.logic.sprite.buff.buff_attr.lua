local logic = template({}, "sprite.buff.buff_timemerge")

function logic:oncreate()

    self.attr_table = {}
    for _, args in ipairs(self.static.args_script) do
        local target, attrtarget, percent, attr, value = table.unpack(args)
        table.insert(self.attr_table, { target = target, attrtarget = attrtarget, percent = percent, attrname = CONST.ATTR[attr], value = value, _orign = value, _sum = 0 })
    end
end

function logic:ontstart(level)

    for _, attr in ipairs(self.attr_table) do
        attr.value = self:amendment(attr._orign)
        if attr.target ~= attr.attrtarget then
            local attrtargetobj = self:gettargetobj(attr.attrtarget)
            attr.value = tsmath.rate(attrtargetobj.attr[attr.attrname], attr.value)
        end
        attr._sum = attr._sum + attr.value
        self:_change_value(attr.target, attr.attrtarget, attr.percent, attr.attrname, attr.value)
    end

end

function logic:ontstop(level)
    for _, attr in ipairs(self.attr_table) do
        self:_change_value(attr.target, attr.attrtarget, attr.percent, attr.attrname, -attr._sum)
    end
end


function logic:_change_value(target, attrtarget, percent, attrname, value)

    local targetobj = self:gettargetobj(target)

    if not targetobj then return end

    if percent == 1 then
        if target == attrtarget then
            targetobj.attr:setpercent(attrname, value)
        else
            targetobj.attr:setbase(attrname, value)
        end
    else
        targetobj.attr:setbase(attrname, value)
    end

end


return logic