local GuildDef = require "Modules.Guild.GuildDef"
local BattleProto = require "Core.Implement.Net.BattleProto"
local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
local RedPointDef = require "Modules.RedPoint.RedPointDef"
local Timer =  require "Common.Util.Timer"
local HeroProxy = require "Modules.Hero.HeroProxy"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local DateFormatUtil = require "Common.Util.DateFormatUtil"

local GuildProxy = GuildProxy or BaseClass(BaseProxy, BattleProto)

function GuildProxy:__init()
	GuildProxy.Instance = self

	self.bPlayBgm = false

	self.data = {}
	self.data.guildInfos = {}

	self.data.guildBossInfos = {}
	self.data.guildBossInfos.nowBossType = GuildDef.BossType.Normal
	self.data.guildBossInfos.progressInfo = {}
	self.data.guildBossInfos.isNewDiff = false --是否达到新的阶数

	--初始化boss最大难度
	local bossMaxDiff = {-1,-1}
	local bossConfig = self:GetBossConfig()
	for k,v in pairs(bossConfig) do 
		if v.difficulty > bossMaxDiff[v.mode] then
			bossMaxDiff[v.mode] = v.difficulty
		end
	end
	self.data.guildBossInfos.bossMaxDiff = bossMaxDiff
	-- print("GuildProxy:__init", table.dump(bossMaxDiff))

	--混沌裂隙
	self.data.chaosInfo = {}
	self.data.chaosInfo.nowBossId = 0 --当前BossId
	self.data.chaosInfo.nowRoomId = 0 --当前RoomId
	self.data.chaosInfo.maxDamage = 0 --本期最高伤害
	self.data.chaosInfo.nowFreeChallengeTimes = 0 --当前免费挑战次数
	self.data.chaosInfo.nowGemChallengeTimes = 0 --当前钻石挑战次数
	self.data.chaosInfo.lastSettleTime = 0 --上次结算时间
	self.data.chaosInfo.honourList = {} --全服荣耀段列表
	self.data.chaosInfo.rankInfos = {} --key:段位 value:{前5列表,总人数}
	self.data.chaosInfo.honourMemberList = {} --公会荣耀段列表
	self.data.chaosInfo.honourRank = nil --自己的荣耀排名
	self.data.chaosInfo.honourPromoteDamage = 0 --晋级要达到的伤害
	self.data.chaosInfo.isShowLastRank = false --是否显示上期排行
	self.data.chaosInfo.isPlayLastReport = false --是否在播上期战报
	self.data.chaosInfo.lastBossId = nil --上期BossId
	self.data.chaosInfo.lastRoomId = nil --上期RoomId
	self.data.chaosInfo.reportOpenViews = nil --播完战报后打开的界面
	self.data.chaosInfo.rankViewParas = nil --保存RankView的一些变量,用于播完战报后界面的数据恢复
	self.data.chaosInfo.behindViewParas = nil --保存BehindView的一些变量,用于播完战报后界面的数据恢复
	self.data.chaosInfo.otherRoomId = nil --他人RoomId,用于查看他人战报
	self.data.chaosInfo.isRequireSettle = false --是否在结算中

	self:AddProto(70000, self.On70000)
	self:AddProto(70001, self.On70001)
	self:AddProto(70002, self.On70002)
	self:AddProto(70003, self.On70003)
	self:AddProto(70004, self.On70004)
	self:AddProto(70005, self.On70005)
	self:AddProto(70006, self.On70006)
	self:AddProto(70007, self.On70007)
	self:AddProto(70008, self.On70008)
	self:AddProto(70009, self.On70009)
	self:AddProto(70010, self.On70010)
	self:AddProto(70011, self.On70011)
	self:AddProto(70012, self.On70012)
	self:AddProto(70013, self.On70013)
	self:AddProto(70014, self.On70014)
	self:AddProto(70015, self.On70015)
	self:AddProto(70016, self.On70016)
	self:AddProto(70017, self.On70017)
	self:AddProto(70018, self.On70018)
	self:AddProto(70019, self.On70019)
	self:AddProto(70020, self.On70020)
	self:AddProto(70021, self.On70021)
	self:AddProto(70022, self.On70022)

	self:AddProto(70023, self.On70023)
	self:AddProto(70024, self.On70024)
	self:AddProto(70025, self.On70025)
	self:AddProto(70026, self.On70026)
	self:AddProto(70027, self.On70027)

	self:AddProto(70028, self.On70028) --备战
	self:AddProto(70029, self.On70029) --上阵

	self:AddProto(70030, self.On70030) --等级提升的提示
	self:AddProto(70031, self.On70031) --取消等级提升的提示

	-- Guild boss
	self:AddProto(70100, self.On70100) -- 请求boss进度信息
	self:AddProto(70101, self.On70101) -- 准备挑战
	self:AddProto(70102, self.On70102) -- 开始挑战
	self:AddProto(70103, self.On70103) -- 扫荡
	self:AddProto(70104, self.On70104) -- 开启公会高级boss
	self:AddProto(70105, self.On70105) -- 排行榜
	self:AddProto(70106, self.On70106) -- 最高排行榜信息
	self:AddProto(70107, self.On70107) -- 我的排行榜信息
	self:AddProto(70108, self.On70108) -- 刷新扫荡状态
	self:AddProto(70109, self.On70109) -- 请求战报
	self:AddProto(70111, self.On70111) -- 公会boss开启

	-- 混沌裂隙
	self:AddProto(70200, self.On70200) -- 请求基础信息
	self:AddProto(70203, self.On70203) -- 重置次数
	self:AddProto(70204, self.On70204) -- 挑战记录
	self:AddProto(70205, self.On70205) -- 全服排行榜

	self:AddPreBattle(ACTIVITYID.GUILD_BOSS, self.OnPreBattle) --准备战斗回调
	self:AddSetBattle(ACTIVITYID.GUILD_BOSS, self.OnSetBattle) --战斗结算回调
	self:AddStartBattle(ACTIVITYID.GUILD_BOSS, self.OnStartBattle) --战斗开始回调
end

function GuildProxy:__delete()
	self:ClearBgmTimer()
	self.bPlayBgm = false
	self.data = {}
end

function GuildProxy:Send70000()
	self:SendMessage(70000)
end

function GuildProxy:On70000(decoder)
	-- print("GuildProxy:On70000")
	local result = decoder:Decode("I2")
	self.data.guildInfos = {}
	if result == 0 then
		--没有公会
		self.data.guildInfos.bguild = false
		self:CloseGuildViews()
	elseif result == 1 then
		--有公会
		local guildInfos = {}
		guildInfos.bguild = true
		guildInfos.guild_id, guildInfos.name, guildInfos.icon_id, guildInfos.announcement, guildInfos.notice, guildInfos.level = decoder:Decode("I4s2I2s2s2I2")
		guildInfos.guild_exp, guildInfos.liveness = decoder:Decode("I4I4") --公会活跃度, 公会当前活跃度 可消耗
		local jion_condition = decoder:DecodeList("I2") --入会条件
		guildInfos.condition_limit, guildInfos.level_limit = jion_condition[1], jion_condition[2]
		guildInfos.persident = decoder:Decode("I8") --会长

		guildInfos.guild_elders = {} --副会长列表
		local elder_count = decoder:Decode("I2") 
		for i=1,elder_count do
			guildInfos.guild_elders[decoder:Decode("I8")] = true
		end

		guildInfos.guild_exemplar = {} --无畏之手列表
		local exemplar_count = decoder:Decode("I2") 
		for i=1,exemplar_count do
			guildInfos.guild_exemplar[decoder:Decode("I8")] = true
		end

		guildInfos.memberInfos = {}
		guildInfos.job = GuildDef.Job.Member
		local count = decoder:Decode("I2")
		for i=1,count do
			local item = {}

			local headItem = {}
			item.guser = decoder:Decode("I8")
			headItem.nickname = decoder:Decode("s2")
			headItem.sex = decoder:Decode("I2")
			headItem.headIcon = decoder:Decode("I4")
			headItem.frameIcon= decoder:Decode("I4")
			headItem.level = decoder:Decode("I2")
			item.headItem = headItem
			item.liveness = decoder:Decode("I4")
			
			local job = GuildDef.Job.Member
			if guildInfos.persident == item.guser then
				job = GuildDef.Job.Persident
			elseif guildInfos.guild_elders[item.guser] then
				job = GuildDef.Job.ViceChairman
			end
			item.job = job
			local fearlessHand = guildInfos.guild_exemplar[item.guser] and GuildDef.Job.FearlessHand or 0
			item.fearlessHand = fearlessHand

			item.lineState = decoder:Decode("I8") --在线状态  0:在线  大于0：离线时间
			item.serverId, item.sevenActivityPoint = decoder:Decode("I2I2")
			-- print(headItem.nickname, item.serverId)
			table.insert(guildInfos.memberInfos, item)

			if RoleInfoModel.guserid == item.guser then
				guildInfos.job = item.job  --自己的公会职位信息
				guildInfos.fearlessHand = item.fearlessHand
			end
		end
		guildInfos.todayActivityPoint, guildInfos.sevenActivityPoint, guildInfos.creatTime = decoder:Decode("I2I2I4")
		-- print(guildInfos.todayActivityPoint, guildInfos.sevenActivityPoint)

		guildInfos.isLevelUpTips = decoder:Decode("I1")

		-- print(table.dump(os.date("*t", guildInfos.creatTime)))
		-- print(guildInfos.level, guildInfos.icon_id)

		self.data.guildInfos = guildInfos
		LuaLayout.Instance:CloseWidget(UIWidgetNameDef.GuildRootView)

		self:UpdateBossRedPointOpenHigh()
		-- self:EnterGuildTrack(guildInfos.guild_id)
	elseif result == 2 then
		self:CloseGuildViews()
	end
	--print("=============", table.dump(self.data.guildInfos))
	self:ToNotify(self.data, GuildDef.Notify.UpdateGuildInfos, {result = result, guildInfos = self.data.guildInfos})

	self:UpdateBossRedPointChallenge()

	RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.GuildLevelIcon, self:GetIsLevelUpTips())
end

--没有公会关闭界面
function GuildProxy:CloseGuildViews()
	LuaLayout.Instance:CloseWidget(UIWidgetNameDef.GuildHallView)
	LuaLayout.Instance:CloseWidget(UIWidgetNameDef.GuildApplyView)
	LuaLayout.Instance:CloseWidget(UIWidgetNameDef.GuildEditorView)
	LuaLayout.Instance:CloseWidget(UIWidgetNameDef.GuildLogoView)
	LuaLayout.Instance:CloseWidget(UIWidgetNameDef.GuildNameView)
	LuaLayout.Instance:CloseWidget(UIWidgetNameDef.GuildNoticeView)
	LuaLayout.Instance:CloseWidget(UIWidgetNameDef.GuildRecordView)
	LuaLayout.Instance:CloseWidget(UIWidgetNameDef.GuildSetView)
	LuaLayout.Instance:CloseWidget(UIWidgetNameDef.GuildEntranceView)
end


function GuildProxy:GetoinGroupEventKey(key)
    local value = PlayerPrefs.GetInt(key, 0)
    return value
end

function GuildProxy:SetoinGroupEventKey(key, value)
    PlayerPrefs.SetInt(key, value)
end

--加入公会事件
function GuildProxy:EnterGuildTrack(guild_id)
    local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
    local IGGSdkDef = require "Modules.IGGSdk.IGGSdkDef"
    local rapidjson = require "rapidjson"
    local key = IGGSdkDef.JoinGroupEventKey .. RoleInfoModel.guserid
	local value = self:GetoinGroupEventKey(key)
	if guild_id and value == 0 then
		IGGSdkProxy.Instance:SendJoinGroup(guild_id)
	    self:SetoinGroupEventKey(key, 1)
	end

	--红点
	self:SetBossChallengeRedValue(GuildDef.BossType.Normal, 0)
	self:SetBossChallengeRedValue(GuildDef.BossType.High, 0)
	self:UpdateBossRedPointChallenge()
end



function GuildProxy:Send70001(icon_id, guild_name, announcement)
	local encoder = NetEncoder.New()
	encoder:Encode("I2s2s2", icon_id, guild_name, announcement)
	self:SendMessage(70001, encoder)
end

function GuildProxy:On70001(decoder)
	local result = decoder:Decode("I2")
	-- print("GuildProxy:On70001", result)
	if result == 0 then
		LuaLayout.Instance:OpenWidget(UIWidgetNameDef.GuildHallView)
		local guild_id = decoder:Decode("I4")
		self:EnterGuildTrack(guild_id)
	else
		GameLogicTools.ShowErrorCode(70001, result)	
	end
end

--申请加入公会
function GuildProxy:Send70002(guild_id)
	local encoder = NetEncoder.New()
	encoder:Encode("I4", guild_id)
	self:SendMessage(70002, encoder)
end

function GuildProxy:On70002(decoder)
	local result = decoder:Decode("I2")
	if result == 0 then
		local guild_id = decoder:Decode("I4")
		local bupdate = false
		if self.data.recommends then
			for i,v in ipairs(self.data.recommends) do
				if v.guild_id == guild_id then
					v.bapply = 1 --0：没申请过 1申请过
					bupdate = true
					break
				end
			end
		end

		if self.data.searchInfos then
			for i,v in ipairs(self.data.searchInfos) do
				if v.guild_id == guild_id then
					v.bapply = 1 --0：没申请过 1申请过
					bupdate = true
					break
				end
			end
		end

		if bupdate then
			self:ToNotify(self.data, GuildDef.Notify.UpdateApplyGuildStatus, {guild_id = guild_id, recommends = self.data.recommends, searchInfos = self.data.searchInfos})
		end
	end
	
	if result == 6 then --退出公会cd
		local exitGuildTime = decoder:Decode("I8")
		self:ShowExitCDTips(exitGuildTime)
    else
		GameLogicTools.ShowErrorCode(70002, result)	
	end
end

function GuildProxy:ShowExitCDTips(exitGuildTime)
	local LanguageManager = require "Common.Mgr.Language.LanguageManager"
	local time = exitGuildTime + GuildDef.Parama.Guild_Exit_CD - RoleInfoModel.servertime
	local str

	time = math.ceil(time / 60)
	str = time .. LanguageManager.Instance:GetWord("Common_1067")
	str = LanguageManager.Instance:GetWord("GuildView_1018", str)
	GameLogicTools.ShowMsgTips(str)
end

--退出公会
function GuildProxy:Send70003()
	self:SendMessage(70003)
end

function GuildProxy:On70003(decoder)
	local result = decoder:Decode("I2")
	if result == 0 then
		self:Send70000()
	end
	GameLogicTools.ShowErrorCode(70003, result)	
end

--公会申请列表
function GuildProxy:Send70004()
	self:SendMessage(70004)
end

function GuildProxy:On70004(decoder)
	local applyInfos = {}
	local result = decoder:Decode("I2")
	if result == 0 then
		local count = decoder:Decode("I2")
		for i=1,count do
			local item = {}
			local headItem = {}
			headItem.nickname = decoder:Decode("s2")
			headItem.sex = decoder:Decode("I2")
			headItem.headIcon = decoder:Decode("I4")
			headItem.frameIcon= decoder:Decode("I4")
			headItem.level = decoder:Decode("I2")
			headItem.fight = decoder:Decode("I4")
			item.headItem = headItem

			item.guser = decoder:Decode("I8")
			table.insert(applyInfos, item)
		end
	end

	self.data.applyInfos = applyInfos
	self:ToNotify(self.data, GuildDef.Notify.UpdateApplyInfos, {applyInfos = applyInfos})
end

--1:拒绝 2：同意
function GuildProxy:Send70005(_type, guserid)
	local encoder = NetEncoder.New()
	encoder:Encode("I2I8", _type, guserid)
	self:SendMessage(70005, encoder)
end

function GuildProxy:On70005(decoder)
	local result = decoder:Decode("I2")
	-- print("GuildProxy:On70005", result)
	if result == 0 or result == 5 or result == 8 then
		self:Send70004()
	end
	GameLogicTools.ShowErrorCode(70005, result)
end

--1:一键拒绝申请 2：一键同意申请
function GuildProxy:Send70006(_type)
	local encoder = NetEncoder.New()
	encoder:Encode("I2", _type)
	self:SendMessage(70006, encoder)
end

function GuildProxy:On70006(decoder)
	local result = decoder:Decode("I2")
	--print("GuildProxy:On70006", result)
	-- if result == 5 or result == 6 then
		self:Send70004()
	-- end
	GameLogicTools.ShowErrorCode(70006, result)
end

--任命 2：副会长  4：无畏之手
function GuildProxy:Send70007(guser, _type)
	local encoder = NetEncoder.New()
	encoder:Encode("I8I2", guser, _type)
	self:SendMessage(70007, encoder)
end

function GuildProxy:On70007(decoder)
	local result = decoder:Decode("I2")
	if result == 0 or result == 11 then
		local guser_id,job = decoder:Decode("I8I2")
		if self.data.guildInfos.memberInfos then
			for i,info in ipairs(self.data.guildInfos.memberInfos) do
				if info.guser == guser_id then
					if job == GuildDef.Job.ViceChairman then
						info.job = GuildDef.Job.ViceChairman
					elseif job == GuildDef.Job.FearlessHand then
						info.fearlessHand = GuildDef.Job.FearlessHand
					end
					break
				end
			end
		end

		if job == GuildDef.Job.ViceChairman then
			self.data.guildInfos.guild_elders[guser_id] = true
		elseif job == GuildDef.Job.FearlessHand then
			self.data.guildInfos.guild_exemplar[guser_id] = true
		end

		self:ToNotify(self.data, GuildDef.Notify.UpdateGuildJob)
	end
	GameLogicTools.ShowErrorCode(70007, result)
end

--罢免 2：副会长  4：无畏之手
function GuildProxy:Send70008(guser, _type)
	local encoder = NetEncoder.New()
	encoder:Encode("I8I2", guser, _type)
	self:SendMessage(70008, encoder)
end

function GuildProxy:On70008(decoder)
	local result = decoder:Decode("I2")
	if result == 0 or result == 5 then
		local guser_id,job = decoder:Decode("I8I2")
		if self.data.guildInfos.memberInfos then
			for i,info in ipairs(self.data.guildInfos.memberInfos) do
				if info.guser == guser_id then
					if job == GuildDef.Job.ViceChairman then
						info.job =  GuildDef.Job.Member
					elseif job == GuildDef.Job.FearlessHand then
						info.fearlessHand = 0
					end
					break
				end
			end
		end
		if job == GuildDef.Job.ViceChairman then
			self.data.guildInfos.guild_elders[guser_id] = false
		elseif job == GuildDef.Job.FearlessHand then
			self.data.guildInfos.guild_exemplar[guser_id] = false
		end
		self:ToNotify(self.data, GuildDef.Notify.UpdateGuildJob)
	end
	GameLogicTools.ShowErrorCode(70008, result)
end

--禅让
function GuildProxy:Send70009(guser)
	local encoder = NetEncoder.New()
	encoder:Encode("I8", guser)
	self:SendMessage(70009, encoder)
end

function GuildProxy:On70009(decoder)
	local result = decoder:Decode("I2")
	if result == 3 then
		local guser_id = decoder:Decode("I8")
		local self_guser = RoleInfoModel.guserid

		if self.data.guildInfos.memberInfos then
			self.data.guildInfos.persident = guser_id
			self.data.guildInfos.job = GuildDef.Job.Member
			local findIndex 
			for i,_guser in ipairs(self.data.guildInfos.guild_elders) do
				if _guser == guser_id then
					findIndex = i
					break
				end
			end

			if findIndex then
				table.remove(self.data.guildInfos.guild_elders, findIndex)
			end

			for i,info in ipairs(self.data.guildInfos.memberInfos) do
				if info.guser == guser_id then
					info.job = GuildDef.Job.Persident
				elseif info.guser == self_guser then
					info.job = GuildDef.Job.Member
				end
			end
		end
		self:ToNotify(self.data, GuildDef.Notify.UpdateDemise)
	end

	GameLogicTools.ShowErrorCode(70009, result)

end

--逐出公会
function GuildProxy:Send70010(guser)
	local encoder = NetEncoder.New()
	encoder:Encode("I8", guser)
	self:SendMessage(70010, encoder)
end

function GuildProxy:On70010(decoder)
	local result = decoder:Decode("I2")
	if result == 0 then
		local guser_id = decoder:Decode("I8")
		local findIndex
		if self.data.guildInfos.memberInfos then
			for i,info in ipairs(self.data.guildInfos.memberInfos) do
				if info.guser == guser_id then
					findIndex = i
					break
				end
			end
		end
		if findIndex then
			table.remove(self.data.guildInfos.memberInfos, findIndex)
		end

		self.data.guildInfos.guild_elders[guser_id] = false
		self.data.guildInfos.guild_exemplar[guser_id] = false
		self:ToNotify(self.data, GuildDef.Notify.UpdateMemberInfosCount)
	end

	GameLogicTools.ShowErrorCode(70010, result)
end

--修改公告
function GuildProxy:Send70011(notice)
	local encoder = NetEncoder.New()
	encoder:Encode("s2", notice)
	self:SendMessage(70011, encoder)
end

function GuildProxy:On70011(decoder)
	local result = decoder:Decode("I2")
	if result == 0 then
		local notice = decoder:Decode("s2")
		if self.data.guildInfos then
			self.data.guildInfos.notice = notice
		end
		self:ToNotify(self.data, GuildDef.Notify.UpdateNotice, {notice = notice})
	end
	GameLogicTools.ShowErrorCode(70011, result)
end

--设置入会条件
function GuildProxy:Send70012(conditionType, levelType)
	local encoder = NetEncoder.New()
	encoder:Encode("I2I2", conditionType, levelType)
	self:SendMessage(70012, encoder)
	-- print("GuildProxy:Send70012", conditionType, levelType)
end

function GuildProxy:On70012(decoder)
	local result = decoder:Decode("I2")
	if result == 0 then
		local conditionType, levelType = decoder:Decode("I2I2")
		if self.data.guildInfos then
			self.data.guildInfos.condition_limit = conditionType
			self.data.guildInfos.level_limit = levelType
		end
		self:ToNotify(self.data, GuildDef.Notify.UpdateLimit, {conditionType = conditionType, levelType = levelType})
	end
	GameLogicTools.ShowErrorCode(70012, result)
end

--修改公会图标
function GuildProxy:Send70013(icon_id)
	local encoder = NetEncoder.New()
	encoder:Encode("I2", icon_id)
	self:SendMessage(70013, encoder)
end

function GuildProxy:On70013(decoder)
	local result = decoder:Decode("I2")
	if result == 0 then
		local icon_id = decoder:Decode("I2")
		if self.data.guildInfos then
			self.data.guildInfos.icon_id = icon_id
		end
		self:ToNotify(self.data, GuildDef.Notify.UpdateGuildIcon, {icon_id = icon_id})
	end
end

--修改公会名
function GuildProxy:Send70014(guild_name)
	local encoder = NetEncoder.New()
	encoder:Encode("s2", guild_name)
	self:SendMessage(70014, encoder)
end

function GuildProxy:On70014(decoder)
	local result = decoder:Decode("I2")
	if result == 0 then
		local guild_name = decoder:Decode("s2")
		if self.data.guildInfos then
			self.data.guildInfos.name = guild_name
		end
		self:ToNotify(self.data, GuildDef.Notify.UpdateGuildName, {guild_name = guild_name})
	end
	GameLogicTools.ShowErrorCode(70014, result)
end

function GuildProxy:Send70015()
	self:SendMessage(70015)
end

function GuildProxy:On70015(decoder)
	local logInfos = {}
	local result = decoder:Decode("I2")
	if result then
		local count = decoder:Decode("I2")
		for i=1,count do
			local item = {}
			item.logType = decoder:Decode("I2")
			item.from_name, item.to_name = decoder:Decode("s2s2")
			item.logTime = decoder:Decode("I4")
			table.insert(logInfos, item)
		end
		table.sort(logInfos, function(a, b)
			return a.logTime > b.logTime
		end)
		self.data.logInfos = logInfos
	end
	self:ToNotify(self.data, GuildDef.Notify.UpdateLogInfos, {logInfos = logInfos})
end

function GuildProxy:Send70016()
	self:SendMessage(70016)
end

function GuildProxy:On70016(decoder)
	local recommends = {}
	local refreshCount = decoder:Decode("I2") --公会刷新次数
	local count = decoder:Decode("I2")
	for i=1,count do
		local item = {}
		item.guild_id = decoder:Decode("I4")
		item.guild_name = decoder:Decode("s2")
		item.icon_id = decoder:Decode("I2")
		item.level = decoder:Decode("I2")
		item.member_num = decoder:Decode("I2")
		local cfg = self:GetLevelConfigByLevel(item.level)
		item.total_num = cfg.population  --总人数
		item.liveness = decoder:Decode("I4") --公会活跃度
		item.condition_limit, item.level_limit = decoder:Decode("I2I2")
		item.bapply = decoder:Decode("I2") --0:没申请过  1：申请过
		table.insert(recommends, item)
	end
	self.data.recommends = recommends
	self:ToNotify(self.data, GuildDef.Notify.UpdateRecommendInfos, {recommends = recommends})

end

--查看公会
function GuildProxy:Send70017(guild_id)
	local encoder = NetEncoder.New()
	encoder:Encode("I4", guild_id)
	self:SendMessage(70017, encoder)
end

function GuildProxy:On70017(decoder)
	local guildInfos = {}
	local result = decoder:Decode("I2")
	if result == 0 then
		guildInfos.name = decoder:Decode("s2")
		guildInfos.icon_id = decoder:Decode("I2")
		guildInfos.guild_id, guildInfos.announcement = decoder:Decode("I4s2")
		guildInfos.level = decoder:Decode("I2")
		guildInfos.liveness = decoder:Decode("I4")
		local jion_condition = decoder:DecodeList("I2")
		guildInfos.condition_limit, guildInfos.level_limit = jion_condition[1], jion_condition[2]

		guildInfos.persident = decoder:Decode("I8") --会长

		guildInfos.guild_elders = {} --副会长列表
		local elder_count = decoder:Decode("I2") 
		for i=1,elder_count do
			guildInfos.guild_elders[decoder:Decode("I8")] = true
		end

		guildInfos.guild_exemplar = {} --无畏之手列表
		local exemplar_count = decoder:Decode("I2") 
		for i=1,exemplar_count do
			guildInfos.guild_exemplar[decoder:Decode("I8")] = true
		end

		guildInfos.bapply = decoder:Decode("I2") --0:没申请过  1：申请过

		local liveness = 0 --公会总活跃度
		local persidentName = ""
		guildInfos.memberInfos = {}
		local count = decoder:Decode("I2")
		for i=1,count do
			local item = {}

			local headItem = {}
			item.guser = decoder:Decode("I8")
			headItem.nickname = decoder:Decode("s2")
			headItem.sex = decoder:Decode("I2")
			headItem.headIcon = decoder:Decode("I4")
			headItem.frameIcon= decoder:Decode("I4")
			headItem.level = decoder:Decode("I2")
			item.headItem = headItem

			local job = GuildDef.Job.Member
			if guildInfos.persident == item.guser then
				job = GuildDef.Job.Persident
			elseif guildInfos.guild_elders[item.guser] then
				job = GuildDef.Job.ViceChairman
			end
			item.job = job
			local fearlessHand = guildInfos.guild_exemplar[item.guser] and GuildDef.Job.FearlessHand or 0
			item.fearlessHand = fearlessHand

			item.liveness = decoder:Decode("I4")
			item.lineState = decoder:Decode("I8") --在线状态  0:在线  大于0：离线时间

			item.serverId, item.sevenActivityPoint = decoder:Decode("I2I2")

			table.insert(guildInfos.memberInfos, item)
			if item.job == GuildDef.Job.Persident then
				persidentName = headItem.nickname
			end

		end
		guildInfos.liveness = liveness
		guildInfos.persidentName = persidentName
	end
	self:ToNotify(self.data, GuildDef.Notify.UpdateOtherGuildInfo, {result = result, guildInfos = guildInfos})
end

function GuildProxy:Send70018()
	self:SendMessage(70018)
end

function GuildProxy:On70018(decoder)
	local applyList = decoder:DecodeList("I4")
	self:ToNotify(self.data, GuildDef.Notify.UpdateHadApplyInfos, {applyList = applyList})
end

function GuildProxy:Send70019(search_content)
	local encoder = NetEncoder.New()
	encoder:Encode("s2", search_content)
	self:SendMessage(70019, encoder)
end

function GuildProxy:On70019(decoder)
	local searchInfos = {}
	local count = decoder:Decode("I2")
	for i=1,count do
		local item = {}
		item.guild_id = decoder:Decode("I4")
		item.guild_name = decoder:Decode("s2")
		item.icon_id = decoder:Decode("I2")
		item.level = decoder:Decode("I2")
		item.member_num = decoder:Decode("I2")
		local cfg = self:GetLevelConfigByLevel(item.level)
		item.total_num = cfg.population  --总人数

		item.liveness = decoder:Decode("I4")
		local jion_condition = decoder:DecodeList("I2")
		item.condition_limit, item.level_limit = jion_condition[1], jion_condition[2]
		item.bapply = decoder:Decode("I2") --0:没申请过  1：申请过
		table.insert(searchInfos, item)
	end
	self.data.searchInfos = searchInfos
	self:ToNotify(self.data, GuildDef.Notify.UpdateSearchInfos, {searchInfos = searchInfos})

	if count == 0 then
		GameLogicTools.ShowMsgTips("GuildView_1019")
	end
end

--修改公会宣言
function GuildProxy:Send70020(announcement)
	local encoder = NetEncoder.New()
	encoder:Encode("s2", announcement)
	self:SendMessage(70020, encoder)
end

function GuildProxy:On70020(decoder)
	local result = decoder:Decode("I2")
	if result == 0 then
		local announcement = decoder:Decode("s2")
		if self.data.guildInfos then
			self.data.guildInfos.announcement = announcement
		end
		self:ToNotify(self.data, GuildDef.Notify.UpdateAnnouncement, {announcement = announcement})
	end
	GameLogicTools.ShowErrorCode(70020, result)
end

function GuildProxy:Send70021()
	self:SendMessage(70021)
end

function GuildProxy:On70021(decoder)
	local result = decoder:Decode("I2")
	if result == 0 then
		self:Send70000()
	end
	GameLogicTools.ShowErrorCode(70021, result)	
end

function GuildProxy:Send70022()
	self:SendMessage(70022)
end

function GuildProxy:On70022(decoder)
	--result为0时，cdTime 返回的是刷新时的时间戳 result为1时，返回的是剩余多少秒可刷新
	local result, cdTime = decoder:Decode("I2I4")
	if result == 0 then
		local recommends = {}
		local refresh_count = decoder:Decode("I2")
		local count = decoder:Decode("I2")
		for i=1,count do
			local item = {}
			item.guild_id = decoder:Decode("I4")
			item.guild_name = decoder:Decode("s2")
			item.icon_id = decoder:Decode("I2")
			item.level = decoder:Decode("I2")
			item.member_num = decoder:Decode("I2")
			local cfg = self:GetLevelConfigByLevel(item.level)
			item.total_num = cfg.population  --总人数
			item.liveness = decoder:Decode("I4") --公会活跃度
			-- local jion_condition = decoder:DecodeList("I2")
			item.condition_limit, item.level_limit = decoder:Decode("I2I2")
			item.bapply = decoder:Decode("I2") --0:没申请过  1：申请过
			table.insert(recommends, item)
		end
		self.data.recommends = recommends
		self:ToNotify(self.data, GuildDef.Notify.UpdateRecommendInfos, {recommends = recommends, cdTime = cdTime})

	else

	end
end

--公会成员增加，公会成员减少
function GuildProxy:On70023(decoder)
	local result = decoder:Decode("I2")
	if result == 2 then
		--公会新成员增加
		local add_count = decoder:Decode("I2")
		if self:ExistGuild() then
			local infos = {}
			for i=1,add_count do
				local item = {}
				local headItem = {}
				item.guser = decoder:Decode("I8")
				headItem.nickname = decoder:Decode("s2")
				headItem.sex = decoder:Decode("I2")
				headItem.headIcon = decoder:Decode("I4")
				headItem.frameIcon= decoder:Decode("I4")
				headItem.level = decoder:Decode("I2")
				item.headItem = headItem
				item.liveness = decoder:Decode("I4")
				item.server_Id = 1 --可以通过guserid得到
				
				item.job = GuildDef.Job.Member
				item.fearlessHand = 0

				item.lineState = decoder:Decode("I4") --在线状态  0:在线  大于0：离线时间
				if RoleInfoModel.guserid ~= item.guser then
					table.insert(self.data.guildInfos.memberInfos, item)
				end
			end
			self:ToNotify(self.data, GuildDef.Notify.UpdateMemberInfosCount)
		end
	elseif result == 1 then
		--公会成员减少
		local delect_list = decoder:DecodeList("I8")
		if self:ExistGuild() then
			for i,_guser in ipairs(delect_list) do
				self.data.guildInfos.guild_elders[_guser] = false
				self.data.guildInfos.guild_exemplar[_guser] = false
				for j,info in ipairs(self.data.guildInfos.memberInfos) do
					if _guser == info.guser then
						table.remove(self.data.guildInfos.memberInfos, j)
						break
					end
				end
			end
			self:ToNotify(self.data, GuildDef.Notify.UpdateMemberInfosCount)
		end
	end
end

function GuildProxy:On70024(decoder)
	local result = decoder:Decode("I2")
	if result == 0 then
		LuaLayout.Instance:OpenWidget(UIWidgetNameDef.GuildHallView)
		local guild_id = decoder:Decode("I4")
		self:EnterGuildTrack(guild_id)
	end
end
function GuildProxy:Send70025()
	self:SendMessage(70025)
end

function GuildProxy:On70025(decoder)
	local result = decoder:Decode("I2")
	if result == 0 then
		LuaLayout.Instance:OpenWidget(UIWidgetNameDef.GuildHallView)
		local guild_id = decoder:Decode("I4")
		self:EnterGuildTrack(guild_id)
	end

	if result == 2 then --退出公会cd
		local exitGuildTime = decoder:Decode("I8")
		self:ShowExitCDTips(exitGuildTime)
	else
		GameLogicTools.ShowErrorCode(70025, result)
	end
end

function GuildProxy:Send70026(open_chaos)
	self.open_chaos = open_chaos
	self:SendMessage(70026)
end

function GuildProxy:On70026(decoder)
	local result = decoder:Decode("I2")
	if result == 0 then
		LuaLayout.Instance:OpenWidget(UIWidgetNameDef.GuildEntranceView)
		if self.open_chaos then
			LuaLayout.Instance:OpenWidget(UIWidgetNameDef.GuildChaosView)
		end
	else
		LuaLayout.Instance:OpenWidget(UIWidgetNameDef.GuildRootView)
	end
	self.open_chaos = nil
end

function GuildProxy:On70027(decoder)
	local bguild = decoder:Decode("I2")
	if bguild == 0 then
		--被同意加入公會
		self.data.guildInfos.bguild = true
		LuaLayout.Instance:CloseWidget(UIWidgetNameDef.GuildRootView)
		local guild_id = decoder:Decode("I4")
		self:EnterGuildTrack(guild_id)
		self:ToNotify(self.data, GuildDef.Notify.UpdatePassedGuild)
	else
		--被逐出工會
		self.data.guildInfos.bguild = false
		self:CloseGuildViews()
		self:ToNotify(self.data, GuildDef.Notify.UpdateKickOutGuild)
	end
end

----------------------------------------------------------切磋 start
function GuildProxy:Send70028(guser)
	local encoder = NetEncoder.New()
	encoder:Encode("I8", guser)
	self:SendMessage(70028, encoder)

	local BattleProxy = require "Modules.Battle.BattleProxy"
    BattleProxy.Instance:BattleReadySetStep(ACTIVITYID.GUILD_VERSUS, 1)
end

function GuildProxy:On70028(decoder)
	local result = decoder:Decode("I1")
	if result ~= 0 then
	    local BattleProxy = require "Modules.Battle.BattleProxy"
        BattleProxy.Instance:BattleReadyNextStep(ACTIVITYID.GUILD_VERSUS, 1)
	end
end

--开始挑战
function GuildProxy:Send70029(hero_infos, enemy_infos)
	local encoder = NetEncoder.New()
    self:_EncodeHeroInfo(hero_infos, encoder)
    self:_EncodeEnemyInfo(enemy_infos, encoder)
	self:SendMessage(70029, encoder)
end

function GuildProxy:On70029(decoder)
end
----------------------------------------------------------切磋 end

function GuildProxy:On70030(decoder)
	-- print("GuildProxy:On70030")
	RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.GuildLevelIcon, 1)
end

function GuildProxy:Send70031()
	-- print("GuildProxy:Send70031")
	self:SendMessage(70031)
end

function GuildProxy:On70031(decoder)
	-- print("GuildProxy:On70031")
	RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.GuildLevelIcon, 0)
end

function GuildProxy:OpenGuildRootView()
	if self:ExistGuild() then
		LuaLayout.Instance:OpenWidget(UIWidgetNameDef.GuildHallView)
	else
		LuaLayout.Instance:OpenWidget(UIWidgetNameDef.GuildRootView)
	end
end

function GuildProxy:PlayGuildBgm()
	local AudioManager = require "Common.Mgr.Audio.AudioManager"
	if self.bPlayBgm == false then
		self.bPlayBgm = true
		AudioManager.PlayBGM("gonghui_entry_bg")
		self:ClearBgmTimer()
		self.bgmTimer = Timer.New(function()
			AudioManager.PlayBGM("gonghui_bg")
		end, 31, 1)
		self.bgmTimer:Start()
	end
end

function GuildProxy:StopGuildBgm()
	local AudioManager = require "Common.Mgr.Audio.AudioManager"
	self.bPlayBgm = false
	self:ClearBgmTimer()
	AudioManager.StopBGM()
end

function GuildProxy:ClearBgmTimer()
	if self.bgmTimer then
		self.bgmTimer:Stop()
		self.bgmTimer = nil
	end
end



--公会图标配置
function GuildProxy:GetGuildIconConfig()
	local config = ConfigManager.GetConfig("data_guild_icon")
	return config
end

function GuildProxy:GetGuildIconById(id)
	local cfg = self:GetGuildIconConfig()
	if cfg[id] then
		return cfg[id]
	else
		print("guild icon is nill: ", id)
	end
end

--公会等级配置
function GuildProxy:GetGuildLevelExpConfig()
	local config = ConfigManager.GetConfig("data_guild")
	return config
end

--公会最大等级
function GuildProxy:GetGuildMaxLevel()
	local config = self:GetGuildLevelExpConfig()
	return #config
end

function GuildProxy:GetLevelConfigByLevel(level)
	local config = self:GetGuildLevelExpConfig()
	return config[level]
end

--通过公会等级获取公会图标列表
function GuildProxy:GetGuildIconCfgSortByLevel(level, cur_icon_id)
	local config = GuildProxy.Instance:GetGuildIconConfig()
	local infos = {}
	for k,v in pairs(config) do
		local item = {}
		item.icon = v.icon
		item.id = v.id
		item.level = v.level
		item.state = level >= v.level and 2 or 3  --2:解锁  3：未解锁
		if cur_icon_id and cur_icon_id == v.id then
			item.state = 1  --当前正在使用
		end
		item.bSelect = item.state == 1 and true or false  --当前选中
		table.insert(infos, item)
	end

	table.sort(infos, function(a, b)
		if a.state ~= b.state then
			return a.state < b.state
		else
			return a.id < b.id
		end
	end)
	return infos
end

--检查输入字符合法性value:输入的字符串  type：公会名称 宣言 公告...
function GuildProxy:CheckContentInput(value, type)
	value = value or ""
	local WordFilter=require "Common.Util.WordFilter"
	local result = 0
	local arr = {} --存空格
	local wordKey

	for w in string.gmatch(value, " ") do
		table.insert(arr, w)
	end
	local lenth = string.len(value)
	if string.isEmpty(value) then
		result = 1  --输入字符不能为空
	elseif lenth == #arr then
		result = 2 --输入全是空格
	else
		local bmask, str = false, ""
		if type == GuildDef.ContentInputType.GuildNameType then
			bmask, str = WordFilter.checkNameMaskWords(value)
		elseif type == GuildDef.ContentInputType.GuildAnnouncementType then
			bmask, str = WordFilter.checkContainAccurateMaskWords(value)
		elseif type == GuildDef.ContentInputType.GuildNoticeType then
			bmask, str = WordFilter.checkContainAccurateMaskWords(value)
		end
		if bmask then
			result = 3 --含有敏感词
		end
	end

	if type == GuildDef.ContentInputType.GuildNameType then
		local lenth, str = GameLogicTools.CheckContentLength(value)

		if lenth == 0 then
			wordKey = "GuildView_1046"
		elseif lenth < GuildDef.Parama.Guild_Name_Min_Char then
			result = 4 --公会名太短
		end
	end
	if result ~= 0 then
		--输入字符串弹tips
		--根据result 和 type 弹不同tips
		if wordKey then
			GameLogicTools.ShowMsgTips(wordKey)
		else
			local strkey = string.format("GuildProxyInputCheck_%d", result)
			GameLogicTools.ShowMsgTips(strkey)
		end
	end

	return result
end

function GuildProxy:CheckOpetate(to_guser)
	local bexist = false
	local guildInfos = self:GetGuildInfos()
	local findIndex
	for i,v in ipairs(guildInfos.memberInfos) do
		if v.guser == to_guser then
			findIndex = i 
			break
		end
	end
	if findIndex then
		bexist = true
	end
	local bElders, bExemplar = false, false
	local elders_list, exemplar_list = self:GetGuildEldersList()
	local persident_guser = self:GetGuildPersidentGuser()
	bElders = elders_list[to_guser] and true or false
	bExemplar = exemplar_list[to_guser] and true or false
	return persident_guser, bElders, bExemplar, bexist
end

--拿到自己对学会成员的操作列表
function GuildProxy:GetOperateTabs(to_guser)
	local idx  --索引对应GuildDef 里权限操作配置
	local operateTab = {}
	local tabs = {}
	local job,fearlessHand = self:GetGuildJob()
	if job then
		local persident_guser, bElders, bExemplar = self:CheckOpetate(to_guser)
		if job == GuildDef.Job.Persident then
			if to_guser == RoleInfoModel.guserid then
				idx = bExemplar and 6 or 5
			elseif bElders == false and bExemplar == false then
				idx = 1
			elseif bElders == false and bExemplar == true then
				idx = 2
			elseif bElders == true and bExemplar == false then
				idx = 3
			elseif bElders == true and bExemplar == true then
				idx = 4
			end
		elseif job == GuildDef.Job.ViceChairman then
			if to_guser == RoleInfoModel.guserid then
				idx = bExemplar and 5 or 4
			elseif persident_guser == to_guser then
				--对方是会长
			elseif bElders then
				--对方是副会长
				idx = bExemplar == false and 3 or nil
			else
				--对方是基础成员
				if bExemplar then
					idx = 2
				else
					idx = 1
				end
			end
		elseif job == GuildDef.Job.Member then
			idx = 1
		end

		if idx then
			operateTab = GuildDef.Permission[job][idx]
		end

		local guildInfos = self:GetGuildInfos()
		local findIndex
		for i,v in ipairs(guildInfos.memberInfos) do
			if v.guser == to_guser then
				findIndex = i 
				break
			end
		end
		if not findIndex then
			local tabs = {}
			for i,v in ipairs(operateTab) do
				if v[1] == GuildDef.OperateType.RetireMember then
				else
					table.insert(tabs, v)
				end
			end
		else
			tabs = operateTab
		end

	end

	local _tabs = {}
	local Application = CS.UnityEngine.Application
	local RuntimePlatform = CS.UnityEngine.RuntimePlatform
	local isEditor = Application.isEditor
	for i,_info in ipairs(tabs) do
		if isEditor then
		elseif Application.platform ~= RuntimePlatform.IPhonePlayer then
			if _info[1] == GuildDef.OperateType.GuildReport then
				table.remove(tabs, i)
			end
		end
	end
	return idx, tabs
end

--是否有公会
function GuildProxy:ExistGuild()
	return self.data.guildInfos.bguild
end

function GuildProxy:GetGuildInfos()
	return self.data.guildInfos
end

function GuildProxy:GetGuildName()
	local name = ""
	if self:ExistGuild() then
		local guildInfos = self:GetGuildInfos()
		if guildInfos.name then
			name = guildInfos.name
		end
	end
	return name
end

--获取自己公会职位，以及无畏之手
function GuildProxy:GetGuildJob()
	return self.data.guildInfos.job, self.data.guildInfos.fearlessHand
end
--获取公会活跃度
function GuildProxy:GetGuildActivityPoint()
	return self.data.guildInfos.liveness or 0
end

--获取公会当前人数
function GuildProxy:GetGuildMemberCount()
	local count = 0
	if self:ExistGuild() then
		count = #self.data.guildInfos.memberInfos
	end
	return count
end

--获取副会长列表 无畏之手列表
function GuildProxy:GetGuildEldersList()
	local elders_list, exemplar_list = {}, {}
	if self:ExistGuild() then
		elders_list, exemplar_list = self.data.guildInfos.guild_elders, self.data.guildInfos.guild_exemplar
	end
	return elders_list, exemplar_list
end

--获取公会 会长guser
function GuildProxy:GetGuildPersidentGuser()
	local guser = 0
	if self:ExistGuild() then
		guser = self.data.guildInfos.persident
	end
	return guser
end

function GuildProxy:GetIsLevelUpTips()
	local isLevelUpTips = self.data.guildInfos.isLevelUpTips
	if isLevelUpTips then
		return isLevelUpTips
	else
		return 0
	end
end

--公会Boss配置
function GuildProxy:GetBossConfig()
	local config = ConfigManager.GetConfig("data_guild_boss")
	return config
end

function GuildProxy:GetBossConfigById(id)
	local config = self:GetBossConfig()
	if config[id] then
		return config[id]
	else
		print("GuildProxy:GetBossConfigById is nil: ", id)
	end
end

function GuildProxy:GetBossConfigByMode(mode)
	local list = {}
	local config = self:GetBossConfig()
	for k,v in pairs(config) do
		if v.mode == mode then
			table.insert(list, v.id)
		end
	end
	table.sort(list, function (a, b)
		return a < b
	end)
	return list
end

function GuildProxy:GetBossConfigByDiff(mode, diffId)
	local config = self:GetBossConfig()
	for k,v in pairs(config) do
		if v.mode == mode and v.difficulty == diffId then
			return v
		end
	end
end

--所有的挑战奖励
function GuildProxy:GetBossAllChallengeReward(mode, diffId)
	local config = self:GetBossConfigByDiff(mode, diffId)
	return config.stage_rewards
end

--挑战奖励
function GuildProxy:GetBossChallengeReward(mode, diffId, startStage, endStage)
	local rewards = {}
	local config = self:GetBossConfigByDiff(mode, diffId)
	for i=startStage,endStage do
		local stageReward = config.stage_rewards[i]
		if stageReward then
			for j=1,#stageReward do
				table.insert(rewards, stageReward[j])
			end
		end
	end
	return rewards
end

--所有的通关奖励
function GuildProxy:GetBossAllFinishReward(mode)
	local list = self:GetBossConfigByMode(mode)
	local result = {}
	for i=1,#list do
		local config = self:GetBossConfigById(list[i])
		table.insert(result, config.clear_rewards)
	end
	return result
end

--当前展示的boss类型
function GuildProxy:SetNowBossType(bossType)
	self.data.guildBossInfos.nowBossType = bossType
end

function GuildProxy:GetNowBossType()
	return self.data.guildBossInfos.nowBossType
end

--获取当前boss进度
function GuildProxy:GetNowBossProgress()
	local nowBossType = self:GetNowBossType()
	local progressInfo = self.data.guildBossInfos.progressInfo
	local info = progressInfo[nowBossType]
	if info then
		return nowBossType, info.diff, info.stage
	else
		return nowBossType, 1, 0
	end 
end

--设置当前boss进度
function GuildProxy:SetNowBossProgress(bossType, diff, stage)
	local progressInfo = self.data.guildBossInfos.progressInfo
	local info = progressInfo[bossType]
	if info then
		info.diff = diff
		info.stage = stage
	end
end

--能否扫荡
function GuildProxy:CanSweepBoss(bossType)
	local ModuleManager = require "Common.Mgr.UI.ModuleManager"
	local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
	local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.GuildBossSweep, false)

	if bopen then
		local progressInfo = self.data.guildBossInfos.progressInfo
		local info = progressInfo[bossType]
		if info then
			if bossType == GuildDef.BossType.High and not self:IsBossHighStateOpen() then
				return false
			else
				return info.canSweep
			end
		else
			return false
		end
	else
		return false
	end
end

--设置能否扫荡
function GuildProxy:SetSweepBoss(bossType, canSweep)
	local progressInfo = self.data.guildBossInfos.progressInfo
	local info = progressInfo[bossType]
	if info then
		if canSweep and info.diff == 1 and info.stage == 0 then --初始进度不可设置为可扫荡
		else
			info.canSweep = canSweep
		end
	end
end

--获取能扫荡的次数
function GuildProxy:GetBossCanSweepTimes()
	local num = 0
	if self:CanSweepBoss(GuildDef.BossType.Normal) then
		num = num + 1
	end
	if self:CanSweepBoss(GuildDef.BossType.High) then
		num = num + 1
	end
	return num
end

--高级boss是否开启
function GuildProxy:IsBossHighStateOpen()
	local isOpen = self:GetBossOpenInfo()
	return isOpen
	-- return self.data.guildBossInfos.highStateOpen
end

--高级boss开启时间
function GuildProxy:GetBossHighStateTime()
	local isOpen, nowOpenTime, nextOpenTime = self:GetBossOpenInfo()
	return nowOpenTime
	-- return self.data.guildBossInfos.highStateTime
end

--关闭高级boss
function GuildProxy:CloseBossHighState()
	self.data.guildBossInfos.highStateOpen = false
	self.data.guildBossInfos.highStateTime = 0
end

--获取enemy
function GuildProxy:GetBossEnemy(mode, diffId)
	local config = self:GetBossConfigByDiff(mode, diffId)
	return config.enemy
end

--获取roleid
function GuildProxy:GetBossRoleId(mode, diffId)
	local enemy = self:GetBossEnemy(mode, diffId)
	local enemylist, bossinfo = GameLogicTools.GetEnemyList(enemy)
	local roleid = bossinfo.role
	return roleid
end

--获取roleid
function GuildProxy:GetBossDisplayRoleId(mode, diffId)
	local config = self:GetBossConfigByDiff(mode, diffId)
	return config.display
end

--进度描述
function GuildProxy:GetBossProgressDesc(diff, stage)
	return LanguageManager.Instance:GetWord(GuildDef.LanguageKey.GuildBossRankView1, diff, stage * 10)
end

--获取最大难度
function GuildProxy:GetBossMaxDiff(bossType)
	return self.data.guildBossInfos.bossMaxDiff[bossType]
end

--是否已达到最大难度
function GuildProxy:IsBossMaxDiff(bossType)
	local maxDiff = self:GetBossMaxDiff(bossType)
	local progressInfo = self.data.guildBossInfos.progressInfo
	local info = progressInfo[bossType]
	if info and info.diff >= maxDiff then
		return true
	end
	return false
end

--是否完成所有难度
function GuildProxy:IsBossFinishAll(bossType)
	local maxDiff = self:GetBossMaxDiff(bossType)
	local progressInfo = self.data.guildBossInfos.progressInfo
	local info = progressInfo[bossType]
	if info and info.diff >= maxDiff and info.stage == 10 then
		return true
	end
	return false
end

--初始化boss的进度信息
function GuildProxy:InitBossProgressInfo(progressInfo, bossType)
	if not progressInfo[bossType] then
		progressInfo[bossType] = {mode = bossType, diff = 1, stage = 0, canSweep = false}
	end
end

--新建或新进公会挑战boss(0:没挑战过 1:挑战过)
function GuildProxy:GetBossChallengeRedKey(mode)
	return RoleInfoModel.guserid .. "_GuildBoss_" .. mode
end

function GuildProxy:GetBossChallengeRedValue(mode)
	local key = self:GetBossChallengeRedKey(mode)
	return PlayerPrefs.GetInt(key, 0)
end

function GuildProxy:SetBossChallengeRedValue(mode, value)
	local key = self:GetBossChallengeRedKey(mode)
	PlayerPrefs.SetInt(key, value)
end

--更新挑战按钮红点
function GuildProxy:UpdateBossRedPointChallenge()
	local value
	local redValue

	--普通boss
	if self:ExistGuild() then
		redValue = self:GetBossChallengeRedValue(GuildDef.BossType.Normal)
		if redValue == 0 then
			value = 1
		else
			value = self:CanSweepBoss(GuildDef.BossType.Normal) and 1 or 0
		end
	else
		value = 0
	end
	RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.GuildBossChallengeNormal, value)

	--高级boss
	if self:ExistGuild() then
		redValue = self:GetBossChallengeRedValue(GuildDef.BossType.High)
		if redValue == 0 and self:IsBossHighStateOpen() then
			value = 1
		-- elseif self.data.guildBossInfos.advanceBossOpenTips == 1 then
		-- 	value = 1
		else
			value = self:CanSweepBoss(GuildDef.BossType.High) and 1 or 0
		end
	else
		value = 0
	end
	RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.GuildBossChallengeHigh, value)
end

--更新开启高级boss红点
function GuildProxy:UpdateBossRedPointOpenHigh()
	-- local liveness = self.data.guildInfos.liveness or 0
	-- local openHighValue = ConfigManager.GetConfig("data_common").advance_cost_activity.value1[1]
	-- local job = self:GetGuildJob()
	-- local redPointValue = 0

	-- if job == GuildDef.Job.Persident or job == GuildDef.Job.ViceChairman then
	-- 	if not self:IsBossHighStateOpen() and liveness >= openHighValue then
	-- 		redPointValue = 1
	-- 	end
	-- end

	-- RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.GuildBossOpenHigh, redPointValue)
end

--更新挑战按钮定时器(服务端高级boss结束时不推送，由客户端计时)
function GuildProxy:UpdateBossChallengeTimer()
	-- local isOpen = self:IsBossHighStateOpen()
	-- if not isOpen then
	-- 	return
	-- end

	-- local duration = ConfigManager.GetConfig("data_common").guildboss_time.value1[1]
	-- local endTime = GuildProxy.Instance:GetBossHighStateTime() + duration
	-- local time = endTime - RoleInfoModel.servertime
	-- if time > duration then
	-- 	time = duration
	-- end

	-- local challengeTimer = self.data.guildBossInfos.challengeTimer
	-- if challengeTimer then
	-- 	challengeTimer:Stop()
	-- 	self.data.guildBossInfos.challengeTimer = nil
	-- end

	-- print("GuildProxy:UpdateBossChallengeTimer time", time)
	-- if time > 0 then
	-- 	local timer = Timer.New(function ()
	-- 		print("GuildProxy:UpdateBossChallengeTimer over")
	-- 		RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.GuildBossChallengeHigh, 0)
	-- 	end, time, 1)
 --    	timer:Start()
 --    	self.data.guildBossInfos.challengeTimer = timer
	-- end
end

function GuildProxy:GetBossOpenInfo(createTime)
	createTime = createTime or self.data.guildBossInfos.createTime

	local temp = DateFormatUtil.Date("*t", createTime)
    local year = temp.year
    local month = temp.month
    local day = temp.day
    local curTime = RoleInfoModel.servertime
    local startTime = DateFormatUtil.Time({year=year, month=month, day=day, hour=23, min=59, sec=59})
    local oneDayTime = 86400
    local diff
    local isOpen = false
    local nowOpenTime = 0 --当前开启时间
    local nextOpenTime = 0 --下次开启时间

    if curTime == 0 then
    	curTime = DateFormatUtil.Time(DateFormatUtil.Date("*t", os.time()))
    end
    -- print("111", createTime, table.dump(DateFormatUtil.Date("*t", createTime)))
    -- print("222", table.dump(DateFormatUtil.Date("*t", curTime)))

    startTime = startTime + 1
    diff = curTime - startTime
    diff = diff % (oneDayTime * 2)

    if diff >= 0 and diff < oneDayTime then
        isOpen = true
    end

    if not isOpen then --今天没开启，则明天开启
    	local t = DateFormatUtil.Date("*t", curTime)
    	nextOpenTime = DateFormatUtil.Time({year=t.year, month=t.month, day=t.day, hour=23, min=59, sec=59}) + 1
    else
    	local t = DateFormatUtil.Date("*t", curTime)
    	nowOpenTime = DateFormatUtil.Time({year=t.year, month=t.month, day=t.day, hour=0, min=0, sec=0})
    end

    return isOpen, nowOpenTime, nextOpenTime
end

function GuildProxy:GetBossIsNewDiff()
	return self.data.guildBossInfos.isNewDiff
end

function GuildProxy:SetBossIsNewDiff(isNewDiff)
	self.data.guildBossInfos.isNewDiff = isNewDiff
end

--公会Boss协议
function GuildProxy:Send70100()
	self:SendMessage(70100)
	-- print("GuildProxy:Send70100")
end

function GuildProxy:On70100(decoder)
	local hasGuild = decoder:Decode("I1") == 0
	if hasGuild then
		local progressInfo = {}
		local count = decoder:Decode("I2")

		for i=1,count do
			local mode, diff, stage, canSweep = decoder:Decode("I1I1I1I1")
			local info = {}
			info.mode = mode
			info.diff = diff
			info.stage = stage
			info.canSweep = canSweep == 1

			progressInfo[mode] = info
		end

		self:InitBossProgressInfo(progressInfo, GuildDef.BossType.Normal)
		self:InitBossProgressInfo(progressInfo, GuildDef.BossType.High)

		local highStateOpen = decoder:Decode("I1") == 1
		local highStateTime = decoder:Decode("I4")
		local advanceBossOpenTips = decoder:Decode("I1")
		local createTime = decoder:Decode("I4")

		-- print("On70100", table.dump(progressInfo), createTime)
		
		self.data.guildBossInfos.progressInfo = progressInfo
		self.data.guildBossInfos.highStateOpen = highStateOpen
		self.data.guildBossInfos.highStateTime = highStateTime
		self.data.guildBossInfos.advanceBossOpenTips = advanceBossOpenTips
		self.data.guildBossInfos.createTime = createTime

		self:ToNotify(self.data, GuildDef.Notify.UpdateBossInfo)

		self:UpdateBossRedPointChallenge()
		self:UpdateBossRedPointOpenHigh()
		self:UpdateBossChallengeTimer()
	end
end

--准备挑战
function GuildProxy:Send70101(model)
	local encoder = NetEncoder.New()
    encoder:Encode("I1", model)
    self:SendMessage(70101, encoder)
    -- print("GuildProxy:Send70101")

    local BattleProxy = require "Modules.Battle.BattleProxy"
    BattleProxy.Instance:BattleReadySetStep(ACTIVITYID.GUILD_BOSS, 1)

end

function GuildProxy:On70101(decoder)
	-- print("GuildProxy:On70101")
	local result = decoder:Decode("I1")
	if result ~= 0 then
        local BattleProxy = require "Modules.Battle.BattleProxy"
        BattleProxy.Instance:BattleReadyNextStep(ACTIVITYID.GUILD_BOSS, 1)
	end
end

-- 开始挑战
function GuildProxy:Send70102(hero_infos, enemy_infos)
	-- print("GuildProxy:Send70102")

	local encoder = NetEncoder.New()
    self:_EncodeHeroInfo(hero_infos, encoder)
	self:_EncodeEnemyInfo(enemy_infos, encoder)
	local bufferstr = string.pack(">I2", self:GetNowBossType())
    encoder:Encode("s2", bufferstr)
    self:SendMessage(70102, encoder) 
end

function GuildProxy:On70102(decoder)
	-- print("GuildProxy:On70102")

	local result = decoder:Decode("I1")
    if result == 1 then
        local lowestPower = decoder:Decode("I4")
        local LanguageManager = require "Common.Mgr.Language.LanguageManager"
        local str = LanguageManager.Instance:GetWord("BattleSelect_1005", lowestPower)
        GameLogicTools.ShowMsgTips(str)
    end
end

-- 扫荡
function GuildProxy:Send70103(mode)
	local encoder = NetEncoder.New()
    encoder:Encode("I1", mode)
    self:SendMessage(70103, encoder)
    -- print("GuildProxy:70103", mode)
end

function GuildProxy:On70103(decoder)
	local result = decoder:Decode("I1") == 0
	-- print("GuildProxy:On70103", result)

	if result then
		local canSweep = decoder:Decode("I1") == 1
		local nowBossType = self:GetNowBossType()
		self:SetSweepBoss(nowBossType, canSweep)

		local rewards = {}
		local count = decoder:Decode("I2")
	    if count > 0 then
	        for i=1,count do
	            local info = {}
	            info.goodsid, info.goodsnum = decoder:Decode("I4I4")
	            table.insert(rewards, info)
	        end
	    end

	    rewards = GameLogicTools.HandleRewardMergeNum2(rewards)

		self.data.guildBossInfos.sweepRewards = rewards
		self:ToNotify(self.data, GuildDef.Notify.UpdateBossSweepReward, rewards)
		self:ToNotify(self.data, GuildDef.Notify.UpdateBossInfo)

		self:UpdateBossRedPointChallenge()
	end
end

-- 开启公会高级boss
function GuildProxy:Send70104()
    self:SendMessage(70104)
    -- print("GuildProxy:Send70104")
end

function GuildProxy:On70104(decoder)
	local result = decoder:Decode("I1")

	if result == 0 then --0成功
		local time = decoder:Decode("I4")
		self.data.guildBossInfos.highStateOpen = true
		self.data.guildBossInfos.highStateTime = time
		self:ToNotify(self.data, GuildDef.Notify.UpdateBossChallengeBtn, time)
		self:UpdateBossRedPointChallenge()
		self:UpdateBossChallengeTimer()

		RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.GuildBossOpenHigh, 0)
	elseif result == 1 then --1失败经验不足
	elseif result == 2 then --2失败权限不够
	end

	-- print("GuildProxy:On70104", result)
end

-- 排行榜
function GuildProxy:Send70105(mode)
	local encoder = NetEncoder.New()
    encoder:Encode("I1", mode)
    self:SendMessage(70105, encoder)
    -- print("GuildProxy:Send70105")
end

function GuildProxy:On70105(decoder)
	local result = decoder:Decode("I1")
	local bossType
	local rankList
	-- print("GuildProxy:On70105", result)
	if result == 0 then
		bossType = decoder:Decode("I1")
		local count = decoder:Decode("I2")
		if count > 0 then
			rankList = {}
			for i=1,count do
	            local info = self:DecoderBossRankInfo(decoder)
	            table.insert(rankList, info)
	        end
	        -- print(table.dump(rankList))
		end
	end
	self.data.guildBossInfos.rankList = rankList
	self:ToNotify(self.data, GuildDef.Notify.UpdateBossRankList, rankList)
end

-- 最高排行榜信息
function GuildProxy:Send70106(mode)
	local encoder = NetEncoder.New()
    encoder:Encode("I1", mode)
    self:SendMessage(70106, encoder)
    -- print("GuildProxy:Send70106")
end

function GuildProxy:On70106(decoder)
	local result = decoder:Decode("I1")
	local info
	-- print("GuildProxy:On70106", result)
	if result == 0 then
		info = self:DecoderBossRankInfo(decoder)
		-- print(table.dump(info))
	end
	self.data.guildBossInfos.rankHighest = info
	self:ToNotify(self.data, GuildDef.Notify.UpdateBossRankHighest, info)
end

-- 我的排行榜信息
function GuildProxy:Send70107(mode)
	local encoder = NetEncoder.New()
    encoder:Encode("I1", mode)
    self:SendMessage(70107, encoder)
    -- print("GuildProxy:Send70107")
end

function GuildProxy:On70107(decoder)
	local result = decoder:Decode("I1")
	local info
	-- print("GuildProxy:On70107", result)
	if result == 0 then
		info = self:DecoderBossRankInfo(decoder)
		-- print(table.dump(info))
	end
	-- if info and info.time == 0 then
	-- 	info = nil
	-- end
	self.data.guildBossInfos.rankMy = info
	self:ToNotify(self.data, GuildDef.Notify.UpdateBossRankMy, info)
end

--零点通知
function GuildProxy:On70108(decoder)
	-- print("GuildProxy:On70108")

	local count = decoder:Decode("I2")

	for i=1,count do
		local mode, canSweep = decoder:Decode("I1I1")
		self:SetSweepBoss(mode, canSweep == 1)
	end

	self:UpdateBossRedPointChallenge()
	self:ToNotify(self.data, GuildDef.Notify.UpdateBossChallengeBtn)

	--客户端和服务端零点有时会不同步有误差,所以延迟一小段时间
	Timer.New(function ()
		local MallProxy = require "Modules.Mall.MallProxy"
		MallProxy.Instance:UpdateMainLeftActivity()
		MallProxy.Instance:UpdateRedPointDailySupply()
	end, 1.2, 1):Start()
end

function GuildProxy:Send70109(mode, guser, headItem)
	-- local encoder = NetEncoder.New()
 --    encoder:Encode("I1I8", mode, guser)
 --    self:SendMessage(70109, encoder)
    -- print("GuildProxy:Send70109")

    self.data.guildBossInfos.reportHeadItem = headItem
    self.data.guildBossInfos.reportMode = mode
    self.data.guildBossInfos.reportGuser = guser

    local ReportLoader = require "Modules.Common.ReportLoader"
    local reporter = ReportLoader.New(guser, ACTIVITYID.GUILD_BOSS, mode)
        reporter:RequestSettleEvery(function (decoder) 
        if decoder then
            self:On70109(decoder) 
        else
            -- dosomething
            print('no report')
        end
    end)
end

function GuildProxy:On70109(decoder)
	local _result = decoder:Decode("I2")
	if _result == 0 then
		print("GuildProxy:On70109")
		local settledata = self:DecodeSettleData(decoder)
		local redData = self.data.guildBossInfos.reportHeadItem
	    local blueData = {}
	    local camps = settledata.camps
	    local result = settledata.result
	    -- print(table.dump(settledata))

	    local bossInfo = camps[2][1]
	    local herocfg = HeroProxy.Instance:GetRoleCfgByConfigId(bossInfo.roleid)
	    blueData.nickname = LanguageManager.Instance:GetWord(herocfg.name)
	    blueData.level = bossInfo.level
	    blueData.rank = bossInfo.rank
	    blueData.roleid = bossInfo.roleid

		local func = function ()
			self:SetBossReportRank(true)
			self:Send70110(self.data.guildBossInfos.reportMode, self.data.guildBossInfos.reportGuser)
	    end

	    UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 4, result == 0 and CAMP.RED or CAMP.BLUE, redData, blueData, camps, func)
	end
end

function GuildProxy:Send70110(mode, guser)
	local ReportLoader = require "Modules.Common.ReportLoader"
    local reporter = ReportLoader.New(guser, ACTIVITYID.GUILD_BOSS, mode)
    reporter:RequestPlay()

	-- local encoder = NetEncoder.New() 
 --    encoder:Encode("I1I8", mode, guser)
 --    self:SendMessage(70110, encoder)
    -- print("GuildProxy:Send70110")
end

function GuildProxy:On70111(decoder)
	local advanceBossOpenTips = decoder:Decode("I1")
	self.data.guildBossInfos.advanceBossOpenTips = advanceBossOpenTips
	-- print("GuildProxy:On70111", advanceBossOpenTips)

	self:UpdateBossRedPointChallenge()
end

--设置是否在查看排行榜战报
function GuildProxy:SetBossReportRank(value)
	self.data.guildBossInfos.reportRank = value
end

function GuildProxy:GetBossReportRank()
	return self.data.guildBossInfos.reportRank
end

function GuildProxy:DecoderBossRankInfo(decoder)
	local item = {}
	local headItem = {}
	
	headItem.nickname = decoder:Decode("s2")
	headItem.sex = decoder:Decode("I2")
	headItem.headicon = decoder:Decode("I4")
	headItem.frameicon= decoder:Decode("I4")
	headItem.level = decoder:Decode("I2")

	item.headItem = headItem
	item.diff = decoder:Decode("I4")
	item.stage = decoder:Decode("I4")
	item.time = decoder:Decode("I4")
	item.rank = decoder:Decode("I4")

	item.guser = decoder:Decode("I8")

	return item
end

function GuildProxy:OnPreBattleBuffer(bufferstr)
	local nowBossType, diff, stage = self:GetNowBossProgress()
	local enemyid = self:GetBossEnemy(nowBossType, diff)
	LuaLayout.Instance:CloseWidget(UIWidgetNameDef.BattleStopView) --防止点下一关时界面被挡住

	return { enemyid = enemyid, view = { name = "BattleGuildBossPanel", args = {} }}
end

function GuildProxy:OnStartBattleBuffer(bufferstr)
	local nowBossType, diff, stage = self:GetNowBossProgress()
	return { nowBossType, diff, stage }
end

function GuildProxy:OnSetBattle(decoder)
end

----------------------------------------------------------------混沌裂隙 start
function GuildProxy:GetChaosBossConfig()
	local config = ConfigManager.GetConfig("data_chaos_boss")
	return config
end

function GuildProxy:GetChaosBossConfigById(id)
	local config = self:GetChaosBossConfig()
	if config[id] then
		return config[id]
	end
end

function GuildProxy:GetChaosBossRoleId(id)
	local bossConfig = self:GetChaosBossConfigById(id)
	return bossConfig.display
end

function GuildProxy:GetChaosRankConfig()
	local config = ConfigManager.GetConfig("data_chaos_rank")
	return config
end

function GuildProxy:GetChaosRankConfigById(id)
	local config = self:GetChaosRankConfig()
	if config[id] then
		return config[id]
	end
end

function GuildProxy:GetChaosRoomConfig()
	local config = ConfigManager.GetConfig("data_chaos_room")
	return config
end

function GuildProxy:GetChaosRoomConfigById(id)
	local config = self:GetChaosRoomConfig()
	if config[id] then
		return config[id]
	end
end

function GuildProxy:GetChaosHonourConfig()
	local config = ConfigManager.GetConfig("data_chaos_honour")
	return config
end

function GuildProxy:GetChaosHonourConfigById(id)
	local config = self:GetChaosHonourConfig()
	if config[id] then
		return config[id]
	end
end

function GuildProxy:GetChaosLegendConfig()
	local config = ConfigManager.GetConfig("data_chaos_legend")
	return config[1]
end

function GuildProxy:GetChaosNowBossId()
	return self.data.chaosInfo.nowBossId
end

function GuildProxy:GetChaosNowRoomId()
	return self.data.chaosInfo.nowRoomId
end

function GuildProxy:GetChaosFreeChallengeInfo()
	local maxFreeChallengeTimes = ConfigManager.GetConfig("data_common").chaos_challenge_free_times.value1[1]
	return self.data.chaosInfo.nowFreeChallengeTimes, maxFreeChallengeTimes
end

function GuildProxy:GetChaosGemChallengeInfo()
	local maxGemChallengeTimes = ConfigManager.GetConfig("data_common").chaos_challenge_gem_times.value1[1]
	local gemCost = ConfigManager.GetConfig("data_common").chaos_challenge_gem_cost.value1[1]
	return self.data.chaosInfo.nowGemChallengeTimes, maxGemChallengeTimes, gemCost
end

function GuildProxy:GetChaosRefreshTime()
	return ConfigManager.GetConfig("data_common").chaos_refresh_time.value1[1]
end

function GuildProxy:GetChaosHonourNum()
	return ConfigManager.GetConfig("data_common").chaos_honour_num.value1[1]
end

function GuildProxy:GetChaosMaxDamage()
	return self.data.chaosInfo.maxDamage
end

function GuildProxy:SetChaosMaxDamage(maxDamage)
	self.data.chaosInfo.maxDamage = maxDamage
end

function GuildProxy:GetChaosLastSettleTime()
	return self.data.chaosInfo.lastSettleTime
end

function GuildProxy:GetChaosHonourList()
	return self.data.chaosInfo.honourList
end

function GuildProxy:GetChaosRankInfos()
	return self.data.chaosInfo.rankInfos
end

function GuildProxy:GetChaosRankInfoByRank(rank)
	return self.data.chaosInfo.rankInfos[rank]
end

function GuildProxy:GetChaosHonourMemberList()
	return self.data.chaosInfo.honourMemberList
end

--下一只boss的id
function GuildProxy:GetChaosNextBossId()
	local nowBossId = self:GetChaosNowBossId()
    local nowBossConfig = self:GetChaosBossConfigById(nowBossId)
    local nowOrder = nowBossConfig.order
    local nextOrder = nowOrder + 1
    local config = self:GetChaosBossConfig()
    local temp = {}
    local bossId

    for k,v in pairs(config) do
        temp[v.order] = v.id
    end

    bossId = temp[nextOrder]
    if not bossId then
        bossId = temp[1]
    end
    
    return bossId
end

--上一只boss的id(该接口暂时不要用)
function GuildProxy:GetChaosLastBossIdByConfig()
	local nowBossId = self:GetChaosNowBossId()
    local nowBossConfig = self:GetChaosBossConfigById(nowBossId)
    local nowOrder = nowBossConfig.order
    local lastOrder = nowOrder - 1
    local config = self:GetChaosBossConfig()
    local temp = {}
    local bossId
    local maxOrder = -1

    for k,v in pairs(config) do
        temp[v.order] = v.id

        if v.order > maxOrder then
            maxOrder = v.order
        end
    end

    bossId = temp[lastOrder]
    if not bossId then
        bossId = temp[maxOrder]
    end
    
    return bossId
end

function GuildProxy:GetChaosDamageKey(bossId)
	return "dmg_" .. bossId
end

function GuildProxy:GetChaosRewardKey(roomId)
	return "reward_" .. roomId
end

function GuildProxy:GetChaosRank(bossId, damage, roomId)
	local rank
	local config = self:GetChaosRankConfig()
	local damageKey = self:GetChaosDamageKey(bossId)
	local roomConfig = self:GetChaosRoomConfigById(roomId)
	local dmg_factor = roomConfig.dmg_factor

	for i,v in ipairs(config) do
		if damage >= v[damageKey] * dmg_factor then
			rank = i
			break
		end
	end
	
	return rank
end

function GuildProxy:GetChaosNowRank(bossId)
	return self:GetChaosRank(bossId, self:GetChaosMaxDamage(), self:GetChaosNowRoomId())
end

function GuildProxy:GetChaosRankReward()
	local bossId = self:GetChaosNowBossId()
	local roomId = self:GetChaosNowRoomId()
	local nowRank = self:GetChaosNowRank(bossId)
	local reward

	if nowRank then
		local rewardKey = self:GetChaosRewardKey(roomId)
		local honourRank = self.data.chaosInfo.honourRank
		local rankConfig
		
		if honourRank then
			rankConfig = self:GetChaosLegendConfig()
		else
			rankConfig = self:GetChaosRankConfigById(nowRank)
		end
		
		reward = rankConfig[rewardKey]
	end

	return reward
end

function GuildProxy:GetChaosRoomLv(isEnemy, roomId)
	local id = roomId or self.data.chaosInfo.nowRoomId
	local config = self:GetChaosRoomConfigById(id)
	if isEnemy then
		return config.enemy_level
	else
		return config.hero_level
	end
end

function GuildProxy:SetChaosReportKey(key)
	self.data.chaosInfo.reportKey = key
end

function GuildProxy:GetChaosReportKey()
	return self.data.chaosInfo.reportKey
end

function GuildProxy:SetChaosClickRecord(isClickRecord)
	self.data.chaosInfo.isClickRecord = isClickRecord
end

function GuildProxy:GetChaosClickRecord()
	return self.data.chaosInfo.isClickRecord
end

function GuildProxy:LookChaosReport(key, guser, headItem)
    self.data.chaosInfo.reportKey = key
    self.data.chaosInfo.reportGuser = guser
    self.data.chaosInfo.reportHeadItem = headItem

    local ReportLoader = require "Modules.Common.ReportLoader"
    local reporter = ReportLoader.New(guser, ACTIVITYID.GUILD_CHAOS, key)
    reporter:RequestSettle(function (decoder) 
        if decoder then
            self:OnLookChaosReport(decoder) 
        else
            -- dosomething
            print('no report')
        end
    end)
end

function GuildProxy:OnLookChaosReport(decoder)
	local _result = decoder:Decode("I2")
	if _result == 0 then
		local settledata = self:DecodeSettleData(decoder)
		local redData = self.data.chaosInfo.reportHeadItem
	    local blueData = {}
	    local camps = settledata.camps
	    local result = settledata.result
	    -- print(table.dump(settledata))

	    local bossInfo = camps[2][1]
	    local herocfg = HeroProxy.Instance:GetRoleCfgByConfigId(bossInfo.roleid)
	    blueData.nickname = LanguageManager.Instance:GetWord(herocfg.name)
	    blueData.level = bossInfo.level
	    blueData.rank = bossInfo.rank
	    blueData.roleid = bossInfo.roleid

		local func = function ()
			local isShowLastRank = self:GetChaosIsShowLastRank()
			if isShowLastRank then
				GuildProxy.Instance:SetIsPlayLastReport(true)
			end
			
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildChaosRankView)
			if view and view:IsOpen() then
				self:SetReportOpenViews(UIWidgetNameDef.GuildChaosRankView)

				self:SetRankViewParas({contentY = view:GetContentY()})
			end

			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildChaosBehindView)
			if view and view:IsOpen() then
				self:SetReportOpenViews(UIWidgetNameDef.GuildChaosBehindView)

				self:SetBehindViewParas({rank = view.rank, rankInfo = view.rankInfo})
			end

			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildChaosRecordView)
			if view and view:IsOpen() then
				self:SetReportOpenViews(UIWidgetNameDef.GuildChaosRecordView)
			end

			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildChaosTopView)
			if view and view:IsOpen() then
				self:SetReportOpenViews(UIWidgetNameDef.GuildChaosTopView)

				self:SetChaosOtherRoomId(view.otherRoomId)
			end
			
			self:PlayChaosReport(self.data.chaosInfo.reportKey, self.data.chaosInfo.reportGuser)
	    end

	    UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 4, CAMP.RED, redData, blueData, camps, func) --固定显示玩家胜利
	end
end

function GuildProxy:PlayChaosReport(key, guser)
	local ReportLoader = require "Modules.Common.ReportLoader"
    local reporter = ReportLoader.New(guser, ACTIVITYID.GUILD_CHAOS, key)
    reporter:RequestPlay()
end

--获取荣耀奖励
function GuildProxy:GetChaosHonourReward(score)
	local config = self:GetChaosHonourConfig()
	local reward

	for i,v in ipairs(config) do
		if score >= v.honour then
			reward = v.reward
			break
		end
	end

	return reward
end

--获取荣耀积分
function GuildProxy:GetChaosHonourScore(roomId)
	local roomConfig = self:GetChaosRoomConfigById(roomId)
	return roomConfig.honour
end

--获取荣耀总积分
function GuildProxy:GetChaosHonourSumScore()
	local sumScore = 0
	local list = self.data.chaosInfo.honourMemberList
	for i=1,#list do
		local roomId = list[i].roomId
		local roomConfig = self:GetChaosRoomConfigById(roomId)
		sumScore = sumScore + roomConfig.honour
	end
	return sumScore
end

--获取荣耀排名信息
function GuildProxy:GetChaosHonourRankInfo()
	return self.data.chaosInfo.honourRank, self.data.chaosInfo.honourPromoteDamage
end

function GuildProxy:GetChaosIsShowLastRank()
	return self.data.chaosInfo.isShowLastRank
end

function GuildProxy:SetChaosIsShowLastRank(value)
	self.data.chaosInfo.isShowLastRank = value
end

function GuildProxy:GetIsPlayLastReport()
	return self.data.chaosInfo.isPlayLastReport
end

function GuildProxy:SetIsPlayLastReport(value)
	self.data.chaosInfo.isPlayLastReport = value
end

function GuildProxy:GetReportOpenViews()
	return self.data.chaosInfo.reportOpenViews
end

function GuildProxy:SetReportOpenViews(value)
	self.data.chaosInfo.reportOpenViews = self.data.chaosInfo.reportOpenViews or {}
	table.insert(self.data.chaosInfo.reportOpenViews, value)
end

function GuildProxy:ClearReportOpenViews()
	self.data.chaosInfo.reportOpenViews = nil
end

function GuildProxy:GetBehindViewParas()
	return self.data.chaosInfo.behindViewParas
end

function GuildProxy:SetBehindViewParas(value)
	self.data.chaosInfo.behindViewParas = value
end

function GuildProxy:ClearBehindViewParas()
	self.data.chaosInfo.behindViewParas = nil
end

function GuildProxy:GetRankViewParas()
	return self.data.chaosInfo.rankViewParas
end

function GuildProxy:SetRankViewParas(value)
	self.data.chaosInfo.rankViewParas = value
end

function GuildProxy:ClearRankViewParas()
	self.data.chaosInfo.rankViewParas = nil
end

function GuildProxy:GetChaosLastBossId()
	return self.data.chaosInfo.lastBossId
end

function GuildProxy:GetChaosLastRoomId()
	return self.data.chaosInfo.lastRoomId
end

function GuildProxy:GetChaosOtherRoomId()
	return self.data.chaosInfo.otherRoomId
end

function GuildProxy:SetChaosOtherRoomId(value)
	-- print("GuildProxy:SetChaosOtherRoomId", tostring(value))
	self.data.chaosInfo.otherRoomId = value
end

function GuildProxy:ClearChaosOtherRoomId()
	self:SetChaosOtherRoomId(nil)
end

function GuildProxy:SetChaosRequireSettle(value)
	self.data.chaosInfo.isRequireSettle = value
end

function GuildProxy:GetChaosRequireSettle()
	return self.data.chaosInfo.isRequireSettle
end

function GuildProxy:DecodeChaosRankInfo(decoder)
	local item = {}
	local headItem = {}
	
	headItem.nickname = decoder:Decode("s2")
	headItem.sex = decoder:Decode("I2")
	headItem.headicon = decoder:Decode("I4")
	headItem.frameicon = decoder:Decode("I4")
	headItem.level = decoder:Decode("I2")

	item.headItem = headItem
	item.guser = decoder:Decode("I8")
	item.maxDamage = decoder:Decode("I8")
	item.time = decoder:Decode("I8")

	return item
end

-- 请求基础信息
function GuildProxy:Send70200()
	self:SendMessage(70200)
end

function GuildProxy:On70200(decoder)
	local result = decoder:Decode("I1")
	if result == 0 then
		self.data.chaosInfo.nowBossId = decoder:Decode("I4")
		self.data.chaosInfo.nowRoomId = decoder:Decode("I1")
		self.data.chaosInfo.maxDamage = decoder:Decode("I8")
		self.data.chaosInfo.nowFreeChallengeTimes = decoder:Decode("I2")
		self.data.chaosInfo.nowGemChallengeTimes = decoder:Decode("I2")
		self.data.chaosInfo.lastSettleTime = decoder:Decode("I8")

		local count
	
		self.data.chaosInfo.honourMemberList = {}
		count = decoder:Decode("I1")
		for i=1,count do
			local info = self:DecodeChaosRankInfo(decoder)
			info.roomId = decoder:Decode("I1")
			info.rank = decoder:Decode("I1")
			table.insert(self.data.chaosInfo.honourMemberList, info)
		end

		if #self.data.chaosInfo.honourMemberList > 0 then
			table.sort(self.data.chaosInfo.honourMemberList, function (a, b)
				if a.roomId == b.roomId then
					return a.rank < b.rank
				else
					return a.roomId > b.roomId
				end
			end)
		end

		self.data.chaosInfo.honourRank = decoder:Decode("I1")
		self.data.chaosInfo.honourPromoteDamage = decoder:Decode("I8")

		if self.data.chaosInfo.honourRank == 0 then
			self.data.chaosInfo.honourRank = nil
		end

		-- print("GuildProxy:On70200", table.dump(self.data.chaosInfo))

		--测试
		-- self.data.chaosInfo.maxDamage = 0
		-- self.data.chaosInfo.honourRank = 12
		-- self.data.chaosInfo.honourPromoteDamage = 12345678

		self:ToNotify(self.data, GuildDef.Notify.UpdateChaosInfo)

		local value = self.data.chaosInfo.maxDamage == 0 and 1 or 0
		RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.GuildChaosChallenge, value)
	end
end

-- 重置次数
function GuildProxy:Send70203()
	self:SendMessage(70203)
end

function GuildProxy:On70203(decoder)
	local result = decoder:Decode("I1")
	-- print("GuildProxy:On70203", result)

	if result == 0 then
		self.data.chaosInfo.nowFreeChallengeTimes = decoder:Decode("I2")
		self.data.chaosInfo.nowGemChallengeTimes = decoder:Decode("I2")

		-- print("GuildProxy:On70203", table.dump(self.data.chaosInfo))
		
		self:ToNotify(self.data, GuildDef.Notify.UpdateChaosChallengeBtn)

		local GuildChaosProxy = require "Modules.Guild.GuildChaosProxy"
		GuildChaosProxy.Instance:Send70201()
	end
end

-- 挑战记录
function GuildProxy:Send70204()
	self:SendMessage(70204)
end

function GuildProxy:On70204(decoder)
	local result = decoder:Decode("I1")
	local list

	if result == 0 then
		local count = decoder:Decode("I2")
		if count > 0 then
			list = {}
			for i=1,count do
				local temp = {}
				temp.time, temp.damage = decoder:Decode("I8I8")
	            table.insert(list, temp)
	        end
	        table.sort(list, function (a, b)
	        	return a.time > b.time
	        end)
	        -- print(table.dump(list))
		end
	end
	self:ToNotify(self.data, GuildDef.Notify.UpdateChaosRecordList, list)
end

-- 全服排行榜 isLast:是否上期
function GuildProxy:Send70205(isLast)
	local encoder = NetEncoder.New()
    encoder:Encode("I1", isLast and 1 or 0)
    self:SendMessage(70205, encoder)
end

function GuildProxy:On70205(decoder)
	local result = decoder:Decode("I1")
	local count

	if result == 0 then
		local oldHonourRank = self:GetChaosHonourRankInfo()
		local nowHonourRank

		--荣耀段
		self.data.chaosInfo.honourList = {}
		count = decoder:Decode("I1")
		for i=1,count do
			local info = self:DecodeChaosRankInfo(decoder)
			table.insert(self.data.chaosInfo.honourList, info)
		end

		for i,v in ipairs(self.data.chaosInfo.honourList) do
			if v.guser == RoleInfoModel.guserid then
				nowHonourRank = i
				break
			end
		end

		--非荣耀段
		self.data.chaosInfo.rankInfos = {}
		count = decoder:Decode("I1")
		for i=1,count do
			local rank, num = decoder:Decode("I1I4")
			local list = {}
			local count2 = decoder:Decode("I1")
			for j=1,count2 do
				local info = self:DecodeChaosRankInfo(decoder)
				table.insert(list, info)
			end
			self.data.chaosInfo.rankInfos[rank] = {list, num}
		end

		--自身信息
		local isLast = decoder:Decode("I1") == 1
		local roomId = decoder:Decode("I1")
		local bossId = decoder:Decode("I4") --上期BossId
		local maxDamage = decoder:Decode("I8")
		local maxDamageTime = decoder:Decode("I8")
		local recordLastSettleTime = decoder:Decode("I8")
		local lastSettleTime = decoder:Decode("I8")

		-- print("GuildProxy:On70205 aaa", table.dump(self.data.chaosInfo.honourList))
		-- print("GuildProxy:On70205 bbb", table.dump(self.data.chaosInfo.rankInfos))
		-- print("GuildProxy:On70205 ccc", isLast, roomId, bossId, maxDamage, maxDamageTime, recordLastSettleTime, lastSettleTime)
		-- print("GuildProxy:On70205 ddd", tostring(oldHonourRank), tostring(nowHonourRank))

		if isLast then
			self.data.chaosInfo.lastBossId = bossId
			self.data.chaosInfo.lastRoomId = roomId
		else
			if oldHonourRank ~= nowHonourRank then
				-- print("GuildProxy:On70205 eee")
				local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildChaosView)
				if view and view:IsOpen() then
					view.isSend70200 = true
					self:Send70200()
				end
			end
		end

		self:ToNotify(self.data, GuildDef.Notify.UpdateChaosRankList, {maxDamage, maxDamageTime, recordLastSettleTime, lastSettleTime})
	elseif result == 1 then --没有上期记录
    	self:SetChaosIsShowLastRank(false)
		GameLogicTools.ShowMsgTips("BagRootView_1002")
	end
end
----------------------------------------------------------------混沌裂隙 end

return GuildProxy