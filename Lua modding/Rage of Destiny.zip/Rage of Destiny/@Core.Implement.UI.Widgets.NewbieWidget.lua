local NewbieManager = require "Modules.Newbie.NewbieManager"
local NewbieProxy = require "Modules.Newbie.NewbieProxy"

local NewbieWidget = NewbieWidget or BaseClass()

function NewbieWidget:__init()
	self.newbieSelectObj = nil 
	self.clist = nil --暂时一个界面只能注册一个list
	self.bForceguide = false --自定义单独的强引导
	self.bWeakguide = false --自定义单独的弱引导
end	

function NewbieWidget:RegisterBtnData(btn, newbieid, step)
	self.btnData[newbieid] = self.btnData[newbieid] or {}
	self.btnData[newbieid][step] = btn	
end

--Register
function NewbieWidget:RegisterSpriteView(spriteview, newbieid, step, clist)
	self.btnData = self.btnData or {}
	self.clist = self.clist or clist

	local btn = spriteview.backBtn
	NewbieManager.Instance:RegisterData(newbieid, step, {obj = btn.gameObject ,spriteview = spriteview})
	self:RegisterBtnData(btn, newbieid, step)

	--ps: 监听按钮按下弹起,如果界面使用了这个事件，按钮引导则失效
	btn:AddMouseDown(function (pointdata)
		self.newbieSelectObj = pointdata.pointerEnter
	end)	
	btn:AddMouseUp(function (pointdata)
		if self.newbieSelectObj == pointdata.pointerEnter or self.newbieSelectObj == nil then
			self:BtnClick(btn)
			self.newbieSelectObj = nil
		end	
	end)
	self:ShowBtnNewbie(newbieid, step)
end

function NewbieWidget:RegisterButton(btn, newbieid, step, clist)
	-- print("RegisterButton=====", newbieid, step)
	self.btnData = self.btnData or {}
	self.clist = self.clist or clist

	NewbieManager.Instance:RegisterData(newbieid, step, {obj = btn.gameObject})
	self:RegisterBtnData(btn, newbieid, step)

	--ps: 监听按钮按下弹起,如果界面使用了这个事件，按钮引导则失效
	-- btn:AddMouseDown(function (pointdata)
		
	-- 	self.newbieSelectObj = pointdata.pointerEnter
	-- 	print("RegisterButton AddMouseDown=======", pointdata, pointdata.pointerEnter, self.newbieSelectObj)
	-- end)	
	-- btn:AddMouseUp(function (pointdata)
	-- 	print("RegisterButton AddMouseUp=======", self.newbieSelectObj, pointdata, pointdata.pointerEnter)
	-- 	-- if self.newbieSelectObj ~= nil and self.newbieSelectObj == pointdata.pointerEnter then
	-- 	-- 	self:BtnClick(btn)
	-- 	-- 	self.newbieSelectObj = nil
	-- 	-- end	
	-- 	if self.newbieSelectObj == pointdata.pointerEnter or self.newbieSelectObj == nil then
	-- 		self:BtnClick(btn)
	-- 		self.newbieSelectObj = nil
	-- 	end	
	-- end)

	-- btn:AddPointExitCallBack(function(pointdata)
	-- 	print("RegisterButton AddPointExitCallBack===", pointdata)
	-- end)

	self:ShowBtnNewbie(newbieid, step)
end	

function NewbieWidget:OnTriggerClickBtn(btn)
	local newbieid, step = NewbieManager.Instance:GetCurNewbieIdStep()
	local bStart = NewbieManager.Instance:CheckStartCondition(newbieid, step)
	if bStart then
		self:BtnClick(btn)
	end
end

function NewbieWidget:RegisterToggle(tog, newbieid, step, clicktab)
	self.btnData = self.btnData or {}

	NewbieManager.Instance:RegisterData(newbieid, step, {obj = tog.gameObject})
	self:RegisterBtnData(tog, newbieid, step)

	clicktab.func = function (clickobj)
		self:BtnClick(clickobj)
	end

	self:ShowBtnNewbie(newbieid, step)
end

--获得新英雄
function NewbieWidget:RegisterNewHero(newbieid, step, roleid, rank, level)
	-- print("RegisterNewHero==", newbieid, step, roleid, rank, level)
	self.btnData = self.btnData or {}

	NewbieManager.Instance:RegisterData(newbieid, step, {roleid = roleid, rank=rank, level=level})
	self:RegisterBtnData({roleid = roleid, rank=rank, level=level}, newbieid, step)



	self:ShowBtnNewbie(newbieid, step)
end

--对话框
function NewbieWidget:RegisterNpcDialog(newbieid, step)
	self.btnData = self.btnData or {}

	NewbieManager.Instance:RegisterData(newbieid, step, {})
	self:RegisterBtnData({}, newbieid, step)

	self:ShowBtnNewbie(newbieid, step)
end

function NewbieWidget:ShowForceguide(btn, id)
	if NewbieManager.Instance:ShowForceguide(id, btn.gameObject) then
		self.bForceguide = true
	end	

	btn:AddMouseDown(function (pointdata)
		self.newbieSelectObj = pointdata.pointerEnter
	end)
	btn:AddMouseUp(function (pointdata)
		if self.newbieSelectObj == pointdata.pointerEnter or self.newbieSelectObj == nil then
			self:BtnClick(btn)
			self.newbieSelectObj = nil
		end	
	end)
end

function NewbieWidget:ShowWeakguide(btn, id)
	if NewbieManager.Instance:ShowWeakguide(id, btn.gameObject) then
		self.bWeakguide = true
	end	

	btn:AddMouseDown(function (pointdata)
		self.newbieSelectObj = pointdata.pointerEnter
	end)	
	btn:AddMouseUp(function (pointdata)
		if self.newbieSelectObj == pointdata.pointerEnter or self.newbieSelectObj == nil then
			self:BtnClick(btn)
			self.newbieSelectObj = nil
		end	
	end)
end

function NewbieWidget:UnRegisterNewbie()
	if not self.btnData then return end
	
	for newbieid, steps in pairs(self.btnData) do
		for step, btn in pairs(steps) do
			NewbieManager.Instance:RegisterData(newbieid, step)
		end	
	end	
end

function NewbieWidget:CheckAllNewbieInfo()
	if self.btnData then
		for newbieid, steps in pairs(self.btnData) do
			for step, btn in pairs(steps) do
				self:ShowBtnNewbie(newbieid, step)
			end
		end	
	end	
end

--end

function NewbieWidget:ShowBtnNewbie(newbieid, step)
	local curNewbieid = NewbieManager.Instance.curNewbieid
	local curStep = NewbieManager.Instance.curStep
	-- print("=== ShowBtnNewbie ===", newbieid, step,curNewbieid,curStep)

	--显示按钮引导
	if curNewbieid == newbieid and curStep == step then
		if self.clist then
			self.clist.enabled = false
		end
		-- NewbieManager.Instance:ShowNewbieType(newbieid, step)
		NewbieManager.Instance:ShowNewbieTypeView(newbieid, step)
	end
end

function NewbieWidget:BtnClick(curbtn)
	if self.bForceguide then
		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.NewbieDialogView)
		if view and view:IsOpen() then
			view:CloseView()
		end
		self.bForceguide = false
	end
	
	if self.bWeakguide then
		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.NewbieWeakGuildView)
		if view and view:IsOpen() then
			view:CloseView()
		end		
		self.bWeakguide = false
	end	
	local curNewbieid = NewbieManager.Instance.curNewbieid
	local curStep = NewbieManager.Instance.curStep
	if self.btnData then
		for newbieid, steps in pairs(self.btnData) do
			for step, btn in pairs(steps) do
				if btn == curbtn then
					if self:CheckNewbie(newbieid, step) then
						return
					end	
				end	
			end
		end	
	end
end

--完成了当前的步骤，直接下一步步骤
function NewbieWidget:CheckNewbie(newbieid, step)
	local curNewbieid = NewbieManager.Instance.curNewbieid
	local curStep = NewbieManager.Instance.curStep
	-- print("CheckNewbie==", newbieid, step, curNewbieid, curStep)
	--如果按钮点击是下一步,则继续引导
	if curNewbieid == newbieid and curStep == step then
		
		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.NewbieDialogView)
		if view and view:IsOpen() then
			view:CloseView()
		end

		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.NewbieWeakGuildView)
		if view and view:IsOpen() then
			view:CloseView()
		end	

		if self.clist then
			self.clist.enabled = true
		end

		NewbieManager.Instance:NextStep()
		return true
	else
		return false
	end
end

--继续执行当前的步骤
function NewbieWidget:ContinueNewbie(newbieid, step)
	local curNewbieid = NewbieManager.Instance.curNewbieid
	local curStep = NewbieManager.Instance.curStep

	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.NewbieDialogView)
	if view and view:IsOpen() then
		view:CloseView()
	end

	if curNewbieid == newbieid and curStep == step then
		if self.clist then
			self.clist.enabled = true
		end

		NewbieManager.Instance:StartStep(step)
		return true
	else
		return false	
	end	
end

function NewbieWidget:StartNewbie(newbieid)
	local bguild = NewbieProxy.Instance:IsNeedGuild(newbieid)
	if bguild then
		NewbieManager.Instance:StartNewbie(newbieid)
	end	
end

return NewbieWidget