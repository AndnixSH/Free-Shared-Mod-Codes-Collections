local BattleDef = {}
BattleDef.NotifyDef =
{
	StopGame = "StopGame",
	UserSkill = "UserSkill",

	--game
	EnterGame = "EnterGame",
	SettleGame = "SettleGame",
	RestartGame = "RestartGame",

	--report
	BattleReport = "BattleReport",
}

BattleDef.FromType = 
{
	HeroSystem = 1, --英雄系统
}

BattleDef.Hire_Hero_Type = 
{
	Normal = 1,
	Hire_Hero = 2,  --上阵雇佣英雄
	
}

BattleDef.LanguageKeys = 
{
	BattleRelationView1 = "BattleRelation_1017", --我方阵容加成 等语言包
	BattleRelationView2 = "BattleRelation_1018",--敌方阵营加成
}

BattleDef.AddEnemyFightFactorType =
{
	[ACTIVITYID.MAINLINE] = 1,
	[ACTIVITYID.TOWER] = 1,
	[ACTIVITYID.MAZE] = 1,
}

BattleDef.ConstNum =
{
	MaxFightNum = 5, --最大上阵英雄数量
}

return BattleDef