local tinsert = table.insert
local trmove = global.array.remove

local function tquery(toquery, queryid)
    if not toquery[queryid] then
        toquery[queryid] = {}
    end
    return toquery[queryid]
end

local pool = 
{ 
    _listobj = {}, _dictobj = {}, _obj_id = 0,
    _listlogic = {}, _dictlogic = {},
}

function pool:_next_gen_id()
    self._obj_id = self._obj_id + 1
    return self._obj_id
end

function pool:add_obj(obj, uid)
    obj.uid = uid or self:_next_gen_id()
    self._dictobj[obj.uid] = obj
    tinsert(self._listobj, obj)
    return obj.uid
end

function pool:get_obj(uid)
    return self._dictobj[uid]
end

function pool:remove_obj(obj)
    self._dictobj[obj.uid] = nil
    trmove(self._listobj, obj)
end

function pool:get_objcount()
    return #self._listobj
end

function pool:get_allobjs()
    return self._listobj
end

function pool:remove_allobjs(obj)
    self._listobj = {}
    self._dictobj = {}
end

function pool:add_logic(obj, logic, logic_type)
    local listlogic = tquery(self._listlogic, obj.uid)
    tinsert(listlogic, logic)

    if logic_type then
        local dictlogic = tquery(self._dictlogic, obj.uid)
        dictlogic[logic_type] = logic
    end
end

function pool:get_all_logic(obj)
    return self._listlogic[obj.uid] or {}
end

function pool:getlogic(obj, logic_type)
    if logic_type then
        local dict = self._dictlogic[obj.uid]
        if dict then
            return dict[logic_type]
        end
    else
        global.debug.warning("logic_type is nil", obj)
    end
end

function pool:remove_logic(obj, logic, logic_type)
    local list = self._listlogic[obj.uid]

    if list then
        trmove(list, logic)
        if #list == 0 then self._listlogic[obj.uid] = nil end
    else
        global.debug.warning("self._listlogic do not contain obj uid")
    end

    if logic_type then
        local dict = self._dictlogic[obj.uid]
        if dict then
            dict[logic_type] = nil
        else
            global.debug.warning("self._dictlogic do not contain logic_type")
        end
    end
end

function pool:dump()
    global.debug.info("pool._listobj", #self._listobj)
    global.debug.info("pool._listlogic", #self._listlogic)
end

function pool:dispose()
    -- 遍历移除开销大  
    -- for i, obj in ipairs(self._listobj) do
    --     obj:destroy(true)
    -- end
    self._listobj = {}
    self._dictobj = {}
    self._listlogic = {}
    self._dictlogic = {}
    self._obj_id = 0
end

return pool