local ModuleManager = require "Common.Mgr.UI.ModuleManager"
local ClistRender = require "Core.Implement.UI.Class.ClistRender"
local ClistItem = require "Core.Implement.UI.Class.ClistItem"
local BagProxy = require "Modules.Bag.BagProxy"
local TaskProxy= require "Modules.Task.TaskProxy"
local TaskDef = require "Modules.Task.TaskDef"
local MainDef = require "Modules.Main.MainDef"
local MailProxy = require "Modules.Mail.MailProxy"
local FriendProxy = require "Modules.Friend.FriendProxy"
local RelationProxy = require "Modules.Relation.RelationProxy"
local ActivityProxy = require "Modules.Activity.ActivityProxy"
local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
local RedPointDef = require "Modules.RedPoint.RedPointDef"
local GameUIUtil = CS.GameUIUtil
----------------
local PoolItem = PetPoolItem or BaseClass(ClistItem)
function PoolItem:Load(obj)
	self.go = obj
	self.label = self:GetChildComponent(obj, "COutline_label", "CLabel")
	self.iconSp = self:GetChildComponent(obj, "CSprite_icon", "CSprite")
	self.redDot = self:GetChild(obj, "CSprite_RedTips")
	self.btn = self:GetComponent(obj, "CButton")
	self.btn:AddClick(function ()
		self:OnClick()
	end)		
end

function PoolItem:SetData(data)
	self.data = data
	self.label.text = self:GetWord(data.label)
	self.iconSp.SpriteName = data.icon

	local bopen = self:IsShowRedDot()
	local systemType = self.data.systemType
	local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
	
	if systemType == ModuleOpenDef.SystemOpenType.FriendlListView then
		RedPointProxy.Instance:BindNode(RedPointDef.Id.Friend, self.redDot)
	else --旧的红点实现
		self.redDot:SetActive((bopen and self.data.reddot > 0) and true or false)
	end
end

function PoolItem:PlaySound()
	local AudioManager = require "Common.Mgr.Audio.AudioManager"
	local _sound = self.data.sound
	AudioManager.PlaySoundByKey(_sound)
end

function PoolItem:OnClick()
	self:PlaySound()
	
	if self.data.view ~= "" then
		UIOperateManager.Instance:OpenWidget(table.unpack(self.data.parama))
	else
		GameLogicTools.ShowMsgTips(self:GetWord("Common_1033"))
	end
end

function PoolItem:Update_Item(infos)
	for i,v in ipairs(infos) do
		if self.index == i then
			--设置红点
			local bopen = self:IsShowRedDot()
			local systemType = self.data.systemType
			local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"

			if systemType == ModuleOpenDef.SystemOpenType.FriendlListView then
			else --旧的红点实现
				self.redDot:SetActive((bopen and v.reddot > 0) and true or false)
			end
		end
	end
end

function PoolItem:IsShowRedDot()
	local ModuleManager = require "Common.Mgr.UI.ModuleManager"
	local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
	local bopen = ModuleManager.SystemIsOpen(self.data.systemType, false)
	return bopen
end

---------------
local MainState = {
    Show = 0,
    Hide = 1
}

local MainSystemPanel = MainSystemPanel or BaseClass(GameObjFactor,TimerFactor)
function MainSystemPanel:__init(go)
	self.go = go
	self:Load(go)	
end
function MainSystemPanel:Load(obj)
	self.rect = self:GetComponent(obj, "RectTransform")
	self.rectPosition = self.rect.anchoredPosition		
	self.backRect = self:GetChildComponent(obj, "CSprite_back", "RectTransform")

    self.poolList = self:GetChildComponent(obj, "CList_menu", "CList")
    self.listRender = ClistRender.New()
    self.listRender:Load(self.poolList, PoolItem)

    self.openObj = self:GetChild(obj, "CSprite_back/CButton_close/sprite")
	self.openBtn = self:GetChildComponent(obj, "CSprite_back/CButton_close", "CButton")
	self.openBtn:AddClick(function ()
		self:ShowBar()
	end)	    
end

function MainSystemPanel:Open()
	self.go:SetActive(true)	
	self:ResetBagObjDepth()
	self:ResetBagObjScale()
	self:ShowBar(MainState.Show)
	self:SetDepth(self.openBtn.gameObject, self:GetNextDepth())
	self:StartOpenTween()
	ActivityProxy.Instance:Send62000()
	local ModuleManager = require "Common.Mgr.UI.ModuleManager"
	local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
	TaskProxy.Instance:Send17000(TaskDef.Task_Type.None)
	FriendProxy.Instance:Send19002()
	local MallProxy = require "Modules.Mall.MallProxy"
	MallProxy.Instance:Send72007()
	if self.timer then
		self:RemoveTimer(self.timer)
		self.timer=false
	end
	local index = 0
	self.timer=self:AddTimer(function ()
		-- local bopen2 = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.RelationMenuRootView,false)
		-- local bopen3 = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.RelationMenuRootView_2,false)
		if index == 0 then
			local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.MailView,false)
			if bopen then
				MailProxy.Instance:Send60001()
				-- if bopen2 or bopen3 then
				-- 	RelationProxy.Instance:Send20300()
				-- end
			end
		elseif index == 2 then
			
			RelationProxy.Instance:Send20307()
			
			ActivityProxy.Instance:Send62006()
			ActivityProxy.Instance:Send62002()
			ActivityProxy.Instance:Send62007()
			ActivityProxy.Instance:Send62009()
			ActivityProxy.Instance:Send62013()
			
			local ActivityDef = require "Modules.Activity.ActivityDef"
			for _ , v in ipairs(ActivityDef.HeroComingId) do
				if v then
					ActivityProxy.Instance:Send62011(v)
				end
			end
		elseif index == 1 then
			
			ActivityProxy.Instance:Send62004()
			local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.RankListView,false)
			if bopen then
				local RankListProxy = require "Modules.RankList.RankListProxy"
				RankListProxy.Instance:Send61003()
			end
		end
		index = index + 1
	end, 1, 3)
end	

function MainSystemPanel:UpdateDepth(depth)
	self:SetDepth(self.openBtn.gameObject, depth)
end

function MainSystemPanel:Close()
	self:ResetBagObjDepth()
	self.go:SetActive(false)
	if self.opensequence then
		self.opensequence:Kill()
		self.opensequence = nil
	end
	if self.timer then
		self:RemoveTimer(self.timer)
		self.timer=false
	end		
	self.listRender:Close()
end	

function MainSystemPanel:Destroy()
	self.systemCfg = nil
	if self.timer then
		self:RemoveTimer(self.timer)
		self.timer=false
	end
	self.listRender:Destroy()
end

function MainSystemPanel:GetSystemCfg()
	local systemCfg = ModuleManager.GetSystemConfig()
	local infos = {}
	for i,_value in ipairs(systemCfg) do
		local item = {}
		item.label = self:GetWord(_value.label)
		item.icon = _value.icon
		item.view = _value.view
		item.systemType = _value.systemOpenType
		item.parama = _value.gotoParama
		item.reddot = 0
		item.sound = _value.sound
		if _value.redDotType == MainDef.MainRedDotType.Bag then
			item.reddot = BagProxy.Instance:GetBagRedDot()
		elseif _value.redDotType == MainDef.MainRedDotType.Task then
			item.reddot = TaskProxy.Instance:GetTaskRedDot()
		elseif _value.redDotType == MainDef.MainRedDotType.Mail then
			item.reddot=MailProxy.Instance:GetMailRedDot() 
		end
		table.insert(infos, item)
	end
	return infos
end

function MainSystemPanel:UpdateInfo()
	self.systemCfg = self:GetSystemCfg()
    self.listRender:ClearData()
	--新号看完开机动画进来 如果此处list做动画，不会显示list，alhpa为0，猜是卡了一些导致的
    self.listRender:AppendDataList(self.state == MainState.Hide and {[1] = self.systemCfg[1]} or self.systemCfg, "")
    self.listRender:SetEnable(self.state == MainState.Show and #self.systemCfg >= 5)
end

function MainSystemPanel:ShowBar(state)
    if state == nil then
        state = (self.state == MainState.Hide) and MainState.Show or MainState.Hide        
    end

	if self.state ~= state then
		self.state = state
		if state == MainState.Show then		
			local systemCfg = ModuleManager.GetSystemConfig()
			local height = 201 + (#systemCfg > 5 and 5 or #systemCfg) * 100 - 100

			self.openObj.transform.localScale = Vector3.New(1, 1, 1)
			self.backRect:DOSizeDelta(Vector2.New(98, height), 0.2)
		else
			local height = 201
			self.openObj.transform.localScale = Vector3.New(1, -1, 1)
			self.backRect:DOSizeDelta(Vector2.New(98, height), 0.2)
		end	
		self:UpdateInfo()
	end
end	

function MainSystemPanel:StartOpenTween()
	-- self.rect.anchoredPosition = Vector2.New(self.rectPosition.x + 100, self.rectPosition.y)
	-- local tween1 = self.rect:DOAnchorPosX(self.rectPosition.x - 10, 0.2)
	-- local tween2 = self.rect:DOAnchorPosX(self.rectPosition.x, 0.2)

	-- local sequence = DOTween.Sequence()
	-- sequence:Append(tween1)
	-- sequence:Append(tween2)
	-- self.opensequence = sequence
	GameUIUtil.SetGroupAlpha(self.rect.gameObject,0)
	GameUIUtil.SetGroupAlphaInTime(self.rect.gameObject ,1 ,0.3)
	
	self:ResetBagObjScale()
end

function MainSystemPanel:ShowRedDot(type, num)
	if self.systemCfg then
		if type == MainDef.MainRedDotType.Bag or
			type == MainDef.MainRedDotType.Task or
			type == MainDef.MainRedDotType.Mail then
			
			self.systemCfg = self:GetSystemCfg()
			self.listRender:ExecuteMethod("Update_Item", self.systemCfg)
		end

	end
end

function MainSystemPanel:GetState()
	return self.state
end

--背包item坐标
function MainSystemPanel:GetBagItemPos()
	local pos = Vector3.New(0,0,0)
	local obj 
	if self.systemCfg then
		for i,v in ipairs(self.systemCfg) do
			if v.view == UIWidgetNameDef.BagRootView then
				local item_class = self.listRender:GetClassOnIdx(i)
				if item_class then
					local _pos = item_class.go.transform.position
					pos = Vector3.New(_pos.x, _pos.y, 0)
					obj = item_class.go
				end
				break
			end
		end
	end
	return pos, obj
end

function MainSystemPanel:ResetBagObjDepth()
	local _pos, _obj = self:GetBagItemPos()
	if _obj then
		_obj:SetActive(true)
		self:SetDepth(_obj, 0, true)
	end
end

function MainSystemPanel:ResetBagObjScale()
	local _pos, _obj = self:GetBagItemPos()
	if _obj then
		_obj.transform.localScale = Vector3.New(1,1,1)
	end
end

return MainSystemPanel