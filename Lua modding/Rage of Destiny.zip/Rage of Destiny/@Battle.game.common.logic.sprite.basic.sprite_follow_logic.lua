local logic = { timer = {} }

function logic:oncreate()

    self.prop.keep_distance = self.prop.keep_distance or 1500
    self.prop.forward_speed = self.prop.forward_speed or 5000
    self._target_vel = nil

    self._target = self.prop.target

    if not self._target and self.prop.rangeid then
        self._target = self:_find_target()
    end

end

function logic:_find_target()
    if  self.caller.skill then
        local targets = self.caller.skill:range(self.prop.rangeid)
        if #targets > 0 then
            local target = targets[1]
            return target
        end
    end
end

function logic.timer:f1()
    
    if self._target then

        if self._target.caller.state and self._target.caller.state:isdead() then
            self._target = self:_find_target()
        end

        if self._target then

            local mypos = self.owner.body.position
            local targetpos = self._target.body.position

            if tsvector.distance_less(mypos, targetpos, self.prop.keep_distance) then
                if not self._target_vel or self._target_vel ~= self._target.body.velocity then
                    self._target_vel = self._target.body.velocity
                    if self._target_vel == tsvector.zero then
                        self.owner.body:setheader(self._target.body.header)
                    end
                    self.owner.body:setvelocity(self._target_vel)
                end
            else
                local header = (targetpos - mypos).normalized
                self.owner.body:setvelocity(header:fmul(self.prop.forward_speed))
            end

        end

    end
end

return logic