local AudioManager = require "Common.Mgr.Audio.AudioManager"
local GameUIUtil = CS.GameUIUtil
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"
local HeroProxy = require "Modules.Hero.HeroProxy"
local BattleProxy = require "Modules.Battle.BattleProxy"
local CampaignProxy = require "Modules.Campaign.CampaignProxy"
local TaskProxy = require "Modules.Task.TaskProxy"
local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"
local TaskPoolItem=require "Modules.Battle.TaskPoolItem"
-------------
local GoodsItem = require "Core.Implement.UI.Class.GoodsItem"

local ObjPoolRender = require "Core.Implement.UI.Class.ObjPoolRender"
local ObjPoolItem = require "Core.Implement.UI.Class.ObjPoolItem"

local UISpineView = require "Core.Implement.UI.Class.UISpineView"
local AutoBattleProxy = require "Modules.AutoBattle.AutoBattleProxy"
local AutoBattleDef = require "Modules.AutoBattle.AutoBattleDef"

local BagProxy = require "Modules.Bag.BagProxy"
local BagDef = require "Modules.Bag.BagDef"

local HeroDef = require "Modules.Hero.HeroDef"

local GoodsPoolItem = PoolItem or BaseClass(ObjPoolItem)
function GoodsPoolItem:Load(obj)
	self.goodsObj = self:GetChild(obj, "GoodsItem")
	self.goodsItem = GoodsItem.New(self.goodsObj)
end

function GoodsPoolItem:SetData(data)
	local goodsid = data[1]
	local goodsnum = data[2]
	self.goodsItem:SetData(goodsid, goodsnum)
	self.goodsItem:SetClickOpenInfo()
	self:ScaleTween(self.goodsObj)
	
	local cfg = BagProxy.Instance:GetGoodsCfgById(goodsid)
	
	if cfg then
		if cfg.subtype == BagDef.SubType.Elite_Hero_Card or cfg.subtype == BagDef.SubType.Rare_Hero_Card then
			self.goodsItem:ChangeShowEffectMinQuality(HeroDef.Hero_Rank_Enum.green)
			self.goodsItem:ShowQualityCircleEffectLoop(cfg.quality)
		end
	end
end

-----EnhancePoolItem
local _EnhanceType = 
{
	[1] = {word = "BattleSettlement_1006", },
	[2] = {word = "BattleSettlement_1007", },
	[3] = {word = "BattleSettlement_1008", },
	[4] = {word = "BattleSettlement_1009", },
	[5] = {word = "BattleSettlement_1010", },
}

local EnhancePoolItem = EnhancePoolItem or BaseClass(ObjPoolItem)
function EnhancePoolItem:Load(obj)
	self.go = obj
	self.contentLab = self:GetChildComponent(self.go, "CLabel_task", "CLabel")

	self.gotoBtn = self:GetChildComponent(obj, "sprite", "CButton")
	self.gotoBtn:AddClick(function ()
		self:OnGoto()
	end)
end

function EnhancePoolItem:SetData(type)
	self.type = type
	local info = _EnhanceType[type]
	self.contentLab.text = self:GetWord(info.word)
end

function EnhancePoolItem:OnGoto()
	--自己点了变强就不需要再引导了
    local NewbieProxy = require "Modules.Newbie.NewbieProxy"
    NewbieProxy.Instance:SetSpecialStatus(false)	

	if self.type == 1 then
		BattleProxy.Instance:EscGame()
		SceneManager.Instance:EnterScene(SceneDef.SceneType.Temple)

	elseif self.type == 2 then
		local CrystalProxy = require "Modules.Crystal.CrystalProxy"
		if CrystalProxy.Instance:IsUnLock() then
			BattleProxy.Instance:EscGame()
			SceneManager.Instance:EnterScene(SceneDef.SceneType.Crystal)
		else	
			SceneManager.Instance:EnterScene(SceneDef.SceneType.Main, {UIWidgetNameDef.HeroRootView})
		end
	elseif self.type == 3 then
		SceneManager.Instance:EnterScene(SceneDef.SceneType.Main, {UIWidgetNameDef.HeroRootView})
	elseif self.type == 4 then
		SceneManager.Instance:EnterScene(SceneDef.SceneType.Main, {UIWidgetNameDef.HeroRootView})
	elseif self.type == 5 then
		BattleProxy.Instance:RestartGame()
	end	
end

-------------------

local BattleSettlementView = BattleSettlementView or BaseClass(LuaBasicWidget)
function BattleSettlementView:__init()
	self.wincamp = nil
	self.battleType = nil
	self.args = nil
	self.enemy_id = nil
	self.enemyData = nil
end

function BattleSettlementView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Battle.BattleSettlementView",self.LoadEnd)
end

function BattleSettlementView:LoadEnd(obj)
	self:SetGo(obj)

	self.winObj = self:GetChild(obj, "win")
	self.winTweenObj = self:GetChild(obj, "win/icon")
	self.winiconObj = self:GetChild(obj, "win/icon/COutline_icon")
	self.winLbl = self:GetChildComponent(self.winObj, "CVerticalItem/item1/CLabel_num", "CLabel")

	self.loseObj = self:GetChild(obj, "lose")
	self.loseTweenObj = self:GetChild(obj, "lose/icon")
	self.loseiconObj = self:GetChild(obj, "lose/icon/COutline_icon")

	self.goodsItem = self:GetChild(self.winObj, "CHorizontalItem/item1")
    self.goodsPoolRender = ObjPoolRender.New()
    self.goodsPoolRender:Load(self.goodsItem, self.goodsItem.transform.parent, GoodsPoolItem)

    self.taskObj = self:GetChild(self.winObj, "CVerticalItem")
    self.taskItem = self:GetChild(self.taskObj, "item1")
    self.taskPoolRender = ObjPoolRender.New()
    self.taskPoolRender:Load(self.taskItem, self.taskItem.transform.parent, TaskPoolItem)

    self.enhanceObj = self:GetChild(self.loseObj, "CVerticalItem1")
    self.enhanceItem = self:GetChild(self.enhanceObj, "item1")
    self.enhancePoolRender = ObjPoolRender.New()
    self.enhancePoolRender:Load(self.enhanceItem, self.enhanceItem.transform.parent, EnhancePoolItem)

	self.closeBtn = self:GetChildComponent(obj, "Black/sprite", "CButton")
	self.closeBtn:AddClick(function ()
		local bclose = self:CancelAutoBattle() --点击屏幕关闭自动推图倒计时或者关闭界面
		if bclose ~= nil then
			if bclose then
				self:EscGame()
			end
		end
	end)

	self.recordBtn_1 = self:GetChildComponent(obj, "win/CButton_record", "CButton")
	self.recordBtn_1:AddClick(function ()
		self:OnClickRecord()
	end)
	self.recordBtn_2 = self:GetChildComponent(obj, "lose/CButton_record", "CButton")
	self.recordBtn_2:AddClick(function ()
		self:OnClickRecord()
	end)
	
	self.continueBtn_1 = self:GetChildComponent(obj, "win/next", "CButton")
	self.continueBtnLabe_1 = self:GetChildComponent(obj, "win/next/label", "CLabel")
	self.continueBtn_1:AddClick(function ()
		self:ClearAutoBattleTimer()
		if self.bAutoBattle ~= nil then
			if self.bAutoBattle then
				if self.battleType == ACTIVITYID.MAINLINE or self.battleType == ACTIVITYID.TOWER then
					AutoBattleProxy.Instance:StartGame(self.battleType, self.args[1], self:GetNextBattleEnemyID())
				else
					BattleProxy.Instance:RestartGame()			
				end
			else
				BattleProxy.Instance:RestartGame(self:GetNextBattleEnemyID())
			end
		end
	end)
	self.continueBtn_2 = self:GetChildComponent(obj, "lose/next", "CButton")
	self.continueBtn_2:AddClick(function ()
		self:ClearAutoBattleTimer()
		if self.bAutoBattle ~= nil then
			if self.battleType == ACTIVITYID.MAINLINE then
				self:EscGame()
				BattleProxy.Instance:RestartGame(self:GetNextBattleEnemyID())
				--self:OpenNextBattle()
			else
				if self.bAutoBattle and (self.battleType == ACTIVITYID.TOWER) then
					AutoBattleProxy.Instance:StartGame(self.battleType, self.args[1], self:GetNextBattleEnemyID())
				else
					BattleProxy.Instance:RestartGame()
				end
			end
		end
	end)

	self.addBtn = self:GetChildComponent(self.loseObj, "CVerticalItem1/item1/sprite", "CButton")
	self.addBtn:AddClick(function ()		
		GameLogicTools.ShowMsgTips(self:GetWord("Common_1033"))
	end)

	-- self.win3effect = UIEffectItem.New("UI_BattleSettlement_win3", self.go)
	-- self.win3effect:SetLocalPosition(65, 0, 0)

	self.winSpineRoot = self:GetChild(self.winObj, "spineRoot")
	self.loseSpineRoot = self:GetChild(self.loseObj, "spineRoot")

	self.winEffectRoot = self:GetChild(self.winObj, "effectRoot")
	self.loseEffectRoot = self:GetChild(self.loseObj, "effectRoot")

	self.spine_win_view = UISpineView.New(self.winSpineRoot)
	self.spine_lose_view = UISpineView.New(self.loseSpineRoot)

	self.rootObj = self:GetChild(self.go, "root")

	self.autoBattleObj = self:GetChild(self.go, "computer")
	self.autoBattleLab = self:GetChildComponent(self.autoBattleObj, "COutline_label", "CLabel")
	self.autoBattleObj:SetActive(false)


	self:SetStep(0)
end

function BattleSettlementView:OnOpen()
	if self.effect then
		self.effect:Destroy()
		self.effect = nil
	end
	if self.effect_result then
		self.effect_result:Close()
		self.effect_result = nil
	end

	AudioManager.StopBGM()
	self:DealAutoBattle()
	self:UpdateInfo()
end

function BattleSettlementView:OnClose()
	self:ClearAutoBattleTimer()
	self.goodsPoolRender:ReleaseAll()
	self.taskPoolRender:ReleaseAll()
	if self.tween then
		self.tween:Kill()
		self.tween = nil
	end	
	if self.effect then
		self.effect:Destroy()
		self.effect = nil
	end	
	if self.effect_result then
		self.effect_result:Destroy()
		self.effect_result = nil
	end	
	if self.effect_fly then
		self.effect_fly:Destroy()
		self.effect_fly = nil
	end		
	-- if self.win3effect then
	-- 	self.win3effect:Destroy()
	-- 	self.win3effect = nil
	-- end	


	if self.spine_win_view then
		self.spine_win_view:Close()
	end
	if self.spine_lose_view then
		self.spine_lose_view:Close()
	end

end

function BattleSettlementView:OnDestroy()
	self:ClearAutoBattleTimer()
	self.taskPoolRender:ReleaseAll()
	if self.tween then
		self.tween:Kill()
		self.tween = nil
	end	
	if self.effect then
		self.effect:Destroy()
		self.effect = nil
	end	
	if self.effect_result then
		self.effect_result:Destroy()
		self.effect_result = nil
	end	
	-- if self.win3effect then
	-- 	self.win3effect:Destroy()
	-- 	self.win3effect = nil
	-- end	

	if self.spine_win_view then
		self.spine_win_view:Destroy()
		self.spine_win_view = nil
	end
	if self.spine_lose_view then
		self.spine_lose_view:Destroy()
		self.spine_lose_view = nil
	end				
end

--下一关按钮显示
function BattleSettlementView:SetNextBtnActive()
	if self.battleType == ACTIVITYID.MAINLINE then
		local bCancelAuto = AutoBattleProxy.Instance:CheckCancelAutoBattle(self.battleType, (self.wincamp == CAMP.RED) and true or false)
		self.continueBtn_1.gameObject:SetActive(bCancelAuto == false and true or false)
		self.continueBtn_2.gameObject:SetActive(bCancelAuto == false and true or false)
	else
		self.continueBtn_1.gameObject:SetActive(false)
		self.continueBtn_2.gameObject:SetActive(false)
	end
end

function BattleSettlementView:GetEffectTopDepth() 
	self:GetNextDepth()
	self:GetNextDepth()
	self:GetNextDepth()
	self:GetNextDepth()
	self:GetNextDepth()
	self:GetNextDepth()
	self:GetNextDepth()
	self:GetNextDepth()
end

function BattleSettlementView:ClearAutoBattleTimer()
	if self.autoBattleTimer then
		self.autoBattleTimer:Stop()
		self.autoBattleTimer = nil
	end
end

function BattleSettlementView:AutoBattleTimer()
	self.autoLeftTime = 3
	self:ClearAutoBattleTimer()
	self.autoBattleObj:SetActive(true)
	self.autoBattleLab.text = self:GetWord(AutoBattleDef.LanguageKeys.LanguageKey3, self.autoLeftTime)
	self.autoBattleTimer = self:AddTimer(function()
		self.autoLeftTime = math.max(self.autoLeftTime - 1, 0)
		self.autoBattleLab.text = self:GetWord(AutoBattleDef.LanguageKeys.LanguageKey3, self.autoLeftTime)
		if self.autoLeftTime == 0 then
			AutoBattleProxy.Instance:StartGame(self.battleType, self.args[1], self:GetNextBattleEnemyID())
			self.autoBattleObj:SetActive(false)
		end
	end, 1, 3)
end

function BattleSettlementView:DealAutoBattle()
	self.bAutoBattle = false --是否自动战斗
	self.autoBattleObj:SetActive(false)
	self:ClearAutoBattleTimer()
	
	local bCancelAuto = AutoBattleProxy.Instance:CheckCancelAutoBattle(self.battleType, (self.wincamp == CAMP.RED) and true or false)
	if not bCancelAuto then
		if self.battleType == ACTIVITYID.MAINLINE or self.battleType == ACTIVITYID.TOWER then
			local status = AutoBattleProxy.Instance:GetAutoBattleStatus()
			if status == 1 then
				self.bAutoBattle = true --是否自动战斗
				--播放战报后不显示倒计时,但是点击下一关要重新开启自动推图，所以要先设置bAutoBattle
				if not BattleProxy.Instance:IsReportBattle() then
					self:AutoBattleTimer()
				end
			end
		end
	end
end

function BattleSettlementView:CancelAutoBattle()
	local bclose = nil --点击屏幕关闭界面回到住见面
	if self.bAutoBattle ~= nil then
		bclose = true
		if self.bAutoBattle then
			if self.autoBattleObj.activeSelf then
				--点击屏幕关闭倒计时
				self:ClearAutoBattleTimer()
				self.autoBattleObj:SetActive(false)
				bclose = false
			else
			end
		end
	end
	return bclose
end

function BattleSettlementView:EscGame()
	self:CloseView()
	BattleProxy.Instance:EscGame()
end

function BattleSettlementView:OpenNextBattle()
	local enemyid = self:GetNextBattleEnemyID()
	local enemylist = GameLogicTools.GetEnemyList(enemyid)
	UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 1, self.battleType, enemylist, enemyid)
end

function BattleSettlementView:GetNextBattleEnemyID()
	if self.wincamp == CAMP.RED then
		if self.battleType == ACTIVITYID.MAINLINE then
			local mainlineid = RoleInfoModel.mainlineid
			local mainlinecfg = CampaignProxy.Instance:GetMainLineCfgById(mainlineid)
			local enemys = CampaignProxy.Instance:GetAllEnemy(mainlineid)
			for _,enemyid in ipairs(enemys) do
				if not CampaignProxy.Instance:GetPassState(mainlineid, enemyid) then
					return enemyid
				end
			end
		end
	end
	return self.enemy_id
end

function BattleSettlementView:UpdateInfo()
	self:SetNextBtnActive()

	local effectNextdepth = self:GetNextDepth()
	self:GetNextDepth()
	local spineNextdepth = self:GetNextDepth()

	local nextdepth = self:GetNextDepth()
	local nextdepth2 = self:GetNextDepth()

	self:GetEffectTopDepth()
	local effectTopDepth = self:GetNextDepth()
	self:GetNextDepth()

	
	self:ShowTaskInfo()
	if self.wincamp == CAMP.RED then
		self.winObj:SetActive(true)
		self.loseObj:SetActive(false)
		self:ShowReward()
		AudioManager.PlaySoundByKey("wf_ty_victory")
		self:ShowTween(self.winTweenObj)

		self.effect_result2 = UIEffectItem.New("UI_BattleSettlement_win1_2", self.winSpineRoot)
		self.effect_result2:SetLocalPosition(0,0,0)

		self.effect_result = UIEffectItem.New("UI_BattleSettlement_win1_1", self.winEffectRoot)
		self.effect_result:SetLocalPosition(0,0,0)

		self:SetDepth(self.winEffectRoot, effectNextdepth)
		self:SetDepth(self.winSpineRoot, spineNextdepth)

		local spine_parama = {position = {-231,-201, 0}, scale = 1, rotation = 0, active = "idle"}
		self.spine_win_view:SetModel("UI_BattleSettlement_win1", spine_parama, "idle")
		self:AddTimer(function( ... )
			self.spine_win_view:StartActive("idle01")
		end, 0.5, 1)

		self.effect_result2:Open()
		self.effect_result2:SetOrderLayer(effectTopDepth)

		self:AddTimer(function()
			self.effect_result:Open()
			self.effect_result:SetOrderLayer(effectNextdepth)
		end, 0.4, 1)

		self:SetDepth(self.winiconObj, nextdepth2) 

	else
		self.winObj:SetActive(false)
		self.loseObj:SetActive(true)
		AudioManager.PlaySoundByKey("wf_ty_defeat")
		self:ShowTween(self.loseTweenObj)
		self.effect = UIEffectItem.New("UI_BattleSettlement_lose2", self.rootObj)
		
		local spine_parama = {position = {0,0,0}, scale = 1, rotation = 0, active = "idle"}
		self.spine_lose_view:SetModel("UI_BattleSettlement_lose1", spine_parama, "idle")

		self:AddTimer(function( ... )
			self.spine_lose_view:StartActive("idle01")
		end, 0.5, 1)		

		self:SetDepth(self.loseiconObj, nextdepth2)
		self:ShowEnhanceInfo()

		self.effect:Open()
		self.effect:SetOrderLayer(nextdepth)
	end
	
end

function BattleSettlementView:ShowTaskInfo()
	local task_infos = {}
	self.taskPoolRender:ReleaseAll()
	local towerType = nil
	if self.args and self.args[1] then
		towerType = self.args[1]
	end
	local task_types = TaskProxy.Instance:GetTaskTypeConfigByActivityId(self.battleType, towerType) --玩法id, 爬塔类型
	for k,_type in pairs(task_types) do
		TaskProxy.Instance:GetTaskInfoByTargerType(task_infos, _type)
	end
	self.taskPoolRender:GetList(task_infos)
	TaskProxy.Instance:BattleEndResetTaskStatus()

	self.taskPoolRender:ExecuteMethod("StartTween")
end

function BattleSettlementView:ShowReward()
	local rewards = {}
	local key1, key2 = "Msgtips_hexmap_1110", "Msgtips_hexmap_1111"
	self.continueBtnLabe_1.text = self:GetWord(key1)
	if self.battleType == ACTIVITYID.MAINLINE then
		rewards = BattleProxy.Instance:GetBattleRewards()
	elseif self.battleType == ACTIVITYID.MAZE then
		rewards = BattleProxy.Instance:GetBattleRewards()
		self.continueBtnLabe_1.text = self:GetWord(key2)
	elseif self.battleType == ACTIVITYID.STORYLINE or self.battleType == ACTIVITYID.ACTIVITY then
		self.continueBtnLabe_1.text = self:GetWord(key2)
	elseif self.battleType == ACTIVITYID.TOWER then
		rewards = BattleProxy.Instance:GetBattleRewards()
		self.continueBtnLabe_1.text = self:GetWord("battleView_1004")
	elseif self.battleType == ACTIVITYID.SUPPLY_DEPOT then
		rewards = BattleProxy.Instance:GetBattleRewards()
	end	

	for _,reward in pairs(rewards) do
		self.goodsPoolRender:Get(reward)
	end		
end

function BattleSettlementView:ShowTween(tweenobj)
	tweenobj.transform.localScale = Vector2.New(12,12)
	self.tween = tweenobj.transform:DOScale(Vector2.one, 0.5)
	self.tween:SetEase(Ease.OutBack)

	GameUIUtil.SetGroupAlpha(tweenobj, 0.1)
	GameUIUtil.SetGroupAlphaInTime(tweenobj ,1 ,0.5)
end

function BattleSettlementView:ShowEnhanceInfo()
	self.enhancePoolRender:ReleaseAll()
	local randomcount = 0
	for i=1, 5 do
		local binsert = true
		if math.random(1, 2) == 1 and randomcount < 2 then
			randomcount = randomcount + 1
			binsert = false
		end
		if binsert and self.enhancePoolRender:Count() < 3 then
			self.enhancePoolRender:Get(i)
		end
	end
end

--onclick
function BattleSettlementView:OnClickRecord()
	self:CancelAutoBattle()
	if self:IsMultiEnemy() then
		CampaignProxy.Instance:ShowBattleRecordListView(self.battleType, self.args[1], RoleInfoModel.guserid, table.deepcopy(RoleInfoModel))
	else
		self:ShowBattleResult()
	end
end
	
function BattleSettlementView:IsMultiEnemy()
	if self.battleType == ACTIVITYID.MAINLINE then
		if self.args then
			local mainlineid = self.args[1]
			if mainlineid then
				return CampaignProxy.Instance:HasExtraEnemy(mainlineid)
			end
		end
	end
	return false
end

function BattleSettlementView:ShowBattleResult()
	local redData = nil
	local blueData = nil
	redData = table.deepcopy(RoleInfoModel)

	--战斗id给一个首领信息
	if self.enemy_id then
	    local enemylist, bossinfo = GameLogicTools.GetEnemyList(self.enemy_id)
	    local info = bossinfo or enemylist[1]
	    if info then
	    	blueData = {}
	        local herocfg = HeroProxy.Instance:GetRoleCfgByConfigId(info.role)
	        blueData.nickname = self:GetWord(herocfg.name)
	        blueData.level = info.level
	        blueData.rank = info.rank
	        blueData.roleid = info.role
	    end	

	--从外部传来玩家信息，对应headitem
	elseif self.enemyData then
		blueData = self.enemyData

	--从战斗内随机拿一个敌人信息
	else
		local sprite = nil
		local spritelist = BattleProxy.Instance:GetSpriteList(CAMP.BLUE)
		for _, spriteid in pairs(spritelist) do
			sprite = BattleProxy.Instance:GetSprite(spriteid)
			break
		end
		if sprite then
	    	blueData = {}
	        local herocfg = HeroProxy.Instance:GetRoleCfgByConfigId(sprite.static.id)
	        blueData.nickname = self:GetWord(herocfg.name)
	        blueData.level = sprite.attr.level
	        blueData.rank = sprite.attr.rank
	        blueData.roleid = sprite.static.id
		end
	end

	if redData and blueData then
		local callback, bformationBtn, camps = nil, nil, nil
		if self.battleType == ACTIVITYID.MAINLINE or self.battleType == ACTIVITYID.TOWER then
			callback = function()
				BattleProxy.Instance:PlayLastLocalGame()
			end
			camps = BattleProxy.Instance:GetSettleData()
			local showTeamBtn = not BattleProxy.Instance:IsPlayOtherReportGame()
			bformationBtn = {showTeamBtn, false}
		end
		
		UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 4, self.wincamp, redData, blueData, camps, callback, bformationBtn)
	end	
end

return BattleSettlementView