local AutoBattleDef = {}


AutoBattleDef.AutoStatusKey = "auto_battle_status_"


AutoBattleDef.LanguageKeys = 
{
	LanguageKey1 = "AutoBattle_1001",
	LanguageKey2 = "AutoBattle_1002",
	LanguageKey3 = "AutoBattle_1003",
}

return AutoBattleDef