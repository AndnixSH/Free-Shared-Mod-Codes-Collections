local logic = { call = service.call(calldef.suffer), timer = {}, event = service.event() }
local dmguffer = { prob = 100, buffid = 900101 }
local sufferactive = {
    [1] = {"hit", nil, nil, nil},
    [2] = {"dizzy", nil, nil, nil},
    [3] = {"liedown", nil ,nil, "getup"},
    [4] = {"dizzy", nil, "floatingdown", "getup"},
    [5] = {"floatingdown", nil, nil, "getup"},
    [6] = {"dizzy", nil, "liehit", "getup"},
}

function logic:oncreate()
    self.suffer_buff = false -- buff触发的suffer
    self.suffer_move = nil   -- 技能触发的suffer
end

--suffer enter
function logic.call:add(fromobj, castobj, suffer_table)

    
    local type, dis, d, prob = table.unpack(suffer_table)
    local hor, ver = table.unpack(dis)

    -- if self.suffer_move and self.suffer_move.type > type then return end
    if self.suffer_move and self.suffer_move.step < 4 and self.suffer_move.height > 0 and ver <= 0 then return  end
    if self.suffer_move and self.suffer_move.step < 4 and self.suffer_move.distance > 0 then hor = 0 end -- 联动规则

    local d1, d2, d3, d4 = table.unpack(d)

    self._trigger_sufffer_table = { fromobj = fromobj, toobj = self.owner, duration = d1 + d2 + d3 + d4 }
    self:sendmessage(eventdef.before_suffer_start, self._trigger_sufffer_table)

    if self.owner.attr.immune_suffer >= 1 then
        self:sendmessage(eventdef.suffer_immune, self._trigger_sufffer_table)
        return 
    end -- 是否免疫suffer

    if (hor ~= 0 or ver > 0) and self.owner.buff.immune_shift_suffer then return end

    if tsmath.random_match(prob) then
        self.caller.body:setheader_towards(fromobj)
        local topos = self.owner.body.position
        local frompos = castobj.body.position
        local dir = topos - frompos
        local distance = dir:magnitude()
        if ver == 0 and hor < 0 and tsmath.abs(hor) > (distance - castobj.body.radius - self.owner.body.radius) then
            hor = -(distance - fromobj.body.radius - self.owner.body.radius)
        end
        local header = dir:fdiv(distance * (hor < 0 and -1 or 1))
        self.suffer_move = { type = type, d1 = d1, d2 = d2, d3 = d3, d4 = d4,
                             header = header, distance = tsmath.abs(hor), height = ver, cur = 0, step = 0 }
        -- print("from suffer", table.dump(self.suffer_move))
    end
end

-- buff enter
function logic.call:entersuffer(fromobj, buffid)
    
    self._trigger_sufffer_table = { fromobj = fromobj, toobj = self.owner, buffid = buffid }
    self:sendmessage(eventdef.before_suffer_start, self._trigger_sufffer_table)

    if self.owner.attr.immune_suffer >= 1 then
        self:sendmessage(eventdef.suffer_immune)
        return 
    end -- 是否免疫suffer
    
    if not self.suffer_move then -- suffer动画
        local buffgroup =  self.caller.buff:getgroup(buffid)
        if buffgroup then
            for _,groupid in ipairs(self.caller.buff:getgroup(buffid)) do
                if groupid == BUFF.GROUP_NAME.DIZZY or groupid == BUFF.GROUP_NAME.HIT then
                    self.caller.view:start_active(BUFF.GROUP[groupid])
                    break
                end
            end
        end
    end

    self.suffer_buff = true
    -- print("from buff", buffid)
end

function logic.call:exitsuffer()
    self.suffer_buff = false
end

function logic.call:getstep()
    if self.suffer_move then
        return self.suffer_move.step
    end
    return 0
end

function logic.call:gettype()
    if self.suffer_move then
        return self.suffer_move.type
    end
    return false
end

function logic.event.sprite.public:skill_damage(fromobj, dmgtable)
    if dmgtable.toobj == self.owner and dmgtable.value >= tsmath.rate(self.owner.attr.hp_max, dmguffer.prob) then
        self.owner.caller.buff:add(dmguffer.buffid, dmgtable.fromobj)
    end
end

function logic:play_active(type, index)
    local activelist = assert(sufferactive[type], "非法的suffer类型"..type)
    local activename = activelist[index]
    if activename then
        self.caller.view:start_active(activename)
    end
end

------------------------------状态机------------------------------
function logic:onbreak()
    return self.suffer_move or self.suffer_buff
end

function logic:onenter(time)
    if self._trigger_sufffer_table then
        self:sendmessage(eventdef.suffer_start, self._trigger_sufffer_table)
    end
    -- print("entersuffer", self.owner, self._trigger_sufffer_table, debug.traceback())
end

function logic:onupdate(time, tick)

    local sm = self.suffer_move
    if sm then
        local step = nil
        local curtime = sm.cur + tick
        local curstep = sm.step
        if curstep == 0 then
            step = 1
        elseif curstep == 1 and curtime >= sm.d1 then
            step = 2
        elseif curstep == 2 and curtime >= sm.d1 + sm.d2 then
            step = 3
        elseif curstep == 3 and curtime >= sm.d1 + sm.d2 + sm.d3 then
            step = 4
        elseif curstep == 4 and curtime >= sm.d1 + sm.d2 + sm.d3 + sm.d4 then
            step = 5
        end
        sm.cur = curtime
        if step then
            self:set_suffer_move_step(step)
        end
     end

    return (not self.suffer_buff and (not sm or sm.step == 5)) and STATE_STATUS.OVER or STATE_STATUS.SUSPEND
end

function logic:set_suffer_move_step(step)
    local sm = self.suffer_move
    if sm.step ~= step then
        -- print('setstep', self.owner, step)
        sm.step = step
        if step == 1 then     -- 上升
            if sm.height > 0 then
                if sm.d1 > 0 then
                    self.owner.body:accverticle(sm.height, sm.d1)
                elseif sm.d1 == 0 then
                    self.owner.body:setheight(sm.height)
                end
            end
            if sm.distance > 0 then
                self.owner.body:moveforward(sm.header, sm.distance, sm.d1 + sm.d2 + sm.d3)
            end
            self:sendmessage(eventdef.suffer_move_start)
            self:play_active(sm.type, 1)
        elseif step == 2 then -- 滞空
            self:play_active(sm.type, 2)
            self.owner.body:setvmotion(0, 0)
        elseif step == 3 then -- 下降
            if sm.height > 0 and sm.d3 > 0 then
                self.owner.body:accverticle(-(sm.height + self.owner.body.height), sm.d3)
            end
            self:play_active(sm.type, 3)
        elseif step == 4 then -- 停留
            self:play_active(sm.type, 4)
            self.owner.body:setvelocity(tsvector.zero)
            self:sendmessage(eventdef.suffer_move_end)
        elseif step == 5 then -- 结束
        end
    end
end

function logic:onexit()
    self.owner.body:setvelocity(tsvector.zero)
    if self.suffer_move and self.suffer_move.step < 3 then --退出的时候suffermove没有走完
        if self.suffer_move.height > 0 and self.suffer_move.d3 > 0 then
            self.owner.body:accverticle(-self.suffer_move.height, self.suffer_move.d3)
        end
    end
    self.suffer_move = nil
    self.suffer_buff = false
    self._trigger_sufffer_table = nil
    self:sendmessage(eventdef.suffer_end)
    -- print("exitsuffer", self.owner, debug.traceback())
end
------------------------------状态机------------------------------
return logic