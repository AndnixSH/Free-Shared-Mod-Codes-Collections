local conf = { skill = {}, buff = {} }
local MainLineConf = require "Config.data_mainline_script"
-- local CampaignProxy = require "Modules.Campaign.CampaignProxy"
-- local GuildProxy = require "Modules.Guild.GuildProxy"
-- local ChaosBoss = ConfigManager.GetConfig("data_chaos_boss")
-- local ChaosRoom = ConfigManager.GetConfig("data_chaos_room")
-- local DataSleep = ConfigManager.GetConfig("data_sleep_buff")

--死亡效果
----------
-- 死亡传递

    local buff_dead_transfer = function(transferid, o)
        o.event = o.event or {}

        local deadevt =     { eventdef.sprite_dead, onfire = function(self)
            local friends = self.service.area:getplayers(self.owner.prop.camp)
            if friends and #friends > 0 then
                local select = friends[tsmath.random(#friends)]
                select.caller.buff:add(transferid)
            end
        end }

        table.insert(o.event, deadevt)

        return o
    end

-- 小怪受击死亡
    conf.skill[900011] = {
        action = {
            default = {
                { trigger.time, { 0 }, action.addstartbuff,},
            },
        },
    }

-- 精英受击死亡
    conf.skill[900021] = {
        action = {
            default = {
                { trigger.time, { 0 }, action.addstartbuff,},
            },
        },
    }
-- 宝箱怪物
    conf.skill[900031] = {
        action = {
            default = {
                { trigger.time, { 0 }, action.addstartbuff,},
                { trigger.time, { 99999999 },},
            },
        },
    }


-- 获取符文胜利次数
    local function get_totalwin_rune(gameobj, buffid)
        local born = gameobj.caller.born
        local runeid = born:get_runeid(buffid)
        if runeid then
            return born:get_runeflag_count(1, runeid)
        end
        return 0
    end

-- 混沌裂隙 BOSS狂暴 buff
    conf.skill[750191] = {
        event = {
            {scriptevent.onstart, onfire = function(self)
                local gameobj = self.service.area:getgameobj()
                local roomid = gameobj.caller.born:get_activity_info("roomid")
                -- print("roomid:", roomid)

                self.prop.hpline = 0
                self.prop.hpchanged = 0
                if roomid and roomid > 0 then
                    local ChaosBoss = self.service.config:get("data_chaos_boss")
                    local ChaosRoom = self.service.config:get("data_chaos_room")
                    for _, content in pairs(ChaosBoss) do
                        if content.display == self.owner.typeid then
                            self.prop.hpline = ChaosRoom[roomid].dmg_factor * content.hp
                            self.prop.buffid = ChaosRoom[roomid].buff
                        end
                    end
                end
            end},
            { "hp", slot = eventslot.attr, onfire = function (self, newvalue, oldvalue)
                if newvalue - oldvalue < 0 and self.prop.hpline > 0 then
                    self.prop.hpchanged = self.prop.hpchanged + tsmath.abs(newvalue - oldvalue)
                    local count = self.prop.hpchanged // self.prop.hpline
                    if count > 0 and self.prop.buffid then
                        self.caller.buff:addlevel(self.prop.buffid, count, self.owner)
                    end
                    self.prop.hpchanged = self.prop.hpchanged - (count * self.prop.hpline)
                end
            end}
        }
    }
    conf.skill[750291] = conf.skill[750191]
    conf.skill[750391] = conf.skill[750191]
    conf.skill[750491] = conf.skill[750191]
    conf.skill[750591] = conf.skill[750191]
    conf.skill[750691] = conf.skill[750191]


--
-- 符文效果
--===================================================================--
-- 巨龙之怒--

    conf.buff[8010030] = script.composite {
        main = {
            event = {--当前血量低于最大值的15%时
                { eventdef.hp_change, onfire = function(self, value)
                -- { "hp", slot = eventslot.attr, onfire = function(self, newvalue, oldvalue)
                    if (not self.owner.buff.immune_dead) and value < 0 and self.owner.attr.hp < tsmath.rate(self.owner.attr.hp_max, 150) then
                        -- self.caller.buff:add(801004)
                        -- self.owner.attr.hp = 0
                        self.caller.hp:suicide(0)
                    end
                end },
                { eventdef.sprite_dead, onfire = function (self)
                    self.action:addchild({typeid = 999999}, "bullet_single") -- 特效
                end },
                { eventdef.fake_dead_start, onfire = function (self)
                    self.action:addchild({typeid = 999999}, "bullet_single") -- 特效
                end }
            }
        },
        bullet_single = {
            action = {
                default = {
                    {trigger.time, {0},     action.active, "801003"},
                    {trigger.time, {4000},  caller.body.destroy}
                }
            }
        }
    }

--===================================================================--
-- 雷神之力--

    conf.buff[8010130] = buff_dead_transfer(801013, {
        -- action = {
        --     default = {
        --         {trigger.time, {0},},
        --         {trigger.time, {15000}, caller.buff.add, 801014, },
        --     },
        -- },
        event = {
            { scriptevent.ontimer, time = { 15000, 15000 }, onfire = function(self)
                local friends = self.service.area:getplayers(self.owner.prop.camp)
                if friends and #friends > 0 then
                    local select = friends[tsmath.random(#friends)]
                    select.caller.buff:add(801014)
                end

            end },
        }
    })
--===================================================================--
-- 怒波狂浪--

    conf.buff[8010230] = script.composite {
        main = {
            event = {
                { scriptevent.onstart, onfire = function(self)
                    local isexist = false
                    for _, target in ipairs(self.action:range(SKILL.RANGEID.FRIENDS)) do
                        isexist = isexist or target.caller.buff:contains_state("rune_1023")
                    end
                    if not isexist then
                        self.caller.buff:add_state("rune_1023")
                        local centerx, centery = self.service.area:getbattlecenter() -- 获取中心点
                        local position = tsvector.new(centerx, centery)
                        local header = (self.owner.prop.camp == 2) and tsvector.new(0, 1000) or tsvector.new(0, -1000)
                        self.action:addchild({typeid = 999999, position = position, header = header}, "bullet_single") -- 特效
                    end
                end },
            }
        },
        bullet_single = {
            action = {
                default = {
                    {trigger.time, {0},     action.active, "801023"},
                    {trigger.time, {4000},  caller.body.destroy}
                }
            }
        }
    }


--===================================================================--
-- 免死圣盾--

    conf.buff[8011130] = {
        event = {
            { eventdef.hp_change, modifer = eventmdf.public ,onfire = function(self, fromobj, value, oldhp)
                if value<0 and fromobj.prop.camp == self.owner.prop.camp and fromobj.attr.hp <= 0 then -- 友方英雄受到致命伤害
                    fromobj.attr.hp = oldhp
                    fromobj.caller.buff:add(801114)
                    self.caller.buff:remove(801113)
                end
            end },
        },
    }

--===================================================================--
-- 恢复水晶--

    conf.buff[8011230] = buff_dead_transfer(801123, {
        event = {
            { eventdef.hp_change, modifer = "public", onfire = function(self, fromobj, value)
                if fromobj.prop.camp == self.owner.prop.camp and fromobj.attr.hp < tsmath.rate(fromobj.attr.hp_max, 400) then --友军 and 血量低于最大值的40%
                    fromobj.caller.buff:add(801124)
                    self.caller.buff:remove(801123) --一场战斗一次，移除buff
                end
            end }
        },
    })

--===================================================================--
-- 庇护神像--

    conf.buff[8011320] = buff_dead_transfer(801132, {
        event = {
            { scriptevent.ontimer, time = { 0, 10000 }, onfire = function(self)
                local target = self.owner
                local targets = self.action:range(SKILL.RANGEID.FRIEND_LOW_HP)
                if #targets > 0 then
                    target = targets[1]
                end
                local amount = target.attr.hp_max - target.attr.hp --已经损失的生命
                local heal_amount = tsmath.rate(amount, 400)
                target.caller.hp:change(heal_amount)
            end }
        },
    })

--===================================================================--
-- 复苏之徽--
    local revive_ring = function(self, hp_rate)
        local target = self.owner
        local targets = self.action:range(900112)
        if #targets > 0 then
            target = targets[1]
        end
        target.caller.hp:change(tsmath.rate(target.attr.hp_max, hp_rate)) --恢复hp_rate%生命最大值的生命
        return
    end

    conf.buff[8011530] = buff_dead_transfer(801153, {
        event = {
            { scriptevent.ontimer, time = { 15000, 1, 0 }, onfire = function(self)
                revive_ring(self, 500)
            end }
        },
    })

    conf.buff[8011520] = buff_dead_transfer(801152, {
        event = {
            { scriptevent.ontimer, time = { 15000, 1, 0 }, onfire = function(self)
                revive_ring(self, 300)
            end }
        },
    })

    conf.buff[8011510] = buff_dead_transfer(801151, {
        event = {
            { scriptevent.ontimer, time = { 15000, 1, 0 }, onfire = function(self)
                revive_ring(self, 200)
            end }
        },
    })
--===================================================================--
-- 浴血面具--
    local rune_1161 =  function (rate)
        return {
            event = {
                { eventdef.sprite_dead, modifer = eventmdf.public, onfire = function(self, deadobj)
                    if deadobj.prop.camp ~= self.owner.prop.camp then
                        local amount = tsmath.rate(self.owner.attr.hp_max, rate)
                        self.caller.hp:change(amount)
                    end
                end },
                { eventdef.fake_dead_start, modifer = eventmdf.public, onfire = function(self, deadobj)
                    if deadobj.prop.camp ~= self.owner.prop.camp then
                        local amount = tsmath.rate(self.owner.attr.hp_max, rate)
                        self.caller.hp:change(amount)
                    end
                end }
            },
        }
    end
    conf.buff[8011620] = rune_1161(240)
    conf.buff[8011610] = rune_1161(160)

--===================================================================--
-- 储能水晶--
    local function power_crystal(buffid)
        return {
            event = {
                { eventdef.gamesettle, slot = eventslot.game, modifer = eventmdf.public, onfire = function (self, fromobj, wincamp)
                    local rate = buffid == 801193 and 300 or 150
                    local value = tsmath.rate(self.owner.attr.mp_max, rate)
                    self.caller.mp:change(value)
                end },
            }
        }
    end
    conf.buff[8011930] = power_crystal(801193)
    conf.buff[8011920] = power_crystal(801192)
--===================================================================--
-- 狂暴之刃--
    conf.buff[8010330] = {
        event = {
            { scriptevent.onstart, onfire = function(self)
                -- local gameobj = self.service.area:getgameobj()
                -- local kill_num = gameobj.caller.born:getrecord(HEXMAP_RECORD.TOTAL_KILL)
                -- local add_num = tsmath.min(kill_num, 20)
                -- self.caller.buff:addlevel(801034, add_num)
            end },
            {eventdef.skill_damage, onfire = function(self, damage_table)
                if damage_table.toobj.attr.hp <= 0 then
                    self.caller.buff:add(801034)
                end
            end},
        }
    }
--===================================================================--
-- 龙血圣杯--

    conf.buff[8017420] = {
        event = {
            { scriptevent.onstart, onfire = function(self)
                local gameobj = self.service.area:getgameobj()
                local use_num = gameobj.caller.born:getrecord(HEXMAP_RECORD.DRAGON_BLOOD_USE)
                local add_num = tsmath.min(use_num, 4)
                self.caller.buff:addlevel(801743, add_num)
            end }
        }
    }

--===================================================================--
-- 能量水晶--

    conf.buff[8012030] = {
        event = {
            { eventdef.slot_use, onfire = function(self, id)
                if id == SKILL.SLOT.ULTIMATE then
                    -- if not self.caller.buff:contains_state("ultimate_used") then
                        self.caller.buff:add(801204)
                        for _, friend in ipairs(self.action:range(SKILL.RANGEID.FRIENDS)) do
                            friend.caller.buff:remove(801203)
                        end
                        -- self.caller.buff:add_state("ultimate_used")
                    -- end
                end
            end }
        },
    }

    conf.buff[8012020] = {
        event = {
            { eventdef.slot_use, onfire = function(self, id)
                if id == SKILL.SLOT.ULTIMATE then
                    -- if not self.caller.buff:contains_state("ultimate_used") then
                        self.caller.buff:add(801201)
                        for _, friend in ipairs(self.action:range(SKILL.RANGEID.FRIENDS)) do
                            friend.caller.buff:remove(801202)
                        end
                        -- self.caller.buff:add_state("ultimate_used")
                    -- end
                end
            end }
        },
    }

--===================================================================--
-- 火炎佩剑--

    conf.buff[8012220] = {
        event = {
            { eventdef.skill_damage, onfire = function(self, damage_table)
                local rate = 50
                if damage_table.toobj == self.owner then return end
                if damage_table.toobj.attr and (not damage_table.toobj.caller.buff:any({801224,801223})) and tsmath.random_match(rate) then
                    if self.caller.buff:contains(801232) then
                        damage_table.toobj.caller.buff:add(801224, self.owner)
                    else
                        damage_table.toobj.caller.buff:add(801223, self.owner)
                    end
                end
        end }
        },
    }

--===================================================================--
-- 冰晶佩剑--

    conf.buff[8012320] = {
        event = {
            { eventdef.skill_damage, onfire = function(self, damage_table)
                local rate = 50
                if damage_table.toobj == self.owner then return end
                if damage_table.toobj.attr and (not damage_table.toobj.caller.buff:any({801234,801233})) and tsmath.random_match(rate) then
                    if self.caller.buff:contains(801222) then
                        damage_table.toobj.caller.buff:add(801234, self.owner)
                    else
                        damage_table.toobj.caller.buff:add(801233, self.owner)
                    end
                end
            end }
        },
    }

--===================================================================--
-- 驱魔箭矢--    


    conf.buff[8012420] = {
        event = {
            { scriptevent.onstart, onfire = function(self, damage_table)
                if self.owner.prop.stance ~= 4 then
                    self.caller.buff:remove(801242)
                end
            end }
        },
    }

--===================================================================--
-- 稻草娃娃--
    conf.buff[8012520] = buff_dead_transfer(801252, {
        event = {
            { scriptevent.onend, onfire = function(self)--结束的时候还没死就直接remove这个buff
                if self.owner.attr.hp > 0 then
                    self.caller.buff:remove(801252)
                end
            end }
        }
    })
--===================================================================--
-- 冲锋战鼓
    conf.buff[8010430] = {
        event = {
            {scriptevent.ontimer, time = {1000,1000,30} ,onfire = function (self)
                self.caller.buff:add(801044)
            end}
        }
    }
--===================================================================--
-- 团队配合--
    local rune_1472 = function(buffid)
        return {--buff挂在全体友方身上，一个敌人死亡则全体友军加mp
            event = {
                { eventdef.sprite_dead, modifer = eventmdf.public ,onfire = function(self, fromobj)
                    if fromobj.prop.camp ~= self.owner.prop.camp then
                        self.caller.buff:add(buffid)
                    end
                end },
                { eventdef.fake_dead_start, modifer = eventmdf.public ,onfire = function(self, fromobj)
                    if fromobj.prop.camp ~= self.owner.prop.camp then
                        self.caller.buff:add(buffid)
                    end
                end },
            }
        }
    end
    conf.buff[8014720] = rune_1472(801474)
    conf.buff[8014710] = rune_1472(801473)
--===================================================================--
-- 傀儡之术--
    local rune_1631 = function(buffid)
        return {
            event = {
                { eventdef.summon_add, modifer = eventmdf.public,onfire = function(self, fromobj)
                    if fromobj.prop.camp == self.owner.prop.camp then
                        self.caller.buff:add(buffid)
                    end
                end },

                { eventdef.summon_remove, modifer = eventmdf.public,onfire = function(self, fromobj)
                    if fromobj.prop.camp == self.owner.prop.camp then
                        local oldlv = self.caller.buff:getlevel(buffid)
                        self.caller.buff:remove(buffid)
                        self.caller.buff:addlevel(buffid, oldlv - 1)
                    end
                end },
            }
        }
    end

    conf.buff[8016330] = rune_1631(801636)
    conf.buff[8016320] = rune_1631(801635)
    conf.buff[8016310] = rune_1631(801634)
--===================================================================--
-- 巫术坩埚--
    -- local function Witchcraft_Crucible(buffid)
    --     return{
    --         event = {
    --             {scriptevent.onstart, onfire = function(self)
    --                 local enemy_camp = self.caller.skill:range(SKILL.RANGEID.ENEMYS)
    --                 for _,enemy in ipairs(enemy_camp) do
    --                     enemy.caller.buff:add(buffid)
    --                 end
    --             end}
    --         }
    --     }
    -- end
    -- conf.buff[8016530] = Witchcraft_Crucible(801656)
    -- conf.buff[8016520] = Witchcraft_Crucible(801655)
    -- conf.buff[8016510] = Witchcraft_Crucible(801654)
--===================================================================--
-- 坚毅之盔--        
--===================================================================--
-- 复仇神像--

    conf.buff[8014320] = {
        event = {
            { eventdef.sprite_dead, onfire = function(self)
                local friends = self.service.area:getplayers(self.owner.prop.camp)
                for _, friend in ipairs(friends) do
                    friend.caller.buff:add(801433)
                end
            end },
            { eventdef.fake_dead_start, onfire = function(self)
                local friends = self.service.area:getplayers(self.owner.prop.camp)
                for _, friend in ipairs(friends) do
                    friend.caller.buff:add(801433)
                end
            end },

        }
    }

--===================================================================--
-- 战争号角--

    conf.buff[8014620] = {
        event = {
            { eventdef.sprite_dead, modifer = eventmdf.excludeself, onfire = function(self, fromobj)
                if fromobj.prop.camp ~= self.owner.prop.camp then
                    self.caller.buff:add(801463)
                end
            end },
            { eventdef.fake_dead_start, modifer = eventmdf.excludeself, onfire = function(self, fromobj)
                if fromobj.prop.camp ~= self.owner.prop.camp then
                    self.caller.buff:add(801463)
                end
            end },
        }
    }

--===================================================================--
-- 晶石碎块--

    conf.buff[8015110] = {
        event = {
            { eventdef.buff_start, onfire = function(self, buffid)
                if not self.caller.buff:contains(801514) and 801511 == buffid then
                    local level = self.caller.buff:getlevel(801511)
                    if level >= 4 then
                        self.caller.buff:add(801514)
                    elseif level >= 3 then
                        self.caller.buff:add(801513)
                    elseif level >= 2 then
                        self.caller.buff:add(801512)
                    end
                end
            end },
        },
    }

--===================================================================--
-- 能量晶盘--

    conf.buff[8015220] = {
        event = {
            { scriptevent.onstart, onfire = function(self)
                for i = 1, 3 do
                    if self.caller.buff:contains(801511 + i) then
                        self.caller.buff:remove(801511 + i)
                        self.caller.buff:add(801511 + i)
                    end
                end
            end },
        }
    }

--===================================================================--
-- 绝境之甲--

    conf.buff[8010530] = {
        event = {
            { "hp", slot = eventslot.attr, onfire = function(self, newvalue, oldvalue)
                if newvalue < tsmath.rate(self.owner.attr.hp_max, 300) then
                    self.caller.buff:remove(801054)
                    self.caller.buff:add(801054)
                end
            end },

        }
    }
--===================================================================--
-- 绝境之剑-- 

    conf.buff[8010630] = {
        event = {
            { "hp", slot = eventslot.attr, onfire = function(self, newvalue, oldvalue)
                if newvalue < tsmath.rate(self.owner.attr.hp_max, 300) then
                    self.caller.buff:remove(801064)
                    self.caller.buff:add(801064)
                end
            end }
        }
    }
--===================================================================--
-- 蔓藤乱舞
    conf.buff[8010730] = {
        event = {
            { scriptevent.onstart, onfire = function(self)
                local rate = 250
                self.prop.hptotal = tsmath.rate(self.owner.attr.hp_max, rate)
                self.prop.hpchanged = 0
            end},
            { eventdef.hp_change, onfire = function(self, value)
                if value < 0 then
                    self.prop.hpchanged = self.prop.hpchanged + value
                end

                if tsmath.abs(self.prop.hpchanged) >= self.prop.hptotal then
                    self.caller.buff:remove(801073)
                end 
            end },

        }
    }
--===================================================================--
-- 勇气之心--

    conf.buff[8014520] = {
        event = {
            { eventdef.hp_change, onfire = function(self)
                self.caller.buff:remove(801452)
                self.caller.buff:add(801452)
            end }
        }
    }
    conf.buff[8014510] = {
        event = {
            { eventdef.hp_change, onfire = function(self)
                self.caller.buff:remove(801451)
                self.caller.buff:add(801451)
            end }
        }
    }
    
--===================================================================--
-- 勇气之心--
    conf.buff[8016930] = {
        event = {
            { scriptevent.onstart, onfire = function(self)
                local readdfunc = function(self, buffid)
                    if self.caller.buff:contains(buffid) then
                        self.caller.buff:remove(buffid)
                        self.caller.buff:add(buffid)
                    end
                end
                readdfunc(self, 801703)
                readdfunc(self, 801713)
                readdfunc(self, 801723)
                readdfunc(self, 801733)

            end }
        }
    }


--===================================================================--
-- 符石之力--
    -- 收集超过15个符文，暴击伤害提升50%。
    -- 收集超过10个符文，攻击力提升25%。
    -- 收集超过5个符文，防御力提升15%。
    local function runes_power(buffid)
        return {
            event = {
                { scriptevent.onstart, onfire = function(self)
                    -- local quality = ({[801484] = 3, [801485] = 5, [801486] = 7})[buffid]
                    local counts = ({[801484] = 5, [801485] = 10, [801486] = 15})[buffid]
                    local gameobj = self.service.area:getgameobj()
                    local runes_counts = gameobj.caller.born:getrunecount(3)
                    runes_counts = gameobj.caller.born:getrunecount(5) + runes_counts
                    runes_counts = gameobj.caller.born:getrunecount(7) + runes_counts
                    if counts <= runes_counts then
                        self.caller.buff:add(buffid)
                    end
                end }
            }
        }
    end

    conf.buff[8014810] = runes_power(801484)
    conf.buff[8014820] = runes_power(801485)
    conf.buff[8014830] = runes_power(801486)
--===================================================================--
-- 迅捷之靴--

    local function swift_boot(buffid)
        return {
            event = {
                -- 周围没有敌人时增加攻击力
                
                { scriptevent.ontimer, time = {0,500}, onfire  = function (self)
                    
                    local opcamp = self.service.area:getoppsitecamp(self.owner.prop.camp)
                    local enemylist = self.service.area:getplayers(opcamp)
                    local rect = self.service.area:getbattleside(self.owner.prop.camp)
                    local has = false

                    for _, enemy in ipairs(enemylist) do
                        local pos = enemy.body.position
                        if rect:contains(pos) then
                            -- print("has")
                            has = true
                            break
                        end
                    end

                    if not has then
                        -- print("hasn't")
                        self.caller.buff:add(buffid)
                    elseif has and self.caller.buff:contains(buffid) then
                        self.caller.buff:remove(buffid)
                    end
                end }
            }
        }
    end

    conf.buff[8014130] = swift_boot(801415)
    conf.buff[8014120] = swift_boot(801414)
--===================================================================--
-- 屠龙之力
    local function dargon_kill(buffid)
        return{
            event = {
                {scriptevent.onstart, onfire = function(self)
                    local gameobj = self.service.area:getgameobj()
                    local level = gameobj.caller.born:get_activity_info(HEXMAP_INFO.MAZE_LEVEL)
                    if level then
                        if level >= 5 and level <= 6 then
                            self.owner.caller.buff:add(buffid)
                        end
                    end
                end}
            }
        }
    end

    conf.buff[8016610] = dargon_kill(801664)
    conf.buff[8016620] = dargon_kill(801665)
    conf.buff[8016630] = dargon_kill(801666)
 
--===================================================================--
-- 百炼利剑/百炼重凯
    local function winner_sword(buffid)
        return{
            event = {
                {scriptevent.onstart, onfire = function(self)
                    local gameobj = self.service.area:getgameobj()
                    local win_battle = get_totalwin_rune(gameobj,buffid-3)
                    -- print(win_battle)
                    if win_battle ~= 0 then
                        for i = 1, win_battle do
                            self.caller.buff:add(buffid)
                        end
                    end
                end}
            }
        }
    end
    conf.buff[8014930] = winner_sword(801496)
    conf.buff[8014920] = winner_sword(801495)
    conf.buff[8014910] = winner_sword(801494)

    conf.buff[8015030] = winner_sword(801506)
    conf.buff[8015020] = winner_sword(801505)
    conf.buff[8015010] = winner_sword(801504)
--===================================================================--
-- 兵临城下
    local rune_1403 = function(buffid)
        return {
            event = {
                { scriptevent.ontimer, time = {1000}, onfire = function(self)
                    self.caller.buff:remove(buffid)
                    self.caller.buff:add(buffid)
                end }
            }
        }
    end
    conf.buff[8014030] = rune_1403(801403)
    conf.buff[8014020] = rune_1403(801402)
    conf.buff[8014010] = rune_1403(801401)


--===================================================================--


------------------------------------------------------------ 随机事件
-- ===================================================================--
-- 随机事件4
    conf.buff[8030430] = {
        event = {
            {scriptevent.ontimer, time = {5000,5000,20}, onfire = function (self)
                if not self.caller.buff:maxlevel(803043) then
                    self.caller.buff:add(803043)
                end
            end}
        }
    }
-- =============================================================--

-- ==================================================================
-- 巨龙洞窟 怪物血量修正
    local function _hp_rate_up(rate)
        return {
            event = {
                {scriptevent.onstart, onfire = function (self, newvalue, oldvalue)
                    self.owner.attr.hp = self.owner.attr.hp + tsmath.rate(self.owner.attr.hp, rate)
                end}
            }
        }
    end
    conf.buff[9998110] = _hp_rate_up(0)
    conf.buff[9998120] = _hp_rate_up(100)
    conf.buff[9998130] = _hp_rate_up(200)
    conf.buff[9998140] = _hp_rate_up(300)
    conf.buff[9998150] = _hp_rate_up(400)
    conf.buff[9998160] = _hp_rate_up(500)
    conf.buff[9998170] = _hp_rate_up(1200)
    conf.buff[9998180] = _hp_rate_up(400)
    conf.buff[9998190] = _hp_rate_up(1200)


-- ==================================================================

------------------------------------------------------------ 神器效果
--===================================================================--
-- 复苏之佑--
    --使用必杀技时附加护盾

    local function Recovery_bless(buffid)
        return {
            event = {
                { eventdef.slot_use, onfire = function(self, slotid)
                    if slotid == SKILL.SLOT.ULTIMATE then
                        self.caller.buff:add(buffid) -- 护盾buff
                        if buffid == 982016 then self.caller.buff:add(982017) end
                    end
                end }
            }
        }
    end
    conf.buff[9820110] = Recovery_bless(982014)
    conf.buff[9820120] = Recovery_bless(982015)
    conf.buff[9820130] = Recovery_bless(982016)


--===================================================================--
-- 神王之眼--
    --暴击时增加攻速和暴击伤害

    local function godking_eye(buffid)
        return {
            event = {
                { eventdef.skill_damage, onfire = function(self, damage_table)
                    if damage_table.crit then
                        self.caller.buff:add(buffid)
                        if buffid == 982026 then self.caller.buff:add(982027) end
                    end
                end }
            }
        }
    end
    conf.buff[9820210] = godking_eye(982024)
    conf.buff[9820220] = godking_eye(982025)
    conf.buff[9820230] = godking_eye(982026)

--===================================================================--
-- 希望号角--
    --死亡后把mp平分给队友，收下吧这是我最后的波纹了jojo！

    conf.buff[9820330] = {
        event = {
            { eventdef.sprite_dead, onfire = function(self)
                local friends = self.service.area:getplayers(self.owner.prop.camp)
                local lastmp = tsmath.floor(self.owner.attr.mp / #friends)
                for _, friend in ipairs(friends) do
                    friend.caller.mp:change(lastmp)
                end
            end },
        }
    }

--===================================================================--
-- 圣灵披风--

    conf.buff[9820430] = {
        event = {
            { eventdef.hp_change, onfire = function(self)
                self.caller.buff:remove(982043)
                self.caller.buff:add(982043)
            end },
        }
    }

--===================================================================--
-- 神圣之刃-- -- 不需要脚本
--===================================================================--
-- 永恒圣杯-- -- 不需要脚本
--===================================================================--
-- 威仪之戒--

    local function might_ring(buffid)
        return {
            event = {
                -- 周围没有敌人时增加攻击力
                { scriptevent.ontimer, time = { 0, 500, 99999 }, onfire = function(self)
                    local enemys = self.caller.skill:range(982071)
                    if #enemys == 0 then
                        self.caller.buff:add(buffid)
                    end
                    if enemys and #enemys > 0 then
                        self.caller.buff:remove(buffid)
                    end
                end },
                -- 3级以后每15秒释放一次震荡波击退敌人
                { scriptevent.ontimer, time = { 15000, 15000, 999 }, onfire = function(self)
                    if buffid == 982076 then
                        self.caller.skill:cast(982073)
                    end
                end }
            }
        }
    end

    conf.buff[9820710] = might_ring(982074)
    conf.buff[9820720] = might_ring(982075)
    conf.buff[9820730] = might_ring(982076)
--===================================================================--


--===================================================================--
-- 生命之树
    local lifetree ={
        "assist",
        "mage",
        "fighter",
        "tank",
        "ranger",
    }
    local lifetree_skill ={
        "skill_one",
        "skill_two",
        "skill_three",
    }
    local lifetree_func = {}
    local lifetree_bufflist = {}
    
    lifetree_bufflist.assist = {
        skill_one = {
            811101,811102,811103,8111014,811105,811106,811107,811108,811109,
        },
        skill_two = {
            811201,811202,811203,811204,811205,811206,811207,811208,811209,
        },
        skill_three = {
            811301,811302,811303,811304,811305,811306,811307,811308,811309,
        }
    }   -- 辅助buffid

    lifetree_bufflist.mage = {
        skill_one = {
            812101,812102,812103,812104,812105,812106,812107,812108,812109,
        },
        skill_two = {
            812201,812202,812203,812204,812205,812206,812207,812208,812209,
        },
        skill_three = {
            812301,812302,812303,812304,812305,812306,812307,812308,812309,
        }
    }   -- 法师buffid

    lifetree_bufflist.fighter = {
        skill_one = {
            813101,813102,813103,813104,813105,813106,813107,813108,813109,
        },
        skill_two = {
            813201,813202,813203,813204,813205,813206,813207,813208,813209,
        },
        skill_three = {
            813301,813302,813303,813304,813305,813306,813307,813308,813309,
        }
    }   -- 战士buffid

    lifetree_bufflist.tank = {
        skill_one = {
            814101,814102,814103,814104,814105,814106,814107,814108,814109,
        },
        skill_two = {
            814201,814202,814203,814204,814205,814206,814207,814208,814209,
        },
        skill_three = {
            814301,814302,814303,814304,814305,814306,814307,814308,814309,
        }
    }   -- 坦克buffid

    lifetree_bufflist.ranger = {
        skill_one = {
            815101,815102,815103,815104,815105,815106,815107,815108,815109,
        },
        skill_two = {
            815201,815202,815203,815204,815205,815206,815207,815208,815209,
        },
        skill_three = {
            815301,815302,815303,815304,815305,815306,815307,815308,815309,
        }
    }   -- 坦克buffid

-- 辅助 -------------------------------------------------------------
    lifetree_func.assist = {
    -- 连携之阵----------------------------------------------------------
        -- 受此祝福的英雄首次使用必杀技时，最虚弱的一名友军获得一个持续7秒的可以抵达自己260%攻击力的护盾
        skill_one = function (buffid)
            return {
                event = {
                    {eventdef.slot_use, onfire = function (self, slotid)
                        if slotid == 2 then
                            local targets = self.action:range(SKILL.RANGEID.FRIEND_LOW_HP)
                            local target = #targets > 0 and targets[1] or nil
                            if target and target.caller then
                                target.caller.buff:add(buffid, self.owner)
                                self.caller.buff:remove(buffid - 10)
                            end
                        end
                    end}
                }
            }
            end,
    -- 生命波动----------------------------------------------------------
        -- 受此祝福的英雄治疗一名其他角色时触发，会额外治疗最虚弱的另一名友军，使其恢复100%攻击力的生命值。每个受此祝福的英雄最多每10秒触发一次该效果
        skill_two = function (buffid)
            return {
                event = {
                    {scriptevent.onstart, onfire = function (self)
                        self.prop.healcd = 10000
                        self.prop.time = self.time.time - self.prop.healcd
                        self.prop.healfunc = function ()
                            local targets = self.action:range(SKILL.RANGEID.FRIEND_LOW_HP)
                            local target = #targets > 0 and targets[1] or nil
                            if target and target.caller then
                                target.caller.buff:add(buffid, self.owner)
                            end
                        end
                    end
                    },
                    {eventdef.skill_heal, onfire = function (self, heal_table)
                        if self.time.time - self.prop.time >= self.prop.healcd then
                            self.prop.healfunc() -- 进入cd
                            self.prop.time = self.time.time
                        end
                        
                    end},
                    {eventdef.buff_heal, onfire = function (self, heal_table)
                        if self.time.time - self.prop.time >= self.prop.healcd then
                            self.prop.healfunc() -- 进入cd
                            self.prop.time = self.time.time
                        end
                    end}
                }
            }
            end,
    -- 祈愿仪式----------------------------------------------------------
        -- 战斗开始第15秒，受此祝福的英雄回复60点能量，并在后续1.5秒内免疫控制效果
        skill_three = function (buffid)
            return {
                event = {
                    {scriptevent.ontimer, time = {15000,100,1}, onfire = function (self)
                        local buffid_extra = 
                        self.caller.buff:addlist({buffid, 900002}, self.owner)
                        self.caller.buff:remove(buffid - 10)
                    end}
                }
            }
        end
    }
-- 法师 -------------------------------------------------------------
    lifetree_func.mage = {
    -- 魔力增幅----------------------------------------------------------
        -- 受此祝福的英雄每次使用必杀技后，3秒内提升12%攻击力
        skill_one = function (buffid)
            return {
                event = {
                    {eventdef.skill_end, onfire = function (self, skillid)
                        if self.caller.skill:toslotid(skillid) == 2 then
                            self.caller.buff:add(buffid, self.owner)
                        end
                    end}
                }
            }
        end,
    -- 法力潮汐----------------------------------------------------------
        -- 受此祝福的英雄首次使用必杀技时，使每个其他友军回复30点能量，同一个角色10秒内受到多次该效果时，后续效果下降60%
        skill_two = function (buffid)
            return{
                event = {
                    {eventdef.slot_use, onfire = function (self, slotid)
                        if slotid == 2  then
                            local targets = self.action:range(SKILL.RANGEID.FRIENDS_NOTSELF)
                            for _, target in ipairs(targets) do
                                target.caller.buff:add(buffid, self.owner)
                            end
                            self.caller.buff:remove(buffid - 10)
                        end
                    end},
                    {eventdef.buff_stop, modifer = eventmdf.excludeself, onfire =function (self, fromobj, buffid)
                        if buffid == buffid and (not fromobj.caller.buff:contains(812291)) then
                            fromobj.caller.buff:add(812291)
                        end
                    end}
                } 
            }
        end,
    -- 灵能涌动----------------------------------------------------------
        -- 受此祝福的英雄生命值首次低于30%时，立即回复40点能量，并在后续1.5秒内免疫控制效果
        skill_three = function (buffid)
            return{
                event = {
                    {"hp", slot = eventslot.attr, onfire = function (self, newvalue, oldvalue)
                        if newvalue <= tsmath.rate(self.owner.attr.hp_max, 300) then
                            self.caller.buff:addlist({buffid, 900002}, self.owner)
                            self.caller.buff:remove(buffid - 10)
                        end
                    end},
                } 
            }
        end,
    }
-- 战士 -------------------------------------------------------------
    lifetree_func.fighter = {
    -- 横冲直撞----------------------------------------------------------
        -- 受此祝福的英雄对敌人造成伤害时，使敌人在后续3秒内受到的生命回复效果下降24%，受到的伤害增加15%。该效果不可叠加。
        skill_one = function (buffid)
            return {
                event = {
                    {eventdef.skill_damage, onfire = function (self, damage_table)
                        damage_table.toobj.caller.buff:add(buffid, self.owner)
                    end}
                }
            }
        end,
    -- 防御屏障----------------------------------------------------------
        -- 敌方使用必杀技时，受此祝福的英雄获得一个持续5秒可以抵挡15%最大生命值伤害的护盾。每个受此祝福的英雄每16秒至多触发一次该效果。
        skill_two = function (buffid)
            return{
                event = {
                    {scriptevent.onstart, onfire = function (self)
                        -- self.prop.cdcost = 16 * 1000
                        -- self.prop.time = self.time.time - self.prop.cdcost
                    end},
                    {eventdef.slot_use, modifer = eventmdf.excludeself, onfire = function (self, fromobj, slotid)
                        -- if self.prop.cdcost < self.time.time - self.prop.time --时间内最多触发一次
                        if not self.caller.buff:contains(buffid+10)
                        and slotid == 2 and fromobj.prop.camp ~= self.owner.prop.camp then
                            -- self.prop.time = self.time.time
                            self.caller.buff:addlist({buffid, buffid + 10}, self.owner)
                        end
                    end}
                }
            }
        end,
    -- 浴血奋战----------------------------------------------------------
        -- 受此祝福的英雄首次使用必杀技后的5秒内提升14点吸血等级
        skill_three = function (buffid)
            return{
                event = {
                    {eventdef.slot_use, onfire = function (self, slotid)
                        if slotid == 2 then
                            self.caller.buff:add(buffid, self.owner)
                            self.caller.buff:remove(buffid + 10)
                        end
                    end}
                } 
            }
        end,
    }

-- 坦克 -------------------------------------------------------------
    lifetree_func.tank = {
    -- 绝境逢生----------------------------------------------------------
        -- 受此祝福的英雄生命值首次低于30%时，后续10秒内，每秒回复3%的最大生命值。
        skill_one = function (buffid)
            return {
                event = {
                    {"hp", slot = eventslot.attr, onfire = function (self, newvalue, oldvalue)
                        if newvalue <= tsmath.rate(self.owner.attr.hp_max, 300) then
                            self.caller.buff:add(buffid, self.owner)
                            self.caller.buff:remove(buffid - 10)
                        end
                    end},
                }
            }
        end,
    -- 斗气冲击----------------------------------------------------------
        -- 受此祝福的英雄每累计失去30%的最大生命值，在自己周围产生冲击波，对附近的敌人造成3%最大生命值的伤害，并使敌人3秒内受到30点减速
        skill_two = function (buffid)
            return{
                event = {
                    {scriptevent.onstart, onfire = function (self)
                        self.prop.hplost = 0 
                        self.prop.hprate = 300
                        self.prop.dmghprate = ({30, 30, 30, 35, 40, 45, 50, 55, 60})[buffid % 10]
                    end},

                    {"hp", slot = eventslot.attr, onfire = function (self, newvalue, oldvalue)
                        if oldvalue - newvalue > 0 then
                            self.prop.hplost = self.prop.hplost + oldvalue - newvalue
                            local hprate_value = tsmath.rate(self.owner.attr.hp_max, self.prop.hprate)
                            local count = self.prop.hplost // hprate_value
                            if count > 0 then
                                self.prop.hplost = self.prop.hplost - (hprate_value * count)
                                for i = 1, count do
                                    for _,target in ipairs(self.action:range(SKILL.RANGEID.ENEMYS_CLOSE_MID)) do
                                        local value = tsmath.rate(target.attr.hp_max, self.prop.dmghprate)
                                        value = tsmath.min(value, tsmath.rate(self.owner.attr.atk, 10000))
                                        target.caller.hp:change(-1 * value, self.owner)
                                        target.caller.buff:add(buffid)
                                    end
                                    -- self.action:cast(buffid - 10)
                                end
                            end
                        end
                    end},
                }
            }
        end,
    -- 回光返照----------------------------------------------------------
        -- 受此祝福的英雄受到来自其他友军的治疗效果时，自己额外受到一次9%最大生命值的治疗效果。每个受到此祝福的英雄每11秒至多触发一次该效果。
        skill_three = function (buffid)
            return{
                event = {
                    {scriptevent.onstart, onfire =function (self)
                        self.prop.cdcost = 11 * 1000
                        self.prop.time = self.time.time - self.prop.cdcost
                    end},
                    {eventdef.skill_heal, modifer = eventmdf.excludeself, onfire = function (self, fromobj, healtable)
                        if healtable.toobj == self.owner and (not self.caller.buff:contains(buffid+10)) then
                            self.prop.time = self.time.time
                            self.caller.buff:addlist({buffid, buffid + 10}, self.owner)
                        end 
                    end},
                    {eventdef.buff_heal, modifer = eventmdf.excludeself, onfire = function (self, fromobj, healtable)
                        if healtable.toobj == self.owner and (not self.caller.buff:contains(buffid+10)) then
                            self.prop.time = self.time.time
                            self.caller.buff:addlist({buffid, buffid + 10}, self.owner)
                        end 
                    end},
                } 
            }
        end,
    }

-- 游侠 -------------------------------------------------------------
    lifetree_func.ranger = {
    -- 危机意识----------------------------------------------------------
        -- 受到祝福的英雄生命值首次低于50%时，在后续8秒内。提升100点闪避与10点急速
        skill_one = function (buffid)
            return {
                event = {
                    {"hp", slot = eventslot.attr, onfire = function (self, newvalue, oldvalue)
                        if newvalue <= tsmath.rate(self.owner.attr.hp_max, 500) then
                            self.caller.buff:add(buffid, self.owner)
                            self.caller.buff:remove(buffid - 10)
                        end
                    end},
                }
            }
        end,
    -- 死亡收割----------------------------------------------------------
        -- 受到此祝福的英雄对生命值不足50%的敌人造成伤害时，额外造成一次无视闪避的140%攻击力的伤害，每个受到此祝福的英雄每3秒最多触发一次该效果。
        skill_two = function (buffid)
            return{
                event = {
                    {scriptevent.onstart, onfire =function (self)
                        self.prop.cdcost = 3 * 1000
                        self.prop.time = self.time.time - self.prop.cdcost
                    end},
                    {eventdef.skill_damage, onfire = function (self, damage_table)
                        local toobj = damage_table.toobj
                        if toobj.attr.hp < tsmath.rate(toobj.attr.hp_max, 500)
                        and self.time.time - self.prop.time > self.prop.cdcost then
                            self.prop.time = self.time.time
                            toobj.caller.buff:add(buffid, self.owner)
                        end 
                    end}
                }
            }
        end,
    -- 致命节奏----------------------------------------------------------
        -- 敌人死亡时，如果一名受到此祝福的英雄在5秒内对该敌人造成过伤害，则该英雄会在4秒内提升80点急速，并立即恢复4%最多生命值。
        skill_three = function (buffid)
            return{
                event = {
                    {scriptevent.onstart, onfire =function (self)
                        self.prop.cdcost = 5 * 1000
                        self.prop.dmglist = {}
                        self.prop.marklist = {}
                        self.prop.runfunc = function(fromobj)
                            if self.prop.dmglist[fromobj] and self.prop.dmglist[fromobj] > 0 then
                                self.caller.buff:addlist({buffid, buffid + 1}, self.owner)
                            end
                        end
                    end},
                    {eventdef.skill_damage, onfire = function (self, damage_table)
                        if not self.prop.dmglist[damage_table.toobj] then
                            table.insert(self.prop.marklist, damage_table.toobj)
                        end 
                        self.prop.dmglist[damage_table.toobj] = self.prop.cdcost
                    end},
                    {scriptevent.ontimer, time = {500,500,9999}, onfire = function (self)
                        for _, v in ipairs(self.prop.marklist) do
                            if self.prop.dmglist[v] >= 0 then
                                self.prop.dmglist[v] = self.prop.dmglist[v] - 500
                            end
                        end
                    end},
                    {eventdef.sprite_dead, modifer = eventmdf.excludeself, onfire = function (self, fromobj)
                        self.prop.runfunc(fromobj)
                    end},
                    {eventdef.fake_dead_start, modifer = eventmdf.excludeself, onfire = function (self, fromobj)
                        self.prop.runfunc(fromobj)
                    end},
                } 
            }
        end,
    }
    
for _,k in ipairs(lifetree) do 
    for _, v in ipairs(lifetree_skill) do
        for _, buffid in ipairs(lifetree_bufflist[k][v]) do
            conf.buff[buffid*10] = lifetree_func[k][v](buffid + 10)
        end
    end
end

--===================================================================--
---------------------------------------------------------------------
-- 训练场
    ---
    conf.buff[9999310] = {
        event = {
            { eventdef.hp_change, onfire = function (self, value)
                if value > 0 then return end
                local value = tsmath.rate(self.owner.attr.hp_max, 500)
                local newvalue = self.owner.attr.hp
                if newvalue <= value then
                    local value = self.owner.attr.hp_max
                    self.owner.attr.immune_suffer = 1
                    self.owner.attr.hp = 1
                    self.caller.hp:change(self.owner.attr.hp_max)
                end
            end },
        }
    }

    local PositionList = {
        tsvector.new( 2000, 2000 ),
        tsvector.new( 6000, 2000 ),
        tsvector.new( 10000, 2000 ),

        tsvector.new( 2000, 18000 ),
        tsvector.new( 6000, 18000 ),
        tsvector.new( 10000, 18000 ),
    }
    conf.buff[9999320] = {
        event = {
            {scriptevent.onstart, onfire = function(self)
                self.prop.positionlist = PositionList
                self.prop.mov = self.owner.attr.mov
            end },
            { "hp", slot = eventslot.attr, onfire = function (self, newvalue, oldvalue)
                if self.owner.attr.hp <= tsmath.rate(self.owner.attr.hp_max, 300) then
                    self.owner.attr.immune_suffer = 1
                else
                    self.owner.attr.immune_suffer = 0
                end

                if newvalue <= 0 then
                    self.owner.attr.hp = 1
                    self.owner.attr.mov = 0
                    self.caller.body:stop()
                    self.caller.skill:stopcurrent()
                    self.caller.skill:addslotactive(-1,{1,2,3,4,5})
                    -- self.caller.state:stop(true)
                    
                    self.caller.buff:addlist({900031,900032})
                    self.action:settimer({100},function()
                        local bufflist = self.caller.buff:getallbuff()
                        for _, buffid in ipairs(bufflist) do
                            if (buffid ~= 999932 
                            and buffid ~= 9999320
                            and buffid ~= 900031
                            and buffid ~= 900032) then
                                self.caller.buff:remove(buffid)
                            end
                        end
                        self.caller.view:active("empty")
                        self.caller.view:active("dead")
                    end)
                    self.action:settimer({1400},function()
                        self.caller.body:sendmessage(eventdef.hide_view)
                    end)
                    self.action:settimer({5000},function()
                        local position = self.prop.positionlist[tsmath.random(#self.prop.positionlist)]
                        self.caller.body:setposition(position)
                    end)
                    self.action:settimer({5500},function()
                        self.caller.body:sendmessage(eventdef.show_view)
                        self.caller.view:active("born_battle")
                        self.caller.view:start_view(999932,{{1,0,nil,{"scenes_battle_born",0,}},})
                        self.owner.attr.hp = self.owner.attr.hp_max
                        self.owner.attr.mp = 0
                    end)
                    self.action:settimer({6000},function()
                        self.owner.attr.mov = self.prop.mov
                        self.caller.skill:addslotactive(1,{1,2,3,4,5})
                        self.caller.buff:removelist({900031,900032})
                    end)
                end
            end },
        }
    }
-- 主线 睡眠buff
    conf.buff[9997010] = {
        event = {
            {scriptevent.onstart, onfire = function (self)
                local gameobj = self.service.area:getgameobj()
                local mainlineid = gameobj.caller.born:get_activity_info("mainlineid") or 0
                local time = 0--tsmath.floor(CampaignProxy.Instance:GetLastPassMainLineTime() / 3600)
                local datasleep = self.service.config:get("data_sleep_buff")

                if time == 0 and mainlineid > 1 then
                    for _, target in ipairs(self.action:range(SKILL.RANGEID.FRIENDS)) do
                        if target.caller.buff and target.caller.buff:contains_state("scriptfallback_last_time") then
                            time = target.caller.buff:get_state("scriptfallback_last_time")
                            break
                        end
                    end
                else
                    self.caller.buff:add_state("scriptfallback_last_time", time)
                end

                if datasleep and mainlineid > 1 then
                    local index
                    for k, v in ipairs(datasleep) do
                        local mainline_range_max = v.mainline_range and v.mainline_range[2]
                        if mainline_range_max > mainlineid then
                            index = k
                            break
                        end
                    end

                    local sleepconfig = datasleep[index]
                    local time_range = sleepconfig.time_range
                    local attr_args = sleepconfig.attr_rate
                    local range_rank = 0
                    local attr_str = {}
                    if time_range and attr_args then
                        for i = 1, #time_range do
                            if time < time_range[i] then
                                break
                            else
                                range_rank = i
                            end
                        end

                        if range_rank > 0 then
                            for k, v in pairs(attr_args) do
                                self.owner.attr:setpercent(k, v[range_rank])
                                table.insert(attr_str, k..":"..v[range_rank])
                            end
                        end
                    end
                    -- print("睡眠时间："..time.."小时,等于"..(time*60).."分钟。  减少属性："..table.concat(attr_str, ", "))
                end
            end}
        }
    }
-- 主线章节-- 第一章
    conf.buff[9999010] = {
        event = {
            {scriptevent.onstart, onfire = function (self)
                local gameobj = self.service.area:getgameobj()
                local mainlineid = gameobj.caller.born:get_activity_info("mainlineid")
                local thisline = MainLineConf[mainlineid]
                
                -- attr_change = {[6202] = {{43, 3450, 1},}},           -- 受伤率 千分比
                -- mpchange = {[1103] = {hit = 3, max = 1}},                       -- 攻击回能
                -- mp_rate_d = {[1103] = 1, rate = 500},            -- 除此英雄外,其他英雄mp回复变慢
                -- ultimate_rate = {[1103] = 500},                  -- 大招伤害提升
                -- taunt = {id = 1103, stance = 1},                    -- 指定攻击某个英雄
                -- stance_attr = {[1] = {{43, 500},}},                      -- 指定某个位置怪物受伤提升
                
                if thisline then
                    local _attrc = thisline.attr_change
                    local _mpchange = thisline.mpchange
                    local _mp_rate_d = thisline.mp_rate_d
                    local _u_rate = thisline.ultimate_rate
                    local _taunt = thisline.taunt
                    local _s_attr = thisline.stance_attr

                    -- 1.前n次受伤 属性修改
                    if _attrc and (_attrc.all or _attrc[self.owner.typeid]) then
                        local attr_table = {}
                        local attrconf = (_attrc.all or _attrc[self.owner.typeid])
                        for _, attr_args in ipairs(attrconf) do
                            local attr, rate, times = table.unpack(attr_args)
                            attr = attr or 0
                            rate = rate or 0
                            times = times or 0
                            self.owner.attr[CONST.ATTR[attr]] = self.owner.attr[CONST.ATTR[attr]] + rate
                            table.insert(attr_table, {attr = CONST.ATTR[attr], rate = rate, count = 0, count_max = times, changed = false})
                        end
                        self.prop.attrc = attr_table
                    end

                    -- 2.攻击回能
                    if _mpchange then
                        local list = _mpchange
                        self.prop.mpc = {list = list, count = {}, mpcount = {}, changed = {}}
                    end

                    -- 3.除此英雄外,其他英雄mp回复变慢
                    if _mp_rate_d then 
                        local targets = self.action:range(SKILL.RANGEID.ENEMYS)
                        for _, target in ipairs(targets) do
                            if not _mp_rate_d[target.typeid] then
                                target.attr.mp_rate_d = _mp_rate_d.rate or 0
                            end
                        end
                    end

                    -- 4.指定英雄对自身的大招增加伤害
                    if _u_rate then 
                        self.prop._u_rate = _u_rate
                        self.prop._u_rate_changed = {}
                    end

                    -- 5.指定攻击某个英雄（或者站位
                    if _taunt and (_taunt.id or _taunt.stance) then  
                        local targets = self.action:range(SKILL.RANGEID.ENEMYS)
                        for _, target in ipairs(targets) do
                            if (target.typeid == _taunt.id) or (target.prop.stance == _taunt.stance) then
                                self.caller.taunt:add(target)
                            end
                        end
                    end

                    -- 6.指定位置怪物属性修改
                    if _s_attr and _s_attr[self.owner.prop.stance] then
                        for _, attr_args in ipairs(_s_attr[self.owner.prop.stance]) do
                            local attr, rate = table.unpack(attr_args)
                            self.owner.attr[CONST.ATTR[attr]] = self.owner.attr[CONST.ATTR[attr]] + rate or 0
                        end
                    end

                end
            end},

            -------------------------------------------------------------------------------------
            {eventdef.skill_damage,  modifer = eventmdf.excludeself, onfire = function (self, fromobj, damage_table)
                local attrc = self.prop.attrc -- 指针
                if attrc and damage_table.toobj == self.owner then
                    for _, attr_args in ipairs(attrc) do
                        attr_args.count = attr_args.count + 1
                        if (not attr_args.changed) and attr_args.count_max > 0 and attr_args.count >= attr_args.count_max then
                            self.owner.attr[attr_args.attr] = self.owner.attr[attr_args.attr] - attr_args.rate
                            attr_args.changed = true
                        end
                    end
                end
            end},
            --------------------------------------------------------------------------------------
            {eventdef.skill_damage, modifer = eventmdf.excludeself, onfire = function(self, fromobj, damage_table)
                local mpc = self.prop.mpc
                local typeid = fromobj.typeid
                local stance = fromobj.prop.stance
                local _check = mpc and mpc.list and (mpc.list[typeid] or mpc.list[stance])
                if mpc and damage_table.toobj == self.owner and _check then
                    self.action:message("999901_mp_change", fromobj)
                end
            end},

            {"999901_mp_change", modifer=eventmdf.public, onfire = function(self, fromobj, target)
                if self.prop.mpc then
                    local mpc = self.prop.mpc
                    local _typeid = mpc.list[target.typeid] and target.typeid or target.prop.stance
                    local _check = mpc.list[_typeid]
                    local _changed = mpc.changed[_typeid]

                    if _check and (not _changed) then
                        local args = mpc.list[_typeid]
                        local value = tsmath.floor((args.value or 1000) /(#self.action:range(SKILL.RANGEID.FRIENDS)))
                        local countlist = mpc.count

                        countlist.count = (countlist.count or 0) + 1
                        if countlist.count >= args.hit then
                            target.caller.mp:change(value)
                            countlist.count = 0
                            countlist.mpcount = (countlist.mpcount or 0) + 1
                            if countlist.mpcount >= args.max then
                                mpc.changed[target.typeid] = true
                                mpc.changed[target.prop.stance] = true
                            end
                        end
                    end
                end
            end},
            ---------------------------------------------------------------------------------------
            {eventdef.slot_use, modifer = eventmdf.excludeself, onfire = function(self, fromobj, slotid)
                local urate = self.prop._u_rate
                local _typeid = urate and urate[fromobj.typeid] and fromobj.typeid or fromobj.prop.stance
                local _check = urate and slotid == SKILL.SLOT.ULTIMATE and urate[_typeid]
                if _check then
                    fromobj.attr.dmg_rate = fromobj.attr.dmg_rate + urate[_typeid]
                    self.prop._u_rate_changed[fromobj] = true
                end
            end},

            {eventdef.skill_end, modifer = eventmdf.excludeself, onfire = function(self, fromobj, castid)
                if self.prop._u_rate_changed and self.prop._u_rate_changed[fromobj] 
                and fromobj.caller.skill:toslotid(castid) == SKILL.SLOT.ULTIMATE then
                    local _typeid = self.prop._u_rate[fromobj.typeid] and fromobj.typeid or fromobj.prop.stance
                    fromobj.attr.dmg_rate = fromobj.attr.dmg_rate - self.prop._u_rate[_typeid]
                    self.prop._u_rate_changed[fromobj] = false
                end
            end},
            ------------------------------------------------------------------------------------------

            {scriptevent.onend, onfire = function(self)

            end}
        }
    }
    ---
    conf.buff[9999210] = { -- todo 融合进buff表
        event = {
            {scriptevent.onstart, onfire = function (self)
                self.caller.mp:change(400)
            end},
        }
    }

    -- 1-11 红龙boss
    conf.buff[9999190] = {
        event = {
            {scriptevent.onstart, onfire = function (self)
                self.prop.checkif = false
                self.prop.time_count = 0
                self.prop.max_count = 3
                self.prop.mp_change = 220
            end},

            {"738211_cast", modifer = eventmdf.excludeself, onfire = function (self)
               self.prop.checkif = true
            end},

            {scriptevent.ontimer, time = {1000,1000}, onfire = function (self)
                if self.prop.checkif and self.prop.time_count < self.prop.max_count then
                    if self.owner.static.class == HERO_CLASS.MENTALITY then
                        self.caller.mp:change(self.prop.mp_change)
                    end
                    self.prop.time_count = self.prop.time_count + 1
                else
                    self.prop.checkif = false
                    self.prop.time_count = 0
                end
            end}
        }
    }
return conf