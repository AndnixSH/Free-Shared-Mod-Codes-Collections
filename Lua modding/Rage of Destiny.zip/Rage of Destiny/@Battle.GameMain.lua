
-- 游戏lua程序的入口类
local GameMain = { _bdestroy = true, _binit = false }

require "Battle.GameConfig"
--local game = require "Battle.game.game"
--local render = require "Battle.render.render_area"
--local input = require "Battle.input.game_input"
local FrameUpdateMgr = require "First.Util.FrameUpdateMgr"

if GameConfig.RENDER_ENABLE then
    GameConfig.ISEDITOR = CS.UnityEngine.Application.isEditor
end

local function strstartswith(str, start)
    return string.sub(str,1,string.len(start)) == start
end

function GameMain._init()
    local render = require "Battle.render.render_area"
    render.initialize()
end

function GameMain.Start(gameinfo, gameprop, isjump)
    for pkgname, _ in pairs(package.loaded) do
        if strstartswith(pkgname, "Battle.engine") or
                strstartswith(pkgname, "Battle.game") or
                strstartswith(pkgname, "Battle.input") or
                strstartswith(pkgname, "Battle.init") then
            package.loaded[pkgname] = nil
        end
    end

    GameMain._Start(gameinfo, gameprop, isjump)
end

function GameMain._Start(gameinfo, gameprop, isjump)
    if not GameMain._binit then
        GameMain._binit = true
        GameMain._init()
    end

    if GameMain._bdestroy then
        GameMain._bdestroy = false
        print("Game Start")

        local engine_init = require "Battle.init.engine_init"
        local game_init = require "Battle.init.game_init"
        local game = require "Battle.game.game"
        local input = require "Battle.input.game_input"

        local render = require "Battle.render.render_area"
        render.setenable(not isjump)
        game.init(require("Battle.engine.engine"), engine_init, game_init, require("Battle.render.render_bridge"))
        game.start("Battle.game", assert(gameinfo.gameid), gameinfo.activityid, gameinfo.seed, gameprop)
        render.start(gameinfo)

        input.operation.start(gameprop.extra.report)
        if isjump then
            input.operation.jump()
        end
        gamelog.write("gamestart")
        FrameUpdateMgr.Add(GameMain)
    end
end

function GameMain.FrameUpdate(self, time, deltaTime)
    if not GameMain._bdestroy then
        local input = require "Battle.input.game_input"
        input.process(time, deltaTime)

        local game = require "Battle.game.game"
        game.process(time, deltaTime)
        -- game.simulateprocess(time, deltaTime)
    end
end

function GameMain.FixedUpdate(self, fixedTime, fixedDeltaTime)

end

function GameMain.Destroy(cbdestroy)
    if not GameMain._bdestroy then
        GameMain._bdestroy = true
        GameMain._Destroy()
        FrameUpdateMgr.Remove(GameMain)
    end
end

function GameMain._Destroy()
    gamelog.write("gamedestroy")
    gamelog.stop()

    local render = require "Battle.render.render_area"
    render.destroy()

    local game = require "Battle.game.game"
    game.dispose()

    local input = require "Battle.input.game_input"
    input.dispose()
    print("Game Destroy")
end

function GameMain.Dispose()
    GameMain._Destroy()
end

return GameMain