local MailDef = require "Modules.Mail.MailDef"
local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local BagProxy = require "Modules.Bag.BagProxy"
local httputil = require "Common.Util.httputil"
local rapidjson = require "rapidjson"
local MailProxy = MailProxy or BaseClass(BaseProxy)
function MailProxy:__init()
    MailProxy.Instance = self
  
    self:AddProto(60001, self.On60001) 
    self:AddProto(60002, self.On60002) 
    self:AddProto(60003, self.On60003)
    self:AddProto(60004, self.On60004)
   self.data={}
   self.data.mailList={}

   self.oneDayToHours=24
   self.fiftyDayToHours=15*24

   self.downloadUrl="https://www.baidu.com/"
end

function MailProxy:__delete()
    MailProxy.Instance = nil
    self.data=nil
end

function MailProxy:GetDownURL()
    return self.downloadUrl
end

function MailProxy:CaculateReceptiontTime(receivetime)
    
    local receptiontime=""
    local time=os.difftime(RoleInfoModel.servertime,receivetime)
    local hour=math.ceil(time*1.0/3600)

    if hour < self.oneDayToHours then
        --24小时内接收到
        receptiontime=string.format(LanguageManager.Instance:GetWord(MailDef.CommonDef.ReceiveHour),hour <= 0 and "1" or tostring(hour))
    else
        local day=math.ceil(hour*1.0/self.oneDayToHours)
        receptiontime=string.format(LanguageManager.Instance:GetWord(MailDef.CommonDef.ReceiveDay),day)
    end
    return receptiontime
end

function MailProxy:CaculateExpiryTime(receivetime,keeptime)
    local expirytime=""
    local time=os.difftime(RoleInfoModel.servertime,receivetime)
    local hour=math.ceil(time*1.0/3600)
    local remainhour=math.floor((keeptime and keeptime * self.oneDayToHours or self.fiftyDayToHours) - hour)
    if remainhour > 0 then
        if remainhour < self.oneDayToHours  then
            expirytime=string.format(LanguageManager.Instance:GetWord(MailDef.CommonDef.ExpireHour),remainhour)
        else
            local day=math.floor(remainhour*1.0/self.oneDayToHours)
            expirytime=string.format(LanguageManager.Instance:GetWord(MailDef.CommonDef.ExpireDay),day)
        end
    else
        --过期
        return false
    end
    return expirytime
end

function MailProxy:GetMailMailCfgById(configid)
    local config=ConfigManager.GetConfig("data_mail")
    if config then
        return config[configid]
    end
end

function MailProxy:Send60001()
    --请求邮件列表
     self:SendMessage(60001)
end

function MailProxy:On60001(decoder)
     --请求邮件列表
     -- 邮件id 邮件已读 未读状态 接收邮件的时间  邮件奖励物品id，数量，icon  --后台获取邮件标题  邮件内容 
    local  version=""
    local maillist={}
    local normal_mail_list = {}
    local count=decoder:Decode("I2")
    for i=1,count do
        local tab={}
        local id,read,type,receivetime,mailconfigid=decoder:Decode("I4I1I2I4I4")
        tab.id=id --邮件id
        tab.read=read --0未读，1已读
        tab.receivetime=receivetime
        tab.mailconfigid=mailconfigid
        tab.receptiontime=self:CaculateReceptiontTime(receivetime)
       
        tab.type=type --邮件类型 0 为普通邮件 1为特殊邮件中的版本更新 2游戏中产生的邮件
        local num = decoder:Decode("I2")
        tab.reward={}
        for i=1,num do
            local reward={}
            local goodsid,goodsnum=decoder:Decode("I4I4")
            reward.id=goodsid
            reward.num=goodsnum
            -- local cfg=BagProxy.Instance:GetGoodsCfgById(goodsid)
            -- if not cfg then 
            --     reward.icon=cfg.icon 
            -- end
            --reward.type=1 --或者奖励类型 -- 2为英雄 否则为底框加图片加数量
            table.insert(tab.reward,reward)
        end

        if tab.type == MailDef.MailType.special then
            if version == SystemConfig.ResVersion then
                --已经更新，就变为普通邮件处理
                tab.type= MailDef.MailType.normal
            end
        end
        if tab.type == MailDef.MailType.normal or tab.type == MailDef.MailType.special then

            table.insert(normal_mail_list,mailconfigid)
            tab.title=""           --从后台获取
            tab.content="" --从后台获取
            tab.expirytime=self:CaculateExpiryTime(receivetime,nil)
        elseif tab.type == MailDef.MailType.system then
            --游戏中产生的邮件，根据mailconfigid 读取配置邮件
            local cfg=self:GetMailMailCfgById(mailconfigid)
            tab.expirytime=self:CaculateExpiryTime(receivetime,cfg.overtime)
            tab.title=""  --从配置邮件获取
            tab.content=""  --从配置邮件获取
            if cfg then
                local paramas=decoder:DecodeList("s8")
                tab.title=LanguageManager.Instance:GetWord(cfg.title)  
                local str=LanguageManager.Instance:GetWord(cfg.info)

                -- print(mailconfigid)
                -- print("aaa", table.dump(paramas))

                if mailconfigid == 41011 then
                    local GuildProxy = require "Modules.Guild.GuildProxy"
                    local HeroProxy = require "Modules.Hero.HeroProxy"
                    for i=1,#paramas do
                        local parama = paramas[i]
                        -- print(parama)
                        if i == 1 then
                            local roleId = GuildProxy.Instance:GetChaosBossRoleId(tonumber(parama))
                            local roleConfig = HeroProxy.Instance:GetRoleCfgByConfigId(roleId)
                            paramas[i] = LanguageManager.Instance:GetWord(roleConfig.name)
                        elseif i == 2 then
                            local roomConfig = GuildProxy.Instance:GetChaosRoomConfigById(tonumber(parama))
                            paramas[i] = tostring(roomConfig.hero_level)
                        elseif i == 3 then
                            paramas[i] = GameLogicTools.NumToCommaFormat(tonumber(parama))
                        elseif i == 4 then
                            if paramas[5] then
                                local rank = tonumber(paramas[5])
                                if rank ~= 0 then
                                    local legendConfig = GuildProxy.Instance:GetChaosLegendConfig()
                                    paramas[i] = LanguageManager.Instance:GetWord(legendConfig.rank_name)
                                else
                                    local rankConfig = GuildProxy.Instance:GetChaosRankConfigById(tonumber(parama))
                                    paramas[i] = LanguageManager.Instance:GetWord(rankConfig.rank_name)
                                end
                            else
                                local rankConfig = GuildProxy.Instance:GetChaosRankConfigById(tonumber(parama))
                                paramas[i] = LanguageManager.Instance:GetWord(rankConfig.rank_name)
                            end
                        elseif i == 5 then
                            paramas[i] = nil
                        end
                    end
                elseif mailconfigid == 41012 then
                    local GuildProxy = require "Modules.Guild.GuildProxy"
                    local HeroProxy = require "Modules.Hero.HeroProxy"
                    for i=1,#paramas do
                        local parama = paramas[i]
                        -- print(parama)
                        if i == 1 then
                            local roleId = GuildProxy.Instance:GetChaosBossRoleId(tonumber(parama))
                            local roleConfig = HeroProxy.Instance:GetRoleCfgByConfigId(roleId)
                            paramas[i] = LanguageManager.Instance:GetWord(roleConfig.name)
                        end
                    end
                end

                -- print("bbb", table.dump(paramas))

                for i=1,#paramas do
                    str=string.gsub(str, "~str", tostring(paramas[i]), 1)
                end
                
                --tab.content=str
                tab.content = string.gsub(str," ","<color=#00000000>.</color>")
                tab.sender=string.format("%s\n%s",LanguageManager.Instance:GetWord(cfg.sender) or "",tab.expirytime)
                --str=string.gsub(str, "~str", tab.expirytime)
            end
        end
        if  tab.expirytime then
            table.insert(maillist,tab)
        end
    end
    if #maillist > 999 then
        for i=#maillist, 1000 ,-1 do
            table.remove(maillist,i)
        end
        print("-------maillistcount--------",#maillist)
    end
    if #normal_mail_list > 0 then
        self:GetMailsContent(normal_mail_list)
        --print("-------------normal_mail_list----------------",table.dump(normal_mail_list))
    end
    table.sort(maillist, function(a,b) --排序
        return a.receivetime > b.receivetime
    end)
    local hasreadlist={}
    for i=#maillist,1,-1 do
        if maillist[i].read == 1 then
            table.insert(hasreadlist,maillist[i])
            table.remove(maillist,i)
        end
    end
    table.sort(hasreadlist, function(a,b) --排序
        return a.receivetime > b.receivetime
    end)
    for i=1,#hasreadlist do
        table.insert(maillist,hasreadlist[i])
    end
    self.data.mailList=maillist
    local MainProxy = require "Modules.Main.MainProxy"
    local MainDef = require "Modules.Main.MainDef"
    MainProxy.Instance:UpdateRedDot(MainDef.MainRedDotType.Mail, self:GetMailRedDot())
    if #normal_mail_list == 0 then
        self:ToNotify(self.data,MailDef.NotifyDef.Mail_Request)
    end
end

function MailProxy:GetMailsContent(list)

    local backFun = function(text)
        print("----GetMailsContent----")
        local rapidjson = require 'rapidjson'
        local data = rapidjson.decode(text)
       -- print("=====>>", table.dump(data))
        if data and data.data and self.data.mailList then
            for _ , v  in ipairs(data.data) do
                if v then
                     for _ , mail in ipairs(self.data.mailList) do
                         if v.mailid == mail.mailconfigid and mail.type ~= MailDef.MailType.system then
                            mail.title = v.title
                            mail.content = v.content
                         end
                     end
                end
            end
        else
            print("--------GetMailsContent-失败-----------")
        end
        self:ToNotify(self.data,MailDef.NotifyDef.Mail_Request)
    end

    local t = {
        ["mailid"] = list,
        ["package"] = SystemConfig.AgentPackageID,
    }

    local p = {
        ["api"] = "email",
        ["func"] = "getEmail",
        ["params"] = t
    }
    local params = {}
    local LoginProxy = require "Modules.Login.LoginProxy"
    local LoginDef = require "Modules.Login.LoginDef"
    local baseUrl = SystemConfig.Router
    local url = baseUrl .. LoginDef.api.gameapi
    params.token = LoginProxy.Instance:cms_encrypt(rapidjson.encode(p))
    httputil.post(url, params, backFun)

end

function MailProxy:GetMailRedDot(  )
    for _, v in pairs(self.data.mailList ) do
        if v.reward then
            if v.read == 0 and #v.reward > 0 then
                return 1
            end
        end
    end
    return 0
end

function MailProxy:Send60003(mailidlist)

    --领取邮件的奖励 一个列表
    local encoder=NetEncoder.New()
    encoder:EncodeList("I4",mailidlist)
    self:SendMessage(60003,encoder)
end

function MailProxy:On60003(decoder)

    local result= decoder:Decode("I1")
    local mailidlist=decoder:DecodeList("I4")
    local getList={}
    if result == 0 or result == 4 then --为4时有部分邮件领取失败
        --领取成功
        for _,v in pairs(self.data.mailList) do
            if v then
                for k,id in pairs(mailidlist) do
                    if v.id == id then
                        v.read=1 --已读
                        table.insert(getList,v)
                        
                    end
                end
            end
        end
        self:ToNotify(self.data,MailDef.NotifyDef.Mail_Update,getList)
        if result == 4 then
            GameLogicTools.ShowMsgTips(LanguageManager.Instance:GetWord("MailToMuch_1001"))
        end
    else

        GameLogicTools.ShowErrorCode(60003, result)
    end
end

function MailProxy:Send60002(mailid)

    --阅读一封没有奖励的邮件
    local encoder=NetEncoder.New()
    encoder:Encode("I4",mailid)
    self:SendMessage(60002,encoder)
end

function MailProxy:On60002(decoder)
    local result,mailid=decoder:Decode("I1I4")
    if result == 0 then
        --成功
        for _,v in pairs(self.data.mailList) do
            if v then
                if v.id == mailid then
                    v.read=1 --已读
                    self:ToNotify(self.data,MailDef.NotifyDef.Mail_Update,{v})
                    break
                end
            end
        end
    else
        GameLogicTools.ShowErrorCode(60002, result)
    end
end

function MailProxy:Send60004()
    --一键删除已读邮件
    local maillist={}
    for _,v in pairs(self.data.mailList) do
        if v then
            if v.read == 1 then
                --存在已读邮件
                table.insert(maillist,v.id)
            end
        end
    end
    
    if #maillist == 0 then
        --所有邮件都未读
        GameLogicTools.ShowMsgTips(MailDef.CommonDef.DeleteMailSuccess)
    else
        local encoder=NetEncoder.New()
        encoder:EncodeList("I4",maillist)
        self:SendMessage(60004,encoder)
    end
   
end

function MailProxy:On60004(decoder)
    local result= decoder:Decode("I1")
    local mailidlist=decoder:DecodeList("I4")
    if result == 0 then
        for _,_id in pairs(mailidlist) do
            for i=#self.data.mailList,1,-1 do
                if self.data.mailList[i].id == _id then
                    table.remove(self.data.mailList,i)
                end
            end
        end
        self:ToNotify(self.data,MailDef.NotifyDef.Mail_DeleteReadMailResult)
    else
        GameLogicTools.ShowErrorCode(60004, result)
    end
end

function MailProxy:GetAllRewardByOneBtn()
    --一键领取邮件
    local hasreward=false
    local specialMailList={}
    local list={}
    for _,v in pairs(self.data.mailList) do
        if v then
            if v.read == 0 and #v.reward > 0 then

                if v.type ~= MailDef.MailType.special then
                    --存在待领取邮件
                    hasreward=true
                    table.insert(list,v.id)
                else
                    table.insert(specialMailList,v)
                end
                
            end
        end
    end

    if not hasreward then
        if #specialMailList > 0 then
            GameLogicTools.ShowMsgTips(MailDef.CommonDef.SpecialMailTips)
        else
            --没有待领取的邮件
            GameLogicTools.ShowMsgTips(MailDef.CommonDef.NoRewardMail)
        end
    else
        self:Send60003(list)
    end
end

return MailProxy
