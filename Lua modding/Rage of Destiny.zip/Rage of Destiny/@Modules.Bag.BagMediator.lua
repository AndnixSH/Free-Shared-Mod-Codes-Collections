local BagMediator = BagMediator or BaseClass(StdMediator)

function BagMediator:OnEnterScenceFirst()	
	local BagProxy = require "Modules.Bag.BagProxy"

	self:DelayExecute(function()
		BagProxy.Instance:Send15000()
	end)
end


return BagMediator