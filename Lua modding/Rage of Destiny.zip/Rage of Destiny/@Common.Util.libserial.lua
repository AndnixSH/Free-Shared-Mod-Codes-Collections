local libserial = {}

function libserial.serialize(obj, ignoremata)
    local lua = ""
    local t = type(obj)
    if t == "number" then
        lua = lua .. obj
    elseif t == "boolean" then
        lua = lua .. tostring(obj)
    elseif t == "string" then
        --lua = lua .. obj
        lua = lua .. string.format("%q", obj)
    elseif t == "table" then
        lua = lua .. "{"
        for k, v in pairs(obj) do
            lua = lua .. "[" .. libserial.serialize(k) .. "]=" .. libserial.serialize(v, ignoremata) .. ","
        end
        if not ignoremata then
            local metatable = getmetatable(obj)
            if metatable ~= nil and type(metatable.__index) == "table" then
                for k, v in pairs(metatable.__index) do
                    lua = lua .. "[" .. libserial.serialize(k) .. "]=" .. libserial.serialize(v, ignoremata) .. ","
                end
            end
        end
        lua = lua .. "}"
    elseif t == "nil" then
        return nil
    else
        return "nil"
        -- error("can not serialize a " .. t .. " type.")
    end
    return lua
end

function libserial.unserialize(lua)
    local t = type(lua)
    if t == "nil" or lua == "" then
        return nil
    elseif t == "number" or t == "string" or t == "boolean" then
        lua = tostring(lua)
    else
        error("can not unserialize a " .. t .. " type.")
    end
    lua = "return " .. lua
    local func = load(lua)
    if func == nil then
        return nil
    end
    return func()
end

return libserial

-- local x1 = {a = 1, {x=222, y="hello"}}

-- local bin = libserial.serialize(x1)
-- print(bin) -- {[1]={["y"]="hello",["x"]=222,},["a"]=1,}

-- local x2 = libserial.unserialize(bin)
-- print(x2.a)
-- print(x2[1].x)
