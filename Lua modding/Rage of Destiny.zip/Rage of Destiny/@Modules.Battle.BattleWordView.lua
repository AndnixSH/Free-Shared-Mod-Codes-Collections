local WordArtHandle = require "Modules.Battle.Handle.WordArtHandle"
local SettingMenuProxy = require "Modules.SettingMenu.SettingMenuProxy"
local SettingMenuDef = require "Modules.SettingMenu.SettingMenuDef"
local BattleBaseClass = require "Core.Implement.UI.Class.BattleBaseClass"
local BattleProxy = require "Modules.Battle.BattleProxy"
local BattleDef = require "Modules.Battle.BattleDef"

local BattleWordView = BattleWordView or LuaWidgetClass(BattleBaseClass)
function BattleWordView:__init()
end

function BattleWordView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Battle.BattleWordView",self.LoadEnd)
end

function BattleWordView:LoadEnd(obj)
	self:SetGo(obj)

	self.wordArtHandle = WordArtHandle.New(self:GetChild(obj, "WordArt"))
	self:SetStep(0)
end

function BattleWordView:OnOpen()
	self.data = {}
		
	self:SetModelDepth(self.go, 0)
	self:SetOverrideSorting(self.go, false)
	
	self:RegisterBattleGlobalEvent()
	self:UpdateInfo()
	self:AddSpriteEvent()
	self.wordArtHandle:Open()
	self:StartFrame()
end

function BattleWordView:OnClose()	
	self:UnRegisterBattleGlobalEvent()
	self:RemoveSpriteEvent()
	self:EndFrame()
end

function BattleWordView:OnDestroy()
	self.wordArtHandle:Destroy()
	self:UnRegisterBattleGlobalEvent()
	self:RemoveSpriteEvent()
	self:AutoUnRegister()
	self:EndFrame()

end

function BattleWordView:UpdateInfo()
	
end

local function _create_new_word_sprite_class(sprite_data, spriteid, camp, word_view)
	local new_word_sprite = BattleBaseClass.New()
	new_word_sprite.event = {}
	new_word_sprite.event.sprite = {}
	
	local BUFF_ATK = 801
	
	new_word_sprite.event.sprite.buff_start = function(battle_sprite, buff_id)
		word_view:SendWordEventNotify(spriteid, spriteid, camp, BUFF_ATK, buff_id)
	end
	
	return new_word_sprite
end

function BattleWordView:AddSpriteEvent()
	self:RemoveSpriteEvent()
	
	self.data.new_sprite_list = {}
	self:AddCampSpriteEvent(CAMP.RED)
	self:AddCampSpriteEvent(CAMP.BLUE)
end

function BattleWordView:AddCampSpriteEvent(camp)
	local spritelist = BattleProxy.Instance:GetSpriteList(camp)
	if spritelist then
		for i, spriteid in ipairs(spritelist) do
			if i > BattleDef.ConstNum.MaxFightNum then
				break
			end
			
			local sprite_data=BattleProxy.Instance:GetSprite(spriteid)
			if spriteid and sprite_data then
				local new_sprite_class = _create_new_word_sprite_class(sprite_data, spriteid, camp, self)
				new_sprite_class:RegisterSpriteEvent(spriteid)
				table.insert(self.data.new_sprite_list, new_sprite_class)
			end
		end
	end
end

function BattleWordView:RemoveSpriteEvent()
	if self.data.new_sprite_list then
		for i,sprite in ipairs(self.data.new_sprite_list) do
			sprite:UnRegisterSpriteEvent()
		end
	end
	self.data.new_sprite_list = {}
end

function BattleWordView:FrameUpdate(time, deltaTime)	
	self.wordArtHandle:FrameUpdate(time, deltaTime)
end

--onclick


--notify
function BattleWordView.event.sprite.public:damagesct(_, sct_args, ...)
	--print("fromobj===", fromobj.uid, toid, tocamp)
	-- print('sct-args', table.dump(sct_args))
	-- print('addtion-args', ...)
	self:SendWordEventNotify(sct_args.fromid, sct_args.toid, sct_args.tocamp, sct_args.state, ...)
end

function BattleWordView:SendWordEventNotify(fromid, toid, tocamp, state, ...)
	local fly_word = SettingMenuProxy.Instance:GetSystemState(SettingMenuDef.Systerm_Option_Key[SettingMenuDef.Systerm_Option_Type.FlyWord])
	if fly_word == 1 then
		self.wordArtHandle:WordEventNotify(fromid, toid, tocamp, state, ...)
	end
end

function BattleWordView.event.game:gametime_pause()
	self.wordArtHandle:ShowWordObjActive(false)

end

function BattleWordView.event.game:gametime_resume()
	self.wordArtHandle:ShowWordObjActive(true)
end

return BattleWordView