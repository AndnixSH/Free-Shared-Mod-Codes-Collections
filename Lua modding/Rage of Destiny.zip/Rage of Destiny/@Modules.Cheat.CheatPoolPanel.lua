local ClistRender = require "Core.Implement.UI.Class.ClistRender"
local ClistItem = require "Core.Implement.UI.Class.ClistItem"
local CheatProxy = require "Modules.Cheat.CheatProxy"
local BattleDef = require "Modules.Battle.BattleDef"

local PoolItem = PetPoolItem or BaseClass(ClistItem)
function PoolItem:Load(go)
    self.name = GameObjTools.GetChildComponent(go, "GM_label", "CLabel")
end

function PoolItem:SetData(data)
    self.data = data
    self.name.text = data.name
end

local CheatType = {
    Network = 1,
    Local = 2,
    Battle = 3,
}

local CheatPoolPanel = CheatPoolPanel or BaseClass(GameObjFactor)
function CheatPoolPanel:__init(go)
    self.go = go
    self:Load(go)
end

function CheatPoolPanel:Load(obj)
    --poollist
    self.poolList = self:GetChildComponent(obj, "CList", "CList")
    self.listRender = ClistRender.New()
    self.listRender:Load(self.poolList, PoolItem)
    self.listRender:AddSelect(
            function(item, index)
                self:OnClickPoolIdx(item, index)
            end
    )

    self.decLbl = self:GetChildComponent(obj, "GM_CLabel_info", "CLabel")
    self.Inp = self:GetChildComponent(obj, "CInput", "CTextInput")
    self.sendBtn = self:GetChildComponent(obj, "CButton_send", "CButton")
    self.sendBtn:AddClick(
            function()
                self:OnClickSend()
            end
    )

    self.item1Btn = self:GetChildComponent(obj, "item1", "CButton")
    self.item1Btn:AddClick(
            function()
                self:SetCheatType(CheatType.Network)
            end
    )

    self.item2Btn = self:GetChildComponent(obj, "item2", "CButton")
    self.item2Btn:AddClick(
            function()
                self:SetCheatType(CheatType.Local)
            end
    )

    self.item3Btn = self:GetChildComponent(obj, "item3", "CButton")
    self.item3Btn:AddClick(
            function()
                self:SetCheatType(CheatType.Battle)
            end
    )

end

function CheatPoolPanel:Open(cheatType)
    self:SetCheatType(cheatType or CheatType.Network)
end

function CheatPoolPanel:Close()
    self.cheatType = nil
end

function CheatPoolPanel:Destroy()
    self.cheatType = nil
end

function CheatPoolPanel:SetCheatType(type)
    self.cheatType = type
    self:UpdateInfo()
end

function CheatPoolPanel:UpdateInfo()
    local cfgs = ConfigManager.GetConfig("data_cheat")[self.cheatType]
    self.listRender:ClearData()
    self.listRender:AppendDataList(cfgs)
end

function CheatPoolPanel:OnClickSend()
    if self.selectData then
        local id = self.selectData.id
        local str = self.Inp.text

        if self.cheatType == CheatType.Network then
            self:SendNetwork(id, str)

        elseif self.cheatType == CheatType.Local then
            self:SendLocal(id, str)

        elseif self.cheatType == CheatType.Battle then
            self:SendBattle(id, str)
        end
    end
end

function CheatPoolPanel:_getdescr(item, index)
    return item.data.des
end

function CheatPoolPanel:OnClickPoolIdx(item, index)
    self.selectData = item.data
    self.decLbl.text = self:_getdescr(item, index)
    self.Inp.text = item.data.input
end

--后端
function CheatPoolPanel:SendNetwork(id, str)
    if id == 0 then
    else
        GameLogicTools.ShowMsgTips("已经输入后端GM！ " .. str)
        CheatProxy.Instance:Send11000(str)
    end
end

--前端
function CheatPoolPanel:SendLocal(id, str)
    if id == 1 then
        local rapidjson = require 'rapidjson'

        local IGGSdkDef = require "Modules.IGGSdk.IGGSdkDef"
        local t = {}
        t[IGGSdkDef.SecondEventParam.LevelUpCharacter] = "nameaaa"
        t[IGGSdkDef.SecondEventParam.LevelUpLevel] = 50
        local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
        IGGSdkProxy.Instance:Track(IGGSdkDef.SecondEventName.LevelUp, rapidjson.encode(t))
        --local key = tonumber(str)
        --local AudioManager = require "Common.Mgr.Audio.AudioManager"
        --if key == 1 then
        --    AudioManager.AudioSetting(AudioManager.AudioType.Music, true)
        --elseif key == 2 then
        --    AudioManager.AudioSetting(AudioManager.AudioType.Music, false)
        --elseif key == 3 then
        --    AudioManager.AudioSetting(AudioManager.AudioType.Sound, true)
        --elseif key == 4 then
        --    AudioManager.AudioSetting(AudioManager.AudioType.Sound, false)
        --end

    elseif id == 2 then
        local args = string.split(str, "_")
        local key = tonumber(args[1])
        local volume = tonumber(args[2]) or 1
        local AudioManager = require "Common.Mgr.Audio.AudioManager"
        if key == 1 then
            AudioManager.VolumeSetting(AudioManager.AudioType.Music, volume)
        elseif key == 2 then
            AudioManager.VolumeSetting(AudioManager.AudioType.Sound, volume)
        end
    elseif id == 3 then
        local obj = CS.UnityEngine.GameObject.Find("Shell")
        local mono = obj:GetComponent(typeof(CS.MonoNetPing))
        if mono then
            mono.enabled = false
        end
        SystemConfig.is_gm = false

        local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.CheatGMBtnView)
        if view and view:IsOpen() then
            view:CloseView()
        end

    elseif id == 4 then
        local state = PlayerPrefs.GetInt("mx_GM_UI", 0)
        PlayerPrefs.SetInt("mx_GM_UI", state == 1 and 0 or 1)
        CS.UnityEngine.Application.Quit()
    elseif id == 5 then
        print("show/hide active")
        local view_manager = require "Battle.render.view_manager"
        view_manager.show_active = not view_manager.show_active
        print("------->>show_active", view_manager.show_active)
    elseif id == 6 then
        print("show view")
        --local render_area = require "Battle.render.render_area"
        --render_area.show()
        local render_camera = require "Battle.render.camera.render_camera"
        render_camera.enable_3d_camera(true)
    elseif id == 7 then
        print("hide view")
        local render_camera = require "Battle.render.camera.render_camera"
        render_camera.enable_3d_camera(false)
        --local render_area = require "Battle.render.render_area"
        --render_area.hide()
        --local view_manager = require "Battle.render.view_manager"
        --view_manager.show_actor = not view_manager.show_actor
        --if not view_manager.show_actor then
        --    view_manager.hideall()
        --else
        --    view_manager.showall()
        --end
    elseif id == 8 then
        print("show/hide UI")
        LuaLayout.Instance:CloseAllWidget()
    elseif id == 9 then
        print("show/hide 飘字")
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.BattleWordView)
    elseif id == 10 then
        -- local SceneManager = require "Modules.Scene.SceneManager"
        -- local SceneDef = require "Modules.Scene.SceneDef"
        -- SceneManager.Instance:EnterScene(SceneDef.SceneType.StoryLine)
        LuaLayout.Instance:OpenWidget(UIWidgetNameDef.StoryLineRootView)
    elseif id == 11 then
        assert(tonumber(str), "invalid argument: " .. str .. "numbser needed!")
        local render_camera = require "Battle.render.camera.render_camera"
        render_camera.set_shdow_type(tonumber(str))
    elseif id == 12 then
         -- local SceneManager = require "Modules.Scene.SceneManager"
         -- local SceneDef = require "Modules.Scene.SceneDef"
         -- SceneManager.Instance:EnterScene(SceneDef.SceneType.Crystal)
        local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MallConfirm3View)
        view:OpenView()
    elseif id == 13 then
        local HeroProxy = require "Modules.Hero.HeroProxy"
        local herodata = HeroProxy.Instance:GetHeroDataByUid(4)
        print("--->>herodata", table.dump(herodata))
        local herolist = {}
        table.insert(herolist, herodata)
        local fightstr, fight = HeroProxy.Instance:GetHeroFight(herolist)
        print("fightstr, fight --> ", fightstr, fight)
    elseif id == 14 then
        LuaLayout.Instance:OpenWidget(UIWidgetNameDef.ArenaEntranceView)
    elseif id == 15 then
        assert(tonumber(str), "invalid argument: " .. str .. "numbser needed!")

        local LanguageUtil = require "First.Util.LanguageUtil"
        LanguageUtil.SetAppLanguageIdx(tonumber(str) or 1)
    elseif id == 16 then
        LuaLayout.Instance:OpenWidget(UIWidgetNameDef.RelationMenuRootView)
    elseif id == 17 then
        LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildRootView)
        LuaLayout.Instance:GetWidget(UIWidgetNameDef.ApplyGuildView)
        LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildCreateView)
        LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildApplyView)
        LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildEditorView)

        LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildHallView)
        LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildInformationView)
        LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildLogoView)
        LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildNameView)
        LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildNoticeView)

        LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildRecordView)
        LuaLayout.Instance:GetWidget(UIWidgetNameDef.GuildSetView)

        local args = string.split(str, "_")
        local _type = tonumber(args[1])
        local uin = tonumber(args[2])
        local FriendProxy = require "Modules.Friend.FriendProxy"
        if _type == 1 then
            --本服添加好友
            FriendProxy.Instance:Send19006(uin)
        elseif _type == 2 then
            --本服拉黑好友
            FriendProxy.Instance:Send19008(uin, 1)
        end
    elseif id == 18 then
        local RedPointDef = require "Modules.RedPoint.RedPointDef"
        local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
        if str == "" then
            RedPointProxy.Instance:Print()
        else
            RedPointProxy.Instance:PrintNode(str)
        end
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.CheatView)
    elseif id == 19 then
        local MobileDevicesUtils = require "Modules.Sdk.MobileDevicesUtils"
        local system_height = MobileDevicesUtils.GetDisplaySystemHeight()
        print("============>>", system_height,  CS.UnityEngine.Screen.height)
    elseif id == 20 then
        --CS.LJY.NX.XLuaManager.Instance:ReStart()
        LuaMain.Dispose()
        LuaMain.Start()
        --local SceneManager = require "Modules.Scene.SceneManager"
        --local SceneDef = require "Modules.Scene.SceneDef"
        --SceneManager.Instance:EnterScene(SceneDef.SceneType.Login)
    elseif id == 21 then
        local IGGSdkProxy = require "Modules.IGGSdk.IGGSdkProxy"
        IGGSdkProxy.Instance:invalidate_current_session()
    elseif id == 22 then
        LuaLayout.Instance:OpenWidget(UIWidgetNameDef.ShareChargeView)
    elseif id == 23 then
        local scale_factor = tonumber(str)
        if scale_factor then
            local Screen = CS.UnityEngine.Screen
            Screen.SetResolution(Screen.width * scale_factor, Screen.height * scale_factor, true);

            local obj = CS.UnityEngine.GameObject.Find("Shell")
            local mono = obj:GetComponent(typeof(CS.MonoNetPing))
            if mono then
                mono.enabled = false
                mono.enabled = true
            end
        end
    elseif id == 24 then
        local AssetLoaderAdapter = CS.LJY.NX.AssetLoaderAdapter
        local info = AssetLoaderAdapter.GetLoadedAssetBundles()
        print("abInfo", info)
    elseif id == 25 then
        local args = string.split(str, "_")
        local notificationID = tonumber(args[2])
        local SettingMenuProxy = require "Modules.SettingMenu.SettingMenuProxy"
        local LanguageManager = require "Common.Mgr.Language.LanguageManager"
        local date = os.date("*t", os.time())
        local cfg = SettingMenuProxy.Instance:GetCfgByNotificationID(notificationID)
        if not cfg then
            return
        end
        local title = LanguageManager.Instance:GetWord(cfg.title and cfg.title or "")
        local content = LanguageManager.Instance:GetWord(cfg.info_tips  and cfg.info_tips or "")
        SettingMenuProxy.Instance:SendTimeIntervalNotification(title, content, 1, notificationID, "", "")
    elseif id == 26 then
        local RedPointDef = require "Modules.RedPoint.RedPointDef"
        local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
        if str == "" then
            RedPointProxy.Instance:Print()
        else
            RedPointProxy.Instance:PrintChildrenNode(str)
        end
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.CheatView)
    end
end

--战斗
function CheatPoolPanel:SendBattle(id, str)
    if id == 1 then
        local spriteid = tonumber(str)
        if spriteid then
            local spriteobj = global.service.pool:get_obj(spriteid)
            local sprite_input = require "Battle.input.sprite_input"
            sprite_input.print_attr(spriteobj)
        end
    elseif id == 2 then
        local args = string.split(str, ",")
        if args then
            for i, v in ipairs(args) do
                local id = tonumber(v)
                if id > 0 then
                    gamelog.addspritelog(id)
                else
                    gamelog.removespritelog(-id)
                end
            end
        end

    elseif id == 3 then
        local args = string.split(str, "_")
        local battleView = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleWordView)
        if battleView:IsOpen() then
            for i = 1, 5 do
                battleView.wordArtHandle:WordEventNotify(1, 1, tonumber(args[1]), args[2] and tonumber(args[2]))
            end
        end
    elseif id == 4 then
        local id = tonumber(str)
        if id then
            local CampaignProxy = require "Modules.Campaign.CampaignProxy"
            local mainlinecfg = CampaignProxy.Instance:GetMainLineCfgById(id)
            if mainlinecfg then
                local enemylist = GameLogicTools.GetEnemyList(mainlinecfg.enemy_id)
                UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 1, ACTIVITYID.MAINLINE, enemylist)
            end
        end
    elseif id == 5 then
        local render_camera = require "Battle.render.camera.render_camera"
        render_camera.free_trunk_strategy()
        render_camera.set_target_trunk_strategy({ 16.19, 8.2, 1.3, 31.467, -49.51, 0, 35, 15, 255, 255, 255, 255 })
    elseif id == 6 then
        local render_camera = require "Battle.render.camera.render_camera"
        render_camera.free_trunk_strategy({ 16.51, 6.17, 1.5, 24.535, -51.036, 0, 27.5, 15, 255, 255, 255, 255 })
        render_camera.set_target_trunk_strategy({ 16.19, 8.2, 1.3, 31.467, -49.51, 0, 35, 15, 255, 255, 255, 255 })
    elseif id == 7 then
        local render_camera = require "Battle.render.camera.render_camera"
        render_camera.free_trunk_strategy()
        render_camera.set_target_trunk_strategy({ 17.6, 12.2, -0.75, 37.647, -47.178, 0, 28, 15, 255, 255, 255, 255 })
    elseif id == 8 then
        local render_camera = require "Battle.render.camera.render_camera"
        render_camera.free_trunk_strategy()
        render_camera.set_target_trunk_strategy({ 17.6, 13.5, -0.75, 40.484, -47.178, 0, 30, 15, 255, 255, 255, 255 })
    elseif id == 9 then
        local game_input = require "Battle.input.game_input"
        game_input.operation.settle(tonumber(str) or 1, 0)
    elseif id == 10 then
        local args = string.split(str, ",")
        local spriteobj = global.service.pool:get_obj(tonumber(args[1]))
        spriteobj.caller.hp:change(tonumber(args[2]))
    elseif id == 11 then
        gamelog.setlevel(tonumber(str))
    elseif id == 12 then
        local args = string.split(str, ",")
        local spriteobj = global.service.pool:get_obj(tonumber(args[1]))
        spriteobj.caller.buff:add(tonumber(args[2]))
    elseif id == 13 then
        local id = tonumber(str)
        if id then
            local TowerProxy = require "Modules.Tower.TowerProxy"
            local cfg = TowerProxy.Instance:GetTowerCfgById(id)
            if cfg then
                local enemylist = GameLogicTools.GetEnemyList(cfg.enemy_id)
                UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 1, ACTIVITYID.TOWER, enemylist, { cfg.type })
            end
        end
    elseif id == 14 then
        local gameobj = global.service.area:getgameobj()
        local runeid = tonumber(str)
        if runeid then
            gameobj.caller.born:addrune({runeid})
        end
    elseif id == 15 then
        local game_input = require "Battle.input.game_input"
        local speed = tonumber(str)
        game_input.operation.jump(speed)
    elseif id == 16 then
        local data_training = require "Config.data_training"
        local gameinfo = data_training.gameinfo
        local camp1, camp2 = data_training.camp1, data_training.camp2
        local camp_list = data_training.camp_list
        local BattleProxy = require "Modules.Battle.BattleProxy"
        local rawplayers = {}

        --heroid, roleid, camp, level, rank, stance
        local args = string.split(str, ",")
        if args then
            local roleid, level, rank, _camp2, _camp1 = table.unpack(args)
            roleid = tonumber(roleid)
            level = tonumber(level)
            rank = tonumber(rank)
            camp2 = tonumber(_camp2)
            if _camp1 then
                camp1 = tonumber(_camp1)
                local iter = 1
                for i, rolecnf in ipairs(camp_list[camp1]) do
                    local stance = rolecnf.stance or iter
                    local _roleid = stance == 1 and roleid or rolecnf.roleid
                    local _level = stance == 1 and level or rolecnf.level
                    local tb = BattleProxy.Instance:GetGamePlayerTable(_roleid, _roleid, 1, _level, rolecnf.rank, stance)
                    rawplayers[stance] = tb
                    iter = iter + 1
                end
            else
                local stance = 1
                local tb = BattleProxy.Instance:GetGamePlayerTable(roleid, roleid, 1, level, rank, stance)
                rawplayers[stance] = tb
            end
        else
            local iter = 1
            for i, rolecnf in ipairs(camp_list[camp1]) do
                local stance = rolecnf.stance or iter
                local tb = BattleProxy.Instance:GetGamePlayerTable(rolecnf.roleid, rolecnf.roleid, 1, rolecnf.level, rolecnf.rank, stance)
                rawplayers[stance] = tb
                iter = iter + 1
            end
        end

        local iter = 1
        for i, rolecnf in ipairs(camp_list[camp2]) do
            local stance = rolecnf.stance or iter
            local tb = BattleProxy.Instance:GetGamePlayerTable(0, rolecnf.roleid, 2, rolecnf.level, rolecnf.rank, stance)
            rawplayers[stance + 5] = tb
            iter = iter + 1
        end

        BattleProxy.Instance:EntryBattleScene_2(ACTIVITYID.TRAINING, rawplayers, gameinfo.seed)
    elseif id == 17 then
        local flag = tonumber(str)
        local status = flag == 1
        GameConfig.HASAI = { [1] = status, [2] = status }
    elseif id == 18 then
        local data_training_inf = require "Config.data_training_inf"
        local traininfo = data_training_inf.traininfo
        local camp_list = data_training_inf.camp_list

        local samecamp = traininfo.samecamp
        local scriptfallback_buff = traininfo.fallback_buff
        local min_level, max_level = table.unpack(traininfo.level[math.random(1, #traininfo.level)])
        local min_rank, max_rank = table.unpack(traininfo.rank[math.random(1, #traininfo.rank)])
        local round = traininfo.round
        local buff_list = traininfo.exbuff
                
        local args = string.split(str, ",")
        if args then
            round = tonumber(args[1]) or round
            max_level = tonumber(args[2]) or max_level
            min_level = max_level
            max_rank = tonumber(args[3]) or max_rank
            min_rank = max_rank
            buff_list = tonumber(args[4]) and {tonumber(args[4])} or buff_list
        end

        local fallback_buff_list = {}
        if scriptfallback_buff then
            local scriptfallback = require "Battle.game.script.scriptfallback"
            for buffid, _ in pairs(scriptfallback.buff) do
                table.insert(fallback_buff_list, buffid)
            end
        end


        local level_list = {}
        for i = min_level, max_level do
            table.insert(level_list, i)
        end
        local rank_list = {}
        for i = min_rank, max_rank do
            table.insert(rank_list, i)
        end

        local role_attr = ConfigManager.GetConfig("role_attr")
        local hero_static = ConfigManager.GetConfig("hero_static")
        local BattleProxy = require "Modules.Battle.BattleProxy"

        local roleid_list = {}
        for roleid, _ in pairs(role_attr) do
            local badd = true
            if hero_static[roleid] and hero_static[roleid].type == 2 then
                badd = false
            end
            if badd then
                table.insert(roleid_list, roleid)
            end
        end

        -- print('roleid_list', table.dump(roleid_list))

        math.randomseed(os.time())

        local round_player_list = {}
        for i = 1, round do
            local player_list = {}
            local markcamp
            for camp = 1, 2 do

                local camp_role_list = nil
                if traininfo.usecamplist then
                    local n = math.random(1, #camp_list)
                    while not samecamp and markcamp == n do
                        n = math.random(1, #camp_list)
                    end
                    markcamp = n
                    camp_role_list = camp_list[n].camp
                end

                for stance = 1, 5 do
                    local roleid = nil
                    if camp_role_list then
                        roleid = camp_role_list[stance]
                    else
                        roleid = roleid_list[math.random(1, #roleid_list)]
                    end
                    if roleid then
                        local level = level_list[math.random(1, #level_list)]
                        local rank = rank_list[math.random(1, #rank_list)]
                        local info = BattleProxy.Instance:GetGamePlayerTable(roleid, roleid, camp, level, rank, stance)
                        info.prop.buff_list = info.prop.buff_list or {}
                        local buffid = 900000 + (roleid * 10 + buff_list[math.random(1,#buff_list)])
                        -- print(roleid, level, rank, buffid)
                        table.insert(info.prop.buff_list, buffid)
                        if #fallback_buff_list > 0 then
                            table.insert(info.prop.buff_list, fallback_buff_list[math.random(1, #fallback_buff_list)])
                        end
                        player_list[stance + (camp-1)*5] = info
                    end
                end
            end
            table.insert(round_player_list, player_list)
        end
        
        BattleProxy.Instance:EntryBattleScene(ACTIVITYID.TEST_ALL_HERO, { playerlist = round_player_list[1],  round_player_list = round_player_list, infrep = data_training_inf.infrep })
    elseif id == 19 then
        local speed = tonumber(str)
        local BattleProxy = require "Modules.Battle.BattleProxy"
        BattleProxy.Instance:SpeedGame(speed)
    elseif id == 20 then
        local dtt = ConfigManager.GetConfig("data_training_test")
        local args = string.split(str, ",")
        local camp_args = {args and args[1] or 1, args and args[2] or 2}
        local round = args and args[3] or #dtt
        local infrep = {
            enable = args and args[4] and true or false,        -- 是否输出战报
            queue_output = true,  -- true:游戏结束后再一次性输出，false:每一场都有输出
        }

        local hero_static = ConfigManager.GetConfig("hero_static")
        local BattleProxy = require "Modules.Battle.BattleProxy"

        -- print('roleid_list', table.dump(roleid_list))

        math.randomseed(os.time())

        local round_player_list = {}
        for i = 1, round do
            local player_list = {}
            for camp = 1, 2 do
                local roundinfo = args and dtt[tonumber(camp_args[camp])] or dtt[i]
                local camp_role_list = roundinfo.camp
                local level_list = roundinfo.level
                local rank_list = roundinfo.rank
                local item_list = roundinfo.item
                local equips_list = roundinfo.equips
    
                for stance = 1, 5 do
                local roleid = nil
                    if camp_role_list then
                        roleid = camp_role_list[stance]
                        roleid = camp == 2 and 1101 or roleid
                    -- else
                    --     roleid = roleid_list[math.random(1, #roleid_list)]
                    end
                    
                    if roleid then
                        local level = level_list and level_list[stance] or 100
                        local rank = rank_list and rank_list[stance] or 100
                        local equips = equips_list and equips_list[stance] or {}
                        local info = BattleProxy.Instance:GetGamePlayerTable(roleid, roleid, camp, level, rank, stance, nil, nil, equips)
                        info.prop.buff_list = info.prop.buff_list or {}
                        table.insert(info.prop.buff_list, 900031)
                        player_list[stance + (camp-1)*5] = info
                    end
                end
            end
            table.insert(round_player_list, player_list)
        end
        BattleProxy.Instance:EntryBattleScene(ACTIVITYID.TEST_ALL_HERO, { playerlist = round_player_list[1],  round_player_list = round_player_list, infrep = infrep })
    end

    LuaLayout.Instance:CloseWidget(UIWidgetNameDef.CheatView)
end

return CheatPoolPanel
 