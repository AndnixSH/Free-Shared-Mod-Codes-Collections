local FormationDef = require "Modules.Formation.FormationDef"
local FormationProxy = require "Modules.Formation.FormationProxy"
local HeroItem = require "Core.Implement.UI.Class.HeroItem"
local ClistRender = require "Core.Implement.UI.Class.ClistRender"
local ClistItem = require "Core.Implement.UI.Class.ClistItem"
local ObjPoolRender = require "Core.Implement.UI.Class.ObjPoolRender"
local HeroProxy = require "Modules.Hero.HeroProxy"
local BattleDef = require "Modules.Battle.BattleDef"
local CrystalProxy = require "Modules.Crystal.CrystalProxy"

local BattleSelectViewFormationItem = BattleSelectViewFormationItem or BaseClass(ClistItem)

function BattleSelectViewFormationItem:Load(obj)
	self.go = obj
	self:InitUI()
end

function BattleSelectViewFormationItem:InitUI()
	self.clickBtn = self:GetComponent(self.go, "CButton")
	self.clickBtn:AddMouseDown(function()
		self.bBtnDown = true
		self.blongCilck = false
	end)

	self.clickBtn:AddClick(function()
		if self.data then
			if self.blongCilck then
			else
				if not self.data.canSelGuildChaos then
					GameLogicTools.ShowMsgTips("Chaos_view_1021")
					return
				end

				if BattleSelectViewFormationItem.target then
					BattleSelectViewFormationItem.callback(BattleSelectViewFormationItem.target, self.data.bselect, self.data.formation_count, self.data.formations, self.data.index, self.data.bselectHero, self.data.replaceHeroDics)
				end
			end
		end
	end)

	self.clickBtn:AddLongClick(function()
		if self.data then
			if self.data.type == FormationDef.FormationType.NormalType then
				if self.blongCilck~=nil and self.blongCilck == false then
					self.blongCilck = true
					local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleFormationMenuView)
					if view then
						view.type = 2
						view.data = self.data
						view.position = self.go.transform.position
						view:OpenView()
					end
				end
			end
		end
	end)

	self.titleNameLab = self:GetChildComponent(self.go, "title/CLabel_title", "CLabel")
	self.heroItemObj = self:GetChild(self.go, "CHorizontalItem")
	self.heroItems = {}
	for i=1,5 do
		local item = {}
		item.heroItemObj = self:GetChild(self.heroItemObj, string.format("item%d/Heroitem", i))
		item.heroClass = HeroItem.New(item.heroItemObj)
		item.noneObj = self:GetChild(self.heroItemObj, string.format("item%d/CSprite_none", i))
		table.insert(self.heroItems, item)
	end

	self.defaultBackObj = self:GetChild(self.go, "CSprite_back")
	self.selectObj = self:GetChild(self.go, "CSprite_select")

	self.lockObj = self:GetChild(self.go, "CSprite_lock")
	self.lockObj:SetActive(false)

end

function BattleSelectViewFormationItem:SetData(data)
	self.data = data
	self.lockObj:SetActive(data.type == FormationDef.FormationType.SpecialType and true or false)
	self.titleNameLab.text = self.data.name
	self.selectObj:SetActive(self.data.bselect)
	self.defaultBackObj:SetActive(self.data.bselect == false and true or false)
	self.data.bselectHero = false  --竞技场是否有已选择的英雄
	self.data.replaceHeroDics = {} --需要替换的竞技场已上阵的英雄 
	self.data.canSelGuildChaos = true --该编队能否被选中(混沌裂隙玩法)

	local onlyRace = self.data.towerRaceType and self.data.towerRaceType > 0 and self.data.towerRaceType or nil
	
	for i,item in ipairs(self.heroItems) do
		item.heroItemObj:SetActive(self.data.formations[i] ~= nil and true or false)
		item.noneObj:SetActive(self.data.formations[i] == nil and true or false)
		if self.data.formations[i] then
			local heroData = HeroProxy.Instance:GetHeroDataByUid(self.data.herouids[i]) --self.data.formations[i] 这个值可能是herouid，或者是配置roleid
			local heroCfg = heroData and HeroProxy.Instance:GetRoleCfgByConfigId(heroData.roleid)
			if self.data.hadselectRoleDic and next(self.data.hadselectRoleDic) then
				if self.data.type == FormationDef.FormationType.SpecialType then
					local roleid
					if heroData then
						roleid = heroData.roleid
					else
						roleid = self.data.roleIds[i]
					end
					heroCfg = HeroProxy.Instance:GetRoleCfgByConfigId(roleid)
					item.heroClass:SetData({roleid = roleid})
					
					local block = self.data.hadselectRoleDic[roleid] ~= nil and true or false
					if block then
						item.heroClass:SetLockObj(block)
						self.data.bselectHero = true
						self.data.replaceHeroDics[roleid] = i
					else
						item.heroClass:SetSelectItem(false)
						item.heroClass:SetLevelObjActive(false)
						item.heroClass:SetRankSprite()
					end
				else
					if heroData then
						item.heroClass:SetData(heroData)
						local block = self.data.hadselectRoleDic[heroData.roleid] ~= nil and true or false
						if block then
							item.heroClass:SetLockObj(block)
							self.data.bselectHero = true
							self.data.replaceHeroDics[heroData.roleid] = i
						else
							item.heroClass:SetSelectItem(self.data.bselect)
						end
					end
				end
			else
				if self.data.type == FormationDef.FormationType.SpecialType then
					local roleid
					if heroData then
						roleid = heroData.roleid
					else
						roleid = self.data.roleIds[i]
					end
					heroCfg = HeroProxy.Instance:GetRoleCfgByConfigId(roleid)
					item.heroClass:SetData({roleid = roleid})
					item.heroClass:SetSelectItem(false)
					item.heroClass:SetLevelObjActive(false)
					item.heroClass:SetRankSprite()
					
				else
					if heroData then
						item.heroClass:SetData(heroData)
						item.heroClass:SetSelectItem(self.data.bselect)

						if BattleSelectViewFormationItem.target.activity_id == ACTIVITYID.GUILD_CHAOS then
							local isTopFiveOrList = CrystalProxy.Instance:IsTopFiveOrList(heroData.herouid)
							if isTopFiveOrList then
								item.heroClass:SetLockObj(false)
							else
								item.heroClass:SetLockObj(true)
								self.data.canSelGuildChaos = false
							end
						end
					end
				end
			end
			--种族塔屏蔽编队非种族英雄
			if onlyRace and heroCfg and onlyRace ~= heroCfg.race then
				item.heroClass:SetLockObj(true)
			end
			
			if heroData and self.getOtherTeamListFunc then
				local other_team_heros, other_team_hero_map, other_team_hero_roleid_map = self.getOtherTeamListFunc()
				if #other_team_heros > 0 then
					if other_team_hero_map[heroData.herouid] or other_team_hero_roleid_map[heroData.roleid] then
						item.heroClass:SetLockObj(true)
					end
				end
			end
		end
	end
end

function BattleSelectViewFormationItem:UpdateItem(formationInfos)
	if self.data then
		for i,v in ipairs(formationInfos) do
			if v.index == self.data.index then
				self:SetData(v)
				break
			end
		end
	end
end

function BattleSelectViewFormationItem:UpdateItemName(index, name)
	if self.data.index == index then
		self.data.name = name
		self.titleNameLab.text = self.data.name
	end
end


function BattleSelectViewFormationItem:Close()
end

function BattleSelectViewFormationItem:Destroy()
end












local BattleSelectViewFormationPanel = BattleSelectViewFormationPanel or BaseClass(GameObjFactor)

function BattleSelectViewFormationPanel:__init(obj)
	self.go = obj
	self.infoTipsObj = self:GetChild(obj, "info/tips")
	self.infoTipsObj:SetActive(false)
	self.infoBtn = self:GetChildComponent(obj, "info/CButton_info", "CButton")
	self.infoBtn:AddClick(function()
		self.infoTipsObj:SetActive(true)
		self:SetDepth(self.infoTipsObj , self:GetNextDepth())
	end)

	self.itemboxcollider = self:GetChildComponent(self.infoTipsObj, "Black", "CBoxCollider")
   	self.itemboxcollider:AddClick(function(go)
   	    self.infoTipsObj:SetActive(false)
   	    -- self:SetDepth(self.infoTipsObj, 0)
   	end)

   	
	self.clist = self:GetChildComponent(obj, "CList_hero", "CList")
	self.clistRender = ClistRender.New()
	self.clistRender:Load(self.clist, BattleSelectViewFormationItem)

	BattleSelectViewFormationItem.target = self
	BattleSelectViewFormationItem.callback = self.OnClickItem
	
	self.bopen = false
	
	self.saveBtn = self:GetChildComponent(obj, "save", "CButton")
	self.saveSp = self:GetComponent(self.saveBtn.gameObject, "CSprite")
	self.saveLab = self:GetChildComponent(self.saveBtn.gameObject, "label", "CLabel")
	self.saveBtn:AddClick(function()
		if self.default_count > 0 then
			if self.bSame then
				GameLogicTools.ShowMsgTips(FormationDef.LanguageKey.FormationKey4)
			else
				local infos = {}
				local bHireHero = false
				local replaceFormation = self:ReplaceUids(self.defaultFormations,true)
				for pos,herouid in pairs(self.defaultFormations) do
					bHireHero = self:IsHireHero(herouid)
					if not bHireHero then
						table.insert(infos, {replaceFormation[pos], pos})
					else
						break
					end
				end
				if not bHireHero then
					FormationProxy.Instance:Send20401(self.lastName, infos)
				else
					GameLogicTools.ShowMsgTips(FormationDef.LanguageKey.FormationKey9)
				end
			end
		else
			GameLogicTools.ShowMsgTips(FormationDef.LanguageKey.FormationKey3)
		end
	end)

	self.noneObj = self:GetChild(obj, "CLabel_none")
end

function BattleSelectViewFormationPanel:IsOpen()
	return self.bopen
end

function BattleSelectViewFormationPanel:AddCallBack(func)
	self.callback = func
end

function BattleSelectViewFormationPanel:OnClickItem(bselect, formation_count, formations, index, bselectHero, replaceRoleIdDic)
	if self.callback then
		self.callback(bselect, formation_count, formations, index, bselectHero, replaceRoleIdDic)
	end

	-- self:SetData(formation_count, formations, self.formationList)
end

--特殊编队 roleid 转换成 最高战力herouid,没有英雄就存roleid
function BattleSelectViewFormationPanel:GetReplaceRoleFormations(formations)
	local _formations = {}
	for stance, roleid in pairs(formations) do
		local herouid = self:GetHighestFightHeroByRoleId(roleid)
		if herouid then
			_formations[stance] = herouid
		else
			_formations[stance] = roleid
		end
	end
	return _formations
end

--巨龙 和 剧情 副本内 HeroUID置换(巨龙ID 换 背包ID)
function BattleSelectViewFormationPanel:ReplaceUids(formations,invert)
	--print("_GetHeroDataByUid----------->",herouid)
	if self.activity_id ~= ACTIVITYID.MAZE and self.activity_id ~= ACTIVITYID.STORYLINE and self.activity_id ~= ACTIVITYID.ACTIVITY then 
		return formations
	end
	local temp_tb = {}
	for stance, herouid in pairs(formations) do
		for _, herodata in ipairs(self.heroInfos) do
			local target_herouid = invert and herodata.herouid or herodata.fromuid
			if target_herouid == herouid then
				temp_tb[stance] = invert and herodata.fromuid or herodata.herouid
			end
		end
	end
	return temp_tb
end

--雇佣兵不能编队
function BattleSelectViewFormationPanel:GetHighestFightHeroByRoleId(roleId)
	local fight, herouid
	for i,herodata in ipairs(self.heroInfos) do
		if herodata.roleid == roleId then
			local herodatas = {}
			table.insert(herodatas, herodata)
			local _fightstr, _fight = HeroProxy.Instance:GetHeroFight(herodatas)
			if fight then
				if _fight > fight then
					fight = _fight
					herouid = herodata.herouid
				end 
			else
				fight = _fight
				herouid = herodata.herouid
			end
		end
	end
	return herouid
end

function BattleSelectViewFormationPanel:IsHireHero(herouid)
	for _, herodata in ipairs(self.heroInfos) do
		if herodata.herouid == herouid and herodata.hire_hero_type == BattleDef.Hire_Hero_Type.Hire_Hero then
			return herodata
		end	
	end	
end



function BattleSelectViewFormationPanel:GetLastName(formationList)
	local name = ""
	for i,v in ipairs(formationList) do
		if v.state == FormationDef.Formation_State.CanEditor then
			name = v.name
			break
		end
	end
	return name
end

--defaultFormations:{[pos] = herouid}
function BattleSelectViewFormationPanel:Open(default_count, defaultFormations, formationList, heroInfos, notTween , activity_id, towerRaceType, getOtherTeamListFunc)
	-- print("BattleSelectViewFormationPanel open ========", default_count, table.dump(defaultFormations), table.dump(formationList), debug.traceback())
	BattleSelectViewFormationItem.target = self
	BattleSelectViewFormationItem.callback = self.OnClickItem
	BattleSelectViewFormationItem.getOtherTeamListFunc = getOtherTeamListFunc

	self.bopen = true
	self.go:SetActive(true)
	self.infoTipsObj:SetActive(false)
	self.activity_id = activity_id
	self.default_count = default_count
	self.defaultFormations = defaultFormations
	self.formationList = formationList
	self.heroInfos = heroInfos
	self.towerRaceType = activity_id == ACTIVITYID.TOWER and towerRaceType or 0
	self.formationInfos, self.bSame = self:ConstructFormationInfos(formationList)
	self.lastName = self:GetLastName(self.formationList)
	self.saveSp.Gray = self.bSame == true and true or false
	self.saveLab.Gray = self.bSame == true and true or false
	self.clistRender:ClearData()
	self.clistRender:AppendDataList(self.formationInfos, notTween)
	self.noneObj:SetActive(#self.formationInfos == 0 and true or false)
end

function BattleSelectViewFormationPanel:SetData(default_count, defaultFormations, formationList, heroInfos, index, activity_id)
	-- print("BattleSelectViewFormationPanel========", default_count, index, table.dump(defaultFormations), table.dump(formationList))
	self.bopen = true
	self.go:SetActive(true)
	self.infoTipsObj:SetActive(false)
	self.activity_id = activity_id
	self.default_count = default_count
	self.defaultFormations = defaultFormations
	self.formationList = formationList
	self.heroInfos = heroInfos
	self.formationInfos, self.bSame = self:ConstructFormationInfos(formationList, index)
	self.lastName = self:GetLastName(self.formationList)
	self.saveSp.Gray = self.bSame == true and true or false
	self.saveLab.Gray = self.bSame == true and true or false
	self.clistRender:ExecuteMethod("UpdateItem", self.formationInfos)
	self.noneObj:SetActive(#self.formationInfos == 0 and true or false)
end

function BattleSelectViewFormationPanel:UpdateItemName(index, name)
	self.clistRender:ExecuteMethod("UpdateItemName", index, name)
end

--雇佣兵不能编队
function BattleSelectViewFormationPanel:ConstructFormationInfos(formationList, index)
	local ArenaProxy = require "Modules.Arena.ArenaProxy"
	local curIndex, infos = ArenaProxy.Instance:GetArenaSelectInfos()

	local hadSelectHeros = {}
	local hadselectRoleDic = {}
	local hadselectHerouidDic = {}
	if curIndex and infos then
		-- print("infos===", curIndex, table.dump(infos))
		for idx,info in ipairs(infos) do
			if idx ~= curIndex then
				for i,value in ipairs(info) do
					if type(value) == "table" then
						local item = {i, value.herouid, value.fromuid, value.roleid}
						table.insert(hadSelectHeros, item)
						hadselectRoleDic[value.roleid] = item
						hadselectHerouidDic[value.herouid] = item
					end
				end
			end
		end
	end
	-- print("hadselectRoleDic===", table.dump(hadselectRoleDic))
	local fomationInfos = {}
	local bsame = false
	for k,info in ipairs(formationList) do
		if info.state == FormationDef.Formation_State.Exist then
			local item = {}
			item.state = info.state
			item.type = info.type
			item.index = info.index
			item.name = info.name
			item.formation_count = info.formation_count
			item.bselect = false
			item.bselectHero = false --竞技场上阵过队列中的英雄
			item.hadselectRoleDic = hadselectRoleDic
			item.towerRaceType = self.towerRaceType
			if item.type == FormationDef.FormationType.SpecialType then
				--特殊编队info.formations 是roleid
				item.formations = self:GetReplaceRoleFormations(info.formations)
				item.roleIds = info.formations
			else
				-- 在非巨龙下 两者相同
				item.formations = self:ReplaceUids(info.formations) --巨龙下特殊的uid
			end
			item.herouids = info.formations -- 巨龙下英雄背包UID

			if item.type == FormationDef.FormationType.NormalType then
				if info.formation_count == self.default_count then
					local formation = {}
					local _bsame = true
					for pos,herouid in pairs(self.defaultFormations) do
						if not item.formations[pos] then
							_bsame = false
						elseif item.formations[pos] ~= herouid then
							_bsame = false
						end
					end
					if _bsame then
						bsame = true
						item.bselect = true
					end
				end
			end

			if index then
				item.bselect = index == item.index and true or false
			end
			table.insert(fomationInfos, item)
		end
	end
	return fomationInfos, bsame
end

function BattleSelectViewFormationPanel:Close()
	self.bopen = false
	self.go:SetActive(false)
	self.clistRender:ClearData()
end

function BattleSelectViewFormationPanel:Destroy()
	self.bopen = false
	self.clistRender:ClearData()
end



return BattleSelectViewFormationPanel