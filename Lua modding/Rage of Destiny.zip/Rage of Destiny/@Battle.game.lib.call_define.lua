calldef = 
{
    --[[*******************精灵CALL*******************]]
    life    = "life",
    skill   = "skill",
    buff    = "buff",
    suffer  = "suffer",
    hp      = "hp",
    mp      = "mp",
    state   = "state",    -- state状态机{idle,skill,suffer,death}
    ai      = "ai",       -- ai状态机
    view    = "view",     -- view 管理转发玩家视图消息
    body    = "body",      
    taunt   = "taunt",
    --[[*******************精灵CALL*******************]]



    --[[*******************玩法CALL*******************]]
    input   = "input",
    born    = "born",
    --[[*******************玩法CALL*******************]]
}