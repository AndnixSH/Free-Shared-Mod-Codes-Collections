local EquipProxy = EquipProxy or BaseClass(BaseProxy)
function EquipProxy:__init(name)
    EquipProxy.Instance = self
    self:AddProto(15100, self.On15100) --穿装备
    self:AddProto(15101, self.On15101) --脱装备
    self:AddProto(15102, self.On15102) --强化装备
    self:AddProto(15103, self.On15103) --装备升阶
    self:AddProto(15104, self.On15104) --装备重铸
    self:AddProto(15105, self.On15105) --装备物品数量改变
    self:AddProto(15106, self.On15106) --一键穿装备
    self:AddProto(15107, self.On15107) --是否保存重铸
    self:AddProto(15108, self.On15108) --重铸结果
    self:AddProto(15109, self.On15109) --最近升阶装备列表 5个
    self.data = {}
    self.data.cacheEquipAttrs = {}
    self.data.upgradeIds = {}
    self.data.exclusiveIds = {}
    --装备强化石
    self.EquipStones = {
        [1] = { goodsTypeId = 404011, quality = 3 },
        [2] = { goodsTypeId = 404021, quality = 5 },
        -- [3] = {goodsTypeId = 404031, quality =7},
    }
    self.materrialId = 405011  --重铸

    --神器强化材料对应的资源id
    self.artifactMaterrials ={
        [402011] = "402011",
        [402021] = "402021",
        [402031] = "402031",
        [402041] = "402041",
        [402051] = "402051",
        [402061] = "402061",
        [402071] = "402071",
        [702001] = "jinbi"
    }

end

function EquipProxy:__delete()
    self.data.cacheEquipAttrs = nil
    self.data.upgradeIds = nil
    self.data.exclusiveIds = nil
    self.data = nil
end

function EquipProxy:Send15100(heroUid, equipId)
    local encoder = NetEncoder.New()
    encoder:Encode("I4", heroUid)
    encoder:Encode("I4", equipId)
    self:SendMessage(15100, encoder)
    -- print("Send15100==", heroUid, equipId)
end

function EquipProxy:On15100(decoder)
    local result = decoder:Decode("I1")
    -- print("on15100===", result)
    GameLogicTools.ShowErrorCode(15100, result)
    if result == 0 then
        local EquipDef = require "Modules.Equip.EquipDef"
        self:ToNotify(self.data, EquipDef.NotifyDef.Update_EquipAttr_Change, { type = 0 })
    end
end

function EquipProxy:Send15101(heroUid, positions)
    local encoder = NetEncoder.New()
    encoder:Encode("I4", heroUid)
    encoder:EncodeList("I4", positions)
    self:SendMessage(15101, encoder)
    -- print("Send15101==", heroUid, table.dump(positions))
end

function EquipProxy:On15101(decoder)
    local result = decoder:Decode("I1")
    GameLogicTools.ShowErrorCode(15101, result)
    if result == 0 then
        local EquipDef = require "Modules.Equip.EquipDef"
        self:ToNotify(self.data, EquipDef.NotifyDef.Update_EquipAttr_Change, { type = 1 })
    end
    -- print("On15101===", result)
end

function EquipProxy:Send15102(equipId, goodslist, equiplist)
    local encoder = NetEncoder.New()
    encoder:Encode("I4", equipId)
    encoder:EncodeList("I4I2", goodslist)
    encoder:EncodeList("I4I2", equiplist)
    self:SendMessage(15102, encoder)
end

function EquipProxy:On15102(decoder)
    local result = decoder:Decode("I1")
    if result == 0 then
        local EquipDef = require "Modules.Equip.EquipDef"
        self:ToNotify(self.data, EquipDef.NotifyDef.Update_EnhanceEquip)
    end
    GameLogicTools.ShowErrorCode(15102, result)
end

function EquipProxy:Send15103(equipId)
    -- print("Send15103==", equipId)
    local encoder = NetEncoder.New()
    encoder:Encode("I4", equipId)
    self:SendMessage(15103, encoder)
end

function EquipProxy:On15103(decoder)
    local result = decoder:Decode("I1")
    if result == 0 then
        local EquipDef = require "Modules.Equip.EquipDef"
        self:ToNotify(self.data, EquipDef.NotifyDef.Update_Strenthen)
    end
    -- print("On15103=", result)
    GameLogicTools.ShowErrorCode(15103, result)
end

function EquipProxy:Send15104(equipId)
    local encoder = NetEncoder.New()
    encoder:Encode("I4", equipId)
    self:SendMessage(15104, encoder)
end

function EquipProxy:On15104(decoder)

    local result = decoder:Decode("I1")
    local race
    if result == 0 then
        race = decoder:Decode("I1")
    end
    GameLogicTools.ShowErrorCode(15104, result)
    local EquipDef = require "Modules.Equip.EquipDef"
    self:ToNotify(self.data, EquipDef.NotifyDef.Update_Reset, { result = result, race = race })
end

function EquipProxy:On15105(decoder)
    local goodsId, goodsTypeId, goodsCount = decoder:Decode("I4I4I4")
    local goodsEnhanceGrade, goodsEnhanceExp, equippedHeroId = decoder:Decode("I2I4I4")
    local BagProxy = require "Modules.Bag.BagProxy"
    local EquipDef = require "Modules.Equip.EquipDef"
    local goodsCfg = BagProxy.Instance:GetGoodsCfgById(goodsTypeId)
    local equipCfg = self:GetHeroEquipById(goodsTypeId)

    local item = {}
    item.goodsId, item.goodsTypeId, item.goodsCount = goodsId, goodsTypeId, goodsCount
    item.goodsEnhanceGrade, item.goodsEnhanceExp, item.equippedHeroId = goodsEnhanceGrade, goodsEnhanceExp, equippedHeroId
    item.isEquip, item.equipPart, item.equipClass = true, equipCfg.position, equipCfg.class
    item.type, item.subtype, item.quality = goodsCfg.type, goodsCfg.subtype, goodsCfg.quality

    BagProxy.Instance:EquipGoodsDataKeyTableChange(goodsId, goodsCount, equipCfg.position, equipCfg.class, item)
    BagProxy.Instance:EquipGoodsInfoTableChange(goodsId, goodsCount, item)
    self:GetHeroTabRedDot(true)
    -- print("On15105========", goodsId, goodsTypeId, goodsCount, table.dump(BagProxy.Instance.normalGoodsInfo), table.dump(BagProxy.Instance.equipGoodsInfo), table.dump(BagProxy.Instance.equipDataInfos))
    self:ToNotify(self.data, EquipDef.NotifyDef.Update_EquipGoods, goodsId)
end

function EquipProxy:Send15106(heroId)
    local encoder = NetEncoder.New()
    encoder:Encode("I4", heroId)
    --print("send15106==", heroId)
    self:SendMessage(15106, encoder)
end

function EquipProxy:On15106(decoder)
    local result = decoder:Decode("I1")
    if result == 0 then
        local EquipDef = require "Modules.Equip.EquipDef"
        self:ToNotify(self.data, EquipDef.NotifyDef.Update_EquipAttr_Change, { type = 6 })
    end
    GameLogicTools.ShowErrorCode(15106, result)
end

function EquipProxy:Send15107(handle, equipId)
    -- print("Send15107==", handle, equipId)
    local encoder = NetEncoder.New()
    encoder:Encode("I1I4", handle, equipId)
    self:SendMessage(15107, encoder)
end

function EquipProxy:On15107(decoder)
    local result = decoder:Decode("I1")
    if result == 0 then
        local EquipDef = require "Modules.Equip.EquipDef"
        self:ToNotify(self.data, EquipDef.NotifyDef.Update_Reset_Confirm)
    end
    -- print("On15107==", result)
    GameLogicTools.ShowErrorCode(15107, result)
end

function EquipProxy:Send15108(equipId)
    local encoder = NetEncoder.New()
    encoder:Encode("I4", equipId)
    self:SendMessage(15108, encoder)
end

function EquipProxy:On15108(decoder)
    local equipId = decoder:Decode("I4")
    local EquipDef = require "Modules.Equip.EquipDef"
    self:ToNotify(self.data, EquipDef.NotifyDef.Update_Reset_Result, { equipId = equipId })
end

function EquipProxy:Send15109()
    self:SendMessage(15109)
end

function EquipProxy:On15109(decoder)
    local infos = {}
    local exclusives = {}
    local count = decoder:Decode("I2")
    for i = 1, count do
        local equipId = decoder:Decode("I4")
        table.insert(infos, equipId)
    end
    count = decoder:Decode("I2")
    for i = 1, count do
        local equipId = decoder:Decode("I4")
        table.insert(exclusives, equipId)
    end
    self.data.upgradeIds = infos
    self.data.exclusiveIds = exclusives
    -- print("On15109==", table.dump(infos), table.dump(exclusives))
    local EquipDef = require "Modules.Equip.EquipDef"
    self:ToNotify(self.data, EquipDef.NotifyDef.Update_Strenthen_Ids, { infos = infos, exclusiveIds = exclusives })
end

function EquipProxy:GetHeroEquipConfig()
    local config = ConfigManager.GetConfig("data_equipment")
    return config
end

function EquipProxy:GetHeroEquipById(equipId)
    local config = self:GetHeroEquipConfig()
    if config[equipId] then
        return config[equipId]
    else
        print("equipId is nil, equipId: ", equipId)
    end
end

--下一升阶物品id
function EquipProxy:GetNestStrengthenGoodsId(goodsId)
    local cfg = self:GetHeroEquipById(goodsId)
    if cfg.strengthen then
        return cfg.strengthen
    end
end

--升阶消耗道具
function EquipProxy:GetStregthenMaterrial(quality, class)
    local cfg = ConfigManager.GetConfig("data_strengthen")
    for i, v in ipairs(cfg) do
        if v.quality == quality and v.class == class then
            return v.expend, v.num
        end
    end
end

--装备部位,职业 物品
function EquipProxy:GetEquipPartGoodsByPartCareer(part, class)
    local infos = {}
    local BagProxy = require "Modules.Bag.BagProxy"
    local equipsInfo = BagProxy.Instance:GetEquipGoodsInfo()
    for i, goodsInfo in pairs(equipsInfo) do
        local equipCfg = self:GetHeroEquipById(goodsInfo.goodsTypeId)
        local isFit = false
        if equipCfg then
            if part and not class and part == equipCfg.position then
                isFit = true
            elseif not part and class and class == equipCfg.class then
                isFit = true
            elseif part and class and part == equipCfg.position and class == equipCfg.class then
                isFit = true
            end
        end
        if isFit then
            table.insert(infos, goodsInfo)
        end
    end
    return infos
end

function EquipProxy:GetEquipEnHanceConfig()
    local config = ConfigManager.GetConfig("data_enhance")
    return config
end

function EquipProxy:GetArtifactConfig()
    local config = ConfigManager.GetConfig("data_artifact")
    return config
end

function EquipProxy:GetArtifactConfigByIdGrade(goodsTypeId, goodsEnhanceGrade)
    local cfg = self:GetArtifactConfig()
    for k,v in pairs(cfg) do
        if v.goods_id == goodsTypeId and v.current_grade == goodsEnhanceGrade then
            return v
        end
    end
end

--装备品质 最高星数
function EquipProxy:GetEquipMaxStarByQuality(quality)
    local config = self:GetEquipEnHanceConfig()
    local maxGrade = 0
    for k, info in pairs(config) do
        if info.quality == quality then
            if maxGrade <= info.target_grade then
                maxGrade = info.target_grade
            end
        end
    end
    return maxGrade
end

function EquipProxy:GetEquipExclusiveConfigInfo(exclusive_type_id)
    local equip_exclusive_config = faceConfig["data_exclusive"]
    local equip_excluseve_config_info = {}

    for i, exclusive_info in ipairs(equip_exclusive_config) do
        if exclusive_info.goods_id == exclusive_type_id then
            equip_excluseve_config_info[exclusive_info.current_grade] = exclusive_info
        end
    end

    return equip_excluseve_config_info
end

function EquipProxy:GetEquipArtifactConfigInfo(artifact_type_id)
    local equip_artifact_config = faceConfig["data_artifact"] --game.cfg["data_artifact"]
    local equip_artifact_config_info = {}

    for i, artifact_info in ipairs(equip_artifact_config) do
        if artifact_info.goods_id == artifact_type_id then
            equip_artifact_config_info[artifact_info.current_grade] = artifact_info
        end
    end

    return equip_artifact_config_info
end

function EquipProxy:GetAttrPercentByQualityGrade(quality, grade)
    local config = self:GetEquipEnHanceConfig()
    for i, v in ipairs(config) do
        if v.quality == quality and v.target_grade == grade then
            return v.percent
        end
    end
    return 0  
end

function EquipProxy:GetEquipGradeContaintExpBy(quality, grade)
    local exp = 0
    local config = self:GetEquipEnHanceConfig()
    for i, v in ipairs(config) do
        if v.quality == quality then
            if v.target_grade <= grade then
                exp = exp + v.exp
            end
        end
    end
    return exp
end

function EquipProxy:GetEquipQualityColorConfig()
    local config = ConfigManager.GetConfig("data_equiprank")
    return config
end

function EquipProxy:GetEquipQualityColorByQuality(quality)
    local config = self:GetEquipQualityColorConfig()
    for k, info in pairs(config) do
        if info.rank == quality then
            return info
        end
    end
    return nil
end

function EquipProxy:GetEquipQualityColor(quality, text)
    local cfg = self:GetEquipQualityColorByQuality(quality)
    if cfg then
        text = string.format("<color=%s>%s</color>", cfg.color, text)
    end
    return text
end

--基础属性显示
function EquipProxy:ShowEquipAttrLab(value, quality, grade, heroTypeId, goodsTypeId)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local BagProxy = require "Modules.Bag.BagProxy"
    local LanguageUtil = require "First.Util.LanguageUtil"
    -- local attrNameColor = "<color=#ffffffcc>%s</color>"  --属性名
    -- local defaultColor = "<color=#ffffffcc>%s</color>"  --白值
    local attrNameColor = "%s"  --属性名
    local defaultColor = "%s"  --白值
    local addAttr = "<color=#b1f278>+%s</color>"   --属性加成
    local addRaceAttr = 0  --种族加成

    local lab1, lab2, lab3 = "", "", "" --属性分成3部分展示
    local heroRaceCfg
    if heroTypeId then
        heroRaceCfg = HeroProxy.Instance:GetRoleCfgByConfigId(heroTypeId)
    end
    local goodsCfg
    if goodsTypeId then
        goodsCfg = BagProxy.Instance:GetGoodsCfgById(goodsTypeId)
    end
    local attrCfg = HeroProxy.Instance:GetAttrValueCfgByType(value[1])
    local str = ""
    if attrCfg then
        str = LanguageUtil.GetWord(attrCfg.name)
    end
    str = string.format(attrNameColor, str)
    lab1 = string.format(attrNameColor, str)
    -- str = str .. string.format(defaultColor, value[2])

    local attr_value = self:GetBasicEquipAttrValue(value[1], value[2])
    local show_attrvalue = self:GetBasicEnhanceFormat(value[1], attr_value)
    str = str .. string.format(defaultColor, show_attrvalue)
    lab2 = string.format(defaultColor, show_attrvalue)

    local _value = self:EquipEnhanceAddAttrValue(attr_value, quality, grade, false)

    if heroRaceCfg and goodsCfg then
        local raceAttrAdd = self:EquipRaceAddAttrValue(attr_value, false)
        addRaceAttr = (heroRaceCfg.race == goodsCfg.race) and raceAttrAdd or 0
        _value = _value + addRaceAttr
    end
    if _value == 0 then
    else
        -- str = str .. string.format(addAttr, _value)
        local show_attrvalue = self:GetBasicEnhanceFormat(value[1], _value)
        str = str .. string.format(addAttr, show_attrvalue)
        lab3 = string.format(addAttr, show_attrvalue)
    end

    return str, lab1, lab2, lab3
end

--基础装备值 
function EquipProxy:GetBasicEquipAttrValue(_type, value)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local _value = value
    local _attrCfg = HeroProxy.Instance:GetAttrValueCfgByType(_type)
    if _attrCfg.conversion then
        _value = _value / _attrCfg.conversion
    end
    return _value
end

--基础装备属性显示格式
function EquipProxy:GetBasicEnhanceFormat(_type, value)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local _attrCfg = HeroProxy.Instance:GetAttrValueCfgByType(_type)
    if _attrCfg.integer == 1 then
        value = math.ceil(value)
    end
    local show_value = string.format(_attrCfg.valuestring, value)
    return show_value
end

function EquipProxy:GetPerEquipAttrLab(value, quality, grade, heroTypeId, goodsTypeId)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local BagProxy = require "Modules.Bag.BagProxy"
    local defaultValue = value[2]
    local addRaceAttr = 0  --种族加成

    -- local attr_value = HeroProxy.Instance:GetAttrValueCfgByType(value[1])
    -- local value1 = value[2] * attr_value.value

    local enhanceAdd = self:EquipEnhanceAddAttrValue(defaultValue, quality, grade)  --强化加成
    if heroTypeId then
        heroRaceCfg = HeroProxy.Instance:GetRoleCfgByConfigId(heroTypeId)
    end
    if goodsTypeId then
        goodsCfg = BagProxy.Instance:GetGoodsCfgById(goodsTypeId)
    end
    if heroRaceCfg and goodsCfg then
        local raceAttrAdd = self:EquipRaceAddAttrValue(defaultValue)
        addRaceAttr = (heroRaceCfg.race == goodsCfg.race) and raceAttrAdd or 0
    end
    local count = defaultValue + enhanceAdd + addRaceAttr
    return count
end

--通过 data_attrvalue 换算后得值 value / cfg.conversion
function EquipProxy:GetPerEquipAttrLabByConversion(value, quality, grade, heroTypeId, goodsTypeId)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local BagProxy = require "Modules.Bag.BagProxy"
    local defaultValue = value[2]
    local addRaceAttr = 0  --种族加成

    local attr_value = self:GetBasicEquipAttrValue(value[1], defaultValue) --value[2] 换算后得值

    local enhanceAdd = self:EquipEnhanceAddAttrValue(attr_value, quality, grade, false)  --强化加成

    if heroTypeId then
        heroRaceCfg = HeroProxy.Instance:GetRoleCfgByConfigId(heroTypeId)
    end
    if goodsTypeId then
        goodsCfg = BagProxy.Instance:GetGoodsCfgById(goodsTypeId)
    end
    if heroRaceCfg and goodsCfg then
        local raceAttrAdd = self:EquipRaceAddAttrValue(attr_value, false)
        addRaceAttr = (heroRaceCfg.race == goodsCfg.race) and raceAttrAdd or 0
    end
    local count = attr_value + enhanceAdd + addRaceAttr   --值

    local show_attrvalue = self:GetBasicEnhanceFormat(value[1], count)
    return show_attrvalue, count
end


--种族加成属性值 isCeil:是否取整
function EquipProxy:EquipRaceAddAttrValue(value, isCeil)
    if isCeil == nil then
        isCeil = true
    end
    local _value = ConfigManager.GetConfig("data_common").equipment_race.value1[1]
    if isCeil then
        value = math.ceil(_value / 1000 * value)
    else
        value = _value / 1000 * value
    end
    return value
end

--强化加成属性值
function EquipProxy:EquipEnhanceAddAttrValue(value, quality, grade, isCeil)
    if isCeil == nil then
        isCeil = true
    end
    local _value = value
    local percent = self:GetAttrPercentByQualityGrade(quality, grade)
    if grade > 0 and percent then
        if isCeil then
            _value = math.ceil(_value * percent / 1000)
        else
            _value = _value * percent / 1000
        end
    else
        _value = 0
    end

    return _value
end

function EquipProxy:GetExclusiveConfig()
    local config = ConfigManager.GetConfig("data_exclusive")
    return config
end

function EquipProxy:GetExclusiveConfigByIdGrade(id, grade)
    local config = self:GetExclusiveConfig()
    for k, item in pairs(config) do
        if item.goods_id == id and item.current_grade == grade then
            return item
        end
    end
end

--获取强化下一等级配置
function EquipProxy:GetNextExclusiveConfig(id, grade)
    local config = self:GetExclusiveConfig()
    local _id = id
    for k, item in pairs(config) do
        if item.goods_id == _id and item.current_grade == (grade + 1) then
            return item
        else
            if item.goods_id == _id and item.current_grade == grade then
                if item.change_goods ~= 0 then
                    _id = item.change_goods
                end
            end
        end
    end
end

function EquipProxy:GetExclusiveLevelDescs(id)
    local LanguageManager = require "Common.Mgr.Language.LanguageManager"
    local config = self:GetExclusiveConfig()
    local strs = {}
    local goodsid = id
    for k, item in ipairs(config) do
        if goodsid == item.goods_id then
            if item.buff_info then
                local info = {}
                info.goodsTypeId = item.goods_id
                info.str = LanguageManager.Instance:GetWord(item.buff_info)
                info.grade = item.current_grade
                table.insert(strs, info)
            end
            if item.change_goods > 0 then
                goodsid = item.change_goods
            end
        end
    end
    return strs
end

--英雄专属装备强化最大等级
function EquipProxy:GetExclusiveMaxGradeByRoleId(roleid)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local heroCfg = HeroProxy.Instance:GetRoleCfgByConfigId(roleid)
    local defaultCfg = self:GetExclusiveConfigByIdGrade(heroCfg.exclusive, 0)
    local goodsId = defaultCfg.goods_id
    local config = self:GetExclusiveConfig()
    local grade = 0
    for i, item in ipairs(config) do
        if item.goods_id == goodsId then
            if item.current_grade > grade then
                grade = item.current_grade
            end
            if item.change_goods > 0 then
                goodsId = item.change_goods
            end
        end
    end
    return grade
end

--专属装备战力
function EquipProxy:GetExclusiveFight(equipId, heroTypeId, heroRank, heroLv, crystal_sub_level, heroUid, goodsTypeId, goodsEnhanceGrade)
    local fight = self:GetSingleEquipFight(equipId, heroTypeId, heroRank, heroLv, crystal_sub_level, heroUid, goodsTypeId, goodsEnhanceGrade)
    return fight
end

function EquipProxy:CheckHeroAttrPercent(_type)
    local attrKey = { [102] = "hp_max", [107] = "atk", [108] = "def" }
    if attrKey[_type] then
        return attrKey[_type]
    end
end

--专属装备 英雄属性添加值(向上取整)
function EquipProxy:GetHeroAttrPercentValue(heroTypeId, heroRank, heroLv, equipValue)
    local addcount = 0
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local attrCfg = HeroProxy.Instance:GetHeroAttr(heroTypeId, heroRank, heroLv)

    local value_str, value_count = self:GetExclusiveValue(equipValue[1], equipValue[2])
    local equipRate = self:CheckHeroAttrPercent(equipValue[1])
    if equipRate then
        addcount = attrCfg[equipRate] * (value_count / 100)
    end
    return math.ceil(addcount)
end

--专属装备 英雄属性战力添加值
function EquipProxy:GetHeroAttrPercentFightValue(heroTypeId, heroRank, heroLv, equipValue)
    local addcount = 0
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local attrCfg = HeroProxy.Instance:GetHeroAttr(heroTypeId, heroRank, heroLv)
    local value_str, value_count = self:GetExclusiveValue(equipValue[1], equipValue[2])
    local equipRate = self:CheckHeroAttrPercent(equipValue[1])
    local _attrCfg = HeroProxy.Instance:GetAttrValueCfgByType(equipValue[1])
    if equipRate then
        addcount = attrCfg[equipRate] * (value_count / 100)
    end
    return addcount
end

--flag:是否需要"："
function EquipProxy:GetEquipAttrNameByType(_type, flag)
    flag = flag or false
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local LanguageUtil = require "First.Util.LanguageUtil"
    local _attrCfg = HeroProxy.Instance:GetAttrValueCfgByType(_type)
    local attrName = ""  --属性名
    if _attrCfg then
        local str = (flag == true) and ": " or ""
        attrName = LanguageUtil.GetWord(_attrCfg.name) .. str
    end
    return attrName
end

--专属装备值 show_value:展示字符串  _value：值
function EquipProxy:GetExclusiveValue(_type, value)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local _value = value
    local _attrCfg = HeroProxy.Instance:GetAttrValueCfgByType(_type)
    if _attrCfg.conversion then
        _value = _value / _attrCfg.conversion
    end
    local _value1 = _value
    if _attrCfg.integer == 1 then
        _value1 = math.ceil(_value)
    end
    local show_value = string.format(_attrCfg.valuestring, _value)
    return show_value, _value1
end

--神器装备值  show_value:展示字符串  _value：值
function EquipProxy:GetArtifactValue(_type, value)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local _value = value
    local _attrCfg = HeroProxy.Instance:GetAttrValueCfgByType(_type)
    if _attrCfg.conversion then
        _value = _value / _attrCfg.conversion
    end

    local _value1 = _value 
    if _attrCfg.integer == 1 then
        _value1 = math.ceil(_value)
    end
    local show_value = string.format(_attrCfg.valuestring, _value1)
    return show_value, _value
end

--神器buff描述列表
function EquipProxy:GetArtifactEquipDesc(artifact_type_id)
    local LanguageManager = require "Common.Mgr.Language.LanguageManager"
    local configs = self:GetEquipArtifactConfigInfo(artifact_type_id)
    local buff_infos = {}
    for k,info in pairs(configs) do
        if info.buff_info then
            local item = {}
            item.current_grade = info.current_grade
            item.buff_info = LanguageManager.Instance:GetWord(info.buff_info)
            table.insert(buff_infos, item)
        end
    end
    table.sort(buff_infos, function(a, b)
        return a.current_grade < b.current_grade
    end)
    return buff_infos
end

--获取神器物品列表 buse:0 未穿戴  1：已穿戴  2:未穿戴及已穿戴
function EquipProxy:GetArtifactGoodsList(buse)
    local BagProxy = require "Modules.Bag.BagProxy"
    local unUseArtifacts, usedArtifacts = BagProxy.Instance:GetEquipGoodsInfoByPosAndClass(6, 0)
    local _unUseArtifacts = table.deepcopy(unUseArtifacts)
    local _usedArtifacts = table.deepcopy(usedArtifacts)
    if buse == nil or buse == 2 then
        for k,v in pairs(_usedArtifacts) do
            table.insert(_unUseArtifacts, v)
        end
        return _unUseArtifacts
    elseif buse ~= nil and buse == 0 then
        return _unUseArtifacts
    elseif buse ~= nil and buse == 1 then
        return _usedArtifacts
    end
    return {}
end

--是否拥有artifact_id（配置id）神器
function EquipProxy:CheckHaveArtifact(artifact_id)
    local bget = false
    local getArtifactInfos = self:GetArtifactGoodsList(2)
    for i,v in ipairs(getArtifactInfos) do
        if v.goodsTypeId == artifact_id then
            bget = true
            break
        end
    end
    return bget
end

--神器穿戴红点(实际是 返回未被穿戴神器是否大于0 , 若想用于红点 还需先判断是否穿戴神器)
function EquipProxy:GetArtifactRedDot()
    local count = 0
    local unUseArtifacts = self:GetArtifactGoodsList(0)
    if #unUseArtifacts > 0 then
        count = count + 1
    end
    return count
end

--神器强化红点
function EquipProxy:GetArtifactEnhanceRedDot(goodsTypeId, enhanceGrade)
    local BagProxy = require "Modules.Bag.BagProxy"
    local count = 0
    local materrials = self:GetArtifactEnhanceMaterrial(goodsTypeId, enhanceGrade)
    if materrials then
        local needCoin = materrials[1][2]
        local coinCount = RoleInfoModel.coin

        local materrialCount = BagProxy.Instance:GetItemCountByID(materrials[2][1])
        local needCount = materrials[2][2]
        if coinCount >= needCoin and materrialCount >= needCount then
            count = count + 1
        end
    end
    return count
end


--神器配置列表
function EquipProxy:GetTotalArtifactInfos()
    local artifacts = {}
    local config = self:GetArtifactConfig()
    for i,v in ipairs(config) do
        if v.current_grade == 0 then
            table.insert(artifacts, v)
        end
    end
    return artifacts
end

--神器获取途径 剧情副本名称名称
function EquipProxy:ArtifactGetWay(artifact_type_id)
    local StoryLineProxy = require "Modules.StoryLine.StoryLineProxy"
    local configs = self:GetEquipArtifactConfigInfo(artifact_type_id)
    if configs[0] and configs[0].getWayId then
        local config = StoryLineProxy.Instance:GetMapConfig(configs[0].getWayId)
        if config then
            return config.name
        end
    end
end

--神器强化材料图标资源
function EquipProxy:GetArtifactEnhanceMatIcon(goodsId)
    if self.artifactMaterrials[goodsId] then
        return self.artifactMaterrials[goodsId]
    end
end

--神器强化所需的金币以及材料
function EquipProxy:GetArtifactEnhanceMaterrial(artifact_type_id, enhanceGrade)
    local configs = self:GetEquipArtifactConfigInfo(artifact_type_id)
    if configs[enhanceGrade] and configs[enhanceGrade].expend then
        local expend_id,expend_count = configs[enhanceGrade].expend, configs[enhanceGrade].num
        local expend_res = self:GetArtifactEnhanceMatIcon(expend_id)

        local coin_id, coin_count = 702001, configs[enhanceGrade].coin
        local coin_res = self:GetArtifactEnhanceMatIcon(coin_id)

        return {{coin_id, coin_count, coin_res}, {expend_id, expend_count, expend_res}}
    end
end

--神器最大等级
function EquipProxy:GetArtifactMaxGrade(artifact_type_id)
    local configs = self:GetEquipArtifactConfigInfo(artifact_type_id)
    local grade = 0
    for k,v in pairs(configs) do
        grade = grade + 1
    end
    return grade - 1 
end

--神器模型资源
function EquipProxy:GetArtifactEquipRes(artifact_type_id)
    local cfg = ConfigManager.GetConfig("data_artifact_mod")
    if cfg[artifact_type_id] then
        return cfg[artifact_type_id].pre_id
    else
        print("data_artifact_mod is is null: ", artifact_type_id)
    end
    -- local res = string.format("shenqi_%d", artifact_type_id)
    -- return res
end

--神器战力
function EquipProxy:GetArtifactFight(equipId, heroTypeId, heroRank, heroLv, crystal_sub_level, heroUid, goodsTypeId, goodsEnhanceGrade)
    local fight = self:GetSingleEquipFight(equipId, heroTypeId, heroRank, heroLv, crystal_sub_level, heroUid, goodsTypeId, goodsEnhanceGrade)
    return fight
end

--神器id
function EquipProxy:GetArtifactEquip(equips)
    if equips then
        for i, equip in ipairs(equips) do
            if equip[1] == 6 then
                return equip[2]
            end
        end
    end
end

--英雄列表红点 战力
function EquipProxy:GetHeroListItemFight(heroBaseAttr, equipId, heroTypeId)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local BagProxy = require "Modules.Bag.BagProxy"

    heroTypeId = heroTypeId or 0
    local equipInfo
    if equipId then
        equipInfo = BagProxy.Instance:GetItemByID(equipId)    
    end
    local attrs = self:_GetEquipAttr(heroTypeId, equipInfo)
    attrs = self:GetEquipPercentAttrs(attrs, heroBaseAttr)
    local fight = HeroProxy.Instance:GetAttrFight(attrs)
    fight = math.floor(fight+0.5)
    return fight
end

--基础装备战力
function EquipProxy:GetEquipFight(equipId, roleid)
    local fight = self:GetSingleEquipFight(equipId, roleid)
    return fight
end

--通过物品id，强化等级计算战力
function EquipProxy:GetEquipFightByGoodsTypeIdGrade(goodsTypeId, enhanceGrade, roleid)
    -- equipId, heroTypeId, rank, level, crystal_sub_level, heroUid, goodsTypeId, goodsEnhanceGrade
    local fight = self:GetSingleEquipFight(nil, roleid, nil, nil, nil, nil, goodsTypeId, enhanceGrade)
    return fight
end

--专属属性总值
function EquipProxy:GetExclusiveEquipAttrValueInfos(goodsTypeId, goodsEnhanceGrade, heroTypeId, heroRank, heroLv)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local infos = {}
    local attrCfg = HeroProxy.Instance:GetHeroAttr(heroTypeId, heroRank, heroLv)
    local curExclusiveCfg = self:GetExclusiveConfigByIdGrade(goodsTypeId, goodsEnhanceGrade)
    local value = curExclusiveCfg.value
    for i, info in pairs(value) do
        if #info > 2 then
            if attrCfg then
                local num = info[2] / info[3] * attrCfg[CONST.ATTR[info[1]]]
                if infos[info[1]] then
                    infos[info[1]] = infos[info[1]] + num
                else
                    infos[info[1]] = num
                end
            end
        else
            local cfg = HeroProxy.Instance:GetAttrValueCfgByType(info[1])
            local num = info[2]--cfg.value*info[2]
            if infos[info[1]] then
                infos[info[1]] = infos[info[1]] + num
            else
                infos[info[1]] = num
            end
        end
    end

    for k, v in pairs(infos) do
        infos[k] = math.ceil(v)
    end

    return infos
end

--神器属性总值
function EquipProxy:GetArtifactEquipAttrValueInfos(goodsTypeId, goodsEnhanceGrade)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local infos = {}
    local cfg = self:GetArtifactConfigByIdGrade(goodsTypeId, goodsEnhanceGrade)
    if cfg then
        for k,v in pairs(cfg.value) do
            if infos[v[1]] then
                infos[v[1]] = infos[v[1]] + v[2]
            else
                infos[v[1]] = v[2]
            end
        end
    end
    for k, v in pairs(infos) do
        infos[k] = math.ceil(v)
    end
    return infos
end

--基础属性总值
function EquipProxy:GetEquipAttrValueInfos(goodsTypeId, goodsEnhanceGrade, heroTypeId)
    local attrInfos
    local cfg = self:GetHeroEquipById(goodsTypeId)
    if cfg then
        for i, value in ipairs(cfg.value) do
            local _type = value[1]
            local show_count, num = self:GetPerEquipAttrLabByConversion(value, cfg.quality, goodsEnhanceGrade, heroTypeId, goodsTypeId)
            if attrInfos == nil then
                attrInfos = {}
            end
            attrInfos[_type] = num
        end
    end
    return attrInfos
end

--装备属性增减
function EquipProxy:GetHeroEquipAttrInfos(lastAttrValueInfos, nextAttrValueInfos, heroUid, heroTypeId, rank)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local attributes_config = HeroProxy.Instance:GetAttrNames()

    local infos = {}
    if lastAttrValueInfos ~= nil and nextAttrValueInfos ~= nil then
        for key, value in pairs(lastAttrValueInfos) do
            if not nextAttrValueInfos[key] then
                table.insert(infos, { key, -value })
            end
        end
        for key, value in pairs(nextAttrValueInfos) do
            if not lastAttrValueInfos[key] then
                table.insert(infos, { key, value })
            else
                table.insert(infos, { key, value - lastAttrValueInfos[key] })
            end
        end
    elseif lastAttrValueInfos == nil and nextAttrValueInfos ~= nil then
        for key, value in pairs(nextAttrValueInfos) do
            table.insert(infos, { key, value })
        end
    elseif nextAttrValueInfos == nil and lastAttrValueInfos ~= nil then
        for key, value in pairs(lastAttrValueInfos) do
            table.insert(infos, { key, -value })
        end
    end

    local _infos = {}
    for key, _value in ipairs(infos) do
        local key = attributes_config[_value[1]]
        if key then
            if _infos[key] then 
                _infos[key] = _infos[key] + _value[2]
            else
                _infos[key] = _value[2]
            end
        end
    end

    local _rank, _level, _sub_level = HeroProxy.Instance:GetHeroLevelAndSubLevel(heroUid, heroTypeId, rank)
    local heroattr = HeroProxy.Instance:GetBaseHeroAttr(heroTypeId, _rank, _level, _sub_level)
    local attrs = self:GetEquipPercentAttrs(_infos, heroattr)
    local _attrs = {}
    for key,_value in pairs(attrs) do
        local attrTypes = HeroProxy.Instance:GetAttrTypes()
        if attrTypes[key] then
             _attrs[key] = {key = key, type = attrTypes[key], value = _value}
        end

    end

    return _attrs
end

function EquipProxy:GetEquipTypeDescByGoodsTypeId(goodsTypeId)
    local BagDef = require "Modules.Bag.BagDef"
    local BagProxy = require "Modules.Bag.BagProxy"
    local cfg = BagProxy.Instance:GetGoodsCfgById(goodsTypeId)
    if cfg then
        for k, v in pairs(BagDef.GoodsTypeDesc) do
            if v.type == cfg.type and v.subtype == cfg.subtype then
                return v.key
            end
        end
    end
    return ""
end

--英雄身上的基础装备 goodsIitem 数据列表
function EquipProxy:GetHeroEquipItemInfos(hero_uid)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local BagProxy = require "Modules.Bag.BagProxy"
    local heroEquipItems = {}
    local herodata = HeroProxy.Instance:GetHeroDataByUid(hero_uid)
    if herodata then
        local equips = herodata.equips
        for i, equip in ipairs(equips) do
            if equip[1] <= 4 then
                local goodsInfo = BagProxy.Instance:GetItemByID(equip[2])
                if goodsInfo then
                    local itemInfo = self:ConstructionEquipItemInfo(goodsInfo.goodsTypeId, nil, goodsInfo.goodsEnhanceGrade, goodsInfo.goodsEnhanceExp)
                    local goodsTypeId, goodsCount, equipInfo = goodsInfo.goodsTypeId, goodsInfo.goodsCount, itemInfo
                    table.insert(heroEquipItems, { goodsTypeId, nil, equipInfo })
                end
            end
        end
    end
    return heroEquipItems
end

--装备图标data  goodsId:唯一id  goodsTypeId：配置id  goodsCount:数量  enhanceGrade：强化星数 enhanceExp：强化经验
function EquipProxy:ConstructionEquipItemInfo(goodsTypeId, goodsCount, enhanceGrade, enhanceExp, isEquip)
    isEquip = isEquip == nil and true or isEquip
    local goodsInfo = {}
    goodsInfo.goodsTypeId = goodsTypeId
    goodsInfo.goodsCount = goodsCount
    goodsInfo.goodsEnhanceGrade = enhanceGrade
    goodsInfo.goodsEnhanceExp = enhanceExp
    goodsInfo.isEquip = isEquip
    return goodsInfo
end

--专属装备
function EquipProxy:ConstructionExclusiveItemInfo(goodsId, goodsTypeId, goodsCount, exclusiveGrade)
    local goodsInfo = {}
    goodsInfo.goodsId = goodsId
    goodsInfo.goodsTypeId = goodsTypeId
    goodsInfo.goodsCount = goodsCount
    goodsInfo.exclusiveGrade = exclusiveGrade
    return goodsInfo
end

--神器装备
function EquipProxy:ConstructionArtifactItemInfo(goodsId, goodsTypeId, goodsCount, enhanceGrade)
    local goodsInfo = {}
    goodsInfo.goodsId = goodsId
    goodsInfo.goodsTypeId = goodsTypeId
    goodsInfo.goodsCount = goodsCount
    goodsInfo.goodsEnhanceGrade = enhanceGrade
    return goodsInfo
end

function EquipProxy:GetEquipRaceTipsByRace(race)
    local EquipDef = require "Modules.Equip.EquipDef"
    for key, info in pairs(EquipDef.RaceTips) do
        if key == race then
            return info.tips
        end
    end
    return ""
end

--英雄是否有专属装备槽位
function EquipProxy:CheckIsExclusiveEquipHero(roleid)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local heroCfg = HeroProxy.Instance:GetRoleCfgByConfigId(roleid)
    if heroCfg then
        if heroCfg.exclusive ~= nil then
            return true
        end
    end
    return false
end

--是否开放专属装备槽位
function EquipProxy:CheckUnLockExclusiveEquipByQuality(quality)
    return (quality >= 9) and true or false
end

--专属红点
function EquipProxy:CheckExclusiveActive(heroId, heroTypeId)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local BagProxy = require "Modules.Bag.BagProxy"
    local heroCfg = HeroProxy.Instance:GetRoleCfgByConfigId(heroTypeId)
    if heroCfg then
        local herodata = HeroProxy.Instance:GetHeroDataByUid(heroId)
        if herodata and herodata.equips then
            local fitQuality = self:CheckUnLockExclusiveEquipByQuality(herodata.rank)
            local needGoodsId, needCount = 401001, 20
            local goodsInfo = BagProxy.Instance:GetItemByID(needGoodsId)
            if goodsInfo and goodsInfo.goodsCount >= needCount and fitQuality then
                return true
            end
        end
    end
    return false
end

--可升阶装备
function EquipProxy:GetUpGradeHeroInfos()
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local BagProxy = require "Modules.Bag.BagProxy"
    local minQuality = 9
    local maxQuality = 10
    local getInfos = {}
    local heroInfos = {}
    local infos = HeroProxy.Instance:GetHeroDataList()
    for i, info in ipairs(infos) do
        local equips = info.equips
        if equips then
            for i, equip in ipairs(equips) do
                local equipId = equip[2]
                local bagInfo = BagProxy.Instance:GetItemByID(equipId)
                if bagInfo and bagInfo.quality >= minQuality and bagInfo.quality <= maxQuality then
                    local equipCfg = self:GetHeroEquipById(bagInfo.goodsTypeId)
                    if equipCfg then
                        local goodsTypeId, goodsCount = self:GetStregthenMaterrial(equipCfg.quality, equipCfg.class)
                        local materrialGoods = BagProxy.Instance:GetItemByID(goodsTypeId)
                        if materrialGoods and materrialGoods.goodsCount >= goodsCount then
                            local flag = self:IsRecentStrenthen(self.data.upgradeIds, equipId)
                            local fight = HeroProxy.Instance:GetHeroBaseFight(info.roleid, info.level, info.rank)
                            local item = { herouid = info.herouid, isRecent = flag, herocfgid = info.roleid, level = info.level, rank = info.rank, fight = fight }
                            if getInfos[info.herouid] then
                            else
                                getInfos[info.herouid] = item
                                table.insert(heroInfos, item)
                            end
                        end
                    end
                end
            end
        end
    end
    return heroInfos
end

--专属装备可强化
function EquipProxy:GetExclusiveEnhanceHeroInfos()
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local BagProxy = require "Modules.Bag.BagProxy"
    local heroInfos = {}
    local infos = HeroProxy.Instance:GetHeroDataList()
    for i, info in ipairs(infos) do
        if info.equips then
            local quality1 = self:CheckIsExclusiveEquipHero(info.roleid)
            local quality2 = self:CheckUnLockExclusiveEquipByQuality(info.rank)
            if quality1 and quality2 then
                local id = self:GetExclusiveEquip(info.equips)
                if not id then
                    --是否能激活
                    local isactive = self:ExclusiveActive()
                    if isactive then
                        local flag = false --是否最近强化
                        local fight = HeroProxy.Instance:GetHeroBaseFight(info.roleid, info.level, info.rank)
                        local item = { herouid = info.herouid, isRecent = flag, herocfgid = info.roleid, level = info.level, rank = info.rank, fight = fight, active = isactive }
                        table.insert(heroInfos, item)
                    end
                else
                    --是否能强化
                    local enhance = self:ExclusiveEnhance(info.roleid, id)
                    if enhance then
                        local flag = self:IsRecentStrenthen(self.data.exclusiveIds, id)
                        local fight = HeroProxy.Instance:GetHeroBaseFight(info.roleid, info.level, info.rank)
                        local item = { herouid = info.herouid, isRecent = flag, herocfgid = info.roleid, level = info.level, rank = info.rank, fight = fight }
                        table.insert(heroInfos, item)
                    end
                end
            end
        end
    end
    return heroInfos
end

--能激活
function EquipProxy:ExclusiveActive()
    local BagProxy = require "Modules.Bag.BagProxy"
    local needGoodsId, needcount = 401001, 20
    local goodsCount = BagProxy.Instance:GetItemCountByID(needGoodsId)
    if needcount <= goodsCount then
        return true
    end
    return false
end


--是否能升阶
function EquipProxy:ExclusiveEnhance(roleid, equipId)
    local BagProxy = require "Modules.Bag.BagProxy"
    local grade = self:GetExclusiveMaxGradeByRoleId(roleid)
    local goodsInfo = BagProxy.Instance:GetItemByID(equipId)
    if goodsInfo then
        if goodsInfo.goodsEnhanceGrade < grade then
            local goodscfg = self:GetExclusiveConfigByIdGrade(goodsInfo.goodsTypeId, goodsInfo.goodsEnhanceGrade)
            if goodscfg then
                local goodsCount = BagProxy.Instance:GetItemCountByID(goodscfg.expend)
                if goodsCount >= goodscfg.num then
                    return true
                end
            end
        end
    end
    return false
end

function EquipProxy:IsRecentStrenthen(ids, equipId)
    local flag = false
    for i, v in ipairs(ids) do
        if v == equipId then
            flag = true
        end
    end
    return flag
end

function EquipProxy:GetExclusiveEquip(equips)
    for i, equip in ipairs(equips) do
        if equip[1] == 5 then
            return equip[2]
        end
    end
end

--装备强化石
function EquipProxy:GetEquipStoneMaterials(stoneIds)
    local BagProxy = require "Modules.Bag.BagProxy"
    local goodsId = stoneId
    local goodsCount
    local stoneInfo
    local stoneGoods = {}
    if stoneIds then
        for i, v in ipairs(stoneIds) do
            stoneInfo = BagProxy.Instance:GetItemByID(v)
            if stoneInfo then
                goodsCount = stoneInfo.goodsCount
                local item = {}
                item.goodsId = v
                item.goodsTypeId = v
                item.goodsCount = goodsCount
                item.goodsEnhanceGrade = 0
                item.goodsEnhanceExp = 0
                item.equippedHeroId = 0
                item.quality = stoneInfo.quality
                item.equipPart = 0
                item.selectCount = 0
                item.isEquip = false
                table.insert(stoneGoods, item)
            end
        end
    end
    table.sort(stoneGoods, function(a, b)
        return a.goodsTypeId > b.goodsTypeId
    end)
    return stoneGoods
end

--装备
function EquipProxy:GetEquipMaterial()
    local stoneIds = self:GetEquipStone()
    local BagProxy = require "Modules.Bag.BagProxy"
    local infos = {}
    local goodsInfo = BagProxy.Instance:GetEquipGoodsInfo()
    for i, v in pairs(goodsInfo) do
        if v.isEquip and v.equippedHeroId == 0 and v.quality <= 9 then
            local item = {}
            item.goodsId = v.goodsId
            item.goodsTypeId = v.goodsTypeId
            item.goodsCount = v.goodsCount
            item.goodsEnhanceGrade = v.goodsEnhanceGrade
            item.goodsEnhanceExp = v.goodsEnhanceExp
            item.equippedHeroId = v.equippedHeroId
            item.quality = v.quality
            item.equipPart = v.equipPart
            item.selectCount = 0
            item.isEquip = true
            table.insert(infos, item)
        end
    end
    table.sort(infos, function(a, b)
        if a.quality == b.quality then
            if a.equipPart == b.equipPart then
                return a.goodsTypeId < b.goodsTypeId
            else
                return a.equipPart < b.equipPart
            end
        else
            return a.quality < b.quality
        end
    end)

    local stoneGoods = self:GetEquipStoneMaterials(stoneIds)
    if stoneGoods then
        for i, v in ipairs(stoneGoods) do
            table.insert(infos, 1, v)
        end
    end
    return infos
end

function EquipProxy:GetEquipStone()
    local goodsIds = {}
    for i, v in ipairs(self.EquipStones) do
        table.insert(goodsIds, v.goodsTypeId)
    end
    return goodsIds
end

function EquipProxy:CheckEnhanceExpEnough(needExp)
    local countExp = 0
    local goodsInfos = self:GetEquipMaterial()
    for k,v in ipairs(goodsInfos) do
        local exp = self:GetEquipGoodsExp(v)
        for i = 1 , v.goodsCount do
            countExp = countExp + exp
            if countExp >= needExp then
                return countExp
            end
        end
    end
end

--强化红点
function EquipProxy:EquipEnhanceRedDotByEquipId(equipId)
    local count = 0
    local BagProxy = require "Modules.Bag.BagProxy"
    local goodsInfo = BagProxy.Instance:GetItemByID(equipId)
    if not goodsInfo then
        --print("EquipProxy:EquipEnhanceRedDotByEquipId------equipId--------->",equipId , debug.traceback())
        return count
    end
    local goodsCfg = BagProxy.Instance:GetGoodsCfgById(goodsInfo.goodsTypeId)
    local equipCfg = self:GetHeroEquipById(goodsInfo.goodsTypeId)
    local maxGrade = self:GetEquipMaxStarByQuality(goodsCfg.quality)
    if goodsInfo.goodsEnhanceGrade >= maxGrade then
        return count
    else
        local needExp = self:GetEquipGradeContaintExpBy(goodsCfg.quality,goodsInfo.goodsEnhanceGrade + 1)
        local curExp = goodsInfo.goodsEnhanceExp
        local offsetExp = needExp - curExp
        local countExp = self:CheckEnhanceExpEnough(offsetExp)
        if countExp and countExp > 0 then
            local perCoin = ConfigManager.GetConfig("data_common").equipment_enhance_coin.value1[1]
            local totalCoin = countExp * perCoin
            if totalCoin <= RoleInfoModel.coin then
                count = count + 1
                return count
            end
        end
        -- local goodsInfos = self:GetEquipMaterial()
        -- if #goodsInfos > 0 then
        --     local exp = self:GetEquipGoodsExp(goodsInfos[1])
        --     local perCoin = ConfigManager.GetConfig("data_common").equipment_enhance_coin.value1[1]
        --     local totalCoin = exp * perCoin
        --     if totalCoin <= RoleInfoModel.coin then
        --         count = count + 1
        --         return count
        --     end
        -- end
    end
    return count
end

--升阶红点
function EquipProxy:EquipUpGradeRedDot(goodsTypeId)
    local BagProxy = require "Modules.Bag.BagProxy"
    local count = 0
    local nextEquipId = self:GetNestStrengthenGoodsId(goodsTypeId)
    if nextEquipId then
        local goodsCfg = BagProxy.Instance:GetGoodsCfgById(goodsTypeId)
        local equipCfg = self:GetHeroEquipById(goodsTypeId)
        local _goodsTypeId, goodsCount = self:GetStregthenMaterrial(goodsCfg.quality, equipCfg.class)
        if _goodsTypeId then
            local curCount = BagProxy.Instance:GetItemCountByID(_goodsTypeId)
            if curCount >= goodsCount then
                count = count + 1
            end
        end
    end
    return count
end

--goodsTypeId:装备物品配置id,装备进阶需要的材料以及数量(返回nil 则该装备不可以升阶)
function EquipProxy:GetEquipUpGradeMaterrialIdAndCount(goodsTypeId)
    local BagProxy = require "Modules.Bag.BagProxy"
    local nextEquipId = self:GetNestStrengthenGoodsId(goodsTypeId)
    if nextEquipId then
        local goodsCfg = BagProxy.Instance:GetGoodsCfgById(goodsTypeId)
        local equipCfg = self:GetHeroEquipById(goodsTypeId)
        local _goodsTypeId, goodsCount = self:GetStregthenMaterrial(goodsCfg.quality, equipCfg.class)
        return _goodsTypeId, goodsCount
    end
end

--重铸红点
function EquipProxy:ReSetEquipRaceRedDot()
    local count = 0
    local BagProxy = require "Modules.Bag.BagProxy"
    local curCount = BagProxy.Instance:GetItemCountByID(self.materrialId)
    if curCount > 0 then
        count = count + 1
    end
    return count
end


function EquipProxy:CheckRebuildCondition(goodsCfg)
    if goodsCfg.quality >= 9 and goodsCfg.race > 0 and goodsCfg.race ~= 7 then
        return true
    end
    return false
end


--每一件装备包含经验
function EquipProxy:GetEquipGoodsExp(goodsInfo)
    local BagProxy = require "Modules.Bag.BagProxy"
    local goodsCfg = BagProxy.Instance:GetGoodsCfgById(goodsInfo.goodsTypeId)
    local stoneIds = self:GetEquipStone()
    local flag = false
    for i, v in ipairs(stoneIds) do
        if v == goodsInfo.goodsTypeId then
            flag = true
        end
    end
    if flag == true then
        --强化石
        return goodsCfg.value[1]
    else
        local exp = 0
        local cfg = self:GetEquipQualityColorByQuality(goodsCfg.quality)
        local containtExp = self:GetEquipGradeContaintExpBy(goodsCfg.quality, goodsInfo.goodsEnhanceGrade)
        exp = exp + cfg.exp + containtExp + goodsInfo.goodsEnhanceExp
        return exp
    end
end

--英雄页签红点
function EquipProxy:GetHeroTabRedDot(bupdate)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local heroList = HeroProxy.Instance:GetHeroDataList()
    local count = 0
    --是否有装备可穿戴
    for i, heroInfo in ipairs(heroList) do
        if heroInfo.level > 1 and heroInfo.equips then
            local wearAllEquip = self:GetWearAllEquipRedDotsByHeroUid(heroInfo.herouid, heroInfo)
            if wearAllEquip then
                count = count + 1
                break
            end
        end
    end
    for i, heroInfo in ipairs(heroList) do
        if heroInfo.level > 1 and heroInfo.equips then
            local redCount = self:GetAllArtifactRedDot(heroInfo.herouid, heroInfo)
            if redCount > 0 then
                count = count + 1
                break
            end
        end
    end
    -- count = count + self:GetHintRedDots()  --专属激活、升阶, 普通强化红点
    if bupdate then
        local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
        local RedPointDef = require "Modules.RedPoint.RedPointDef"
        RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.HeroTab, count)
        -- local MainProxy = require "Modules.Main.MainProxy"
        -- local MainDef = require "Modules.Main.MainDef"
        -- MainProxy.Instance:UpdateRedDot(MainDef.MainRedDotType.Hero, count)
    end
    return count
end

--装备升阶 专属强化红点
function EquipProxy:GetHintRedDots()
    local num = 0
    local upInfos = self:GetUpGradeHeroInfos()
    local exclusiveInfos = self:GetExclusiveEnhanceHeroInfos()
    if #upInfos > 0 or #exclusiveInfos > 0 then
        num = num + 1
    end
    return num
end

--圣物穿戴 以及 强化红点
function EquipProxy:GetAllArtifactRedDot(herouid)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local BagProxy = require "Modules.Bag.BagProxy"

    local num = 0
    local herodata = HeroProxy.Instance:GetHeroDataByUid(herouid)
    if not herodata then
        return num
    end
    local equipId = self:GetArtifactEquip(herodata.equips)
    if equipId then
        local equipInfos = BagProxy.Instance:GetEquipGoodsInfo()
        local artifactGoodsInfo = equipInfos[equipId]
        -- 上线时 在英雄列表协议中会检查红点，但此时背包数据协议还没过来
        if artifactGoodsInfo then
            num = self:GetArtifactEnhanceRedDot(artifactGoodsInfo.goodsTypeId, artifactGoodsInfo.goodsEnhanceGrade) + num
        end
    else
        num = self:GetArtifactRedDot() + num
    end
    return num
end

function EquipProxy:GetUpgradeMataria(equipId)
    --lilin
    local BagProxy = require "Modules.Bag.BagProxy"
    local goodsInfo = BagProxy.Instance:GetItemByID(equipId)
    return self:GetEquipUpGradeMaterrialIdAndCount(goodsInfo.goodsTypeId)
end

--是否为英雄强化所需装备
function EquipProxy:IsHeroNeedEquip(heroUid, goodsTypeId)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local BagProxy = require "Modules.Bag.BagProxy"

    local herodata = HeroProxy.Instance:GetHeroDataByUid(heroUid)
    if herodata and herodata.equips then
        local heroCfg = HeroProxy.Instance:GetRoleCfgByConfigId(herodata.roleid)
        for i = 1, 4 do
            local cur_equipId
            for _, equip in ipairs(herodata.equips) do
                if equip[1] == i then
                    cur_equipId = equip[2]
                end
            end
            local cur_equip_Info
            if cur_equipId then
                cur_equip_Info = BagProxy.Instance:GetItemByID(cur_equipId)
            end

            local equipCfg = self:GetHeroEquipById(goodsTypeId)
            if equipCfg and heroCfg and equipCfg.position == i and heroCfg.class == equipCfg.class then
                if not cur_equip_Info then
                    return true
                else
                    local lastFight = self:GetEquipFight(cur_equip_Info.goodsId, heroCfg.id)
                    local curFight = self:GetEquipFightByGoodsTypeIdGrade(goodsTypeId, 0, (herodata.roleid))
                    if curFight > lastFight then
                        return true
                    end
                end
            end
        end
    end
    return false
end

--一键穿戴红点
function EquipProxy:GetWearAllEquipRedDotsByHeroUid(heroUid, herodata)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local BagProxy = require "Modules.Bag.BagProxy"
    local wear_equips = {}
    local bred = false
    if herodata then
    else
        herodata = HeroProxy.Instance:GetHeroDataByUid(heroUid)
    end
    
    if herodata and herodata.equips then
        local _rank, _level, _sub_level = HeroProxy.Instance:GetHeroLevelAndSubLevel(heroUid, herodata.roleid)
        local heroBaseAttr = HeroProxy.Instance:GetBaseHeroAttr(herodata.roleid, _rank, _level, _sub_level)

        local heroCfg = HeroProxy.Instance:GetRoleCfgByConfigId(herodata.roleid)
        for i = 1, 4 do
            local cur_equipId
            for _, equip in ipairs(herodata.equips) do
                if equip[1] == i then
                    cur_equipId = equip[2]
                end
            end
            local cur_equip_Info
            if cur_equipId then
                cur_equip_Info = BagProxy.Instance:GetItemByID(cur_equipId)
            end
            local equipGoods = BagProxy.Instance:GetUnUseEquipByPosAndClass(i, heroCfg.class)
            if equipGoods then
                if not cur_equip_Info then
                    bred = true
                else
                    -- local lastFight = self:GetEquipFight(cur_equip_Info.goodsId, heroCfg.id)
                    local lastFight = self:GetHeroListItemFight(heroBaseAttr, cur_equip_Info.goodsId, heroCfg.id)
                    for _, info in ipairs(equipGoods) do
                        -- local curFight = self:GetEquipFight(info.goodsId, heroCfg.id)
                        local curFight = self:GetHeroListItemFight(heroBaseAttr, info.goodsId, heroCfg.id)
                        if curFight > lastFight then
                            lastFight = curFight
                            bred = true
                            break
                        end
                    end
                end
            end
            if bred then
                break
            end
        end
    end
    return bred
end

--获取专属装备物品id
function EquipProxy:GetExclusiveEquipGoodsId(equips)
    local BagProxy = require "Modules.Bag.BagProxy"
    local exclusiveId
    if equips then
        for i, v in ipairs(equips) do
            if v[1] == 5 then
                exclusiveId = v[2]
            end
        end

        if exclusiveId then
            local info = BagProxy.Instance:GetItemByID(exclusiveId)
            if info then
                return info.goodsTypeId
            end
        end
    end
end

-- 获取装备buff列表
function EquipProxy:GetEquipBuffList(heroUid)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local BagProxy = require "Modules.Bag.BagProxy"
    local herodata = HeroProxy.Instance:GetHeroDataByUid(heroUid)
    local exclusiveId, artifactId = nil, nil
    if herodata and herodata.equips then
        for i, equip in ipairs(herodata.equips) do
            if equip[1] == 5 then
                exclusiveId = equip[2]
            elseif equip[1] == 6 then
                artifactId = equip[2]
            end
        end
    end

    local bufflist = nil

    if exclusiveId then
        local goodsInfo = BagProxy.Instance:GetGoodsInfoById(exclusiveId)
        if goodsInfo then

            local exclusiveConfig = self:GetExclusiveConfigByIdGrade(goodsInfo.goodsTypeId, goodsInfo.goodsEnhanceGrade)
            if exclusiveConfig then
                bufflist = bufflist or {}
                for i, buffid in ipairs(exclusiveConfig.buff_id) do
                    table.insert(bufflist, buffid)
                end
            end
        end
    end

    if artifactId then
        local goodsInfo = BagProxy.Instance:GetGoodsInfoById(artifactId)
        if goodsInfo then
            local artifactCfg = self:GetArtifactConfigByIdGrade(goodsInfo.goodsTypeId, goodsInfo.goodsEnhanceGrade)
            if artifactCfg then
                bufflist = bufflist or {}
                table.insert(bufflist, artifactCfg.buff_id)
            end
        end
    end
    return bufflist
end

--equips = {{goods_type_id, goods_grade}, ...} 装备配置id, 等级
function EquipProxy:GetEquipBuffListByEquips(equips)
    local bufflist = {}
    for k,info in pairs(equips) do
        local equip_cfg = self:GetHeroEquipById(info[1])
        if equip_cfg then
            if equip_cfg.position == 5 then
                local exclusiveConfig = self:GetExclusiveConfigByIdGrade(info[1], info[2])
                if exclusiveConfig then
                    bufflist = bufflist or {}
                    for i, buffid in ipairs(exclusiveConfig.buff_id) do
                        table.insert(bufflist, buffid)
                    end
                end
            elseif equip_cfg.position == 6 then
                local artifactCfg = self:GetArtifactConfigByIdGrade(info[1], info[2])
                if artifactCfg then
                    bufflist = bufflist or {}
                    table.insert(bufflist, artifactCfg.buff_id)
                end
            end
        end
    end
    return bufflist
end

--是否有穿戴装备
function EquipProxy:IsHeroWearBasicEquip(heroUid)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local is_wear_equip = false
    local herodata = HeroProxy.Instance:GetHeroDataByUid(heroUid)
    if herodata then
        for i, equip in ipairs(herodata.equips) do
            if equip[2] > 0 then
                is_wear_equip = true
                break
            end
        end
    end
    return is_wear_equip
end

function EquipProxy:GetEquipAttrSpriteByType(attr_type)
    local attrSprite = "attr_0"
    local attr_key_value = {
        [2] = "attr_2",
        [7] = "attr_7",
        [8] = "attr_8",
        [102] = "attr_2",
        [107] = "attr_7",
        [108] = "attr_8",
    }
    if attr_key_value[attr_type] then
        attrSprite = attr_key_value[attr_type]
    end
    return attrSprite
end

function EquipProxy:GetHeroEclusiveEquipRes(roleId)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local spritecfg = HeroProxy.Instance:GetSpriteConfigeById(roleId)
    local eclusiveEquip = string.format("%s_eqpt", spritecfg.prefab_id[1])
    return eclusiveEquip
end

---------------------属性计算相关---------------------
--全部装备属性 己方
function EquipProxy:GetEquipAttr(heroTypeId, equipList)
	local attributes = {}
    --print("------->>>", heroTypeId, table.dump(equipList))
    local BagProxy = require "Modules.Bag.BagProxy"
	for _, equip_id in ipairs(equipList) do
		local equip_info = BagProxy.Instance:GetItemByID(equip_id) -- context.equiplist[equip_id]
		if equip_info then
			local attr_one = self:_GetEquipAttr(heroTypeId, equip_info)
            --print("------>>>", table.dump(attr_one))
			for k, value in pairs(attr_one) do
				if attributes[k] then
					attributes[k] = attributes[k] + value
				else
					attributes[k] = value
				end
			end
		end
	end

	return attributes
end

--装备配置 列表equipList {{equipTypeId, lv}, ...}
function EquipProxy:GetEnemyEquipAttr(heroTypeId, equipList)
    local attributes = {}
    for i,v in ipairs(equipList) do
        local attr_one = self:_GetEquipAttr(heroTypeId, nil, v[1], v[2])
        for k, value in pairs(attr_one) do
            if attributes[k] then
                attributes[k] = attributes[k] + value
            else
                attributes[k] = value
            end
        end
    end

    return attributes
end

--单件装备属性
function EquipProxy:_GetSingleEquipAttrs(equipId, heroTypeId, rank, level, crystal_sub_level, heroUid, goodsTypeId, goodsEnhanceGrade)
    local BagProxy = require "Modules.Bag.BagProxy"
    local HeroProxy = require "Modules.Hero.HeroProxy"
    heroTypeId = heroTypeId or 0
    local equipInfo
    if equipId then
        equipInfo = BagProxy.Instance:GetItemByID(equipId)    
    end

    local attrs = self:_GetEquipAttr(heroTypeId, equipInfo, goodsTypeId, goodsEnhanceGrade)
    local _rank, _level, _sub_level = HeroProxy.Instance:GetHeroLevelAndSubLevel(heroUid, heroTypeId, rank, level, crystal_sub_level)
    local heroattr = HeroProxy.Instance:GetBaseHeroAttr(heroTypeId, _rank, _level, _sub_level)
    local attrs = self:GetEquipPercentAttrs(attrs, heroattr)

    return attrs
end

--百分比属性添加值
function EquipProxy:GetEquipPercentAttrs(attrs, heroattr)
    local ceil_floor_func = function(value)
        local _value = 0
        if value > 0 then
            _value = math.ceil(value)
        else
            _value = math.floor(value)
        end
        return _value
    end

    --百分比属性处理
    if attrs.hp_max_rate then
        heroattr.hp = heroattr.hp or 0
        if attrs.hp then
            attrs.hp = attrs.hp + ceil_floor_func(heroattr.hp * attrs.hp_max_rate / 1000)
        else
            attrs.hp = ceil_floor_func(heroattr.hp * attrs.hp_max_rate / 1000)
        end
        attrs.hp_max = attrs.hp
    end

    if attrs.atk_rate then
        heroattr.atk = heroattr.atk or 0
        if attrs.atk then
            attrs.atk = attrs.atk + ceil_floor_func(heroattr.atk * attrs.atk_rate / 1000)
        else
            attrs.atk = ceil_floor_func(heroattr.atk * attrs.atk_rate / 1000)
        end
    end

    if attrs.def_rate then
        heroattr.def = heroattr.def or 0
        if attrs.def then
            attrs.def = attrs.def + ceil_floor_func(heroattr.def * attrs.def_rate / 1000)
        else
            attrs.def = ceil_floor_func(heroattr.def * attrs.def_rate / 1000)
        end
    end
    return attrs
end


--计算单件装备的战力
function EquipProxy:GetSingleEquipFight(equipId, heroTypeId, rank, level, crystal_sub_level, heroUid, goodsTypeId, goodsEnhanceGrade)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local attrs = self:_GetSingleEquipAttrs(equipId, heroTypeId, rank, level, crystal_sub_level, heroUid, goodsTypeId, goodsEnhanceGrade)
    local fight = HeroProxy.Instance:GetAttrFight(attrs)
    fight = math.floor(fight+0.5)
    return fight
end

--未拥有的装备 equipInfo = nil, goodsEnhanceGrade = 0
function EquipProxy:_GetEquipAttr(heroTypeId, equipInfo, goodsTypeId, goodsEnhanceGrade)
    local BagDef = require "Modules.Bag.BagDef"
    local BagProxy = require "Modules.Bag.BagProxy"
    local attributes = {}
    local _goodsTypeId = goodsTypeId
    local _goodsEnhanceGrade = goodsEnhanceGrade
    heroTypeId = heroTypeId or 0
    if equipInfo then
        _goodsTypeId = equipInfo.goodsTypeId
        _goodsEnhanceGrade = equipInfo.goodsEnhanceGrade
    end
    if _goodsTypeId then
        local goodsCfg = BagProxy.Instance:GetGoodsCfgById(_goodsTypeId)
        if goodsCfg then
            if goodsCfg.type == BagDef.BagType.Basic_Equip then
                attributes = self:GetBasicEquipAttrs(equipInfo, heroTypeId, goodsTypeId, _goodsEnhanceGrade)
            elseif goodsCfg.subtype == BagDef.SubType.Equip_Exclusive then
                attributes = self:GetExclusiveAttrs(equipInfo, goodsTypeId, _goodsEnhanceGrade)
            elseif goodsCfg.subtype == BagDef.SubType.Equip_Artifacts then
                attributes = self:GetArtifactAttrs(equipInfo, goodsTypeId, _goodsEnhanceGrade)
            end
        end
    end
    --服务端在类似的地方做了向上取整的处理(防止其他地方获取属性后带有小数并且用于协议传输导致报错)
    --客户端保持一致
    for k,v in pairs(attributes) do
        if type(v) == "number" then
            attributes[k] = math.ceil(v)
        end
    end
    return attributes
end

function EquipProxy:_GetEquipAttr_origin(heroTypeId, equipInfo)
    local attributes = {}

    local HeroProxy = require "Modules.Hero.HeroProxy"
    local BagProxy = require "Modules.Bag.BagProxy"
    local attributes_config = HeroProxy.Instance:GetAttrNames()

    heroTypeId = heroTypeId or 0

    local equip_type_id = equipInfo.goodsTypeId
    local equip_config_info = faceConfig["data_equipment"][equip_type_id]
    if not equip_config_info then
        return attributes
    end

    if equip_config_info.position <= 4 then -- 基础装备
        -- 基础属性
        local base_attr_value = equip_config_info.value
        for _, value in ipairs(base_attr_value) do
            local key = attributes_config[value[1]]
            if attributes[key] then
                attributes[key] = attributes[key] + value[2]
            else
                attributes[key] = value[2]
            end
        end

        -- 强化属性
        local enhance_grade = equipInfo.goodsEnhanceGrade
        local equip_quality = equip_config_info.quality
        local enhance_percent = 0
        if enhance_grade > 0 then
            enhance_percent = self:GetAttrPercentByQualityGrade(equip_quality, enhance_grade)-- enhance_config_info[enhance_grade]
            --enhance_percent = cur_grade_enhance_config_info.percent

            --local enhance_config_info = _get_equip_enhance_config_info(game, equip_quality) -- module.equip_enhance_config[equip_quality]
            --if enhance_config_info then
            --    local cur_grade_enhance_config_info = self:GetAttrPercentByQualityGrade(equip_quality, enhance_grade)-- enhance_config_info[enhance_grade]
            --    enhance_percent = cur_grade_enhance_config_info.percent
            --end
        end

        for _, value in ipairs(base_attr_value) do
            local key = attributes_config[value[1]]
            if attributes[key] then
                attributes[key] = attributes[key] + value[2] * enhance_percent / 1000
            else
                attributes[key] = value[2] * enhance_percent / 1000
            end
        end

        -- 种族加成
        local hero_race = 0
        local hero_config_info = HeroProxy.Instance:GetRoleCfgByConfigId(heroTypeId) -- game.moduleapi("get_hero_config", {role_id = hero_type_id})
        if hero_config_info then
            hero_race = hero_config_info.race
        end

        local equip_race = 0
        local equip_goods_config_info = BagProxy.Instance:GetGoodsCfgById(equip_type_id) --game.moduleapi("getgoodsconfig", {goods_type_id = equip_type_id})
        if equip_goods_config_info then
            equip_race = equip_goods_config_info.race
        end

        if hero_race ~= 0 and hero_race == equip_race then
            local equip_race_percent = faceConfig["data_common"].equipment_race.value1[1]
            for _, value in ipairs(base_attr_value) do
                local key = attributes_config[value[1]]
                if attributes[key] then
                    attributes[key] = attributes[key] + value[2] * equip_race_percent / 1000
                else
                    attributes[key] = value[2] * equip_race_percent / 1000
                end
            end
        end

    elseif equip_config_info.position == 5 then -- 专属装备
        local exclusive_all_config = self:GetEquipExclusiveConfigInfo(equip_type_id) --_get_equip_exclusive_config_info(game, equip_type_id) -- module.equip_exclusive_config[equip_info.goods_type_id]
        if exclusive_all_config then
            local enhance_grade = equipInfo.goodsEnhanceGrade
            local exclusive_config = exclusive_all_config[enhance_grade]
            if exclusive_config then
                -- 基础属性
                local base_attr_value = exclusive_config.value
                for _, value in ipairs(base_attr_value) do
                    local key = attributes_config[value[1]]
                    if attributes[key] then
                        attributes[key] = attributes[key] + value[2]
                    else
                        attributes[key] = value[2]
                    end
                end
            end
        end
    elseif equip_config_info.position == 6 then -- 神器
        local artifact_all_config = self:GetEquipArtifactConfigInfo(equip_type_id) -- module.equip_artifact_config[equip_info.goods_type_id]
        if artifact_all_config then
            local enhance_grade = equipInfo.goodsEnhanceGrade
            local artifact_config = artifact_all_config[enhance_grade]
            if artifact_config then
                -- 基础属性
                local base_attr_value = artifact_config.value
                for _, value in ipairs(base_attr_value) do
                    local key = attributes_config[value[1]]
                    if attributes[key] then
                        attributes[key] = attributes[key] + value[2]
                    else
                        attributes[key] = value[2]
                    end
                end
            end
        end
    end

    return attributes
end

--基础装备属性
function EquipProxy:GetBasicEquipAttrs(equipInfo, heroTypeId, goodsTypeId, goodsEnhanceGrade)
    local attributes = {}
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local BagProxy = require "Modules.Bag.BagProxy"
    local attributes_config = HeroProxy.Instance:GetAttrNames()

    heroTypeId = heroTypeId or 0
    local equip_type_id, enhance_grade
    if equipInfo then
        equip_type_id = equipInfo.goodsTypeId
        enhance_grade = equipInfo.goodsEnhanceGrade
    elseif goodsTypeId and goodsEnhanceGrade then
        equip_type_id, enhance_grade = goodsTypeId, goodsEnhanceGrade
    end

    if equip_type_id and enhance_grade then
        local equip_config_info = faceConfig["data_equipment"][equip_type_id]
        if not equip_config_info then
            return attributes
        end

        local base_attr_value = equip_config_info.value
        for _, value in ipairs(base_attr_value) do
            local key = attributes_config[value[1]]
            if attributes[key] then
                attributes[key] = attributes[key] + value[2]
            else
                attributes[key] = value[2]
            end
        end

        -- 强化属性
        local equip_quality = equip_config_info.quality
        local enhance_percent = 0
        if enhance_grade > 0 then
            enhance_percent = self:GetAttrPercentByQualityGrade(equip_quality, enhance_grade)-- enhance_config_info[enhance_grade]
        end

        for _, value in ipairs(base_attr_value) do
            local key = attributes_config[value[1]]
            if attributes[key] then
                attributes[key] = attributes[key] + value[2] * enhance_percent / 1000
            else
                attributes[key] = value[2] * enhance_percent / 1000
            end
        end

        -- 种族加成
        local hero_race = 0
        local hero_config_info = HeroProxy.Instance:GetRoleCfgByConfigId(heroTypeId) -- game.moduleapi("get_hero_config", {role_id = hero_type_id})
        if hero_config_info then
            hero_race = hero_config_info.race
        end

        local equip_race = 0
        local equip_goods_config_info = BagProxy.Instance:GetGoodsCfgById(equip_type_id) --game.moduleapi("getgoodsconfig", {goods_type_id = equip_type_id})
        if equip_goods_config_info then
            equip_race = equip_goods_config_info.race
        end
        
        if hero_race ~= 0 and hero_race == equip_race then
            local equip_race_percent = faceConfig["data_common"].equipment_race.value1[1]
            for _, value in ipairs(base_attr_value) do
                local key = attributes_config[value[1]]
                if attributes[key] then
                    attributes[key] = attributes[key] + value[2] * equip_race_percent / 1000
                else
                    attributes[key] = value[2] * equip_race_percent / 1000
                end
            end
        end
    end
    return attributes
end


--专属装备属性
function EquipProxy:GetExclusiveAttrs(equipInfo, goodsTypeId, goodsEnhanceGrade)
    local attributes = {}
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local attributes_config = HeroProxy.Instance:GetAttrNames()

    local equip_type_id, enhance_grade
    if equipInfo then
        equip_type_id = equipInfo.goodsTypeId
        enhance_grade = equipInfo.goodsEnhanceGrade
    elseif goodsTypeId and goodsEnhanceGrade then
        equip_type_id, enhance_grade = goodsTypeId, goodsEnhanceGrade
    end

    if equip_type_id and enhance_grade then
        local equip_config_info = faceConfig["data_equipment"][equip_type_id]
        if not equip_config_info then
            return attributes
        end 

        local exclusive_all_config = self:GetEquipExclusiveConfigInfo(equip_type_id) --_get_equip_exclusive_config_info(game, equip_type_id) -- module.equip_exclusive_config[equip_info.goods_type_id]
        if exclusive_all_config then
            local exclusive_config = exclusive_all_config[enhance_grade]
            if exclusive_config then
                -- 基础属性
                local base_attr_value = exclusive_config.value
                for _, value in ipairs(base_attr_value) do
                    local key = attributes_config[value[1]]
                    if attributes[key] then
                        attributes[key] = attributes[key] + value[2]
                    else
                        attributes[key] = value[2]
                    end
                end
            end
        end
    end
    return attributes
end


--获取神器装备属性 equipInfo:物品信息  or goodsTypeId, goodsEnhanceGrade
function EquipProxy:GetArtifactAttrs(equipInfo, goodsTypeId, goodsEnhanceGrade)
    local attributes = {}
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local attributes_config = HeroProxy.Instance:GetAttrNames()

    local equip_type_id, enhance_grade
    if equipInfo then
        equip_type_id = equipInfo.goodsTypeId
        enhance_grade = equipInfo.goodsEnhanceGrade
    elseif goodsTypeId and goodsEnhanceGrade then
        equip_type_id, enhance_grade = goodsTypeId, goodsEnhanceGrade
    end

    if equip_type_id and enhance_grade then
        local equip_config_info = faceConfig["data_equipment"][equip_type_id]
        if not equip_config_info then
            return attributes
        end 

        local artifact_all_config = self:GetEquipArtifactConfigInfo(equip_type_id) -- module.equip_artifact_config[equip_info.goods_type_id]
        if artifact_all_config then
            local artifact_config = artifact_all_config[enhance_grade]
            if artifact_config then
                -- 基础属性
                local base_attr_value = artifact_config.value
                for _, value in ipairs(base_attr_value) do
                    local key = attributes_config[value[1]]
                    if attributes[key] then
                        attributes[key] = attributes[key] + value[2]
                    else
                        attributes[key] = value[2]
                    end
                end
            end
        end
    end
    return attributes
end

---------------------属性计算相关---------------------
return EquipProxy

