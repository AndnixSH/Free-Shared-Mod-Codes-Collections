SdkManager = {bforce = false, baudit = false, bload_appcfg_end = true, bmaintain = false, maintain_view = nil, func=nil}
local cs_coroutine = require "First.Util.cs_coroutine"
--local rapidjson = require "rapidjson"
local cIGGSdkInterface = CS.LJY.NX.IGGSdkInterface
local cIGGSdkTestAdapt = CS.LJY.NX.IGGSdkTestAdapt
local Application = CS.UnityEngine.Application

local _initSuc = false
local _loadAppconf = false
--版本号检查
local function _CheckVersionNum(cfg_version, cur_Version)
    local bforce = false
    if cfg_version and cur_Version then
        local cfg_versionArgs = string.split(cfg_version .. ".", "%.")
        local cur_version_Args = string.split(cur_Version .. ".", "%.")
        for i = 1, math.max(#cfg_versionArgs, #cur_version_Args) do
            --local _cfg_Version, _cur_version = tonumber(cfg_VersionArgs[i]), tonumber(cur_version_Args[i])
            --if _cfg_Version and _cur_version and _cfg_Version > _cur_version then
            --    bforce = true
            --    break
            --end
            local _cfg_version = tonumber(cfg_versionArgs[i]) or 0
            local _cur_version = tonumber(cur_version_Args[i]) or 0
            if _cfg_version ~= _cur_version then
                return _cfg_version > _cur_version and true or false
            end
        end
    end
    return bforce
end
function SdkManager.Init()
    _initSuc = false
    _loadAppconf = false
    local bstart = false
    if SystemConfig.isIGGPlatform() then
        bstart = true
        local LanguageUtil = require "First.Util.LanguageUtil"
        -- IGGSdkInterface.Instance:Init(LanguageUtil.GetLanguageGameId())
        local game_id = LanguageUtil.GetLanguageGameId()

        local _agentPackageID = LanguageUtil.GetAgentPackageIDByGameId(game_id)
        if _agentPackageID then
            SystemConfig.AgentPackageID = _agentPackageID
        end
        
        --print("--------SdkManager.Init---game_id-------",game_id)
        cIGGSdkInterface.SdkInit(game_id)
    end

    if SystemConfig.isIGGTestPlatform() then
        cIGGSdkTestAdapt.SdkInit()
    end

    if bstart then
        local coro = cs_coroutine.start(function()
            --挂起协程等待sdk回调,如果没有回调,则重启吧
            local waittime = 20
            for i = 1, waittime do
                if _initSuc then
                    return nil
                else
                    coroutine.yield(CS.UnityEngine.WaitForSeconds(1))
                end
            end
            error("sdk init is fail!!!")
        end)
        return coro
    end
end

function SdkManager.OnInitIGGSDKComplete()
	print("IGGSdk init success...")
    _initSuc = true
    
end


function SdkManager.OnLoadAppConfSuccess(appconfig, serverTime)
    print("OnLoadAppConfSuccess=============>>")
    local server_time = serverTime.Timestamp
    SystemConfig.ServerTime = server_time
    SystemConfig.InitAppConfig(appconfig)
    -- SdkManager.checkShowForceView()
    SdkManager.checkShowView(server_time)
    _loadAppconf = true
end

function SdkManager.OnLoadAppConfFail()
    print("OnLoadAppConfFail===========")
end

function SdkManager.OnLoadGameDefaultConfig()
    print("OnLoadGameDefaultConfig===========")
    SystemConfig.InitAppConfig(nil)
    -- SdkManager.checkShowForceView()
    SdkManager.checkShowView()
    _loadAppconf = true
end

--检查维护，强更界面
function SdkManager.checkShowView(server_time)
    local bWhiteId = SdkManager.CheckWhiteIdList()
    if bWhiteId then
        local bforce = SdkManager.checkShowForceView()
        if not bforce then
            SdkManager.func()
        end
    else
        local bmaintain = SdkManager.CheckMaintainView(server_time)
        if not bmaintain then
            local bforce = SdkManager.checkShowForceView()
            if not bforce then
                SdkManager.func()
            end
        end
    end
end

--强更面板
function SdkManager.checkShowForceView()
    local bforce, contentStr = SdkManager.CheckForceVersion()

    SdkManager.bforce = bforce
    if bforce then
        local titleKey = "UpdateNoticeView_1002"
        local btnMiddleKey = "UpdateNoticeView_1001"
        local UpdateNoticeView = require "First.Update.View.UpdateNoticeView"
        UpdateNoticeView.Show(contentStr, function(bValue)
            if bValue then
                local appconfig =  SystemConfig.AppConfig.rawString
                if appconfig and appconfig["Update"] then
                    local googleUrl = appconfig["Update"].googleUrl
                    local appleUrl = appconfig["Update"].appleUrl
                    local RuntimePlatform = CS.UnityEngine.RuntimePlatform
                    local url = Application.platform == RuntimePlatform.Android and googleUrl or appleUrl
                    Application.OpenURL(url)
                end
            else
                Application.Quit()
            end
        end, titleKey, btnMiddleKey)
    end
    return bforce
end

--维护界面
function SdkManager.CheckMaintainView(serverTime)
    local bshow = false
    local bMainTainIn, strContent, timeLeft = SdkManager.checkShowMaintain(serverTime)

    SdkManager.bmaintain = bMainTainIn
    if bMainTainIn then
        local UpdateMaintenanceView = require "First.Update.View.UpdateMaintenanceView"
        local maintain_view = UpdateMaintenanceView.Show(strContent, function(bValue)
            if bValue == 2 then
                -- self:RefreshAppconfig() --暂时自己维护时间
                cIGGSdkInterface.LoadUpdateAppconf()
            elseif bValue == 1 then
                local LanguageUtil = require "First.Util.LanguageUtil"
                -- local idx = LanguageUtil.GetLanguageIdx()
                -- local _languageType = {
                --     [1] = {facebookurl = "https://www.facebook.com/RageofDestiny/"}, --简体
                --     [2] = {facebookurl = "https://www.facebook.com/RageofDestinyTW/"}, --繁体
                --     [3] = {facebookurl = "https://www.facebook.com/RageofDestiny/"},  --英文
                -- }
                -- local _facebookurl = _languageType[3]
                -- if _languageType[idx] then
                --     _facebookurl = _languageType[idx].facebookurl
                -- end
                local url = LanguageUtil.GetFaceBookUrl()
                if url ~= "" and url then
                    Application.OpenURL(url)
                end
                
            else
                Application.Quit()
            end
        end, "MaintenanceView_1001", nil, "MaintenanceView_1002", timeLeft)
        SdkManager.SetMaintainViewValue(maintain_view)
        bshow = true
    else
        if SdkManager.maintain_view then
            SdkManager.maintain_view:Close()
        end
    end
    print("CheckMaintainView benter=====", serverTime, bshow)
    return bshow
end

function SdkManager.CheckForceVersionCondition(func)
    --print("LoadAppconf=============>>")
    if SystemConfig.isIGGPlatform() then
        SdkManager.func = func
        _loadAppconf = false
        SdkManager.bload_appcfg_end = false
        --加载appconfig
        cIGGSdkInterface.LoadAppconf()

        local coro = cs_coroutine.start(function()
            local waittime = 60
            for i = 1, waittime do
                if _loadAppconf then
                    SdkManager.bload_appcfg_end = true
                    return nil
                else
                    coroutine.yield(CS.UnityEngine.WaitForSeconds(1))
                end
            end
        end)
        return coro
    else
        func()
        return
    end
end

--白名单检查
function SdkManager:CheckWhiteIdList()
    local bWhiteId = false
    if not SystemConfig.AppConfig then
        return bWhiteId
    end
    local cur_client = SystemConfig.AppConfig.clientIp

    local logincfg = SystemConfig.AppConfig.rawString["LoginBox"]
    if logincfg then
        local whiteListStatus = logincfg["whiteListStatus"]
        local whiteListIp = logincfg["whiteListIp"]
        if whiteListStatus and whiteListIp then
            if whiteListStatus == "1" then 
                local iplist = string.split(whiteListIp, ",")
                if iplist and next(iplist) then
                    for k,value in pairs(iplist) do
                        if value == cur_client then
                            bWhiteId = true
                            break
                        end
                    end
                end
            end
        end
    end
    return bWhiteId
end

--强更检查
function SdkManager.CheckForceVersion()
    local bforce, contentStr = false, ""
    --if not Application.isEditor then
        local logincfg = SystemConfig.AppConfig.rawString["LoginBox"]
        local messagecfg = SystemConfig.AppConfig.rawString["Messages"]
        if messagecfg and messagecfg["content"] then
            contentStr = messagecfg["content"]["forceUpdate"] or ""
        end
        if logincfg then
            local forceVersion = logincfg["forceVersion"]
            if forceVersion and forceVersion ~= "" then
                local version = Application.version
                bforce = _CheckVersionNum(forceVersion, version)
            end
        end
    --end
    print("CheckVersion===", SystemConfig.ResVersion, Application.version, bforce, contentStr)
    return bforce, contentStr
end

--维护检查serverTime 服务器时间
function SdkManager.checkShowMaintain(serverTime)
    local bshow = false
    local contentStr = ""
    local timeLeft = 0

    local iggzone = SdkManager._GetCurZone()
    --local updatecfg = SystemConfig.AppConfig.rawString["Update"]
    --local logincfg = SystemConfig.AppConfig.rawString["LoginBox"]
    local messagecfg = SystemConfig.AppConfig.rawString["Messages"]

    local bMainTainIn = SystemConfig.AppConfig.MainTainIn.isMaintain
    local startTime = SystemConfig.AppConfig.MainTainIn.startTime
    local endTime = SystemConfig.AppConfig.MainTainIn.endTime
    local startTimeStr = SystemConfig.AppConfig.MainTainIn.startTimeStr
    local endTimeStr = SystemConfig.AppConfig.MainTainIn.endTimeStr
    
    if serverTime then
        if bMainTainIn and serverTime >= startTime and serverTime <= endTime then
            if messagecfg and messagecfg["content"] and messagecfg["content"]["maintain"] then
                contentStr = SdkManager.regmatchstr(messagecfg["content"]["maintain"], {{ ["key"] = "utc", [0] = SdkManager.changeLocalZonebyStr(startTimeStr, iggzone), 
                    [1] = SdkManager.changeLocalZonebyStr(endTimeStr, iggzone), [2] = SystemConfig.AppConfig.MainTainIn.awardNum}})
            end
            bshow = true
            timeLeft = endTime - serverTime
        end
    end

    -- print("bshow, contentStr, timeLeft===", bshow, contentStr, timeLeft)
    return bshow, contentStr, timeLeft
end

--转换为本地时区 by string
function SdkManager.changeLocalZonebyStr(str, zone)
    local time = SdkManager.string2time(str)    
    time = SdkManager.changeLocalZone(time, zone)
    return SdkManager.formatYMDHM(time)
end

function SdkManager._GetCurZone()
    local zone = 8
    if SystemConfig.isIGGPlatform() then
        zone = -5
    end
    return zone
end

function SdkManager._GetLocalZone()
    return os.difftime(os.time(), os.time(os.date("!*t", os.time()))) /3600
end

function SdkManager.changeLocalZone(time, zone)
    zone = zone or SdkManager._GetCurZone()
    
    local localZone = SdkManager._GetLocalZone()
    local offset = localZone - zone
    return time + offset * 3600 + (os.date("*t", time).isdst and 3600 or 0)
end

--2019-02-05 10:50
function SdkManager.formatYMDHM(time)
    local str = ""
    local t = os.date("*t", time)
    local month,day,hour,min = t.month,t.day,t.hour,t.min
    if t.month < 10 then
        month = string.format("0%d", t.month)
    end
    if t.day < 10 then
        day = string.format("0%d", t.day)
    end
    if t.hour < 10 then
        hour = string.format("0%d", t.hour)
    end
    if t.min < 10 then
        min = string.format("0%d", t.min)
    end

    local str1 = string.format("%d-%s-%s", t.year, month, day)
    local str2 = string.format("%s:%s", hour, min)
    local str = str1 .. " " .. str2
    return str
end

-- 输入总秒数，输出00:01:44
function SdkManager.formatTickTime(totalSeconds)
    local hour = math.floor(totalSeconds / 3600)
    local minutes = math.floor((totalSeconds - hour * 3600) / 60)
    local seconds = math.floor((totalSeconds - hour * 3600) % 60)

    local strTime = ""
    if hour < 10 then
        strTime =  "0" .. hour .. ":" -- "小时"
    else 
        strTime = hour .. ":" -- "小时"
    end
    if minutes == 0 then
        strTime = strTime .. "00" .. ":"
    elseif minutes < 10 then
        strTime = strTime .."0" .. minutes .. ":"
    else
        strTime = strTime .. minutes .. ":"
    end
    if seconds == 0 then
        strTime = strTime .. "00" -- "秒"
    elseif seconds < 10 then
        strTime = strTime .."0" .. seconds -- "秒"
    else
        strTime = strTime .. seconds -- "秒"
    end 
    return strTime
end

--字符串时间转成时间戳 时间格式必须为 2018-08-07 10:43:33
function SdkManager.string2time(timeString)
    if type(timeString) ~= 'string' then error('string2time: timeString is not a string') return 0 end
    local fun = string.gmatch( timeString, "%d+")
    local y = fun() or 0
    if y == 0 then error('timeString is a invalid time string') return 0 end
    local m = fun() or 0
    if m == 0 then error('timeString is a invalid time string') return 0 end
    local d = fun() or 0
    if d == 0 then error('timeString is a invalid time string') return 0 end
    local H = fun() or 0
    if H == 0 then error('timeString is a invalid time string') return 0 end
    local M = fun() or 0
    -- if M == 0 then error('timeString is a invalid time string') return 0 end
    local S = fun() or 0
    -- if S == 0 then error('timeString is a invalid time string') return 0 end
    return os.time({year=y, month=m, day=d, hour=H,min=M,sec=S})
end

function SdkManager.regmatchstr(str, args_list)
    for _, args in ipairs(args_list) do
        local left = "%["..args["key"].."]"
        local right = "%[/"..args["key"].."]"
        local regkey = left.."(%d+)"..right
        for s in string.gmatch(str, regkey) do
            local key = left..s..right
            if tonumber(s) and args[tonumber(s)] then
                str = string.gsub(str, key, args[tonumber(s)])
            end
        end     
    end
    return str
end

function SdkManager.IsForceUpdate()
    return SdkManager.bforce
end

function SdkManager.IsLoad_Appcfg_End()
    return SdkManager.bload_appcfg_end
end

function SdkManager.SetMaintainViewValue(value)
    SdkManager.maintain_view = value
end

function SdkManager.GetMaintainViewValue()
    return SdkManager.maintain_view
end

--用于显示tsh按钮
function SdkManager.IsSdkInitSus()
    return _loadAppconf
end

--重启LUA虚拟机需要先Dispose
function SdkManager.Dispose()
	if SystemConfig.isIGGPlatform() then
		cIGGSdkInterface.Dispose()
	end
end

return SdkManager