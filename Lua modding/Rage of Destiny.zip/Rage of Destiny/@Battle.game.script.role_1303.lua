-- 湍流少女·洁西卡（水元素法师）
local conf = { skill = {}, buff = {}, bullet = {} }

-- 水弹（普攻）——朝目标发射水弹，造成n%攻击力的伤害
conf.skill[130301] = {
    action = {
        default = {
            {trigger.time, {0}, action.active, script.prop('active'), },
            {trigger.time, script.prop('time'), caller.body.addchild, script.prop('bullet_table'), scriptcommon.bullet_trace, {speed = 20000, duration = 2000, rangeid = 130301}},
            {trigger.time, {600} },
        },
    },
    event = {
        {scriptevent.onstart, onfire = function(self)
            local randomid = tsmath.random(2)
            self.prop.bullet_table = {typeid = 130300 + randomid}
            self.prop.time = {({466,600})[randomid]}
            self.prop.active = ("attack0"..randomid)
        end},
    }
}


-- 水蛇之舞（必杀技）——在最集中的敌人区域召唤两条巨大水蛇，造成n%攻击力的范围伤害

-- 伤害提升至n%攻击力，离攻击区域中心越近的敌人，将受到2倍额外伤害

-- 攻击范围留下巨大旋涡，对范围内的敌人每n秒造成m%攻击力的伤害，持续x秒
conf.skill[130311] = script.composite{
    main = {
        action = {
            default = {
                {trigger.time, {0}, caller.view.active, "spell_01",caller.skill.pause, 2000},
                -- {trigger.time, {500}, caller.view.active, "spell_01_loop"},
                -- {trigger.time, {1200}, action.cast, 130341, scriptcommon.bullet_single},
                {trigger.time, {200}, action.addchild, script.prop("bullet_args"), "bullet_single"},
                --{trigger.time, {1000}, action.cast, 130341, scriptcommon.bullet_single},
                {trigger.time, {2000}},
            },
        },
        event = {
            {scriptevent.onstart, onfire = function (self)
                local targets = self.action:range(self.static.id)
                local position = #targets > 0 and targets[1].body.position or self.owner.body.position
                local centerx, centery = self.service.area:getbattlecenter()
                position.x = centerx
                self.prop.ultimatelevel = self.action.info.level >= 2 and 1 or 0
                self.prop.bulletcastid = self.action.info.level + 130311 - 1
                self.prop.bullet_args = {typeid = 999999, position = position}
            end},
        }
    },
    bullet_single = {
        action = {
            default = {
                {trigger.time, {0},   action.active, "130311"},
                {trigger.time, {2400},action.cast, 130342, action.cast, script.prop("bulletcastid")},
                {trigger.time, {500}, action.cast, 130342, action.cast, script.prop("bulletcastid")},
                {trigger.time, {500}, action.cast, 130342, action.cast, script.prop("bulletcastid")},
                -- {define = script.equal("ultimatelevel", 1), trigger.time, {500,1000, 5}, action.cast, 130343}, -- 留下旋涡
                
                --{define = script.equal("ultimatelevel", 1), trigger.time, {0}, action.cast, 130312},
                {trigger.time, {1000}, caller.body.destroy},
            },
            event = {
                {scriptevent.onstart, onfire = function(self)
                end}
            },
        },
    },
}


conf.skill[130312] = conf.skill[130311]
conf.skill[130313] = conf.skill[130311]


-- 水鲛弹（常规技能1）——在头顶召唤巨大的净化水珠，每0.5s随机选择一个敌方英雄发射大水弹，对其及周围造成n%攻击力的伤害

-- 伤害提升至n%攻击力

-- 攻击段数提高至n段，且每次同时向两个目标发射
-- 挂buff实现
conf.skill[130321] = {
    action = {
        default = {
            {trigger.time, {0},   caller.view.active , "spell_02"},
            {trigger.time, {1000}, action.addstartbuff, },
            {trigger.time, {800}},
        },
    },
    event = {
        {scriptevent.onstart, onfire = function(self)
        end}
    }
    
}

conf.skill[130322] = conf.skill[130321]
conf.skill[130323] = conf.skill[130321]
conf.skill[130324] = conf.skill[130321]

--水弹buff，每n秒发射一个水弹
conf.buff[1303210] = script.composite {
    main = {
        event = {
            {scriptevent.onstart, onfire = function (self) -- 在头顶添加一个follow child
                local position = self.owner.body.position
                -- local radius = 1000
                self.prop.double_rate = 0
                self.prop.position = position
                self.prop.child = self.action:addchild({typeid = 130322, position = position},"bullet_single")
            end},
            {scriptevent.ontimer, time = {500,500}, onfire = function (self)
                -- self.prop.child.caller.view:active("bullet_loop")
                local position = self.caller.body.position
                local castid = self.caller.skill:getslot(SKILL.SLOT.SKILL3).skillid--self.caller.skill:getslotlevel(SKILL.SLOT.SKILL3) + 130321 - 1
                
                local bullet_args = {speed = 20000, duration = 2000, castid = castid, rangeid = 130351, burn_range = 1500} -- burn_range:波及范围
                local child_args = {{typeid = 130321, position = position}, scriptcommon.bullet_trace, bullet_args}

                self.action:addchild(child_args[1],child_args[2],child_args[3])
                
                if castid >= 130323 and tsmath.random_match(self.prop.double_rate) then--当3级之后，向两个目标发射
                    self.action:addchild(child_args[1],child_args[2],child_args[3])
                end
            end},
            {scriptevent.onend, onfire = function (self)
                self.prop.child:sendmessage("130321_child_destory")
                -- buff结束提醒子弹销毁
            end}
        }
    },
    bullet_single = {
        action= {
            born = {
                {trigger.time, {0}, caller.view.active, "130322_start"},

            },
            destroy = {
                {trigger.time, {0}, caller.view.active, "130322_end"},
                {trigger.time, {500}, caller.body.destroy},
            }
        },
        event = {
            {scriptevent.onstart, onfire = function(self)
                local radius = 1000
                self.caller.body:addlogic("sprite.basic.sprite_follow_logic", {target = self.owner.body.parent, keep_distance = radius})
            end},
            {"130321_child_destory", onfire = function(self)
                self.action:run("destroy")
            end}
        }
    }

}


conf.buff[1303220] = conf.buff[1303210]
-- 伤害提升至n%攻击力

-- 水盾（被动技能）——给最虚弱的友军添加水体护盾，最多能吸收%攻击力的伤害
conf.skill[130331] = {
    action = {
        default = {
            {trigger.time, {0},   caller.view.active , "spell_03"},
            {trigger.time, {500}, action.addstartbuff, action.cast},
            {trigger.time, {1000}},
        },
    },
    check = function(self)
        return (not self.caller.state:isdead() and #self.caller.taunt:get() == 0 ) -- 自身没有死亡
    end
}

conf.skill[130332] = conf.skill[130331]
conf.skill[130333] = conf.skill[130331]


conf.buff[1303310] = {
    event = {
        {scriptevent.onend, onfire = function(self)
            self.caller.buff:add(130334, self.owner)
        end},
    }
}
conf.buff[1303330] = {
    event = {
        {scriptevent.onstart, onfire = function(self)
            local rebound = self.owner.attr.harm_rebound
            local rebound_rate = 300
            self.owner.attr.harm_rebound = rebound and rebound + rebound_rate or rebound_rate -- 反弹伤害
            self.prop.rebound_rate = rebound_rate
        end},
        {eventdef.skill_damage, modifer = eventmdf.excludeself, onfire = function (self, fromobj, damage_table)
        --2级效果护盾存在时，反弹n%受到的伤害，并有一定概率使目标减速m秒
            if damage_table.toobj == self.owner then
                -- if tsmath.random_match(1000) then
                    fromobj.caller.buff:add(130332,self.owner)
                -- end
            end
        end},
        {scriptevent.onend, onfire = function(self)
            self.owner.attr.harm_rebound = self.owner.attr.harm_rebound - self.prop.rebound_rate
            self.caller.buff:add(130334,self.owner)
        end},
    }

}


return conf