
local RelationDef = {}
RelationDef.NotifyDef =
{
    Relation_RequestList="Relation_RequestList",
    Relation_RequestMyAidList="Relation_RequestMyAidList",
    Relation_SetRelationHeroList="Relation_SetRelationHeroList", --获取可以激活羁绊的英雄列表
    Relation_DoingActive="Relation_DoingActive", 
    Relation_UpdateAidRedDot="Relation_UpdateAidRedDot", 
}

RelationDef.CommonDef={

    AmountTips="Aid_1005",
    Resting="Aid_1001",
    DoTasking="Aid_1002", --Aid_1003&&正在帮助%d激活羁绊
    HasBeenPermanentActive="Aid_1006",
    ActiveProgressIncline="Aid_1007",
}

RelationDef.Property={

    [1]="Aid_1008",
    [2]="Aid_1009",
    [3]="Aid_1010",
}
RelationDef.Rank={

    [1]="Aid_1017",
    [2]="Aid_1018",
    [3]="Aid_1019",
}

RelationDef.Btn = ----需要改成多语言配置的id
{
    [1] = "Aid_1011", --信息
    [2] = "Tree_view_1001",
    --[2]="RoleInfoView_1003",--设置
    --[3]="Common_1014", --成就
}

RelationDef.BtnIcon = {
    [1] = "relation",
    [2] = "tree",
}

RelationDef.OpenViews={
    [1]=UIWidgetNameDef.RelationMenuView,
    [2]=UIWidgetNameDef.RelationTreeView,
}

local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
RelationDef.ModuleOpenType = {
    [1] = ModuleOpenDef.SystemOpenType.RelationMenuRootView_2,
    [2] = ModuleOpenDef.SystemOpenType.Tree, 
}

RelationDef.FullScreenViewBg = {
    [1] = "Tex_Bg_8",
    [2] = "Tex_Bg_tree",
}
return RelationDef
