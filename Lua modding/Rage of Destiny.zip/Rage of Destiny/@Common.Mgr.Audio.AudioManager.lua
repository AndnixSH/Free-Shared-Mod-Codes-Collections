local LanguageManager = require "Common.Mgr.Language.LanguageManager"
local Timer = require "Common.Util.Timer"

local AudioManager = {}
AudioManager.default = 1
AudioManager.config = ConfigManager.GetConfig("data_sound")
AudioManager._bgm_key = nil
AudioManager.AudioType =
{
	None = 0,
	Sound = 1,
	Music = 2,	
}

local music_effect = "mx_music_effect"
local sound_effect = "mx_sound_effect"
local music_volume = "mx_music_volume"
local sound_volume = "mx_sound_volume"
local bgm_sound_key = "mx_bgm_sound_key"

local cs_AudioManager = CS.LJY.NX.AudioManager.Instance

function AudioManager.GetConfig(key)
	if AudioManager.config[key] then
		return AudioManager.config[key]
	else
		-- print("error: no find sound, key,idx:", key, idx)
	end	
end

function AudioManager.AudioSetting(audioType, bopen)
	-- if audioType == AudioManager.AudioType.Music then
	-- 	PlayerPrefs.SetInt(music_effect, bopen and 0 or 1)
	-- 	if bopen then
	-- 		--只有主界面才能关闭,所有打开只重新加载主场景音乐
	-- 		AudioManager.PlaySoundByKey("main_bg")
	-- 	else	
	-- 		AudioManager.StopAllAudio(audioType)
	-- 	end	
	-- elseif audioType == AudioManager.AudioType.Sound then
	-- 	PlayerPrefs.SetInt(sound_effect, bopen and 0 or 1)
	-- end		
end

--size 0~1
function AudioManager.VolumeSetting(audioType, volume)
	volume = Mathf.Clamp(volume, 0, 1)
	if audioType == AudioManager.AudioType.Music then
		local befor_volume = AudioManager.GetVolume(audioType)
		PlayerPrefs.SetFloat(music_volume, volume)

		local strSoundName = bgm_sound_key  -- AudioManager.GetSoundNameByKey("main_bg")
		--只有主界面才能设置音量,所有只设置主场景音乐大小
		--print("------ww-----",PlayerPrefs.GetInt(music_effect),strSoundName,volume)
		AudioManager.SetVolume(strSoundName, volume)
		if volume > 0 and befor_volume == 0 then
			AudioManager.PlayBGM(AudioManager._bgm_key)
		end
		-- if PlayerPrefs.GetInt(music_effect) == 0 and AudioManager.IsActiving(strSoundName)	 then 	
			
		-- end	

	elseif audioType == AudioManager.AudioType.Sound then
		PlayerPrefs.SetFloat(sound_volume, volume)
		if volume == 0 then
			AudioManager.StopAllAudio(AudioManager.AudioType.Sound)
		end
	end	
end

function AudioManager.GetVolume(audioType)
	local volume = 0
	if audioType == AudioManager.AudioType.Music then
		volume= PlayerPrefs.GetFloat(music_volume)

	elseif audioType == AudioManager.AudioType.Sound then
		volume= PlayerPrefs.GetFloat(sound_volume)
	end	
	return volume
end

function AudioManager.CheckSound(audioType)
	if audioType == AudioManager.AudioType.Music then
		return PlayerPrefs.GetInt(music_effect) == 0

	elseif audioType == AudioManager.AudioType.Sound then
		return PlayerPrefs.GetInt(sound_effect) == 0
	end	
	return false
end

function AudioManager.PlaySoundByKey(key ,soundkey, volume)

	if AudioManager.config[key] then
		local cfg = AudioManager.config[key]
		volume = volume or cfg.volume

		local soundName = AudioManager.GetLanguageInfo(cfg)
		if AudioManager.CheckSound(cfg.type) and soundName then
			if cfg.delay and cfg.delay > 0 then
				local timer = Timer.New(function ()		
						AudioManager.PlaySound(soundName, soundkey, cfg.type, cfg.loop, volume or 1)
					end, cfg.delay, 1)
				timer:Start()
			else	
				AudioManager.PlaySound(soundName, soundkey, cfg.type, cfg.loop, volume or 1)
			end	
		end	
	else
		print("error: no find sound, key,idx:", key, idx)
	end	
end

function AudioManager.PlayBGM(key)
	key = key or "main_bg"
	AudioManager._bgm_key = key
	local volum = AudioManager.GetVolume(AudioManager.AudioType.Music)
	if volum == 0 then
		AudioManager.VolumeSetting(AudioManager.AudioType.Music,volum)
		return
	end
	AudioManager.StopBGM()
	AudioManager.PlaySoundByKey(key, bgm_sound_key)
end

function AudioManager.StopBGM(key)
	if key and key ~= AudioManager._bgm_key then
		return
	end
	AudioManager.StopSound(bgm_sound_key)
end

function AudioManager.SetBGMPitch(pitch)
	AudioManager.SetPitch(bgm_sound_key, pitch)
end

-- return soundName,time
function AudioManager.GetLanguageInfo(cfg)
	local soundName = cfg.sound[1]
	local time = cfg.time and cfg.time[1] or 0

	local idx = LanguageManager.Instance:GetCurLanguageIdx()
	if cfg.sound[idx] then
		soundName = cfg.sound[idx]
		time = cfg.time and cfg.time[idx] or 0

	--默认设置为英语	
	elseif #cfg.sound >= 2 and idx ~= 0 then
		soundName = cfg.sound[2]
		time = cfg.time and cfg.time[2] or 0
	end		

	return soundName,time
end

--路径, 类型, 循环, 声音, 速度
function AudioManager.PlaySound(strSoundName, soundkey, type, isLoop, volume, pitch)		
	--print("-----------strSoundName--------",strSoundName)
	type = type or AudioManager.AudioType.Sound
	isLoop = isLoop or false
	pitch = pitch or AudioManager.default
	soundkey = soundkey or ""
	strSoundName = strSoundName or ""
	if type == AudioManager.AudioType.Sound then
		if AudioManager.GetVolume(AudioManager.AudioType.Sound) == 0 then
			return
		end
	end
	if cs_AudioManager then
		cs_AudioManager:PlaySound(strSoundName, tostring(soundkey), type, isLoop, volume or 1, pitch)
	end	
end

function AudioManager.StopSoundByKey(key ,idx)
	idx = idx or 1
	if AudioManager.config[key] and AudioManager.config[key].sound[idx] then
		local cfg = AudioManager.config[key]
		local strSoundName = cfg.sound[idx]
		local type = cfg.type
		AudioManager.StopSound(strSoundName)
	else
		-- AudioManager.StopSound(key)
		-- print("error: no find sound, key,idx:", key, idx)
	end		
end	

function AudioManager.StopSound(strSoundName)
	if not string.isEmpty(strSoundName) and cs_AudioManager then
		cs_AudioManager:StopSound(strSoundName)
	end	
end

function AudioManager.GetSoundNameByKey(key ,idx)
	idx = idx or 1
	if AudioManager.config[key] and AudioManager.config[key].sound[idx] then
		local cfg = AudioManager.config[key]
		local strSoundName = cfg.sound[idx]
		return strSoundName
	end		
	return ""
end

function AudioManager.PauseSound(strSoundName)
	if not string.isEmpty(strSoundName) and cs_AudioManager then
		cs_AudioManager:PauseSound(strSoundName)
	end	
end

function AudioManager.SetVolume(strSoundName, volume)
	if not string.isEmpty(strSoundName) and cs_AudioManager then
		cs_AudioManager:SetVolume(strSoundName, volume)
	end	
end

function AudioManager.SetPitch(strSoundName, pitch)
	if not string.isEmpty(strSoundName) and cs_AudioManager then
		cs_AudioManager:SetPitch(strSoundName, pitch)
	end	
end

function AudioManager.StopAllAudio(type)
	if cs_AudioManager then
		cs_AudioManager:StopAllAudio(type or AudioManager.AudioType.None)
	end	
end

function AudioManager.IsActivingByKey(key, idx)
	local strSoundName = AudioManager.GetSoundNameByKey(key ,idx)
	return AudioManager.IsActiving(strSoundName)
end	

function AudioManager.IsActiving(strSoundName)
	if not string.isEmpty(strSoundName) and cs_AudioManager then
		return cs_AudioManager:IsActiving(strSoundName)
	end	
end

function AudioManager.DestroyAllAudio()
	if cs_AudioManager then
		cs_AudioManager:DestroyAllAudio()
	end	
end

return AudioManager
