local logic = { timer = {}, event = service.event(), call = service.call(calldef.mp) }

function logic.timer:t1000()
    local toobj = self.owner
    if toobj.attr.mps > 0 and toobj.attr.mp < toobj.attr.mp_max then
        local rate = toobj.attr.mp_rate - toobj.attr.mp_rate_d
        self:change_mp(toobj, toobj.attr.mps + tsmath.rate(toobj.attr.mps, rate))
    end
end

function logic.event.sprite:skill_choose(fromobj, damage_table)
    self:skill_choose(fromobj, damage_table)
end

function logic:skill_choose(fromobj, damage_table)
    local toobj = self.owner

    -- local attack_mp_add, battack_mp_add = damage_table.attack_mp_add, damage_table.battack_mp_add
    -- if attack_mp_add and fromobj.attr.mp < fromobj.attr.mp_max then
    --     local rate = fromobj.attr.mp_rate - fromobj.attr.mp_rate_d + fromobj.attr.dmg_mp_rate - fromobj.attr.dmg_mp_rate_d
    --     self:change_mp(fromobj, attack_mp_add + tsmath.rate(attack_mp_add, rate))
    -- end
    -- if battack_mp_add and toobj.attr.mp < toobj.attr.mp_max then
    --     local rate = toobj.attr.mp_rate - toobj.attr.mp_rate_d + toobj.attr.harm_mp_rate - toobj.attr.harm_mp_rate_d
    --     self:change_mp(toobj, battack_mp_add + tsmath.rate(battack_mp_add, rate))
    -- end
end


function logic:change_mp(toobj, amount, fromobj, bsct)
    if amount ~= 0 and self.caller.state and not self.caller.state:isdead() then
        toobj.attr.mp = tsmath.clamp(toobj.attr.mp + amount, 0, toobj.attr.mp_max)
        -- gamelog.sprite(toobj, "mp_change", amount)
        if bsct then
            self.caller.view:battlesct(toobj, toobj, DAMAGE_STATE.MP, amount)
        end
    end
end

function logic.call:change(value, fromobj, bsct)
    self:change_mp(self.owner, value, fromobj, bsct)
end

function logic.call:cast_change(value, fromobj, bsct)
    if value and value > 0 then
        local target = self.owner
        local rate = target.attr.mp_rate - target.attr.mp_rate_d + target.attr.dmg_mp_rate - target.attr.dmg_mp_rate_d
        value = value + tsmath.rate(value, rate)
        if value > 0 then
            self:change_mp(target, value, fromobj, bsct)
        end
    end
end

function logic.call:buff_change(value, fromobj, bsct)
    local target = self.owner
    if value and value > 0 then
        local rate = target.attr.mp_rate - target.attr.mp_rate_d
        value = tsmath.max(value + tsmath.rate(value, rate), 0)
    end
    self:change_mp(target, value, fromobj, bsct)
end

return logic