local LoginProxy = require "Modules.Login.LoginProxy"
local ClistRender = require "Core.Implement.UI.Class.ClistRender"
local ClistItem = require "Core.Implement.UI.Class.ClistItem"
local LoginDef =  require "Modules.Login.LoginDef"

local SocketListPanel = SocketListPanel or BaseClass(GameObjFactor)
local SocketItem = SocketItem or BaseClass(ClistItem)
	
function SocketListPanel:__init(obj)
	self.go = obj
	self:InitObj(obj)
end

function SocketListPanel:InitObj(obj)

	self.comboBox =  GameObjTools.GetComponent(obj, "CComboBox")
	self.socketList = GameObjTools.GetChildComponent(obj, "list", "CList")
	self.listRender = ClistRender.New()
	self.listRender:Load(self.socketList,SocketItem) 
	self.listRender:AddSelect(function (item, index)
		self:OnSelect(item, index)
	end)

	self.selectInput = GameObjTools.GetChildComponent(obj, "ipInp", "CTextInput")
	self.selectData = nil
	self:SetData()

	self:SetDepth(self.go, self:GetNextDepth())
end	

function SocketListPanel:SetData()
	local cfgdata = ConfigManager.GetConfig("data_socket", false)	
	self.socketList:ClearData()
	self.socketList:AppendDataList(cfgdata)

	local default =  PlayerPrefs.GetInt(LoginDef.socketSelectIdx)
	if default and tonumber(default) ~= 0 then
		local cfg = cfgdata[tonumber(default)]
		if not cfg then
			cfg = cfgdata[1]
			self.socketList.SelectIndex = 0
		else
			self.socketList.SelectIndex = default - 1
		end
		local item = {}
		item.data = cfg
		self:OnSelect(item,default)
	else
		self.socketList.SelectIndex = 0	
	end
end

function SocketListPanel:OnSelect(item, index)
	self.selectInput.text = item.data.name
	self.selectData = item.data
	self.comboBox:OnClose()
	PlayerPrefs.SetInt(LoginDef.socketSelectIdx, index)

	-- LoginProxy.Instance:SetLoginInfo(item.data.name, item.data.ip, item.data.port)
end

function SocketListPanel:Open()
	if LoginProxy.Instance:Is_WLan_Release() then
		self.go:SetActive(false)
	elseif SystemConfig.isIGGPlatform() then
		self.go:SetActive(false)
	else
		self.go:SetActive(true)
	end
end

function SocketListPanel:Close()
	self.go:SetActive(false)
	-- LoginProxy.Instance:SetLoginInfo()
end

function SocketListPanel:Destroy()
	if self.listRender then
		self.listRender:Destroy()
	end
end

-----------SocketItem------------
function SocketItem:Load(go)
	self.rendr = GameObjTools.GetComponent(go, "CBaseRender")
end

function SocketItem:SetData(data)
	self.data = data
	self.rendr.defaultLabel.text = string.format("%s, ip:%s, port:%s" ,data.name ,data.ip ,data.port)
end
return SocketListPanel