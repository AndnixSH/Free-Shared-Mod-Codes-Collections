local skill_base = {}
skill_base.__index = skill_base

function skill_base:init(context)
    self._context = context
    self._running = false
    self._spdrate = nil
end

function skill_base:start()
    if self._running then return end
    self._running = true
    if self.onstart then
        self.onstart(self._context)
    end
end

function skill_base:stop()
    if not self._running then return end
    self._running = false
    if self.onend then
        self.onend(self._context)
    end
end

function skill_base:setspeed(speed)
    self._spdrate = speed
    if self.onspeed then
        self.onspeed(self._context, speed)
    end
end

function skill_base:getspeed()
    return self._spdrate
end

function skill_base:isrun()
    return self._running
end

function skill_base:check()
    if self.oncheck then
        return self.oncheck(self._context)
    end
    return true
end

function skill_base:destroy()
end

function skill_base:tobuff(typeid, prop, toobj, fromobj)
    return (fromobj or self._context.owner).caller.buff:add(typeid, prop, toobj)
end

function skill_base:tosuffer(typeid, prop, toobj, fromobj)
    return (fromobj or self._context.owner).caller.suffer:add(typeid, prop, toobj)
end

function skill_base:todamage(toobj, damagetable, fromobj)
    
end

function skill_base:toheal(toobj, healtable, fromobj)
    
end

function skill_base:select_target()
    if self.onselect then
        return self.onselect(self._context)
    end
end



local skillserver = {}

function skillserver:addskill(obj, skillid, prop)
    local skill_config = global.service.config:get("skill_static")
    local static = skill_config[skillid]
    if not static then
        global.debug.warning("skill_static找不到"..skillid)
    end
    local template = global.service.requirer:require("sprite.skill.skill_script_runner")
    return global.service.logic_factory:createlogic(obj, skillid, static, prop or {}, template)
end

function skillserver:load(tb, context, source)
    setmetatable(tb, skill_base)
    local newskill = {}
    setmetatable(newskill, {__index = tb})
    newskill:init(context)
    return newskill
end

function skillserver:unload(tb)
    tb:destroy()
end

function skillserver:dump()
end

function skillserver:dispose()
end

return skillserver