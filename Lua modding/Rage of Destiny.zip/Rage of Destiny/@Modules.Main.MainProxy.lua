local MainDef = require "Modules.Main.MainDef"
local MainProxy = MainProxy or BaseClass(BaseProxy)
function MainProxy:__init(name)
	MainProxy.Instance = self
	self.data = {}
end

function MainProxy:__delete()
	self.data = nil
end

function MainProxy:MainTweenNotify(state)	
	self:ToNotify(self.data, MainDef.NotifyDef.Main_Tween_bar, state)
end

function MainProxy:ReShowNotify()
	self:ToNotify(self.data, MainDef.NotifyDef.ReShow)
	local BattleProxy = require "Modules.Battle.BattleProxy"
	BattleProxy.Instance:ContinusGame()
	--print("--------------------->>>MainProxy.ReShowNotify<<<---------------------")
	--local render_area = require "Battle.render.render_area"
	--render_area.show()
end

function MainProxy:HideViewNotify()
	self:ToNotify(self.data, MainDef.NotifyDef.HideView)
end

function MainProxy:HideSceneNotify()

	self:ToNotify(self.data, MainDef.NotifyDef.HideScene)
end

function MainProxy:UpdateRedDot(type, rednum, ...)
	self:ToNotify(self.data, MainDef.NotifyDef.UpdateRedDot, {type = type, rednum = rednum, args = {...}})
end

function MainProxy:OpenFullScreenWidgetNotify(widgetName)
	self:ToNotify(self.data, MainDef.NotifyDef.OpenFullScreenWidget, {widgetName = widgetName})
	local BattleProxy = require "Modules.Battle.BattleProxy"
	BattleProxy.Instance:StopGame()
	--print("--------------------->>>MainProxy.OpenFullScreenWidgetNotify<<<---------------------")
	--local render_area = require "Battle.render.render_area"
	--render_area.hide()
end


return MainProxy
