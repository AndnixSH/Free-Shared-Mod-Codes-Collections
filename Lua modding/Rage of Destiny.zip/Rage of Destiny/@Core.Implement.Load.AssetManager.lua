AssetManager = {}

local AssetLoaderAdapter = CS.LJY.NX.AssetLoaderAdapter
local ResType = CS.ResType
local UIPoolManager = CS.LJY.NX.UIPoolManager

AssetManager.UITexture = {
    UITex = "", --大图
    --压缩
    Background = "Background.",
    Goods = "Goods.goods_", --物品
    Skill = "Skill.skill_", --技能
    Exclusive = "Exclusive.exclusive_", --专属技能
    Buff = "Buff.",
    BossQuality = "BossQuality.", --boss品质底板
    Head = "Head.", --头像
    Frame = "Frame.", --头像框
    StoryLine = "StoryLine.", --剧情副本

    Rune = "Rune.", --符文
    NpcHead = "NpcHead.", --NPC头像
    Arena = "Arena.", --竞技场
    Relation = "Relation.", --羁绊
    Guild = "Guild.",
    Hexmap = "Hexmap.",
    Chat = "Chat.BigEMoji.",
    SupplyDepot = "Island.",
    Activity = "Activity.",
    Events = "Events.",

    --高清
    High = "High.", --高清
    Rank = "High.RankBack.", --品质
    HeroPk = "High.RoleVerticalDrawing.RVD_Battle_", --英雄pk图片
    BossPk = "High.RoleVerticalDrawing.RVD_Select_", --英雄pk图片
    HeroSkillPk = "High.RoleVerticalDrawing.RVD_Skill_", --英雄pk图片
    HeroHead = "High.Hero.Hero_head_", --英雄头像 
    Campaign = "High.Campaign.", --英雄头像 
    WorldMapChapter = "High.WorldMapChapter.", --英雄头像 
    BigPk = "High.RoleVerticalDrawing.RVD_Big_", --
    StoryPk = "High.RoleVerticalDrawing.RVD_Story_", --
    Whole = "High.RoleVerticalDrawing.RVD_Whole_", --
    HVD = "High.HeroVerticalDrawing.HVD_", --
    Mall = "High.Mall.",
    HeroSmall = "HeroSmall.HSVD_",
    BossIcon = "Bossicon.roleid_", --boss头像
    GuildChaos = "Chaos.Chaos_boss_",
    GuildChaos2 = "High.Chaos.Chaos_",
    GuildChaos3 = "High.Chaos.Chaos_big_",
    MobilizeGoods = "High.Mobilize."
}

----------------------Loader------------------------------
--形式：LoadUIPrefab("模块.uiprefab")
function AssetManager.LoadUIPrefab(owner, resName, callBack)
    UIPoolManager.Instance:LoadUIPrefab(resName, function(go)
        if go == nil then
            print("[Error] AssetLoad Fail ,resName:", resName)
        elseif callBack ~= nil then
            owner.resName = resName
            callBack(owner, go)
        end
    end)
end

function AssetManager.LoadUIAtlas(owner, resName, callBack)
    UIPoolManager.Instance:LoadUIPrefab(resName, function(go)
        if go == nil then
            print("[Error] AssetLoad Atlas Fail ,resName:", resName)
        elseif callBack ~= nil then
            callBack(owner, go)
        end
    end)
end

function AssetManager.LoadUITexture(textureType, resName, texObj, callBack, forceLoad)
    local _resName = string.format("%s%s", textureType, resName)
    texObj.autoSnap = false
    if texObj.Path ~= _resName or forceLoad then
        if callBack then
            texObj:SetLoadCompleteBack(function()
                callBack()
            end)
        end
        if forceLoad then
            texObj.Path = ""
        end
        texObj.Path = _resName
    else
        --防止图片被销毁,重新加载
        --texObj.enabled = false
        --texObj.enabled = true
        if callBack then
            callBack()
        end
    end
end

function AssetManager.SeedUIPrefab(resNameList, callback)
    UIPoolManager.Instance:SeedUIPrefab(resNameList, callback)
end

function AssetManager.SeedUITexture(resNameList, callback)
    UIPoolManager.Instance:SeedUITexture(resNameList, callback)
end

function AssetManager.UnloadUIPrefab(resName)
    AssetLoaderAdapter.UnLoadUIAssetBundle(resName)
end

function AssetManager.ClearUITexture()
    UIPoolManager.Instance:ClearUITextureCache()
end

function AssetManager.DestroyUIPrefab(resName, go, bsave)
    if bsave == nil then
        bsave = false
    end
    UIPoolManager.Instance:DestroyUIPrefab(resName, go, bsave)
end

function AssetManager.DestroyPoolUIPrefab()
    UIPoolManager.Instance:DestroyPoolUIPrefab()
end

--function AssetManager.DestroyFrameEffect()
--    for obj, data in pairs(_frameEffect) do
--        if data.effect then
--            data.effect:Destroy()
--        end
--    end
--    _frameEffect = {}
--end

AssetManager.LoadSceneType = {
    Always = 1, --常驻内存
    Temp = 2, --临时存在
    Never = 3, --及时卸载
}

function AssetManager.LoadScene(resName, callBack)
    AssetLoaderAdapter.LoadScene(tostring(resName), callBack)
end

function AssetManager.UnloadScene(scene)
    AssetLoaderAdapter.UnloadScene(scene)
end

function AssetManager.SetActiveScene(resName)
    AssetManager.activeSceneName = resName
    AssetLoaderAdapter.SetActiveScene(resName)
end

function AssetManager.GetActiveSceneRootObject()
    return AssetLoaderAdapter.GetActiveSceneRootObject()
end

