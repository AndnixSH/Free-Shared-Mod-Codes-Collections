local data_battle_key = ConfigManager.GetConfig("data_hangup_key")

local scenekey = function (key)
    local tbl = {}
    for k, v in pairs(data_battle_key) do
        tbl[k] = v[key]
    end
    return keyselect(tbl)
end

local game = {
    tick = 100,
    sceneid = 0,
    area = scenekey("area") --战斗区域
}

local logic = {}


local borncfg = { center = tsvector.new(6000, 10000) }

local bornpos = function(index, offset, head)
    local header = tsvector.rotate(tsvector.new(0, 1000), 360 / 5 * (index - 1))
    local pos = borncfg.center + header:fmul(offset)
    return pos, header
end 

local playerlist = {}

local loadconfig = function ()
    local camp1 = tsmath.random_select({1,2,3,4,5}, 5)
    for i, v in ipairs(camp1) do
        local position, header = bornpos(i, 1500)
        playerlist[i] = { seat = v, camp = 1, roleid = 1102, position = { position.x, position.y }, header = { header.x, header.y } }
    end
end

-- 出生buff
local buff = {
    [1] = {900001},
    [2] = {},
}

logic["game.basic.player_born_logic"] = { players = playerlist, born = { [1] = { delay = 500, active = "born_hangup" }, [2] = { delay = 3000, active = "born_hangup" } }, buff = buff }

logic["game.play.group_refresh_logic"] = {

    group = {
        {{6,9535,13535},{6,10914,13441},{6,10531,12113},{6,11795,11552},{6,10980,10435},{6,11977,9477},{6,11795,8447},{6,10531,7886},{6,10914,6558},},
        {{6,9535,6464},{6,9441,5085},{6,8113,5468},{6,7552,4204},{6,6435,5019},{6,5477,4022},{6,4447,4204},{6,3886,5468},{6,2558,5085},},
        {{7,2464,6464},{7,1085,6558},{7,1468,7886},{7,204,8447},{7,1019,9564},{7,22,10522},{7,204,11552},{7,1468,12113},{7,1085,13441},},
        {{8,2464,13535},{8,2558,14914},{8,3886,14531},{8,4447,15795},{8,5564,14980},{8,6522,15977},{8,7552,15795},{8,8113,14531},{8,9441,14914},},
        {{10,9695,11530},{11,9695,11530},{12,9695,11530},},
        {{10,7530,6304},{11,7530,6304},{12,7530,6304},},
        {{10,2304,8469},{11,2304,8469},{12,2304,8469},},
        {{10,4469,13695},{11,4469,13695},{12,4469,13695},},

   },
   startborn = {13,6000,10000},
    wave = {
       {2000,{1,7,9},{3,7,9},},
       {2000,{2,7,9},{4,7,9},},
       {2000,{1,7,9},{3,7,9},{5,1,1},{7,1,1},},
       {2000,{1,7,9},{3,7,9},{4,7,9},},
       {2000,{2,7,9},{3,7,9},{4,7,9},{6,1,1},{7,1,1},{8,1,1},},
       {2000,{1,7,9},{2,7,9},{3,7,9},{4,7,9},},
    },
    max = 1,
    refresh_timer = {1000, 1000},
    center = borncfg.center,
}


logic["game.basic.camera_adjust_logic"] =
{
    delay = 300,   -- 延迟检测(运镜开始时间)
    interval = 1000, -- 检测间隔
    clampx = {-8000,8000},  -- x偏移范围
    clampy = {-8000,8000},  -- y偏移范围
    lift = 0,
}

--摄像机类型
logic["game.basic.camera_strategy_logic"] =
{
    strategy_list = 
    {
        gamestart = 
        {
            strategy = CAMERA_STRATEGY.TRANSFORM,
            confkey = "data_hangup_key",
            argskey = "camera_start",
        },
        camera_adjust_start = 
        {
            strategy = CAMERA_STRATEGY.ADJUST,
            confkey = "data_hangup_key",
            argskey = "camera_adjust",
        }
    }
}


return { game, logic, loadconfig = loadconfig }