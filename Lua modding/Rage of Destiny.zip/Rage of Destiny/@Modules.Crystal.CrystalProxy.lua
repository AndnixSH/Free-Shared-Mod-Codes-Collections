local CrystalDef = require "Modules.Crystal.CrystalDef"
local CrystalProxy = CrystalProxy or BaseClass(BaseProxy)
function CrystalProxy:__init()
	CrystalProxy.Instance = self

	self:AddProto(20100, self.On20100) --水晶信息
	self:AddProto(20101, self.On20101) --上阵
	self:AddProto(20102, self.On20102) --下阵
	self:AddProto(20103, self.On20103) --清空cd
	self:AddProto(20104, self.On20104) --解锁槽位
	self:AddProto(20105, self.On20105) --解锁等级上限
	self:AddProto(20106, self.On20106) --水晶升级
	self:AddProto(20107, self.On20107) --排序

	self.data = {}
	self.data.crystaldata = {}
	self.data.crystaldata.herolist = {}
	self.data.crystaldata.crystainfos = {}
	self.data.crystaldata.level = 0
	self.data.crystaldata.sublevelup = 0
	self.data.crystaldata.maxlevel = 60
	self.data.crystaldata.crystaopencount = 1
	self.data.crystaldata.unlock = 1
	self.data.crystaldata.sorttype = 0  --0:   1:品阶排序  2：种族排序
end	

function CrystalProxy:__delete(self)
    CrystalProxy.Instance = nil
end

--protp
function CrystalProxy:Send20100()
	self:SendMessage(20100)
end

function CrystalProxy:On20100(decoder)
	self.data.crystaldata.herolist = decoder:DecodeList("I4")

	local crystainfos = {}
	local count = decoder:Decode("I2")
	for i=1,count do
		local tab = {}
		tab.herouid, tab.cdtime = decoder:Decode("I4I4")
		table.insert(crystainfos, tab)
	end
	self.data.crystaldata.crystainfos = self:GenerateCrystalHeroList(crystainfos)
	self.data.crystaldata.level = decoder:Decode("I2")
	self.data.crystaldata.sublevelup = decoder:Decode("I2")
	self.data.crystaldata.maxlevel = decoder:Decode("I2")
	self.data.crystaldata.crystaopencount = decoder:Decode("I2")
	self.data.crystaldata.unlock = decoder:Decode("I2")
	self.data.crystaldata.sorttype = decoder:Decode("I2")  --0:   1:品阶排序  2：种族排序

	self:UpdateHeroCrystalLevel()
	self:ToNotify(self.data, CrystalDef.NotifyDef.UpdateCrystal)

	--更新红点
	self:UpdateCrystalRedDot()
	--print("= =On20100 ===>", table.dump(self.data.crystaldata))
end

function CrystalProxy:Send20101(herouid, index)
	local encoder = NetEncoder.New()
	encoder:Encode("I4I2", herouid, index)
	self:SendMessage(20101, encoder)
end

function CrystalProxy:On20101(decoder)
	local result, herouid, index = decoder:Decode("I2I4I2")
	if result == 0 then
		local crystainfo = self:GetCrystalListByIndex(index)
		crystainfo.herouid = herouid
		crystainfo.cdtime = 0
		self:UpdateHeroCrystalLevel()
		self:ToNotify(self.data, CrystalDef.NotifyDef.UpdateCrystalInfo, index)

		UIOperateManager.Instance:OpenWidget(AppFacade.Crystal, 3, herouid)
		
	end
end

function CrystalProxy:Send20102(index)
	local encoder = NetEncoder.New()
	encoder:Encode("I2", index)
	self:SendMessage(20102, encoder)
end

function CrystalProxy:On20102(decoder)
	local result, index = decoder:Decode("I2I2")
	if result == 0 then
		local value = ConfigManager.GetConfig("data_common").crystal_refresh.value1
		local crystainfo = self:GetCrystalListByIndex(index)
		crystainfo.herouid = 0
		crystainfo.cdtime = RoleInfoModel.servertime + value[1]
		self:UpdateHeroCrystalLevel()
		self:ToNotify(self.data, CrystalDef.NotifyDef.UpdateCrystalInfo, index)
	end	
end

function CrystalProxy:Send20103(index)
	local encoder = NetEncoder.New()
	encoder:Encode("I2", index)
	self:SendMessage(20103, encoder)
end

function CrystalProxy:On20103(decoder)
	local result, index = decoder:Decode("I2I2")
	if result == 0 then
		local crystainfo = self:GetCrystalListByIndex(index)
		crystainfo.herouid = 0
		crystainfo.cdtime = 0		
		self:ToNotify(self.data, CrystalDef.NotifyDef.UpdateCrystalInfo, index)
	end
end

-- type 1:精华 2:钻石
-- (类型1 是花所有的材料来解锁  类型2 是花钻石只解锁一个)
function CrystalProxy:Send20104(index, type)
	local encoder = NetEncoder.New()
	encoder:Encode("I2", index)
	encoder:Encode("I2", type)
	count = 1
	if type == 1  then
		count = self:GetCrystalUnlockCount()
	end
	self.cacheCrystalUnlockCount = count
	self:SendMessage(20104, encoder)
end

function CrystalProxy:On20104(decoder)
	local result, index = decoder:Decode("I2I2")
	if result == 0 then
		-- self:Send20100()
		-- local crystainfos = self.data.crystaldata.crystainfos
		-- table.insert(crystainfos, {0,0})
		self:ToNotify(self.data, CrystalDef.NotifyDef.UpdateCrystalOpen, {index = index , count = self.cacheCrystalUnlockCount or 1})
	end	
end

-- type 1:精华 2:钻石
function CrystalProxy:Send20105()
	self:SendMessage(20105)
end

function CrystalProxy:On20105(decoder)
	local result = decoder:Decode("I2")
	if result == 0 then
		self.data.crystaldata.unlock = 0
		self.data.crystaldata.herolist = {}
		self:ToNotify(self.data,  CrystalDef.NotifyDef.UpdateCrystalUnLock)
		
		--更新红点
		self:UpdateCrystalRedDot()
	end	
end

function CrystalProxy:Send20106(isDust)
	local encoder = NetEncoder.New()
	encoder:Encode("I2", isDust and 1 or 0)
	self:SendMessage(20106,encoder)
end

function CrystalProxy:On20106(decoder)
	local result = decoder:Decode("I2")
	if result == 0 then		
		if self.data.crystaldata.sublevelup == 9 then
			self.data.crystaldata.sublevelup = 0
			self.data.crystaldata.level = self.data.crystaldata.level + 1
			
			self:UpdateHeroCrystalLevel()
			self:ToNotify(self.data, CrystalDef.NotifyDef.UpdateCrystal)

			-- LuaLayout.Instance:OpenWidget(UIWidgetNameDef.CrystalUpgradeView)
		else
			self.data.crystaldata.sublevelup = self.data.crystaldata.sublevelup + 1
		end
		self:ToNotify(self.data, CrystalDef.NotifyDef.UpdateCrystalLevelUp ,{result = result})
		self:UpdateCrystalRedDot()
	elseif result ~= 7 then
		GameLogicTools.ShowErrorCode(20106, result)
	end
end

--_type 1:品阶排序  2：种族排序
function CrystalProxy:Send20107(_type)
	local encoder = NetEncoder.New()
	encoder:Encode("I2", _type)
	self:SendMessage(20107, encoder)
end

function CrystalProxy:On20107(decoder)
	local result = decoder:Decode("I1")
	if result == 0 then
		self.data.crystaldata.sorttype = decoder:Decode("I2")
		self.data.crystaldata.crystainfos = self:SortCrystalList(self.data.crystaldata.crystainfos)
		self:ToNotify(self.data, CrystalDef.NotifyDef.UpdateCrystalSort, {crystainfos = crystainfos})
	end
end

function CrystalProxy:GenerateCrystalHeroList(heroList)
	local HeroProxy = require "Modules.Hero.HeroProxy"
    local _state = {
        hero = 1, --有英雄
        unlock = 2, --解锁
        lefttime = 3, --冷却cd
        lock = 4 --未解锁
    }
	local hero_infos = {}
	for i,v in ipairs(heroList) do
		local gridState = _state.lock
		local roleId, rank, race = 0, 0, 0
		local data = v
		if data then
			if data.herouid > 0 then
				local herodata = HeroProxy.Instance:GetHeroDataByUid(data.herouid)
				if herodata then
					local heroCfg = HeroProxy.Instance:GetRoleCfgByConfigId(herodata.roleid)
					gridState = _state.hero
					roleId = herodata.roleid
					rank = herodata.rank
					race = heroCfg.race
				end
			else
				if data.cdtime == 0 then
					gridState = _state.unlock
				else
					gridState = _state.lefttime
				end
			end
			local item = {herouid = data.herouid,  cdtime = data.cdtime, index = i, gridState = gridState, roleId = gridState, rank = rank, race = race}
		
			table.insert(hero_infos, item)
		end
	end
	return hero_infos
end


--1:品阶排序  2：种族排序
function CrystalProxy:SortCrystalList(list)
	local list = list or {}
	local sortType = self.data.crystaldata.sorttype
	if sortType == 1 then
		list = self:SortCrystalByRank(list)
	elseif sortType == 2 then
		list = self:SortCrystalByRace(list)
	end
	return list
end

--1:品阶排序
function CrystalProxy:SortCrystalByRank(list)
	local list = list or {}
	table.sort(list, function(a, b)
		if a.gridState ~= b.gridState then
			return a.gridState < b.gridState
		else
			if a.rank ~= b.rank then
				return a.rank > b.rank
			else
				if a.roleId ~= b.roleId then
					return a.roleId < b.roleId
				else
					return a.index < b.index
				end
			end
		end
	end)
	return list
end

--2:种族排序
function CrystalProxy:SortCrystalByRace(list)
	local list = list or {}
	table.sort(list, function(a, b)
		if a.gridState ~= b.gridState then
			return a.gridState < b.gridState
		else
			if a.race ~= b.race then
				return a.race < b.race
			else
				if a.roleId ~= b.roleId then
					return a.roleId < b.roleId
				else
					return a.index < b.index
				end
			end
		end
	end)
	return list
end

--config
function CrystalProxy:GetCrystalUnlock(id)
	id = id or self.data.crystaldata.crystaopencount
	local config = ConfigManager.GetConfig("data_crystalunlock") 
	if config[id] then
		return config[id]
	end
end

function CrystalProxy:GetCrystalUnlockCount()
	local curcount = RoleInfoModel.inv_essence
	local id = self.data.crystaldata.crystaopencount
	local config = ConfigManager.GetConfig("data_crystalunlock") 
	local count = 0
	local count_coin = 0
	for i=id, #config do
		local cfg = config[i]		
		if count_coin + config[i].item > curcount then
			break
		else
			count_coin = count_coin + config[i].item
			count = count + 1
		end
	end
	return count, count_coin
end

-------------

function CrystalProxy:UpdateHeroCrystalLevel()
	local HeroProxy = require "Modules.Hero.HeroProxy"
	HeroProxy.Instance:UpdateHeroCrystalLevel()
end

function CrystalProxy:GetCrystalData()
	return self.data.crystaldata
end

function CrystalProxy:GetCrystalListByIndex(index)
	local crystainfos = self.data.crystaldata.crystainfos
	if index <= #crystainfos then
		return crystainfos[index]
	end	
end

function CrystalProxy:GetCrystalListByUid(herouid)
	local crystainfos = self.data.crystaldata.crystainfos
	for index,info in pairs(crystainfos) do
		if info.herouid == herouid then
			return info
		end
	end
end

-- return count, herocount
function CrystalProxy:GetCrystalListCount()
	local num = 0
	for _, data in ipairs(self.data.crystaldata.crystainfos) do
		if data.herouid > 0 then
			num = num + 1
		end
	end
	return #self.data.crystaldata.crystainfos, num
end

--return level
function CrystalProxy:HeroInCrystal(herouid)
	local crystainfos = self.data.crystaldata.crystainfos
	for i,info in ipairs(crystainfos) do
		if info.herouid == herouid then
			return self.data.crystaldata.level
		end
	end
	return nil
end

--英雄是否在前5个或者在右边的那个列表里
function CrystalProxy:IsTopFiveOrList(herouid)
	local herolist = self.data.crystaldata.herolist
	local crystainfos = self.data.crystaldata.crystainfos

	-- print("CrystalProxy:IsTopFiveOrList herolist:", table.dump(herolist))
	-- print("CrystalProxy:IsTopFiveOrList crystainfos:", table.dump(crystainfos))

	for k,v in pairs(herolist) do
		if v == herouid then
			return true
		end
	end

	for k,v in pairs(crystainfos) do
		if v.herouid == herouid then
			return true
		end
	end

	return false
end
function CrystalProxy:HeroConfigInCrystal(heroconfigid)
	local HeroProxy = require "Modules.Hero.HeroProxy"
	local crystainfos = self.data.crystaldata.crystainfos
	for i,info in ipairs(crystainfos) do
		if info.herouid > 0 then
			local herodata = HeroProxy.Instance:GetHeroDataByUid(info.herouid)
			if herodata.roleid == heroconfigid then
				return true
			end
		end
	end
	return false
end

--是否解锁了等级上限
function CrystalProxy:IsUnLock()
	return self.data.crystaldata.unlock == 0
end

--是否满足解锁槽位
function CrystalProxy:UnLockCrystalHeroPos()
	local costType = 0
	local unlockcfg = self:GetCrystalUnlock()
	if unlockcfg then
		if RoleInfoModel.inv_essence >= unlockcfg.item then
			costType = 1
		elseif RoleInfoModel.diamond >= unlockcfg.gem then
			costType = 2
		end
	end
	return costType
end

--更新水晶红点
function CrystalProxy:UpdateCrystalRedDot()
	local RedPointDef = require "Modules.RedPoint.RedPointDef"
	local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
	local count = self:GetCrystalRedDot()
	RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.Crystal, count)
end

--共鸣水晶红点
function CrystalProxy:GetCrystalRedDot()
	local count = 0
	count = count + self:GetCrystalLevelUpRedDot()
	count = count + self:UnLockCrystalHeroPosRedDot()
	return count
end

--共鸣水晶可升级红点
function CrystalProxy:GetCrystalLevelUpRedDot()
	local redDotCount = 0
	local unlock = self:IsUnLock()
	if not unlock then 
		return redDotCount
	end
	local HeroProxy = require "Modules.Hero.HeroProxy"
	local crystaldata = self:GetCrystalData()
	if crystaldata.level == crystaldata.maxlevel then
		return redDotCount
	end

	local upgrade = HeroProxy.Instance:GetUpgradeCfgBylevel(crystaldata.level)
	local curCoin = RoleInfoModel.coin
	local curExp = RoleInfoModel.hero_exp
	local curDust = 0

	local needCoin = upgrade.gold
	local needExp = upgrade.exp
	local needDust = 0
	if crystaldata.sublevelup >= 9 and upgrade.dust then
		local BagProxy = require "Modules.Bag.BagProxy"
		local num = BagProxy.Instance:GetItemCountByID(690001)
		curDust = num
		needDust = upgrade.dust
	end

	if curCoin >= needCoin and curExp >= needExp and curDust >= needDust then
		redDotCount = 1
	end
	return redDotCount
end

--是否满足解锁槽位红点（满足的话，点击共鸣水晶改条件当天不在生效）
function CrystalProxy:UnLockCrystalHeroPosRedDot()
	local redDotCount = 0
	local unlock = self:UnLockCrystalHeroPos()
	if unlock == 1 then
		--可以解锁，且当前没有点击过共鸣水晶
		local bsame = self:IsCrystalRedDotSameDay()
		redDotCount = bsame == false and 1 or 0
	end
	return redDotCount
end

function CrystalProxy:Get_Crystal_HeroPos_RedDot_Key()
	local Crystal_HeroPos_RedDot_Key = "CrystalPosRed" .. RoleInfoModel.guserid
	return Crystal_HeroPos_RedDot_Key
end

function CrystalProxy:IsCrystalRedDotSameDay()
	local bsame = false
	local key = self:Get_Crystal_HeroPos_RedDot_Key()
	local value = self:Get_Crystal_HeroPos_RedDot_Status(key)
	if value > 0 then
		local t1 = os.date("*t", value)
		local t2 = os.date("*t")
		if t1.year == t2.year and t1.month == t2.month and t1.day == t2.day then 
			bsame = true
		end
	end
	return bsame
end

function CrystalProxy:Get_Crystal_HeroPos_RedDot_Status(key)
	local value = PlayerPrefs.GetInt(key, 0)
	return value
end

function CrystalProxy:Set_Crystal_HeroPos_RedDot_Status(key, value)
	PlayerPrefs.SetInt(key, value)
end

function CrystalProxy:CacheCrystalMaxLevel()
	self.cacheCrystalMaxLevel = self.data.crystaldata.maxlevel
end

function CrystalProxy:GetCahceCrystalMaxLevel()
	return self.cacheCrystalMaxLevel
end


return CrystalProxy