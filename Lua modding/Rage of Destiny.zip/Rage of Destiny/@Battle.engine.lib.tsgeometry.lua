tsgeometry = {}

-- 矩形
local rect = {}
rect.__index = rect

function rect:_contains(x, y)
    return x <= self.p_ur.x and x >= self.p_ld.x and y <= self.p_ur.y and y >= self.p_ld.y
end

function rect:contains(point, radius)
    local rpoint = tsvector.rotate(point, self.angle)
    local x, y = rpoint.x, rpoint.y
    local _contain = self:_contains(x, y)
    if radius and not _contain then
        _contain = self:_contains(x - radius, y)
        if not _contain then _contain = self:_contains(x + radius, y) end
        if not _contain then _contain = self:_contains(x, y - radius) end
        if not _contain then _contain = self:_contains(x, y + radius) end
    end
    return _contain

end

function tsgeometry.create_rect(center, header, headsize, othersize)

    local angle = tsvector.angle(header, tsvector.new(1000, 0))
    if header.y > 0 then angle = angle * -1 end
    local pl = center
    local pr = center + tsmath.vmul(header, headsize)
    pl = tsvector.rotate(pl, angle)
    pr = tsvector.rotate(pr, angle)
    local half = tsmath.vmul(tsvector.new(0, 1000), tsmath.floor(othersize / 2))
    local p_ld = pl - half -- 左下
    local p_ur = pr + half -- 右上

    local o = { p_ld = p_ld, p_ur = p_ur, angle = angle}

    setmetatable(o, rect)

    return o

end

function tsgeometry.create_rect_center(center, header, headsize, othersize)

    local angle = tsvector.angle(header, tsvector.new(1000, 0))
    if header.y > 0 then angle = angle * -1 end
    local pl = center - tsmath.vmul(header, headsize/2)
    local pr = center + tsmath.vmul(header, headsize/2)
    pl = tsvector.rotate(pl, angle)
    pr = tsvector.rotate(pr, angle)
    local half = tsmath.vmul(tsvector.new(0, 1000), tsmath.floor(othersize / 2))
    local p_ld = pl - half -- 左下
    local p_ur = pr + half -- 右上

    local o = { p_ld = p_ld, p_ur = p_ur, angle = angle}

    setmetatable(o, rect)

    return o

end

-- 归一化矩形
local normalrect = {}
normalrect.__index = normalrect

function normalrect:contains(point)
    local x, y = point.x, point.y
    return x <= self.p_ur.x and x >= self.p_ld.x and y <= self.p_ur.y and y >= self.p_ld.y
end

function normalrect:__tostring()
    return string.format("ld:%s ur:%s", self.p_ld, self.p_ur)
end

function tsgeometry.create_normalrect(ld, size)
    
    local o = { p_ld = ld, p_ur = ld + size }
    setmetatable(o, normalrect)

    return o

end
return tsgeometry