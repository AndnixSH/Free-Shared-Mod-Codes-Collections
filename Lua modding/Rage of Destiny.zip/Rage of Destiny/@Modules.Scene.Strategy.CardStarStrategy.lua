local BasicSceneStrategy = require "Modules.Scene.Strategy.BasicSceneStrategy"
local CardStarStrategy = CardStarStrategy or BaseClass(BasicSceneStrategy)
local BattleProxy = require "Modules.Battle.BattleProxy"
local render_camera = require "Battle.render.camera.render_camera"

function CardStarStrategy:OnLoad()
    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.NetworkDelayView)
    local scenename = "20015"
    self:LoadScene(nil, scenename)
end

function CardStarStrategy:Destroy()
    self:UnloadScene()
end

function CardStarStrategy:OnLoadSceneEnd()
    local args = {}
    args.bone = "20015/guadian/Pre_Scenes_CardStar_10_1/Camera_20015"
    render_camera.free_trunk_strategy()
    render_camera.set_camera_field_of_view(30)

    local rootObj = AssetManager.GetActiveSceneRootObject()
    local camera_position_obj = GameObjTools.GetChild(rootObj, "guadian/Pre_Scenes_CardStar_10_1/Camera_20015")

    render_camera.set_bone_trunk_strategy(camera_position_obj, args)
end

function CardStarStrategy:OnStartEntry()
    self:DefaultOpenWidgets()
end

function CardStarStrategy:DefaultOpenWidgets()
    BattleProxy.Instance:StopGame()
    -- local render_area = require "Battle.render.render_area"
    -- render_area.destroy()

    -- local render_camera = require "Battle.render.camera.render_camera"
    -- render_camera.free_trunk_strategy()
    -- render_camera.set_world_map_camera({75, 15, 25, 53, 180, 0})

    LuaLayout.Instance:OpenWidget(UIWidgetNameDef.CardStarView)
end

return CardStarStrategy