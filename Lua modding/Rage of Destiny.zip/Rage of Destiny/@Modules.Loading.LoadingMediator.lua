local LoadingMediator = LoadingMediator or BaseClass(StdMediator)
local LoadingView = require "Modules.Loading.LoadingView"
local LoadingCommonView = require "Modules.Loading.LoadingCommonView"

function LoadingMediator:OnEnterScenceInit()
	self:ShowLoading(0)
end

function LoadingMediator:OnEnterScenceStart()	
 	--场景进度是虚拟的，加载完成返回一百	
	self:ShowLoading(70)
end

function LoadingMediator:OnEnterScenceEnd()
	self:ShowLoading(100)
end

function LoadingMediator:ShowLoading(progress)
	if SceneConstruct.enterLoading then
		LoadingCommonView.ShowLoading(progress)
	end	
end

return LoadingMediator