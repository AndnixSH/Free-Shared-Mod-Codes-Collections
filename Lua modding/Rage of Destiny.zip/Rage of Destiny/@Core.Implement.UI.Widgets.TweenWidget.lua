local GameUIUtil = CS.GameUIUtil
local AudioManager = require "Common.Mgr.Audio.AudioManager"

local TweenWidget = TweenWidget or BaseClass()
function TweenWidget:OpenScaleTween(obj,callback)
	self:ClearWidgetTween()
	if obj then
		DOTween.Kill(obj)
		AudioManager.PlaySoundByKey("view_open")
		obj:SetActive(true)
		GameUIUtil.SetGroupAlpha(obj ,0)
		obj.transform.localScale = Vector3.New(1,0,1)

		local time = 0.2
		local tween = obj.transform:DOScale(Vector3.one ,time)
		tween:SetEase(Ease.OutBack)
		tween:OnComplete(function ()
			if callback then
				callback()
			end
		end)
		self._widgetTween = tween
		GameUIUtil.SetGroupAlphaInTime(obj, 1, time)
	end	
end

function TweenWidget:CloseScaleTween(obj, func)
	self:ClearWidgetTween()
	if obj then		
		DOTween.Kill(obj)
		AudioManager.PlaySoundByKey("view_close")
		obj:SetActive(true)
		GameUIUtil.SetGroupAlpha(obj ,1)
		obj.transform.localScale = Vector3.one

		local time = 0.2
		local tween = obj.transform:DOScale(Vector3.New(1,0,1) ,time)
		tween:OnComplete(function ()
			if func then
				func()
			end	
		end)			
		self._widgetTween = tween	
		GameUIUtil.SetGroupAlphaInTime(obj, 0, time)		
	end		
end

function TweenWidget:CloseAniView(func)	
	AudioManager.PlaySoundByKey("screen_close")
	UIOperateManager.Instance:OpenWidget(AppFacade.Common, 2, func)		
end

function TweenWidget:OpenAniView(func)	
	AudioManager.PlaySoundByKey("screen_open")
	if func then
		func()
	end	
	UIOperateManager.Instance:OpenWidget(AppFacade.Common, 1)		
end

function TweenWidget:ClearWidgetTween()	
	if self._widgetTween then
		self._widgetTween:Kill()
		self._widgetTween = nil
	end	
end

return TweenWidget
