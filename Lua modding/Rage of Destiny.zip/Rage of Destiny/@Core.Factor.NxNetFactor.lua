local listProtoData = {}
local cacheProtoData = {}

local cGameNetWork = CS.LJY.NX.GameNetWork.Instance

cGameNetWork.HandleTcpBuffer = function(buffer)
    local uid, cmd, pos = LibNet.DecodeHeader(buffer)
    local listCmd = listProtoData[cmd]
    if nil ~= listCmd then
        for key, value in pairs(listCmd.funcs) do
            if cacheProtoData[cmd] then
                cacheProtoData[cmd] = nil
            end
            value(key, NetDecoder.New(buffer, pos))
        end
    end
end

local function AddProto(owner, cmd, func)
    local listCmd = listProtoData[cmd]
    local funcs = nil
    if nil == listCmd then
        listCmd = {}
        funcs = {}
        listCmd.funcs = funcs
        listCmd.intCount = 1
        listProtoData[cmd] = listCmd
    else
        funcs = listCmd.funcs
        listCmd.intCount = listCmd.intCount + 1
    end
    funcs[owner] = func
end

local function RemoveProto(owner, cmd)
    local listCmd = listProtoData[cmd]
    if listCmd then
        listCmd.funcs[owner] = nil
        listCmd.intCount = listCmd.intCount - 1
        if 0 == listCmd.intCount then
            listProtoData[cmd] = nil
        end
    end
end

local server_cluster_info = {}
NxNetFactor = NxNetFactor or BaseClass()
function NxNetFactor:__init()
    self.listCmd = {}
end

function NxNetFactor:__delete()
    self:RemoveAllProto()
end

function NxNetFactor:SetServerAddresInfo(info)
    server_cluster_info = info
end

function NxNetFactor:AddProto(cmd, func)
    if nil == self.listCmd[cmd] then
        self.listCmd[cmd] = true
        AddProto(self, cmd, func)
    end
end

function NxNetFactor:RemoveProto(cmd)
    if nil ~= self.listCmd[cmd] then
        self.listCmd[cmd] = nil
        RemoveProto(self, cmd)
    end
end

function NxNetFactor:RemoveAllProto()
    for key, value in pairs(self.listCmd) do
        RemoveProto(self, key)
    end
    self.listCmd = {}
end

function NxNetFactor:SendMessage(cmd, encode, service)
    --print("NxNetFactor -->> SendMessage", cmd, os.time())
    service = service or "player"
    local svrid = self:_GetServiceId(service)

    local header = LibNet.EncodeHeader(svrid, cmd)
    local body = encode and encode.buffer or ""
    self:_SendMessage(header, body)
    cacheProtoData[cmd] = {header = header, body = body}
end

function NxNetFactor:_GetServiceId(service_name)
    for _, v in ipairs(server_cluster_info) do
        if string.contains(v[3], service_name) then
            return v[1]
        end
    end
    return 0
end

function NxNetFactor:SendCacheProto()
    --print("------>>SendCacheProto", table.dump(cacheProtoData))
    for cmd, proto_info in pairs(cacheProtoData) do
        if cmd == 50001 and proto_info.header and proto_info.body then
            if proto_info.header and proto_info.body then
                self:_SendMessage(proto_info.header, proto_info.body)
            end
        end
    end
end

function NxNetFactor:_SendMessage(header, body)
    local t = {}
    t[1] = header
    t[2] = body
    cGameNetWork:SendTcpMessage(table.concat(t))
end