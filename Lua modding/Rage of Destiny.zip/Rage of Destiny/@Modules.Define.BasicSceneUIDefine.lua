require "Core.Implement.UI.Widgets.TabFormWidget"
require "Common.Mgr.UI.UIOperateManager"

local BasicSceneUIDefine = {}

function BasicSceneUIDefine.RegisterStaticWidgets()
	if not BasicSceneUIDefine.isStaticRegister then
		BasicSceneUIDefine.isStaticRegister = true
		local layout = LuaLayout.New()

		local UIRootWidgetPath = "Core.Implement.UI.Widgets.UIRootWidget"
		local UINormalWidgetPath =  "Core.Implement.UI.Widgets.UINormalWidget"
		local UILiveAllwayWidgetPath = "Core.Implement.UI.Widgets.UILiveAllwayWidget"
		local UITopWidgetPath = "Core.Implement.UI.Widgets.UITopWidget"


		--UIRoot
		layout:RegisterWidget(UIWidgetNameDef.UIRoot, UIRootWidgetPath, "", "", LayoutShowType.CoexistClose)
		layout:RegisterWidget(UIWidgetNameDef.Root_liveAllway, UILiveAllwayWidgetPath, UIWidgetNameDef.UIRoot, UIWidgetNameDef.UIRootPanel, LayoutShowType.CoexistClose)
		layout:RegisterWidget(UIWidgetNameDef.Root_normal, UINormalWidgetPath, UIWidgetNameDef.UIRoot, UIWidgetNameDef.UIRootPanel, LayoutShowType.CoexistClose)
		layout:RegisterWidget(UIWidgetNameDef.Root_top, UITopWidgetPath, UIWidgetNameDef.UIRoot, UIWidgetNameDef.UIRootPanel, LayoutShowType.CoexistClose)
		if SystemConfig.isIGGPlatform() then
			local UIIGGWidgetPath = "Core.Implement.UI.Widgets.UIIGGWidget"
			layout:RegisterWidget(UIWidgetNameDef.Root_IGG, UIIGGWidgetPath, UIWidgetNameDef.UIRoot, UIWidgetNameDef.UIRootPanel, LayoutShowType.CoexistClose)
		end

		layout:OpenWidget(UIWidgetNameDef.UIRoot)
		layout:OpenWidget(UIWidgetNameDef.Root_liveAllway)
		layout:OpenWidget(UIWidgetNameDef.Root_normal)
		layout:OpenWidget(UIWidgetNameDef.Root_top)
		if SystemConfig.isIGGPlatform() then
			layout:OpenWidget(UIWidgetNameDef.Root_IGG)
		end
		
		local cfg = ConfigManager.GetConfig("data_uiview")
		for widgetName, info in pairs(cfg) do
			layout:RegisterWidgetByCfg(widgetName, info)
		end
	end
end	

return BasicSceneUIDefine