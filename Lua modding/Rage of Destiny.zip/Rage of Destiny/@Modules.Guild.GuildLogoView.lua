local GuildProxy = require "Modules.Guild.GuildProxy"
local GuildDef = require "Modules.Guild.GuildDef"
local ClistRender = require "Core.Implement.UI.Class.ClistRender"
local ClistItem = require "Core.Implement.UI.Class.ClistItem"
local GameUIUtil = CS.GameUIUtil


local GuildLogoViewItem = GuildLogoViewItem or BaseClass(ClistItem)

function GuildLogoViewItem:Load(obj)
	self.iconTex = self:GetChildComponent(self.go, "lock/CTexture_icon", "CTexture")
	self.lockLab = self:GetChildComponent(self.go, "lock/label", "CLabel")
	self.lockBackObj = self:GetChild(self.go, "lock/wenzidi")
	self.selectObj = self:GetChild(self.go, "lock/gou")

end

function GuildLogoViewItem:SetData(data)
	self.data = data
	AssetManager.LoadUITexture(AssetManager.UITexture.Guild, self.data.icon, self.iconTex)
	self.lockLab.text = self:GetWord(GuildDef.LanguageKey.GuildLogoView2, self.data.level)
	self.lockLab.gameObject:SetActive(self.data.state == 3 and true or false)
	self.lockBackObj:SetActive(self.data.state == 3 and true or false)
	self.iconTex.Gray = self.data.state == 3 and true or false

	local alpha = self.data.state == 1 and 0.7 or 1
	GameUIUtil.SetGroupAlpha(self.iconTex.gameObject, alpha)
	self.selectObj:SetActive(self.data.bSelect)

end

--select_iconId:選中  delect_id：上一個選中
function GuildLogoViewItem:SetSelectObj(select_iconId, delect_id)
	self.selectObj:SetActive(select_iconId == self.data.id and true or false)
	if delect_id then
		if delect_id == self.data.id then
			self.selectObj:SetActive(false)
		end
	end
end


local GuildLogoView = GuildLogoView or LuaWidgetClass()
GuildLogoView.guildLevel = nil --公会等级
GuildLogoView.cur_icon_id = nil  --公會圖標
GuildLogoView.callBack = nil
function GuildLogoView:__init()
	self.tweenOption= {bScale = true}
end

function GuildLogoView:OnLoad()
	AssetManager.LoadUIPrefab(self, "Guild.GuildLogoView", self.LoadEnd)
end

function GuildLogoView:LoadEnd(obj)
	self:SetGo(obj)
	self:InitUI()
	self:SetStep(0)
end

function GuildLogoView:InitUI()
	self.rootObj = self:GetChild(self.go, "root")
	self.closeBtn = self:GetChildComponent(self.rootObj, "close", "CButton")
	self.closeBtn:AddClick(function()
		self:CloseView()
	end)

	self.guildLvLab = self:GetChildComponent(self.rootObj, "CLabel_dengji", "CLabel")

	self.clist = self:GetChildComponent(self.rootObj, "CList", "CList")
	self.clistRender = ClistRender.New()
	self.clistRender:Load(self.clist, GuildLogoViewItem)
	self.clistRender:AddSelect(function(item, index)
		self:OnClickItem(item, index)
	end)


	-- self.clistRender:AddDeSelect(function(item, index)
	-- 	self:OnDeSelectItem(item, index)
	-- end)
	self.cancelBtn = self:GetChildComponent(self.rootObj, "cancel", "CButton")
	self.saveBtn = self:GetChildComponent(self.rootObj, "save", "CButton")

	self.cancelBtn:AddClick(function()
		self:CloseView()
	end)

	self.saveBtn:AddClick(function()
		if self.selectIconId and GuildLogoView.callBack then
			GuildLogoView.callBack(self.selectIconId)
			self:CloseView()
		end
	end)
end

function GuildLogoView:OnClose()
	GuildLogoView.guildLevel = nil
	GuildLogoView.cur_icon_id = nil
	GuildLogoView.callBack = nil
end

function GuildLogoView:OnDestroy()
	GuildLogoView.guildLevel = nil
	GuildLogoView.cur_icon_id = nil
	GuildLogoView.callBack = nil
end

function GuildLogoView:OnOpen()
	self:UpdateView()
end

function GuildLogoView:UpdateView()	
	self.selectIconId = GuildLogoView.cur_icon_id
	self.config = GuildProxy.Instance:GetGuildIconCfgSortByLevel(GuildLogoView.guildLevel, self.selectIconId)
	--print("self.config======", table.dump(self.config))
	self.guildLvLab.text = self:GetWord(GuildDef.LanguageKey.GuildLogoView1, GuildLogoView.guildLevel)
	self.clistRender:ClearData()
	self.clistRender:AppendDataList(self.config)
end

function GuildLogoView:OnClickItem(item, idx)
	if item then
		if item.data.state == 3 then
			--未开启
			local str = self:GetWord(GuildDef.LanguageKey.GuildLogoView3)
			GameLogicTools.ShowMsgTips(str)
		else
			if item.data.id ~= self.selectIconId then
				self.clistRender:ExecuteMethod("SetSelectObj", item.data.id, self.selectIconId)
				self.selectIconId = item.data.id
			end
		end
	end
end

function GuildLogoView:OnDeSelectItem(item, idx)
end

return GuildLogoView