local cs_coroutine = require "First.Util.cs_coroutine"

--网络加载
local httputil = httputil or {}

local UnityWebRequest = CS.UnityEngine.Networking.UnityWebRequest
local WWWForm = CS.UnityEngine.WWWForm
--------------------------------------------------
--                 公开接口                     --
--------------------------------------------------

--http get加载
function httputil.get(url, backFunc)
    cs_coroutine.start(
            function()
                local www = UnityWebRequest.Get(url)

                coroutine.yield(www:SendWebRequest())

                if www.isNetworkError or www.isHttpError then
                    -- error(string.format("get error: %s ---- url=%s", www.error, url))
                    -- GameObjTools.ShowConfirmById(10, function(bvalue)
                    -- end)                    
                    backFunc()
                else
                    backFunc(www.downloadHandler.text)
                end

                www:Dispose()
            end
    )
end

--http post 加载
function httputil.post(url, dic, backFunc)
    cs_coroutine.start(
            function()
                local wwwForm = WWWForm()

                for k, v in pairs(dic) do
                    wwwForm:AddField(k, v)
                end

                local www = UnityWebRequest.Post(url, wwwForm)

                coroutine.yield(www:SendWebRequest())

                if www.isNetworkError or www.isHttpError then
                    print(string.format("post error: %s ---- url=%s", www.error, url), table.dump(dic))
                else
                    if backFunc then
                        backFunc(www.downloadHandler.text)
                    end
                end
                www:Dispose()
            end
    )
end

--http post 带网络错误弹窗
function httputil.post_error(url, dic, backFunc)
    cs_coroutine.start(
            function()
                local wwwForm = WWWForm()

                for k, v in pairs(dic) do
                    wwwForm:AddField(k, v)
                end

                local www = UnityWebRequest.Post(url, wwwForm)
                coroutine.yield(www:SendWebRequest())

                if www.isNetworkError or www.isHttpError then
                    local LanguageUtil = require "First.Util.LanguageUtil"
                    local ConfirmView = require "First.Update.View.ConfirmView"
                    local content = string.format(LanguageUtil.GetWord("confirm_tips_1001"))
                    ConfirmView.Show(content, function()
                        Application.Quit()
                    end, nil, nil, "Common_1004", 1, "Common_1006")
                    print(string.format("post error: %s ---- url=%s", www.error, url), table.dump(dic))
                else
                    if backFunc then
                        backFunc(www.downloadHandler.text)
                    end
                end
                www:Dispose()
            end
    )
end

--test
function httputil.test()
    local backFun = function(text)
        print("text back = ", text)
        local rapidjson = require 'rapidjson'
        local t = rapidjson.decode(text)
        print("=====>>", table.dump(t))
    end

    -- httputil.post("http://192.168.0.121/sdk/login/login", backFun)
    local param = {}
    param.username  = "1002"
    param.password = "123456"
    param.ts = os.time()
    param.sign = "fdagagafsdafasdgfasd"
    httputil.post("http://192.168.0.121/sdk/login/login", param, backFun)
end

return httputil
