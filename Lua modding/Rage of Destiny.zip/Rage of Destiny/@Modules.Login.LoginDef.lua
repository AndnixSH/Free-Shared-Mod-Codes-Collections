local LoginDef = {
    socketSelectIdx = "mx_socketSelectIdx",
    loginAccount = "mx_loginAccount",
    loginPassword = "mx_loginPassword",

    SDK = {
        Url = "http://192.168.0.121/sdk/login/login",
        Key = "41295f8d7b20c3c153676f8336f2de15",
        NoticeUrl = "http://192.168.0.121/api/notice",
        InsideNoticeUrl = "http://192.168.0.121/api/notice/gameNotice",
    },

    api = {
        login = "single/sdk/account/",
        get_token = "single/login/package/",
        gameapi = "api/game/",
        buryingpoint = "api/burying_point/",
        report = "single/api/package/",
    },

    NotifyDef = {
        Sdk_Login_Suc = "Sdk_Login_Suc",
		Sdk_Login_Auth_Fail = "Sdk_Login_Auth_Fail",
        Sdk_Login_Notice = "Sdk_Login_Notice",
        Sdk_Game_Notice = "Sdk_Game_Notice",
        Start_Auto_Login = "Start_Auto_Login",
		Cross_Day = "Cross_Day",
    },

    LoginCode = {
        OK = 0,
        AUTH_FAIL = 1, -- 认证失败
        POP_BY_ANOTHER = 2, -- 被顶号
        SHUTDOWN = 3, -- 关服
        KICKED = 4, -- 被踢（gm）
        TIMEOUT = 5, -- 登录超时
        INVALID = 6, -- 角色连接失效
        CREATE_ROLE_FAIL = 7, -- 创建角色失败（db挂了）
        LOGIN_ROLE_FAIL = 8, -- 登录角色失败（db挂了/未创建角色）
        PROTO_MISS = 10, -- 登录协议丢失
        PROTO_ERROR = 11, -- 登录协议数据有误
        UNKNOWN = 99,
    }
}

return LoginDef