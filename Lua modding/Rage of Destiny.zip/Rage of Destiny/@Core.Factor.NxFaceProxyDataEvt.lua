

NxFaceProxyDataEvt = NxFaceProxyDataEvt or BaseClass(NxProxyDataEvtFactor)

function NxFaceProxyDataEvt:Resgister( tbl , func )
	for proxyName , proxy in pairs( tbl ) do
		local proxyIns = faceProxyList[proxyName]
		if proxyIns then
			for propName , prop in pairs(proxy) do
				for notifyName , notify in pairs(prop) do
					func(self , proxyIns[propName] , notifyName , nil , false )
					self.data2func[proxyIns[propName]] = self.data2func[proxyIns[propName]] or {}
					self.data2func[proxyIns[propName]][notifyName] = tbl[proxyName][propName][notifyName]
				end
			end
		end
	end
end

-- 注册事件监听，需子类调用父类方法
function NxFaceProxyDataEvt:AutoRegister()
	self.data2func = self.data2func or {}
	self:Resgister( self.EvtNotify , self.RegisterLuaNotify  )
	self:Resgister( self.EvtProp , self.RegisterLuaData  )	
end

function NxFaceProxyDataEvt:UnRegister( tbl , func )
	for proxyName , proxy in pairs( tbl ) do
		local proxyIns = faceProxyList[proxyName]
		if proxyIns then
			for propName , prop in pairs(proxy) do
				for notifyName , notify in pairs(prop) do
					func(self , proxyIns[propName] , notifyName )
					if self.data2func and self.data2func[proxyIns[propName]] then
						self.data2func[proxyIns[propName]][notifyName] = nil
					end	
				end
			end
		end
	end
end

-- 卸载事件监听，需子类调用父类方法
function NxFaceProxyDataEvt:AutoUnRegister()
	if not self.data2func then return end

	self:UnRegister( self.EvtNotify , self.UnRegisterLuaNotify )
	self:UnRegister( self.EvtProp , self.UnRegisterLuaData )
end

function NxFaceProxyDataEvt:OnLuaNotify(data,strEvent,args,strContext)
    local func = self.data2func[data][strEvent]
    func( self , data , args , strContext )
end

function NxFaceProxyDataEvt:OnLuaData(data,strEvent,args,strContext)
    local func = self.data2func[data][strEvent]
    func( self , data , args , strContext )
end

function NxFaceProxyDataEvt:ReplaceLuaData(data, strProtery, fromValue, toValue, strContext)
    local func = self.data2func[data][strProtery]
    func( self , data, strProtery, fromValue, toValue, strContext)
end

