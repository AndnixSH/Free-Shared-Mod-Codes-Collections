local base_sprite_model = require "Battle.render.model.base_sprite_model"
local empty_active_model = BaseClass(base_sprite_model)

local cEmptyActiveModel = CS.LJY.NX.EmptyActiveModel

function empty_active_model:__init(anchor)
    self.cmodel = cEmptyActiveModel(anchor.canchor)
end

return empty_active_model