local SceneDef = {}

SceneDef.SceneType = 
{
	None = 0,
	Login = 1,		--登录
	Main  = 2,		--主场景
	Battle = 3,		--战斗
	Hero = 4,		--英雄场景 args:raceid
	Newbie = 5, 	--新手场
	Train = 6,		--训练场(不联网)
	Maze = 7,		--迷宫格子
	Temple = 8,		--大圣堂
	StoryLine = 9,  --剧情副本
	WorldMap = 10,  --世界地图
	DrawCard = 11,  --抽卡
	Crystal = 12,   -- 共鸣水晶
	Arena = 13,   -- 竞技场
	CardStar = 14, --占星
	Drama = 15, -- 开场动画
	HeroSwitch = 16,--英雄切换
	Activity = 17,  --活动副本

	--等同于 ACTIVITYID
	MainLineBattle = 101,  --主界面战斗
	TowerBattle = 102,  --爬塔战斗
	MazeBattle = 103,   --迷宫战斗
	StoryLineBattle = 104,   --剧情战斗
	ArenaBattle = 105, --竞技场战斗
	HighArenaBattle = 106, --高阶竞技场战斗
	GuildBossBattle = 108, --公会boss战斗
	FriendVersusBattle = 109, --友谊战战斗
	SupplyDepotBattle = 110, --补给站
	GuildVersusBattle = 111, --公会战斗
	ActivityBattle = 112, --活动副本
	GuildChaosBattle = 113, --混沌裂隙
	MobilizeBattle = 114, --命运总动员
	TrialBattle= 998,--图鉴里英雄试玩战斗
	TrainingBattle = 999, --训练场（测试用）
	TEST_ALL_HERO = 996, --英雄测试
}

SceneDef.NotifyDef = 
{
	Scene_Enter_First = "Scene_Enter_First", 	--第一次进入场景
	Scene_Enter_Init  = "Scene_Enter_Init",		--场景初始化
	Scene_Enter_Start = "Scene_Enter_Start",	--场景开始进入
	Scene_Enter_End   = "Scene_Enter_End",		--场景进入结束
	Scene_Enter_Clear = "Scene_Enter_Clear",	--场景资源释放
	Scene_Loading_End = "Scene_Loading_End",	--场景进度条关闭回调
}
return SceneDef