local init = {
    --_G
    libpaths = {
        "Battle.engine.lib.engine_define",
        "Battle.engine.lib.engine_service",
        "Battle.engine.lib.class",
        "Battle.engine.lib.engine_functions",
        "Battle.engine.lib.listener",
        "Battle.engine.lib.fp",
        "Battle.engine.lib.tsmath",                 -- 数学库
        "Battle.engine.lib.tsvector",               -- 向量
        "Battle.engine.lib.tsrandom",               -- 随机库
        "Battle.engine.lib.tsgeometry",             -- 几何库
    },
    -- global
    corelist = {
        {name = "array", path = "Battle.engine.core.array"},
        {name = "debug", path = "Battle.engine.core.debug"}
    },
    -- global.service
    servicelist = {
        {name = "requirer",         path = "Battle.engine.service.requirer"},
        {name = "call",             path = "Battle.engine.service.call"},
        {name = "frame",            path = "Battle.engine.service.frame"},
        {name = "pool",             path = "Battle.engine.service.pool"},
        {name = "time",             path = "Battle.engine.service.time"},
        {name = "timer",            path = "Battle.engine.service.timer"},
        {name = "state",            path = "Battle.engine.service.state"},
        {name = "obj_factory",      path = "Battle.engine.service.obj_factory"},
        {name = "logic_factory",    path = "Battle.engine.service.logic_factory"},
        {name = "propchange",       path = "Battle.engine.service.propchange"},
        {name = "eventslots",       path = "Battle.engine.service.eventslots",      args = {"sprite","game","attr"}},
        {name = "scriptengine_v2",  path = "Battle.engine.service.scriptengine_v2", args = {searchpath = "Battle.game.script", commonscript = "scriptcommon", actionscript = "scriptaction", fallbackscript = "scriptfallback"}}
    },
    -- logic internal service
    loaderlist = {
        {name = "call",  service = "call"},
        {name = "event", service = "eventslots"},
        {name = "timer", service = "timer"},
        {name = "state", service = "state"},
    }
}

return init