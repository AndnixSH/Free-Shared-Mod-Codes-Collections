local bone_ui_anchor = bone_ui_anchor or BaseClass()

function bone_ui_anchor:__init(model, bone)
    self.canchor = CS.LJY.NX.BoneUIAnchor(model, bone)
end

function bone_ui_anchor:__delete()
    self.canchor = nil
end

-- 未实现
--function bone_ui_anchor:set_delta(delta)
--    if self.canchor then
--        self.canchor:SetDelta(delta)
--    end
--end

return bone_ui_anchor