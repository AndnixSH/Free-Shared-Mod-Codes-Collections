local CampaignProxy = require "Modules.Campaign.CampaignProxy"
local BattleProxy = require "Modules.Battle.BattleProxy"
local view_manager = require "Battle.render.view_manager"

local BattleBaseClass = require "Core.Implement.UI.Class.BattleBaseClass"

local BossInfoHandle = BossInfoHandle or LuaEventClass(GameObjFactor, BattleBaseClass)
function BossInfoHandle:__init(go)
	self.hpSpriteNamePre = "bossxuetiao"
	self.hp_colors = {"e5c3ff","aafaff","afffaa","fff7a0","f9ffc7"}
	self.go = go
	self:Load(go)
end
function BossInfoHandle:Load(obj)

	self.bossHeadTex = self:GetChildComponent(obj, "CSprite_icon/CTexture_boss_head", "CTexture")
	self.hpSld = self:GetChildComponent(obj, "attribute/CSlider_Hp", "CSlider")
	self.mpSld = self:GetChildComponent(obj, "attribute/CSlider_Mp", "CSlider")

	self.hpSp = self:GetChildComponent(self.hpSld.gameObject, "hp", "CSprite")
	self.hpbackSp = self:GetChildComponent(self.hpSld.gameObject, "hpback", "CSprite")
	self.nextSp = self:GetChildComponent(self.hpSld.gameObject, "nexthp", "CSprite")
	self.hpSp.SpriteName = self.hpSpriteNamePre .. 1
	self.nextSp.SpriteName = self.hpSpriteNamePre .. 1

	self.hpCountLab = self:GetChildComponent(self.hpSld.gameObject, "COutline_XNum", "CLabel")
	self.hpCountLab.gameObject:SetActive(true)
	self.mpSp = self:GetChildComponent(self.mpSld.gameObject, "Fill Area/Fill", "CSprite")
end

function BossInfoHandle:Open()
	local activityId = BattleProxy.Instance:GetBattleActivityId()
	if activityId == ACTIVITYID.GUILD_CHAOS then
		self.go:SetActive(false)
	else
		self.go:SetActive(true)
	end

	self:UpdateInfo()
end

function BossInfoHandle:Close()	
	self.go:SetActive(false)
	self:UnRegisterSpriteEvent()
end	

function BossInfoHandle:Destroy()
	self:UnRegisterSpriteEvent()
end

function BossInfoHandle:GetBossInfo()
	local spritelist = BattleProxy.Instance:GetSpriteList(CAMP.BLUE)
	if spritelist then
		for _, spriteid in ipairs(spritelist) do
			local sprite = BattleProxy.Instance:GetSprite(spriteid)
			local hp_level = sprite.static.hp_level or 1
			if sprite.static.type == MONSTER_TYPE.BOSS then
				return sprite, spriteid, hp_level
			end	
		end
	end
	return false
end

function BossInfoHandle:ShowBossHead()
	local roleid = self.spritedata.prop.roleid
	local monster_config = ConfigManager.GetConfig("monster_static")
	if monster_config[roleid] and monster_config[roleid].head_id then
		AssetManager.LoadUITexture(AssetManager.UITexture.BossIcon, monster_config[roleid].head_id, self.bossHeadTex)
	else
		AssetManager.LoadUITexture(AssetManager.UITexture.BossIcon, roleid, self.bossHeadTex)
	end
end

function BossInfoHandle:UpdateInfo()
	local sprite, spriteid, hp_level = self:GetBossInfo()
	if sprite then
		local spriteview = view_manager.getsprite(spriteid)
		if spriteview then
			spriteview:remove_title_view()
		end	
		self.spritedata = sprite
		self.hp_level = hp_level
		self:RegisterSpriteEvent(spriteid)
		--boss头像
		self:ShowBossHead()

		self:ChangeHp()
		self:ChangeMp()
	else
		self:Close()
	end	
end

--当前显示的索引以及下一条显示的索引
function BossInfoHandle:GetHpShowIndex(hp_index)
	local maxHpSpIndex = 5
	local hp_index_formard = hp_index
	local t1, t2 = math.modf(hp_index/maxHpSpIndex)
	if t1 ~= 0 then
		hp_index_formard = hp_index - t1 * maxHpSpIndex
		if hp_index_formard == 0 then
			hp_index_formard = maxHpSpIndex
		end
	end

	local hp_index_next = 1
	if hp_index_formard ~= maxHpSpIndex then
		hp_index_next = hp_index_formard + 1
	end
	return hp_index_formard, hp_index_next
end

function BossInfoHandle:ChangeHp()
	local hp_level = self.hp_level
	local hp_max = self.spritedata.attr.hp_max
	local cur_hp = self.spritedata.attr.hp
	cur_hp = math.min(hp_max, cur_hp)       --当前血量不能高于最大血量
	local per_value = hp_max / hp_level

	local hp_index = math.floor((hp_max - cur_hp) / per_value) + 1 --处于第几管血

	hp_index = math.min(hp_index, hp_level)

	local hp_index_formard, hp_index_next = self:GetHpShowIndex(hp_index)
	self.hpSp.SpriteName = self.hpSpriteNamePre .. hp_index_formard
	self.nextSp.SpriteName = self.hpSpriteNamePre .. hp_index_next

	--是否跨血条
	local hp_change_index = false
	if not self.hp_index then
		self.hp_index = hp_index
	elseif self.hp_index ~= hp_index then
		self.hp_index = hp_index
		hp_change_index = true
	end

	local _hp_max = per_value
	local _cur_hp = cur_hp - (hp_level - hp_index) * per_value
	local value = _cur_hp / _hp_max
	self.hpSp.fillAmount = value

	if hp_change_index then
		self.hpbackSp.fillAmount = 1
	end

	local leftHpCount = hp_level - hp_index + 1
	if hp_level == hp_index and value <= 0 then
		leftHpCount = 0
	end

	if leftHpCount == 1 or leftHpCount == 0 then
		self.nextSp.SpriteName = ""
	end

	self.hpCountLab.text = "x" .. math.max(leftHpCount, 0)
	self.hpbackSp:DOFillAmount(value, 0.5)	
end

function BossInfoHandle:ChangeMp()
	local mp_max = self.spritedata.attr.mp_max
	local cur_mp = self.spritedata.attr.mp
	local value = cur_mp / mp_max
	self.mpSld.value = value
end

function BossInfoHandle.event.attr:hp(newvalue, oldvalue)
	self:ChangeHp()
end

function BossInfoHandle.event.attr:hp_max(newvalue, oldvalue)
	self:ChangeHp()
end

function BossInfoHandle.event.attr:mp(newvalue, oldvalue)	
	self:ChangeMp()
end

function BossInfoHandle.event.attr:mp_max(newvalue, oldvalue)
	self:ChangeMp()
end

return BossInfoHandle