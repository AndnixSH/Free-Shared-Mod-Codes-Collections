local logic = { state = {}, event = service.event(), call = service.call(calldef.state) }

function logic:oncreate()
    
    local prepare = self:createlogic("sprite.basic.sprite_prepare_logic", { prepare_duration = self.owner.static.prepare_duration or 0 })
    local idle = self:createlogic("sprite.basic.sprite_idle_logic")
    local skill = self:createlogic("sprite.basic.sprite_skill_logic_v2")
    local suffer = self:createlogic("sprite.basic.sprite_suffer_logic")
    local death = self:createlogic("sprite.basic.sprite_death_logic")
    local fakedeath = self:createlogic("sprite.basic.sprite_fakedeath_logic")

    -- self.state.isdebug = true
    self.state:configure(prepare, idle, { death, suffer }, true)
    self.state:configure(idle, idle, { death, suffer, skill })
    self.state:configure(skill, idle, { death, suffer, skill })
    self.state:configure(suffer, idle, { death, fakedeath })
    self.state:configure(death, idle, nil)
    self.state:configure(fakedeath, idle, nil)
    self.state:start(self.time.tick, self.owner)

    self._idle = idle
    self._skill = skill
    self._suffer = suffer
    self._death = death

end

function logic.call:canattack()
    local cur = self.state:getcurrent()
    return cur and cur == self._idle or cur == self._skill
end

function logic.call:isdead()
    local cur = self.state:getcurrent()
    return cur and cur == self._death
end

function logic.call:stop(immediate)
    self.state:stop(immediate)
end

return logic