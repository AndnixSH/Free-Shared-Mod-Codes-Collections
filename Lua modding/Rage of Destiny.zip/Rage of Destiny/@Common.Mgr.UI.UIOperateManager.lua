-- ModulesViewDef = 
-- {
-- 	Talent = "Talent", --text
-- }

--用来看的，实际没用
local ModulesViewDef = 
{
	AppFacade.Main, --1 战役 2领地 3户外 4英雄
	AppFacade.Battle, --1 玩法选择,args: BattleType;怪物阵营id;args参数  || 2 战斗结束界面, args: wincamp enemy_id || 3 战斗加成图 4 战斗记录 args：wincamp;reddata;bluedata
					  --10 网络版玩法选择 args, activityid, 英雄阵营, 怪物阵营, 派生类, 参数
					  --11打开战斗重播
					  --12打开主线boss关开始挑战
	AppFacade.Campaign, -- 1 关卡展示 args:mainlineid
	AppFacade.Hero, --1 英雄界面 args:heroid; herolist tabIndex,  2英雄属性面板 args:heroid; 3英雄技能面板 args: skillid;skilllevel; localposition hideLevelObj
					--4 英雄粉尘升级界面 5 英雄技能解锁 6快速升级界面 7英雄马车资源界面 8英雄页签界面  9 马车
	AppFacade.Tower,  --1 挑战之塔 args:类型,上移	 2	赎罪之塔	
	AppFacade.Crystal,  --1 选择英雄 args:索引 2 卸下英雄 args:索引 3添加英雄成功, args:herouid 4共鸣水晶
	AppFacade.Temple, --1 进阶确认 args:list, type(1进阶,2共鸣) , 2进阶成功 args herodata1,herodata2  3大圣堂
	AppFacade.CardPortal, ---1 普通卡池  2 种族卡池,3占星
	AppFacade.Task, --1 主线任务
	AppFacade.Territory, --领地
	AppFacade.StoryLine, --剧情副本
	AppFacade.Mail, --邮件
	AppFacade.Bag, --背包
	AppFacade.RoleInfo, --个人信息
	AppFacade.Guild, --公会
	AppFacade.Chat,  --聊天
	AppFacade.Journey,  --征途
}

UIOperateManager = UIOperateManager or BaseClass()
function UIOperateManager:__init()
	UIOperateManager.Instance = self
	self.operationTable = {}
	self.operatefuncStack = {}
	self:RegisterFunc()
end	

function UIOperateManager:__delete()
	self.operationTable = {}
	self.operatefuncStack = {}
	self.Instance = nil
end

function UIOperateManager:RegisterOperation(intKey, operation)
	self.operationTable[intKey] = operation
end

function UIOperateManager:OpenWidget(intKey, ...)
	if nil ~= self.operationTable[intKey] then
		self.operationTable[intKey]({...})
	end
end

function UIOperateManager:PushOperate(operatefunc)
	-- table.insert(self.operatefuncStack, operatefunc)
	operatefunc()
end

function UIOperateManager:PopOperate()
	local func = table.remove(self.operatefuncStack)
	if func then
		func()
	end
end

function UIOperateManager:RegisterFunc()
	self:RegisterOperation(AppFacade.Main, function(args)
		LuaLayout.Instance:CloseAllWidget()
		LuaLayout.Instance:OpenWidget(UIWidgetNameDef.MainView)
		if args[1] == 1 then
			LuaLayout.Instance:OpenWidget(UIWidgetNameDef.CampaignView)
		elseif args[1] == 4 then

		end
	end)

	self:RegisterOperation(AppFacade.Battle, function(args)
		if args[1] == 1 then
			if AppConfig.ISALONE then
				local readyview = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleReadyView)
				readyview.callback = function ()
					local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleSelectView)
					view.battleType = args[2]
					view.enemylist = args[3]
					view.args = args[4]
					view:OpenView()
				end
				readyview:OpenView()

			elseif args[2] == ACTIVITYID.MAINLINE then
				local CampaignProxy = require "Modules.Campaign.CampaignProxy"
				local enemyid = args[4] or 0
				CampaignProxy.Instance:Send51004(enemyid)
			end

		elseif args[1] == 2 then
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleSettlementView)
			if args[3] == ACTIVITYID.MAINLINE then
				if args[7] and (args[7] == 0) then
					view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleSettlement2View)
				end
			elseif args[3] == ACTIVITYID.STORYLINE or args[3] == ACTIVITYID.ACTIVITY or args[3] == ACTIVITYID.MOBILIZE then
				view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleSettlement2View)
			end
			view.wincamp = args[2]
			view.battleType = args[3]
			view.args = args[4]
			view.enemy_id = args[5]
			view.enemyData = args[6]
			view:OpenView()
			
		elseif args[1] == 3 then
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleRelationView)
			view.heroconfiglist = args[2]
			view.camp = args[3]
			view:OpenView()

		elseif args[1] == 4 then
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleRecordView)
			view.wincamp = args[2]
			view.redInfo = args[3]
			view.blueInfo = args[4]
			view.camps= args[5]
			view.callback = args[6]
			view.bformationBtn = args[7] or {true, false} --玩家方，敌方是否显示编队按钮（只有是玩家才显示）
			view:OpenView()
		elseif args[1] == 10 then
			local BattleProxy = require "Modules.Battle.BattleProxy"
			local paramas = {}
			paramas.activityid = args[2]
			paramas.heroinfos = args[3]
			paramas.enemyinfos = args[4]
			paramas.panelstr = args[5]
			paramas.args = args[6]
			BattleProxy.Instance:BattleReadyNextStep(args[2], 1, paramas)
			-- local readyview = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleReadyView)
			-- readyview.callback = function ()
			-- 	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleNetSelectView)
			-- 	view.activityid = args[2]
			-- 	view.heroinfos = args[3]
			-- 	view.enemyinfos = args[4]
			-- 	view.panelstr = args[5]
			-- 	view.args = args[6]
			-- 	view:OpenView()
			-- end
			-- readyview:OpenView()	
		elseif args[1] == 11 then
			local activityid, levelId = args[2], args[3]
			if activityid and levelId then
	            local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.WinFormationView)
	            if view then
	                view.activityId = activityid
	                view.levelId = levelId
	                view:OpenView()
	            end
	        end
		elseif args[1] == 12 then
			local ModuleManager = require "Common.Mgr.UI.ModuleManager"
			local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
			local CampaignProxy = require "Modules.Campaign.CampaignProxy"
			local SceneManager = require "Modules.Scene.SceneManager"
			local SceneDef = require "Modules.Scene.SceneDef"
			local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.MainLine)
			if bopen then
				local mainlinecfg = CampaignProxy.Instance:GetMainLineCfgById(RoleInfoModel.mainlineid)
				if CampaignProxy.Instance:IsPassToNextChapter() then
					SceneManager.Instance:EnterScene(SceneDef.SceneType.WorldMap)
				else
					if mainlinecfg then
						if mainlinecfg.chapter == 1 then
							if math.fmod(mainlinecfg.section, 3) == 0 then
								UIOperateManager.Instance:OpenWidget(AppFacade.Campaign, 1, RoleInfoModel.mainlineid)
							else
								local enemy_id = mainlinecfg.enemy_id
								local enemylist = GameLogicTools.GetEnemyList(enemy_id)
								UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 1, ACTIVITYID.MAINLINE, enemylist, enemy_id)
							end
						else
							if math.fmod(mainlinecfg.section, 4) == 0 then
								UIOperateManager.Instance:OpenWidget(AppFacade.Campaign, 1, RoleInfoModel.mainlineid)
							else
								local enemy_id = mainlinecfg.enemy_id
								local enemylist = GameLogicTools.GetEnemyList(enemy_id)
								UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 1, ACTIVITYID.MAINLINE, enemylist, enemy_id)
							end
						end
					else
						GameLogicTools.ShowMsgTips("Common_1002")
					end
				end
			end

		end
	end)

	self:RegisterOperation(AppFacade.Campaign, function(args)
		if args[1] == 1 then
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BossInfoView)
			view.mainlineid = args[2]
			view.bshowRecord = args[3] == nil and true or args[3]
			view:OpenView()
		end	
	end)

	self:RegisterOperation(AppFacade.Hero, function(args)
		if args[1] == 1 then
		    -- local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.HeroView)
		    local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.HeroNewView)
		    view.selectid = args[2]
		    view.herolist = args[3]
		    view.tabIndex = args[4]
		    view.mercenaryInfo = args[5]
		    view:OpenView()

		elseif args[1] == 2 then
		    local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.HeroAttrView)
		    view.herouid = args[2]
		    view.roleid = args[3]
		    view.rank = args[4]
		    view.level = args[5]
		    view.equips = args[6]
		    view.isMercenary = args[7]
		    view.tree_info = args[8]
		    view:OpenView()

		elseif args[1] == 3 then
		    local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.SkillTipsView)
			view.skillid = args[2]
			view.skilllevel = args[3]
			view.localPosition = args[4]
			view.callback = args[5]
			view.hideLevelObj = args[6]
			if view:IsOpen() then
				view:UpdateInfo()
			else	
		    	view:OpenView()
		    end
		elseif args[1] == 4 then
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.UpgradeConfirmView)
			view.herouid = args[2]
			view:OpenView()
			
		elseif args[1] == 5 then
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.HeroUpgradeView)
			view.herouid = args[2]
			view.quickUp = args[3]
			view.formerLv = args[4]
			view:OpenView()

		elseif args[1] == 6 then
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.AutoUpgradeView)
			view.herouid = args[2]
			view:OpenView()

		elseif args[1] == 7 then
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.RetireConfirmView)
			view.list = args[2]
			view.callback = args[3]
			view:OpenView()	
		elseif args[1] == 8 then
			local ModuleManager = require "Common.Mgr.UI.ModuleManager"
			local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
			local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.HeroRootView)
			if bopen then
				local enterMainScene = args[2] and args[2] or false
				local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.HeroRootView)
				view.enterMainScene = enterMainScene  --关闭界面是是否退回到主场景
				view:OpenView()
				-- LuaLayout.Instance:OpenWidget(UIWidgetNameDef.HeroRootView)	
			end
		elseif args[1] == 9 then
			local ModuleManager = require "Common.Mgr.UI.ModuleManager"
			local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
			local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.FountainView)
			if bopen then
				local FountainView = require "Modules.Hero.Fountain.FountainView"
				local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.FountainView)
				FountainView.TabIndex = args[2] or 1
				local bBackMainScene = args[3] or false
				FountainView.bBackMainScene = bBackMainScene
				local closeParam = args[4]
				view.closeParam = closeParam
				local initHerouid = args[5]
				view.initHerouid = initHerouid
				view:OpenView()
			end
		elseif args[1] == 10 then
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.ItemQuickUseView)
			view.targetGoodsId = args[2]
			view.targetCostNum = args[3]
			view:OpenView()
		end	
	end)

	self:RegisterOperation(AppFacade.Tower, function(args)
		if args[1] == 1 then
			local str = "TowerEntranceView_" .. args[2]
			local ModuleManager = require "Common.Mgr.UI.ModuleManager"
			local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
			local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType[str])
			if bopen then
				local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.TowerChallengeView)
				view.towertype = args[2]
				view.badd = args[3]
				view:OpenView()
			end
		elseif args[1] == 2 then
			local ModuleManager = require "Common.Mgr.UI.ModuleManager"
			local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
			local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.TowerEntranceView_0)
			if bopen then
				local bopen1 = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.TowerEntranceView_1, false)
				local bopen2 = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.TowerEntranceView_2, false)
				local bopen3 = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.TowerEntranceView_3, false)
				local bopen4 = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.TowerEntranceView_4, false)
				if not bopen1 and not bopen2 and not bopen3 and not bopen4 then
					--种族塔没有开启，不打开TowerEntranceView,
					local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.TowerChallengeView)
					view.towertype = 0
					view.badd = false
					view:OpenView()
				else
					LuaLayout.Instance:OpenWidget(UIWidgetNameDef.TowerEntranceView)
				end
			end
		end
	end)	

	self:RegisterOperation(AppFacade.Crystal, function(args)
		if args[1] == 1 then
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.CrystalSelectView)
			view.index = args[2]
			view:OpenView()
		elseif args[1] == 2 then
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.CrystalRemoveHeroView)
			view.index = args[2]
			view:OpenView()			
		elseif args[1] == 3 then
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.CrystalAddHeroView)
			view.herouid = args[2]
			view:OpenView()	
		elseif args[1] == 4 then
			local ModuleManager = require "Common.Mgr.UI.ModuleManager"
			local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
			local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.CrystalView)
			if bopen then
				local SceneManager = require "Modules.Scene.SceneManager"
	         	local SceneDef = require "Modules.Scene.SceneDef"
	         	local closeParam = args[2] --目前是空表，以后若有多种跳转再考虑加参数
	         	SceneManager.Instance:EnterScene(SceneDef.SceneType.Crystal, closeParam)
	        end
		end
	end)	

	self:RegisterOperation(AppFacade.Temple, function(args)
		if args[1] == 1 then
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.TempleConfirmView)
			view.list = args[2]
			view.type = args[3]
			view:OpenView()
			
		elseif args[1] == 2 then	
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.TempleSuccessView)
			view.herodata1 = args[2]
			view.herodata2 = args[3]
			view.water = args[4]
			view:OpenView()		
		elseif args[1] == 3 then
			local ModuleManager = require "Common.Mgr.UI.ModuleManager"
			local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
			local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.TempleView)
			if bopen then
				local herouid = args[2]
				local closeParam = args[3] --关闭界面时跳转用到参数
				local SceneManager = require "Modules.Scene.SceneManager"
				local SceneDef = require "Modules.Scene.SceneDef"
	        	SceneManager.Instance:EnterScene(SceneDef.SceneType.Temple , herouid, closeParam)
	        end					
		end			
	end)

	self:RegisterOperation(AppFacade.CardPortal, function(args)
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.CardPortView)
		if bopen then
			local SceneManager = require "Modules.Scene.SceneManager"
			local SceneDef = require "Modules.Scene.SceneDef"        
			local selectIdx = args[1] or 1
			if selectIdx == 3 then
				--LuaLayout.Instance:CloseWidget(UIWidgetNameDef.CardPortalView)
				--LuaLayout.Instance:OpenWidget(UIWidgetNameDef.CardStarView)
				SceneManager.Instance:EnterScene(SceneDef.SceneType.CardStar, args[1])
			else
				SceneManager.Instance:EnterScene(SceneDef.SceneType.DrawCard, args[1])		
			end
	       
	    end
	end)

	self:RegisterOperation(AppFacade.Task, function(args)
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.MainTaskView)
		if bopen then
			local view = require "Modules.Task.MainTaskView"
			view.SelectIndex = args[1] or -1	
			LuaLayout.Instance:OpenWidget(UIWidgetNameDef.MainTaskView)
		end
	end)	

	self:RegisterOperation(AppFacade.Maze, function(args)
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.MazeView)
		if bopen then
			-- local SceneManager = require "Modules.Scene.SceneManager"
	  --       local SceneDef = require "Modules.Scene.SceneDef"
	  --       SceneManager.Instance:EnterScene(SceneDef.SceneType.Maze) 
	        local MazeProxy = require "Modules.Maze.MazeProxy"
	        MazeProxy.Instance:RequireEnterMazeScene()
	    end
	end)

	self:RegisterOperation(AppFacade.Store, function(args)
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.StoreView)
		if bopen then
			local StoreDef =require "Modules.Store.StoreDef"
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.StoreView)
			local type=1
			if not args or not args[1] then
				type=StoreDef.StoreType.normal
			else
				type=args[1]
			end
			view.storeType=type
			view:OpenView()
		end
	end)
	
	self:RegisterOperation(AppFacade.RoleInfo, function(args)
		--打开自己的，打开别人的暂时不加
		local openWay = args[1] --1:点公会头像打开
		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.HomePageView)
		view.openWay = openWay
		view:OpenView()
	end)

	self:RegisterOperation(AppFacade.StoryLine, function(args)
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.StoryLineRootView)
		if bopen then	
			LuaLayout.Instance:OpenWidget(UIWidgetNameDef.StoryLineRootView)
		end
	end)

	self:RegisterOperation(AppFacade.Mail, function(args)
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.MailView)
		if bopen then	
			LuaLayout.Instance:OpenWidget(UIWidgetNameDef.MailView)
		end
	end)


	self:RegisterOperation(AppFacade.Bag, function(args)
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.BagRootView)
		if bopen then	
			LuaLayout.Instance:OpenWidget(UIWidgetNameDef.BagRootView)
		end
	end)

	self:RegisterOperation(AppFacade.Friend, function(args)
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.FriendlListView)
		if bopen then
		 	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.FriendlListView)
			view.tagIndex = args[1]
			view:OpenView()
		end
	end)

	self:RegisterOperation(AppFacade.Guild, function(args)
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		local GuildProxy = require "Modules.Guild.GuildProxy"
		local AudioManager = require "Common.Mgr.Audio.AudioManager"
		local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.GuildRootView)
		if bopen then
			local open_chaos = args and args[1]
			GuildProxy.Instance:Send70026(open_chaos)
		end
	end)

	self:RegisterOperation(AppFacade.Chat, function(args)
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.ChatRootView)
		if bopen then	
			LuaLayout.Instance:OpenWidget(UIWidgetNameDef.ChatRootView)
		end
	end)

	self:RegisterOperation(AppFacade.Arena, function(args)
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		local type = args[1] or 0
		if  type == 0 then
			local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.ArenaEntranceView)
			if bopen then	
				LuaLayout.Instance:OpenWidget(UIWidgetNameDef.ArenaEntranceView)
			end
		elseif type == 1 then
			local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.ArenaEntranceView)
			if bopen then	
				LuaLayout.Instance:OpenWidget(UIWidgetNameDef.ArenaEntranceView)
				LuaLayout.Instance:OpenWidget(UIWidgetNameDef.ArenaView)
			end
		elseif type == 2 then
			local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.ProArenaEntranceView)
			if bopen then	
				LuaLayout.Instance:OpenWidget(UIWidgetNameDef.ArenaEntranceView)
				LuaLayout.Instance:OpenWidget(UIWidgetNameDef.ProArenaView)
			end
		end
		
		
	end)

	self:RegisterOperation(AppFacade.StoryLine, function(args)
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.StoryLineRootView )
		if bopen then	
			LuaLayout.Instance:OpenWidget(UIWidgetNameDef.StoryLineRootView)
		end
		 
	end)

	self:RegisterOperation(AppFacade.SupplyDepot, function(args)
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.SupplyDepotView)
		if bopen then
			LuaLayout.Instance:OpenWidget(UIWidgetNameDef.SupplyDepotView)
		end
	end)

	self:RegisterOperation(AppFacade.RankList, function(args)
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.RankListView)
		if bopen then
			LuaLayout.Instance:OpenWidget(UIWidgetNameDef.RankListView)
		end
	end)

	self:RegisterOperation(AppFacade.Mall, function(args)
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		local type = args[1] or 1
		if type == 1 then
			local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.MallRootView)
			if bopen then
				local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MallRootView)
				if args[2] then --MallDef.RootType
					view.selectIndex = args[2]
				end
				if args[3] then --MallDef.NormalType or MallDef.LimitType
					view.selectIndex2 = args[3]
				end
				view:OpenView()
			end
		elseif type == 2 then
			-- 首充任意
			LuaLayout.Instance:OpenWidget(UIWidgetNameDef.MallFirstChargeView)
		elseif type == 3 then
			local MallProxy = require "Modules.Mall.MallProxy"
			MallProxy.Instance:ShowPushView(args[2])
		elseif type == 4 then
			local MallDef = require "Modules.Mall.MallDef"
			local MallPassProxy = require "Modules.Mall.MallPassProxy"
			local selectIndex2 = args[3]
			local is_open = false
			if selectIndex2 == MallDef.LimitType.HappyMonth then
				is_open = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.HappyMonthPanel)
			else
				is_open = MallPassProxy.Instance:CheckPassOpenBytype(selectIndex2)
			end
			local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.MallRootView)
			if is_open and bopen then
				local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MallRootView)
				if args[2] then --MallDef.RootType
					view.selectIndex = args[2]
				end
				if args[3] then --MallDef.NormalType or MallDef.LimitType
					view.selectIndex2 = args[3]
				end
				view:OpenView()
			end
		elseif type == 5 then
			local select_info = args[2] --选中信息 {[槽位index] = 选中的Index} 0是未选中
			local gift_id = args[3] -- data_mall_gift礼包库ID
			local confirm_cb = args[4] -- 确认按钮的回调
			local select_index = args[5] -- 默认选中的槽位
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.MallSelfView)
			--view.custom_id = custom_id
			view.select_index = select_index
			view.select_info = select_info
			view.gift_id = gift_id
			view.confirm_cb = confirm_cb
			view:OpenView()
		elseif type == 6 then
			LuaLayout.Instance:OpenWidget(UIWidgetNameDef.MallDailySupplyView)
		end
	end)

	self:RegisterOperation(AppFacade.Relation, function(args)
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.RelationMenuRootView_2) --领地羁绊入口
		if bopen then
			LuaLayout.Instance:OpenWidget(UIWidgetNameDef.RelationMenuRootView)
		end
	end)

	self:RegisterOperation(AppFacade.Tree, function(args)
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		local type = args[1] or 1

		if type == 1 then
			local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.Tree) --领地羁绊入口
			if bopen then
				local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.RelationMenuRootView)
				view.init_index = 2
			end
		elseif type == 2 then
		    local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.SkillTipsView)
			view.tree_branch_index = args[2]
			view.tree_buff_index = args[3]
			view.localPosition = args[4]
			view.callback = args[5]
			if view:IsOpen() then
				view:UpdateTreeBuffInfo()
			else	
		    	view:OpenView()
		    end
		elseif type == 3 then
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.WaterReceiveView)
			view.new_hero_info = args[2]
			view:OpenView()
		end
	end)

	self:RegisterOperation(AppFacade.Activity, function(args)
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.ActivityRoot) --领地羁绊入口
		if bopen then
			if args[1] == 3 then
				LuaLayout.Instance:OpenWidget(UIWidgetNameDef.ShareChargeView)
				return
			end
			local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.ActivityRootView)
			if view  then
				local data = {}
				data.type = args[1] or 1
				view.data = data
				view:OpenView()
			end
		end
	end)

	self:RegisterOperation(AppFacade.SettingMenu, function(args)
		if args[1] == 1 then
			local SettingMenuProxy = require "Modules.SettingMenu.SettingMenuProxy"
			SettingMenuProxy.Instance:SetNewsRedDotState(1)
			
			SettingMenuProxy.Instance:OpenNewsWebView()
		end
	end)

	self:RegisterOperation(AppFacade.Realm, function(args)
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.RealmRootView) --位面幻境
		if bopen then
			if args[1] == 1 then
				LuaLayout.Instance:OpenWidget(UIWidgetNameDef.RealmRootView)
			end
		end
	end)

	self:RegisterOperation(AppFacade.CycleActivity, function(args)
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		if args[1] then
			if args[2] == 1 then --类型
				local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.CycleActivityRoot) 
				if bopen then
					local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.CycleSevendaysCheckinView)
					if view then
						view.data = {}
						view.data.id = args[1] -- id
						view:OpenView()
					end
				end
			elseif args[2] == 2 then
				local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.CycleSevenLoginTypeTwoView)
				if view then
					view.data = {}
					view.data.id = args[1]
					view:OpenView()
				end
			elseif args[2] == 3 then
				local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.EventsNineBoxView)
				if view then
					view.data = {}
					view.data.id = args[1]
					view:OpenView()
				end
			end
			
		end
	end)

	self:RegisterOperation(AppFacade.Mobilize, function(args)
		local ModuleManager = require "Common.Mgr.UI.ModuleManager"
		local ModuleOpenDef = require "Common.Mgr.UI.ModuleOpenDef"
		local bopen = ModuleManager.SystemIsOpen(ModuleOpenDef.SystemOpenType.MobilizeView) --
		if bopen then
			if args[1] == 1 then
				LuaLayout.Instance:OpenWidget(UIWidgetNameDef.MobilizeView)
			end
		end
	end)
end

UIOperateManager.New()