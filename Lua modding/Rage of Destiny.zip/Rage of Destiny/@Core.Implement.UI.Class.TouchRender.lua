local Input = CS.UnityEngine.Input
local KeyCode = CS.UnityEngine.KeyCode
local TouchPhase = CS.UnityEngine.TouchPhase
local isEditor = CS.UnityEngine.Application.isEditor

local FrameUpdateMgr = require "First.Util.FrameUpdateMgr"

local TouchRender = TouchRender or BaseClass()

TouchRender.MoveType = {
    None = 0,
    Left = 1,
    Right = 2,
    Top = 3,
    Down = 4,
    Enlarge = 5, --扩大
    Narrow = 6, --缩小
}

TouchRender.State = {
    None = 0,
    Start = 1,
    End = 2,
}

function TouchRender:__init()
    self._clickFunc = nil
    self._moveFunc = nil
    self._scaleFunc = nil

    --记录上一次手机触摸位置判断用户是在做放大还是缩小手势
    self.oldPosition1 = Vector2.zero
    self.oldPosition2 = Vector2.zero
end

function TouchRender:SetClickCallback(func)
    self._clickFunc = func
end

--moveType, delta
function TouchRender:SetMoveCallback(func)
    self._moveFunc = func
end

--移动 position
function TouchRender:SetMovePositionCallback(func)
    self._movePositionFunc = func
end

--缩放
function TouchRender:SetScaleCallback(func)
    self._scaleFunc = func
end

--按下
function TouchRender:SetDownCallback(func)
    self._startFunc = func
end

--松手
function TouchRender:SetUpCallback(func)
    self._endFunc = func
end

function TouchRender:Start()
    FrameUpdateMgr.Add(self)
end

function TouchRender:Stop()
    FrameUpdateMgr.Remove(self)
    self.state = TouchRender.State.None
end

function TouchRender:FrameUpdate(time, deltaTime)
    if (Input.GetMouseButtonDown(0) or Input.touchCount > 0) then
        local position = nil
        if isEditor then
            position = Input.mousePosition
        else
            if Input.touchCount > 0 and Input.GetMouseButtonDown(0) then
                position = Input.touches[0].position
            end
        end
        if position and self._clickFunc then
            local screenPos = UILayerTool.ScreenRateToScreenPoint(position)
            local screen = UILayerTool.CurrentScreen()
            local vec2 = Vector2.New(screenPos.x - screen.width / 2, screenPos.y - screen.height / 2)
            self._clickFunc(vec2)
        end
        if self.state ~= TouchRender.State.Start then
            self.state = TouchRender.State.Start
            if self._startFunc then
                self._startFunc()
            end
        end
    end

    if Input.GetMouseButtonUp(0) or Input.touchCount == 0 then
        if self.state == TouchRender.State.Start then
            self.state = TouchRender.State.End
            if self._endFunc then
                self._endFunc()
            end
        end
    end

    if self.state == TouchRender.State.Start and self._movePositionFunc then
        local position = nil
        if isEditor then
            position = Input.mousePosition
        else
            if Input.touchCount > 0 and Input.GetMouseButtonDown(0) then
                position = Input.touches[0].position
            end
        end

        if position and self._movePositionFunc then
            self._movePositionFunc(position)
        end
    end

    --onclick
    -- if (Input.GetMouseButton(0)) then
    -- 	if self._moveFunc then
    -- 		local deltaX = Input.GetAxis ("Mouse X")
    -- 		local deltaY = Input.GetAxis ("Mouse Y")
    -- 		self._moveFunc(deltaX > 0 and TouchRender.MoveType.Right or TouchRender.MoveType.Left, deltaX)
    -- 		self._moveFunc(deltaY > 0 and TouchRender.MoveType.Top or TouchRender.MoveType.Down, deltaY)
    -- 	end
    -- end
    -- if Input.GetMouseButtonDown(0) or Input.touchCount == 1 then
    -- 	local position = nil
    -- 	if isEditor then
    -- 		position = Input.mousePosition
    -- 		if position and self._clickFunc then
    -- 			self._clickFunc(position)
    -- 		end

    -- 	elseif Input.touchCount == 1 then
    -- 		local touch = Input.touches[0]
    -- 		if touch.phase == TouchPhase.Moved then
    -- 			if self._moveFunc then
    -- 				local deltaX = Input.GetAxis ("Mouse X")
    -- 				local deltaY = Input.GetAxis ("Mouse Y")
    -- 				self._moveFunc(deltaX > 0 and TouchRender.MoveType.Right or TouchRender.MoveType.Left, deltaX)
    -- 				self._moveFunc(deltaY > 0 and TouchRender.MoveType.Top or TouchRender.MoveType.Down, deltaY)
    -- 			end
    --            else
    --            	position = Input.touches[0].position
    -- 			if position and self._clickFunc then
    -- 				self._clickFunc(position)
    -- 			end
    --            end
    -- 	end

    --if Input.touchCount > 1 then
    --    -- 前两只手指触摸类型都为移动触摸
    --    local tempPosition1
    --    local tempPosition2
    --    for i = 1, 2 do
    --        local touch = Input.GetTouch(1)
    --        if touch.phase == TouchPhase.Began then
    --            if i == 0 then
    --                self.oldPosition1 = touch.position
    --            else
    --                self.oldPosition2 = touch.position
    --            end
    --        elseif touch.phase == TouchPhase.Moved then
    --            if i == 0 then
    --                tempPosition1 = touch.position
    --            else
    --                tempPosition2 = touch.position
    --            end
    --        end
    --    end
    --    if self:isEnlarge(self.oldPosition1, self.oldPosition2, tempPosition1, tempPosition2) then
    --        print("1111")
    --        if self._scaleFunc then
    --            print("222")
    --            self._scaleFunc(TouchRender.MoveType.Enlarge)
    --        end
    --    else
    --        print("333")
    --        if self._scaleFunc then
    --            print("4444")
    --            self._scaleFunc(TouchRender.MoveType.Narrow)
    --        end
    --    end
    --    self.oldPosition1 = tempPosition1
    --    self.oldPosition2 = tempPosition2
    --end
    --if isEditor then
    --    local scroll = Input.GetAxis("Mouse ScrollWheel")
    --    if (scroll > 0) then
    --        if self._scaleFunc then
    --            self._scaleFunc(TouchRender.MoveType.Enlarge)
    --        end
    --    elseif scroll < 0.0 then
    --        if self._scaleFunc then
    --            self._scaleFunc(TouchRender.MoveType.Narrow)
    --        end
    --    end
    --end
end

--返回真为放大，返回假为缩小
function TouchRender:isEnlarge(oP1, oP2, nP1, nP2)
    local leng1 = Vector2.Distance(oP1, oP2)
    local leng2 = Vector2.Distance(nP1, nP2)
    -- local leng1 = math.sqrt((oP1.x - oP2.x) * (oP1.x - oP2.x) + (oP1.y - oP2.y) * (oP1.y - oP2.y))
    -- local leng2 = math.sqrt((nP1.x - nP2.x) * (nP1.x - nP2.x) + (nP1.y - nP2.y) * (nP1.y - nP2.y))
    return leng1 < leng2
end

return TouchRender