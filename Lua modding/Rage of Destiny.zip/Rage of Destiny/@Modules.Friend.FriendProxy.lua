local FriendDef = require "Modules.Friend.FriendDef"
local BattleProto = require "Core.Implement.Net.BattleProto"
local LoginProxy = require "Modules.Login.LoginProxy"
local LoginDef = require "Modules.Login.LoginDef"
local crypt = require "crypt"
local md5 = require "First.Util.md5"
local rapidjson = require "rapidjson"
local httputil = require "Common.Util.httputil"
local RedPointProxy = require "Modules.RedPoint.RedPointProxy"
local RedPointDef = require "Modules.RedPoint.RedPointDef"

local FriendProxy = FriendProxy or BaseClass(BaseProxy, BattleProto)

function FriendProxy:__init()
	FriendProxy.Instance = self
	self.data = {}

	--好友一些写死参数
	self.friendParama = {
		sendLove_max = 40,  --每日赠送爱心上限
		getLove_max = 20,   --每日领取爱心上限
		friendNum_max = 40, --好友最大数量
		applyfrienNum_max = 100, --好友申请列表最大数量
		blackFriendNum_max = 30, --拉黑列表最大数量
	}

	self:AddProto(19000, self.On19000)
	self:AddProto(19001, self.On19001)
	self:AddProto(19002, self.On19002)
	self:AddProto(19003, self.On19003)
	self:AddProto(19004, self.On19004)
	self:AddProto(19005, self.On19005)
	self:AddProto(19006, self.On19006)
	self:AddProto(19007, self.On19007)
	self:AddProto(19008, self.On19008)
	self:AddProto(19009, self.On19009)
	self:AddProto(19010, self.On19010)
	self:AddProto(19011, self.On19011)
	self:AddProto(19012, self.On19012)
	self:AddProto(19013, self.On19013)
	self:AddProto(19014, self.On19014)
	self:AddProto(19015, self.On19015)
	
	self:AddProto(19016, self.On19016) --备战
	self:AddProto(19017, self.On19017) --上阵

	self:AddProto(19018, self.On19018)

	self:AddProto(19019, self.On19019) --收到好友申请
	self:AddProto(19020, self.On19020) --收到红心

    self:AddPreBattle(ACTIVITYID.FRIEND_VERSUS, self.OnPreBattle) --准备战斗回调
    self:AddSetBattle(ACTIVITYID.FRIEND_VERSUS, self.OnSetBattle) --战斗结算回调
    self:AddStartBattle(ACTIVITYID.FRIEND_VERSUS, self.OnStartBattle) --战斗开始回调
end

function FriendProxy:__delete()
	self.data = nil
end

function FriendProxy:Send19000()
	self:SendMessage(19000)
end

function FriendProxy:On19000(decoder)
	self.data.friendInfo = {}  --好友列表相关数据
	local info = {}
	info.intimacy = decoder:Decode("I4") --当天拥有亲密度
	info.sendIntimacyNum = decoder:Decode("I2") --当日赠送爱心数量
	info.getIntimacyNum = decoder:Decode("I2") --当日收取爱心数量
	info.sortTypr = decoder:Decode("I2") --排序类型
	info.friendLists = {}   --好友列表

	local friend_count = decoder:Decode("I2")
	for i=1,friend_count do
		--headitem数据  nickname, sex, headIcon, frameIcon, level, fight, roleid
		local item = {}

		local headItem = {}
		headItem.nickname = decoder:Decode("s2")   --昵称
		headItem.sex = decoder:Decode("I2")           --性别
		headItem.headIcon = decoder:Decode("I4")  --头像id
		headItem.frameIcon = decoder:Decode("I4") --头像框id
		headItem.level = decoder:Decode("I2")         --等于
		headItem.fight = decoder:Decode("I4")         --战力

		item.headItem = headItem

		item.server_Id = decoder:Decode("I2")      --服务器id
		item.serverName = item.server_Id --服务器名称
		item.guser = decoder:Decode("I8")     --guser
		item.mainlineId = decoder:Decode("I2")     --主线id
		item.lineState = decoder:Decode("I8")      --在线状态  0:在线  大于0：离线时间
		item.getLove = decoder:Decode("I2")        --收获爱心 0 没有收获爱心 1 收获爱心未领取  2 收获爱心已领取
		item.sendLove = decoder:Decode("I2")       --赠送爱心 0 未赠送 1已赠送
		table.insert(info.friendLists, item)

	end
	
	self.data.friendInfo = info
	-- print("friendInfo===", table.dump(info))
	self:ToNotify(self.data, FriendDef.Notify.UpdateFriendList, {friendInfos = info})

	self:UpdateRedPoint()
end

function FriendProxy:Send19001(searchList)
	local encode = NetEncoder.New()
	encode:EncodeList("I2I2I4", searchList)

	self:SendMessage(19001, encode)
end

function FriendProxy:On19001(decoder)
	local searchList = {}
	local friend_count = decoder:Decode("I2")
	for i=1,friend_count do
		--headitem数据  nickname, sex, headIcon, frameIcon, level, fight, roleid
		local item = {}

		local headItem = {}
		headItem.nickname = decoder:Decode("s2")   --昵称
		headItem.sex = decoder:Decode("I2")           --性别
		headItem.headIcon = decoder:Decode("I4")  --头像id
		headItem.frameIcon = decoder:Decode("I4") --头像框id
		headItem.level = decoder:Decode("I2")         --等于
		headItem.fight = decoder:Decode("I4")         --战力

		item.headItem = headItem

		item.server_Id = decoder:Decode("I2")      --服务器id
		item.serverName = item.server_Id --服务器名称
		item.guser = decoder:Decode("I8")     --guser
		table.insert(searchList, item)

	end
	self.data.searchInfos = searchList
	self:ToNotify(self.data, FriendDef.Notify.UpdateSearchList, {searchInfos = searchList})
end

function FriendProxy:Send19002()
	self:SendMessage(19002)
end

function FriendProxy:On19002(decoder)
	local applyList = {}
	local friend_count = decoder:Decode("I2")
	for i=1,friend_count do
		--headitem数据  nickname, sex, headIcon, frameIcon, level, fight, roleid
		local item = {}

		local headItem = {}
		headItem.nickname = decoder:Decode("s2")   --昵称
		headItem.sex = decoder:Decode("I2")           --性别
		headItem.headIcon = decoder:Decode("I4")  --头像id
		headItem.frameIcon = decoder:Decode("I4") --头像框id
		headItem.level = decoder:Decode("I2")         --等于
		headItem.fight = decoder:Decode("I4")         --战力

		item.headItem = headItem

		item.server_Id = decoder:Decode("I2")      --服务器id
		item.serverName = item.server_Id --服务器名称
		item.guser = decoder:Decode("I8")     --guser
		item.applyTime = decoder:Decode("I4")  --发送申请时间
		table.insert(applyList, item)

	end
	self.data.applyInfos = applyList
	-- print("applyList===", table.dump(applyList))
	-- self:UpdateRedDot()
	RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.FriendApply, self:GetFriendApplyRedNum())

	self:ToNotify(self.data, FriendDef.Notify.UpdateApplyList, {applyInfos = applyList})
end

function FriendProxy:Send19003()
	self:SendMessage(19003)
end

function FriendProxy:On19003(decoder)
	local blackList = {}
	local friend_count = decoder:Decode("I2")
	for i=1,friend_count do
		--headitem数据  nickname, sex, headIcon, frameIcon, level, fight, roleid
		local item = {}

		local headItem = {}
		headItem.nickname = decoder:Decode("s2")   --昵称
		headItem.sex = decoder:Decode("I2")           --性别
		headItem.headIcon = decoder:Decode("I4")  --头像id
		headItem.frameIcon = decoder:Decode("I4") --头像框id
		headItem.level = decoder:Decode("I2")         --等于
		headItem.fight = decoder:Decode("I4")         --战力

		item.headItem = headItem

		item.server_Id = decoder:Decode("I2")      --服务器id
		item.serverName = item.server_Id --服务器名称
		item.guser = decoder:Decode("I8")     --guser
		table.insert(blackList, item)

	end
	self.data.blackInfos = blackList
	-- print("blackList===", table.dump(blackList))
	self:ToNotify(self.data, FriendDef.Notify.UpdateBlackList, {blackInfos = blackList})
end

function FriendProxy:Send19004(guser)
	local encoder = NetEncoder.New()
	encoder:Encode("I8", guser)
	self:SendMessage(19004, encoder)
end

function FriendProxy:On19004(decoder)
	local result = decoder:Decode("I2")
	if result == 0 then
		local guser, sendLove = decoder:Decode("I8I2")
		for i,info in ipairs(self.data.friendInfo.friendLists) do
			if info.guser == guser then
				info.sendLove = sendLove
				self.data.friendInfo.sendIntimacyNum = self.data.friendInfo.sendIntimacyNum + 1
				break
			end
		end
		-- self:ToNotify(self.data, FriendDef.Notify.UpdateSendIntimacy)
		self:ToNotify(self.data, FriendDef.Notify.UpdateFriendList, {friendInfos = self.data.friendInfo})

		GameLogicTools.ShowMsgTips("FriendView_1039")
	else
		GameLogicTools.ShowErrorCode(19004,result)
	end

	self:UpdateRedPoint()
end

function FriendProxy:Send19005(guser)
	local encoder = NetEncoder.New()
	encoder:Encode("I8", guser)
	self:SendMessage(19005, encoder)
end

function FriendProxy:On19005(decoder)
	local result = decoder:Decode("I2")
	if result == 0 then
		local guser, getLove = decoder:Decode("I8I2")
		for i,info in ipairs(self.data.friendInfo.friendLists) do
			if info.guser == guser then
				info.getLove = getLove
				self.data.friendInfo.intimacy = self.data.friendInfo.intimacy + 1
				self.data.friendInfo.getIntimacyNum = self.data.friendInfo.getIntimacyNum + 1
				break
			end
		end
		-- self:ToNotify(self.data, FriendDef.Notify.UpdateGetIntimacy)
		self:ToNotify(self.data, FriendDef.Notify.UpdateFriendList, {friendInfos = self.data.friendInfo})

		GameLogicTools.ShowMsgTips("FriendView_1040")
	else
		GameLogicTools.ShowErrorCode(19005,result)
	end

	self:UpdateRedPoint()
end

function FriendProxy:Send19006(guser)
	local encoder = NetEncoder.New()
	encoder:Encode("I8", guser)
	self:SendMessage(19006, encoder)
end

function FriendProxy:On19006(decoder)
	local result = decoder:Decode("I2")
	GameLogicTools.ShowErrorCode(19006,result)
end


function FriendProxy:Send19007(guser, order)
	local encoder = NetEncoder.New()
	encoder:Encode("I8", guser)
	encoder:Encode("I2", order)
	self:SendMessage(19007, encoder)
end

function FriendProxy:On19007(decoder)
	local result = decoder:Decode("I2")
	GameLogicTools.ShowErrorCode(19007,result)

	RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.FriendApply, self:GetFriendApplyRedNum())
end

function FriendProxy:Send19008(guser, order)
	local encoder = NetEncoder.New()
	encoder:Encode("I8", guser)
	encoder:Encode("I2", order)
	self:SendMessage(19008, encoder)
end

function FriendProxy:On19008(decoder)
	local result = decoder:Decode("I2")
	GameLogicTools.ShowErrorCode(19008,result)
end

function FriendProxy:Send19009(order)
	local encoder = NetEncoder.New()
	encoder:Encode("I2", order)
	self:SendMessage(19009, encoder)
end

function FriendProxy:On19009(decoder)
	local result, order = decoder:Decode("I2I2")
	GameLogicTools.ShowErrorCode(19009,result)
end

function FriendProxy:Send19010()
	self:SendMessage(19010)
end

function FriendProxy:On19010(decoder)
	local result = decoder:Decode("I2")
	GameLogicTools.ShowErrorCode(19010,result)
end

function FriendProxy:Send19011()
	self:SendMessage(19011)
end

function FriendProxy:On19011(decoder)
	local send_apply_list = decoder:DecodeList("I2")
	self.data.send_apply_list = send_apply_list
	self:ToNotify(self.data, FriendDef.Notify.UpdateSendApplyList)
end

function FriendProxy:Send19012()
	self:SendMessage(19012)
end

function FriendProxy:On19012(decoder)
	local result = decoder:Decode("I2")
	GameLogicTools.ShowErrorCode(19012, result)
end

--好友申请被拒绝推送
function FriendProxy:On19013(decoder)
	local _guser = decoder:Decode("I8")

end

--发送好友请求列表刷新_type :1增加  2减少 
function FriendProxy:On19014(decoder)
	local _type, _guser = decoder:Decode("I2I8")
	if _type == 1 then
		table.insert(self.data.send_apply_list, _guser)
	elseif _type == 2 then
		local select_idx
		for i, guser in ipairs(self.data.send_apply_list) do
			if guser == _guser then
				select_idx = i
				break
			end
		end
		if select_idx then
			table.remove(self.data.send_apply_list, select_idx)
		end
	end
	self:ToNotify(self.data, FriendDef.Notify.UpdateSendApplyList)
end

--sortTypr:1 状态排序  2名称排序
function FriendProxy:Send19015(sortTypr)
	local encoder = NetEncoder.New()
	encoder:Encode("I2", sortTypr)
	self:SendMessage(19015, encoder)
end

function FriendProxy:On19015(decoder)
	local sortTypr = decoder:Decode("I2")
	self.data.friendInfo.sortTypr = sortTypr
	self:ToNotify(self.data, FriendDef.Notify.UpdateFriendSortType, {sorType = sortTypr})
end

--好友备战
function FriendProxy:Send19016(guser)
	local encoder = NetEncoder.New()
	encoder:Encode("I8", guser)
	self:SendMessage(19016, encoder)
	
    local BattleProxy = require "Modules.Battle.BattleProxy"
    BattleProxy.Instance:BattleReadySetStep(ACTIVITYID.FRIEND_VERSUS, 1)
end

function FriendProxy:On19016(decoder)
	local result = decoder:Decode("I1")
	if result ~= 0 then
	    local BattleProxy = require "Modules.Battle.BattleProxy"
        BattleProxy.Instance:BattleReadyNextStep(ACTIVITYID.FRIEND_VERSUS, 1)
	end
end

function FriendProxy:OnPreBattle(decoder)
    local heroinfos = self:_DecodeHeroInfo(decoder)
    local enemyinfos = self:_DecodeEnemyInfo(decoder)
    local bufferstr = decoder:Decode("s2")
    -- local enemyid, mainlineid = string.unpack(">I4I4", bufferstr)
    --打开备战界面
    UIOperateManager.Instance:OpenWidget(AppFacade.Battle, 10, ACTIVITYID.FRIEND_VERSUS, heroinfos, enemyinfos, "BattleFriendPanel", {})
    
end

--好友上阵
function FriendProxy:Send19017(hero_infos, enemy_infos)
	local encoder = NetEncoder.New()
    self:_EncodeHeroInfo(hero_infos, encoder)
    self:_EncodeEnemyInfo(enemy_infos, encoder)
	self:SendMessage(19017, encoder)
end

function FriendProxy:On19017(decoder)
end

function FriendProxy:OnStartBattleBuffer(bufferstr, heroinfos, enemyinfos)
	return {}
end

function FriendProxy:OnSetBattle()

end

--删除好友
function FriendProxy:Send19018(guser)
	local encoder = NetEncoder.New()
	encoder:Encode("I8", guser)
	self:SendMessage(19018, encoder)

	--保留好友列表的滑动距离
	local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.FriendlListView)
	if view and view:IsOpen() then
		view:SaveFriendClistContentY()
	end
end

function FriendProxy:On19018(decoder)
	local result = decoder:Decode("I2")
	-- GameLogicTools.ShowErrorCode(19018, result)
	-- print("FriendProxy:On19018", result)

	if result == 0 then
		--关闭该玩家主页
		local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.FullScreenView)
	    if view and view:IsOpen() then
	        view:OnClickClose()
	    end

		GameLogicTools.ShowMsgTips("FriendView_1038")
	end
end

function FriendProxy:On19019(decoder)
	-- print("FriendProxy:On19019")

	RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.FriendApply, 1)
end

function FriendProxy:On19020(decoder)
	local guser = decoder:Decode("I8")
	-- print("FriendProxy:On19020", guser)
	
	for i,info in ipairs(self.data.friendInfo.friendLists) do
		if info.guser == guser then
			info.getLove = 1
			break
		end
	end

	self:UpdateRedPoint()
end

function FriendProxy:GetFriendInfoByGuser(guser)
	if self.data.friendInfo and self.data.friendInfo.friendLists then
		for i,info in ipairs(self.data.friendInfo.friendLists) do
			if info.guser == guser then
				return info
			end
		end
	end
end

--是否是好友
function FriendProxy:IsFriendByGuser(guser)
	local bfriend = false
	if self.data.friendInfo and self.data.friendInfo.friendLists then
		for i,info in ipairs(self.data.friendInfo.friendLists) do
			if info.guser == guser then
				bfriend = true 
				break
			end
		end
	end
	return bfriend
end

--好友申请红点
function FriendProxy:GetFriendApplyRedNum()
	local num = 0
	local applyInfos = self.data.applyInfos or {}
	num = #applyInfos
	return num
end

--好友模块红点
function FriendProxy:GetFriendRootRed()
	local num = 0
	num = num + self:GetFriendApplyRedNum()
	return num
end

function FriendProxy:GetLoveMax()
	return self.friendParama.getLove_max
end

function FriendProxy:GetIntimacyNum()
	return self.data.friendInfo.getIntimacyNum
end

function FriendProxy:UpdateRedDot()
	local MainProxy = require "Modules.Main.MainProxy"
	local MainDef = require "Modules.Main.MainDef"
	local count = self:GetFriendRootRed()
	MainProxy.Instance:UpdateRedDot(MainDef.MainRedDotType.Friend, count)
end

function FriendProxy:UpdateRedPoint()
	local canSend = false
	local canGet = false
	local redPointNum = 0

	for i,v in ipairs(self.data.friendInfo.friendLists) do
		if v.sendLove == 0 then --没有赠送爱心
			canSend = true
		end

		if v.getLove == 1 then --被赠送爱心
			canGet = true
		end
	end

	if canSend and (self.data.friendInfo.sendIntimacyNum < self.friendParama.sendLove_max) then
		redPointNum = 1
	elseif canGet and (self.data.friendInfo.getIntimacyNum < self.friendParama.getLove_max) then
		redPointNum = 1
	end

	-- print("FriendProxy:UpdateRedPoint", tostring(canSend), tostring(canGet), self.data.friendInfo.sendIntimacyNum, self.data.friendInfo.getIntimacyNum)

	RedPointProxy.Instance:SetNodeNum(RedPointDef.Id.FriendQuickSendGet, redPointNum)
end

function FriendProxy:SearchFriend(nickname, target_uin)

	-- print("FriendProxy:SearchFriend==========", nickname, target_uin)
    local t = {
        ["uin"] = RoleInfoModel.uid,
        ["nickname"] = nickname or "",
        ["target_uin"] = target_uin or 0,
    }

    local p = {
        ["api"] = "nickname",
        ["func"] = "Search",
        ["time"] = RoleInfoModel.servertime,
        ["params"] = t,
    }

    local params = {}
    params.token = LoginProxy.Instance:cms_encrypt(rapidjson.encode(p))

    local baseUrl = SystemConfig.Router
    local url = baseUrl .. LoginDef.api.gameapi
    httputil.post(url, params, function(text)
    	local info = rapidjson.decode(text)
    	self:OnSearchResult(info)
    end)


end

function FriendProxy:OnSearchResult(info)
	-- print("OnSearchResult============", table.dump(info))
	local code = info.code
	if code == 0 then
		local role_lists = {}
		local search_list = info.data
		for k,v in pairs(search_list) do
			-- if tonumber(v.uin) ~= RoleInfoModel.uid then
				table.insert(role_lists, {tonumber(v.zone), tonumber(v.part), tonumber(v.uin)})
			-- end
		end
		
		if #role_lists > 0 then
			self:Send19001(role_lists)
		end
	elseif code == 404 then
		GameLogicTools.ShowMsgTips("FriendView_1042")
	end
end

return FriendProxy