local HeroProxy = require "Modules.Hero.HeroProxy"
local UIEffectItem = require "Core.Implement.UI.Class.UIEffectItem"

local RelationItem = RelationItem or BaseClass(GameObjFactor)
function RelationItem:__init(go)
	self.go = go
	self:Load(go)
end

function RelationItem:Load(obj)
	self.backSp = self:GetChildComponent(obj, "CSprite_back", "CSprite")
	self.levelSpList = {}
	for i=1,5 do
		self.levelSpList[i] = self:GetChildComponent(obj, i, "CSprite")
	end
	self.effect_1 = UIEffectItem.New("UI_Battle_relation1", self.go)
	self.effect_2 = UIEffectItem.New("UI_Battle_relation2", self.go)
end

-- data: {herotypeid}
function RelationItem:SetData(data)
	self:InitData()

	self.relationlevel, self.speciallevel = HeroProxy.Instance:GetRelation(data)
	self.backSp.SpriteName = self.speciallevel > 0 and "jibandi_2" or "jibandi_1"
	if self.relationlevel == 1 then
		self.levelSpList[1].SpriteName = "jiban2_1"
		self.levelSpList[2].SpriteName = "jiban1_1"
		self.levelSpList[3].SpriteName = "jiban1_1"

		if self.speciallevel > 0 then
			for i=1, self.speciallevel do
				self.levelSpList[3 + i].SpriteName = "jiban3_2"
			end
		end	
	elseif self.relationlevel == 2 then
		self.levelSpList[1].SpriteName = "jiban2_1"
		self.levelSpList[2].SpriteName = "jiban1_1"
		self.levelSpList[3].SpriteName = "jiban1_1"
		self.levelSpList[4].SpriteName = "jiban3_3"
		self.levelSpList[5].SpriteName = "jiban3_3"

	elseif self.relationlevel == 3 then
		self.levelSpList[2].SpriteName = "jiban1_1"
		self.levelSpList[3].SpriteName = "jiban1_1"
		self.levelSpList[4].SpriteName = "jiban3_1"
		self.levelSpList[5].SpriteName = "jiban3_1"

		if self.speciallevel > 0 then
			self.levelSpList[1].SpriteName = "jiban2_2"
		end	

	elseif self.relationlevel == 4 then
		self.levelSpList[1].SpriteName = "jiban2_1"
		self.levelSpList[2].SpriteName = "jiban1_1"
		self.levelSpList[3].SpriteName = "jiban1_1"
		self.levelSpList[4].SpriteName = "jiban3_1"
		self.levelSpList[5].SpriteName = "jiban3_1"

	elseif self.speciallevel == 1 then
		self.levelSpList[1].SpriteName = "jiban2_2"

	elseif self.speciallevel == 2 then
		self.levelSpList[2].SpriteName = "jiban1_2"
		self.levelSpList[3].SpriteName = "jiban1_2"

	elseif self.speciallevel == 3 then
		self.levelSpList[1].SpriteName = "jiban2_2"
		self.levelSpList[2].SpriteName = "jiban1_2"
		self.levelSpList[3].SpriteName = "jiban1_2"

	elseif self.speciallevel == 4 then
		self.levelSpList[2].SpriteName = "jiban1_2"
		self.levelSpList[3].SpriteName = "jiban1_2"
		self.levelSpList[4].SpriteName = "jiban3_2"
		self.levelSpList[5].SpriteName = "jiban3_2"

	elseif self.speciallevel == 5 then
		self.levelSpList[1].SpriteName = "jiban2_2"	
		self.levelSpList[2].SpriteName = "jiban1_2"
		self.levelSpList[3].SpriteName = "jiban1_2"
		self.levelSpList[4].SpriteName = "jiban3_2"
		self.levelSpList[5].SpriteName = "jiban3_2"							
	end	
	self:ShowEffect(self.relationlevel, self.speciallevel)
end

function RelationItem:InitData()
	for idx, sprite in pairs(self.levelSpList) do
		if idx == 1 then
			sprite.SpriteName = ""
		else
			sprite.SpriteName = ""
		end	
	end
	self.backSp.SpriteName = "jibandi_0"
end

function RelationItem:ShowEffect(relationlevel, speciallevel)
	self.effect_1:Close()
	self.effect_2:Close()
	if relationlevel > 0 then
		if speciallevel > 0 then
			self.effect_2:Open()
		else
			self.effect_1:Open()
		end	
	end	
end

function RelationItem:Close()
	if self.effect_1 then
		self.effect_1:Close()
	end
	if self.effect_2 then
		self.effect_2:Close()
	end	
end

function RelationItem:Destroy()
	if self.effect_1 then
		self.effect_1:Destroy()
	end
	if self.effect_2 then
		self.effect_2:Destroy()
	end		
end

return RelationItem