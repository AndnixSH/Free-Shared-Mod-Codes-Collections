local tunpack = table.unpack

local function isobj(value)
    return value.uid and value.caller and value.type
end

trigger = {
    redirect = function (self, name)

        local bsuccess = false
        local obj = self.exeresult
        local scriptobj = self.scriptobj

        if obj and type(obj) == 'table' then
            if #obj > 0 then
                for _, value in ipairs(obj) do
                    if isobj(value) then
                        bsuccess = true
                        scriptobj:redirect(value, name)
                    end
                end
            elseif isobj(obj) then
                bsuccess = true
                scriptobj:redirect(obj, name)
            end
        end

        if not bsuccess then
            scriptobj:redirect(scriptobj.owner, name)
        end
    end,

    print = function(self, ...)
        print(...)
    end,

    timeprint = function (self, ...)
        local time = global.service.time
        print(string.format("f:%s t:%s lt:%s rt:%s", time.frame, time.tick, time.time, Time.time), ...)
    end,
}

metafunc.classify("trigger", trigger.redirect)
metafunc.classify("trigger", trigger.print)
metafunc.classify("trigger", trigger.timeprint)


local triggerbase = {}

function triggerbase:constructor(scriptobj, args, ...)
    self.scriptobj = scriptobj
    self.oldargs = args
    self.exeresult = nil
    self.cmdlist = {...}
end

function triggerbase:start()
    if type(self.oldargs) == 'function' then
        self.args = self.oldargs(self.scriptobj)
    else
        self.args = self.oldargs
    end
    if self.onstart then
        return self:onstart()
    end
    return true
end

function triggerbase:update(time, tick)
    if self.onupdate then
        local speed = self.scriptobj:getspeed() or 1000
        return self:onupdate(time, tsmath.nmul(tick, speed))
    end
    return false
end

function triggerbase:action()
    local cb = nil
    local fclass = nil
    local args = nil
    self.exeresult = nil
    
    for i = 1, #self.cmdlist do
        local element = self.cmdlist[i]
        if type(element) == 'function' then
            local class = metafunc.getclass(element)
            if class then
                self:_execute_func(fclass, cb, args)
                cb = element
                fclass = class
                args = {}
            else
                local ret = element(self.scriptobj)
                if ret then
                    table.insert(args, ret)
                end
            end
        else
            table.insert(args, element)
        end
    end
    self:_execute_func(fclass, cb, args)
end

function triggerbase:_execute_func(fclass, func, args)

    if not func then return end

    if fclass == 'caller' then
        self.exeresult = func(self.scriptobj:getowner(), tunpack(args))
    elseif fclass == 'trigger' then
        func(self, tunpack(args))
    elseif fclass == 'action' then
        self.exeresult = func(self.scriptobj.action, tunpack(args))
    else
        global.debug.error("error fclass", fclass)
    end

end

function triggerbase:stop()
    if self.onend then
        self:onend()
    end
    if self.cbend then
        self.cbend()
    end
    self.exeresult = nil
    self.scriptobj = nil
    self.cmdlist = nil
end


trigger.time = class(triggerbase)

function trigger.time:onstart()
    self.delay, self.interval, self.count = tunpack(self.args)
    self.delay = self.delay or 0
    self.interval = self.interval or 0
    if self.delay == 0 and self.interval == 0 then
        self:action()
        return false
    end
    self.curtime = 0
    self.curindex = 0
    return true
end

function trigger.time:onupdate(time, tick)
    self.curtime = self.curtime + tick
    if self.curtime >= self.delay then
        self:action()
        self.curindex = self.curindex + 1
        if self.interval == 0 or (self.count and self.curindex >= self.count) then
            return false
        else
            self.delay = self.curtime + self.interval
        end
    end
    return true
end

trigger.close_select = class(triggerbase)

function trigger.close_select:onstart()

    local owner = self.scriptobj.owner
    self._target = self.args.target or self.scriptobj.service.area:select(owner, self.scriptobj.static.range.target)

    if not self._target then
        self:action()
        return false
    end

    self._stopdis = self.args.stopdis + owner.body.radius + self._target.body.radius

    if self:close_enough() then
        self:action()
        return false
    else
        self.curtime = 0
        local dis = tsvector.distance(owner.body.position, self._target.body.position) - self._stopdis
        self.args.speed = self.args.speed or tsmath.ndiv(dis, self.args.duration)
        self.args.duration = self.args.duration or tsmath.ndiv(dis, self.args.speed)
        owner.caller.body:move(self.args.speed)
    end

    return true
end

function trigger.close_select:onupdate(time, tick)

    self.curtime = self.curtime + tick
    if self:close_enough() or (self.args.duration and self.curtime >= self.args.duration) then
        self:action()
        return false
    end

    local dir = (self._target.body.position - self.scriptobj.owner.body.position).normalized
    self.scriptobj.owner.body:setvelocity(dir:fmul(self.args.speed))

    return true
end

function trigger.close_select:close_enough()
    return tsvector.distance_less_equal(self.scriptobj.owner.body.position, self._target.body.position, self._stopdis)
end

-- 蓄力
trigger.charge = class(triggerbase)

function trigger.charge:onstart()
    self.slotid = self.args.slotid or self.scriptobj.action.info.slotid
    self.curtime = 0
    local duration = assert(self.args.duration)
    self.scriptobj.owner.caller.skill:setslotcharge(self.slotid, true)
    return true
end

function trigger.charge:onupdate(time, tick)
    self.curtime = self.curtime + tick
    local charging = self.scriptobj.owner.caller.skill:getslotcharge(self.slotid)
    if not charging then
        self:action()
        return false
    end
    if self.curtime >= self.args.duration then
        self.scriptobj.owner.caller.skill:setslotcharge(self.slotid, false)
    end
    return true
end