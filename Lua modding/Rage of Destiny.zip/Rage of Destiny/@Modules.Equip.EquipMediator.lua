local EquipMediator = EquipMediator or BaseClass(StdMediator)
local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"


function EquipMediator:OnEnterLoadingEnd()
	if SceneManager.Instance.sceneType == SceneDef.SceneType.Main then
		self:DelayExecute(function( ... )
			local EquipProxy = require "Modules.Equip.EquipProxy"
			EquipProxy.Instance:Send15109()
		end)
	end		
end

function EquipMediator:OnEnterScenceFirst()
end

return EquipMediator