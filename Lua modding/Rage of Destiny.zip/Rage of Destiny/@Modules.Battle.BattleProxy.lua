local BattleProto = require "Core.Implement.Net.BattleProto"
local SceneManager = require "Modules.Scene.SceneManager"
local SceneDef = require "Modules.Scene.SceneDef"
local BattleDef = require "Modules.Battle.BattleDef"
local CampaignProxy = require "Modules.Campaign.CampaignProxy"
local data_scene = ConfigManager.GetConfig("data_scene")
local data_enemy = ConfigManager.GetConfig("data_enemy")
local data_battle_key = ConfigManager.GetConfig("data_battle_key")
local md5 = require "First.Util.md5"
local libserial = require "Common.Util.libserial"

local BattleProxy = BattleProxy or BaseClass(BaseProxy, BattleProto)
function BattleProxy:__init(name)
    BattleProxy.Instance = self

    self:AddProto(50005, self.On50005) --进入战斗
    self:AddProto(50001, self.On50001) --战斗结算
    self:AddProto(50002, self.On50002) --战前准备
    self:AddProto(50003, self.On50003) --战报进入战斗
    self:AddProto(50004, self.On50004) --自动战斗战前准备

    self.data = {}
    self.playlist = {}
    self.heroinfos = {}
    self.battleResult_rewards = {}
    self.entryCallBack = nil
    self.data.battleReadySteps = {}
end

function BattleProxy:__delete()
    self:SetBattle_bStart(false)
    self.battleResult_rewards = nil
    self.data.battleReadySteps = nil
    self.data = nil
end

--proto
----开始战斗
function BattleProxy:Send50005(activityid, heroinfos, enemyinfos, bufferstr)
    local encoder = NetEncoder.New()
    encoder:Encode("I2", activityid)
    self:_EncodeHeroInfo(heroinfos, encoder)
    self:_EncodeEnemyInfo(enemyinfos, encoder)
    encoder:Encode("s2", bufferstr or "")

    self:SendMessage(50005, encoder)
end

function BattleProxy:On50005(decoder)
    local __bstart = self:GetBattle_bStart()
    if __bstart == true then
        return
    end
    -- self:ToNotify(self.data, BattleDef.NotifyDef.EnterGame, result)
    local result = decoder:Decode("I2")
    if result == 0 then
        self:SetBattle_bStart(true)
        self:UnJumpGame()
        self:CallStartBattle(decoder)
    else
        --1:不能同时上多个雇佣英雄 2英雄不能再次使用
        print(" ============  startbattle fail:code ", result)
    end
end

function BattleProxy:On50003(decoder, guser)
    local result = decoder:Decode("I2")
    if result == 0 then
        self:UnJumpGame()
        local framestr = decoder:Decode("s2")
		local fast_start = decoder:Decode("I1")
        local showOtherReport = true
        if guser and (guser == RoleInfoModel.guserid) then
            showOtherReport = false
        end
        local report = { framestr = framestr, showOtherReport = showOtherReport, fast_start = fast_start and (fast_start == 1) or false }
        self:CallStartBattle(decoder, { report = report })
    end
end

--自动战斗战前准备
function BattleProxy:On50004(decoder)
    self:CallAutoPreBattle(decoder)
end

-- 播放上次本地战斗
function BattleProxy:PlayLastLocalGame()
    if self.__local_game_data then
        local d = self.__local_game_data
        if (not d.battlearg.extra) or (not d.battlearg.extra.report) then
            local input_record = require "Battle.input.input_record"
            local report = { framestr = input_record.serialize() or "" }
            d.battlearg.extra = d.battlearg.extra or {}
            d.battlearg.extra.report = report
        end
        self:UnJumpGame()
        self:EntryBattleScene(d.activityid, d.battlearg, d.customarg)
    end
end

function BattleProxy:SaveLocalGame(activityid, battlearg, customarg)
    self.__local_game_data = { activityid = activityid, battlearg = battlearg, customarg = customarg }
end

function BattleProxy:IsPlayLocalGame()
    return not self:IsPlayOtherReportGame()
end

function BattleProxy:IsPlayOtherReportGame()
    if self:IsReportBattle() then
        local extra = self.__local_game_data and self.__local_game_data.battlearg and self.__local_game_data.battlearg.extra
        if extra and extra.report and extra.report.showOtherReport then
            return true
        end
    end
    return false
end

local battle_key = "ak77RKr@qld^&tfZ#MEQ"

--result 0胜 1负
function BattleProxy:Send50001(activityid, result, bufferstr)
    if activityid ~= ACTIVITYID.TRIAL then
        --试玩不需要结算
        bufferstr = bufferstr or ""
        local encoder = NetEncoder.New()
        local clipbuffstr = string.sub(bufferstr, 1, math.min(#bufferstr, 10))
        local sign = md5.sumhexa(tostring(result) .. battle_key .. clipbuffstr)
        encoder:Encode("I2I1s2s2s2", activityid, result, sign, bufferstr, self:_GetSettleStat())
        self:SendMessage(50001, encoder)
    end
end

-- 结算统计
function BattleProxy:_GetSettleStat()
    local spritelist = self:GetSpriteList(CAMP.RED)
    local results = {}
    for _, spriteid in ipairs(spritelist) do
        local sprite = self:GetSprite(spriteid)
        if sprite and sprite.prop and sprite.prop.sid and sprite.record then
            table.insert(results, { sprite.prop.sid, sprite.prop.stance or 0, sprite.record.castcnt or 0, sprite.record.maxdamage or 0 })
        end
    end
    local encoder = NetEncoder.New()
    encoder:EncodeList("I2I1I4I4", results)

    local game = require "Battle.game.game"
    local game_state = game.getstate()
    encoder:Encode("I4", game_state.current_frame)
    encoder:Encode("I4", math.floor(game_state.total_time))
    encoder:Encode("I1", game.getbmod() and 0 or 1)

    local token = 0
    local function calctoken(camp_list)
        for i, spriteid in ipairs(camp_list) do
            local sprite = global.service.pool:get_obj(spriteid)
            if sprite then
                if sprite.attr and sprite.attr.hp then
                    token = token + sprite.attr.hp
                    -- print('addhptoken', sprite, sprite.attr.hp, token)
                end
                if sprite.attr and sprite.attr.mp then
                    token = token + sprite.attr.mp
                    -- print('addmptoken', sprite, sprite.attr.mp, token)
                end
            end
        end
    end
    token = math.fmod(token, 4294967295)
    -- print('game_frame', global.service.time.frame)
    -- print('game_time', global.service.time.time)

    local camp1_list = global.service.area:getplayeruids(1)
    local camp2_list = global.service.area:getplayeruids(2)
    calctoken(camp1_list)
    calctoken(camp2_list)
    encoder:Encode("I4", token)

    return encoder.buffer or ""
end

function BattleProxy:On50001(decoder)
    local result, game_result = decoder:Decode("I1I1")
    self.battleResult_rewards = {}
    if result == 0 then
        self:SetBattle_bStart(false)
        local rewards = decoder:DecodeList("I4I4", true)
        self.battleResult_rewards = rewards
        local buffer_str = decoder:Decode("s2")
        self:OnSettleGame(game_result, rewards, buffer_str)
    else
        print("*************************结算验证失败*************************")
        self:OnSettleGame(1, {}, "")
    end
end

function BattleProxy:GetBattleRewards()
    return self.battleResult_rewards
end

--战前准备
function BattleProxy:On50002(decoder)
    print("BattleProxy:On50002")
    self:CallPreBattle(decoder)
end

function BattleProxy:OnSettleGame(result, rewards, buffer_str)
    local settleGameData = { result = result, rewards = rewards, buffer_str = buffer_str }
    self:ToNotify(self.data, BattleDef.NotifyDef.SettleGame, settleGameData)
end

-- 战斗操作相关
function BattleProxy:EntryBattleScene(activityid, battlearg, customarg)
    self:SetBattleActivityId(activityid)
    self.playlist = battlearg.playerlist
    SceneManager.Instance:EnterScene(activityid, battlearg, customarg)
end

function BattleProxy:EntryBattleScene_2(activityid, playlist, seed, ...)
    self:SetBattleActivityId(activityid)
    self.playlist = playlist
    SceneManager.Instance:EnterScene(activityid, { playerlist = playlist, seed = seed }, ...)
end

function BattleProxy:EscGame()
    self:SetBattle_bStart(false)
	self:SetIsReport(false)
    self.playlist = nil

    local ScreenShotter = require "Common.Util.ScreenShotter"
    ScreenShotter.Capture(function()
        SceneManager.Instance:CleanCurScene()
        self.__local_game_data = nil
    end)
end

--是否需要弹 stopInfoObj
function BattleProxy:StopGame(bShow)
    -- if not self.bstop then
    self:SetBattle_bStart(false)
    bShow = (bShow == nil) and true or bShow
    self.bstop = true

    local game_input = require "Battle.input.game_input"
    local operation = game_input.operation
    operation.pause()

    self:ToNotify(self.data, BattleDef.NotifyDef.StopGame, { bShow = bShow })
    if SceneManager.Instance:GetCurSceneType() == SceneDef.SceneType.Main then
        -- SceneManager.Instance:SetCurSceneActive(false)
        -- local render_area = require "Battle.render.render_area"
        -- render_area.setmodelactive(false)
        -- render_area.hide()
    end
    -- end
end

function BattleProxy:PauseGame()
    local game_input = require "Battle.input.game_input"
    local operation = game_input.operation
    operation.pause()
end

function BattleProxy:ContinusGame()
    -- if self.bstop then
    self.bstop = false
    local game_input = require "Battle.input.game_input"
    local operation = game_input.operation
    operation.resume()

    if SceneManager.Instance:GetCurSceneType() == SceneDef.SceneType.Main then
        -- SceneManager.Instance:SetCurSceneActive(true)
        -- local render_area = require "Battle.render.render_area"
        -- render_area.setmodelactive(true)
        -- render_area.show()
    end
    -- end
end

function BattleProxy:IsStop()
    return self.bstop
end

function BattleProxy:RestartGame(args)
    self:SetBattle_bStart(false)
    self:ToNotify(self.data, BattleDef.NotifyDef.RestartGame, args)
end

function BattleProxy:AutoGame(bauto)
    if not self:IsReportBattle() then
        local game_input = require "Battle.input.game_input"
        local operation = game_input.operation
        operation.auto(bauto)
    end
end

function BattleProxy:SpeedGame(speed)
    self.battleSpeed = speed
    local game_input = require "Battle.input.game_input"
    local operation = game_input.operation
    operation.speed(speed)
end

function BattleProxy:GetGameSpeed()
    return self.battleSpeed
end

function BattleProxy:JumpGame()
    self.bjump = true
    local game_input = require "Battle.input.game_input"
    local operation = game_input.operation
    operation.jump()
end

--是否战报播放战斗
function BattleProxy:BattleReport(breport)
    self.breport = breport
    self:ToNotify(self.data, BattleDef.NotifyDef.BattleReport)
end

function BattleProxy:SetIsReport(breport)
    self.breport = breport
end

function BattleProxy:IsReportBattle()
    local breport = self.breport or false
    return breport
end

-- 根据场景id和敌人id获取config_key
function BattleProxy:GetConfigKey(sceneid, enemyid)
    local scenecnf, enemyconf = data_scene[sceneid], data_enemy[enemyid]
    local battle_key = nil
    if scenecnf then
        if not enemyconf or not enemyconf.boss.coordinate then
            battle_key = scenecnf.battle_key
        else
            battle_key = scenecnf.battle_key_boss
        end
    end
    if not battle_key then
        print("找不到合适的config_key", sceneid, enemyid)
    elseif not data_battle_key[battle_key] then
        print("data_battle_key找不到配置", battle_key)
    end
    return battle_key
end

function BattleProxy:UnJumpGame()
    self.bjump = false
end

function BattleProxy:IsJump()
    return self.bjump
end

function BattleProxy:IsInBattle()
    return self.binbattle
end

function BattleProxy:SetInBattle(inbattle)
    self.binbattle = inbattle
end

function BattleProxy:SetBattleActivityId(activityid)
    self.data.activity_id = activityid
end

function BattleProxy:GetBattleActivityId()
    return self.data.activity_id
end

function BattleProxy:SetBattle_bStart(bStart)
    self.__bstart = bStart
end

function BattleProxy:GetBattle_bStart()
    return self.__bstart
end

function BattleProxy:IsInMainlineBattle()
    return self:GetBattleActivityId() == ACTIVITYID.MAINLINE
end

function BattleProxy:IsInTowerBattle()
    return self:GetBattleActivityId() == ACTIVITYID.TOWER
end

--skill
function BattleProxy:UserSkill(spriteid)
    local game_input = require "Battle.input.game_input"
    local operation = game_input.operation
    operation.use_skill(spriteid, SKILL.SLOT.ULTIMATE)
end

function BattleProxy:UserSkillSuccess(spriteid)
    self:ToNotify(self.data, BattleDef.NotifyDef.UserSkill, spriteid)
end

--sprite
function BattleProxy:GetSprite(spriteid)
    return global.service.readonly:reader(spriteid)
end

function BattleProxy:GetSpriteList(camp)
    local spritelist = global.service.area:getplayeruids(camp)
    return spritelist
end

function BattleProxy:GetSpriteData(tab, camp)
    local spritelist = self:GetSpriteList(camp)
    for _, spriteid in ipairs(spritelist) do
        local spriteobj = self:GetSprite(spriteid)
        if spriteobj and (spriteobj.body.spritetype == SPRITE_TYPE.PLAYER or (spriteobj.body.spritetype == SPRITE_TYPE.MONSTER and spriteobj.static.type == MONSTER_TYPE.BOSS)) then
            local settledata = {
                roleid = spriteobj.static.id,
                level = spriteobj.attr.level,
                rank = spriteobj.prop.rank_level or spriteobj.prop.rank,
                stance = spriteobj.prop.stance or 0,
                damage = spriteobj.record.damage or 0,
                bharm = spriteobj.record.bharm or 0,
                heal = spriteobj.record.heal or 0,
                dead = spriteobj.attr.hp == 0,
                record = spriteobj.record
            }
            table.insert(tab, settledata)
        end
    end
end

function BattleProxy:GetSettleData()
    local datas = { {}, {} }
    self:GetSpriteData(datas[1], CAMP.RED)
    self:GetSpriteData(datas[2], CAMP.BLUE)
    return datas
end

--英雄唯一id, 英雄配置id, 阵营, 等级, 品质, 站位
--equips({{goods_type_id, goods_grade},...}) hire_hero_type 1:普通英雄 2：雇佣英雄  hire_nickname：雇佣所有者昵称
function BattleProxy:GetGamePlayerTable(heroid, roleid, camp, level, rank, stance, position, attrchange, equips, hire_hero_type, hire_nickname, fromuid, tree_info, activityid, total_attr, fight, server_skill_list, server_equip_buff_list, server_tree_buff_list, relation_add_attr)
    if camp == 1 and AppConfig.ISALONE then
        -- level = 240
    end
	
	if self:IsReportBattle() then
		total_attr = nil
		fight = nil
		server_skill_list = nil
		server_equip_buff_list = nil
		server_tree_buff_list = nil
	end
	
    local HeroProxy = require "Modules.Hero.HeroProxy"

    local heroCfg = HeroProxy.Instance:GetRoleCfgByConfigId(roleid)
    if not heroCfg then
        return nil
    end

    local tab = {}
    tab.heroid = heroid
    tab.roleid = roleid
    tab.position = position

    --prop
    local prop = {}
    prop.camp = camp
    prop.stance = stance
    prop.sid = heroid
    prop.hire_hero_type = hire_hero_type or BattleDef.Hire_Hero_Type.Normal
    prop.hire_nickname = hire_nickname or ""
    prop.rank = rank
    prop.roleid = roleid
    prop.fromuid = fromuid or heroid
    tab.prop = prop

    --skill
    local skill_list = {}
    local skilllist = HeroProxy.Instance:GetSkillidList(roleid)
    for idx, skillid in ipairs(skilllist) do
        local skillcfg, skilllevel = HeroProxy.Instance:GetCurSkill(skillid, level)
        if skilllevel then
            skill_list[idx] = skillcfg.id
        else
            skill_list[idx] = 0
        end
    end
	if server_skill_list then
		local diff_skill = false
		local diff_skill_list = {}
		for i,skill_id in ipairs(server_skill_list) do
			if skill_id ~= skill_list[i] then
				diff_skill = true
				table.insert(diff_skill_list, {server_skill = skill_id, client_skill = skill_list[i]})
			end
		end
		
		for i = #server_skill_list + 1, #skill_list do
			diff_skill = true
			table.insert(diff_skill_list, {server_skill = 0, client_skill = skill_list[i]})
		end
		
		if diff_skill and (not self:IsReportBattle()) then
			--print("服务端技能列表:", table.dump(server_skill_list))
			--print("客户端技能列表:", table.dump(skill_list))
			--print("前后端技能列表不一致:", table.dump(diff_skill_list))
		end
	end
    tab.prop.skill_list = server_skill_list or skill_list

    --buff
    local EquipProxy = require "Modules.Equip.EquipProxy"
    -- local bufflist = EquipProxy.Instance:GetEquipBuffList(heroid)
    local equip_buff_list = EquipProxy.Instance:GetEquipBuffListByEquips(equips or {})
    tab.prop.buff_list = server_equip_buff_list or equip_buff_list

    local TreeProxy = require "Modules.Tree.TreeProxy"
    local tree_buff_list = TreeProxy.Instance:GetTreeBuffList(roleid, heroid, tree_info and tree_info[2])
	
	tree_buff_list = server_tree_buff_list or tree_buff_list
    for _, buff_id in ipairs(tree_buff_list) do
        table.insert(tab.prop.buff_list, buff_id)
    end

    --attr
	local client_attr = HeroProxy.Instance:GetHeroAttr(roleid, rank, level, prop.fromuid > 0 and prop.fromuid or nil, equips, nil, tree_info, activityid, relation_add_attr)
	tab.attr = total_attr and table.deepcopy(total_attr) or client_attr
	tab.attr.hp = math.max(tab.attr.hp_max or 0, tab.attr.hp or 0)
	local client_fight = HeroProxy.Instance:GetAttrFight(tab.attr)
	tab.attr.fight = fight or client_fight

	local effect_client_attr = {}
	local diff_attr = {}
	local has_diff = false
	for k,v in pairs(client_attr) do
		if CONST.ATTR_NAME[k] then
			if (v > 0) then
				effect_client_attr[k] = v
			end
			
			if total_attr and total_attr[k] then
				local server_v = total_attr[k] or 0
				local diff = server_v - v
				if diff ~= 0 then
					has_diff = true
					diff_attr[k] = {server_attr = server_v, client_attr = v, diff = diff}
				end
			else
				if (v > 0) then
					diff_attr[k] = {server_attr = 0, client_attr = v, diff = -v}
				end
			end
		end
	end
	
	if total_attr then
		for k,v in pairs(total_attr) do
			if not client_attr[k] then
				has_diff = true
				diff_attr[k] = {server_attr = v, client_attr = 0, diff = v}
			end
		end
	end
	
	if total_attr and (not self:IsReportBattle()) then
		--print("服务端计算战斗属性:", "hero_uid", heroid, "role_id", roleid, "stance", stance, "camp", camp, table.dump(total_attr))
		
		if (not self:IsArenaBattle(activityid)) then
			--print("客户端计算战斗属性:", "hero_uid", heroid, "role_id", roleid, "stance", stance, "camp", camp, table.dump(effect_client_attr))
			if has_diff then
				--print("前后端战斗属性不一致:","hero_uid", heroid, "role_id", roleid, "stance", stance, table.dump(diff_attr))
			--else
				--print("前后端属性相同")
			end
		end
	end
	
    if attrchange then
        for _, proptable in ipairs(attrchange) do
            local propid, propvalue = table.unpack(proptable)
            local attrname = CONST.ATTR[propid]
            if not self:IsReportBattle() then
                if self:CheckIsSandScene() then
                    if attrname == "hp" then
                        tab.attr.hp = math.floor(propvalue / 1000 * tab.attr.hp_max)
                    elseif attrname == "mp" then
                        tab.attr.mp = math.floor(propvalue / 1000 * tab.attr.mp_max)
                    end
                else
                    tab.attr[attrname] = propvalue
                end
            else
                -- 战报特殊处理 直接用战报存储的属性值
                tab.attr[attrname] = propvalue
            end
        end
        if not self:IsReportBattle() then
            if not self:CheckIsSandScene() then
                tab.attr.hp = tab.attr.hp_max
                tab.attr.fight = fight or HeroProxy.Instance:GetAttrFight(tab.attr)
            end
        else
            tab.attr.hp = tab.attr.hp_max
            tab.attr.fight = HeroProxy.Instance:GetAttrFight(tab.attr)
        end

    end
    --print_player_info({heroid = heroid, roleid = roleid, level = level, rank = rank, equips = equips or {}, fight = tab.attr.fight })
    return tab
end

function BattleProxy:CheckIsSandScene()
    if self.data.activity_id == ACTIVITYID.ACTIVITY or
    self.data.activity_id == ACTIVITYID.STORYLINE or
    self.data.activity_id == ACTIVITYID.MAZE then
        return true
    else
        return false
    end
end

function BattleProxy:IsArenaBattle(activity_id)
	return (activity_id == ACTIVITYID.HIGHARENA) or (activity_id == ACTIVITYID.ARENA)
end

--end
--gamelogic
function BattleProxy:GetPlayerList()
    return self.playlist
end

function BattleProxy:GetDefaultTeam(battletype, args)
    local SettingProxy = require "Modules.Setting.SettingProxy"
    local SettingDef = require "Modules.Setting.SettingDef"
    --local HeroProxy = require "Modules.Hero.HeroProxy"
    local defaultTeam = ""
    if battletype == ACTIVITYID.MAINLINE then
        local enemyid, mainlineid = args and args[1], args and args[2]

        local index = CampaignProxy.Instance:GetEnemyIndex(mainlineid, enemyid)
        if index and (index > 1) then
            defaultTeam = SettingProxy.Instance:GetSettingInfo(SettingDef.Camp_Setting.MainLine .. "_" .. tostring(index))
        else
            defaultTeam = SettingProxy.Instance:GetSettingInfo(SettingDef.Camp_Setting.MainLine)
        end
    elseif battletype == ACTIVITYID.HANGUP then
        defaultTeam = SettingProxy.Instance:GetSettingInfo(SettingDef.Camp_Setting.HangUp)
    elseif battletype == ACTIVITYID.TOWER then
        -- local towertype = args[1]
        local TowerProxy = require "Modules.Tower.TowerProxy"
        local towerCfg = TowerProxy.Instance:GetTowerCfgById(args[2])
        local towertype = towerCfg.type
        defaultTeam = SettingProxy.Instance:GetSettingInfo(SettingDef.Camp_Setting.Tower, { towertype = towertype })
    elseif battletype == ACTIVITYID.MAZE then
        defaultTeam = SettingProxy.Instance:GetSettingInfo(SettingDef.Camp_Setting.Maze)
    elseif battletype == ACTIVITYID.STORYLINE then
        defaultTeam = SettingProxy.Instance:GetSettingInfo(SettingDef.Camp_Setting.STORYLINE)
    elseif battletype == ACTIVITYID.ARENA then
        defaultTeam = SettingProxy.Instance:GetSettingInfo(SettingDef.Camp_Setting.Arena)
    elseif battletype == ACTIVITYID.HIGHARENA then
        defaultTeam = SettingProxy.Instance:GetSettingInfo(SettingDef.Camp_Setting.HighArena)
    elseif battletype == ACTIVITYID.GUILD_BOSS then
        defaultTeam = SettingProxy.Instance:GetSettingInfo(SettingDef.Camp_Setting.GuildBoss)
    elseif battletype == ACTIVITYID.SUPPLY_DEPOT then
        defaultTeam = SettingProxy.Instance:GetSettingInfo(SettingDef.Camp_Setting.SupplyDepot)
    elseif battletype == ACTIVITYID.ACTIVITY then
        defaultTeam = SettingProxy.Instance:GetSettingInfo(SettingDef.Camp_Setting.ACTIVITY)
    elseif battletype == ACTIVITYID.GUILD_CHAOS then
        defaultTeam = SettingProxy.Instance:GetSettingInfo(SettingDef.Camp_Setting.GuildChaos, { bossId = args[1] })
    end

    if not defaultTeam or defaultTeam == "" then
        return { 0, 0, 0, 0, 0 }
    else
        defaultTeam = string.split(defaultTeam, "_")
        local list = {}
        for _, str in ipairs(defaultTeam) do
            local id = tonumber(str)
            table.insert(list, id or 0)
        end
        return list
    end
end

function BattleProxy:SetDefaultTeam(battletype, herolist, args)
    local SettingProxy = require "Modules.Setting.SettingProxy"
    local SettingDef = require "Modules.Setting.SettingDef"
    local str = ""
    for idx, heroid in ipairs(herolist) do
        if idx == 1 then
            str = heroid
        else
            str = string.format("%s_%s", str, heroid)
        end
    end

    if battletype == ACTIVITYID.MAINLINE then
        local enemyid, mainlineid = args and args[1], args and args[2]
        local index = CampaignProxy.Instance:GetEnemyIndex(mainlineid, enemyid)
        if index and (index > 1) then
            SettingProxy.Instance:SetSettingInfo(SettingDef.Camp_Setting.MainLine .. "_" .. tostring(index), str)
        else
            SettingProxy.Instance:SetSettingInfo(SettingDef.Camp_Setting.MainLine, str)
            self:SetDefaultTeam(ACTIVITYID.HANGUP, herolist, args)
        end
    elseif battletype == ACTIVITYID.HANGUP then
        SettingProxy.Instance:SetSettingInfo(SettingDef.Camp_Setting.HangUp, str)
        self:SetHangUpHeroDetail(herolist)
    elseif battletype == ACTIVITYID.TOWER then
        -- local towertype = args[1]
        local TowerProxy = require "Modules.Tower.TowerProxy"
        local towerCfg = TowerProxy.Instance:GetTowerCfgById(args[2])
        local towertype = towerCfg.type
        SettingProxy.Instance:SetSettingInfo(SettingDef.Camp_Setting.Tower .. towertype, str)
    elseif battletype == ACTIVITYID.MAZE then
        SettingProxy.Instance:SetSettingInfo(SettingDef.Camp_Setting.Maze, str)
    elseif battletype == ACTIVITYID.STORYLINE then
        SettingProxy.Instance:SetSettingInfo(SettingDef.Camp_Setting.STORYLINE, str)
    elseif battletype == ACTIVITYID.ARENA then
        SettingProxy.Instance:SetSettingInfo(SettingDef.Camp_Setting.Arena, str)
    elseif battletype == ACTIVITYID.HIGHARENA then
        SettingProxy.Instance:SetSettingInfo(SettingDef.Camp_Setting.HighArena, str)
    elseif battletype == ACTIVITYID.GUILD_BOSS then
        SettingProxy.Instance:SetSettingInfo(SettingDef.Camp_Setting.GuildBoss, str)
    elseif battletype == ACTIVITYID.SUPPLY_DEPOT then
        SettingProxy.Instance:SetSettingInfo(SettingDef.Camp_Setting.SupplyDepot, str)
    elseif battletype == ACTIVITYID.ACTIVITY then
        SettingProxy.Instance:SetSettingInfo(SettingDef.Camp_Setting.ACTIVITY, str)
    elseif battletype == ACTIVITYID.GUILD_CHAOS then
        local bossId = args[1]
        SettingProxy.Instance:SetSettingInfo(SettingDef.Camp_Setting.GuildChaos .. bossId, str)
    end
end

function BattleProxy:SetHangUpHeroDetail(herolist)
    local HeroProxy = require "Modules.Hero.HeroProxy"
    local SettingProxy = require "Modules.Setting.SettingProxy"
    local SettingDef = require "Modules.Setting.SettingDef"

    local list = {}
    for _, heroid in ipairs(herolist) do
        local herodata = HeroProxy.Instance:GetHeroDataByUid(heroid)
        if herodata then
            local BagProxy = require "Modules.Bag.BagProxy"
            local equips = herodata.equips
            local new_equips = {}
            if equips then
                for p, equip in pairs(equips) do
                    local bag_equip = BagProxy.Instance:GetItemByID(equip[2])
                    if bag_equip then
                        table.insert(new_equips, { bag_equip.goodsTypeId, equip[1] })
                    end
                end
            end
            herodata.hangup_equips = new_equips
            table.insert(list, herodata)
        else
            table.insert(list, {})
        end
    end

    local str = libserial.serialize(list)
    SettingProxy.Instance:SetSettingInfo(SettingDef.Camp_Setting.HangUp_HeroDetail, str)
end

--isEnemy:是否为敌方
function BattleProxy:GetHeroLv(heroItem, activityId, isEnemy)
    local lv

    if activityId == ACTIVITYID.GUILD_CHAOS then
        local GuildProxy = require "Modules.Guild.GuildProxy"
        lv = GuildProxy.Instance:GetChaosRoomLv(isEnemy)
    else
        lv = heroItem.crystalLevel or heroItem.level
    end

    return lv
end
-------------------------------转菊花 start--------------------------------
--loadingType 转菊花类型 0:BattleReadyView  1:NetworkReconnectView
function BattleProxy:BattleReadySetStep(activityid, step, loadingType)
    loadingType = loadingType or 0
    self.data.battleReadySteps[activityid] = { step, loadingType }
    if self.data.battleReadySteps[activityid][1] > 0 then
        LuaLayout.Instance:OpenWidget(UIWidgetNameDef.NetworkDelayView)
    end
    -- print("BattleReadySetStep====", self.data.battleReadySteps[activityid])
end

--parama.activityid
--parama.heroinfos
--parama.enemyinfos
--parama.panelstr
--parama.args
--parama 为空，不需要打开BattleReadyView（比如爬塔种族塔每天上限10层了，无法战斗，只需要关闭转菊花即可）
function BattleProxy:BattleReadyNextStep(activityid, step, parama)
    if self.data.battleReadySteps[activityid] then
        self.data.battleReadySteps[activityid][1] = self.data.battleReadySteps[activityid][1] - step
    else
        self.data.battleReadySteps[activityid] = { 0, 0 }
    end
    -- print("BattleReadyNextStep====", self.data.battleReadySteps[activityid])
    if self.data.battleReadySteps[activityid][1] <= 0 then
        LuaLayout.Instance:CloseWidget(UIWidgetNameDef.NetworkDelayView)
        if parama then
            local readyview = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleReadyView)
            readyview.callback = function()
                local view = LuaLayout.Instance:GetWidget(UIWidgetNameDef.BattleNetSelectView)
                view.activityid = parama.activityid
                view.heroinfos = parama.heroinfos
                view.enemyinfos = parama.enemyinfos
                view.panelstr = parama.panelstr
                view.args = parama.args
                view:OpenView()
            end
            readyview:OpenView()
        end
    end
end
-------------------------------转菊花 end--------------------------------
return BattleProxy