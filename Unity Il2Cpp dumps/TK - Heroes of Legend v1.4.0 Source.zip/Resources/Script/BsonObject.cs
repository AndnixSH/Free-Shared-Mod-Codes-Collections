using UnityEngine;

namespace Newtonsoft.Json.Bson
{
    internal class BsonObject : BsonToken, IEnumerable<Newtonsoft.Json.Bson.BsonProperty>, IEnumerable
    {
        // Fields
        private readonly System.Collections.Generic.List<Newtonsoft.Json.Bson.BsonProperty> _children; //  0x00000020
        
        // Properties
        public override Newtonsoft.Json.Bson.BsonType Type { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AD1BDC (11344860), len: 112  VirtAddr: 0x00AD1BDC RVA: 0x00AD1BDC token: 100684766 methodIndex: 47371 delegateWrapperIndex: 0 methodInvoker: 0
        public BsonObject()
        {
            //
            // Disasemble & Code
            // 0x00AD1BDC: STP x20, x19, [sp, #-0x20]! | stack[1152921513722433072] = ???;  stack[1152921513722433080] = ???;  //  dest_result_addr=1152921513722433072 |  dest_result_addr=1152921513722433080
            // 0x00AD1BE0: STP x29, x30, [sp, #0x10]  | stack[1152921513722433088] = ???;  stack[1152921513722433096] = ???;  //  dest_result_addr=1152921513722433088 |  dest_result_addr=1152921513722433096
            // 0x00AD1BE4: ADD x29, sp, #0x10         | X29 = (1152921513722433072 + 16) = 1152921513722433088 (0x100000021F54CE40);
            // 0x00AD1BE8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AD1BEC: LDRB w8, [x20, #0x4cb]     | W8 = (bool)static_value_037334CB;       
            // 0x00AD1BF0: MOV x19, x0                | X19 = 1152921513722445104 (0x100000021F54FD30);//ML01
            // 0x00AD1BF4: TBNZ w8, #0, #0xad1c10     | if (static_value_037334CB == true) goto label_0;
            // 0x00AD1BF8: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
            // 0x00AD1BFC: LDR x8, [x8, #0x3f0]       | X8 = 0x2B8F978;                         
            // 0x00AD1C00: LDR w0, [x8]               | W0 = 0x1522;                            
            // 0x00AD1C04: BL #0x2782188              | X0 = sub_2782188( ?? 0x1522, ????);     
            // 0x00AD1C08: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD1C0C: STRB w8, [x20, #0x4cb]     | static_value_037334CB = true;            //  dest_result_addr=57881803
            label_0:
            // 0x00AD1C10: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
            // 0x00AD1C14: LDR x8, [x8, #0xd8]        | X8 = 1152921504616644608;               
            // 0x00AD1C18: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<Newtonsoft.Json.Bson.BsonProperty> val_1 = null;
            // 0x00AD1C1C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00AD1C20: ADRP x8, #0x365c000        | X8 = 56999936 (0x365C000);              
            // 0x00AD1C24: LDR x8, [x8, #0xa30]       | X8 = 1152921513722420080;               
            // 0x00AD1C28: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AD1C2C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<Newtonsoft.Json.Bson.BsonProperty>::.ctor();
            // 0x00AD1C30: BL #0x25e9474              | .ctor();                                
            val_1 = new System.Collections.Generic.List<Newtonsoft.Json.Bson.BsonProperty>();
            // 0x00AD1C34: STR x20, [x19, #0x20]      | this._children = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513722445136
            this._children = val_1;
            // 0x00AD1C38: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD1C3C: MOV x0, x19                | X0 = 1152921513722445104 (0x100000021F54FD30);//ML01
            object val_2 = this;
            // 0x00AD1C40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD1C44: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD1C48: B #0x16f59f0               | this..ctor(); return;                   
            val_2 = new System.Object();
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1C4C (11344972), len: 240  VirtAddr: 0x00AD1C4C RVA: 0x00AD1C4C token: 100684767 methodIndex: 47372 delegateWrapperIndex: 0 methodInvoker: 0
        public void Add(string name, Newtonsoft.Json.Bson.BsonToken token)
        {
            //
            // Disasemble & Code
            // 0x00AD1C4C: STP x24, x23, [sp, #-0x40]! | stack[1152921513722558352] = ???;  stack[1152921513722558360] = ???;  //  dest_result_addr=1152921513722558352 |  dest_result_addr=1152921513722558360
            // 0x00AD1C50: STP x22, x21, [sp, #0x10]  | stack[1152921513722558368] = ???;  stack[1152921513722558376] = ???;  //  dest_result_addr=1152921513722558368 |  dest_result_addr=1152921513722558376
            // 0x00AD1C54: STP x20, x19, [sp, #0x20]  | stack[1152921513722558384] = ???;  stack[1152921513722558392] = ???;  //  dest_result_addr=1152921513722558384 |  dest_result_addr=1152921513722558392
            // 0x00AD1C58: STP x29, x30, [sp, #0x30]  | stack[1152921513722558400] = ???;  stack[1152921513722558408] = ???;  //  dest_result_addr=1152921513722558400 |  dest_result_addr=1152921513722558408
            // 0x00AD1C5C: ADD x29, sp, #0x30         | X29 = (1152921513722558352 + 48) = 1152921513722558400 (0x100000021F56B7C0);
            // 0x00AD1C60: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD1C64: LDRB w8, [x21, #0x4cc]     | W8 = (bool)static_value_037334CC;       
            // 0x00AD1C68: MOV x19, x2                | X19 = token;//m1                        
            // 0x00AD1C6C: MOV x23, x1                | X23 = name;//m1                         
            // 0x00AD1C70: MOV x20, x0                | X20 = 1152921513722570416 (0x100000021F56E6B0);//ML01
            // 0x00AD1C74: TBNZ w8, #0, #0xad1c90     | if (static_value_037334CC == true) goto label_0;
            // 0x00AD1C78: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
            // 0x00AD1C7C: LDR x8, [x8, #0x2a8]       | X8 = 0x2B8F97C;                         
            // 0x00AD1C80: LDR w0, [x8]               | W0 = 0x1523;                            
            // 0x00AD1C84: BL #0x2782188              | X0 = sub_2782188( ?? 0x1523, ????);     
            // 0x00AD1C88: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD1C8C: STRB w8, [x21, #0x4cc]     | static_value_037334CC = true;            //  dest_result_addr=57881804
            label_0:
            // 0x00AD1C90: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
            // 0x00AD1C94: LDR x21, [x20, #0x20]      | X21 = this._children; //P2              
            // 0x00AD1C98: LDR x8, [x8, #0xbf8]       | X8 = 1152921504858017792;               
            // 0x00AD1C9C: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Bson.BsonProperty);
            object val_1 = null;
            // 0x00AD1CA0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Bson.BsonProperty), ????);
            // 0x00AD1CA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD1CA8: MOV x22, x0                | X22 = 1152921504858017792 (0x100000000EF89000);//ML01
            // 0x00AD1CAC: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x00AD1CB0: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x00AD1CB4: LDR x8, [x8, #0x188]       | X8 = 1152921504857911296;               
            // 0x00AD1CB8: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Bson.BsonString);
            object val_2 = null;
            // 0x00AD1CBC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Bson.BsonString), ????);
            // 0x00AD1CC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD1CC4: MOV x24, x0                | X24 = 1152921504857911296 (0x100000000EF6F000);//ML01
            // 0x00AD1CC8: BL #0x16f59f0              | .ctor();                                
            val_2 = new System.Object();
            // 0x00AD1CCC: ORR w8, wzr, #2            | W8 = 2(0x2);                            
            // 0x00AD1CD0: STR x23, [x24, #0x20]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_20 = name;  //  dest_result_addr=1152921504857911328
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_20 = name;
            // 0x00AD1CD4: STRB w8, [x24, #0x28]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_28 = 0x2;  //  dest_result_addr=1152921504857911336
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_28 = 2;
            // 0x00AD1CD8: STRB wzr, [x24, #0x30]     | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_30 = 0x0;  //  dest_result_addr=1152921504857911344
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_30 = 0;
            // 0x00AD1CDC: CBZ x22, #0xad1ce8         | if ( == 0) goto label_1;                
            if(null == 0)
            {
                goto label_1;
            }
            // 0x00AD1CE0: STR x24, [x22, #0x10]      | typeof(Newtonsoft.Json.Bson.BsonProperty).__il2cppRuntimeField_10 = typeof(Newtonsoft.Json.Bson.BsonString);  //  dest_result_addr=1152921504858017808
            typeof(Newtonsoft.Json.Bson.BsonProperty).__il2cppRuntimeField_10 = val_2;
            // 0x00AD1CE4: B #0xad1cf8                |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x00AD1CE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x00AD1CEC: ORR w8, wzr, #0x10         | W8 = 16(0x10);                          
            // 0x00AD1CF0: STR x24, [x8]              | mem[16] = typeof(Newtonsoft.Json.Bson.BsonString);  //  dest_result_addr=16
            mem[16] = val_2;
            // 0x00AD1CF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_2:
            // 0x00AD1CF8: STR x19, [x22, #0x18]      | typeof(Newtonsoft.Json.Bson.BsonProperty).__il2cppRuntimeField_18 = token;  //  dest_result_addr=1152921504858017816
            typeof(Newtonsoft.Json.Bson.BsonProperty).__il2cppRuntimeField_18 = token;
            // 0x00AD1CFC: CBNZ x21, #0xad1d04        | if (this._children != null) goto label_3;
            if(this._children != null)
            {
                goto label_3;
            }
            // 0x00AD1D00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_3:
            // 0x00AD1D04: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
            // 0x00AD1D08: LDR x8, [x8, #0x3e8]       | X8 = 1152921513722545392;               
            // 0x00AD1D0C: MOV x0, x21                | X0 = this._children;//m1                
            // 0x00AD1D10: MOV x1, x22                | X1 = 1152921504858017792 (0x100000000EF89000);//ML01
            // 0x00AD1D14: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Newtonsoft.Json.Bson.BsonProperty>::Add(Newtonsoft.Json.Bson.BsonProperty item);
            // 0x00AD1D18: BL #0x25ea480              | this._children.Add(item:  val_1);       
            this._children.Add(item:  val_1);
            // 0x00AD1D1C: CBNZ x19, #0xad1d24        | if (token != null) goto label_4;        
            if(token != null)
            {
                goto label_4;
            }
            // 0x00AD1D20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._children, ????);
            label_4:
            // 0x00AD1D24: STR x20, [x19, #0x10]      | token.<Parent>k__BackingField = this;    //  dest_result_addr=0
            token.<Parent>k__BackingField = this;
            // 0x00AD1D28: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD1D2C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD1D30: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00AD1D34: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00AD1D38: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1D9C (11345308), len: 8  VirtAddr: 0x00AD1D9C RVA: 0x00AD1D9C token: 100684768 methodIndex: 47373 delegateWrapperIndex: 0 methodInvoker: 0
        public override Newtonsoft.Json.Bson.BsonType get_Type()
        {
            //
            // Disasemble & Code
            // 0x00AD1D9C: ORR w0, wzr, #3            | W0 = 3(0x3);                            
            // 0x00AD1DA0: RET                        |  return (Newtonsoft.Json.Bson.BsonType)0x3;
            return (Newtonsoft.Json.Bson.BsonType)3;
            //  |  // // {name=val_0, type=Newtonsoft.Json.Bson.BsonType, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1798 (11343768), len: 144  VirtAddr: 0x00AD1798 RVA: 0x00AD1798 token: 100684769 methodIndex: 47374 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonProperty> GetEnumerator()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            // 0x00AD1798: STP x20, x19, [sp, #-0x20]! | stack[1152921513722803888] = ???;  stack[1152921513722803896] = ???;  //  dest_result_addr=1152921513722803888 |  dest_result_addr=1152921513722803896
            // 0x00AD179C: STP x29, x30, [sp, #0x10]  | stack[1152921513722803904] = ???;  stack[1152921513722803912] = ???;  //  dest_result_addr=1152921513722803904 |  dest_result_addr=1152921513722803912
            // 0x00AD17A0: ADD x29, sp, #0x10         | X29 = (1152921513722803888 + 16) = 1152921513722803904 (0x100000021F5A76C0);
            // 0x00AD17A4: SUB sp, sp, #0x30          | SP = (1152921513722803888 - 48) = 1152921513722803840 (0x100000021F5A7680);
            // 0x00AD17A8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AD17AC: LDRB w8, [x20, #0x4cd]     | W8 = (bool)static_value_037334CD;       
            // 0x00AD17B0: MOV x19, x0                | X19 = 1152921513722815920 (0x100000021F5AA5B0);//ML01
            // 0x00AD17B4: TBNZ w8, #0, #0xad17d0     | if (static_value_037334CD == true) goto label_0;
            // 0x00AD17B8: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x00AD17BC: LDR x8, [x8, #0xba8]       | X8 = 0x2B8F980;                         
            // 0x00AD17C0: LDR w0, [x8]               | W0 = 0x1524;                            
            // 0x00AD17C4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1524, ????);     
            // 0x00AD17C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD17CC: STRB w8, [x20, #0x4cd]     | static_value_037334CD = true;            //  dest_result_addr=57881805
            label_0:
            // 0x00AD17D0: LDR x19, [x19, #0x20]      | X19 = this._children; //P2              
            // 0x00AD17D4: CBNZ x19, #0xad17dc        | if (this._children != null) goto label_1;
            if(this._children != null)
            {
                goto label_1;
            }
            // 0x00AD17D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1524, ????);     
            label_1:
            // 0x00AD17DC: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x00AD17E0: LDR x8, [x8, #0xbb8]       | X8 = 1152921513722786800;               
            // 0x00AD17E4: MOV x0, x19                | X0 = this._children;//m1                
            // 0x00AD17E8: LDR x1, [x8]               | X1 = public List.Enumerator<T> System.Collections.Generic.List<Newtonsoft.Json.Bson.BsonProperty>::GetEnumerator();
            // 0x00AD17EC: ADD x8, sp, #0x18          | X8 = (1152921513722803840 + 24) = 1152921513722803864 (0x100000021F5A7698);
            // 0x00AD17F0: BL #0x25ebf2c              | X0 = this._children.GetEnumerator();    
            List.Enumerator<T> val_1 = this._children.GetEnumerator();
            // 0x00AD17F4: ADRP x9, #0x35d5000        | X9 = 56446976 (0x35D5000);              
            // 0x00AD17F8: LDR x8, [sp, #0x28]        | X8 = val_2;                              //  find_add[1152921513722791920]
            // 0x00AD17FC: LDUR q0, [sp, #0x18]       | Q0 = val_3;                              //  find_add[1152921513722791920]
            // 0x00AD1800: LDR x9, [x9, #0x140]       | X9 = 1152921504616697856;               
            // 0x00AD1804: MOV x1, sp                 | X1 = 1152921513722803840 (0x100000021F5A7680);//ML01
            // 0x00AD1808: STR x8, [sp, #0x10]        | stack[1152921513722803856] = val_2;      //  dest_result_addr=1152921513722803856
            // 0x00AD180C: LDR x0, [x9]               | X0 = typeof(List.Enumerator<T>);        
            // 0x00AD1810: STR q0, [sp]               | stack[1152921513722803840] = val_3;      //  dest_result_addr=1152921513722803840
            // 0x00AD1814: BL #0x27bc028              | X0 = 1152921513722852016 = (Il2CppObject*)Box((RuntimeClass*)typeof(List.Enumerator<T>), val_3);
            // 0x00AD1818: SUB sp, x29, #0x10         | SP = (1152921513722803904 - 16) = 1152921513722803888 (0x100000021F5A76B0);
            // 0x00AD181C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD1820: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD1824: RET                        |  return (System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonProperty>)val_3;
            return (System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonProperty>)val_3;
            //  |  // // {name=val_0, type=System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonProperty>, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1DA4 (11345316), len: 4  VirtAddr: 0x00AD1DA4 RVA: 0x00AD1DA4 token: 100684770 methodIndex: 47375 delegateWrapperIndex: 0 methodInvoker: 0
        private System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            //
            // Disasemble & Code
            // 0x00AD1DA4: B #0xad1798                | return this.GetEnumerator();            
            return this.GetEnumerator();
        
        }
    
    }

}
