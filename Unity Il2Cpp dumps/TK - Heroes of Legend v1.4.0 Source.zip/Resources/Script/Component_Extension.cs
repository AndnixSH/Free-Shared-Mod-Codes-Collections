using UnityEngine;
[System.Runtime.CompilerServices.ExtensionAttribute] // 0x287C5B0
public static class Component_Extension
{
    // Methods
    // Generic instance method:
    //
    // file offset: 0x00FD7298 VirtAddr: 0x00FD7298 -RVA: 0x00FD7298 
    // -Component_Extension.SafeGetComponent<object>
    //
    //
    // Offset in libil2cpp.so: 0x00FD7298 (16609944), len: 208  VirtAddr: 0x00FD7298 RVA: 0x00FD7298 token: 100696620 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    [System.Runtime.CompilerServices.ExtensionAttribute] // 0x287C5C0
    public static T SafeGetComponent<T>(UnityEngine.Component _this)
    {
        //
        // Disasemble & Code
        // 0x00FD7298: STP x22, x21, [sp, #-0x30]! | stack[1152921515562382432] = ???;  stack[1152921515562382440] = ???;  //  dest_result_addr=1152921515562382432 |  dest_result_addr=1152921515562382440
        // 0x00FD729C: STP x20, x19, [sp, #0x10]  | stack[1152921515562382448] = ???;  stack[1152921515562382456] = ???;  //  dest_result_addr=1152921515562382448 |  dest_result_addr=1152921515562382456
        // 0x00FD72A0: STP x29, x30, [sp, #0x20]  | stack[1152921515562382464] = ???;  stack[1152921515562382472] = ???;  //  dest_result_addr=1152921515562382464 |  dest_result_addr=1152921515562382472
        // 0x00FD72A4: ADD x29, sp, #0x20         | X29 = (1152921515562382432 + 32) = 1152921515562382464 (0x100000028D003480);
        // 0x00FD72A8: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
        // 0x00FD72AC: LDRB w8, [x21, #0x3e8]     | W8 = (bool)static_value_037353E8;       
        // 0x00FD72B0: MOV x19, x2                | X19 = X2;//m1                           
        // 0x00FD72B4: MOV x20, x1                | X20 = __RuntimeMethodHiddenParam;//m1   
        // 0x00FD72B8: TBNZ w8, #0, #0xfd72d4     | if (static_value_037353E8 == true) goto label_0;
        // 0x00FD72BC: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
        // 0x00FD72C0: LDR x8, [x8, #0xee8]       | X8 = 0x2B926C4;                         
        // 0x00FD72C4: LDR w0, [x8]               | W0 = 0x2076;                            
        // 0x00FD72C8: BL #0x2782188              | X0 = sub_2782188( ?? 0x2076, ????);     
        // 0x00FD72CC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00FD72D0: STRB w8, [x21, #0x3e8]     | static_value_037353E8 = true;            //  dest_result_addr=57889768
        label_0:
        // 0x00FD72D4: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00FD72D8: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00FD72DC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00FD72E0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00FD72E4: TBZ w8, #0, #0xfd72f4      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00FD72E8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00FD72EC: CBNZ w8, #0xfd72f4         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00FD72F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00FD72F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00FD72F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00FD72FC: MOV x1, x20                | X1 = __RuntimeMethodHiddenParam;//m1    
        // 0x00FD7300: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00FD7304: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  __RuntimeMethodHiddenParam);
        bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  __RuntimeMethodHiddenParam);
        // 0x00FD7308: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x00FD730C: TBZ w8, #0, #0xfd7330      | if ((val_1 & 1) == false) goto label_3; 
        if(val_2 == false)
        {
            goto label_3;
        }
        // 0x00FD7310: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
        // 0x00FD7314: LDR x0, [x8]               | X0 = X2 + 48;                           
        // 0x00FD7318: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 48, ????);    
        // 0x00FD731C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00FD7320: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00FD7324: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00FD7328: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00FD732C: RET                        |  return (System.Object)null;            
        return (object)0;
        //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        label_3:
        // 0x00FD7330: CBNZ x20, #0xfd7338        | if (__RuntimeMethodHiddenParam != 0) goto label_4;
        if(__RuntimeMethodHiddenParam != 0)
        {
            goto label_4;
        }
        // 0x00FD7334: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00FD7338: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00FD733C: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam;//m1    
        // 0x00FD7340: BL #0x20d50fc              | X0 = __RuntimeMethodHiddenParam.get_gameObject();
        UnityEngine.GameObject val_3 = __RuntimeMethodHiddenParam.gameObject;
        // 0x00FD7344: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
        // 0x00FD7348: MOV x1, x0                 | X1 = val_3;//m1                         
        // 0x00FD734C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00FD7350: LDR x2, [x8, #8]           | X2 = X2 + 48 + 8;                       
        // 0x00FD7354: LDR x3, [x2]               | X3 = X2 + 48 + 8;                       
        // 0x00FD7358: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00FD735C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00FD7360: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00FD7364: BR x3                      | goto X2 + 48 + 8;                       
        goto X2 + 48 + 8;
    
    }
    // Generic instance method:
    //
    // file offset: 0x00FD71C8 VirtAddr: 0x00FD71C8 -RVA: 0x00FD71C8 
    // -Component_Extension.GetOrCreateComponent<object>
    // -Component_Extension.GetOrCreateComponent<BloomEffect>
    //
    //
    // Offset in libil2cpp.so: 0x00FD71C8 (16609736), len: 208  VirtAddr: 0x00FD71C8 RVA: 0x00FD71C8 token: 100696621 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    [System.Runtime.CompilerServices.ExtensionAttribute] // 0x287C5D0
    public static T GetOrCreateComponent<T>(UnityEngine.Component _this)
    {
        //
        // Disasemble & Code
        // 0x00FD71C8: STP x22, x21, [sp, #-0x30]! | stack[1152921515562510816] = ???;  stack[1152921515562510824] = ???;  //  dest_result_addr=1152921515562510816 |  dest_result_addr=1152921515562510824
        // 0x00FD71CC: STP x20, x19, [sp, #0x10]  | stack[1152921515562510832] = ???;  stack[1152921515562510840] = ???;  //  dest_result_addr=1152921515562510832 |  dest_result_addr=1152921515562510840
        // 0x00FD71D0: STP x29, x30, [sp, #0x20]  | stack[1152921515562510848] = ???;  stack[1152921515562510856] = ???;  //  dest_result_addr=1152921515562510848 |  dest_result_addr=1152921515562510856
        // 0x00FD71D4: ADD x29, sp, #0x20         | X29 = (1152921515562510816 + 32) = 1152921515562510848 (0x100000028D022A00);
        // 0x00FD71D8: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
        // 0x00FD71DC: LDRB w8, [x21, #0x3e7]     | W8 = (bool)static_value_037353E7;       
        // 0x00FD71E0: MOV x19, x2                | X19 = X2;//m1                           
        // 0x00FD71E4: MOV x20, x1                | X20 = __RuntimeMethodHiddenParam;//m1   
        // 0x00FD71E8: TBNZ w8, #0, #0xfd7204     | if (static_value_037353E7 == true) goto label_0;
        // 0x00FD71EC: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
        // 0x00FD71F0: LDR x8, [x8, #0x208]       | X8 = 0x2B926C0;                         
        // 0x00FD71F4: LDR w0, [x8]               | W0 = 0x2075;                            
        // 0x00FD71F8: BL #0x2782188              | X0 = sub_2782188( ?? 0x2075, ????);     
        // 0x00FD71FC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00FD7200: STRB w8, [x21, #0x3e7]     | static_value_037353E7 = true;            //  dest_result_addr=57889767
        label_0:
        // 0x00FD7204: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00FD7208: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00FD720C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00FD7210: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00FD7214: TBZ w8, #0, #0xfd7224      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00FD7218: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00FD721C: CBNZ w8, #0xfd7224         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00FD7220: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00FD7224: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00FD7228: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00FD722C: MOV x1, x20                | X1 = __RuntimeMethodHiddenParam;//m1    
        // 0x00FD7230: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00FD7234: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  __RuntimeMethodHiddenParam);
        bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  __RuntimeMethodHiddenParam);
        // 0x00FD7238: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x00FD723C: TBZ w8, #0, #0xfd7260      | if ((val_1 & 1) == false) goto label_3; 
        if(val_2 == false)
        {
            goto label_3;
        }
        // 0x00FD7240: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
        // 0x00FD7244: LDR x0, [x8]               | X0 = X2 + 48;                           
        // 0x00FD7248: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 48, ????);    
        // 0x00FD724C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00FD7250: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00FD7254: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00FD7258: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00FD725C: RET                        |  return (System.Object)null;            
        return (object)0;
        //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        label_3:
        // 0x00FD7260: CBNZ x20, #0xfd7268        | if (__RuntimeMethodHiddenParam != 0) goto label_4;
        if(__RuntimeMethodHiddenParam != 0)
        {
            goto label_4;
        }
        // 0x00FD7264: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00FD7268: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00FD726C: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam;//m1    
        // 0x00FD7270: BL #0x20d50fc              | X0 = __RuntimeMethodHiddenParam.get_gameObject();
        UnityEngine.GameObject val_3 = __RuntimeMethodHiddenParam.gameObject;
        // 0x00FD7274: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
        // 0x00FD7278: MOV x1, x0                 | X1 = val_3;//m1                         
        // 0x00FD727C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00FD7280: LDR x2, [x8, #8]           | X2 = X2 + 48 + 8;                       
        // 0x00FD7284: LDR x3, [x2]               | X3 = X2 + 48 + 8;                       
        // 0x00FD7288: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00FD728C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00FD7290: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00FD7294: BR x3                      | goto X2 + 48 + 8;                       
        goto X2 + 48 + 8;
    
    }

}
