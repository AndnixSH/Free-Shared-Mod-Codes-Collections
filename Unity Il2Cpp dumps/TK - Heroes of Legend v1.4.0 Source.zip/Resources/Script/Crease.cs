using UnityEngine;
[UnityEngine.AddComponentMenu] // 0x281A8B0
[UnityEngine.ExecuteInEditMode] // 0x281A8B0
[UnityEngine.RequireComponent] // 0x281A8B0
[Serializable]
public class Crease : PostEffectsBase
{
    // Fields
    public float intensity; //  0x0000001C
    public int softness; //  0x00000020
    public float spread; //  0x00000024
    public UnityEngine.Shader blurShader; //  0x00000028
    private UnityEngine.Material blurMaterial; //  0x00000030
    public UnityEngine.Shader depthFetchShader; //  0x00000038
    private UnityEngine.Material depthFetchMaterial; //  0x00000040
    public UnityEngine.Shader creaseApplyShader; //  0x00000048
    private UnityEngine.Material creaseApplyMaterial; //  0x00000050
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x02679D58 (40344920), len: 68  VirtAddr: 0x02679D58 RVA: 0x02679D58 token: 100663363 methodIndex: 24447 delegateWrapperIndex: 0 methodInvoker: 0
    public Crease()
    {
        //
        // Disasemble & Code
        // 0x02679D58: STP x20, x19, [sp, #-0x20]! | stack[1152921509954418848] = ???;  stack[1152921509954418856] = ???;  //  dest_result_addr=1152921509954418848 |  dest_result_addr=1152921509954418856
        // 0x02679D5C: STP x29, x30, [sp, #0x10]  | stack[1152921509954418864] = ???;  stack[1152921509954418872] = ???;  //  dest_result_addr=1152921509954418864 |  dest_result_addr=1152921509954418872
        // 0x02679D60: ADD x29, sp, #0x10         | X29 = (1152921509954418848 + 16) = 1152921509954418864 (0x100000013EBD78B0);
        // 0x02679D64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02679D68: MOV x19, x0                | X19 = 1152921509954430880 (0x100000013EBDA7A0);//ML01
        // 0x02679D6C: BL #0x1b76fd4              | this..ctor();                           
        val_1 = new UnityEngine.MonoBehaviour();
        // 0x02679D70: MOVZ x10, #0x3f80, lsl #48 | X10 = 4575657221408423936 (0x3F80000000000000);//ML01
        // 0x02679D74: MOVK x10, #0x1             | X10 = 4575657221408423937 (0x3F80000000000001);
        // 0x02679D78: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02679D7C: ORR w9, wzr, #0x3f000000   | W9 = 1056964608(0x3F000000);            
        // 0x02679D80: STR x10, [x19, #0x20]      | this.softness = 1; this.spread = 1;      //  dest_result_addr=1152921509954430912 dest_result_addr=1152921509954430916
        this.softness = 1;
        this.spread = 1f;
        // 0x02679D84: STRB w8, [x19, #0x18]      | mem[1152921509954430904] = 0x1;          //  dest_result_addr=1152921509954430904
        mem[1152921509954430904] = 1;
        // 0x02679D88: STRB w8, [x19, #0x1a]      | mem[1152921509954430906] = 0x1;          //  dest_result_addr=1152921509954430906
        mem[1152921509954430906] = 1;
        // 0x02679D8C: STR w9, [x19, #0x1c]       | this.intensity = 0.5;                    //  dest_result_addr=1152921509954430908
        this.intensity = 0.5f;
        // 0x02679D90: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02679D94: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x02679D98: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02679D9C (40344988), len: 152  VirtAddr: 0x02679D9C RVA: 0x02679D9C token: 100663364 methodIndex: 24448 delegateWrapperIndex: 0 methodInvoker: 0
    public override bool CheckResources()
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        // 0x02679D9C: STP x20, x19, [sp, #-0x20]! | stack[1152921509954555424] = ???;  stack[1152921509954555432] = ???;  //  dest_result_addr=1152921509954555424 |  dest_result_addr=1152921509954555432
        // 0x02679DA0: STP x29, x30, [sp, #0x10]  | stack[1152921509954555440] = ???;  stack[1152921509954555448] = ???;  //  dest_result_addr=1152921509954555440 |  dest_result_addr=1152921509954555448
        // 0x02679DA4: ADD x29, sp, #0x10         | X29 = (1152921509954555424 + 16) = 1152921509954555440 (0x100000013EBF8E30);
        // 0x02679DA8: MOV x19, x0                | X19 = 1152921509954567456 (0x100000013EBFBD20);//ML01
        // 0x02679DAC: LDR x8, [x19]              | X8 = typeof(Crease);                    
        // 0x02679DB0: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x02679DB4: LDP x9, x2, [x8, #0x1b0]   | X9 = typeof(Crease).__il2cppRuntimeField_1B0; X2 = typeof(Crease).__il2cppRuntimeField_1B8; //  | 
        // 0x02679DB8: BLR x9                     | X0 = typeof(Crease).__il2cppRuntimeField_1B0();
        // 0x02679DBC: LDR x8, [x19]              | X8 = typeof(Crease);                    
        // 0x02679DC0: LDP x1, x2, [x19, #0x28]   | X1 = this.blurShader; //P2  X2 = this.blurMaterial; //P2  //  | 
        // 0x02679DC4: MOV x0, x19                | X0 = 1152921509954567456 (0x100000013EBFBD20);//ML01
        // 0x02679DC8: LDP x9, x3, [x8, #0x150]   | X9 = typeof(Crease).__il2cppRuntimeField_150; X3 = typeof(Crease).__il2cppRuntimeField_158; //  | 
        // 0x02679DCC: BLR x9                     | X0 = typeof(Crease).__il2cppRuntimeField_150();
        // 0x02679DD0: LDR x8, [x19]              | X8 = typeof(Crease);                    
        // 0x02679DD4: STR x0, [x19, #0x30]       | this.blurMaterial = this;                //  dest_result_addr=1152921509954567504
        this.blurMaterial = this;
        // 0x02679DD8: LDP x1, x2, [x19, #0x38]   | X1 = this.depthFetchShader; //P2  X2 = this.depthFetchMaterial; //P2  //  | 
        // 0x02679DDC: MOV x0, x19                | X0 = 1152921509954567456 (0x100000013EBFBD20);//ML01
        // 0x02679DE0: LDP x9, x3, [x8, #0x150]   | X9 = typeof(Crease).__il2cppRuntimeField_150; X3 = typeof(Crease).__il2cppRuntimeField_158; //  | 
        // 0x02679DE4: BLR x9                     | X0 = typeof(Crease).__il2cppRuntimeField_150();
        // 0x02679DE8: LDR x8, [x19]              | X8 = typeof(Crease);                    
        // 0x02679DEC: STR x0, [x19, #0x40]       | this.depthFetchMaterial = this;          //  dest_result_addr=1152921509954567520
        this.depthFetchMaterial = this;
        // 0x02679DF0: LDP x1, x2, [x19, #0x48]   | X1 = this.creaseApplyShader; //P2  X2 = this.creaseApplyMaterial; //P2  //  | 
        // 0x02679DF4: MOV x0, x19                | X0 = 1152921509954567456 (0x100000013EBFBD20);//ML01
        // 0x02679DF8: LDP x9, x3, [x8, #0x150]   | X9 = typeof(Crease).__il2cppRuntimeField_150; X3 = typeof(Crease).__il2cppRuntimeField_158; //  | 
        // 0x02679DFC: BLR x9                     | X0 = typeof(Crease).__il2cppRuntimeField_150();
        // 0x02679E00: LDRB w8, [x19, #0x1a]      | 
        // 0x02679E04: STR x0, [x19, #0x50]       | this.creaseApplyMaterial = this;         //  dest_result_addr=1152921509954567536
        this.creaseApplyMaterial = this;
        // 0x02679E08: CBNZ w8, #0x2679e20        | if (typeof(Crease) != null) goto label_0;
        if(null != null)
        {
            goto label_0;
        }
        // 0x02679E0C: LDR x8, [x19]              | X8 = typeof(Crease);                    
        // 0x02679E10: MOV x0, x19                | X0 = 1152921509954567456 (0x100000013EBFBD20);//ML01
        // 0x02679E14: LDP x9, x1, [x8, #0x1e0]   | X9 = typeof(Crease).__il2cppRuntimeField_1E0; X1 = typeof(Crease).__il2cppRuntimeField_1E8; //  | 
        // 0x02679E18: BLR x9                     | X0 = typeof(Crease).__il2cppRuntimeField_1E0();
        // 0x02679E1C: LDRB w8, [x19, #0x1a]      | 
        label_0:
        // 0x02679E20: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02679E24: CMP w8, #0                 | STATE = COMPARE(typeof(Crease), 0x0)    
        // 0x02679E28: CSET w0, ne                | W0 = typeof(Crease) != null ? 1 : 0;    
        var val_1 = (null != 0) ? 1 : 0;
        // 0x02679E2C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x02679E30: RET                        |  return (System.Boolean)typeof(Crease) != null ? 1 : 0;
        return (bool)val_1;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x02679E34 (40345140), len: 1064  VirtAddr: 0x02679E34 RVA: 0x02679E34 token: 100663365 methodIndex: 24449 delegateWrapperIndex: 0 methodInvoker: 0
    public override void OnRenderImage(UnityEngine.RenderTexture source, UnityEngine.RenderTexture destination)
    {
        //
        // Disasemble & Code
        //  | 
        int val_11;
        //  | 
        UnityEngine.RenderTexture val_12;
        // 0x02679E34: STP d11, d10, [sp, #-0x80]! | stack[1152921509954753536] = ???;  stack[1152921509954753544] = ???;  //  dest_result_addr=1152921509954753536 |  dest_result_addr=1152921509954753544
        // 0x02679E38: STP d9, d8, [sp, #0x10]    | stack[1152921509954753552] = ???;  stack[1152921509954753560] = ???;  //  dest_result_addr=1152921509954753552 |  dest_result_addr=1152921509954753560
        // 0x02679E3C: STP x28, x27, [sp, #0x20]  | stack[1152921509954753568] = ???;  stack[1152921509954753576] = ???;  //  dest_result_addr=1152921509954753568 |  dest_result_addr=1152921509954753576
        // 0x02679E40: STP x26, x25, [sp, #0x30]  | stack[1152921509954753584] = ???;  stack[1152921509954753592] = ???;  //  dest_result_addr=1152921509954753584 |  dest_result_addr=1152921509954753592
        // 0x02679E44: STP x24, x23, [sp, #0x40]  | stack[1152921509954753600] = ???;  stack[1152921509954753608] = ???;  //  dest_result_addr=1152921509954753600 |  dest_result_addr=1152921509954753608
        // 0x02679E48: STP x22, x21, [sp, #0x50]  | stack[1152921509954753616] = ???;  stack[1152921509954753624] = ???;  //  dest_result_addr=1152921509954753616 |  dest_result_addr=1152921509954753624
        // 0x02679E4C: STP x20, x19, [sp, #0x60]  | stack[1152921509954753632] = ???;  stack[1152921509954753640] = ???;  //  dest_result_addr=1152921509954753632 |  dest_result_addr=1152921509954753640
        // 0x02679E50: STP x29, x30, [sp, #0x70]  | stack[1152921509954753648] = ???;  stack[1152921509954753656] = ???;  //  dest_result_addr=1152921509954753648 |  dest_result_addr=1152921509954753656
        // 0x02679E54: ADD x29, sp, #0x70         | X29 = (1152921509954753536 + 112) = 1152921509954753648 (0x100000013EC29470);
        // 0x02679E58: SUB sp, sp, #0x40          | SP = (1152921509954753536 - 64) = 1152921509954753472 (0x100000013EC293C0);
        // 0x02679E5C: ADRP x19, #0x3740000       | X19 = 57933824 (0x3740000);             
        // 0x02679E60: LDRB w8, [x19, #0xe66]     | W8 = (bool)static_value_03740E66;       
        // 0x02679E64: MOV x22, x2                | X22 = destination;//m1                  
        // 0x02679E68: MOV x20, x1                | X20 = source;//m1                       
        // 0x02679E6C: MOV x21, x0                | X21 = 1152921509954765664 (0x100000013EC2C360);//ML01
        // 0x02679E70: TBNZ w8, #0, #0x2679e8c    | if (static_value_03740E66 == true) goto label_0;
        // 0x02679E74: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
        // 0x02679E78: LDR x8, [x8, #0xba0]       | X8 = 0x2B92DD8;                         
        // 0x02679E7C: LDR w0, [x8]               | W0 = 0x223B;                            
        // 0x02679E80: BL #0x2782188              | X0 = sub_2782188( ?? 0x223B, ????);     
        // 0x02679E84: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02679E88: STRB w8, [x19, #0xe66]     | static_value_03740E66 = true;            //  dest_result_addr=57937510
        label_0:
        // 0x02679E8C: LDR x8, [x21]              | X8 = typeof(Crease);                    
        // 0x02679E90: MOV x0, x21                | X0 = 1152921509954765664 (0x100000013EC2C360);//ML01
        // 0x02679E94: LDP x9, x1, [x8, #0x190]   | X9 = typeof(Crease).__il2cppRuntimeField_190; X1 = typeof(Crease).__il2cppRuntimeField_198; //  | 
        // 0x02679E98: BLR x9                     | X0 = typeof(Crease).__il2cppRuntimeField_190();
        // 0x02679E9C: AND w8, w0, #1             | W8 = (this & 1) = 0 (0x00000000);       
        // 0x02679EA0: TBZ w8, #0, #0x267a204     | if (((Crease)[1152921509954765664] & 0x1) == 0) goto label_1;
        if((0 & 1) == 0)
        {
            goto label_1;
        }
        // 0x02679EA4: CBNZ x20, #0x2679eac       | if (source != null) goto label_2;       
        if(source != null)
        {
            goto label_2;
        }
        // 0x02679EA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_2:
        // 0x02679EAC: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02679EB0: MOV x0, x20                | X0 = source;//m1                        
        // 0x02679EB4: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x02679EB8: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x02679EBC: MOV w26, w0                | W26 = source;//m1                       
        // 0x02679EC0: CBNZ x20, #0x2679ec8       | if (source != null) goto label_3;       
        if(source != null)
        {
            goto label_3;
        }
        // 0x02679EC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_3:
        // 0x02679EC8: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02679ECC: MOV x0, x20                | X0 = source;//m1                        
        // 0x02679ED0: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x02679ED4: STR x20, [sp, #0x10]       | stack[1152921509954753488] = source;     //  dest_result_addr=1152921509954753488
        // 0x02679ED8: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x02679EDC: MOV w27, w0                | W27 = source;//m1                       
        val_11 = source;
        // 0x02679EE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679EE4: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x02679EE8: MOV w1, w26                | W1 = source;//m1                        
        // 0x02679EEC: MOV w2, w27                | W2 = source;//m1                        
        // 0x02679EF0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02679EF4: BL #0x1b89164              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  source, depthBuffer:  val_11);
        UnityEngine.RenderTexture val_1 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  source, depthBuffer:  val_11);
        // 0x02679EF8: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x02679EFC: CMP w26, #0                | STATE = COMPARE(source, 0x0)            
        // 0x02679F00: CINC w8, w26, lt           | W8 = source < null ? (source + 1) : source;
        var val_2 = (source < 0) ? (source + 1) : (source);
        // 0x02679F04: CMP w27, #0                | STATE = COMPARE(source, 0x0)            
        // 0x02679F08: CINC w9, w27, lt           | W9 = val_11 < null ? (source + 1) : source;
        var val_3 = (val_11 < 0) ? (val_11 + 1) : (val_11);
        // 0x02679F0C: ASR w24, w8, #1            | W24 = (source < null ? (source + 1) : source >> 1);
        int val_4 = val_2 >> 1;
        // 0x02679F10: ASR w25, w9, #1            | W25 = (val_11 < null ? (source + 1) : source >> 1);
        int val_5 = val_3 >> 1;
        // 0x02679F14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679F18: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x02679F1C: MOV w1, w24                | W1 = (source < null ? (source + 1) : source >> 1);//m1
        // 0x02679F20: MOV w2, w25                | W2 = (val_11 < null ? (source + 1) : source >> 1);//m1
        // 0x02679F24: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02679F28: BL #0x1b89164              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_4, depthBuffer:  val_5);
        UnityEngine.RenderTexture val_6 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_4, depthBuffer:  val_5);
        // 0x02679F2C: ADRP x19, #0x3641000       | X19 = 56889344 (0x3641000);             
        // 0x02679F30: LDR x19, [x19, #0x800]     | X19 = 1152921504693481472;              
        // 0x02679F34: LDR x28, [x21, #0x40]      | X28 = this.depthFetchMaterial; //P2     
        // 0x02679F38: MOV x23, x0                | X23 = val_6;//m1                        
        val_12 = val_6;
        // 0x02679F3C: LDR x8, [x19]              | X8 = typeof(UnityEngine.Graphics);      
        // 0x02679F40: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02679F44: TBZ w9, #0, #0x2679f58     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x02679F48: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02679F4C: CBNZ w9, #0x2679f58        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x02679F50: MOV x0, x8                 | X0 = 1152921504693481472 (0x100000000529F000);//ML01
        // 0x02679F54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_5:
        // 0x02679F58: LDR x1, [sp, #0x10]        | X1 = source;                            
        // 0x02679F5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679F60: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02679F64: MOV x2, x20                | X2 = val_1;//m1                         
        // 0x02679F68: MOV x3, x28                | X3 = this.depthFetchMaterial;//m1       
        // 0x02679F6C: STR x22, [sp, #8]          | stack[1152921509954753480] = destination;  //  dest_result_addr=1152921509954753480
        // 0x02679F70: STR x20, [sp, #0x18]       | stack[1152921509954753496] = val_1;      //  dest_result_addr=1152921509954753496
        // 0x02679F74: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  val_1);
        UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  val_1);
        // 0x02679F78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679F7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02679F80: MOV x1, x20                | X1 = val_1;//m1                         
        // 0x02679F84: MOV x2, x23                | X2 = val_6;//m1                         
        // 0x02679F88: BL #0x1a6ba68              | UnityEngine.Graphics.Blit(source:  0, dest:  val_1);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_1);
        // 0x02679F8C: LDR w8, [x21, #0x20]       | W8 = this.softness; //P2                
        // 0x02679F90: CMP w8, #1                 | STATE = COMPARE(this.softness, 0x1)     
        // 0x02679F94: B.LT #0x267a104            | if (this.softness < 1) goto label_6;    
        if(this.softness < 1)
        {
            goto label_6;
        }
        // 0x02679F98: ADRP x8, #0x2ac3000        | X8 = 44838912 (0x2AC3000);              
        // 0x02679F9C: ADRP x22, #0x364a000       | X22 = 56926208 (0x364A000);             
        // 0x02679FA0: LDR s9, [x8, #0xd1c]       | S9 = 0.001953125;                       
        // 0x02679FA4: LDR x22, [x22, #0x178]     | X22 = (string**)(1152921509946714736)("offsets");
        // 0x02679FA8: SCVTF s0, w26              | S0 = (float)(source);                   
        // 0x02679FAC: SCVTF s1, w27              | S1 = (float)(source);                   
        // 0x02679FB0: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
        var val_12 = 0;
        // 0x02679FB4: FDIV s10, s0, s1           | S10 = (source / source);                
        float val_7 = (float)source / (float)val_11;
        // 0x02679FB8: FMOV s8, wzr               | S8 = 0f;                                
        label_11:
        // 0x02679FBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679FC0: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x02679FC4: MOV w1, w24                | W1 = (source < null ? (source + 1) : source >> 1);//m1
        // 0x02679FC8: MOV w2, w25                | W2 = (val_11 < null ? (source + 1) : source >> 1);//m1
        // 0x02679FCC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02679FD0: BL #0x1b89164              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_4, depthBuffer:  val_5);
        UnityEngine.RenderTexture val_8 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_4, depthBuffer:  val_5);
        // 0x02679FD4: LDR s0, [x21, #0x24]       | S0 = this.spread; //P2                  
        // 0x02679FD8: LDR x27, [x21, #0x30]      | X27 = this.blurMaterial; //P2           
        // 0x02679FDC: MOV x26, x0                | X26 = val_8;//m1                        
        // 0x02679FE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02679FE4: FMUL s1, s0, s9            | S1 = (this.spread * 0.001953125f);      
        float val_9 = this.spread * 0.001953125f;
        // 0x02679FE8: ADD x0, sp, #0x30          | X0 = (1152921509954753472 + 48) = 1152921509954753520 (0x100000013EC293F0);
        // 0x02679FEC: MOV v0.16b, v8.16b         | V0 = 0;//m1                             
        // 0x02679FF0: MOV v2.16b, v8.16b         | V2 = 0;//m1                             
        // 0x02679FF4: MOV v3.16b, v8.16b         | V3 = 0;//m1                             
        // 0x02679FF8: STP xzr, xzr, [sp, #0x30]  | stack[1152921509954753520] = 0x0;  stack[1152921509954753528] = 0x0;  //  dest_result_addr=1152921509954753520 |  dest_result_addr=1152921509954753528
        // 0x02679FFC: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x0267A000: CBNZ x27, #0x267a008       | if (this.blurMaterial != null) goto label_7;
        if(this.blurMaterial != null)
        {
            goto label_7;
        }
        // 0x0267A004: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013EC293F0, ????);
        label_7:
        // 0x0267A008: LDR x1, [x22]              | X1 = "offsets";                         
        // 0x0267A00C: LDP s0, s1, [sp, #0x30]    | S0 = 0; S1 = 0;                          //  | 
        // 0x0267A010: LDP s2, s3, [sp, #0x38]    | S2 = 0; S3 = 0;                          //  | 
        // 0x0267A014: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0267A018: MOV x0, x27                | X0 = this.blurMaterial;//m1             
        // 0x0267A01C: BL #0x1a79fa8              | this.blurMaterial.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.blurMaterial.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x0267A020: LDR x0, [x19]              | X0 = typeof(UnityEngine.Graphics);      
        // 0x0267A024: LDR x27, [x21, #0x30]      | X27 = this.blurMaterial; //P2           
        // 0x0267A028: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x0267A02C: TBZ w8, #0, #0x267a03c     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x0267A030: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x0267A034: CBNZ w8, #0x267a03c        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x0267A038: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_9:
        // 0x0267A03C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267A040: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x0267A044: MOV x1, x23                | X1 = val_6;//m1                         
        // 0x0267A048: MOV x2, x26                | X2 = val_8;//m1                         
        // 0x0267A04C: MOV x3, x27                | X3 = this.blurMaterial;//m1             
        // 0x0267A050: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  val_12, mat:  val_8);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_12, mat:  val_8);
        // 0x0267A054: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267A058: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0267A05C: MOV x1, x23                | X1 = val_6;//m1                         
        // 0x0267A060: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x0267A064: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267A068: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x0267A06C: MOV w1, w24                | W1 = (source < null ? (source + 1) : source >> 1);//m1
        // 0x0267A070: MOV w2, w25                | W2 = (val_11 < null ? (source + 1) : source >> 1);//m1
        // 0x0267A074: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x0267A078: BL #0x1b89164              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_4, depthBuffer:  val_5);
        UnityEngine.RenderTexture val_10 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_4, depthBuffer:  val_5);
        // 0x0267A07C: LDR s0, [x21, #0x24]       | S0 = this.spread; //P2                  
        float val_11 = this.spread;
        // 0x0267A080: LDR x27, [x21, #0x30]      | X27 = this.blurMaterial; //P2           
        val_11 = this.blurMaterial;
        // 0x0267A084: MOV x23, x0                | X23 = val_10;//m1                       
        val_12 = val_10;
        // 0x0267A088: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267A08C: FMUL s0, s0, s9            | S0 = (this.spread * 0.001953125f);      
        val_11 = val_11 * 0.001953125f;
        // 0x0267A090: FDIV s0, s0, s10           | S0 = ((this.spread * 0.001953125f) / (source / source));
        val_11 = val_11 / val_7;
        // 0x0267A094: ADD x0, sp, #0x20          | X0 = (1152921509954753472 + 32) = 1152921509954753504 (0x100000013EC293E0);
        // 0x0267A098: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
        // 0x0267A09C: MOV v2.16b, v8.16b         | V2 = 0;//m1                             
        // 0x0267A0A0: MOV v3.16b, v8.16b         | V3 = 0;//m1                             
        // 0x0267A0A4: STP xzr, xzr, [sp, #0x20]  | stack[1152921509954753504] = 0x0;  stack[1152921509954753512] = 0x0;  //  dest_result_addr=1152921509954753504 |  dest_result_addr=1152921509954753512
        // 0x0267A0A8: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x0267A0AC: CBNZ x27, #0x267a0b4       | if (this.blurMaterial != null) goto label_10;
        if(val_11 != null)
        {
            goto label_10;
        }
        // 0x0267A0B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013EC293E0, ????);
        label_10:
        // 0x0267A0B4: LDR x1, [x22]              | X1 = "offsets";                         
        // 0x0267A0B8: LDP s0, s1, [sp, #0x20]    | S0 = 0; S1 = 0;                          //  | 
        // 0x0267A0BC: LDP s2, s3, [sp, #0x28]    | S2 = 0; S3 = 0;                          //  | 
        // 0x0267A0C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0267A0C4: MOV x0, x27                | X0 = this.blurMaterial;//m1             
        // 0x0267A0C8: BL #0x1a79fa8              | this.blurMaterial.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        val_11.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x0267A0CC: LDR x3, [x21, #0x30]       | X3 = this.blurMaterial; //P2            
        // 0x0267A0D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267A0D4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x0267A0D8: MOV x1, x26                | X1 = val_8;//m1                         
        // 0x0267A0DC: MOV x2, x23                | X2 = val_10;//m1                        
        // 0x0267A0E0: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  val_8, mat:  val_12);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_8, mat:  val_12);
        // 0x0267A0E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267A0E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0267A0EC: MOV x1, x26                | X1 = val_8;//m1                         
        // 0x0267A0F0: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x0267A0F4: LDR w8, [x21, #0x20]       | W8 = this.softness; //P2                
        // 0x0267A0F8: ADD w28, w28, #1           | W28 = (0 + 1);                          
        val_12 = val_12 + 1;
        // 0x0267A0FC: CMP w28, w8                | STATE = COMPARE((0 + 1), this.softness) 
        // 0x0267A100: B.LT #0x2679fbc            | if (0 < this.softness) goto label_11;   
        if(val_12 < this.softness)
        {
            goto label_11;
        }
        label_6:
        // 0x0267A104: LDR x24, [x21, #0x50]      | X24 = this.creaseApplyMaterial; //P2    
        // 0x0267A108: LDR x20, [sp, #0x10]       | X20 = source;                           
        // 0x0267A10C: CBNZ x24, #0x267a114       | if (this.creaseApplyMaterial != null) goto label_12;
        if(this.creaseApplyMaterial != null)
        {
            goto label_12;
        }
        // 0x0267A110: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_12:
        // 0x0267A114: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x0267A118: LDR x8, [x8, #0xac0]       | X8 = (string**)(1152921509954729184)("_HrDepthTex");
        // 0x0267A11C: LDR x2, [sp, #0x18]        | X2 = val_1;                             
        // 0x0267A120: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0267A124: MOV x0, x24                | X0 = this.creaseApplyMaterial;//m1      
        // 0x0267A128: LDR x1, [x8]               | X1 = "_HrDepthTex";                     
        // 0x0267A12C: BL #0x1a780c4              | this.creaseApplyMaterial.SetTexture(name:  "_HrDepthTex", value:  val_1);
        this.creaseApplyMaterial.SetTexture(name:  "_HrDepthTex", value:  val_1);
        // 0x0267A130: LDR x24, [x21, #0x50]      | X24 = this.creaseApplyMaterial; //P2    
        // 0x0267A134: LDR x22, [sp, #8]          | X22 = destination;                      
        // 0x0267A138: CBNZ x24, #0x267a140       | if (this.creaseApplyMaterial != null) goto label_13;
        if(this.creaseApplyMaterial != null)
        {
            goto label_13;
        }
        // 0x0267A13C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.creaseApplyMaterial, ????);
        label_13:
        // 0x0267A140: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
        // 0x0267A144: LDR x8, [x8, #0x598]       | X8 = (string**)(1152921509954733376)("_LrDepthTex");
        // 0x0267A148: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0267A14C: MOV x0, x24                | X0 = this.creaseApplyMaterial;//m1      
        // 0x0267A150: MOV x2, x23                | X2 = val_10;//m1                        
        // 0x0267A154: LDR x1, [x8]               | X1 = "_LrDepthTex";                     
        // 0x0267A158: BL #0x1a780c4              | this.creaseApplyMaterial.SetTexture(name:  "_LrDepthTex", value:  val_12);
        this.creaseApplyMaterial.SetTexture(name:  "_LrDepthTex", value:  val_12);
        // 0x0267A15C: LDR x24, [x21, #0x50]      | X24 = this.creaseApplyMaterial; //P2    
        // 0x0267A160: LDR s8, [x21, #0x1c]       | S8 = this.intensity; //P2               
        // 0x0267A164: CBNZ x24, #0x267a16c       | if (this.creaseApplyMaterial != null) goto label_14;
        if(this.creaseApplyMaterial != null)
        {
            goto label_14;
        }
        // 0x0267A168: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.creaseApplyMaterial, ????);
        label_14:
        // 0x0267A16C: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x0267A170: LDR x8, [x8, #0xe80]       | X8 = (string**)(1152921509954117248)("intensity");
        // 0x0267A174: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0267A178: MOV x0, x24                | X0 = this.creaseApplyMaterial;//m1      
        // 0x0267A17C: MOV v0.16b, v8.16b         | V0 = this.intensity;//m1                
        // 0x0267A180: LDR x1, [x8]               | X1 = "intensity";                       
        // 0x0267A184: BL #0x1a79ef8              | this.creaseApplyMaterial.SetFloat(name:  "intensity", value:  this.intensity);
        this.creaseApplyMaterial.SetFloat(name:  "intensity", value:  this.intensity);
        // 0x0267A188: LDR x0, [x19]              | X0 = typeof(UnityEngine.Graphics);      
        // 0x0267A18C: LDR x21, [x21, #0x50]      | X21 = this.creaseApplyMaterial; //P2    
        // 0x0267A190: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x0267A194: TBZ w8, #0, #0x267a1a4     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_16;
        // 0x0267A198: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x0267A19C: CBNZ w8, #0x267a1a4        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
        // 0x0267A1A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_16:
        // 0x0267A1A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267A1A8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x0267A1AC: MOV x1, x20                | X1 = source;//m1                        
        // 0x0267A1B0: MOV x2, x22                | X2 = destination;//m1                   
        // 0x0267A1B4: MOV x3, x21                | X3 = this.creaseApplyMaterial;//m1      
        // 0x0267A1B8: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  destination);
        UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  destination);
        // 0x0267A1BC: LDR x1, [sp, #0x18]        | X1 = val_1;                             
        // 0x0267A1C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267A1C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0267A1C8: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x0267A1CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267A1D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0267A1D4: MOV x1, x23                | X1 = val_10;//m1                        
        // 0x0267A1D8: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x0267A1DC: SUB sp, x29, #0x70         | SP = (1152921509954753648 - 112) = 1152921509954753536 (0x100000013EC29400);
        // 0x0267A1E0: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x0267A1E4: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x0267A1E8: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x0267A1EC: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x0267A1F0: LDP x26, x25, [sp, #0x30]  | X26 = ; X25 = ;                          //  | 
        // 0x0267A1F4: LDP x28, x27, [sp, #0x20]  | X28 = ; X27 = ;                          //  | 
        // 0x0267A1F8: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x0267A1FC: LDP d11, d10, [sp], #0x80  | D11 = ; D10 = ;                          //  | 
        // 0x0267A200: RET                        |  return;                                
        return;
        label_1:
        // 0x0267A204: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x0267A208: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x0267A20C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x0267A210: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x0267A214: TBZ w8, #0, #0x267a224     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_18;
        // 0x0267A218: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x0267A21C: CBNZ w8, #0x267a224        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
        // 0x0267A220: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_18:
        // 0x0267A224: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267A228: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0267A22C: MOV x1, x20                | X1 = source;//m1                        
        // 0x0267A230: MOV x2, x22                | X2 = destination;//m1                   
        // 0x0267A234: SUB sp, x29, #0x70         | SP = (1152921509954753648 - 112) = 1152921509954753536 (0x100000013EC29400);
        // 0x0267A238: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x0267A23C: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x0267A240: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x0267A244: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x0267A248: LDP x26, x25, [sp, #0x30]  | X26 = ; X25 = ;                          //  | 
        // 0x0267A24C: LDP x28, x27, [sp, #0x20]  | X28 = ; X27 = ;                          //  | 
        // 0x0267A250: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x0267A254: LDP d11, d10, [sp], #0x80  | D11 = ; D10 = ;                          //  | 
        // 0x0267A258: B #0x1a6ba68               | UnityEngine.Graphics.Blit(source:  0, dest:  source); return;
        UnityEngine.Graphics.Blit(source:  0, dest:  source);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0267A25C (40346204), len: 4  VirtAddr: 0x0267A25C RVA: 0x0267A25C token: 100663366 methodIndex: 24450 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Main()
    {
        //
        // Disasemble & Code
        // 0x0267A25C: RET                        |  return;                                
        return;
    
    }

}
