using UnityEngine;

namespace Newtonsoft.Json.Bson
{
    internal abstract class BsonToken
    {
        // Fields
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285E8B4
        private Newtonsoft.Json.Bson.BsonToken <Parent>k__BackingField; //  0x00000010
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285E8F0
        private int <CalculatedSize>k__BackingField; //  0x00000018
        
        // Properties
        public abstract Newtonsoft.Json.Bson.BsonType Type { get; }
        public Newtonsoft.Json.Bson.BsonToken Parent { get; set; }
        public int CalculatedSize { get; set; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00ACF7E4 (11335652), len: 8  VirtAddr: 0x00ACF7E4 RVA: 0x00ACF7E4 token: 100684760 methodIndex: 47431 delegateWrapperIndex: 0 methodInvoker: 0
        protected BsonToken()
        {
            //
            // Disasemble & Code
            // 0x00ACF7E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00ACF7E8: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        public abstract Newtonsoft.Json.Bson.BsonType get_Type(); // 0
        //
        // Offset in libil2cpp.so: 0x00AD47DC (11356124), len: 8  VirtAddr: 0x00AD47DC RVA: 0x00AD47DC token: 100684762 methodIndex: 47432 delegateWrapperIndex: 0 methodInvoker: 0
        public Newtonsoft.Json.Bson.BsonToken get_Parent()
        {
            //
            // Disasemble & Code
            // 0x00AD47DC: LDR x0, [x0, #0x10]        | X0 = this.<Parent>k__BackingField; //P2 
            // 0x00AD47E0: RET                        |  return (Newtonsoft.Json.Bson.BsonToken)this.<Parent>k__BackingField;
            return this.<Parent>k__BackingField;
            //  |  // // {name=val_0, type=Newtonsoft.Json.Bson.BsonToken, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00ACF868 (11335784), len: 8  VirtAddr: 0x00ACF868 RVA: 0x00ACF868 token: 100684763 methodIndex: 47433 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_Parent(Newtonsoft.Json.Bson.BsonToken value)
        {
            //
            // Disasemble & Code
            // 0x00ACF868: STR x1, [x0, #0x10]        | this.<Parent>k__BackingField = value;    //  dest_result_addr=1152921513722104000
            this.<Parent>k__BackingField = value;
            // 0x00ACF86C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1790 (11343760), len: 8  VirtAddr: 0x00AD1790 RVA: 0x00AD1790 token: 100684764 methodIndex: 47434 delegateWrapperIndex: 0 methodInvoker: 0
        public int get_CalculatedSize()
        {
            //
            // Disasemble & Code
            // 0x00AD1790: LDR w0, [x0, #0x18]        | W0 = this.<CalculatedSize>k__BackingField; //P2 
            // 0x00AD1794: RET                        |  return (System.Int32)this.<CalculatedSize>k__BackingField;
            return this.<CalculatedSize>k__BackingField;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1B48 (11344712), len: 8  VirtAddr: 0x00AD1B48 RVA: 0x00AD1B48 token: 100684765 methodIndex: 47435 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_CalculatedSize(int value)
        {
            //
            // Disasemble & Code
            // 0x00AD1B48: STR w1, [x0, #0x18]        | this.<CalculatedSize>k__BackingField = value;  //  dest_result_addr=1152921513722332104
            this.<CalculatedSize>k__BackingField = value;
            // 0x00AD1B4C: RET                        |  return;                                
            return;
        
        }
    
    }

}
