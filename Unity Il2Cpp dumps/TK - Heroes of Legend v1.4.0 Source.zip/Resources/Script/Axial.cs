using UnityEngine;
public enum UIUVAni.Axial
{
    // Fields
    X = 0
    ,Y = 1
    

}
