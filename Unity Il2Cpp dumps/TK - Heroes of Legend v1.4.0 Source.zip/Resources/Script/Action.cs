using UnityEngine;
public enum UIKeyBinding.Action
{
    // Fields
    PressAndClick = 0
    ,Select = 1
    ,All = 2
    

}
