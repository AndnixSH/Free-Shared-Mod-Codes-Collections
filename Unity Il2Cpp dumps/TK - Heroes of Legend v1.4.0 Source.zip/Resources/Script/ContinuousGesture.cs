using UnityEngine;
public abstract class ContinuousGesture : Gesture
{
    // Properties
    public ContinuousGesturePhase Phase { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B4333C (11809596), len: 8  VirtAddr: 0x00B4333C RVA: 0x00B4333C token: 100683818 methodIndex: 26670 delegateWrapperIndex: 0 methodInvoker: 0
    protected ContinuousGesture()
    {
        //
        // Disasemble & Code
        // 0x00B4333C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B43340: B #0x287d40c               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B43344 (11809604), len: 64  VirtAddr: 0x00B43344 RVA: 0x00B43344 token: 100683819 methodIndex: 26671 delegateWrapperIndex: 0 methodInvoker: 0
    public ContinuousGesturePhase get_Phase()
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x00B43344: STP x29, x30, [sp, #-0x10]! | stack[1152921513556241728] = ???;  stack[1152921513556241736] = ???;  //  dest_result_addr=1152921513556241728 |  dest_result_addr=1152921513556241736
        // 0x00B43348: MOV x29, sp                | X29 = 1152921513556241728 (0x10000002156CED40);//ML01
        // 0x00B4334C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B43350: BL #0x287d708              | X0 = this.get_State();                  
        GestureRecognitionState val_1 = this.State;
        // 0x00B43354: MOV x8, xzr                | X8 = 0 (0x0);//ML01                     
        val_3 = 0;
        // 0x00B43358: SUB w9, w0, #1             | W9 = (val_1 - 1);                       
        GestureRecognitionState val_2 = val_1 - 1;
        // 0x00B4335C: CMP w9, #3                 | STATE = COMPARE((val_1 - 1), 0x3)       
        // 0x00B43360: B.HI #0xb43370             | if (val_2 > 0x3) goto label_0;          
        if(val_2 > 3)
        {
            goto label_0;
        }
        // 0x00B43364: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B43368: ADD x8, x8, #0xbd0         | X8 = (44638208 + 3024) = 44641232 (0x02A92BD0);
        // 0x00B4336C: LDRSW x8, [x8, w9, sxtw #2] | X8 = 44641232 + ((val_1 - 1)) << 2;     
        val_3 = mem[44641232 + ((val_1 - 1)) << 2];
        val_3 = 44641232 + ((val_1 - 1)) << 2;
        label_0:
        // 0x00B43370: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
        // 0x00B43374: ADD x9, x9, #0xca0         | X9 = (44638208 + 3232) = 44641440 (0x02A92CA0);
        // 0x00B43378: LDR w0, [x9, x8, lsl #2]   | W0 = 44641440 + (44641232 + ((val_1 - 1)) << 2) << 2;
        // 0x00B4337C: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
        // 0x00B43380: RET                        |  return (ContinuousGesturePhase)44641440 + (44641232 + ((val_1 - 1)) << 2) << 2;
        return (ContinuousGesturePhase)44641440 + (44641232 + ((val_1 - 1)) << 2) << 2;
        //  |  // // {name=val_0, type=ContinuousGesturePhase, size=8, nGRN=0 }
    
    }

}
