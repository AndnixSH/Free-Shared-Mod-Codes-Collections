using UnityEngine;

namespace ILRuntime.Mono.Cecil
{
    public sealed class ArrayType : TypeSpecification
    {
        // Fields
        private ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ArrayDimension> dimensions; //  0x00000070
        
        // Properties
        public ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ArrayDimension> Dimensions { get; }
        public int Rank { get; }
        public bool IsVector { get; }
        public override bool IsValueType { get; set; }
        public override string Name { get; }
        public override string FullName { get; }
        private string Suffix { get; }
        public override bool IsArray { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E54050 (15024208), len: 152  VirtAddr: 0x00E54050 RVA: 0x00E54050 token: 100663434 methodIndex: 19262 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ArrayDimension> get_Dimensions()
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ArrayDimension> val_2;
            // 0x00E54050: STP x20, x19, [sp, #-0x20]! | stack[1152921509418400400] = ???;  stack[1152921509418400408] = ???;  //  dest_result_addr=1152921509418400400 |  dest_result_addr=1152921509418400408
            // 0x00E54054: STP x29, x30, [sp, #0x10]  | stack[1152921509418400416] = ???;  stack[1152921509418400424] = ???;  //  dest_result_addr=1152921509418400416 |  dest_result_addr=1152921509418400424
            // 0x00E54058: ADD x29, sp, #0x10         | X29 = (1152921509418400400 + 16) = 1152921509418400416 (0x100000011ECA7AA0);
            // 0x00E5405C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E54060: LDRB w8, [x20, #0xaa7]     | W8 = (bool)static_value_03734AA7;       
            // 0x00E54064: MOV x19, x0                | X19 = 1152921509418412432 (0x100000011ECAA990);//ML01
            // 0x00E54068: TBNZ w8, #0, #0xe54084     | if (static_value_03734AA7 == true) goto label_0;
            // 0x00E5406C: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
            // 0x00E54070: LDR x8, [x8, #0x2d8]       | X8 = 0x2B8E848;                         
            // 0x00E54074: LDR w0, [x8]               | W0 = 0x10D0;                            
            // 0x00E54078: BL #0x2782188              | X0 = sub_2782188( ?? 0x10D0, ????);     
            // 0x00E5407C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E54080: STRB w8, [x20, #0xaa7]     | static_value_03734AA7 = true;            //  dest_result_addr=57887399
            label_0:
            // 0x00E54084: LDR x0, [x19, #0x70]       | X0 = this.dimensions; //P2              
            val_2 = this.dimensions;
            // 0x00E54088: CBNZ x0, #0xe540dc         | if (this.dimensions != null) goto label_1;
            if(val_2 != null)
            {
                goto label_1;
            }
            // 0x00E5408C: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
            // 0x00E54090: LDR x8, [x8, #0xd98]       | X8 = 1152921504736985088;               
            // 0x00E54094: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);
            ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ArrayDimension> val_1 = null;
            // 0x00E54098: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Mono.Collections.Generic.Collection<T>), ????);
            // 0x00E5409C: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x00E540A0: LDR x8, [x8, #0x138]       | X8 = 1152921509418382288;               
            // 0x00E540A4: MOV x20, x0                | X20 = 1152921504736985088 (0x1000000007C1C000);//ML01
            // 0x00E540A8: LDR x1, [x8]               | X1 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ArrayDimension>::.ctor();
            // 0x00E540AC: BL #0x19d45b0              | .ctor();                                
            val_1 = new ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ArrayDimension>();
            // 0x00E540B0: STR x20, [x19, #0x70]      | this.dimensions = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);  //  dest_result_addr=1152921509418412544
            this.dimensions = val_1;
            // 0x00E540B4: CBNZ x20, #0xe540bc        | if ( != 0) goto label_2;                
            if(null != 0)
            {
                goto label_2;
            }
            // 0x00E540B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_2:
            // 0x00E540BC: ADRP x8, #0x367e000        | X8 = 57139200 (0x367E000);              
            // 0x00E540C0: LDR x8, [x8, #0x1e8]       | X8 = 1152921509418383312;               
            // 0x00E540C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E540C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E540CC: MOV x0, x20                | X0 = 1152921504736985088 (0x1000000007C1C000);//ML01
            // 0x00E540D0: LDR x3, [x8]               | X3 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ArrayDimension>::Add(ILRuntime.Mono.Cecil.ArrayDimension item);
            // 0x00E540D4: BL #0x19d4914              | Add(item:  new ILRuntime.Mono.Cecil.ArrayDimension() {lower_bound = new System.Nullable<System.Int32>() {HasValue = false}, upper_bound = new System.Nullable<System.Int32>() {HasValue = false}});
            Add(item:  new ILRuntime.Mono.Cecil.ArrayDimension() {lower_bound = new System.Nullable<System.Int32>() {HasValue = false}, upper_bound = new System.Nullable<System.Int32>() {HasValue = false}});
            // 0x00E540D8: LDR x0, [x19, #0x70]       | X0 = this.dimensions; //P2              
            val_2 = this.dimensions;
            label_1:
            // 0x00E540DC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E540E0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E540E4: RET                        |  return (ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ArrayDimension>)this.dimensions;
            return val_2;
            //  |  // // {name=val_0, type=ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ArrayDimension>, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E540E8 (15024360), len: 100  VirtAddr: 0x00E540E8 RVA: 0x00E540E8 token: 100663435 methodIndex: 19263 delegateWrapperIndex: 0 methodInvoker: 0
        public int get_Rank()
        {
            //
            // Disasemble & Code
            // 0x00E540E8: STP x20, x19, [sp, #-0x20]! | stack[1152921509418525712] = ???;  stack[1152921509418525720] = ???;  //  dest_result_addr=1152921509418525712 |  dest_result_addr=1152921509418525720
            // 0x00E540EC: STP x29, x30, [sp, #0x10]  | stack[1152921509418525728] = ???;  stack[1152921509418525736] = ???;  //  dest_result_addr=1152921509418525728 |  dest_result_addr=1152921509418525736
            // 0x00E540F0: ADD x29, sp, #0x10         | X29 = (1152921509418525712 + 16) = 1152921509418525728 (0x100000011ECC6420);
            // 0x00E540F4: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E540F8: LDRB w8, [x20, #0xaa8]     | W8 = (bool)static_value_03734AA8;       
            // 0x00E540FC: MOV x19, x0                | X19 = 1152921509418537744 (0x100000011ECC9310);//ML01
            // 0x00E54100: TBNZ w8, #0, #0xe5411c     | if (static_value_03734AA8 == true) goto label_0;
            // 0x00E54104: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
            // 0x00E54108: LDR x8, [x8, #0xff8]       | X8 = 0x2B8E858;                         
            // 0x00E5410C: LDR w0, [x8]               | W0 = 0x10D4;                            
            // 0x00E54110: BL #0x2782188              | X0 = sub_2782188( ?? 0x10D4, ????);     
            // 0x00E54114: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E54118: STRB w8, [x20, #0xaa8]     | static_value_03734AA8 = true;            //  dest_result_addr=57887400
            label_0:
            // 0x00E5411C: LDR x0, [x19, #0x70]       | X0 = this.dimensions; //P2              
            // 0x00E54120: CBZ x0, #0xe5413c          | if (this.dimensions == null) goto label_1;
            if(this.dimensions == null)
            {
                goto label_1;
            }
            // 0x00E54124: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
            // 0x00E54128: LDR x8, [x8, #0xa20]       | X8 = 1152921509418512720;               
            // 0x00E5412C: LDR x1, [x8]               | X1 = public System.Int32 ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ArrayDimension>::get_Count();
            // 0x00E54130: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E54134: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E54138: B #0x19d4114               | return this.dimensions.get_Count();     
            return this.dimensions.Count;
            label_1:
            // 0x00E5413C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E54140: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            // 0x00E54144: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E54148: RET                        |  return (System.Int32)1;                
            return (int)1;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5414C (15024460), len: 180  VirtAddr: 0x00E5414C RVA: 0x00E5414C token: 100663436 methodIndex: 19264 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsVector()
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ArrayDimension> val_3;
            //  | 
            var val_4;
            // 0x00E5414C: STP x20, x19, [sp, #-0x20]! | stack[1152921509418651024] = ???;  stack[1152921509418651032] = ???;  //  dest_result_addr=1152921509418651024 |  dest_result_addr=1152921509418651032
            // 0x00E54150: STP x29, x30, [sp, #0x10]  | stack[1152921509418651040] = ???;  stack[1152921509418651048] = ???;  //  dest_result_addr=1152921509418651040 |  dest_result_addr=1152921509418651048
            // 0x00E54154: ADD x29, sp, #0x10         | X29 = (1152921509418651024 + 16) = 1152921509418651040 (0x100000011ECE4DA0);
            // 0x00E54158: SUB sp, sp, #0x10          | SP = (1152921509418651024 - 16) = 1152921509418651008 (0x100000011ECE4D80);
            // 0x00E5415C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E54160: LDRB w8, [x20, #0xaa9]     | W8 = (bool)static_value_03734AA9;       
            // 0x00E54164: MOV x19, x0                | X19 = 1152921509418663056 (0x100000011ECE7C90);//ML01
            val_3 = this;
            // 0x00E54168: TBNZ w8, #0, #0xe54184     | if (static_value_03734AA9 == true) goto label_0;
            // 0x00E5416C: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x00E54170: LDR x8, [x8, #0xef0]       | X8 = 0x2B8E850;                         
            // 0x00E54174: LDR w0, [x8]               | W0 = 0x10D2;                            
            // 0x00E54178: BL #0x2782188              | X0 = sub_2782188( ?? 0x10D2, ????);     
            // 0x00E5417C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E54180: STRB w8, [x20, #0xaa9]     | static_value_03734AA9 = true;            //  dest_result_addr=57887401
            label_0:
            // 0x00E54184: STP xzr, xzr, [sp]         | stack[1152921509418651008] = 0x0;  stack[1152921509418651016] = 0x0;  //  dest_result_addr=1152921509418651008 |  dest_result_addr=1152921509418651016
            // 0x00E54188: LDR x0, [x19, #0x70]       | X0 = this.dimensions; //P2              
            // 0x00E5418C: CBZ x0, #0xe541e0          | if (this.dimensions == null) goto label_1;
            if(this.dimensions == null)
            {
                goto label_1;
            }
            // 0x00E54190: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
            // 0x00E54194: LDR x8, [x8, #0xa20]       | X8 = 1152921509418512720;               
            // 0x00E54198: LDR x1, [x8]               | X1 = public System.Int32 ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ArrayDimension>::get_Count();
            // 0x00E5419C: BL #0x19d4114              | X0 = this.dimensions.get_Count();       
            int val_1 = this.dimensions.Count;
            // 0x00E541A0: CMP w0, #1                 | STATE = COMPARE(val_1, 0x1)             
            // 0x00E541A4: B.GT #0xe541e8             | if (val_1 > 1) goto label_2;            
            if(val_1 > 1)
            {
                goto label_2;
            }
            // 0x00E541A8: LDR x19, [x19, #0x70]      | X19 = this.dimensions; //P2             
            val_3 = this.dimensions;
            // 0x00E541AC: CBNZ x19, #0xe541b4        | if (this.dimensions != null) goto label_3;
            if(val_3 != null)
            {
                goto label_3;
            }
            // 0x00E541B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x00E541B4: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
            // 0x00E541B8: LDR x8, [x8, #0x220]       | X8 = 1152921509418638032;               
            // 0x00E541BC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x00E541C0: MOV x0, x19                | X0 = this.dimensions;//m1               
            // 0x00E541C4: LDR x2, [x8]               | X2 = public ILRuntime.Mono.Cecil.ArrayDimension ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ArrayDimension>::get_Item(int index);
            // 0x00E541C8: BL #0x19d411c              | X0 = this.dimensions.get_Item(index:  0);
            ILRuntime.Mono.Cecil.ArrayDimension val_2 = val_3.Item[0];
            // 0x00E541CC: STP x0, x1, [sp]           | stack[1152921509418651008] = val_2.lower_bound.HasValue; stack[1152921509418651009] = val_2.upper_bound.HasValue;  stack[1152921509418651016] = 0x0;  //  dest_result_addr=1152921509418651008 dest_result_addr=1152921509418651009 |  dest_result_addr=1152921509418651016
            // 0x00E541D0: MOV x0, sp                 | X0 = 1152921509418651008 (0x100000011ECE4D80);//ML01
            // 0x00E541D4: BL #0xe53e54               | X0 = sub_E53E54( ?? 0x100000011ECE4D80, ????);
            // 0x00E541D8: EOR w8, w0, #1             | W8 = ( ^ 1) = 1152921509418651009 (0x100000011ECE4D81);
            // 0x00E541DC: B #0xe541ec                |  goto label_5;                          
            goto label_5;
            label_1:
            // 0x00E541E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            val_4 = 1;
            // 0x00E541E4: B #0xe541ec                |  goto label_5;                          
            goto label_5;
            label_2:
            // 0x00E541E8: MOV w8, wzr                | W8 = 0 (0x0);//ML01                     
            val_4 = 0;
            label_5:
            // 0x00E541EC: AND w0, w8, #1             | W0 = (val_4 & 1);                       
            var val_3 = val_4 & 1;
            // 0x00E541F0: SUB sp, x29, #0x10         | SP = (1152921509418651040 - 16) = 1152921509418651024 (0x100000011ECE4D90);
            // 0x00E541F4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E541F8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E541FC: RET                        |  return (System.Boolean)(val_4 & 1);    
            return (bool)val_3;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E54200 (15024640), len: 8  VirtAddr: 0x00E54200 RVA: 0x00E54200 token: 100663437 methodIndex: 19265 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool get_IsValueType()
        {
            //
            // Disasemble & Code
            // 0x00E54200: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x00E54204: RET                        |  return (System.Boolean)false;          
            return (bool)0;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E54208 (15024648), len: 100  VirtAddr: 0x00E54208 RVA: 0x00E54208 token: 100663438 methodIndex: 19266 delegateWrapperIndex: 0 methodInvoker: 0
        public override void set_IsValueType(bool value)
        {
            //
            // Disasemble & Code
            // 0x00E54208: STP x20, x19, [sp, #-0x20]! | stack[1152921509418884240] = ???;  stack[1152921509418884248] = ???;  //  dest_result_addr=1152921509418884240 |  dest_result_addr=1152921509418884248
            // 0x00E5420C: STP x29, x30, [sp, #0x10]  | stack[1152921509418884256] = ???;  stack[1152921509418884264] = ???;  //  dest_result_addr=1152921509418884256 |  dest_result_addr=1152921509418884264
            // 0x00E54210: ADD x29, sp, #0x10         | X29 = (1152921509418884240 + 16) = 1152921509418884256 (0x100000011ED1DCA0);
            // 0x00E54214: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00E54218: LDRB w8, [x19, #0xaaa]     | W8 = (bool)static_value_03734AAA;       
            // 0x00E5421C: TBNZ w8, #0, #0xe54238     | if (static_value_03734AAA == true) goto label_0;
            // 0x00E54220: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
            // 0x00E54224: LDR x8, [x8, #0xc20]       | X8 = 0x2B8E864;                         
            // 0x00E54228: LDR w0, [x8]               | W0 = 0x10D7;                            
            // 0x00E5422C: BL #0x2782188              | X0 = sub_2782188( ?? 0x10D7, ????);     
            // 0x00E54230: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E54234: STRB w8, [x19, #0xaaa]     | static_value_03734AAA = true;            //  dest_result_addr=57887402
            label_0:
            // 0x00E54238: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x00E5423C: LDR x8, [x8, #0xbd8]       | X8 = 1152921504654397440;               
            // 0x00E54240: LDR x0, [x8]               | X0 = typeof(System.InvalidOperationException);
            System.InvalidOperationException val_1 = null;
            // 0x00E54244: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.InvalidOperationException), ????);
            // 0x00E54248: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E5424C: MOV x19, x0                | X19 = 1152921504654397440 (0x1000000002D59000);//ML01
            // 0x00E54250: BL #0x1e66414              | .ctor();                                
            val_1 = new System.InvalidOperationException();
            // 0x00E54254: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E54258: LDR x8, [x8, #0x3a0]       | X8 = 1152921509418871248;               
            // 0x00E5425C: MOV x0, x19                | X0 = 1152921504654397440 (0x1000000002D59000);//ML01
            // 0x00E54260: LDR x1, [x8]               | X1 = public System.Void ILRuntime.Mono.Cecil.ArrayType::set_IsValueType(bool value);
            // 0x00E54264: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.InvalidOperationException), ????);
            // 0x00E54268: BL #0xe53e30               | X0 = sub_E53E30( ?? typeof(System.InvalidOperationException), ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5426C (15024748), len: 144  VirtAddr: 0x00E5426C RVA: 0x00E5426C token: 100663439 methodIndex: 19267 delegateWrapperIndex: 0 methodInvoker: 0
        public override string get_Name()
        {
            //
            // Disasemble & Code
            // 0x00E5426C: STP x20, x19, [sp, #-0x20]! | stack[1152921509419004432] = ???;  stack[1152921509419004440] = ???;  //  dest_result_addr=1152921509419004432 |  dest_result_addr=1152921509419004440
            // 0x00E54270: STP x29, x30, [sp, #0x10]  | stack[1152921509419004448] = ???;  stack[1152921509419004456] = ???;  //  dest_result_addr=1152921509419004448 |  dest_result_addr=1152921509419004456
            // 0x00E54274: ADD x29, sp, #0x10         | X29 = (1152921509419004432 + 16) = 1152921509419004448 (0x100000011ED3B220);
            // 0x00E54278: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00E5427C: LDRB w8, [x19, #0xaab]     | W8 = (bool)static_value_03734AAB;       
            // 0x00E54280: MOV x20, x0                | X20 = 1152921509419016464 (0x100000011ED3E110);//ML01
            // 0x00E54284: TBNZ w8, #0, #0xe542a0     | if (static_value_03734AAB == true) goto label_0;
            // 0x00E54288: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
            // 0x00E5428C: LDR x8, [x8, #0xfc8]       | X8 = 0x2B8E854;                         
            // 0x00E54290: LDR w0, [x8]               | W0 = 0x10D3;                            
            // 0x00E54294: BL #0x2782188              | X0 = sub_2782188( ?? 0x10D3, ????);     
            // 0x00E54298: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5429C: STRB w8, [x19, #0xaab]     | static_value_03734AAB = true;            //  dest_result_addr=57887403
            label_0:
            // 0x00E542A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E542A4: MOV x0, x20                | X0 = 1152921509419016464 (0x100000011ED3E110);//ML01
            // 0x00E542A8: BL #0x11dfd58              | X0 = this.get_Name();                   
            string val_1 = this.Name;
            // 0x00E542AC: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x00E542B0: MOV x0, x20                | X0 = 1152921509419016464 (0x100000011ED3E110);//ML01
            // 0x00E542B4: BL #0xe542fc               | X0 = this.get_Suffix();                 
            string val_2 = this.Suffix;
            // 0x00E542B8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00E542BC: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00E542C0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00E542C4: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x00E542C8: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00E542CC: TBZ w9, #0, #0xe542e0      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E542D0: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E542D4: CBNZ w9, #0xe542e0         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E542D8: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00E542DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_2:
            // 0x00E542E0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E542E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E542E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E542EC: MOV x1, x19                | X1 = val_1;//m1                         
            // 0x00E542F0: MOV x2, x20                | X2 = val_2;//m1                         
            // 0x00E542F4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E542F8: B #0x18a3e88               | return System.String.Concat(str0:  0, str1:  val_1);
            return System.String.Concat(str0:  0, str1:  val_1);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E544B4 (15025332), len: 144  VirtAddr: 0x00E544B4 RVA: 0x00E544B4 token: 100663440 methodIndex: 19268 delegateWrapperIndex: 0 methodInvoker: 0
        public override string get_FullName()
        {
            //
            // Disasemble & Code
            // 0x00E544B4: STP x20, x19, [sp, #-0x20]! | stack[1152921509419132816] = ???;  stack[1152921509419132824] = ???;  //  dest_result_addr=1152921509419132816 |  dest_result_addr=1152921509419132824
            // 0x00E544B8: STP x29, x30, [sp, #0x10]  | stack[1152921509419132832] = ???;  stack[1152921509419132840] = ???;  //  dest_result_addr=1152921509419132832 |  dest_result_addr=1152921509419132840
            // 0x00E544BC: ADD x29, sp, #0x10         | X29 = (1152921509419132816 + 16) = 1152921509419132832 (0x100000011ED5A7A0);
            // 0x00E544C0: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00E544C4: LDRB w8, [x19, #0xaac]     | W8 = (bool)static_value_03734AAC;       
            // 0x00E544C8: MOV x20, x0                | X20 = 1152921509419144848 (0x100000011ED5D690);//ML01
            // 0x00E544CC: TBNZ w8, #0, #0xe544e8     | if (static_value_03734AAC == true) goto label_0;
            // 0x00E544D0: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x00E544D4: LDR x8, [x8, #0xd88]       | X8 = 0x2B8E84C;                         
            // 0x00E544D8: LDR w0, [x8]               | W0 = 0x10D1;                            
            // 0x00E544DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x10D1, ????);     
            // 0x00E544E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E544E4: STRB w8, [x19, #0xaac]     | static_value_03734AAC = true;            //  dest_result_addr=57887404
            label_0:
            // 0x00E544E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E544EC: MOV x0, x20                | X0 = 1152921509419144848 (0x100000011ED5D690);//ML01
            // 0x00E544F0: BL #0x11dfeb0              | X0 = this.get_FullName();               
            string val_1 = this.FullName;
            // 0x00E544F4: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x00E544F8: MOV x0, x20                | X0 = 1152921509419144848 (0x100000011ED5D690);//ML01
            // 0x00E544FC: BL #0xe542fc               | X0 = this.get_Suffix();                 
            string val_2 = this.Suffix;
            // 0x00E54500: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00E54504: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00E54508: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00E5450C: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x00E54510: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00E54514: TBZ w9, #0, #0xe54528      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E54518: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E5451C: CBNZ w9, #0xe54528         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E54520: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00E54524: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_2:
            // 0x00E54528: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5452C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E54530: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E54534: MOV x1, x19                | X1 = val_1;//m1                         
            // 0x00E54538: MOV x2, x20                | X2 = val_2;//m1                         
            // 0x00E5453C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E54540: B #0x18a3e88               | return System.String.Concat(str0:  0, str1:  val_1);
            return System.String.Concat(str0:  0, str1:  val_1);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E542FC (15024892), len: 440  VirtAddr: 0x00E542FC RVA: 0x00E542FC token: 100663441 methodIndex: 19269 delegateWrapperIndex: 0 methodInvoker: 0
        private string get_Suffix()
        {
            //
            // Disasemble & Code
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            string val_13;
            // 0x00E542FC: STP x26, x25, [sp, #-0x50]! | stack[1152921509419281872] = ???;  stack[1152921509419281880] = ???;  //  dest_result_addr=1152921509419281872 |  dest_result_addr=1152921509419281880
            // 0x00E54300: STP x24, x23, [sp, #0x10]  | stack[1152921509419281888] = ???;  stack[1152921509419281896] = ???;  //  dest_result_addr=1152921509419281888 |  dest_result_addr=1152921509419281896
            // 0x00E54304: STP x22, x21, [sp, #0x20]  | stack[1152921509419281904] = ???;  stack[1152921509419281912] = ???;  //  dest_result_addr=1152921509419281904 |  dest_result_addr=1152921509419281912
            // 0x00E54308: STP x20, x19, [sp, #0x30]  | stack[1152921509419281920] = ???;  stack[1152921509419281928] = ???;  //  dest_result_addr=1152921509419281920 |  dest_result_addr=1152921509419281928
            // 0x00E5430C: STP x29, x30, [sp, #0x40]  | stack[1152921509419281936] = ???;  stack[1152921509419281944] = ???;  //  dest_result_addr=1152921509419281936 |  dest_result_addr=1152921509419281944
            // 0x00E54310: ADD x29, sp, #0x40         | X29 = (1152921509419281872 + 64) = 1152921509419281936 (0x100000011ED7EE10);
            // 0x00E54314: SUB sp, sp, #0x10          | SP = (1152921509419281872 - 16) = 1152921509419281856 (0x100000011ED7EDC0);
            // 0x00E54318: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00E5431C: LDRB w8, [x19, #0xaad]     | W8 = (bool)static_value_03734AAD;       
            // 0x00E54320: MOV x20, x0                | X20 = 1152921509419293952 (0x100000011ED81D00);//ML01
            // 0x00E54324: TBNZ w8, #0, #0xe54340     | if (static_value_03734AAD == true) goto label_0;
            // 0x00E54328: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x00E5432C: LDR x8, [x8, #0xde8]       | X8 = 0x2B8E85C;                         
            // 0x00E54330: LDR w0, [x8]               | W0 = 0x10D5;                            
            // 0x00E54334: BL #0x2782188              | X0 = sub_2782188( ?? 0x10D5, ????);     
            // 0x00E54338: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5433C: STRB w8, [x19, #0xaad]     | static_value_03734AAD = true;            //  dest_result_addr=57887405
            label_0:
            // 0x00E54340: MOV x0, x20                | X0 = 1152921509419293952 (0x100000011ED81D00);//ML01
            // 0x00E54344: STP xzr, xzr, [sp]         | stack[1152921509419281856] = 0x0;  stack[1152921509419281864] = 0x0;  //  dest_result_addr=1152921509419281856 |  dest_result_addr=1152921509419281864
            // 0x00E54348: BL #0xe5414c               | X0 = this.get_IsVector();               
            bool val_1 = this.IsVector;
            // 0x00E5434C: TBZ w0, #0, #0xe54360      | if (val_1 == false) goto label_1;       
            if(val_1 == false)
            {
                goto label_1;
            }
            // 0x00E54350: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x00E54354: LDR x8, [x8, #0x3f8]       | X8 = (string**)(1152921509419241040)("[]");
            // 0x00E54358: LDR x0, [x8]               | X0 = "[]";                              
            val_11 = "[]";
            // 0x00E5435C: B #0xe54498                |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x00E54360: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x00E54364: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
            // 0x00E54368: LDR x0, [x8]               | X0 = typeof(System.Text.StringBuilder); 
            System.Text.StringBuilder val_2 = null;
            // 0x00E5436C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
            // 0x00E54370: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E54374: MOV x19, x0                | X19 = 1152921504649605120 (0x10000000028C7000);//ML01
            val_10 = val_2;
            // 0x00E54378: BL #0x1b5a30c              | .ctor();                                
            val_2 = new System.Text.StringBuilder();
            // 0x00E5437C: CBNZ x19, #0xe54384        | if ( != 0) goto label_3;                
            if(null != 0)
            {
                goto label_3;
            }
            // 0x00E54380: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_3:
            // 0x00E54384: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x00E54388: LDR x8, [x8, #0x430]       | X8 = (string**)(1152921509419241120)("[");
            // 0x00E5438C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E54390: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E54394: LDR x1, [x8]               | X1 = "[";                               
            // 0x00E54398: BL #0x1b5b818              | X0 = Append(value:  "[");               
            System.Text.StringBuilder val_3 = Append(value:  "[");
            // 0x00E5439C: ADRP x23, #0x3610000       | X23 = 56688640 (0x3610000);             
            // 0x00E543A0: ADRP x24, #0x3656000       | X24 = 56975360 (0x3656000);             
            // 0x00E543A4: ADRP x25, #0x3641000       | X25 = 56889344 (0x3641000);             
            // 0x00E543A8: LDR x23, [x23, #0xa20]     | X23 = 1152921509418512720;              
            // 0x00E543AC: LDR x24, [x24, #0x220]     | X24 = 1152921509418638032;              
            // 0x00E543B0: LDR x25, [x25, #0x2d8]     | X25 = (string**)(1152921509408423568)(",");
            // 0x00E543B4: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_12 = 0;
            // 0x00E543B8: B #0xe543d0                |  goto label_4;                          
            goto label_4;
            label_11:
            // 0x00E543BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E543C0: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E543C4: MOV x1, x22                | X1 = X22;//m1                           
            // 0x00E543C8: BL #0x1b5b818              | X0 = Append(value:  X22);               
            System.Text.StringBuilder val_4 = Append(value:  X22);
            // 0x00E543CC: ADD w21, w21, #1           | W21 = (val_12 + 1) = val_12 (0x00000001);
            val_12 = 1;
            label_4:
            // 0x00E543D0: LDR x22, [x20, #0x70]      | X22 = this.dimensions; //P2             
            // 0x00E543D4: CBNZ x22, #0xe543dc        | if (this.dimensions != null) goto label_5;
            if(this.dimensions != null)
            {
                goto label_5;
            }
            // 0x00E543D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_5:
            // 0x00E543DC: LDR x1, [x23]              | X1 = public System.Int32 ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ArrayDimension>::get_Count();
            // 0x00E543E0: MOV x0, x22                | X0 = this.dimensions;//m1               
            // 0x00E543E4: BL #0x19d4114              | X0 = this.dimensions.get_Count();       
            int val_5 = this.dimensions.Count;
            // 0x00E543E8: CMP w21, w0                | STATE = COMPARE(0x1, val_5)             
            // 0x00E543EC: B.GE #0xe54448             | if (val_12 >= val_5) goto label_6;      
            if(val_12 >= val_5)
            {
                goto label_6;
            }
            // 0x00E543F0: CMP w21, #1                | STATE = COMPARE(0x1, 0x1)               
            // 0x00E543F4: B.LT #0xe54410             | if (val_12 < 0x1) goto label_7;         
            if(val_12 < 1)
            {
                goto label_7;
            }
            // 0x00E543F8: CBNZ x19, #0xe54400        | if ( != 0) goto label_8;                
            if(null != 0)
            {
                goto label_8;
            }
            // 0x00E543FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_8:
            // 0x00E54400: LDR x1, [x25]              | X1 = ",";                               
            // 0x00E54404: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E54408: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E5440C: BL #0x1b5b818              | X0 = Append(value:  ",");               
            System.Text.StringBuilder val_6 = Append(value:  ",");
            label_7:
            // 0x00E54410: LDR x22, [x20, #0x70]      | X22 = this.dimensions; //P2             
            // 0x00E54414: CBNZ x22, #0xe5441c        | if (this.dimensions != null) goto label_9;
            if(this.dimensions != null)
            {
                goto label_9;
            }
            // 0x00E54418: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_9:
            // 0x00E5441C: LDR x2, [x24]              | X2 = public ILRuntime.Mono.Cecil.ArrayDimension ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ArrayDimension>::get_Item(int index);
            // 0x00E54420: MOV x0, x22                | X0 = this.dimensions;//m1               
            // 0x00E54424: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
            // 0x00E54428: BL #0x19d411c              | X0 = this.dimensions.get_Item(index:  1);
            ILRuntime.Mono.Cecil.ArrayDimension val_7 = this.dimensions.Item[1];
            // 0x00E5442C: STP x0, x1, [sp]           | stack[1152921509419281856] = val_7.lower_bound.HasValue; stack[1152921509419281857] = val_7.upper_bound.HasValue;  stack[1152921509419281864] = 0x1;  //  dest_result_addr=1152921509419281856 dest_result_addr=1152921509419281857 |  dest_result_addr=1152921509419281864
            // 0x00E54430: MOV x0, sp                 | X0 = 1152921509419281856 (0x100000011ED7EDC0);//ML01
            // 0x00E54434: BL #0xe53ee0               | X0 = sub_E53EE0( ?? 0x100000011ED7EDC0, ????);
            // 0x00E54438: MOV x22, x0                | X22 = 1152921509419281856 (0x100000011ED7EDC0);//ML01
            // 0x00E5443C: CBNZ x19, #0xe543bc        | if ( != 0) goto label_11;               
            if(null != 0)
            {
                goto label_11;
            }
            // 0x00E54440: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000011ED7EDC0, ????);
            // 0x00E54444: B #0xe543bc                |  goto label_11;                         
            goto label_11;
            label_6:
            // 0x00E54448: CBZ x19, #0xe54468         | if ( == 0) goto label_12;               
            if(null == 0)
            {
                goto label_12;
            }
            // 0x00E5444C: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x00E54450: LDR x8, [x8, #0x320]       | X8 = (string**)(1152921509419261680)("]");
            // 0x00E54454: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E54458: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E5445C: LDR x1, [x8]               | X1 = "]";                               
            val_13 = "]";
            // 0x00E54460: BL #0x1b5b818              | X0 = Append(value:  val_13 = "]");      
            System.Text.StringBuilder val_8 = Append(value:  val_13);
            // 0x00E54464: B #0xe54488                |  goto label_13;                         
            goto label_13;
            label_12:
            // 0x00E54468: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            // 0x00E5446C: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x00E54470: LDR x8, [x8, #0x320]       | X8 = (string**)(1152921509419261680)("]");
            // 0x00E54474: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E54478: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E5447C: LDR x1, [x8]               | X1 = "]";                               
            val_13 = "]";
            // 0x00E54480: BL #0x1b5b818              | X0 = Append(value:  val_13 = "]");      
            System.Text.StringBuilder val_9 = Append(value:  val_13);
            // 0x00E54484: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_13:
            // 0x00E54488: LDR x8, [x19]              | X8 = ;                                  
            // 0x00E5448C: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            val_11 = val_10;
            // 0x00E54490: LDP x9, x1, [x8, #0x140]   |                                          //  not_find_field!1:320 |  not_find_field!1:328
            // 0x00E54494: BLR x9                     | X0 = mem[null + 320]();                 
            label_2:
            // 0x00E54498: SUB sp, x29, #0x40         | SP = (1152921509419281936 - 64) = 1152921509419281872 (0x100000011ED7EDD0);
            // 0x00E5449C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00E544A0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00E544A4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00E544A8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00E544AC: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00E544B0: RET                        |  return (System.String)typeof(System.Text.StringBuilder);
            return (string)val_11;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E54544 (15025476), len: 8  VirtAddr: 0x00E54544 RVA: 0x00E54544 token: 100663442 methodIndex: 19270 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool get_IsArray()
        {
            //
            // Disasemble & Code
            // 0x00E54544: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            // 0x00E54548: RET                        |  return (System.Boolean)true;           
            return (bool)1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5454C (15025484), len: 148  VirtAddr: 0x00E5454C RVA: 0x00E5454C token: 100663443 methodIndex: 19271 delegateWrapperIndex: 0 methodInvoker: 0
        public ArrayType(ILRuntime.Mono.Cecil.TypeReference type)
        {
            //
            // Disasemble & Code
            // 0x00E5454C: STP x22, x21, [sp, #-0x30]! | stack[1152921509419538672] = ???;  stack[1152921509419538680] = ???;  //  dest_result_addr=1152921509419538672 |  dest_result_addr=1152921509419538680
            // 0x00E54550: STP x20, x19, [sp, #0x10]  | stack[1152921509419538688] = ???;  stack[1152921509419538696] = ???;  //  dest_result_addr=1152921509419538688 |  dest_result_addr=1152921509419538696
            // 0x00E54554: STP x29, x30, [sp, #0x20]  | stack[1152921509419538704] = ???;  stack[1152921509419538712] = ???;  //  dest_result_addr=1152921509419538704 |  dest_result_addr=1152921509419538712
            // 0x00E54558: ADD x29, sp, #0x20         | X29 = (1152921509419538672 + 32) = 1152921509419538704 (0x100000011EDBD910);
            // 0x00E5455C: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E54560: LDRB w8, [x21, #0xaae]     | W8 = (bool)static_value_03734AAE;       
            // 0x00E54564: MOV x20, x1                | X20 = type;//m1                         
            // 0x00E54568: MOV x19, x0                | X19 = 1152921509419550720 (0x100000011EDC0800);//ML01
            // 0x00E5456C: TBNZ w8, #0, #0xe54588     | if (static_value_03734AAE == true) goto label_0;
            // 0x00E54570: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x00E54574: LDR x8, [x8, #0x370]       | X8 = 0x2B8E838;                         
            // 0x00E54578: LDR w0, [x8]               | W0 = 0x10CC;                            
            // 0x00E5457C: BL #0x2782188              | X0 = sub_2782188( ?? 0x10CC, ????);     
            // 0x00E54580: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E54584: STRB w8, [x21, #0xaae]     | static_value_03734AAE = true;            //  dest_result_addr=57887406
            label_0:
            // 0x00E54588: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E5458C: MOV x0, x19                | X0 = 1152921509419550720 (0x100000011EDC0800);//ML01
            // 0x00E54590: MOV x1, x20                | X1 = type;//m1                          
            // 0x00E54594: BL #0x11e0120              | this..ctor(type:  type);                
            // 0x00E54598: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E5459C: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x00E545A0: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E545A4: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E545A8: TBZ w8, #0, #0xe545b8      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E545AC: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E545B0: CBNZ w8, #0xe545b8         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E545B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_2:
            // 0x00E545B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E545BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E545C0: MOV x1, x20                | X1 = type;//m1                          
            // 0x00E545C4: BL #0x11d28e8              | ILRuntime.Mono.Cecil.Mixin.CheckType(type:  0);
            ILRuntime.Mono.Cecil.Mixin.CheckType(type:  0);
            // 0x00E545C8: MOVZ w8, #0x14             | W8 = 20 (0x14);//ML01                   
            // 0x00E545CC: STRB w8, [x19, #0x50]      | mem[1152921509419550800] = 0x14;         //  dest_result_addr=1152921509419550800
            mem[1152921509419550800] = 20;
            // 0x00E545D0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E545D4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E545D8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E545DC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E545E0 (15025632), len: 260  VirtAddr: 0x00E545E0 RVA: 0x00E545E0 token: 100663444 methodIndex: 19272 delegateWrapperIndex: 0 methodInvoker: 0
        public ArrayType(ILRuntime.Mono.Cecil.TypeReference type, int rank)
        {
            //
            // Disasemble & Code
            //  | 
            int val_2;
            //  | 
            ILRuntime.Mono.Cecil.TypeReference val_3;
            // 0x00E545E0: STP x22, x21, [sp, #-0x30]! | stack[1152921509419663984] = ???;  stack[1152921509419663992] = ???;  //  dest_result_addr=1152921509419663984 |  dest_result_addr=1152921509419663992
            // 0x00E545E4: STP x20, x19, [sp, #0x10]  | stack[1152921509419664000] = ???;  stack[1152921509419664008] = ???;  //  dest_result_addr=1152921509419664000 |  dest_result_addr=1152921509419664008
            // 0x00E545E8: STP x29, x30, [sp, #0x20]  | stack[1152921509419664016] = ???;  stack[1152921509419664024] = ???;  //  dest_result_addr=1152921509419664016 |  dest_result_addr=1152921509419664024
            // 0x00E545EC: ADD x29, sp, #0x20         | X29 = (1152921509419663984 + 32) = 1152921509419664016 (0x100000011EDDC290);
            // 0x00E545F0: ADRP x22, #0x3734000       | X22 = 57884672 (0x3734000);             
            // 0x00E545F4: LDRB w8, [x22, #0xaaf]     | W8 = (bool)static_value_03734AAF;       
            // 0x00E545F8: MOV w19, w2                | W19 = rank;//m1                         
            val_2 = rank;
            // 0x00E545FC: MOV x21, x1                | X21 = type;//m1                         
            val_3 = type;
            // 0x00E54600: MOV x20, x0                | X20 = 1152921509419676032 (0x100000011EDDF180);//ML01
            // 0x00E54604: TBNZ w8, #0, #0xe54620     | if (static_value_03734AAF == true) goto label_0;
            // 0x00E54608: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
            // 0x00E5460C: LDR x8, [x8, #0x730]       | X8 = 0x2B8E83C;                         
            // 0x00E54610: LDR w0, [x8]               | W0 = 0x10CD;                            
            // 0x00E54614: BL #0x2782188              | X0 = sub_2782188( ?? 0x10CD, ????);     
            // 0x00E54618: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5461C: STRB w8, [x22, #0xaaf]     | static_value_03734AAF = true;            //  dest_result_addr=57887407
            label_0:
            // 0x00E54620: MOV x0, x20                | X0 = 1152921509419676032 (0x100000011EDDF180);//ML01
            // 0x00E54624: MOV x1, x21                | X1 = type;//m1                          
            // 0x00E54628: BL #0xe5454c               | this..ctor(type:  val_3);               
            // 0x00E5462C: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E54630: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x00E54634: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E54638: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E5463C: TBZ w8, #0, #0xe5464c      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E54640: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E54644: CBNZ w8, #0xe5464c         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E54648: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_2:
            // 0x00E5464C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E54650: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E54654: MOV x1, x21                | X1 = type;//m1                          
            // 0x00E54658: BL #0x11d28e8              | ILRuntime.Mono.Cecil.Mixin.CheckType(type:  0);
            ILRuntime.Mono.Cecil.Mixin.CheckType(type:  0);
            // 0x00E5465C: CMP w19, #1                | STATE = COMPARE(rank, 0x1)              
            // 0x00E54660: B.EQ #0xe546d4             | if (val_2 == 1) goto label_3;           
            if(val_2 == 1)
            {
                goto label_3;
            }
            // 0x00E54664: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
            // 0x00E54668: LDR x8, [x8, #0xd98]       | X8 = 1152921504736985088;               
            // 0x00E5466C: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);
            ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ArrayDimension> val_1 = null;
            // 0x00E54670: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Mono.Collections.Generic.Collection<T>), ????);
            // 0x00E54674: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x00E54678: LDR x8, [x8, #0xc28]       | X8 = 1152921509419646912;               
            // 0x00E5467C: MOV w1, w19                | W1 = rank;//m1                          
            // 0x00E54680: MOV x21, x0                | X21 = 1152921504736985088 (0x1000000007C1C000);//ML01
            val_3 = val_1;
            // 0x00E54684: LDR x2, [x8]               | X2 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ArrayDimension>::.ctor(int capacity);
            // 0x00E54688: BL #0x19d4660              | .ctor(capacity:  val_2);                
            val_1 = new ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ArrayDimension>(capacity:  val_2);
            // 0x00E5468C: STR x21, [x20, #0x70]      | this.dimensions = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);  //  dest_result_addr=1152921509419676144
            this.dimensions = val_3;
            // 0x00E54690: CMP w19, #1                | STATE = COMPARE(rank, 0x1)              
            // 0x00E54694: B.LT #0xe546cc             | if (val_2 < 1) goto label_4;            
            if(val_2 < 1)
            {
                goto label_4;
            }
            // 0x00E54698: ADRP x22, #0x367e000       | X22 = 57139200 (0x367E000);             
            // 0x00E5469C: LDR x22, [x22, #0x1e8]     | X22 = 1152921509418383312;              
            // 0x00E546A0: B #0xe546a8                |  goto label_5;                          
            goto label_5;
            label_7:
            // 0x00E546A4: LDR x21, [x20, #0x70]      | X21 = this.dimensions; //P2             
            val_3 = this.dimensions;
            label_5:
            // 0x00E546A8: CBNZ x21, #0xe546b0        | if (this.dimensions != null) goto label_6;
            if(val_3 != null)
            {
                goto label_6;
            }
            // 0x00E546AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(capacity:  val_2), ????);
            label_6:
            // 0x00E546B0: LDR x3, [x22]              | X3 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ArrayDimension>::Add(ILRuntime.Mono.Cecil.ArrayDimension item);
            // 0x00E546B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E546B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E546BC: MOV x0, x21                | X0 = this.dimensions;//m1               
            // 0x00E546C0: BL #0x19d4914              | this.dimensions.Add(item:  new ILRuntime.Mono.Cecil.ArrayDimension() {lower_bound = new System.Nullable<System.Int32>() {HasValue = false}, upper_bound = new System.Nullable<System.Int32>() {HasValue = false}});
            val_3.Add(item:  new ILRuntime.Mono.Cecil.ArrayDimension() {lower_bound = new System.Nullable<System.Int32>() {HasValue = false}, upper_bound = new System.Nullable<System.Int32>() {HasValue = false}});
            // 0x00E546C4: SUB w19, w19, #1           | W19 = (rank - 1);                       
            val_2 = val_2 - 1;
            // 0x00E546C8: CBNZ w19, #0xe546a4        | if ((rank - 1) != 0) goto label_7;      
            if(val_2 != 0)
            {
                goto label_7;
            }
            label_4:
            // 0x00E546CC: MOVZ w8, #0x14             | W8 = 20 (0x14);//ML01                   
            // 0x00E546D0: STRB w8, [x20, #0x50]      | mem[1152921509419676112] = 0x14;         //  dest_result_addr=1152921509419676112
            mem[1152921509419676112] = 20;
            label_3:
            // 0x00E546D4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E546D8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E546DC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E546E0: RET                        |  return;                                
            return;
        
        }
    
    }

}
