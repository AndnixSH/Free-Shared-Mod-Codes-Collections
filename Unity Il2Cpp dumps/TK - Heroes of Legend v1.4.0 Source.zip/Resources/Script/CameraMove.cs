using UnityEngine;
public class CameraMove : MonoBehaviour
{
    // Fields
    private const float mDamping = 0.5;
    [UnityEngine.HideInInspector] // 0x286B840
    public UnityEngine.Transform target; //  0x00000018
    private float nearTime; //  0x00000020
    private float farTime; //  0x00000024
    private float mNearTime; //  0x00000028
    private float mFarTime; //  0x0000002C
    private bool bZoomIn; //  0x00000030
    private float curtime; //  0x00000034
    private UnityEngine.Vector3 speed_near; //  0x00000038
    private UnityEngine.Vector3 speed_far; //  0x00000044
    private UnityEngine.Vector3 cameraTarget; //  0x00000050
    public UnityEngine.Vector3 initOffset; //  0x0000005C
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BAD22C (12243500), len: 8  VirtAddr: 0x00BAD22C RVA: 0x00BAD22C token: 100690243 methodIndex: 25705 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraMove()
    {
        //
        // Disasemble & Code
        // 0x00BAD22C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD230: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAD234 (12243508), len: 1124  VirtAddr: 0x00BAD234 RVA: 0x00BAD234 token: 100690244 methodIndex: 25706 delegateWrapperIndex: 0 methodInvoker: 0
    private void LateUpdate()
    {
        //
        // Disasemble & Code
        //  | 
        var val_21;
        //  | 
        var val_22;
        //  | 
        float val_23;
        //  | 
        float val_24;
        //  | 
        float val_25;
        // 0x00BAD234: STP d15, d14, [sp, #-0x70]! | stack[1152921514493568608] = ???;  stack[1152921514493568616] = ???;  //  dest_result_addr=1152921514493568608 |  dest_result_addr=1152921514493568616
        // 0x00BAD238: STP d13, d12, [sp, #0x10]  | stack[1152921514493568624] = ???;  stack[1152921514493568632] = ???;  //  dest_result_addr=1152921514493568624 |  dest_result_addr=1152921514493568632
        // 0x00BAD23C: STP d11, d10, [sp, #0x20]  | stack[1152921514493568640] = ???;  stack[1152921514493568648] = ???;  //  dest_result_addr=1152921514493568640 |  dest_result_addr=1152921514493568648
        // 0x00BAD240: STP d9, d8, [sp, #0x30]    | stack[1152921514493568656] = ???;  stack[1152921514493568664] = ???;  //  dest_result_addr=1152921514493568656 |  dest_result_addr=1152921514493568664
        // 0x00BAD244: STP x22, x21, [sp, #0x40]  | stack[1152921514493568672] = ???;  stack[1152921514493568680] = ???;  //  dest_result_addr=1152921514493568672 |  dest_result_addr=1152921514493568680
        // 0x00BAD248: STP x20, x19, [sp, #0x50]  | stack[1152921514493568688] = ???;  stack[1152921514493568696] = ???;  //  dest_result_addr=1152921514493568688 |  dest_result_addr=1152921514493568696
        // 0x00BAD24C: STP x29, x30, [sp, #0x60]  | stack[1152921514493568704] = ???;  stack[1152921514493568712] = ???;  //  dest_result_addr=1152921514493568704 |  dest_result_addr=1152921514493568712
        // 0x00BAD250: ADD x29, sp, #0x60         | X29 = (1152921514493568608 + 96) = 1152921514493568704 (0x100000024D4B66C0);
        // 0x00BAD254: SUB sp, sp, #0x10          | SP = (1152921514493568608 - 16) = 1152921514493568592 (0x100000024D4B6650);
        // 0x00BAD258: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BAD25C: LDRB w8, [x20, #0xb05]     | W8 = (bool)static_value_03733B05;       
        // 0x00BAD260: MOV x19, x0                | X19 = 1152921514493580720 (0x100000024D4B95B0);//ML01
        // 0x00BAD264: TBNZ w8, #0, #0xbad280     | if (static_value_03733B05 == true) goto label_0;
        // 0x00BAD268: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
        // 0x00BAD26C: LDR x8, [x8, #0x2b8]       | X8 = 0x2B90258;                         
        // 0x00BAD270: LDR w0, [x8]               | W0 = 0x175A;                            
        // 0x00BAD274: BL #0x2782188              | X0 = sub_2782188( ?? 0x175A, ????);     
        // 0x00BAD278: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAD27C: STRB w8, [x20, #0xb05]     | static_value_03733B05 = true;            //  dest_result_addr=57883397
        label_0:
        // 0x00BAD280: ADRP x20, #0x3611000       | X20 = 56692736 (0x3611000);             
        // 0x00BAD284: LDR x20, [x20, #0x430]     | X20 = 1152921504887730176;              
        // 0x00BAD288: LDR x0, [x20]              | X0 = typeof(CameraHelper);              
        val_21 = null;
        // 0x00BAD28C: LDRB w8, [x0, #0x10a]      | W8 = CameraHelper.__il2cppRuntimeField_10A;
        // 0x00BAD290: TBZ w8, #0, #0xbad2a4      | if (CameraHelper.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BAD294: LDR w8, [x0, #0xbc]        | W8 = CameraHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00BAD298: CBNZ w8, #0xbad2a4         | if (CameraHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BAD29C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraHelper), ????);
        // 0x00BAD2A0: LDR x0, [x20]              | X0 = typeof(CameraHelper);              
        val_21 = null;
        label_2:
        // 0x00BAD2A4: LDR x8, [x0, #0xa0]        | X8 = CameraHelper.__il2cppRuntimeField_static_fields;
        // 0x00BAD2A8: LDR x20, [x8]              | X20 = CameraHelper.instance;            
        // 0x00BAD2AC: CBNZ x20, #0xbad2b4        | if (CameraHelper.instance != null) goto label_3;
        if(CameraHelper.instance != null)
        {
            goto label_3;
        }
        // 0x00BAD2B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraHelper), ????);
        label_3:
        // 0x00BAD2B4: LDRB w8, [x20, #0x78]      | W8 = CameraHelper.instance.motionBluring;
        // 0x00BAD2B8: CBNZ w8, #0xbad5a4         | if (CameraHelper.instance.motionBluring == true) goto label_10;
        if(CameraHelper.instance.motionBluring == true)
        {
            goto label_10;
        }
        // 0x00BAD2BC: LDR s8, [x19, #0x34]       | S8 = this.curtime; //P2                 
        // 0x00BAD2C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD2C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD2C8: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_1 = UnityEngine.Time.deltaTime;
        // 0x00BAD2CC: LDRB w21, [x19, #0x30]     | W21 = this.bZoomIn; //P2                
        // 0x00BAD2D0: FADD s0, s8, s0            | S0 = (this.curtime + val_1);            
        val_1 = this.curtime + val_1;
        // 0x00BAD2D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD2D8: MOV x0, x19                | X0 = 1152921514493580720 (0x100000024D4B95B0);//ML01
        // 0x00BAD2DC: STR s0, [x19, #0x34]       | this.curtime = (this.curtime + val_1);   //  dest_result_addr=1152921514493580772
        this.curtime = val_1;
        // 0x00BAD2E0: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_2 = this.transform;
        // 0x00BAD2E4: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00BAD2E8: CBNZ x20, #0xbad2f0        | if (val_2 != null) goto label_5;        
        if(val_2 != null)
        {
            goto label_5;
        }
        // 0x00BAD2EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x00BAD2F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD2F4: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00BAD2F8: BL #0x2693654              | X0 = val_2.get_localPosition();         
        UnityEngine.Vector3 val_3 = val_2.localPosition;
        // 0x00BAD2FC: MOV v10.16b, v0.16b        | V10 = val_3.x;//m1                      
        // 0x00BAD300: MOV v9.16b, v1.16b         | V9 = val_3.y;//m1                       
        // 0x00BAD304: STR s2, [sp, #0xc]         | stack[1152921514493568604] = val_3.z;    //  dest_result_addr=1152921514493568604
        // 0x00BAD308: CBZ w21, #0xbad470         | if (this.bZoomIn == false) goto label_6;
        if(this.bZoomIn == false)
        {
            goto label_6;
        }
        // 0x00BAD30C: LDP s11, s12, [x19, #0x38] | S11 = this.speed_near; //P2              //  | 
        // 0x00BAD310: LDR s13, [x19, #0x40]      | 
        // 0x00BAD314: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD318: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD31C: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_4 = UnityEngine.Time.deltaTime;
        // 0x00BAD320: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BAD324: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BAD328: MOV v14.16b, v0.16b        | V14 = val_4;//m1                        
        // 0x00BAD32C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAD330: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BAD334: TBZ w8, #0, #0xbad344      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00BAD338: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAD33C: CBNZ w8, #0xbad344         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00BAD340: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_8:
        // 0x00BAD344: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD348: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD34C: MOV v0.16b, v11.16b        | V0 = this.speed_near;//m1               
        // 0x00BAD350: MOV v1.16b, v12.16b        | V1 = V12.16B;//m1                       
        // 0x00BAD354: MOV v2.16b, v13.16b        | V2 = V13.16B;//m1                       
        // 0x00BAD358: MOV v3.16b, v14.16b        | V3 = val_4;//m1                         
        // 0x00BAD35C: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = this.speed_near, y = V12.16B, z = V13.16B}, d:  val_4);
        UnityEngine.Vector3 val_5 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = this.speed_near, y = V12.16B, z = V13.16B}, d:  val_4);
        // 0x00BAD360: LDP s13, s14, [x19, #0x38] | S13 = this.speed_near; //P2              //  | 
        // 0x00BAD364: LDR s15, [x19, #0x40]      | 
        // 0x00BAD368: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD36C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD370: MOV v11.16b, v0.16b        | V11 = val_5.x;//m1                      
        // 0x00BAD374: MOV v12.16b, v1.16b        | V12 = val_5.y;//m1                      
        val_23 = val_5.y;
        // 0x00BAD378: MOV v8.16b, v2.16b         | V8 = val_5.z;//m1                       
        // 0x00BAD37C: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_6 = UnityEngine.Time.deltaTime;
        // 0x00BAD380: MOV v3.16b, v0.16b         | V3 = val_6;//m1                         
        // 0x00BAD384: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD388: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD38C: MOV v0.16b, v13.16b        | V0 = this.speed_near;//m1               
        // 0x00BAD390: MOV v1.16b, v14.16b        | V1 = val_4;//m1                         
        // 0x00BAD394: MOV v2.16b, v15.16b        | V2 = V15.16B;//m1                       
        // 0x00BAD398: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = this.speed_near, y = val_4, z = V15.16B}, d:  val_6);
        UnityEngine.Vector3 val_7 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = this.speed_near, y = val_4, z = V15.16B}, d:  val_6);
        // 0x00BAD39C: LDR s3, [x19, #0x34]       | S3 = this.curtime; //P2                 
        float val_21 = this.curtime;
        // 0x00BAD3A0: LDR s4, [x19, #0x28]       | S4 = this.mNearTime; //P2               
        // 0x00BAD3A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD3A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD3AC: FDIV s3, s3, s4            | S3 = (this.curtime / this.mNearTime);   
        val_21 = val_21 / this.mNearTime;
        // 0x00BAD3B0: FMOV s4, #1.00000000       | S4 = 1;                                 
        // 0x00BAD3B4: FSUB s3, s4, s3            | S3 = (1f - (this.curtime / this.mNearTime));
        val_21 = 1f - val_21;
        // 0x00BAD3B8: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z}, d:  this.curtime = 1f - this.curtime);
        UnityEngine.Vector3 val_8 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z}, d:  val_21);
        // 0x00BAD3BC: MOV v3.16b, v0.16b         | V3 = val_8.x;//m1                       
        // 0x00BAD3C0: MOV v4.16b, v1.16b         | V4 = val_8.y;//m1                       
        // 0x00BAD3C4: MOV v5.16b, v2.16b         | V5 = val_8.z;//m1                       
        // 0x00BAD3C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD3CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD3D0: MOV v0.16b, v11.16b        | V0 = val_5.x;//m1                       
        // 0x00BAD3D4: MOV v1.16b, v12.16b        | V1 = val_5.y;//m1                       
        // 0x00BAD3D8: MOV v2.16b, v8.16b         | V2 = val_5.z;//m1                       
        // 0x00BAD3DC: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_5.x, y = val_23, z = val_5.z}, b:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z});
        UnityEngine.Vector3 val_9 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_5.x, y = val_23, z = val_5.z}, b:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z});
        // 0x00BAD3E0: MOV v5.16b, v2.16b         | V5 = val_9.z;//m1                       
        // 0x00BAD3E4: LDR s2, [sp, #0xc]         | S2 = val_3.z;                           
        // 0x00BAD3E8: MOV v3.16b, v0.16b         | V3 = val_9.x;//m1                       
        // 0x00BAD3EC: MOV v4.16b, v1.16b         | V4 = val_9.y;//m1                       
        // 0x00BAD3F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD3F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD3F8: MOV v0.16b, v10.16b        | V0 = val_3.x;//m1                       
        // 0x00BAD3FC: MOV v1.16b, v9.16b         | V1 = val_3.y;//m1                       
        // 0x00BAD400: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}, b:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z});
        UnityEngine.Vector3 val_10 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}, b:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z});
        // 0x00BAD404: MOV v8.16b, v0.16b         | V8 = val_10.x;//m1                      
        val_24 = val_10.x;
        // 0x00BAD408: MOV v9.16b, v1.16b         | V9 = val_10.y;//m1                      
        // 0x00BAD40C: MOV v10.16b, v2.16b        | V10 = val_10.z;//m1                     
        val_25 = val_10.z;
        // 0x00BAD410: CBNZ x20, #0xbad418        | if (val_2 != null) goto label_9;        
        if(val_2 != null)
        {
            goto label_9;
        }
        // 0x00BAD414: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_9:
        // 0x00BAD418: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD41C: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00BAD420: MOV v0.16b, v8.16b         | V0 = val_10.x;//m1                      
        // 0x00BAD424: MOV v1.16b, v9.16b         | V1 = val_10.y;//m1                      
        // 0x00BAD428: MOV v2.16b, v10.16b        | V2 = val_10.z;//m1                      
        // 0x00BAD42C: BL #0x26936fc              | val_2.set_localPosition(value:  new UnityEngine.Vector3() {x = val_24, y = val_10.y, z = val_25});
        val_2.localPosition = new UnityEngine.Vector3() {x = val_24, y = val_10.y, z = val_25};
        // 0x00BAD430: LDR s0, [x19, #0x34]       | S0 = this.curtime; //P2                 
        // 0x00BAD434: LDR s1, [x19, #0x20]       | S1 = this.nearTime; //P2                
        // 0x00BAD438: FCMP s0, s1                | STATE = COMPARE(this.curtime, this.nearTime)
        // 0x00BAD43C: B.LT #0xbad5a4             | if (this.curtime < this.nearTime) goto label_10;
        if(this.curtime < this.nearTime)
        {
            goto label_10;
        }
        // 0x00BAD440: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BAD444: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAD448: MOV x0, x19                | X0 = 1152921514493580720 (0x100000024D4B95B0);//ML01
        // 0x00BAD44C: SUB sp, x29, #0x60         | SP = (1152921514493568704 - 96) = 1152921514493568608 (0x100000024D4B6660);
        // 0x00BAD450: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAD454: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAD458: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00BAD45C: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00BAD460: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00BAD464: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00BAD468: LDP d15, d14, [sp], #0x70  | D15 = ; D14 = ;                          //  | 
        // 0x00BAD46C: B #0x20cb458               | this.set_enabled(value:  false); return;
        this.enabled = false;
        return;
        label_6:
        // 0x00BAD470: LDP s11, s12, [x19, #0x44] | S11 = this.speed_far; //P2               //  | 
        // 0x00BAD474: LDR s13, [x19, #0x4c]      | 
        // 0x00BAD478: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD47C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD480: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_11 = UnityEngine.Time.deltaTime;
        // 0x00BAD484: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BAD488: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BAD48C: MOV v14.16b, v0.16b        | V14 = val_11;//m1                       
        // 0x00BAD490: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAD494: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BAD498: TBZ w8, #0, #0xbad4a8      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00BAD49C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAD4A0: CBNZ w8, #0xbad4a8         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00BAD4A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_12:
        // 0x00BAD4A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD4AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD4B0: MOV v0.16b, v11.16b        | V0 = this.speed_far;//m1                
        // 0x00BAD4B4: MOV v1.16b, v12.16b        | V1 = V12.16B;//m1                       
        // 0x00BAD4B8: MOV v2.16b, v13.16b        | V2 = V13.16B;//m1                       
        // 0x00BAD4BC: MOV v3.16b, v14.16b        | V3 = val_11;//m1                        
        // 0x00BAD4C0: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = this.speed_far, y = V12.16B, z = V13.16B}, d:  val_11);
        UnityEngine.Vector3 val_12 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = this.speed_far, y = V12.16B, z = V13.16B}, d:  val_11);
        // 0x00BAD4C4: LDP s12, s13, [x19, #0x44] | S12 = this.speed_far; //P2               //  | 
        val_23 = this.speed_far;
        // 0x00BAD4C8: LDR s14, [x19, #0x4c]      | 
        // 0x00BAD4CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD4D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD4D4: MOV v8.16b, v0.16b         | V8 = val_12.x;//m1                      
        // 0x00BAD4D8: MOV v11.16b, v1.16b        | V11 = val_12.y;//m1                     
        // 0x00BAD4DC: MOV v15.16b, v2.16b        | V15 = val_12.z;//m1                     
        // 0x00BAD4E0: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_13 = UnityEngine.Time.deltaTime;
        // 0x00BAD4E4: MOV v3.16b, v0.16b         | V3 = val_13;//m1                        
        // 0x00BAD4E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD4EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD4F0: MOV v0.16b, v12.16b        | V0 = this.speed_far;//m1                
        // 0x00BAD4F4: MOV v1.16b, v13.16b        | V1 = V13.16B;//m1                       
        // 0x00BAD4F8: MOV v2.16b, v14.16b        | V2 = val_11;//m1                        
        // 0x00BAD4FC: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_23, y = V13.16B, z = val_11}, d:  val_13);
        UnityEngine.Vector3 val_14 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_23, y = V13.16B, z = val_11}, d:  val_13);
        // 0x00BAD500: LDR s3, [x19, #0x34]       | S3 = this.curtime; //P2                 
        float val_22 = this.curtime;
        // 0x00BAD504: LDR s4, [x19, #0x2c]       | S4 = this.mFarTime; //P2                
        // 0x00BAD508: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD50C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD510: FDIV s3, s3, s4            | S3 = (this.curtime / this.mFarTime);    
        val_22 = val_22 / this.mFarTime;
        // 0x00BAD514: FMOV s4, #1.00000000       | S4 = 1;                                 
        // 0x00BAD518: FSUB s3, s4, s3            | S3 = (1f - (this.curtime / this.mFarTime));
        val_22 = 1f - val_22;
        // 0x00BAD51C: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_14.x, y = val_14.y, z = val_14.z}, d:  this.curtime = 1f - this.curtime);
        UnityEngine.Vector3 val_15 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_14.x, y = val_14.y, z = val_14.z}, d:  val_22);
        // 0x00BAD520: MOV v3.16b, v0.16b         | V3 = val_15.x;//m1                      
        // 0x00BAD524: MOV v4.16b, v1.16b         | V4 = val_15.y;//m1                      
        // 0x00BAD528: MOV v5.16b, v2.16b         | V5 = val_15.z;//m1                      
        // 0x00BAD52C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD530: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD534: MOV v0.16b, v8.16b         | V0 = val_12.x;//m1                      
        // 0x00BAD538: MOV v1.16b, v11.16b        | V1 = val_12.y;//m1                      
        // 0x00BAD53C: MOV v2.16b, v15.16b        | V2 = val_12.z;//m1                      
        // 0x00BAD540: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.y, z = val_12.z}, b:  new UnityEngine.Vector3() {x = val_15.x, y = val_15.y, z = val_15.z});
        UnityEngine.Vector3 val_16 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.y, z = val_12.z}, b:  new UnityEngine.Vector3() {x = val_15.x, y = val_15.y, z = val_15.z});
        // 0x00BAD544: MOV v5.16b, v2.16b         | V5 = val_16.z;//m1                      
        // 0x00BAD548: LDR s2, [sp, #0xc]         | S2 = val_3.z;                           
        // 0x00BAD54C: MOV v3.16b, v0.16b         | V3 = val_16.x;//m1                      
        // 0x00BAD550: MOV v4.16b, v1.16b         | V4 = val_16.y;//m1                      
        // 0x00BAD554: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD558: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD55C: MOV v0.16b, v10.16b        | V0 = val_3.x;//m1                       
        // 0x00BAD560: MOV v1.16b, v9.16b         | V1 = val_3.y;//m1                       
        // 0x00BAD564: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}, b:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z});
        UnityEngine.Vector3 val_17 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}, b:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z});
        // 0x00BAD568: MOV v8.16b, v0.16b         | V8 = val_17.x;//m1                      
        val_24 = val_17.x;
        // 0x00BAD56C: MOV v9.16b, v1.16b         | V9 = val_17.y;//m1                      
        // 0x00BAD570: MOV v10.16b, v2.16b        | V10 = val_17.z;//m1                     
        val_25 = val_17.z;
        // 0x00BAD574: CBNZ x20, #0xbad57c        | if (val_2 != null) goto label_13;       
        if(val_2 != null)
        {
            goto label_13;
        }
        // 0x00BAD578: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_13:
        // 0x00BAD57C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD580: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00BAD584: MOV v0.16b, v8.16b         | V0 = val_17.x;//m1                      
        // 0x00BAD588: MOV v1.16b, v9.16b         | V1 = val_17.y;//m1                      
        // 0x00BAD58C: MOV v2.16b, v10.16b        | V2 = val_17.z;//m1                      
        // 0x00BAD590: BL #0x26936fc              | val_2.set_localPosition(value:  new UnityEngine.Vector3() {x = val_24, y = val_17.y, z = val_25});
        val_2.localPosition = new UnityEngine.Vector3() {x = val_24, y = val_17.y, z = val_25};
        // 0x00BAD594: LDR s0, [x19, #0x34]       | S0 = this.curtime; //P2                 
        // 0x00BAD598: LDR s1, [x19, #0x24]       | S1 = this.farTime; //P2                 
        // 0x00BAD59C: FCMP s0, s1                | STATE = COMPARE(this.curtime, this.farTime)
        // 0x00BAD5A0: B.GE #0xbad5c8             | if (this.curtime >= this.farTime) goto label_14;
        if(this.curtime >= this.farTime)
        {
            goto label_14;
        }
        label_10:
        // 0x00BAD5A4: SUB sp, x29, #0x60         | SP = (1152921514493568704 - 96) = 1152921514493568608 (0x100000024D4B6660);
        // 0x00BAD5A8: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAD5AC: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAD5B0: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00BAD5B4: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00BAD5B8: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00BAD5BC: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00BAD5C0: LDP d15, d14, [sp], #0x70  | D15 = ; D14 = ;                          //  | 
        // 0x00BAD5C4: RET                        |  return;                                
        return;
        label_14:
        // 0x00BAD5C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD5CC: MOV x0, x19                | X0 = 1152921514493580720 (0x100000024D4B95B0);//ML01
        // 0x00BAD5D0: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_18 = this.transform;
        // 0x00BAD5D4: LDP s8, s9, [x19, #0x50]   | S8 = this.cameraTarget; //P2             //  | 
        // 0x00BAD5D8: LDR s10, [x19, #0x58]      | 
        // 0x00BAD5DC: MOV x20, x0                | X20 = val_18;//m1                       
        // 0x00BAD5E0: CBNZ x20, #0xbad5e8        | if (val_18 != null) goto label_15;      
        if(val_18 != null)
        {
            goto label_15;
        }
        // 0x00BAD5E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_15:
        // 0x00BAD5E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD5EC: MOV x0, x20                | X0 = val_18;//m1                        
        // 0x00BAD5F0: MOV v0.16b, v8.16b         | V0 = this.cameraTarget;//m1             
        // 0x00BAD5F4: MOV v1.16b, v9.16b         | V1 = val_17.y;//m1                      
        // 0x00BAD5F8: MOV v2.16b, v10.16b        | V2 = val_17.z;//m1                      
        // 0x00BAD5FC: BL #0x26936fc              | val_18.set_localPosition(value:  new UnityEngine.Vector3() {x = this.cameraTarget, y = val_17.y, z = val_25});
        val_18.localPosition = new UnityEngine.Vector3() {x = this.cameraTarget, y = val_17.y, z = val_25};
        // 0x00BAD600: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD604: MOV x0, x19                | X0 = 1152921514493580720 (0x100000024D4B95B0);//ML01
        // 0x00BAD608: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_19 = this.gameObject;
        // 0x00BAD60C: MOV x20, x0                | X20 = val_19;//m1                       
        // 0x00BAD610: CBNZ x20, #0xbad618        | if (val_19 != null) goto label_16;      
        if(val_19 != null)
        {
            goto label_16;
        }
        // 0x00BAD614: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_16:
        // 0x00BAD618: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
        // 0x00BAD61C: LDR x8, [x8, #0xb0]        | X8 = 1152921514493551600;               
        // 0x00BAD620: MOV x0, x20                | X0 = val_19;//m1                        
        // 0x00BAD624: LDR x1, [x8]               | X1 = public CameraSmoothFollow UnityEngine.GameObject::GetComponent<CameraSmoothFollow>();
        // 0x00BAD628: BL #0x23d5abc              | X0 = val_19.GetComponent<CameraSmoothFollow>();
        CameraSmoothFollow val_20 = val_19.GetComponent<CameraSmoothFollow>();
        // 0x00BAD62C: MOV x20, x0                | X20 = val_20;//m1                       
        // 0x00BAD630: CBNZ x20, #0xbad638        | if (val_20 != null) goto label_17;      
        if(val_20 != null)
        {
            goto label_17;
        }
        // 0x00BAD634: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_17:
        // 0x00BAD638: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAD63C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BAD640: MOV x0, x20                | X0 = val_20;//m1                        
        // 0x00BAD644: BL #0x20cb458              | val_20.set_enabled(value:  true);       
        val_20.enabled = true;
        // 0x00BAD648: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00BAD64C: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00BAD650: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00BAD654: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00BAD658: TBZ w8, #0, #0xbad668      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_19;
        // 0x00BAD65C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00BAD660: CBNZ w8, #0xbad668         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
        // 0x00BAD664: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_19:
        // 0x00BAD668: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD66C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAD670: MOV x1, x19                | X1 = 1152921514493580720 (0x100000024D4B95B0);//ML01
        // 0x00BAD674: SUB sp, x29, #0x60         | SP = (1152921514493568704 - 96) = 1152921514493568608 (0x100000024D4B6660);
        // 0x00BAD678: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAD67C: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAD680: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00BAD684: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00BAD688: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00BAD68C: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00BAD690: LDP d15, d14, [sp], #0x70  | D15 = ; D14 = ;                          //  | 
        // 0x00BAD694: B #0x1b78acc               | UnityEngine.Object.Destroy(obj:  0); return;
        UnityEngine.Object.Destroy(obj:  0);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAAE80 (12234368), len: 496  VirtAddr: 0x00BAAE80 RVA: 0x00BAAE80 token: 100690245 methodIndex: 25707 delegateWrapperIndex: 0 methodInvoker: 0
    public void NearBy(UnityEngine.Transform target, float nearTime, float farTime, UnityEngine.Vector3 zoominoffset)
    {
        //
        // Disasemble & Code
        // 0x00BAAE80: STP d15, d14, [sp, #-0x70]! | stack[1152921514493713376] = ???;  stack[1152921514493713384] = ???;  //  dest_result_addr=1152921514493713376 |  dest_result_addr=1152921514493713384
        // 0x00BAAE84: STP d13, d12, [sp, #0x10]  | stack[1152921514493713392] = ???;  stack[1152921514493713400] = ???;  //  dest_result_addr=1152921514493713392 |  dest_result_addr=1152921514493713400
        // 0x00BAAE88: STP d11, d10, [sp, #0x20]  | stack[1152921514493713408] = ???;  stack[1152921514493713416] = ???;  //  dest_result_addr=1152921514493713408 |  dest_result_addr=1152921514493713416
        // 0x00BAAE8C: STP d9, d8, [sp, #0x30]    | stack[1152921514493713424] = ???;  stack[1152921514493713432] = ???;  //  dest_result_addr=1152921514493713424 |  dest_result_addr=1152921514493713432
        // 0x00BAAE90: STP x22, x21, [sp, #0x40]  | stack[1152921514493713440] = ???;  stack[1152921514493713448] = ???;  //  dest_result_addr=1152921514493713440 |  dest_result_addr=1152921514493713448
        // 0x00BAAE94: STP x20, x19, [sp, #0x50]  | stack[1152921514493713456] = ???;  stack[1152921514493713464] = ???;  //  dest_result_addr=1152921514493713456 |  dest_result_addr=1152921514493713464
        // 0x00BAAE98: STP x29, x30, [sp, #0x60]  | stack[1152921514493713472] = ???;  stack[1152921514493713480] = ???;  //  dest_result_addr=1152921514493713472 |  dest_result_addr=1152921514493713480
        // 0x00BAAE9C: ADD x29, sp, #0x60         | X29 = (1152921514493713376 + 96) = 1152921514493713472 (0x100000024D4D9C40);
        // 0x00BAAEA0: SUB sp, sp, #0x10          | SP = (1152921514493713376 - 16) = 1152921514493713360 (0x100000024D4D9BD0);
        // 0x00BAAEA4: STP s3, s4, [sp, #8]       | stack[1152921514493713368] = zoominoffset.y;  stack[1152921514493713372] = zoominoffset.z;  //  dest_result_addr=1152921514493713368 |  dest_result_addr=1152921514493713372
        // 0x00BAAEA8: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00BAAEAC: LDRB w8, [x21, #0xb06]     | W8 = (bool)static_value_03733B06;       
        // 0x00BAAEB0: MOV v11.16b, v2.16b        | V11 = zoominoffset.x;//m1               
        // 0x00BAAEB4: MOV v12.16b, v1.16b        | V12 = farTime;//m1                      
        // 0x00BAAEB8: MOV v8.16b, v0.16b         | V8 = nearTime;//m1                      
        // 0x00BAAEBC: MOV x20, x1                | X20 = target;//m1                       
        // 0x00BAAEC0: MOV x19, x0                | X19 = 1152921514493725488 (0x100000024D4DCB30);//ML01
        // 0x00BAAEC4: TBNZ w8, #0, #0xbaaee0     | if (static_value_03733B06 == true) goto label_0;
        // 0x00BAAEC8: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00BAAECC: LDR x8, [x8, #0x880]       | X8 = 0x2B9025C;                         
        // 0x00BAAED0: LDR w0, [x8]               | W0 = 0x175B;                            
        // 0x00BAAED4: BL #0x2782188              | X0 = sub_2782188( ?? 0x175B, ????);     
        // 0x00BAAED8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAAEDC: STRB w8, [x21, #0xb06]     | static_value_03733B06 = true;            //  dest_result_addr=57883398
        label_0:
        // 0x00BAAEE0: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BAAEE4: MOV x0, x19                | X0 = 1152921514493725488 (0x100000024D4DCB30);//ML01
        // 0x00BAAEE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAAEEC: ORR w21, wzr, #1           | W21 = 1(0x1);                           
        // 0x00BAAEF0: BL #0x20cb458              | this.set_enabled(value:  true);         
        this.enabled = true;
        // 0x00BAAEF4: FMOV s0, #0.50000000       | S0 = 0.5;                               
        float val_11 = 0.5f;
        // 0x00BAAEF8: FMUL s1, s8, s0            | S1 = (nearTime * 0.5f);                 
        float val_1 = nearTime * val_11;
        // 0x00BAAEFC: FMUL s0, s12, s0           | S0 = (farTime * 0.5f);                  
        val_11 = farTime * val_11;
        // 0x00BAAF00: STR x20, [x19, #0x18]      | this.target = target;                    //  dest_result_addr=1152921514493725512
        this.target = target;
        // 0x00BAAF04: STP s8, s12, [x19, #0x20]  | this.nearTime = nearTime;  this.farTime = farTime;  //  dest_result_addr=1152921514493725520 |  dest_result_addr=1152921514493725524
        this.nearTime = nearTime;
        this.farTime = farTime;
        // 0x00BAAF08: STRB w21, [x19, #0x30]     | this.bZoomIn = true;                     //  dest_result_addr=1152921514493725536
        this.bZoomIn = true;
        // 0x00BAAF0C: STP s1, s0, [x19, #0x28]   | this.mNearTime = (nearTime * 0.5f);  this.mFarTime = (farTime * 0.5f);  //  dest_result_addr=1152921514493725528 |  dest_result_addr=1152921514493725532
        this.mNearTime = val_1;
        this.mFarTime = val_11;
        // 0x00BAAF10: STR wzr, [x19, #0x34]      | this.curtime = 0;                        //  dest_result_addr=1152921514493725540
        this.curtime = 0f;
        // 0x00BAAF14: CBNZ x20, #0xbaaf1c        | if (target != null) goto label_1;       
        if(target != null)
        {
            goto label_1;
        }
        // 0x00BAAF18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_1:
        // 0x00BAAF1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAF20: MOV x0, x20                | X0 = target;//m1                        
        // 0x00BAAF24: BL #0x2693510              | X0 = target.get_position();             
        UnityEngine.Vector3 val_2 = target.position;
        // 0x00BAAF28: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BAAF2C: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BAAF30: MOV v12.16b, v0.16b        | V12 = val_2.x;//m1                      
        // 0x00BAAF34: MOV v13.16b, v1.16b        | V13 = val_2.y;//m1                      
        // 0x00BAAF38: MOV v10.16b, v2.16b        | V10 = val_2.z;//m1                      
        // 0x00BAAF3C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAAF40: LDP s9, s15, [x19, #0x5c]  | S9 = this.initOffset; //P2               //  | 
        // 0x00BAAF44: LDR s14, [x19, #0x64]      | 
        // 0x00BAAF48: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BAAF4C: TBZ w8, #0, #0xbaaf5c      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00BAAF50: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAAF54: CBNZ w8, #0xbaaf5c         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00BAAF58: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_3:
        // 0x00BAAF5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAAF60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAF64: MOV v0.16b, v12.16b        | V0 = val_2.x;//m1                       
        // 0x00BAAF68: MOV v1.16b, v13.16b        | V1 = val_2.y;//m1                       
        // 0x00BAAF6C: MOV v2.16b, v10.16b        | V2 = val_2.z;//m1                       
        // 0x00BAAF70: MOV v3.16b, v9.16b         | V3 = this.initOffset;//m1               
        // 0x00BAAF74: MOV v4.16b, v15.16b        | V4 = V15.16B;//m1                       
        // 0x00BAAF78: MOV v5.16b, v14.16b        | V5 = V14.16B;//m1                       
        // 0x00BAAF7C: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z}, b:  new UnityEngine.Vector3() {x = this.initOffset, y = V15.16B, z = V14.16B});
        UnityEngine.Vector3 val_3 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z}, b:  new UnityEngine.Vector3() {x = this.initOffset, y = V15.16B, z = V14.16B});
        // 0x00BAAF80: LDP s4, s5, [sp, #8]       | S4 = zoominoffset.y; S5 = zoominoffset.z; //  | 
        // 0x00BAAF84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAAF88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAF8C: MOV v3.16b, v11.16b        | V3 = zoominoffset.x;//m1                
        // 0x00BAAF90: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}, b:  new UnityEngine.Vector3() {x = zoominoffset.x, y = zoominoffset.y, z = zoominoffset.z});
        UnityEngine.Vector3 val_4 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}, b:  new UnityEngine.Vector3() {x = zoominoffset.x, y = zoominoffset.y, z = zoominoffset.z});
        // 0x00BAAF94: MOV v9.16b, v0.16b         | V9 = val_4.x;//m1                       
        // 0x00BAAF98: MOV v10.16b, v1.16b        | V10 = val_4.y;//m1                      
        // 0x00BAAF9C: MOV v11.16b, v2.16b        | V11 = val_4.z;//m1                      
        // 0x00BAAFA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAFA4: MOV x0, x19                | X0 = 1152921514493725488 (0x100000024D4DCB30);//ML01
        // 0x00BAAFA8: STP s9, s10, [x19, #0x50]  | this.cameraTarget = val_4;  mem[1152921514493725572] = val_4.y;  //  dest_result_addr=1152921514493725568 |  dest_result_addr=1152921514493725572
        this.cameraTarget = val_4;
        mem[1152921514493725572] = val_4.y;
        // 0x00BAAFAC: STR s11, [x19, #0x58]      | mem[1152921514493725576] = val_4.z;      //  dest_result_addr=1152921514493725576
        mem[1152921514493725576] = val_4.z;
        // 0x00BAAFB0: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_5 = this.transform;
        // 0x00BAAFB4: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00BAAFB8: CBNZ x20, #0xbaafc0        | if (val_5 != null) goto label_4;        
        if(val_5 != null)
        {
            goto label_4;
        }
        // 0x00BAAFBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_4:
        // 0x00BAAFC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAFC4: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00BAAFC8: BL #0x2693510              | X0 = val_5.get_position();              
        UnityEngine.Vector3 val_6 = val_5.position;
        // 0x00BAAFCC: MOV v3.16b, v0.16b         | V3 = val_6.x;//m1                       
        // 0x00BAAFD0: MOV v4.16b, v1.16b         | V4 = val_6.y;//m1                       
        // 0x00BAAFD4: MOV v5.16b, v2.16b         | V5 = val_6.z;//m1                       
        // 0x00BAAFD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAAFDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAFE0: MOV v0.16b, v9.16b         | V0 = val_4.x;//m1                       
        // 0x00BAAFE4: MOV v1.16b, v10.16b        | V1 = val_4.y;//m1                       
        // 0x00BAAFE8: MOV v2.16b, v11.16b        | V2 = val_4.z;//m1                       
        // 0x00BAAFEC: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z}, b:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z});
        UnityEngine.Vector3 val_7 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z}, b:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z});
        // 0x00BAAFF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAAFF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAAFF8: MOV v3.16b, v8.16b         | V3 = nearTime;//m1                      
        // 0x00BAAFFC: BL #0x2699130              | X0 = UnityEngine.Vector3.op_Division(a:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z}, d:  nearTime);
        UnityEngine.Vector3 val_8 = UnityEngine.Vector3.op_Division(a:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z}, d:  nearTime);
        // 0x00BAB000: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAB004: MOV x0, x19                | X0 = 1152921514493725488 (0x100000024D4DCB30);//ML01
        // 0x00BAB008: STP s0, s1, [x19, #0x38]   | this.speed_near = val_8;  mem[1152921514493725548] = val_8.y;  //  dest_result_addr=1152921514493725544 |  dest_result_addr=1152921514493725548
        this.speed_near = val_8;
        mem[1152921514493725548] = val_8.y;
        // 0x00BAB00C: STR s2, [x19, #0x40]       | mem[1152921514493725552] = val_8.z;      //  dest_result_addr=1152921514493725552
        mem[1152921514493725552] = val_8.z;
        // 0x00BAB010: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_9 = this.gameObject;
        // 0x00BAB014: MOV x19, x0                | X19 = val_9;//m1                        
        // 0x00BAB018: CBNZ x19, #0xbab020        | if (val_9 != null) goto label_5;        
        if(val_9 != null)
        {
            goto label_5;
        }
        // 0x00BAB01C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_5:
        // 0x00BAB020: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
        // 0x00BAB024: LDR x8, [x8, #0xb0]        | X8 = 1152921514493551600;               
        // 0x00BAB028: MOV x0, x19                | X0 = val_9;//m1                         
        // 0x00BAB02C: LDR x1, [x8]               | X1 = public CameraSmoothFollow UnityEngine.GameObject::GetComponent<CameraSmoothFollow>();
        // 0x00BAB030: BL #0x23d5abc              | X0 = val_9.GetComponent<CameraSmoothFollow>();
        CameraSmoothFollow val_10 = val_9.GetComponent<CameraSmoothFollow>();
        // 0x00BAB034: MOV x19, x0                | X19 = val_10;//m1                       
        // 0x00BAB038: CBNZ x19, #0xbab040        | if (val_10 != null) goto label_6;       
        if(val_10 != null)
        {
            goto label_6;
        }
        // 0x00BAB03C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_6:
        // 0x00BAB040: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BAB044: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAB048: MOV x0, x19                | X0 = val_10;//m1                        
        // 0x00BAB04C: SUB sp, x29, #0x60         | SP = (1152921514493713472 - 96) = 1152921514493713376 (0x100000024D4D9BE0);
        // 0x00BAB050: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAB054: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAB058: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00BAB05C: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00BAB060: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00BAB064: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00BAB068: LDP d15, d14, [sp], #0x70  | D15 = ; D14 = ;                          //  | 
        // 0x00BAB06C: B #0x20cb458               | val_10.set_enabled(value:  false); return;
        val_10.enabled = false;
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAA380 (12231552), len: 376  VirtAddr: 0x00BAA380 RVA: 0x00BAA380 token: 100690246 methodIndex: 25708 delegateWrapperIndex: 0 methodInvoker: 0
    public void FarAway()
    {
        //
        // Disasemble & Code
        // 0x00BAA380: STP d13, d12, [sp, #-0x50]! | stack[1152921514493854080] = ???;  stack[1152921514493854088] = ???;  //  dest_result_addr=1152921514493854080 |  dest_result_addr=1152921514493854088
        // 0x00BAA384: STP d11, d10, [sp, #0x10]  | stack[1152921514493854096] = ???;  stack[1152921514493854104] = ???;  //  dest_result_addr=1152921514493854096 |  dest_result_addr=1152921514493854104
        // 0x00BAA388: STP d9, d8, [sp, #0x20]    | stack[1152921514493854112] = ???;  stack[1152921514493854120] = ???;  //  dest_result_addr=1152921514493854112 |  dest_result_addr=1152921514493854120
        // 0x00BAA38C: STP x20, x19, [sp, #0x30]  | stack[1152921514493854128] = ???;  stack[1152921514493854136] = ???;  //  dest_result_addr=1152921514493854128 |  dest_result_addr=1152921514493854136
        // 0x00BAA390: STP x29, x30, [sp, #0x40]  | stack[1152921514493854144] = ???;  stack[1152921514493854152] = ???;  //  dest_result_addr=1152921514493854144 |  dest_result_addr=1152921514493854152
        // 0x00BAA394: ADD x29, sp, #0x40         | X29 = (1152921514493854080 + 64) = 1152921514493854144 (0x100000024D4FC1C0);
        // 0x00BAA398: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BAA39C: LDRB w8, [x20, #0xb07]     | W8 = (bool)static_value_03733B07;       
        // 0x00BAA3A0: MOV x19, x0                | X19 = 1152921514493866160 (0x100000024D4FF0B0);//ML01
        // 0x00BAA3A4: TBNZ w8, #0, #0xbaa3c0     | if (static_value_03733B07 == true) goto label_0;
        // 0x00BAA3A8: ADRP x8, #0x35d7000        | X8 = 56455168 (0x35D7000);              
        // 0x00BAA3AC: LDR x8, [x8, #0x330]       | X8 = 0x2B90254;                         
        // 0x00BAA3B0: LDR w0, [x8]               | W0 = 0x1759;                            
        // 0x00BAA3B4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1759, ????);     
        // 0x00BAA3B8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAA3BC: STRB w8, [x20, #0xb07]     | static_value_03733B07 = true;            //  dest_result_addr=57883399
        label_0:
        // 0x00BAA3C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAA3C4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BAA3C8: MOV x0, x19                | X0 = 1152921514493866160 (0x100000024D4FF0B0);//ML01
        // 0x00BAA3CC: BL #0x20cb458              | this.set_enabled(value:  true);         
        this.enabled = true;
        // 0x00BAA3D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA3D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA3D8: STRB wzr, [x19, #0x30]     | this.bZoomIn = false;                    //  dest_result_addr=1152921514493866208
        this.bZoomIn = false;
        // 0x00BAA3DC: STR wzr, [x19, #0x34]      | this.curtime = 0;                        //  dest_result_addr=1152921514493866212
        this.curtime = 0f;
        // 0x00BAA3E0: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_1 = HeroMgr.instance;
        // 0x00BAA3E4: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00BAA3E8: CBNZ x20, #0xbaa3f0        | if (val_1 != null) goto label_1;        
        if(val_1 != null)
        {
            goto label_1;
        }
        // 0x00BAA3EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x00BAA3F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA3F4: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00BAA3F8: BL #0x2895980              | X0 = val_1.GetCameraTarger();           
        UnityEngine.Transform val_2 = val_1.GetCameraTarger();
        // 0x00BAA3FC: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00BAA400: CBNZ x20, #0xbaa408        | if (val_2 != null) goto label_2;        
        if(val_2 != null)
        {
            goto label_2;
        }
        // 0x00BAA404: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_2:
        // 0x00BAA408: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA40C: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00BAA410: BL #0x2693510              | X0 = val_2.get_position();              
        UnityEngine.Vector3 val_3 = val_2.position;
        // 0x00BAA414: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BAA418: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BAA41C: MOV v8.16b, v0.16b         | V8 = val_3.x;//m1                       
        // 0x00BAA420: MOV v9.16b, v1.16b         | V9 = val_3.y;//m1                       
        // 0x00BAA424: MOV v13.16b, v2.16b        | V13 = val_3.z;//m1                      
        // 0x00BAA428: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAA42C: LDP s12, s11, [x19, #0x5c] | S12 = this.initOffset; //P2              //  | 
        // 0x00BAA430: LDR s10, [x19, #0x64]      | 
        // 0x00BAA434: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BAA438: TBZ w8, #0, #0xbaa448      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00BAA43C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAA440: CBNZ w8, #0xbaa448         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00BAA444: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_4:
        // 0x00BAA448: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA44C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA450: MOV v0.16b, v8.16b         | V0 = val_3.x;//m1                       
        // 0x00BAA454: MOV v1.16b, v9.16b         | V1 = val_3.y;//m1                       
        // 0x00BAA458: MOV v2.16b, v13.16b        | V2 = val_3.z;//m1                       
        // 0x00BAA45C: MOV v3.16b, v12.16b        | V3 = this.initOffset;//m1               
        // 0x00BAA460: MOV v4.16b, v11.16b        | V4 = V11.16B;//m1                       
        // 0x00BAA464: MOV v5.16b, v10.16b        | V5 = V10.16B;//m1                       
        // 0x00BAA468: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}, b:  new UnityEngine.Vector3() {x = this.initOffset, y = V11.16B, z = V10.16B});
        UnityEngine.Vector3 val_4 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}, b:  new UnityEngine.Vector3() {x = this.initOffset, y = V11.16B, z = V10.16B});
        // 0x00BAA46C: MOV v8.16b, v0.16b         | V8 = val_4.x;//m1                       
        // 0x00BAA470: MOV v9.16b, v1.16b         | V9 = val_4.y;//m1                       
        // 0x00BAA474: MOV v10.16b, v2.16b        | V10 = val_4.z;//m1                      
        // 0x00BAA478: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA47C: MOV x0, x19                | X0 = 1152921514493866160 (0x100000024D4FF0B0);//ML01
        // 0x00BAA480: STP s8, s9, [x19, #0x50]   | this.cameraTarget = val_4;  mem[1152921514493866244] = val_4.y;  //  dest_result_addr=1152921514493866240 |  dest_result_addr=1152921514493866244
        this.cameraTarget = val_4;
        mem[1152921514493866244] = val_4.y;
        // 0x00BAA484: STR s10, [x19, #0x58]      | mem[1152921514493866248] = val_4.z;      //  dest_result_addr=1152921514493866248
        mem[1152921514493866248] = val_4.z;
        // 0x00BAA488: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_5 = this.transform;
        // 0x00BAA48C: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00BAA490: CBNZ x20, #0xbaa498        | if (val_5 != null) goto label_5;        
        if(val_5 != null)
        {
            goto label_5;
        }
        // 0x00BAA494: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_5:
        // 0x00BAA498: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA49C: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00BAA4A0: BL #0x2693510              | X0 = val_5.get_position();              
        UnityEngine.Vector3 val_6 = val_5.position;
        // 0x00BAA4A4: MOV v3.16b, v0.16b         | V3 = val_6.x;//m1                       
        // 0x00BAA4A8: MOV v4.16b, v1.16b         | V4 = val_6.y;//m1                       
        // 0x00BAA4AC: MOV v5.16b, v2.16b         | V5 = val_6.z;//m1                       
        // 0x00BAA4B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA4B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA4B8: MOV v0.16b, v8.16b         | V0 = val_4.x;//m1                       
        // 0x00BAA4BC: MOV v1.16b, v9.16b         | V1 = val_4.y;//m1                       
        // 0x00BAA4C0: MOV v2.16b, v10.16b        | V2 = val_4.z;//m1                       
        // 0x00BAA4C4: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z}, b:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z});
        UnityEngine.Vector3 val_7 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z}, b:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z});
        // 0x00BAA4C8: LDR s3, [x19, #0x24]       | S3 = this.farTime; //P2                 
        // 0x00BAA4CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAA4D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAA4D4: BL #0x2699130              | X0 = UnityEngine.Vector3.op_Division(a:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z}, d:  this.farTime);
        UnityEngine.Vector3 val_8 = UnityEngine.Vector3.op_Division(a:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z}, d:  this.farTime);
        // 0x00BAA4D8: STP s0, s1, [x19, #0x44]   | this.speed_far = val_8;  mem[1152921514493866232] = val_8.y;  //  dest_result_addr=1152921514493866228 |  dest_result_addr=1152921514493866232
        this.speed_far = val_8;
        mem[1152921514493866232] = val_8.y;
        // 0x00BAA4DC: STR s2, [x19, #0x4c]       | mem[1152921514493866236] = val_8.z;      //  dest_result_addr=1152921514493866236
        mem[1152921514493866236] = val_8.z;
        // 0x00BAA4E0: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAA4E4: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAA4E8: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x00BAA4EC: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x00BAA4F0: LDP d13, d12, [sp], #0x50  | D13 = ; D12 = ;                          //  | 
        // 0x00BAA4F4: RET                        |  return;                                
        return;
    
    }

}
