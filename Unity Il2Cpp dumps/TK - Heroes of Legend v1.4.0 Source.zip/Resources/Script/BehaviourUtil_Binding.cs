using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class BehaviourUtil_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache4; // static_offset: 0x00000020
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache5; // static_offset: 0x00000028
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache6; // static_offset: 0x00000030
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache7; // static_offset: 0x00000038
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache8; // static_offset: 0x00000040
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache9; // static_offset: 0x00000048
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheA; // static_offset: 0x00000050
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheB; // static_offset: 0x00000058
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheC; // static_offset: 0x00000060
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheD; // static_offset: 0x00000068
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheE; // static_offset: 0x00000070
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheF; // static_offset: 0x00000078
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache10; // static_offset: 0x00000080
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache11; // static_offset: 0x00000088
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00BC4368 (12338024), len: 8  VirtAddr: 0x00BC4368 RVA: 0x00BC4368 token: 100663829 methodIndex: 29874 delegateWrapperIndex: 0 methodInvoker: 0
        public BehaviourUtil_Binding()
        {
            //
            // Disasemble & Code
            // 0x00BC4368: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC436C: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC4370 (12338032), len: 11196  VirtAddr: 0x00BC4370 RVA: 0x00BC4370 token: 100663830 methodIndex: 29875 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            var val_46;
            //  | 
            var val_47;
            //  | 
            var val_117;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_118;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_119;
            //  | 
            System.Type val_120;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_121;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_122;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_123;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_124;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_125;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_126;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_127;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_128;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_129;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_130;
            //  | 
            var val_131;
            //  | 
            var val_132;
            //  | 
            System.Type val_133;
            //  | 
            var val_134;
            //  | 
            string val_135;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_136;
            //  | 
            var val_137;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_138;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_139;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_140;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_141;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_142;
            //  | 
            System.Type val_143;
            //  | 
            var val_144;
            // 0x00BC4370: STP x28, x27, [sp, #-0x60]! | stack[1152921510055116816] = ???;  stack[1152921510055116824] = ???;  //  dest_result_addr=1152921510055116816 |  dest_result_addr=1152921510055116824
            // 0x00BC4374: STP x26, x25, [sp, #0x10]  | stack[1152921510055116832] = ???;  stack[1152921510055116840] = ???;  //  dest_result_addr=1152921510055116832 |  dest_result_addr=1152921510055116840
            // 0x00BC4378: STP x24, x23, [sp, #0x20]  | stack[1152921510055116848] = ???;  stack[1152921510055116856] = ???;  //  dest_result_addr=1152921510055116848 |  dest_result_addr=1152921510055116856
            // 0x00BC437C: STP x22, x21, [sp, #0x30]  | stack[1152921510055116864] = ???;  stack[1152921510055116872] = ???;  //  dest_result_addr=1152921510055116864 |  dest_result_addr=1152921510055116872
            // 0x00BC4380: STP x20, x19, [sp, #0x40]  | stack[1152921510055116880] = ???;  stack[1152921510055116888] = ???;  //  dest_result_addr=1152921510055116880 |  dest_result_addr=1152921510055116888
            // 0x00BC4384: STP x29, x30, [sp, #0x50]  | stack[1152921510055116896] = ???;  stack[1152921510055116904] = ???;  //  dest_result_addr=1152921510055116896 |  dest_result_addr=1152921510055116904
            // 0x00BC4388: ADD x29, sp, #0x50         | X29 = (1152921510055116816 + 80) = 1152921510055116896 (0x1000000144BE0060);
            // 0x00BC438C: SUB sp, sp, #0x110         | SP = (1152921510055116816 - 272) = 1152921510055116544 (0x1000000144BDFF00);
            // 0x00BC4390: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BC4394: LDRB w8, [x19, #0xb9e]     | W8 = (bool)static_value_03733B9E;       
            // 0x00BC4398: MOV x26, x1                | X26 = X1;//m1                           
            // 0x00BC439C: TBNZ w8, #0, #0xbc43b8     | if (static_value_03733B9E == true) goto label_0;
            // 0x00BC43A0: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00BC43A4: LDR x8, [x8, #0x18]        | X8 = 0x2B8F280;                         
            // 0x00BC43A8: LDR w0, [x8]               | W0 = 0x1362;                            
            // 0x00BC43AC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1362, ????);     
            // 0x00BC43B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC43B4: STRB w8, [x19, #0xb9e]     | static_value_03733B9E = true;            //  dest_result_addr=57883550
            label_0:
            // 0x00BC43B8: STP xzr, xzr, [x29, #-0x60] | stack[1152921510055116800] = 0x0;  stack[1152921510055116808] = 0x0;  //  dest_result_addr=1152921510055116800 |  dest_result_addr=1152921510055116808
            // 0x00BC43BC: STP xzr, xzr, [x29, #-0x70] | stack[1152921510055116784] = 0x0;  stack[1152921510055116792] = 0x0;  //  dest_result_addr=1152921510055116784 |  dest_result_addr=1152921510055116792
            // 0x00BC43C0: STP xzr, xzr, [x29, #-0x88] | stack[1152921510055116760] = 0x0;  stack[1152921510055116768] = 0x0;  //  dest_result_addr=1152921510055116760 |  dest_result_addr=1152921510055116768
            // 0x00BC43C4: STUR xzr, [x29, #-0x90]    | stack[1152921510055116752] = 0x0;        //  dest_result_addr=1152921510055116752
            // 0x00BC43C8: STP xzr, xzr, [sp, #0xb8]  | stack[1152921510055116728] = 0x0;  stack[1152921510055116736] = 0x0;  //  dest_result_addr=1152921510055116728 |  dest_result_addr=1152921510055116736
            // 0x00BC43CC: STR xzr, [sp, #0xb0]       | stack[1152921510055116720] = 0x0;        //  dest_result_addr=1152921510055116720
            // 0x00BC43D0: STP xzr, xzr, [sp, #0x98]  | stack[1152921510055116696] = 0x0;  stack[1152921510055116704] = 0x0;  //  dest_result_addr=1152921510055116696 |  dest_result_addr=1152921510055116704
            // 0x00BC43D4: STR xzr, [sp, #0x90]       | stack[1152921510055116688] = 0x0;        //  dest_result_addr=1152921510055116688
            // 0x00BC43D8: STP xzr, xzr, [sp, #0x78]  | stack[1152921510055116664] = 0x0;  stack[1152921510055116672] = 0x0;  //  dest_result_addr=1152921510055116664 |  dest_result_addr=1152921510055116672
            // 0x00BC43DC: STR xzr, [sp, #0x70]       | stack[1152921510055116656] = 0x0;        //  dest_result_addr=1152921510055116656
            // 0x00BC43E0: STP xzr, xzr, [sp, #0x58]  | stack[1152921510055116632] = 0x0;  stack[1152921510055116640] = 0x0;  //  dest_result_addr=1152921510055116632 |  dest_result_addr=1152921510055116640
            // 0x00BC43E4: STR xzr, [sp, #0x50]       | stack[1152921510055116624] = 0x0;        //  dest_result_addr=1152921510055116624
            // 0x00BC43E8: STP xzr, xzr, [sp, #0x38]  | stack[1152921510055116600] = 0x0;  stack[1152921510055116608] = 0x0;  //  dest_result_addr=1152921510055116600 |  dest_result_addr=1152921510055116608
            // 0x00BC43EC: ADRP x27, #0x3620000       | X27 = 56754176 (0x3620000);             
            // 0x00BC43F0: LDR x27, [x27, #0x340]     | X27 = 1152921504609562624;              
            // 0x00BC43F4: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
            // 0x00BC43F8: STR xzr, [sp, #0x30]       | stack[1152921510055116592] = 0x0;        //  dest_result_addr=1152921510055116592
            // 0x00BC43FC: LDR x0, [x27]              | X0 = typeof(System.Type);               
            // 0x00BC4400: LDR x8, [x8, #0xef0]       | X8 = 1152921504922660864;               
            // 0x00BC4404: LDR x20, [x8]              | X20 = typeof(BehaviourUtil);            
            // 0x00BC4408: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC440C: TBZ w8, #0, #0xbc441c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00BC4410: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC4414: CBNZ w8, #0xbc441c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00BC4418: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00BC441C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC4420: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC4424: MOV x1, x20                | X1 = 1152921504922660864 (0x1000000012D2F000);//ML01
            // 0x00BC4428: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC442C: ADRP x28, #0x35ef000       | X28 = 56553472 (0x35EF000);             
            // 0x00BC4430: LDR x28, [x28, #0xff0]     | X28 = 1152921504987155056;              
            // 0x00BC4434: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BC4438: LDR x20, [x28]             | X20 = typeof(System.Type[]);            
            // 0x00BC443C: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4440: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC4444: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4448: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC444C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC4450: MOV x20, x0                | X20 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4454: CBNZ x21, #0xbc445c        | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x00BC4458: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_3:
            // 0x00BC445C: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x00BC4460: LDR x8, [x8, #0x3a8]       | X8 = (string**)(1152921510033340128)("Update");
            // 0x00BC4464: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4468: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC446C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC4470: LDR x1, [x8]               | X1 = "Update";                          
            // 0x00BC4474: MOV x0, x21                | X0 = val_1;//m1                         
            // 0x00BC4478: MOV x4, x20                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC447C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC4480: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Update", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_2 = val_1.GetMethod(name:  "Update", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC4484: ADRP x19, #0x362d000       | X19 = 56807424 (0x362D000);             
            // 0x00BC4488: LDR x19, [x19, #0xd10]     | X19 = 1152921504783044608;              
            // 0x00BC448C: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BC4490: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC4494: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC4498: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache0;
            val_118 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache0;
            // 0x00BC449C: CBNZ x22, #0xbc44e8        | if (ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache0 != null) goto label_4;
            if(val_118 != null)
            {
                goto label_4;
            }
            // 0x00BC44A0: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
            // 0x00BC44A4: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC44A8: LDR x8, [x8, #0x650]       | X8 = 1152921510054765168;               
            // 0x00BC44AC: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC44B0: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::Update_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC44B4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_3 = null;
            // 0x00BC44B8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC44BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC44C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC44C4: MOV x2, x22                | X2 = 1152921510054765168 (0x1000000144B8A270);//ML01
            // 0x00BC44C8: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_119 = val_3;
            // 0x00BC44CC: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::Update_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_3 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::Update_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC44D0: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC44D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC44D8: STR x23, [x8]              | ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783048704
            ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache0 = val_119;
            // 0x00BC44DC: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC44E0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC44E4: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_118 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache0;
            label_4:
            // 0x00BC44E8: CBNZ x26, #0xbc44f0        | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x00BC44EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::Update_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_5:
            // 0x00BC44F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC44F4: MOV x0, x26                | X0 = X1;//m1                            
            // 0x00BC44F8: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00BC44FC: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC4500: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_2, func:  val_118);
            X1.RegisterCLRMethodRedirection(mi:  val_2, func:  val_118);
            // 0x00BC4504: LDR x20, [x28]             | X20 = typeof(System.Type[]);            
            // 0x00BC4508: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC450C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC4510: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00BC4514: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4518: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC451C: ADRP x25, #0x3672000       | X25 = 57090048 (0x3672000);             
            // 0x00BC4520: LDR x8, [x27]              | X8 = typeof(System.Type);               
            // 0x00BC4524: LDR x25, [x25, #0x458]     | X25 = 1152921504608018432;              
            val_120 = 1152921504608018432;
            // 0x00BC4528: MOV x20, x0                | X20 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC452C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC4530: LDR x22, [x25]             | X22 = typeof(System.Collections.IEnumerator);
            // 0x00BC4534: TBZ w9, #0, #0xbc4548      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BC4538: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC453C: CBNZ w9, #0xbc4548         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BC4540: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC4544: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_7:
            // 0x00BC4548: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC454C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC4550: MOV x1, x22                | X1 = 1152921504608018432 (0x100000000011E000);//ML01
            // 0x00BC4554: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC4558: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00BC455C: CBNZ x20, #0xbc4564        | if ( != null) goto label_8;             
            if(null != null)
            {
                goto label_8;
            }
            // 0x00BC4560: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_8:
            // 0x00BC4564: CBZ x22, #0xbc4588         | if (val_4 == null) goto label_10;       
            if(val_4 == null)
            {
                goto label_10;
            }
            // 0x00BC4568: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BC456C: MOV x0, x22                | X0 = val_4;//m1                         
            // 0x00BC4570: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC4574: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_4, ????);      
            // 0x00BC4578: CBNZ x0, #0xbc4588         | if (val_4 != null) goto label_10;       
            if(val_4 != null)
            {
                goto label_10;
            }
            // 0x00BC457C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_4, ????);      
            // 0x00BC4580: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4584: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_10:
            // 0x00BC4588: LDR w8, [x20, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC458C: CBNZ w8, #0xbc459c         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_11;
            // 0x00BC4590: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
            // 0x00BC4594: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4598: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_11:
            // 0x00BC459C: STR x22, [x20, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_4;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_4;
            // 0x00BC45A0: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x00BC45A4: LDR x8, [x8, #0xff0]       | X8 = 1152921504607645696;               
            // 0x00BC45A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC45AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC45B0: LDR x1, [x8]               | X1 = typeof(System.UInt32);             
            // 0x00BC45B4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC45B8: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BC45BC: CBZ x22, #0xbc45e0         | if (val_5 == null) goto label_13;       
            if(val_5 == null)
            {
                goto label_13;
            }
            // 0x00BC45C0: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BC45C4: MOV x0, x22                | X0 = val_5;//m1                         
            // 0x00BC45C8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC45CC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_5, ????);      
            // 0x00BC45D0: CBNZ x0, #0xbc45e0         | if (val_5 != null) goto label_13;       
            if(val_5 != null)
            {
                goto label_13;
            }
            // 0x00BC45D4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_5, ????);      
            // 0x00BC45D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC45DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            label_13:
            // 0x00BC45E0: LDR w8, [x20, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC45E4: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00BC45E8: B.HI #0xbc45f8             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_14;
            // 0x00BC45EC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_5, ????);      
            // 0x00BC45F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC45F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            label_14:
            // 0x00BC45F8: STR x22, [x20, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_5;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_5;
            // 0x00BC45FC: CBNZ x21, #0xbc4604        | if (val_1 != null) goto label_15;       
            if(val_1 != null)
            {
                goto label_15;
            }
            // 0x00BC4600: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_15:
            // 0x00BC4604: ADRP x24, #0x3627000       | X24 = 56782848 (0x3627000);             
            // 0x00BC4608: LDR x24, [x24, #0xcf0]     | X24 = (string**)(1152921510054774384)("StartCoroutine");
            // 0x00BC460C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4610: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC4614: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC4618: LDR x1, [x24]              | X1 = "StartCoroutine";                  
            // 0x00BC461C: MOV x0, x21                | X0 = val_1;//m1                         
            // 0x00BC4620: MOV x4, x20                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4624: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC4628: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "StartCoroutine", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_6 = val_1.GetMethod(name:  "StartCoroutine", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC462C: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC4630: MOV x20, x0                | X20 = val_6;//m1                        
            // 0x00BC4634: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC4638: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache1;
            val_121 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache1;
            // 0x00BC463C: CBNZ x22, #0xbc4688        | if (ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache1 != null) goto label_16;
            if(val_121 != null)
            {
                goto label_16;
            }
            // 0x00BC4640: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x00BC4644: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC4648: LDR x8, [x8, #0x1d0]       | X8 = 1152921510054778576;               
            // 0x00BC464C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC4650: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::StartCoroutine_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC4654: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_7 = null;
            // 0x00BC4658: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC465C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4660: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4664: MOV x2, x22                | X2 = 1152921510054778576 (0x1000000144B8D6D0);//ML01
            // 0x00BC4668: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_119 = val_7;
            // 0x00BC466C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::StartCoroutine_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_7 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::StartCoroutine_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC4670: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC4674: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC4678: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783048712
            ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache1 = val_119;
            // 0x00BC467C: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC4680: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC4684: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_121 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache1;
            label_16:
            // 0x00BC4688: CBNZ x26, #0xbc4690        | if (X1 != 0) goto label_17;             
            if(X1 != 0)
            {
                goto label_17;
            }
            // 0x00BC468C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::StartCoroutine_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_17:
            // 0x00BC4690: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4694: MOV x0, x26                | X0 = X1;//m1                            
            // 0x00BC4698: MOV x1, x20                | X1 = val_6;//m1                         
            // 0x00BC469C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC46A0: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_6, func:  val_121);
            X1.RegisterCLRMethodRedirection(mi:  val_6, func:  val_121);
            // 0x00BC46A4: LDR x20, [x28]             | X20 = typeof(System.Type[]);            
            // 0x00BC46A8: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC46AC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC46B0: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BC46B4: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC46B8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC46BC: LDR x8, [x27]              | X8 = typeof(System.Type);               
            // 0x00BC46C0: LDR x22, [x25]             | X22 = typeof(System.Collections.IEnumerator);
            // 0x00BC46C4: MOV x20, x0                | X20 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC46C8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC46CC: TBZ w9, #0, #0xbc46e0      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_19;
            // 0x00BC46D0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC46D4: CBNZ w9, #0xbc46e0         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
            // 0x00BC46D8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC46DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_19:
            // 0x00BC46E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC46E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC46E8: MOV x1, x22                | X1 = 1152921504608018432 (0x100000000011E000);//ML01
            // 0x00BC46EC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC46F0: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x00BC46F4: CBNZ x20, #0xbc46fc        | if ( != null) goto label_20;            
            if(null != null)
            {
                goto label_20;
            }
            // 0x00BC46F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_20:
            // 0x00BC46FC: CBZ x22, #0xbc4720         | if (val_8 == null) goto label_22;       
            if(val_8 == null)
            {
                goto label_22;
            }
            // 0x00BC4700: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BC4704: MOV x0, x22                | X0 = val_8;//m1                         
            // 0x00BC4708: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC470C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_8, ????);      
            // 0x00BC4710: CBNZ x0, #0xbc4720         | if (val_8 != null) goto label_22;       
            if(val_8 != null)
            {
                goto label_22;
            }
            // 0x00BC4714: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_8, ????);      
            // 0x00BC4718: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC471C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            label_22:
            // 0x00BC4720: LDR w8, [x20, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC4724: CBNZ w8, #0xbc4734         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_23;
            // 0x00BC4728: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_8, ????);      
            // 0x00BC472C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4730: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            label_23:
            // 0x00BC4734: STR x22, [x20, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_8;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_8;
            // 0x00BC4738: CBNZ x21, #0xbc4740        | if (val_1 != null) goto label_24;       
            if(val_1 != null)
            {
                goto label_24;
            }
            // 0x00BC473C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_24:
            // 0x00BC4740: LDR x1, [x24]              | X1 = "StartCoroutine";                  
            // 0x00BC4744: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4748: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC474C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC4750: MOV x0, x21                | X0 = val_1;//m1                         
            // 0x00BC4754: MOV x4, x20                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4758: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC475C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "StartCoroutine", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_9 = val_1.GetMethod(name:  "StartCoroutine", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC4760: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC4764: MOV x20, x0                | X20 = val_9;//m1                        
            // 0x00BC4768: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC476C: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache2;
            val_122 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache2;
            // 0x00BC4770: CBNZ x22, #0xbc47bc        | if (ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache2 != null) goto label_25;
            if(val_122 != null)
            {
                goto label_25;
            }
            // 0x00BC4774: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x00BC4778: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC477C: LDR x8, [x8, #8]           | X8 = 1152921510054787792;               
            // 0x00BC4780: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC4784: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::StartCoroutine_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC4788: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_10 = null;
            // 0x00BC478C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC4790: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4794: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4798: MOV x2, x22                | X2 = 1152921510054787792 (0x1000000144B8FAD0);//ML01
            // 0x00BC479C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_119 = val_10;
            // 0x00BC47A0: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::StartCoroutine_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_10 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::StartCoroutine_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC47A4: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC47A8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC47AC: STR x23, [x8, #0x10]       | ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783048720
            ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache2 = val_119;
            // 0x00BC47B0: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC47B4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC47B8: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_122 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache2;
            label_25:
            // 0x00BC47BC: CBNZ x26, #0xbc47c4        | if (X1 != 0) goto label_26;             
            if(X1 != 0)
            {
                goto label_26;
            }
            // 0x00BC47C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::StartCoroutine_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_26:
            // 0x00BC47C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC47C8: MOV x0, x26                | X0 = X1;//m1                            
            // 0x00BC47CC: MOV x1, x20                | X1 = val_9;//m1                         
            // 0x00BC47D0: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC47D4: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_9, func:  val_122);
            X1.RegisterCLRMethodRedirection(mi:  val_9, func:  val_122);
            // 0x00BC47D8: LDR x20, [x28]             | X20 = typeof(System.Type[]);            
            // 0x00BC47DC: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC47E0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC47E4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BC47E8: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC47EC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC47F0: ADRP x9, #0x362b000        | X9 = 56799232 (0x362B000);              
            // 0x00BC47F4: LDR x8, [x27]              | X8 = typeof(System.Type);               
            // 0x00BC47F8: LDR x9, [x9, #0x7f0]       | X9 = 1152921504926228480;               
            // 0x00BC47FC: MOV x20, x0                | X20 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4800: LDR x22, [x9]              | X22 = typeof(Mihua.Utils.WaitForSeconds);
            // 0x00BC4804: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC4808: TBZ w9, #0, #0xbc481c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_28;
            // 0x00BC480C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC4810: CBNZ w9, #0xbc481c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_28;
            // 0x00BC4814: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC4818: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_28:
            // 0x00BC481C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC4820: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC4824: MOV x1, x22                | X1 = 1152921504926228480 (0x1000000013096000);//ML01
            // 0x00BC4828: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_11 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC482C: MOV x22, x0                | X22 = val_11;//m1                       
            // 0x00BC4830: CBNZ x20, #0xbc4838        | if ( != null) goto label_29;            
            if(null != null)
            {
                goto label_29;
            }
            // 0x00BC4834: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_29:
            // 0x00BC4838: CBZ x22, #0xbc485c         | if (val_11 == null) goto label_31;      
            if(val_11 == null)
            {
                goto label_31;
            }
            // 0x00BC483C: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BC4840: MOV x0, x22                | X0 = val_11;//m1                        
            // 0x00BC4844: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC4848: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_11, ????);     
            // 0x00BC484C: CBNZ x0, #0xbc485c         | if (val_11 != null) goto label_31;      
            if(val_11 != null)
            {
                goto label_31;
            }
            // 0x00BC4850: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_11, ????);     
            // 0x00BC4854: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4858: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            label_31:
            // 0x00BC485C: LDR w8, [x20, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC4860: CBNZ w8, #0xbc4870         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_32;
            // 0x00BC4864: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_11, ????);     
            // 0x00BC4868: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC486C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            label_32:
            // 0x00BC4870: STR x22, [x20, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_11;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_11;
            // 0x00BC4874: CBNZ x21, #0xbc487c        | if (val_1 != null) goto label_33;       
            if(val_1 != null)
            {
                goto label_33;
            }
            // 0x00BC4878: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_33:
            // 0x00BC487C: LDR x1, [x24]              | X1 = "StartCoroutine";                  
            // 0x00BC4880: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4884: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC4888: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC488C: MOV x0, x21                | X0 = val_1;//m1                         
            // 0x00BC4890: MOV x4, x20                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4894: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC4898: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "StartCoroutine", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_12 = val_1.GetMethod(name:  "StartCoroutine", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC489C: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC48A0: MOV x20, x0                | X20 = val_12;//m1                       
            // 0x00BC48A4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC48A8: LDR x22, [x8, #0x18]       | X22 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache3;
            val_123 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache3;
            // 0x00BC48AC: CBNZ x22, #0xbc48f8        | if (ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache3 != null) goto label_34;
            if(val_123 != null)
            {
                goto label_34;
            }
            // 0x00BC48B0: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
            // 0x00BC48B4: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC48B8: LDR x8, [x8, #0x660]       | X8 = 1152921510054797008;               
            // 0x00BC48BC: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC48C0: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::StartCoroutine_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC48C4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_13 = null;
            // 0x00BC48C8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC48CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC48D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC48D4: MOV x2, x22                | X2 = 1152921510054797008 (0x1000000144B91ED0);//ML01
            // 0x00BC48D8: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_119 = val_13;
            // 0x00BC48DC: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::StartCoroutine_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_13 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::StartCoroutine_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC48E0: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC48E4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC48E8: STR x23, [x8, #0x18]       | ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783048728
            ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache3 = val_119;
            // 0x00BC48EC: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC48F0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC48F4: LDR x22, [x8, #0x18]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_123 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache3;
            label_34:
            // 0x00BC48F8: CBNZ x26, #0xbc4900        | if (X1 != 0) goto label_35;             
            if(X1 != 0)
            {
                goto label_35;
            }
            // 0x00BC48FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::StartCoroutine_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_35:
            // 0x00BC4900: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4904: MOV x0, x26                | X0 = X1;//m1                            
            // 0x00BC4908: MOV x1, x20                | X1 = val_12;//m1                        
            // 0x00BC490C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC4910: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_12, func:  val_123);
            X1.RegisterCLRMethodRedirection(mi:  val_12, func:  val_123);
            // 0x00BC4914: LDR x20, [x28]             | X20 = typeof(System.Type[]);            
            // 0x00BC4918: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC491C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC4920: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4924: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4928: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC492C: MOV x20, x0                | X20 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4930: CBNZ x21, #0xbc4938        | if (val_1 != null) goto label_36;       
            if(val_1 != null)
            {
                goto label_36;
            }
            // 0x00BC4934: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_36:
            // 0x00BC4938: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x00BC493C: LDR x8, [x8, #0x340]       | X8 = (string**)(1152921510054798032)("StopAllCoroutine");
            // 0x00BC4940: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4944: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC4948: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC494C: LDR x1, [x8]               | X1 = "StopAllCoroutine";                
            // 0x00BC4950: MOV x0, x21                | X0 = val_1;//m1                         
            // 0x00BC4954: MOV x4, x20                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4958: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC495C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "StopAllCoroutine", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_14 = val_1.GetMethod(name:  "StopAllCoroutine", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC4960: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC4964: MOV x20, x0                | X20 = val_14;//m1                       
            // 0x00BC4968: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC496C: LDR x22, [x8, #0x20]       | X22 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache4;
            val_124 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache4;
            // 0x00BC4970: CBNZ x22, #0xbc49bc        | if (ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache4 != null) goto label_37;
            if(val_124 != null)
            {
                goto label_37;
            }
            // 0x00BC4974: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
            // 0x00BC4978: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC497C: LDR x8, [x8, #0xbc0]       | X8 = 1152921510054802240;               
            // 0x00BC4980: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC4984: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::StopAllCoroutine_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC4988: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_15 = null;
            // 0x00BC498C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC4990: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4994: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4998: MOV x2, x22                | X2 = 1152921510054802240 (0x1000000144B93340);//ML01
            // 0x00BC499C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_119 = val_15;
            // 0x00BC49A0: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::StopAllCoroutine_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_15 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::StopAllCoroutine_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC49A4: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC49A8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC49AC: STR x23, [x8, #0x20]       | ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783048736
            ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache4 = val_119;
            // 0x00BC49B0: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC49B4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC49B8: LDR x22, [x8, #0x20]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_124 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache4;
            label_37:
            // 0x00BC49BC: CBNZ x26, #0xbc49c4        | if (X1 != 0) goto label_38;             
            if(X1 != 0)
            {
                goto label_38;
            }
            // 0x00BC49C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::StopAllCoroutine_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_38:
            // 0x00BC49C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC49C8: MOV x0, x26                | X0 = X1;//m1                            
            // 0x00BC49CC: MOV x1, x20                | X1 = val_14;//m1                        
            // 0x00BC49D0: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC49D4: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_14, func:  val_124);
            X1.RegisterCLRMethodRedirection(mi:  val_14, func:  val_124);
            // 0x00BC49D8: LDR x20, [x28]             | X20 = typeof(System.Type[]);            
            // 0x00BC49DC: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC49E0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC49E4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BC49E8: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC49EC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC49F0: ADRP x9, #0x3600000        | X9 = 56623104 (0x3600000);              
            // 0x00BC49F4: LDR x8, [x27]              | X8 = typeof(System.Type);               
            // 0x00BC49F8: LDR x9, [x9, #0xff0]       | X9 = 1152921504607645696;               
            // 0x00BC49FC: MOV x20, x0                | X20 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4A00: LDR x22, [x9]              | X22 = typeof(System.UInt32);            
            // 0x00BC4A04: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC4A08: TBZ w9, #0, #0xbc4a1c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_40;
            // 0x00BC4A0C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC4A10: CBNZ w9, #0xbc4a1c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_40;
            // 0x00BC4A14: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC4A18: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_40:
            // 0x00BC4A1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC4A20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC4A24: MOV x1, x22                | X1 = 1152921504607645696 (0x10000000000C3000);//ML01
            // 0x00BC4A28: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_16 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC4A2C: MOV x22, x0                | X22 = val_16;//m1                       
            // 0x00BC4A30: CBNZ x20, #0xbc4a38        | if ( != null) goto label_41;            
            if(null != null)
            {
                goto label_41;
            }
            // 0x00BC4A34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_41:
            // 0x00BC4A38: CBZ x22, #0xbc4a5c         | if (val_16 == null) goto label_43;      
            if(val_16 == null)
            {
                goto label_43;
            }
            // 0x00BC4A3C: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BC4A40: MOV x0, x22                | X0 = val_16;//m1                        
            // 0x00BC4A44: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC4A48: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_16, ????);     
            // 0x00BC4A4C: CBNZ x0, #0xbc4a5c         | if (val_16 != null) goto label_43;      
            if(val_16 != null)
            {
                goto label_43;
            }
            // 0x00BC4A50: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_16, ????);     
            // 0x00BC4A54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4A58: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            label_43:
            // 0x00BC4A5C: LDR w8, [x20, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC4A60: CBNZ w8, #0xbc4a70         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_44;
            // 0x00BC4A64: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_16, ????);     
            // 0x00BC4A68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4A6C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            label_44:
            // 0x00BC4A70: STR x22, [x20, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_16;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_16;
            // 0x00BC4A74: CBNZ x21, #0xbc4a7c        | if (val_1 != null) goto label_45;       
            if(val_1 != null)
            {
                goto label_45;
            }
            // 0x00BC4A78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_45:
            // 0x00BC4A7C: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
            // 0x00BC4A80: LDR x8, [x8, #0xce8]       | X8 = (string**)(1152921510054807360)("StopCoroutine");
            // 0x00BC4A84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4A88: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC4A8C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC4A90: LDR x1, [x8]               | X1 = "StopCoroutine";                   
            // 0x00BC4A94: MOV x0, x21                | X0 = val_1;//m1                         
            // 0x00BC4A98: MOV x4, x20                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4A9C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC4AA0: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "StopCoroutine", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_17 = val_1.GetMethod(name:  "StopCoroutine", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC4AA4: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC4AA8: MOV x20, x0                | X20 = val_17;//m1                       
            // 0x00BC4AAC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC4AB0: LDR x22, [x8, #0x28]       | X22 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache5;
            val_125 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache5;
            // 0x00BC4AB4: CBNZ x22, #0xbc4b00        | if (ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache5 != null) goto label_46;
            if(val_125 != null)
            {
                goto label_46;
            }
            // 0x00BC4AB8: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
            // 0x00BC4ABC: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC4AC0: LDR x8, [x8, #0x7e8]       | X8 = 1152921510054811552;               
            // 0x00BC4AC4: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC4AC8: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::StopCoroutine_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC4ACC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_18 = null;
            // 0x00BC4AD0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC4AD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4AD8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4ADC: MOV x2, x22                | X2 = 1152921510054811552 (0x1000000144B957A0);//ML01
            // 0x00BC4AE0: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_119 = val_18;
            // 0x00BC4AE4: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::StopCoroutine_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_18 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::StopCoroutine_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC4AE8: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC4AEC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC4AF0: STR x23, [x8, #0x28]       | ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache5 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783048744
            ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache5 = val_119;
            // 0x00BC4AF4: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC4AF8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC4AFC: LDR x22, [x8, #0x28]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_125 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache5;
            label_46:
            // 0x00BC4B00: CBNZ x26, #0xbc4b08        | if (X1 != 0) goto label_47;             
            if(X1 != 0)
            {
                goto label_47;
            }
            // 0x00BC4B04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::StopCoroutine_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_47:
            // 0x00BC4B08: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4B0C: MOV x0, x26                | X0 = X1;//m1                            
            // 0x00BC4B10: MOV x1, x20                | X1 = val_17;//m1                        
            // 0x00BC4B14: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC4B18: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_17, func:  val_125);
            X1.RegisterCLRMethodRedirection(mi:  val_17, func:  val_125);
            // 0x00BC4B1C: LDR x20, [x28]             | X20 = typeof(System.Type[]);            
            // 0x00BC4B20: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4B24: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC4B28: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00BC4B2C: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4B30: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC4B34: ADRP x9, #0x3600000        | X9 = 56623104 (0x3600000);              
            // 0x00BC4B38: LDR x8, [x27]              | X8 = typeof(System.Type);               
            // 0x00BC4B3C: LDR x9, [x9, #0xff0]       | X9 = 1152921504607645696;               
            // 0x00BC4B40: MOV x20, x0                | X20 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4B44: LDR x22, [x9]              | X22 = typeof(System.UInt32);            
            // 0x00BC4B48: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC4B4C: TBZ w9, #0, #0xbc4b60      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_49;
            // 0x00BC4B50: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC4B54: CBNZ w9, #0xbc4b60         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_49;
            // 0x00BC4B58: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC4B5C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_49:
            // 0x00BC4B60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC4B64: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC4B68: MOV x1, x22                | X1 = 1152921504607645696 (0x10000000000C3000);//ML01
            // 0x00BC4B6C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_19 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC4B70: MOV x22, x0                | X22 = val_19;//m1                       
            // 0x00BC4B74: CBNZ x20, #0xbc4b7c        | if ( != null) goto label_50;            
            if(null != null)
            {
                goto label_50;
            }
            // 0x00BC4B78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
            label_50:
            // 0x00BC4B7C: CBZ x22, #0xbc4ba0         | if (val_19 == null) goto label_52;      
            if(val_19 == null)
            {
                goto label_52;
            }
            // 0x00BC4B80: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BC4B84: MOV x0, x22                | X0 = val_19;//m1                        
            // 0x00BC4B88: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC4B8C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_19, ????);     
            // 0x00BC4B90: CBNZ x0, #0xbc4ba0         | if (val_19 != null) goto label_52;      
            if(val_19 != null)
            {
                goto label_52;
            }
            // 0x00BC4B94: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_19, ????);     
            // 0x00BC4B98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4B9C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            label_52:
            // 0x00BC4BA0: LDR w8, [x20, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC4BA4: CBNZ w8, #0xbc4bb4         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_53;
            // 0x00BC4BA8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_19, ????);     
            // 0x00BC4BAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4BB0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            label_53:
            // 0x00BC4BB4: STR x22, [x20, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_19;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_19;
            // 0x00BC4BB8: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x00BC4BBC: LDR x8, [x8, #0xcb8]       | X8 = 1152921504608604160;               
            // 0x00BC4BC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC4BC4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC4BC8: LDR x1, [x8]               | X1 = typeof(System.Boolean);            
            // 0x00BC4BCC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_20 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC4BD0: MOV x22, x0                | X22 = val_20;//m1                       
            // 0x00BC4BD4: CBZ x22, #0xbc4bf8         | if (val_20 == null) goto label_55;      
            if(val_20 == null)
            {
                goto label_55;
            }
            // 0x00BC4BD8: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BC4BDC: MOV x0, x22                | X0 = val_20;//m1                        
            // 0x00BC4BE0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC4BE4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_20, ????);     
            // 0x00BC4BE8: CBNZ x0, #0xbc4bf8         | if (val_20 != null) goto label_55;      
            if(val_20 != null)
            {
                goto label_55;
            }
            // 0x00BC4BEC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_20, ????);     
            // 0x00BC4BF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4BF4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_20, ????);     
            label_55:
            // 0x00BC4BF8: LDR w8, [x20, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC4BFC: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00BC4C00: B.HI #0xbc4c10             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_56;
            // 0x00BC4C04: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_20, ????);     
            // 0x00BC4C08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4C0C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_20, ????);     
            label_56:
            // 0x00BC4C10: STR x22, [x20, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_20;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_20;
            // 0x00BC4C14: CBNZ x21, #0xbc4c1c        | if (val_1 != null) goto label_57;       
            if(val_1 != null)
            {
                goto label_57;
            }
            // 0x00BC4C18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
            label_57:
            // 0x00BC4C1C: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
            // 0x00BC4C20: LDR x8, [x8, #0x728]       | X8 = (string**)(1152921510054820768)("SetPause");
            // 0x00BC4C24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4C28: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC4C2C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC4C30: LDR x1, [x8]               | X1 = "SetPause";                        
            // 0x00BC4C34: MOV x0, x21                | X0 = val_1;//m1                         
            // 0x00BC4C38: MOV x4, x20                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4C3C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC4C40: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "SetPause", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_21 = val_1.GetMethod(name:  "SetPause", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC4C44: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC4C48: MOV x20, x0                | X20 = val_21;//m1                       
            // 0x00BC4C4C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC4C50: LDR x22, [x8, #0x30]       | X22 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache6;
            val_126 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache6;
            // 0x00BC4C54: CBNZ x22, #0xbc4ca0        | if (ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache6 != null) goto label_58;
            if(val_126 != null)
            {
                goto label_58;
            }
            // 0x00BC4C58: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
            // 0x00BC4C5C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC4C60: LDR x8, [x8, #0x8e0]       | X8 = 1152921510054824960;               
            // 0x00BC4C64: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC4C68: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::SetPause_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC4C6C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_22 = null;
            // 0x00BC4C70: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC4C74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4C78: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4C7C: MOV x2, x22                | X2 = 1152921510054824960 (0x1000000144B98C00);//ML01
            // 0x00BC4C80: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_119 = val_22;
            // 0x00BC4C84: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::SetPause_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_22 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::SetPause_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC4C88: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC4C8C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC4C90: STR x23, [x8, #0x30]       | ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache6 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783048752
            ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache6 = val_119;
            // 0x00BC4C94: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC4C98: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC4C9C: LDR x22, [x8, #0x30]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_126 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache6;
            label_58:
            // 0x00BC4CA0: CBNZ x26, #0xbc4ca8        | if (X1 != 0) goto label_59;             
            if(X1 != 0)
            {
                goto label_59;
            }
            // 0x00BC4CA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::SetPause_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_59:
            // 0x00BC4CA8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4CAC: MOV x0, x26                | X0 = X1;//m1                            
            // 0x00BC4CB0: MOV x1, x20                | X1 = val_21;//m1                        
            // 0x00BC4CB4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC4CB8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_21, func:  val_126);
            X1.RegisterCLRMethodRedirection(mi:  val_21, func:  val_126);
            // 0x00BC4CBC: LDR x20, [x28]             | X20 = typeof(System.Type[]);            
            // 0x00BC4CC0: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4CC4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC4CC8: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00BC4CCC: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4CD0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC4CD4: ADRP x9, #0x3683000        | X9 = 57159680 (0x3683000);              
            // 0x00BC4CD8: LDR x8, [x27]              | X8 = typeof(System.Type);               
            // 0x00BC4CDC: LDR x9, [x9, #0xc48]       | X9 = 1152921504608444416;               
            // 0x00BC4CE0: MOV x20, x0                | X20 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4CE4: LDR x22, [x9]              | X22 = typeof(System.Single);            
            // 0x00BC4CE8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC4CEC: TBZ w9, #0, #0xbc4d00      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_61;
            // 0x00BC4CF0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC4CF4: CBNZ w9, #0xbc4d00         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_61;
            // 0x00BC4CF8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC4CFC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_61:
            // 0x00BC4D00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC4D04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC4D08: MOV x1, x22                | X1 = 1152921504608444416 (0x1000000000186000);//ML01
            // 0x00BC4D0C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_23 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC4D10: MOV x22, x0                | X22 = val_23;//m1                       
            // 0x00BC4D14: CBNZ x20, #0xbc4d1c        | if ( != null) goto label_62;            
            if(null != null)
            {
                goto label_62;
            }
            // 0x00BC4D18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_62:
            // 0x00BC4D1C: CBZ x22, #0xbc4d40         | if (val_23 == null) goto label_64;      
            if(val_23 == null)
            {
                goto label_64;
            }
            // 0x00BC4D20: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BC4D24: MOV x0, x22                | X0 = val_23;//m1                        
            // 0x00BC4D28: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC4D2C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_23, ????);     
            // 0x00BC4D30: CBNZ x0, #0xbc4d40         | if (val_23 != null) goto label_64;      
            if(val_23 != null)
            {
                goto label_64;
            }
            // 0x00BC4D34: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_23, ????);     
            // 0x00BC4D38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4D3C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_64:
            // 0x00BC4D40: LDR w8, [x20, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC4D44: CBNZ w8, #0xbc4d54         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_65;
            // 0x00BC4D48: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x00BC4D4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4D50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_65:
            // 0x00BC4D54: STR x22, [x20, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_23;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_23;
            // 0x00BC4D58: ADRP x24, #0x3618000       | X24 = 56721408 (0x3618000);             
            // 0x00BC4D5C: LDR x24, [x24, #0x130]     | X24 = 1152921504687837184;              
            // 0x00BC4D60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC4D64: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC4D68: LDR x1, [x24]              | X1 = typeof(System.Action);             
            // 0x00BC4D6C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_24 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC4D70: MOV x22, x0                | X22 = val_24;//m1                       
            // 0x00BC4D74: CBZ x22, #0xbc4d98         | if (val_24 == null) goto label_67;      
            if(val_24 == null)
            {
                goto label_67;
            }
            // 0x00BC4D78: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BC4D7C: MOV x0, x22                | X0 = val_24;//m1                        
            // 0x00BC4D80: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC4D84: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_24, ????);     
            // 0x00BC4D88: CBNZ x0, #0xbc4d98         | if (val_24 != null) goto label_67;      
            if(val_24 != null)
            {
                goto label_67;
            }
            // 0x00BC4D8C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_24, ????);     
            // 0x00BC4D90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4D94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_24, ????);     
            label_67:
            // 0x00BC4D98: LDR w8, [x20, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC4D9C: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00BC4DA0: B.HI #0xbc4db0             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_68;
            // 0x00BC4DA4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_24, ????);     
            // 0x00BC4DA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4DAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_24, ????);     
            label_68:
            // 0x00BC4DB0: STR x22, [x20, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_24;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_24;
            // 0x00BC4DB4: CBNZ x21, #0xbc4dbc        | if (val_1 != null) goto label_69;       
            if(val_1 != null)
            {
                goto label_69;
            }
            // 0x00BC4DB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
            label_69:
            // 0x00BC4DBC: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x00BC4DC0: LDR x8, [x8, #0x340]       | X8 = (string**)(1152921510054834176)("JSDelayCall");
            // 0x00BC4DC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4DC8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC4DCC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC4DD0: LDR x1, [x8]               | X1 = "JSDelayCall";                     
            // 0x00BC4DD4: MOV x0, x21                | X0 = val_1;//m1                         
            // 0x00BC4DD8: MOV x4, x20                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4DDC: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC4DE0: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "JSDelayCall", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_25 = val_1.GetMethod(name:  "JSDelayCall", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC4DE4: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC4DE8: MOV x20, x0                | X20 = val_25;//m1                       
            // 0x00BC4DEC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC4DF0: LDR x22, [x8, #0x38]       | X22 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache7;
            val_127 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache7;
            // 0x00BC4DF4: CBNZ x22, #0xbc4e40        | if (ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache7 != null) goto label_70;
            if(val_127 != null)
            {
                goto label_70;
            }
            // 0x00BC4DF8: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x00BC4DFC: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC4E00: LDR x8, [x8, #0x1a0]       | X8 = 1152921510054838368;               
            // 0x00BC4E04: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC4E08: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::JSDelayCall_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC4E0C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_26 = null;
            // 0x00BC4E10: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC4E14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4E18: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4E1C: MOV x2, x22                | X2 = 1152921510054838368 (0x1000000144B9C060);//ML01
            // 0x00BC4E20: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_119 = val_26;
            // 0x00BC4E24: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::JSDelayCall_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_26 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::JSDelayCall_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC4E28: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC4E2C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC4E30: STR x23, [x8, #0x38]       | ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache7 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783048760
            ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache7 = val_119;
            // 0x00BC4E34: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC4E38: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC4E3C: LDR x22, [x8, #0x38]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_127 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache7;
            label_70:
            // 0x00BC4E40: CBNZ x26, #0xbc4e48        | if (X1 != 0) goto label_71;             
            if(X1 != 0)
            {
                goto label_71;
            }
            // 0x00BC4E44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::JSDelayCall_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_71:
            // 0x00BC4E48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4E4C: MOV x0, x26                | X0 = X1;//m1                            
            // 0x00BC4E50: MOV x1, x20                | X1 = val_25;//m1                        
            // 0x00BC4E54: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC4E58: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_25, func:  val_127);
            X1.RegisterCLRMethodRedirection(mi:  val_25, func:  val_127);
            // 0x00BC4E5C: LDR x20, [x28]             | X20 = typeof(System.Type[]);            
            // 0x00BC4E60: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4E64: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC4E68: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00BC4E6C: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4E70: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC4E74: ADRP x9, #0x3683000        | X9 = 57159680 (0x3683000);              
            // 0x00BC4E78: LDR x8, [x27]              | X8 = typeof(System.Type);               
            // 0x00BC4E7C: LDR x9, [x9, #0xc48]       | X9 = 1152921504608444416;               
            // 0x00BC4E80: MOV x20, x0                | X20 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4E84: LDR x22, [x9]              | X22 = typeof(System.Single);            
            // 0x00BC4E88: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC4E8C: TBZ w9, #0, #0xbc4ea0      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_73;
            // 0x00BC4E90: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC4E94: CBNZ w9, #0xbc4ea0         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_73;
            // 0x00BC4E98: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC4E9C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_73:
            // 0x00BC4EA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC4EA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC4EA8: MOV x1, x22                | X1 = 1152921504608444416 (0x1000000000186000);//ML01
            // 0x00BC4EAC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_27 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC4EB0: MOV x22, x0                | X22 = val_27;//m1                       
            // 0x00BC4EB4: CBNZ x20, #0xbc4ebc        | if ( != null) goto label_74;            
            if(null != null)
            {
                goto label_74;
            }
            // 0x00BC4EB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
            label_74:
            // 0x00BC4EBC: CBZ x22, #0xbc4ee0         | if (val_27 == null) goto label_76;      
            if(val_27 == null)
            {
                goto label_76;
            }
            // 0x00BC4EC0: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BC4EC4: MOV x0, x22                | X0 = val_27;//m1                        
            // 0x00BC4EC8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC4ECC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_27, ????);     
            // 0x00BC4ED0: CBNZ x0, #0xbc4ee0         | if (val_27 != null) goto label_76;      
            if(val_27 != null)
            {
                goto label_76;
            }
            // 0x00BC4ED4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_27, ????);     
            // 0x00BC4ED8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4EDC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_27, ????);     
            label_76:
            // 0x00BC4EE0: LDR w8, [x20, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC4EE4: CBNZ w8, #0xbc4ef4         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_77;
            // 0x00BC4EE8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_27, ????);     
            // 0x00BC4EEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4EF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_27, ????);     
            label_77:
            // 0x00BC4EF4: STR x22, [x20, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_27;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_27;
            // 0x00BC4EF8: LDR x1, [x24]              | X1 = typeof(System.Action);             
            // 0x00BC4EFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC4F00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC4F04: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_28 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC4F08: MOV x22, x0                | X22 = val_28;//m1                       
            // 0x00BC4F0C: CBZ x22, #0xbc4f30         | if (val_28 == null) goto label_79;      
            if(val_28 == null)
            {
                goto label_79;
            }
            // 0x00BC4F10: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BC4F14: MOV x0, x22                | X0 = val_28;//m1                        
            // 0x00BC4F18: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC4F1C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_28, ????);     
            // 0x00BC4F20: CBNZ x0, #0xbc4f30         | if (val_28 != null) goto label_79;      
            if(val_28 != null)
            {
                goto label_79;
            }
            // 0x00BC4F24: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_28, ????);     
            // 0x00BC4F28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4F2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_28, ????);     
            label_79:
            // 0x00BC4F30: LDR w8, [x20, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC4F34: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00BC4F38: B.HI #0xbc4f48             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_80;
            // 0x00BC4F3C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_28, ????);     
            // 0x00BC4F40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4F44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_28, ????);     
            label_80:
            // 0x00BC4F48: STR x22, [x20, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_28;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_28;
            // 0x00BC4F4C: CBNZ x21, #0xbc4f54        | if (val_1 != null) goto label_81;       
            if(val_1 != null)
            {
                goto label_81;
            }
            // 0x00BC4F50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
            label_81:
            // 0x00BC4F54: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
            // 0x00BC4F58: LDR x8, [x8, #0xc90]       | X8 = (string**)(1152921510054847584)("DelayCall");
            // 0x00BC4F5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4F60: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC4F64: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC4F68: LDR x1, [x8]               | X1 = "DelayCall";                       
            // 0x00BC4F6C: MOV x0, x21                | X0 = val_1;//m1                         
            // 0x00BC4F70: MOV x4, x20                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4F74: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC4F78: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "DelayCall", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_29 = val_1.GetMethod(name:  "DelayCall", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC4F7C: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC4F80: MOV x20, x0                | X20 = val_29;//m1                       
            // 0x00BC4F84: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC4F88: LDR x22, [x8, #0x40]       | X22 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache8;
            val_128 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache8;
            // 0x00BC4F8C: CBNZ x22, #0xbc4fd8        | if (ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache8 != null) goto label_82;
            if(val_128 != null)
            {
                goto label_82;
            }
            // 0x00BC4F90: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x00BC4F94: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC4F98: LDR x8, [x8, #0x320]       | X8 = 1152921510054851776;               
            // 0x00BC4F9C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC4FA0: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::DelayCall_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC4FA4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_30 = null;
            // 0x00BC4FA8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC4FAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4FB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4FB4: MOV x2, x22                | X2 = 1152921510054851776 (0x1000000144B9F4C0);//ML01
            // 0x00BC4FB8: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_119 = val_30;
            // 0x00BC4FBC: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::DelayCall_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_30 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::DelayCall_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC4FC0: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC4FC4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC4FC8: STR x23, [x8, #0x40]       | ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache8 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783048768
            ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache8 = val_119;
            // 0x00BC4FCC: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC4FD0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC4FD4: LDR x22, [x8, #0x40]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_128 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache8;
            label_82:
            // 0x00BC4FD8: CBNZ x26, #0xbc4fe0        | if (X1 != 0) goto label_83;             
            if(X1 != 0)
            {
                goto label_83;
            }
            // 0x00BC4FDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::DelayCall_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_83:
            // 0x00BC4FE0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4FE4: MOV x0, x26                | X0 = X1;//m1                            
            // 0x00BC4FE8: MOV x1, x20                | X1 = val_29;//m1                        
            // 0x00BC4FEC: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC4FF0: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_29, func:  val_128);
            X1.RegisterCLRMethodRedirection(mi:  val_29, func:  val_128);
            // 0x00BC4FF4: LDR x20, [x28]             | X20 = typeof(System.Type[]);            
            // 0x00BC4FF8: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC4FFC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC5000: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BC5004: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC5008: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC500C: ADRP x9, #0x3683000        | X9 = 57159680 (0x3683000);              
            // 0x00BC5010: LDR x8, [x27]              | X8 = typeof(System.Type);               
            // 0x00BC5014: LDR x9, [x9, #0xc48]       | X9 = 1152921504608444416;               
            // 0x00BC5018: MOV x20, x0                | X20 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC501C: LDR x22, [x9]              | X22 = typeof(System.Single);            
            // 0x00BC5020: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC5024: TBZ w9, #0, #0xbc5038      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_85;
            // 0x00BC5028: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC502C: CBNZ w9, #0xbc5038         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_85;
            // 0x00BC5030: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC5034: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_85:
            // 0x00BC5038: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC503C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC5040: MOV x1, x22                | X1 = 1152921504608444416 (0x1000000000186000);//ML01
            // 0x00BC5044: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_31 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC5048: MOV x22, x0                | X22 = val_31;//m1                       
            // 0x00BC504C: CBNZ x20, #0xbc5054        | if ( != null) goto label_86;            
            if(null != null)
            {
                goto label_86;
            }
            // 0x00BC5050: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
            label_86:
            // 0x00BC5054: CBZ x22, #0xbc5078         | if (val_31 == null) goto label_88;      
            if(val_31 == null)
            {
                goto label_88;
            }
            // 0x00BC5058: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BC505C: MOV x0, x22                | X0 = val_31;//m1                        
            // 0x00BC5060: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC5064: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_31, ????);     
            // 0x00BC5068: CBNZ x0, #0xbc5078         | if (val_31 != null) goto label_88;      
            if(val_31 != null)
            {
                goto label_88;
            }
            // 0x00BC506C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_31, ????);     
            // 0x00BC5070: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5074: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_31, ????);     
            label_88:
            // 0x00BC5078: LDR w8, [x20, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC507C: CBNZ w8, #0xbc508c         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_89;
            // 0x00BC5080: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_31, ????);     
            // 0x00BC5084: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5088: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_31, ????);     
            label_89:
            // 0x00BC508C: STR x22, [x20, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_31;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_31;
            // 0x00BC5090: CBNZ x21, #0xbc5098        | if (val_1 != null) goto label_90;       
            if(val_1 != null)
            {
                goto label_90;
            }
            // 0x00BC5094: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
            label_90:
            // 0x00BC5098: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
            // 0x00BC509C: LDR x8, [x8, #0x410]       | X8 = (string**)(1152921510054856896)("DelayPause");
            // 0x00BC50A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC50A4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC50A8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC50AC: LDR x1, [x8]               | X1 = "DelayPause";                      
            // 0x00BC50B0: MOV x0, x21                | X0 = val_1;//m1                         
            // 0x00BC50B4: MOV x4, x20                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC50B8: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC50BC: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "DelayPause", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_32 = val_1.GetMethod(name:  "DelayPause", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC50C0: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC50C4: MOV x20, x0                | X20 = val_32;//m1                       
            // 0x00BC50C8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC50CC: LDR x22, [x8, #0x48]       | X22 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache9;
            val_129 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache9;
            // 0x00BC50D0: CBNZ x22, #0xbc511c        | if (ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache9 != null) goto label_91;
            if(val_129 != null)
            {
                goto label_91;
            }
            // 0x00BC50D4: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
            // 0x00BC50D8: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC50DC: LDR x8, [x8, #0xb80]       | X8 = 1152921510054861088;               
            // 0x00BC50E0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC50E4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::DelayPause_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC50E8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_33 = null;
            // 0x00BC50EC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC50F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC50F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC50F8: MOV x2, x22                | X2 = 1152921510054861088 (0x1000000144BA1920);//ML01
            // 0x00BC50FC: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_119 = val_33;
            // 0x00BC5100: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::DelayPause_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_33 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::DelayPause_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC5104: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC5108: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC510C: STR x23, [x8, #0x48]       | ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache9 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783048776
            ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache9 = val_119;
            // 0x00BC5110: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC5114: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC5118: LDR x22, [x8, #0x48]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_129 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache9;
            label_91:
            // 0x00BC511C: CBNZ x26, #0xbc5124        | if (X1 != 0) goto label_92;             
            if(X1 != 0)
            {
                goto label_92;
            }
            // 0x00BC5120: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::DelayPause_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_92:
            // 0x00BC5124: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC5128: MOV x0, x26                | X0 = X1;//m1                            
            // 0x00BC512C: MOV x1, x20                | X1 = val_32;//m1                        
            // 0x00BC5130: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC5134: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_32, func:  val_129);
            X1.RegisterCLRMethodRedirection(mi:  val_32, func:  val_129);
            // 0x00BC5138: LDR x20, [x28]             | X20 = typeof(System.Type[]);            
            // 0x00BC513C: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC5140: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC5144: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5148: MOV x0, x20                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC514C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC5150: MOV x20, x0                | X20 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC5154: CBNZ x21, #0xbc515c        | if (val_1 != null) goto label_93;       
            if(val_1 != null)
            {
                goto label_93;
            }
            // 0x00BC5158: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_93:
            // 0x00BC515C: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
            // 0x00BC5160: LDR x8, [x8, #0xc08]       | X8 = (string**)(1152921510054862112)("get_GlobalCoroutine");
            // 0x00BC5164: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC5168: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC516C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC5170: LDR x1, [x8]               | X1 = "get_GlobalCoroutine";             
            // 0x00BC5174: MOV x0, x21                | X0 = val_1;//m1                         
            // 0x00BC5178: MOV x4, x20                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC517C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC5180: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_GlobalCoroutine", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_34 = val_1.GetMethod(name:  "get_GlobalCoroutine", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC5184: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC5188: MOV x20, x0                | X20 = val_34;//m1                       
            // 0x00BC518C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC5190: LDR x22, [x8, #0x50]       | X22 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheA;
            val_130 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheA;
            // 0x00BC5194: CBNZ x22, #0xbc51e0        | if (ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheA != null) goto label_94;
            if(val_130 != null)
            {
                goto label_94;
            }
            // 0x00BC5198: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
            // 0x00BC519C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC51A0: LDR x8, [x8, #0xf8]        | X8 = 1152921510054866320;               
            // 0x00BC51A4: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC51A8: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::get_GlobalCoroutine_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC51AC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_35 = null;
            // 0x00BC51B0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC51B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC51B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC51BC: MOV x2, x22                | X2 = 1152921510054866320 (0x1000000144BA2D90);//ML01
            // 0x00BC51C0: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_119 = val_35;
            // 0x00BC51C4: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::get_GlobalCoroutine_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_35 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::get_GlobalCoroutine_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC51C8: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC51CC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC51D0: STR x23, [x8, #0x50]       | ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheA = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783048784
            ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheA = val_119;
            // 0x00BC51D4: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC51D8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC51DC: LDR x22, [x8, #0x50]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_130 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheA;
            label_94:
            // 0x00BC51E0: CBNZ x26, #0xbc51e8        | if (X1 != 0) goto label_95;             
            if(X1 != 0)
            {
                goto label_95;
            }
            // 0x00BC51E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::get_GlobalCoroutine_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_95:
            // 0x00BC51E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC51EC: MOV x0, x26                | X0 = X1;//m1                            
            // 0x00BC51F0: MOV x1, x20                | X1 = val_34;//m1                        
            // 0x00BC51F4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC51F8: STR x26, [sp, #0x10]       | stack[1152921510055116560] = X1;         //  dest_result_addr=1152921510055116560
            // 0x00BC51FC: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_34, func:  val_130);
            X1.RegisterCLRMethodRedirection(mi:  val_34, func:  val_130);
            // 0x00BC5200: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
            // 0x00BC5204: LDR x8, [x8, #0x870]       | X8 = 1152921504615792640;               
            // 0x00BC5208: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.Reflection.MethodInfo>> val_36 = null;
            // 0x00BC520C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x00BC5210: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x00BC5214: LDR x8, [x8, #0x688]       | X8 = 1152921510054867344;               
            // 0x00BC5218: MOV x20, x0                | X20 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x00BC521C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.Reflection.MethodInfo>>::.ctor();
            // 0x00BC5220: BL #0x23fb0c4              | .ctor();                                
            val_36 = new System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.Reflection.MethodInfo>>();
            // 0x00BC5224: STUR xzr, [x29, #-0x58]    | stack[1152921510055116808] = 0x0;        //  dest_result_addr=1152921510055116808
            System.Collections.Generic.List<System.Reflection.MethodInfo> val_38 = 0;
            // 0x00BC5228: CBNZ x21, #0xbc5230        | if (val_1 != null) goto label_96;       
            if(val_1 != null)
            {
                goto label_96;
            }
            // 0x00BC522C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_96:
            // 0x00BC5230: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5234: MOV x0, x21                | X0 = val_1;//m1                         
            // 0x00BC5238: BL #0x1b6e2d4              | X0 = val_1.GetMethods();                
            System.Reflection.MethodInfo[] val_37 = val_1.GetMethods();
            // 0x00BC523C: ADRP x24, #0x35c9000       | X24 = 56397824 (0x35C9000);             
            // 0x00BC5240: ADRP x28, #0x365f000       | X28 = 57012224 (0x365F000);             
            // 0x00BC5244: ADRP x26, #0x3662000       | X26 = 57024512 (0x3662000);             
            // 0x00BC5248: ADRP x19, #0x35f9000       | X19 = 56594432 (0x35F9000);             
            // 0x00BC524C: LDR x24, [x24, #0xcf8]     | X24 = 1152921510054905232;              
            val_131 = 1152921510054905232;
            // 0x00BC5250: LDR x28, [x28, #0x330]     | X28 = 1152921510054906256;              
            // 0x00BC5254: LDR x26, [x26, #0xd78]     | X26 = 1152921510054907280;              
            // 0x00BC5258: LDR x19, [x19, #0x8c8]     | X19 = 1152921510054908304;              
            // 0x00BC525C: MOV x21, x0                | X21 = val_37;//m1                       
            // 0x00BC5260: MOV w27, wzr               | W27 = 0 (0x0);//ML01                    
            val_132 = 0;
            // 0x00BC5264: B #0xbc526c                |  goto label_97;                         
            goto label_97;
            label_108:
            // 0x00BC5268: ADD w27, w27, #1           | W27 = (val_132 + 1) = val_132 (0x00000001);
            val_132 = 1;
            label_97:
            // 0x00BC526C: CBNZ x21, #0xbc5274        | if (val_37 != null) goto label_98;      
            if(val_37 != null)
            {
                goto label_98;
            }
            // 0x00BC5270: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
            label_98:
            // 0x00BC5274: LDR w8, [x21, #0x18]       | W8 = val_37.Length; //P2                
            // 0x00BC5278: CMP w27, w8                | STATE = COMPARE(0x1, val_37.Length)     
            // 0x00BC527C: B.GE #0xbc5384             | if (val_132 >= val_37.Length) goto label_99;
            if(val_132 >= val_37.Length)
            {
                goto label_99;
            }
            // 0x00BC5280: SXTW x22, w27              | X22 = 1 (0x00000001);                   
            // 0x00BC5284: CMP w27, w8                | STATE = COMPARE(0x1, val_37.Length)     
            // 0x00BC5288: B.LO #0xbc5298             | if (val_132 < val_37.Length) goto label_100;
            if(val_132 < val_37.Length)
            {
                goto label_100;
            }
            // 0x00BC528C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_37, ????);     
            // 0x00BC5290: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5294: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_37, ????);     
            label_100:
            // 0x00BC5298: ADD x8, x21, x22, lsl #3   | X8 = val_37[0x1]; //PARR1               
            // 0x00BC529C: LDR x22, [x8, #0x20]       | X22 = val_37[0x1][0]                    
            System.Reflection.MethodInfo val_117 = val_37[1];
            // 0x00BC52A0: CBNZ x22, #0xbc52a8        | if (val_37[0x1][0] != null) goto label_101;
            if(val_117 != null)
            {
                goto label_101;
            }
            // 0x00BC52A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
            label_101:
            // 0x00BC52A8: LDR x8, [x22]              | X8 = typeof(System.Reflection.MethodInfo);
            // 0x00BC52AC: MOV x0, x22                | X0 = val_37[0x1][0];//m1                
            // 0x00BC52B0: LDR x9, [x8, #0x350]       | X9 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_350;
            // 0x00BC52B4: LDR x1, [x8, #0x358]       | X1 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_358;
            // 0x00BC52B8: BLR x9                     | X0 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_350();
            // 0x00BC52BC: TBZ w0, #0, #0xbc5268      | if ((val_37[0x1][0] & 0x1) == 0) goto label_108;
            if((val_117 & 1) == 0)
            {
                goto label_108;
            }
            // 0x00BC52C0: LDR x8, [x22]              | X8 = typeof(System.Reflection.MethodInfo);
            // 0x00BC52C4: MOV x0, x22                | X0 = val_37[0x1][0];//m1                
            // 0x00BC52C8: LDP x9, x1, [x8, #0x190]   | X9 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_190; X1 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_198; //  | 
            // 0x00BC52CC: BLR x9                     | X0 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_190();
            // 0x00BC52D0: MOV x23, x0                | X23 = val_37[0x1][0];//m1               
            // 0x00BC52D4: CBNZ x20, #0xbc52dc        | if ( != 0) goto label_103;              
            if(null != 0)
            {
                goto label_103;
            }
            // 0x00BC52D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37[0x1][0], ????);
            label_103:
            // 0x00BC52DC: LDR x3, [x24]              | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.Reflection.MethodInfo>>::TryGetValue(System.String key, out System.Collections.Generic.List<System.Reflection.MethodInfo> value);
            // 0x00BC52E0: SUB x2, x29, #0x58         | X2 = (1152921510055116896 - 88) = 1152921510055116808 (0x1000000144BE0008);
            // 0x00BC52E4: MOV x0, x20                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x00BC52E8: MOV x1, x23                | X1 = val_37[0x1][0];//m1                
            // 0x00BC52EC: BL #0x23fe7ec              | X0 = TryGetValue(key:  val_37[1], value: out  System.Collections.Generic.List<System.Reflection.MethodInfo> val_38 = 0);
            bool val_39 = TryGetValue(key:  val_117, value: out  val_38);
            // 0x00BC52F0: AND w8, w0, #1             | W8 = (val_39 & 1);                      
            bool val_40 = val_39;
            // 0x00BC52F4: TBNZ w8, #0, #0xbc5364     | if ((val_39 & 1) == true) goto label_104;
            if(val_40 == true)
            {
                goto label_104;
            }
            // 0x00BC52F8: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x00BC52FC: LDR x8, [x8, #0x5a0]       | X8 = 1152921504616644608;               
            // 0x00BC5300: MOV x25, x20               | X25 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x00BC5304: MOV x20, x24               | X20 = 58072624 (0x3761E30);//ML01       
            // 0x00BC5308: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.Reflection.MethodInfo> val_41 = null;
            // 0x00BC530C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00BC5310: LDR x1, [x26]              | X1 = public System.Void System.Collections.Generic.List<System.Reflection.MethodInfo>::.ctor();
            // 0x00BC5314: MOV x23, x0                | X23 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00BC5318: BL #0x25e9474              | .ctor();                                
            val_41 = new System.Collections.Generic.List<System.Reflection.MethodInfo>();
            // 0x00BC531C: STUR x23, [x29, #-0x58]    | stack[1152921510055116808] = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921510055116808
            System.Collections.Generic.List<System.Reflection.MethodInfo> val_43 = val_41;
            // 0x00BC5320: CBNZ x22, #0xbc5328        | if (val_37[0x1][0] != null) goto label_105;
            if(val_117 != null)
            {
                goto label_105;
            }
            // 0x00BC5324: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_105:
            // 0x00BC5328: LDR x8, [x22]              | X8 = typeof(System.Reflection.MethodInfo);
            // 0x00BC532C: MOV x0, x22                | X0 = val_37[0x1][0];//m1                
            // 0x00BC5330: LDP x9, x1, [x8, #0x190]   | X9 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_190; X1 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_198; //  | 
            // 0x00BC5334: BLR x9                     | X0 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_190();
            // 0x00BC5338: LDUR x23, [x29, #-0x58]    | X23 = typeof(System.Collections.Generic.List<T>);
            // 0x00BC533C: MOV x24, x0                | X24 = val_37[0x1][0];//m1               
            // 0x00BC5340: CBNZ x25, #0xbc5348        | if ( != 0) goto label_106;              
            if(null != 0)
            {
                goto label_106;
            }
            // 0x00BC5344: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37[0x1][0], ????);
            label_106:
            // 0x00BC5348: LDR x3, [x19]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.Reflection.MethodInfo>>::set_Item(System.String key, System.Collections.Generic.List<System.Reflection.MethodInfo> value);
            // 0x00BC534C: MOV x0, x25                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x00BC5350: MOV x1, x24                | X1 = val_37[0x1][0];//m1                
            // 0x00BC5354: MOV x2, x23                | X2 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00BC5358: BL #0x23fc55c              | set_Item(key:  val_37[1], value:  val_41);
            set_Item(key:  val_117, value:  val_43);
            // 0x00BC535C: MOV x24, x20               | X24 = 58072624 (0x3761E30);//ML01       
            // 0x00BC5360: MOV x20, x25               | X20 = 1152921504615792640 (0x1000000000888000);//ML01
            label_104:
            // 0x00BC5364: LDUR x23, [x29, #-0x58]    | X23 = typeof(System.Collections.Generic.List<T>);
            // 0x00BC5368: CBNZ x23, #0xbc5370        | if ( != 0) goto label_107;              
            if(null != 0)
            {
                goto label_107;
            }
            // 0x00BC536C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            label_107:
            // 0x00BC5370: LDR x2, [x28]              | X2 = public System.Void System.Collections.Generic.List<System.Reflection.MethodInfo>::Add(System.Reflection.MethodInfo item);
            // 0x00BC5374: MOV x0, x23                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00BC5378: MOV x1, x22                | X1 = val_37[0x1][0];//m1                
            // 0x00BC537C: BL #0x25ea480              | Add(item:  val_37[1]);                  
            Add(item:  val_117);
            // 0x00BC5380: B #0xbc5268                |  goto label_108;                        
            goto label_108;
            label_99:
            // 0x00BC5384: ADRP x28, #0x35ef000       | X28 = 56553472 (0x35EF000);             
            // 0x00BC5388: LDR x28, [x28, #0xff0]     | X28 = 1152921504987155056;              
            val_133 = 1152921504987155056;
            // 0x00BC538C: LDR x21, [x28]             | X21 = typeof(System.Type[]);            
            // 0x00BC5390: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC5394: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC5398: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BC539C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC53A0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC53A4: ADRP x19, #0x3620000       | X19 = 56754176 (0x3620000);             
            // 0x00BC53A8: LDR x19, [x19, #0x340]     | X19 = 1152921504609562624;              
            val_134 = 1152921504609562624;
            // 0x00BC53AC: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x00BC53B0: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC53B4: LDR x8, [x19]              | X8 = typeof(System.Type);               
            // 0x00BC53B8: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x00BC53BC: LDR x22, [x9]              | X22 = typeof(System.String);            
            // 0x00BC53C0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC53C4: TBZ w9, #0, #0xbc53d8      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_110;
            // 0x00BC53C8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC53CC: CBNZ w9, #0xbc53d8         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_110;
            // 0x00BC53D0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC53D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_110:
            // 0x00BC53D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC53DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC53E0: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BC53E4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_42 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC53E8: ADRP x26, #0x366b000       | X26 = 57061376 (0x366B000);             
            // 0x00BC53EC: LDR x26, [x26, #0x340]     | X26 = (string**)(1152921510054834176)("JSDelayCall");
            val_135 = "JSDelayCall";
            // 0x00BC53F0: MOV x22, x0                | X22 = val_42;//m1                       
            // 0x00BC53F4: CBNZ x21, #0xbc53fc        | if ( != null) goto label_111;           
            if(null != null)
            {
                goto label_111;
            }
            // 0x00BC53F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            label_111:
            // 0x00BC53FC: CBZ x22, #0xbc5420         | if (val_42 == null) goto label_113;     
            if(val_42 == null)
            {
                goto label_113;
            }
            // 0x00BC5400: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC5404: MOV x0, x22                | X0 = val_42;//m1                        
            // 0x00BC5408: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC540C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_42, ????);     
            // 0x00BC5410: CBNZ x0, #0xbc5420         | if (val_42 != null) goto label_113;     
            if(val_42 != null)
            {
                goto label_113;
            }
            // 0x00BC5414: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_42, ????);     
            // 0x00BC5418: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC541C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            label_113:
            // 0x00BC5420: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC5424: CBNZ w8, #0xbc5434         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_114;
            // 0x00BC5428: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_42, ????);     
            // 0x00BC542C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5430: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            label_114:
            // 0x00BC5434: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_42;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_42;
            // 0x00BC5438: CBNZ x20, #0xbc5440        | if ( != 0) goto label_115;              
            if(null != 0)
            {
                goto label_115;
            }
            // 0x00BC543C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            label_115:
            // 0x00BC5440: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
            // 0x00BC5444: LDR x8, [x8, #0xc90]       | X8 = (string**)(1152921510054847584)("DelayCall");
            // 0x00BC5448: LDR x3, [x24]              | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.Reflection.MethodInfo>>::TryGetValue(System.String key, out System.Collections.Generic.List<System.Reflection.MethodInfo> value);
            // 0x00BC544C: SUB x2, x29, #0x58         | X2 = (1152921510055116896 - 88) = 1152921510055116808 (0x1000000144BE0008);
            // 0x00BC5450: MOV x0, x20                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x00BC5454: LDR x1, [x8]               | X1 = "DelayCall";                       
            // 0x00BC5458: BL #0x23fe7ec              | X0 = TryGetValue(key:  "DelayCall", value: out  System.Collections.Generic.List<System.Reflection.MethodInfo> val_43 = val_41);
            bool val_44 = TryGetValue(key:  "DelayCall", value: out  val_43);
            // 0x00BC545C: TBZ w0, #0, #0xbc5780      | if (val_44 == false) goto label_136;    
            if(val_44 == false)
            {
                goto label_136;
            }
            // 0x00BC5460: LDUR x22, [x29, #-0x58]    | X22 = typeof(System.Collections.Generic.List<T>);
            // 0x00BC5464: MOV x26, x28               | X26 = 57978136 (0x374AD18);//ML01       
            // 0x00BC5468: CBNZ x22, #0xbc5470        | if ( != 0) goto label_117;              
            if(null != 0)
            {
                goto label_117;
            }
            // 0x00BC546C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_44, ????);     
            label_117:
            // 0x00BC5470: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x00BC5474: LDR x8, [x8, #0x60]        | X8 = 1152921510054917520;               
            // 0x00BC5478: MOV x0, x22                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00BC547C: LDR x1, [x8]               | X1 = public List.Enumerator<T> System.Collections.Generic.List<System.Reflection.MethodInfo>::GetEnumerator();
            // 0x00BC5480: ADD x8, sp, #0x18          | X8 = (1152921510055116544 + 24) = 1152921510055116568 (0x1000000144BDFF18);
            // 0x00BC5484: BL #0x25ebf2c              | X0 = GetEnumerator();                   
            List.Enumerator<T> val_45 = GetEnumerator();
            // 0x00BC5488: LDR x8, [sp, #0x28]        | X8 = val_46;                             //  find_add[1152921510055104912]
            // 0x00BC548C: ADRP x27, #0x3671000       | X27 = 57085952 (0x3671000);             
            // 0x00BC5490: ADRP x28, #0x360e000       | X28 = 56680448 (0x360E000);             
            // 0x00BC5494: LDUR q0, [sp, #0x18]       | Q0 = val_47;                             //  find_add[1152921510055104912]
            // 0x00BC5498: LDR x27, [x27, #0x830]     | X27 = 1152921510054918544;              
            // 0x00BC549C: LDR x28, [x28, #0x9f0]     | X28 = 1152921510054919568;              
            // 0x00BC54A0: STUR x8, [x29, #-0x60]     | stack[1152921510055116800] = val_46;     //  dest_result_addr=1152921510055116800
            // 0x00BC54A4: ADD x8, sp, #0xb0          | X8 = (1152921510055116544 + 176) = 1152921510055116720 (0x1000000144BDFFB0);
            // 0x00BC54A8: STR q0, [x8, #0x40]        | stack[1152921510055116784] = val_47;     //  dest_result_addr=1152921510055116784
            label_131:
            // 0x00BC54AC: LDR x1, [x27]              | X1 = public System.Boolean List.Enumerator<System.Reflection.MethodInfo>::MoveNext();
            // 0x00BC54B0: SUB x0, x29, #0x70         | X0 = (1152921510055116896 - 112) = 1152921510055116784 (0x1000000144BDFFF0);
            // 0x00BC54B4: BL #0x133720c              | X0 = label_List_Enumerator<System_Object>_VerifyState_GL0133720C();
            // 0x00BC54B8: AND w8, w0, #1             | W8 = (1152921510055116784 & 1) = 0 (0x00000000);
            // 0x00BC54BC: TBZ w8, #0, #0xbc5710      | if ((0x0 & 0x1) == 0) goto label_118;   
            if((0 & 1) == 0)
            {
                goto label_118;
            }
            // 0x00BC54C0: LDR x1, [x28]              | X1 = public System.Reflection.MethodInfo List.Enumerator<System.Reflection.MethodInfo>::get_Current();
            // 0x00BC54C4: SUB x0, x29, #0x70         | X0 = (1152921510055116896 - 112) = 1152921510055116784 (0x1000000144BDFFF0);
            // 0x00BC54C8: BL #0x13372d8              | X0 = val_47.get_InitialType();          
            System.Type val_48 = val_47.InitialType;
            // 0x00BC54CC: MOV x22, x0                | X22 = val_48;//m1                       
            // 0x00BC54D0: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x00BC54D4: LDR x0, [x19]              | X0 = typeof(System.Type);               
            // 0x00BC54D8: LDR x8, [x8, #0xff0]       | X8 = 1152921504607645696;               
            // 0x00BC54DC: LDR x23, [x8]              | X23 = typeof(System.UInt32);            
            // 0x00BC54E0: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC54E4: TBZ w8, #0, #0xbc54f4      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_120;
            // 0x00BC54E8: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC54EC: CBNZ w8, #0xbc54f4         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_120;
            // 0x00BC54F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_120:
            // 0x00BC54F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC54F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC54FC: MOV x1, x23                | X1 = 1152921504607645696 (0x10000000000C3000);//ML01
            // 0x00BC5500: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_49 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC5504: MOV x23, x0                | X23 = val_49;//m1                       
            val_119 = val_49;
            // 0x00BC5508: LDR x24, [x26]             | X24 = typeof(System.Type[]);            
            // 0x00BC550C: MOV x0, x24                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC5510: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC5514: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x00BC5518: MOV x0, x24                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC551C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC5520: MOV x24, x0                | X24 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC5524: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x00BC5528: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x00BC552C: LDR x1, [x8]               | X1 = typeof(System.Single);             
            // 0x00BC5530: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC5534: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC5538: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_50 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC553C: MOV x25, x0                | X25 = val_50;//m1                       
            // 0x00BC5540: CBNZ x24, #0xbc5548        | if ( != null) goto label_121;           
            if(null != null)
            {
                goto label_121;
            }
            // 0x00BC5544: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_50, ????);     
            label_121:
            // 0x00BC5548: CBZ x25, #0xbc556c         | if (val_50 == null) goto label_123;     
            if(val_50 == null)
            {
                goto label_123;
            }
            // 0x00BC554C: LDR x8, [x24]              | X8 = ;                                  
            // 0x00BC5550: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC5554: MOV x0, x25                | X0 = val_50;//m1                        
            // 0x00BC5558: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_50, ????);     
            // 0x00BC555C: CBNZ x0, #0xbc556c         | if (val_50 != null) goto label_123;     
            if(val_50 != null)
            {
                goto label_123;
            }
            // 0x00BC5560: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_50, ????);     
            // 0x00BC5564: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5568: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_50, ????);     
            label_123:
            // 0x00BC556C: LDR w8, [x24, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC5570: CBNZ w8, #0xbc5580         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_124;
            // 0x00BC5574: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_50, ????);     
            // 0x00BC5578: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC557C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_50, ????);     
            label_124:
            // 0x00BC5580: STR x25, [x24, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_50;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_50;
            // 0x00BC5584: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x00BC5588: LDR x8, [x8, #0xa18]       | X8 = 1152921504657965056;               
            // 0x00BC558C: LDR x1, [x8]               | X1 = typeof(System.Action<T>);          
            // 0x00BC5590: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC5594: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC5598: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_51 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC559C: MOV x25, x0                | X25 = val_51;//m1                       
            // 0x00BC55A0: CBZ x25, #0xbc55c4         | if (val_51 == null) goto label_126;     
            if(val_51 == null)
            {
                goto label_126;
            }
            // 0x00BC55A4: LDR x8, [x24]              | X8 = ;                                  
            // 0x00BC55A8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC55AC: MOV x0, x25                | X0 = val_51;//m1                        
            // 0x00BC55B0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_51, ????);     
            // 0x00BC55B4: CBNZ x0, #0xbc55c4         | if (val_51 != null) goto label_126;     
            if(val_51 != null)
            {
                goto label_126;
            }
            // 0x00BC55B8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_51, ????);     
            // 0x00BC55BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC55C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_51, ????);     
            label_126:
            // 0x00BC55C4: LDR w8, [x24, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC55C8: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00BC55CC: B.HI #0xbc55dc             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_127;
            // 0x00BC55D0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_51, ????);     
            // 0x00BC55D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC55D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_51, ????);     
            label_127:
            // 0x00BC55DC: STR x25, [x24, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_51;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_51;
            // 0x00BC55E0: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x00BC55E4: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x00BC55E8: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00BC55EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC55F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC55F4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_52 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC55F8: MOV x25, x0                | X25 = val_52;//m1                       
            val_120 = val_52;
            // 0x00BC55FC: CBZ x25, #0xbc5620         | if (val_52 == null) goto label_129;     
            if(val_120 == null)
            {
                goto label_129;
            }
            // 0x00BC5600: LDR x8, [x24]              | X8 = ;                                  
            // 0x00BC5604: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC5608: MOV x0, x25                | X0 = val_52;//m1                        
            // 0x00BC560C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_52, ????);     
            // 0x00BC5610: CBNZ x0, #0xbc5620         | if (val_52 != null) goto label_129;     
            if(val_120 != null)
            {
                goto label_129;
            }
            // 0x00BC5614: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_52, ????);     
            // 0x00BC5618: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC561C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_52, ????);     
            label_129:
            // 0x00BC5620: LDR w8, [x24, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC5624: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x00BC5628: B.HI #0xbc5638             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_130;
            // 0x00BC562C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_52, ????);     
            // 0x00BC5630: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5634: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_52, ????);     
            label_130:
            // 0x00BC5638: STR x25, [x24, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_52;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_120;
            // 0x00BC563C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC5640: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC5644: MOV x1, x22                | X1 = val_48;//m1                        
            // 0x00BC5648: MOV x2, x21                | X2 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC564C: MOV x3, x23                | X3 = val_49;//m1                        
            // 0x00BC5650: MOV x4, x24                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC5654: BL #0x28f47e4              | X0 = ILRuntime.Runtime.Extensions.MatchGenericParameters(m:  0, genericArguments:  val_48, returnType:  null, parameters:  val_119);
            bool val_53 = ILRuntime.Runtime.Extensions.MatchGenericParameters(m:  0, genericArguments:  val_48, returnType:  null, parameters:  val_119);
            // 0x00BC5658: TBZ w0, #0, #0xbc54ac      | if (val_53 == false) goto label_131;    
            if(val_53 == false)
            {
                goto label_131;
            }
            // 0x00BC565C: CBNZ x22, #0xbc5664        | if (val_48 != null) goto label_132;     
            if(val_48 != null)
            {
                goto label_132;
            }
            // 0x00BC5660: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_53, ????);     
            label_132:
            // 0x00BC5664: LDR x8, [x22]              | X8 = typeof(System.Type);               
            // 0x00BC5668: LDR x9, [x8, #0x3b0]       | X9 = typeof(System.Type).__il2cppRuntimeField_3B0;
            // 0x00BC566C: LDR x2, [x8, #0x3b8]       | X2 = typeof(System.Type).__il2cppRuntimeField_3B8;
            // 0x00BC5670: MOV x0, x22                | X0 = val_48;//m1                        
            // 0x00BC5674: MOV x1, x21                | X1 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC5678: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_3B0();
            // 0x00BC567C: MOV x21, x0                | X21 = val_48;//m1                       
            // 0x00BC5680: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x00BC5684: LDR x8, [x8, #0xd10]       | X8 = 1152921504783044608;               
            // 0x00BC5688: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC568C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC5690: LDR x22, [x8, #0x58]       | X22 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheB;
            val_136 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheB;
            // 0x00BC5694: CBNZ x22, #0xbc56f0        | if (ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheB != null) goto label_133;
            if(val_136 != null)
            {
                goto label_133;
            }
            // 0x00BC5698: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x00BC569C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC56A0: LDR x8, [x8, #0xd40]       | X8 = 1152921510054941072;               
            // 0x00BC56A4: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC56A8: LDR x23, [x8]              | X23 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::DelayCall_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            val_119 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::DelayCall_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC56AC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x00BC56B0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC56B4: MOV x22, x0                | X22 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC56B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC56BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC56C0: MOV x0, x22                | X0 = 1152921504823939072 (0x100000000CF09000);//ML01
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_54 = null;
            // 0x00BC56C4: MOV x2, x23                | X2 = 1152921510054941072 (0x1000000144BB5190);//ML01
            // 0x00BC56C8: BL #0x28e3b10              | .ctor(object:  0, method:  val_119);    
            val_54 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  val_119);
            // 0x00BC56CC: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x00BC56D0: LDR x8, [x8, #0xd10]       | X8 = 1152921504783044608;               
            // 0x00BC56D4: MOV x9, x8                 | X9 = 57999632 (0x3750110);//ML01        
            // 0x00BC56D8: LDR x8, [x9]               | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC56DC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC56E0: STR x22, [x8, #0x58]       | ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheB = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783048792
            ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheB = null;
            // 0x00BC56E4: LDR x8, [x9]               | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC56E8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC56EC: LDR x22, [x8, #0x58]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_136 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheB;
            label_133:
            // 0x00BC56F0: LDR x8, [sp, #0x10]        | X8 = X1;                                
            // 0x00BC56F4: CBNZ x8, #0xbc56fc         | if (X1 != 0) goto label_134;            
            if(X1 != 0)
            {
                goto label_134;
            }
            // 0x00BC56F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  val_119), ????);
            label_134:
            // 0x00BC56FC: LDR x0, [sp, #0x10]        | X0 = X1;                                
            // 0x00BC5700: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC5704: MOV x1, x21                | X1 = val_48;//m1                        
            // 0x00BC5708: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC570C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_48, func:  val_136);
            X1.RegisterCLRMethodRedirection(mi:  val_48, func:  val_136);
            label_118:
            // 0x00BC5710: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC5714: LDR x8, [x8, #0x568]       | X8 = 1152921510054942096;               
            // 0x00BC5718: SUB x0, x29, #0x70         | X0 = (1152921510055116896 - 112) = 1152921510055116784 (0x1000000144BDFFF0);
            // 0x00BC571C: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<System.Reflection.MethodInfo>::Dispose();
            // 0x00BC5720: BL #0x13371f4              | val_47.Dispose();                       
            val_47.Dispose();
            // 0x00BC5724: MOV x28, x26               | X28 = 57978136 (0x374AD18);//ML01       
            val_133 = val_133;
            // 0x00BC5728: ADRP x26, #0x366b000       | X26 = 57061376 (0x366B000);             
            // 0x00BC572C: ADRP x24, #0x35c9000       | X24 = 56397824 (0x35C9000);             
            // 0x00BC5730: LDR x26, [x26, #0x340]     | X26 = (string**)(1152921510054834176)("JSDelayCall");
            val_135 = "JSDelayCall";
            // 0x00BC5734: LDR x24, [x24, #0xcf8]     | X24 = 1152921510054905232;              
            val_131 = 1152921510054905232;
            // 0x00BC5738: B #0xbc5780                |  goto label_136;                        
            goto label_136;
            label_312:
            // 0x00BC573C: ADRP x24, #0x35c9000       | X24 = 56397824 (0x35C9000);             
            // 0x00BC5740: LDR x24, [x24, #0xcf8]     | X24 = 1152921510054905232;              
            val_131 = 1152921510054905232;
            // 0x00BC5744: MOV x28, x26               | X28 = 58347504 (0x37A4FF0);//ML01       
            val_133 = val_135;
            // 0x00BC5748: BL #0x981060               | X0 = sub_981060( ?? 0x1000000144BDFFF0, ????);
            // 0x00BC574C: LDR x21, [x0]              | X21 = val_47;                           
            // 0x00BC5750: BL #0x980920               | X0 = sub_980920( ?? 0x1000000144BDFFF0, ????);
            // 0x00BC5754: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC5758: LDR x8, [x8, #0x568]       | X8 = 1152921510054942096;               
            // 0x00BC575C: SUB x0, x29, #0x70         | X0 = (1152921510055116896 - 112) = 1152921510055116784 (0x1000000144BDFFF0);
            // 0x00BC5760: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<System.Reflection.MethodInfo>::Dispose();
            // 0x00BC5764: BL #0x13371f4              | val_47.Dispose();                       
            val_47.Dispose();
            // 0x00BC5768: ADRP x26, #0x366b000       | X26 = 57061376 (0x366B000);             
            // 0x00BC576C: LDR x26, [x26, #0x340]     | X26 = (string**)(1152921510054834176)("JSDelayCall");
            val_135 = "JSDelayCall";
            // 0x00BC5770: CBZ x21, #0xbc5780         | if (val_47 == 0) goto label_136;        
            if(val_47 == 0)
            {
                goto label_136;
            }
            // 0x00BC5774: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5778: MOV x0, x21                | X0 = val_47;//m1                        
            // 0x00BC577C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_47, ????);     
            label_136:
            // 0x00BC5780: LDR x21, [x28]             | X21 = "JSDelayCall";                    
            // 0x00BC5784: MOV x0, x21                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC5788: BL #0x277461c              | X0 = sub_277461C( ?? "JSDelayCall", ????);
            // 0x00BC578C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BC5790: MOV x0, x21                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC5794: BL #0x27c1608              | X0 = sub_27C1608( ?? "JSDelayCall", ????);
            // 0x00BC5798: ADRP x27, #0x35bb000       | X27 = 56340480 (0x35BB000);             
            // 0x00BC579C: LDR x8, [x19]              | X8 = typeof(System.Type);               
            // 0x00BC57A0: LDR x27, [x27, #0x268]     | X27 = 1152921504897847296;              
            val_137 = 1152921504897847296;
            // 0x00BC57A4: MOV x21, x0                | X21 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC57A8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC57AC: LDR x22, [x27]             | X22 = typeof(HERO_ELEMENT);             
            // 0x00BC57B0: TBZ w9, #0, #0xbc57c4      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_138;
            // 0x00BC57B4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC57B8: CBNZ w9, #0xbc57c4         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_138;
            // 0x00BC57BC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC57C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_138:
            // 0x00BC57C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC57C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC57CC: MOV x1, x22                | X1 = 1152921504897847296 (0x1000000011585000);//ML01
            // 0x00BC57D0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_55 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC57D4: MOV x22, x0                | X22 = val_55;//m1                       
            // 0x00BC57D8: CBNZ x21, #0xbc57e0        | if ("JSDelayCall" != null) goto label_139;
            if("JSDelayCall" != null)
            {
                goto label_139;
            }
            // 0x00BC57DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_55, ????);     
            label_139:
            // 0x00BC57E0: CBZ x22, #0xbc5804         | if (val_55 == null) goto label_141;     
            if(val_55 == null)
            {
                goto label_141;
            }
            // 0x00BC57E4: LDR x8, [x21]              | X8 = "JSDelayCall";                     
            // 0x00BC57E8: MOV x0, x22                | X0 = val_55;//m1                        
            // 0x00BC57EC: LDR x1, [x8, #0x30]        | 
            // 0x00BC57F0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_55, ????);     
            // 0x00BC57F4: CBNZ x0, #0xbc5804         | if (val_55 != null) goto label_141;     
            if(val_55 != null)
            {
                goto label_141;
            }
            // 0x00BC57F8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_55, ????);     
            // 0x00BC57FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5800: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_55, ????);     
            label_141:
            // 0x00BC5804: LDR w8, [x21, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC5808: CBNZ w8, #0xbc5818         | if ("JSDelayCall".__il2cppRuntimeField_18 != 0) goto label_142;
            // 0x00BC580C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_55, ????);     
            // 0x00BC5810: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5814: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_55, ????);     
            label_142:
            // 0x00BC5818: STR x22, [x21, #0x20]      | "JSDelayCall".__il2cppRuntimeField_20 = val_55;  //  dest_result_addr=1152921510054834208
            "JSDelayCall".__il2cppRuntimeField_20 = val_55;
            // 0x00BC581C: CBNZ x20, #0xbc5824        | if ( != 0) goto label_143;              
            if(null != 0)
            {
                goto label_143;
            }
            // 0x00BC5820: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_55, ????);     
            label_143:
            // 0x00BC5824: LDR x1, [x26]              | X1 = "JSDelayCall";                     
            // 0x00BC5828: LDR x3, [x24]              | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.Reflection.MethodInfo>>::TryGetValue(System.String key, out System.Collections.Generic.List<System.Reflection.MethodInfo> value);
            // 0x00BC582C: SUB x2, x29, #0x58         | X2 = (1152921510055116896 - 88) = 1152921510055116808 (0x1000000144BE0008);
            // 0x00BC5830: MOV x0, x20                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x00BC5834: BL #0x23fe7ec              | X0 = TryGetValue(key:  val_135 = "JSDelayCall", value: out  val_43);
            bool val_56 = TryGetValue(key:  val_135, value: out  val_43);
            // 0x00BC5838: TBZ w0, #0, #0xbc5b54      | if (val_56 == false) goto label_164;    
            if(val_56 == false)
            {
                goto label_164;
            }
            // 0x00BC583C: LDUR x22, [x29, #-0x58]    | X22 = typeof(System.Collections.Generic.List<T>);
            // 0x00BC5840: MOV x26, x28               | X26 = 58347504 (0x37A4FF0);//ML01       
            // 0x00BC5844: CBNZ x22, #0xbc584c        | if ( != 0) goto label_145;              
            if(null != 0)
            {
                goto label_145;
            }
            // 0x00BC5848: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_56, ????);     
            label_145:
            // 0x00BC584C: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x00BC5850: LDR x8, [x8, #0x60]        | X8 = 1152921510054917520;               
            // 0x00BC5854: MOV x0, x22                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00BC5858: LDR x1, [x8]               | X1 = public List.Enumerator<T> System.Collections.Generic.List<System.Reflection.MethodInfo>::GetEnumerator();
            // 0x00BC585C: ADD x8, sp, #0x18          | X8 = (1152921510055116544 + 24) = 1152921510055116568 (0x1000000144BDFF18);
            // 0x00BC5860: BL #0x25ebf2c              | X0 = GetEnumerator();                   
            List.Enumerator<T> val_57 = GetEnumerator();
            // 0x00BC5864: LDR x8, [sp, #0x28]        | X8 = val_46;                             //  find_add[1152921510055104912]
            // 0x00BC5868: ADRP x28, #0x3671000       | X28 = 57085952 (0x3671000);             
            // 0x00BC586C: LDUR q0, [sp, #0x18]       | Q0 = val_47;                             //  find_add[1152921510055104912]
            // 0x00BC5870: LDR x28, [x28, #0x830]     | X28 = 1152921510054918544;              
            // 0x00BC5874: STUR x8, [x29, #-0x80]     | stack[1152921510055116768] = val_46;     //  dest_result_addr=1152921510055116768
            // 0x00BC5878: ADD x8, sp, #0xb0          | X8 = (1152921510055116544 + 176) = 1152921510055116720 (0x1000000144BDFFB0);
            // 0x00BC587C: STR q0, [x8, #0x20]        | stack[1152921510055116752] = val_47;     //  dest_result_addr=1152921510055116752
            label_159:
            // 0x00BC5880: LDR x1, [x28]              | X1 = public System.Boolean List.Enumerator<System.Reflection.MethodInfo>::MoveNext();
            // 0x00BC5884: SUB x0, x29, #0x90         | X0 = (1152921510055116896 - 144) = 1152921510055116752 (0x1000000144BDFFD0);
            // 0x00BC5888: BL #0x133720c              | X0 = label_List_Enumerator<System_Object>_VerifyState_GL0133720C();
            // 0x00BC588C: AND w8, w0, #1             | W8 = (1152921510055116752 & 1) = 0 (0x00000000);
            // 0x00BC5890: TBZ w8, #0, #0xbc5ae4      | if ((0x0 & 0x1) == 0) goto label_146;   
            if((0 & 1) == 0)
            {
                goto label_146;
            }
            // 0x00BC5894: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x00BC5898: LDR x8, [x8, #0x9f0]       | X8 = 1152921510054919568;               
            // 0x00BC589C: LDR x1, [x8]               | X1 = public System.Reflection.MethodInfo List.Enumerator<System.Reflection.MethodInfo>::get_Current();
            // 0x00BC58A0: SUB x0, x29, #0x90         | X0 = (1152921510055116896 - 144) = 1152921510055116752 (0x1000000144BDFFD0);
            // 0x00BC58A4: BL #0x13372d8              | X0 = val_47.get_InitialType();          
            System.Type val_58 = val_47.InitialType;
            // 0x00BC58A8: MOV x22, x0                | X22 = val_58;//m1                       
            // 0x00BC58AC: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x00BC58B0: LDR x0, [x19]              | X0 = typeof(System.Type);               
            // 0x00BC58B4: LDR x8, [x8, #0xff0]       | X8 = 1152921504607645696;               
            // 0x00BC58B8: LDR x23, [x8]              | X23 = typeof(System.UInt32);            
            // 0x00BC58BC: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC58C0: TBZ w8, #0, #0xbc58d0      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_148;
            // 0x00BC58C4: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC58C8: CBNZ w8, #0xbc58d0         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_148;
            // 0x00BC58CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_148:
            // 0x00BC58D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC58D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC58D8: MOV x1, x23                | X1 = 1152921504607645696 (0x10000000000C3000);//ML01
            // 0x00BC58DC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_59 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC58E0: MOV x23, x0                | X23 = val_59;//m1                       
            val_119 = val_59;
            // 0x00BC58E4: LDR x24, [x26]             | X24 = "JSDelayCall";                    
            // 0x00BC58E8: MOV x0, x24                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC58EC: BL #0x277461c              | X0 = sub_277461C( ?? "JSDelayCall", ????);
            // 0x00BC58F0: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x00BC58F4: MOV x0, x24                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC58F8: BL #0x27c1608              | X0 = sub_27C1608( ?? "JSDelayCall", ????);
            // 0x00BC58FC: MOV x24, x0                | X24 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC5900: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x00BC5904: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x00BC5908: LDR x1, [x8]               | X1 = typeof(System.Single);             
            // 0x00BC590C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC5910: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC5914: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_60 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC5918: MOV x25, x0                | X25 = val_60;//m1                       
            // 0x00BC591C: CBNZ x24, #0xbc5924        | if ("JSDelayCall" != null) goto label_149;
            if("JSDelayCall" != null)
            {
                goto label_149;
            }
            // 0x00BC5920: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_60, ????);     
            label_149:
            // 0x00BC5924: CBZ x25, #0xbc5948         | if (val_60 == null) goto label_151;     
            if(val_60 == null)
            {
                goto label_151;
            }
            // 0x00BC5928: LDR x8, [x24]              | X8 = "JSDelayCall";                     
            // 0x00BC592C: LDR x1, [x8, #0x30]        | 
            // 0x00BC5930: MOV x0, x25                | X0 = val_60;//m1                        
            // 0x00BC5934: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_60, ????);     
            // 0x00BC5938: CBNZ x0, #0xbc5948         | if (val_60 != null) goto label_151;     
            if(val_60 != null)
            {
                goto label_151;
            }
            // 0x00BC593C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_60, ????);     
            // 0x00BC5940: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5944: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_60, ????);     
            label_151:
            // 0x00BC5948: LDR w8, [x24, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC594C: CBNZ w8, #0xbc595c         | if ("JSDelayCall".__il2cppRuntimeField_18 != 0) goto label_152;
            // 0x00BC5950: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_60, ????);     
            // 0x00BC5954: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5958: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_60, ????);     
            label_152:
            // 0x00BC595C: STR x25, [x24, #0x20]      | "JSDelayCall".__il2cppRuntimeField_20 = val_60;  //  dest_result_addr=1152921510054834208
            "JSDelayCall".__il2cppRuntimeField_20 = val_60;
            // 0x00BC5960: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
            // 0x00BC5964: LDR x8, [x8, #0x78]        | X8 = 1152921504657965056;               
            // 0x00BC5968: LDR x1, [x8]               | X1 = typeof(System.Action<T>);          
            // 0x00BC596C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC5970: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC5974: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_61 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC5978: MOV x25, x0                | X25 = val_61;//m1                       
            // 0x00BC597C: CBZ x25, #0xbc59a0         | if (val_61 == null) goto label_154;     
            if(val_61 == null)
            {
                goto label_154;
            }
            // 0x00BC5980: LDR x8, [x24]              | X8 = "JSDelayCall";                     
            // 0x00BC5984: LDR x1, [x8, #0x30]        | 
            // 0x00BC5988: MOV x0, x25                | X0 = val_61;//m1                        
            // 0x00BC598C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_61, ????);     
            // 0x00BC5990: CBNZ x0, #0xbc59a0         | if (val_61 != null) goto label_154;     
            if(val_61 != null)
            {
                goto label_154;
            }
            // 0x00BC5994: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_61, ????);     
            // 0x00BC5998: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC599C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_61, ????);     
            label_154:
            // 0x00BC59A0: LDR w8, [x24, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC59A4: CMP w8, #1                 | STATE = COMPARE("JSDelayCall".__il2cppRuntimeField_18, 0x1)
            // 0x00BC59A8: B.HI #0xbc59b8             | if ("JSDelayCall".__il2cppRuntimeField_18 > 0x1) goto label_155;
            // 0x00BC59AC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_61, ????);     
            // 0x00BC59B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC59B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_61, ????);     
            label_155:
            // 0x00BC59B8: STR x25, [x24, #0x28]      | "JSDelayCall".__il2cppRuntimeField_28 = val_61;  //  dest_result_addr=1152921510054834216
            "JSDelayCall".__il2cppRuntimeField_28 = val_61;
            // 0x00BC59BC: LDR x1, [x27]              | X1 = typeof(HERO_ELEMENT);              
            // 0x00BC59C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC59C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC59C8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_62 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC59CC: MOV x25, x0                | X25 = val_62;//m1                       
            val_120 = val_62;
            // 0x00BC59D0: CBZ x25, #0xbc59f4         | if (val_62 == null) goto label_157;     
            if(val_120 == null)
            {
                goto label_157;
            }
            // 0x00BC59D4: LDR x8, [x24]              | X8 = "JSDelayCall";                     
            // 0x00BC59D8: LDR x1, [x8, #0x30]        | 
            // 0x00BC59DC: MOV x0, x25                | X0 = val_62;//m1                        
            // 0x00BC59E0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_62, ????);     
            // 0x00BC59E4: CBNZ x0, #0xbc59f4         | if (val_62 != null) goto label_157;     
            if(val_120 != null)
            {
                goto label_157;
            }
            // 0x00BC59E8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_62, ????);     
            // 0x00BC59EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC59F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_62, ????);     
            label_157:
            // 0x00BC59F4: LDR w8, [x24, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC59F8: CMP w8, #2                 | STATE = COMPARE("JSDelayCall".__il2cppRuntimeField_18, 0x2)
            // 0x00BC59FC: B.HI #0xbc5a0c             | if ("JSDelayCall".__il2cppRuntimeField_18 > 0x2) goto label_158;
            // 0x00BC5A00: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_62, ????);     
            // 0x00BC5A04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5A08: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_62, ????);     
            label_158:
            // 0x00BC5A0C: STR x25, [x24, #0x30]      | "JSDelayCall".__il2cppRuntimeField_30 = val_62;  //  dest_result_addr=1152921510054834224
            "JSDelayCall".__il2cppRuntimeField_30 = val_120;
            // 0x00BC5A10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC5A14: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC5A18: MOV x1, x22                | X1 = val_58;//m1                        
            // 0x00BC5A1C: MOV x2, x21                | X2 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC5A20: MOV x3, x23                | X3 = val_59;//m1                        
            // 0x00BC5A24: MOV x4, x24                | X4 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC5A28: BL #0x28f47e4              | X0 = ILRuntime.Runtime.Extensions.MatchGenericParameters(m:  0, genericArguments:  val_58, returnType:  val_133, parameters:  val_119);
            bool val_63 = ILRuntime.Runtime.Extensions.MatchGenericParameters(m:  0, genericArguments:  val_58, returnType:  val_133, parameters:  val_119);
            // 0x00BC5A2C: TBZ w0, #0, #0xbc5880      | if (val_63 == false) goto label_159;    
            if(val_63 == false)
            {
                goto label_159;
            }
            // 0x00BC5A30: CBNZ x22, #0xbc5a38        | if (val_58 != null) goto label_160;     
            if(val_58 != null)
            {
                goto label_160;
            }
            // 0x00BC5A34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_63, ????);     
            label_160:
            // 0x00BC5A38: LDR x8, [x22]              | X8 = typeof(System.Type);               
            // 0x00BC5A3C: LDR x9, [x8, #0x3b0]       | X9 = typeof(System.Type).__il2cppRuntimeField_3B0;
            // 0x00BC5A40: LDR x2, [x8, #0x3b8]       | X2 = typeof(System.Type).__il2cppRuntimeField_3B8;
            // 0x00BC5A44: MOV x0, x22                | X0 = val_58;//m1                        
            // 0x00BC5A48: MOV x1, x21                | X1 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC5A4C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_3B0();
            // 0x00BC5A50: MOV x21, x0                | X21 = val_58;//m1                       
            // 0x00BC5A54: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x00BC5A58: LDR x8, [x8, #0xd10]       | X8 = 1152921504783044608;               
            // 0x00BC5A5C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC5A60: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC5A64: LDR x22, [x8, #0x60]       | X22 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheC;
            val_138 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheC;
            // 0x00BC5A68: CBNZ x22, #0xbc5ac4        | if (ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheC != null) goto label_161;
            if(val_138 != null)
            {
                goto label_161;
            }
            // 0x00BC5A6C: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x00BC5A70: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC5A74: LDR x8, [x8, #0xb20]       | X8 = 1152921510054967696;               
            // 0x00BC5A78: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC5A7C: LDR x23, [x8]              | X23 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::JSDelayCall_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            val_119 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::JSDelayCall_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC5A80: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x00BC5A84: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC5A88: MOV x22, x0                | X22 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC5A8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5A90: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC5A94: MOV x0, x22                | X0 = 1152921504823939072 (0x100000000CF09000);//ML01
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_64 = null;
            // 0x00BC5A98: MOV x2, x23                | X2 = 1152921510054967696 (0x1000000144BBB990);//ML01
            // 0x00BC5A9C: BL #0x28e3b10              | .ctor(object:  0, method:  val_119);    
            val_64 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  val_119);
            // 0x00BC5AA0: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x00BC5AA4: LDR x8, [x8, #0xd10]       | X8 = 1152921504783044608;               
            // 0x00BC5AA8: MOV x9, x8                 | X9 = 57999632 (0x3750110);//ML01        
            // 0x00BC5AAC: LDR x8, [x9]               | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC5AB0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC5AB4: STR x22, [x8, #0x60]       | ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheC = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783048800
            ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheC = null;
            // 0x00BC5AB8: LDR x8, [x9]               | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC5ABC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC5AC0: LDR x22, [x8, #0x60]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_138 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheC;
            label_161:
            // 0x00BC5AC4: LDR x8, [sp, #0x10]        | X8 = X1;                                
            // 0x00BC5AC8: CBNZ x8, #0xbc5ad0         | if (X1 != 0) goto label_162;            
            if(X1 != 0)
            {
                goto label_162;
            }
            // 0x00BC5ACC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  val_119), ????);
            label_162:
            // 0x00BC5AD0: LDR x0, [sp, #0x10]        | X0 = X1;                                
            // 0x00BC5AD4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC5AD8: MOV x1, x21                | X1 = val_58;//m1                        
            // 0x00BC5ADC: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC5AE0: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_58, func:  val_138);
            X1.RegisterCLRMethodRedirection(mi:  val_58, func:  val_138);
            label_146:
            // 0x00BC5AE4: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC5AE8: LDR x8, [x8, #0x568]       | X8 = 1152921510054942096;               
            // 0x00BC5AEC: SUB x0, x29, #0x90         | X0 = (1152921510055116896 - 144) = 1152921510055116752 (0x1000000144BDFFD0);
            // 0x00BC5AF0: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<System.Reflection.MethodInfo>::Dispose();
            // 0x00BC5AF4: BL #0x13371f4              | val_47.Dispose();                       
            val_47.Dispose();
            // 0x00BC5AF8: MOV x28, x26               | X28 = 58347504 (0x37A4FF0);//ML01       
            val_133 = val_133;
            // 0x00BC5AFC: ADRP x26, #0x366b000       | X26 = 57061376 (0x366B000);             
            // 0x00BC5B00: ADRP x24, #0x35c9000       | X24 = 56397824 (0x35C9000);             
            // 0x00BC5B04: LDR x26, [x26, #0x340]     | X26 = (string**)(1152921510054834176)("JSDelayCall");
            val_135 = "JSDelayCall";
            // 0x00BC5B08: LDR x24, [x24, #0xcf8]     | X24 = 1152921510054905232;              
            val_131 = 1152921510054905232;
            // 0x00BC5B0C: B #0xbc5b54                |  goto label_164;                        
            goto label_164;
            label_313:
            // 0x00BC5B10: ADRP x24, #0x35c9000       | X24 = 56397824 (0x35C9000);             
            // 0x00BC5B14: LDR x24, [x24, #0xcf8]     | X24 = 1152921510054905232;              
            val_131 = 1152921510054905232;
            // 0x00BC5B18: MOV x28, x26               | X28 = 58347504 (0x37A4FF0);//ML01       
            val_133 = val_135;
            // 0x00BC5B1C: BL #0x981060               | X0 = sub_981060( ?? 0x1000000144BDFFD0, ????);
            // 0x00BC5B20: LDR x21, [x0]              | X21 = val_47;                           
            // 0x00BC5B24: BL #0x980920               | X0 = sub_980920( ?? 0x1000000144BDFFD0, ????);
            // 0x00BC5B28: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC5B2C: LDR x8, [x8, #0x568]       | X8 = 1152921510054942096;               
            // 0x00BC5B30: SUB x0, x29, #0x90         | X0 = (1152921510055116896 - 144) = 1152921510055116752 (0x1000000144BDFFD0);
            // 0x00BC5B34: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<System.Reflection.MethodInfo>::Dispose();
            // 0x00BC5B38: BL #0x13371f4              | val_47.Dispose();                       
            val_47.Dispose();
            // 0x00BC5B3C: ADRP x26, #0x366b000       | X26 = 57061376 (0x366B000);             
            // 0x00BC5B40: LDR x26, [x26, #0x340]     | X26 = (string**)(1152921510054834176)("JSDelayCall");
            val_135 = "JSDelayCall";
            // 0x00BC5B44: CBZ x21, #0xbc5b54         | if (val_47 == 0) goto label_164;        
            if(val_47 == 0)
            {
                goto label_164;
            }
            // 0x00BC5B48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5B4C: MOV x0, x21                | X0 = val_47;//m1                        
            // 0x00BC5B50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_47, ????);     
            label_164:
            // 0x00BC5B54: LDR x21, [x28]             | X21 = "JSDelayCall";                    
            // 0x00BC5B58: MOV x0, x21                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC5B5C: BL #0x277461c              | X0 = sub_277461C( ?? "JSDelayCall", ????);
            // 0x00BC5B60: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BC5B64: MOV x0, x21                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC5B68: BL #0x27c1608              | X0 = sub_27C1608( ?? "JSDelayCall", ????);
            // 0x00BC5B6C: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x00BC5B70: LDR x8, [x19]              | X8 = typeof(System.Type);               
            // 0x00BC5B74: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x00BC5B78: MOV x21, x0                | X21 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC5B7C: LDR x22, [x9]              | X22 = typeof(System.String);            
            // 0x00BC5B80: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC5B84: TBZ w9, #0, #0xbc5b98      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_166;
            // 0x00BC5B88: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC5B8C: CBNZ w9, #0xbc5b98         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_166;
            // 0x00BC5B90: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC5B94: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_166:
            // 0x00BC5B98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC5B9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC5BA0: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BC5BA4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_65 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC5BA8: MOV x22, x0                | X22 = val_65;//m1                       
            // 0x00BC5BAC: CBNZ x21, #0xbc5bb4        | if ("JSDelayCall" != null) goto label_167;
            if("JSDelayCall" != null)
            {
                goto label_167;
            }
            // 0x00BC5BB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_65, ????);     
            label_167:
            // 0x00BC5BB4: CBZ x22, #0xbc5bd8         | if (val_65 == null) goto label_169;     
            if(val_65 == null)
            {
                goto label_169;
            }
            // 0x00BC5BB8: LDR x8, [x21]              | X8 = "JSDelayCall";                     
            // 0x00BC5BBC: MOV x0, x22                | X0 = val_65;//m1                        
            // 0x00BC5BC0: LDR x1, [x8, #0x30]        | 
            // 0x00BC5BC4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_65, ????);     
            // 0x00BC5BC8: CBNZ x0, #0xbc5bd8         | if (val_65 != null) goto label_169;     
            if(val_65 != null)
            {
                goto label_169;
            }
            // 0x00BC5BCC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_65, ????);     
            // 0x00BC5BD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5BD4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_65, ????);     
            label_169:
            // 0x00BC5BD8: LDR w8, [x21, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC5BDC: CBNZ w8, #0xbc5bec         | if ("JSDelayCall".__il2cppRuntimeField_18 != 0) goto label_170;
            // 0x00BC5BE0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_65, ????);     
            // 0x00BC5BE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5BE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_65, ????);     
            label_170:
            // 0x00BC5BEC: STR x22, [x21, #0x20]      | "JSDelayCall".__il2cppRuntimeField_20 = val_65;  //  dest_result_addr=1152921510054834208
            "JSDelayCall".__il2cppRuntimeField_20 = val_65;
            // 0x00BC5BF0: CBNZ x20, #0xbc5bf8        | if ( != 0) goto label_171;              
            if(null != 0)
            {
                goto label_171;
            }
            // 0x00BC5BF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_65, ????);     
            label_171:
            // 0x00BC5BF8: LDR x1, [x26]              | X1 = "JSDelayCall";                     
            // 0x00BC5BFC: LDR x3, [x24]              | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.Reflection.MethodInfo>>::TryGetValue(System.String key, out System.Collections.Generic.List<System.Reflection.MethodInfo> value);
            // 0x00BC5C00: SUB x2, x29, #0x58         | X2 = (1152921510055116896 - 88) = 1152921510055116808 (0x1000000144BE0008);
            // 0x00BC5C04: MOV x0, x20                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x00BC5C08: BL #0x23fe7ec              | X0 = TryGetValue(key:  val_135 = "JSDelayCall", value: out  val_43);
            bool val_66 = TryGetValue(key:  val_135, value: out  val_43);
            // 0x00BC5C0C: TBZ w0, #0, #0xbc5f30      | if (val_66 == false) goto label_192;    
            if(val_66 == false)
            {
                goto label_192;
            }
            // 0x00BC5C10: LDUR x22, [x29, #-0x58]    | X22 = typeof(System.Collections.Generic.List<T>);
            // 0x00BC5C14: MOV x26, x28               | X26 = 58347504 (0x37A4FF0);//ML01       
            // 0x00BC5C18: CBNZ x22, #0xbc5c20        | if ( != 0) goto label_173;              
            if(null != 0)
            {
                goto label_173;
            }
            // 0x00BC5C1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_66, ????);     
            label_173:
            // 0x00BC5C20: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x00BC5C24: LDR x8, [x8, #0x60]        | X8 = 1152921510054917520;               
            // 0x00BC5C28: MOV x0, x22                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00BC5C2C: LDR x1, [x8]               | X1 = public List.Enumerator<T> System.Collections.Generic.List<System.Reflection.MethodInfo>::GetEnumerator();
            // 0x00BC5C30: ADD x8, sp, #0x18          | X8 = (1152921510055116544 + 24) = 1152921510055116568 (0x1000000144BDFF18);
            // 0x00BC5C34: BL #0x25ebf2c              | X0 = GetEnumerator();                   
            List.Enumerator<T> val_67 = GetEnumerator();
            // 0x00BC5C38: LDR x8, [sp, #0x28]        | X8 = val_46;                             //  find_add[1152921510055104912]
            // 0x00BC5C3C: ADRP x27, #0x3671000       | X27 = 57085952 (0x3671000);             
            // 0x00BC5C40: ADRP x28, #0x360e000       | X28 = 56680448 (0x360E000);             
            // 0x00BC5C44: LDUR q0, [sp, #0x18]       | Q0 = val_47;                             //  find_add[1152921510055104912]
            // 0x00BC5C48: LDR x27, [x27, #0x830]     | X27 = 1152921510054918544;              
            val_137 = 1152921510054918544;
            // 0x00BC5C4C: LDR x28, [x28, #0x9f0]     | X28 = 1152921510054919568;              
            // 0x00BC5C50: STR x8, [sp, #0xc0]        | stack[1152921510055116736] = val_46;     //  dest_result_addr=1152921510055116736
            // 0x00BC5C54: ADD x8, sp, #0xb0          | X8 = (1152921510055116544 + 176) = 1152921510055116720 (0x1000000144BDFFB0);
            // 0x00BC5C58: STR q0, [x8]               | stack[1152921510055116720] = val_47;     //  dest_result_addr=1152921510055116720
            label_187:
            // 0x00BC5C5C: LDR x1, [x27]              | X1 = public System.Boolean List.Enumerator<System.Reflection.MethodInfo>::MoveNext();
            // 0x00BC5C60: ADD x0, sp, #0xb0          | X0 = (1152921510055116544 + 176) = 1152921510055116720 (0x1000000144BDFFB0);
            // 0x00BC5C64: BL #0x133720c              | X0 = label_List_Enumerator<System_Object>_VerifyState_GL0133720C();
            // 0x00BC5C68: AND w8, w0, #1             | W8 = (1152921510055116720 & 1) = 0 (0x00000000);
            // 0x00BC5C6C: TBZ w8, #0, #0xbc5ec0      | if ((0x0 & 0x1) == 0) goto label_174;   
            if((0 & 1) == 0)
            {
                goto label_174;
            }
            // 0x00BC5C70: LDR x1, [x28]              | X1 = public System.Reflection.MethodInfo List.Enumerator<System.Reflection.MethodInfo>::get_Current();
            // 0x00BC5C74: ADD x0, sp, #0xb0          | X0 = (1152921510055116544 + 176) = 1152921510055116720 (0x1000000144BDFFB0);
            // 0x00BC5C78: BL #0x13372d8              | X0 = val_47.get_InitialType();          
            System.Type val_68 = val_47.InitialType;
            // 0x00BC5C7C: MOV x22, x0                | X22 = val_68;//m1                       
            // 0x00BC5C80: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x00BC5C84: LDR x0, [x19]              | X0 = typeof(System.Type);               
            // 0x00BC5C88: LDR x8, [x8, #0xff0]       | X8 = 1152921504607645696;               
            // 0x00BC5C8C: LDR x23, [x8]              | X23 = typeof(System.UInt32);            
            // 0x00BC5C90: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC5C94: TBZ w8, #0, #0xbc5ca4      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_176;
            // 0x00BC5C98: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC5C9C: CBNZ w8, #0xbc5ca4         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_176;
            // 0x00BC5CA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_176:
            // 0x00BC5CA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC5CA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC5CAC: MOV x1, x23                | X1 = 1152921504607645696 (0x10000000000C3000);//ML01
            // 0x00BC5CB0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_69 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC5CB4: MOV x23, x0                | X23 = val_69;//m1                       
            val_119 = val_69;
            // 0x00BC5CB8: LDR x24, [x26]             | X24 = "JSDelayCall";                    
            // 0x00BC5CBC: MOV x0, x24                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC5CC0: BL #0x277461c              | X0 = sub_277461C( ?? "JSDelayCall", ????);
            // 0x00BC5CC4: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x00BC5CC8: MOV x0, x24                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC5CCC: BL #0x27c1608              | X0 = sub_27C1608( ?? "JSDelayCall", ????);
            // 0x00BC5CD0: MOV x24, x0                | X24 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC5CD4: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x00BC5CD8: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x00BC5CDC: LDR x1, [x8]               | X1 = typeof(System.Single);             
            // 0x00BC5CE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC5CE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC5CE8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_70 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC5CEC: MOV x25, x0                | X25 = val_70;//m1                       
            // 0x00BC5CF0: CBNZ x24, #0xbc5cf8        | if ("JSDelayCall" != null) goto label_177;
            if("JSDelayCall" != null)
            {
                goto label_177;
            }
            // 0x00BC5CF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_70, ????);     
            label_177:
            // 0x00BC5CF8: CBZ x25, #0xbc5d1c         | if (val_70 == null) goto label_179;     
            if(val_70 == null)
            {
                goto label_179;
            }
            // 0x00BC5CFC: LDR x8, [x24]              | X8 = "JSDelayCall";                     
            // 0x00BC5D00: LDR x1, [x8, #0x30]        | 
            // 0x00BC5D04: MOV x0, x25                | X0 = val_70;//m1                        
            // 0x00BC5D08: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_70, ????);     
            // 0x00BC5D0C: CBNZ x0, #0xbc5d1c         | if (val_70 != null) goto label_179;     
            if(val_70 != null)
            {
                goto label_179;
            }
            // 0x00BC5D10: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_70, ????);     
            // 0x00BC5D14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5D18: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_70, ????);     
            label_179:
            // 0x00BC5D1C: LDR w8, [x24, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC5D20: CBNZ w8, #0xbc5d30         | if ("JSDelayCall".__il2cppRuntimeField_18 != 0) goto label_180;
            // 0x00BC5D24: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_70, ????);     
            // 0x00BC5D28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5D2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_70, ????);     
            label_180:
            // 0x00BC5D30: STR x25, [x24, #0x20]      | "JSDelayCall".__il2cppRuntimeField_20 = val_70;  //  dest_result_addr=1152921510054834208
            "JSDelayCall".__il2cppRuntimeField_20 = val_70;
            // 0x00BC5D34: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x00BC5D38: LDR x8, [x8, #0xa18]       | X8 = 1152921504657965056;               
            // 0x00BC5D3C: LDR x1, [x8]               | X1 = typeof(System.Action<T>);          
            // 0x00BC5D40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC5D44: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC5D48: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_71 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC5D4C: MOV x25, x0                | X25 = val_71;//m1                       
            // 0x00BC5D50: CBZ x25, #0xbc5d74         | if (val_71 == null) goto label_182;     
            if(val_71 == null)
            {
                goto label_182;
            }
            // 0x00BC5D54: LDR x8, [x24]              | X8 = "JSDelayCall";                     
            // 0x00BC5D58: LDR x1, [x8, #0x30]        | 
            // 0x00BC5D5C: MOV x0, x25                | X0 = val_71;//m1                        
            // 0x00BC5D60: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_71, ????);     
            // 0x00BC5D64: CBNZ x0, #0xbc5d74         | if (val_71 != null) goto label_182;     
            if(val_71 != null)
            {
                goto label_182;
            }
            // 0x00BC5D68: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_71, ????);     
            // 0x00BC5D6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5D70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_71, ????);     
            label_182:
            // 0x00BC5D74: LDR w8, [x24, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC5D78: CMP w8, #1                 | STATE = COMPARE("JSDelayCall".__il2cppRuntimeField_18, 0x1)
            // 0x00BC5D7C: B.HI #0xbc5d8c             | if ("JSDelayCall".__il2cppRuntimeField_18 > 0x1) goto label_183;
            // 0x00BC5D80: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_71, ????);     
            // 0x00BC5D84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5D88: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_71, ????);     
            label_183:
            // 0x00BC5D8C: STR x25, [x24, #0x28]      | "JSDelayCall".__il2cppRuntimeField_28 = val_71;  //  dest_result_addr=1152921510054834216
            "JSDelayCall".__il2cppRuntimeField_28 = val_71;
            // 0x00BC5D90: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x00BC5D94: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x00BC5D98: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00BC5D9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC5DA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC5DA4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_72 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC5DA8: MOV x25, x0                | X25 = val_72;//m1                       
            val_120 = val_72;
            // 0x00BC5DAC: CBZ x25, #0xbc5dd0         | if (val_72 == null) goto label_185;     
            if(val_120 == null)
            {
                goto label_185;
            }
            // 0x00BC5DB0: LDR x8, [x24]              | X8 = "JSDelayCall";                     
            // 0x00BC5DB4: LDR x1, [x8, #0x30]        | 
            // 0x00BC5DB8: MOV x0, x25                | X0 = val_72;//m1                        
            // 0x00BC5DBC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_72, ????);     
            // 0x00BC5DC0: CBNZ x0, #0xbc5dd0         | if (val_72 != null) goto label_185;     
            if(val_120 != null)
            {
                goto label_185;
            }
            // 0x00BC5DC4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_72, ????);     
            // 0x00BC5DC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5DCC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_72, ????);     
            label_185:
            // 0x00BC5DD0: LDR w8, [x24, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC5DD4: CMP w8, #2                 | STATE = COMPARE("JSDelayCall".__il2cppRuntimeField_18, 0x2)
            // 0x00BC5DD8: B.HI #0xbc5de8             | if ("JSDelayCall".__il2cppRuntimeField_18 > 0x2) goto label_186;
            // 0x00BC5DDC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_72, ????);     
            // 0x00BC5DE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5DE4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_72, ????);     
            label_186:
            // 0x00BC5DE8: STR x25, [x24, #0x30]      | "JSDelayCall".__il2cppRuntimeField_30 = val_72;  //  dest_result_addr=1152921510054834224
            "JSDelayCall".__il2cppRuntimeField_30 = val_120;
            // 0x00BC5DEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC5DF0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC5DF4: MOV x1, x22                | X1 = val_68;//m1                        
            // 0x00BC5DF8: MOV x2, x21                | X2 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC5DFC: MOV x3, x23                | X3 = val_69;//m1                        
            // 0x00BC5E00: MOV x4, x24                | X4 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC5E04: BL #0x28f47e4              | X0 = ILRuntime.Runtime.Extensions.MatchGenericParameters(m:  0, genericArguments:  val_68, returnType:  val_133, parameters:  val_119);
            bool val_73 = ILRuntime.Runtime.Extensions.MatchGenericParameters(m:  0, genericArguments:  val_68, returnType:  val_133, parameters:  val_119);
            // 0x00BC5E08: TBZ w0, #0, #0xbc5c5c      | if (val_73 == false) goto label_187;    
            if(val_73 == false)
            {
                goto label_187;
            }
            // 0x00BC5E0C: CBNZ x22, #0xbc5e14        | if (val_68 != null) goto label_188;     
            if(val_68 != null)
            {
                goto label_188;
            }
            // 0x00BC5E10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_73, ????);     
            label_188:
            // 0x00BC5E14: LDR x8, [x22]              | X8 = typeof(System.Type);               
            // 0x00BC5E18: LDR x9, [x8, #0x3b0]       | X9 = typeof(System.Type).__il2cppRuntimeField_3B0;
            // 0x00BC5E1C: LDR x2, [x8, #0x3b8]       | X2 = typeof(System.Type).__il2cppRuntimeField_3B8;
            // 0x00BC5E20: MOV x0, x22                | X0 = val_68;//m1                        
            // 0x00BC5E24: MOV x1, x21                | X1 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC5E28: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_3B0();
            // 0x00BC5E2C: MOV x21, x0                | X21 = val_68;//m1                       
            // 0x00BC5E30: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x00BC5E34: LDR x8, [x8, #0xd10]       | X8 = 1152921504783044608;               
            // 0x00BC5E38: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC5E3C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC5E40: LDR x22, [x8, #0x68]       | X22 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheD;
            val_139 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheD;
            // 0x00BC5E44: CBNZ x22, #0xbc5ea0        | if (ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheD != null) goto label_189;
            if(val_139 != null)
            {
                goto label_189;
            }
            // 0x00BC5E48: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
            // 0x00BC5E4C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC5E50: LDR x8, [x8, #0x140]       | X8 = 1152921510054993296;               
            // 0x00BC5E54: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC5E58: LDR x23, [x8]              | X23 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::JSDelayCall_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            val_119 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::JSDelayCall_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC5E5C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x00BC5E60: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC5E64: MOV x22, x0                | X22 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC5E68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5E6C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC5E70: MOV x0, x22                | X0 = 1152921504823939072 (0x100000000CF09000);//ML01
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_74 = null;
            // 0x00BC5E74: MOV x2, x23                | X2 = 1152921510054993296 (0x1000000144BC1D90);//ML01
            // 0x00BC5E78: BL #0x28e3b10              | .ctor(object:  0, method:  val_119);    
            val_74 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  val_119);
            // 0x00BC5E7C: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x00BC5E80: LDR x8, [x8, #0xd10]       | X8 = 1152921504783044608;               
            // 0x00BC5E84: MOV x9, x8                 | X9 = 57999632 (0x3750110);//ML01        
            // 0x00BC5E88: LDR x8, [x9]               | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC5E8C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC5E90: STR x22, [x8, #0x68]       | ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheD = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783048808
            ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheD = null;
            // 0x00BC5E94: LDR x8, [x9]               | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC5E98: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC5E9C: LDR x22, [x8, #0x68]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_139 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheD;
            label_189:
            // 0x00BC5EA0: LDR x8, [sp, #0x10]        | X8 = X1;                                
            // 0x00BC5EA4: CBNZ x8, #0xbc5eac         | if (X1 != 0) goto label_190;            
            if(X1 != 0)
            {
                goto label_190;
            }
            // 0x00BC5EA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  val_119), ????);
            label_190:
            // 0x00BC5EAC: LDR x0, [sp, #0x10]        | X0 = X1;                                
            // 0x00BC5EB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC5EB4: MOV x1, x21                | X1 = val_68;//m1                        
            // 0x00BC5EB8: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC5EBC: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_68, func:  val_139);
            X1.RegisterCLRMethodRedirection(mi:  val_68, func:  val_139);
            label_174:
            // 0x00BC5EC0: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC5EC4: LDR x8, [x8, #0x568]       | X8 = 1152921510054942096;               
            // 0x00BC5EC8: ADD x0, sp, #0xb0          | X0 = (1152921510055116544 + 176) = 1152921510055116720 (0x1000000144BDFFB0);
            // 0x00BC5ECC: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<System.Reflection.MethodInfo>::Dispose();
            // 0x00BC5ED0: BL #0x13371f4              | val_47.Dispose();                       
            val_47.Dispose();
            // 0x00BC5ED4: MOV x28, x26               | X28 = 58347504 (0x37A4FF0);//ML01       
            val_133 = val_133;
            // 0x00BC5ED8: ADRP x26, #0x366b000       | X26 = 57061376 (0x366B000);             
            // 0x00BC5EDC: ADRP x24, #0x35c9000       | X24 = 56397824 (0x35C9000);             
            // 0x00BC5EE0: LDR x26, [x26, #0x340]     | X26 = (string**)(1152921510054834176)("JSDelayCall");
            val_135 = "JSDelayCall";
            // 0x00BC5EE4: LDR x24, [x24, #0xcf8]     | X24 = 1152921510054905232;              
            val_131 = 1152921510054905232;
            // 0x00BC5EE8: B #0xbc5f30                |  goto label_192;                        
            goto label_192;
            label_314:
            // 0x00BC5EEC: ADRP x24, #0x35c9000       | X24 = 56397824 (0x35C9000);             
            // 0x00BC5EF0: LDR x24, [x24, #0xcf8]     | X24 = 1152921510054905232;              
            val_131 = 1152921510054905232;
            // 0x00BC5EF4: MOV x28, x26               | X28 = 58347504 (0x37A4FF0);//ML01       
            val_133 = val_135;
            // 0x00BC5EF8: BL #0x981060               | X0 = sub_981060( ?? 0x1000000144BDFFB0, ????);
            // 0x00BC5EFC: LDR x21, [x0]              | X21 = val_47;                           
            // 0x00BC5F00: BL #0x980920               | X0 = sub_980920( ?? 0x1000000144BDFFB0, ????);
            // 0x00BC5F04: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC5F08: LDR x8, [x8, #0x568]       | X8 = 1152921510054942096;               
            // 0x00BC5F0C: ADD x0, sp, #0xb0          | X0 = (1152921510055116544 + 176) = 1152921510055116720 (0x1000000144BDFFB0);
            // 0x00BC5F10: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<System.Reflection.MethodInfo>::Dispose();
            // 0x00BC5F14: BL #0x13371f4              | val_47.Dispose();                       
            val_47.Dispose();
            // 0x00BC5F18: ADRP x26, #0x366b000       | X26 = 57061376 (0x366B000);             
            // 0x00BC5F1C: LDR x26, [x26, #0x340]     | X26 = (string**)(1152921510054834176)("JSDelayCall");
            val_135 = "JSDelayCall";
            // 0x00BC5F20: CBZ x21, #0xbc5f30         | if (val_47 == 0) goto label_192;        
            if(val_47 == 0)
            {
                goto label_192;
            }
            // 0x00BC5F24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5F28: MOV x0, x21                | X0 = val_47;//m1                        
            // 0x00BC5F2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_47, ????);     
            label_192:
            // 0x00BC5F30: LDR x21, [x28]             | X21 = "JSDelayCall";                    
            // 0x00BC5F34: MOV x0, x21                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC5F38: BL #0x277461c              | X0 = sub_277461C( ?? "JSDelayCall", ????);
            // 0x00BC5F3C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BC5F40: MOV x0, x21                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC5F44: BL #0x27c1608              | X0 = sub_27C1608( ?? "JSDelayCall", ????);
            // 0x00BC5F48: ADRP x9, #0x365e000        | X9 = 57008128 (0x365E000);              
            // 0x00BC5F4C: LDR x8, [x19]              | X8 = typeof(System.Type);               
            // 0x00BC5F50: LDR x9, [x9, #0xcb8]       | X9 = 1152921504608604160;               
            // 0x00BC5F54: MOV x21, x0                | X21 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC5F58: LDR x22, [x9]              | X22 = typeof(System.Boolean);           
            // 0x00BC5F5C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC5F60: TBZ w9, #0, #0xbc5f74      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_194;
            // 0x00BC5F64: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC5F68: CBNZ w9, #0xbc5f74         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_194;
            // 0x00BC5F6C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC5F70: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_194:
            // 0x00BC5F74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC5F78: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC5F7C: MOV x1, x22                | X1 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x00BC5F80: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_75 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC5F84: MOV x22, x0                | X22 = val_75;//m1                       
            // 0x00BC5F88: CBNZ x21, #0xbc5f90        | if ("JSDelayCall" != null) goto label_195;
            if("JSDelayCall" != null)
            {
                goto label_195;
            }
            // 0x00BC5F8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_75, ????);     
            label_195:
            // 0x00BC5F90: CBZ x22, #0xbc5fb4         | if (val_75 == null) goto label_197;     
            if(val_75 == null)
            {
                goto label_197;
            }
            // 0x00BC5F94: LDR x8, [x21]              | X8 = "JSDelayCall";                     
            // 0x00BC5F98: MOV x0, x22                | X0 = val_75;//m1                        
            // 0x00BC5F9C: LDR x1, [x8, #0x30]        | 
            // 0x00BC5FA0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_75, ????);     
            // 0x00BC5FA4: CBNZ x0, #0xbc5fb4         | if (val_75 != null) goto label_197;     
            if(val_75 != null)
            {
                goto label_197;
            }
            // 0x00BC5FA8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_75, ????);     
            // 0x00BC5FAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5FB0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_75, ????);     
            label_197:
            // 0x00BC5FB4: LDR w8, [x21, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC5FB8: CBNZ w8, #0xbc5fc8         | if ("JSDelayCall".__il2cppRuntimeField_18 != 0) goto label_198;
            // 0x00BC5FBC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_75, ????);     
            // 0x00BC5FC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC5FC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_75, ????);     
            label_198:
            // 0x00BC5FC8: STR x22, [x21, #0x20]      | "JSDelayCall".__il2cppRuntimeField_20 = val_75;  //  dest_result_addr=1152921510054834208
            "JSDelayCall".__il2cppRuntimeField_20 = val_75;
            // 0x00BC5FCC: CBNZ x20, #0xbc5fd4        | if ( != 0) goto label_199;              
            if(null != 0)
            {
                goto label_199;
            }
            // 0x00BC5FD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_75, ????);     
            label_199:
            // 0x00BC5FD4: LDR x1, [x26]              | X1 = "JSDelayCall";                     
            // 0x00BC5FD8: LDR x3, [x24]              | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.Reflection.MethodInfo>>::TryGetValue(System.String key, out System.Collections.Generic.List<System.Reflection.MethodInfo> value);
            // 0x00BC5FDC: SUB x2, x29, #0x58         | X2 = (1152921510055116896 - 88) = 1152921510055116808 (0x1000000144BE0008);
            // 0x00BC5FE0: MOV x0, x20                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x00BC5FE4: BL #0x23fe7ec              | X0 = TryGetValue(key:  val_135 = "JSDelayCall", value: out  val_43);
            bool val_76 = TryGetValue(key:  val_135, value: out  val_43);
            // 0x00BC5FE8: TBZ w0, #0, #0xbc6308      | if (val_76 == false) goto label_220;    
            if(val_76 == false)
            {
                goto label_220;
            }
            // 0x00BC5FEC: LDUR x22, [x29, #-0x58]    | X22 = typeof(System.Collections.Generic.List<T>);
            // 0x00BC5FF0: MOV x26, x28               | X26 = 58347504 (0x37A4FF0);//ML01       
            // 0x00BC5FF4: CBNZ x22, #0xbc5ffc        | if ( != 0) goto label_201;              
            if(null != 0)
            {
                goto label_201;
            }
            // 0x00BC5FF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_76, ????);     
            label_201:
            // 0x00BC5FFC: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x00BC6000: LDR x8, [x8, #0x60]        | X8 = 1152921510054917520;               
            // 0x00BC6004: MOV x0, x22                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00BC6008: LDR x1, [x8]               | X1 = public List.Enumerator<T> System.Collections.Generic.List<System.Reflection.MethodInfo>::GetEnumerator();
            // 0x00BC600C: ADD x8, sp, #0x18          | X8 = (1152921510055116544 + 24) = 1152921510055116568 (0x1000000144BDFF18);
            // 0x00BC6010: BL #0x25ebf2c              | X0 = GetEnumerator();                   
            List.Enumerator<T> val_77 = GetEnumerator();
            // 0x00BC6014: ADRP x27, #0x3671000       | X27 = 57085952 (0x3671000);             
            // 0x00BC6018: ADRP x28, #0x360e000       | X28 = 56680448 (0x360E000);             
            // 0x00BC601C: LDR x8, [sp, #0x28]        | X8 = val_46;                             //  find_add[1152921510055104912]
            // 0x00BC6020: LDUR q0, [sp, #0x18]       | Q0 = val_47;                             //  find_add[1152921510055104912]
            // 0x00BC6024: LDR x27, [x27, #0x830]     | X27 = 1152921510054918544;              
            val_137 = 1152921510054918544;
            // 0x00BC6028: LDR x28, [x28, #0x9f0]     | X28 = 1152921510054919568;              
            // 0x00BC602C: STR x8, [sp, #0xa0]        | stack[1152921510055116704] = val_46;     //  dest_result_addr=1152921510055116704
            // 0x00BC6030: STR q0, [sp, #0x90]        | stack[1152921510055116688] = val_47;     //  dest_result_addr=1152921510055116688
            label_215:
            // 0x00BC6034: LDR x1, [x27]              | X1 = public System.Boolean List.Enumerator<System.Reflection.MethodInfo>::MoveNext();
            // 0x00BC6038: ADD x0, sp, #0x90          | X0 = (1152921510055116544 + 144) = 1152921510055116688 (0x1000000144BDFF90);
            // 0x00BC603C: BL #0x133720c              | X0 = label_List_Enumerator<System_Object>_VerifyState_GL0133720C();
            // 0x00BC6040: AND w8, w0, #1             | W8 = (1152921510055116688 & 1) = 0 (0x00000000);
            // 0x00BC6044: TBZ w8, #0, #0xbc6298      | if ((0x0 & 0x1) == 0) goto label_202;   
            if((0 & 1) == 0)
            {
                goto label_202;
            }
            // 0x00BC6048: LDR x1, [x28]              | X1 = public System.Reflection.MethodInfo List.Enumerator<System.Reflection.MethodInfo>::get_Current();
            // 0x00BC604C: ADD x0, sp, #0x90          | X0 = (1152921510055116544 + 144) = 1152921510055116688 (0x1000000144BDFF90);
            // 0x00BC6050: BL #0x13372d8              | X0 = val_47.get_InitialType();          
            System.Type val_78 = val_47.InitialType;
            // 0x00BC6054: MOV x22, x0                | X22 = val_78;//m1                       
            // 0x00BC6058: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x00BC605C: LDR x0, [x19]              | X0 = typeof(System.Type);               
            // 0x00BC6060: LDR x8, [x8, #0xff0]       | X8 = 1152921504607645696;               
            // 0x00BC6064: LDR x23, [x8]              | X23 = typeof(System.UInt32);            
            // 0x00BC6068: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC606C: TBZ w8, #0, #0xbc607c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_204;
            // 0x00BC6070: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC6074: CBNZ w8, #0xbc607c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_204;
            // 0x00BC6078: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_204:
            // 0x00BC607C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC6080: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC6084: MOV x1, x23                | X1 = 1152921504607645696 (0x10000000000C3000);//ML01
            // 0x00BC6088: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_79 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC608C: MOV x23, x0                | X23 = val_79;//m1                       
            val_119 = val_79;
            // 0x00BC6090: LDR x24, [x26]             | X24 = "JSDelayCall";                    
            // 0x00BC6094: MOV x0, x24                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC6098: BL #0x277461c              | X0 = sub_277461C( ?? "JSDelayCall", ????);
            // 0x00BC609C: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x00BC60A0: MOV x0, x24                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC60A4: BL #0x27c1608              | X0 = sub_27C1608( ?? "JSDelayCall", ????);
            // 0x00BC60A8: MOV x24, x0                | X24 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC60AC: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x00BC60B0: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x00BC60B4: LDR x1, [x8]               | X1 = typeof(System.Single);             
            // 0x00BC60B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC60BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC60C0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_80 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC60C4: MOV x25, x0                | X25 = val_80;//m1                       
            // 0x00BC60C8: CBNZ x24, #0xbc60d0        | if ("JSDelayCall" != null) goto label_205;
            if("JSDelayCall" != null)
            {
                goto label_205;
            }
            // 0x00BC60CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_80, ????);     
            label_205:
            // 0x00BC60D0: CBZ x25, #0xbc60f4         | if (val_80 == null) goto label_207;     
            if(val_80 == null)
            {
                goto label_207;
            }
            // 0x00BC60D4: LDR x8, [x24]              | X8 = "JSDelayCall";                     
            // 0x00BC60D8: LDR x1, [x8, #0x30]        | 
            // 0x00BC60DC: MOV x0, x25                | X0 = val_80;//m1                        
            // 0x00BC60E0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_80, ????);     
            // 0x00BC60E4: CBNZ x0, #0xbc60f4         | if (val_80 != null) goto label_207;     
            if(val_80 != null)
            {
                goto label_207;
            }
            // 0x00BC60E8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_80, ????);     
            // 0x00BC60EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC60F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_80, ????);     
            label_207:
            // 0x00BC60F4: LDR w8, [x24, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC60F8: CBNZ w8, #0xbc6108         | if ("JSDelayCall".__il2cppRuntimeField_18 != 0) goto label_208;
            // 0x00BC60FC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_80, ????);     
            // 0x00BC6100: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6104: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_80, ????);     
            label_208:
            // 0x00BC6108: STR x25, [x24, #0x20]      | "JSDelayCall".__il2cppRuntimeField_20 = val_80;  //  dest_result_addr=1152921510054834208
            "JSDelayCall".__il2cppRuntimeField_20 = val_80;
            // 0x00BC610C: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
            // 0x00BC6110: LDR x8, [x8, #0x150]       | X8 = 1152921504657965056;               
            // 0x00BC6114: LDR x1, [x8]               | X1 = typeof(System.Action<T>);          
            // 0x00BC6118: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC611C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC6120: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_81 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC6124: MOV x25, x0                | X25 = val_81;//m1                       
            // 0x00BC6128: CBZ x25, #0xbc614c         | if (val_81 == null) goto label_210;     
            if(val_81 == null)
            {
                goto label_210;
            }
            // 0x00BC612C: LDR x8, [x24]              | X8 = "JSDelayCall";                     
            // 0x00BC6130: LDR x1, [x8, #0x30]        | 
            // 0x00BC6134: MOV x0, x25                | X0 = val_81;//m1                        
            // 0x00BC6138: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_81, ????);     
            // 0x00BC613C: CBNZ x0, #0xbc614c         | if (val_81 != null) goto label_210;     
            if(val_81 != null)
            {
                goto label_210;
            }
            // 0x00BC6140: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_81, ????);     
            // 0x00BC6144: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6148: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_81, ????);     
            label_210:
            // 0x00BC614C: LDR w8, [x24, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC6150: CMP w8, #1                 | STATE = COMPARE("JSDelayCall".__il2cppRuntimeField_18, 0x1)
            // 0x00BC6154: B.HI #0xbc6164             | if ("JSDelayCall".__il2cppRuntimeField_18 > 0x1) goto label_211;
            // 0x00BC6158: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_81, ????);     
            // 0x00BC615C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6160: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_81, ????);     
            label_211:
            // 0x00BC6164: STR x25, [x24, #0x28]      | "JSDelayCall".__il2cppRuntimeField_28 = val_81;  //  dest_result_addr=1152921510054834216
            "JSDelayCall".__il2cppRuntimeField_28 = val_81;
            // 0x00BC6168: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x00BC616C: LDR x8, [x8, #0xcb8]       | X8 = 1152921504608604160;               
            // 0x00BC6170: LDR x1, [x8]               | X1 = typeof(System.Boolean);            
            // 0x00BC6174: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC6178: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC617C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_82 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC6180: MOV x25, x0                | X25 = val_82;//m1                       
            val_120 = val_82;
            // 0x00BC6184: CBZ x25, #0xbc61a8         | if (val_82 == null) goto label_213;     
            if(val_120 == null)
            {
                goto label_213;
            }
            // 0x00BC6188: LDR x8, [x24]              | X8 = "JSDelayCall";                     
            // 0x00BC618C: LDR x1, [x8, #0x30]        | 
            // 0x00BC6190: MOV x0, x25                | X0 = val_82;//m1                        
            // 0x00BC6194: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_82, ????);     
            // 0x00BC6198: CBNZ x0, #0xbc61a8         | if (val_82 != null) goto label_213;     
            if(val_120 != null)
            {
                goto label_213;
            }
            // 0x00BC619C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_82, ????);     
            // 0x00BC61A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC61A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_82, ????);     
            label_213:
            // 0x00BC61A8: LDR w8, [x24, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC61AC: CMP w8, #2                 | STATE = COMPARE("JSDelayCall".__il2cppRuntimeField_18, 0x2)
            // 0x00BC61B0: B.HI #0xbc61c0             | if ("JSDelayCall".__il2cppRuntimeField_18 > 0x2) goto label_214;
            // 0x00BC61B4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_82, ????);     
            // 0x00BC61B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC61BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_82, ????);     
            label_214:
            // 0x00BC61C0: STR x25, [x24, #0x30]      | "JSDelayCall".__il2cppRuntimeField_30 = val_82;  //  dest_result_addr=1152921510054834224
            "JSDelayCall".__il2cppRuntimeField_30 = val_120;
            // 0x00BC61C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC61C8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC61CC: MOV x1, x22                | X1 = val_78;//m1                        
            // 0x00BC61D0: MOV x2, x21                | X2 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC61D4: MOV x3, x23                | X3 = val_79;//m1                        
            // 0x00BC61D8: MOV x4, x24                | X4 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC61DC: BL #0x28f47e4              | X0 = ILRuntime.Runtime.Extensions.MatchGenericParameters(m:  0, genericArguments:  val_78, returnType:  val_133, parameters:  val_119);
            bool val_83 = ILRuntime.Runtime.Extensions.MatchGenericParameters(m:  0, genericArguments:  val_78, returnType:  val_133, parameters:  val_119);
            // 0x00BC61E0: TBZ w0, #0, #0xbc6034      | if (val_83 == false) goto label_215;    
            if(val_83 == false)
            {
                goto label_215;
            }
            // 0x00BC61E4: CBNZ x22, #0xbc61ec        | if (val_78 != null) goto label_216;     
            if(val_78 != null)
            {
                goto label_216;
            }
            // 0x00BC61E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_83, ????);     
            label_216:
            // 0x00BC61EC: LDR x8, [x22]              | X8 = typeof(System.Type);               
            // 0x00BC61F0: LDR x9, [x8, #0x3b0]       | X9 = typeof(System.Type).__il2cppRuntimeField_3B0;
            // 0x00BC61F4: LDR x2, [x8, #0x3b8]       | X2 = typeof(System.Type).__il2cppRuntimeField_3B8;
            // 0x00BC61F8: MOV x0, x22                | X0 = val_78;//m1                        
            // 0x00BC61FC: MOV x1, x21                | X1 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC6200: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_3B0();
            // 0x00BC6204: MOV x21, x0                | X21 = val_78;//m1                       
            // 0x00BC6208: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x00BC620C: LDR x8, [x8, #0xd10]       | X8 = 1152921504783044608;               
            // 0x00BC6210: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC6214: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC6218: LDR x22, [x8, #0x70]       | X22 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheE;
            val_140 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheE;
            // 0x00BC621C: CBNZ x22, #0xbc6278        | if (ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheE != null) goto label_217;
            if(val_140 != null)
            {
                goto label_217;
            }
            // 0x00BC6220: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
            // 0x00BC6224: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC6228: LDR x8, [x8, #0xe18]       | X8 = 1152921510055018896;               
            // 0x00BC622C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC6230: LDR x23, [x8]              | X23 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::JSDelayCall_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            val_119 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::JSDelayCall_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC6234: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x00BC6238: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC623C: MOV x22, x0                | X22 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC6240: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6244: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC6248: MOV x0, x22                | X0 = 1152921504823939072 (0x100000000CF09000);//ML01
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_84 = null;
            // 0x00BC624C: MOV x2, x23                | X2 = 1152921510055018896 (0x1000000144BC8190);//ML01
            // 0x00BC6250: BL #0x28e3b10              | .ctor(object:  0, method:  val_119);    
            val_84 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  val_119);
            // 0x00BC6254: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x00BC6258: LDR x8, [x8, #0xd10]       | X8 = 1152921504783044608;               
            // 0x00BC625C: MOV x9, x8                 | X9 = 57999632 (0x3750110);//ML01        
            // 0x00BC6260: LDR x8, [x9]               | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC6264: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC6268: STR x22, [x8, #0x70]       | ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheE = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783048816
            ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheE = null;
            // 0x00BC626C: LDR x8, [x9]               | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC6270: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC6274: LDR x22, [x8, #0x70]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_140 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheE;
            label_217:
            // 0x00BC6278: LDR x8, [sp, #0x10]        | X8 = X1;                                
            // 0x00BC627C: CBNZ x8, #0xbc6284         | if (X1 != 0) goto label_218;            
            if(X1 != 0)
            {
                goto label_218;
            }
            // 0x00BC6280: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  val_119), ????);
            label_218:
            // 0x00BC6284: LDR x0, [sp, #0x10]        | X0 = X1;                                
            // 0x00BC6288: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC628C: MOV x1, x21                | X1 = val_78;//m1                        
            // 0x00BC6290: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC6294: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_78, func:  val_140);
            X1.RegisterCLRMethodRedirection(mi:  val_78, func:  val_140);
            label_202:
            // 0x00BC6298: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC629C: LDR x8, [x8, #0x568]       | X8 = 1152921510054942096;               
            // 0x00BC62A0: ADD x0, sp, #0x90          | X0 = (1152921510055116544 + 144) = 1152921510055116688 (0x1000000144BDFF90);
            // 0x00BC62A4: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<System.Reflection.MethodInfo>::Dispose();
            // 0x00BC62A8: BL #0x13371f4              | val_47.Dispose();                       
            val_47.Dispose();
            // 0x00BC62AC: MOV x28, x26               | X28 = 58347504 (0x37A4FF0);//ML01       
            val_133 = val_133;
            // 0x00BC62B0: ADRP x26, #0x366b000       | X26 = 57061376 (0x366B000);             
            // 0x00BC62B4: ADRP x24, #0x35c9000       | X24 = 56397824 (0x35C9000);             
            // 0x00BC62B8: LDR x26, [x26, #0x340]     | X26 = (string**)(1152921510054834176)("JSDelayCall");
            val_135 = "JSDelayCall";
            // 0x00BC62BC: LDR x24, [x24, #0xcf8]     | X24 = 1152921510054905232;              
            val_131 = 1152921510054905232;
            // 0x00BC62C0: B #0xbc6308                |  goto label_220;                        
            goto label_220;
            label_315:
            // 0x00BC62C4: ADRP x24, #0x35c9000       | X24 = 56397824 (0x35C9000);             
            // 0x00BC62C8: LDR x24, [x24, #0xcf8]     | X24 = 1152921510054905232;              
            val_131 = 1152921510054905232;
            // 0x00BC62CC: MOV x28, x26               | X28 = 58347504 (0x37A4FF0);//ML01       
            val_133 = val_135;
            // 0x00BC62D0: BL #0x981060               | X0 = sub_981060( ?? 0x1000000144BDFF90, ????);
            // 0x00BC62D4: LDR x21, [x0]              | X21 = val_47;                           
            // 0x00BC62D8: BL #0x980920               | X0 = sub_980920( ?? 0x1000000144BDFF90, ????);
            // 0x00BC62DC: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC62E0: LDR x8, [x8, #0x568]       | X8 = 1152921510054942096;               
            // 0x00BC62E4: ADD x0, sp, #0x90          | X0 = (1152921510055116544 + 144) = 1152921510055116688 (0x1000000144BDFF90);
            // 0x00BC62E8: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<System.Reflection.MethodInfo>::Dispose();
            // 0x00BC62EC: BL #0x13371f4              | val_47.Dispose();                       
            val_47.Dispose();
            // 0x00BC62F0: ADRP x26, #0x366b000       | X26 = 57061376 (0x366B000);             
            // 0x00BC62F4: LDR x26, [x26, #0x340]     | X26 = (string**)(1152921510054834176)("JSDelayCall");
            val_135 = "JSDelayCall";
            // 0x00BC62F8: CBZ x21, #0xbc6308         | if (val_47 == 0) goto label_220;        
            if(val_47 == 0)
            {
                goto label_220;
            }
            // 0x00BC62FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6300: MOV x0, x21                | X0 = val_47;//m1                        
            // 0x00BC6304: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_47, ????);     
            label_220:
            // 0x00BC6308: LDR x21, [x28]             | X21 = "JSDelayCall";                    
            // 0x00BC630C: MOV x0, x21                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC6310: BL #0x277461c              | X0 = sub_277461C( ?? "JSDelayCall", ????);
            // 0x00BC6314: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00BC6318: MOV x0, x21                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC631C: BL #0x27c1608              | X0 = sub_27C1608( ?? "JSDelayCall", ????);
            // 0x00BC6320: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
            // 0x00BC6324: LDR x8, [x19]              | X8 = typeof(System.Type);               
            // 0x00BC6328: LDR x9, [x9, #0xd20]       | X9 = 1152921504825909248;               
            // 0x00BC632C: MOV x21, x0                | X21 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC6330: LDR x22, [x9]              | X22 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
            // 0x00BC6334: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC6338: TBZ w9, #0, #0xbc634c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_222;
            // 0x00BC633C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC6340: CBNZ w9, #0xbc634c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_222;
            // 0x00BC6344: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC6348: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_222:
            // 0x00BC634C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC6350: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC6354: MOV x1, x22                | X1 = 1152921504825909248 (0x100000000D0EA000);//ML01
            // 0x00BC6358: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_85 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC635C: MOV x22, x0                | X22 = val_85;//m1                       
            // 0x00BC6360: CBNZ x21, #0xbc6368        | if ("JSDelayCall" != null) goto label_223;
            if("JSDelayCall" != null)
            {
                goto label_223;
            }
            // 0x00BC6364: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_85, ????);     
            label_223:
            // 0x00BC6368: CBZ x22, #0xbc638c         | if (val_85 == null) goto label_225;     
            if(val_85 == null)
            {
                goto label_225;
            }
            // 0x00BC636C: LDR x8, [x21]              | X8 = "JSDelayCall";                     
            // 0x00BC6370: MOV x0, x22                | X0 = val_85;//m1                        
            // 0x00BC6374: LDR x1, [x8, #0x30]        | 
            // 0x00BC6378: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_85, ????);     
            // 0x00BC637C: CBNZ x0, #0xbc638c         | if (val_85 != null) goto label_225;     
            if(val_85 != null)
            {
                goto label_225;
            }
            // 0x00BC6380: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_85, ????);     
            // 0x00BC6384: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6388: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_85, ????);     
            label_225:
            // 0x00BC638C: LDR w8, [x21, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC6390: CBNZ w8, #0xbc63a0         | if ("JSDelayCall".__il2cppRuntimeField_18 != 0) goto label_226;
            // 0x00BC6394: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_85, ????);     
            // 0x00BC6398: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC639C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_85, ????);     
            label_226:
            // 0x00BC63A0: STR x22, [x21, #0x20]      | "JSDelayCall".__il2cppRuntimeField_20 = val_85;  //  dest_result_addr=1152921510054834208
            "JSDelayCall".__il2cppRuntimeField_20 = val_85;
            // 0x00BC63A4: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x00BC63A8: LDR x8, [x8, #0x9a8]       | X8 = 1152921504607113216;               
            // 0x00BC63AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC63B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC63B4: LDR x1, [x8]               | X1 = typeof(System.Int32);              
            // 0x00BC63B8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_86 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC63BC: MOV x22, x0                | X22 = val_86;//m1                       
            // 0x00BC63C0: CBZ x22, #0xbc63e4         | if (val_86 == null) goto label_228;     
            if(val_86 == null)
            {
                goto label_228;
            }
            // 0x00BC63C4: LDR x8, [x21]              | X8 = "JSDelayCall";                     
            // 0x00BC63C8: MOV x0, x22                | X0 = val_86;//m1                        
            // 0x00BC63CC: LDR x1, [x8, #0x30]        | 
            // 0x00BC63D0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_86, ????);     
            // 0x00BC63D4: CBNZ x0, #0xbc63e4         | if (val_86 != null) goto label_228;     
            if(val_86 != null)
            {
                goto label_228;
            }
            // 0x00BC63D8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_86, ????);     
            // 0x00BC63DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC63E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_86, ????);     
            label_228:
            // 0x00BC63E4: LDR w8, [x21, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC63E8: CMP w8, #1                 | STATE = COMPARE("JSDelayCall".__il2cppRuntimeField_18, 0x1)
            // 0x00BC63EC: B.HI #0xbc63fc             | if ("JSDelayCall".__il2cppRuntimeField_18 > 0x1) goto label_229;
            // 0x00BC63F0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_86, ????);     
            // 0x00BC63F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC63F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_86, ????);     
            label_229:
            // 0x00BC63FC: STR x22, [x21, #0x28]      | "JSDelayCall".__il2cppRuntimeField_28 = val_86;  //  dest_result_addr=1152921510054834216
            "JSDelayCall".__il2cppRuntimeField_28 = val_86;
            // 0x00BC6400: CBNZ x20, #0xbc6408        | if ( != 0) goto label_230;              
            if(null != 0)
            {
                goto label_230;
            }
            // 0x00BC6404: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_86, ????);     
            label_230:
            // 0x00BC6408: LDR x1, [x26]              | X1 = "JSDelayCall";                     
            // 0x00BC640C: LDR x3, [x24]              | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.Reflection.MethodInfo>>::TryGetValue(System.String key, out System.Collections.Generic.List<System.Reflection.MethodInfo> value);
            // 0x00BC6410: SUB x2, x29, #0x58         | X2 = (1152921510055116896 - 88) = 1152921510055116808 (0x1000000144BE0008);
            // 0x00BC6414: MOV x0, x20                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x00BC6418: BL #0x23fe7ec              | X0 = TryGetValue(key:  val_135 = "JSDelayCall", value: out  val_43);
            bool val_87 = TryGetValue(key:  val_135, value: out  val_43);
            // 0x00BC641C: TBZ w0, #0, #0xbc677c      | if (val_87 == false) goto label_254;    
            if(val_87 == false)
            {
                goto label_254;
            }
            // 0x00BC6420: LDUR x22, [x29, #-0x58]    | X22 = typeof(System.Collections.Generic.List<T>);
            // 0x00BC6424: CBNZ x22, #0xbc642c        | if ( != 0) goto label_232;              
            if(null != 0)
            {
                goto label_232;
            }
            // 0x00BC6428: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_87, ????);     
            label_232:
            // 0x00BC642C: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x00BC6430: LDR x8, [x8, #0x60]        | X8 = 1152921510054917520;               
            // 0x00BC6434: MOV x0, x22                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00BC6438: LDR x1, [x8]               | X1 = public List.Enumerator<T> System.Collections.Generic.List<System.Reflection.MethodInfo>::GetEnumerator();
            // 0x00BC643C: ADD x8, sp, #0x18          | X8 = (1152921510055116544 + 24) = 1152921510055116568 (0x1000000144BDFF18);
            // 0x00BC6440: BL #0x25ebf2c              | X0 = GetEnumerator();                   
            List.Enumerator<T> val_88 = GetEnumerator();
            // 0x00BC6444: ADRP x27, #0x3671000       | X27 = 57085952 (0x3671000);             
            // 0x00BC6448: LDR x8, [sp, #0x28]        | X8 = val_46;                             //  find_add[1152921510055104912]
            // 0x00BC644C: LDUR q0, [sp, #0x18]       | Q0 = val_47;                             //  find_add[1152921510055104912]
            // 0x00BC6450: LDR x27, [x27, #0x830]     | X27 = 1152921510054918544;              
            val_137 = 1152921510054918544;
            // 0x00BC6454: STR x8, [sp, #0x80]        | stack[1152921510055116672] = val_46;     //  dest_result_addr=1152921510055116672
            // 0x00BC6458: STR q0, [sp, #0x70]        | stack[1152921510055116656] = val_47;     //  dest_result_addr=1152921510055116656
            label_249:
            // 0x00BC645C: LDR x1, [x27]              | X1 = public System.Boolean List.Enumerator<System.Reflection.MethodInfo>::MoveNext();
            // 0x00BC6460: ADD x0, sp, #0x70          | X0 = (1152921510055116544 + 112) = 1152921510055116656 (0x1000000144BDFF70);
            // 0x00BC6464: BL #0x133720c              | X0 = label_List_Enumerator<System_Object>_VerifyState_GL0133720C();
            // 0x00BC6468: AND w8, w0, #1             | W8 = (1152921510055116656 & 1) = 0 (0x00000000);
            // 0x00BC646C: TBZ w8, #0, #0xbc6724      | if ((0x0 & 0x1) == 0) goto label_233;   
            if((0 & 1) == 0)
            {
                goto label_233;
            }
            // 0x00BC6470: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x00BC6474: LDR x8, [x8, #0x9f0]       | X8 = 1152921510054919568;               
            // 0x00BC6478: LDR x1, [x8]               | X1 = public System.Reflection.MethodInfo List.Enumerator<System.Reflection.MethodInfo>::get_Current();
            // 0x00BC647C: ADD x0, sp, #0x70          | X0 = (1152921510055116544 + 112) = 1152921510055116656 (0x1000000144BDFF70);
            // 0x00BC6480: BL #0x13372d8              | X0 = val_47.get_InitialType();          
            System.Type val_89 = val_47.InitialType;
            // 0x00BC6484: MOV x22, x0                | X22 = val_89;//m1                       
            // 0x00BC6488: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x00BC648C: LDR x0, [x19]              | X0 = typeof(System.Type);               
            // 0x00BC6490: LDR x8, [x8, #0xff0]       | X8 = 1152921504607645696;               
            // 0x00BC6494: LDR x23, [x8]              | X23 = typeof(System.UInt32);            
            // 0x00BC6498: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC649C: TBZ w8, #0, #0xbc64ac      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_235;
            // 0x00BC64A0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC64A4: CBNZ w8, #0xbc64ac         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_235;
            // 0x00BC64A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_235:
            // 0x00BC64AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC64B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC64B4: MOV x1, x23                | X1 = 1152921504607645696 (0x10000000000C3000);//ML01
            // 0x00BC64B8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_90 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC64BC: MOV x23, x0                | X23 = val_90;//m1                       
            val_119 = val_90;
            // 0x00BC64C0: LDR x24, [x28]             | X24 = "JSDelayCall";                    
            // 0x00BC64C4: MOV x0, x24                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC64C8: BL #0x277461c              | X0 = sub_277461C( ?? "JSDelayCall", ????);
            // 0x00BC64CC: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x00BC64D0: MOV x0, x24                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC64D4: BL #0x27c1608              | X0 = sub_27C1608( ?? "JSDelayCall", ????);
            // 0x00BC64D8: MOV x24, x0                | X24 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC64DC: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x00BC64E0: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x00BC64E4: LDR x1, [x8]               | X1 = typeof(System.Single);             
            // 0x00BC64E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC64EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC64F0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_91 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC64F4: MOV x25, x0                | X25 = val_91;//m1                       
            // 0x00BC64F8: CBNZ x24, #0xbc6500        | if ("JSDelayCall" != null) goto label_236;
            if("JSDelayCall" != null)
            {
                goto label_236;
            }
            // 0x00BC64FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_91, ????);     
            label_236:
            // 0x00BC6500: CBZ x25, #0xbc6524         | if (val_91 == null) goto label_238;     
            if(val_91 == null)
            {
                goto label_238;
            }
            // 0x00BC6504: LDR x8, [x24]              | X8 = "JSDelayCall";                     
            // 0x00BC6508: LDR x1, [x8, #0x30]        | 
            // 0x00BC650C: MOV x0, x25                | X0 = val_91;//m1                        
            // 0x00BC6510: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_91, ????);     
            // 0x00BC6514: CBNZ x0, #0xbc6524         | if (val_91 != null) goto label_238;     
            if(val_91 != null)
            {
                goto label_238;
            }
            // 0x00BC6518: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_91, ????);     
            // 0x00BC651C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6520: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_91, ????);     
            label_238:
            // 0x00BC6524: LDR w8, [x24, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC6528: CBNZ w8, #0xbc6538         | if ("JSDelayCall".__il2cppRuntimeField_18 != 0) goto label_239;
            // 0x00BC652C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_91, ????);     
            // 0x00BC6530: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6534: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_91, ????);     
            label_239:
            // 0x00BC6538: STR x25, [x24, #0x20]      | "JSDelayCall".__il2cppRuntimeField_20 = val_91;  //  dest_result_addr=1152921510054834208
            "JSDelayCall".__il2cppRuntimeField_20 = val_91;
            // 0x00BC653C: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x00BC6540: LDR x8, [x8, #0xbc8]       | X8 = 1152921504687890432;               
            // 0x00BC6544: LDR x1, [x8]               | X1 = typeof(System.Action<T1, T2>);     
            // 0x00BC6548: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC654C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC6550: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_92 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC6554: MOV x25, x0                | X25 = val_92;//m1                       
            // 0x00BC6558: CBZ x25, #0xbc657c         | if (val_92 == null) goto label_241;     
            if(val_92 == null)
            {
                goto label_241;
            }
            // 0x00BC655C: LDR x8, [x24]              | X8 = "JSDelayCall";                     
            // 0x00BC6560: LDR x1, [x8, #0x30]        | 
            // 0x00BC6564: MOV x0, x25                | X0 = val_92;//m1                        
            // 0x00BC6568: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_92, ????);     
            // 0x00BC656C: CBNZ x0, #0xbc657c         | if (val_92 != null) goto label_241;     
            if(val_92 != null)
            {
                goto label_241;
            }
            // 0x00BC6570: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_92, ????);     
            // 0x00BC6574: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6578: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_92, ????);     
            label_241:
            // 0x00BC657C: LDR w8, [x24, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC6580: CMP w8, #1                 | STATE = COMPARE("JSDelayCall".__il2cppRuntimeField_18, 0x1)
            // 0x00BC6584: B.HI #0xbc6594             | if ("JSDelayCall".__il2cppRuntimeField_18 > 0x1) goto label_242;
            // 0x00BC6588: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_92, ????);     
            // 0x00BC658C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6590: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_92, ????);     
            label_242:
            // 0x00BC6594: STR x25, [x24, #0x28]      | "JSDelayCall".__il2cppRuntimeField_28 = val_92;  //  dest_result_addr=1152921510054834216
            "JSDelayCall".__il2cppRuntimeField_28 = val_92;
            // 0x00BC6598: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00BC659C: LDR x8, [x8, #0xd20]       | X8 = 1152921504825909248;               
            // 0x00BC65A0: LDR x1, [x8]               | X1 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
            // 0x00BC65A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC65A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC65AC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_93 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC65B0: MOV x25, x0                | X25 = val_93;//m1                       
            // 0x00BC65B4: CBZ x25, #0xbc65d8         | if (val_93 == null) goto label_244;     
            if(val_93 == null)
            {
                goto label_244;
            }
            // 0x00BC65B8: LDR x8, [x24]              | X8 = "JSDelayCall";                     
            // 0x00BC65BC: LDR x1, [x8, #0x30]        | 
            // 0x00BC65C0: MOV x0, x25                | X0 = val_93;//m1                        
            // 0x00BC65C4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_93, ????);     
            // 0x00BC65C8: CBNZ x0, #0xbc65d8         | if (val_93 != null) goto label_244;     
            if(val_93 != null)
            {
                goto label_244;
            }
            // 0x00BC65CC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_93, ????);     
            // 0x00BC65D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC65D4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_93, ????);     
            label_244:
            // 0x00BC65D8: LDR w8, [x24, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC65DC: CMP w8, #2                 | STATE = COMPARE("JSDelayCall".__il2cppRuntimeField_18, 0x2)
            // 0x00BC65E0: B.HI #0xbc65f0             | if ("JSDelayCall".__il2cppRuntimeField_18 > 0x2) goto label_245;
            // 0x00BC65E4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_93, ????);     
            // 0x00BC65E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC65EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_93, ????);     
            label_245:
            // 0x00BC65F0: STR x25, [x24, #0x30]      | "JSDelayCall".__il2cppRuntimeField_30 = val_93;  //  dest_result_addr=1152921510054834224
            "JSDelayCall".__il2cppRuntimeField_30 = val_93;
            // 0x00BC65F4: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x00BC65F8: LDR x8, [x8, #0x9a8]       | X8 = 1152921504607113216;               
            // 0x00BC65FC: LDR x1, [x8]               | X1 = typeof(System.Int32);              
            // 0x00BC6600: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC6604: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC6608: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_94 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC660C: MOV x25, x0                | X25 = val_94;//m1                       
            val_120 = val_94;
            // 0x00BC6610: CBZ x25, #0xbc6634         | if (val_94 == null) goto label_247;     
            if(val_120 == null)
            {
                goto label_247;
            }
            // 0x00BC6614: LDR x8, [x24]              | X8 = "JSDelayCall";                     
            // 0x00BC6618: LDR x1, [x8, #0x30]        | 
            // 0x00BC661C: MOV x0, x25                | X0 = val_94;//m1                        
            // 0x00BC6620: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_94, ????);     
            // 0x00BC6624: CBNZ x0, #0xbc6634         | if (val_94 != null) goto label_247;     
            if(val_120 != null)
            {
                goto label_247;
            }
            // 0x00BC6628: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_94, ????);     
            // 0x00BC662C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6630: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_94, ????);     
            label_247:
            // 0x00BC6634: LDR w8, [x24, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC6638: CMP w8, #3                 | STATE = COMPARE("JSDelayCall".__il2cppRuntimeField_18, 0x3)
            // 0x00BC663C: B.HI #0xbc664c             | if ("JSDelayCall".__il2cppRuntimeField_18 > 0x3) goto label_248;
            // 0x00BC6640: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_94, ????);     
            // 0x00BC6644: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6648: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_94, ????);     
            label_248:
            // 0x00BC664C: STR x25, [x24, #0x38]      | "JSDelayCall".__il2cppRuntimeField_38 = val_94;  //  dest_result_addr=1152921510054834232
            "JSDelayCall".__il2cppRuntimeField_38 = val_120;
            // 0x00BC6650: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC6654: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC6658: MOV x1, x22                | X1 = val_89;//m1                        
            // 0x00BC665C: MOV x2, x21                | X2 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC6660: MOV x3, x23                | X3 = val_90;//m1                        
            // 0x00BC6664: MOV x4, x24                | X4 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC6668: BL #0x28f47e4              | X0 = ILRuntime.Runtime.Extensions.MatchGenericParameters(m:  0, genericArguments:  val_89, returnType:  val_133, parameters:  val_119);
            bool val_95 = ILRuntime.Runtime.Extensions.MatchGenericParameters(m:  0, genericArguments:  val_89, returnType:  val_133, parameters:  val_119);
            // 0x00BC666C: TBZ w0, #0, #0xbc645c      | if (val_95 == false) goto label_249;    
            if(val_95 == false)
            {
                goto label_249;
            }
            // 0x00BC6670: CBNZ x22, #0xbc6678        | if (val_89 != null) goto label_250;     
            if(val_89 != null)
            {
                goto label_250;
            }
            // 0x00BC6674: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_95, ????);     
            label_250:
            // 0x00BC6678: LDR x8, [x22]              | X8 = typeof(System.Type);               
            // 0x00BC667C: LDR x9, [x8, #0x3b0]       | X9 = typeof(System.Type).__il2cppRuntimeField_3B0;
            // 0x00BC6680: LDR x2, [x8, #0x3b8]       | X2 = typeof(System.Type).__il2cppRuntimeField_3B8;
            // 0x00BC6684: MOV x0, x22                | X0 = val_89;//m1                        
            // 0x00BC6688: MOV x1, x21                | X1 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC668C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_3B0();
            // 0x00BC6690: MOV x21, x0                | X21 = val_89;//m1                       
            // 0x00BC6694: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x00BC6698: LDR x8, [x8, #0xd10]       | X8 = 1152921504783044608;               
            // 0x00BC669C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC66A0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC66A4: LDR x22, [x8, #0x78]       | X22 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheF;
            val_141 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheF;
            // 0x00BC66A8: CBNZ x22, #0xbc6704        | if (ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheF != null) goto label_251;
            if(val_141 != null)
            {
                goto label_251;
            }
            // 0x00BC66AC: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
            // 0x00BC66B0: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC66B4: LDR x8, [x8, #0x408]       | X8 = 1152921510055052688;               
            // 0x00BC66B8: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC66BC: LDR x23, [x8]              | X23 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::JSDelayCall_15(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            val_119 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::JSDelayCall_15(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC66C0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x00BC66C4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC66C8: MOV x22, x0                | X22 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC66CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC66D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC66D4: MOV x0, x22                | X0 = 1152921504823939072 (0x100000000CF09000);//ML01
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_96 = null;
            // 0x00BC66D8: MOV x2, x23                | X2 = 1152921510055052688 (0x1000000144BD0590);//ML01
            // 0x00BC66DC: BL #0x28e3b10              | .ctor(object:  0, method:  val_119);    
            val_96 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  val_119);
            // 0x00BC66E0: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x00BC66E4: LDR x8, [x8, #0xd10]       | X8 = 1152921504783044608;               
            // 0x00BC66E8: MOV x9, x8                 | X9 = 57999632 (0x3750110);//ML01        
            // 0x00BC66EC: LDR x8, [x9]               | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC66F0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC66F4: STR x22, [x8, #0x78]       | ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheF = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783048824
            ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheF = null;
            // 0x00BC66F8: LDR x8, [x9]               | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC66FC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC6700: LDR x22, [x8, #0x78]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_141 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cacheF;
            label_251:
            // 0x00BC6704: LDR x8, [sp, #0x10]        | X8 = X1;                                
            // 0x00BC6708: CBNZ x8, #0xbc6710         | if (X1 != 0) goto label_252;            
            if(X1 != 0)
            {
                goto label_252;
            }
            // 0x00BC670C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  val_119), ????);
            label_252:
            // 0x00BC6710: LDR x0, [sp, #0x10]        | X0 = X1;                                
            // 0x00BC6714: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC6718: MOV x1, x21                | X1 = val_89;//m1                        
            // 0x00BC671C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC6720: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_89, func:  val_141);
            X1.RegisterCLRMethodRedirection(mi:  val_89, func:  val_141);
            label_233:
            // 0x00BC6724: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC6728: LDR x8, [x8, #0x568]       | X8 = 1152921510054942096;               
            // 0x00BC672C: ADD x0, sp, #0x70          | X0 = (1152921510055116544 + 112) = 1152921510055116656 (0x1000000144BDFF70);
            // 0x00BC6730: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<System.Reflection.MethodInfo>::Dispose();
            // 0x00BC6734: BL #0x13371f4              | val_47.Dispose();                       
            val_47.Dispose();
            // 0x00BC6738: ADRP x24, #0x35c9000       | X24 = 56397824 (0x35C9000);             
            // 0x00BC673C: LDR x24, [x24, #0xcf8]     | X24 = 1152921510054905232;              
            val_131 = 1152921510054905232;
            // 0x00BC6740: B #0xbc677c                |  goto label_254;                        
            goto label_254;
            label_318:
            // 0x00BC6744: ADRP x24, #0x35c9000       | X24 = 56397824 (0x35C9000);             
            // 0x00BC6748: LDR x24, [x24, #0xcf8]     | X24 = 1152921510054905232;              
            val_131 = 1152921510054905232;
            // 0x00BC674C: BL #0x981060               | X0 = sub_981060( ?? 0x1000000144BDFF70, ????);
            // 0x00BC6750: LDR x21, [x0]              | X21 = val_47;                           
            // 0x00BC6754: BL #0x980920               | X0 = sub_980920( ?? 0x1000000144BDFF70, ????);
            // 0x00BC6758: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC675C: LDR x8, [x8, #0x568]       | X8 = 1152921510054942096;               
            // 0x00BC6760: ADD x0, sp, #0x70          | X0 = (1152921510055116544 + 112) = 1152921510055116656 (0x1000000144BDFF70);
            // 0x00BC6764: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<System.Reflection.MethodInfo>::Dispose();
            // 0x00BC6768: BL #0x13371f4              | val_47.Dispose();                       
            val_47.Dispose();
            // 0x00BC676C: CBZ x21, #0xbc677c         | if (val_47 == 0) goto label_254;        
            if(val_47 == 0)
            {
                goto label_254;
            }
            // 0x00BC6770: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6774: MOV x0, x21                | X0 = val_47;//m1                        
            // 0x00BC6778: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_47, ????);     
            label_254:
            // 0x00BC677C: LDR x21, [x28]             | X21 = "JSDelayCall";                    
            // 0x00BC6780: MOV x0, x21                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC6784: BL #0x277461c              | X0 = sub_277461C( ?? "JSDelayCall", ????);
            // 0x00BC6788: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BC678C: MOV x0, x21                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC6790: BL #0x27c1608              | X0 = sub_27C1608( ?? "JSDelayCall", ????);
            // 0x00BC6794: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
            // 0x00BC6798: LDR x8, [x19]              | X8 = typeof(System.Type);               
            // 0x00BC679C: LDR x9, [x9, #0xd20]       | X9 = 1152921504825909248;               
            // 0x00BC67A0: MOV x21, x0                | X21 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC67A4: LDR x22, [x9]              | X22 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
            // 0x00BC67A8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC67AC: TBZ w9, #0, #0xbc67c0      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_256;
            // 0x00BC67B0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC67B4: CBNZ w9, #0xbc67c0         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_256;
            // 0x00BC67B8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC67BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_256:
            // 0x00BC67C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC67C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC67C8: MOV x1, x22                | X1 = 1152921504825909248 (0x100000000D0EA000);//ML01
            // 0x00BC67CC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_97 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC67D0: MOV x22, x0                | X22 = val_97;//m1                       
            // 0x00BC67D4: CBNZ x21, #0xbc67dc        | if ("JSDelayCall" != null) goto label_257;
            if("JSDelayCall" != null)
            {
                goto label_257;
            }
            // 0x00BC67D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_97, ????);     
            label_257:
            // 0x00BC67DC: CBZ x22, #0xbc6800         | if (val_97 == null) goto label_259;     
            if(val_97 == null)
            {
                goto label_259;
            }
            // 0x00BC67E0: LDR x8, [x21]              | X8 = "JSDelayCall";                     
            // 0x00BC67E4: MOV x0, x22                | X0 = val_97;//m1                        
            // 0x00BC67E8: LDR x1, [x8, #0x30]        | 
            // 0x00BC67EC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_97, ????);     
            // 0x00BC67F0: CBNZ x0, #0xbc6800         | if (val_97 != null) goto label_259;     
            if(val_97 != null)
            {
                goto label_259;
            }
            // 0x00BC67F4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_97, ????);     
            // 0x00BC67F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC67FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_97, ????);     
            label_259:
            // 0x00BC6800: LDR w8, [x21, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC6804: CBNZ w8, #0xbc6814         | if ("JSDelayCall".__il2cppRuntimeField_18 != 0) goto label_260;
            // 0x00BC6808: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_97, ????);     
            // 0x00BC680C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6810: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_97, ????);     
            label_260:
            // 0x00BC6814: STR x22, [x21, #0x20]      | "JSDelayCall".__il2cppRuntimeField_20 = val_97;  //  dest_result_addr=1152921510054834208
            "JSDelayCall".__il2cppRuntimeField_20 = val_97;
            // 0x00BC6818: CBNZ x20, #0xbc6820        | if ( != 0) goto label_261;              
            if(null != 0)
            {
                goto label_261;
            }
            // 0x00BC681C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_97, ????);     
            label_261:
            // 0x00BC6820: LDR x1, [x26]              | X1 = "JSDelayCall";                     
            // 0x00BC6824: LDR x3, [x24]              | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.Reflection.MethodInfo>>::TryGetValue(System.String key, out System.Collections.Generic.List<System.Reflection.MethodInfo> value);
            // 0x00BC6828: SUB x2, x29, #0x58         | X2 = (1152921510055116896 - 88) = 1152921510055116808 (0x1000000144BE0008);
            // 0x00BC682C: MOV x0, x20                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x00BC6830: BL #0x23fe7ec              | X0 = TryGetValue(key:  "JSDelayCall", value: out  val_43);
            bool val_98 = TryGetValue(key:  "JSDelayCall", value: out  val_43);
            // 0x00BC6834: TBZ w0, #0, #0xbc6b54      | if (val_98 == false) goto label_282;    
            if(val_98 == false)
            {
                goto label_282;
            }
            // 0x00BC6838: LDUR x22, [x29, #-0x58]    | X22 = typeof(System.Collections.Generic.List<T>);
            // 0x00BC683C: MOV x26, x28               | X26 = 58347504 (0x37A4FF0);//ML01       
            // 0x00BC6840: CBNZ x22, #0xbc6848        | if ( != 0) goto label_263;              
            if(null != 0)
            {
                goto label_263;
            }
            // 0x00BC6844: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_98, ????);     
            label_263:
            // 0x00BC6848: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x00BC684C: LDR x8, [x8, #0x60]        | X8 = 1152921510054917520;               
            // 0x00BC6850: MOV x0, x22                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00BC6854: LDR x1, [x8]               | X1 = public List.Enumerator<T> System.Collections.Generic.List<System.Reflection.MethodInfo>::GetEnumerator();
            // 0x00BC6858: ADD x8, sp, #0x18          | X8 = (1152921510055116544 + 24) = 1152921510055116568 (0x1000000144BDFF18);
            // 0x00BC685C: BL #0x25ebf2c              | X0 = GetEnumerator();                   
            List.Enumerator<T> val_99 = GetEnumerator();
            // 0x00BC6860: ADRP x27, #0x3671000       | X27 = 57085952 (0x3671000);             
            // 0x00BC6864: ADRP x28, #0x360e000       | X28 = 56680448 (0x360E000);             
            // 0x00BC6868: LDR x8, [sp, #0x28]        | X8 = val_46;                             //  find_add[1152921510055104912]
            // 0x00BC686C: LDUR q0, [sp, #0x18]       | Q0 = val_47;                             //  find_add[1152921510055104912]
            // 0x00BC6870: LDR x27, [x27, #0x830]     | X27 = 1152921510054918544;              
            val_137 = 1152921510054918544;
            // 0x00BC6874: LDR x28, [x28, #0x9f0]     | X28 = 1152921510054919568;              
            // 0x00BC6878: STR x8, [sp, #0x60]        | stack[1152921510055116640] = val_46;     //  dest_result_addr=1152921510055116640
            // 0x00BC687C: STR q0, [sp, #0x50]        | stack[1152921510055116624] = val_47;     //  dest_result_addr=1152921510055116624
            label_277:
            // 0x00BC6880: LDR x1, [x27]              | X1 = public System.Boolean List.Enumerator<System.Reflection.MethodInfo>::MoveNext();
            // 0x00BC6884: ADD x0, sp, #0x50          | X0 = (1152921510055116544 + 80) = 1152921510055116624 (0x1000000144BDFF50);
            // 0x00BC6888: BL #0x133720c              | X0 = label_List_Enumerator<System_Object>_VerifyState_GL0133720C();
            // 0x00BC688C: AND w8, w0, #1             | W8 = (1152921510055116624 & 1) = 0 (0x00000000);
            // 0x00BC6890: TBZ w8, #0, #0xbc6ae4      | if ((0x0 & 0x1) == 0) goto label_264;   
            if((0 & 1) == 0)
            {
                goto label_264;
            }
            // 0x00BC6894: LDR x1, [x28]              | X1 = public System.Reflection.MethodInfo List.Enumerator<System.Reflection.MethodInfo>::get_Current();
            // 0x00BC6898: ADD x0, sp, #0x50          | X0 = (1152921510055116544 + 80) = 1152921510055116624 (0x1000000144BDFF50);
            // 0x00BC689C: BL #0x13372d8              | X0 = val_47.get_InitialType();          
            System.Type val_100 = val_47.InitialType;
            // 0x00BC68A0: MOV x22, x0                | X22 = val_100;//m1                      
            // 0x00BC68A4: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x00BC68A8: LDR x0, [x19]              | X0 = typeof(System.Type);               
            // 0x00BC68AC: LDR x8, [x8, #0xff0]       | X8 = 1152921504607645696;               
            // 0x00BC68B0: LDR x23, [x8]              | X23 = typeof(System.UInt32);            
            // 0x00BC68B4: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC68B8: TBZ w8, #0, #0xbc68c8      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_266;
            // 0x00BC68BC: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC68C0: CBNZ w8, #0xbc68c8         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_266;
            // 0x00BC68C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_266:
            // 0x00BC68C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC68CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC68D0: MOV x1, x23                | X1 = 1152921504607645696 (0x10000000000C3000);//ML01
            // 0x00BC68D4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_101 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC68D8: MOV x23, x0                | X23 = val_101;//m1                      
            val_119 = val_101;
            // 0x00BC68DC: LDR x24, [x26]             | X24 = "JSDelayCall";                    
            // 0x00BC68E0: MOV x0, x24                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC68E4: BL #0x277461c              | X0 = sub_277461C( ?? "JSDelayCall", ????);
            // 0x00BC68E8: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x00BC68EC: MOV x0, x24                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC68F0: BL #0x27c1608              | X0 = sub_27C1608( ?? "JSDelayCall", ????);
            // 0x00BC68F4: MOV x24, x0                | X24 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC68F8: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x00BC68FC: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x00BC6900: LDR x1, [x8]               | X1 = typeof(System.Single);             
            // 0x00BC6904: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC6908: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC690C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_102 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC6910: MOV x25, x0                | X25 = val_102;//m1                      
            // 0x00BC6914: CBNZ x24, #0xbc691c        | if ("JSDelayCall" != null) goto label_267;
            if("JSDelayCall" != null)
            {
                goto label_267;
            }
            // 0x00BC6918: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_102, ????);    
            label_267:
            // 0x00BC691C: CBZ x25, #0xbc6940         | if (val_102 == null) goto label_269;    
            if(val_102 == null)
            {
                goto label_269;
            }
            // 0x00BC6920: LDR x8, [x24]              | X8 = "JSDelayCall";                     
            // 0x00BC6924: LDR x1, [x8, #0x30]        | 
            // 0x00BC6928: MOV x0, x25                | X0 = val_102;//m1                       
            // 0x00BC692C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_102, ????);    
            // 0x00BC6930: CBNZ x0, #0xbc6940         | if (val_102 != null) goto label_269;    
            if(val_102 != null)
            {
                goto label_269;
            }
            // 0x00BC6934: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_102, ????);    
            // 0x00BC6938: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC693C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_102, ????);    
            label_269:
            // 0x00BC6940: LDR w8, [x24, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC6944: CBNZ w8, #0xbc6954         | if ("JSDelayCall".__il2cppRuntimeField_18 != 0) goto label_270;
            // 0x00BC6948: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_102, ????);    
            // 0x00BC694C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6950: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_102, ????);    
            label_270:
            // 0x00BC6954: STR x25, [x24, #0x20]      | "JSDelayCall".__il2cppRuntimeField_20 = val_102;  //  dest_result_addr=1152921510054834208
            "JSDelayCall".__il2cppRuntimeField_20 = val_102;
            // 0x00BC6958: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x00BC695C: LDR x8, [x8, #0xd40]       | X8 = 1152921504657965056;               
            // 0x00BC6960: LDR x1, [x8]               | X1 = typeof(System.Action<T>);          
            // 0x00BC6964: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC6968: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC696C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_103 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC6970: MOV x25, x0                | X25 = val_103;//m1                      
            // 0x00BC6974: CBZ x25, #0xbc6998         | if (val_103 == null) goto label_272;    
            if(val_103 == null)
            {
                goto label_272;
            }
            // 0x00BC6978: LDR x8, [x24]              | X8 = "JSDelayCall";                     
            // 0x00BC697C: LDR x1, [x8, #0x30]        | 
            // 0x00BC6980: MOV x0, x25                | X0 = val_103;//m1                       
            // 0x00BC6984: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_103, ????);    
            // 0x00BC6988: CBNZ x0, #0xbc6998         | if (val_103 != null) goto label_272;    
            if(val_103 != null)
            {
                goto label_272;
            }
            // 0x00BC698C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_103, ????);    
            // 0x00BC6990: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6994: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_103, ????);    
            label_272:
            // 0x00BC6998: LDR w8, [x24, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC699C: CMP w8, #1                 | STATE = COMPARE("JSDelayCall".__il2cppRuntimeField_18, 0x1)
            // 0x00BC69A0: B.HI #0xbc69b0             | if ("JSDelayCall".__il2cppRuntimeField_18 > 0x1) goto label_273;
            // 0x00BC69A4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_103, ????);    
            // 0x00BC69A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC69AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_103, ????);    
            label_273:
            // 0x00BC69B0: STR x25, [x24, #0x28]      | "JSDelayCall".__il2cppRuntimeField_28 = val_103;  //  dest_result_addr=1152921510054834216
            "JSDelayCall".__il2cppRuntimeField_28 = val_103;
            // 0x00BC69B4: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00BC69B8: LDR x8, [x8, #0xd20]       | X8 = 1152921504825909248;               
            // 0x00BC69BC: LDR x1, [x8]               | X1 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
            // 0x00BC69C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC69C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC69C8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_104 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC69CC: MOV x25, x0                | X25 = val_104;//m1                      
            val_120 = val_104;
            // 0x00BC69D0: CBZ x25, #0xbc69f4         | if (val_104 == null) goto label_275;    
            if(val_120 == null)
            {
                goto label_275;
            }
            // 0x00BC69D4: LDR x8, [x24]              | X8 = "JSDelayCall";                     
            // 0x00BC69D8: LDR x1, [x8, #0x30]        | 
            // 0x00BC69DC: MOV x0, x25                | X0 = val_104;//m1                       
            // 0x00BC69E0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_104, ????);    
            // 0x00BC69E4: CBNZ x0, #0xbc69f4         | if (val_104 != null) goto label_275;    
            if(val_120 != null)
            {
                goto label_275;
            }
            // 0x00BC69E8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_104, ????);    
            // 0x00BC69EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC69F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_104, ????);    
            label_275:
            // 0x00BC69F4: LDR w8, [x24, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC69F8: CMP w8, #2                 | STATE = COMPARE("JSDelayCall".__il2cppRuntimeField_18, 0x2)
            // 0x00BC69FC: B.HI #0xbc6a0c             | if ("JSDelayCall".__il2cppRuntimeField_18 > 0x2) goto label_276;
            // 0x00BC6A00: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_104, ????);    
            // 0x00BC6A04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6A08: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_104, ????);    
            label_276:
            // 0x00BC6A0C: STR x25, [x24, #0x30]      | "JSDelayCall".__il2cppRuntimeField_30 = val_104;  //  dest_result_addr=1152921510054834224
            "JSDelayCall".__il2cppRuntimeField_30 = val_120;
            // 0x00BC6A10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC6A14: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC6A18: MOV x1, x22                | X1 = val_100;//m1                       
            // 0x00BC6A1C: MOV x2, x21                | X2 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC6A20: MOV x3, x23                | X3 = val_101;//m1                       
            // 0x00BC6A24: MOV x4, x24                | X4 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC6A28: BL #0x28f47e4              | X0 = ILRuntime.Runtime.Extensions.MatchGenericParameters(m:  0, genericArguments:  val_100, returnType:  "JSDelayCall", parameters:  val_119);
            bool val_105 = ILRuntime.Runtime.Extensions.MatchGenericParameters(m:  0, genericArguments:  val_100, returnType:  "JSDelayCall", parameters:  val_119);
            // 0x00BC6A2C: TBZ w0, #0, #0xbc6880      | if (val_105 == false) goto label_277;   
            if(val_105 == false)
            {
                goto label_277;
            }
            // 0x00BC6A30: CBNZ x22, #0xbc6a38        | if (val_100 != null) goto label_278;    
            if(val_100 != null)
            {
                goto label_278;
            }
            // 0x00BC6A34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_105, ????);    
            label_278:
            // 0x00BC6A38: LDR x8, [x22]              | X8 = typeof(System.Type);               
            // 0x00BC6A3C: LDR x9, [x8, #0x3b0]       | X9 = typeof(System.Type).__il2cppRuntimeField_3B0;
            // 0x00BC6A40: LDR x2, [x8, #0x3b8]       | X2 = typeof(System.Type).__il2cppRuntimeField_3B8;
            // 0x00BC6A44: MOV x0, x22                | X0 = val_100;//m1                       
            // 0x00BC6A48: MOV x1, x21                | X1 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC6A4C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_3B0();
            // 0x00BC6A50: MOV x21, x0                | X21 = val_100;//m1                      
            // 0x00BC6A54: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x00BC6A58: LDR x8, [x8, #0xd10]       | X8 = 1152921504783044608;               
            // 0x00BC6A5C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC6A60: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC6A64: LDR x22, [x8, #0x80]       | X22 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache10;
            val_142 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache10;
            // 0x00BC6A68: CBNZ x22, #0xbc6ac4        | if (ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache10 != null) goto label_279;
            if(val_142 != null)
            {
                goto label_279;
            }
            // 0x00BC6A6C: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
            // 0x00BC6A70: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC6A74: LDR x8, [x8, #0x2d0]       | X8 = 1152921510055078288;               
            // 0x00BC6A78: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC6A7C: LDR x23, [x8]              | X23 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::JSDelayCall_16(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            val_119 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::JSDelayCall_16(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC6A80: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x00BC6A84: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC6A88: MOV x22, x0                | X22 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC6A8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6A90: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC6A94: MOV x0, x22                | X0 = 1152921504823939072 (0x100000000CF09000);//ML01
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_106 = null;
            // 0x00BC6A98: MOV x2, x23                | X2 = 1152921510055078288 (0x1000000144BD6990);//ML01
            // 0x00BC6A9C: BL #0x28e3b10              | .ctor(object:  0, method:  val_119);    
            val_106 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  val_119);
            // 0x00BC6AA0: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x00BC6AA4: LDR x8, [x8, #0xd10]       | X8 = 1152921504783044608;               
            // 0x00BC6AA8: MOV x9, x8                 | X9 = 57999632 (0x3750110);//ML01        
            // 0x00BC6AAC: LDR x8, [x9]               | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC6AB0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC6AB4: STR x22, [x8, #0x80]       | ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache10 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783048832
            ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache10 = null;
            // 0x00BC6AB8: LDR x8, [x9]               | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC6ABC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC6AC0: LDR x22, [x8, #0x80]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_142 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache10;
            label_279:
            // 0x00BC6AC4: LDR x8, [sp, #0x10]        | X8 = X1;                                
            // 0x00BC6AC8: CBNZ x8, #0xbc6ad0         | if (X1 != 0) goto label_280;            
            if(X1 != 0)
            {
                goto label_280;
            }
            // 0x00BC6ACC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  val_119), ????);
            label_280:
            // 0x00BC6AD0: LDR x0, [sp, #0x10]        | X0 = X1;                                
            // 0x00BC6AD4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC6AD8: MOV x1, x21                | X1 = val_100;//m1                       
            // 0x00BC6ADC: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC6AE0: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_100, func:  val_142);
            X1.RegisterCLRMethodRedirection(mi:  val_100, func:  val_142);
            label_264:
            // 0x00BC6AE4: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC6AE8: LDR x8, [x8, #0x568]       | X8 = 1152921510054942096;               
            // 0x00BC6AEC: ADD x0, sp, #0x50          | X0 = (1152921510055116544 + 80) = 1152921510055116624 (0x1000000144BDFF50);
            // 0x00BC6AF0: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<System.Reflection.MethodInfo>::Dispose();
            // 0x00BC6AF4: BL #0x13371f4              | val_47.Dispose();                       
            val_47.Dispose();
            // 0x00BC6AF8: MOV x28, x26               | X28 = 58347504 (0x37A4FF0);//ML01       
            val_133 = val_133;
            // 0x00BC6AFC: ADRP x26, #0x366b000       | X26 = 57061376 (0x366B000);             
            // 0x00BC6B00: ADRP x24, #0x35c9000       | X24 = 56397824 (0x35C9000);             
            // 0x00BC6B04: LDR x26, [x26, #0x340]     | X26 = (string**)(1152921510054834176)("JSDelayCall");
            val_135 = "JSDelayCall";
            // 0x00BC6B08: LDR x24, [x24, #0xcf8]     | X24 = 1152921510054905232;              
            val_131 = 1152921510054905232;
            // 0x00BC6B0C: B #0xbc6b54                |  goto label_282;                        
            goto label_282;
            label_316:
            // 0x00BC6B10: ADRP x24, #0x35c9000       | X24 = 56397824 (0x35C9000);             
            // 0x00BC6B14: LDR x24, [x24, #0xcf8]     | X24 = 1152921510054905232;              
            val_131 = 1152921510054905232;
            // 0x00BC6B18: MOV x28, x26               | X28 = 58347504 (0x37A4FF0);//ML01       
            val_133 = val_135;
            // 0x00BC6B1C: BL #0x981060               | X0 = sub_981060( ?? 0x1000000144BDFF50, ????);
            // 0x00BC6B20: LDR x21, [x0]              | X21 = val_47;                           
            // 0x00BC6B24: BL #0x980920               | X0 = sub_980920( ?? 0x1000000144BDFF50, ????);
            // 0x00BC6B28: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC6B2C: LDR x8, [x8, #0x568]       | X8 = 1152921510054942096;               
            // 0x00BC6B30: ADD x0, sp, #0x50          | X0 = (1152921510055116544 + 80) = 1152921510055116624 (0x1000000144BDFF50);
            // 0x00BC6B34: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<System.Reflection.MethodInfo>::Dispose();
            // 0x00BC6B38: BL #0x13371f4              | val_47.Dispose();                       
            val_47.Dispose();
            // 0x00BC6B3C: ADRP x26, #0x366b000       | X26 = 57061376 (0x366B000);             
            // 0x00BC6B40: LDR x26, [x26, #0x340]     | X26 = (string**)(1152921510054834176)("JSDelayCall");
            val_135 = "JSDelayCall";
            // 0x00BC6B44: CBZ x21, #0xbc6b54         | if (val_47 == 0) goto label_282;        
            if(val_47 == 0)
            {
                goto label_282;
            }
            // 0x00BC6B48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6B4C: MOV x0, x21                | X0 = val_47;//m1                        
            // 0x00BC6B50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_47, ????);     
            label_282:
            // 0x00BC6B54: LDR x21, [x28]             | X21 = "JSDelayCall";                    
            // 0x00BC6B58: MOV x0, x21                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC6B5C: BL #0x277461c              | X0 = sub_277461C( ?? "JSDelayCall", ????);
            // 0x00BC6B60: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BC6B64: MOV x0, x21                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC6B68: BL #0x27c1608              | X0 = sub_27C1608( ?? "JSDelayCall", ????);
            // 0x00BC6B6C: ADRP x9, #0x3611000        | X9 = 56692736 (0x3611000);              
            // 0x00BC6B70: LDR x8, [x19]              | X8 = typeof(System.Type);               
            // 0x00BC6B74: LDR x9, [x9, #0x9a8]       | X9 = 1152921504607113216;               
            // 0x00BC6B78: MOV x21, x0                | X21 = 1152921510054834176 (0x1000000144B9B000);//ML01
            val_143 = val_133;
            // 0x00BC6B7C: LDR x22, [x9]              | X22 = typeof(System.Int32);             
            // 0x00BC6B80: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC6B84: TBZ w9, #0, #0xbc6b98      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_284;
            // 0x00BC6B88: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC6B8C: CBNZ w9, #0xbc6b98         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_284;
            // 0x00BC6B90: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC6B94: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_284:
            // 0x00BC6B98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC6B9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC6BA0: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x00BC6BA4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_107 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC6BA8: MOV x22, x0                | X22 = val_107;//m1                      
            // 0x00BC6BAC: CBNZ x21, #0xbc6bb4        | if ("JSDelayCall" != null) goto label_285;
            if("JSDelayCall" != null)
            {
                goto label_285;
            }
            // 0x00BC6BB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_107, ????);    
            label_285:
            // 0x00BC6BB4: CBZ x22, #0xbc6bd8         | if (val_107 == null) goto label_287;    
            if(val_107 == null)
            {
                goto label_287;
            }
            // 0x00BC6BB8: LDR x8, [x21]              | X8 = "JSDelayCall";                     
            // 0x00BC6BBC: MOV x0, x22                | X0 = val_107;//m1                       
            // 0x00BC6BC0: LDR x1, [x8, #0x30]        | 
            // 0x00BC6BC4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_107, ????);    
            // 0x00BC6BC8: CBNZ x0, #0xbc6bd8         | if (val_107 != null) goto label_287;    
            if(val_107 != null)
            {
                goto label_287;
            }
            // 0x00BC6BCC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_107, ????);    
            // 0x00BC6BD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6BD4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_107, ????);    
            label_287:
            // 0x00BC6BD8: LDR w8, [x21, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC6BDC: CBNZ w8, #0xbc6bec         | if ("JSDelayCall".__il2cppRuntimeField_18 != 0) goto label_288;
            // 0x00BC6BE0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_107, ????);    
            // 0x00BC6BE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6BE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_107, ????);    
            label_288:
            // 0x00BC6BEC: STR x22, [x21, #0x20]      | "JSDelayCall".__il2cppRuntimeField_20 = val_107;  //  dest_result_addr=1152921510054834208
            "JSDelayCall".__il2cppRuntimeField_20 = val_107;
            // 0x00BC6BF0: CBNZ x20, #0xbc6bf8        | if ( != 0) goto label_289;              
            if(null != 0)
            {
                goto label_289;
            }
            // 0x00BC6BF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_107, ????);    
            label_289:
            // 0x00BC6BF8: LDR x1, [x26]              | X1 = "JSDelayCall";                     
            // 0x00BC6BFC: LDR x3, [x24]              | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.Reflection.MethodInfo>>::TryGetValue(System.String key, out System.Collections.Generic.List<System.Reflection.MethodInfo> value);
            // 0x00BC6C00: SUB x2, x29, #0x58         | X2 = (1152921510055116896 - 88) = 1152921510055116808 (0x1000000144BE0008);
            // 0x00BC6C04: MOV x0, x20                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x00BC6C08: BL #0x23fe7ec              | X0 = TryGetValue(key:  val_135 = "JSDelayCall", value: out  val_43);
            bool val_108 = TryGetValue(key:  val_135, value: out  val_43);
            // 0x00BC6C0C: TBZ w0, #0, #0xbc6ef0      | if (val_108 == false) goto label_311;   
            if(val_108 == false)
            {
                goto label_311;
            }
            // 0x00BC6C10: LDUR x20, [x29, #-0x58]    | X20 = typeof(System.Collections.Generic.List<T>);
            // 0x00BC6C14: CBNZ x20, #0xbc6c1c        | if ( != 0) goto label_291;              
            if(null != 0)
            {
                goto label_291;
            }
            // 0x00BC6C18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_108, ????);    
            label_291:
            // 0x00BC6C1C: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x00BC6C20: LDR x8, [x8, #0x60]        | X8 = 1152921510054917520;               
            // 0x00BC6C24: MOV x0, x20                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00BC6C28: LDR x1, [x8]               | X1 = public List.Enumerator<T> System.Collections.Generic.List<System.Reflection.MethodInfo>::GetEnumerator();
            // 0x00BC6C2C: ADD x8, sp, #0x18          | X8 = (1152921510055116544 + 24) = 1152921510055116568 (0x1000000144BDFF18);
            // 0x00BC6C30: BL #0x25ebf2c              | X0 = GetEnumerator();                   
            List.Enumerator<T> val_109 = GetEnumerator();
            // 0x00BC6C34: LDR x8, [sp, #0x28]        | X8 = val_46;                             //  find_add[1152921510055104912]
            // 0x00BC6C38: LDUR q0, [sp, #0x18]       | Q0 = val_47;                             //  find_add[1152921510055104912]
            // 0x00BC6C3C: ADRP x25, #0x3671000       | X25 = 57085952 (0x3671000);             
            // 0x00BC6C40: ADRP x26, #0x360e000       | X26 = 56680448 (0x360E000);             
            // 0x00BC6C44: ADRP x27, #0x365f000       | X27 = 57012224 (0x365F000);             
            // 0x00BC6C48: LDR x25, [x25, #0x830]     | X25 = 1152921510054918544;              
            val_120 = 1152921510054918544;
            // 0x00BC6C4C: LDR x26, [x26, #0x9f0]     | X26 = 1152921510054919568;              
            // 0x00BC6C50: STR x8, [sp, #0x40]        | stack[1152921510055116608] = val_46;     //  dest_result_addr=1152921510055116608
            // 0x00BC6C54: STR q0, [sp, #0x30]        | stack[1152921510055116592] = val_47;     //  dest_result_addr=1152921510055116592
            // 0x00BC6C58: LDR x27, [x27, #0xa88]     | X27 = 1152921504657965056;              
            val_137 = 1152921504657965056;
            label_305:
            // 0x00BC6C5C: LDR x1, [x25]              | X1 = public System.Boolean List.Enumerator<System.Reflection.MethodInfo>::MoveNext();
            // 0x00BC6C60: ADD x0, sp, #0x30          | X0 = (1152921510055116544 + 48) = 1152921510055116592 (0x1000000144BDFF30);
            // 0x00BC6C64: BL #0x133720c              | X0 = label_List_Enumerator<System_Object>_VerifyState_GL0133720C();
            // 0x00BC6C68: AND w8, w0, #1             | W8 = (1152921510055116592 & 1) = 0 (0x00000000);
            // 0x00BC6C6C: TBZ w8, #0, #0xbc6eac      | if ((0x0 & 0x1) == 0) goto label_292;   
            if((0 & 1) == 0)
            {
                goto label_292;
            }
            // 0x00BC6C70: LDR x1, [x26]              | X1 = public System.Reflection.MethodInfo List.Enumerator<System.Reflection.MethodInfo>::get_Current();
            // 0x00BC6C74: ADD x0, sp, #0x30          | X0 = (1152921510055116544 + 48) = 1152921510055116592 (0x1000000144BDFF30);
            // 0x00BC6C78: BL #0x13372d8              | X0 = val_47.get_InitialType();          
            System.Type val_110 = val_47.InitialType;
            // 0x00BC6C7C: MOV x20, x0                | X20 = val_110;//m1                      
            // 0x00BC6C80: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x00BC6C84: LDR x0, [x19]              | X0 = typeof(System.Type);               
            // 0x00BC6C88: LDR x8, [x8, #0xff0]       | X8 = 1152921504607645696;               
            // 0x00BC6C8C: LDR x22, [x8]              | X22 = typeof(System.UInt32);            
            // 0x00BC6C90: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC6C94: TBZ w8, #0, #0xbc6ca4      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_294;
            // 0x00BC6C98: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC6C9C: CBNZ w8, #0xbc6ca4         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_294;
            // 0x00BC6CA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_294:
            // 0x00BC6CA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC6CA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC6CAC: MOV x1, x22                | X1 = 1152921504607645696 (0x10000000000C3000);//ML01
            // 0x00BC6CB0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_111 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC6CB4: MOV x22, x0                | X22 = val_111;//m1                      
            // 0x00BC6CB8: LDR x23, [x28]             | X23 = "JSDelayCall";                    
            // 0x00BC6CBC: MOV x0, x23                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC6CC0: BL #0x277461c              | X0 = sub_277461C( ?? "JSDelayCall", ????);
            // 0x00BC6CC4: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x00BC6CC8: MOV x0, x23                | X0 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC6CCC: BL #0x27c1608              | X0 = sub_27C1608( ?? "JSDelayCall", ????);
            // 0x00BC6CD0: MOV x23, x0                | X23 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC6CD4: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x00BC6CD8: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x00BC6CDC: LDR x1, [x8]               | X1 = typeof(System.Single);             
            // 0x00BC6CE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC6CE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC6CE8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_112 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC6CEC: MOV x24, x0                | X24 = val_112;//m1                      
            // 0x00BC6CF0: CBNZ x23, #0xbc6cf8        | if ("JSDelayCall" != null) goto label_295;
            if("JSDelayCall" != null)
            {
                goto label_295;
            }
            // 0x00BC6CF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_112, ????);    
            label_295:
            // 0x00BC6CF8: CBZ x24, #0xbc6d1c         | if (val_112 == null) goto label_297;    
            if(val_112 == null)
            {
                goto label_297;
            }
            // 0x00BC6CFC: LDR x8, [x23]              | X8 = "JSDelayCall";                     
            // 0x00BC6D00: LDR x1, [x8, #0x30]        | 
            // 0x00BC6D04: MOV x0, x24                | X0 = val_112;//m1                       
            // 0x00BC6D08: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_112, ????);    
            // 0x00BC6D0C: CBNZ x0, #0xbc6d1c         | if (val_112 != null) goto label_297;    
            if(val_112 != null)
            {
                goto label_297;
            }
            // 0x00BC6D10: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_112, ????);    
            // 0x00BC6D14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6D18: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_112, ????);    
            label_297:
            // 0x00BC6D1C: LDR w8, [x23, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC6D20: CBNZ w8, #0xbc6d30         | if ("JSDelayCall".__il2cppRuntimeField_18 != 0) goto label_298;
            // 0x00BC6D24: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_112, ????);    
            // 0x00BC6D28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6D2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_112, ????);    
            label_298:
            // 0x00BC6D30: STR x24, [x23, #0x20]      | "JSDelayCall".__il2cppRuntimeField_20 = val_112;  //  dest_result_addr=1152921510054834208
            "JSDelayCall".__il2cppRuntimeField_20 = val_112;
            // 0x00BC6D34: LDR x1, [x27]              | X1 = typeof(System.Action<T>);          
            // 0x00BC6D38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC6D3C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC6D40: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_113 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC6D44: MOV x24, x0                | X24 = val_113;//m1                      
            // 0x00BC6D48: CBZ x24, #0xbc6d6c         | if (val_113 == null) goto label_300;    
            if(val_113 == null)
            {
                goto label_300;
            }
            // 0x00BC6D4C: LDR x8, [x23]              | X8 = "JSDelayCall";                     
            // 0x00BC6D50: LDR x1, [x8, #0x30]        | 
            // 0x00BC6D54: MOV x0, x24                | X0 = val_113;//m1                       
            // 0x00BC6D58: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_113, ????);    
            // 0x00BC6D5C: CBNZ x0, #0xbc6d6c         | if (val_113 != null) goto label_300;    
            if(val_113 != null)
            {
                goto label_300;
            }
            // 0x00BC6D60: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_113, ????);    
            // 0x00BC6D64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6D68: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_113, ????);    
            label_300:
            // 0x00BC6D6C: LDR w8, [x23, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC6D70: CMP w8, #1                 | STATE = COMPARE("JSDelayCall".__il2cppRuntimeField_18, 0x1)
            // 0x00BC6D74: B.HI #0xbc6d84             | if ("JSDelayCall".__il2cppRuntimeField_18 > 0x1) goto label_301;
            // 0x00BC6D78: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_113, ????);    
            // 0x00BC6D7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6D80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_113, ????);    
            label_301:
            // 0x00BC6D84: STR x24, [x23, #0x28]      | "JSDelayCall".__il2cppRuntimeField_28 = val_113;  //  dest_result_addr=1152921510054834216
            "JSDelayCall".__il2cppRuntimeField_28 = val_113;
            // 0x00BC6D88: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x00BC6D8C: LDR x8, [x8, #0x9a8]       | X8 = 1152921504607113216;               
            // 0x00BC6D90: LDR x1, [x8]               | X1 = typeof(System.Int32);              
            // 0x00BC6D94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC6D98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC6D9C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_114 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC6DA0: MOV x24, x0                | X24 = val_114;//m1                      
            // 0x00BC6DA4: CBZ x24, #0xbc6dc8         | if (val_114 == null) goto label_303;    
            if(val_114 == null)
            {
                goto label_303;
            }
            // 0x00BC6DA8: LDR x8, [x23]              | X8 = "JSDelayCall";                     
            // 0x00BC6DAC: LDR x1, [x8, #0x30]        | 
            // 0x00BC6DB0: MOV x0, x24                | X0 = val_114;//m1                       
            // 0x00BC6DB4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_114, ????);    
            // 0x00BC6DB8: CBNZ x0, #0xbc6dc8         | if (val_114 != null) goto label_303;    
            if(val_114 != null)
            {
                goto label_303;
            }
            // 0x00BC6DBC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_114, ????);    
            // 0x00BC6DC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6DC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_114, ????);    
            label_303:
            // 0x00BC6DC8: LDR w8, [x23, #0x18]       | W8 = "JSDelayCall".__il2cppRuntimeField_18;
            // 0x00BC6DCC: CMP w8, #2                 | STATE = COMPARE("JSDelayCall".__il2cppRuntimeField_18, 0x2)
            // 0x00BC6DD0: B.HI #0xbc6de0             | if ("JSDelayCall".__il2cppRuntimeField_18 > 0x2) goto label_304;
            // 0x00BC6DD4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_114, ????);    
            // 0x00BC6DD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6DDC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_114, ????);    
            label_304:
            // 0x00BC6DE0: STR x24, [x23, #0x30]      | "JSDelayCall".__il2cppRuntimeField_30 = val_114;  //  dest_result_addr=1152921510054834224
            "JSDelayCall".__il2cppRuntimeField_30 = val_114;
            // 0x00BC6DE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC6DE8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC6DEC: MOV x1, x20                | X1 = val_110;//m1                       
            // 0x00BC6DF0: MOV x2, x21                | X2 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC6DF4: MOV x3, x22                | X3 = val_111;//m1                       
            // 0x00BC6DF8: MOV x4, x23                | X4 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC6DFC: BL #0x28f47e4              | X0 = ILRuntime.Runtime.Extensions.MatchGenericParameters(m:  0, genericArguments:  val_110, returnType:  val_143, parameters:  val_111);
            bool val_115 = ILRuntime.Runtime.Extensions.MatchGenericParameters(m:  0, genericArguments:  val_110, returnType:  val_143, parameters:  val_111);
            // 0x00BC6E00: TBZ w0, #0, #0xbc6c5c      | if (val_115 == false) goto label_305;   
            if(val_115 == false)
            {
                goto label_305;
            }
            // 0x00BC6E04: ADRP x23, #0x362d000       | X23 = 56807424 (0x362D000);             
            // 0x00BC6E08: LDR x19, [sp, #0x10]       | X19 = X1;                               
            // 0x00BC6E0C: LDR x23, [x23, #0xd10]     | X23 = 1152921504783044608;              
            val_119 = 1152921504783044608;
            // 0x00BC6E10: CBNZ x20, #0xbc6e18        | if (val_110 != null) goto label_306;    
            if(val_110 != null)
            {
                goto label_306;
            }
            // 0x00BC6E14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_115, ????);    
            label_306:
            // 0x00BC6E18: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BC6E1C: LDR x9, [x8, #0x3b0]       | X9 = typeof(System.Type).__il2cppRuntimeField_3B0;
            // 0x00BC6E20: LDR x2, [x8, #0x3b8]       | X2 = typeof(System.Type).__il2cppRuntimeField_3B8;
            // 0x00BC6E24: MOV x0, x20                | X0 = val_110;//m1                       
            // 0x00BC6E28: MOV x1, x21                | X1 = 1152921510054834176 (0x1000000144B9B000);//ML01
            // 0x00BC6E2C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_3B0();
            // 0x00BC6E30: MOV x20, x0                | X20 = val_110;//m1                      
            // 0x00BC6E34: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC6E38: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC6E3C: LDR x21, [x8, #0x88]       | X21 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache11;
            val_143 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache11;
            // 0x00BC6E40: CBNZ x21, #0xbc6e90        | if (ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache11 != null) goto label_307;
            if(val_143 != null)
            {
                goto label_307;
            }
            // 0x00BC6E44: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x00BC6E48: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC6E4C: LDR x8, [x8, #0xc08]       | X8 = 1152921510055103888;               
            // 0x00BC6E50: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC6E54: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::JSDelayCall_17(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC6E58: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x00BC6E5C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC6E60: MOV x21, x0                | X21 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC6E64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6E68: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC6E6C: MOV x0, x21                | X0 = 1152921504823939072 (0x100000000CF09000);//ML01
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_116 = null;
            // 0x00BC6E70: MOV x2, x22                | X2 = 1152921510055103888 (0x1000000144BDCD90);//ML01
            // 0x00BC6E74: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::JSDelayCall_17(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_116 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::JSDelayCall_17(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC6E78: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC6E7C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC6E80: STR x21, [x8, #0x88]       | ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache11 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783048840
            ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache11 = null;
            // 0x00BC6E84: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.BehaviourUtil_Binding);
            // 0x00BC6E88: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC6E8C: LDR x21, [x8, #0x88]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_143 = ILRuntime.Runtime.Generated.BehaviourUtil_Binding.<>f__mg$cache11;
            label_307:
            // 0x00BC6E90: CBNZ x19, #0xbc6e98        | if (X1 != 0) goto label_308;            
            if(X1 != 0)
            {
                goto label_308;
            }
            // 0x00BC6E94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BehaviourUtil_Binding::JSDelayCall_17(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_308:
            // 0x00BC6E98: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC6E9C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC6EA0: MOV x1, x20                | X1 = val_110;//m1                       
            // 0x00BC6EA4: MOV x2, x21                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC6EA8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_110, func:  val_143);
            X1.RegisterCLRMethodRedirection(mi:  val_110, func:  val_143);
            label_292:
            // 0x00BC6EAC: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_134 = 0;
            // 0x00BC6EB0: ORR w20, wzr, #1           | W20 = 1(0x1);                           
            val_144 = 1;
            // 0x00BC6EB4: B #0xbc6ec8                |  goto label_309;                        
            goto label_309;
            label_317:
            // 0x00BC6EB8: BL #0x981060               | X0 = sub_981060( ?? X1, ????);          
            // 0x00BC6EBC: LDR x19, [x0]              | X19 = X1;                               
            val_134 = mem[X1];
            val_134 = X1;
            // 0x00BC6EC0: BL #0x980920               | X0 = sub_980920( ?? X1, ????);          
            // 0x00BC6EC4: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_144 = 0;
            label_309:
            // 0x00BC6EC8: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC6ECC: LDR x8, [x8, #0x568]       | X8 = 1152921510054942096;               
            // 0x00BC6ED0: ADD x0, sp, #0x30          | X0 = (1152921510055116544 + 48) = 1152921510055116592 (0x1000000144BDFF30);
            // 0x00BC6ED4: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<System.Reflection.MethodInfo>::Dispose();
            // 0x00BC6ED8: BL #0x13371f4              | val_47.Dispose();                       
            val_47.Dispose();
            // 0x00BC6EDC: TBNZ w20, #0, #0xbc6ef0    | if ((0x0 & 0x1) != 0) goto label_311;   
            if((val_144 & 1) != 0)
            {
                goto label_311;
            }
            // 0x00BC6EE0: CBZ x19, #0xbc6ef0         | if (X1 == 0) goto label_311;            
            if(val_134 == 0)
            {
                goto label_311;
            }
            // 0x00BC6EE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6EE8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC6EEC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
            label_311:
            // 0x00BC6EF0: SUB sp, x29, #0x50         | SP = (1152921510055116896 - 80) = 1152921510055116816 (0x1000000144BE0010);
            // 0x00BC6EF4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC6EF8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC6EFC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC6F00: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BC6F04: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BC6F08: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00BC6F0C: RET                        |  return;                                
            return;
            // 0x00BC6F10: B #0xbc573c                | 
            // 0x00BC6F14: B #0xbc5b10                | 
            // 0x00BC6F18: B #0xbc5eec                | 
            // 0x00BC6F1C: B #0xbc62c4                | 
            // 0x00BC6F20: B #0xbc6b10                | 
            // 0x00BC6F24: B #0xbc6eb8                | 
            // 0x00BC6F28: B #0xbc6744                | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC6F2C (12349228), len: 528  VirtAddr: 0x00BC6F2C RVA: 0x00BC6F2C token: 100663831 methodIndex: 29876 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Update_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00BC6F2C: STP x24, x23, [sp, #-0x40]! | stack[1152921510055581104] = ???;  stack[1152921510055581112] = ???;  //  dest_result_addr=1152921510055581104 |  dest_result_addr=1152921510055581112
            // 0x00BC6F30: STP x22, x21, [sp, #0x10]  | stack[1152921510055581120] = ???;  stack[1152921510055581128] = ???;  //  dest_result_addr=1152921510055581120 |  dest_result_addr=1152921510055581128
            // 0x00BC6F34: STP x20, x19, [sp, #0x20]  | stack[1152921510055581136] = ???;  stack[1152921510055581144] = ???;  //  dest_result_addr=1152921510055581136 |  dest_result_addr=1152921510055581144
            // 0x00BC6F38: STP x29, x30, [sp, #0x30]  | stack[1152921510055581152] = ???;  stack[1152921510055581160] = ???;  //  dest_result_addr=1152921510055581152 |  dest_result_addr=1152921510055581160
            // 0x00BC6F3C: ADD x29, sp, #0x30         | X29 = (1152921510055581104 + 48) = 1152921510055581152 (0x1000000144C515E0);
            // 0x00BC6F40: SUB sp, sp, #0x10          | SP = (1152921510055581104 - 16) = 1152921510055581088 (0x1000000144C515A0);
            // 0x00BC6F44: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BC6F48: LDRB w8, [x20, #0xb9f]     | W8 = (bool)static_value_03733B9F;       
            // 0x00BC6F4C: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BC6F50: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BC6F54: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BC6F58: TBNZ w8, #0, #0xbc6f74     | if (static_value_03733B9F == true) goto label_0;
            // 0x00BC6F5C: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x00BC6F60: LDR x8, [x8, #0xb0]        | X8 = 0x2B8F29C;                         
            // 0x00BC6F64: LDR w0, [x8]               | W0 = 0x1369;                            
            // 0x00BC6F68: BL #0x2782188              | X0 = sub_2782188( ?? 0x1369, ????);     
            // 0x00BC6F6C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC6F70: STRB w8, [x20, #0xb9f]     | static_value_03733B9F = true;            //  dest_result_addr=57883551
            label_0:
            // 0x00BC6F74: CBNZ x19, #0xbc6f7c        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC6F78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1369, ????);     
            label_1:
            // 0x00BC6F7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC6F80: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC6F84: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC6F88: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BC6F8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC6F90: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC6F94: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC6F98: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BC6F9C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC6FA0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BC6FA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC6FA8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC6FAC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC6FB0: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BC6FB4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC6FB8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC6FBC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC6FC0: ADRP x9, #0x35d1000        | X9 = 56430592 (0x35D1000);              
            // 0x00BC6FC4: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BC6FC8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC6FCC: LDR x9, [x9, #0xef0]       | X9 = 1152921504922660864;               
            // 0x00BC6FD0: LDR x24, [x9]              | X24 = typeof(BehaviourUtil);            
            // 0x00BC6FD4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC6FD8: TBZ w9, #0, #0xbc6fec      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BC6FDC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC6FE0: CBNZ w9, #0xbc6fec         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BC6FE4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC6FE8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BC6FEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC6FF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC6FF4: MOV x1, x24                | X1 = 1152921504922660864 (0x1000000012D2F000);//ML01
            // 0x00BC6FF8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC6FFC: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BC7000: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BC7004: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BC7008: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC700C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC7010: TBZ w9, #0, #0xbc7024      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BC7014: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC7018: CBNZ w9, #0xbc7024         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BC701C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC7020: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BC7024: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7028: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC702C: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BC7030: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC7034: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BC7038: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC703C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC7040: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC7044: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BC7048: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC704C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC7050: TBZ w9, #0, #0xbc7064      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BC7054: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC7058: CBNZ w9, #0xbc7064         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BC705C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC7060: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BC7064: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7068: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC706C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BC7070: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BC7074: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BC7078: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x00BC707C: CBZ x0, #0xbc70e0          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BC7080: ADRP x9, #0x365d000        | X9 = 57004032 (0x365D000);              
            // 0x00BC7084: LDR x9, [x9, #0x4b8]       | X9 = 1152921504922660864;               
            // 0x00BC7088: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC708C: LDR x1, [x9]               | X1 = typeof(BehaviourUtil);             
            // 0x00BC7090: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC7094: LDRB w9, [x1, #0x104]      | W9 = BehaviourUtil.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC7098: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BehaviourUtil.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC709C: B.LO #0xbc70b8             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BehaviourUtil.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BC70A0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BC70A4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BehaviourUtil.__il2cppRuntimeField_typeHie
            // 0x00BC70A8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BehaviourUtil.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC70AC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BehaviourUtil.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BehaviourUtil))
            // 0x00BC70B0: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x00BC70B4: B.EQ #0xbc70e0             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BehaviourUtil.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BC70B8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC70BC: ADD x8, sp, #8             | X8 = (1152921510055581088 + 8) = 1152921510055581096 (0x1000000144C515A8);
            // 0x00BC70C0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC70C4: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510055569168]
            // 0x00BC70C8: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BC70CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC70D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BC70D4: ADD x0, sp, #8             | X0 = (1152921510055581088 + 8) = 1152921510055581096 (0x1000000144C515A8);
            // 0x00BC70D8: BL #0x299a140              | 
            // 0x00BC70DC: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x00BC70E0: CBNZ x19, #0xbc70e8        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BC70E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144C515A8, ????);
            label_11:
            // 0x00BC70E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC70EC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC70F0: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BC70F4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC70F8: CBNZ x22, #0xbc7100        | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x00BC70FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BC7100: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC7104: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7108: BL #0xb8d640               | val_9.Update();                         
            val_9.Update();
            // 0x00BC710C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BC7110: SUB sp, x29, #0x30         | SP = (1152921510055581152 - 48) = 1152921510055581104 (0x1000000144C515B0);
            // 0x00BC7114: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC7118: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC711C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC7120: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BC7124: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BC7128: MOV x19, x0                | 
            // 0x00BC712C: ADD x0, sp, #8             | 
            // 0x00BC7130: BL #0x299a140              | 
            // 0x00BC7134: MOV x0, x19                | 
            // 0x00BC7138: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC713C (12349756), len: 616  VirtAddr: 0x00BC713C RVA: 0x00BC713C token: 100663832 methodIndex: 29877 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* StartCoroutine_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            // 0x00BC713C: STP x26, x25, [sp, #-0x50]! | stack[1152921510055754528] = ???;  stack[1152921510055754536] = ???;  //  dest_result_addr=1152921510055754528 |  dest_result_addr=1152921510055754536
            // 0x00BC7140: STP x24, x23, [sp, #0x10]  | stack[1152921510055754544] = ???;  stack[1152921510055754552] = ???;  //  dest_result_addr=1152921510055754544 |  dest_result_addr=1152921510055754552
            // 0x00BC7144: STP x22, x21, [sp, #0x20]  | stack[1152921510055754560] = ???;  stack[1152921510055754568] = ???;  //  dest_result_addr=1152921510055754560 |  dest_result_addr=1152921510055754568
            // 0x00BC7148: STP x20, x19, [sp, #0x30]  | stack[1152921510055754576] = ???;  stack[1152921510055754584] = ???;  //  dest_result_addr=1152921510055754576 |  dest_result_addr=1152921510055754584
            // 0x00BC714C: STP x29, x30, [sp, #0x40]  | stack[1152921510055754592] = ???;  stack[1152921510055754600] = ???;  //  dest_result_addr=1152921510055754592 |  dest_result_addr=1152921510055754600
            // 0x00BC7150: ADD x29, sp, #0x40         | X29 = (1152921510055754528 + 64) = 1152921510055754592 (0x1000000144C7BB60);
            // 0x00BC7154: SUB sp, sp, #0x10          | SP = (1152921510055754528 - 16) = 1152921510055754512 (0x1000000144C7BB10);
            // 0x00BC7158: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BC715C: LDRB w8, [x21, #0xba0]     | W8 = (bool)static_value_03733BA0;       
            // 0x00BC7160: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00BC7164: MOV x23, x2                | X23 = X2;//m1                           
            // 0x00BC7168: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BC716C: TBNZ w8, #0, #0xbc7188     | if (static_value_03733BA0 == true) goto label_0;
            // 0x00BC7170: ADRP x8, #0x3678000        | X8 = 57114624 (0x3678000);              
            // 0x00BC7174: LDR x8, [x8, #0xfb8]       | X8 = 0x2B8F288;                         
            // 0x00BC7178: LDR w0, [x8]               | W0 = 0x1364;                            
            // 0x00BC717C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1364, ????);     
            // 0x00BC7180: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC7184: STRB w8, [x21, #0xba0]     | static_value_03733BA0 = true;            //  dest_result_addr=57883552
            label_0:
            // 0x00BC7188: CBNZ x20, #0xbc7190        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC718C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1364, ????);     
            label_1:
            // 0x00BC7190: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC7194: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC7198: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC719C: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x00BC71A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC71A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC71A8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC71AC: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BC71B0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC71B4: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00BC71B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC71BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC71C0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC71C4: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BC71C8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC71CC: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00BC71D0: CBNZ x22, #0xbc71d8        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BC71D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BC71D8: LDR w22, [x22, #4]         | W22 = val_3 + 4;                        
            // 0x00BC71DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC71E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC71E4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC71E8: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BC71EC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC71F0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC71F4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC71F8: ADRP x9, #0x3672000        | X9 = 57090048 (0x3672000);              
            // 0x00BC71FC: MOV x23, x0                | X23 = val_4;//m1                        
            // 0x00BC7200: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC7204: LDR x9, [x9, #0x458]       | X9 = 1152921504608018432;               
            // 0x00BC7208: LDR x25, [x9]              | X25 = typeof(System.Collections.IEnumerator);
            // 0x00BC720C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC7210: TBZ w9, #0, #0xbc7224      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00BC7214: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC7218: CBNZ w9, #0xbc7224         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00BC721C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC7220: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x00BC7224: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7228: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC722C: MOV x1, x25                | X1 = 1152921504608018432 (0x100000000011E000);//ML01
            // 0x00BC7230: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC7234: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BC7238: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BC723C: MOV x25, x0                | X25 = val_5;//m1                        
            // 0x00BC7240: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC7244: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC7248: TBZ w9, #0, #0xbc725c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00BC724C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC7250: CBNZ w9, #0xbc725c         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00BC7254: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC7258: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x00BC725C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7260: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC7264: MOV x1, x23                | X1 = val_4;//m1                         
            // 0x00BC7268: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BC726C: MOV x3, x19                | X3 = X3;//m1                            
            // 0x00BC7270: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC7274: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC7278: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC727C: MOV x24, x0                | X24 = val_6;//m1                        
            // 0x00BC7280: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC7284: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC7288: TBZ w9, #0, #0xbc729c      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00BC728C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC7290: CBNZ w9, #0xbc729c         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00BC7294: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC7298: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x00BC729C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC72A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC72A4: MOV x1, x25                | X1 = val_5;//m1                         
            // 0x00BC72A8: MOV x2, x24                | X2 = val_6;//m1                         
            // 0x00BC72AC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x00BC72B0: MOV x25, x0                | X25 = val_7;//m1                        
            // 0x00BC72B4: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BC72B8: CBZ x25, #0xbc730c         | if (val_7 == null) goto label_10;       
            if(val_7 == null)
            {
                goto label_10;
            }
            // 0x00BC72BC: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
            // 0x00BC72C0: LDR x8, [x8, #0x358]       | X8 = 1152921504608018432;               
            // 0x00BC72C4: MOV x0, x25                | X0 = val_7;//m1                         
            // 0x00BC72C8: LDR x26, [x8]              | X26 = typeof(System.Collections.IEnumerator);
            // 0x00BC72CC: MOV x1, x26                | X1 = 1152921504608018432 (0x100000000011E000);//ML01
            // 0x00BC72D0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_7, ????);      
            // 0x00BC72D4: MOV x24, x0                | X24 = val_7;//m1                        
            val_11 = val_7;
            // 0x00BC72D8: CBNZ x24, #0xbc730c        | if (val_7 != null) goto label_10;       
            if(val_11 != null)
            {
                goto label_10;
            }
            // 0x00BC72DC: LDR x8, [x25]              | X8 = typeof(System.Object);             
            // 0x00BC72E0: MOV x1, x26                | X1 = 1152921504608018432 (0x100000000011E000);//ML01
            // 0x00BC72E4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC72E8: ADD x8, sp, #8             | X8 = (1152921510055754512 + 8) = 1152921510055754520 (0x1000000144C7BB18);
            // 0x00BC72EC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC72F0: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510055742608]
            // 0x00BC72F4: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BC72F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC72FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BC7300: ADD x0, sp, #8             | X0 = (1152921510055754512 + 8) = 1152921510055754520 (0x1000000144C7BB18);
            // 0x00BC7304: BL #0x299a140              | 
            // 0x00BC7308: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x00BC730C: CBNZ x20, #0xbc7314        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BC7310: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144C7BB18, ????);
            label_11:
            // 0x00BC7314: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC7318: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC731C: MOV x1, x23                | X1 = val_4;//m1                         
            // 0x00BC7320: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC7324: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00BC7328: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
            // 0x00BC732C: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
            // 0x00BC7330: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
            // 0x00BC7334: TBZ w8, #0, #0xbc7344      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x00BC7338: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00BC733C: CBNZ w8, #0xbc7344         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x00BC7340: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
            label_13:
            // 0x00BC7344: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7348: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC734C: MOV x1, x24                | X1 = 0 (0x0);//ML01                     
            // 0x00BC7350: MOV w2, w22                | W2 = val_3 + 4;//m1                     
            // 0x00BC7354: BL #0xb8d738               | X0 = BehaviourUtil.StartCoroutine(routine:  0, id:  0);
            UnityEngine.Coroutine val_9 = BehaviourUtil.StartCoroutine(routine:  0, id:  0);
            // 0x00BC7358: MOV x3, x0                 | X3 = val_9;//m1                         
            // 0x00BC735C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7360: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BC7364: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x00BC7368: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00BC736C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC7370: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_10 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x00BC7374: SUB sp, x29, #0x40         | SP = (1152921510055754592 - 64) = 1152921510055754528 (0x1000000144C7BB20);
            // 0x00BC7378: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC737C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC7380: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC7384: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BC7388: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BC738C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_10;
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BC7390: MOV x19, x0                | 
            // 0x00BC7394: ADD x0, sp, #8             | 
            // 0x00BC7398: BL #0x299a140              | 
            // 0x00BC739C: MOV x0, x19                | 
            // 0x00BC73A0: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC73A4 (12350372), len: 576  VirtAddr: 0x00BC73A4 RVA: 0x00BC73A4 token: 100663833 methodIndex: 29878 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* StartCoroutine_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_10;
            // 0x00BC73A4: STP x26, x25, [sp, #-0x50]! | stack[1152921510055932064] = ???;  stack[1152921510055932072] = ???;  //  dest_result_addr=1152921510055932064 |  dest_result_addr=1152921510055932072
            // 0x00BC73A8: STP x24, x23, [sp, #0x10]  | stack[1152921510055932080] = ???;  stack[1152921510055932088] = ???;  //  dest_result_addr=1152921510055932080 |  dest_result_addr=1152921510055932088
            // 0x00BC73AC: STP x22, x21, [sp, #0x20]  | stack[1152921510055932096] = ???;  stack[1152921510055932104] = ???;  //  dest_result_addr=1152921510055932096 |  dest_result_addr=1152921510055932104
            // 0x00BC73B0: STP x20, x19, [sp, #0x30]  | stack[1152921510055932112] = ???;  stack[1152921510055932120] = ???;  //  dest_result_addr=1152921510055932112 |  dest_result_addr=1152921510055932120
            // 0x00BC73B4: STP x29, x30, [sp, #0x40]  | stack[1152921510055932128] = ???;  stack[1152921510055932136] = ???;  //  dest_result_addr=1152921510055932128 |  dest_result_addr=1152921510055932136
            // 0x00BC73B8: ADD x29, sp, #0x40         | X29 = (1152921510055932064 + 64) = 1152921510055932128 (0x1000000144CA70E0);
            // 0x00BC73BC: SUB sp, sp, #0x10          | SP = (1152921510055932064 - 16) = 1152921510055932048 (0x1000000144CA7090);
            // 0x00BC73C0: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BC73C4: LDRB w8, [x21, #0xba1]     | W8 = (bool)static_value_03733BA1;       
            // 0x00BC73C8: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00BC73CC: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BC73D0: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BC73D4: TBNZ w8, #0, #0xbc73f0     | if (static_value_03733BA1 == true) goto label_0;
            // 0x00BC73D8: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
            // 0x00BC73DC: LDR x8, [x8, #0x4e0]       | X8 = 0x2B8F28C;                         
            // 0x00BC73E0: LDR w0, [x8]               | W0 = 0x1365;                            
            // 0x00BC73E4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1365, ????);     
            // 0x00BC73E8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC73EC: STRB w8, [x21, #0xba1]     | static_value_03733BA1 = true;            //  dest_result_addr=57883553
            label_0:
            // 0x00BC73F0: CBNZ x20, #0xbc73f8        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC73F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1365, ????);     
            label_1:
            // 0x00BC73F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC73FC: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC7400: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC7404: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BC7408: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC740C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC7410: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC7414: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BC7418: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC741C: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00BC7420: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7424: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC7428: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC742C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BC7430: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC7434: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC7438: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC743C: ADRP x9, #0x3672000        | X9 = 57090048 (0x3672000);              
            // 0x00BC7440: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00BC7444: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC7448: LDR x9, [x9, #0x458]       | X9 = 1152921504608018432;               
            // 0x00BC744C: LDR x24, [x9]              | X24 = typeof(System.Collections.IEnumerator);
            // 0x00BC7450: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC7454: TBZ w9, #0, #0xbc7468      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BC7458: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC745C: CBNZ w9, #0xbc7468         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BC7460: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC7464: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BC7468: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC746C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC7470: MOV x1, x24                | X1 = 1152921504608018432 (0x100000000011E000);//ML01
            // 0x00BC7474: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC7478: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BC747C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BC7480: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BC7484: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC7488: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC748C: TBZ w9, #0, #0xbc74a0      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BC7490: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC7494: CBNZ w9, #0xbc74a0         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BC7498: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC749C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BC74A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC74A4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC74A8: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00BC74AC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC74B0: MOV x3, x19                | X3 = X3;//m1                            
            // 0x00BC74B4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC74B8: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC74BC: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC74C0: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x00BC74C4: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC74C8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC74CC: TBZ w9, #0, #0xbc74e0      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BC74D0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC74D4: CBNZ w9, #0xbc74e0         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BC74D8: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC74DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BC74E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC74E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC74E8: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BC74EC: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x00BC74F0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BC74F4: MOV x24, x0                | X24 = val_6;//m1                        
            // 0x00BC74F8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x00BC74FC: CBZ x24, #0xbc7550         | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x00BC7500: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
            // 0x00BC7504: LDR x8, [x8, #0x358]       | X8 = 1152921504608018432;               
            // 0x00BC7508: MOV x0, x24                | X0 = val_6;//m1                         
            // 0x00BC750C: LDR x25, [x8]              | X25 = typeof(System.Collections.IEnumerator);
            // 0x00BC7510: MOV x1, x25                | X1 = 1152921504608018432 (0x100000000011E000);//ML01
            // 0x00BC7514: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
            // 0x00BC7518: MOV x23, x0                | X23 = val_6;//m1                        
            val_10 = val_6;
            // 0x00BC751C: CBNZ x23, #0xbc7550        | if (val_6 != null) goto label_9;        
            if(val_10 != null)
            {
                goto label_9;
            }
            // 0x00BC7520: LDR x8, [x24]              | X8 = typeof(System.Object);             
            // 0x00BC7524: MOV x1, x25                | X1 = 1152921504608018432 (0x100000000011E000);//ML01
            // 0x00BC7528: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC752C: ADD x8, sp, #8             | X8 = (1152921510055932048 + 8) = 1152921510055932056 (0x1000000144CA7098);
            // 0x00BC7530: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC7534: LDR x0, [sp, #8]           | X0 = val_7;                              //  find_add[1152921510055920144]
            // 0x00BC7538: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x00BC753C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC7540: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x00BC7544: ADD x0, sp, #8             | X0 = (1152921510055932048 + 8) = 1152921510055932056 (0x1000000144CA7098);
            // 0x00BC7548: BL #0x299a140              | 
            // 0x00BC754C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            label_9:
            // 0x00BC7550: CBNZ x20, #0xbc7558        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00BC7554: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144CA7098, ????);
            label_10:
            // 0x00BC7558: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC755C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC7560: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00BC7564: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC7568: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00BC756C: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
            // 0x00BC7570: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
            // 0x00BC7574: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
            // 0x00BC7578: TBZ w8, #0, #0xbc7588      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x00BC757C: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00BC7580: CBNZ w8, #0xbc7588         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x00BC7584: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
            label_12:
            // 0x00BC7588: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC758C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC7590: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x00BC7594: BL #0xb8d914               | X0 = BehaviourUtil.StartCoroutine(routine:  0);
            UnityEngine.Coroutine val_8 = BehaviourUtil.StartCoroutine(routine:  0);
            // 0x00BC7598: MOV x3, x0                 | X3 = val_8;//m1                         
            // 0x00BC759C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC75A0: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BC75A4: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x00BC75A8: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00BC75AC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC75B0: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x00BC75B4: SUB sp, x29, #0x40         | SP = (1152921510055932128 - 64) = 1152921510055932064 (0x1000000144CA70A0);
            // 0x00BC75B8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC75BC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC75C0: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC75C4: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BC75C8: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BC75CC: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_9;
            return val_9;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BC75D0: MOV x19, x0                | 
            // 0x00BC75D4: ADD x0, sp, #8             | 
            // 0x00BC75D8: BL #0x299a140              | 
            // 0x00BC75DC: MOV x0, x19                | 
            // 0x00BC75E0: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC75E4 (12350948), len: 580  VirtAddr: 0x00BC75E4 RVA: 0x00BC75E4 token: 100663834 methodIndex: 29879 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* StartCoroutine_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            // 0x00BC75E4: STP x24, x23, [sp, #-0x40]! | stack[1152921510056109616] = ???;  stack[1152921510056109624] = ???;  //  dest_result_addr=1152921510056109616 |  dest_result_addr=1152921510056109624
            // 0x00BC75E8: STP x22, x21, [sp, #0x10]  | stack[1152921510056109632] = ???;  stack[1152921510056109640] = ???;  //  dest_result_addr=1152921510056109632 |  dest_result_addr=1152921510056109640
            // 0x00BC75EC: STP x20, x19, [sp, #0x20]  | stack[1152921510056109648] = ???;  stack[1152921510056109656] = ???;  //  dest_result_addr=1152921510056109648 |  dest_result_addr=1152921510056109656
            // 0x00BC75F0: STP x29, x30, [sp, #0x30]  | stack[1152921510056109664] = ???;  stack[1152921510056109672] = ???;  //  dest_result_addr=1152921510056109664 |  dest_result_addr=1152921510056109672
            // 0x00BC75F4: ADD x29, sp, #0x30         | X29 = (1152921510056109616 + 48) = 1152921510056109664 (0x1000000144CD2660);
            // 0x00BC75F8: SUB sp, sp, #0x10          | SP = (1152921510056109616 - 16) = 1152921510056109600 (0x1000000144CD2620);
            // 0x00BC75FC: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BC7600: LDRB w8, [x21, #0xba2]     | W8 = (bool)static_value_03733BA2;       
            // 0x00BC7604: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00BC7608: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BC760C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BC7610: TBNZ w8, #0, #0xbc762c     | if (static_value_03733BA2 == true) goto label_0;
            // 0x00BC7614: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
            // 0x00BC7618: LDR x8, [x8]               | X8 = 0x2B8F290;                         
            // 0x00BC761C: LDR w0, [x8]               | W0 = 0x1366;                            
            // 0x00BC7620: BL #0x2782188              | X0 = sub_2782188( ?? 0x1366, ????);     
            // 0x00BC7624: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC7628: STRB w8, [x21, #0xba2]     | static_value_03733BA2 = true;            //  dest_result_addr=57883554
            label_0:
            // 0x00BC762C: CBNZ x20, #0xbc7634        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC7630: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1366, ????);     
            label_1:
            // 0x00BC7634: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC7638: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC763C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC7640: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BC7644: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7648: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC764C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC7650: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BC7654: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC7658: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00BC765C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7660: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC7664: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC7668: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BC766C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC7670: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC7674: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC7678: ADRP x9, #0x362b000        | X9 = 56799232 (0x362B000);              
            // 0x00BC767C: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00BC7680: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC7684: LDR x9, [x9, #0x7f0]       | X9 = 1152921504926228480;               
            // 0x00BC7688: LDR x24, [x9]              | X24 = typeof(Mihua.Utils.WaitForSeconds);
            // 0x00BC768C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC7690: TBZ w9, #0, #0xbc76a4      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BC7694: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC7698: CBNZ w9, #0xbc76a4         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BC769C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC76A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BC76A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC76A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC76AC: MOV x1, x24                | X1 = 1152921504926228480 (0x1000000013096000);//ML01
            // 0x00BC76B0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC76B4: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BC76B8: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BC76BC: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BC76C0: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC76C4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC76C8: TBZ w9, #0, #0xbc76dc      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BC76CC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC76D0: CBNZ w9, #0xbc76dc         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BC76D4: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC76D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BC76DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC76E0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC76E4: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00BC76E8: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC76EC: MOV x3, x19                | X3 = X3;//m1                            
            // 0x00BC76F0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC76F4: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC76F8: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC76FC: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x00BC7700: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC7704: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC7708: TBZ w9, #0, #0xbc771c      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BC770C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC7710: CBNZ w9, #0xbc771c         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BC7714: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC7718: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BC771C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7720: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC7724: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BC7728: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x00BC772C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BC7730: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BC7734: CBZ x0, #0xbc7798          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BC7738: ADRP x9, #0x3650000        | X9 = 56950784 (0x3650000);              
            // 0x00BC773C: LDR x9, [x9, #0x9e0]       | X9 = 1152921504926228480;               
            // 0x00BC7740: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC7744: LDR x1, [x9]               | X1 = typeof(Mihua.Utils.WaitForSeconds);
            // 0x00BC7748: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC774C: LDRB w9, [x1, #0x104]      | W9 = Mihua.Utils.WaitForSeconds.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC7750: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Mihua.Utils.WaitForSeconds.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC7754: B.LO #0xbc7770             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Mihua.Utils.WaitForSeconds.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BC7758: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BC775C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Mihua.Utils.WaitForSeconds.__il2cppRuntime
            // 0x00BC7760: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Mihua.Utils.WaitForSeconds.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC7764: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Mihua.Utils.WaitForSeconds.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Mihua.Utils.WaitForSeconds))
            // 0x00BC7768: MOV x23, x0                | X23 = val_6;//m1                        
            val_11 = val_6;
            // 0x00BC776C: B.EQ #0xbc7798             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Mihua.Utils.WaitForSeconds.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BC7770: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC7774: ADD x8, sp, #8             | X8 = (1152921510056109600 + 8) = 1152921510056109608 (0x1000000144CD2628);
            // 0x00BC7778: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC777C: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510056097680]
            // 0x00BC7780: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BC7784: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC7788: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BC778C: ADD x0, sp, #8             | X0 = (1152921510056109600 + 8) = 1152921510056109608 (0x1000000144CD2628);
            // 0x00BC7790: BL #0x299a140              | 
            // 0x00BC7794: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x00BC7798: CBNZ x20, #0xbc77a0        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BC779C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144CD2628, ????);
            label_11:
            // 0x00BC77A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC77A4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC77A8: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00BC77AC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC77B0: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00BC77B4: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
            // 0x00BC77B8: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
            // 0x00BC77BC: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
            // 0x00BC77C0: TBZ w8, #0, #0xbc77d0      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x00BC77C4: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00BC77C8: CBNZ w8, #0xbc77d0         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x00BC77CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
            label_13:
            // 0x00BC77D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC77D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC77D8: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x00BC77DC: BL #0xb8d98c               | X0 = BehaviourUtil.StartCoroutine(routine:  0);
            UnityEngine.Coroutine val_9 = BehaviourUtil.StartCoroutine(routine:  0);
            // 0x00BC77E0: MOV x3, x0                 | X3 = val_9;//m1                         
            // 0x00BC77E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC77E8: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BC77EC: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x00BC77F0: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00BC77F4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC77F8: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_10 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x00BC77FC: SUB sp, x29, #0x30         | SP = (1152921510056109664 - 48) = 1152921510056109616 (0x1000000144CD2630);
            // 0x00BC7800: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC7804: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC7808: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC780C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BC7810: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_10;
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BC7814: MOV x19, x0                | 
            // 0x00BC7818: ADD x0, sp, #8             | 
            // 0x00BC781C: BL #0x299a140              | 
            // 0x00BC7820: MOV x0, x19                | 
            // 0x00BC7824: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC7828 (12351528), len: 172  VirtAddr: 0x00BC7828 RVA: 0x00BC7828 token: 100663835 methodIndex: 29880 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* StopAllCoroutine_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            // 0x00BC7828: STP x22, x21, [sp, #-0x30]! | stack[1152921510056270784] = ???;  stack[1152921510056270792] = ???;  //  dest_result_addr=1152921510056270784 |  dest_result_addr=1152921510056270792
            // 0x00BC782C: STP x20, x19, [sp, #0x10]  | stack[1152921510056270800] = ???;  stack[1152921510056270808] = ???;  //  dest_result_addr=1152921510056270800 |  dest_result_addr=1152921510056270808
            // 0x00BC7830: STP x29, x30, [sp, #0x20]  | stack[1152921510056270816] = ???;  stack[1152921510056270824] = ???;  //  dest_result_addr=1152921510056270816 |  dest_result_addr=1152921510056270824
            // 0x00BC7834: ADD x29, sp, #0x20         | X29 = (1152921510056270784 + 32) = 1152921510056270816 (0x1000000144CF9BE0);
            // 0x00BC7838: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BC783C: LDRB w8, [x21, #0xba3]     | W8 = (bool)static_value_03733BA3;       
            // 0x00BC7840: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BC7844: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BC7848: TBNZ w8, #0, #0xbc7864     | if (static_value_03733BA3 == true) goto label_0;
            // 0x00BC784C: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x00BC7850: LDR x8, [x8, #0x520]       | X8 = 0x2B8F294;                         
            // 0x00BC7854: LDR w0, [x8]               | W0 = 0x1367;                            
            // 0x00BC7858: BL #0x2782188              | X0 = sub_2782188( ?? 0x1367, ????);     
            // 0x00BC785C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC7860: STRB w8, [x21, #0xba3]     | static_value_03733BA3 = true;            //  dest_result_addr=57883555
            label_0:
            // 0x00BC7864: CBNZ x20, #0xbc786c        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC7868: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1367, ????);     
            label_1:
            // 0x00BC786C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC7870: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC7874: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC7878: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC787C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00BC7880: MOV x1, x19                | X1 = X2;//m1                            
            // 0x00BC7884: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC7888: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            // 0x00BC788C: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00BC7890: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
            // 0x00BC7894: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BC7898: LDR x8, [x8]               | X8 = typeof(BehaviourUtil);             
            // 0x00BC789C: LDRB w9, [x8, #0x10a]      | W9 = BehaviourUtil.__il2cppRuntimeField_10A;
            // 0x00BC78A0: TBZ w9, #0, #0xbc78b4      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BC78A4: LDR w9, [x8, #0xbc]        | W9 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00BC78A8: CBNZ w9, #0xbc78b4         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BC78AC: MOV x0, x8                 | X0 = 1152921504922660864 (0x1000000012D2F000);//ML01
            // 0x00BC78B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
            label_3:
            // 0x00BC78B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC78B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC78BC: BL #0xb8da70               | BehaviourUtil.StopAllCoroutine();       
            BehaviourUtil.StopAllCoroutine();
            // 0x00BC78C0: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x00BC78C4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC78C8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC78CC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BC78D0: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC78D4 (12351700), len: 208  VirtAddr: 0x00BC78D4 RVA: 0x00BC78D4 token: 100663836 methodIndex: 29881 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* StopCoroutine_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            // 0x00BC78D4: STP x22, x21, [sp, #-0x30]! | stack[1152921510056415552] = ???;  stack[1152921510056415560] = ???;  //  dest_result_addr=1152921510056415552 |  dest_result_addr=1152921510056415560
            // 0x00BC78D8: STP x20, x19, [sp, #0x10]  | stack[1152921510056415568] = ???;  stack[1152921510056415576] = ???;  //  dest_result_addr=1152921510056415568 |  dest_result_addr=1152921510056415576
            // 0x00BC78DC: STP x29, x30, [sp, #0x20]  | stack[1152921510056415584] = ???;  stack[1152921510056415592] = ???;  //  dest_result_addr=1152921510056415584 |  dest_result_addr=1152921510056415592
            // 0x00BC78E0: ADD x29, sp, #0x20         | X29 = (1152921510056415552 + 32) = 1152921510056415584 (0x1000000144D1D160);
            // 0x00BC78E4: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BC78E8: LDRB w8, [x21, #0xba4]     | W8 = (bool)static_value_03733BA4;       
            // 0x00BC78EC: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BC78F0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BC78F4: TBNZ w8, #0, #0xbc7910     | if (static_value_03733BA4 == true) goto label_0;
            // 0x00BC78F8: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
            // 0x00BC78FC: LDR x8, [x8, #0xa0]        | X8 = 0x2B8F298;                         
            // 0x00BC7900: LDR w0, [x8]               | W0 = 0x1368;                            
            // 0x00BC7904: BL #0x2782188              | X0 = sub_2782188( ?? 0x1368, ????);     
            // 0x00BC7908: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC790C: STRB w8, [x21, #0xba4]     | static_value_03733BA4 = true;            //  dest_result_addr=57883556
            label_0:
            // 0x00BC7910: CBNZ x19, #0xbc7918        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC7914: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1368, ????);     
            label_1:
            // 0x00BC7918: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC791C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC7920: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC7924: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7928: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC792C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC7930: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC7934: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            // 0x00BC7938: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BC793C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7940: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC7944: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC7948: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC794C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            // 0x00BC7950: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x00BC7954: CBNZ x20, #0xbc795c        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BC7958: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BC795C: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00BC7960: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
            // 0x00BC7964: LDR w20, [x20, #4]         | W20 = val_3 + 4;                        
            // 0x00BC7968: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
            // 0x00BC796C: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
            // 0x00BC7970: TBZ w8, #0, #0xbc7980      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00BC7974: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00BC7978: CBNZ w8, #0xbc7980         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00BC797C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
            label_4:
            // 0x00BC7980: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7984: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC7988: MOV w1, w20                | W1 = val_3 + 4;//m1                     
            // 0x00BC798C: BL #0xb8dc54               | BehaviourUtil.StopCoroutine(id:  0);    
            BehaviourUtil.StopCoroutine(id:  0);
            // 0x00BC7990: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x00BC7994: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC7998: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC799C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BC79A0: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC79A4 (12351908), len: 252  VirtAddr: 0x00BC79A4 RVA: 0x00BC79A4 token: 100663837 methodIndex: 29882 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* SetPause_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            // 0x00BC79A4: STP x22, x21, [sp, #-0x30]! | stack[1152921510056560320] = ???;  stack[1152921510056560328] = ???;  //  dest_result_addr=1152921510056560320 |  dest_result_addr=1152921510056560328
            // 0x00BC79A8: STP x20, x19, [sp, #0x10]  | stack[1152921510056560336] = ???;  stack[1152921510056560344] = ???;  //  dest_result_addr=1152921510056560336 |  dest_result_addr=1152921510056560344
            // 0x00BC79AC: STP x29, x30, [sp, #0x20]  | stack[1152921510056560352] = ???;  stack[1152921510056560360] = ???;  //  dest_result_addr=1152921510056560352 |  dest_result_addr=1152921510056560360
            // 0x00BC79B0: ADD x29, sp, #0x20         | X29 = (1152921510056560320 + 32) = 1152921510056560352 (0x1000000144D406E0);
            // 0x00BC79B4: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BC79B8: LDRB w8, [x21, #0xba5]     | W8 = (bool)static_value_03733BA5;       
            // 0x00BC79BC: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BC79C0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BC79C4: TBNZ w8, #0, #0xbc79e0     | if (static_value_03733BA5 == true) goto label_0;
            // 0x00BC79C8: ADRP x8, #0x3675000        | X8 = 57102336 (0x3675000);              
            // 0x00BC79CC: LDR x8, [x8, #0xba8]       | X8 = 0x2B8F284;                         
            // 0x00BC79D0: LDR w0, [x8]               | W0 = 0x1363;                            
            // 0x00BC79D4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1363, ????);     
            // 0x00BC79D8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC79DC: STRB w8, [x21, #0xba5]     | static_value_03733BA5 = true;            //  dest_result_addr=57883557
            label_0:
            // 0x00BC79E0: CBNZ x19, #0xbc79e8        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC79E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1363, ????);     
            label_1:
            // 0x00BC79E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC79EC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC79F0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC79F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC79F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC79FC: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC7A00: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC7A04: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            // 0x00BC7A08: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BC7A0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7A10: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC7A14: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC7A18: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC7A1C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            // 0x00BC7A20: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BC7A24: CBNZ x21, #0xbc7a2c        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BC7A28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BC7A2C: LDR w21, [x21, #4]         | W21 = val_3 + 4;                        
            // 0x00BC7A30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7A34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC7A38: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC7A3C: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC7A40: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            // 0x00BC7A44: MOV x20, x0                | X20 = val_4;//m1                        
            // 0x00BC7A48: CBNZ x20, #0xbc7a50        | if (val_4 != 0) goto label_3;           
            if(val_4 != 0)
            {
                goto label_3;
            }
            // 0x00BC7A4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_3:
            // 0x00BC7A50: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00BC7A54: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
            // 0x00BC7A58: LDR w20, [x20, #4]         | W20 = val_4 + 4;                        
            // 0x00BC7A5C: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
            // 0x00BC7A60: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
            // 0x00BC7A64: TBZ w8, #0, #0xbc7a74      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BC7A68: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00BC7A6C: CBNZ w8, #0xbc7a74         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BC7A70: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
            label_5:
            // 0x00BC7A74: CMP w21, #1                | STATE = COMPARE(val_3 + 4, 0x1)         
            // 0x00BC7A78: CSET w2, eq                | W2 = val_3 + 4 == 0x1 ? 1 : 0;          
            var val_5 = ((val_3 + 4) == 1) ? 1 : 0;
            // 0x00BC7A7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7A80: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC7A84: MOV w1, w20                | W1 = val_4 + 4;//m1                     
            // 0x00BC7A88: BL #0xb8df68               | BehaviourUtil.SetPause(id:  0, isPause:  val_4 + 4);
            BehaviourUtil.SetPause(id:  0, isPause:  val_4 + 4);
            // 0x00BC7A8C: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x00BC7A90: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC7A94: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC7A98: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BC7A9C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC7AA0 (12352160), len: 632  VirtAddr: 0x00BC7AA0 RVA: 0x00BC7AA0 token: 100663838 methodIndex: 29883 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* JSDelayCall_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x00BC7AA0: STP d9, d8, [sp, #-0x60]!  | stack[1152921510056717328] = ???;  stack[1152921510056717336] = ???;  //  dest_result_addr=1152921510056717328 |  dest_result_addr=1152921510056717336
            // 0x00BC7AA4: STP x26, x25, [sp, #0x10]  | stack[1152921510056717344] = ???;  stack[1152921510056717352] = ???;  //  dest_result_addr=1152921510056717344 |  dest_result_addr=1152921510056717352
            // 0x00BC7AA8: STP x24, x23, [sp, #0x20]  | stack[1152921510056717360] = ???;  stack[1152921510056717368] = ???;  //  dest_result_addr=1152921510056717360 |  dest_result_addr=1152921510056717368
            // 0x00BC7AAC: STP x22, x21, [sp, #0x30]  | stack[1152921510056717376] = ???;  stack[1152921510056717384] = ???;  //  dest_result_addr=1152921510056717376 |  dest_result_addr=1152921510056717384
            // 0x00BC7AB0: STP x20, x19, [sp, #0x40]  | stack[1152921510056717392] = ???;  stack[1152921510056717400] = ???;  //  dest_result_addr=1152921510056717392 |  dest_result_addr=1152921510056717400
            // 0x00BC7AB4: STP x29, x30, [sp, #0x50]  | stack[1152921510056717408] = ???;  stack[1152921510056717416] = ???;  //  dest_result_addr=1152921510056717408 |  dest_result_addr=1152921510056717416
            // 0x00BC7AB8: ADD x29, sp, #0x50         | X29 = (1152921510056717328 + 80) = 1152921510056717408 (0x1000000144D66C60);
            // 0x00BC7ABC: SUB sp, sp, #0x10          | SP = (1152921510056717328 - 16) = 1152921510056717312 (0x1000000144D66C00);
            // 0x00BC7AC0: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BC7AC4: LDRB w8, [x19, #0xba6]     | W8 = (bool)static_value_03733BA6;       
            // 0x00BC7AC8: MOV x23, x3                | X23 = X3;//m1                           
            // 0x00BC7ACC: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BC7AD0: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BC7AD4: TBNZ w8, #0, #0xbc7af0     | if (static_value_03733BA6 == true) goto label_0;
            // 0x00BC7AD8: ADRP x8, #0x367e000        | X8 = 57139200 (0x367E000);              
            // 0x00BC7ADC: LDR x8, [x8, #0x40]        | X8 = 0x2B8F27C;                         
            // 0x00BC7AE0: LDR w0, [x8]               | W0 = 0x1361;                            
            // 0x00BC7AE4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1361, ????);     
            // 0x00BC7AE8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC7AEC: STRB w8, [x19, #0xba6]     | static_value_03733BA6 = true;            //  dest_result_addr=57883558
            label_0:
            // 0x00BC7AF0: CBNZ x21, #0xbc7af8        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC7AF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1361, ????);     
            label_1:
            // 0x00BC7AF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC7AFC: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC7B00: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC7B04: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x00BC7B08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7B0C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC7B10: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC7B14: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC7B18: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC7B1C: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BC7B20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7B24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC7B28: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC7B2C: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC7B30: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC7B34: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC7B38: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC7B3C: ADRP x9, #0x3618000        | X9 = 56721408 (0x3618000);              
            // 0x00BC7B40: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00BC7B44: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC7B48: LDR x9, [x9, #0x130]       | X9 = 1152921504687837184;               
            // 0x00BC7B4C: LDR x25, [x9]              | X25 = typeof(System.Action);            
            // 0x00BC7B50: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC7B54: TBZ w9, #0, #0xbc7b68      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BC7B58: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC7B5C: CBNZ w9, #0xbc7b68         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BC7B60: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC7B64: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BC7B68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7B6C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC7B70: MOV x1, x25                | X1 = 1152921504687837184 (0x1000000004D3D000);//ML01
            // 0x00BC7B74: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC7B78: ADRP x26, #0x366f000       | X26 = 57077760 (0x366F000);             
            // 0x00BC7B7C: LDR x26, [x26, #0x7a0]     | X26 = 1152921504826228736;              
            // 0x00BC7B80: MOV x25, x0                | X25 = val_4;//m1                        
            // 0x00BC7B84: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC7B88: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC7B8C: TBZ w9, #0, #0xbc7ba0      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BC7B90: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC7B94: CBNZ w9, #0xbc7ba0         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BC7B98: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC7B9C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BC7BA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7BA4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC7BA8: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00BC7BAC: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BC7BB0: MOV x3, x23                | X3 = X3;//m1                            
            // 0x00BC7BB4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC7BB8: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC7BBC: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC7BC0: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x00BC7BC4: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC7BC8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC7BCC: TBZ w9, #0, #0xbc7be0      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BC7BD0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC7BD4: CBNZ w9, #0xbc7be0         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BC7BD8: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC7BDC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BC7BE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7BE4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC7BE8: MOV x1, x25                | X1 = val_4;//m1                         
            // 0x00BC7BEC: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x00BC7BF0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BC7BF4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BC7BF8: CBZ x0, #0xbc7c40          | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x00BC7BFC: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x00BC7C00: LDR x8, [x8, #0xbe0]       | X8 = 1152921504687837184;               
            // 0x00BC7C04: LDR x1, [x8]               | X1 = typeof(System.Action);             
            // 0x00BC7C08: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC7C0C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.Action))
            // 0x00BC7C10: MOV x23, x0                | X23 = val_6;//m1                        
            val_11 = val_6;
            // 0x00BC7C14: B.EQ #0xbc7c40             | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x00BC7C18: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC7C1C: ADD x8, sp, #8             | X8 = (1152921510056717312 + 8) = 1152921510056717320 (0x1000000144D66C08);
            // 0x00BC7C20: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC7C24: LDR x0, [sp, #8]           | X0 = val_7;                              //  find_add[1152921510056705424]
            // 0x00BC7C28: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x00BC7C2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC7C30: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x00BC7C34: ADD x0, sp, #8             | X0 = (1152921510056717312 + 8) = 1152921510056717320 (0x1000000144D66C08);
            // 0x00BC7C38: BL #0x299a140              | 
            // 0x00BC7C3C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_9:
            // 0x00BC7C40: CBNZ x21, #0xbc7c48        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00BC7C44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144D66C08, ????);
            label_10:
            // 0x00BC7C48: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC7C4C: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC7C50: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00BC7C54: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC7C58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7C5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC7C60: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC7C64: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC7C68: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC7C6C: MOV x20, x0                | X20 = val_8;//m1                        
            // 0x00BC7C70: CBNZ x20, #0xbc7c78        | if (val_8 != 0) goto label_11;          
            if(val_8 != 0)
            {
                goto label_11;
            }
            // 0x00BC7C74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_11:
            // 0x00BC7C78: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00BC7C7C: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
            // 0x00BC7C80: LDR s8, [x20, #4]          | S8 = val_8 + 4;                         
            // 0x00BC7C84: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
            // 0x00BC7C88: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
            // 0x00BC7C8C: TBZ w8, #0, #0xbc7c9c      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x00BC7C90: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00BC7C94: CBNZ w8, #0xbc7c9c         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x00BC7C98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
            label_13:
            // 0x00BC7C9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7CA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC7CA4: MOV v0.16b, v8.16b         | V0 = val_8 + 4;//m1                     
            // 0x00BC7CA8: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x00BC7CAC: BL #0xb8e070               | X0 = BehaviourUtil.JSDelayCall(delaytime:  val_8 + 4, act:  0);
            uint val_9 = BehaviourUtil.JSDelayCall(delaytime:  val_8 + 4, act:  0);
            // 0x00BC7CB0: CBZ x19, #0xbc7cfc         | if (val_2 == 0) goto label_14;          
            if(val_2 == 0)
            {
                goto label_14;
            }
            // 0x00BC7CB4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC7CB8: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_9;         //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_9;
            // 0x00BC7CBC: LDR x0, [x26]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC7CC0: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x00BC7CC4: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BC7CC8: TBZ w9, #0, #0xbc7cd8      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_15;
            // 0x00BC7CCC: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BC7CD0: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BC7CD4: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_15:
            // 0x00BC7CD8: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_12 + val_2;
            // 0x00BC7CDC: SUB sp, x29, #0x50         | SP = (1152921510056717408 - 80) = 1152921510056717328 (0x1000000144D66C10);
            // 0x00BC7CE0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC7CE4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC7CE8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC7CEC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BC7CF0: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BC7CF4: LDP d9, d8, [sp], #0x60    | D9 = ; D8 = ;                            //  | 
            // 0x00BC7CF8: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            label_14:
            // 0x00BC7CFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x00BC7D00: BRK #0x1                   | 
            // 0x00BC7D04: MOV x19, x0                | X19 = val_9;//m1                        
            // 0x00BC7D08: ADD x0, sp, #8             | X0 = (1152921510056717312 + 8) = 1152921510056717320 (0x1000000144D66C08);
            // 0x00BC7D0C: BL #0x299a140              | 
            // 0x00BC7D10: MOV x0, x19                | X0 = val_9;//m1                         
            // 0x00BC7D14: BL #0x980800               | X0 = sub_980800( ?? val_9, ????);       
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC7D18 (12352792), len: 632  VirtAddr: 0x00BC7D18 RVA: 0x00BC7D18 token: 100663839 methodIndex: 29884 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* DelayCall_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x00BC7D18: STP d9, d8, [sp, #-0x60]!  | stack[1152921510056886672] = ???;  stack[1152921510056886680] = ???;  //  dest_result_addr=1152921510056886672 |  dest_result_addr=1152921510056886680
            // 0x00BC7D1C: STP x26, x25, [sp, #0x10]  | stack[1152921510056886688] = ???;  stack[1152921510056886696] = ???;  //  dest_result_addr=1152921510056886688 |  dest_result_addr=1152921510056886696
            // 0x00BC7D20: STP x24, x23, [sp, #0x20]  | stack[1152921510056886704] = ???;  stack[1152921510056886712] = ???;  //  dest_result_addr=1152921510056886704 |  dest_result_addr=1152921510056886712
            // 0x00BC7D24: STP x22, x21, [sp, #0x30]  | stack[1152921510056886720] = ???;  stack[1152921510056886728] = ???;  //  dest_result_addr=1152921510056886720 |  dest_result_addr=1152921510056886728
            // 0x00BC7D28: STP x20, x19, [sp, #0x40]  | stack[1152921510056886736] = ???;  stack[1152921510056886744] = ???;  //  dest_result_addr=1152921510056886736 |  dest_result_addr=1152921510056886744
            // 0x00BC7D2C: STP x29, x30, [sp, #0x50]  | stack[1152921510056886752] = ???;  stack[1152921510056886760] = ???;  //  dest_result_addr=1152921510056886752 |  dest_result_addr=1152921510056886760
            // 0x00BC7D30: ADD x29, sp, #0x50         | X29 = (1152921510056886672 + 80) = 1152921510056886752 (0x1000000144D901E0);
            // 0x00BC7D34: SUB sp, sp, #0x10          | SP = (1152921510056886672 - 16) = 1152921510056886656 (0x1000000144D90180);
            // 0x00BC7D38: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BC7D3C: LDRB w8, [x19, #0xba7]     | W8 = (bool)static_value_03733BA7;       
            // 0x00BC7D40: MOV x23, x3                | X23 = X3;//m1                           
            // 0x00BC7D44: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BC7D48: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BC7D4C: TBNZ w8, #0, #0xbc7d68     | if (static_value_03733BA7 == true) goto label_0;
            // 0x00BC7D50: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x00BC7D54: LDR x8, [x8, #0x4b0]       | X8 = 0x2B8F258;                         
            // 0x00BC7D58: LDR w0, [x8]               | W0 = 0x1358;                            
            // 0x00BC7D5C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1358, ????);     
            // 0x00BC7D60: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC7D64: STRB w8, [x19, #0xba7]     | static_value_03733BA7 = true;            //  dest_result_addr=57883559
            label_0:
            // 0x00BC7D68: CBNZ x21, #0xbc7d70        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC7D6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1358, ????);     
            label_1:
            // 0x00BC7D70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC7D74: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC7D78: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC7D7C: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x00BC7D80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7D84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC7D88: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC7D8C: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC7D90: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC7D94: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BC7D98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7D9C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC7DA0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC7DA4: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC7DA8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC7DAC: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC7DB0: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC7DB4: ADRP x9, #0x3618000        | X9 = 56721408 (0x3618000);              
            // 0x00BC7DB8: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00BC7DBC: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC7DC0: LDR x9, [x9, #0x130]       | X9 = 1152921504687837184;               
            // 0x00BC7DC4: LDR x25, [x9]              | X25 = typeof(System.Action);            
            // 0x00BC7DC8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC7DCC: TBZ w9, #0, #0xbc7de0      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BC7DD0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC7DD4: CBNZ w9, #0xbc7de0         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BC7DD8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC7DDC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BC7DE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7DE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC7DE8: MOV x1, x25                | X1 = 1152921504687837184 (0x1000000004D3D000);//ML01
            // 0x00BC7DEC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC7DF0: ADRP x26, #0x366f000       | X26 = 57077760 (0x366F000);             
            // 0x00BC7DF4: LDR x26, [x26, #0x7a0]     | X26 = 1152921504826228736;              
            // 0x00BC7DF8: MOV x25, x0                | X25 = val_4;//m1                        
            // 0x00BC7DFC: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC7E00: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC7E04: TBZ w9, #0, #0xbc7e18      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BC7E08: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC7E0C: CBNZ w9, #0xbc7e18         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BC7E10: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC7E14: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BC7E18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7E1C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC7E20: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00BC7E24: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BC7E28: MOV x3, x23                | X3 = X3;//m1                            
            // 0x00BC7E2C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC7E30: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC7E34: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC7E38: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x00BC7E3C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC7E40: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC7E44: TBZ w9, #0, #0xbc7e58      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BC7E48: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC7E4C: CBNZ w9, #0xbc7e58         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BC7E50: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC7E54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BC7E58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7E5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC7E60: MOV x1, x25                | X1 = val_4;//m1                         
            // 0x00BC7E64: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x00BC7E68: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BC7E6C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BC7E70: CBZ x0, #0xbc7eb8          | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x00BC7E74: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x00BC7E78: LDR x8, [x8, #0xbe0]       | X8 = 1152921504687837184;               
            // 0x00BC7E7C: LDR x1, [x8]               | X1 = typeof(System.Action);             
            // 0x00BC7E80: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC7E84: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.Action))
            // 0x00BC7E88: MOV x23, x0                | X23 = val_6;//m1                        
            val_11 = val_6;
            // 0x00BC7E8C: B.EQ #0xbc7eb8             | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x00BC7E90: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC7E94: ADD x8, sp, #8             | X8 = (1152921510056886656 + 8) = 1152921510056886664 (0x1000000144D90188);
            // 0x00BC7E98: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC7E9C: LDR x0, [sp, #8]           | X0 = val_7;                              //  find_add[1152921510056874768]
            // 0x00BC7EA0: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x00BC7EA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC7EA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x00BC7EAC: ADD x0, sp, #8             | X0 = (1152921510056886656 + 8) = 1152921510056886664 (0x1000000144D90188);
            // 0x00BC7EB0: BL #0x299a140              | 
            // 0x00BC7EB4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_9:
            // 0x00BC7EB8: CBNZ x21, #0xbc7ec0        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00BC7EBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144D90188, ????);
            label_10:
            // 0x00BC7EC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC7EC4: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC7EC8: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00BC7ECC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC7ED0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7ED4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC7ED8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC7EDC: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC7EE0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC7EE4: MOV x20, x0                | X20 = val_8;//m1                        
            // 0x00BC7EE8: CBNZ x20, #0xbc7ef0        | if (val_8 != 0) goto label_11;          
            if(val_8 != 0)
            {
                goto label_11;
            }
            // 0x00BC7EEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_11:
            // 0x00BC7EF0: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00BC7EF4: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
            // 0x00BC7EF8: LDR s8, [x20, #4]          | S8 = val_8 + 4;                         
            // 0x00BC7EFC: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
            // 0x00BC7F00: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
            // 0x00BC7F04: TBZ w8, #0, #0xbc7f14      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x00BC7F08: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00BC7F0C: CBNZ w8, #0xbc7f14         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x00BC7F10: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
            label_13:
            // 0x00BC7F14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7F18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC7F1C: MOV v0.16b, v8.16b         | V0 = val_8 + 4;//m1                     
            // 0x00BC7F20: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x00BC7F24: BL #0xb8e194               | X0 = BehaviourUtil.DelayCall(delaytime:  val_8 + 4, act:  0);
            uint val_9 = BehaviourUtil.DelayCall(delaytime:  val_8 + 4, act:  0);
            // 0x00BC7F28: CBZ x19, #0xbc7f74         | if (val_2 == 0) goto label_14;          
            if(val_2 == 0)
            {
                goto label_14;
            }
            // 0x00BC7F2C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC7F30: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_9;         //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_9;
            // 0x00BC7F34: LDR x0, [x26]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC7F38: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x00BC7F3C: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BC7F40: TBZ w9, #0, #0xbc7f50      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_15;
            // 0x00BC7F44: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BC7F48: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BC7F4C: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_15:
            // 0x00BC7F50: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_12 + val_2;
            // 0x00BC7F54: SUB sp, x29, #0x50         | SP = (1152921510056886752 - 80) = 1152921510056886672 (0x1000000144D90190);
            // 0x00BC7F58: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC7F5C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC7F60: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC7F64: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BC7F68: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BC7F6C: LDP d9, d8, [sp], #0x60    | D9 = ; D8 = ;                            //  | 
            // 0x00BC7F70: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            label_14:
            // 0x00BC7F74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x00BC7F78: BRK #0x1                   | 
            // 0x00BC7F7C: MOV x19, x0                | X19 = val_9;//m1                        
            // 0x00BC7F80: ADD x0, sp, #8             | X0 = (1152921510056886656 + 8) = 1152921510056886664 (0x1000000144D90188);
            // 0x00BC7F84: BL #0x299a140              | 
            // 0x00BC7F88: MOV x0, x19                | X0 = val_9;//m1                         
            // 0x00BC7F8C: BL #0x980800               | X0 = sub_980800( ?? val_9, ????);       
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC7F90 (12353424), len: 216  VirtAddr: 0x00BC7F90 RVA: 0x00BC7F90 token: 100663840 methodIndex: 29885 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* DelayPause_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            // 0x00BC7F90: STP d9, d8, [sp, #-0x40]!  | stack[1152921510057043760] = ???;  stack[1152921510057043768] = ???;  //  dest_result_addr=1152921510057043760 |  dest_result_addr=1152921510057043768
            // 0x00BC7F94: STP x22, x21, [sp, #0x10]  | stack[1152921510057043776] = ???;  stack[1152921510057043784] = ???;  //  dest_result_addr=1152921510057043776 |  dest_result_addr=1152921510057043784
            // 0x00BC7F98: STP x20, x19, [sp, #0x20]  | stack[1152921510057043792] = ???;  stack[1152921510057043800] = ???;  //  dest_result_addr=1152921510057043792 |  dest_result_addr=1152921510057043800
            // 0x00BC7F9C: STP x29, x30, [sp, #0x30]  | stack[1152921510057043808] = ???;  stack[1152921510057043816] = ???;  //  dest_result_addr=1152921510057043808 |  dest_result_addr=1152921510057043816
            // 0x00BC7FA0: ADD x29, sp, #0x30         | X29 = (1152921510057043760 + 48) = 1152921510057043808 (0x1000000144DB6760);
            // 0x00BC7FA4: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BC7FA8: LDRB w8, [x21, #0xba8]     | W8 = (bool)static_value_03733BA8;       
            // 0x00BC7FAC: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BC7FB0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BC7FB4: TBNZ w8, #0, #0xbc7fd0     | if (static_value_03733BA8 == true) goto label_0;
            // 0x00BC7FB8: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x00BC7FBC: LDR x8, [x8, #0xc80]       | X8 = 0x2B8F25C;                         
            // 0x00BC7FC0: LDR w0, [x8]               | W0 = 0x1359;                            
            // 0x00BC7FC4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1359, ????);     
            // 0x00BC7FC8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC7FCC: STRB w8, [x21, #0xba8]     | static_value_03733BA8 = true;            //  dest_result_addr=57883560
            label_0:
            // 0x00BC7FD0: CBNZ x19, #0xbc7fd8        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC7FD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1359, ????);     
            label_1:
            // 0x00BC7FD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC7FDC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC7FE0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC7FE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC7FE8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC7FEC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC7FF0: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC7FF4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            // 0x00BC7FF8: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BC7FFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8000: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC8004: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC8008: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC800C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            // 0x00BC8010: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x00BC8014: CBNZ x20, #0xbc801c        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BC8018: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BC801C: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00BC8020: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
            // 0x00BC8024: LDR s8, [x20, #4]          | S8 = val_3 + 4;                         
            // 0x00BC8028: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
            // 0x00BC802C: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
            // 0x00BC8030: TBZ w8, #0, #0xbc8040      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00BC8034: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00BC8038: CBNZ w8, #0xbc8040         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00BC803C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
            label_4:
            // 0x00BC8040: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8044: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC8048: MOV v0.16b, v8.16b         | V0 = val_3 + 4;//m1                     
            // 0x00BC804C: BL #0xb8e2d4               | BehaviourUtil.DelayPause(time:  val_3 + 4);
            BehaviourUtil.DelayPause(time:  val_3 + 4);
            // 0x00BC8050: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x00BC8054: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC8058: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC805C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC8060: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
            // 0x00BC8064: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC8068 (12353640), len: 572  VirtAddr: 0x00BC8068 RVA: 0x00BC8068 token: 100663841 methodIndex: 29886 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_GlobalCoroutine_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            // 0x00BC8068: STP x24, x23, [sp, #-0x40]! | stack[1152921510057192624] = ???;  stack[1152921510057192632] = ???;  //  dest_result_addr=1152921510057192624 |  dest_result_addr=1152921510057192632
            // 0x00BC806C: STP x22, x21, [sp, #0x10]  | stack[1152921510057192640] = ???;  stack[1152921510057192648] = ???;  //  dest_result_addr=1152921510057192640 |  dest_result_addr=1152921510057192648
            // 0x00BC8070: STP x20, x19, [sp, #0x20]  | stack[1152921510057192656] = ???;  stack[1152921510057192664] = ???;  //  dest_result_addr=1152921510057192656 |  dest_result_addr=1152921510057192664
            // 0x00BC8074: STP x29, x30, [sp, #0x30]  | stack[1152921510057192672] = ???;  stack[1152921510057192680] = ???;  //  dest_result_addr=1152921510057192672 |  dest_result_addr=1152921510057192680
            // 0x00BC8078: ADD x29, sp, #0x30         | X29 = (1152921510057192624 + 48) = 1152921510057192672 (0x1000000144DDACE0);
            // 0x00BC807C: SUB sp, sp, #0x10          | SP = (1152921510057192624 - 16) = 1152921510057192608 (0x1000000144DDACA0);
            // 0x00BC8080: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00BC8084: LDRB w8, [x22, #0xba9]     | W8 = (bool)static_value_03733BA9;       
            // 0x00BC8088: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00BC808C: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BC8090: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BC8094: TBNZ w8, #0, #0xbc80b0     | if (static_value_03733BA9 == true) goto label_0;
            // 0x00BC8098: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
            // 0x00BC809C: LDR x8, [x8, #0x448]       | X8 = 0x2B8F260;                         
            // 0x00BC80A0: LDR w0, [x8]               | W0 = 0x135A;                            
            // 0x00BC80A4: BL #0x2782188              | X0 = sub_2782188( ?? 0x135A, ????);     
            // 0x00BC80A8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC80AC: STRB w8, [x22, #0xba9]     | static_value_03733BA9 = true;            //  dest_result_addr=57883561
            label_0:
            // 0x00BC80B0: CBNZ x21, #0xbc80b8        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC80B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x135A, ????);     
            label_1:
            // 0x00BC80B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC80BC: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC80C0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC80C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC80C8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00BC80CC: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC80D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC80D4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC80D8: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00BC80DC: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
            // 0x00BC80E0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BC80E4: LDR x8, [x8]               | X8 = typeof(BehaviourUtil);             
            // 0x00BC80E8: LDRB w9, [x8, #0x10a]      | W9 = BehaviourUtil.__il2cppRuntimeField_10A;
            // 0x00BC80EC: TBZ w9, #0, #0xbc8100      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BC80F0: LDR w9, [x8, #0xbc]        | W9 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00BC80F4: CBNZ w9, #0xbc8100         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BC80F8: MOV x0, x8                 | X0 = 1152921504922660864 (0x1000000012D2F000);//ML01
            // 0x00BC80FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
            label_3:
            // 0x00BC8100: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8104: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC8108: BL #0xb8d7f0               | X0 = BehaviourUtil.get_GlobalCoroutine();
            UnityEngine.MonoBehaviour val_3 = BehaviourUtil.GlobalCoroutine;
            // 0x00BC810C: ADRP x23, #0x365d000       | X23 = 57004032 (0x365D000);             
            // 0x00BC8110: LDR x23, [x23, #0xa58]     | X23 = 1152921504824418304;              
            // 0x00BC8114: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00BC8118: LDR x1, [x23]              | X1 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_8 = null;
            // 0x00BC811C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x00BC8120: CBZ x0, #0xbc81b4          | if (val_3 == null) goto label_4;        
            if(val_3 == null)
            {
                goto label_4;
            }
            // 0x00BC8124: CBZ x22, #0xbc81e4         | if (val_3 == null) goto label_5;        
            if(val_3 == null)
            {
                goto label_5;
            }
            // 0x00BC8128: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            // 0x00BC812C: MOV x0, x22                | X0 = val_3;//m1                         
            // 0x00BC8130: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x00BC8134: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x00BC8138: CBNZ x0, #0xbc816c         | if (val_3 != null) goto label_6;        
            if(val_3 != null)
            {
                goto label_6;
            }
            // 0x00BC813C: LDR x8, [x22]              | X8 = typeof(UnityEngine.MonoBehaviour); 
            // 0x00BC8140: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x00BC8144: LDR x0, [x8, #0x30]        | X0 = UnityEngine.MonoBehaviour.__il2cppRuntimeField_element_class;
            // 0x00BC8148: MOV x8, sp                 | X8 = 1152921510057192608 (0x1000000144DDACA0);//ML01
            // 0x00BC814C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? UnityEngine.MonoBehaviour.__il2cppRuntimeField_element_class, ????);
            // 0x00BC8150: LDR x0, [sp]               | X0 = val_4;                              //  find_add[1152921510057180688]
            // 0x00BC8154: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BC8158: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC815C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BC8160: MOV x0, sp                 | X0 = 1152921510057192608 (0x1000000144DDACA0);//ML01
            // 0x00BC8164: BL #0x299a140              | 
            // 0x00BC8168: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144DDACA0, ????);
            label_6:
            // 0x00BC816C: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_9 = null;
            // 0x00BC8170: MOV x0, x22                | X0 = val_3;//m1                         
            // 0x00BC8174: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_8 = val_9;
            // 0x00BC8178: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x00BC817C: MOV x23, x0                | X23 = val_3;//m1                        
            val_10 = val_3;
            // 0x00BC8180: CBNZ x23, #0xbc81f0        | if (val_3 != null) goto label_7;        
            if(val_10 != null)
            {
                goto label_7;
            }
            // 0x00BC8184: LDR x8, [x22]              | X8 = typeof(UnityEngine.MonoBehaviour); 
            // 0x00BC8188: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x00BC818C: LDR x0, [x8, #0x30]        | X0 = UnityEngine.MonoBehaviour.__il2cppRuntimeField_element_class;
            // 0x00BC8190: ADD x8, sp, #8             | X8 = (1152921510057192608 + 8) = 1152921510057192616 (0x1000000144DDACA8);
            // 0x00BC8194: BL #0x27d96d4              | X0 = sub_27D96D4( ?? UnityEngine.MonoBehaviour.__il2cppRuntimeField_element_class, ????);
            // 0x00BC8198: LDR x0, [sp, #8]           | X0 = val_5;                              //  find_add[1152921510057180688]
            // 0x00BC819C: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BC81A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_8 = 0;
            // 0x00BC81A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BC81A8: ADD x0, sp, #8             | X0 = (1152921510057192608 + 8) = 1152921510057192616 (0x1000000144DDACA8);
            // 0x00BC81AC: BL #0x299a140              | 
            // 0x00BC81B0: B #0xbc81ec                |  goto label_8;                          
            goto label_8;
            label_4:
            // 0x00BC81B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC81B8: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BC81BC: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00BC81C0: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00BC81C4: MOV x3, x22                | X3 = val_3;//m1                         
            // 0x00BC81C8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC81CC: SUB sp, x29, #0x30         | SP = (1152921510057192672 - 48) = 1152921510057192624 (0x1000000144DDACB0);
            // 0x00BC81D0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC81D4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC81D8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC81DC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BC81E0: B #0x1f657ec               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
            label_5:
            // 0x00BC81E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            // 0x00BC81E8: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_9 = null;
            label_8:
            // 0x00BC81EC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            label_7:
            // 0x00BC81F0: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x00BC81F4: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x00BC81F8: CBZ x9, #0xbc8224          | if (mem[282584257676929] == 0) goto label_9;
            if(mem[282584257676929] == 0)
            {
                goto label_9;
            }
            // 0x00BC81FC: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_7 = mem[282584257676823];
            // 0x00BC8200: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_8 = 0;
            // 0x00BC8204: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_7 = val_7 + 8;
            label_11:
            // 0x00BC8208: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x00BC820C: CMP x12, x21               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType))
            // 0x00BC8210: B.EQ #0xbc8238             | if ((mem[282584257676823] + 8) + -8 == val_9) goto label_10;
            if(((mem[282584257676823] + 8) + -8) == val_9)
            {
                goto label_10;
            }
            // 0x00BC8214: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x00BC8218: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_7 = val_7 + 16;
            // 0x00BC821C: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x00BC8220: B.LO #0xbc8208             | if (0 < mem[282584257676929]) goto label_11;
            if(val_8 < mem[282584257676929])
            {
                goto label_11;
            }
            label_9:
            // 0x00BC8224: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00BC8228: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_11 = val_10;
            // 0x00BC822C: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_8 = val_9;
            // 0x00BC8230: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x00BC8234: B #0xbc8244                |  goto label_12;                         
            goto label_12;
            label_10:
            // 0x00BC8238: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            // 0x00BC823C: ADD x8, x8, x9, lsl #4     | X8 = (val_10 + ((mem[282584257676823] + 8)) << 4);
            val_10 = val_10 + (((mem[282584257676823] + 8)) << 4);
            // 0x00BC8240: ADD x0, x8, #0x110         | X0 = ((val_10 + ((mem[282584257676823] + 8)) << 4) + 272);
            val_11 = val_10 + 272;
            label_12:
            // 0x00BC8244: LDP x8, x1, [x0]           | X8 = ((val_10 + ((mem[282584257676823] + 8)) << 4) + 272); X1 = ((val_10 + ((mem[282584257676823] + 8)) << 4) + 272) + 8; //  | 
            // 0x00BC8248: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x00BC824C: BLR x8                     | X0 = ((val_10 + ((mem[282584257676823] + 8)) << 4) + 272)();
            // 0x00BC8250: MOV x3, x0                 | X3 = 0 (0x0);//ML01                     
            // 0x00BC8254: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8258: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BC825C: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00BC8260: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00BC8264: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC8268: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_6 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x00BC826C: SUB sp, x29, #0x30         | SP = (1152921510057192672 - 48) = 1152921510057192624 (0x1000000144DDACB0);
            // 0x00BC8270: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC8274: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC8278: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC827C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BC8280: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_6;
            return val_6;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BC8284: MOV x19, x0                | 
            // 0x00BC8288: MOV x0, sp                 | 
            // 0x00BC828C: B #0xbc8298                | 
            // 0x00BC8290: MOV x19, x0                | 
            // 0x00BC8294: ADD x0, sp, #8             | 
            label_13:
            // 0x00BC8298: BL #0x299a140              | 
            // 0x00BC829C: MOV x0, x19                | 
            // 0x00BC82A0: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC82A4 (12354212), len: 860  VirtAddr: 0x00BC82A4 RVA: 0x00BC82A4 token: 100663842 methodIndex: 29887 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* DelayCall_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_12;
            //  | 
            var val_16;
            //  | 
            CEvent.ZEvent val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            var val_20;
            // 0x00BC82A4: STP d9, d8, [sp, #-0x70]!  | stack[1152921510057367040] = ???;  stack[1152921510057367048] = ???;  //  dest_result_addr=1152921510057367040 |  dest_result_addr=1152921510057367048
            // 0x00BC82A8: STP x28, x27, [sp, #0x10]  | stack[1152921510057367056] = ???;  stack[1152921510057367064] = ???;  //  dest_result_addr=1152921510057367056 |  dest_result_addr=1152921510057367064
            // 0x00BC82AC: STP x26, x25, [sp, #0x20]  | stack[1152921510057367072] = ???;  stack[1152921510057367080] = ???;  //  dest_result_addr=1152921510057367072 |  dest_result_addr=1152921510057367080
            // 0x00BC82B0: STP x24, x23, [sp, #0x30]  | stack[1152921510057367088] = ???;  stack[1152921510057367096] = ???;  //  dest_result_addr=1152921510057367088 |  dest_result_addr=1152921510057367096
            // 0x00BC82B4: STP x22, x21, [sp, #0x40]  | stack[1152921510057367104] = ???;  stack[1152921510057367112] = ???;  //  dest_result_addr=1152921510057367104 |  dest_result_addr=1152921510057367112
            // 0x00BC82B8: STP x20, x19, [sp, #0x50]  | stack[1152921510057367120] = ???;  stack[1152921510057367128] = ???;  //  dest_result_addr=1152921510057367120 |  dest_result_addr=1152921510057367128
            // 0x00BC82BC: STP x29, x30, [sp, #0x60]  | stack[1152921510057367136] = ???;  stack[1152921510057367144] = ???;  //  dest_result_addr=1152921510057367136 |  dest_result_addr=1152921510057367144
            // 0x00BC82C0: ADD x29, sp, #0x60         | X29 = (1152921510057367040 + 96) = 1152921510057367136 (0x1000000144E05660);
            // 0x00BC82C4: SUB sp, sp, #0x10          | SP = (1152921510057367040 - 16) = 1152921510057367024 (0x1000000144E055F0);
            // 0x00BC82C8: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BC82CC: LDRB w8, [x19, #0xbaa]     | W8 = (bool)static_value_03733BAA;       
            // 0x00BC82D0: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BC82D4: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BC82D8: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BC82DC: TBNZ w8, #0, #0xbc82f8     | if (static_value_03733BAA == true) goto label_0;
            // 0x00BC82E0: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
            // 0x00BC82E4: LDR x8, [x8, #0x148]       | X8 = 0x2B8F254;                         
            // 0x00BC82E8: LDR w0, [x8]               | W0 = 0x1357;                            
            // 0x00BC82EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1357, ????);     
            // 0x00BC82F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC82F4: STRB w8, [x19, #0xbaa]     | static_value_03733BAA = true;            //  dest_result_addr=57883562
            label_0:
            // 0x00BC82F8: CBNZ x21, #0xbc8300        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC82FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1357, ????);     
            label_1:
            // 0x00BC8300: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC8304: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC8308: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC830C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BC8310: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8314: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC8318: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BC831C: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC8320: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC8324: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BC8328: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC832C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC8330: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC8334: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC8338: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC833C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC8340: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC8344: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x00BC8348: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00BC834C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC8350: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x00BC8354: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x00BC8358: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC835C: TBZ w9, #0, #0xbc8370      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BC8360: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC8364: CBNZ w9, #0xbc8370         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BC8368: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC836C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BC8370: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8374: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC8378: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BC837C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC8380: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
            // 0x00BC8384: LDR x27, [x27, #0x7a0]     | X27 = 1152921504826228736;              
            // 0x00BC8388: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BC838C: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC8390: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC8394: TBZ w9, #0, #0xbc83a8      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BC8398: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC839C: CBNZ w9, #0xbc83a8         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BC83A0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC83A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BC83A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC83AC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC83B0: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BC83B4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC83B8: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BC83BC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC83C0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC83C4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC83C8: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BC83CC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC83D0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC83D4: TBZ w9, #0, #0xbc83e8      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BC83D8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC83DC: CBNZ w9, #0xbc83e8         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BC83E0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC83E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BC83E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC83EC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC83F0: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BC83F4: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00BC83F8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BC83FC: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x00BC8400: CBZ x0, #0xbc8448          | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x00BC8404: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00BC8408: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00BC840C: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00BC8410: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC8414: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BC8418: MOV x24, x0                | X24 = val_6;//m1                        
            val_16 = val_6;
            // 0x00BC841C: B.EQ #0xbc8448             | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x00BC8420: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC8424: MOV x8, sp                 | X8 = 1152921510057367024 (0x1000000144E055F0);//ML01
            // 0x00BC8428: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC842C: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510057355152]
            // 0x00BC8430: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x00BC8434: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC8438: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x00BC843C: MOV x0, sp                 | X0 = 1152921510057367024 (0x1000000144E055F0);//ML01
            // 0x00BC8440: BL #0x299a140              | 
            // 0x00BC8444: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_9:
            // 0x00BC8448: CBNZ x21, #0xbc8450        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00BC844C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144E055F0, ????);
            label_10:
            // 0x00BC8450: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC8454: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC8458: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BC845C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC8460: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8464: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC8468: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC846C: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC8470: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC8474: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x00BC8478: LDR x8, [x8, #0xa18]       | X8 = 1152921504657965056;               
            // 0x00BC847C: MOV x25, x0                | X25 = val_8;//m1                        
            // 0x00BC8480: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8484: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC8488: LDR x1, [x8]               | X1 = typeof(System.Action<T>);          
            // 0x00BC848C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC8490: MOV x26, x0                | X26 = val_9;//m1                        
            // 0x00BC8494: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8498: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC849C: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x00BC84A0: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC84A4: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BC84A8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC84AC: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x00BC84B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC84B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC84B8: MOV x1, x26                | X1 = val_9;//m1                         
            // 0x00BC84BC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x00BC84C0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x00BC84C4: CBZ x0, #0xbc850c          | if (val_11 == null) goto label_12;      
            if(val_11 == null)
            {
                goto label_12;
            }
            // 0x00BC84C8: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
            // 0x00BC84CC: LDR x8, [x8, #0x648]       | X8 = 1152921504657965056;               
            // 0x00BC84D0: LDR x1, [x8]               | X1 = typeof(System.Action<T>);          
            // 0x00BC84D4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC84D8: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.Action<T>))
            // 0x00BC84DC: MOV x22, x0                | X22 = val_11;//m1                       
            val_17 = val_11;
            // 0x00BC84E0: B.EQ #0xbc850c             | if (typeof(System.Object) == null) goto label_12;
            if(null == null)
            {
                goto label_12;
            }
            // 0x00BC84E4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC84E8: ADD x8, sp, #8             | X8 = (1152921510057367024 + 8) = 1152921510057367032 (0x1000000144E055F8);
            // 0x00BC84EC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC84F0: LDR x0, [sp, #8]           | X0 = val_12;                             //  find_add[1152921510057355152]
            // 0x00BC84F4: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x00BC84F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC84FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x00BC8500: ADD x0, sp, #8             | X0 = (1152921510057367024 + 8) = 1152921510057367032 (0x1000000144E055F8);
            // 0x00BC8504: BL #0x299a140              | 
            // 0x00BC8508: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_17 = 0;
            label_12:
            // 0x00BC850C: CBNZ x21, #0xbc8514        | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x00BC8510: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144E055F8, ????);
            label_13:
            // 0x00BC8514: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC8518: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC851C: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x00BC8520: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC8524: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8528: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC852C: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BC8530: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC8534: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_13 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC8538: MOV x20, x0                | X20 = val_13;//m1                       
            // 0x00BC853C: CBNZ x20, #0xbc8544        | if (val_13 != 0) goto label_14;         
            if(val_13 != 0)
            {
                goto label_14;
            }
            // 0x00BC8540: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_14:
            // 0x00BC8544: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00BC8548: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
            // 0x00BC854C: LDR s8, [x20, #4]          | S8 = val_13 + 4;                        
            // 0x00BC8550: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
            // 0x00BC8554: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
            // 0x00BC8558: TBZ w8, #0, #0xbc8568      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x00BC855C: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00BC8560: CBNZ w8, #0xbc8568         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x00BC8564: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
            label_16:
            // 0x00BC8568: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
            // 0x00BC856C: LDR x8, [x8, #0x20]        | X8 = 1152921510057354128;               
            // 0x00BC8570: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8574: MOV v0.16b, v8.16b         | V0 = val_13 + 4;//m1                    
            // 0x00BC8578: MOV x1, x22                | X1 = 0 (0x0);//ML01                     
            // 0x00BC857C: LDR x3, [x8]               | X3 = public static System.UInt32 BehaviourUtil::DelayCall<System.String>(float delaytime, System.Action<T1> act, System.String arg1);
            // 0x00BC8580: MOV x2, x24                | X2 = 0 (0x0);//ML01                     
            // 0x00BC8584: BL #0x10cecb4              | X0 = BehaviourUtil.DelayCall<CEvent.ZEvent>(delaytime:  val_13 + 4, act:  0, arg1:  val_17);
            uint val_14 = BehaviourUtil.DelayCall<CEvent.ZEvent>(delaytime:  val_13 + 4, act:  0, arg1:  val_17);
            // 0x00BC8588: CBZ x19, #0xbc85d8         | if (val_2 == 0) goto label_17;          
            if(val_2 == 0)
            {
                goto label_17;
            }
            // 0x00BC858C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC8590: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_14;        //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_14;
            // 0x00BC8594: LDR x0, [x27]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC8598: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_18 = 8;
            // 0x00BC859C: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BC85A0: TBZ w9, #0, #0xbc85b0      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_18;
            // 0x00BC85A4: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BC85A8: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BC85AC: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_18 = 219381744;
            label_18:
            // 0x00BC85B0: ADD x0, x8, x19            | X0 = (val_18 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_15 = val_18 + val_2;
            // 0x00BC85B4: SUB sp, x29, #0x60         | SP = (1152921510057367136 - 96) = 1152921510057367040 (0x1000000144E05600);
            // 0x00BC85B8: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC85BC: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC85C0: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC85C4: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
            // 0x00BC85C8: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
            // 0x00BC85CC: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
            // 0x00BC85D0: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
            // 0x00BC85D4: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_18 + val_2);
            return val_15;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            label_17:
            // 0x00BC85D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            // 0x00BC85DC: BRK #0x1                   | 
            // 0x00BC85E0: MOV x19, x0                | X19 = val_14;//m1                       
            val_19 = val_14;
            // 0x00BC85E4: MOV x0, sp                 | X0 = 1152921510057367024 (0x1000000144E055F0);//ML01
            val_20;
            // 0x00BC85E8: B #0xbc85f4                |  goto label_19;                         
            goto label_19;
            // 0x00BC85EC: MOV x19, x0                | X19 = 1152921510057367024 (0x1000000144E055F0);//ML01
            val_19 = val_20;
            // 0x00BC85F0: ADD x0, sp, #8             | X0 = (1152921510057367024 + 8) = 1152921510057367032 (0x1000000144E055F8);
            label_19:
            // 0x00BC85F4: BL #0x299a140              | 
            // 0x00BC85F8: MOV x0, x19                | X0 = 1152921510057367024 (0x1000000144E055F0);//ML01
            // 0x00BC85FC: BL #0x980800               | X0 = sub_980800( ?? 0x1000000144E055F0, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC8600 (12355072), len: 876  VirtAddr: 0x00BC8600 RVA: 0x00BC8600 token: 100663843 methodIndex: 29888 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* JSDelayCall_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_11;
            //  | 
            var val_15;
            //  | 
            HERO_ELEMENT val_16;
            //  | 
            System.Action<T> val_17;
            //  | 
            var val_18;
            // 0x00BC8600: STP d9, d8, [sp, #-0x70]!  | stack[1152921510057561984] = ???;  stack[1152921510057561992] = ???;  //  dest_result_addr=1152921510057561984 |  dest_result_addr=1152921510057561992
            // 0x00BC8604: STP x28, x27, [sp, #0x10]  | stack[1152921510057562000] = ???;  stack[1152921510057562008] = ???;  //  dest_result_addr=1152921510057562000 |  dest_result_addr=1152921510057562008
            // 0x00BC8608: STP x26, x25, [sp, #0x20]  | stack[1152921510057562016] = ???;  stack[1152921510057562024] = ???;  //  dest_result_addr=1152921510057562016 |  dest_result_addr=1152921510057562024
            // 0x00BC860C: STP x24, x23, [sp, #0x30]  | stack[1152921510057562032] = ???;  stack[1152921510057562040] = ???;  //  dest_result_addr=1152921510057562032 |  dest_result_addr=1152921510057562040
            // 0x00BC8610: STP x22, x21, [sp, #0x40]  | stack[1152921510057562048] = ???;  stack[1152921510057562056] = ???;  //  dest_result_addr=1152921510057562048 |  dest_result_addr=1152921510057562056
            // 0x00BC8614: STP x20, x19, [sp, #0x50]  | stack[1152921510057562064] = ???;  stack[1152921510057562072] = ???;  //  dest_result_addr=1152921510057562064 |  dest_result_addr=1152921510057562072
            // 0x00BC8618: STP x29, x30, [sp, #0x60]  | stack[1152921510057562080] = ???;  stack[1152921510057562088] = ???;  //  dest_result_addr=1152921510057562080 |  dest_result_addr=1152921510057562088
            // 0x00BC861C: ADD x29, sp, #0x60         | X29 = (1152921510057561984 + 96) = 1152921510057562080 (0x1000000144E34FE0);
            // 0x00BC8620: SUB sp, sp, #0x10          | SP = (1152921510057561984 - 16) = 1152921510057561968 (0x1000000144E34F70);
            // 0x00BC8624: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BC8628: LDRB w8, [x19, #0xbab]     | W8 = (bool)static_value_03733BAB;       
            // 0x00BC862C: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BC8630: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BC8634: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BC8638: TBNZ w8, #0, #0xbc8654     | if (static_value_03733BAB == true) goto label_0;
            // 0x00BC863C: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
            // 0x00BC8640: LDR x8, [x8, #0xf28]       | X8 = 0x2B8F264;                         
            // 0x00BC8644: LDR w0, [x8]               | W0 = 0x135B;                            
            // 0x00BC8648: BL #0x2782188              | X0 = sub_2782188( ?? 0x135B, ????);     
            // 0x00BC864C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC8650: STRB w8, [x19, #0xbab]     | static_value_03733BAB = true;            //  dest_result_addr=57883563
            label_0:
            // 0x00BC8654: CBNZ x21, #0xbc865c        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC8658: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x135B, ????);     
            label_1:
            // 0x00BC865C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC8660: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC8664: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC8668: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x00BC866C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8670: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC8674: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BC8678: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC867C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC8680: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BC8684: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8688: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC868C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC8690: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC8694: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC8698: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC869C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC86A0: ADRP x9, #0x35bb000        | X9 = 56340480 (0x35BB000);              
            // 0x00BC86A4: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00BC86A8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC86AC: LDR x9, [x9, #0x268]       | X9 = 1152921504897847296;               
            // 0x00BC86B0: LDR x23, [x9]              | X23 = typeof(HERO_ELEMENT);             
            // 0x00BC86B4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC86B8: TBZ w9, #0, #0xbc86cc      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BC86BC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC86C0: CBNZ w9, #0xbc86cc         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BC86C4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC86C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BC86CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC86D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC86D4: MOV x1, x23                | X1 = 1152921504897847296 (0x1000000011585000);//ML01
            // 0x00BC86D8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC86DC: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
            // 0x00BC86E0: LDR x27, [x27, #0x7a0]     | X27 = 1152921504826228736;              
            // 0x00BC86E4: MOV x23, x0                | X23 = val_4;//m1                        
            // 0x00BC86E8: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC86EC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC86F0: TBZ w9, #0, #0xbc8704      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BC86F4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC86F8: CBNZ w9, #0xbc8704         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BC86FC: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC8700: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BC8704: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8708: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC870C: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BC8710: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BC8714: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BC8718: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC871C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC8720: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC8724: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BC8728: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC872C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC8730: TBZ w9, #0, #0xbc8744      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BC8734: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC8738: CBNZ w9, #0xbc8744         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BC873C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC8740: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BC8744: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8748: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC874C: MOV x1, x23                | X1 = val_4;//m1                         
            // 0x00BC8750: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00BC8754: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BC8758: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
            // 0x00BC875C: LDR x8, [x8, #0x210]       | X8 = 1152921504897847296;               
            // 0x00BC8760: MOV x26, x0                | X26 = val_6;//m1                        
            // 0x00BC8764: LDR x23, [x8]              | X23 = typeof(HERO_ELEMENT);             
            // 0x00BC8768: CBNZ x26, #0xbc8770        | if (val_6 != null) goto label_8;        
            if(val_6 != null)
            {
                goto label_8;
            }
            // 0x00BC876C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_8:
            // 0x00BC8770: LDR x8, [x26]              | X8 = typeof(System.Object);             
            // 0x00BC8774: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC8778: LDR x8, [x23, #0x30]       | X8 = HERO_ELEMENT.__il2cppRuntimeField_element_class;
            // 0x00BC877C: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, HERO_ELEMENT.__il2cppRuntimeField_element_class)
            // 0x00BC8780: B.NE #0xbc8920             | if (System.Object.__il2cppRuntimeField_element_class != HERO_ELEMENT.__il2cppRuntimeField_element_class) goto label_9;
            // 0x00BC8784: MOV x0, x26                | X0 = val_6;//m1                         
            // 0x00BC8788: BL #0x27bc4e8              | val_6.System.IDisposable.Dispose();     
            val_6.System.IDisposable.Dispose();
            // 0x00BC878C: LDR w23, [x0]              | W23 = typeof(System.Object);            
            // 0x00BC8790: CBNZ x21, #0xbc8798        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00BC8794: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_10:
            // 0x00BC8798: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC879C: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC87A0: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BC87A4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC87A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC87AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC87B0: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC87B4: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC87B8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_7 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC87BC: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
            // 0x00BC87C0: LDR x8, [x8, #0x78]        | X8 = 1152921504657965056;               
            // 0x00BC87C4: MOV x25, x0                | X25 = val_7;//m1                        
            // 0x00BC87C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC87CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC87D0: LDR x1, [x8]               | X1 = typeof(System.Action<T>);          
            // 0x00BC87D4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC87D8: MOV x26, x0                | X26 = val_8;//m1                        
            // 0x00BC87DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC87E0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC87E4: MOV x1, x25                | X1 = val_7;//m1                         
            // 0x00BC87E8: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BC87EC: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BC87F0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_9 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC87F4: MOV x2, x0                 | X2 = val_9;//m1                         
            // 0x00BC87F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC87FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC8800: MOV x1, x26                | X1 = val_8;//m1                         
            // 0x00BC8804: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            object val_10 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            // 0x00BC8808: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x00BC880C: CBZ x0, #0xbc8854          | if (val_10 == null) goto label_12;      
            if(val_10 == null)
            {
                goto label_12;
            }
            // 0x00BC8810: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
            // 0x00BC8814: LDR x8, [x8, #0x130]       | X8 = 1152921504657965056;               
            // 0x00BC8818: LDR x1, [x8]               | X1 = typeof(System.Action<T>);          
            // 0x00BC881C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC8820: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.Action<T>))
            // 0x00BC8824: MOV x22, x0                | X22 = val_10;//m1                       
            val_16 = val_10;
            // 0x00BC8828: B.EQ #0xbc8854             | if (typeof(System.Object) == null) goto label_12;
            if(null == null)
            {
                goto label_12;
            }
            // 0x00BC882C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC8830: ADD x8, sp, #8             | X8 = (1152921510057561968 + 8) = 1152921510057561976 (0x1000000144E34F78);
            // 0x00BC8834: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC8838: LDR x0, [sp, #8]           | X0 = val_11;                             //  find_add[1152921510057550096]
            // 0x00BC883C: BL #0x27af090              | X0 = sub_27AF090( ?? val_11, ????);     
            // 0x00BC8840: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC8844: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            // 0x00BC8848: ADD x0, sp, #8             | X0 = (1152921510057561968 + 8) = 1152921510057561976 (0x1000000144E34F78);
            // 0x00BC884C: BL #0x299a140              | 
            // 0x00BC8850: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_12:
            // 0x00BC8854: CBNZ x21, #0xbc885c        | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x00BC8858: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144E34F78, ????);
            label_13:
            // 0x00BC885C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC8860: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC8864: MOV x1, x25                | X1 = val_7;//m1                         
            // 0x00BC8868: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC886C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8870: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC8874: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BC8878: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC887C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_12 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC8880: MOV x20, x0                | X20 = val_12;//m1                       
            // 0x00BC8884: CBNZ x20, #0xbc888c        | if (val_12 != 0) goto label_14;         
            if(val_12 != 0)
            {
                goto label_14;
            }
            // 0x00BC8888: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_14:
            // 0x00BC888C: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00BC8890: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
            // 0x00BC8894: LDR s8, [x20, #4]          | S8 = val_12 + 4;                        
            // 0x00BC8898: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
            // 0x00BC889C: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
            // 0x00BC88A0: TBZ w8, #0, #0xbc88b0      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x00BC88A4: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00BC88A8: CBNZ w8, #0xbc88b0         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x00BC88AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
            label_16:
            // 0x00BC88B0: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
            // 0x00BC88B4: LDR x8, [x8, #0xce8]       | X8 = 1152921510057549072;               
            // 0x00BC88B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_17 = 0;
            // 0x00BC88BC: MOV v0.16b, v8.16b         | V0 = val_12 + 4;//m1                    
            // 0x00BC88C0: MOV x1, x22                | X1 = 0 (0x0);//ML01                     
            // 0x00BC88C4: LDR x3, [x8]               | X3 = public static System.UInt32 BehaviourUtil::JSDelayCall<HERO_ELEMENT>(float delaytime, System.Action<T> act, HERO_ELEMENT arg1);
            // 0x00BC88C8: MOV w2, w23                | W2 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x00BC88CC: BL #0x10cef34              | X0 = BehaviourUtil.JSDelayCall<HERO_ELEMENT>(delaytime:  val_12 + 4, act:  val_17 = 0, arg1:  val_16);
            uint val_13 = BehaviourUtil.JSDelayCall<HERO_ELEMENT>(delaytime:  val_12 + 4, act:  val_17, arg1:  val_16);
            // 0x00BC88D0: CBZ x19, #0xbc8944         | if (val_2 == 0) goto label_17;          
            if(val_2 == 0)
            {
                goto label_17;
            }
            // 0x00BC88D4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC88D8: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_13;        //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_13;
            // 0x00BC88DC: LDR x0, [x27]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC88E0: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_18 = 8;
            // 0x00BC88E4: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BC88E8: TBZ w9, #0, #0xbc88f8      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_18;
            // 0x00BC88EC: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BC88F0: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BC88F4: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_18 = 219381744;
            label_18:
            // 0x00BC88F8: ADD x0, x8, x19            | X0 = (val_18 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_14 = val_18 + val_2;
            // 0x00BC88FC: SUB sp, x29, #0x60         | SP = (1152921510057562080 - 96) = 1152921510057561984 (0x1000000144E34F80);
            // 0x00BC8900: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC8904: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC8908: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC890C: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
            // 0x00BC8910: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
            // 0x00BC8914: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
            // 0x00BC8918: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
            // 0x00BC891C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_18 + val_2);
            return val_14;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            label_9:
            // 0x00BC8920: MOV x8, sp                 | X8 = 1152921510057561968 (0x1000000144E34F70);//ML01
            // 0x00BC8924: MOV x1, x23                | X1 = 1152921504897847296 (0x1000000011585000);//ML01
            // 0x00BC8928: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC892C: LDR x0, [sp]               | X0 = val_15;                             //  find_add[1152921510057550096]
            // 0x00BC8930: BL #0x27af090              | X0 = sub_27AF090( ?? val_15, ????);     
            // 0x00BC8934: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC8938: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            // 0x00BC893C: MOV x0, sp                 | X0 = 1152921510057561968 (0x1000000144E34F70);//ML01
            val_17;
            // 0x00BC8940: BL #0x299a140              | 
            label_17:
            // 0x00BC8944: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144E34F70, ????);
            // 0x00BC8948: BRK #0x1                   | 
            // 0x00BC894C: MOV x19, x0                | X19 = 1152921510057561968 (0x1000000144E34F70);//ML01
            // 0x00BC8950: ADD x0, sp, #8             | X0 = (1152921510057561968 + 8) = 1152921510057561976 (0x1000000144E34F78);
            label_19:
            // 0x00BC8954: BL #0x299a140              | 
            // 0x00BC8958: MOV x0, x19                | X0 = 1152921510057561968 (0x1000000144E34F70);//ML01
            // 0x00BC895C: BL #0x980800               | X0 = sub_980800( ?? 0x1000000144E34F70, ????);
            // 0x00BC8960: MOV x19, x0                | X19 = 1152921510057561968 (0x1000000144E34F70);//ML01
            // 0x00BC8964: MOV x0, sp                 | X0 = 1152921510057561968 (0x1000000144E34F70);//ML01
            // 0x00BC8968: B #0xbc8954                |  goto label_19;                         
            goto label_19;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC896C (12355948), len: 860  VirtAddr: 0x00BC896C RVA: 0x00BC896C token: 100663844 methodIndex: 29889 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* JSDelayCall_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_12;
            //  | 
            var val_16;
            //  | 
            ILRuntime.Runtime.Intepreter.ILTypeInstance val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            var val_20;
            // 0x00BC896C: STP d9, d8, [sp, #-0x70]!  | stack[1152921510057756928] = ???;  stack[1152921510057756936] = ???;  //  dest_result_addr=1152921510057756928 |  dest_result_addr=1152921510057756936
            // 0x00BC8970: STP x28, x27, [sp, #0x10]  | stack[1152921510057756944] = ???;  stack[1152921510057756952] = ???;  //  dest_result_addr=1152921510057756944 |  dest_result_addr=1152921510057756952
            // 0x00BC8974: STP x26, x25, [sp, #0x20]  | stack[1152921510057756960] = ???;  stack[1152921510057756968] = ???;  //  dest_result_addr=1152921510057756960 |  dest_result_addr=1152921510057756968
            // 0x00BC8978: STP x24, x23, [sp, #0x30]  | stack[1152921510057756976] = ???;  stack[1152921510057756984] = ???;  //  dest_result_addr=1152921510057756976 |  dest_result_addr=1152921510057756984
            // 0x00BC897C: STP x22, x21, [sp, #0x40]  | stack[1152921510057756992] = ???;  stack[1152921510057757000] = ???;  //  dest_result_addr=1152921510057756992 |  dest_result_addr=1152921510057757000
            // 0x00BC8980: STP x20, x19, [sp, #0x50]  | stack[1152921510057757008] = ???;  stack[1152921510057757016] = ???;  //  dest_result_addr=1152921510057757008 |  dest_result_addr=1152921510057757016
            // 0x00BC8984: STP x29, x30, [sp, #0x60]  | stack[1152921510057757024] = ???;  stack[1152921510057757032] = ???;  //  dest_result_addr=1152921510057757024 |  dest_result_addr=1152921510057757032
            // 0x00BC8988: ADD x29, sp, #0x60         | X29 = (1152921510057756928 + 96) = 1152921510057757024 (0x1000000144E64960);
            // 0x00BC898C: SUB sp, sp, #0x10          | SP = (1152921510057756928 - 16) = 1152921510057756912 (0x1000000144E648F0);
            // 0x00BC8990: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BC8994: LDRB w8, [x19, #0xbac]     | W8 = (bool)static_value_03733BAC;       
            // 0x00BC8998: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BC899C: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BC89A0: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BC89A4: TBNZ w8, #0, #0xbc89c0     | if (static_value_03733BAC == true) goto label_0;
            // 0x00BC89A8: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x00BC89AC: LDR x8, [x8, #0x6e0]       | X8 = 0x2B8F268;                         
            // 0x00BC89B0: LDR w0, [x8]               | W0 = 0x135C;                            
            // 0x00BC89B4: BL #0x2782188              | X0 = sub_2782188( ?? 0x135C, ????);     
            // 0x00BC89B8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC89BC: STRB w8, [x19, #0xbac]     | static_value_03733BAC = true;            //  dest_result_addr=57883564
            label_0:
            // 0x00BC89C0: CBNZ x21, #0xbc89c8        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC89C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x135C, ????);     
            label_1:
            // 0x00BC89C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC89CC: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC89D0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC89D4: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BC89D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC89DC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC89E0: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BC89E4: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC89E8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC89EC: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BC89F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC89F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC89F8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC89FC: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC8A00: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC8A04: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC8A08: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC8A0C: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x00BC8A10: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00BC8A14: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC8A18: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x00BC8A1C: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x00BC8A20: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC8A24: TBZ w9, #0, #0xbc8a38      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BC8A28: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC8A2C: CBNZ w9, #0xbc8a38         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BC8A30: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC8A34: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BC8A38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8A3C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC8A40: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BC8A44: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC8A48: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
            // 0x00BC8A4C: LDR x27, [x27, #0x7a0]     | X27 = 1152921504826228736;              
            // 0x00BC8A50: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BC8A54: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC8A58: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC8A5C: TBZ w9, #0, #0xbc8a70      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BC8A60: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC8A64: CBNZ w9, #0xbc8a70         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BC8A68: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC8A6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BC8A70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8A74: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC8A78: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BC8A7C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC8A80: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BC8A84: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC8A88: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC8A8C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC8A90: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BC8A94: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC8A98: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC8A9C: TBZ w9, #0, #0xbc8ab0      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BC8AA0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC8AA4: CBNZ w9, #0xbc8ab0         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BC8AA8: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC8AAC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BC8AB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8AB4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC8AB8: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BC8ABC: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00BC8AC0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BC8AC4: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x00BC8AC8: CBZ x0, #0xbc8b10          | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x00BC8ACC: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00BC8AD0: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00BC8AD4: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00BC8AD8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC8ADC: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BC8AE0: MOV x24, x0                | X24 = val_6;//m1                        
            val_16 = val_6;
            // 0x00BC8AE4: B.EQ #0xbc8b10             | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x00BC8AE8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC8AEC: MOV x8, sp                 | X8 = 1152921510057756912 (0x1000000144E648F0);//ML01
            // 0x00BC8AF0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC8AF4: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510057745040]
            // 0x00BC8AF8: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x00BC8AFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC8B00: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x00BC8B04: MOV x0, sp                 | X0 = 1152921510057756912 (0x1000000144E648F0);//ML01
            // 0x00BC8B08: BL #0x299a140              | 
            // 0x00BC8B0C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_9:
            // 0x00BC8B10: CBNZ x21, #0xbc8b18        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00BC8B14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144E648F0, ????);
            label_10:
            // 0x00BC8B18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC8B1C: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC8B20: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BC8B24: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC8B28: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8B2C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC8B30: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC8B34: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC8B38: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC8B3C: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x00BC8B40: LDR x8, [x8, #0xa18]       | X8 = 1152921504657965056;               
            // 0x00BC8B44: MOV x25, x0                | X25 = val_8;//m1                        
            // 0x00BC8B48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8B4C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC8B50: LDR x1, [x8]               | X1 = typeof(System.Action<T>);          
            // 0x00BC8B54: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC8B58: MOV x26, x0                | X26 = val_9;//m1                        
            // 0x00BC8B5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8B60: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC8B64: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x00BC8B68: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC8B6C: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BC8B70: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC8B74: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x00BC8B78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8B7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC8B80: MOV x1, x26                | X1 = val_9;//m1                         
            // 0x00BC8B84: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x00BC8B88: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x00BC8B8C: CBZ x0, #0xbc8bd4          | if (val_11 == null) goto label_12;      
            if(val_11 == null)
            {
                goto label_12;
            }
            // 0x00BC8B90: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
            // 0x00BC8B94: LDR x8, [x8, #0x648]       | X8 = 1152921504657965056;               
            // 0x00BC8B98: LDR x1, [x8]               | X1 = typeof(System.Action<T>);          
            // 0x00BC8B9C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC8BA0: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.Action<T>))
            // 0x00BC8BA4: MOV x22, x0                | X22 = val_11;//m1                       
            val_17 = val_11;
            // 0x00BC8BA8: B.EQ #0xbc8bd4             | if (typeof(System.Object) == null) goto label_12;
            if(null == null)
            {
                goto label_12;
            }
            // 0x00BC8BAC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC8BB0: ADD x8, sp, #8             | X8 = (1152921510057756912 + 8) = 1152921510057756920 (0x1000000144E648F8);
            // 0x00BC8BB4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC8BB8: LDR x0, [sp, #8]           | X0 = val_12;                             //  find_add[1152921510057745040]
            // 0x00BC8BBC: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x00BC8BC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC8BC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x00BC8BC8: ADD x0, sp, #8             | X0 = (1152921510057756912 + 8) = 1152921510057756920 (0x1000000144E648F8);
            // 0x00BC8BCC: BL #0x299a140              | 
            // 0x00BC8BD0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_17 = 0;
            label_12:
            // 0x00BC8BD4: CBNZ x21, #0xbc8bdc        | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x00BC8BD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144E648F8, ????);
            label_13:
            // 0x00BC8BDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC8BE0: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC8BE4: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x00BC8BE8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC8BEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8BF0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC8BF4: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BC8BF8: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC8BFC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_13 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC8C00: MOV x20, x0                | X20 = val_13;//m1                       
            // 0x00BC8C04: CBNZ x20, #0xbc8c0c        | if (val_13 != 0) goto label_14;         
            if(val_13 != 0)
            {
                goto label_14;
            }
            // 0x00BC8C08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_14:
            // 0x00BC8C0C: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00BC8C10: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
            // 0x00BC8C14: LDR s8, [x20, #4]          | S8 = val_13 + 4;                        
            // 0x00BC8C18: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
            // 0x00BC8C1C: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
            // 0x00BC8C20: TBZ w8, #0, #0xbc8c30      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x00BC8C24: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00BC8C28: CBNZ w8, #0xbc8c30         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x00BC8C2C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
            label_16:
            // 0x00BC8C30: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
            // 0x00BC8C34: LDR x8, [x8, #0x518]       | X8 = 1152921510057744016;               
            // 0x00BC8C38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8C3C: MOV v0.16b, v8.16b         | V0 = val_13 + 4;//m1                    
            // 0x00BC8C40: MOV x1, x22                | X1 = 0 (0x0);//ML01                     
            // 0x00BC8C44: LDR x3, [x8]               | X3 = public static System.UInt32 BehaviourUtil::JSDelayCall<System.String>(float delaytime, System.Action<T> act, System.String arg1);
            // 0x00BC8C48: MOV x2, x24                | X2 = 0 (0x0);//ML01                     
            // 0x00BC8C4C: BL #0x10cf50c              | X0 = BehaviourUtil.JSDelayCall<ILRuntime.Runtime.Intepreter.ILTypeInstance>(delaytime:  val_13 + 4, act:  0, arg1:  val_17);
            uint val_14 = BehaviourUtil.JSDelayCall<ILRuntime.Runtime.Intepreter.ILTypeInstance>(delaytime:  val_13 + 4, act:  0, arg1:  val_17);
            // 0x00BC8C50: CBZ x19, #0xbc8ca0         | if (val_2 == 0) goto label_17;          
            if(val_2 == 0)
            {
                goto label_17;
            }
            // 0x00BC8C54: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC8C58: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_14;        //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_14;
            // 0x00BC8C5C: LDR x0, [x27]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC8C60: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_18 = 8;
            // 0x00BC8C64: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BC8C68: TBZ w9, #0, #0xbc8c78      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_18;
            // 0x00BC8C6C: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BC8C70: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BC8C74: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_18 = 219381744;
            label_18:
            // 0x00BC8C78: ADD x0, x8, x19            | X0 = (val_18 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_15 = val_18 + val_2;
            // 0x00BC8C7C: SUB sp, x29, #0x60         | SP = (1152921510057757024 - 96) = 1152921510057756928 (0x1000000144E64900);
            // 0x00BC8C80: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC8C84: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC8C88: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC8C8C: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
            // 0x00BC8C90: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
            // 0x00BC8C94: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
            // 0x00BC8C98: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
            // 0x00BC8C9C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_18 + val_2);
            return val_15;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            label_17:
            // 0x00BC8CA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            // 0x00BC8CA4: BRK #0x1                   | 
            // 0x00BC8CA8: MOV x19, x0                | X19 = val_14;//m1                       
            val_19 = val_14;
            // 0x00BC8CAC: MOV x0, sp                 | X0 = 1152921510057756912 (0x1000000144E648F0);//ML01
            val_20;
            // 0x00BC8CB0: B #0xbc8cbc                |  goto label_19;                         
            goto label_19;
            // 0x00BC8CB4: MOV x19, x0                | X19 = 1152921510057756912 (0x1000000144E648F0);//ML01
            val_19 = val_20;
            // 0x00BC8CB8: ADD x0, sp, #8             | X0 = (1152921510057756912 + 8) = 1152921510057756920 (0x1000000144E648F8);
            label_19:
            // 0x00BC8CBC: BL #0x299a140              | 
            // 0x00BC8CC0: MOV x0, x19                | X0 = 1152921510057756912 (0x1000000144E648F0);//ML01
            // 0x00BC8CC4: BL #0x980800               | X0 = sub_980800( ?? 0x1000000144E648F0, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC8CC8 (12356808), len: 692  VirtAddr: 0x00BC8CC8 RVA: 0x00BC8CC8 token: 100663845 methodIndex: 29890 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* JSDelayCall_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            var val_14;
            // 0x00BC8CC8: STP d9, d8, [sp, #-0x70]!  | stack[1152921510057939584] = ???;  stack[1152921510057939592] = ???;  //  dest_result_addr=1152921510057939584 |  dest_result_addr=1152921510057939592
            // 0x00BC8CCC: STP x28, x27, [sp, #0x10]  | stack[1152921510057939600] = ???;  stack[1152921510057939608] = ???;  //  dest_result_addr=1152921510057939600 |  dest_result_addr=1152921510057939608
            // 0x00BC8CD0: STP x26, x25, [sp, #0x20]  | stack[1152921510057939616] = ???;  stack[1152921510057939624] = ???;  //  dest_result_addr=1152921510057939616 |  dest_result_addr=1152921510057939624
            // 0x00BC8CD4: STP x24, x23, [sp, #0x30]  | stack[1152921510057939632] = ???;  stack[1152921510057939640] = ???;  //  dest_result_addr=1152921510057939632 |  dest_result_addr=1152921510057939640
            // 0x00BC8CD8: STP x22, x21, [sp, #0x40]  | stack[1152921510057939648] = ???;  stack[1152921510057939656] = ???;  //  dest_result_addr=1152921510057939648 |  dest_result_addr=1152921510057939656
            // 0x00BC8CDC: STP x20, x19, [sp, #0x50]  | stack[1152921510057939664] = ???;  stack[1152921510057939672] = ???;  //  dest_result_addr=1152921510057939664 |  dest_result_addr=1152921510057939672
            // 0x00BC8CE0: STP x29, x30, [sp, #0x60]  | stack[1152921510057939680] = ???;  stack[1152921510057939688] = ???;  //  dest_result_addr=1152921510057939680 |  dest_result_addr=1152921510057939688
            // 0x00BC8CE4: ADD x29, sp, #0x60         | X29 = (1152921510057939584 + 96) = 1152921510057939680 (0x1000000144E912E0);
            // 0x00BC8CE8: SUB sp, sp, #0x10          | SP = (1152921510057939584 - 16) = 1152921510057939568 (0x1000000144E91270);
            // 0x00BC8CEC: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BC8CF0: LDRB w8, [x19, #0xbad]     | W8 = (bool)static_value_03733BAD;       
            // 0x00BC8CF4: MOV x23, x3                | X23 = X3;//m1                           
            // 0x00BC8CF8: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BC8CFC: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BC8D00: TBNZ w8, #0, #0xbc8d1c     | if (static_value_03733BAD == true) goto label_0;
            // 0x00BC8D04: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
            // 0x00BC8D08: LDR x8, [x8, #0x730]       | X8 = 0x2B8F26C;                         
            // 0x00BC8D0C: LDR w0, [x8]               | W0 = 0x135D;                            
            // 0x00BC8D10: BL #0x2782188              | X0 = sub_2782188( ?? 0x135D, ????);     
            // 0x00BC8D14: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC8D18: STRB w8, [x19, #0xbad]     | static_value_03733BAD = true;            //  dest_result_addr=57883565
            label_0:
            // 0x00BC8D1C: CBNZ x21, #0xbc8d24        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC8D20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x135D, ????);     
            label_1:
            // 0x00BC8D24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC8D28: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC8D2C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC8D30: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x00BC8D34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8D38: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC8D3C: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BC8D40: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC8D44: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC8D48: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BC8D4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8D50: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC8D54: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC8D58: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC8D5C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC8D60: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00BC8D64: CBNZ x22, #0xbc8d6c        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BC8D68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BC8D6C: LDR w26, [x22, #4]         | W26 = val_3 + 4;                        
            // 0x00BC8D70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8D74: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC8D78: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC8D7C: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC8D80: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC8D84: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC8D88: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC8D8C: ADRP x9, #0x35c0000        | X9 = 56360960 (0x35C0000);              
            // 0x00BC8D90: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00BC8D94: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC8D98: LDR x9, [x9, #0x150]       | X9 = 1152921504657965056;               
            // 0x00BC8D9C: LDR x25, [x9]              | X25 = typeof(System.Action<T>);         
            // 0x00BC8DA0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC8DA4: TBZ w9, #0, #0xbc8db8      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00BC8DA8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC8DAC: CBNZ w9, #0xbc8db8         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00BC8DB0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC8DB4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x00BC8DB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8DBC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC8DC0: MOV x1, x25                | X1 = 1152921504657965056 (0x10000000030C0000);//ML01
            // 0x00BC8DC4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC8DC8: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
            // 0x00BC8DCC: LDR x27, [x27, #0x7a0]     | X27 = 1152921504826228736;              
            // 0x00BC8DD0: MOV x25, x0                | X25 = val_5;//m1                        
            // 0x00BC8DD4: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC8DD8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC8DDC: TBZ w9, #0, #0xbc8df0      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00BC8DE0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC8DE4: CBNZ w9, #0xbc8df0         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00BC8DE8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC8DEC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x00BC8DF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8DF4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC8DF8: MOV x1, x22                | X1 = val_4;//m1                         
            // 0x00BC8DFC: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BC8E00: MOV x3, x23                | X3 = X3;//m1                            
            // 0x00BC8E04: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC8E08: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC8E0C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC8E10: MOV x23, x0                | X23 = val_6;//m1                        
            // 0x00BC8E14: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC8E18: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC8E1C: TBZ w9, #0, #0xbc8e30      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00BC8E20: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC8E24: CBNZ w9, #0xbc8e30         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00BC8E28: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC8E2C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x00BC8E30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8E34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC8E38: MOV x1, x25                | X1 = val_5;//m1                         
            // 0x00BC8E3C: MOV x2, x23                | X2 = val_6;//m1                         
            // 0x00BC8E40: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x00BC8E44: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x00BC8E48: CBZ x0, #0xbc8e90          | if (val_7 == null) goto label_10;       
            if(val_7 == null)
            {
                goto label_10;
            }
            // 0x00BC8E4C: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
            // 0x00BC8E50: LDR x8, [x8, #0x820]       | X8 = 1152921504657965056;               
            // 0x00BC8E54: LDR x1, [x8]               | X1 = typeof(System.Action<T>);          
            // 0x00BC8E58: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC8E5C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.Action<T>))
            // 0x00BC8E60: MOV x23, x0                | X23 = val_7;//m1                        
            val_13 = val_7;
            // 0x00BC8E64: B.EQ #0xbc8e90             | if (typeof(System.Object) == null) goto label_10;
            if(null == null)
            {
                goto label_10;
            }
            // 0x00BC8E68: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC8E6C: ADD x8, sp, #8             | X8 = (1152921510057939568 + 8) = 1152921510057939576 (0x1000000144E91278);
            // 0x00BC8E70: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC8E74: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510057927696]
            // 0x00BC8E78: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BC8E7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC8E80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BC8E84: ADD x0, sp, #8             | X0 = (1152921510057939568 + 8) = 1152921510057939576 (0x1000000144E91278);
            // 0x00BC8E88: BL #0x299a140              | 
            // 0x00BC8E8C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_10:
            // 0x00BC8E90: CBNZ x21, #0xbc8e98        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BC8E94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144E91278, ????);
            label_11:
            // 0x00BC8E98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC8E9C: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC8EA0: MOV x1, x22                | X1 = val_4;//m1                         
            // 0x00BC8EA4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC8EA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8EAC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC8EB0: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BC8EB4: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC8EB8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC8EBC: MOV x20, x0                | X20 = val_9;//m1                        
            // 0x00BC8EC0: CBNZ x20, #0xbc8ec8        | if (val_9 != 0) goto label_12;          
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x00BC8EC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_12:
            // 0x00BC8EC8: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00BC8ECC: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
            // 0x00BC8ED0: LDR s8, [x20, #4]          | S8 = val_9 + 4;                         
            // 0x00BC8ED4: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
            // 0x00BC8ED8: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
            // 0x00BC8EDC: TBZ w8, #0, #0xbc8eec      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x00BC8EE0: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00BC8EE4: CBNZ w8, #0xbc8eec         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x00BC8EE8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
            label_14:
            // 0x00BC8EEC: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
            // 0x00BC8EF0: LDR x8, [x8, #0x2d8]       | X8 = 1152921510057926672;               
            // 0x00BC8EF4: CMP w26, #1                | STATE = COMPARE(val_3 + 4, 0x1)         
            // 0x00BC8EF8: CSET w2, eq                | W2 = val_3 + 4 == 0x1 ? 1 : 0;          
            var val_10 = ((val_3 + 4) == 1) ? 1 : 0;
            // 0x00BC8EFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8F00: LDR x3, [x8]               | X3 = public static System.UInt32 BehaviourUtil::JSDelayCall<System.Boolean>(float delaytime, System.Action<T> act, System.Boolean arg1);
            // 0x00BC8F04: MOV v0.16b, v8.16b         | V0 = val_9 + 4;//m1                     
            // 0x00BC8F08: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x00BC8F0C: BL #0x10ceffc              | X0 = BehaviourUtil.JSDelayCall<System.Boolean>(delaytime:  val_9 + 4, act:  0, arg1:  false);
            uint val_11 = BehaviourUtil.JSDelayCall<System.Boolean>(delaytime:  val_9 + 4, act:  0, arg1:  false);
            // 0x00BC8F10: CBZ x19, #0xbc8f60         | if (val_2 == 0) goto label_15;          
            if(val_2 == 0)
            {
                goto label_15;
            }
            // 0x00BC8F14: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC8F18: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_11;        //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_11;
            // 0x00BC8F1C: LDR x0, [x27]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC8F20: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_14 = 8;
            // 0x00BC8F24: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BC8F28: TBZ w9, #0, #0xbc8f38      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_16;
            // 0x00BC8F2C: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BC8F30: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BC8F34: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_14 = 219381744;
            label_16:
            // 0x00BC8F38: ADD x0, x8, x19            | X0 = (val_14 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_12 = val_14 + val_2;
            // 0x00BC8F3C: SUB sp, x29, #0x60         | SP = (1152921510057939680 - 96) = 1152921510057939584 (0x1000000144E91280);
            // 0x00BC8F40: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC8F44: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC8F48: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC8F4C: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
            // 0x00BC8F50: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
            // 0x00BC8F54: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
            // 0x00BC8F58: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
            // 0x00BC8F5C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_14 + val_2);
            return val_12;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            label_15:
            // 0x00BC8F60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            // 0x00BC8F64: BRK #0x1                   | 
            // 0x00BC8F68: MOV x19, x0                | X19 = val_11;//m1                       
            // 0x00BC8F6C: ADD x0, sp, #8             | X0 = (1152921510057939568 + 8) = 1152921510057939576 (0x1000000144E91278);
            // 0x00BC8F70: BL #0x299a140              | 
            // 0x00BC8F74: MOV x0, x19                | X0 = val_11;//m1                        
            // 0x00BC8F78: BL #0x980800               | X0 = sub_980800( ?? val_11, ????);      
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC8F7C (12357500), len: 928  VirtAddr: 0x00BC8F7C RVA: 0x00BC8F7C token: 100663846 methodIndex: 29891 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* JSDelayCall_15(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_14;
            //  | 
            var val_18;
            //  | 
            object val_19;
            //  | 
            var val_20;
            //  | 
            var val_21;
            //  | 
            var val_22;
            // 0x00BC8F7C: STP d9, d8, [sp, #-0x70]!  | stack[1152921510058122240] = ???;  stack[1152921510058122248] = ???;  //  dest_result_addr=1152921510058122240 |  dest_result_addr=1152921510058122248
            // 0x00BC8F80: STP x28, x27, [sp, #0x10]  | stack[1152921510058122256] = ???;  stack[1152921510058122264] = ???;  //  dest_result_addr=1152921510058122256 |  dest_result_addr=1152921510058122264
            // 0x00BC8F84: STP x26, x25, [sp, #0x20]  | stack[1152921510058122272] = ???;  stack[1152921510058122280] = ???;  //  dest_result_addr=1152921510058122272 |  dest_result_addr=1152921510058122280
            // 0x00BC8F88: STP x24, x23, [sp, #0x30]  | stack[1152921510058122288] = ???;  stack[1152921510058122296] = ???;  //  dest_result_addr=1152921510058122288 |  dest_result_addr=1152921510058122296
            // 0x00BC8F8C: STP x22, x21, [sp, #0x40]  | stack[1152921510058122304] = ???;  stack[1152921510058122312] = ???;  //  dest_result_addr=1152921510058122304 |  dest_result_addr=1152921510058122312
            // 0x00BC8F90: STP x20, x19, [sp, #0x50]  | stack[1152921510058122320] = ???;  stack[1152921510058122328] = ???;  //  dest_result_addr=1152921510058122320 |  dest_result_addr=1152921510058122328
            // 0x00BC8F94: STP x29, x30, [sp, #0x60]  | stack[1152921510058122336] = ???;  stack[1152921510058122344] = ???;  //  dest_result_addr=1152921510058122336 |  dest_result_addr=1152921510058122344
            // 0x00BC8F98: ADD x29, sp, #0x60         | X29 = (1152921510058122240 + 96) = 1152921510058122336 (0x1000000144EBDC60);
            // 0x00BC8F9C: SUB sp, sp, #0x10          | SP = (1152921510058122240 - 16) = 1152921510058122224 (0x1000000144EBDBF0);
            // 0x00BC8FA0: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BC8FA4: LDRB w8, [x19, #0xbae]     | W8 = (bool)static_value_03733BAE;       
            // 0x00BC8FA8: MOV x23, x3                | X23 = X3;//m1                           
            // 0x00BC8FAC: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BC8FB0: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BC8FB4: TBNZ w8, #0, #0xbc8fd0     | if (static_value_03733BAE == true) goto label_0;
            // 0x00BC8FB8: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x00BC8FBC: LDR x8, [x8, #0xc48]       | X8 = 0x2B8F270;                         
            // 0x00BC8FC0: LDR w0, [x8]               | W0 = 0x135E;                            
            // 0x00BC8FC4: BL #0x2782188              | X0 = sub_2782188( ?? 0x135E, ????);     
            // 0x00BC8FC8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC8FCC: STRB w8, [x19, #0xbae]     | static_value_03733BAE = true;            //  dest_result_addr=57883566
            label_0:
            // 0x00BC8FD0: CBNZ x21, #0xbc8fd8        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC8FD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x135E, ????);     
            label_1:
            // 0x00BC8FD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC8FDC: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC8FE0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC8FE4: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x00BC8FE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC8FEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC8FF0: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x00BC8FF4: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC8FF8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC8FFC: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BC9000: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC9004: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9008: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC900C: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC9010: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC9014: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00BC9018: CBNZ x22, #0xbc9020        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BC901C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BC9020: LDR w22, [x22, #4]         | W22 = val_3 + 4;                        
            // 0x00BC9024: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC9028: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC902C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC9030: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC9034: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC9038: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC903C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC9040: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
            // 0x00BC9044: MOV x26, x0                | X26 = val_4;//m1                        
            // 0x00BC9048: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC904C: LDR x9, [x9, #0xd20]       | X9 = 1152921504825909248;               
            // 0x00BC9050: LDR x25, [x9]              | X25 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
            // 0x00BC9054: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC9058: TBZ w9, #0, #0xbc906c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00BC905C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC9060: CBNZ w9, #0xbc906c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00BC9064: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC9068: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x00BC906C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC9070: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC9074: MOV x1, x25                | X1 = 1152921504825909248 (0x100000000D0EA000);//ML01
            // 0x00BC9078: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC907C: ADRP x28, #0x366f000       | X28 = 57077760 (0x366F000);             
            // 0x00BC9080: LDR x28, [x28, #0x7a0]     | X28 = 1152921504826228736;              
            // 0x00BC9084: MOV x25, x0                | X25 = val_5;//m1                        
            // 0x00BC9088: LDR x8, [x28]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC908C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC9090: TBZ w9, #0, #0xbc90a4      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00BC9094: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC9098: CBNZ w9, #0xbc90a4         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00BC909C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC90A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x00BC90A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC90A8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC90AC: MOV x1, x26                | X1 = val_4;//m1                         
            // 0x00BC90B0: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BC90B4: MOV x3, x23                | X3 = X3;//m1                            
            // 0x00BC90B8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC90BC: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC90C0: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC90C4: MOV x27, x0                | X27 = val_6;//m1                        
            // 0x00BC90C8: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC90CC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC90D0: TBZ w9, #0, #0xbc90e4      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00BC90D4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC90D8: CBNZ w9, #0xbc90e4         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00BC90DC: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC90E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x00BC90E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC90E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC90EC: MOV x1, x25                | X1 = val_5;//m1                         
            // 0x00BC90F0: MOV x2, x27                | X2 = val_6;//m1                         
            // 0x00BC90F4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x00BC90F8: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_18 = 0;
            // 0x00BC90FC: CBZ x0, #0xbc9160          | if (val_7 == null) goto label_11;       
            if(val_7 == null)
            {
                goto label_11;
            }
            // 0x00BC9100: ADRP x9, #0x35dd000        | X9 = 56479744 (0x35DD000);              
            // 0x00BC9104: LDR x9, [x9, #0xb50]       | X9 = 1152921504825909248;               
            // 0x00BC9108: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC910C: LDR x1, [x9]               | X1 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
            // 0x00BC9110: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC9114: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC9118: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC911C: B.LO #0xbc9138             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x00BC9120: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BC9124: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstanc
            // 0x00BC9128: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC912C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance))
            // 0x00BC9130: MOV x25, x0                | X25 = val_7;//m1                        
            val_18 = val_7;
            // 0x00BC9134: B.EQ #0xbc9160             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x00BC9138: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC913C: MOV x8, sp                 | X8 = 1152921510058122224 (0x1000000144EBDBF0);//ML01
            // 0x00BC9140: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC9144: LDR x0, [sp]               | X0 = val_9;                              //  find_add[1152921510058110352]
            // 0x00BC9148: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x00BC914C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC9150: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x00BC9154: MOV x0, sp                 | X0 = 1152921510058122224 (0x1000000144EBDBF0);//ML01
            // 0x00BC9158: BL #0x299a140              | 
            // 0x00BC915C: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_18 = 0;
            label_11:
            // 0x00BC9160: CBNZ x21, #0xbc9168        | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x00BC9164: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144EBDBF0, ????);
            label_12:
            // 0x00BC9168: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC916C: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC9170: MOV x1, x26                | X1 = val_4;//m1                         
            // 0x00BC9174: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC9178: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC917C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9180: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BC9184: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC9188: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_10 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC918C: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x00BC9190: LDR x8, [x8, #0xbc8]       | X8 = 1152921504687890432;               
            // 0x00BC9194: MOV x26, x0                | X26 = val_10;//m1                       
            // 0x00BC9198: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC919C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC91A0: LDR x1, [x8]               | X1 = typeof(System.Action<T1, T2>);     
            // 0x00BC91A4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_11 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC91A8: MOV x27, x0                | X27 = val_11;//m1                       
            // 0x00BC91AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC91B0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC91B4: MOV x1, x26                | X1 = val_10;//m1                        
            // 0x00BC91B8: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BC91BC: MOV x3, x23                | X3 = X3;//m1                            
            // 0x00BC91C0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_12 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC91C4: MOV x2, x0                 | X2 = val_12;//m1                        
            // 0x00BC91C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC91CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC91D0: MOV x1, x27                | X1 = val_11;//m1                        
            // 0x00BC91D4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_11);
            object val_13 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_11);
            // 0x00BC91D8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_19 = 0;
            // 0x00BC91DC: CBZ x0, #0xbc9224          | if (val_13 == null) goto label_14;      
            if(val_13 == null)
            {
                goto label_14;
            }
            // 0x00BC91E0: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x00BC91E4: LDR x8, [x8, #0xdf8]       | X8 = 1152921504687890432;               
            // 0x00BC91E8: LDR x1, [x8]               | X1 = typeof(System.Action<T1, T2>);     
            // 0x00BC91EC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC91F0: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.Action<T1, T2>))
            // 0x00BC91F4: MOV x23, x0                | X23 = val_13;//m1                       
            val_19 = val_13;
            // 0x00BC91F8: B.EQ #0xbc9224             | if (typeof(System.Object) == null) goto label_14;
            if(null == null)
            {
                goto label_14;
            }
            // 0x00BC91FC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC9200: ADD x8, sp, #8             | X8 = (1152921510058122224 + 8) = 1152921510058122232 (0x1000000144EBDBF8);
            // 0x00BC9204: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC9208: LDR x0, [sp, #8]           | X0 = val_14;                             //  find_add[1152921510058110352]
            // 0x00BC920C: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x00BC9210: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC9214: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x00BC9218: ADD x0, sp, #8             | X0 = (1152921510058122224 + 8) = 1152921510058122232 (0x1000000144EBDBF8);
            // 0x00BC921C: BL #0x299a140              | 
            // 0x00BC9220: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_19 = 0;
            label_14:
            // 0x00BC9224: CBNZ x21, #0xbc922c        | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x00BC9228: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144EBDBF8, ????);
            label_15:
            // 0x00BC922C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC9230: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC9234: MOV x1, x26                | X1 = val_10;//m1                        
            // 0x00BC9238: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC923C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC9240: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9244: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x00BC9248: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC924C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_15 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC9250: MOV x20, x0                | X20 = val_15;//m1                       
            // 0x00BC9254: CBNZ x20, #0xbc925c        | if (val_15 != 0) goto label_16;         
            if(val_15 != 0)
            {
                goto label_16;
            }
            // 0x00BC9258: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_16:
            // 0x00BC925C: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00BC9260: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
            // 0x00BC9264: LDR s8, [x20, #4]          | S8 = val_15 + 4;                        
            // 0x00BC9268: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
            // 0x00BC926C: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
            // 0x00BC9270: TBZ w8, #0, #0xbc9280      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_18;
            // 0x00BC9274: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00BC9278: CBNZ w8, #0xbc9280         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
            // 0x00BC927C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
            label_18:
            // 0x00BC9280: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x00BC9284: LDR x8, [x8, #0x3f8]       | X8 = 1152921510058109328;               
            // 0x00BC9288: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC928C: MOV v0.16b, v8.16b         | V0 = val_15 + 4;//m1                    
            // 0x00BC9290: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x00BC9294: LDR x4, [x8]               | X4 = public static System.UInt32 BehaviourUtil::JSDelayCall<ILRuntime.Runtime.Intepreter.ILTypeInstance, System.Int32>(float delaytime, System.Action<T1, T2> act, ILRuntime.Runtime.Intepreter.ILTypeInstance arg1, System.Int32 arg2);
            // 0x00BC9298: MOV x2, x25                | X2 = 0 (0x0);//ML01                     
            // 0x00BC929C: MOV w3, w22                | W3 = val_3 + 4;//m1                     
            // 0x00BC92A0: BL #0x10cf18c              | X0 = BehaviourUtil.JSDelayCall<System.Object, System.Int32>(delaytime:  val_15 + 4, act:  0, arg1:  val_19, arg2:  0);
            uint val_16 = BehaviourUtil.JSDelayCall<System.Object, System.Int32>(delaytime:  val_15 + 4, act:  0, arg1:  val_19, arg2:  0);
            // 0x00BC92A4: CBZ x19, #0xbc9300         | if (val_2 == 0) goto label_19;          
            if(val_2 == 0)
            {
                goto label_19;
            }
            // 0x00BC92A8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC92AC: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_16;        //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_16;
            // 0x00BC92B0: LDR x0, [x28]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC92B4: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_20 = 8;
            // 0x00BC92B8: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BC92BC: TBZ w9, #0, #0xbc92cc      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_20;
            // 0x00BC92C0: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BC92C4: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BC92C8: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_20 = 219381744;
            label_20:
            // 0x00BC92CC: ADD x0, x8, x19            | X0 = (val_20 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_17 = val_20 + val_2;
            // 0x00BC92D0: SUB sp, x29, #0x60         | SP = (1152921510058122336 - 96) = 1152921510058122240 (0x1000000144EBDC00);
            // 0x00BC92D4: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC92D8: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC92DC: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC92E0: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
            // 0x00BC92E4: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
            // 0x00BC92E8: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
            // 0x00BC92EC: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
            // 0x00BC92F0: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_20 + val_2);
            return val_17;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BC92F4: MOV x19, x0                | X19 = (val_20 + val_2);//m1             
            val_21 = val_17;
            // 0x00BC92F8: MOV x0, sp                 | X0 = 1152921510058122352 (0x1000000144EBDC70);//ML01
            val_22;
            // 0x00BC92FC: B #0xbc9310                |  goto label_21;                         
            goto label_21;
            label_19:
            // 0x00BC9300: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            // 0x00BC9304: BRK #0x1                   | 
            // 0x00BC9308: MOV x19, x0                | X19 = val_16;//m1                       
            val_21 = val_16;
            // 0x00BC930C: ADD x0, sp, #8             | X0 = (1152921510058122224 + 8) = 1152921510058122232 (0x1000000144EBDBF8);
            label_21:
            // 0x00BC9310: BL #0x299a140              | 
            // 0x00BC9314: MOV x0, x19                | X0 = val_16;//m1                        
            // 0x00BC9318: BL #0x980800               | X0 = sub_980800( ?? val_16, ????);      
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC931C (12358428), len: 888  VirtAddr: 0x00BC931C RVA: 0x00BC931C token: 100663847 methodIndex: 29892 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* JSDelayCall_16(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            var val_17;
            //  | 
            ILRuntime.Runtime.Intepreter.ILTypeInstance val_18;
            //  | 
            var val_19;
            //  | 
            var val_20;
            //  | 
            var val_21;
            // 0x00BC931C: STP d9, d8, [sp, #-0x70]!  | stack[1152921510058317184] = ???;  stack[1152921510058317192] = ???;  //  dest_result_addr=1152921510058317184 |  dest_result_addr=1152921510058317192
            // 0x00BC9320: STP x28, x27, [sp, #0x10]  | stack[1152921510058317200] = ???;  stack[1152921510058317208] = ???;  //  dest_result_addr=1152921510058317200 |  dest_result_addr=1152921510058317208
            // 0x00BC9324: STP x26, x25, [sp, #0x20]  | stack[1152921510058317216] = ???;  stack[1152921510058317224] = ???;  //  dest_result_addr=1152921510058317216 |  dest_result_addr=1152921510058317224
            // 0x00BC9328: STP x24, x23, [sp, #0x30]  | stack[1152921510058317232] = ???;  stack[1152921510058317240] = ???;  //  dest_result_addr=1152921510058317232 |  dest_result_addr=1152921510058317240
            // 0x00BC932C: STP x22, x21, [sp, #0x40]  | stack[1152921510058317248] = ???;  stack[1152921510058317256] = ???;  //  dest_result_addr=1152921510058317248 |  dest_result_addr=1152921510058317256
            // 0x00BC9330: STP x20, x19, [sp, #0x50]  | stack[1152921510058317264] = ???;  stack[1152921510058317272] = ???;  //  dest_result_addr=1152921510058317264 |  dest_result_addr=1152921510058317272
            // 0x00BC9334: STP x29, x30, [sp, #0x60]  | stack[1152921510058317280] = ???;  stack[1152921510058317288] = ???;  //  dest_result_addr=1152921510058317280 |  dest_result_addr=1152921510058317288
            // 0x00BC9338: ADD x29, sp, #0x60         | X29 = (1152921510058317184 + 96) = 1152921510058317280 (0x1000000144EED5E0);
            // 0x00BC933C: SUB sp, sp, #0x10          | SP = (1152921510058317184 - 16) = 1152921510058317168 (0x1000000144EED570);
            // 0x00BC9340: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BC9344: LDRB w8, [x19, #0xbaf]     | W8 = (bool)static_value_03733BAF;       
            // 0x00BC9348: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BC934C: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BC9350: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BC9354: TBNZ w8, #0, #0xbc9370     | if (static_value_03733BAF == true) goto label_0;
            // 0x00BC9358: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
            // 0x00BC935C: LDR x8, [x8, #0x8f0]       | X8 = 0x2B8F274;                         
            // 0x00BC9360: LDR w0, [x8]               | W0 = 0x135F;                            
            // 0x00BC9364: BL #0x2782188              | X0 = sub_2782188( ?? 0x135F, ????);     
            // 0x00BC9368: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC936C: STRB w8, [x19, #0xbaf]     | static_value_03733BAF = true;            //  dest_result_addr=57883567
            label_0:
            // 0x00BC9370: CBNZ x21, #0xbc9378        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC9374: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x135F, ????);     
            label_1:
            // 0x00BC9378: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC937C: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC9380: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC9384: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BC9388: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC938C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9390: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BC9394: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC9398: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC939C: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BC93A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC93A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC93A8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC93AC: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC93B0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC93B4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC93B8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC93BC: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
            // 0x00BC93C0: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00BC93C4: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC93C8: LDR x9, [x9, #0xd20]       | X9 = 1152921504825909248;               
            // 0x00BC93CC: LDR x24, [x9]              | X24 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
            // 0x00BC93D0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC93D4: TBZ w9, #0, #0xbc93e8      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BC93D8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC93DC: CBNZ w9, #0xbc93e8         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BC93E0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC93E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BC93E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC93EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC93F0: MOV x1, x24                | X1 = 1152921504825909248 (0x100000000D0EA000);//ML01
            // 0x00BC93F4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC93F8: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
            // 0x00BC93FC: LDR x27, [x27, #0x7a0]     | X27 = 1152921504826228736;              
            // 0x00BC9400: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BC9404: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC9408: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC940C: TBZ w9, #0, #0xbc9420      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BC9410: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC9414: CBNZ w9, #0xbc9420         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BC9418: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC941C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BC9420: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC9424: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC9428: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BC942C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC9430: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BC9434: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC9438: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC943C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC9440: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BC9444: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC9448: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC944C: TBZ w9, #0, #0xbc9460      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BC9450: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC9454: CBNZ w9, #0xbc9460         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BC9458: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC945C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BC9460: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC9464: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9468: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BC946C: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00BC9470: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BC9474: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x00BC9478: CBZ x0, #0xbc94dc          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BC947C: ADRP x9, #0x35dd000        | X9 = 56479744 (0x35DD000);              
            // 0x00BC9480: LDR x9, [x9, #0xb50]       | X9 = 1152921504825909248;               
            // 0x00BC9484: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC9488: LDR x1, [x9]               | X1 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
            // 0x00BC948C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC9490: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC9494: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC9498: B.LO #0xbc94b4             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BC949C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BC94A0: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstanc
            // 0x00BC94A4: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC94A8: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance))
            // 0x00BC94AC: MOV x24, x0                | X24 = val_6;//m1                        
            val_17 = val_6;
            // 0x00BC94B0: B.EQ #0xbc94dc             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BC94B4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC94B8: MOV x8, sp                 | X8 = 1152921510058317168 (0x1000000144EED570);//ML01
            // 0x00BC94BC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC94C0: LDR x0, [sp]               | X0 = val_8;                              //  find_add[1152921510058305296]
            // 0x00BC94C4: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BC94C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC94CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BC94D0: MOV x0, sp                 | X0 = 1152921510058317168 (0x1000000144EED570);//ML01
            // 0x00BC94D4: BL #0x299a140              | 
            // 0x00BC94D8: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_17 = 0;
            label_10:
            // 0x00BC94DC: CBNZ x21, #0xbc94e4        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BC94E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144EED570, ????);
            label_11:
            // 0x00BC94E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC94E8: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC94EC: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BC94F0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC94F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC94F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC94FC: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC9500: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC9504: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC9508: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x00BC950C: LDR x8, [x8, #0xd40]       | X8 = 1152921504657965056;               
            // 0x00BC9510: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x00BC9514: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC9518: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC951C: LDR x1, [x8]               | X1 = typeof(System.Action<T>);          
            // 0x00BC9520: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC9524: MOV x26, x0                | X26 = val_10;//m1                       
            // 0x00BC9528: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC952C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC9530: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x00BC9534: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC9538: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BC953C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_11 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC9540: MOV x2, x0                 | X2 = val_11;//m1                        
            // 0x00BC9544: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC9548: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC954C: MOV x1, x26                | X1 = val_10;//m1                        
            // 0x00BC9550: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            object val_12 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            // 0x00BC9554: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_18 = 0;
            // 0x00BC9558: CBZ x0, #0xbc95a0          | if (val_12 == null) goto label_13;      
            if(val_12 == null)
            {
                goto label_13;
            }
            // 0x00BC955C: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x00BC9560: LDR x8, [x8, #0x90]        | X8 = 1152921504657965056;               
            // 0x00BC9564: LDR x1, [x8]               | X1 = typeof(System.Action<T>);          
            // 0x00BC9568: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC956C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.Action<T>))
            // 0x00BC9570: MOV x22, x0                | X22 = val_12;//m1                       
            val_18 = val_12;
            // 0x00BC9574: B.EQ #0xbc95a0             | if (typeof(System.Object) == null) goto label_13;
            if(null == null)
            {
                goto label_13;
            }
            // 0x00BC9578: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC957C: ADD x8, sp, #8             | X8 = (1152921510058317168 + 8) = 1152921510058317176 (0x1000000144EED578);
            // 0x00BC9580: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC9584: LDR x0, [sp, #8]           | X0 = val_13;                             //  find_add[1152921510058305296]
            // 0x00BC9588: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x00BC958C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC9590: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x00BC9594: ADD x0, sp, #8             | X0 = (1152921510058317168 + 8) = 1152921510058317176 (0x1000000144EED578);
            // 0x00BC9598: BL #0x299a140              | 
            // 0x00BC959C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_18 = 0;
            label_13:
            // 0x00BC95A0: CBNZ x21, #0xbc95a8        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00BC95A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144EED578, ????);
            label_14:
            // 0x00BC95A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC95AC: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC95B0: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x00BC95B4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC95B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC95BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC95C0: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BC95C4: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC95C8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_14 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC95CC: MOV x20, x0                | X20 = val_14;//m1                       
            // 0x00BC95D0: CBNZ x20, #0xbc95d8        | if (val_14 != 0) goto label_15;         
            if(val_14 != 0)
            {
                goto label_15;
            }
            // 0x00BC95D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_15:
            // 0x00BC95D8: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00BC95DC: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
            // 0x00BC95E0: LDR s8, [x20, #4]          | S8 = val_14 + 4;                        
            // 0x00BC95E4: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
            // 0x00BC95E8: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
            // 0x00BC95EC: TBZ w8, #0, #0xbc95fc      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_17;
            // 0x00BC95F0: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00BC95F4: CBNZ w8, #0xbc95fc         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
            // 0x00BC95F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
            label_17:
            // 0x00BC95FC: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x00BC9600: LDR x8, [x8, #0x7c0]       | X8 = 1152921510058304272;               
            // 0x00BC9604: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC9608: MOV v0.16b, v8.16b         | V0 = val_14 + 4;//m1                    
            // 0x00BC960C: MOV x1, x22                | X1 = 0 (0x0);//ML01                     
            // 0x00BC9610: LDR x3, [x8]               | X3 = public static System.UInt32 BehaviourUtil::JSDelayCall<ILRuntime.Runtime.Intepreter.ILTypeInstance>(float delaytime, System.Action<T> act, ILRuntime.Runtime.Intepreter.ILTypeInstance arg1);
            // 0x00BC9614: MOV x2, x24                | X2 = 0 (0x0);//ML01                     
            // 0x00BC9618: BL #0x10cf50c              | X0 = BehaviourUtil.JSDelayCall<ILRuntime.Runtime.Intepreter.ILTypeInstance>(delaytime:  val_14 + 4, act:  0, arg1:  val_18);
            uint val_15 = BehaviourUtil.JSDelayCall<ILRuntime.Runtime.Intepreter.ILTypeInstance>(delaytime:  val_14 + 4, act:  0, arg1:  val_18);
            // 0x00BC961C: CBZ x19, #0xbc9678         | if (val_2 == 0) goto label_18;          
            if(val_2 == 0)
            {
                goto label_18;
            }
            // 0x00BC9620: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC9624: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_15;        //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_15;
            // 0x00BC9628: LDR x0, [x27]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC962C: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_19 = 8;
            // 0x00BC9630: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BC9634: TBZ w9, #0, #0xbc9644      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_19;
            // 0x00BC9638: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BC963C: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BC9640: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_19 = 219381744;
            label_19:
            // 0x00BC9644: ADD x0, x8, x19            | X0 = (val_19 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_16 = val_19 + val_2;
            // 0x00BC9648: SUB sp, x29, #0x60         | SP = (1152921510058317280 - 96) = 1152921510058317184 (0x1000000144EED580);
            // 0x00BC964C: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC9650: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC9654: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC9658: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
            // 0x00BC965C: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
            // 0x00BC9660: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
            // 0x00BC9664: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
            // 0x00BC9668: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_19 + val_2);
            return val_16;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BC966C: MOV x19, x0                | X19 = (val_19 + val_2);//m1             
            val_20 = val_16;
            // 0x00BC9670: MOV x0, sp                 | X0 = 1152921510058317296 (0x1000000144EED5F0);//ML01
            val_21;
            // 0x00BC9674: B #0xbc9688                |  goto label_20;                         
            goto label_20;
            label_18:
            // 0x00BC9678: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            // 0x00BC967C: BRK #0x1                   | 
            // 0x00BC9680: MOV x19, x0                | X19 = val_15;//m1                       
            val_20 = val_15;
            // 0x00BC9684: ADD x0, sp, #8             | X0 = (1152921510058317168 + 8) = 1152921510058317176 (0x1000000144EED578);
            label_20:
            // 0x00BC9688: BL #0x299a140              | 
            // 0x00BC968C: MOV x0, x19                | X0 = val_15;//m1                        
            // 0x00BC9690: BL #0x980800               | X0 = sub_980800( ?? val_15, ????);      
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC9694 (12359316), len: 688  VirtAddr: 0x00BC9694 RVA: 0x00BC9694 token: 100663848 methodIndex: 29893 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* JSDelayCall_17(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_12;
            //  | 
            var val_13;
            // 0x00BC9694: STP d9, d8, [sp, #-0x70]!  | stack[1152921510058499840] = ???;  stack[1152921510058499848] = ???;  //  dest_result_addr=1152921510058499840 |  dest_result_addr=1152921510058499848
            // 0x00BC9698: STP x28, x27, [sp, #0x10]  | stack[1152921510058499856] = ???;  stack[1152921510058499864] = ???;  //  dest_result_addr=1152921510058499856 |  dest_result_addr=1152921510058499864
            // 0x00BC969C: STP x26, x25, [sp, #0x20]  | stack[1152921510058499872] = ???;  stack[1152921510058499880] = ???;  //  dest_result_addr=1152921510058499872 |  dest_result_addr=1152921510058499880
            // 0x00BC96A0: STP x24, x23, [sp, #0x30]  | stack[1152921510058499888] = ???;  stack[1152921510058499896] = ???;  //  dest_result_addr=1152921510058499888 |  dest_result_addr=1152921510058499896
            // 0x00BC96A4: STP x22, x21, [sp, #0x40]  | stack[1152921510058499904] = ???;  stack[1152921510058499912] = ???;  //  dest_result_addr=1152921510058499904 |  dest_result_addr=1152921510058499912
            // 0x00BC96A8: STP x20, x19, [sp, #0x50]  | stack[1152921510058499920] = ???;  stack[1152921510058499928] = ???;  //  dest_result_addr=1152921510058499920 |  dest_result_addr=1152921510058499928
            // 0x00BC96AC: STP x29, x30, [sp, #0x60]  | stack[1152921510058499936] = ???;  stack[1152921510058499944] = ???;  //  dest_result_addr=1152921510058499936 |  dest_result_addr=1152921510058499944
            // 0x00BC96B0: ADD x29, sp, #0x60         | X29 = (1152921510058499840 + 96) = 1152921510058499936 (0x1000000144F19F60);
            // 0x00BC96B4: SUB sp, sp, #0x10          | SP = (1152921510058499840 - 16) = 1152921510058499824 (0x1000000144F19EF0);
            // 0x00BC96B8: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BC96BC: LDRB w8, [x19, #0xbb0]     | W8 = (bool)static_value_03733BB0;       
            // 0x00BC96C0: MOV x24, x3                | X24 = X3;//m1                           
            // 0x00BC96C4: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BC96C8: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BC96CC: TBNZ w8, #0, #0xbc96e8     | if (static_value_03733BB0 == true) goto label_0;
            // 0x00BC96D0: ADRP x8, #0x367e000        | X8 = 57139200 (0x367E000);              
            // 0x00BC96D4: LDR x8, [x8, #0x108]       | X8 = 0x2B8F278;                         
            // 0x00BC96D8: LDR w0, [x8]               | W0 = 0x1360;                            
            // 0x00BC96DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1360, ????);     
            // 0x00BC96E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC96E4: STRB w8, [x19, #0xbb0]     | static_value_03733BB0 = true;            //  dest_result_addr=57883568
            label_0:
            // 0x00BC96E8: CBNZ x21, #0xbc96f0        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC96EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1360, ????);     
            label_1:
            // 0x00BC96F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC96F4: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC96F8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC96FC: MOV x25, x0                | X25 = val_1;//m1                        
            // 0x00BC9700: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC9704: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9708: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BC970C: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC9710: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC9714: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BC9718: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC971C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9720: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC9724: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC9728: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC972C: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00BC9730: CBNZ x22, #0xbc9738        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BC9734: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BC9738: LDR w22, [x22, #4]         | W22 = val_3 + 4;                        
            // 0x00BC973C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC9740: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9744: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC9748: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC974C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC9750: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC9754: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC9758: ADRP x9, #0x365f000        | X9 = 57012224 (0x365F000);              
            // 0x00BC975C: MOV x23, x0                | X23 = val_4;//m1                        
            // 0x00BC9760: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC9764: LDR x9, [x9, #0xa88]       | X9 = 1152921504657965056;               
            // 0x00BC9768: LDR x26, [x9]              | X26 = typeof(System.Action<T>);         
            // 0x00BC976C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC9770: TBZ w9, #0, #0xbc9784      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00BC9774: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC9778: CBNZ w9, #0xbc9784         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00BC977C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC9780: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x00BC9784: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC9788: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC978C: MOV x1, x26                | X1 = 1152921504657965056 (0x10000000030C0000);//ML01
            // 0x00BC9790: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC9794: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
            // 0x00BC9798: LDR x27, [x27, #0x7a0]     | X27 = 1152921504826228736;              
            // 0x00BC979C: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BC97A0: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC97A4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC97A8: TBZ w9, #0, #0xbc97bc      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00BC97AC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC97B0: CBNZ w9, #0xbc97bc         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00BC97B4: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC97B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x00BC97BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC97C0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC97C4: MOV x1, x23                | X1 = val_4;//m1                         
            // 0x00BC97C8: MOV x2, x25                | X2 = val_1;//m1                         
            // 0x00BC97CC: MOV x3, x24                | X3 = X3;//m1                            
            // 0x00BC97D0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC97D4: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC97D8: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC97DC: MOV x24, x0                | X24 = val_6;//m1                        
            // 0x00BC97E0: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC97E4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC97E8: TBZ w9, #0, #0xbc97fc      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00BC97EC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC97F0: CBNZ w9, #0xbc97fc         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00BC97F4: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC97F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x00BC97FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC9800: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9804: MOV x1, x26                | X1 = val_5;//m1                         
            // 0x00BC9808: MOV x2, x24                | X2 = val_6;//m1                         
            // 0x00BC980C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x00BC9810: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_12 = 0;
            // 0x00BC9814: CBZ x0, #0xbc985c          | if (val_7 == null) goto label_10;       
            if(val_7 == null)
            {
                goto label_10;
            }
            // 0x00BC9818: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
            // 0x00BC981C: LDR x8, [x8, #0x5e8]       | X8 = 1152921504657965056;               
            // 0x00BC9820: LDR x1, [x8]               | X1 = typeof(System.Action<T>);          
            // 0x00BC9824: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC9828: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.Action<T>))
            // 0x00BC982C: MOV x24, x0                | X24 = val_7;//m1                        
            val_12 = val_7;
            // 0x00BC9830: B.EQ #0xbc985c             | if (typeof(System.Object) == null) goto label_10;
            if(null == null)
            {
                goto label_10;
            }
            // 0x00BC9834: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC9838: ADD x8, sp, #8             | X8 = (1152921510058499824 + 8) = 1152921510058499832 (0x1000000144F19EF8);
            // 0x00BC983C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC9840: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510058487952]
            // 0x00BC9844: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BC9848: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC984C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BC9850: ADD x0, sp, #8             | X0 = (1152921510058499824 + 8) = 1152921510058499832 (0x1000000144F19EF8);
            // 0x00BC9854: BL #0x299a140              | 
            // 0x00BC9858: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_12 = 0;
            label_10:
            // 0x00BC985C: CBNZ x21, #0xbc9864        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BC9860: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144F19EF8, ????);
            label_11:
            // 0x00BC9864: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC9868: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BC986C: MOV x1, x23                | X1 = val_4;//m1                         
            // 0x00BC9870: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC9874: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC9878: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC987C: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BC9880: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BC9884: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC9888: MOV x20, x0                | X20 = val_9;//m1                        
            // 0x00BC988C: CBNZ x20, #0xbc9894        | if (val_9 != 0) goto label_12;          
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x00BC9890: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_12:
            // 0x00BC9894: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00BC9898: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
            // 0x00BC989C: LDR s8, [x20, #4]          | S8 = val_9 + 4;                         
            // 0x00BC98A0: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
            // 0x00BC98A4: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
            // 0x00BC98A8: TBZ w8, #0, #0xbc98b8      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x00BC98AC: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00BC98B0: CBNZ w8, #0xbc98b8         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x00BC98B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
            label_14:
            // 0x00BC98B8: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
            // 0x00BC98BC: LDR x8, [x8, #0x620]       | X8 = 1152921510058486928;               
            // 0x00BC98C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC98C4: MOV v0.16b, v8.16b         | V0 = val_9 + 4;//m1                     
            // 0x00BC98C8: MOV x1, x24                | X1 = 0 (0x0);//ML01                     
            // 0x00BC98CC: LDR x3, [x8]               | X3 = public static System.UInt32 BehaviourUtil::JSDelayCall<System.Int32>(float delaytime, System.Action<T> act, System.Int32 arg1);
            // 0x00BC98D0: MOV w2, w22                | W2 = val_3 + 4;//m1                     
            // 0x00BC98D4: BL #0x10cf0c4              | X0 = BehaviourUtil.JSDelayCall<System.Int32>(delaytime:  val_9 + 4, act:  0, arg1:  0);
            uint val_10 = BehaviourUtil.JSDelayCall<System.Int32>(delaytime:  val_9 + 4, act:  0, arg1:  0);
            // 0x00BC98D8: CBZ x19, #0xbc9928         | if (val_2 == 0) goto label_15;          
            if(val_2 == 0)
            {
                goto label_15;
            }
            // 0x00BC98DC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC98E0: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_10;        //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_10;
            // 0x00BC98E4: LDR x0, [x27]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC98E8: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_13 = 8;
            // 0x00BC98EC: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BC98F0: TBZ w9, #0, #0xbc9900      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_16;
            // 0x00BC98F4: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BC98F8: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BC98FC: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_13 = 219381744;
            label_16:
            // 0x00BC9900: ADD x0, x8, x19            | X0 = (val_13 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_11 = val_13 + val_2;
            // 0x00BC9904: SUB sp, x29, #0x60         | SP = (1152921510058499936 - 96) = 1152921510058499840 (0x1000000144F19F00);
            // 0x00BC9908: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC990C: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC9910: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC9914: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
            // 0x00BC9918: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
            // 0x00BC991C: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
            // 0x00BC9920: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
            // 0x00BC9924: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_13 + val_2);
            return val_11;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            label_15:
            // 0x00BC9928: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            // 0x00BC992C: BRK #0x1                   | 
            // 0x00BC9930: MOV x19, x0                | X19 = val_10;//m1                       
            // 0x00BC9934: ADD x0, sp, #8             | X0 = (1152921510058499824 + 8) = 1152921510058499832 (0x1000000144F19EF8);
            // 0x00BC9938: BL #0x299a140              | 
            // 0x00BC993C: MOV x0, x19                | X0 = val_10;//m1                        
            // 0x00BC9940: BL #0x980800               | X0 = sub_980800( ?? val_10, ????);      
        
        }
    
    }

}
