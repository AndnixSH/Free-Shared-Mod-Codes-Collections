using UnityEngine;

namespace wxb
{
    public class CoroutineAdapter : CrossBindingAdaptor
    {
        // Properties
        public override System.Type BaseCLRType { get; }
        public override System.Type[] BaseCLRTypes { get; }
        public override System.Type AdaptorType { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2FA40 (14875200), len: 8  VirtAddr: 0x00E2FA40 RVA: 0x00E2FA40 token: 100680996 methodIndex: 57321 delegateWrapperIndex: 0 methodInvoker: 0
        public CoroutineAdapter()
        {
            //
            // Disasemble & Code
            // 0x00E2FA40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2FA44: B #0x28ef918               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2FA48 (14875208), len: 8  VirtAddr: 0x00E2FA48 RVA: 0x00E2FA48 token: 100680997 methodIndex: 57322 delegateWrapperIndex: 0 methodInvoker: 0
        public override System.Type get_BaseCLRType()
        {
            //
            // Disasemble & Code
            // 0x00E2FA48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E2FA4C: RET                        |  return (System.Type)null;              
            return (System.Type)0;
            //  |  // // {name=val_0, type=System.Type, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2FA50 (14875216), len: 420  VirtAddr: 0x00E2FA50 RVA: 0x00E2FA50 token: 100680998 methodIndex: 57323 delegateWrapperIndex: 0 methodInvoker: 0
        public override System.Type[] get_BaseCLRTypes()
        {
            //
            // Disasemble & Code
            // 0x00E2FA50: STP x20, x19, [sp, #-0x20]! | stack[1152921512998274208] = ???;  stack[1152921512998274216] = ???;  //  dest_result_addr=1152921512998274208 |  dest_result_addr=1152921512998274216
            // 0x00E2FA54: STP x29, x30, [sp, #0x10]  | stack[1152921512998274224] = ???;  stack[1152921512998274232] = ???;  //  dest_result_addr=1152921512998274224 |  dest_result_addr=1152921512998274232
            // 0x00E2FA58: ADD x29, sp, #0x10         | X29 = (1152921512998274208 + 16) = 1152921512998274224 (0x10000001F42B04B0);
            // 0x00E2FA5C: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00E2FA60: LDRB w8, [x19, #0x93c]     | W8 = (bool)static_value_0373493C;       
            // 0x00E2FA64: TBNZ w8, #0, #0xe2fa80     | if (static_value_0373493C == true) goto label_0;
            // 0x00E2FA68: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x00E2FA6C: LDR x8, [x8, #0x9d8]       | X8 = 0x2B92D48;                         
            // 0x00E2FA70: LDR w0, [x8]               | W0 = 0x2217;                            
            // 0x00E2FA74: BL #0x2782188              | X0 = sub_2782188( ?? 0x2217, ????);     
            // 0x00E2FA78: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2FA7C: STRB w8, [x19, #0x93c]     | static_value_0373493C = true;            //  dest_result_addr=57887036
            label_0:
            // 0x00E2FA80: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x00E2FA84: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x00E2FA88: LDR x19, [x8]              | X19 = typeof(System.Type[]);            
            // 0x00E2FA8C: MOV x0, x19                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00E2FA90: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00E2FA94: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x00E2FA98: MOV x0, x19                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00E2FA9C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00E2FAA0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00E2FAA4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00E2FAA8: ADRP x9, #0x366f000        | X9 = 57077760 (0x366F000);              
            // 0x00E2FAAC: MOV x19, x0                | X19 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00E2FAB0: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00E2FAB4: LDR x9, [x9, #0x78]        | X9 = 1152921504608178176;               
            // 0x00E2FAB8: LDR x20, [x9]              | X20 = typeof(System.Collections.Generic.IEnumerator<T>);
            // 0x00E2FABC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00E2FAC0: TBZ w9, #0, #0xe2fad4      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E2FAC4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00E2FAC8: CBNZ w9, #0xe2fad4         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E2FACC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00E2FAD0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00E2FAD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E2FAD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2FADC: MOV x1, x20                | X1 = 1152921504608178176 (0x1000000000145000);//ML01
            // 0x00E2FAE0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00E2FAE4: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00E2FAE8: CBNZ x19, #0xe2faf0        | if ( != null) goto label_3;             
            if(null != null)
            {
                goto label_3;
            }
            // 0x00E2FAEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x00E2FAF0: CBZ x20, #0xe2fb14         | if (val_1 == null) goto label_5;        
            if(val_1 == null)
            {
                goto label_5;
            }
            // 0x00E2FAF4: LDR x8, [x19]              | X8 = ;                                  
            // 0x00E2FAF8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00E2FAFC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00E2FB00: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_1, ????);      
            // 0x00E2FB04: CBNZ x0, #0xe2fb14         | if (val_1 != null) goto label_5;        
            if(val_1 != null)
            {
                goto label_5;
            }
            // 0x00E2FB08: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_1, ????);      
            // 0x00E2FB0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2FB10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            label_5:
            // 0x00E2FB14: LDR w8, [x19, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00E2FB18: CBNZ w8, #0xe2fb28         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_6;
            // 0x00E2FB1C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x00E2FB20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2FB24: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            label_6:
            // 0x00E2FB28: STR x20, [x19, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_1;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_1;
            // 0x00E2FB2C: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
            // 0x00E2FB30: LDR x8, [x8, #0x458]       | X8 = 1152921504608018432;               
            // 0x00E2FB34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E2FB38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2FB3C: LDR x1, [x8]               | X1 = typeof(System.Collections.IEnumerator);
            // 0x00E2FB40: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_2 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00E2FB44: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00E2FB48: CBZ x20, #0xe2fb6c         | if (val_2 == null) goto label_8;        
            if(val_2 == null)
            {
                goto label_8;
            }
            // 0x00E2FB4C: LDR x8, [x19]              | X8 = ;                                  
            // 0x00E2FB50: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00E2FB54: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00E2FB58: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x00E2FB5C: CBNZ x0, #0xe2fb6c         | if (val_2 != null) goto label_8;        
            if(val_2 != null)
            {
                goto label_8;
            }
            // 0x00E2FB60: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
            // 0x00E2FB64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2FB68: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_8:
            // 0x00E2FB6C: LDR w8, [x19, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00E2FB70: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00E2FB74: B.HI #0xe2fb84             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_9;
            // 0x00E2FB78: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x00E2FB7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2FB80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_9:
            // 0x00E2FB84: STR x20, [x19, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_2;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_2;
            // 0x00E2FB88: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
            // 0x00E2FB8C: LDR x8, [x8, #0x6f8]       | X8 = 1152921504608124928;               
            // 0x00E2FB90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E2FB94: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2FB98: LDR x1, [x8]               | X1 = typeof(System.IDisposable);        
            // 0x00E2FB9C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00E2FBA0: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x00E2FBA4: CBZ x20, #0xe2fbc8         | if (val_3 == null) goto label_11;       
            if(val_3 == null)
            {
                goto label_11;
            }
            // 0x00E2FBA8: LDR x8, [x19]              | X8 = ;                                  
            // 0x00E2FBAC: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x00E2FBB0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00E2FBB4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x00E2FBB8: CBNZ x0, #0xe2fbc8         | if (val_3 != null) goto label_11;       
            if(val_3 != null)
            {
                goto label_11;
            }
            // 0x00E2FBBC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_3, ????);      
            // 0x00E2FBC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2FBC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_11:
            // 0x00E2FBC8: LDR w8, [x19, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00E2FBCC: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x00E2FBD0: B.HI #0xe2fbe0             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_12;
            // 0x00E2FBD4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
            // 0x00E2FBD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2FBDC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_12:
            // 0x00E2FBE0: STR x20, [x19, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_3;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_3;
            // 0x00E2FBE4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2FBE8: MOV x0, x19                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00E2FBEC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2FBF0: RET                        |  return (System.Type[])typeof(System.Type[]);
            return (System.Type[])null;
            //  |  // // {name=val_0, type=System.Type[], size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2FBF4 (14875636), len: 116  VirtAddr: 0x00E2FBF4 RVA: 0x00E2FBF4 token: 100680999 methodIndex: 57324 delegateWrapperIndex: 0 methodInvoker: 0
        public override System.Type get_AdaptorType()
        {
            //
            // Disasemble & Code
            // 0x00E2FBF4: STP x20, x19, [sp, #-0x20]! | stack[1152921512998398496] = ???;  stack[1152921512998398504] = ???;  //  dest_result_addr=1152921512998398496 |  dest_result_addr=1152921512998398504
            // 0x00E2FBF8: STP x29, x30, [sp, #0x10]  | stack[1152921512998398512] = ???;  stack[1152921512998398520] = ???;  //  dest_result_addr=1152921512998398512 |  dest_result_addr=1152921512998398520
            // 0x00E2FBFC: ADD x29, sp, #0x10         | X29 = (1152921512998398496 + 16) = 1152921512998398512 (0x10000001F42CEA30);
            // 0x00E2FC00: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00E2FC04: LDRB w8, [x19, #0x93d]     | W8 = (bool)static_value_0373493D;       
            // 0x00E2FC08: TBNZ w8, #0, #0xe2fc24     | if (static_value_0373493D == true) goto label_0;
            // 0x00E2FC0C: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
            // 0x00E2FC10: LDR x8, [x8, #0xc90]       | X8 = 0x2B92D40;                         
            // 0x00E2FC14: LDR w0, [x8]               | W0 = 0x2215;                            
            // 0x00E2FC18: BL #0x2782188              | X0 = sub_2782188( ?? 0x2215, ????);     
            // 0x00E2FC1C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2FC20: STRB w8, [x19, #0x93d]     | static_value_0373493D = true;            //  dest_result_addr=57887037
            label_0:
            // 0x00E2FC24: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00E2FC28: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00E2FC2C: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x00E2FC30: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x00E2FC34: LDR x8, [x8, #0xb0]        | X8 = 1152921504828891136;               
            // 0x00E2FC38: LDR x19, [x8]              | X19 = typeof(CoroutineAdapter.Adaptor); 
            // 0x00E2FC3C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00E2FC40: TBZ w8, #0, #0xe2fc50      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E2FC44: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00E2FC48: CBNZ w8, #0xe2fc50         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E2FC4C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00E2FC50: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2FC54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E2FC58: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2FC5C: MOV x1, x19                | X1 = 1152921504828891136 (0x100000000D3C2000);//ML01
            // 0x00E2FC60: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2FC64: B #0x1b6d31c               | return System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            return System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2FC68 (14875752), len: 112  VirtAddr: 0x00E2FC68 RVA: 0x00E2FC68 token: 100681000 methodIndex: 57325 delegateWrapperIndex: 0 methodInvoker: 0
        public override object CreateCLRInstance(ILRuntime.Runtime.Enviorment.AppDomain appdomain, ILRuntime.Runtime.Intepreter.ILTypeInstance instance)
        {
            //
            // Disasemble & Code
            // 0x00E2FC68: STP x22, x21, [sp, #-0x30]! | stack[1152921512998518672] = ???;  stack[1152921512998518680] = ???;  //  dest_result_addr=1152921512998518672 |  dest_result_addr=1152921512998518680
            // 0x00E2FC6C: STP x20, x19, [sp, #0x10]  | stack[1152921512998518688] = ???;  stack[1152921512998518696] = ???;  //  dest_result_addr=1152921512998518688 |  dest_result_addr=1152921512998518696
            // 0x00E2FC70: STP x29, x30, [sp, #0x20]  | stack[1152921512998518704] = ???;  stack[1152921512998518712] = ???;  //  dest_result_addr=1152921512998518704 |  dest_result_addr=1152921512998518712
            // 0x00E2FC74: ADD x29, sp, #0x20         | X29 = (1152921512998518672 + 32) = 1152921512998518704 (0x10000001F42EBFB0);
            // 0x00E2FC78: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2FC7C: LDRB w8, [x21, #0x93e]     | W8 = (bool)static_value_0373493E;       
            // 0x00E2FC80: MOV x19, x2                | X19 = instance;//m1                     
            // 0x00E2FC84: MOV x20, x1                | X20 = appdomain;//m1                    
            // 0x00E2FC88: TBNZ w8, #0, #0xe2fca4     | if (static_value_0373493E == true) goto label_0;
            // 0x00E2FC8C: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x00E2FC90: LDR x8, [x8, #0xaf8]       | X8 = 0x2B92D38;                         
            // 0x00E2FC94: LDR w0, [x8]               | W0 = 0x2213;                            
            // 0x00E2FC98: BL #0x2782188              | X0 = sub_2782188( ?? 0x2213, ????);     
            // 0x00E2FC9C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2FCA0: STRB w8, [x21, #0x93e]     | static_value_0373493E = true;            //  dest_result_addr=57887038
            label_0:
            // 0x00E2FCA4: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
            // 0x00E2FCA8: LDR x8, [x8, #0xdd0]       | X8 = 1152921504828891136;               
            // 0x00E2FCAC: LDR x0, [x8]               | X0 = typeof(CoroutineAdapter.Adaptor);  
            object val_1 = null;
            // 0x00E2FCB0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CoroutineAdapter.Adaptor), ????);
            // 0x00E2FCB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2FCB8: MOV x21, x0                | X21 = 1152921504828891136 (0x100000000D3C2000);//ML01
            // 0x00E2FCBC: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x00E2FCC0: STP x19, x20, [x21, #0x10] | typeof(CoroutineAdapter.Adaptor).__il2cppRuntimeField_10 = instance;  typeof(CoroutineAdapter.Adaptor).__il2cppRuntimeField_18 = appdomain;  //  dest_result_addr=1152921504828891152 |  dest_result_addr=1152921504828891160
            typeof(CoroutineAdapter.Adaptor).__il2cppRuntimeField_10 = instance;
            typeof(CoroutineAdapter.Adaptor).__il2cppRuntimeField_18 = appdomain;
            // 0x00E2FCC4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2FCC8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2FCCC: MOV x0, x21                | X0 = 1152921504828891136 (0x100000000D3C2000);//ML01
            // 0x00E2FCD0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2FCD4: RET                        |  return (System.Object)typeof(CoroutineAdapter.Adaptor);
            return (object)val_1;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
    
    }

}
