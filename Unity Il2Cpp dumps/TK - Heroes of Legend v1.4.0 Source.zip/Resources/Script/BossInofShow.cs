using UnityEngine;
public class BossInofShow : MonoBehaviour
{
    // Fields
    [UnityEngine.HideInInspector] // 0x286B794
    public UnityEngine.Camera bossCamera; //  0x00000018
    private UnityEngine.GameObject _obj_left; //  0x00000020
    private UnityEngine.GameObject _obj_right; //  0x00000028
    private UISprite _boss_name_Left; //  0x00000030
    private UISprite _boss_name_right; //  0x00000038
    private int type; //  0x00000040
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B96C7C (12151932), len: 8  VirtAddr: 0x00B96C7C RVA: 0x00B96C7C token: 100690200 methodIndex: 25254 delegateWrapperIndex: 0 methodInvoker: 0
    public BossInofShow()
    {
        //
        // Disasemble & Code
        // 0x00B96C7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96C80: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B96C84 (12151940), len: 456  VirtAddr: 0x00B96C84 RVA: 0x00B96C84 token: 100690201 methodIndex: 25255 delegateWrapperIndex: 0 methodInvoker: 0
    public void Awake()
    {
        //
        // Disasemble & Code
        // 0x00B96C84: STP x22, x21, [sp, #-0x30]! | stack[1152921514486204480] = ???;  stack[1152921514486204488] = ???;  //  dest_result_addr=1152921514486204480 |  dest_result_addr=1152921514486204488
        // 0x00B96C88: STP x20, x19, [sp, #0x10]  | stack[1152921514486204496] = ???;  stack[1152921514486204504] = ???;  //  dest_result_addr=1152921514486204496 |  dest_result_addr=1152921514486204504
        // 0x00B96C8C: STP x29, x30, [sp, #0x20]  | stack[1152921514486204512] = ???;  stack[1152921514486204520] = ???;  //  dest_result_addr=1152921514486204512 |  dest_result_addr=1152921514486204520
        // 0x00B96C90: ADD x29, sp, #0x20         | X29 = (1152921514486204480 + 32) = 1152921514486204512 (0x100000024CDB0860);
        // 0x00B96C94: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B96C98: LDRB w8, [x20, #0xa76]     | W8 = (bool)static_value_03733A76;       
        // 0x00B96C9C: MOV x19, x0                | X19 = 1152921514486216528 (0x100000024CDB3750);//ML01
        // 0x00B96CA0: TBNZ w8, #0, #0xb96cbc     | if (static_value_03733A76 == true) goto label_0;
        // 0x00B96CA4: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x00B96CA8: LDR x8, [x8, #0x170]       | X8 = 0x2B8F8F8;                         
        // 0x00B96CAC: LDR w0, [x8]               | W0 = 0x1502;                            
        // 0x00B96CB0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1502, ????);     
        // 0x00B96CB4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B96CB8: STRB w8, [x20, #0xa76]     | static_value_03733A76 = true;            //  dest_result_addr=57883254
        label_0:
        // 0x00B96CBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96CC0: MOV x0, x19                | X0 = 1152921514486216528 (0x100000024CDB3750);//ML01
        // 0x00B96CC4: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_1 = this.transform;
        // 0x00B96CC8: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B96CCC: CBNZ x20, #0xb96cd4        | if (val_1 != null) goto label_1;        
        if(val_1 != null)
        {
            goto label_1;
        }
        // 0x00B96CD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x00B96CD4: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
        // 0x00B96CD8: LDR x8, [x8, #0x130]       | X8 = (string**)(1152921514486130640)("Texture_bj_left");
        // 0x00B96CDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B96CE0: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B96CE4: LDR x1, [x8]               | X1 = "Texture_bj_left";                 
        // 0x00B96CE8: BL #0x2695ac0              | X0 = val_1.Find(name:  "Texture_bj_left");
        UnityEngine.Transform val_2 = val_1.Find(name:  "Texture_bj_left");
        // 0x00B96CEC: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B96CF0: CBNZ x20, #0xb96cf8        | if (val_2 != null) goto label_2;        
        if(val_2 != null)
        {
            goto label_2;
        }
        // 0x00B96CF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_2:
        // 0x00B96CF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96CFC: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B96D00: BL #0x20d50fc              | X0 = val_2.get_gameObject();            
        UnityEngine.GameObject val_3 = val_2.gameObject;
        // 0x00B96D04: STR x0, [x19, #0x20]       | this._obj_left = val_3;                  //  dest_result_addr=1152921514486216560
        this._obj_left = val_3;
        // 0x00B96D08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96D0C: MOV x0, x19                | X0 = 1152921514486216528 (0x100000024CDB3750);//ML01
        // 0x00B96D10: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_4 = this.transform;
        // 0x00B96D14: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B96D18: CBNZ x20, #0xb96d20        | if (val_4 != null) goto label_3;        
        if(val_4 != null)
        {
            goto label_3;
        }
        // 0x00B96D1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_3:
        // 0x00B96D20: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
        // 0x00B96D24: LDR x8, [x8, #0x298]       | X8 = (string**)(1152921514486143040)("Texture_bj_right");
        // 0x00B96D28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B96D2C: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x00B96D30: LDR x1, [x8]               | X1 = "Texture_bj_right";                
        // 0x00B96D34: BL #0x2695ac0              | X0 = val_4.Find(name:  "Texture_bj_right");
        UnityEngine.Transform val_5 = val_4.Find(name:  "Texture_bj_right");
        // 0x00B96D38: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00B96D3C: CBNZ x20, #0xb96d44        | if (val_5 != null) goto label_4;        
        if(val_5 != null)
        {
            goto label_4;
        }
        // 0x00B96D40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_4:
        // 0x00B96D44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96D48: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00B96D4C: BL #0x20d50fc              | X0 = val_5.get_gameObject();            
        UnityEngine.GameObject val_6 = val_5.gameObject;
        // 0x00B96D50: LDR x20, [x19, #0x20]      | X20 = this._obj_left; //P2              
        // 0x00B96D54: STR x0, [x19, #0x28]       | this._obj_right = val_6;                 //  dest_result_addr=1152921514486216568
        this._obj_right = val_6;
        // 0x00B96D58: CBNZ x20, #0xb96d60        | if (this._obj_left != null) goto label_5;
        if(this._obj_left != null)
        {
            goto label_5;
        }
        // 0x00B96D5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_5:
        // 0x00B96D60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96D64: MOV x0, x20                | X0 = this._obj_left;//m1                
        // 0x00B96D68: BL #0x1a62c1c              | X0 = this._obj_left.get_transform();    
        UnityEngine.Transform val_7 = this._obj_left.transform;
        // 0x00B96D6C: MOV x20, x0                | X20 = val_7;//m1                        
        // 0x00B96D70: CBNZ x20, #0xb96d78        | if (val_7 != null) goto label_6;        
        if(val_7 != null)
        {
            goto label_6;
        }
        // 0x00B96D74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_6:
        // 0x00B96D78: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
        // 0x00B96D7C: LDR x8, [x8, #0x50]        | X8 = (string**)(1152921514486159536)("Sprite_name_left");
        // 0x00B96D80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B96D84: MOV x0, x20                | X0 = val_7;//m1                         
        // 0x00B96D88: LDR x1, [x8]               | X1 = "Sprite_name_left";                
        // 0x00B96D8C: BL #0x2695ac0              | X0 = val_7.Find(name:  "Sprite_name_left");
        UnityEngine.Transform val_8 = val_7.Find(name:  "Sprite_name_left");
        // 0x00B96D90: MOV x20, x0                | X20 = val_8;//m1                        
        // 0x00B96D94: CBNZ x20, #0xb96d9c        | if (val_8 != null) goto label_7;        
        if(val_8 != null)
        {
            goto label_7;
        }
        // 0x00B96D98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_7:
        // 0x00B96D9C: ADRP x21, #0x35b8000       | X21 = 56328192 (0x35B8000);             
        // 0x00B96DA0: LDR x21, [x21, #0x570]     | X21 = 1152921511724753616;              
        // 0x00B96DA4: MOV x0, x20                | X0 = val_8;//m1                         
        // 0x00B96DA8: LDR x1, [x21]              | X1 = public UISprite UnityEngine.Component::GetComponent<UISprite>();
        // 0x00B96DAC: BL #0x23d5410              | X0 = val_8.GetComponent<UISprite>();    
        UISprite val_9 = val_8.GetComponent<UISprite>();
        // 0x00B96DB0: LDR x20, [x19, #0x28]      | X20 = this._obj_right; //P2             
        // 0x00B96DB4: STR x0, [x19, #0x30]       | this._boss_name_Left = val_9;            //  dest_result_addr=1152921514486216576
        this._boss_name_Left = val_9;
        // 0x00B96DB8: CBNZ x20, #0xb96dc0        | if (this._obj_right != null) goto label_8;
        if(this._obj_right != null)
        {
            goto label_8;
        }
        // 0x00B96DBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_8:
        // 0x00B96DC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96DC4: MOV x0, x20                | X0 = this._obj_right;//m1               
        // 0x00B96DC8: BL #0x1a62c1c              | X0 = this._obj_right.get_transform();   
        UnityEngine.Transform val_10 = this._obj_right.transform;
        // 0x00B96DCC: MOV x20, x0                | X20 = val_10;//m1                       
        // 0x00B96DD0: CBNZ x20, #0xb96dd8        | if (val_10 != null) goto label_9;       
        if(val_10 != null)
        {
            goto label_9;
        }
        // 0x00B96DD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_9:
        // 0x00B96DD8: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
        // 0x00B96DDC: LDR x8, [x8, #0xe18]       | X8 = (string**)(1152921514486176032)("Sprite_name_right");
        // 0x00B96DE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B96DE4: MOV x0, x20                | X0 = val_10;//m1                        
        // 0x00B96DE8: LDR x1, [x8]               | X1 = "Sprite_name_right";               
        // 0x00B96DEC: BL #0x2695ac0              | X0 = val_10.Find(name:  "Sprite_name_right");
        UnityEngine.Transform val_11 = val_10.Find(name:  "Sprite_name_right");
        // 0x00B96DF0: MOV x20, x0                | X20 = val_11;//m1                       
        // 0x00B96DF4: CBNZ x20, #0xb96dfc        | if (val_11 != null) goto label_10;      
        if(val_11 != null)
        {
            goto label_10;
        }
        // 0x00B96DF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_10:
        // 0x00B96DFC: LDR x1, [x21]              | X1 = public UISprite UnityEngine.Component::GetComponent<UISprite>();
        // 0x00B96E00: MOV x0, x20                | X0 = val_11;//m1                        
        // 0x00B96E04: BL #0x23d5410              | X0 = val_11.GetComponent<UISprite>();   
        UISprite val_12 = val_11.GetComponent<UISprite>();
        // 0x00B96E08: STR x0, [x19, #0x38]       | this._boss_name_right = val_12;          //  dest_result_addr=1152921514486216584
        this._boss_name_right = val_12;
        // 0x00B96E0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96E10: MOV x0, x19                | X0 = 1152921514486216528 (0x100000024CDB3750);//ML01
        // 0x00B96E14: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_13 = this.transform;
        // 0x00B96E18: MOV x20, x0                | X20 = val_13;//m1                       
        // 0x00B96E1C: CBNZ x20, #0xb96e24        | if (val_13 != null) goto label_11;      
        if(val_13 != null)
        {
            goto label_11;
        }
        // 0x00B96E20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_11:
        // 0x00B96E24: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00B96E28: LDR x8, [x8, #0x338]       | X8 = 1152921509941328016;               
        // 0x00B96E2C: MOV x0, x20                | X0 = val_13;//m1                        
        // 0x00B96E30: LDR x1, [x8]               | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x00B96E34: BL #0x23d5410              | X0 = val_13.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_14 = val_13.GetComponent<UnityEngine.Camera>();
        // 0x00B96E38: STR x0, [x19, #0x18]       | this.bossCamera = val_14;                //  dest_result_addr=1152921514486216552
        this.bossCamera = val_14;
        // 0x00B96E3C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B96E40: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B96E44: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B96E48: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B96E4C (12152396), len: 16  VirtAddr: 0x00B96E4C RVA: 0x00B96E4C token: 100690202 methodIndex: 25256 delegateWrapperIndex: 0 methodInvoker: 0
    public void OnDestroy()
    {
        //
        // Disasemble & Code
        // 0x00B96E4C: STP xzr, xzr, [x0, #0x30]  | this._boss_name_Left = null;  this._boss_name_right = null;  //  dest_result_addr=1152921514486394112 |  dest_result_addr=1152921514486394120
        this._boss_name_Left = 0;
        this._boss_name_right = 0;
        // 0x00B96E50: STP xzr, xzr, [x0, #0x20]  | this._obj_left = null;  this._obj_right = null;  //  dest_result_addr=1152921514486394096 |  dest_result_addr=1152921514486394104
        this._obj_left = 0;
        this._obj_right = 0;
        // 0x00B96E54: STR xzr, [x0, #0x18]       | this.bossCamera = null;                  //  dest_result_addr=1152921514486394088
        this.bossCamera = 0;
        // 0x00B96E58: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B96A48 (12151368), len: 216  VirtAddr: 0x00B96A48 RVA: 0x00B96A48 token: 100690203 methodIndex: 25257 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetName(string name, int type)
    {
        //
        // Disasemble & Code
        //  | 
        UISprite val_3;
        //  | 
        UISprite val_4;
        // 0x00B96A48: STP x22, x21, [sp, #-0x30]! | stack[1152921514486522688] = ???;  stack[1152921514486522696] = ???;  //  dest_result_addr=1152921514486522688 |  dest_result_addr=1152921514486522696
        // 0x00B96A4C: STP x20, x19, [sp, #0x10]  | stack[1152921514486522704] = ???;  stack[1152921514486522712] = ???;  //  dest_result_addr=1152921514486522704 |  dest_result_addr=1152921514486522712
        // 0x00B96A50: STP x29, x30, [sp, #0x20]  | stack[1152921514486522720] = ???;  stack[1152921514486522728] = ???;  //  dest_result_addr=1152921514486522720 |  dest_result_addr=1152921514486522728
        // 0x00B96A54: ADD x29, sp, #0x20         | X29 = (1152921514486522688 + 32) = 1152921514486522720 (0x100000024CDFE360);
        // 0x00B96A58: MOV x19, x0                | X19 = 1152921514486534736 (0x100000024CE01250);//ML01
        // 0x00B96A5C: LDR x22, [x19, #0x20]      | X22 = this._obj_left; //P2              
        // 0x00B96A60: MOV w21, w2                | W21 = type;//m1                         
        // 0x00B96A64: MOV x20, x1                | X20 = name;//m1                         
        // 0x00B96A68: STR w21, [x19, #0x40]      | this.type = type;                        //  dest_result_addr=1152921514486534800
        this.type = type;
        // 0x00B96A6C: CBNZ x22, #0xb96a74        | if (this._obj_left != null) goto label_0;
        if(this._obj_left != null)
        {
            goto label_0;
        }
        // 0x00B96A70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00B96A74: CMP w21, #1                | STATE = COMPARE(type, 0x1)              
        // 0x00B96A78: CSET w1, eq                | W1 = type == 1 ? 1 : 0;                 
        bool val_1 = (type == 1) ? 1 : 0;
        // 0x00B96A7C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B96A80: MOV x0, x22                | X0 = this._obj_left;//m1                
        // 0x00B96A84: BL #0x1a62d64              | this._obj_left.SetActive(value:  bool val_1 = (type == 1) ? 1 : 0);
        this._obj_left.SetActive(value:  val_1);
        // 0x00B96A88: LDR x22, [x19, #0x28]      | X22 = this._obj_right; //P2             
        // 0x00B96A8C: CBNZ x22, #0xb96a94        | if (this._obj_right != null) goto label_1;
        if(this._obj_right != null)
        {
            goto label_1;
        }
        // 0x00B96A90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._obj_left, ????);
        label_1:
        // 0x00B96A94: CMP w21, #2                | STATE = COMPARE(type, 0x2)              
        // 0x00B96A98: CSET w1, eq                | W1 = type == 2 ? 1 : 0;                 
        bool val_2 = (type == 2) ? 1 : 0;
        // 0x00B96A9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B96AA0: MOV x0, x22                | X0 = this._obj_right;//m1               
        // 0x00B96AA4: BL #0x1a62d64              | this._obj_right.SetActive(value:  bool val_2 = (type == 2) ? 1 : 0);
        this._obj_right.SetActive(value:  val_2);
        // 0x00B96AA8: CMP w21, #1                | STATE = COMPARE(type, 0x1)              
        // 0x00B96AAC: B.NE #0xb96ad8             | if (type != 1) goto label_2;            
        if(type != 1)
        {
            goto label_2;
        }
        // 0x00B96AB0: LDR x21, [x19, #0x30]      | X21 = this._boss_name_Left; //P2        
        val_3 = this._boss_name_Left;
        // 0x00B96AB4: CBNZ x21, #0xb96abc        | if (this._boss_name_Left != null) goto label_3;
        if(val_3 != null)
        {
            goto label_3;
        }
        // 0x00B96AB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._obj_right, ????);
        label_3:
        // 0x00B96ABC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B96AC0: MOV x0, x21                | X0 = this._boss_name_Left;//m1          
        // 0x00B96AC4: MOV x1, x20                | X1 = name;//m1                          
        // 0x00B96AC8: BL #0x1538560              | this._boss_name_Left.set_spriteName(value:  name);
        val_3.spriteName = name;
        // 0x00B96ACC: LDR x19, [x19, #0x30]      | X19 = this._boss_name_Left; //P2        
        val_4 = this._boss_name_Left;
        // 0x00B96AD0: CBNZ x19, #0xb96b00        | if (this._boss_name_Left != null) goto label_7;
        if(val_4 != null)
        {
            goto label_7;
        }
        // 0x00B96AD4: B #0xb96afc                |  goto label_5;                          
        goto label_5;
        label_2:
        // 0x00B96AD8: LDR x21, [x19, #0x38]      | X21 = this._boss_name_right; //P2       
        val_3 = this._boss_name_right;
        // 0x00B96ADC: CBNZ x21, #0xb96ae4        | if (this._boss_name_right != null) goto label_6;
        if(val_3 != null)
        {
            goto label_6;
        }
        // 0x00B96AE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._obj_right, ????);
        label_6:
        // 0x00B96AE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B96AE8: MOV x0, x21                | X0 = this._boss_name_right;//m1         
        // 0x00B96AEC: MOV x1, x20                | X1 = name;//m1                          
        // 0x00B96AF0: BL #0x1538560              | this._boss_name_right.set_spriteName(value:  name);
        val_3.spriteName = name;
        // 0x00B96AF4: LDR x19, [x19, #0x38]      | X19 = this._boss_name_right; //P2       
        val_4 = this._boss_name_right;
        // 0x00B96AF8: CBNZ x19, #0xb96b00        | if (this._boss_name_right != null) goto label_7;
        if(val_4 != null)
        {
            goto label_7;
        }
        label_5:
        // 0x00B96AFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._boss_name_right, ????);
        label_7:
        // 0x00B96B00: LDR x8, [x19]              | X8 = typeof(UISprite);                  
        // 0x00B96B04: MOV x0, x19                | X0 = this._boss_name_right;//m1         
        // 0x00B96B08: LDR x2, [x8, #0x320]       | X2 = typeof(UISprite).__il2cppRuntimeField_320;
        // 0x00B96B0C: LDR x1, [x8, #0x328]       | X1 = typeof(UISprite).__il2cppRuntimeField_328;
        // 0x00B96B10: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B96B14: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B96B18: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B96B1C: BR x2                      | goto typeof(UISprite).__il2cppRuntimeField_320;
        goto typeof(UISprite).__il2cppRuntimeField_320;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B96B58 (12151640), len: 140  VirtAddr: 0x00B96B58 RVA: 0x00B96B58 token: 100690204 methodIndex: 25258 delegateWrapperIndex: 0 methodInvoker: 0
    public void PlayForward()
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.GameObject val_2;
        // 0x00B96B58: STP x20, x19, [sp, #-0x20]! | stack[1152921514486676688] = ???;  stack[1152921514486676696] = ???;  //  dest_result_addr=1152921514486676688 |  dest_result_addr=1152921514486676696
        // 0x00B96B5C: STP x29, x30, [sp, #0x10]  | stack[1152921514486676704] = ???;  stack[1152921514486676712] = ???;  //  dest_result_addr=1152921514486676704 |  dest_result_addr=1152921514486676712
        // 0x00B96B60: ADD x29, sp, #0x10         | X29 = (1152921514486676688 + 16) = 1152921514486676704 (0x100000024CE23CE0);
        // 0x00B96B64: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B96B68: LDRB w8, [x20, #0xa77]     | W8 = (bool)static_value_03733A77;       
        // 0x00B96B6C: MOV x19, x0                | X19 = 1152921514486688720 (0x100000024CE26BD0);//ML01
        // 0x00B96B70: TBNZ w8, #0, #0xb96b8c     | if (static_value_03733A77 == true) goto label_0;
        // 0x00B96B74: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
        // 0x00B96B78: LDR x8, [x8, #0xc70]       | X8 = 0x2B8F8FC;                         
        // 0x00B96B7C: LDR w0, [x8]               | W0 = 0x1503;                            
        // 0x00B96B80: BL #0x2782188              | X0 = sub_2782188( ?? 0x1503, ????);     
        // 0x00B96B84: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B96B88: STRB w8, [x20, #0xa77]     | static_value_03733A77 = true;            //  dest_result_addr=57883255
        label_0:
        // 0x00B96B8C: LDR w8, [x19, #0x40]       | W8 = this.type; //P2                    
        // 0x00B96B90: CMP w8, #1                 | STATE = COMPARE(this.type, 0x1)         
        // 0x00B96B94: B.NE #0xb96ba4             | if (this.type != 1) goto label_1;       
        if(this.type != 1)
        {
            goto label_1;
        }
        // 0x00B96B98: LDR x19, [x19, #0x20]      | X19 = this._obj_left; //P2              
        val_2 = this._obj_left;
        // 0x00B96B9C: CBNZ x19, #0xb96bb0        | if (this._obj_left != null) goto label_4;
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00B96BA0: B #0xb96bac                |  goto label_3;                          
        goto label_3;
        label_1:
        // 0x00B96BA4: LDR x19, [x19, #0x28]      | X19 = this._obj_right; //P2             
        val_2 = this._obj_right;
        // 0x00B96BA8: CBNZ x19, #0xb96bb0        | if (this._obj_right != null) goto label_4;
        if(val_2 != null)
        {
            goto label_4;
        }
        label_3:
        // 0x00B96BAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1503, ????);     
        label_4:
        // 0x00B96BB0: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
        // 0x00B96BB4: LDR x8, [x8, #0x260]       | X8 = 1152921514486659600;               
        // 0x00B96BB8: MOV x0, x19                | X0 = this._obj_right;//m1               
        // 0x00B96BBC: LDR x1, [x8]               | X1 = public TweenAlpha UnityEngine.GameObject::GetComponentInChildren<TweenAlpha>();
        // 0x00B96BC0: BL #0x23d5b88              | X0 = this._obj_right.GetComponentInChildren<TweenAlpha>();
        TweenAlpha val_1 = val_2.GetComponentInChildren<TweenAlpha>();
        // 0x00B96BC4: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00B96BC8: CBNZ x19, #0xb96bd0        | if (val_1 != null) goto label_5;        
        if(val_1 != null)
        {
            goto label_5;
        }
        // 0x00B96BCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00B96BD0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B96BD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96BD8: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x00B96BDC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B96BE0: B #0x1542ad4               | val_1.PlayForward(); return;            
        val_1.PlayForward();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B96830 (12150832), len: 128  VirtAddr: 0x00B96830 RVA: 0x00B96830 token: 100690205 methodIndex: 25259 delegateWrapperIndex: 0 methodInvoker: 0
    public void PlayReverse()
    {
        //
        // Disasemble & Code
        // 0x00B96830: STP x20, x19, [sp, #-0x20]! | stack[1152921514486805072] = ???;  stack[1152921514486805080] = ???;  //  dest_result_addr=1152921514486805072 |  dest_result_addr=1152921514486805080
        // 0x00B96834: STP x29, x30, [sp, #0x10]  | stack[1152921514486805088] = ???;  stack[1152921514486805096] = ???;  //  dest_result_addr=1152921514486805088 |  dest_result_addr=1152921514486805096
        // 0x00B96838: ADD x29, sp, #0x10         | X29 = (1152921514486805072 + 16) = 1152921514486805088 (0x100000024CE43260);
        // 0x00B9683C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B96840: LDRB w8, [x20, #0xa78]     | W8 = (bool)static_value_03733A78;       
        // 0x00B96844: MOV x19, x0                | X19 = 1152921514486817104 (0x100000024CE46150);//ML01
        // 0x00B96848: TBNZ w8, #0, #0xb96864     | if (static_value_03733A78 == true) goto label_0;
        // 0x00B9684C: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
        // 0x00B96850: LDR x8, [x8, #0x1a0]       | X8 = 0x2B8F900;                         
        // 0x00B96854: LDR w0, [x8]               | W0 = 0x1504;                            
        // 0x00B96858: BL #0x2782188              | X0 = sub_2782188( ?? 0x1504, ????);     
        // 0x00B9685C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B96860: STRB w8, [x20, #0xa78]     | static_value_03733A78 = true;            //  dest_result_addr=57883256
        label_0:
        // 0x00B96864: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96868: MOV x0, x19                | X0 = 1152921514486817104 (0x100000024CE46150);//ML01
        // 0x00B9686C: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_1 = this.gameObject;
        // 0x00B96870: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B96874: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B96878: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00B9687C: LDR x8, [x8]               | X8 = typeof(UnityEngine.Object);        
        // 0x00B96880: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B96884: TBZ w9, #0, #0xb96898      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B96888: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B9688C: CBNZ w9, #0xb96898         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B96890: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00B96894: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B96898: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B9689C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B968A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B968A4: MOV x1, x19                | X1 = val_1;//m1                         
        // 0x00B968A8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B968AC: B #0x1b78acc               | UnityEngine.Object.Destroy(obj:  0); return;
        UnityEngine.Object.Destroy(obj:  0);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B96E5C (12152412), len: 4  VirtAddr: 0x00B96E5C RVA: 0x00B96E5C token: 100690206 methodIndex: 25260 delegateWrapperIndex: 0 methodInvoker: 0
    private void End()
    {
        //
        // Disasemble & Code
        // 0x00B96E5C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B9442C (12141612), len: 56  VirtAddr: 0x00B9442C RVA: 0x00B9442C token: 100690207 methodIndex: 25261 delegateWrapperIndex: 0 methodInvoker: 0
    public void Hide()
    {
        //
        // Disasemble & Code
        // 0x00B9442C: STP x20, x19, [sp, #-0x20]! | stack[1152921514487037264] = ???;  stack[1152921514487037272] = ???;  //  dest_result_addr=1152921514487037264 |  dest_result_addr=1152921514487037272
        // 0x00B94430: STP x29, x30, [sp, #0x10]  | stack[1152921514487037280] = ???;  stack[1152921514487037288] = ???;  //  dest_result_addr=1152921514487037280 |  dest_result_addr=1152921514487037288
        // 0x00B94434: ADD x29, sp, #0x10         | X29 = (1152921514487037264 + 16) = 1152921514487037280 (0x100000024CE7BD60);
        // 0x00B94438: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9443C: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_1 = this.gameObject;
        // 0x00B94440: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00B94444: CBNZ x19, #0xb9444c        | if (val_1 != null) goto label_0;        
        if(val_1 != null)
        {
            goto label_0;
        }
        // 0x00B94448: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_0:
        // 0x00B9444C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B94450: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B94454: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B94458: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x00B9445C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B94460: B #0x1a62d64               | val_1.SetActive(value:  false); return; 
        val_1.SetActive(value:  false);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B96B20 (12151584), len: 56  VirtAddr: 0x00B96B20 RVA: 0x00B96B20 token: 100690208 methodIndex: 25262 delegateWrapperIndex: 0 methodInvoker: 0
    public void Show()
    {
        //
        // Disasemble & Code
        // 0x00B96B20: STP x20, x19, [sp, #-0x20]! | stack[1152921514487157456] = ???;  stack[1152921514487157464] = ???;  //  dest_result_addr=1152921514487157456 |  dest_result_addr=1152921514487157464
        // 0x00B96B24: STP x29, x30, [sp, #0x10]  | stack[1152921514487157472] = ???;  stack[1152921514487157480] = ???;  //  dest_result_addr=1152921514487157472 |  dest_result_addr=1152921514487157480
        // 0x00B96B28: ADD x29, sp, #0x10         | X29 = (1152921514487157456 + 16) = 1152921514487157472 (0x100000024CE992E0);
        // 0x00B96B2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96B30: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_1 = this.gameObject;
        // 0x00B96B34: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00B96B38: CBNZ x19, #0xb96b40        | if (val_1 != null) goto label_0;        
        if(val_1 != null)
        {
            goto label_0;
        }
        // 0x00B96B3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_0:
        // 0x00B96B40: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B96B44: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B96B48: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B96B4C: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x00B96B50: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B96B54: B #0x1a62d64               | val_1.SetActive(value:  true); return;  
        val_1.SetActive(value:  true);
        return;
    
    }

}
