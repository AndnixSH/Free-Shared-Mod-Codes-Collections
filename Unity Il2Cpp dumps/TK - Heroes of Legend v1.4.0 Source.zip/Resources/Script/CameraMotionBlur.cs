using UnityEngine;
[UnityEngine.AddComponentMenu] // 0x281A6E8
[UnityEngine.ExecuteInEditMode] // 0x281A6E8
[UnityEngine.RequireComponent] // 0x281A6E8
[Serializable]
public class CameraMotionBlur : PostEffectsBase
{
    // Fields
    public static int MAX_RADIUS; // static_offset: 0x00000000
    public CameraMotionBlur.MotionBlurFilter filterType; //  0x0000001C
    public bool preview; //  0x00000020
    public UnityEngine.Vector3 previewScale; //  0x00000024
    public float movementScale; //  0x00000030
    public float rotationScale; //  0x00000034
    public float maxVelocity; //  0x00000038
    public float minVelocity; //  0x0000003C
    public float velocityScale; //  0x00000040
    public float softZDistance; //  0x00000044
    public int velocityDownsample; //  0x00000048
    public UnityEngine.LayerMask excludeLayers; //  0x0000004C
    private UnityEngine.GameObject tmpCam; //  0x00000050
    public UnityEngine.Shader shader; //  0x00000058
    public UnityEngine.Shader dx11MotionBlurShader; //  0x00000060
    public UnityEngine.Shader replacementClear; //  0x00000068
    private UnityEngine.Material motionBlurMaterial; //  0x00000070
    private UnityEngine.Material dx11MotionBlurMaterial; //  0x00000078
    public UnityEngine.Texture2D noiseTexture; //  0x00000080
    public float jitter; //  0x00000088
    public bool showVelocity; //  0x0000008C
    public float showVelocityScale; //  0x00000090
    private UnityEngine.Matrix4x4 currentViewProjMat; //  0x00000094
    private UnityEngine.Matrix4x4 prevViewProjMat; //  0x000000D4
    private int prevFrameCount; //  0x00000114
    private bool wasActive; //  0x00000118
    private UnityEngine.Vector3 prevFrameForward; //  0x0000011C
    private UnityEngine.Vector3 prevFrameRight; //  0x00000128
    private UnityEngine.Vector3 prevFrameUp; //  0x00000134
    private UnityEngine.Vector3 prevFramePos; //  0x00000140
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x02675924 (40327460), len: 292  VirtAddr: 0x02675924 RVA: 0x02675924 token: 100663329 methodIndex: 24413 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraMotionBlur()
    {
        //
        // Disasemble & Code
        // 0x02675924: STP x20, x19, [sp, #-0x20]! | stack[1152921509948582000] = ???;  stack[1152921509948582008] = ???;  //  dest_result_addr=1152921509948582000 |  dest_result_addr=1152921509948582008
        // 0x02675928: STP x29, x30, [sp, #0x10]  | stack[1152921509948582016] = ???;  stack[1152921509948582024] = ???;  //  dest_result_addr=1152921509948582016 |  dest_result_addr=1152921509948582024
        // 0x0267592C: ADD x29, sp, #0x10         | X29 = (1152921509948582000 + 16) = 1152921509948582016 (0x100000013E646880);
        // 0x02675930: ADRP x20, #0x3740000       | X20 = 57933824 (0x3740000);             
        // 0x02675934: LDRB w8, [x20, #0xe53]     | W8 = (bool)static_value_03740E53;       
        // 0x02675938: MOV x19, x0                | X19 = 1152921509948594032 (0x100000013E649770);//ML01
        // 0x0267593C: TBNZ w8, #0, #0x2675958    | if (static_value_03740E53 == true) goto label_0;
        // 0x02675940: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
        // 0x02675944: LDR x8, [x8, #0x738]       | X8 = 0x2B90228;                         
        // 0x02675948: LDR w0, [x8]               | W0 = 0x174E;                            
        // 0x0267594C: BL #0x2782188              | X0 = sub_2782188( ?? 0x174E, ????);     
        // 0x02675950: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02675954: STRB w8, [x20, #0xe53]     | static_value_03740E53 = true;            //  dest_result_addr=57937491
        label_0:
        // 0x02675958: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267595C: MOV x0, x19                | X0 = 1152921509948594032 (0x100000013E649770);//ML01
        UnityEngine.MonoBehaviour val_1 = this;
        // 0x02675960: BL #0x1b76fd4              | this..ctor();                           
        val_1 = new UnityEngine.MonoBehaviour();
        // 0x02675964: ORR w8, wzr, #2            | W8 = 2(0x2);                            
        // 0x02675968: ORR w20, wzr, #1           | W20 = 1(0x1);                           
        // 0x0267596C: STR w8, [x19, #0x1c]       | this.filterType = 0x2;                   //  dest_result_addr=1152921509948594060
        this.filterType = 2;
        // 0x02675970: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x02675974: STRB w20, [x19, #0x18]     | mem[1152921509948594056] = 0x1;          //  dest_result_addr=1152921509948594056
        mem[1152921509948594056] = 1;
        // 0x02675978: STRB w20, [x19, #0x1a]     | mem[1152921509948594058] = 0x1;          //  dest_result_addr=1152921509948594058
        mem[1152921509948594058] = 1;
        // 0x0267597C: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x02675980: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x02675984: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x02675988: TBZ w8, #0, #0x2675998     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0267598C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x02675990: CBNZ w8, #0x2675998        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x02675994: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_2:
        // 0x02675998: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267599C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026759A0: BL #0x269a58c              | X0 = UnityEngine.Vector3.get_one();     
        UnityEngine.Vector3 val_2 = UnityEngine.Vector3.one;
        // 0x026759A4: ADRP x8, #0x2ac3000        | X8 = 44838912 (0x2AC3000);              
        // 0x026759A8: STP s0, s1, [x19, #0x24]   | this.previewScale = val_2;  mem[1152921509948594072] = val_2.y;  //  dest_result_addr=1152921509948594068 |  dest_result_addr=1152921509948594072
        this.previewScale = val_2;
        mem[1152921509948594072] = val_2.y;
        // 0x026759AC: LDR q0, [x8, #0xc60]       | Q0 = ;                                  
        // 0x026759B0: MOVZ w9, #0x3ba3, lsl #16  | W9 = 1000538112 (0x3BA30000);//ML01     
        // 0x026759B4: MOVK w9, #0xd70a           | W9 = 1000593162 (0x3BA3D70A);           
        // 0x026759B8: MOVZ w8, #0x3d4c, lsl #16  | W8 = 1028390912 (0x3D4C0000);//ML01     
        // 0x026759BC: MOVK w8, #0xcccd           | W8 = 1028443341 (0x3D4CCCCD);           
        // 0x026759C0: STR w9, [x19, #0x44]       | this.softZDistance = 0.005;              //  dest_result_addr=1152921509948594100
        this.softZDistance = 0.005f;
        // 0x026759C4: ORR w9, wzr, #0x3f800000   | W9 = 1065353216(0x3F800000);            
        // 0x026759C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026759CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026759D0: STR s2, [x19, #0x2c]       | mem[1152921509948594076] = val_2.z;      //  dest_result_addr=1152921509948594076
        mem[1152921509948594076] = val_2.z;
        // 0x026759D4: STR w20, [x19, #0x48]      | this.velocityDownsample = 1;             //  dest_result_addr=1152921509948594104
        this.velocityDownsample = 1;
        // 0x026759D8: STR w8, [x19, #0x88]       | this.jitter = 0.05;                      //  dest_result_addr=1152921509948594168
        this.jitter = 0.05f;
        // 0x026759DC: STUR q0, [x19, #0x34]      | this.rotationScale = ; this.maxVelocity = ; this.minVelocity = 0.1; this.velocityScale = 0.375;  //  dest_result_addr=1152921509948594084 dest_result_addr=1152921509948594088 dest_result_addr=1152921509948594092 dest_result_addr=1152921509948594096
        this.rotationScale = ;
        this.maxVelocity = ;
        this.minVelocity = 0.1f;
        this.velocityScale = 0.375f;
        // 0x026759E0: STR w9, [x19, #0x90]       | this.showVelocityScale = 1;              //  dest_result_addr=1152921509948594176
        this.showVelocityScale = 1f;
        // 0x026759E4: BL #0x2693fb8              | X0 = UnityEngine.Vector3.get_forward(); 
        UnityEngine.Vector3 val_3 = UnityEngine.Vector3.forward;
        // 0x026759E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026759EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026759F0: STR s0, [x19, #0x11c]      | this.prevFrameForward = val_3;           //  dest_result_addr=1152921509948594316
        this.prevFrameForward = val_3;
        // 0x026759F4: STR s1, [x19, #0x120]      | mem[1152921509948594320] = val_3.y;      //  dest_result_addr=1152921509948594320
        mem[1152921509948594320] = val_3.y;
        // 0x026759F8: STR s2, [x19, #0x124]      | mem[1152921509948594324] = val_3.z;      //  dest_result_addr=1152921509948594324
        mem[1152921509948594324] = val_3.z;
        // 0x026759FC: BL #0x2693b08              | X0 = UnityEngine.Vector3.get_right();   
        UnityEngine.Vector3 val_4 = UnityEngine.Vector3.right;
        // 0x02675A00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02675A04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02675A08: STR s0, [x19, #0x128]      | this.prevFrameRight = val_4;             //  dest_result_addr=1152921509948594328
        this.prevFrameRight = val_4;
        // 0x02675A0C: STR s1, [x19, #0x12c]      | mem[1152921509948594332] = val_4.y;      //  dest_result_addr=1152921509948594332
        mem[1152921509948594332] = val_4.y;
        // 0x02675A10: STR s2, [x19, #0x130]      | mem[1152921509948594336] = val_4.z;      //  dest_result_addr=1152921509948594336
        mem[1152921509948594336] = val_4.z;
        // 0x02675A14: BL #0x2693d60              | X0 = UnityEngine.Vector3.get_up();      
        UnityEngine.Vector3 val_5 = UnityEngine.Vector3.up;
        // 0x02675A18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02675A1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02675A20: STR s0, [x19, #0x134]      | this.prevFrameUp = val_5;                //  dest_result_addr=1152921509948594340
        this.prevFrameUp = val_5;
        // 0x02675A24: STR s1, [x19, #0x138]      | mem[1152921509948594344] = val_5.y;      //  dest_result_addr=1152921509948594344
        mem[1152921509948594344] = val_5.y;
        // 0x02675A28: STR s2, [x19, #0x13c]      | mem[1152921509948594348] = val_5.z;      //  dest_result_addr=1152921509948594348
        mem[1152921509948594348] = val_5.z;
        // 0x02675A2C: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
        UnityEngine.Vector3 val_6 = UnityEngine.Vector3.zero;
        // 0x02675A30: STR s2, [x19, #0x148]      | mem[1152921509948594360] = val_6.z;      //  dest_result_addr=1152921509948594360
        mem[1152921509948594360] = val_6.z;
        // 0x02675A34: STR s0, [x19, #0x140]      | this.prevFramePos = val_6;               //  dest_result_addr=1152921509948594352
        this.prevFramePos = val_6;
        // 0x02675A38: STR s1, [x19, #0x144]      | mem[1152921509948594356] = val_6.y;      //  dest_result_addr=1152921509948594356
        mem[1152921509948594356] = val_6.y;
        // 0x02675A3C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02675A40: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x02675A44: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02675A48 (40327752), len: 84  VirtAddr: 0x02675A48 RVA: 0x02675A48 token: 100663330 methodIndex: 24414 delegateWrapperIndex: 0 methodInvoker: 0
    private static CameraMotionBlur()
    {
        //
        // Disasemble & Code
        // 0x02675A48: STP x20, x19, [sp, #-0x20]! | stack[1152921509948694000] = ???;  stack[1152921509948694008] = ???;  //  dest_result_addr=1152921509948694000 |  dest_result_addr=1152921509948694008
        // 0x02675A4C: STP x29, x30, [sp, #0x10]  | stack[1152921509948694016] = ???;  stack[1152921509948694024] = ???;  //  dest_result_addr=1152921509948694016 |  dest_result_addr=1152921509948694024
        // 0x02675A50: ADD x29, sp, #0x10         | X29 = (1152921509948694000 + 16) = 1152921509948694016 (0x100000013E661E00);
        // 0x02675A54: ADRP x19, #0x3740000       | X19 = 57933824 (0x3740000);             
        // 0x02675A58: LDRB w8, [x19, #0xe54]     | W8 = (bool)static_value_03740E54;       
        // 0x02675A5C: TBNZ w8, #0, #0x2675a78    | if (static_value_03740E54 == true) goto label_0;
        // 0x02675A60: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
        // 0x02675A64: LDR x8, [x8, #0x758]       | X8 = 0x2B90224;                         
        // 0x02675A68: LDR w0, [x8]               | W0 = 0x174D;                            
        // 0x02675A6C: BL #0x2782188              | X0 = sub_2782188( ?? 0x174D, ????);     
        // 0x02675A70: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02675A74: STRB w8, [x19, #0xe54]     | static_value_03740E54 = true;            //  dest_result_addr=57937492
        label_0:
        // 0x02675A78: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
        // 0x02675A7C: LDR x8, [x8, #0x88]        | X8 = 1152921504778838016;               
        // 0x02675A80: MOVZ w9, #0xa              | W9 = 10 (0xA);//ML01                    
        // 0x02675A84: LDR x8, [x8]               | X8 = typeof(CameraMotionBlur);          
        // 0x02675A88: LDR x8, [x8, #0xa0]        | X8 = CameraMotionBlur.__il2cppRuntimeField_static_fields;
        // 0x02675A8C: STR w9, [x8]               | CameraMotionBlur.MAX_RADIUS = 10;        //  dest_result_addr=1152921504778842112
        CameraMotionBlur.MAX_RADIUS = 10;
        // 0x02675A90: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02675A94: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x02675A98: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02675A9C (40327836), len: 416  VirtAddr: 0x02675A9C RVA: 0x02675A9C token: 100663331 methodIndex: 24415 delegateWrapperIndex: 0 methodInvoker: 0
    private void CalculateViewProjection()
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        //  | 
        var val_4;
        //  | 
        var val_5;
        //  | 
        var val_6;
        //  | 
        var val_9;
        //  | 
        var val_10;
        //  | 
        var val_11;
        //  | 
        var val_12;
        //  | 
        float val_14;
        //  | 
        float val_15;
        //  | 
        float val_16;
        //  | 
        float val_17;
        //  | 
        var val_19;
        //  | 
        var val_20;
        //  | 
        var val_21;
        //  | 
        UnityEngine.Matrix4x4 val_22;
        // 0x02675A9C: STP x22, x21, [sp, #-0x30]! | stack[1152921509948830752] = ???;  stack[1152921509948830760] = ???;  //  dest_result_addr=1152921509948830752 |  dest_result_addr=1152921509948830760
        // 0x02675AA0: STP x20, x19, [sp, #0x10]  | stack[1152921509948830768] = ???;  stack[1152921509948830776] = ???;  //  dest_result_addr=1152921509948830768 |  dest_result_addr=1152921509948830776
        // 0x02675AA4: STP x29, x30, [sp, #0x20]  | stack[1152921509948830784] = ???;  stack[1152921509948830792] = ???;  //  dest_result_addr=1152921509948830784 |  dest_result_addr=1152921509948830792
        // 0x02675AA8: ADD x29, sp, #0x20         | X29 = (1152921509948830752 + 32) = 1152921509948830784 (0x100000013E683440);
        // 0x02675AAC: SUB sp, sp, #0x280         | SP = (1152921509948830752 - 640) = 1152921509948830112 (0x100000013E6831A0);
        // 0x02675AB0: ADRP x20, #0x3740000       | X20 = 57933824 (0x3740000);             
        // 0x02675AB4: LDRB w8, [x20, #0xe55]     | W8 = (bool)static_value_03740E55;       
        // 0x02675AB8: MOV x19, x0                | X19 = 1152921509948842800 (0x100000013E686330);//ML01
        // 0x02675ABC: TBNZ w8, #0, #0x2675ad8    | if (static_value_03740E55 == true) goto label_0;
        // 0x02675AC0: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
        // 0x02675AC4: LDR x8, [x8, #0x460]       | X8 = 0x2B9022C;                         
        // 0x02675AC8: LDR w0, [x8]               | W0 = 0x174F;                            
        // 0x02675ACC: BL #0x2782188              | X0 = sub_2782188( ?? 0x174F, ????);     
        // 0x02675AD0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02675AD4: STRB w8, [x20, #0xe55]     | static_value_03740E55 = true;            //  dest_result_addr=57937493
        label_0:
        // 0x02675AD8: STP xzr, xzr, [x29, #-0x30] | stack[1152921509948830736] = 0x0;  stack[1152921509948830744] = 0x0;  //  dest_result_addr=1152921509948830736 |  dest_result_addr=1152921509948830744
        // 0x02675ADC: STP xzr, xzr, [x29, #-0x40] | stack[1152921509948830720] = 0x0;  stack[1152921509948830728] = 0x0;  //  dest_result_addr=1152921509948830720 |  dest_result_addr=1152921509948830728
        // 0x02675AE0: ADRP x21, #0x3668000       | X21 = 57049088 (0x3668000);             
        // 0x02675AE4: STUR xzr, [x29, #-0x48]    | stack[1152921509948830712] = 0x0;        //  dest_result_addr=1152921509948830712
        // 0x02675AE8: LDR x21, [x21, #0x338]     | X21 = 1152921509941328016;              
        // 0x02675AEC: MOV x0, x19                | X0 = 1152921509948842800 (0x100000013E686330);//ML01
        // 0x02675AF0: LDR x1, [x21]              | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x02675AF4: STP xzr, xzr, [x29, #-0x58] | stack[1152921509948830696] = 0x0;  stack[1152921509948830704] = 0x0;  //  dest_result_addr=1152921509948830696 |  dest_result_addr=1152921509948830704
        // 0x02675AF8: STUR xzr, [x29, #-0x60]    | stack[1152921509948830688] = 0x0;        //  dest_result_addr=1152921509948830688
        // 0x02675AFC: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_1 = this.GetComponent<UnityEngine.Camera>();
        // 0x02675B00: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x02675B04: CBNZ x20, #0x2675b0c       | if (val_1 != null) goto label_1;        
        if(val_1 != null)
        {
            goto label_1;
        }
        // 0x02675B08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x02675B0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02675B10: SUB x8, x29, #0xa0         | X8 = (1152921509948830784 - 160) = 1152921509948830624 (0x100000013E6833A0);
        // 0x02675B14: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x02675B18: BL #0x20d01b8              | X0 = val_1.get_worldToCameraMatrix();   
        UnityEngine.Matrix4x4 val_2 = val_1.worldToCameraMatrix;
        // 0x02675B1C: LDP q1, q0, [x29, #-0x80]  | Q1 = val_3; Q0 = val_4;                  //  find_add[1152921509948818800] |  find_add[1152921509948818800]
        // 0x02675B20: LDP q3, q2, [x29, #-0xa0]  | Q3 = val_5; Q2 = val_6;                  //  find_add[1152921509948818800] |  find_add[1152921509948818800]
        // 0x02675B24: LDR x1, [x21]              | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x02675B28: MOV x0, x19                | X0 = 1152921509948842800 (0x100000013E686330);//ML01
        // 0x02675B2C: STP q1, q0, [x29, #-0x40]  | stack[1152921509948830720] = val_3;  stack[1152921509948830736] = val_4;  //  dest_result_addr=1152921509948830720 |  dest_result_addr=1152921509948830736
        // 0x02675B30: STP q3, q2, [x29, #-0x60]  | stack[1152921509948830688] = val_5;  stack[1152921509948830704] = val_6;  //  dest_result_addr=1152921509948830688 |  dest_result_addr=1152921509948830704
        // 0x02675B34: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_7 = this.GetComponent<UnityEngine.Camera>();
        // 0x02675B38: MOV x20, x0                | X20 = val_7;//m1                        
        // 0x02675B3C: CBNZ x20, #0x2675b44       | if (val_7 != null) goto label_2;        
        if(val_7 != null)
        {
            goto label_2;
        }
        // 0x02675B40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_2:
        // 0x02675B44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02675B48: SUB x8, x29, #0xe0         | X8 = (1152921509948830784 - 224) = 1152921509948830560 (0x100000013E683360);
        // 0x02675B4C: MOV x0, x20                | X0 = val_7;//m1                         
        // 0x02675B50: BL #0x20d0368              | X0 = val_7.get_projectionMatrix();      
        UnityEngine.Matrix4x4 val_8 = val_7.projectionMatrix;
        // 0x02675B54: LDP q1, q0, [x29, #-0xc0]  | Q1 = val_9; Q0 = val_10;                 //  find_add[1152921509948818800] |  find_add[1152921509948818800]
        // 0x02675B58: LDP q3, q2, [x29, #-0xe0]  | Q3 = val_11; Q2 = val_12;                //  find_add[1152921509948818800] |  find_add[1152921509948818800]
        // 0x02675B5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02675B60: ADD x8, sp, #0x180         | X8 = (1152921509948830112 + 384) = 1152921509948830496 (0x100000013E683320);
        // 0x02675B64: ADD x1, sp, #0x140         | X1 = (1152921509948830112 + 320) = 1152921509948830432 (0x100000013E6832E0);
        // 0x02675B68: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x02675B6C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02675B70: STP q1, q0, [sp, #0x160]   | stack[1152921509948830464] = val_9;  stack[1152921509948830480] = val_10;  //  dest_result_addr=1152921509948830464 |  dest_result_addr=1152921509948830480
        // 0x02675B74: STP q3, q2, [sp, #0x140]   | stack[1152921509948830432] = val_11;  stack[1152921509948830448] = val_12;  //  dest_result_addr=1152921509948830432 |  dest_result_addr=1152921509948830448
        // 0x02675B78: BL #0x1a6615c              | X0 = UnityEngine.GL.GetGPUProjectionMatrix(proj:  new UnityEngine.Matrix4x4(), renderIntoTexture:  true);
        UnityEngine.Matrix4x4 val_13 = UnityEngine.GL.GetGPUProjectionMatrix(proj:  new UnityEngine.Matrix4x4(), renderIntoTexture:  true);
        // 0x02675B7C: LDP q1, q0, [sp, #0x1a0]   | Q1 = val_14; Q0 = val_15;                //  find_add[1152921509948818800] |  find_add[1152921509948818800]
        // 0x02675B80: ADRP x8, #0x3645000        | X8 = 56905728 (0x3645000);              
        // 0x02675B84: STR q0, [sp, #0x130]       | stack[1152921509948830416] = val_15;     //  dest_result_addr=1152921509948830416
        // 0x02675B88: LDP q0, q2, [sp, #0x180]   | Q0 = val_16; Q2 = val_17;                //  find_add[1152921509948818800] |  find_add[1152921509948818800]
        // 0x02675B8C: STR q1, [sp, #0x120]       | stack[1152921509948830400] = val_14;     //  dest_result_addr=1152921509948830400
        // 0x02675B90: LDUR q1, [x29, #-0x30]     | Q1 = val_4;                             
        // 0x02675B94: STR q2, [sp, #0x110]       | stack[1152921509948830384] = val_17;     //  dest_result_addr=1152921509948830384
        // 0x02675B98: LDUR q2, [x29, #-0x40]     | Q2 = val_3;                             
        // 0x02675B9C: STR q0, [sp, #0x100]       | stack[1152921509948830368] = val_16;     //  dest_result_addr=1152921509948830368
        // 0x02675BA0: LDUR q0, [x29, #-0x50]     | Q0 = val_6;                             
        // 0x02675BA4: STR q1, [sp, #0xf0]        | stack[1152921509948830352] = val_4;      //  dest_result_addr=1152921509948830352
        // 0x02675BA8: LDUR q1, [x29, #-0x60]     | Q1 = val_5;                             
        // 0x02675BAC: LDR x8, [x8, #0x778]       | X8 = 1152921504695238656;               
        // 0x02675BB0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Matrix4x4);     
        // 0x02675BB4: STP q0, q2, [sp, #0xd0]    | stack[1152921509948830320] = val_6;  stack[1152921509948830336] = val_3;  //  dest_result_addr=1152921509948830320 |  dest_result_addr=1152921509948830336
        // 0x02675BB8: STR q1, [sp, #0xc0]        | stack[1152921509948830304] = val_5;      //  dest_result_addr=1152921509948830304
        // 0x02675BBC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Matrix4x4.__il2cppRuntimeField_10A;
        // 0x02675BC0: TBZ w8, #0, #0x2675bd0     | if (UnityEngine.Matrix4x4.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x02675BC4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Matrix4x4.__il2cppRuntimeField_cctor_finished;
        // 0x02675BC8: CBNZ w8, #0x2675bd0        | if (UnityEngine.Matrix4x4.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x02675BCC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Matrix4x4), ????);
        label_4:
        // 0x02675BD0: LDP q1, q0, [sp, #0x120]   | Q1 = val_14; Q0 = val_15;                //  | 
        // 0x02675BD4: LDP q3, q2, [sp, #0x100]   | Q3 = val_16; Q2 = val_17;                //  | 
        // 0x02675BD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02675BDC: ADD x8, sp, #0x80          | X8 = (1152921509948830112 + 128) = 1152921509948830240 (0x100000013E683220);
        // 0x02675BE0: STP q1, q0, [sp, #0x60]    | stack[1152921509948830208] = val_14;  stack[1152921509948830224] = val_15;  //  dest_result_addr=1152921509948830208 |  dest_result_addr=1152921509948830224
        // 0x02675BE4: LDP q1, q0, [sp, #0xe0]    | Q1 = val_3; Q0 = val_4;                  //  | 
        // 0x02675BE8: STP q3, q2, [sp, #0x40]    | stack[1152921509948830176] = val_16;  stack[1152921509948830192] = val_17;  //  dest_result_addr=1152921509948830176 |  dest_result_addr=1152921509948830192
        // 0x02675BEC: LDP q3, q2, [sp, #0xc0]    | Q3 = val_5; Q2 = val_6;                  //  | 
        // 0x02675BF0: ADD x1, sp, #0x40          | X1 = (1152921509948830112 + 64) = 1152921509948830176 (0x100000013E6831E0);
        // 0x02675BF4: MOV x2, sp                 | X2 = 1152921509948830112 (0x100000013E6831A0);//ML01
        // 0x02675BF8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02675BFC: STP q1, q0, [sp, #0x20]    | stack[1152921509948830144] = val_3;  stack[1152921509948830160] = val_4;  //  dest_result_addr=1152921509948830144 |  dest_result_addr=1152921509948830160
        // 0x02675C00: STP q3, q2, [sp]           | stack[1152921509948830112] = val_5;  stack[1152921509948830128] = val_6;  //  dest_result_addr=1152921509948830112 |  dest_result_addr=1152921509948830128
        // 0x02675C04: BL #0x1b7133c              | X0 = UnityEngine.Matrix4x4.op_Multiply(lhs:  new UnityEngine.Matrix4x4(), rhs:  new UnityEngine.Matrix4x4() {m00 = val_16, m10 = val_16, m20 = val_16, m30 = val_16, m01 = val_17, m11 = val_17, m21 = val_17, m31 = val_17, m02 = val_14, m12 = val_14, m22 = val_14, m32 = val_14, m03 = val_15, m13 = val_15, m23 = val_15, m33 = val_15});
        UnityEngine.Matrix4x4 val_18 = UnityEngine.Matrix4x4.op_Multiply(lhs:  new UnityEngine.Matrix4x4(), rhs:  new UnityEngine.Matrix4x4() {m00 = val_16, m10 = val_16, m20 = val_16, m30 = val_16, m01 = val_17, m11 = val_17, m21 = val_17, m31 = val_17, m02 = val_14, m12 = val_14, m22 = val_14, m32 = val_14, m03 = val_15, m13 = val_15, m23 = val_15, m33 = val_15});
        // 0x02675C08: LDR q0, [sp, #0xb0]        | Q0 = val_19;                             //  find_add[1152921509948818800]
        // 0x02675C0C: STUR q0, [x19, #0xc4]      | mem[1152921509948842996] = val_19;       //  dest_result_addr=1152921509948842996
        mem[1152921509948842996] = val_19;
        // 0x02675C10: LDR q0, [sp, #0xa0]        | Q0 = val_20;                             //  find_add[1152921509948818800]
        // 0x02675C14: STUR q0, [x19, #0xb4]      | mem[1152921509948842980] = val_20;       //  dest_result_addr=1152921509948842980
        mem[1152921509948842980] = val_20;
        // 0x02675C18: LDR q0, [sp, #0x90]        | Q0 = val_21;                             //  find_add[1152921509948818800]
        // 0x02675C1C: STUR q0, [x19, #0xa4]      | mem[1152921509948842964] = val_21;       //  dest_result_addr=1152921509948842964
        mem[1152921509948842964] = val_21;
        // 0x02675C20: LDR q0, [sp, #0x80]        | Q0 = val_22;                             //  find_add[1152921509948818800]
        // 0x02675C24: STUR q0, [x19, #0x94]      | this.currentViewProjMat = val_22;        //  dest_result_addr=1152921509948842948
        this.currentViewProjMat = val_22;
        // 0x02675C28: SUB sp, x29, #0x20         | SP = (1152921509948830784 - 32) = 1152921509948830752 (0x100000013E683420);
        // 0x02675C2C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x02675C30: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x02675C34: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x02675C38: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02675C3C (40328252), len: 116  VirtAddr: 0x02675C3C RVA: 0x02675C3C token: 100663332 methodIndex: 24416 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Start()
    {
        //
        // Disasemble & Code
        // 0x02675C3C: STP x20, x19, [sp, #-0x20]! | stack[1152921509948971632] = ???;  stack[1152921509948971640] = ???;  //  dest_result_addr=1152921509948971632 |  dest_result_addr=1152921509948971640
        // 0x02675C40: STP x29, x30, [sp, #0x10]  | stack[1152921509948971648] = ???;  stack[1152921509948971656] = ???;  //  dest_result_addr=1152921509948971648 |  dest_result_addr=1152921509948971656
        // 0x02675C44: ADD x29, sp, #0x10         | X29 = (1152921509948971632 + 16) = 1152921509948971648 (0x100000013E6A5A80);
        // 0x02675C48: MOV x19, x0                | X19 = 1152921509948983664 (0x100000013E6A8970);//ML01
        // 0x02675C4C: LDR x8, [x19]              | X8 = typeof(CameraMotionBlur);          
        // 0x02675C50: LDP x9, x1, [x8, #0x190]   | X9 = typeof(CameraMotionBlur).__il2cppRuntimeField_190; X1 = typeof(CameraMotionBlur).__il2cppRuntimeField_198; //  | 
        // 0x02675C54: BLR x9                     | X0 = typeof(CameraMotionBlur).__il2cppRuntimeField_190();
        // 0x02675C58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02675C5C: MOV x0, x19                | X0 = 1152921509948983664 (0x100000013E6A8970);//ML01
        // 0x02675C60: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_1 = this.gameObject;
        // 0x02675C64: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x02675C68: CBNZ x20, #0x2675c70       | if (val_1 != null) goto label_0;        
        if(val_1 != null)
        {
            goto label_0;
        }
        // 0x02675C6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_0:
        // 0x02675C70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02675C74: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x02675C78: BL #0x1a62e44              | X0 = val_1.get_activeInHierarchy();     
        bool val_2 = val_1.activeInHierarchy;
        // 0x02675C7C: AND w8, w0, #1             | W8 = (val_2 & 1);                       
        bool val_3 = val_2;
        // 0x02675C80: MOV x0, x19                | X0 = 1152921509948983664 (0x100000013E6A8970);//ML01
        // 0x02675C84: STRB w8, [x19, #0x118]     | this.wasActive = (val_2 & 1);            //  dest_result_addr=1152921509948983944
        this.wasActive = val_3;
        // 0x02675C88: BL #0x2675a9c              | this.CalculateViewProjection();         
        this.CalculateViewProjection();
        // 0x02675C8C: LDR x8, [x19]              | X8 = typeof(CameraMotionBlur);          
        // 0x02675C90: MOV x0, x19                | X0 = 1152921509948983664 (0x100000013E6A8970);//ML01
        // 0x02675C94: LDR x9, [x8, #0x250]       | X9 = typeof(CameraMotionBlur).__il2cppRuntimeField_250;
        // 0x02675C98: LDR x1, [x8, #0x258]       | X1 = typeof(CameraMotionBlur).__il2cppRuntimeField_258;
        // 0x02675C9C: BLR x9                     | X0 = typeof(CameraMotionBlur).__il2cppRuntimeField_250();
        // 0x02675CA0: STRB wzr, [x19, #0x118]    | this.wasActive = false;                  //  dest_result_addr=1152921509948983944
        this.wasActive = false;
        // 0x02675CA4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02675CA8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x02675CAC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02675CB0 (40328368), len: 148  VirtAddr: 0x02675CB0 RVA: 0x02675CB0 token: 100663333 methodIndex: 24417 delegateWrapperIndex: 0 methodInvoker: 0
    public override void OnEnable()
    {
        //
        // Disasemble & Code
        // 0x02675CB0: STP x20, x19, [sp, #-0x20]! | stack[1152921509949100016] = ???;  stack[1152921509949100024] = ???;  //  dest_result_addr=1152921509949100016 |  dest_result_addr=1152921509949100024
        // 0x02675CB4: STP x29, x30, [sp, #0x10]  | stack[1152921509949100032] = ???;  stack[1152921509949100040] = ???;  //  dest_result_addr=1152921509949100032 |  dest_result_addr=1152921509949100040
        // 0x02675CB8: ADD x29, sp, #0x10         | X29 = (1152921509949100016 + 16) = 1152921509949100032 (0x100000013E6C5000);
        // 0x02675CBC: ADRP x19, #0x3740000       | X19 = 57933824 (0x3740000);             
        // 0x02675CC0: LDRB w8, [x19, #0xe56]     | W8 = (bool)static_value_03740E56;       
        // 0x02675CC4: MOV x20, x0                | X20 = 1152921509949112048 (0x100000013E6C7EF0);//ML01
        // 0x02675CC8: TBNZ w8, #0, #0x2675ce4    | if (static_value_03740E56 == true) goto label_0;
        // 0x02675CCC: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
        // 0x02675CD0: LDR x8, [x8, #0xbc8]       | X8 = 0x2B90238;                         
        // 0x02675CD4: LDR w0, [x8]               | W0 = 0x1752;                            
        // 0x02675CD8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1752, ????);     
        // 0x02675CDC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02675CE0: STRB w8, [x19, #0xe56]     | static_value_03740E56 = true;            //  dest_result_addr=57937494
        label_0:
        // 0x02675CE4: ADRP x19, #0x3668000       | X19 = 57049088 (0x3668000);             
        // 0x02675CE8: LDR x19, [x19, #0x338]     | X19 = 1152921509941328016;              
        // 0x02675CEC: MOV x0, x20                | X0 = 1152921509949112048 (0x100000013E6C7EF0);//ML01
        // 0x02675CF0: LDR x1, [x19]              | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x02675CF4: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_1 = this.GetComponent<UnityEngine.Camera>();
        // 0x02675CF8: LDR x1, [x19]              | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x02675CFC: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x02675D00: MOV x0, x20                | X0 = 1152921509949112048 (0x100000013E6C7EF0);//ML01
        // 0x02675D04: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_2 = this.GetComponent<UnityEngine.Camera>();
        // 0x02675D08: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x02675D0C: CBNZ x20, #0x2675d14       | if (val_2 != null) goto label_1;        
        if(val_2 != null)
        {
            goto label_1;
        }
        // 0x02675D10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_1:
        // 0x02675D14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02675D18: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x02675D1C: BL #0x20d2b10              | X0 = val_2.get_depthTextureMode();      
        UnityEngine.DepthTextureMode val_3 = val_2.depthTextureMode;
        // 0x02675D20: MOV w20, w0                | W20 = val_3;//m1                        
        // 0x02675D24: CBNZ x19, #0x2675d2c       | if (val_1 != null) goto label_2;        
        if(val_1 != null)
        {
            goto label_2;
        }
        // 0x02675D28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_2:
        // 0x02675D2C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02675D30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02675D34: ORR w1, w20, #1            | W1 = (val_3 | 1);                       
        UnityEngine.DepthTextureMode val_4 = val_3 | 1;
        // 0x02675D38: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x02675D3C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x02675D40: B #0x20d2b78               | val_1.set_depthTextureMode(value:  UnityEngine.DepthTextureMode val_4 = val_3 | 1); return;
        val_1.depthTextureMode = val_4;
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02675D44 (40328516), len: 380  VirtAddr: 0x02675D44 RVA: 0x02675D44 token: 100663334 methodIndex: 24418 delegateWrapperIndex: 0 methodInvoker: 0
    public override void OnDisable()
    {
        //
        // Disasemble & Code
        // 0x02675D44: STP x22, x21, [sp, #-0x30]! | stack[1152921509949248864] = ???;  stack[1152921509949248872] = ???;  //  dest_result_addr=1152921509949248864 |  dest_result_addr=1152921509949248872
        // 0x02675D48: STP x20, x19, [sp, #0x10]  | stack[1152921509949248880] = ???;  stack[1152921509949248888] = ???;  //  dest_result_addr=1152921509949248880 |  dest_result_addr=1152921509949248888
        // 0x02675D4C: STP x29, x30, [sp, #0x20]  | stack[1152921509949248896] = ???;  stack[1152921509949248904] = ???;  //  dest_result_addr=1152921509949248896 |  dest_result_addr=1152921509949248904
        // 0x02675D50: ADD x29, sp, #0x20         | X29 = (1152921509949248864 + 32) = 1152921509949248896 (0x100000013E6E9580);
        // 0x02675D54: ADRP x20, #0x3740000       | X20 = 57933824 (0x3740000);             
        // 0x02675D58: LDRB w8, [x20, #0xe57]     | W8 = (bool)static_value_03740E57;       
        // 0x02675D5C: MOV x19, x0                | X19 = 1152921509949260912 (0x100000013E6EC470);//ML01
        // 0x02675D60: TBNZ w8, #0, #0x2675d7c    | if (static_value_03740E57 == true) goto label_0;
        // 0x02675D64: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
        // 0x02675D68: LDR x8, [x8, #0x388]       | X8 = 0x2B90234;                         
        // 0x02675D6C: LDR w0, [x8]               | W0 = 0x1751;                            
        // 0x02675D70: BL #0x2782188              | X0 = sub_2782188( ?? 0x1751, ????);     
        // 0x02675D74: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02675D78: STRB w8, [x20, #0xe57]     | static_value_03740E57 = true;            //  dest_result_addr=57937495
        label_0:
        // 0x02675D7C: ADRP x21, #0x35fe000       | X21 = 56614912 (0x35FE000);             
        // 0x02675D80: LDR x21, [x21, #0x810]     | X21 = 1152921504697475072;              
        // 0x02675D84: LDR x20, [x19, #0x70]      | X20 = this.motionBlurMaterial; //P2     
        // 0x02675D88: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02675D8C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02675D90: TBZ w8, #0, #0x2675da0     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x02675D94: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02675D98: CBNZ w8, #0x2675da0        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x02675D9C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x02675DA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02675DA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02675DA8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02675DAC: MOV x2, x20                | X2 = this.motionBlurMaterial;//m1       
        // 0x02675DB0: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        // 0x02675DB4: TBZ w0, #0, #0x2675de8     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x02675DB8: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02675DBC: LDR x20, [x19, #0x70]      | X20 = this.motionBlurMaterial; //P2     
        // 0x02675DC0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02675DC4: TBZ w8, #0, #0x2675dd4     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x02675DC8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02675DCC: CBNZ w8, #0x2675dd4        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x02675DD0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_5:
        // 0x02675DD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02675DD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02675DDC: MOV x1, x20                | X1 = this.motionBlurMaterial;//m1       
        // 0x02675DE0: BL #0x1b78bac              | UnityEngine.Object.DestroyImmediate(obj:  0);
        UnityEngine.Object.DestroyImmediate(obj:  0);
        // 0x02675DE4: STR xzr, [x19, #0x70]      | this.motionBlurMaterial = null;          //  dest_result_addr=1152921509949261024
        this.motionBlurMaterial = 0;
        label_3:
        // 0x02675DE8: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02675DEC: LDR x20, [x19, #0x78]      | X20 = this.dx11MotionBlurMaterial; //P2 
        // 0x02675DF0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02675DF4: TBZ w8, #0, #0x2675e04     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x02675DF8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02675DFC: CBNZ w8, #0x2675e04        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x02675E00: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_7:
        // 0x02675E04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02675E08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02675E0C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02675E10: MOV x2, x20                | X2 = this.dx11MotionBlurMaterial;//m1   
        // 0x02675E14: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        bool val_2 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        // 0x02675E18: TBZ w0, #0, #0x2675e4c     | if (val_2 == false) goto label_8;       
        if(val_2 == false)
        {
            goto label_8;
        }
        // 0x02675E1C: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02675E20: LDR x20, [x19, #0x78]      | X20 = this.dx11MotionBlurMaterial; //P2 
        // 0x02675E24: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02675E28: TBZ w8, #0, #0x2675e38     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x02675E2C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02675E30: CBNZ w8, #0x2675e38        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x02675E34: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_10:
        // 0x02675E38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02675E3C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02675E40: MOV x1, x20                | X1 = this.dx11MotionBlurMaterial;//m1   
        // 0x02675E44: BL #0x1b78bac              | UnityEngine.Object.DestroyImmediate(obj:  0);
        UnityEngine.Object.DestroyImmediate(obj:  0);
        // 0x02675E48: STR xzr, [x19, #0x78]      | this.dx11MotionBlurMaterial = null;      //  dest_result_addr=1152921509949261032
        this.dx11MotionBlurMaterial = 0;
        label_8:
        // 0x02675E4C: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02675E50: LDR x20, [x19, #0x50]      | X20 = this.tmpCam; //P2                 
        // 0x02675E54: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02675E58: TBZ w8, #0, #0x2675e68     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x02675E5C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02675E60: CBNZ w8, #0x2675e68        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x02675E64: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_12:
        // 0x02675E68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02675E6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02675E70: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02675E74: MOV x2, x20                | X2 = this.tmpCam;//m1                   
        // 0x02675E78: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        bool val_3 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        // 0x02675E7C: TBZ w0, #0, #0x2675eb0     | if (val_3 == false) goto label_13;      
        if(val_3 == false)
        {
            goto label_13;
        }
        // 0x02675E80: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02675E84: LDR x20, [x19, #0x50]      | X20 = this.tmpCam; //P2                 
        // 0x02675E88: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02675E8C: TBZ w8, #0, #0x2675e9c     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_15;
        // 0x02675E90: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02675E94: CBNZ w8, #0x2675e9c        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
        // 0x02675E98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_15:
        // 0x02675E9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02675EA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02675EA4: MOV x1, x20                | X1 = this.tmpCam;//m1                   
        // 0x02675EA8: BL #0x1b78bac              | UnityEngine.Object.DestroyImmediate(obj:  0);
        UnityEngine.Object.DestroyImmediate(obj:  0);
        // 0x02675EAC: STR xzr, [x19, #0x50]      | this.tmpCam = null;                      //  dest_result_addr=1152921509949260992
        this.tmpCam = 0;
        label_13:
        // 0x02675EB0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x02675EB4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x02675EB8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x02675EBC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02675EC0 (40328896), len: 160  VirtAddr: 0x02675EC0 RVA: 0x02675EC0 token: 100663335 methodIndex: 24419 delegateWrapperIndex: 0 methodInvoker: 0
    public override bool CheckResources()
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.Shader val_2;
        //  | 
        var val_3;
        // 0x02675EC0: STP x20, x19, [sp, #-0x20]! | stack[1152921509949405936] = ???;  stack[1152921509949405944] = ???;  //  dest_result_addr=1152921509949405936 |  dest_result_addr=1152921509949405944
        // 0x02675EC4: STP x29, x30, [sp, #0x10]  | stack[1152921509949405952] = ???;  stack[1152921509949405960] = ???;  //  dest_result_addr=1152921509949405952 |  dest_result_addr=1152921509949405960
        // 0x02675EC8: ADD x29, sp, #0x10         | X29 = (1152921509949405936 + 16) = 1152921509949405952 (0x100000013E70FB00);
        // 0x02675ECC: MOV x19, x0                | X19 = 1152921509949417968 (0x100000013E7129F0);//ML01
        // 0x02675ED0: LDR x8, [x19]              | X8 = typeof(CameraMotionBlur);          
        // 0x02675ED4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x02675ED8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x02675EDC: LDP x9, x3, [x8, #0x1c0]   | X9 = typeof(CameraMotionBlur).__il2cppRuntimeField_1C0; X3 = typeof(CameraMotionBlur).__il2cppRuntimeField_1C8; //  | 
        // 0x02675EE0: BLR x9                     | X0 = typeof(CameraMotionBlur).__il2cppRuntimeField_1C0();
        // 0x02675EE4: LDR x8, [x19]              | X8 = typeof(CameraMotionBlur);          
        // 0x02675EE8: LDR x1, [x19, #0x58]       | X1 = this.shader; //P2                  
        val_2 = this.shader;
        // 0x02675EEC: LDR x2, [x19, #0x70]       | X2 = this.motionBlurMaterial; //P2      
        // 0x02675EF0: MOV x0, x19                | X0 = 1152921509949417968 (0x100000013E7129F0);//ML01
        // 0x02675EF4: LDP x9, x3, [x8, #0x150]   | X9 = typeof(CameraMotionBlur).__il2cppRuntimeField_150; X3 = typeof(CameraMotionBlur).__il2cppRuntimeField_158; //  | 
        // 0x02675EF8: BLR x9                     | X0 = typeof(CameraMotionBlur).__il2cppRuntimeField_150();
        // 0x02675EFC: LDRB w8, [x19, #0x19]      | 
        // 0x02675F00: STR x0, [x19, #0x70]       | this.motionBlurMaterial = this;          //  dest_result_addr=1152921509949418080
        this.motionBlurMaterial = this;
        // 0x02675F04: CBZ w8, #0x2675f30         | if (typeof(CameraMotionBlur) == null) goto label_1;
        if(null == null)
        {
            goto label_1;
        }
        // 0x02675F08: LDR w8, [x19, #0x1c]       | W8 = this.filterType; //P2              
        // 0x02675F0C: CMP w8, #3                 | STATE = COMPARE(this.filterType, 0x3)   
        // 0x02675F10: B.NE #0x2675f30            | if (this.filterType != 0x3) goto label_1;
        if(this.filterType != 3)
        {
            goto label_1;
        }
        // 0x02675F14: LDR x8, [x19]              | X8 = typeof(CameraMotionBlur);          
        // 0x02675F18: LDR x1, [x19, #0x60]       | X1 = this.dx11MotionBlurShader; //P2    
        val_2 = this.dx11MotionBlurShader;
        // 0x02675F1C: LDR x2, [x19, #0x78]       | X2 = this.dx11MotionBlurMaterial; //P2  
        // 0x02675F20: MOV x0, x19                | X0 = 1152921509949417968 (0x100000013E7129F0);//ML01
        // 0x02675F24: LDP x9, x3, [x8, #0x150]   | X9 = typeof(CameraMotionBlur).__il2cppRuntimeField_150; X3 = typeof(CameraMotionBlur).__il2cppRuntimeField_158; //  | 
        // 0x02675F28: BLR x9                     | X0 = typeof(CameraMotionBlur).__il2cppRuntimeField_150();
        // 0x02675F2C: STR x0, [x19, #0x78]       | this.dx11MotionBlurMaterial = this;      //  dest_result_addr=1152921509949418088
        this.dx11MotionBlurMaterial = this;
        label_1:
        // 0x02675F30: LDRB w8, [x19, #0x1a]      | 
        // 0x02675F34: CBNZ w8, #0x2675f4c        | if (typeof(CameraMotionBlur) != null) goto label_2;
        if(null != null)
        {
            goto label_2;
        }
        // 0x02675F38: LDR x8, [x19]              | X8 = typeof(CameraMotionBlur);          
        // 0x02675F3C: MOV x0, x19                | X0 = 1152921509949417968 (0x100000013E7129F0);//ML01
        // 0x02675F40: LDP x9, x1, [x8, #0x1e0]   | X9 = typeof(CameraMotionBlur).__il2cppRuntimeField_1E0; X1 = typeof(CameraMotionBlur).__il2cppRuntimeField_1E8; //  | 
        // 0x02675F44: BLR x9                     | X0 = typeof(CameraMotionBlur).__il2cppRuntimeField_1E0();
        // 0x02675F48: LDRB w8, [x19, #0x1a]      | 
        label_2:
        // 0x02675F4C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02675F50: CMP w8, #0                 | STATE = COMPARE(typeof(CameraMotionBlur), 0x0)
        // 0x02675F54: CSET w0, ne                | W0 = typeof(CameraMotionBlur) != null ? 1 : 0;
        var val_1 = (null != 0) ? 1 : 0;
        // 0x02675F58: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x02675F5C: RET                        |  return (System.Boolean)typeof(CameraMotionBlur) != null ? 1 : 0;
        return (bool)val_1;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x02675F60 (40329056), len: 6704  VirtAddr: 0x02675F60 RVA: 0x02675F60 token: 100663336 methodIndex: 24420 delegateWrapperIndex: 0 methodInvoker: 0
    public override void OnRenderImage(UnityEngine.RenderTexture source, UnityEngine.RenderTexture destination)
    {
        //
        // Disasemble & Code
        //  | 
        float val_18;
        //  | 
        float val_19;
        //  | 
        float val_20;
        //  | 
        float val_21;
        //  | 
        float val_23;
        //  | 
        float val_24;
        //  | 
        float val_25;
        //  | 
        float val_26;
        //  | 
        float val_38;
        //  | 
        float val_39;
        //  | 
        float val_40;
        //  | 
        float val_41;
        //  | 
        float val_43;
        //  | 
        float val_44;
        //  | 
        float val_45;
        //  | 
        float val_46;
        //  | 
        var val_103;
        //  | 
        var val_104;
        //  | 
        var val_105;
        //  | 
        var val_106;
        //  | 
        float val_107;
        //  | 
        string val_108;
        //  | 
        var val_109;
        //  | 
        float val_110;
        //  | 
        float val_111;
        //  | 
        float val_112;
        //  | 
        var val_113;
        //  | 
        UnityEngine.LayerMask val_114;
        //  | 
        UnityEngine.Material val_115;
        //  | 
        var val_116;
        //  | 
        float val_117;
        //  | 
        var val_118;
        //  | 
        float val_119;
        //  | 
        float val_120;
        //  | 
        float val_121;
        //  | 
        float val_122;
        //  | 
        UnityEngine.RenderTexture val_123;
        //  | 
        UnityEngine.Texture val_124;
        //  | 
        UnityEngine.RenderTexture val_125;
        //  | 
        UnityEngine.Material val_126;
        // 0x02675F60: STP d15, d14, [sp, #-0xa0]! | stack[1152921509949872032] = ???;  stack[1152921509949872040] = ???;  //  dest_result_addr=1152921509949872032 |  dest_result_addr=1152921509949872040
        // 0x02675F64: STP d13, d12, [sp, #0x10]  | stack[1152921509949872048] = ???;  stack[1152921509949872056] = ???;  //  dest_result_addr=1152921509949872048 |  dest_result_addr=1152921509949872056
        // 0x02675F68: STP d11, d10, [sp, #0x20]  | stack[1152921509949872064] = ???;  stack[1152921509949872072] = ???;  //  dest_result_addr=1152921509949872064 |  dest_result_addr=1152921509949872072
        // 0x02675F6C: STP d9, d8, [sp, #0x30]    | stack[1152921509949872080] = ???;  stack[1152921509949872088] = ???;  //  dest_result_addr=1152921509949872080 |  dest_result_addr=1152921509949872088
        // 0x02675F70: STP x28, x27, [sp, #0x40]  | stack[1152921509949872096] = ???;  stack[1152921509949872104] = ???;  //  dest_result_addr=1152921509949872096 |  dest_result_addr=1152921509949872104
        // 0x02675F74: STP x26, x25, [sp, #0x50]  | stack[1152921509949872112] = ???;  stack[1152921509949872120] = ???;  //  dest_result_addr=1152921509949872112 |  dest_result_addr=1152921509949872120
        // 0x02675F78: STP x24, x23, [sp, #0x60]  | stack[1152921509949872128] = ???;  stack[1152921509949872136] = ???;  //  dest_result_addr=1152921509949872128 |  dest_result_addr=1152921509949872136
        // 0x02675F7C: STP x22, x21, [sp, #0x70]  | stack[1152921509949872144] = ???;  stack[1152921509949872152] = ???;  //  dest_result_addr=1152921509949872144 |  dest_result_addr=1152921509949872152
        // 0x02675F80: STP x20, x19, [sp, #0x80]  | stack[1152921509949872160] = ???;  stack[1152921509949872168] = ???;  //  dest_result_addr=1152921509949872160 |  dest_result_addr=1152921509949872168
        // 0x02675F84: STP x29, x30, [sp, #0x90]  | stack[1152921509949872176] = ???;  stack[1152921509949872184] = ???;  //  dest_result_addr=1152921509949872176 |  dest_result_addr=1152921509949872184
        // 0x02675F88: ADD x29, sp, #0x90         | X29 = (1152921509949872032 + 144) = 1152921509949872176 (0x100000013E781830);
        // 0x02675F8C: SUB sp, sp, #0x6e0         | SP = (1152921509949872032 - 1760) = 1152921509949870272 (0x100000013E7810C0);
        // 0x02675F90: ADRP x19, #0x3740000       | X19 = 57933824 (0x3740000);             
        // 0x02675F94: LDRB w8, [x19, #0xe58]     | W8 = (bool)static_value_03740E58;       
        // 0x02675F98: MOV x22, x2                | X22 = destination;//m1                  
        // 0x02675F9C: MOV x20, x1                | X20 = source;//m1                       
        // 0x02675FA0: MOV x21, x0                | X21 = 1152921509949884192 (0x100000013E784720);//ML01
        val_105 = this;
        // 0x02675FA4: TBNZ w8, #0, #0x2675fc0    | if (static_value_03740E58 == true) goto label_0;
        // 0x02675FA8: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
        // 0x02675FAC: LDR x8, [x8, #0x9f8]       | X8 = 0x2B9023C;                         
        // 0x02675FB0: LDR w0, [x8]               | W0 = 0x1753;                            
        // 0x02675FB4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1753, ????);     
        // 0x02675FB8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02675FBC: STRB w8, [x19, #0xe58]     | static_value_03740E58 = true;            //  dest_result_addr=57937496
        label_0:
        // 0x02675FC0: STP xzr, xzr, [x29, #-0xa0] | stack[1152921509949872016] = 0x0;  stack[1152921509949872024] = 0x0;  //  dest_result_addr=1152921509949872016 |  dest_result_addr=1152921509949872024
        // 0x02675FC4: STP xzr, xzr, [x29, #-0xb0] | stack[1152921509949872000] = 0x0;  stack[1152921509949872008] = 0x0;  //  dest_result_addr=1152921509949872000 |  dest_result_addr=1152921509949872008
        // 0x02675FC8: STP xzr, xzr, [x29, #-0xc0] | stack[1152921509949871984] = 0x0;  stack[1152921509949871992] = 0x0;  //  dest_result_addr=1152921509949871984 |  dest_result_addr=1152921509949871992
        // 0x02675FCC: STP xzr, xzr, [x29, #-0xd0] | stack[1152921509949871968] = 0x0;  stack[1152921509949871976] = 0x0;  //  dest_result_addr=1152921509949871968 |  dest_result_addr=1152921509949871976
        // 0x02675FD0: STR xzr, [sp, #0x698]      | stack[1152921509949871960] = 0x0;        //  dest_result_addr=1152921509949871960
        // 0x02675FD4: STR xzr, [sp, #0x690]      | stack[1152921509949871952] = 0x0;        //  dest_result_addr=1152921509949871952
        // 0x02675FD8: STR xzr, [sp, #0x688]      | stack[1152921509949871944] = 0x0;        //  dest_result_addr=1152921509949871944
        // 0x02675FDC: STR xzr, [sp, #0x680]      | stack[1152921509949871936] = 0x0;        //  dest_result_addr=1152921509949871936
        // 0x02675FE0: STR xzr, [sp, #0x678]      | stack[1152921509949871928] = 0x0;        //  dest_result_addr=1152921509949871928
        // 0x02675FE4: STR xzr, [sp, #0x670]      | stack[1152921509949871920] = 0x0;        //  dest_result_addr=1152921509949871920
        // 0x02675FE8: STR xzr, [sp, #0x668]      | stack[1152921509949871912] = 0x0;        //  dest_result_addr=1152921509949871912
        // 0x02675FEC: STR xzr, [sp, #0x660]      | stack[1152921509949871904] = 0x0;        //  dest_result_addr=1152921509949871904
        // 0x02675FF0: STR xzr, [sp, #0x658]      | stack[1152921509949871896] = 0x0;        //  dest_result_addr=1152921509949871896
        // 0x02675FF4: STR xzr, [sp, #0x650]      | stack[1152921509949871888] = 0x0;        //  dest_result_addr=1152921509949871888
        // 0x02675FF8: STR xzr, [sp, #0x648]      | stack[1152921509949871880] = 0x0;        //  dest_result_addr=1152921509949871880
        // 0x02675FFC: STR xzr, [sp, #0x640]      | stack[1152921509949871872] = 0x0;        //  dest_result_addr=1152921509949871872
        // 0x02676000: STR xzr, [sp, #0x638]      | stack[1152921509949871864] = 0x0;        //  dest_result_addr=1152921509949871864
        // 0x02676004: STR xzr, [sp, #0x630]      | stack[1152921509949871856] = 0x0;        //  dest_result_addr=1152921509949871856
        // 0x02676008: STR xzr, [sp, #0x628]      | stack[1152921509949871848] = 0x0;        //  dest_result_addr=1152921509949871848
        // 0x0267600C: STR xzr, [sp, #0x620]      | stack[1152921509949871840] = 0x0;        //  dest_result_addr=1152921509949871840
        // 0x02676010: STR wzr, [sp, #0x618]      | stack[1152921509949871832] = 0x0;        //  dest_result_addr=1152921509949871832
        // 0x02676014: STR xzr, [sp, #0x610]      | stack[1152921509949871824] = 0x0;        //  dest_result_addr=1152921509949871824
        // 0x02676018: LDR x8, [x21]              | X8 = typeof(CameraMotionBlur);          
        // 0x0267601C: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676020: LDP x9, x1, [x8, #0x190]   | X9 = typeof(CameraMotionBlur).__il2cppRuntimeField_190; X1 = typeof(CameraMotionBlur).__il2cppRuntimeField_198; //  | 
        // 0x02676024: BLR x9                     | X0 = typeof(CameraMotionBlur).__il2cppRuntimeField_190();
        // 0x02676028: AND w8, w0, #1             | W8 = (this & 1) = 0 (0x00000000);       
        // 0x0267602C: TBZ w8, #0, #0x2676190     | if (((CameraMotionBlur)[1152921509949884192] & 0x1) == 0) goto label_1;
        if((0 & 1) == 0)
        {
            goto label_1;
        }
        // 0x02676030: LDR w8, [x21, #0x1c]       | W8 = this.filterType; //P2              
        // 0x02676034: CBNZ w8, #0x267604c        | if (this.filterType != 0) goto label_2; 
        if(this.filterType != 0)
        {
            goto label_2;
        }
        // 0x02676038: LDR x8, [x21]              | X8 = typeof(CameraMotionBlur);          
        // 0x0267603C: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676040: LDR x9, [x8, #0x270]       | X9 = typeof(CameraMotionBlur).__il2cppRuntimeField_270;
        // 0x02676044: LDR x1, [x8, #0x278]       | X1 = typeof(CameraMotionBlur).__il2cppRuntimeField_278;
        // 0x02676048: BLR x9                     | X0 = typeof(CameraMotionBlur).__il2cppRuntimeField_270();
        label_2:
        // 0x0267604C: MOVZ w1, #0xd              | W1 = 13 (0xD);//ML01                    
        // 0x02676050: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676054: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02676058: STR x22, [sp, #0x48]       | stack[1152921509949870344] = destination;  //  dest_result_addr=1152921509949870344
        // 0x0267605C: MOVZ w19, #0xd             | W19 = 13 (0xD);//ML01                   
        // 0x02676060: BL #0x268e294              | X0 = UnityEngine.SystemInfo.SupportsRenderTextureFormat(format:  0);
        bool val_1 = UnityEngine.SystemInfo.SupportsRenderTextureFormat(format:  0);
        // 0x02676064: TST w0, #1                 | STATE = COMPARE(val_1, 0x1)             
        // 0x02676068: ORR w8, wzr, #2            | W8 = 2(0x2);                            
        // 0x0267606C: CSEL w24, w19, w8, ne      | W24 = val_1 != true ? 13 : 2;           
        var val_2 = (val_1 != true) ? 13 : (2);
        // 0x02676070: CBNZ x20, #0x2676078       | if (source != null) goto label_3;       
        if(source != null)
        {
            goto label_3;
        }
        // 0x02676074: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x02676078: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x0267607C: MOV x0, x20                | X0 = source;//m1                        
        // 0x02676080: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x02676084: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x02676088: LDR x8, [x21]              | X8 = typeof(CameraMotionBlur);          
        // 0x0267608C: LDR w2, [x21, #0x48]       | W2 = this.velocityDownsample; //P2      
        // 0x02676090: MOV w1, w0                 | W1 = source;//m1                        
        // 0x02676094: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676098: LDR x9, [x8, #0x280]       | X9 = typeof(CameraMotionBlur).__il2cppRuntimeField_280;
        // 0x0267609C: LDR x3, [x8, #0x288]       | X3 = typeof(CameraMotionBlur).__il2cppRuntimeField_288;
        // 0x026760A0: BLR x9                     | X0 = typeof(CameraMotionBlur).__il2cppRuntimeField_280();
        // 0x026760A4: MOV w22, w0                | W22 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x026760A8: CBNZ x20, #0x26760b0       | if (source != null) goto label_4;       
        if(source != null)
        {
            goto label_4;
        }
        // 0x026760AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_4:
        // 0x026760B0: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x026760B4: MOV x0, x20                | X0 = source;//m1                        
        // 0x026760B8: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x026760BC: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x026760C0: LDR x8, [x21]              | X8 = typeof(CameraMotionBlur);          
        // 0x026760C4: LDR w2, [x21, #0x48]       | W2 = this.velocityDownsample; //P2      
        // 0x026760C8: MOV w1, w0                 | W1 = source;//m1                        
        // 0x026760CC: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x026760D0: LDR x9, [x8, #0x280]       | X9 = typeof(CameraMotionBlur).__il2cppRuntimeField_280;
        // 0x026760D4: LDR x3, [x8, #0x288]       | X3 = typeof(CameraMotionBlur).__il2cppRuntimeField_288;
        // 0x026760D8: BLR x9                     | X0 = typeof(CameraMotionBlur).__il2cppRuntimeField_280();
        // 0x026760DC: MOV w2, w0                 | W2 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x026760E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026760E4: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x026760E8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026760EC: MOV w1, w22                | W1 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x026760F0: MOV w4, w24                | W4 = val_1 != true ? 13 : 2;//m1        
        // 0x026760F4: BL #0x1b89134              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  1048069920, depthBuffer:  1048069920, format:  0);
        UnityEngine.RenderTexture val_3 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  1048069920, depthBuffer:  1048069920, format:  0);
        // 0x026760F8: ADRP x25, #0x363f000       | X25 = 56881152 (0x363F000);             
        // 0x026760FC: LDR x25, [x25, #0x3b0]     | X25 = 1152921504695345152;              
        // 0x02676100: LDR s8, [x21, #0x38]       | S8 = this.maxVelocity; //P2             
        // 0x02676104: MOV x22, x0                | X22 = val_3;//m1                        
        // 0x02676108: LDR x8, [x25]              | X8 = typeof(UnityEngine.Mathf);         
        // 0x0267610C: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x02676110: TBZ w9, #0, #0x2676124     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x02676114: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x02676118: CBNZ w9, #0x2676124        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x0267611C: MOV x0, x8                 | X0 = 1152921504695345152 (0x1000000005466000);//ML01
        // 0x02676120: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_6:
        // 0x02676124: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676128: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267612C: FMOV s0, #2.00000000       | S0 = 2;                                 
        // 0x02676130: MOV v1.16b, v8.16b         | V1 = this.maxVelocity;//m1              
        // 0x02676134: BL #0x1a7d940              | X0 = UnityEngine.Mathf.Max(a:  2f, b:  this.maxVelocity);
        float val_4 = UnityEngine.Mathf.Max(a:  2f, b:  this.maxVelocity);
        // 0x02676138: LDR w8, [x21, #0x1c]       | W8 = this.filterType; //P2              
        // 0x0267613C: STR s0, [x21, #0x38]       | this.maxVelocity = val_4;                //  dest_result_addr=1152921509949884248
        this.maxVelocity = val_4;
        // 0x02676140: CMP w8, #3                 | STATE = COMPARE(this.filterType, 0x3)   
        // 0x02676144: B.NE #0x26761cc            | if (this.filterType != 0x3) goto label_7;
        if(this.filterType != 3)
        {
            goto label_7;
        }
        // 0x02676148: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x0267614C: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x02676150: LDR x23, [x21, #0x78]      | X23 = this.dx11MotionBlurMaterial; //P2 
        // 0x02676154: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x02676158: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x0267615C: TBZ w8, #0, #0x267616c     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x02676160: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02676164: CBNZ w8, #0x267616c        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x02676168: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_9:
        // 0x0267616C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676170: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02676174: MOV x1, x23                | X1 = this.dx11MotionBlurMaterial;//m1   
        // 0x02676178: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0267617C: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  this.dx11MotionBlurMaterial);
        bool val_5 = UnityEngine.Object.op_Equality(x:  0, y:  this.dx11MotionBlurMaterial);
        // 0x02676180: AND w8, w0, #1             | W8 = (val_5 & 1);                       
        bool val_6 = val_5;
        // 0x02676184: TBZ w8, #0, #0x26761c8     | if ((val_5 & 1) == false) goto label_10;
        if(val_6 == false)
        {
            goto label_10;
        }
        // 0x02676188: ORR w10, wzr, #1           | W10 = 1(0x1);                           
        // 0x0267618C: B #0x26761e0               |  goto label_15;                         
        goto label_15;
        label_1:
        // 0x02676190: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02676194: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02676198: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x0267619C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x026761A0: TBZ w8, #0, #0x26761b0     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x026761A4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x026761A8: CBNZ w8, #0x26761b0        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x026761AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_13:
        // 0x026761B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026761B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x026761B8: MOV x1, x20                | X1 = source;//m1                        
        // 0x026761BC: MOV x2, x22                | X2 = destination;//m1                   
        // 0x026761C0: BL #0x1a6ba68              | UnityEngine.Graphics.Blit(source:  0, dest:  source);
        UnityEngine.Graphics.Blit(source:  0, dest:  source);
        // 0x026761C4: B #0x2677808               |  goto label_14;                         
        goto label_14;
        label_10:
        // 0x026761C8: LDR w8, [x21, #0x1c]       | W8 = this.filterType; //P2              
        label_7:
        // 0x026761CC: MOV w10, wzr               | W10 = 0 (0x0);//ML01                    
        // 0x026761D0: CMP w8, #4                 | STATE = COMPARE(this.filterType, 0x4)   
        // 0x026761D4: B.EQ #0x26761e0            | if (this.filterType == 0x4) goto label_15;
        if(this.filterType == 4)
        {
            goto label_15;
        }
        // 0x026761D8: CMP w8, #2                 | STATE = COMPARE(this.filterType, 0x2)   
        // 0x026761DC: B.NE #0x2676208            | if (this.filterType != 0x2) goto label_16;
        if(this.filterType != 2)
        {
            goto label_16;
        }
        label_15:
        // 0x026761E0: ADRP x19, #0x3601000       | X19 = 56627200 (0x3601000);             
        // 0x026761E4: LDR x19, [x19, #0x88]      | X19 = 1152921504778838016;              
        // 0x026761E8: LDR s8, [x21, #0x38]       | S8 = this.maxVelocity; //P2             
        // 0x026761EC: LDR x0, [x19]              | X0 = typeof(CameraMotionBlur);          
        // 0x026761F0: LDRB w8, [x0, #0x10a]      | W8 = CameraMotionBlur.__il2cppRuntimeField_10A;
        // 0x026761F4: TBZ w8, #0, #0x2676200     | if (CameraMotionBlur.__il2cppRuntimeField_has_cctor == 0) goto label_17;
        // 0x026761F8: LDR w8, [x0, #0xbc]        | W8 = CameraMotionBlur.__il2cppRuntimeField_cctor_finished;
        // 0x026761FC: CBZ w8, #0x26762a0         | if (CameraMotionBlur.__il2cppRuntimeField_cctor_finished == 0) goto label_18;
        label_17:
        // 0x02676200: STR w10, [sp, #0x44]       | stack[1152921509949870340] = 0x0;        //  dest_result_addr=1152921509949870340
        // 0x02676204: B #0x26762ac               |  goto label_19;                         
        goto label_19;
        label_16:
        // 0x02676208: CBNZ x22, #0x2676210       | if (val_3 != null) goto label_20;       
        if(val_3 != null)
        {
            goto label_20;
        }
        // 0x0267620C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_20:
        // 0x02676210: LDR x8, [x22]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02676214: MOV x0, x22                | X0 = val_3;//m1                         
        // 0x02676218: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x0267621C: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x02676220: LDR x8, [x21]              | X8 = typeof(CameraMotionBlur);          
        // 0x02676224: LDR s0, [x21, #0x38]       | S0 = this.maxVelocity; //P2             
        // 0x02676228: MOV w1, w0                 | W1 = val_3;//m1                         
        // 0x0267622C: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676230: LDR x9, [x8, #0x280]       | X9 = typeof(CameraMotionBlur).__il2cppRuntimeField_280;
        // 0x02676234: LDR x3, [x8, #0x288]       | X3 = typeof(CameraMotionBlur).__il2cppRuntimeField_288;
        // 0x02676238: FCVTZS w2, s0              | W2 = (int)(this.maxVelocity);           
        // 0x0267623C: BLR x9                     | X0 = typeof(CameraMotionBlur).__il2cppRuntimeField_280();
        // 0x02676240: MOV w25, w0                | W25 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676244: CBNZ x22, #0x267624c       | if (val_3 != null) goto label_21;       
        if(val_3 != null)
        {
            goto label_21;
        }
        // 0x02676248: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_21:
        // 0x0267624C: LDR x8, [x22]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02676250: MOV x0, x22                | X0 = val_3;//m1                         
        // 0x02676254: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x02676258: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x0267625C: LDR x8, [x21]              | X8 = typeof(CameraMotionBlur);          
        // 0x02676260: LDR s0, [x21, #0x38]       | S0 = this.maxVelocity; //P2             
        // 0x02676264: MOV w1, w0                 | W1 = val_3;//m1                         
        // 0x02676268: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x0267626C: LDR x9, [x8, #0x280]       | X9 = typeof(CameraMotionBlur).__il2cppRuntimeField_280;
        // 0x02676270: LDR x3, [x8, #0x288]       | X3 = typeof(CameraMotionBlur).__il2cppRuntimeField_288;
        // 0x02676274: FCVTZS w2, s0              | W2 = (int)(this.maxVelocity);           
        // 0x02676278: BLR x9                     | X0 = typeof(CameraMotionBlur).__il2cppRuntimeField_280();
        // 0x0267627C: MOV w26, w0                | W26 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676280: CBNZ x22, #0x2676288       | if (val_3 != null) goto label_22;       
        if(val_3 != null)
        {
            goto label_22;
        }
        // 0x02676284: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_22:
        // 0x02676288: LDR x8, [x22]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x0267628C: MOV x0, x22                | X0 = val_3;//m1                         
        // 0x02676290: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x02676294: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x02676298: STR wzr, [sp, #0x44]       | stack[1152921509949870340] = 0x0;        //  dest_result_addr=1152921509949870340
        // 0x0267629C: B #0x2676374               |  goto label_23;                         
        goto label_23;
        label_18:
        // 0x026762A0: STR w10, [sp, #0x44]       | stack[1152921509949870340] = 0x0;        //  dest_result_addr=1152921509949870340
        // 0x026762A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraMotionBlur), ????);
        // 0x026762A8: LDR x0, [x19]              | X0 = typeof(CameraMotionBlur);          
        label_19:
        // 0x026762AC: LDR x8, [x0, #0xa0]        | X8 = CameraMotionBlur.__il2cppRuntimeField_static_fields;
        // 0x026762B0: LDR x0, [x25]              | X0 = typeof(UnityEngine.Mathf);         
        // 0x026762B4: LDR w19, [x8]              | W19 = CameraMotionBlur.MAX_RADIUS;      
        // 0x026762B8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x026762BC: TBZ w8, #0, #0x26762cc     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_25;
        // 0x026762C0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x026762C4: CBNZ w8, #0x26762cc        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
        // 0x026762C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_25:
        // 0x026762CC: SCVTF s1, w19              | S1 = (float)(CameraMotionBlur.MAX_RADIUS);
        // 0x026762D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026762D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026762D8: MOV v0.16b, v8.16b         | V0 = this.maxVelocity;//m1              
        // 0x026762DC: BL #0x1a7d7bc              | X0 = UnityEngine.Mathf.Min(a:  this.maxVelocity, b:  (float)CameraMotionBlur.MAX_RADIUS);
        float val_7 = UnityEngine.Mathf.Min(a:  this.maxVelocity, b:  (float)CameraMotionBlur.MAX_RADIUS);
        // 0x026762E0: STR s0, [x21, #0x38]       | this.maxVelocity = val_7;                //  dest_result_addr=1152921509949884248
        this.maxVelocity = val_7;
        // 0x026762E4: CBNZ x22, #0x26762ec       | if (val_3 != null) goto label_26;       
        if(val_3 != null)
        {
            goto label_26;
        }
        // 0x026762E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_26:
        // 0x026762EC: LDR x8, [x22]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x026762F0: MOV x0, x22                | X0 = val_3;//m1                         
        // 0x026762F4: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x026762F8: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x026762FC: LDR x8, [x21]              | X8 = typeof(CameraMotionBlur);          
        // 0x02676300: LDR s0, [x21, #0x38]       | S0 = this.maxVelocity; //P2             
        // 0x02676304: MOV w1, w0                 | W1 = val_3;//m1                         
        // 0x02676308: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x0267630C: LDR x9, [x8, #0x280]       | X9 = typeof(CameraMotionBlur).__il2cppRuntimeField_280;
        // 0x02676310: LDR x3, [x8, #0x288]       | X3 = typeof(CameraMotionBlur).__il2cppRuntimeField_288;
        // 0x02676314: FCVTZS w2, s0              | W2 = (int)(this.maxVelocity);           
        // 0x02676318: BLR x9                     | X0 = typeof(CameraMotionBlur).__il2cppRuntimeField_280();
        // 0x0267631C: MOV w25, w0                | W25 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676320: CBNZ x22, #0x2676328       | if (val_3 != null) goto label_27;       
        if(val_3 != null)
        {
            goto label_27;
        }
        // 0x02676324: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_27:
        // 0x02676328: LDR x8, [x22]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x0267632C: MOV x0, x22                | X0 = val_3;//m1                         
        // 0x02676330: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x02676334: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x02676338: LDR x8, [x21]              | X8 = typeof(CameraMotionBlur);          
        // 0x0267633C: LDR s0, [x21, #0x38]       | S0 = this.maxVelocity; //P2             
        // 0x02676340: MOV w1, w0                 | W1 = val_3;//m1                         
        // 0x02676344: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676348: LDR x9, [x8, #0x280]       | X9 = typeof(CameraMotionBlur).__il2cppRuntimeField_280;
        // 0x0267634C: LDR x3, [x8, #0x288]       | X3 = typeof(CameraMotionBlur).__il2cppRuntimeField_288;
        // 0x02676350: FCVTZS w2, s0              | W2 = (int)(this.maxVelocity);           
        // 0x02676354: BLR x9                     | X0 = typeof(CameraMotionBlur).__il2cppRuntimeField_280();
        // 0x02676358: MOV w26, w0                | W26 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x0267635C: CBNZ x22, #0x2676364       | if (val_3 != null) goto label_28;       
        if(val_3 != null)
        {
            goto label_28;
        }
        // 0x02676360: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_28:
        // 0x02676364: LDR x8, [x22]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02676368: MOV x0, x22                | X0 = val_3;//m1                         
        // 0x0267636C: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x02676370: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        label_23:
        // 0x02676374: SDIV w27, w0, w25          | W27 = (val_3 / this);                   
        UnityEngine.RenderTexture val_8 = val_3 / val_105;
        // 0x02676378: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267637C: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x02676380: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02676384: MOV w1, w25                | W1 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676388: MOV w2, w26                | W2 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x0267638C: MOV w4, w24                | W4 = val_1 != true ? 13 : 2;//m1        
        // 0x02676390: BL #0x1b89134              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  1048069920, depthBuffer:  1048069920, format:  0);
        UnityEngine.RenderTexture val_9 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  1048069920, depthBuffer:  1048069920, format:  0);
        // 0x02676394: MOV x23, x0                | X23 = val_9;//m1                        
        // 0x02676398: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267639C: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x026763A0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026763A4: MOV w1, w25                | W1 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x026763A8: MOV w2, w26                | W2 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x026763AC: MOV w4, w24                | W4 = val_1 != true ? 13 : 2;//m1        
        // 0x026763B0: BL #0x1b89134              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  1048069920, depthBuffer:  1048069920, format:  0);
        UnityEngine.RenderTexture val_10 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  1048069920, depthBuffer:  1048069920, format:  0);
        // 0x026763B4: MOV x24, x0                | X24 = val_10;//m1                       
        // 0x026763B8: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x026763BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026763C0: MOV x0, x22                | X0 = val_3;//m1                         
        // 0x026763C4: BL #0x268eee8              | val_3.set_filterMode(value:  0);        
        val_3.filterMode = 0;
        // 0x026763C8: CBNZ x23, #0x26763d0       | if (val_9 != null) goto label_29;       
        if(val_9 != null)
        {
            goto label_29;
        }
        // 0x026763CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_29:
        // 0x026763D0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x026763D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026763D8: MOV x0, x23                | X0 = val_9;//m1                         
        // 0x026763DC: BL #0x268eee8              | val_9.set_filterMode(value:  0);        
        val_9.filterMode = 0;
        // 0x026763E0: CBNZ x24, #0x26763e8       | if (val_10 != null) goto label_30;      
        if(val_10 != null)
        {
            goto label_30;
        }
        // 0x026763E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_30:
        // 0x026763E8: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x026763EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026763F0: MOV x0, x24                | X0 = val_10;//m1                        
        // 0x026763F4: BL #0x268eee8              | val_10.set_filterMode(value:  0);       
        val_10.filterMode = 0;
        // 0x026763F8: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x026763FC: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x02676400: LDR x25, [x21, #0x80]      | X25 = this.noiseTexture; //P2           
        // 0x02676404: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x02676408: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x0267640C: TBZ w8, #0, #0x267641c     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_32;
        // 0x02676410: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02676414: CBNZ w8, #0x267641c        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_32;
        // 0x02676418: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_32:
        // 0x0267641C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676420: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02676424: MOV x1, x25                | X1 = this.noiseTexture;//m1             
        // 0x02676428: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_11 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x0267642C: TBZ w0, #0, #0x267644c     | if (val_11 == false) goto label_33;     
        if(val_11 == false)
        {
            goto label_33;
        }
        // 0x02676430: LDR x25, [x21, #0x80]      | X25 = this.noiseTexture; //P2           
        // 0x02676434: CBNZ x25, #0x267643c       | if (this.noiseTexture != null) goto label_34;
        if(this.noiseTexture != null)
        {
            goto label_34;
        }
        // 0x02676438: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_34:
        // 0x0267643C: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x02676440: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02676444: MOV x0, x25                | X0 = this.noiseTexture;//m1             
        // 0x02676448: BL #0x268eee8              | this.noiseTexture.set_filterMode(value:  0);
        this.noiseTexture.filterMode = 0;
        label_33:
        // 0x0267644C: CBNZ x20, #0x2676454       | if (source != null) goto label_35;      
        if(source != null)
        {
            goto label_35;
        }
        // 0x02676450: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.noiseTexture, ????);
        label_35:
        // 0x02676454: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02676458: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x0267645C: MOV x0, x20                | X0 = source;//m1                        
        // 0x02676460: BL #0x268f0a8              | source.set_wrapMode(value:  1);         
        source.wrapMode = 1;
        // 0x02676464: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02676468: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x0267646C: MOV x0, x22                | X0 = val_3;//m1                         
        // 0x02676470: BL #0x268f0a8              | val_3.set_wrapMode(value:  1);          
        val_3.wrapMode = 1;
        // 0x02676474: CBNZ x24, #0x267647c       | if (val_10 != null) goto label_36;      
        if(val_10 != null)
        {
            goto label_36;
        }
        // 0x02676478: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_36:
        // 0x0267647C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02676480: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x02676484: MOV x0, x24                | X0 = val_10;//m1                        
        // 0x02676488: BL #0x268f0a8              | val_10.set_wrapMode(value:  1);         
        val_10.wrapMode = 1;
        // 0x0267648C: CBNZ x23, #0x2676494       | if (val_9 != null) goto label_37;       
        if(val_9 != null)
        {
            goto label_37;
        }
        // 0x02676490: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_37:
        // 0x02676494: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02676498: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x0267649C: MOV x0, x23                | X0 = val_9;//m1                         
        // 0x026764A0: BL #0x268f0a8              | val_9.set_wrapMode(value:  1);          
        val_9.wrapMode = 1;
        // 0x026764A4: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x026764A8: BL #0x2675a9c              | this.CalculateViewProjection();         
        this.CalculateViewProjection();
        // 0x026764AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026764B0: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x026764B4: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_12 = this.gameObject;
        // 0x026764B8: MOV x25, x0                | X25 = val_12;//m1                       
        // 0x026764BC: CBNZ x25, #0x26764c4       | if (val_12 != null) goto label_38;      
        if(val_12 != null)
        {
            goto label_38;
        }
        // 0x026764C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_38:
        // 0x026764C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026764C8: MOV x0, x25                | X0 = val_12;//m1                        
        // 0x026764CC: BL #0x1a62e44              | X0 = val_12.get_activeInHierarchy();    
        bool val_13 = val_12.activeInHierarchy;
        // 0x026764D0: TBZ w0, #0, #0x26764f0     | if (val_13 == false) goto label_40;     
        if(val_13 == false)
        {
            goto label_40;
        }
        // 0x026764D4: LDRB w8, [x21, #0x118]     | W8 = this.wasActive; //P2               
        // 0x026764D8: CBNZ w8, #0x26764f0        | if (this.wasActive == true) goto label_40;
        if(this.wasActive == true)
        {
            goto label_40;
        }
        // 0x026764DC: LDR x8, [x21]              | X8 = typeof(CameraMotionBlur);          
        // 0x026764E0: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x026764E4: LDR x9, [x8, #0x250]       | X9 = typeof(CameraMotionBlur).__il2cppRuntimeField_250;
        // 0x026764E8: LDR x1, [x8, #0x258]       | X1 = typeof(CameraMotionBlur).__il2cppRuntimeField_258;
        // 0x026764EC: BLR x9                     | X0 = typeof(CameraMotionBlur).__il2cppRuntimeField_250();
        label_40:
        // 0x026764F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026764F4: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x026764F8: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_14 = this.gameObject;
        // 0x026764FC: MOV x25, x0                | X25 = val_14;//m1                       
        // 0x02676500: CBNZ x25, #0x2676508       | if (val_14 != null) goto label_41;      
        if(val_14 != null)
        {
            goto label_41;
        }
        // 0x02676504: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_41:
        // 0x02676508: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267650C: MOV x0, x25                | X0 = val_14;//m1                        
        // 0x02676510: BL #0x1a62e44              | X0 = val_14.get_activeInHierarchy();    
        bool val_15 = val_14.activeInHierarchy;
        // 0x02676514: LDUR q0, [x21, #0xc4]      | 
        // 0x02676518: AND w8, w0, #1             | W8 = (val_15 & 1);                      
        bool val_16 = val_15;
        // 0x0267651C: STRB w8, [x21, #0x118]     | this.wasActive = (val_15 & 1);           //  dest_result_addr=1152921509949884472
        this.wasActive = val_16;
        // 0x02676520: ADRP x19, #0x3645000       | X19 = 56905728 (0x3645000);             
        // 0x02676524: STR q0, [sp, #0x600]       | stack[1152921509949871808] = this.maxVelocity;  //  dest_result_addr=1152921509949871808
        // 0x02676528: LDUR q0, [x21, #0xb4]      | 
        // 0x0267652C: STR q0, [sp, #0x5f0]       | stack[1152921509949871792] = this.maxVelocity;  //  dest_result_addr=1152921509949871792
        // 0x02676530: LDUR q0, [x21, #0xa4]      | 
        // 0x02676534: STR q0, [sp, #0x5e0]       | stack[1152921509949871776] = this.maxVelocity;  //  dest_result_addr=1152921509949871776
        // 0x02676538: LDUR q0, [x21, #0x94]      | Q0 = this.currentViewProjMat; //P2      
        // 0x0267653C: LDR x19, [x19, #0x778]     | X19 = 1152921504695238656;              
        // 0x02676540: STR q0, [sp, #0x5d0]       | stack[1152921509949871760] = this.currentViewProjMat;  //  dest_result_addr=1152921509949871760
        // 0x02676544: LDR x0, [x19]              | X0 = typeof(UnityEngine.Matrix4x4);     
        // 0x02676548: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Matrix4x4.__il2cppRuntimeField_10A;
        // 0x0267654C: TBZ w8, #0, #0x267655c     | if (UnityEngine.Matrix4x4.__il2cppRuntimeField_has_cctor == 0) goto label_43;
        // 0x02676550: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Matrix4x4.__il2cppRuntimeField_cctor_finished;
        // 0x02676554: CBNZ w8, #0x267655c        | if (UnityEngine.Matrix4x4.__il2cppRuntimeField_cctor_finished != 0) goto label_43;
        // 0x02676558: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Matrix4x4), ????);
        label_43:
        // 0x0267655C: LDR q0, [sp, #0x600]       | Q0 = this.maxVelocity;                  
        // 0x02676560: LDR q1, [sp, #0x5f0]       | Q1 = this.maxVelocity;                  
        // 0x02676564: LDR q2, [sp, #0x5e0]       | Q2 = this.maxVelocity;                  
        // 0x02676568: LDR q3, [sp, #0x5d0]       | Q3 = this.currentViewProjMat;           
        // 0x0267656C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676570: ADD x8, sp, #0x590         | X8 = (1152921509949870272 + 1424) = 1152921509949871696 (0x100000013E781650);
        // 0x02676574: ADD x1, sp, #0x550         | X1 = (1152921509949870272 + 1360) = 1152921509949871632 (0x100000013E781610);
        // 0x02676578: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0267657C: STR q0, [sp, #0x580]       | stack[1152921509949871680] = this.maxVelocity;  //  dest_result_addr=1152921509949871680
        // 0x02676580: STR q1, [sp, #0x570]       | stack[1152921509949871664] = this.maxVelocity;  //  dest_result_addr=1152921509949871664
        // 0x02676584: STR q2, [sp, #0x560]       | stack[1152921509949871648] = this.maxVelocity;  //  dest_result_addr=1152921509949871648
        // 0x02676588: STR q3, [sp, #0x550]       | stack[1152921509949871632] = this.currentViewProjMat;  //  dest_result_addr=1152921509949871632
        // 0x0267658C: BL #0x1b6f9fc              | X0 = UnityEngine.Matrix4x4.Inverse(m:  new UnityEngine.Matrix4x4());
        UnityEngine.Matrix4x4 val_17 = UnityEngine.Matrix4x4.Inverse(m:  new UnityEngine.Matrix4x4());
        // 0x02676590: LDR q0, [sp, #0x5c0]       | Q0 = val_18;                             //  find_add[1152921509949860192]
        // 0x02676594: LDR q1, [sp, #0x5b0]       | Q1 = val_19;                             //  find_add[1152921509949860192]
        // 0x02676598: LDR q2, [sp, #0x5a0]       | Q2 = val_20;                             //  find_add[1152921509949860192]
        // 0x0267659C: LDR q3, [sp, #0x590]       | Q3 = val_21;                             //  find_add[1152921509949860192]
        // 0x026765A0: STUR q0, [x29, #-0xa0]     | stack[1152921509949872016] = val_18;     //  dest_result_addr=1152921509949872016
        // 0x026765A4: LDR q0, [sp, #0x5c0]       | Q0 = val_18;                             //  find_add[1152921509949860192]
        // 0x026765A8: STUR q1, [x29, #-0xb0]     | stack[1152921509949872000] = val_19;     //  dest_result_addr=1152921509949872000
        // 0x026765AC: LDR q1, [sp, #0x5b0]       | Q1 = val_19;                             //  find_add[1152921509949860192]
        // 0x026765B0: STUR q2, [x29, #-0xc0]     | stack[1152921509949871984] = val_20;     //  dest_result_addr=1152921509949871984
        // 0x026765B4: STUR q3, [x29, #-0xd0]     | stack[1152921509949871968] = val_21;     //  dest_result_addr=1152921509949871968
        // 0x026765B8: LDR q2, [sp, #0x5a0]       | Q2 = val_20;                             //  find_add[1152921509949860192]
        // 0x026765BC: LDR q3, [sp, #0x590]       | Q3 = val_21;                             //  find_add[1152921509949860192]
        // 0x026765C0: LDR x25, [x21, #0x70]      | X25 = this.motionBlurMaterial; //P2     
        // 0x026765C4: STR q0, [sp, #0x540]       | stack[1152921509949871616] = val_18;     //  dest_result_addr=1152921509949871616
        // 0x026765C8: STR q1, [sp, #0x530]       | stack[1152921509949871600] = val_19;     //  dest_result_addr=1152921509949871600
        // 0x026765CC: STR q2, [sp, #0x520]       | stack[1152921509949871584] = val_20;     //  dest_result_addr=1152921509949871584
        // 0x026765D0: STR q3, [sp, #0x510]       | stack[1152921509949871568] = val_21;     //  dest_result_addr=1152921509949871568
        // 0x026765D4: CBNZ x25, #0x26765dc       | if (this.motionBlurMaterial != null) goto label_44;
        if(this.motionBlurMaterial != null)
        {
            goto label_44;
        }
        // 0x026765D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_44:
        // 0x026765DC: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
        // 0x026765E0: LDR x8, [x8, #0x550]       | X8 = (string**)(1152921509949587936)("_InvViewProj");
        // 0x026765E4: LDR q0, [sp, #0x540]       | Q0 = val_18;                            
        // 0x026765E8: LDR q1, [sp, #0x530]       | Q1 = val_19;                            
        // 0x026765EC: LDR q2, [sp, #0x520]       | Q2 = val_20;                            
        // 0x026765F0: LDR q3, [sp, #0x510]       | Q3 = val_21;                            
        // 0x026765F4: LDR x1, [x8]               | X1 = "_InvViewProj";                    
        // 0x026765F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x026765FC: ADD x2, sp, #0x4d0         | X2 = (1152921509949870272 + 1232) = 1152921509949871504 (0x100000013E781590);
        // 0x02676600: MOV x0, x25                | X0 = this.motionBlurMaterial;//m1       
        // 0x02676604: STR q0, [sp, #0x500]       | stack[1152921509949871552] = val_18;     //  dest_result_addr=1152921509949871552
        // 0x02676608: STR q1, [sp, #0x4f0]       | stack[1152921509949871536] = val_19;     //  dest_result_addr=1152921509949871536
        // 0x0267660C: STR q2, [sp, #0x4e0]       | stack[1152921509949871520] = val_20;     //  dest_result_addr=1152921509949871520
        // 0x02676610: STR q3, [sp, #0x4d0]       | stack[1152921509949871504] = val_21;     //  dest_result_addr=1152921509949871504
        // 0x02676614: BL #0x1a7a040              | this.motionBlurMaterial.SetMatrix(name:  "_InvViewProj", value:  new UnityEngine.Matrix4x4() {m00 = val_21, m10 = val_21, m20 = val_21, m30 = val_21, m01 = val_20, m11 = val_20, m21 = val_20, m31 = val_20, m02 = val_19, m12 = val_19, m22 = val_19, m32 = val_19, m03 = val_18, m13 = val_18, m23 = val_18, m33 = val_18});
        this.motionBlurMaterial.SetMatrix(name:  "_InvViewProj", value:  new UnityEngine.Matrix4x4() {m00 = val_21, m10 = val_21, m20 = val_21, m30 = val_21, m01 = val_20, m11 = val_20, m21 = val_20, m31 = val_20, m02 = val_19, m12 = val_19, m22 = val_19, m32 = val_19, m03 = val_18, m13 = val_18, m23 = val_18, m33 = val_18});
        // 0x02676618: ADD x8, x21, #0x104        | X8 = (this + 260) = 1152921509949884452 (0x100000013E784824);
        // 0x0267661C: LDR q0, [x8]               | Q0 = typeof(CameraMotionBlur);          
        // 0x02676620: LDR x25, [x21, #0x70]      | X25 = this.motionBlurMaterial; //P2     
        // 0x02676624: ADD x28, x21, #0xd4        | X28 = this.prevViewProjMat;//AP2 res_addr=1152921509949884404
        // 0x02676628: STR q0, [sp, #0x4c0]       | stack[1152921509949871488] = typeof(CameraMotionBlur);  //  dest_result_addr=1152921509949871488
        // 0x0267662C: LDUR q0, [x21, #0xf4]      | 
        // 0x02676630: STR q0, [sp, #0x4b0]       | stack[1152921509949871472] = typeof(CameraMotionBlur);  //  dest_result_addr=1152921509949871472
        // 0x02676634: LDUR q0, [x21, #0xe4]      | 
        // 0x02676638: STR q0, [sp, #0x4a0]       | stack[1152921509949871456] = typeof(CameraMotionBlur);  //  dest_result_addr=1152921509949871456
        // 0x0267663C: LDUR q0, [x21, #0xd4]      | Q0 = this.prevViewProjMat; //P2         
        // 0x02676640: STR q0, [sp, #0x490]       | stack[1152921509949871440] = this.prevViewProjMat;  //  dest_result_addr=1152921509949871440
        // 0x02676644: CBNZ x25, #0x267664c       | if (this.motionBlurMaterial != null) goto label_45;
        if(this.motionBlurMaterial != null)
        {
            goto label_45;
        }
        // 0x02676648: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.motionBlurMaterial, ????);
        label_45:
        // 0x0267664C: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
        // 0x02676650: LDR x8, [x8, #0xab0]       | X8 = (string**)(1152921509949592128)("_PrevViewProj");
        // 0x02676654: LDR q0, [sp, #0x4c0]       | Q0 = typeof(CameraMotionBlur);          
        // 0x02676658: LDR q1, [sp, #0x4b0]       | Q1 = typeof(CameraMotionBlur);          
        // 0x0267665C: LDR q2, [sp, #0x4a0]       | Q2 = typeof(CameraMotionBlur);          
        // 0x02676660: LDR q3, [sp, #0x490]       | Q3 = this.prevViewProjMat;              
        // 0x02676664: LDR x1, [x8]               | X1 = "_PrevViewProj";                   
        // 0x02676668: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0267666C: ADD x2, sp, #0x450         | X2 = (1152921509949870272 + 1104) = 1152921509949871376 (0x100000013E781510);
        // 0x02676670: MOV x0, x25                | X0 = this.motionBlurMaterial;//m1       
        // 0x02676674: STR q0, [sp, #0x480]       | stack[1152921509949871424] = typeof(CameraMotionBlur);  //  dest_result_addr=1152921509949871424
        // 0x02676678: STR q1, [sp, #0x470]       | stack[1152921509949871408] = typeof(CameraMotionBlur);  //  dest_result_addr=1152921509949871408
        // 0x0267667C: STR q2, [sp, #0x460]       | stack[1152921509949871392] = typeof(CameraMotionBlur);  //  dest_result_addr=1152921509949871392
        // 0x02676680: STR q3, [sp, #0x450]       | stack[1152921509949871376] = this.prevViewProjMat;  //  dest_result_addr=1152921509949871376
        // 0x02676684: BL #0x1a7a040              | this.motionBlurMaterial.SetMatrix(name:  "_PrevViewProj", value:  new UnityEngine.Matrix4x4() {m00 = this.prevViewProjMat, m10 = this.prevViewProjMat, m20 = this.prevViewProjMat, m30 = this.prevViewProjMat, m01 = 9.262519E-33f, m11 = 2.524355E-29f, m21 = 9.262519E-33f, m31 = 2.524355E-29f, m02 = 9.262519E-33f, m12 = 2.524355E-29f, m22 = 9.262519E-33f, m32 = 2.524355E-29f, m03 = 9.262519E-33f, m13 = 2.524355E-29f, m23 = 9.262519E-33f, m33 = 2.524355E-29f});
        this.motionBlurMaterial.SetMatrix(name:  "_PrevViewProj", value:  new UnityEngine.Matrix4x4() {m00 = this.prevViewProjMat, m10 = this.prevViewProjMat, m20 = this.prevViewProjMat, m30 = this.prevViewProjMat, m01 = 9.262519E-33f, m11 = 2.524355E-29f, m21 = 9.262519E-33f, m31 = 2.524355E-29f, m02 = 9.262519E-33f, m12 = 2.524355E-29f, m22 = 9.262519E-33f, m32 = 2.524355E-29f, m03 = 9.262519E-33f, m13 = 2.524355E-29f, m23 = 9.262519E-33f, m33 = 2.524355E-29f});
        // 0x02676688: LDR q0, [x28, #0x30]       | Q0 = this.prevViewProjMat.m03;          
        // 0x0267668C: LDR x25, [x21, #0x70]      | X25 = this.motionBlurMaterial; //P2     
        // 0x02676690: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676694: ADD x8, sp, #0x410         | X8 = (1152921509949870272 + 1040) = 1152921509949871312 (0x100000013E7814D0);
        // 0x02676698: STR q0, [sp, #0x400]       | stack[1152921509949871296] = this.prevViewProjMat.m03;  //  dest_result_addr=1152921509949871296
        // 0x0267669C: LDR q0, [x28, #0x20]       | Q0 = this.prevViewProjMat.m02;          
        // 0x026766A0: ADD x1, sp, #0x3d0         | X1 = (1152921509949870272 + 976) = 1152921509949871248 (0x100000013E781490);
        // 0x026766A4: ADD x2, sp, #0x390         | X2 = (1152921509949870272 + 912) = 1152921509949871184 (0x100000013E781450);
        // 0x026766A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x026766AC: STR q0, [sp, #0x3f0]       | stack[1152921509949871280] = this.prevViewProjMat.m02;  //  dest_result_addr=1152921509949871280
        // 0x026766B0: LDR q0, [x28, #0x10]       | Q0 = this.prevViewProjMat.m01;          
        // 0x026766B4: LDP q2, q1, [x29, #-0xb0]  | Q2 = val_19; Q1 = val_18;                //  | 
        // 0x026766B8: LDUR q3, [x29, #-0xc0]     | Q3 = val_20;                            
        // 0x026766BC: STR q0, [sp, #0x3e0]       | stack[1152921509949871264] = this.prevViewProjMat.m01;  //  dest_result_addr=1152921509949871264
        // 0x026766C0: LDR q0, [x28]              | Q0 = this.prevViewProjMat.m00;          
        // 0x026766C4: STR q1, [sp, #0x3c0]       | stack[1152921509949871232] = val_18;     //  dest_result_addr=1152921509949871232
        // 0x026766C8: LDUR q1, [x29, #-0xd0]     | Q1 = val_21;                            
        // 0x026766CC: STP q3, q2, [sp, #0x3a0]   | stack[1152921509949871200] = val_20;  stack[1152921509949871216] = val_19;  //  dest_result_addr=1152921509949871200 |  dest_result_addr=1152921509949871216
        // 0x026766D0: STR q0, [sp, #0x3d0]       | stack[1152921509949871248] = this.prevViewProjMat.m00;  //  dest_result_addr=1152921509949871248
        // 0x026766D4: STR q1, [sp, #0x390]       | stack[1152921509949871184] = val_21;     //  dest_result_addr=1152921509949871184
        // 0x026766D8: BL #0x1b7133c              | X0 = UnityEngine.Matrix4x4.op_Multiply(lhs:  new UnityEngine.Matrix4x4(), rhs:  new UnityEngine.Matrix4x4() {m00 = this.prevViewProjMat.m00, m01 = this.prevViewProjMat.m01, m02 = this.prevViewProjMat.m02, m03 = this.prevViewProjMat.m03});
        UnityEngine.Matrix4x4 val_22 = UnityEngine.Matrix4x4.op_Multiply(lhs:  new UnityEngine.Matrix4x4(), rhs:  new UnityEngine.Matrix4x4() {m00 = this.prevViewProjMat.m00, m01 = this.prevViewProjMat.m01, m02 = this.prevViewProjMat.m02, m03 = this.prevViewProjMat.m03});
        // 0x026766DC: CBNZ x25, #0x26766e4       | if (this.motionBlurMaterial != null) goto label_46;
        if(this.motionBlurMaterial != null)
        {
            goto label_46;
        }
        // 0x026766E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_46:
        // 0x026766E4: SCVTF s15, w27             | S15 = (float)((val_3 / this));          
        val_107 = (float)val_8;
        // 0x026766E8: ADRP x27, #0x35d9000       | X27 = 56463360 (0x35D9000);             
        // 0x026766EC: LDR x27, [x27, #0x30]      | X27 = (string**)(1152921509949600464)("_ToPrevViewProjCombined");
        val_108 = "_ToPrevViewProjCombined";
        // 0x026766F0: LDR q0, [sp, #0x440]       | Q0 = val_23;                             //  find_add[1152921509949860192]
        // 0x026766F4: LDR q1, [sp, #0x430]       | Q1 = val_24;                             //  find_add[1152921509949860192]
        // 0x026766F8: LDR q2, [sp, #0x420]       | Q2 = val_25;                             //  find_add[1152921509949860192]
        // 0x026766FC: LDR q3, [sp, #0x410]       | Q3 = val_26;                             //  find_add[1152921509949860192]
        // 0x02676700: LDR x1, [x27]              | X1 = "_ToPrevViewProjCombined";         
        // 0x02676704: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02676708: ADD x2, sp, #0x350         | X2 = (1152921509949870272 + 848) = 1152921509949871120 (0x100000013E781410);
        // 0x0267670C: MOV x0, x25                | X0 = this.motionBlurMaterial;//m1       
        // 0x02676710: STP q1, q0, [sp, #0x370]   | stack[1152921509949871152] = val_24;  stack[1152921509949871168] = val_23;  //  dest_result_addr=1152921509949871152 |  dest_result_addr=1152921509949871168
        // 0x02676714: STP q3, q2, [sp, #0x350]   | stack[1152921509949871120] = val_26;  stack[1152921509949871136] = val_25;  //  dest_result_addr=1152921509949871120 |  dest_result_addr=1152921509949871136
        // 0x02676718: BL #0x1a7a040              | this.motionBlurMaterial.SetMatrix(name:  "_ToPrevViewProjCombined", value:  new UnityEngine.Matrix4x4() {m00 = val_26, m10 = val_26, m20 = val_26, m30 = val_26, m01 = val_25, m11 = val_25, m21 = val_25, m31 = val_25, m02 = val_24, m12 = val_24, m22 = val_24, m32 = val_24, m03 = val_23, m13 = val_23, m23 = val_23, m33 = val_23});
        this.motionBlurMaterial.SetMatrix(name:  "_ToPrevViewProjCombined", value:  new UnityEngine.Matrix4x4() {m00 = val_26, m10 = val_26, m20 = val_26, m30 = val_26, m01 = val_25, m11 = val_25, m21 = val_25, m31 = val_25, m02 = val_24, m12 = val_24, m22 = val_24, m32 = val_24, m03 = val_23, m13 = val_23, m23 = val_23, m33 = val_23});
        // 0x0267671C: LDR x25, [x21, #0x70]      | X25 = this.motionBlurMaterial; //P2     
        // 0x02676720: CBNZ x25, #0x2676728       | if (this.motionBlurMaterial != null) goto label_47;
        if(this.motionBlurMaterial != null)
        {
            goto label_47;
        }
        // 0x02676724: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.motionBlurMaterial, ????);
        label_47:
        // 0x02676728: ADRP x8, #0x3643000        | X8 = 56897536 (0x3643000);              
        // 0x0267672C: LDR x8, [x8, #0x280]       | X8 = (string**)(1152921509949604688)("_MaxVelocity");
        // 0x02676730: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02676734: MOV x0, x25                | X0 = this.motionBlurMaterial;//m1       
        // 0x02676738: MOV v0.16b, v15.16b        | V0 = (val_3 / this);//m1                
        // 0x0267673C: LDR x1, [x8]               | X1 = "_MaxVelocity";                    
        // 0x02676740: BL #0x1a79ef8              | this.motionBlurMaterial.SetFloat(name:  "_MaxVelocity", value:  val_107);
        this.motionBlurMaterial.SetFloat(name:  "_MaxVelocity", value:  val_107);
        // 0x02676744: LDR x25, [x21, #0x70]      | X25 = this.motionBlurMaterial; //P2     
        // 0x02676748: CBNZ x25, #0x2676750       | if (this.motionBlurMaterial != null) goto label_48;
        if(this.motionBlurMaterial != null)
        {
            goto label_48;
        }
        // 0x0267674C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.motionBlurMaterial, ????);
        label_48:
        // 0x02676750: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x02676754: LDR x8, [x8, #0x28]        | X8 = (string**)(1152921509949608880)("_MaxRadiusOrKInPaper");
        // 0x02676758: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0267675C: MOV x0, x25                | X0 = this.motionBlurMaterial;//m1       
        // 0x02676760: MOV v0.16b, v15.16b        | V0 = (val_3 / this);//m1                
        // 0x02676764: LDR x1, [x8]               | X1 = "_MaxRadiusOrKInPaper";            
        // 0x02676768: BL #0x1a79ef8              | this.motionBlurMaterial.SetFloat(name:  "_MaxRadiusOrKInPaper", value:  val_107);
        this.motionBlurMaterial.SetFloat(name:  "_MaxRadiusOrKInPaper", value:  val_107);
        // 0x0267676C: LDR x25, [x21, #0x70]      | X25 = this.motionBlurMaterial; //P2     
        // 0x02676770: LDR s8, [x21, #0x3c]       | S8 = this.minVelocity; //P2             
        // 0x02676774: CBNZ x25, #0x267677c       | if (this.motionBlurMaterial != null) goto label_49;
        if(this.motionBlurMaterial != null)
        {
            goto label_49;
        }
        // 0x02676778: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.motionBlurMaterial, ????);
        label_49:
        // 0x0267677C: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
        // 0x02676780: LDR x8, [x8, #0x1a0]       | X8 = (string**)(1152921509949613088)("_MinVelocity");
        // 0x02676784: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02676788: MOV x0, x25                | X0 = this.motionBlurMaterial;//m1       
        // 0x0267678C: MOV v0.16b, v8.16b         | V0 = this.minVelocity;//m1              
        // 0x02676790: LDR x1, [x8]               | X1 = "_MinVelocity";                    
        // 0x02676794: BL #0x1a79ef8              | this.motionBlurMaterial.SetFloat(name:  "_MinVelocity", value:  this.minVelocity);
        this.motionBlurMaterial.SetFloat(name:  "_MinVelocity", value:  this.minVelocity);
        // 0x02676798: LDR x25, [x21, #0x70]      | X25 = this.motionBlurMaterial; //P2     
        // 0x0267679C: LDR s8, [x21, #0x40]       | S8 = this.velocityScale; //P2           
        // 0x026767A0: CBNZ x25, #0x26767a8       | if (this.motionBlurMaterial != null) goto label_50;
        if(this.motionBlurMaterial != null)
        {
            goto label_50;
        }
        // 0x026767A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.motionBlurMaterial, ????);
        label_50:
        // 0x026767A8: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
        // 0x026767AC: LDR x8, [x8, #0x7c8]       | X8 = (string**)(1152921509949617280)("_VelocityScale");
        // 0x026767B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026767B4: MOV x0, x25                | X0 = this.motionBlurMaterial;//m1       
        // 0x026767B8: MOV v0.16b, v8.16b         | V0 = this.velocityScale;//m1            
        // 0x026767BC: LDR x1, [x8]               | X1 = "_VelocityScale";                  
        // 0x026767C0: BL #0x1a79ef8              | this.motionBlurMaterial.SetFloat(name:  "_VelocityScale", value:  this.velocityScale);
        this.motionBlurMaterial.SetFloat(name:  "_VelocityScale", value:  this.velocityScale);
        // 0x026767C4: LDR x25, [x21, #0x70]      | X25 = this.motionBlurMaterial; //P2     
        // 0x026767C8: LDR s8, [x21, #0x88]       | S8 = this.jitter; //P2                  
        // 0x026767CC: CBNZ x25, #0x26767d4       | if (this.motionBlurMaterial != null) goto label_51;
        if(this.motionBlurMaterial != null)
        {
            goto label_51;
        }
        // 0x026767D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.motionBlurMaterial, ????);
        label_51:
        // 0x026767D4: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
        // 0x026767D8: LDR x8, [x8, #0xe38]       | X8 = (string**)(1152921509949621472)("_Jitter");
        // 0x026767DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026767E0: MOV x0, x25                | X0 = this.motionBlurMaterial;//m1       
        // 0x026767E4: MOV v0.16b, v8.16b         | V0 = this.jitter;//m1                   
        // 0x026767E8: LDR x1, [x8]               | X1 = "_Jitter";                         
        // 0x026767EC: BL #0x1a79ef8              | this.motionBlurMaterial.SetFloat(name:  "_Jitter", value:  this.jitter);
        this.motionBlurMaterial.SetFloat(name:  "_Jitter", value:  this.jitter);
        // 0x026767F0: LDR x25, [x21, #0x70]      | X25 = this.motionBlurMaterial; //P2     
        // 0x026767F4: LDR x26, [x21, #0x80]      | X26 = this.noiseTexture; //P2           
        // 0x026767F8: CBNZ x25, #0x2676800       | if (this.motionBlurMaterial != null) goto label_52;
        if(this.motionBlurMaterial != null)
        {
            goto label_52;
        }
        // 0x026767FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.motionBlurMaterial, ????);
        label_52:
        // 0x02676800: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
        // 0x02676804: LDR x8, [x8, #0xe30]       | X8 = (string**)(1152921509949629760)("_NoiseTex");
        // 0x02676808: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0267680C: MOV x0, x25                | X0 = this.motionBlurMaterial;//m1       
        // 0x02676810: MOV x2, x26                | X2 = this.noiseTexture;//m1             
        // 0x02676814: LDR x1, [x8]               | X1 = "_NoiseTex";                       
        // 0x02676818: BL #0x1a780c4              | this.motionBlurMaterial.SetTexture(name:  "_NoiseTex", value:  this.noiseTexture);
        this.motionBlurMaterial.SetTexture(name:  "_NoiseTex", value:  this.noiseTexture);
        // 0x0267681C: LDR x25, [x21, #0x70]      | X25 = this.motionBlurMaterial; //P2     
        // 0x02676820: CBNZ x25, #0x2676828       | if (this.motionBlurMaterial != null) goto label_53;
        if(this.motionBlurMaterial != null)
        {
            goto label_53;
        }
        // 0x02676824: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.motionBlurMaterial, ????);
        label_53:
        // 0x02676828: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x0267682C: LDR x8, [x8, #0xf18]       | X8 = (string**)(1152921509949633952)("_VelTex");
        // 0x02676830: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02676834: MOV x0, x25                | X0 = this.motionBlurMaterial;//m1       
        // 0x02676838: MOV x2, x22                | X2 = val_3;//m1                         
        // 0x0267683C: LDR x1, [x8]               | X1 = "_VelTex";                         
        // 0x02676840: BL #0x1a780c4              | this.motionBlurMaterial.SetTexture(name:  "_VelTex", value:  val_3);
        this.motionBlurMaterial.SetTexture(name:  "_VelTex", value:  val_3);
        // 0x02676844: LDR x25, [x21, #0x70]      | X25 = this.motionBlurMaterial; //P2     
        // 0x02676848: CBNZ x25, #0x2676850       | if (this.motionBlurMaterial != null) goto label_54;
        if(this.motionBlurMaterial != null)
        {
            goto label_54;
        }
        // 0x0267684C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.motionBlurMaterial, ????);
        label_54:
        // 0x02676850: ADRP x8, #0x35e4000        | X8 = 56508416 (0x35E4000);              
        // 0x02676854: LDR x8, [x8, #0xe68]       | X8 = (string**)(1152921509949638144)("_NeighbourMaxTex");
        // 0x02676858: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0267685C: MOV x0, x25                | X0 = this.motionBlurMaterial;//m1       
        // 0x02676860: MOV x2, x24                | X2 = val_10;//m1                        
        // 0x02676864: LDR x1, [x8]               | X1 = "_NeighbourMaxTex";                
        // 0x02676868: BL #0x1a780c4              | this.motionBlurMaterial.SetTexture(name:  "_NeighbourMaxTex", value:  val_10);
        this.motionBlurMaterial.SetTexture(name:  "_NeighbourMaxTex", value:  val_10);
        // 0x0267686C: LDR x25, [x21, #0x70]      | X25 = this.motionBlurMaterial; //P2     
        // 0x02676870: CBNZ x25, #0x2676878       | if (this.motionBlurMaterial != null) goto label_55;
        if(this.motionBlurMaterial != null)
        {
            goto label_55;
        }
        // 0x02676874: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.motionBlurMaterial, ????);
        label_55:
        // 0x02676878: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
        // 0x0267687C: LDR x8, [x8, #0x508]       | X8 = (string**)(1152921509949642352)("_TileTexDebug");
        // 0x02676880: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02676884: MOV x0, x25                | X0 = this.motionBlurMaterial;//m1       
        // 0x02676888: MOV x2, x23                | X2 = val_9;//m1                         
        // 0x0267688C: LDR x1, [x8]               | X1 = "_TileTexDebug";                   
        // 0x02676890: BL #0x1a780c4              | this.motionBlurMaterial.SetTexture(name:  "_TileTexDebug", value:  val_9);
        this.motionBlurMaterial.SetTexture(name:  "_TileTexDebug", value:  val_9);
        // 0x02676894: LDRB w8, [x21, #0x20]      | W8 = this.preview; //P2                 
        // 0x02676898: CBZ w8, #0x2676bd0         | if (this.preview == false) goto label_56;
        if(this.preview == false)
        {
            goto label_56;
        }
        // 0x0267689C: ADRP x26, #0x3668000       | X26 = 57049088 (0x3668000);             
        // 0x026768A0: LDR x26, [x26, #0x338]     | X26 = 1152921509941328016;              
        // 0x026768A4: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x026768A8: LDR x1, [x26]              | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x026768AC: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_27 = this.GetComponent<UnityEngine.Camera>();
        // 0x026768B0: MOV x25, x0                | X25 = val_27;//m1                       
        // 0x026768B4: CBNZ x25, #0x26768bc       | if (val_27 != null) goto label_57;      
        if(val_27 != null)
        {
            goto label_57;
        }
        // 0x026768B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
        label_57:
        // 0x026768BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026768C0: ADD x8, sp, #0x5d0         | X8 = (1152921509949870272 + 1488) = 1152921509949871760 (0x100000013E781690);
        // 0x026768C4: MOV x0, x25                | X0 = val_27;//m1                        
        // 0x026768C8: BL #0x20d01b8              | X0 = val_27.get_worldToCameraMatrix();  
        UnityEngine.Matrix4x4 val_28 = val_27.worldToCameraMatrix;
        // 0x026768CC: LDR q0, [sp, #0x600]       | Q0 = this.maxVelocity;                  
        // 0x026768D0: LDR q1, [sp, #0x5f0]       | Q1 = this.maxVelocity;                  
        // 0x026768D4: LDR q2, [sp, #0x5e0]       | Q2 = this.maxVelocity;                  
        // 0x026768D8: LDR q3, [sp, #0x5d0]       | Q3 = this.currentViewProjMat;           
        // 0x026768DC: LDR x0, [x19]              | X0 = typeof(UnityEngine.Matrix4x4);     
        // 0x026768E0: STR q0, [sp, #0x690]       | stack[1152921509949871952] = this.maxVelocity;  //  dest_result_addr=1152921509949871952
        // 0x026768E4: STR q1, [sp, #0x680]       | stack[1152921509949871936] = this.maxVelocity;  //  dest_result_addr=1152921509949871936
        // 0x026768E8: STR q2, [sp, #0x670]       | stack[1152921509949871920] = this.maxVelocity;  //  dest_result_addr=1152921509949871920
        // 0x026768EC: STR q3, [sp, #0x660]       | stack[1152921509949871904] = this.currentViewProjMat;  //  dest_result_addr=1152921509949871904
        // 0x026768F0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Matrix4x4.__il2cppRuntimeField_10A;
        // 0x026768F4: TBZ w8, #0, #0x2676904     | if (UnityEngine.Matrix4x4.__il2cppRuntimeField_has_cctor == 0) goto label_59;
        // 0x026768F8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Matrix4x4.__il2cppRuntimeField_cctor_finished;
        // 0x026768FC: CBNZ w8, #0x2676904        | if (UnityEngine.Matrix4x4.__il2cppRuntimeField_cctor_finished != 0) goto label_59;
        // 0x02676900: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Matrix4x4), ????);
        label_59:
        // 0x02676904: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676908: ADD x8, sp, #0x590         | X8 = (1152921509949870272 + 1424) = 1152921509949871696 (0x100000013E781650);
        // 0x0267690C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676910: BL #0x1b72194              | X0 = UnityEngine.Matrix4x4.get_identity();
        UnityEngine.Matrix4x4 val_29 = UnityEngine.Matrix4x4.identity;
        // 0x02676914: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x02676918: LDR q0, [sp, #0x5c0]       | Q0 = val_18;                             //  find_add[1152921509949860192]
        // 0x0267691C: LDR q1, [sp, #0x5b0]       | Q1 = val_19;                             //  find_add[1152921509949860192]
        // 0x02676920: LDR q2, [sp, #0x5a0]       | Q2 = val_20;                             //  find_add[1152921509949860192]
        // 0x02676924: LDR q3, [sp, #0x590]       | Q3 = val_21;                             //  find_add[1152921509949860192]
        // 0x02676928: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x0267692C: STR q0, [sp, #0x650]       | stack[1152921509949871888] = val_18;     //  dest_result_addr=1152921509949871888
        // 0x02676930: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x02676934: STR q1, [sp, #0x640]       | stack[1152921509949871872] = val_19;     //  dest_result_addr=1152921509949871872
        // 0x02676938: STR q2, [sp, #0x630]       | stack[1152921509949871856] = val_20;     //  dest_result_addr=1152921509949871856
        // 0x0267693C: STR q3, [sp, #0x620]       | stack[1152921509949871840] = val_21;     //  dest_result_addr=1152921509949871840
        // 0x02676940: LDP s11, s10, [x21, #0x24] | S11 = this.previewScale; //P2            //  | 
        // 0x02676944: LDR s9, [x21, #0x2c]       | 
        // 0x02676948: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x0267694C: TBZ w8, #0, #0x267695c     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_61;
        // 0x02676950: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x02676954: CBNZ w8, #0x267695c        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_61;
        // 0x02676958: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_61:
        // 0x0267695C: ADRP x8, #0x2ac3000        | X8 = 44838912 (0x2AC3000);              
        // 0x02676960: LDR s3, [x8, #0xd24]       | S3 = 0.3333;                            
        // 0x02676964: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676968: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267696C: MOV v0.16b, v11.16b        | V0 = this.previewScale;//m1             
        // 0x02676970: MOV v1.16b, v10.16b        | V1 = V10.16B;//m1                       
        // 0x02676974: MOV v2.16b, v9.16b         | V2 = V9.16B;//m1                        
        // 0x02676978: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = this.previewScale, y = V10.16B, z = V9.16B}, d:  0.3333f);
        UnityEngine.Vector3 val_30 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = this.previewScale, y = V10.16B, z = V9.16B}, d:  0.3333f);
        // 0x0267697C: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x02676980: LDR x8, [x8, #0xd78]       | X8 = 1152921504695132160;               
        // 0x02676984: MOV v9.16b, v0.16b         | V9 = val_30.x;//m1                      
        // 0x02676988: MOV v10.16b, v1.16b        | V10 = val_30.y;//m1                     
        val_110 = val_30.y;
        // 0x0267698C: MOV v11.16b, v2.16b        | V11 = val_30.z;//m1                     
        // 0x02676990: LDR x0, [x8]               | X0 = typeof(UnityEngine.Quaternion);    
        // 0x02676994: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_10A;
        // 0x02676998: TBZ w8, #0, #0x26769a8     | if (UnityEngine.Quaternion.__il2cppRuntimeField_has_cctor == 0) goto label_63;
        // 0x0267699C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x026769A0: CBNZ w8, #0x26769a8        | if (UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished != 0) goto label_63;
        // 0x026769A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Quaternion), ????);
        label_63:
        // 0x026769A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026769AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026769B0: BL #0x1b7fb20              | X0 = UnityEngine.Quaternion.get_identity();
        UnityEngine.Quaternion val_31 = UnityEngine.Quaternion.identity;
        // 0x026769B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026769B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026769BC: MOV v8.16b, v0.16b         | V8 = val_31.x;//m1                      
        // 0x026769C0: MOV v12.16b, v1.16b        | V12 = val_31.y;//m1                     
        val_111 = val_31.y;
        // 0x026769C4: MOV v13.16b, v2.16b        | V13 = val_31.z;//m1                     
        // 0x026769C8: MOV v14.16b, v3.16b        | V14 = val_31.w;//m1                     
        val_112 = val_31.w;
        // 0x026769CC: BL #0x269a58c              | X0 = UnityEngine.Vector3.get_one();     
        UnityEngine.Vector3 val_32 = UnityEngine.Vector3.one;
        // 0x026769D0: STP s1, s2, [sp, #4]       | stack[1152921509949870276] = val_32.y;  stack[1152921509949870280] = val_32.z;  //  dest_result_addr=1152921509949870276 |  dest_result_addr=1152921509949870280
        // 0x026769D4: ADD x0, sp, #0x620         | X0 = (1152921509949870272 + 1568) = 1152921509949871840 (0x100000013E7816E0);
        // 0x026769D8: STR s0, [sp]               | stack[1152921509949870272] = val_32.x;   //  dest_result_addr=1152921509949870272
        // 0x026769DC: MOV v0.16b, v9.16b         | V0 = val_30.x;//m1                      
        // 0x026769E0: MOV v1.16b, v10.16b        | V1 = val_30.y;//m1                      
        // 0x026769E4: MOV v2.16b, v11.16b        | V2 = val_30.z;//m1                      
        // 0x026769E8: MOV v3.16b, v8.16b         | V3 = val_31.x;//m1                      
        // 0x026769EC: MOV v4.16b, v12.16b        | V4 = val_31.y;//m1                      
        // 0x026769F0: MOV v5.16b, v13.16b        | V5 = val_31.z;//m1                      
        // 0x026769F4: MOV v6.16b, v14.16b        | V6 = val_31.w;//m1                      
        // 0x026769F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026769FC: BL #0x1b701c8              | X0 = label_UnityEngine_Matrix4x4_get_determinant_GL01B701C8();
        // 0x02676A00: LDR x1, [x26]              | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x02676A04: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676A08: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_33 = this.GetComponent<UnityEngine.Camera>();
        // 0x02676A0C: MOV x25, x0                | X25 = val_33;//m1                       
        // 0x02676A10: CBNZ x25, #0x2676a18       | if (val_33 != null) goto label_64;      
        if(val_33 != null)
        {
            goto label_64;
        }
        // 0x02676A14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_33, ????);     
        label_64:
        // 0x02676A18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676A1C: ADD x8, sp, #0x510         | X8 = (1152921509949870272 + 1296) = 1152921509949871568 (0x100000013E7815D0);
        // 0x02676A20: MOV x0, x25                | X0 = val_33;//m1                        
        // 0x02676A24: BL #0x20d0368              | X0 = val_33.get_projectionMatrix();     
        UnityEngine.Matrix4x4 val_34 = val_33.projectionMatrix;
        // 0x02676A28: LDR q0, [sp, #0x540]       | Q0 = val_18;                            
        // 0x02676A2C: LDR q1, [sp, #0x530]       | Q1 = val_19;                            
        // 0x02676A30: LDR q2, [sp, #0x520]       | Q2 = val_20;                            
        // 0x02676A34: LDR q3, [sp, #0x510]       | Q3 = val_21;                            
        // 0x02676A38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676A3C: ADD x8, sp, #0x490         | X8 = (1152921509949870272 + 1168) = 1152921509949871440 (0x100000013E781550);
        // 0x02676A40: ADD x1, sp, #0x310         | X1 = (1152921509949870272 + 784) = 1152921509949871056 (0x100000013E7813D0);
        // 0x02676A44: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x02676A48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02676A4C: STP q1, q0, [sp, #0x330]   | stack[1152921509949871088] = val_19;  stack[1152921509949871104] = val_18;  //  dest_result_addr=1152921509949871088 |  dest_result_addr=1152921509949871104
        // 0x02676A50: STP q3, q2, [sp, #0x310]   | stack[1152921509949871056] = val_21;  stack[1152921509949871072] = val_20;  //  dest_result_addr=1152921509949871056 |  dest_result_addr=1152921509949871072
        // 0x02676A54: BL #0x1a6615c              | X0 = UnityEngine.GL.GetGPUProjectionMatrix(proj:  new UnityEngine.Matrix4x4(), renderIntoTexture:  true);
        UnityEngine.Matrix4x4 val_35 = UnityEngine.GL.GetGPUProjectionMatrix(proj:  new UnityEngine.Matrix4x4(), renderIntoTexture:  true);
        // 0x02676A58: LDR q0, [sp, #0x4c0]       | Q0 = typeof(CameraMotionBlur);          
        // 0x02676A5C: LDR q1, [sp, #0x4b0]       | Q1 = typeof(CameraMotionBlur);          
        // 0x02676A60: LDR q2, [sp, #0x4a0]       | Q2 = typeof(CameraMotionBlur);          
        // 0x02676A64: LDR q3, [sp, #0x490]       | Q3 = this.prevViewProjMat;              
        // 0x02676A68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676A6C: STP q1, q0, [sp, #0x2f0]   | stack[1152921509949871024] = typeof(CameraMotionBlur);  stack[1152921509949871040] = typeof(CameraMotionBlur);  //  dest_result_addr=1152921509949871024 |  dest_result_addr=1152921509949871040
        // 0x02676A70: LDR q0, [sp, #0x650]       | Q0 = val_18;                            
        // 0x02676A74: LDR q1, [sp, #0x640]       | Q1 = val_19;                            
        // 0x02676A78: STP q3, q2, [sp, #0x2d0]   | stack[1152921509949870992] = this.prevViewProjMat;  stack[1152921509949871008] = typeof(CameraMotionBlur);  //  dest_result_addr=1152921509949870992 |  dest_result_addr=1152921509949871008
        // 0x02676A7C: LDR q2, [sp, #0x630]       | Q2 = val_20;                            
        // 0x02676A80: LDR q3, [sp, #0x620]       | Q3 = val_21;                            
        // 0x02676A84: ADD x8, sp, #0x410         | X8 = (1152921509949870272 + 1040) = 1152921509949871312 (0x100000013E7814D0);
        // 0x02676A88: ADD x1, sp, #0x2d0         | X1 = (1152921509949870272 + 720) = 1152921509949870992 (0x100000013E781390);
        // 0x02676A8C: ADD x2, sp, #0x290         | X2 = (1152921509949870272 + 656) = 1152921509949870928 (0x100000013E781350);
        // 0x02676A90: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02676A94: STP q1, q0, [sp, #0x2b0]   | stack[1152921509949870960] = val_19;  stack[1152921509949870976] = val_18;  //  dest_result_addr=1152921509949870960 |  dest_result_addr=1152921509949870976
        // 0x02676A98: STP q3, q2, [sp, #0x290]   | stack[1152921509949870928] = val_21;  stack[1152921509949870944] = val_20;  //  dest_result_addr=1152921509949870928 |  dest_result_addr=1152921509949870944
        // 0x02676A9C: BL #0x1b7133c              | X0 = UnityEngine.Matrix4x4.op_Multiply(lhs:  new UnityEngine.Matrix4x4(), rhs:  new UnityEngine.Matrix4x4() {m00 = this.prevViewProjMat, m10 = this.prevViewProjMat, m20 = this.prevViewProjMat, m30 = this.prevViewProjMat, m01 = 9.262519E-33f, m11 = 2.524355E-29f, m21 = 9.262519E-33f, m31 = 2.524355E-29f, m02 = 9.262519E-33f, m12 = 2.524355E-29f, m22 = 9.262519E-33f, m32 = 2.524355E-29f, m03 = 9.262519E-33f, m13 = 2.524355E-29f, m23 = 9.262519E-33f, m33 = 2.524355E-29f});
        UnityEngine.Matrix4x4 val_36 = UnityEngine.Matrix4x4.op_Multiply(lhs:  new UnityEngine.Matrix4x4(), rhs:  new UnityEngine.Matrix4x4() {m00 = this.prevViewProjMat, m10 = this.prevViewProjMat, m20 = this.prevViewProjMat, m30 = this.prevViewProjMat, m01 = 9.262519E-33f, m11 = 2.524355E-29f, m21 = 9.262519E-33f, m31 = 2.524355E-29f, m02 = 9.262519E-33f, m12 = 2.524355E-29f, m22 = 9.262519E-33f, m32 = 2.524355E-29f, m03 = 9.262519E-33f, m13 = 2.524355E-29f, m23 = 9.262519E-33f, m33 = 2.524355E-29f});
        // 0x02676AA0: LDR q0, [sp, #0x690]       | Q0 = this.maxVelocity;                  
        // 0x02676AA4: LDR q1, [sp, #0x680]       | Q1 = this.maxVelocity;                  
        // 0x02676AA8: LDR q2, [sp, #0x670]       | Q2 = this.maxVelocity;                  
        // 0x02676AAC: LDR q3, [sp, #0x660]       | Q3 = this.currentViewProjMat;           
        // 0x02676AB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676AB4: STP q1, q0, [sp, #0x1f0]   | stack[1152921509949870768] = this.maxVelocity;  stack[1152921509949870784] = this.maxVelocity;  //  dest_result_addr=1152921509949870768 |  dest_result_addr=1152921509949870784
        // 0x02676AB8: LDR q0, [sp, #0x440]       | Q0 = val_23;                             //  find_add[1152921509949860192]
        // 0x02676ABC: LDR q1, [sp, #0x430]       | Q1 = val_24;                             //  find_add[1152921509949860192]
        // 0x02676AC0: STP q3, q2, [sp, #0x1d0]   | stack[1152921509949870736] = this.currentViewProjMat;  stack[1152921509949870752] = this.maxVelocity;  //  dest_result_addr=1152921509949870736 |  dest_result_addr=1152921509949870752
        // 0x02676AC4: LDR q2, [sp, #0x420]       | Q2 = val_25;                             //  find_add[1152921509949860192]
        // 0x02676AC8: LDR q3, [sp, #0x410]       | Q3 = val_26;                             //  find_add[1152921509949860192]
        // 0x02676ACC: ADD x8, sp, #0x250         | X8 = (1152921509949870272 + 592) = 1152921509949870864 (0x100000013E781310);
        // 0x02676AD0: ADD x1, sp, #0x210         | X1 = (1152921509949870272 + 528) = 1152921509949870800 (0x100000013E7812D0);
        // 0x02676AD4: ADD x2, sp, #0x1d0         | X2 = (1152921509949870272 + 464) = 1152921509949870736 (0x100000013E781290);
        // 0x02676AD8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02676ADC: STP q1, q0, [sp, #0x230]   | stack[1152921509949870832] = val_24;  stack[1152921509949870848] = val_23;  //  dest_result_addr=1152921509949870832 |  dest_result_addr=1152921509949870848
        // 0x02676AE0: STP q3, q2, [sp, #0x210]   | stack[1152921509949870800] = val_26;  stack[1152921509949870816] = val_25;  //  dest_result_addr=1152921509949870800 |  dest_result_addr=1152921509949870816
        // 0x02676AE4: BL #0x1b7133c              | X0 = UnityEngine.Matrix4x4.op_Multiply(lhs:  new UnityEngine.Matrix4x4(), rhs:  new UnityEngine.Matrix4x4() {m00 = val_26, m10 = val_26, m20 = val_26, m30 = val_26, m01 = val_25, m11 = val_25, m21 = val_25, m31 = val_25, m02 = val_24, m12 = val_24, m22 = val_24, m32 = val_24, m03 = val_23, m13 = val_23, m23 = val_23, m33 = val_23});
        UnityEngine.Matrix4x4 val_37 = UnityEngine.Matrix4x4.op_Multiply(lhs:  new UnityEngine.Matrix4x4(), rhs:  new UnityEngine.Matrix4x4() {m00 = val_26, m10 = val_26, m20 = val_26, m30 = val_26, m01 = val_25, m11 = val_25, m21 = val_25, m31 = val_25, m02 = val_24, m12 = val_24, m22 = val_24, m32 = val_24, m03 = val_23, m13 = val_23, m23 = val_23, m33 = val_23});
        // 0x02676AE8: LDR q0, [sp, #0x280]       | Q0 = val_38;                             //  find_add[1152921509949860192]
        // 0x02676AEC: STR q0, [x28, #0x30]       | m03 = val_38;                            //  dest_result_addr=0
        m03 = val_38;
        // 0x02676AF0: LDR q0, [sp, #0x270]       | Q0 = val_39;                             //  find_add[1152921509949860192]
        // 0x02676AF4: STR q0, [x28, #0x20]       | m02 = val_39;                            //  dest_result_addr=0
        m02 = val_39;
        // 0x02676AF8: LDR q0, [sp, #0x260]       | Q0 = val_40;                             //  find_add[1152921509949860192]
        // 0x02676AFC: STR q0, [x28, #0x10]       | m01 = val_40;                            //  dest_result_addr=0
        m01 = val_40;
        // 0x02676B00: LDR q0, [sp, #0x250]       | Q0 = val_41;                             //  find_add[1152921509949860192]
        // 0x02676B04: STR q0, [x28]              | mem2[0] = val_41;                        //  dest_result_addr=0
        mem2[0] = val_41;
        // 0x02676B08: LDR x25, [x21, #0x70]      | X25 = this.motionBlurMaterial; //P2     
        // 0x02676B0C: LDP q1, q0, [sp, #0x270]   | Q1 = val_39; Q0 = val_38;                //  find_add[1152921509949860192] |  find_add[1152921509949860192]
        // 0x02676B10: LDP q3, q2, [sp, #0x250]   | Q3 = val_41; Q2 = val_40;                //  find_add[1152921509949860192] |  find_add[1152921509949860192]
        // 0x02676B14: STP q1, q0, [sp, #0x1b0]   | stack[1152921509949870704] = val_39;  stack[1152921509949870720] = val_38;  //  dest_result_addr=1152921509949870704 |  dest_result_addr=1152921509949870720
        // 0x02676B18: STP q3, q2, [sp, #0x190]   | stack[1152921509949870672] = val_41;  stack[1152921509949870688] = val_40;  //  dest_result_addr=1152921509949870672 |  dest_result_addr=1152921509949870688
        // 0x02676B1C: CBNZ x25, #0x2676b24       | if (this.motionBlurMaterial != null) goto label_65;
        if(this.motionBlurMaterial != null)
        {
            goto label_65;
        }
        // 0x02676B20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_65:
        // 0x02676B24: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
        // 0x02676B28: LDR x8, [x8, #0xab0]       | X8 = (string**)(1152921509949592128)("_PrevViewProj");
        // 0x02676B2C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02676B30: ADD x2, sp, #0x150         | X2 = (1152921509949870272 + 336) = 1152921509949870608 (0x100000013E781210);
        // 0x02676B34: MOV x0, x25                | X0 = this.motionBlurMaterial;//m1       
        // 0x02676B38: LDR x1, [x8]               | X1 = "_PrevViewProj";                   
        // 0x02676B3C: LDP q1, q0, [sp, #0x1b0]   | Q1 = val_39; Q0 = val_38;                //  | 
        // 0x02676B40: LDP q3, q2, [sp, #0x190]   | Q3 = val_41; Q2 = val_40;                //  | 
        // 0x02676B44: STP q1, q0, [sp, #0x170]   | stack[1152921509949870640] = val_39;  stack[1152921509949870656] = val_38;  //  dest_result_addr=1152921509949870640 |  dest_result_addr=1152921509949870656
        // 0x02676B48: STP q3, q2, [sp, #0x150]   | stack[1152921509949870608] = val_41;  stack[1152921509949870624] = val_40;  //  dest_result_addr=1152921509949870608 |  dest_result_addr=1152921509949870624
        // 0x02676B4C: BL #0x1a7a040              | this.motionBlurMaterial.SetMatrix(name:  "_PrevViewProj", value:  new UnityEngine.Matrix4x4() {m00 = val_41, m10 = val_41, m20 = val_41, m30 = val_41, m01 = val_40, m11 = val_40, m21 = val_40, m31 = val_40, m02 = val_39, m12 = val_39, m22 = val_39, m32 = val_39, m03 = val_38, m13 = val_38, m23 = val_38, m33 = val_38});
        this.motionBlurMaterial.SetMatrix(name:  "_PrevViewProj", value:  new UnityEngine.Matrix4x4() {m00 = val_41, m10 = val_41, m20 = val_41, m30 = val_41, m01 = val_40, m11 = val_40, m21 = val_40, m31 = val_40, m02 = val_39, m12 = val_39, m22 = val_39, m32 = val_39, m03 = val_38, m13 = val_38, m23 = val_38, m33 = val_38});
        // 0x02676B50: LDR q0, [x28, #0x30]       | Q0 = this.prevViewProjMat.m03;          
        // 0x02676B54: LDR x25, [x21, #0x70]      | X25 = this.motionBlurMaterial; //P2     
        // 0x02676B58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676B5C: ADD x8, sp, #0x110         | X8 = (1152921509949870272 + 272) = 1152921509949870544 (0x100000013E7811D0);
        // 0x02676B60: STR q0, [sp, #0x100]       | stack[1152921509949870528] = this.prevViewProjMat.m03;  //  dest_result_addr=1152921509949870528
        // 0x02676B64: LDR q0, [x28, #0x20]       | Q0 = this.prevViewProjMat.m02;          
        // 0x02676B68: ADD x1, sp, #0xd0          | X1 = (1152921509949870272 + 208) = 1152921509949870480 (0x100000013E781190);
        // 0x02676B6C: ADD x2, sp, #0x90          | X2 = (1152921509949870272 + 144) = 1152921509949870416 (0x100000013E781150);
        // 0x02676B70: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02676B74: STR q0, [sp, #0xf0]        | stack[1152921509949870512] = this.prevViewProjMat.m02;  //  dest_result_addr=1152921509949870512
        // 0x02676B78: LDR q0, [x28, #0x10]       | Q0 = this.prevViewProjMat.m01;          
        // 0x02676B7C: LDP q2, q1, [x29, #-0xb0]  | Q2 = val_19; Q1 = val_18;                //  | 
        // 0x02676B80: LDUR q3, [x29, #-0xc0]     | Q3 = val_20;                            
        // 0x02676B84: STR q0, [sp, #0xe0]        | stack[1152921509949870496] = this.prevViewProjMat.m01;  //  dest_result_addr=1152921509949870496
        // 0x02676B88: LDR q0, [x28]              | Q0 = this.prevViewProjMat.m00;          
        // 0x02676B8C: STR q1, [sp, #0xc0]        | stack[1152921509949870464] = val_18;     //  dest_result_addr=1152921509949870464
        // 0x02676B90: LDUR q1, [x29, #-0xd0]     | Q1 = val_21;                            
        // 0x02676B94: STP q3, q2, [sp, #0xa0]    | stack[1152921509949870432] = val_20;  stack[1152921509949870448] = val_19;  //  dest_result_addr=1152921509949870432 |  dest_result_addr=1152921509949870448
        // 0x02676B98: STR q0, [sp, #0xd0]        | stack[1152921509949870480] = this.prevViewProjMat.m00;  //  dest_result_addr=1152921509949870480
        // 0x02676B9C: STR q1, [sp, #0x90]        | stack[1152921509949870416] = val_21;     //  dest_result_addr=1152921509949870416
        // 0x02676BA0: BL #0x1b7133c              | X0 = UnityEngine.Matrix4x4.op_Multiply(lhs:  new UnityEngine.Matrix4x4(), rhs:  new UnityEngine.Matrix4x4() {m00 = this.prevViewProjMat.m00, m01 = this.prevViewProjMat.m01, m02 = this.prevViewProjMat.m02, m03 = this.prevViewProjMat.m03});
        UnityEngine.Matrix4x4 val_42 = UnityEngine.Matrix4x4.op_Multiply(lhs:  new UnityEngine.Matrix4x4(), rhs:  new UnityEngine.Matrix4x4() {m00 = this.prevViewProjMat.m00, m01 = this.prevViewProjMat.m01, m02 = this.prevViewProjMat.m02, m03 = this.prevViewProjMat.m03});
        // 0x02676BA4: CBNZ x25, #0x2676bac       | if (this.motionBlurMaterial != null) goto label_66;
        if(this.motionBlurMaterial != null)
        {
            goto label_66;
        }
        // 0x02676BA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_66:
        // 0x02676BAC: LDR x1, [x27]              | X1 = "_ToPrevViewProjCombined";         
        // 0x02676BB0: LDP q1, q0, [sp, #0x130]   | Q1 = val_43; Q0 = val_44;                //  find_add[1152921509949860192] |  find_add[1152921509949860192]
        // 0x02676BB4: LDP q3, q2, [sp, #0x110]   | Q3 = val_45; Q2 = val_46;                //  find_add[1152921509949860192] |  find_add[1152921509949860192]
        // 0x02676BB8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02676BBC: ADD x2, sp, #0x50          | X2 = (1152921509949870272 + 80) = 1152921509949870352 (0x100000013E781110);
        // 0x02676BC0: MOV x0, x25                | X0 = this.motionBlurMaterial;//m1       
        // 0x02676BC4: STP q1, q0, [sp, #0x70]    | stack[1152921509949870384] = val_43;  stack[1152921509949870400] = val_44;  //  dest_result_addr=1152921509949870384 |  dest_result_addr=1152921509949870400
        // 0x02676BC8: STP q3, q2, [sp, #0x50]    | stack[1152921509949870352] = val_45;  stack[1152921509949870368] = val_46;  //  dest_result_addr=1152921509949870352 |  dest_result_addr=1152921509949870368
        // 0x02676BCC: BL #0x1a7a040              | this.motionBlurMaterial.SetMatrix(name:  "_ToPrevViewProjCombined", value:  new UnityEngine.Matrix4x4() {m00 = val_45, m10 = val_45, m20 = val_45, m30 = val_45, m01 = val_46, m11 = val_46, m21 = val_46, m31 = val_46, m02 = val_43, m12 = val_43, m22 = val_43, m32 = val_43, m03 = val_44, m13 = val_44, m23 = val_44, m33 = val_44});
        this.motionBlurMaterial.SetMatrix(name:  "_ToPrevViewProjCombined", value:  new UnityEngine.Matrix4x4() {m00 = val_45, m10 = val_45, m20 = val_45, m30 = val_45, m01 = val_46, m11 = val_46, m21 = val_46, m31 = val_46, m02 = val_43, m12 = val_43, m22 = val_43, m32 = val_43, m03 = val_44, m13 = val_44, m23 = val_44, m33 = val_44});
        label_56:
        // 0x02676BD0: LDR w8, [x21, #0x1c]       | W8 = this.filterType; //P2              
        // 0x02676BD4: CBZ w8, #0x2676d6c         | if (this.filterType == 0) goto label_67;
        if(this.filterType == 0)
        {
            goto label_67;
        }
        // 0x02676BD8: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02676BDC: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02676BE0: LDR x25, [x21, #0x70]      | X25 = this.motionBlurMaterial; //P2     
        // 0x02676BE4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02676BE8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02676BEC: TBZ w8, #0, #0x2676bfc     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_69;
        // 0x02676BF0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02676BF4: CBNZ w8, #0x2676bfc        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_69;
        // 0x02676BF8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_69:
        // 0x02676BFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676C00: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
        // 0x02676C04: MOV x1, x20                | X1 = source;//m1                        
        // 0x02676C08: MOV x2, x22                | X2 = val_3;//m1                         
        // 0x02676C0C: MOV x3, x25                | X3 = this.motionBlurMaterial;//m1       
        // 0x02676C10: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02676C14: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  val_3, pass:  this.motionBlurMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  val_3, pass:  this.motionBlurMaterial);
        // 0x02676C18: ADD x26, x21, #0x4c        | X26 = this.excludeLayers;//AP2 res_addr=1152921509949884268
        val_114 = this.excludeLayers;
        // 0x02676C1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676C20: MOV x0, x26                | X0 = this.excludeLayers;//m1            
        // 0x02676C24: BL #0x1a73234              | X0 = this.excludeLayers.get_areaMask(); 
        int val_47 = val_114.areaMask;
        // 0x02676C28: ADRP x19, #0x35fe000       | X19 = 56614912 (0x35FE000);             
        // 0x02676C2C: LDR x19, [x19, #0x810]     | X19 = 1152921504697475072;              
        val_104 = 1152921504697475072;
        // 0x02676C30: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
        val_115 = 0;
        // 0x02676C34: CBZ w0, #0x2676c50         | if (val_47 == 0) goto label_70;         
        if(val_47 == 0)
        {
            goto label_70;
        }
        // 0x02676C38: LDR x8, [x21]              | X8 = typeof(CameraMotionBlur);          
        // 0x02676C3C: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676C40: LDR x9, [x8, #0x260]       | X9 = typeof(CameraMotionBlur).__il2cppRuntimeField_260;
        // 0x02676C44: LDR x1, [x8, #0x268]       | X1 = typeof(CameraMotionBlur).__il2cppRuntimeField_268;
        // 0x02676C48: BLR x9                     | X0 = typeof(CameraMotionBlur).__il2cppRuntimeField_260();
        // 0x02676C4C: MOV x25, x0                | X25 = 1152921509949884192 (0x100000013E784720);//ML01
        val_115 = val_105;
        label_70:
        // 0x02676C50: LDR x0, [x19]              | X0 = typeof(UnityEngine.Object);        
        // 0x02676C54: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02676C58: TBZ w8, #0, #0x2676c68     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_72;
        // 0x02676C5C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02676C60: CBNZ w8, #0x2676c68        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_72;
        // 0x02676C64: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_72:
        // 0x02676C68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676C6C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02676C70: MOV x1, x25                | X1 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676C74: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_48 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x02676C78: TBZ w0, #0, #0x2677400     | if (val_48 == false) goto label_120;    
        if(val_48 == false)
        {
            goto label_120;
        }
        // 0x02676C7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676C80: MOV x0, x26                | X0 = this.excludeLayers;//m1            
        // 0x02676C84: BL #0x1a73234              | X0 = this.excludeLayers.get_areaMask(); 
        int val_49 = val_114.areaMask;
        // 0x02676C88: CBZ w0, #0x2677400         | if (val_49 == 0) goto label_120;        
        if(val_49 == 0)
        {
            goto label_120;
        }
        // 0x02676C8C: LDR x0, [x19]              | X0 = typeof(UnityEngine.Object);        
        // 0x02676C90: LDR x26, [x21, #0x68]      | X26 = this.replacementClear; //P2       
        val_114 = this.replacementClear;
        // 0x02676C94: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02676C98: TBZ w8, #0, #0x2676ca8     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_76;
        // 0x02676C9C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02676CA0: CBNZ w8, #0x2676ca8        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_76;
        // 0x02676CA4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_76:
        // 0x02676CA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676CAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02676CB0: MOV x1, x26                | X1 = this.replacementClear;//m1         
        // 0x02676CB4: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_50 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x02676CB8: TBZ w0, #0, #0x2677400     | if (val_50 == false) goto label_120;    
        if(val_50 == false)
        {
            goto label_120;
        }
        // 0x02676CBC: LDR x26, [x21, #0x68]      | X26 = this.replacementClear; //P2       
        val_114 = this.replacementClear;
        // 0x02676CC0: CBNZ x26, #0x2676cc8       | if (this.replacementClear != null) goto label_78;
        if(val_114 != null)
        {
            goto label_78;
        }
        // 0x02676CC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_50, ????);     
        label_78:
        // 0x02676CC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676CCC: MOV x0, x26                | X0 = this.replacementClear;//m1         
        // 0x02676CD0: BL #0x1b8e0d8              | X0 = this.replacementClear.get_isSupported();
        bool val_51 = val_114.isSupported;
        // 0x02676CD4: TBZ w0, #0, #0x2677400     | if (val_51 == false) goto label_120;    
        if(val_51 == false)
        {
            goto label_120;
        }
        // 0x02676CD8: CBNZ x25, #0x2676ce0       | if (this != null) goto label_80;        
        if(this != null)
        {
            goto label_80;
        }
        // 0x02676CDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_51, ????);     
        label_80:
        // 0x02676CE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02676CE4: MOV x0, x25                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676CE8: MOV x1, x22                | X1 = val_3;//m1                         
        // 0x02676CEC: BL #0x20cfd28              | this.set_targetTexture(value:  val_3);  
        this.targetTexture = val_3;
        // 0x02676CF0: LDR w1, [x21, #0x4c]       | W1 = this.excludeLayers; //P2           
        // 0x02676CF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676CF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02676CFC: BL #0x1a73224              | X0 = UnityEngine.LayerMask.op_Implicit(mask:  new UnityEngine.LayerMask());
        int val_52 = UnityEngine.LayerMask.op_Implicit(mask:  new UnityEngine.LayerMask());
        // 0x02676D00: MOV w26, w0                | W26 = val_52;//m1                       
        // 0x02676D04: CBNZ x25, #0x2676d0c       | if (this != null) goto label_81;        
        if(this != null)
        {
            goto label_81;
        }
        // 0x02676D08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_52, ????);     
        label_81:
        // 0x02676D0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02676D10: MOV x0, x25                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676D14: MOV w1, w26                | W1 = val_52;//m1                        
        // 0x02676D18: BL #0x20cf678              | this.set_cullingMask(value:  val_52);   
        this.cullingMask = val_52;
        // 0x02676D1C: ADRP x19, #0x35d6000       | X19 = 56451072 (0x35D6000);             
        // 0x02676D20: LDR x19, [x19, #0xe38]     | X19 = 1152921504608284672;              
        val_104 = 1152921504608284672;
        // 0x02676D24: LDR x26, [x21, #0x68]      | X26 = this.replacementClear; //P2       
        val_114 = this.replacementClear;
        // 0x02676D28: LDR x0, [x19]              | X0 = typeof(System.String);             
        // 0x02676D2C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x02676D30: TBZ w8, #0, #0x2676d44     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_83;
        // 0x02676D34: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x02676D38: CBNZ w8, #0x2676d44        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_83;
        // 0x02676D3C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x02676D40: LDR x0, [x19]              | X0 = typeof(System.String);             
        label_83:
        // 0x02676D44: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x02676D48: LDR x27, [x8]              | X27 = System.String.Empty;              
        val_108 = System.String.Empty;
        // 0x02676D4C: CBNZ x25, #0x2676d54       | if (this != null) goto label_84;        
        if(this != null)
        {
            goto label_84;
        }
        // 0x02676D50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String), ????);
        label_84:
        // 0x02676D54: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02676D58: MOV x0, x25                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676D5C: MOV x1, x26                | X1 = this.replacementClear;//m1         
        // 0x02676D60: MOV x2, x27                | X2 = System.String.Empty;//m1           
        // 0x02676D64: BL #0x20d22f0              | this.RenderWithShader(shader:  val_114, replacementTag:  val_108);
        this.RenderWithShader(shader:  val_114, replacementTag:  val_108);
        // 0x02676D68: B #0x2677400               |  goto label_120;                        
        goto label_120;
        label_67:
        // 0x02676D6C: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x02676D70: LDR x8, [x8, #0xb10]       | X8 = 1152921504708763648;               
        // 0x02676D74: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector4);       
        // 0x02676D78: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector4.__il2cppRuntimeField_10A;
        // 0x02676D7C: TBZ w8, #0, #0x2676d8c     | if (UnityEngine.Vector4.__il2cppRuntimeField_has_cctor == 0) goto label_87;
        // 0x02676D80: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector4.__il2cppRuntimeField_cctor_finished;
        // 0x02676D84: CBNZ w8, #0x2676d8c        | if (UnityEngine.Vector4.__il2cppRuntimeField_cctor_finished != 0) goto label_87;
        // 0x02676D88: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector4), ????);
        label_87:
        // 0x02676D8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676D90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676D94: BL #0x2689b4c              | X0 = UnityEngine.Vector4.get_zero();    
        UnityEngine.Vector4 val_53 = UnityEngine.Vector4.zero;
        // 0x02676D98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676D9C: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676DA0: STR s3, [sp, #0x30]        | stack[1152921509949870320] = val_53.w;   //  dest_result_addr=1152921509949870320
        // 0x02676DA4: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_54 = this.transform;
        // 0x02676DA8: MOV x25, x0                | X25 = val_54;//m1                       
        // 0x02676DAC: CBNZ x25, #0x2676db4       | if (val_54 != null) goto label_88;      
        if(val_54 != null)
        {
            goto label_88;
        }
        // 0x02676DB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_54, ????);     
        label_88:
        // 0x02676DB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676DB8: MOV x0, x25                | X0 = val_54;//m1                        
        // 0x02676DBC: BL #0x2693c68              | X0 = val_54.get_up();                   
        UnityEngine.Vector3 val_55 = val_54.up;
        // 0x02676DC0: ADRP x19, #0x3673000       | X19 = 57094144 (0x3673000);             
        // 0x02676DC4: LDR x19, [x19, #0x488]     | X19 = 1152921504695078912;              
        val_104 = 1152921504695078912;
        // 0x02676DC8: MOV v9.16b, v0.16b         | V9 = val_55.x;//m1                      
        // 0x02676DCC: MOV v10.16b, v1.16b        | V10 = val_55.y;//m1                     
        // 0x02676DD0: MOV v11.16b, v2.16b        | V11 = val_55.z;//m1                     
        // 0x02676DD4: LDR x0, [x19]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x02676DD8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x02676DDC: TBZ w8, #0, #0x2676dec     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_90;
        // 0x02676DE0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x02676DE4: CBNZ w8, #0x2676dec        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_90;
        // 0x02676DE8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_90:
        // 0x02676DEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676DF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676DF4: BL #0x2693d60              | X0 = UnityEngine.Vector3.get_up();      
        UnityEngine.Vector3 val_56 = UnityEngine.Vector3.up;
        // 0x02676DF8: MOV v3.16b, v0.16b         | V3 = val_56.x;//m1                      
        // 0x02676DFC: MOV v4.16b, v1.16b         | V4 = val_56.y;//m1                      
        // 0x02676E00: MOV v5.16b, v2.16b         | V5 = val_56.z;//m1                      
        // 0x02676E04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676E08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676E0C: MOV v0.16b, v9.16b         | V0 = val_55.x;//m1                      
        // 0x02676E10: MOV v1.16b, v10.16b        | V1 = val_55.y;//m1                      
        // 0x02676E14: MOV v2.16b, v11.16b        | V2 = val_55.z;//m1                      
        // 0x02676E18: BL #0x2699664              | X0 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_55.x, y = val_55.y, z = val_55.z}, rhs:  new UnityEngine.Vector3() {x = val_56.x, y = val_56.y, z = val_56.z});
        float val_57 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_55.x, y = val_55.y, z = val_55.z}, rhs:  new UnityEngine.Vector3() {x = val_56.x, y = val_56.y, z = val_56.z});
        // 0x02676E1C: LDR s10, [x21, #0x140]     | S10 = this.prevFramePos; //P2           
        // 0x02676E20: LDR s11, [x21, #0x144]     | 
        // 0x02676E24: LDR s12, [x21, #0x148]     | 
        // 0x02676E28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676E2C: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676E30: STR s0, [sp, #0x40]        | stack[1152921509949870336] = val_57;     //  dest_result_addr=1152921509949870336
        // 0x02676E34: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_58 = this.transform;
        // 0x02676E38: MOV x25, x0                | X25 = val_58;//m1                       
        // 0x02676E3C: CBNZ x25, #0x2676e44       | if (val_58 != null) goto label_91;      
        if(val_58 != null)
        {
            goto label_91;
        }
        // 0x02676E40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_58, ????);     
        label_91:
        // 0x02676E44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676E48: MOV x0, x25                | X0 = val_58;//m1                        
        // 0x02676E4C: BL #0x2693510              | X0 = val_58.get_position();             
        UnityEngine.Vector3 val_59 = val_58.position;
        // 0x02676E50: MOV v3.16b, v0.16b         | V3 = val_59.x;//m1                      
        // 0x02676E54: MOV v4.16b, v1.16b         | V4 = val_59.y;//m1                      
        // 0x02676E58: MOV v5.16b, v2.16b         | V5 = val_59.z;//m1                      
        // 0x02676E5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676E60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676E64: MOV v0.16b, v10.16b        | V0 = this.prevFramePos;//m1             
        // 0x02676E68: MOV v1.16b, v11.16b        | V1 = val_55.z;//m1                      
        // 0x02676E6C: MOV v2.16b, v12.16b        | V2 = val_31.y;//m1                      
        // 0x02676E70: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = this.prevFramePos, y = val_55.z, z = val_111}, b:  new UnityEngine.Vector3() {x = val_59.x, y = val_59.y, z = val_59.z});
        UnityEngine.Vector3 val_60 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = this.prevFramePos, y = val_55.z, z = val_111}, b:  new UnityEngine.Vector3() {x = val_59.x, y = val_59.y, z = val_59.z});
        // 0x02676E74: ADD x0, sp, #0x610         | X0 = (1152921509949870272 + 1552) = 1152921509949871824 (0x100000013E7816D0);
        // 0x02676E78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676E7C: STR s0, [sp, #0x610]       | stack[1152921509949871824] = val_60.x;   //  dest_result_addr=1152921509949871824
        // 0x02676E80: STR s1, [sp, #0x614]       | stack[1152921509949871828] = val_60.y;   //  dest_result_addr=1152921509949871828
        // 0x02676E84: STR s2, [sp, #0x618]       | stack[1152921509949871832] = val_60.z;   //  dest_result_addr=1152921509949871832
        // 0x02676E88: BL #0x2699080              | X0 = label_UnityEngine_Vector3_MoveTowards_GL02699080();
        // 0x02676E8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676E90: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676E94: STR s0, [sp, #0x38]        | stack[1152921509949870328] = val_60.x;   //  dest_result_addr=1152921509949870328
        // 0x02676E98: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_61 = this.transform;
        // 0x02676E9C: MOV x25, x0                | X25 = val_61;//m1                       
        // 0x02676EA0: CBNZ x25, #0x2676ea8       | if (val_61 != null) goto label_92;      
        if(val_61 != null)
        {
            goto label_92;
        }
        // 0x02676EA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_61, ????);     
        label_92:
        // 0x02676EA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676EAC: MOV x0, x25                | X0 = val_61;//m1                        
        // 0x02676EB0: BL #0x2693c68              | X0 = val_61.get_up();                   
        UnityEngine.Vector3 val_62 = val_61.up;
        // 0x02676EB4: LDR s3, [x21, #0x134]      | S3 = this.prevFrameUp; //P2             
        // 0x02676EB8: LDR s4, [x21, #0x138]      | 
        // 0x02676EBC: LDR s5, [x21, #0x13c]      | 
        // 0x02676EC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676EC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676EC8: BL #0x269a014              | X0 = UnityEngine.Vector3.Angle(from:  new UnityEngine.Vector3() {x = val_62.x, y = val_62.y, z = val_62.z}, to:  new UnityEngine.Vector3() {x = this.prevFrameUp, y = val_59.y, z = val_59.z});
        float val_63 = UnityEngine.Vector3.Angle(from:  new UnityEngine.Vector3() {x = val_62.x, y = val_62.y, z = val_62.z}, to:  new UnityEngine.Vector3() {x = this.prevFrameUp, y = val_59.y, z = val_59.z});
        // 0x02676ECC: ADRP x28, #0x3668000       | X28 = 57049088 (0x3668000);             
        // 0x02676ED0: LDR x28, [x28, #0x338]     | X28 = 1152921509941328016;              
        // 0x02676ED4: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676ED8: MOV v12.16b, v0.16b        | V12 = val_63;//m1                       
        float val_101 = val_63;
        // 0x02676EDC: LDR x1, [x28]              | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x02676EE0: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_64 = this.GetComponent<UnityEngine.Camera>();
        // 0x02676EE4: MOV x25, x0                | X25 = val_64;//m1                       
        // 0x02676EE8: CBNZ x25, #0x2676ef0       | if (val_64 != null) goto label_93;      
        if(val_64 != null)
        {
            goto label_93;
        }
        // 0x02676EEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_64, ????);     
        label_93:
        // 0x02676EF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676EF4: MOV x0, x25                | X0 = val_64;//m1                        
        // 0x02676EF8: BL #0x20ce7bc              | X0 = val_64.get_fieldOfView();          
        float val_65 = val_64.fieldOfView;
        // 0x02676EFC: MOV v14.16b, v0.16b        | V14 = val_65;//m1                       
        // 0x02676F00: CBNZ x20, #0x2676f08       | if (source != null) goto label_94;      
        if(source != null)
        {
            goto label_94;
        }
        // 0x02676F04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_64, ????);     
        label_94:
        // 0x02676F08: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02676F0C: STR s15, [sp, #0x3c]       | stack[1152921509949870332] = (val_3 / this);  //  dest_result_addr=1152921509949870332
        // 0x02676F10: MOV x0, x20                | X0 = source;//m1                        
        // 0x02676F14: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x02676F18: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x02676F1C: LDR s0, [x21, #0x34]       | S0 = this.rotationScale; //P2           
        // 0x02676F20: MOV w25, w0                | W25 = source;//m1                       
        // 0x02676F24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676F28: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676F2C: STR s0, [sp, #0x34]        | stack[1152921509949870324] = this.rotationScale;  //  dest_result_addr=1152921509949870324
        // 0x02676F30: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_66 = this.transform;
        // 0x02676F34: MOV x26, x0                | X26 = val_66;//m1                       
        // 0x02676F38: CBNZ x26, #0x2676f40       | if (val_66 != null) goto label_95;      
        if(val_66 != null)
        {
            goto label_95;
        }
        // 0x02676F3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_66, ????);     
        label_95:
        // 0x02676F40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676F44: MOV x0, x26                | X0 = val_66;//m1                        
        // 0x02676F48: BL #0x2693ec0              | X0 = val_66.get_forward();              
        UnityEngine.Vector3 val_67 = val_66.forward;
        // 0x02676F4C: LDR s3, [x21, #0x11c]      | S3 = this.prevFrameForward; //P2        
        // 0x02676F50: LDR s4, [x21, #0x120]      | 
        // 0x02676F54: LDR s5, [x21, #0x124]      | 
        // 0x02676F58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676F5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676F60: BL #0x269a014              | X0 = UnityEngine.Vector3.Angle(from:  new UnityEngine.Vector3() {x = val_67.x, y = val_67.y, z = val_67.z}, to:  new UnityEngine.Vector3() {x = this.prevFrameForward, y = val_59.y, z = val_59.z});
        float val_68 = UnityEngine.Vector3.Angle(from:  new UnityEngine.Vector3() {x = val_67.x, y = val_67.y, z = val_67.z}, to:  new UnityEngine.Vector3() {x = this.prevFrameForward, y = val_59.y, z = val_59.z});
        // 0x02676F64: LDR x1, [x28]              | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x02676F68: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676F6C: MOV v15.16b, v0.16b        | V15 = val_68;//m1                       
        // 0x02676F70: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_69 = this.GetComponent<UnityEngine.Camera>();
        // 0x02676F74: MOV x26, x0                | X26 = val_69;//m1                       
        // 0x02676F78: CBNZ x26, #0x2676f80       | if (val_69 != null) goto label_96;      
        if(val_69 != null)
        {
            goto label_96;
        }
        // 0x02676F7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_69, ????);     
        label_96:
        // 0x02676F80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676F84: MOV x0, x26                | X0 = val_69;//m1                        
        // 0x02676F88: BL #0x20ce7bc              | X0 = val_69.get_fieldOfView();          
        float val_70 = val_69.fieldOfView;
        // 0x02676F8C: MOV v10.16b, v0.16b        | V10 = val_70;//m1                       
        // 0x02676F90: CBNZ x20, #0x2676f98       | if (source != null) goto label_97;      
        if(source != null)
        {
            goto label_97;
        }
        // 0x02676F94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_69, ????);     
        label_97:
        // 0x02676F98: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02676F9C: MOV x0, x20                | X0 = source;//m1                        
        // 0x02676FA0: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x02676FA4: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x02676FA8: LDR s9, [x21, #0x34]       | S9 = this.rotationScale; //P2           
        float val_104 = this.rotationScale;
        // 0x02676FAC: MOV w26, w0                | W26 = source;//m1                       
        // 0x02676FB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676FB4: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02676FB8: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_71 = this.transform;
        // 0x02676FBC: MOV x27, x0                | X27 = val_71;//m1                       
        val_108 = val_71;
        // 0x02676FC0: CBNZ x27, #0x2676fc8       | if (val_71 != null) goto label_98;      
        if(val_108 != null)
        {
            goto label_98;
        }
        // 0x02676FC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_71, ????);     
        label_98:
        // 0x02676FC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676FCC: MOV x0, x27                | X0 = val_71;//m1                        
        // 0x02676FD0: SCVTF s11, w25             | S11 = (float)(source);                  
        float val_102 = (float)source;
        // 0x02676FD4: FMOV s8, #0.75000000       | S8 = 0.75;                              
        // 0x02676FD8: SCVTF s13, w26             | S13 = (float)(source);                  
        float val_103 = (float)source;
        // 0x02676FDC: BL #0x2693ec0              | X0 = val_71.get_forward();              
        UnityEngine.Vector3 val_72 = val_108.forward;
        // 0x02676FE0: LDR s3, [x21, #0x11c]      | S3 = this.prevFrameForward; //P2        
        // 0x02676FE4: LDR s4, [x21, #0x120]      | 
        // 0x02676FE8: LDR s5, [x21, #0x124]      | 
        // 0x02676FEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02676FF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02676FF4: BL #0x269a014              | X0 = UnityEngine.Vector3.Angle(from:  new UnityEngine.Vector3() {x = val_72.x, y = val_72.y, z = val_72.z}, to:  new UnityEngine.Vector3() {x = this.prevFrameForward, y = val_59.y, z = val_59.z});
        float val_73 = UnityEngine.Vector3.Angle(from:  new UnityEngine.Vector3() {x = val_72.x, y = val_72.y, z = val_72.z}, to:  new UnityEngine.Vector3() {x = this.prevFrameForward, y = val_59.y, z = val_59.z});
        // 0x02676FF8: LDR x1, [x28]              | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x02676FFC: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02677000: STR s0, [sp, #0x2c]        | stack[1152921509949870316] = val_73;     //  dest_result_addr=1152921509949870316
        // 0x02677004: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_74 = this.GetComponent<UnityEngine.Camera>();
        // 0x02677008: MOV x25, x0                | X25 = val_74;//m1                       
        // 0x0267700C: CBNZ x25, #0x2677014       | if (val_74 != null) goto label_99;      
        if(val_74 != null)
        {
            goto label_99;
        }
        // 0x02677010: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_74, ????);     
        label_99:
        // 0x02677014: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677018: MOV x0, x25                | X0 = val_74;//m1                        
        // 0x0267701C: FDIV s12, s12, s14         | S12 = (val_63 / val_65);                
        val_101 = val_101 / val_65;
        // 0x02677020: FMUL s11, s11, s8          | S11 = (source * 0.75f);                 
        val_102 = val_102 * 0.75f;
        // 0x02677024: FDIV s14, s15, s10         | S14 = (val_68 / val_70);                
        float val_75 = val_68 / val_70;
        // 0x02677028: FMUL s13, s13, s8          | S13 = (source * 0.75f);                 
        val_103 = val_103 * 0.75f;
        // 0x0267702C: BL #0x20ce7bc              | X0 = val_74.get_fieldOfView();          
        float val_76 = val_74.fieldOfView;
        // 0x02677030: MOV v8.16b, v0.16b         | V8 = val_76;//m1                        
        val_117 = val_76;
        // 0x02677034: CBNZ x20, #0x267703c       | if (source != null) goto label_100;     
        if(source != null)
        {
            goto label_100;
        }
        // 0x02677038: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_74, ????);     
        label_100:
        // 0x0267703C: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02677040: MOV x0, x20                | X0 = source;//m1                        
        // 0x02677044: FMUL s10, s12, s11         | S10 = ((val_63 / val_65) * (source * 0.75f));
        val_110 = val_101 * val_102;
        // 0x02677048: FMUL s11, s14, s13         | S11 = ((val_68 / val_70) * (source * 0.75f));
        float val_77 = val_75 * val_103;
        // 0x0267704C: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x02677050: LDR s0, [sp, #0x40]        | S0 = val_57;                            
        // 0x02677054: FMUL s9, s0, s9            | S9 = (val_57 * this.rotationScale);     
        val_104 = val_57 * val_104;
        // 0x02677058: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x0267705C: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x02677060: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x02677064: LDR s12, [x21, #0x34]      | S12 = this.rotationScale; //P2          
        val_111 = this.rotationScale;
        // 0x02677068: MOV w25, w0                | W25 = source;//m1                       
        val_115 = source;
        // 0x0267706C: LDR x8, [x8]               | X8 = typeof(UnityEngine.Mathf);         
        val_118 = null;
        // 0x02677070: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x02677074: TBZ w9, #0, #0x2677094     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_102;
        // 0x02677078: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x0267707C: CBNZ w9, #0x2677094        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_102;
        // 0x02677080: MOV x0, x8                 | X0 = 1152921504695345152 (0x1000000005466000);//ML01
        // 0x02677084: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        // 0x02677088: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x0267708C: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x02677090: LDR x8, [x8]               | X8 = typeof(UnityEngine.Mathf);         
        val_118 = null;
        label_102:
        // 0x02677094: LDP s2, s1, [sp, #0x34]    | S2 = this.rotationScale; S1 = val_60.x;  //  | 
        // 0x02677098: LDR x9, [x8, #0xa0]        | X9 = UnityEngine.Mathf.__il2cppRuntimeField_static_fields;
        // 0x0267709C: FMUL s14, s9, s11          | S14 = ((val_57 * this.rotationScale) * ((val_68 / val_70) * (source * 0.75f)));
        val_112 = val_104 * val_77;
        // 0x026770A0: FMUL s15, s2, s10          | S15 = (this.rotationScale * ((val_63 / val_65) * (source * 0.75f)));
        val_119 = this.rotationScale * val_110;
        // 0x026770A4: LDR s0, [x9]               | S0 = UnityEngine.Mathf.Epsilon;         
        val_120 = UnityEngine.Mathf.Epsilon;
        // 0x026770A8: FCMP s1, s0                | STATE = COMPARE(val_60.x, UnityEngine.Mathf.Epsilon)
        // 0x026770AC: B.LS #0x2677284            | if (val_60.x <= val_120) goto label_103;
        if(val_60.x <= val_120)
        {
            goto label_103;
        }
        // 0x026770B0: STR s8, [sp, #0x38]        | stack[1152921509949870328] = val_76;     //  dest_result_addr=1152921509949870328
        // 0x026770B4: LDR s8, [x21, #0x30]       | S8 = this.movementScale; //P2           
        // 0x026770B8: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x026770BC: TBZ w9, #0, #0x26770e4     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_105;
        // 0x026770C0: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x026770C4: CBNZ w9, #0x26770e4        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_105;
        // 0x026770C8: MOV x0, x8                 | X0 = 1152921504695345152 (0x1000000005466000);//ML01
        // 0x026770CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        // 0x026770D0: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x026770D4: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x026770D8: LDR x8, [x8]               | X8 = typeof(UnityEngine.Mathf);         
        // 0x026770DC: LDR x8, [x8, #0xa0]        | X8 = UnityEngine.Mathf.__il2cppRuntimeField_static_fields;
        // 0x026770E0: LDR s0, [x8]               | S0 = UnityEngine.Mathf.Epsilon;         
        val_120 = UnityEngine.Mathf.Epsilon;
        label_105:
        // 0x026770E4: FCMP s8, s0                | STATE = COMPARE(this.movementScale, UnityEngine.Mathf.Epsilon)
        // 0x026770E8: B.LS #0x267728c            | if (this.movementScale <= val_120) goto label_106;
        if(this.movementScale <= val_120)
        {
            goto label_106;
        }
        // 0x026770EC: LDR s0, [x21, #0x30]       | S0 = this.movementScale; //P2           
        // 0x026770F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026770F4: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x026770F8: STR s12, [sp, #0x34]       | stack[1152921509949870324] = this.rotationScale;  //  dest_result_addr=1152921509949870324
        // 0x026770FC: STR s0, [sp, #0x30]        | stack[1152921509949870320] = this.movementScale;  //  dest_result_addr=1152921509949870320
        // 0x02677100: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_78 = this.transform;
        // 0x02677104: MOV x26, x0                | X26 = val_78;//m1                       
        // 0x02677108: CBNZ x26, #0x2677110       | if (val_78 != null) goto label_107;     
        if(val_78 != null)
        {
            goto label_107;
        }
        // 0x0267710C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_78, ????);     
        label_107:
        // 0x02677110: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677114: MOV x0, x26                | X0 = val_78;//m1                        
        // 0x02677118: BL #0x2693ec0              | X0 = val_78.get_forward();              
        UnityEngine.Vector3 val_79 = val_78.forward;
        // 0x0267711C: LDR x0, [x19]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x02677120: LDR s12, [sp, #0x610]      | S12 = val_60.x;                         
        // 0x02677124: LDR s11, [sp, #0x614]      | S11 = val_60.y;                         
        // 0x02677128: LDR s9, [sp, #0x618]       | S9 = val_60.z;                          
        // 0x0267712C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x02677130: MOV v10.16b, v0.16b        | V10 = val_79.x;//m1                     
        // 0x02677134: MOV v13.16b, v1.16b        | V13 = val_79.y;//m1                     
        // 0x02677138: MOV v8.16b, v2.16b         | V8 = val_79.z;//m1                      
        // 0x0267713C: TBZ w8, #0, #0x267714c     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_109;
        // 0x02677140: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x02677144: CBNZ w8, #0x267714c        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_109;
        // 0x02677148: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_109:
        // 0x0267714C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02677150: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677154: MOV v0.16b, v10.16b        | V0 = val_79.x;//m1                      
        // 0x02677158: MOV v1.16b, v13.16b        | V1 = val_79.y;//m1                      
        // 0x0267715C: MOV v2.16b, v8.16b         | V2 = val_79.z;//m1                      
        // 0x02677160: MOV v3.16b, v12.16b        | V3 = val_60.x;//m1                      
        // 0x02677164: MOV v4.16b, v11.16b        | V4 = val_60.y;//m1                      
        // 0x02677168: MOV v5.16b, v9.16b         | V5 = val_60.z;//m1                      
        // 0x0267716C: BL #0x2699664              | X0 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_79.x, y = val_79.y, z = val_79.z}, rhs:  new UnityEngine.Vector3() {x = val_60.x, y = val_60.y, z = val_60.z});
        float val_80 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_79.x, y = val_79.y, z = val_79.z}, rhs:  new UnityEngine.Vector3() {x = val_60.x, y = val_60.y, z = val_60.z});
        // 0x02677170: MOV v10.16b, v0.16b        | V10 = val_80;//m1                       
        // 0x02677174: CBNZ x20, #0x267717c       | if (source != null) goto label_110;     
        if(source != null)
        {
            goto label_110;
        }
        // 0x02677178: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_110:
        // 0x0267717C: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02677180: MOV x0, x20                | X0 = source;//m1                        
        // 0x02677184: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x02677188: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x0267718C: LDR s12, [x21, #0x30]      | S12 = this.movementScale; //P2          
        // 0x02677190: SCVTF s8, w0               | S8 = (float)(source);                   
        // 0x02677194: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677198: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x0267719C: FMOV s9, #0.50000000       | S9 = 0.5;                               
        // 0x026771A0: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_81 = this.transform;
        // 0x026771A4: MOV x26, x0                | X26 = val_81;//m1                       
        // 0x026771A8: CBNZ x26, #0x26771b0       | if (val_81 != null) goto label_111;     
        if(val_81 != null)
        {
            goto label_111;
        }
        // 0x026771AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_81, ????);     
        label_111:
        // 0x026771B0: LDR s0, [sp, #0x30]        | S0 = this.movementScale;                
        // 0x026771B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026771B8: MOV x0, x26                | X0 = val_81;//m1                        
        // 0x026771BC: FMUL s11, s8, s9           | S11 = (source * 0.5f);                  
        float val_82 = (float)source * 0.5f;
        // 0x026771C0: FMUL s10, s0, s10          | S10 = (this.movementScale * val_80);    
        val_110 = this.movementScale * val_80;
        // 0x026771C4: BL #0x2693c68              | X0 = val_81.get_up();                   
        UnityEngine.Vector3 val_83 = val_81.up;
        // 0x026771C8: LDR s3, [sp, #0x610]       | S3 = val_60.x;                          
        // 0x026771CC: LDR s4, [sp, #0x614]       | S4 = val_60.y;                          
        // 0x026771D0: LDR s5, [sp, #0x618]       | S5 = val_60.z;                          
        // 0x026771D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026771D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026771DC: BL #0x2699664              | X0 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_83.x, y = val_83.y, z = val_83.z}, rhs:  new UnityEngine.Vector3() {x = val_60.x, y = val_60.y, z = val_60.z});
        float val_84 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_83.x, y = val_83.y, z = val_83.z}, rhs:  new UnityEngine.Vector3() {x = val_60.x, y = val_60.y, z = val_60.z});
        // 0x026771E0: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x026771E4: MOV x0, x20                | X0 = source;//m1                        
        // 0x026771E8: MOV v8.16b, v0.16b         | V8 = val_84;//m1                        
        float val_106 = val_84;
        // 0x026771EC: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x026771F0: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x026771F4: FMUL s0, s12, s8           | S0 = (this.movementScale * val_84);     
        val_84 = this.movementScale * val_106;
        // 0x026771F8: LDR s12, [x21, #0x30]      | S12 = this.movementScale; //P2          
        // 0x026771FC: SCVTF s1, w0               | S1 = (float)(source);                   
        float val_105 = (float)source;
        // 0x02677200: FMUL s1, s1, s9            | S1 = (source * 0.5f);                   
        val_105 = val_105 * 0.5f;
        // 0x02677204: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677208: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x0267720C: FMUL s8, s0, s1            | S8 = ((this.movementScale * val_84) * (source * 0.5f));
        val_106 = val_84 * val_105;
        // 0x02677210: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_85 = this.transform;
        // 0x02677214: MOV x26, x0                | X26 = val_85;//m1                       
        // 0x02677218: CBNZ x26, #0x2677220       | if (val_85 != null) goto label_112;     
        if(val_85 != null)
        {
            goto label_112;
        }
        // 0x0267721C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_85, ????);     
        label_112:
        // 0x02677220: FMUL s0, s10, s11          | S0 = ((this.movementScale * val_80) * (source * 0.5f));
        float val_86 = val_110 * val_82;
        // 0x02677224: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677228: MOV x0, x26                | X0 = val_85;//m1                        
        // 0x0267722C: STR s0, [sp, #0x30]        | stack[1152921509949870320] = ((this.movementScale * val_80) * (source * 0.5f));  //  dest_result_addr=1152921509949870320
        // 0x02677230: FADD s15, s15, s8          | S15 = ((this.rotationScale * ((val_63 / val_65) * (source * 0.75f))) + ((this.movementScale * val_84) * (source * 0.5f)));
        val_119 = val_119 + val_106;
        // 0x02677234: BL #0x2693a10              | X0 = val_85.get_right();                
        UnityEngine.Vector3 val_87 = val_85.right;
        // 0x02677238: LDR s3, [sp, #0x610]       | S3 = val_60.x;                          
        // 0x0267723C: LDR s4, [sp, #0x614]       | S4 = val_60.y;                          
        // 0x02677240: LDR s5, [sp, #0x618]       | S5 = val_60.z;                          
        // 0x02677244: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02677248: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267724C: BL #0x2699664              | X0 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_87.x, y = val_87.y, z = val_87.z}, rhs:  new UnityEngine.Vector3() {x = val_60.x, y = val_60.y, z = val_60.z});
        float val_88 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_87.x, y = val_87.y, z = val_87.z}, rhs:  new UnityEngine.Vector3() {x = val_60.x, y = val_60.y, z = val_60.z});
        // 0x02677250: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02677254: MOV x0, x20                | X0 = source;//m1                        
        // 0x02677258: MOV v8.16b, v0.16b         | V8 = val_88;//m1                        
        // 0x0267725C: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x02677260: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x02677264: FMUL s0, s12, s8           | S0 = (this.movementScale * val_88);     
        val_88 = this.movementScale * val_88;
        // 0x02677268: SCVTF s1, w0               | S1 = (float)(source);                   
        float val_107 = (float)source;
        // 0x0267726C: LDP s12, s8, [sp, #0x34]   | S12 = this.rotationScale; S8 = val_76;   //  | 
        val_111 = val_111;
        val_117 = val_117;
        // 0x02677270: FMUL s1, s1, s9            | S1 = (source * 0.5f);                   
        val_107 = val_107 * 0.5f;
        // 0x02677274: FMUL s0, s0, s1            | S0 = ((this.movementScale * val_88) * (source * 0.5f));
        val_88 = val_88 * val_107;
        // 0x02677278: FADD s14, s14, s0          | S14 = (((val_57 * this.rotationScale) * ((val_68 / val_70) * (source * 0.75f))) + ((this.movementScale * val_88) * (source * 0.5f)));
        val_112 = val_112 + val_88;
        // 0x0267727C: FMOV s3, #0.75000000       | S3 = 0.75;                              
        val_121 = 0.75f;
        // 0x02677280: B #0x2677294               |  goto label_114;                        
        goto label_114;
        label_103:
        // 0x02677284: FMOV s3, #0.75000000       | S3 = 0.75;                              
        val_121 = 0.75f;
        // 0x02677288: B #0x2677294               |  goto label_114;                        
        goto label_114;
        label_106:
        // 0x0267728C: LDR s8, [sp, #0x38]        | S8 = val_76;                            
        val_117 = val_117;
        // 0x02677290: FMOV s3, #0.75000000       | S3 = 0.75;                              
        val_121 = 0.75f;
        label_114:
        // 0x02677294: LDR x8, [x21, #0x20]       | X8 = this.preview; //P2                 
        bool val_108 = this.preview;
        // 0x02677298: LDR x26, [x21, #0x70]      | X26 = this.motionBlurMaterial; //P2     
        val_114 = this.motionBlurMaterial;
        // 0x0267729C: AND w9, w8, #0xff          | W9 = (this.preview & 255);              
        bool val_89 = val_108 & 255;
        // 0x026772A0: CBZ w9, #0x26773a4         | if ((this.preview & 255) == false) goto label_115;
        if(val_89 == false)
        {
            goto label_115;
        }
        // 0x026772A4: LDP s0, s3, [x21, #0x28]   |                                          //  | 
        // 0x026772A8: LSR x8, x8, #0x20          | X8 = (this.preview >> 32);              
        val_108 = val_108 >> 32;
        // 0x026772AC: FMOV s1, w8                | S1 = ((this.preview >> 32));            
        // 0x026772B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026772B4: FMOV s2, wzr               | S2 = 0f;                                
        // 0x026772B8: ADD x0, sp, #0x5d0         | X0 = (1152921509949870272 + 1488) = 1152921509949871760 (0x100000013E781690);
        // 0x026772BC: STR xzr, [sp, #0x5d8]      | stack[1152921509949871768] = 0x0;        //  dest_result_addr=1152921509949871768
        // 0x026772C0: STR xzr, [sp, #0x5d0]      | stack[1152921509949871760] = 0x0;        //  dest_result_addr=1152921509949871760
        // 0x026772C4: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x026772C8: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x026772CC: LDR x8, [x8, #0xb10]       | X8 = 1152921504708763648;               
        // 0x026772D0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector4);       
        // 0x026772D4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector4.__il2cppRuntimeField_10A;
        // 0x026772D8: TBZ w8, #0, #0x26772e8     | if (UnityEngine.Vector4.__il2cppRuntimeField_has_cctor == 0) goto label_117;
        // 0x026772DC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector4.__il2cppRuntimeField_cctor_finished;
        // 0x026772E0: CBNZ w8, #0x26772e8        | if (UnityEngine.Vector4.__il2cppRuntimeField_cctor_finished != 0) goto label_117;
        // 0x026772E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector4), ????);
        label_117:
        // 0x026772E8: LDR s0, [sp, #0x5d0]       | S0 = 0;                                 
        // 0x026772EC: LDR s1, [sp, #0x5d4]       | S1 = 0;                                 
        // 0x026772F0: LDR s2, [sp, #0x5d8]       | S2 = 0;                                 
        // 0x026772F4: LDR s3, [sp, #0x5dc]       | S3 = 0;                                 
        // 0x026772F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026772FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677300: FMOV s4, #0.50000000       | S4 = 0.5;                               
        // 0x02677304: BL #0x269b780              | X0 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  0.5f);
        UnityEngine.Vector4 val_90 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  0.5f);
        // 0x02677308: LDR x1, [x28]              | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x0267730C: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02677310: MOV v9.16b, v0.16b         | V9 = val_90.x;//m1                      
        // 0x02677314: MOV v10.16b, v1.16b        | V10 = val_90.y;//m1                     
        // 0x02677318: MOV v12.16b, v2.16b        | V12 = val_90.z;//m1                     
        // 0x0267731C: MOV v11.16b, v3.16b        | V11 = val_90.w;//m1                     
        // 0x02677320: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_91 = this.GetComponent<UnityEngine.Camera>();
        // 0x02677324: LDR s15, [sp, #0x3c]       | S15 = (val_3 / this);                   
        val_107 = val_107;
        // 0x02677328: MOV x25, x0                | X25 = val_91;//m1                       
        val_115 = val_91;
        // 0x0267732C: CBNZ x25, #0x2677334       | if (val_91 != null) goto label_118;     
        if(val_115 != null)
        {
            goto label_118;
        }
        // 0x02677330: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_91, ????);     
        label_118:
        // 0x02677334: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677338: MOV x0, x25                | X0 = val_91;//m1                        
        // 0x0267733C: BL #0x20ce7bc              | X0 = val_91.get_fieldOfView();          
        float val_92 = val_115.fieldOfView;
        // 0x02677340: MOV v4.16b, v0.16b         | V4 = val_92;//m1                        
        // 0x02677344: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02677348: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267734C: MOV v0.16b, v9.16b         | V0 = val_90.x;//m1                      
        // 0x02677350: MOV v1.16b, v10.16b        | V1 = val_90.y;//m1                      
        // 0x02677354: MOV v2.16b, v12.16b        | V2 = val_90.z;//m1                      
        // 0x02677358: MOV v3.16b, v11.16b        | V3 = val_90.w;//m1                      
        // 0x0267735C: BL #0x269b780              | X0 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = val_90.x, y = val_90.y, z = val_90.z, w = val_90.w}, d:  val_92);
        UnityEngine.Vector4 val_93 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = val_90.x, y = val_90.y, z = val_90.z, w = val_90.w}, d:  val_92);
        // 0x02677360: MOV v9.16b, v0.16b         | V9 = val_93.x;//m1                      
        // 0x02677364: MOV v10.16b, v1.16b        | V10 = val_93.y;//m1                     
        val_110 = val_93.y;
        // 0x02677368: MOV v11.16b, v2.16b        | V11 = val_93.z;//m1                     
        // 0x0267736C: MOV v12.16b, v3.16b        | V12 = val_93.w;//m1                     
        val_111 = val_93.w;
        // 0x02677370: CBNZ x26, #0x2677378       | if (this.motionBlurMaterial != null) goto label_119;
        if(val_114 != null)
        {
            goto label_119;
        }
        // 0x02677374: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_119:
        // 0x02677378: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
        // 0x0267737C: LDR x8, [x8, #0xdc0]       | X8 = (string**)(1152921509949761568)("_BlurDirectionPacked");
        // 0x02677380: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02677384: MOV x0, x26                | X0 = this.motionBlurMaterial;//m1       
        // 0x02677388: MOV v0.16b, v9.16b         | V0 = val_93.x;//m1                      
        // 0x0267738C: LDR x1, [x8]               | X1 = "_BlurDirectionPacked";            
        // 0x02677390: MOV v1.16b, v10.16b        | V1 = val_93.y;//m1                      
        // 0x02677394: MOV v2.16b, v11.16b        | V2 = val_93.z;//m1                      
        // 0x02677398: MOV v3.16b, v12.16b        | V3 = val_93.w;//m1                      
        // 0x0267739C: BL #0x1a79fa8              | this.motionBlurMaterial.SetVector(name:  "_BlurDirectionPacked", value:  new UnityEngine.Vector4() {x = val_93.x, y = val_110, z = val_93.z, w = val_111});
        val_114.SetVector(name:  "_BlurDirectionPacked", value:  new UnityEngine.Vector4() {x = val_93.x, y = val_110, z = val_93.z, w = val_111});
        // 0x026773A0: B #0x2677400               |  goto label_120;                        
        goto label_120;
        label_115:
        // 0x026773A4: SCVTF s0, w25              | S0 = (float)(source);                   
        float val_109 = (float)val_115;
        // 0x026773A8: LDR s2, [sp, #0x2c]        | S2 = val_73;                            
        float val_110 = val_73;
        // 0x026773AC: FMUL s0, s0, s3            | S0 = (source * val_121);                
        val_109 = val_109 * val_121;
        // 0x026773B0: LDR s3, [sp, #0x40]        | S3 = val_57;                            
        // 0x026773B4: FMOV s1, #1.00000000       | S1 = 1;                                 
        float val_111 = 1f;
        // 0x026773B8: FDIV s2, s2, s8            | S2 = (val_73 / val_76);                 
        val_110 = val_110 / val_117;
        // 0x026773BC: FMUL s0, s2, s0            | S0 = ((val_73 / val_76) * (source * val_121));
        val_109 = val_110 * val_109;
        // 0x026773C0: FSUB s1, s1, s3            | S1 = (1f - val_57);                     
        val_111 = val_111 - val_57;
        // 0x026773C4: FMUL s1, s1, s12           | S1 = ((1f - val_57) * this.rotationScale);
        val_111 = val_111 * val_111;
        // 0x026773C8: FMUL s8, s1, s0            | S8 = (((1f - val_57) * this.rotationScale) * ((val_73 / val_76) * (source * val_121)));
        val_117 = val_111 * val_109;
        // 0x026773CC: CBNZ x26, #0x26773d4       | if (this.motionBlurMaterial != null) goto label_121;
        if(val_114 != null)
        {
            goto label_121;
        }
        // 0x026773D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Mathf), ????);
        label_121:
        // 0x026773D4: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
        // 0x026773D8: LDR x8, [x8, #0xdc0]       | X8 = (string**)(1152921509949761568)("_BlurDirectionPacked");
        // 0x026773DC: LDR s3, [sp, #0x30]        | S3 = ((this.movementScale * val_80) * (source * 0.5f));
        // 0x026773E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026773E4: MOV x0, x26                | X0 = this.motionBlurMaterial;//m1       
        // 0x026773E8: LDR x1, [x8]               | X1 = "_BlurDirectionPacked";            
        // 0x026773EC: MOV v0.16b, v15.16b        | V0 = (this.rotationScale * ((val_63 / val_65) * (source * 0.75f)));//m1
        // 0x026773F0: MOV v1.16b, v14.16b        | V1 = ((val_57 * this.rotationScale) * ((val_68 / val_70) * (source * 0.75f)));//m1
        // 0x026773F4: MOV v2.16b, v8.16b         | V2 = (((1f - val_57) * this.rotationScale) * ((val_73 / val_76) * (source * val_121)));//m1
        // 0x026773F8: BL #0x1a79fa8              | this.motionBlurMaterial.SetVector(name:  "_BlurDirectionPacked", value:  new UnityEngine.Vector4() {x = val_119, y = val_112, z = val_117, w = val_86});
        val_114.SetVector(name:  "_BlurDirectionPacked", value:  new UnityEngine.Vector4() {x = val_119, y = val_112, z = val_117, w = val_86});
        // 0x026773FC: LDR s15, [sp, #0x3c]       | S15 = (val_3 / this);                   
        val_107 = val_107;
        label_120:
        // 0x02677400: LDRB w8, [x21, #0x20]      | W8 = this.preview; //P2                 
        // 0x02677404: CBNZ w8, #0x2677444        | if (this.preview == true) goto label_123;
        if(this.preview == true)
        {
            goto label_123;
        }
        // 0x02677408: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267740C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677410: BL #0x269115c              | X0 = UnityEngine.Time.get_frameCount(); 
        int val_94 = UnityEngine.Time.frameCount;
        // 0x02677414: LDR w8, [x21, #0x114]      | W8 = this.prevFrameCount; //P2          
        // 0x02677418: CMP w0, w8                 | STATE = COMPARE(val_94, this.prevFrameCount)
        // 0x0267741C: B.EQ #0x2677444            | if (val_94 == this.prevFrameCount) goto label_123;
        if(val_94 == this.prevFrameCount)
        {
            goto label_123;
        }
        // 0x02677420: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02677424: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677428: BL #0x269115c              | X0 = UnityEngine.Time.get_frameCount(); 
        int val_95 = UnityEngine.Time.frameCount;
        // 0x0267742C: LDR x8, [x21]              | X8 = typeof(CameraMotionBlur);          
        // 0x02677430: STR w0, [x21, #0x114]      | this.prevFrameCount = val_95;            //  dest_result_addr=1152921509949884468
        this.prevFrameCount = val_95;
        // 0x02677434: MOV x0, x21                | X0 = 1152921509949884192 (0x100000013E784720);//ML01
        // 0x02677438: LDR x9, [x8, #0x250]       | X9 = typeof(CameraMotionBlur).__il2cppRuntimeField_250;
        // 0x0267743C: LDR x1, [x8, #0x258]       | X1 = typeof(CameraMotionBlur).__il2cppRuntimeField_258;
        // 0x02677440: BLR x9                     | X0 = typeof(CameraMotionBlur).__il2cppRuntimeField_250();
        label_123:
        // 0x02677444: CBNZ x20, #0x267744c       | if (source != null) goto label_124;     
        if(source != null)
        {
            goto label_124;
        }
        // 0x02677448: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_124:
        // 0x0267744C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02677450: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x02677454: MOV x0, x20                | X0 = source;//m1                        
        // 0x02677458: BL #0x268eee8              | source.set_filterMode(value:  1);       
        source.filterMode = 1;
        // 0x0267745C: LDRB w8, [x21, #0x8c]      | W8 = this.showVelocity; //P2            
        // 0x02677460: CBZ w8, #0x26774d0         | if (this.showVelocity == false) goto label_125;
        if(this.showVelocity == false)
        {
            goto label_125;
        }
        // 0x02677464: LDR x20, [x21, #0x70]      | X20 = this.motionBlurMaterial; //P2     
        // 0x02677468: LDR s8, [x21, #0x90]       | S8 = this.showVelocityScale; //P2       
        val_122 = this.showVelocityScale;
        // 0x0267746C: CBNZ x20, #0x2677474       | if (this.motionBlurMaterial != null) goto label_126;
        if(this.motionBlurMaterial != null)
        {
            goto label_126;
        }
        // 0x02677470: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_126:
        // 0x02677474: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
        // 0x02677478: LDR x8, [x8, #0x9e8]       | X8 = (string**)(1152921509949765776)("_DisplayVelocityScale");
        // 0x0267747C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02677480: MOV x0, x20                | X0 = this.motionBlurMaterial;//m1       
        // 0x02677484: MOV v0.16b, v8.16b         | V0 = this.showVelocityScale;//m1        
        // 0x02677488: LDR x1, [x8]               | X1 = "_DisplayVelocityScale";           
        // 0x0267748C: BL #0x1a79ef8              | this.motionBlurMaterial.SetFloat(name:  "_DisplayVelocityScale", value:  val_122);
        this.motionBlurMaterial.SetFloat(name:  "_DisplayVelocityScale", value:  val_122);
        // 0x02677490: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02677494: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02677498: LDR x20, [x21, #0x70]      | X20 = this.motionBlurMaterial; //P2     
        // 0x0267749C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x026774A0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x026774A4: TBZ w8, #0, #0x26774b4     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_128;
        // 0x026774A8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x026774AC: CBNZ w8, #0x26774b4        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_128;
        // 0x026774B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_128:
        // 0x026774B4: LDR x2, [sp, #0x48]        | X2 = destination;                       
        val_123 = destination;
        // 0x026774B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        val_124 = 0;
        // 0x026774BC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026774C0: ORR w4, wzr, #1            | W4 = 1(0x1);                            
        // 0x026774C4: MOV x1, x22                | X1 = val_3;//m1                         
        val_125 = val_3;
        // 0x026774C8: MOV x3, x20                | X3 = this.motionBlurMaterial;//m1       
        val_126 = this.motionBlurMaterial;
        // 0x026774CC: B #0x26777d4               |  goto label_163;                        
        goto label_163;
        label_125:
        // 0x026774D0: LDR w8, [x21, #0x1c]       | W8 = this.filterType; //P2              
        // 0x026774D4: LDR w10, [sp, #0x44]       | W10 = 0x0;                              
        // 0x026774D8: CMP w8, #3                 | STATE = COMPARE(this.filterType, 0x3)   
        // 0x026774DC: CSET w9, ne                | W9 = this.filterType != 0x3 ? 1 : 0;    
        var val_96 = (this.filterType != 3) ? 1 : 0;
        // 0x026774E0: ORR w9, w10, w9            | W9 = (0 | this.filterType != 0x3 ? 1 : 0);
        val_96 = 0 | val_96;
        // 0x026774E4: TBZ w9, #0, #0x26775d4     | if (((0 | this.filterType != 0x3 ? 1 : 0) & 0x1) == 0) goto label_130;
        if((val_96 & 1) == 0)
        {
            goto label_130;
        }
        // 0x026774E8: CMP w8, #2                 | STATE = COMPARE(this.filterType, 0x2)   
        // 0x026774EC: CSET w9, eq                | W9 = this.filterType == 0x2 ? 1 : 0;    
        var val_97 = (this.filterType == 2) ? 1 : 0;
        // 0x026774F0: ORR w9, w10, w9            | W9 = (0 | this.filterType == 0x2 ? 1 : 0);
        val_97 = 0 | val_97;
        // 0x026774F4: CMP w9, #1                 | STATE = COMPARE((0 | this.filterType == 0x2 ? 1 : 0), 0x1)
        // 0x026774F8: ADRP x9, #0x363f000        | X9 = 56881152 (0x363F000);              
        // 0x026774FC: LDR x9, [x9, #0x3b0]       | X9 = 1152921504695345152;               
        // 0x02677500: B.NE #0x2677838            | if (val_97 != 0x1) goto label_131;      
        if(val_97 != 1)
        {
            goto label_131;
        }
        // 0x02677504: LDR x0, [x9]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x02677508: LDR x25, [x21, #0x70]      | X25 = this.motionBlurMaterial; //P2     
        // 0x0267750C: LDR s8, [x21, #0x44]       | S8 = this.softZDistance; //P2           
        // 0x02677510: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x02677514: TBZ w8, #0, #0x2677524     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_133;
        // 0x02677518: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x0267751C: CBNZ w8, #0x2677524        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_133;
        // 0x02677520: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_133:
        // 0x02677524: ADRP x8, #0x2ac3000        | X8 = 44838912 (0x2AC3000);              
        // 0x02677528: LDR s0, [x8, #0xd28]       | S0 = 0.00025;                           
        // 0x0267752C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02677530: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677534: MOV v1.16b, v8.16b         | V1 = this.softZDistance;//m1            
        // 0x02677538: BL #0x1a7d940              | X0 = UnityEngine.Mathf.Max(a:  0.00025f, b:  this.softZDistance);
        float val_98 = UnityEngine.Mathf.Max(a:  0.00025f, b:  this.softZDistance);
        // 0x0267753C: MOV v8.16b, v0.16b         | V8 = val_98;//m1                        
        val_122 = val_98;
        // 0x02677540: CBNZ x25, #0x2677548       | if (this.motionBlurMaterial != null) goto label_134;
        if(this.motionBlurMaterial != null)
        {
            goto label_134;
        }
        // 0x02677544: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_134:
        // 0x02677548: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
        // 0x0267754C: LDR x8, [x8, #0xd00]       | X8 = (string**)(1152921509949778176)("_SoftZDistance");
        // 0x02677550: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02677554: MOV x0, x25                | X0 = this.motionBlurMaterial;//m1       
        // 0x02677558: MOV v0.16b, v8.16b         | V0 = val_98;//m1                        
        // 0x0267755C: LDR x1, [x8]               | X1 = "_SoftZDistance";                  
        // 0x02677560: BL #0x1a79ef8              | this.motionBlurMaterial.SetFloat(name:  "_SoftZDistance", value:  val_122);
        this.motionBlurMaterial.SetFloat(name:  "_SoftZDistance", value:  val_122);
        // 0x02677564: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02677568: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x0267756C: LDR x25, [x21, #0x70]      | X25 = this.motionBlurMaterial; //P2     
        val_115 = this.motionBlurMaterial;
        // 0x02677570: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02677574: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02677578: TBZ w8, #0, #0x2677588     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_136;
        // 0x0267757C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02677580: CBNZ w8, #0x2677588        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_136;
        // 0x02677584: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_136:
        // 0x02677588: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267758C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02677590: ORR w4, wzr, #2            | W4 = 2(0x2);                            
        // 0x02677594: MOV x1, x22                | X1 = val_3;//m1                         
        // 0x02677598: MOV x2, x23                | X2 = val_9;//m1                         
        // 0x0267759C: MOV x3, x25                | X3 = this.motionBlurMaterial;//m1       
        // 0x026775A0: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_3, mat:  val_9, pass:  val_115);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_3, mat:  val_9, pass:  val_115);
        // 0x026775A4: LDR x3, [x21, #0x70]       | X3 = this.motionBlurMaterial; //P2      
        // 0x026775A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026775AC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026775B0: ORR w4, wzr, #3            | W4 = 3(0x3);                            
        // 0x026775B4: MOV x1, x23                | X1 = val_9;//m1                         
        // 0x026775B8: MOV x2, x24                | X2 = val_10;//m1                        
        // 0x026775BC: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_9, mat:  val_10, pass:  this.motionBlurMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_9, mat:  val_10, pass:  this.motionBlurMaterial);
        // 0x026775C0: LDR x3, [x21, #0x70]       | X3 = this.motionBlurMaterial; //P2      
        val_126 = this.motionBlurMaterial;
        // 0x026775C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        val_124 = 0;
        // 0x026775C8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026775CC: ORR w4, wzr, #4            | W4 = 4(0x4);                            
        // 0x026775D0: B #0x26777cc               |  goto label_157;                        
        goto label_157;
        label_130:
        // 0x026775D4: LDR x25, [x21, #0x78]      | X25 = this.dx11MotionBlurMaterial; //P2 
        // 0x026775D8: LDR s8, [x21, #0x3c]       | S8 = this.minVelocity; //P2             
        // 0x026775DC: CBNZ x25, #0x26775e4       | if (this.dx11MotionBlurMaterial != null) goto label_138;
        if(this.dx11MotionBlurMaterial != null)
        {
            goto label_138;
        }
        // 0x026775E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_138:
        // 0x026775E4: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
        // 0x026775E8: LDR x8, [x8, #0x1a0]       | X8 = (string**)(1152921509949613088)("_MinVelocity");
        // 0x026775EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026775F0: MOV x0, x25                | X0 = this.dx11MotionBlurMaterial;//m1   
        // 0x026775F4: MOV v0.16b, v8.16b         | V0 = this.minVelocity;//m1              
        // 0x026775F8: LDR x1, [x8]               | X1 = "_MinVelocity";                    
        // 0x026775FC: BL #0x1a79ef8              | this.dx11MotionBlurMaterial.SetFloat(name:  "_MinVelocity", value:  this.minVelocity);
        this.dx11MotionBlurMaterial.SetFloat(name:  "_MinVelocity", value:  this.minVelocity);
        // 0x02677600: LDR x25, [x21, #0x78]      | X25 = this.dx11MotionBlurMaterial; //P2 
        // 0x02677604: LDR s8, [x21, #0x40]       | S8 = this.velocityScale; //P2           
        // 0x02677608: CBNZ x25, #0x2677610       | if (this.dx11MotionBlurMaterial != null) goto label_139;
        if(this.dx11MotionBlurMaterial != null)
        {
            goto label_139;
        }
        // 0x0267760C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.dx11MotionBlurMaterial, ????);
        label_139:
        // 0x02677610: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
        // 0x02677614: LDR x8, [x8, #0x7c8]       | X8 = (string**)(1152921509949617280)("_VelocityScale");
        // 0x02677618: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0267761C: MOV x0, x25                | X0 = this.dx11MotionBlurMaterial;//m1   
        // 0x02677620: MOV v0.16b, v8.16b         | V0 = this.velocityScale;//m1            
        // 0x02677624: LDR x1, [x8]               | X1 = "_VelocityScale";                  
        // 0x02677628: BL #0x1a79ef8              | this.dx11MotionBlurMaterial.SetFloat(name:  "_VelocityScale", value:  this.velocityScale);
        this.dx11MotionBlurMaterial.SetFloat(name:  "_VelocityScale", value:  this.velocityScale);
        // 0x0267762C: LDR x25, [x21, #0x78]      | X25 = this.dx11MotionBlurMaterial; //P2 
        // 0x02677630: LDR s8, [x21, #0x88]       | S8 = this.jitter; //P2                  
        // 0x02677634: CBNZ x25, #0x267763c       | if (this.dx11MotionBlurMaterial != null) goto label_140;
        if(this.dx11MotionBlurMaterial != null)
        {
            goto label_140;
        }
        // 0x02677638: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.dx11MotionBlurMaterial, ????);
        label_140:
        // 0x0267763C: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
        // 0x02677640: LDR x8, [x8, #0xe38]       | X8 = (string**)(1152921509949621472)("_Jitter");
        // 0x02677644: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02677648: MOV x0, x25                | X0 = this.dx11MotionBlurMaterial;//m1   
        // 0x0267764C: MOV v0.16b, v8.16b         | V0 = this.jitter;//m1                   
        // 0x02677650: LDR x1, [x8]               | X1 = "_Jitter";                         
        // 0x02677654: BL #0x1a79ef8              | this.dx11MotionBlurMaterial.SetFloat(name:  "_Jitter", value:  this.jitter);
        this.dx11MotionBlurMaterial.SetFloat(name:  "_Jitter", value:  this.jitter);
        // 0x02677658: LDP x25, x26, [x21, #0x78] | X25 = this.dx11MotionBlurMaterial; //P2  X26 = this.noiseTexture; //P2  //  | 
        // 0x0267765C: CBNZ x25, #0x2677664       | if (this.dx11MotionBlurMaterial != null) goto label_141;
        if(this.dx11MotionBlurMaterial != null)
        {
            goto label_141;
        }
        // 0x02677660: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.dx11MotionBlurMaterial, ????);
        label_141:
        // 0x02677664: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
        // 0x02677668: LDR x8, [x8, #0xe30]       | X8 = (string**)(1152921509949629760)("_NoiseTex");
        // 0x0267766C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02677670: MOV x0, x25                | X0 = this.dx11MotionBlurMaterial;//m1   
        // 0x02677674: MOV x2, x26                | X2 = this.noiseTexture;//m1             
        // 0x02677678: LDR x1, [x8]               | X1 = "_NoiseTex";                       
        // 0x0267767C: BL #0x1a780c4              | this.dx11MotionBlurMaterial.SetTexture(name:  "_NoiseTex", value:  this.noiseTexture);
        this.dx11MotionBlurMaterial.SetTexture(name:  "_NoiseTex", value:  this.noiseTexture);
        // 0x02677680: LDR x25, [x21, #0x78]      | X25 = this.dx11MotionBlurMaterial; //P2 
        // 0x02677684: CBNZ x25, #0x267768c       | if (this.dx11MotionBlurMaterial != null) goto label_142;
        if(this.dx11MotionBlurMaterial != null)
        {
            goto label_142;
        }
        // 0x02677688: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.dx11MotionBlurMaterial, ????);
        label_142:
        // 0x0267768C: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x02677690: LDR x8, [x8, #0xf18]       | X8 = (string**)(1152921509949633952)("_VelTex");
        // 0x02677694: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02677698: MOV x0, x25                | X0 = this.dx11MotionBlurMaterial;//m1   
        // 0x0267769C: MOV x2, x22                | X2 = val_3;//m1                         
        // 0x026776A0: LDR x1, [x8]               | X1 = "_VelTex";                         
        // 0x026776A4: BL #0x1a780c4              | this.dx11MotionBlurMaterial.SetTexture(name:  "_VelTex", value:  val_3);
        this.dx11MotionBlurMaterial.SetTexture(name:  "_VelTex", value:  val_3);
        // 0x026776A8: LDR x25, [x21, #0x78]      | X25 = this.dx11MotionBlurMaterial; //P2 
        // 0x026776AC: CBNZ x25, #0x26776b4       | if (this.dx11MotionBlurMaterial != null) goto label_143;
        if(this.dx11MotionBlurMaterial != null)
        {
            goto label_143;
        }
        // 0x026776B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.dx11MotionBlurMaterial, ????);
        label_143:
        // 0x026776B4: ADRP x8, #0x35e4000        | X8 = 56508416 (0x35E4000);              
        // 0x026776B8: LDR x8, [x8, #0xe68]       | X8 = (string**)(1152921509949638144)("_NeighbourMaxTex");
        // 0x026776BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x026776C0: MOV x0, x25                | X0 = this.dx11MotionBlurMaterial;//m1   
        // 0x026776C4: MOV x2, x24                | X2 = val_10;//m1                        
        // 0x026776C8: LDR x1, [x8]               | X1 = "_NeighbourMaxTex";                
        // 0x026776CC: BL #0x1a780c4              | this.dx11MotionBlurMaterial.SetTexture(name:  "_NeighbourMaxTex", value:  val_10);
        this.dx11MotionBlurMaterial.SetTexture(name:  "_NeighbourMaxTex", value:  val_10);
        // 0x026776D0: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x026776D4: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x026776D8: LDR x25, [x21, #0x78]      | X25 = this.dx11MotionBlurMaterial; //P2 
        // 0x026776DC: LDR s8, [x21, #0x44]       | S8 = this.softZDistance; //P2           
        // 0x026776E0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x026776E4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x026776E8: TBZ w8, #0, #0x26776f8     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_145;
        // 0x026776EC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x026776F0: CBNZ w8, #0x26776f8        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_145;
        // 0x026776F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_145:
        // 0x026776F8: ADRP x8, #0x2ac3000        | X8 = 44838912 (0x2AC3000);              
        // 0x026776FC: LDR s0, [x8, #0xd28]       | S0 = 0.00025;                           
        // 0x02677700: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02677704: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677708: MOV v1.16b, v8.16b         | V1 = this.softZDistance;//m1            
        // 0x0267770C: BL #0x1a7d940              | X0 = UnityEngine.Mathf.Max(a:  0.00025f, b:  this.softZDistance);
        float val_99 = UnityEngine.Mathf.Max(a:  0.00025f, b:  this.softZDistance);
        // 0x02677710: MOV v8.16b, v0.16b         | V8 = val_99;//m1                        
        val_122 = val_99;
        // 0x02677714: CBNZ x25, #0x267771c       | if (this.dx11MotionBlurMaterial != null) goto label_146;
        if(this.dx11MotionBlurMaterial != null)
        {
            goto label_146;
        }
        // 0x02677718: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_146:
        // 0x0267771C: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
        // 0x02677720: LDR x8, [x8, #0xd00]       | X8 = (string**)(1152921509949778176)("_SoftZDistance");
        // 0x02677724: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02677728: MOV x0, x25                | X0 = this.dx11MotionBlurMaterial;//m1   
        // 0x0267772C: MOV v0.16b, v8.16b         | V0 = val_99;//m1                        
        // 0x02677730: LDR x1, [x8]               | X1 = "_SoftZDistance";                  
        // 0x02677734: BL #0x1a79ef8              | this.dx11MotionBlurMaterial.SetFloat(name:  "_SoftZDistance", value:  val_122);
        this.dx11MotionBlurMaterial.SetFloat(name:  "_SoftZDistance", value:  val_122);
        // 0x02677738: LDR x25, [x21, #0x78]      | X25 = this.dx11MotionBlurMaterial; //P2 
        // 0x0267773C: CBNZ x25, #0x2677744       | if (this.dx11MotionBlurMaterial != null) goto label_147;
        if(this.dx11MotionBlurMaterial != null)
        {
            goto label_147;
        }
        // 0x02677740: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.dx11MotionBlurMaterial, ????);
        label_147:
        // 0x02677744: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x02677748: LDR x8, [x8, #0x28]        | X8 = (string**)(1152921509949608880)("_MaxRadiusOrKInPaper");
        // 0x0267774C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02677750: MOV x0, x25                | X0 = this.dx11MotionBlurMaterial;//m1   
        // 0x02677754: MOV v0.16b, v15.16b        | V0 = (val_3 / this);//m1                
        // 0x02677758: LDR x1, [x8]               | X1 = "_MaxRadiusOrKInPaper";            
        // 0x0267775C: BL #0x1a79ef8              | this.dx11MotionBlurMaterial.SetFloat(name:  "_MaxRadiusOrKInPaper", value:  val_107);
        this.dx11MotionBlurMaterial.SetFloat(name:  "_MaxRadiusOrKInPaper", value:  val_107);
        // 0x02677760: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02677764: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02677768: LDR x25, [x21, #0x78]      | X25 = this.dx11MotionBlurMaterial; //P2 
        val_115 = this.dx11MotionBlurMaterial;
        // 0x0267776C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02677770: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02677774: TBZ w8, #0, #0x2677784     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_149;
        // 0x02677778: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x0267777C: CBNZ w8, #0x2677784        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_149;
        // 0x02677780: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_149:
        // 0x02677784: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02677788: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
        // 0x0267778C: MOV x1, x22                | X1 = val_3;//m1                         
        // 0x02677790: MOV x2, x23                | X2 = val_9;//m1                         
        // 0x02677794: MOV x3, x25                | X3 = this.dx11MotionBlurMaterial;//m1   
        // 0x02677798: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x0267779C: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_3, mat:  val_9, pass:  val_115);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_3, mat:  val_9, pass:  val_115);
        // 0x026777A0: LDR x3, [x21, #0x78]       | X3 = this.dx11MotionBlurMaterial; //P2  
        // 0x026777A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026777A8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026777AC: ORR w4, wzr, #1            | W4 = 1(0x1);                            
        // 0x026777B0: MOV x1, x23                | X1 = val_9;//m1                         
        // 0x026777B4: MOV x2, x24                | X2 = val_10;//m1                        
        // 0x026777B8: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_9, mat:  val_10, pass:  this.dx11MotionBlurMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_9, mat:  val_10, pass:  this.dx11MotionBlurMaterial);
        // 0x026777BC: LDR x3, [x21, #0x78]       | X3 = this.dx11MotionBlurMaterial; //P2  
        val_126 = this.dx11MotionBlurMaterial;
        // 0x026777C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        val_124 = 0;
        // 0x026777C4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026777C8: ORR w4, wzr, #2            | W4 = 2(0x2);                            
        label_157:
        // 0x026777CC: LDR x2, [sp, #0x48]        | X2 = destination;                       
        val_123 = destination;
        // 0x026777D0: MOV x1, x20                | X1 = source;//m1                        
        val_125 = source;
        label_163:
        // 0x026777D4: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  val_124 = 0, dest:  val_125 = source, mat:  val_123 = destination, pass:  val_126 = this.dx11MotionBlurMaterial);
        UnityEngine.Graphics.Blit(source:  val_124, dest:  val_125, mat:  val_123, pass:  val_126);
        // 0x026777D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026777DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026777E0: MOV x1, x22                | X1 = val_3;//m1                         
        // 0x026777E4: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x026777E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026777EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026777F0: MOV x1, x23                | X1 = val_9;//m1                         
        // 0x026777F4: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x026777F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026777FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02677800: MOV x1, x24                | X1 = val_10;//m1                        
        // 0x02677804: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        label_14:
        // 0x02677808: SUB sp, x29, #0x90         | SP = (1152921509949872176 - 144) = 1152921509949872032 (0x100000013E7817A0);
        // 0x0267780C: LDP x29, x30, [sp, #0x90]  | X29 = ; X30 = ;                          //  | 
        // 0x02677810: LDP x20, x19, [sp, #0x80]  | X20 = ; X19 = ;                          //  | 
        // 0x02677814: LDP x22, x21, [sp, #0x70]  | X22 = ; X21 = ;                          //  | 
        // 0x02677818: LDP x24, x23, [sp, #0x60]  | X24 = ; X23 = ;                          //  | 
        // 0x0267781C: LDP x26, x25, [sp, #0x50]  | X26 = ; X25 = ;                          //  | 
        // 0x02677820: LDP x28, x27, [sp, #0x40]  | X28 = ; X27 = ;                          //  | 
        // 0x02677824: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x02677828: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x0267782C: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x02677830: LDP d15, d14, [sp], #0xa0  | D15 = ; D14 = ;                          //  | 
        // 0x02677834: RET                        |  return;                                
        return;
        label_131:
        // 0x02677838: CBZ w8, #0x2677914         | if (this.filterType == 0) goto label_150;
        if(this.filterType == 0)
        {
            goto label_150;
        }
        // 0x0267783C: LDR x25, [x21, #0x70]      | X25 = this.motionBlurMaterial; //P2     
        // 0x02677840: CMP w8, #4                 | STATE = COMPARE(this.filterType, 0x4)   
        // 0x02677844: B.NE #0x2677954            | if (this.filterType != 0x4) goto label_151;
        if(this.filterType != 4)
        {
            goto label_151;
        }
        // 0x02677848: LDR x0, [x9]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x0267784C: LDR s8, [x21, #0x44]       | S8 = this.softZDistance; //P2           
        // 0x02677850: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x02677854: TBZ w8, #0, #0x2677864     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_153;
        // 0x02677858: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x0267785C: CBNZ w8, #0x2677864        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_153;
        // 0x02677860: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_153:
        // 0x02677864: ADRP x8, #0x2ac3000        | X8 = 44838912 (0x2AC3000);              
        // 0x02677868: LDR s0, [x8, #0xd28]       | S0 = 0.00025;                           
        // 0x0267786C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02677870: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677874: MOV v1.16b, v8.16b         | V1 = this.softZDistance;//m1            
        // 0x02677878: BL #0x1a7d940              | X0 = UnityEngine.Mathf.Max(a:  0.00025f, b:  this.softZDistance);
        float val_100 = UnityEngine.Mathf.Max(a:  0.00025f, b:  this.softZDistance);
        // 0x0267787C: MOV v8.16b, v0.16b         | V8 = val_100;//m1                       
        // 0x02677880: CBNZ x25, #0x2677888       | if (this.motionBlurMaterial != null) goto label_154;
        if(this.motionBlurMaterial != null)
        {
            goto label_154;
        }
        // 0x02677884: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_154:
        // 0x02677888: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
        // 0x0267788C: LDR x8, [x8, #0xd00]       | X8 = (string**)(1152921509949778176)("_SoftZDistance");
        // 0x02677890: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02677894: MOV x0, x25                | X0 = this.motionBlurMaterial;//m1       
        // 0x02677898: MOV v0.16b, v8.16b         | V0 = val_100;//m1                       
        // 0x0267789C: LDR x1, [x8]               | X1 = "_SoftZDistance";                  
        // 0x026778A0: BL #0x1a79ef8              | this.motionBlurMaterial.SetFloat(name:  "_SoftZDistance", value:  val_100);
        this.motionBlurMaterial.SetFloat(name:  "_SoftZDistance", value:  val_100);
        // 0x026778A4: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x026778A8: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x026778AC: LDR x25, [x21, #0x70]      | X25 = this.motionBlurMaterial; //P2     
        // 0x026778B0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x026778B4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x026778B8: TBZ w8, #0, #0x26778c8     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_156;
        // 0x026778BC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x026778C0: CBNZ w8, #0x26778c8        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_156;
        // 0x026778C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_156:
        // 0x026778C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026778CC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026778D0: ORR w4, wzr, #2            | W4 = 2(0x2);                            
        // 0x026778D4: MOV x1, x22                | X1 = val_3;//m1                         
        // 0x026778D8: MOV x2, x23                | X2 = val_9;//m1                         
        // 0x026778DC: MOV x3, x25                | X3 = this.motionBlurMaterial;//m1       
        // 0x026778E0: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_3, mat:  val_9, pass:  this.motionBlurMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_3, mat:  val_9, pass:  this.motionBlurMaterial);
        // 0x026778E4: LDR x3, [x21, #0x70]       | X3 = this.motionBlurMaterial; //P2      
        // 0x026778E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026778EC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026778F0: ORR w4, wzr, #3            | W4 = 3(0x3);                            
        // 0x026778F4: MOV x1, x23                | X1 = val_9;//m1                         
        // 0x026778F8: MOV x2, x24                | X2 = val_10;//m1                        
        // 0x026778FC: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_9, mat:  val_10, pass:  this.motionBlurMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_9, mat:  val_10, pass:  this.motionBlurMaterial);
        // 0x02677900: LDR x3, [x21, #0x70]       | X3 = this.motionBlurMaterial; //P2      
        // 0x02677904: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02677908: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x0267790C: ORR w4, wzr, #7            | W4 = 7(0x7);                            
        // 0x02677910: B #0x26777cc               |  goto label_157;                        
        goto label_157;
        label_150:
        // 0x02677914: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02677918: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x0267791C: LDR x21, [x21, #0x70]      | X21 = this.motionBlurMaterial; //P2     
        // 0x02677920: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02677924: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02677928: TBZ w8, #0, #0x2677938     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_159;
        // 0x0267792C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02677930: CBNZ w8, #0x2677938        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_159;
        // 0x02677934: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_159:
        // 0x02677938: LDR x2, [sp, #0x48]        | X2 = destination;                       
        // 0x0267793C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02677940: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02677944: ORR w4, wzr, #6            | W4 = 6(0x6);                            
        // 0x02677948: MOV x1, x20                | X1 = source;//m1                        
        // 0x0267794C: MOV x3, x21                | X3 = this.motionBlurMaterial;//m1       
        // 0x02677950: B #0x26777d4               |  goto label_163;                        
        goto label_163;
        label_151:
        // 0x02677954: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02677958: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x0267795C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02677960: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02677964: TBZ w8, #0, #0x2677974     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_162;
        // 0x02677968: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x0267796C: CBNZ w8, #0x2677974        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_162;
        // 0x02677970: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_162:
        // 0x02677974: LDR x2, [sp, #0x48]        | X2 = destination;                       
        // 0x02677978: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267797C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02677980: MOVZ w4, #0x5              | W4 = 5 (0x5);//ML01                     
        // 0x02677984: MOV x1, x20                | X1 = source;//m1                        
        // 0x02677988: MOV x3, x25                | X3 = this.motionBlurMaterial;//m1       
        // 0x0267798C: B #0x26777d4               |  goto label_163;                        
        goto label_163;
    
    }
    //
    // Offset in libil2cpp.so: 0x02677990 (40335760), len: 252  VirtAddr: 0x02677990 RVA: 0x02677990 token: 100663337 methodIndex: 24421 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Remember()
    {
        //
        // Disasemble & Code
        // 0x02677990: STP x20, x19, [sp, #-0x20]! | stack[1152921509950332752] = ???;  stack[1152921509950332760] = ???;  //  dest_result_addr=1152921509950332752 |  dest_result_addr=1152921509950332760
        // 0x02677994: STP x29, x30, [sp, #0x10]  | stack[1152921509950332768] = ???;  stack[1152921509950332776] = ???;  //  dest_result_addr=1152921509950332768 |  dest_result_addr=1152921509950332776
        // 0x02677998: ADD x29, sp, #0x10         | X29 = (1152921509950332752 + 16) = 1152921509950332768 (0x100000013E7F1F60);
        // 0x0267799C: MOV x19, x0                | X19 = 1152921509950344784 (0x100000013E7F4E50);//ML01
        // 0x026779A0: LDUR q0, [x19, #0xc4]      | 
        // 0x026779A4: ADD x8, x19, #0x104        | X8 = (this + 260) = 1152921509950345044 (0x100000013E7F4F54);
        // 0x026779A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026779AC: STR q0, [x8]               | mem[1152921509950345044] = ???;          //  dest_result_addr=1152921509950345044
        mem[1152921509950345044] = ???;
        // 0x026779B0: LDUR q0, [x19, #0xb4]      | 
        // 0x026779B4: LDUR q1, [x19, #0xa4]      | 
        // 0x026779B8: LDUR q2, [x19, #0x94]      | Q2 = this.currentViewProjMat; //P2      
        // 0x026779BC: STUR q0, [x19, #0xf4]      | mem[1152921509950345028] = ???;          //  dest_result_addr=1152921509950345028
        mem[1152921509950345028] = ???;
        // 0x026779C0: STUR q1, [x19, #0xe4]      | mem[1152921509950345012] = ???;          //  dest_result_addr=1152921509950345012
        mem[1152921509950345012] = ???;
        // 0x026779C4: STUR q2, [x19, #0xd4]      | this.prevViewProjMat = this.currentViewProjMat;  //  dest_result_addr=1152921509950344996
        this.prevViewProjMat = this.currentViewProjMat;
        // 0x026779C8: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_1 = this.transform;
        // 0x026779CC: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x026779D0: CBNZ x20, #0x26779d8       | if (val_1 != null) goto label_0;        
        if(val_1 != null)
        {
            goto label_0;
        }
        // 0x026779D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_0:
        // 0x026779D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026779DC: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x026779E0: BL #0x2693ec0              | X0 = val_1.get_forward();               
        UnityEngine.Vector3 val_2 = val_1.forward;
        // 0x026779E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026779E8: MOV x0, x19                | X0 = 1152921509950344784 (0x100000013E7F4E50);//ML01
        // 0x026779EC: STR s0, [x19, #0x11c]      | this.prevFrameForward = val_2;           //  dest_result_addr=1152921509950345068
        this.prevFrameForward = val_2;
        // 0x026779F0: STR s1, [x19, #0x120]      | mem[1152921509950345072] = val_2.y;      //  dest_result_addr=1152921509950345072
        mem[1152921509950345072] = val_2.y;
        // 0x026779F4: STR s2, [x19, #0x124]      | mem[1152921509950345076] = val_2.z;      //  dest_result_addr=1152921509950345076
        mem[1152921509950345076] = val_2.z;
        // 0x026779F8: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_3 = this.transform;
        // 0x026779FC: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x02677A00: CBNZ x20, #0x2677a08       | if (val_3 != null) goto label_1;        
        if(val_3 != null)
        {
            goto label_1;
        }
        // 0x02677A04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_1:
        // 0x02677A08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677A0C: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x02677A10: BL #0x2693a10              | X0 = val_3.get_right();                 
        UnityEngine.Vector3 val_4 = val_3.right;
        // 0x02677A14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677A18: MOV x0, x19                | X0 = 1152921509950344784 (0x100000013E7F4E50);//ML01
        // 0x02677A1C: STR s0, [x19, #0x128]      | this.prevFrameRight = val_4;             //  dest_result_addr=1152921509950345080
        this.prevFrameRight = val_4;
        // 0x02677A20: STR s1, [x19, #0x12c]      | mem[1152921509950345084] = val_4.y;      //  dest_result_addr=1152921509950345084
        mem[1152921509950345084] = val_4.y;
        // 0x02677A24: STR s2, [x19, #0x130]      | mem[1152921509950345088] = val_4.z;      //  dest_result_addr=1152921509950345088
        mem[1152921509950345088] = val_4.z;
        // 0x02677A28: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_5 = this.transform;
        // 0x02677A2C: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x02677A30: CBNZ x20, #0x2677a38       | if (val_5 != null) goto label_2;        
        if(val_5 != null)
        {
            goto label_2;
        }
        // 0x02677A34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_2:
        // 0x02677A38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677A3C: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x02677A40: BL #0x2693c68              | X0 = val_5.get_up();                    
        UnityEngine.Vector3 val_6 = val_5.up;
        // 0x02677A44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677A48: MOV x0, x19                | X0 = 1152921509950344784 (0x100000013E7F4E50);//ML01
        // 0x02677A4C: STR s0, [x19, #0x134]      | this.prevFrameUp = val_6;                //  dest_result_addr=1152921509950345092
        this.prevFrameUp = val_6;
        // 0x02677A50: STR s1, [x19, #0x138]      | mem[1152921509950345096] = val_6.y;      //  dest_result_addr=1152921509950345096
        mem[1152921509950345096] = val_6.y;
        // 0x02677A54: STR s2, [x19, #0x13c]      | mem[1152921509950345100] = val_6.z;      //  dest_result_addr=1152921509950345100
        mem[1152921509950345100] = val_6.z;
        // 0x02677A58: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_7 = this.transform;
        // 0x02677A5C: MOV x20, x0                | X20 = val_7;//m1                        
        // 0x02677A60: CBNZ x20, #0x2677a68       | if (val_7 != null) goto label_3;        
        if(val_7 != null)
        {
            goto label_3;
        }
        // 0x02677A64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_3:
        // 0x02677A68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677A6C: MOV x0, x20                | X0 = val_7;//m1                         
        // 0x02677A70: BL #0x2693510              | X0 = val_7.get_position();              
        UnityEngine.Vector3 val_8 = val_7.position;
        // 0x02677A74: STR s2, [x19, #0x148]      | mem[1152921509950345112] = val_8.z;      //  dest_result_addr=1152921509950345112
        mem[1152921509950345112] = val_8.z;
        // 0x02677A78: STR s0, [x19, #0x140]      | this.prevFramePos = val_8;               //  dest_result_addr=1152921509950345104
        this.prevFramePos = val_8;
        // 0x02677A7C: STR s1, [x19, #0x144]      | mem[1152921509950345108] = val_8.y;      //  dest_result_addr=1152921509950345108
        mem[1152921509950345108] = val_8.y;
        // 0x02677A80: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02677A84: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x02677A88: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02677A8C (40336012), len: 1284  VirtAddr: 0x02677A8C RVA: 0x02677A8C token: 100663338 methodIndex: 24422 delegateWrapperIndex: 0 methodInvoker: 0
    public override UnityEngine.Camera GetTmpCam()
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.GameObject val_28;
        // 0x02677A8C: STP d11, d10, [sp, #-0x60]! | stack[1152921509950585168] = ???;  stack[1152921509950585176] = ???;  //  dest_result_addr=1152921509950585168 |  dest_result_addr=1152921509950585176
        // 0x02677A90: STP d9, d8, [sp, #0x10]    | stack[1152921509950585184] = ???;  stack[1152921509950585192] = ???;  //  dest_result_addr=1152921509950585184 |  dest_result_addr=1152921509950585192
        // 0x02677A94: STP x24, x23, [sp, #0x20]  | stack[1152921509950585200] = ???;  stack[1152921509950585208] = ???;  //  dest_result_addr=1152921509950585200 |  dest_result_addr=1152921509950585208
        // 0x02677A98: STP x22, x21, [sp, #0x30]  | stack[1152921509950585216] = ???;  stack[1152921509950585224] = ???;  //  dest_result_addr=1152921509950585216 |  dest_result_addr=1152921509950585224
        // 0x02677A9C: STP x20, x19, [sp, #0x40]  | stack[1152921509950585232] = ???;  stack[1152921509950585240] = ???;  //  dest_result_addr=1152921509950585232 |  dest_result_addr=1152921509950585240
        // 0x02677AA0: STP x29, x30, [sp, #0x50]  | stack[1152921509950585248] = ???;  stack[1152921509950585256] = ???;  //  dest_result_addr=1152921509950585248 |  dest_result_addr=1152921509950585256
        // 0x02677AA4: ADD x29, sp, #0x50         | X29 = (1152921509950585168 + 80) = 1152921509950585248 (0x100000013E82F9A0);
        // 0x02677AA8: ADRP x20, #0x3740000       | X20 = 57933824 (0x3740000);             
        // 0x02677AAC: LDRB w8, [x20, #0xe59]     | W8 = (bool)static_value_03740E59;       
        // 0x02677AB0: MOV x19, x0                | X19 = 1152921509950597264 (0x100000013E832890);//ML01
        // 0x02677AB4: TBNZ w8, #0, #0x2677ad0    | if (static_value_03740E59 == true) goto label_0;
        // 0x02677AB8: ADRP x8, #0x3681000        | X8 = 57151488 (0x3681000);              
        // 0x02677ABC: LDR x8, [x8, #0x700]       | X8 = 0x2B90230;                         
        // 0x02677AC0: LDR w0, [x8]               | W0 = 0x1750;                            
        // 0x02677AC4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1750, ????);     
        // 0x02677AC8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02677ACC: STRB w8, [x20, #0xe59]     | static_value_03740E59 = true;            //  dest_result_addr=57937497
        label_0:
        // 0x02677AD0: ADRP x21, #0x35fe000       | X21 = 56614912 (0x35FE000);             
        // 0x02677AD4: LDR x21, [x21, #0x810]     | X21 = 1152921504697475072;              
        // 0x02677AD8: LDR x20, [x19, #0x50]      | X20 = this.tmpCam; //P2                 
        // 0x02677ADC: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02677AE0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02677AE4: TBZ w8, #0, #0x2677af4     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x02677AE8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02677AEC: CBNZ w8, #0x2677af4        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x02677AF0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x02677AF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02677AF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02677AFC: MOV x1, x20                | X1 = this.tmpCam;//m1                   
        // 0x02677B00: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02677B04: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  this.tmpCam);
        bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  this.tmpCam);
        // 0x02677B08: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x02677B0C: TBZ w8, #0, #0x2677cc0     | if ((val_1 & 1) == false) goto label_3; 
        if(val_2 == false)
        {
            goto label_3;
        }
        // 0x02677B10: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x02677B14: LDR x8, [x8, #0x338]       | X8 = 1152921509941328016;               
        // 0x02677B18: MOV x0, x19                | X0 = 1152921509950597264 (0x100000013E832890);//ML01
        // 0x02677B1C: LDR x1, [x8]               | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x02677B20: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_3 = this.GetComponent<UnityEngine.Camera>();
        // 0x02677B24: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x02677B28: CBNZ x20, #0x2677b30       | if (val_3 != null) goto label_4;        
        if(val_3 != null)
        {
            goto label_4;
        }
        // 0x02677B2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_4:
        // 0x02677B30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677B34: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x02677B38: BL #0x1b759fc              | X0 = val_3.get_name();                  
        string val_4 = val_3.name;
        // 0x02677B3C: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x02677B40: LDR x8, [x8, #0x300]       | X8 = 1152921504721223680;               
        // 0x02677B44: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x02677B48: LDR x8, [x8]               | X8 = typeof(Boo.Lang.Runtime.RuntimeServices);
        // 0x02677B4C: LDRB w9, [x8, #0x10a]      | W9 = Boo.Lang.Runtime.RuntimeServices.__il2cppRuntimeField_10A;
        // 0x02677B50: TBZ w9, #0, #0x2677b64     | if (Boo.Lang.Runtime.RuntimeServices.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x02677B54: LDR w9, [x8, #0xbc]        | W9 = Boo.Lang.Runtime.RuntimeServices.__il2cppRuntimeField_cctor_finished;
        // 0x02677B58: CBNZ w9, #0x2677b64        | if (Boo.Lang.Runtime.RuntimeServices.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x02677B5C: MOV x0, x8                 | X0 = 1152921504721223680 (0x1000000006D14000);//ML01
        // 0x02677B60: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Boo.Lang.Runtime.RuntimeServices), ????);
        label_6:
        // 0x02677B64: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
        // 0x02677B68: LDR x8, [x8, #0x160]       | X8 = (string**)(1152921509950461456)("_");
        // 0x02677B6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02677B70: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02677B74: MOV x2, x20                | X2 = val_4;//m1                         
        // 0x02677B78: LDR x1, [x8]               | X1 = "_";                               
        // 0x02677B7C: BL #0x275d858              | X0 = Boo.Lang.Runtime.RuntimeServices.op_Addition(lhs:  0, rhs:  "_");
        string val_5 = Boo.Lang.Runtime.RuntimeServices.op_Addition(lhs:  0, rhs:  "_");
        // 0x02677B80: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
        // 0x02677B84: LDR x8, [x8, #0x1c0]       | X8 = (string**)(1152921509950465632)("_MotionBlurTmpCam");
        // 0x02677B88: MOV x1, x0                 | X1 = val_5;//m1                         
        // 0x02677B8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02677B90: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02677B94: LDR x2, [x8]               | X2 = "_MotionBlurTmpCam";               
        // 0x02677B98: BL #0x275d858              | X0 = Boo.Lang.Runtime.RuntimeServices.op_Addition(lhs:  0, rhs:  val_5);
        string val_6 = Boo.Lang.Runtime.RuntimeServices.op_Addition(lhs:  0, rhs:  val_5);
        // 0x02677B9C: MOV x20, x0                | X20 = val_6;//m1                        
        // 0x02677BA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02677BA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02677BA8: MOV x1, x20                | X1 = val_6;//m1                         
        // 0x02677BAC: BL #0x1a634b4              | X0 = UnityEngine.GameObject.Find(name:  0);
        UnityEngine.GameObject val_7 = UnityEngine.GameObject.Find(name:  0);
        // 0x02677BB0: LDR x8, [x21]              | X8 = typeof(UnityEngine.Object);        
        // 0x02677BB4: MOV x22, x0                | X22 = val_7;//m1                        
        val_28 = val_7;
        // 0x02677BB8: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02677BBC: TBZ w9, #0, #0x2677bd0     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x02677BC0: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02677BC4: CBNZ w9, #0x2677bd0        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x02677BC8: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x02677BCC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_8:
        // 0x02677BD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02677BD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677BD8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02677BDC: MOV x2, x22                | X2 = val_7;//m1                         
        // 0x02677BE0: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  0);
        bool val_8 = UnityEngine.Object.op_Equality(x:  0, y:  0);
        // 0x02677BE4: TBZ w0, #0, #0x2677cb8     | if (val_8 == false) goto label_9;       
        if(val_8 == false)
        {
            goto label_9;
        }
        // 0x02677BE8: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
        // 0x02677BEC: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
        // 0x02677BF0: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
        // 0x02677BF4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
        // 0x02677BF8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
        // 0x02677BFC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x02677C00: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
        // 0x02677C04: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
        // 0x02677C08: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
        // 0x02677C0C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
        // 0x02677C10: ADRP x9, #0x365f000        | X9 = 57012224 (0x365F000);              
        // 0x02677C14: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
        // 0x02677C18: LDR x8, [x8]               | X8 = typeof(System.Type);               
        // 0x02677C1C: LDR x9, [x9, #0x520]       | X9 = 1152921504691671040;               
        // 0x02677C20: LDR x22, [x9]              | X22 = typeof(UnityEngine.Camera);       
        // 0x02677C24: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
        // 0x02677C28: TBZ w9, #0, #0x2677c3c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x02677C2C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
        // 0x02677C30: CBNZ w9, #0x2677c3c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x02677C34: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
        // 0x02677C38: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
        label_11:
        // 0x02677C3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02677C40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02677C44: MOV x1, x22                | X1 = 1152921504691671040 (0x10000000050E5000);//ML01
        // 0x02677C48: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
        System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
        // 0x02677C4C: MOV x22, x0                | X22 = val_9;//m1                        
        // 0x02677C50: CBNZ x21, #0x2677c58       | if ( != null) goto label_12;            
        if(null != null)
        {
            goto label_12;
        }
        // 0x02677C54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_12:
        // 0x02677C58: CBZ x22, #0x2677c7c        | if (val_9 == null) goto label_14;       
        if(val_9 == null)
        {
            goto label_14;
        }
        // 0x02677C5C: LDR x8, [x21]              | X8 = ;                                  
        // 0x02677C60: MOV x0, x22                | X0 = val_9;//m1                         
        // 0x02677C64: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x02677C68: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
        // 0x02677C6C: CBNZ x0, #0x2677c7c        | if (val_9 != null) goto label_14;       
        if(val_9 != null)
        {
            goto label_14;
        }
        // 0x02677C70: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_9, ????);      
        // 0x02677C74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677C78: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
        label_14:
        // 0x02677C7C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
        // 0x02677C80: CBNZ w8, #0x2677c90        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_15;
        // 0x02677C84: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_9, ????);      
        // 0x02677C88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677C8C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
        label_15:
        // 0x02677C90: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_9;  //  dest_result_addr=1152921504987155088
        typeof(System.Type[]).__il2cppRuntimeField_20 = val_9;
        // 0x02677C94: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x02677C98: LDR x8, [x8, #0x30]        | X8 = 1152921504692629504;               
        // 0x02677C9C: LDR x0, [x8]               | X0 = typeof(UnityEngine.GameObject);    
        UnityEngine.GameObject val_10 = null;
        // 0x02677CA0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.GameObject), ????);
        // 0x02677CA4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02677CA8: MOV x1, x20                | X1 = val_6;//m1                         
        // 0x02677CAC: MOV x2, x21                | X2 = 1152921504987155056 (0x1000000016AB0A70);//ML01
        // 0x02677CB0: MOV x22, x0                | X22 = 1152921504692629504 (0x10000000051CF000);//ML01
        val_28 = val_10;
        // 0x02677CB4: BL #0x1a624e4              | .ctor(name:  val_6, components:  null); 
        val_10 = new UnityEngine.GameObject(name:  val_6, components:  null);
        label_9:
        // 0x02677CB8: STR x22, [x19, #0x50]      | this.tmpCam = typeof(UnityEngine.GameObject);  //  dest_result_addr=1152921509950597344
        this.tmpCam = val_28;
        // 0x02677CBC: B #0x2677cc4               |  goto label_16;                         
        goto label_16;
        label_3:
        // 0x02677CC0: LDR x22, [x19, #0x50]      | X22 = this.tmpCam; //P2                 
        val_28 = this.tmpCam;
        label_16:
        // 0x02677CC4: CBNZ x22, #0x2677ccc       | if (this.tmpCam != null) goto label_17; 
        if(val_28 != null)
        {
            goto label_17;
        }
        // 0x02677CC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_17:
        // 0x02677CCC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02677CD0: MOVZ w1, #0x34             | W1 = 52 (0x34);//ML01                   
        // 0x02677CD4: MOV x0, x22                | X0 = this.tmpCam;//m1                   
        // 0x02677CD8: BL #0x1b77b04              | this.tmpCam.set_hideFlags(value:  52);  
        val_28.hideFlags = 52;
        // 0x02677CDC: LDR x20, [x19, #0x50]      | X20 = this.tmpCam; //P2                 
        // 0x02677CE0: CBNZ x20, #0x2677ce8       | if (this.tmpCam != null) goto label_18; 
        if(this.tmpCam != null)
        {
            goto label_18;
        }
        // 0x02677CE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.tmpCam, ????);
        label_18:
        // 0x02677CE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677CEC: MOV x0, x20                | X0 = this.tmpCam;//m1                   
        // 0x02677CF0: BL #0x1a62c1c              | X0 = this.tmpCam.get_transform();       
        UnityEngine.Transform val_11 = this.tmpCam.transform;
        // 0x02677CF4: ADRP x22, #0x3668000       | X22 = 57049088 (0x3668000);             
        // 0x02677CF8: LDR x22, [x22, #0x338]     | X22 = 1152921509941328016;              
        // 0x02677CFC: MOV x20, x0                | X20 = val_11;//m1                       
        // 0x02677D00: MOV x0, x19                | X0 = 1152921509950597264 (0x100000013E832890);//ML01
        // 0x02677D04: LDR x1, [x22]              | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x02677D08: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_12 = this.GetComponent<UnityEngine.Camera>();
        // 0x02677D0C: MOV x21, x0                | X21 = val_12;//m1                       
        // 0x02677D10: CBNZ x21, #0x2677d18       | if (val_12 != null) goto label_19;      
        if(val_12 != null)
        {
            goto label_19;
        }
        // 0x02677D14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_19:
        // 0x02677D18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677D1C: MOV x0, x21                | X0 = val_12;//m1                        
        // 0x02677D20: BL #0x20d5094              | X0 = val_12.get_transform();            
        UnityEngine.Transform val_13 = val_12.transform;
        // 0x02677D24: MOV x21, x0                | X21 = val_13;//m1                       
        // 0x02677D28: CBNZ x21, #0x2677d30       | if (val_13 != null) goto label_20;      
        if(val_13 != null)
        {
            goto label_20;
        }
        // 0x02677D2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_20:
        // 0x02677D30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677D34: MOV x0, x21                | X0 = val_13;//m1                        
        // 0x02677D38: BL #0x2693510              | X0 = val_13.get_position();             
        UnityEngine.Vector3 val_14 = val_13.position;
        // 0x02677D3C: MOV v8.16b, v0.16b         | V8 = val_14.x;//m1                      
        // 0x02677D40: MOV v9.16b, v1.16b         | V9 = val_14.y;//m1                      
        // 0x02677D44: MOV v10.16b, v2.16b        | V10 = val_14.z;//m1                     
        // 0x02677D48: CBNZ x20, #0x2677d50       | if (val_11 != null) goto label_21;      
        if(val_11 != null)
        {
            goto label_21;
        }
        // 0x02677D4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_21:
        // 0x02677D50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677D54: MOV x0, x20                | X0 = val_11;//m1                        
        // 0x02677D58: MOV v0.16b, v8.16b         | V0 = val_14.x;//m1                      
        // 0x02677D5C: MOV v1.16b, v9.16b         | V1 = val_14.y;//m1                      
        // 0x02677D60: MOV v2.16b, v10.16b        | V2 = val_14.z;//m1                      
        // 0x02677D64: BL #0x26935b8              | val_11.set_position(value:  new UnityEngine.Vector3() {x = val_14.x, y = val_14.y, z = val_14.z});
        val_11.position = new UnityEngine.Vector3() {x = val_14.x, y = val_14.y, z = val_14.z};
        // 0x02677D68: LDR x20, [x19, #0x50]      | X20 = this.tmpCam; //P2                 
        // 0x02677D6C: CBNZ x20, #0x2677d74       | if (this.tmpCam != null) goto label_22; 
        if(this.tmpCam != null)
        {
            goto label_22;
        }
        // 0x02677D70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_22:
        // 0x02677D74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677D78: MOV x0, x20                | X0 = this.tmpCam;//m1                   
        // 0x02677D7C: BL #0x1a62c1c              | X0 = this.tmpCam.get_transform();       
        UnityEngine.Transform val_15 = this.tmpCam.transform;
        // 0x02677D80: LDR x1, [x22]              | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x02677D84: MOV x20, x0                | X20 = val_15;//m1                       
        // 0x02677D88: MOV x0, x19                | X0 = 1152921509950597264 (0x100000013E832890);//ML01
        // 0x02677D8C: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_16 = this.GetComponent<UnityEngine.Camera>();
        // 0x02677D90: MOV x21, x0                | X21 = val_16;//m1                       
        // 0x02677D94: CBNZ x21, #0x2677d9c       | if (val_16 != null) goto label_23;      
        if(val_16 != null)
        {
            goto label_23;
        }
        // 0x02677D98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_23:
        // 0x02677D9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677DA0: MOV x0, x21                | X0 = val_16;//m1                        
        // 0x02677DA4: BL #0x20d5094              | X0 = val_16.get_transform();            
        UnityEngine.Transform val_17 = val_16.transform;
        // 0x02677DA8: MOV x21, x0                | X21 = val_17;//m1                       
        // 0x02677DAC: CBNZ x21, #0x2677db4       | if (val_17 != null) goto label_24;      
        if(val_17 != null)
        {
            goto label_24;
        }
        // 0x02677DB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_24:
        // 0x02677DB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677DB8: MOV x0, x21                | X0 = val_17;//m1                        
        // 0x02677DBC: BL #0x26937d8              | X0 = val_17.get_rotation();             
        UnityEngine.Quaternion val_18 = val_17.rotation;
        // 0x02677DC0: MOV v8.16b, v0.16b         | V8 = val_18.x;//m1                      
        // 0x02677DC4: MOV v9.16b, v1.16b         | V9 = val_18.y;//m1                      
        // 0x02677DC8: MOV v10.16b, v2.16b        | V10 = val_18.z;//m1                     
        // 0x02677DCC: MOV v11.16b, v3.16b        | V11 = val_18.w;//m1                     
        // 0x02677DD0: CBNZ x20, #0x2677dd8       | if (val_15 != null) goto label_25;      
        if(val_15 != null)
        {
            goto label_25;
        }
        // 0x02677DD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_25:
        // 0x02677DD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677DDC: MOV x0, x20                | X0 = val_15;//m1                        
        // 0x02677DE0: MOV v0.16b, v8.16b         | V0 = val_18.x;//m1                      
        // 0x02677DE4: MOV v1.16b, v9.16b         | V1 = val_18.y;//m1                      
        // 0x02677DE8: MOV v2.16b, v10.16b        | V2 = val_18.z;//m1                      
        // 0x02677DEC: MOV v3.16b, v11.16b        | V3 = val_18.w;//m1                      
        // 0x02677DF0: BL #0x26938b0              | val_15.set_rotation(value:  new UnityEngine.Quaternion() {x = val_18.x, y = val_18.y, z = val_18.z, w = val_18.w});
        val_15.rotation = new UnityEngine.Quaternion() {x = val_18.x, y = val_18.y, z = val_18.z, w = val_18.w};
        // 0x02677DF4: LDR x20, [x19, #0x50]      | X20 = this.tmpCam; //P2                 
        // 0x02677DF8: CBNZ x20, #0x2677e00       | if (this.tmpCam != null) goto label_26; 
        if(this.tmpCam != null)
        {
            goto label_26;
        }
        // 0x02677DFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_26:
        // 0x02677E00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677E04: MOV x0, x20                | X0 = this.tmpCam;//m1                   
        // 0x02677E08: BL #0x1a62c1c              | X0 = this.tmpCam.get_transform();       
        UnityEngine.Transform val_19 = this.tmpCam.transform;
        // 0x02677E0C: LDR x1, [x22]              | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x02677E10: MOV x20, x0                | X20 = val_19;//m1                       
        // 0x02677E14: MOV x0, x19                | X0 = 1152921509950597264 (0x100000013E832890);//ML01
        // 0x02677E18: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_20 = this.GetComponent<UnityEngine.Camera>();
        // 0x02677E1C: MOV x21, x0                | X21 = val_20;//m1                       
        // 0x02677E20: CBNZ x21, #0x2677e28       | if (val_20 != null) goto label_27;      
        if(val_20 != null)
        {
            goto label_27;
        }
        // 0x02677E24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_27:
        // 0x02677E28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677E2C: MOV x0, x21                | X0 = val_20;//m1                        
        // 0x02677E30: BL #0x20d5094              | X0 = val_20.get_transform();            
        UnityEngine.Transform val_21 = val_20.transform;
        // 0x02677E34: MOV x21, x0                | X21 = val_21;//m1                       
        // 0x02677E38: CBNZ x21, #0x2677e40       | if (val_21 != null) goto label_28;      
        if(val_21 != null)
        {
            goto label_28;
        }
        // 0x02677E3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_28:
        // 0x02677E40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677E44: MOV x0, x21                | X0 = val_21;//m1                        
        // 0x02677E48: BL #0x26942b4              | X0 = val_21.get_localScale();           
        UnityEngine.Vector3 val_22 = val_21.localScale;
        // 0x02677E4C: MOV v8.16b, v0.16b         | V8 = val_22.x;//m1                      
        // 0x02677E50: MOV v9.16b, v1.16b         | V9 = val_22.y;//m1                      
        // 0x02677E54: MOV v10.16b, v2.16b        | V10 = val_22.z;//m1                     
        // 0x02677E58: CBNZ x20, #0x2677e60       | if (val_19 != null) goto label_29;      
        if(val_19 != null)
        {
            goto label_29;
        }
        // 0x02677E5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_29:
        // 0x02677E60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677E64: MOV x0, x20                | X0 = val_19;//m1                        
        // 0x02677E68: MOV v0.16b, v8.16b         | V0 = val_22.x;//m1                      
        // 0x02677E6C: MOV v1.16b, v9.16b         | V1 = val_22.y;//m1                      
        // 0x02677E70: MOV v2.16b, v10.16b        | V2 = val_22.z;//m1                      
        // 0x02677E74: BL #0x269435c              | val_19.set_localScale(value:  new UnityEngine.Vector3() {x = val_22.x, y = val_22.y, z = val_22.z});
        val_19.localScale = new UnityEngine.Vector3() {x = val_22.x, y = val_22.y, z = val_22.z};
        // 0x02677E78: LDR x20, [x19, #0x50]      | X20 = this.tmpCam; //P2                 
        // 0x02677E7C: CBNZ x20, #0x2677e84       | if (this.tmpCam != null) goto label_30; 
        if(this.tmpCam != null)
        {
            goto label_30;
        }
        // 0x02677E80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_30:
        // 0x02677E84: ADRP x23, #0x35e7000       | X23 = 56520704 (0x35E7000);             
        // 0x02677E88: LDR x23, [x23, #0x6e8]     | X23 = 1152921509950535376;              
        // 0x02677E8C: MOV x0, x20                | X0 = this.tmpCam;//m1                   
        // 0x02677E90: LDR x1, [x23]              | X1 = public UnityEngine.Camera UnityEngine.GameObject::GetComponent<UnityEngine.Camera>();
        // 0x02677E94: BL #0x23d5abc              | X0 = this.tmpCam.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_23 = this.tmpCam.GetComponent<UnityEngine.Camera>();
        // 0x02677E98: LDR x1, [x22]              | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x02677E9C: MOV x20, x0                | X20 = val_23;//m1                       
        // 0x02677EA0: MOV x0, x19                | X0 = 1152921509950597264 (0x100000013E832890);//ML01
        // 0x02677EA4: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_24 = this.GetComponent<UnityEngine.Camera>();
        // 0x02677EA8: MOV x21, x0                | X21 = val_24;//m1                       
        // 0x02677EAC: CBNZ x20, #0x2677eb4       | if (val_23 != null) goto label_31;      
        if(val_23 != null)
        {
            goto label_31;
        }
        // 0x02677EB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_31:
        // 0x02677EB4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02677EB8: MOV x0, x20                | X0 = val_23;//m1                        
        // 0x02677EBC: MOV x1, x21                | X1 = val_24;//m1                        
        // 0x02677EC0: BL #0x20d2a98              | val_23.CopyFrom(other:  val_24);        
        val_23.CopyFrom(other:  val_24);
        // 0x02677EC4: LDR x20, [x19, #0x50]      | X20 = this.tmpCam; //P2                 
        // 0x02677EC8: CBNZ x20, #0x2677ed0       | if (this.tmpCam != null) goto label_32; 
        if(this.tmpCam != null)
        {
            goto label_32;
        }
        // 0x02677ECC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
        label_32:
        // 0x02677ED0: LDR x1, [x23]              | X1 = public UnityEngine.Camera UnityEngine.GameObject::GetComponent<UnityEngine.Camera>();
        // 0x02677ED4: MOV x0, x20                | X0 = this.tmpCam;//m1                   
        // 0x02677ED8: BL #0x23d5abc              | X0 = this.tmpCam.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_25 = this.tmpCam.GetComponent<UnityEngine.Camera>();
        // 0x02677EDC: MOV x20, x0                | X20 = val_25;//m1                       
        // 0x02677EE0: CBNZ x20, #0x2677ee8       | if (val_25 != null) goto label_33;      
        if(val_25 != null)
        {
            goto label_33;
        }
        // 0x02677EE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
        label_33:
        // 0x02677EE8: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x02677EEC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02677EF0: MOV x0, x20                | X0 = val_25;//m1                        
        // 0x02677EF4: BL #0x20cb458              | val_25.set_enabled(value:  false);      
        val_25.enabled = false;
        // 0x02677EF8: LDR x20, [x19, #0x50]      | X20 = this.tmpCam; //P2                 
        // 0x02677EFC: CBNZ x20, #0x2677f04       | if (this.tmpCam != null) goto label_34; 
        if(this.tmpCam != null)
        {
            goto label_34;
        }
        // 0x02677F00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
        label_34:
        // 0x02677F04: LDR x1, [x23]              | X1 = public UnityEngine.Camera UnityEngine.GameObject::GetComponent<UnityEngine.Camera>();
        // 0x02677F08: MOV x0, x20                | X0 = this.tmpCam;//m1                   
        // 0x02677F0C: BL #0x23d5abc              | X0 = this.tmpCam.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_26 = this.tmpCam.GetComponent<UnityEngine.Camera>();
        // 0x02677F10: MOV x20, x0                | X20 = val_26;//m1                       
        // 0x02677F14: CBNZ x20, #0x2677f1c       | if (val_26 != null) goto label_35;      
        if(val_26 != null)
        {
            goto label_35;
        }
        // 0x02677F18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
        label_35:
        // 0x02677F1C: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x02677F20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02677F24: MOV x0, x20                | X0 = val_26;//m1                        
        // 0x02677F28: BL #0x20d2b78              | val_26.set_depthTextureMode(value:  0); 
        val_26.depthTextureMode = 0;
        // 0x02677F2C: LDR x20, [x19, #0x50]      | X20 = this.tmpCam; //P2                 
        // 0x02677F30: CBNZ x20, #0x2677f38       | if (this.tmpCam != null) goto label_36; 
        if(this.tmpCam != null)
        {
            goto label_36;
        }
        // 0x02677F34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
        label_36:
        // 0x02677F38: LDR x1, [x23]              | X1 = public UnityEngine.Camera UnityEngine.GameObject::GetComponent<UnityEngine.Camera>();
        // 0x02677F3C: MOV x0, x20                | X0 = this.tmpCam;//m1                   
        // 0x02677F40: BL #0x23d5abc              | X0 = this.tmpCam.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_27 = this.tmpCam.GetComponent<UnityEngine.Camera>();
        // 0x02677F44: MOV x20, x0                | X20 = val_27;//m1                       
        // 0x02677F48: CBNZ x20, #0x2677f50       | if (val_27 != null) goto label_37;      
        if(val_27 != null)
        {
            goto label_37;
        }
        // 0x02677F4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
        label_37:
        // 0x02677F50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02677F54: ORR w1, wzr, #4            | W1 = 4(0x4);                            
        // 0x02677F58: MOV x0, x20                | X0 = val_27;//m1                        
        // 0x02677F5C: BL #0x20d097c              | val_27.set_clearFlags(value:  4);       
        val_27.clearFlags = 4;
        // 0x02677F60: LDR x19, [x19, #0x50]      | X19 = this.tmpCam; //P2                 
        // 0x02677F64: CBNZ x19, #0x2677f6c       | if (this.tmpCam != null) goto label_38; 
        if(this.tmpCam != null)
        {
            goto label_38;
        }
        // 0x02677F68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
        label_38:
        // 0x02677F6C: LDR x1, [x23]              | X1 = public UnityEngine.Camera UnityEngine.GameObject::GetComponent<UnityEngine.Camera>();
        // 0x02677F70: MOV x0, x19                | X0 = this.tmpCam;//m1                   
        // 0x02677F74: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x02677F78: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x02677F7C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x02677F80: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x02677F84: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x02677F88: LDP d11, d10, [sp], #0x60  | D11 = ; D10 = ;                          //  | 
        // 0x02677F8C: B #0x23d5abc               | return this.tmpCam.GetComponent<UnityEngine.Camera>();
        return this.tmpCam.GetComponent<UnityEngine.Camera>();
    
    }
    //
    // Offset in libil2cpp.so: 0x02677F90 (40337296), len: 232  VirtAddr: 0x02677F90 RVA: 0x02677F90 token: 100663339 methodIndex: 24423 delegateWrapperIndex: 0 methodInvoker: 0
    public override void StartFrame()
    {
        //
        // Disasemble & Code
        // 0x02677F90: STP d13, d12, [sp, #-0x50]! | stack[1152921509950824160] = ???;  stack[1152921509950824168] = ???;  //  dest_result_addr=1152921509950824160 |  dest_result_addr=1152921509950824168
        // 0x02677F94: STP d11, d10, [sp, #0x10]  | stack[1152921509950824176] = ???;  stack[1152921509950824184] = ???;  //  dest_result_addr=1152921509950824176 |  dest_result_addr=1152921509950824184
        // 0x02677F98: STP d9, d8, [sp, #0x20]    | stack[1152921509950824192] = ???;  stack[1152921509950824200] = ???;  //  dest_result_addr=1152921509950824192 |  dest_result_addr=1152921509950824200
        // 0x02677F9C: STP x20, x19, [sp, #0x30]  | stack[1152921509950824208] = ???;  stack[1152921509950824216] = ???;  //  dest_result_addr=1152921509950824208 |  dest_result_addr=1152921509950824216
        // 0x02677FA0: STP x29, x30, [sp, #0x40]  | stack[1152921509950824224] = ???;  stack[1152921509950824232] = ???;  //  dest_result_addr=1152921509950824224 |  dest_result_addr=1152921509950824232
        // 0x02677FA4: ADD x29, sp, #0x40         | X29 = (1152921509950824160 + 64) = 1152921509950824224 (0x100000013E869F20);
        // 0x02677FA8: ADRP x20, #0x3740000       | X20 = 57933824 (0x3740000);             
        // 0x02677FAC: LDRB w8, [x20, #0xe5a]     | W8 = (bool)static_value_03740E5A;       
        // 0x02677FB0: MOV x19, x0                | X19 = 1152921509950836240 (0x100000013E86CE10);//ML01
        // 0x02677FB4: TBNZ w8, #0, #0x2677fd0    | if (static_value_03740E5A == true) goto label_0;
        // 0x02677FB8: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
        // 0x02677FBC: LDR x8, [x8, #0xf10]       | X8 = 0x2B90240;                         
        // 0x02677FC0: LDR w0, [x8]               | W0 = 0x1754;                            
        // 0x02677FC4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1754, ????);     
        // 0x02677FC8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02677FCC: STRB w8, [x20, #0xe5a]     | static_value_03740E5A = true;            //  dest_result_addr=57937498
        label_0:
        // 0x02677FD0: LDR s8, [x19, #0x140]      | S8 = this.prevFramePos; //P2            
        // 0x02677FD4: LDR s9, [x19, #0x144]      | 
        // 0x02677FD8: LDR s10, [x19, #0x148]     | 
        // 0x02677FDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677FE0: MOV x0, x19                | X0 = 1152921509950836240 (0x100000013E86CE10);//ML01
        // 0x02677FE4: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_1 = this.transform;
        // 0x02677FE8: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x02677FEC: CBNZ x20, #0x2677ff4       | if (val_1 != null) goto label_1;        
        if(val_1 != null)
        {
            goto label_1;
        }
        // 0x02677FF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x02677FF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02677FF8: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x02677FFC: BL #0x2693510              | X0 = val_1.get_position();              
        UnityEngine.Vector3 val_2 = val_1.position;
        // 0x02678000: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x02678004: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x02678008: MOV v11.16b, v0.16b        | V11 = val_2.x;//m1                      
        // 0x0267800C: MOV v12.16b, v1.16b        | V12 = val_2.y;//m1                      
        // 0x02678010: MOV v13.16b, v2.16b        | V13 = val_2.z;//m1                      
        // 0x02678014: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x02678018: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x0267801C: TBZ w8, #0, #0x267802c     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x02678020: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x02678024: CBNZ w8, #0x267802c        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x02678028: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_3:
        // 0x0267802C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02678030: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02678034: FMOV s6, #0.75000000       | S6 = 0.75;                              
        // 0x02678038: MOV v0.16b, v8.16b         | V0 = this.prevFramePos;//m1             
        // 0x0267803C: MOV v1.16b, v9.16b         | V1 = V9.16B;//m1                        
        // 0x02678040: MOV v2.16b, v10.16b        | V2 = V10.16B;//m1                       
        // 0x02678044: MOV v3.16b, v11.16b        | V3 = val_2.x;//m1                       
        // 0x02678048: MOV v4.16b, v12.16b        | V4 = val_2.y;//m1                       
        // 0x0267804C: MOV v5.16b, v13.16b        | V5 = val_2.z;//m1                       
        // 0x02678050: BL #0x26987d0              | X0 = UnityEngine.Vector3.Slerp(a:  new UnityEngine.Vector3() {x = this.prevFramePos, y = V9.16B, z = V10.16B}, b:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z}, t:  0.75f);
        UnityEngine.Vector3 val_3 = UnityEngine.Vector3.Slerp(a:  new UnityEngine.Vector3() {x = this.prevFramePos, y = V9.16B, z = V10.16B}, b:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z}, t:  0.75f);
        // 0x02678054: STR s2, [x19, #0x148]      | mem[1152921509950836568] = val_3.z;      //  dest_result_addr=1152921509950836568
        mem[1152921509950836568] = val_3.z;
        // 0x02678058: STR s0, [x19, #0x140]      | this.prevFramePos = val_3;               //  dest_result_addr=1152921509950836560
        this.prevFramePos = val_3;
        // 0x0267805C: STR s1, [x19, #0x144]      | mem[1152921509950836564] = val_3.y;      //  dest_result_addr=1152921509950836564
        mem[1152921509950836564] = val_3.y;
        // 0x02678060: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x02678064: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x02678068: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x0267806C: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x02678070: LDP d13, d12, [sp], #0x50  | D13 = ; D12 = ;                          //  | 
        // 0x02678074: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02678078 (40337528), len: 16  VirtAddr: 0x02678078 RVA: 0x02678078 token: 100663340 methodIndex: 24424 delegateWrapperIndex: 0 methodInvoker: 0
    public override int divRoundUp(int x, int d)
    {
        //
        // Disasemble & Code
        // 0x02678078: ADD w8, w1, w2             | W8 = (x + d);                           
        int val_1 = x + d;
        // 0x0267807C: SUB w8, w8, #1             | W8 = ((x + d) - 1);                     
        val_1 = val_1 - 1;
        // 0x02678080: SDIV w0, w8, w2            | W0 = (((x + d) - 1) / d);               
        int val_2 = val_1 / d;
        // 0x02678084: RET                        |  return (System.Int32)(((x + d) - 1) / d);
        return val_2;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x02678088 (40337544), len: 4  VirtAddr: 0x02678088 RVA: 0x02678088 token: 100663341 methodIndex: 24425 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Main()
    {
        //
        // Disasemble & Code
        // 0x02678088: RET                        |  return;                                
        return;
    
    }

}
