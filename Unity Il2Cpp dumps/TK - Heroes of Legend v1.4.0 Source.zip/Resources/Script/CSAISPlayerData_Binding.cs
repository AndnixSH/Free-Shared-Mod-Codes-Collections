using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class CSAISPlayerData_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache4; // static_offset: 0x00000020
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache5; // static_offset: 0x00000028
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache6; // static_offset: 0x00000030
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache7; // static_offset: 0x00000038
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache8; // static_offset: 0x00000040
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache9; // static_offset: 0x00000048
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheA; // static_offset: 0x00000050
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cacheB; // static_offset: 0x00000058
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheC; // static_offset: 0x00000060
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cacheD; // static_offset: 0x00000068
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheE; // static_offset: 0x00000070
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cacheF; // static_offset: 0x00000078
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache10; // static_offset: 0x00000080
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache11; // static_offset: 0x00000088
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache12; // static_offset: 0x00000090
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache13; // static_offset: 0x00000098
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache14; // static_offset: 0x000000A0
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache15; // static_offset: 0x000000A8
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache16; // static_offset: 0x000000B0
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache17; // static_offset: 0x000000B8
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x01C01FDC (29368284), len: 8  VirtAddr: 0x01C01FDC RVA: 0x01C01FDC token: 100665090 methodIndex: 31139 delegateWrapperIndex: 0 methodInvoker: 0
        public CSAISPlayerData_Binding()
        {
            //
            // Disasemble & Code
            // 0x01C01FDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C01FE0: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C01FE4 (29368292), len: 3508  VirtAddr: 0x01C01FE4 RVA: 0x01C01FE4 token: 100665091 methodIndex: 31140 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_26;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_27;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_28;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_29;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_30;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_31;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_32;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_33;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_34;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_35;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_36;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_37;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_38;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_39;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_40;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_41;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_42;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_43;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_44;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_45;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_46;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_47;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_48;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_49;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_50;
            // 0x01C01FE4: STP x24, x23, [sp, #-0x40]! | stack[1152921510257821776] = ???;  stack[1152921510257821784] = ???;  //  dest_result_addr=1152921510257821776 |  dest_result_addr=1152921510257821784
            // 0x01C01FE8: STP x22, x21, [sp, #0x10]  | stack[1152921510257821792] = ???;  stack[1152921510257821800] = ???;  //  dest_result_addr=1152921510257821792 |  dest_result_addr=1152921510257821800
            // 0x01C01FEC: STP x20, x19, [sp, #0x20]  | stack[1152921510257821808] = ???;  stack[1152921510257821816] = ???;  //  dest_result_addr=1152921510257821808 |  dest_result_addr=1152921510257821816
            // 0x01C01FF0: STP x29, x30, [sp, #0x30]  | stack[1152921510257821824] = ???;  stack[1152921510257821832] = ???;  //  dest_result_addr=1152921510257821824 |  dest_result_addr=1152921510257821832
            // 0x01C01FF4: ADD x29, sp, #0x30         | X29 = (1152921510257821776 + 48) = 1152921510257821824 (0x1000000150D30880);
            // 0x01C01FF8: ADRP x20, #0x373c000       | X20 = 57917440 (0x373C000);             
            // 0x01C01FFC: LDRB w8, [x20, #0x25e]     | W8 = (bool)static_value_0373C25E;       
            // 0x01C02000: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01C02004: TBNZ w8, #0, #0x1c02020    | if (static_value_0373C25E == true) goto label_0;
            // 0x01C02008: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x01C0200C: LDR x8, [x8, #0x9f0]       | X8 = 0x2B92F34;                         
            // 0x01C02010: LDR w0, [x8]               | W0 = 0x2292;                            
            // 0x01C02014: BL #0x2782188              | X0 = sub_2782188( ?? 0x2292, ????);     
            // 0x01C02018: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C0201C: STRB w8, [x20, #0x25e]     | static_value_0373C25E = true;            //  dest_result_addr=57918046
            label_0:
            // 0x01C02020: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01C02024: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01C02028: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x01C0202C: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x01C02030: LDR x8, [x8, #0x260]       | X8 = 1152921504904503296;               
            // 0x01C02034: LDR x20, [x8]              | X20 = typeof(CSAISPlayerData);          
            // 0x01C02038: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01C0203C: TBZ w8, #0, #0x1c0204c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01C02040: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01C02044: CBNZ w8, #0x1c0204c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01C02048: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x01C0204C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C02050: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C02054: MOV x1, x20                | X1 = 1152921504904503296 (0x1000000011BDE000);//ML01
            // 0x01C02058: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C0205C: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x01C02060: CBNZ x20, #0x1c02068       | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x01C02064: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x01C02068: ADRP x9, #0x3633000        | X9 = 56832000 (0x3633000);              
            // 0x01C0206C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01C02070: LDR x9, [x9, #0x518]       | X9 = (string**)(1152921510257784480)("roleId");
            // 0x01C02074: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01C02078: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01C0207C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01C02080: LDR x1, [x9]               | X1 = "roleId";                          
            // 0x01C02084: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01C02088: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01C0208C: ADRP x24, #0x364a000       | X24 = 56926208 (0x364A000);             
            // 0x01C02090: LDR x24, [x24, #0x6c0]     | X24 = 1152921504784269312;              
            // 0x01C02094: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01C02098: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C0209C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C020A0: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache0;
            val_26 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache0;
            // 0x01C020A4: CBNZ x22, #0x1c020f0       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache0 != null) goto label_4;
            if(val_26 != null)
            {
                goto label_4;
            }
            // 0x01C020A8: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
            // 0x01C020AC: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01C020B0: LDR x8, [x8, #0x980]       | X8 = 1152921510257784560;               
            // 0x01C020B4: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01C020B8: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_roleId_0(ref object o);
            // 0x01C020BC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_2 = null;
            // 0x01C020C0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01C020C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C020C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C020CC: MOV x2, x22                | X2 = 1152921510257784560 (0x1000000150D276F0);//ML01
            // 0x01C020D0: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_27 = val_2;
            // 0x01C020D4: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_roleId_0(ref object o));
            val_2 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_roleId_0(ref object o));
            // 0x01C020D8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C020DC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C020E0: STR x23, [x8]              | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504784273408
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache0 = val_27;
            // 0x01C020E4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C020E8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C020EC: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_26 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache0;
            label_4:
            // 0x01C020F0: CBNZ x19, #0x1c020f8       | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x01C020F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_roleId_0(ref object o)), ????);
            label_5:
            // 0x01C020F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C020FC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C02100: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C02104: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01C02108: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_26);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_26);
            // 0x01C0210C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02110: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02114: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache1;
            val_28 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache1;
            // 0x01C02118: CBNZ x22, #0x1c02164       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache1 != null) goto label_6;
            if(val_28 != null)
            {
                goto label_6;
            }
            // 0x01C0211C: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x01C02120: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01C02124: LDR x8, [x8, #0x560]       | X8 = 1152921510257785584;               
            // 0x01C02128: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01C0212C: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_roleId_0(ref object o, object v);
            // 0x01C02130: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_3 = null;
            // 0x01C02134: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01C02138: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C0213C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02140: MOV x2, x22                | X2 = 1152921510257785584 (0x1000000150D27AF0);//ML01
            // 0x01C02144: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_27 = val_3;
            // 0x01C02148: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_roleId_0(ref object o, object v));
            val_3 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_roleId_0(ref object o, object v));
            // 0x01C0214C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02150: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02154: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504784273416
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache1 = val_27;
            // 0x01C02158: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C0215C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02160: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_28 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache1;
            label_6:
            // 0x01C02164: CBNZ x19, #0x1c0216c       | if (X1 != 0) goto label_7;              
            if(X1 != 0)
            {
                goto label_7;
            }
            // 0x01C02168: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_roleId_0(ref object o, object v)), ????);
            label_7:
            // 0x01C0216C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02170: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C02174: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C02178: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01C0217C: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_28);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_28);
            // 0x01C02180: CBNZ x20, #0x1c02188       | if (val_1 != null) goto label_8;        
            if(val_1 != null)
            {
                goto label_8;
            }
            // 0x01C02184: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_8:
            // 0x01C02188: ADRP x9, #0x35c6000        | X9 = 56385536 (0x35C6000);              
            // 0x01C0218C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01C02190: LDR x9, [x9, #0x5f0]       | X9 = (string**)(1152921509593945888)("name");
            // 0x01C02194: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01C02198: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01C0219C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01C021A0: LDR x1, [x9]               | X1 = "name";                            
            // 0x01C021A4: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01C021A8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01C021AC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C021B0: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01C021B4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C021B8: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache2;
            val_29 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache2;
            // 0x01C021BC: CBNZ x22, #0x1c02208       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache2 != null) goto label_9;
            if(val_29 != null)
            {
                goto label_9;
            }
            // 0x01C021C0: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
            // 0x01C021C4: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01C021C8: LDR x8, [x8, #0x660]       | X8 = 1152921510257786608;               
            // 0x01C021CC: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01C021D0: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_name_1(ref object o);
            // 0x01C021D4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_4 = null;
            // 0x01C021D8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01C021DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C021E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C021E4: MOV x2, x22                | X2 = 1152921510257786608 (0x1000000150D27EF0);//ML01
            // 0x01C021E8: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_27 = val_4;
            // 0x01C021EC: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_name_1(ref object o));
            val_4 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_name_1(ref object o));
            // 0x01C021F0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C021F4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C021F8: STR x23, [x8, #0x10]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504784273424
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache2 = val_27;
            // 0x01C021FC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02200: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02204: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_29 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache2;
            label_9:
            // 0x01C02208: CBNZ x19, #0x1c02210       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x01C0220C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_name_1(ref object o)), ????);
            label_10:
            // 0x01C02210: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02214: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C02218: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C0221C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01C02220: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_29);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_29);
            // 0x01C02224: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02228: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C0222C: LDR x22, [x8, #0x18]       | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache3;
            val_30 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache3;
            // 0x01C02230: CBNZ x22, #0x1c0227c       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache3 != null) goto label_11;
            if(val_30 != null)
            {
                goto label_11;
            }
            // 0x01C02234: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
            // 0x01C02238: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01C0223C: LDR x8, [x8, #0x5c8]       | X8 = 1152921510257787632;               
            // 0x01C02240: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01C02244: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_name_1(ref object o, object v);
            // 0x01C02248: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_5 = null;
            // 0x01C0224C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01C02250: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C02254: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02258: MOV x2, x22                | X2 = 1152921510257787632 (0x1000000150D282F0);//ML01
            // 0x01C0225C: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_27 = val_5;
            // 0x01C02260: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_name_1(ref object o, object v));
            val_5 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_name_1(ref object o, object v));
            // 0x01C02264: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02268: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C0226C: STR x23, [x8, #0x18]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504784273432
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache3 = val_27;
            // 0x01C02270: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02274: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02278: LDR x22, [x8, #0x18]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_30 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache3;
            label_11:
            // 0x01C0227C: CBNZ x19, #0x1c02284       | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x01C02280: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_name_1(ref object o, object v)), ????);
            label_12:
            // 0x01C02284: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02288: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C0228C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C02290: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01C02294: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_30);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_30);
            // 0x01C02298: CBNZ x20, #0x1c022a0       | if (val_1 != null) goto label_13;       
            if(val_1 != null)
            {
                goto label_13;
            }
            // 0x01C0229C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_13:
            // 0x01C022A0: ADRP x9, #0x3666000        | X9 = 57040896 (0x3666000);              
            // 0x01C022A4: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01C022A8: LDR x9, [x9, #0xaf8]       | X9 = (string**)(1152921510257788656)("unionName");
            // 0x01C022AC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01C022B0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01C022B4: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01C022B8: LDR x1, [x9]               | X1 = "unionName";                       
            // 0x01C022BC: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01C022C0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01C022C4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C022C8: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01C022CC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C022D0: LDR x22, [x8, #0x20]       | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache4;
            val_31 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache4;
            // 0x01C022D4: CBNZ x22, #0x1c02320       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache4 != null) goto label_14;
            if(val_31 != null)
            {
                goto label_14;
            }
            // 0x01C022D8: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
            // 0x01C022DC: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01C022E0: LDR x8, [x8, #0x918]       | X8 = 1152921510257788752;               
            // 0x01C022E4: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01C022E8: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_unionName_2(ref object o);
            // 0x01C022EC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_6 = null;
            // 0x01C022F0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01C022F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C022F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C022FC: MOV x2, x22                | X2 = 1152921510257788752 (0x1000000150D28750);//ML01
            // 0x01C02300: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_27 = val_6;
            // 0x01C02304: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_unionName_2(ref object o));
            val_6 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_unionName_2(ref object o));
            // 0x01C02308: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C0230C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02310: STR x23, [x8, #0x20]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504784273440
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache4 = val_27;
            // 0x01C02314: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02318: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C0231C: LDR x22, [x8, #0x20]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_31 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache4;
            label_14:
            // 0x01C02320: CBNZ x19, #0x1c02328       | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x01C02324: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_unionName_2(ref object o)), ????);
            label_15:
            // 0x01C02328: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C0232C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C02330: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C02334: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01C02338: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_31);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_31);
            // 0x01C0233C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02340: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02344: LDR x22, [x8, #0x28]       | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache5;
            val_32 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache5;
            // 0x01C02348: CBNZ x22, #0x1c02394       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache5 != null) goto label_16;
            if(val_32 != null)
            {
                goto label_16;
            }
            // 0x01C0234C: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
            // 0x01C02350: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01C02354: LDR x8, [x8, #0xdc8]       | X8 = 1152921510257789776;               
            // 0x01C02358: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01C0235C: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_unionName_2(ref object o, object v);
            // 0x01C02360: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_7 = null;
            // 0x01C02364: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01C02368: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C0236C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02370: MOV x2, x22                | X2 = 1152921510257789776 (0x1000000150D28B50);//ML01
            // 0x01C02374: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_27 = val_7;
            // 0x01C02378: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_unionName_2(ref object o, object v));
            val_7 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_unionName_2(ref object o, object v));
            // 0x01C0237C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02380: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02384: STR x23, [x8, #0x28]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache5 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504784273448
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache5 = val_27;
            // 0x01C02388: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C0238C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02390: LDR x22, [x8, #0x28]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_32 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache5;
            label_16:
            // 0x01C02394: CBNZ x19, #0x1c0239c       | if (X1 != 0) goto label_17;             
            if(X1 != 0)
            {
                goto label_17;
            }
            // 0x01C02398: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_unionName_2(ref object o, object v)), ????);
            label_17:
            // 0x01C0239C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C023A0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C023A4: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C023A8: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01C023AC: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_32);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_32);
            // 0x01C023B0: CBNZ x20, #0x1c023b8       | if (val_1 != null) goto label_18;       
            if(val_1 != null)
            {
                goto label_18;
            }
            // 0x01C023B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_18:
            // 0x01C023B8: ADRP x9, #0x35f0000        | X9 = 56557568 (0x35F0000);              
            // 0x01C023BC: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01C023C0: LDR x9, [x9, #0xe50]       | X9 = (string**)(1152921510257790800)("icon");
            // 0x01C023C4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01C023C8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01C023CC: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01C023D0: LDR x1, [x9]               | X1 = "icon";                            
            // 0x01C023D4: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01C023D8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01C023DC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C023E0: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01C023E4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C023E8: LDR x22, [x8, #0x30]       | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache6;
            val_33 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache6;
            // 0x01C023EC: CBNZ x22, #0x1c02438       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache6 != null) goto label_19;
            if(val_33 != null)
            {
                goto label_19;
            }
            // 0x01C023F0: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
            // 0x01C023F4: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01C023F8: LDR x8, [x8, #0xa18]       | X8 = 1152921510257790880;               
            // 0x01C023FC: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01C02400: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_icon_3(ref object o);
            // 0x01C02404: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_8 = null;
            // 0x01C02408: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01C0240C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C02410: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02414: MOV x2, x22                | X2 = 1152921510257790880 (0x1000000150D28FA0);//ML01
            // 0x01C02418: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_27 = val_8;
            // 0x01C0241C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_icon_3(ref object o));
            val_8 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_icon_3(ref object o));
            // 0x01C02420: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02424: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02428: STR x23, [x8, #0x30]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache6 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504784273456
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache6 = val_27;
            // 0x01C0242C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02430: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02434: LDR x22, [x8, #0x30]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_33 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache6;
            label_19:
            // 0x01C02438: CBNZ x19, #0x1c02440       | if (X1 != 0) goto label_20;             
            if(X1 != 0)
            {
                goto label_20;
            }
            // 0x01C0243C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_icon_3(ref object o)), ????);
            label_20:
            // 0x01C02440: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02444: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C02448: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C0244C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01C02450: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_33);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_33);
            // 0x01C02454: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02458: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C0245C: LDR x22, [x8, #0x38]       | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache7;
            val_34 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache7;
            // 0x01C02460: CBNZ x22, #0x1c024ac       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache7 != null) goto label_21;
            if(val_34 != null)
            {
                goto label_21;
            }
            // 0x01C02464: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
            // 0x01C02468: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01C0246C: LDR x8, [x8, #0xd68]       | X8 = 1152921510257791904;               
            // 0x01C02470: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01C02474: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_icon_3(ref object o, object v);
            // 0x01C02478: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_9 = null;
            // 0x01C0247C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01C02480: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C02484: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02488: MOV x2, x22                | X2 = 1152921510257791904 (0x1000000150D293A0);//ML01
            // 0x01C0248C: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_27 = val_9;
            // 0x01C02490: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_icon_3(ref object o, object v));
            val_9 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_icon_3(ref object o, object v));
            // 0x01C02494: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02498: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C0249C: STR x23, [x8, #0x38]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache7 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504784273464
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache7 = val_27;
            // 0x01C024A0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C024A4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C024A8: LDR x22, [x8, #0x38]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_34 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache7;
            label_21:
            // 0x01C024AC: CBNZ x19, #0x1c024b4       | if (X1 != 0) goto label_22;             
            if(X1 != 0)
            {
                goto label_22;
            }
            // 0x01C024B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_icon_3(ref object o, object v)), ????);
            label_22:
            // 0x01C024B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C024B8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C024BC: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C024C0: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01C024C4: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_34);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_34);
            // 0x01C024C8: CBNZ x20, #0x1c024d0       | if (val_1 != null) goto label_23;       
            if(val_1 != null)
            {
                goto label_23;
            }
            // 0x01C024CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_23:
            // 0x01C024D0: ADRP x9, #0x35c6000        | X9 = 56385536 (0x35C6000);              
            // 0x01C024D4: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01C024D8: LDR x9, [x9, #0x7e0]       | X9 = (string**)(1152921510257792928)("rank");
            // 0x01C024DC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01C024E0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01C024E4: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01C024E8: LDR x1, [x9]               | X1 = "rank";                            
            // 0x01C024EC: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01C024F0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01C024F4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C024F8: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01C024FC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02500: LDR x22, [x8, #0x40]       | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache8;
            val_35 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache8;
            // 0x01C02504: CBNZ x22, #0x1c02550       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache8 != null) goto label_24;
            if(val_35 != null)
            {
                goto label_24;
            }
            // 0x01C02508: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x01C0250C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01C02510: LDR x8, [x8, #0x850]       | X8 = 1152921510257793008;               
            // 0x01C02514: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01C02518: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_rank_4(ref object o);
            // 0x01C0251C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_10 = null;
            // 0x01C02520: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01C02524: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C02528: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C0252C: MOV x2, x22                | X2 = 1152921510257793008 (0x1000000150D297F0);//ML01
            // 0x01C02530: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_27 = val_10;
            // 0x01C02534: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_rank_4(ref object o));
            val_10 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_rank_4(ref object o));
            // 0x01C02538: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C0253C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02540: STR x23, [x8, #0x40]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache8 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504784273472
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache8 = val_27;
            // 0x01C02544: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02548: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C0254C: LDR x22, [x8, #0x40]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_35 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache8;
            label_24:
            // 0x01C02550: CBNZ x19, #0x1c02558       | if (X1 != 0) goto label_25;             
            if(X1 != 0)
            {
                goto label_25;
            }
            // 0x01C02554: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_rank_4(ref object o)), ????);
            label_25:
            // 0x01C02558: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C0255C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C02560: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C02564: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01C02568: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_35);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_35);
            // 0x01C0256C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02570: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02574: LDR x22, [x8, #0x48]       | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache9;
            val_36 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache9;
            // 0x01C02578: CBNZ x22, #0x1c025c4       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache9 != null) goto label_26;
            if(val_36 != null)
            {
                goto label_26;
            }
            // 0x01C0257C: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
            // 0x01C02580: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01C02584: LDR x8, [x8, #0x9f8]       | X8 = 1152921510257794032;               
            // 0x01C02588: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01C0258C: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_rank_4(ref object o, object v);
            // 0x01C02590: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_11 = null;
            // 0x01C02594: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01C02598: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C0259C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C025A0: MOV x2, x22                | X2 = 1152921510257794032 (0x1000000150D29BF0);//ML01
            // 0x01C025A4: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_27 = val_11;
            // 0x01C025A8: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_rank_4(ref object o, object v));
            val_11 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_rank_4(ref object o, object v));
            // 0x01C025AC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C025B0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C025B4: STR x23, [x8, #0x48]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache9 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504784273480
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache9 = val_27;
            // 0x01C025B8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C025BC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C025C0: LDR x22, [x8, #0x48]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_36 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache9;
            label_26:
            // 0x01C025C4: CBNZ x19, #0x1c025cc       | if (X1 != 0) goto label_27;             
            if(X1 != 0)
            {
                goto label_27;
            }
            // 0x01C025C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_rank_4(ref object o, object v)), ????);
            label_27:
            // 0x01C025CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C025D0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C025D4: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C025D8: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01C025DC: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_36);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_36);
            // 0x01C025E0: CBNZ x20, #0x1c025e8       | if (val_1 != null) goto label_28;       
            if(val_1 != null)
            {
                goto label_28;
            }
            // 0x01C025E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_28:
            // 0x01C025E8: ADRP x9, #0x3671000        | X9 = 57085952 (0x3671000);              
            // 0x01C025EC: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01C025F0: LDR x9, [x9, #0xd50]       | X9 = (string**)(1152921510257795056)("lv");
            // 0x01C025F4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01C025F8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01C025FC: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01C02600: LDR x1, [x9]               | X1 = "lv";                              
            // 0x01C02604: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01C02608: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01C0260C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02610: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01C02614: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02618: LDR x22, [x8, #0x50]       | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheA;
            val_37 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheA;
            // 0x01C0261C: CBNZ x22, #0x1c02668       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheA != null) goto label_29;
            if(val_37 != null)
            {
                goto label_29;
            }
            // 0x01C02620: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x01C02624: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01C02628: LDR x8, [x8, #0xe50]       | X8 = 1152921510257795136;               
            // 0x01C0262C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01C02630: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_lv_5(ref object o);
            // 0x01C02634: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_12 = null;
            // 0x01C02638: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01C0263C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C02640: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02644: MOV x2, x22                | X2 = 1152921510257795136 (0x1000000150D2A040);//ML01
            // 0x01C02648: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_27 = val_12;
            // 0x01C0264C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_lv_5(ref object o));
            val_12 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_lv_5(ref object o));
            // 0x01C02650: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02654: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02658: STR x23, [x8, #0x50]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheA = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504784273488
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheA = val_27;
            // 0x01C0265C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02660: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02664: LDR x22, [x8, #0x50]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_37 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheA;
            label_29:
            // 0x01C02668: CBNZ x19, #0x1c02670       | if (X1 != 0) goto label_30;             
            if(X1 != 0)
            {
                goto label_30;
            }
            // 0x01C0266C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_lv_5(ref object o)), ????);
            label_30:
            // 0x01C02670: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02674: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C02678: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C0267C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01C02680: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_37);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_37);
            // 0x01C02684: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02688: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C0268C: LDR x22, [x8, #0x58]       | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheB;
            val_38 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheB;
            // 0x01C02690: CBNZ x22, #0x1c026dc       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheB != null) goto label_31;
            if(val_38 != null)
            {
                goto label_31;
            }
            // 0x01C02694: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x01C02698: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01C0269C: LDR x8, [x8, #0x250]       | X8 = 1152921510257796160;               
            // 0x01C026A0: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01C026A4: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_lv_5(ref object o, object v);
            // 0x01C026A8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_13 = null;
            // 0x01C026AC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01C026B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C026B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C026B8: MOV x2, x22                | X2 = 1152921510257796160 (0x1000000150D2A440);//ML01
            // 0x01C026BC: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_27 = val_13;
            // 0x01C026C0: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_lv_5(ref object o, object v));
            val_13 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_lv_5(ref object o, object v));
            // 0x01C026C4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C026C8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C026CC: STR x23, [x8, #0x58]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheB = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504784273496
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheB = val_27;
            // 0x01C026D0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C026D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C026D8: LDR x22, [x8, #0x58]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_38 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheB;
            label_31:
            // 0x01C026DC: CBNZ x19, #0x1c026e4       | if (X1 != 0) goto label_32;             
            if(X1 != 0)
            {
                goto label_32;
            }
            // 0x01C026E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_lv_5(ref object o, object v)), ????);
            label_32:
            // 0x01C026E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C026E8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C026EC: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C026F0: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01C026F4: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_38);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_38);
            // 0x01C026F8: CBNZ x20, #0x1c02700       | if (val_1 != null) goto label_33;       
            if(val_1 != null)
            {
                goto label_33;
            }
            // 0x01C026FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_33:
            // 0x01C02700: ADRP x9, #0x3665000        | X9 = 57036800 (0x3665000);              
            // 0x01C02704: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01C02708: LDR x9, [x9, #0x3d8]       | X9 = (string**)(1152921510257797184)("vipLv");
            // 0x01C0270C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01C02710: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01C02714: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01C02718: LDR x1, [x9]               | X1 = "vipLv";                           
            // 0x01C0271C: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01C02720: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01C02724: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02728: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01C0272C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02730: LDR x22, [x8, #0x60]       | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheC;
            val_39 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheC;
            // 0x01C02734: CBNZ x22, #0x1c02780       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheC != null) goto label_34;
            if(val_39 != null)
            {
                goto label_34;
            }
            // 0x01C02738: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
            // 0x01C0273C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01C02740: LDR x8, [x8, #0x558]       | X8 = 1152921510257797264;               
            // 0x01C02744: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01C02748: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_vipLv_6(ref object o);
            // 0x01C0274C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_14 = null;
            // 0x01C02750: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01C02754: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C02758: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C0275C: MOV x2, x22                | X2 = 1152921510257797264 (0x1000000150D2A890);//ML01
            // 0x01C02760: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_27 = val_14;
            // 0x01C02764: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_vipLv_6(ref object o));
            val_14 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_vipLv_6(ref object o));
            // 0x01C02768: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C0276C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02770: STR x23, [x8, #0x60]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheC = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504784273504
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheC = val_27;
            // 0x01C02774: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02778: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C0277C: LDR x22, [x8, #0x60]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_39 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheC;
            label_34:
            // 0x01C02780: CBNZ x19, #0x1c02788       | if (X1 != 0) goto label_35;             
            if(X1 != 0)
            {
                goto label_35;
            }
            // 0x01C02784: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_vipLv_6(ref object o)), ????);
            label_35:
            // 0x01C02788: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C0278C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C02790: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C02794: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01C02798: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_39);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_39);
            // 0x01C0279C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C027A0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C027A4: LDR x22, [x8, #0x68]       | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheD;
            val_40 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheD;
            // 0x01C027A8: CBNZ x22, #0x1c027f4       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheD != null) goto label_36;
            if(val_40 != null)
            {
                goto label_36;
            }
            // 0x01C027AC: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
            // 0x01C027B0: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01C027B4: LDR x8, [x8, #0xff0]       | X8 = 1152921510257798288;               
            // 0x01C027B8: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01C027BC: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_vipLv_6(ref object o, object v);
            // 0x01C027C0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_15 = null;
            // 0x01C027C4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01C027C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C027CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C027D0: MOV x2, x22                | X2 = 1152921510257798288 (0x1000000150D2AC90);//ML01
            // 0x01C027D4: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_27 = val_15;
            // 0x01C027D8: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_vipLv_6(ref object o, object v));
            val_15 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_vipLv_6(ref object o, object v));
            // 0x01C027DC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C027E0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C027E4: STR x23, [x8, #0x68]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheD = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504784273512
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheD = val_27;
            // 0x01C027E8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C027EC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C027F0: LDR x22, [x8, #0x68]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_40 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheD;
            label_36:
            // 0x01C027F4: CBNZ x19, #0x1c027fc       | if (X1 != 0) goto label_37;             
            if(X1 != 0)
            {
                goto label_37;
            }
            // 0x01C027F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_vipLv_6(ref object o, object v)), ????);
            label_37:
            // 0x01C027FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02800: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C02804: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C02808: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01C0280C: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_40);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_40);
            // 0x01C02810: CBNZ x20, #0x1c02818       | if (val_1 != null) goto label_38;       
            if(val_1 != null)
            {
                goto label_38;
            }
            // 0x01C02814: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_38:
            // 0x01C02818: ADRP x9, #0x3600000        | X9 = 56623104 (0x3600000);              
            // 0x01C0281C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01C02820: LDR x9, [x9, #0xe58]       | X9 = (string**)(1152921510122316320)("exp");
            // 0x01C02824: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01C02828: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01C0282C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01C02830: LDR x1, [x9]               | X1 = "exp";                             
            // 0x01C02834: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01C02838: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01C0283C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02840: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01C02844: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02848: LDR x22, [x8, #0x70]       | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheE;
            val_41 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheE;
            // 0x01C0284C: CBNZ x22, #0x1c02898       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheE != null) goto label_39;
            if(val_41 != null)
            {
                goto label_39;
            }
            // 0x01C02850: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
            // 0x01C02854: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01C02858: LDR x8, [x8, #0x460]       | X8 = 1152921510257799312;               
            // 0x01C0285C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01C02860: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_exp_7(ref object o);
            // 0x01C02864: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_16 = null;
            // 0x01C02868: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01C0286C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C02870: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02874: MOV x2, x22                | X2 = 1152921510257799312 (0x1000000150D2B090);//ML01
            // 0x01C02878: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_27 = val_16;
            // 0x01C0287C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_exp_7(ref object o));
            val_16 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_exp_7(ref object o));
            // 0x01C02880: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02884: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02888: STR x23, [x8, #0x70]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheE = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504784273520
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheE = val_27;
            // 0x01C0288C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02890: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02894: LDR x22, [x8, #0x70]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_41 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheE;
            label_39:
            // 0x01C02898: CBNZ x19, #0x1c028a0       | if (X1 != 0) goto label_40;             
            if(X1 != 0)
            {
                goto label_40;
            }
            // 0x01C0289C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_exp_7(ref object o)), ????);
            label_40:
            // 0x01C028A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C028A4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C028A8: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C028AC: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01C028B0: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_41);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_41);
            // 0x01C028B4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C028B8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C028BC: LDR x22, [x8, #0x78]       | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheF;
            val_42 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheF;
            // 0x01C028C0: CBNZ x22, #0x1c0290c       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheF != null) goto label_41;
            if(val_42 != null)
            {
                goto label_41;
            }
            // 0x01C028C4: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x01C028C8: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01C028CC: LDR x8, [x8, #0x540]       | X8 = 1152921510257800336;               
            // 0x01C028D0: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01C028D4: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_exp_7(ref object o, object v);
            // 0x01C028D8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_17 = null;
            // 0x01C028DC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01C028E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C028E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C028E8: MOV x2, x22                | X2 = 1152921510257800336 (0x1000000150D2B490);//ML01
            // 0x01C028EC: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_27 = val_17;
            // 0x01C028F0: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_exp_7(ref object o, object v));
            val_17 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_exp_7(ref object o, object v));
            // 0x01C028F4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C028F8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C028FC: STR x23, [x8, #0x78]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheF = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504784273528
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheF = val_27;
            // 0x01C02900: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02904: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02908: LDR x22, [x8, #0x78]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_42 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cacheF;
            label_41:
            // 0x01C0290C: CBNZ x19, #0x1c02914       | if (X1 != 0) goto label_42;             
            if(X1 != 0)
            {
                goto label_42;
            }
            // 0x01C02910: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_exp_7(ref object o, object v)), ????);
            label_42:
            // 0x01C02914: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02918: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C0291C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C02920: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01C02924: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_42);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_42);
            // 0x01C02928: CBNZ x20, #0x1c02930       | if (val_1 != null) goto label_43;       
            if(val_1 != null)
            {
                goto label_43;
            }
            // 0x01C0292C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_43:
            // 0x01C02930: ADRP x9, #0x35cc000        | X9 = 56410112 (0x35CC000);              
            // 0x01C02934: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01C02938: LDR x9, [x9, #0x660]       | X9 = (string**)(1152921510122453664)("power");
            // 0x01C0293C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01C02940: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01C02944: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01C02948: LDR x1, [x9]               | X1 = "power";                           
            // 0x01C0294C: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01C02950: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01C02954: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02958: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01C0295C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02960: LDR x22, [x8, #0x80]       | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache10;
            val_43 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache10;
            // 0x01C02964: CBNZ x22, #0x1c029b0       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache10 != null) goto label_44;
            if(val_43 != null)
            {
                goto label_44;
            }
            // 0x01C02968: ADRP x8, #0x3678000        | X8 = 57114624 (0x3678000);              
            // 0x01C0296C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01C02970: LDR x8, [x8, #0x2b8]       | X8 = 1152921510257801360;               
            // 0x01C02974: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01C02978: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_power_8(ref object o);
            // 0x01C0297C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_18 = null;
            // 0x01C02980: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01C02984: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C02988: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C0298C: MOV x2, x22                | X2 = 1152921510257801360 (0x1000000150D2B890);//ML01
            // 0x01C02990: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_27 = val_18;
            // 0x01C02994: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_power_8(ref object o));
            val_18 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_power_8(ref object o));
            // 0x01C02998: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C0299C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C029A0: STR x23, [x8, #0x80]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache10 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504784273536
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache10 = val_27;
            // 0x01C029A4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C029A8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C029AC: LDR x22, [x8, #0x80]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_43 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache10;
            label_44:
            // 0x01C029B0: CBNZ x19, #0x1c029b8       | if (X1 != 0) goto label_45;             
            if(X1 != 0)
            {
                goto label_45;
            }
            // 0x01C029B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_power_8(ref object o)), ????);
            label_45:
            // 0x01C029B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C029BC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C029C0: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C029C4: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01C029C8: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_43);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_43);
            // 0x01C029CC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C029D0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C029D4: LDR x22, [x8, #0x88]       | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache11;
            val_44 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache11;
            // 0x01C029D8: CBNZ x22, #0x1c02a24       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache11 != null) goto label_46;
            if(val_44 != null)
            {
                goto label_46;
            }
            // 0x01C029DC: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x01C029E0: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01C029E4: LDR x8, [x8, #0xf70]       | X8 = 1152921510257802384;               
            // 0x01C029E8: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01C029EC: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_power_8(ref object o, object v);
            // 0x01C029F0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_19 = null;
            // 0x01C029F4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01C029F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C029FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02A00: MOV x2, x22                | X2 = 1152921510257802384 (0x1000000150D2BC90);//ML01
            // 0x01C02A04: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_27 = val_19;
            // 0x01C02A08: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_power_8(ref object o, object v));
            val_19 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_power_8(ref object o, object v));
            // 0x01C02A0C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02A10: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02A14: STR x23, [x8, #0x88]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache11 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504784273544
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache11 = val_27;
            // 0x01C02A18: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02A1C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02A20: LDR x22, [x8, #0x88]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_44 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache11;
            label_46:
            // 0x01C02A24: CBNZ x19, #0x1c02a2c       | if (X1 != 0) goto label_47;             
            if(X1 != 0)
            {
                goto label_47;
            }
            // 0x01C02A28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_power_8(ref object o, object v)), ????);
            label_47:
            // 0x01C02A2C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02A30: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C02A34: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C02A38: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01C02A3C: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_44);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_44);
            // 0x01C02A40: CBNZ x20, #0x1c02a48       | if (val_1 != null) goto label_48;       
            if(val_1 != null)
            {
                goto label_48;
            }
            // 0x01C02A44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_48:
            // 0x01C02A48: ADRP x9, #0x3615000        | X9 = 56709120 (0x3615000);              
            // 0x01C02A4C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01C02A50: LDR x9, [x9, #0x1d0]       | X9 = (string**)(1152921510257803408)("serviceId");
            // 0x01C02A54: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01C02A58: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01C02A5C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01C02A60: LDR x1, [x9]               | X1 = "serviceId";                       
            // 0x01C02A64: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01C02A68: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01C02A6C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02A70: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01C02A74: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02A78: LDR x22, [x8, #0x90]       | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache12;
            val_45 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache12;
            // 0x01C02A7C: CBNZ x22, #0x1c02ac8       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache12 != null) goto label_49;
            if(val_45 != null)
            {
                goto label_49;
            }
            // 0x01C02A80: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x01C02A84: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01C02A88: LDR x8, [x8, #0x350]       | X8 = 1152921510257803504;               
            // 0x01C02A8C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01C02A90: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_serviceId_9(ref object o);
            // 0x01C02A94: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_20 = null;
            // 0x01C02A98: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01C02A9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C02AA0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02AA4: MOV x2, x22                | X2 = 1152921510257803504 (0x1000000150D2C0F0);//ML01
            // 0x01C02AA8: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_27 = val_20;
            // 0x01C02AAC: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_serviceId_9(ref object o));
            val_20 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_serviceId_9(ref object o));
            // 0x01C02AB0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02AB4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02AB8: STR x23, [x8, #0x90]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache12 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504784273552
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache12 = val_27;
            // 0x01C02ABC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02AC0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02AC4: LDR x22, [x8, #0x90]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_45 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache12;
            label_49:
            // 0x01C02AC8: CBNZ x19, #0x1c02ad0       | if (X1 != 0) goto label_50;             
            if(X1 != 0)
            {
                goto label_50;
            }
            // 0x01C02ACC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_serviceId_9(ref object o)), ????);
            label_50:
            // 0x01C02AD0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02AD4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C02AD8: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C02ADC: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01C02AE0: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_45);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_45);
            // 0x01C02AE4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02AE8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02AEC: LDR x22, [x8, #0x98]       | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache13;
            val_46 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache13;
            // 0x01C02AF0: CBNZ x22, #0x1c02b3c       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache13 != null) goto label_51;
            if(val_46 != null)
            {
                goto label_51;
            }
            // 0x01C02AF4: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x01C02AF8: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01C02AFC: LDR x8, [x8, #0xcc0]       | X8 = 1152921510257804528;               
            // 0x01C02B00: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01C02B04: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_serviceId_9(ref object o, object v);
            // 0x01C02B08: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_21 = null;
            // 0x01C02B0C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01C02B10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C02B14: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02B18: MOV x2, x22                | X2 = 1152921510257804528 (0x1000000150D2C4F0);//ML01
            // 0x01C02B1C: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_27 = val_21;
            // 0x01C02B20: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_serviceId_9(ref object o, object v));
            val_21 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_serviceId_9(ref object o, object v));
            // 0x01C02B24: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02B28: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02B2C: STR x23, [x8, #0x98]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache13 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504784273560
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache13 = val_27;
            // 0x01C02B30: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02B34: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02B38: LDR x22, [x8, #0x98]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_46 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache13;
            label_51:
            // 0x01C02B3C: CBNZ x19, #0x1c02b44       | if (X1 != 0) goto label_52;             
            if(X1 != 0)
            {
                goto label_52;
            }
            // 0x01C02B40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_serviceId_9(ref object o, object v)), ????);
            label_52:
            // 0x01C02B44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02B48: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C02B4C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C02B50: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01C02B54: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_46);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_46);
            // 0x01C02B58: CBNZ x20, #0x1c02b60       | if (val_1 != null) goto label_53;       
            if(val_1 != null)
            {
                goto label_53;
            }
            // 0x01C02B5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_53:
            // 0x01C02B60: ADRP x9, #0x367d000        | X9 = 57135104 (0x367D000);              
            // 0x01C02B64: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01C02B68: LDR x9, [x9, #0x558]       | X9 = (string**)(1152921510257805552)("serviceName");
            // 0x01C02B6C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01C02B70: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01C02B74: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01C02B78: LDR x1, [x9]               | X1 = "serviceName";                     
            // 0x01C02B7C: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01C02B80: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01C02B84: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02B88: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01C02B8C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02B90: LDR x22, [x8, #0xa0]       | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache14;
            val_47 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache14;
            // 0x01C02B94: CBNZ x22, #0x1c02be0       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache14 != null) goto label_54;
            if(val_47 != null)
            {
                goto label_54;
            }
            // 0x01C02B98: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
            // 0x01C02B9C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01C02BA0: LDR x8, [x8, #0x1a8]       | X8 = 1152921510257805648;               
            // 0x01C02BA4: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01C02BA8: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_serviceName_10(ref object o);
            // 0x01C02BAC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_22 = null;
            // 0x01C02BB0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01C02BB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C02BB8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02BBC: MOV x2, x22                | X2 = 1152921510257805648 (0x1000000150D2C950);//ML01
            // 0x01C02BC0: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_27 = val_22;
            // 0x01C02BC4: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_serviceName_10(ref object o));
            val_22 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_serviceName_10(ref object o));
            // 0x01C02BC8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02BCC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02BD0: STR x23, [x8, #0xa0]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache14 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504784273568
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache14 = val_27;
            // 0x01C02BD4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02BD8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02BDC: LDR x22, [x8, #0xa0]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_47 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache14;
            label_54:
            // 0x01C02BE0: CBNZ x19, #0x1c02be8       | if (X1 != 0) goto label_55;             
            if(X1 != 0)
            {
                goto label_55;
            }
            // 0x01C02BE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_serviceName_10(ref object o)), ????);
            label_55:
            // 0x01C02BE8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02BEC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C02BF0: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C02BF4: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01C02BF8: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_47);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_47);
            // 0x01C02BFC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02C00: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02C04: LDR x22, [x8, #0xa8]       | X22 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache15;
            val_48 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache15;
            // 0x01C02C08: CBNZ x22, #0x1c02c54       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache15 != null) goto label_56;
            if(val_48 != null)
            {
                goto label_56;
            }
            // 0x01C02C0C: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x01C02C10: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01C02C14: LDR x8, [x8, #0x308]       | X8 = 1152921510257806672;               
            // 0x01C02C18: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01C02C1C: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_serviceName_10(ref object o, object v);
            // 0x01C02C20: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_23 = null;
            // 0x01C02C24: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01C02C28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C02C2C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02C30: MOV x2, x22                | X2 = 1152921510257806672 (0x1000000150D2CD50);//ML01
            // 0x01C02C34: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_27 = val_23;
            // 0x01C02C38: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_serviceName_10(ref object o, object v));
            val_23 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_serviceName_10(ref object o, object v));
            // 0x01C02C3C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02C40: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02C44: STR x23, [x8, #0xa8]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache15 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504784273576
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache15 = val_27;
            // 0x01C02C48: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02C4C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02C50: LDR x22, [x8, #0xa8]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_48 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache15;
            label_56:
            // 0x01C02C54: CBNZ x19, #0x1c02c5c       | if (X1 != 0) goto label_57;             
            if(X1 != 0)
            {
                goto label_57;
            }
            // 0x01C02C58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_serviceName_10(ref object o, object v)), ????);
            label_57:
            // 0x01C02C5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02C60: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C02C64: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01C02C68: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01C02C6C: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_48);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_48);
            // 0x01C02C70: CBNZ x20, #0x1c02c78       | if (val_1 != null) goto label_58;       
            if(val_1 != null)
            {
                goto label_58;
            }
            // 0x01C02C74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_58:
            // 0x01C02C78: ADRP x9, #0x3636000        | X9 = 56844288 (0x3636000);              
            // 0x01C02C7C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01C02C80: LDR x9, [x9, #0xa98]       | X9 = (string**)(1152921510257807696)("heroGroups");
            // 0x01C02C84: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01C02C88: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01C02C8C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01C02C90: LDR x1, [x9]               | X1 = "heroGroups";                      
            // 0x01C02C94: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01C02C98: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01C02C9C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02CA0: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x01C02CA4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02CA8: LDR x21, [x8, #0xb0]       | X21 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache16;
            val_49 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache16;
            // 0x01C02CAC: CBNZ x21, #0x1c02cf8       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache16 != null) goto label_59;
            if(val_49 != null)
            {
                goto label_59;
            }
            // 0x01C02CB0: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x01C02CB4: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01C02CB8: LDR x8, [x8, #0x418]       | X8 = 1152921510257807792;               
            // 0x01C02CBC: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01C02CC0: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_heroGroups_11(ref object o);
            // 0x01C02CC4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_24 = null;
            // 0x01C02CC8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01C02CCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C02CD0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02CD4: MOV x2, x21                | X2 = 1152921510257807792 (0x1000000150D2D1B0);//ML01
            // 0x01C02CD8: MOV x22, x0                | X22 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01C02CDC: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_heroGroups_11(ref object o));
            val_24 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_heroGroups_11(ref object o));
            // 0x01C02CE0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02CE4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02CE8: STR x22, [x8, #0xb0]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache16 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504784273584
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache16 = val_24;
            // 0x01C02CEC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02CF0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02CF4: LDR x21, [x8, #0xb0]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_49 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache16;
            label_59:
            // 0x01C02CF8: CBNZ x19, #0x1c02d00       | if (X1 != 0) goto label_60;             
            if(X1 != 0)
            {
                goto label_60;
            }
            // 0x01C02CFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::get_heroGroups_11(ref object o)), ????);
            label_60:
            // 0x01C02D00: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02D04: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C02D08: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x01C02D0C: MOV x2, x21                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01C02D10: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_49);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_49);
            // 0x01C02D14: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02D18: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02D1C: LDR x21, [x8, #0xb8]       | X21 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache17;
            val_50 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache17;
            // 0x01C02D20: CBNZ x21, #0x1c02d6c       | if (ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache17 != null) goto label_61;
            if(val_50 != null)
            {
                goto label_61;
            }
            // 0x01C02D24: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01C02D28: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01C02D2C: LDR x8, [x8, #0x500]       | X8 = 1152921510257808816;               
            // 0x01C02D30: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01C02D34: LDR x21, [x8]              | X21 = static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_heroGroups_11(ref object o, object v);
            // 0x01C02D38: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_25 = null;
            // 0x01C02D3C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01C02D40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C02D44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02D48: MOV x2, x21                | X2 = 1152921510257808816 (0x1000000150D2D5B0);//ML01
            // 0x01C02D4C: MOV x22, x0                | X22 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01C02D50: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_heroGroups_11(ref object o, object v));
            val_25 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_heroGroups_11(ref object o, object v));
            // 0x01C02D54: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02D58: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02D5C: STR x22, [x8, #0xb8]       | ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache17 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504784273592
            ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache17 = val_25;
            // 0x01C02D60: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CSAISPlayerData_Binding);
            // 0x01C02D64: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C02D68: LDR x21, [x8, #0xb8]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_50 = ILRuntime.Runtime.Generated.CSAISPlayerData_Binding.<>f__mg$cache17;
            label_61:
            // 0x01C02D6C: CBNZ x19, #0x1c02d74       | if (X1 != 0) goto label_62;             
            if(X1 != 0)
            {
                goto label_62;
            }
            // 0x01C02D70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CSAISPlayerData_Binding::set_heroGroups_11(ref object o, object v)), ????);
            label_62:
            // 0x01C02D74: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C02D78: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x01C02D7C: MOV x2, x21                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01C02D80: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01C02D84: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01C02D88: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01C02D8C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C02D90: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01C02D94: B #0x28e59c8               | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_50); return;
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_50);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C02D98 (29371800), len: 312  VirtAddr: 0x01C02D98 RVA: 0x01C02D98 token: 100665092 methodIndex: 31141 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_roleId_0(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01C02D98: STP x20, x19, [sp, #-0x20]! | stack[1152921510257950112] = ???;  stack[1152921510257950120] = ???;  //  dest_result_addr=1152921510257950112 |  dest_result_addr=1152921510257950120
            // 0x01C02D9C: STP x29, x30, [sp, #0x10]  | stack[1152921510257950128] = ???;  stack[1152921510257950136] = ???;  //  dest_result_addr=1152921510257950128 |  dest_result_addr=1152921510257950136
            // 0x01C02DA0: ADD x29, sp, #0x10         | X29 = (1152921510257950112 + 16) = 1152921510257950128 (0x1000000150D4FDB0);
            // 0x01C02DA4: SUB sp, sp, #0x20          | SP = (1152921510257950112 - 32) = 1152921510257950080 (0x1000000150D4FD80);
            // 0x01C02DA8: ADRP x20, #0x373c000       | X20 = 57917440 (0x373C000);             
            // 0x01C02DAC: LDRB w8, [x20, #0x25f]     | W8 = (bool)static_value_0373C25F;       
            // 0x01C02DB0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01C02DB4: TBNZ w8, #0, #0x1c02dd0    | if (static_value_0373C25F == true) goto label_0;
            // 0x01C02DB8: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
            // 0x01C02DBC: LDR x8, [x8, #0xb28]       | X8 = 0x2B92F20;                         
            // 0x01C02DC0: LDR w0, [x8]               | W0 = 0x228D;                            
            // 0x01C02DC4: BL #0x2782188              | X0 = sub_2782188( ?? 0x228D, ????);     
            // 0x01C02DC8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C02DCC: STRB w8, [x20, #0x25f]     | static_value_0373C25F = true;            //  dest_result_addr=57918047
            label_0:
            // 0x01C02DD0: ADRP x20, #0x35cd000       | X20 = 56414208 (0x35CD000);             
            // 0x01C02DD4: LDR x19, [x19]             | X19 = X1;                               
            // 0x01C02DD8: LDR x20, [x20, #0xd70]     | X20 = 1152921504904503296;              
            // 0x01C02DDC: CBZ x19, #0x1c02e30        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01C02DE0: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C02DE4: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C02DE8: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C02DEC: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C02DF0: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C02DF4: B.LO #0x1c02e0c            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C02DF8: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C02DFC: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C02E00: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C02E04: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C02E08: B.EQ #0x1c02e34            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C02E0C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C02E10: ADD x8, sp, #0x10          | X8 = (1152921510257950080 + 16) = 1152921510257950096 (0x1000000150D4FD90);
            // 0x01C02E14: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C02E18: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510257938144]
            // 0x01C02E1C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C02E20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C02E24: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C02E28: ADD x0, sp, #0x10          | X0 = (1152921510257950080 + 16) = 1152921510257950096 (0x1000000150D4FD90);
            // 0x01C02E2C: BL #0x299a140              | 
            label_1:
            // 0x01C02E30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150D4FD90, ????);
            label_3:
            // 0x01C02E34: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C02E38: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C02E3C: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C02E40: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C02E44: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C02E48: B.LO #0x1c02e8c            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01C02E4C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C02E50: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C02E54: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C02E58: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C02E5C: B.NE #0x1c02e8c            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01C02E60: ADRP x9, #0x35e2000        | X9 = 56500224 (0x35E2000);              
            // 0x01C02E64: LDR w8, [x19, #0x10]       | W8 = X1 + 16;                           
            // 0x01C02E68: LDR x9, [x9, #0xe18]       | X9 = 1152921504607645696;               
            // 0x01C02E6C: ADD x1, sp, #0xc           | X1 = (1152921510257950080 + 12) = 1152921510257950092 (0x1000000150D4FD8C);
            // 0x01C02E70: STR w8, [sp, #0xc]         | stack[1152921510257950092] = X1 + 16;    //  dest_result_addr=1152921510257950092
            // 0x01C02E74: LDR x0, [x9]               | X0 = typeof(System.UInt32);             
            // 0x01C02E78: BL #0x27bc028              | X0 = 1152921510257998160 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.UInt32), X1 + 16);
            // 0x01C02E7C: SUB sp, x29, #0x10         | SP = (1152921510257950128 - 16) = 1152921510257950112 (0x1000000150D4FDA0);
            // 0x01C02E80: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01C02E84: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01C02E88: RET                        |  return (System.Object)X1 + 16;         
            return (object)X1 + 16;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01C02E8C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C02E90: ADD x8, sp, #0x18          | X8 = (1152921510257950080 + 24) = 1152921510257950104 (0x1000000150D4FD98);
            // 0x01C02E94: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C02E98: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510257938144]
            // 0x01C02E9C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C02EA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C02EA4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C02EA8: ADD x0, sp, #0x18          | X0 = (1152921510257950080 + 24) = 1152921510257950104 (0x1000000150D4FD98);
            // 0x01C02EAC: BL #0x299a140              | 
            // 0x01C02EB0: MOV x19, x0                | X19 = 1152921510257950104 (0x1000000150D4FD98);//ML01
            // 0x01C02EB4: ADD x0, sp, #0x10          | X0 = (1152921510257950080 + 16) = 1152921510257950096 (0x1000000150D4FD90);
            label_6:
            // 0x01C02EB8: BL #0x299a140              | 
            // 0x01C02EBC: MOV x0, x19                | X0 = 1152921510257950104 (0x1000000150D4FD98);//ML01
            // 0x01C02EC0: BL #0x980800               | X0 = sub_980800( ?? 0x1000000150D4FD98, ????);
            // 0x01C02EC4: MOV x19, x0                | X19 = 1152921510257950104 (0x1000000150D4FD98);//ML01
            // 0x01C02EC8: ADD x0, sp, #0x18          | X0 = (1152921510257950080 + 24) = 1152921510257950104 (0x1000000150D4FD98);
            // 0x01C02ECC: B #0x1c02eb8               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C02ED0 (29372112), len: 412  VirtAddr: 0x01C02ED0 RVA: 0x01C02ED0 token: 100665093 methodIndex: 31142 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_roleId_0(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x01C02ED0: STP x22, x21, [sp, #-0x30]! | stack[1152921510258078320] = ???;  stack[1152921510258078328] = ???;  //  dest_result_addr=1152921510258078320 |  dest_result_addr=1152921510258078328
            // 0x01C02ED4: STP x20, x19, [sp, #0x10]  | stack[1152921510258078336] = ???;  stack[1152921510258078344] = ???;  //  dest_result_addr=1152921510258078336 |  dest_result_addr=1152921510258078344
            // 0x01C02ED8: STP x29, x30, [sp, #0x20]  | stack[1152921510258078352] = ???;  stack[1152921510258078360] = ???;  //  dest_result_addr=1152921510258078352 |  dest_result_addr=1152921510258078360
            // 0x01C02EDC: ADD x29, sp, #0x20         | X29 = (1152921510258078320 + 32) = 1152921510258078352 (0x1000000150D6F290);
            // 0x01C02EE0: SUB sp, sp, #0x20          | SP = (1152921510258078320 - 32) = 1152921510258078288 (0x1000000150D6F250);
            // 0x01C02EE4: ADRP x21, #0x373c000       | X21 = 57917440 (0x373C000);             
            // 0x01C02EE8: LDRB w8, [x21, #0x260]     | W8 = (bool)static_value_0373C260;       
            // 0x01C02EEC: MOV x19, x2                | X19 = X2;//m1                           
            // 0x01C02EF0: MOV x20, x1                | X20 = v;//m1                            
            // 0x01C02EF4: TBNZ w8, #0, #0x1c02f10    | if (static_value_0373C260 == true) goto label_0;
            // 0x01C02EF8: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
            // 0x01C02EFC: LDR x8, [x8, #0xb58]       | X8 = 0x2B92F54;                         
            // 0x01C02F00: LDR w0, [x8]               | W0 = 0x229A;                            
            // 0x01C02F04: BL #0x2782188              | X0 = sub_2782188( ?? 0x229A, ????);     
            // 0x01C02F08: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C02F0C: STRB w8, [x21, #0x260]     | static_value_0373C260 = true;            //  dest_result_addr=57918048
            label_0:
            // 0x01C02F10: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x01C02F14: CBZ x21, #0x1c02fc8        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01C02F18: ADRP x20, #0x35cd000       | X20 = 56414208 (0x35CD000);             
            // 0x01C02F1C: LDR x20, [x20, #0xd70]     | X20 = 1152921504904503296;              
            // 0x01C02F20: LDR x8, [x21]              | X8 = ;                                  
            // 0x01C02F24: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C02F28: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C02F2C: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C02F30: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C02F34: B.LO #0x1c02f4c            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C02F38: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C02F3C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C02F40: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C02F44: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C02F48: B.EQ #0x1c02f74            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C02F4C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C02F50: ADD x8, sp, #8             | X8 = (1152921510258078288 + 8) = 1152921510258078296 (0x1000000150D6F258);
            // 0x01C02F54: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C02F58: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510258066368]
            // 0x01C02F5C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C02F60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C02F64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C02F68: ADD x0, sp, #8             | X0 = (1152921510258078288 + 8) = 1152921510258078296 (0x1000000150D6F258);
            // 0x01C02F6C: BL #0x299a140              | 
            // 0x01C02F70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150D6F258, ????);
            label_3:
            // 0x01C02F74: LDR x8, [x21]              | X8 = ;                                  
            // 0x01C02F78: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C02F7C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C02F80: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C02F84: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C02F88: B.LO #0x1c02fa0            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01C02F8C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C02F90: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C02F94: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C02F98: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C02F9C: B.EQ #0x1c02fd0            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01C02FA0: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C02FA4: ADD x8, sp, #0x10          | X8 = (1152921510258078288 + 16) = 1152921510258078304 (0x1000000150D6F260);
            // 0x01C02FA8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C02FAC: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510258066368]
            // 0x01C02FB0: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C02FB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C02FB8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C02FBC: ADD x0, sp, #0x10          | X0 = (1152921510258078288 + 16) = 1152921510258078304 (0x1000000150D6F260);
            // 0x01C02FC0: BL #0x299a140              | 
            // 0x01C02FC4: B #0x1c02fcc               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01C02FC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x229A, ????);     
            label_6:
            // 0x01C02FCC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x01C02FD0: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x01C02FD4: LDR x8, [x8, #0xe18]       | X8 = 1152921504607645696;               
            // 0x01C02FD8: LDR x20, [x8]              | X20 = typeof(System.UInt32);            
            // 0x01C02FDC: CBNZ x19, #0x1c02fe4       | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x01C02FE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x229A, ????);     
            label_7:
            // 0x01C02FE4: LDR x8, [x19]              | X8 = X2;                                
            // 0x01C02FE8: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01C02FEC: LDR x8, [x20, #0x30]       | X8 = System.UInt32.__il2cppRuntimeField_element_class;
            // 0x01C02FF0: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.UInt32.__il2cppRuntimeField_element_class)
            // 0x01C02FF4: B.NE #0x1c0303c            | if (X2 + 48 != System.UInt32.__il2cppRuntimeField_element_class) goto label_8;
            // 0x01C02FF8: MOV x0, x19                | X0 = X2;//m1                            
            // 0x01C02FFC: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x01C03000: LDR w8, [x0]               | W8 = X2;                                
            // 0x01C03004: STR w8, [x21, #0x10]       | mem[16] = X2;                            //  dest_result_addr=16
            mem[16] = X2;
            // 0x01C03008: SUB sp, x29, #0x20         | SP = (1152921510258078352 - 32) = 1152921510258078320 (0x1000000150D6F270);
            // 0x01C0300C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01C03010: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01C03014: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01C03018: RET                        |  return;                                
            return;
            // 0x01C0301C: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01C03020: ADD x0, sp, #8             | X0 = (1152921510258078368 + 8) = 1152921510258078376 (0x1000000150D6F2A8);
            // 0x01C03024: B #0x1c03030               |  goto label_10;                         
            goto label_10;
            // 0x01C03028: MOV x19, x0                | X19 = 1152921510258078376 (0x1000000150D6F2A8);//ML01
            val_7;
            // 0x01C0302C: ADD x0, sp, #0x10          | X0 = (1152921510258078368 + 16) = 1152921510258078384 (0x1000000150D6F2B0);
            label_10:
            // 0x01C03030: BL #0x299a140              | 
            // 0x01C03034: MOV x0, x19                | X0 = 1152921510258078376 (0x1000000150D6F2A8);//ML01
            // 0x01C03038: BL #0x980800               | X0 = sub_980800( ?? 0x1000000150D6F2A8, ????);
            label_8:
            // 0x01C0303C: ADD x8, sp, #0x18          | X8 = (1152921510258078368 + 24) = 1152921510258078392 (0x1000000150D6F2B8);
            // 0x01C03040: MOV x1, x20                | X1 = X20;//m1                           
            // 0x01C03044: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000150D6F2A8, ????);
            // 0x01C03048: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510258066368]
            // 0x01C0304C: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01C03050: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C03054: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01C03058: ADD x0, sp, #0x18          | X0 = (1152921510258078368 + 24) = 1152921510258078392 (0x1000000150D6F2B8);
            // 0x01C0305C: BL #0x299a140              | 
            // 0x01C03060: MOV x19, x0                | X19 = 1152921510258078392 (0x1000000150D6F2B8);//ML01
            // 0x01C03064: ADD x0, sp, #0x18          | X0 = (1152921510258078368 + 24) = 1152921510258078392 (0x1000000150D6F2B8);
            // 0x01C03068: B #0x1c03030               |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C0306C (29372524), len: 288  VirtAddr: 0x01C0306C RVA: 0x01C0306C token: 100665094 methodIndex: 31143 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_name_1(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01C0306C: STP x20, x19, [sp, #-0x20]! | stack[1152921510258202464] = ???;  stack[1152921510258202472] = ???;  //  dest_result_addr=1152921510258202464 |  dest_result_addr=1152921510258202472
            // 0x01C03070: STP x29, x30, [sp, #0x10]  | stack[1152921510258202480] = ???;  stack[1152921510258202488] = ???;  //  dest_result_addr=1152921510258202480 |  dest_result_addr=1152921510258202488
            // 0x01C03074: ADD x29, sp, #0x10         | X29 = (1152921510258202464 + 16) = 1152921510258202480 (0x1000000150D8D770);
            // 0x01C03078: SUB sp, sp, #0x10          | SP = (1152921510258202464 - 16) = 1152921510258202448 (0x1000000150D8D750);
            // 0x01C0307C: ADRP x20, #0x373c000       | X20 = 57917440 (0x373C000);             
            // 0x01C03080: LDRB w8, [x20, #0x261]     | W8 = (bool)static_value_0373C261;       
            // 0x01C03084: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01C03088: TBNZ w8, #0, #0x1c030a4    | if (static_value_0373C261 == true) goto label_0;
            // 0x01C0308C: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x01C03090: LDR x8, [x8, #0x6f8]       | X8 = 0x2B92F14;                         
            // 0x01C03094: LDR w0, [x8]               | W0 = 0x228A;                            
            // 0x01C03098: BL #0x2782188              | X0 = sub_2782188( ?? 0x228A, ????);     
            // 0x01C0309C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C030A0: STRB w8, [x20, #0x261]     | static_value_0373C261 = true;            //  dest_result_addr=57918049
            label_0:
            // 0x01C030A4: ADRP x20, #0x35cd000       | X20 = 56414208 (0x35CD000);             
            // 0x01C030A8: LDR x19, [x19]             | X19 = X1;                               
            // 0x01C030AC: LDR x20, [x20, #0xd70]     | X20 = 1152921504904503296;              
            // 0x01C030B0: CBZ x19, #0x1c03104        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01C030B4: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C030B8: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C030BC: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C030C0: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C030C4: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C030C8: B.LO #0x1c030e0            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C030CC: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C030D0: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C030D4: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C030D8: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C030DC: B.EQ #0x1c03108            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C030E0: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C030E4: MOV x8, sp                 | X8 = 1152921510258202448 (0x1000000150D8D750);//ML01
            // 0x01C030E8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C030EC: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510258190496]
            // 0x01C030F0: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C030F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C030F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C030FC: MOV x0, sp                 | X0 = 1152921510258202448 (0x1000000150D8D750);//ML01
            // 0x01C03100: BL #0x299a140              | 
            label_1:
            // 0x01C03104: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150D8D750, ????);
            label_3:
            // 0x01C03108: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C0310C: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C03110: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C03114: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C03118: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C0311C: B.LO #0x1c03148            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01C03120: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C03124: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C03128: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C0312C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C03130: B.NE #0x1c03148            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01C03134: LDR x0, [x19, #0x18]       | X0 = X1 + 24;                           
            // 0x01C03138: SUB sp, x29, #0x10         | SP = (1152921510258202480 - 16) = 1152921510258202464 (0x1000000150D8D760);
            // 0x01C0313C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01C03140: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01C03144: RET                        |  return (System.Object)X1 + 24;         
            return (object)X1 + 24;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01C03148: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C0314C: ADD x8, sp, #8             | X8 = (1152921510258202448 + 8) = 1152921510258202456 (0x1000000150D8D758);
            // 0x01C03150: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C03154: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510258190496]
            // 0x01C03158: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C0315C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C03160: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C03164: ADD x0, sp, #8             | X0 = (1152921510258202448 + 8) = 1152921510258202456 (0x1000000150D8D758);
            // 0x01C03168: BL #0x299a140              | 
            // 0x01C0316C: MOV x19, x0                | X19 = 1152921510258202456 (0x1000000150D8D758);//ML01
            // 0x01C03170: MOV x0, sp                 | X0 = 1152921510258202448 (0x1000000150D8D750);//ML01
            label_6:
            // 0x01C03174: BL #0x299a140              | 
            // 0x01C03178: MOV x0, x19                | X0 = 1152921510258202456 (0x1000000150D8D758);//ML01
            // 0x01C0317C: BL #0x980800               | X0 = sub_980800( ?? 0x1000000150D8D758, ????);
            // 0x01C03180: MOV x19, x0                | X19 = 1152921510258202456 (0x1000000150D8D758);//ML01
            // 0x01C03184: ADD x0, sp, #8             | X0 = (1152921510258202448 + 8) = 1152921510258202456 (0x1000000150D8D758);
            // 0x01C03188: B #0x1c03174               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C0318C (29372812), len: 392  VirtAddr: 0x01C0318C RVA: 0x01C0318C token: 100665095 methodIndex: 31144 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_name_1(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x01C0318C: STP x22, x21, [sp, #-0x30]! | stack[1152921510258326576] = ???;  stack[1152921510258326584] = ???;  //  dest_result_addr=1152921510258326576 |  dest_result_addr=1152921510258326584
            // 0x01C03190: STP x20, x19, [sp, #0x10]  | stack[1152921510258326592] = ???;  stack[1152921510258326600] = ???;  //  dest_result_addr=1152921510258326592 |  dest_result_addr=1152921510258326600
            // 0x01C03194: STP x29, x30, [sp, #0x20]  | stack[1152921510258326608] = ???;  stack[1152921510258326616] = ???;  //  dest_result_addr=1152921510258326608 |  dest_result_addr=1152921510258326616
            // 0x01C03198: ADD x29, sp, #0x20         | X29 = (1152921510258326576 + 32) = 1152921510258326608 (0x1000000150DABC50);
            // 0x01C0319C: SUB sp, sp, #0x20          | SP = (1152921510258326576 - 32) = 1152921510258326544 (0x1000000150DABC10);
            // 0x01C031A0: ADRP x21, #0x373c000       | X21 = 57917440 (0x373C000);             
            // 0x01C031A4: LDRB w8, [x21, #0x262]     | W8 = (bool)static_value_0373C262;       
            // 0x01C031A8: MOV x19, x2                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01C031AC: MOV x20, x1                | X20 = v;//m1                            
            // 0x01C031B0: TBNZ w8, #0, #0x1c031cc    | if (static_value_0373C262 == true) goto label_0;
            // 0x01C031B4: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x01C031B8: LDR x8, [x8, #0x398]       | X8 = 0x2B92F48;                         
            // 0x01C031BC: LDR w0, [x8]               | W0 = 0x2297;                            
            // 0x01C031C0: BL #0x2782188              | X0 = sub_2782188( ?? 0x2297, ????);     
            // 0x01C031C4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C031C8: STRB w8, [x21, #0x262]     | static_value_0373C262 = true;            //  dest_result_addr=57918050
            label_0:
            // 0x01C031CC: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x01C031D0: CBZ x20, #0x1c03284        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01C031D4: ADRP x21, #0x35cd000       | X21 = 56414208 (0x35CD000);             
            // 0x01C031D8: LDR x21, [x21, #0xd70]     | X21 = 1152921504904503296;              
            val_6 = 1152921504904503296;
            // 0x01C031DC: LDR x8, [x20]              | X8 = ;                                  
            // 0x01C031E0: LDR x1, [x21]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C031E4: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C031E8: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C031EC: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C031F0: B.LO #0x1c03208            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C031F4: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C031F8: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C031FC: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C03200: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C03204: B.EQ #0x1c03230            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C03208: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C0320C: ADD x8, sp, #8             | X8 = (1152921510258326544 + 8) = 1152921510258326552 (0x1000000150DABC18);
            // 0x01C03210: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C03214: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510258314624]
            // 0x01C03218: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C0321C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C03220: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C03224: ADD x0, sp, #8             | X0 = (1152921510258326544 + 8) = 1152921510258326552 (0x1000000150DABC18);
            // 0x01C03228: BL #0x299a140              | 
            // 0x01C0322C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150DABC18, ????);
            label_3:
            // 0x01C03230: LDR x8, [x20]              | X8 = ;                                  
            // 0x01C03234: LDR x1, [x21]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C03238: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C0323C: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C03240: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C03244: B.LO #0x1c0325c            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01C03248: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C0324C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C03250: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C03254: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C03258: B.EQ #0x1c0328c            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01C0325C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C03260: ADD x8, sp, #0x10          | X8 = (1152921510258326544 + 16) = 1152921510258326560 (0x1000000150DABC20);
            // 0x01C03264: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C03268: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510258314624]
            // 0x01C0326C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C03270: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C03274: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C03278: ADD x0, sp, #0x10          | X0 = (1152921510258326544 + 16) = 1152921510258326560 (0x1000000150DABC20);
            // 0x01C0327C: BL #0x299a140              | 
            // 0x01C03280: B #0x1c03288               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01C03284: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2297, ????);     
            label_6:
            // 0x01C03288: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_5:
            // 0x01C0328C: CBZ x19, #0x1c032cc        | if (X2 == 0) goto label_7;              
            if(val_7 == 0)
            {
                goto label_7;
            }
            // 0x01C03290: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01C03294: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01C03298: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01C0329C: LDR x8, [x19]              | X8 = X2;                                
            // 0x01C032A0: CMP x8, x1                 | STATE = COMPARE(X2, typeof(System.String))
            // 0x01C032A4: B.EQ #0x1c032d0            | if (val_7 == null) goto label_8;        
            if(val_7 == null)
            {
                goto label_8;
            }
            // 0x01C032A8: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01C032AC: ADD x8, sp, #0x18          | X8 = (1152921510258326544 + 24) = 1152921510258326568 (0x1000000150DABC28);
            // 0x01C032B0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x01C032B4: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510258314624]
            // 0x01C032B8: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01C032BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C032C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01C032C4: ADD x0, sp, #0x18          | X0 = (1152921510258326544 + 24) = 1152921510258326568 (0x1000000150DABC28);
            // 0x01C032C8: BL #0x299a140              | 
            label_7:
            // 0x01C032CC: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_8:
            // 0x01C032D0: STR x19, [x20, #0x18]      | mem[24] = 0x0;                           //  dest_result_addr=24
            mem[24] = val_7;
            // 0x01C032D4: SUB sp, x29, #0x20         | SP = (1152921510258326608 - 32) = 1152921510258326576 (0x1000000150DABC30);
            // 0x01C032D8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01C032DC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01C032E0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01C032E4: RET                        |  return;                                
            return;
            // 0x01C032E8: MOV x19, x0                | 
            // 0x01C032EC: ADD x0, sp, #8             | 
            // 0x01C032F0: B #0x1c03308               | 
            // 0x01C032F4: MOV x19, x0                | 
            // 0x01C032F8: ADD x0, sp, #0x10          | 
            // 0x01C032FC: B #0x1c03308               | 
            // 0x01C03300: MOV x19, x0                | 
            // 0x01C03304: ADD x0, sp, #0x18          | 
            label_10:
            // 0x01C03308: BL #0x299a140              | 
            // 0x01C0330C: MOV x0, x19                | 
            // 0x01C03310: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01C03314 (29373204), len: 288  VirtAddr: 0x01C03314 RVA: 0x01C03314 token: 100665096 methodIndex: 31145 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_unionName_2(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01C03314: STP x20, x19, [sp, #-0x20]! | stack[1152921510258450720] = ???;  stack[1152921510258450728] = ???;  //  dest_result_addr=1152921510258450720 |  dest_result_addr=1152921510258450728
            // 0x01C03318: STP x29, x30, [sp, #0x10]  | stack[1152921510258450736] = ???;  stack[1152921510258450744] = ???;  //  dest_result_addr=1152921510258450736 |  dest_result_addr=1152921510258450744
            // 0x01C0331C: ADD x29, sp, #0x10         | X29 = (1152921510258450720 + 16) = 1152921510258450736 (0x1000000150DCA130);
            // 0x01C03320: SUB sp, sp, #0x10          | SP = (1152921510258450720 - 16) = 1152921510258450704 (0x1000000150DCA110);
            // 0x01C03324: ADRP x20, #0x373c000       | X20 = 57917440 (0x373C000);             
            // 0x01C03328: LDRB w8, [x20, #0x263]     | W8 = (bool)static_value_0373C263;       
            // 0x01C0332C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01C03330: TBNZ w8, #0, #0x1c0334c    | if (static_value_0373C263 == true) goto label_0;
            // 0x01C03334: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x01C03338: LDR x8, [x8, #0xa78]       | X8 = 0x2B92F2C;                         
            // 0x01C0333C: LDR w0, [x8]               | W0 = 0x2290;                            
            // 0x01C03340: BL #0x2782188              | X0 = sub_2782188( ?? 0x2290, ????);     
            // 0x01C03344: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C03348: STRB w8, [x20, #0x263]     | static_value_0373C263 = true;            //  dest_result_addr=57918051
            label_0:
            // 0x01C0334C: ADRP x20, #0x35cd000       | X20 = 56414208 (0x35CD000);             
            // 0x01C03350: LDR x19, [x19]             | X19 = X1;                               
            // 0x01C03354: LDR x20, [x20, #0xd70]     | X20 = 1152921504904503296;              
            // 0x01C03358: CBZ x19, #0x1c033ac        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01C0335C: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C03360: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C03364: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C03368: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C0336C: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C03370: B.LO #0x1c03388            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C03374: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C03378: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C0337C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C03380: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C03384: B.EQ #0x1c033b0            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C03388: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C0338C: MOV x8, sp                 | X8 = 1152921510258450704 (0x1000000150DCA110);//ML01
            // 0x01C03390: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C03394: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510258438752]
            // 0x01C03398: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C0339C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C033A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C033A4: MOV x0, sp                 | X0 = 1152921510258450704 (0x1000000150DCA110);//ML01
            // 0x01C033A8: BL #0x299a140              | 
            label_1:
            // 0x01C033AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150DCA110, ????);
            label_3:
            // 0x01C033B0: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C033B4: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C033B8: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C033BC: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C033C0: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C033C4: B.LO #0x1c033f0            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01C033C8: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C033CC: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C033D0: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C033D4: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C033D8: B.NE #0x1c033f0            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01C033DC: LDR x0, [x19, #0x20]       | X0 = X1 + 32;                           
            // 0x01C033E0: SUB sp, x29, #0x10         | SP = (1152921510258450736 - 16) = 1152921510258450720 (0x1000000150DCA120);
            // 0x01C033E4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01C033E8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01C033EC: RET                        |  return (System.Object)X1 + 32;         
            return (object)X1 + 32;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01C033F0: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C033F4: ADD x8, sp, #8             | X8 = (1152921510258450704 + 8) = 1152921510258450712 (0x1000000150DCA118);
            // 0x01C033F8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C033FC: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510258438752]
            // 0x01C03400: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C03404: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C03408: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C0340C: ADD x0, sp, #8             | X0 = (1152921510258450704 + 8) = 1152921510258450712 (0x1000000150DCA118);
            // 0x01C03410: BL #0x299a140              | 
            // 0x01C03414: MOV x19, x0                | X19 = 1152921510258450712 (0x1000000150DCA118);//ML01
            // 0x01C03418: MOV x0, sp                 | X0 = 1152921510258450704 (0x1000000150DCA110);//ML01
            label_6:
            // 0x01C0341C: BL #0x299a140              | 
            // 0x01C03420: MOV x0, x19                | X0 = 1152921510258450712 (0x1000000150DCA118);//ML01
            // 0x01C03424: BL #0x980800               | X0 = sub_980800( ?? 0x1000000150DCA118, ????);
            // 0x01C03428: MOV x19, x0                | X19 = 1152921510258450712 (0x1000000150DCA118);//ML01
            // 0x01C0342C: ADD x0, sp, #8             | X0 = (1152921510258450704 + 8) = 1152921510258450712 (0x1000000150DCA118);
            // 0x01C03430: B #0x1c0341c               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C03434 (29373492), len: 392  VirtAddr: 0x01C03434 RVA: 0x01C03434 token: 100665097 methodIndex: 31146 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_unionName_2(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x01C03434: STP x22, x21, [sp, #-0x30]! | stack[1152921510258574832] = ???;  stack[1152921510258574840] = ???;  //  dest_result_addr=1152921510258574832 |  dest_result_addr=1152921510258574840
            // 0x01C03438: STP x20, x19, [sp, #0x10]  | stack[1152921510258574848] = ???;  stack[1152921510258574856] = ???;  //  dest_result_addr=1152921510258574848 |  dest_result_addr=1152921510258574856
            // 0x01C0343C: STP x29, x30, [sp, #0x20]  | stack[1152921510258574864] = ???;  stack[1152921510258574872] = ???;  //  dest_result_addr=1152921510258574864 |  dest_result_addr=1152921510258574872
            // 0x01C03440: ADD x29, sp, #0x20         | X29 = (1152921510258574832 + 32) = 1152921510258574864 (0x1000000150DE8610);
            // 0x01C03444: SUB sp, sp, #0x20          | SP = (1152921510258574832 - 32) = 1152921510258574800 (0x1000000150DE85D0);
            // 0x01C03448: ADRP x21, #0x373c000       | X21 = 57917440 (0x373C000);             
            // 0x01C0344C: LDRB w8, [x21, #0x264]     | W8 = (bool)static_value_0373C264;       
            // 0x01C03450: MOV x19, x2                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01C03454: MOV x20, x1                | X20 = v;//m1                            
            // 0x01C03458: TBNZ w8, #0, #0x1c03474    | if (static_value_0373C264 == true) goto label_0;
            // 0x01C0345C: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x01C03460: LDR x8, [x8, #0xbe0]       | X8 = 0x2B92F60;                         
            // 0x01C03464: LDR w0, [x8]               | W0 = 0x229D;                            
            // 0x01C03468: BL #0x2782188              | X0 = sub_2782188( ?? 0x229D, ????);     
            // 0x01C0346C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C03470: STRB w8, [x21, #0x264]     | static_value_0373C264 = true;            //  dest_result_addr=57918052
            label_0:
            // 0x01C03474: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x01C03478: CBZ x20, #0x1c0352c        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01C0347C: ADRP x21, #0x35cd000       | X21 = 56414208 (0x35CD000);             
            // 0x01C03480: LDR x21, [x21, #0xd70]     | X21 = 1152921504904503296;              
            val_6 = 1152921504904503296;
            // 0x01C03484: LDR x8, [x20]              | X8 = ;                                  
            // 0x01C03488: LDR x1, [x21]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C0348C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C03490: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C03494: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C03498: B.LO #0x1c034b0            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C0349C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C034A0: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C034A4: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C034A8: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C034AC: B.EQ #0x1c034d8            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C034B0: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C034B4: ADD x8, sp, #8             | X8 = (1152921510258574800 + 8) = 1152921510258574808 (0x1000000150DE85D8);
            // 0x01C034B8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C034BC: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510258562880]
            // 0x01C034C0: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C034C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C034C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C034CC: ADD x0, sp, #8             | X0 = (1152921510258574800 + 8) = 1152921510258574808 (0x1000000150DE85D8);
            // 0x01C034D0: BL #0x299a140              | 
            // 0x01C034D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150DE85D8, ????);
            label_3:
            // 0x01C034D8: LDR x8, [x20]              | X8 = ;                                  
            // 0x01C034DC: LDR x1, [x21]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C034E0: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C034E4: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C034E8: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C034EC: B.LO #0x1c03504            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01C034F0: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C034F4: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C034F8: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C034FC: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C03500: B.EQ #0x1c03534            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01C03504: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C03508: ADD x8, sp, #0x10          | X8 = (1152921510258574800 + 16) = 1152921510258574816 (0x1000000150DE85E0);
            // 0x01C0350C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C03510: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510258562880]
            // 0x01C03514: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C03518: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C0351C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C03520: ADD x0, sp, #0x10          | X0 = (1152921510258574800 + 16) = 1152921510258574816 (0x1000000150DE85E0);
            // 0x01C03524: BL #0x299a140              | 
            // 0x01C03528: B #0x1c03530               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01C0352C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x229D, ????);     
            label_6:
            // 0x01C03530: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_5:
            // 0x01C03534: CBZ x19, #0x1c03574        | if (X2 == 0) goto label_7;              
            if(val_7 == 0)
            {
                goto label_7;
            }
            // 0x01C03538: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01C0353C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01C03540: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01C03544: LDR x8, [x19]              | X8 = X2;                                
            // 0x01C03548: CMP x8, x1                 | STATE = COMPARE(X2, typeof(System.String))
            // 0x01C0354C: B.EQ #0x1c03578            | if (val_7 == null) goto label_8;        
            if(val_7 == null)
            {
                goto label_8;
            }
            // 0x01C03550: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01C03554: ADD x8, sp, #0x18          | X8 = (1152921510258574800 + 24) = 1152921510258574824 (0x1000000150DE85E8);
            // 0x01C03558: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x01C0355C: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510258562880]
            // 0x01C03560: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01C03564: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C03568: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01C0356C: ADD x0, sp, #0x18          | X0 = (1152921510258574800 + 24) = 1152921510258574824 (0x1000000150DE85E8);
            // 0x01C03570: BL #0x299a140              | 
            label_7:
            // 0x01C03574: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_8:
            // 0x01C03578: STR x19, [x20, #0x20]      | mem[32] = 0x0;                           //  dest_result_addr=32
            mem[32] = val_7;
            // 0x01C0357C: SUB sp, x29, #0x20         | SP = (1152921510258574864 - 32) = 1152921510258574832 (0x1000000150DE85F0);
            // 0x01C03580: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01C03584: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01C03588: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01C0358C: RET                        |  return;                                
            return;
            // 0x01C03590: MOV x19, x0                | 
            // 0x01C03594: ADD x0, sp, #8             | 
            // 0x01C03598: B #0x1c035b0               | 
            // 0x01C0359C: MOV x19, x0                | 
            // 0x01C035A0: ADD x0, sp, #0x10          | 
            // 0x01C035A4: B #0x1c035b0               | 
            // 0x01C035A8: MOV x19, x0                | 
            // 0x01C035AC: ADD x0, sp, #0x18          | 
            label_10:
            // 0x01C035B0: BL #0x299a140              | 
            // 0x01C035B4: MOV x0, x19                | 
            // 0x01C035B8: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01C035BC (29373884), len: 288  VirtAddr: 0x01C035BC RVA: 0x01C035BC token: 100665098 methodIndex: 31147 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_icon_3(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01C035BC: STP x20, x19, [sp, #-0x20]! | stack[1152921510258698976] = ???;  stack[1152921510258698984] = ???;  //  dest_result_addr=1152921510258698976 |  dest_result_addr=1152921510258698984
            // 0x01C035C0: STP x29, x30, [sp, #0x10]  | stack[1152921510258698992] = ???;  stack[1152921510258699000] = ???;  //  dest_result_addr=1152921510258698992 |  dest_result_addr=1152921510258699000
            // 0x01C035C4: ADD x29, sp, #0x10         | X29 = (1152921510258698976 + 16) = 1152921510258698992 (0x1000000150E06AF0);
            // 0x01C035C8: SUB sp, sp, #0x10          | SP = (1152921510258698976 - 16) = 1152921510258698960 (0x1000000150E06AD0);
            // 0x01C035CC: ADRP x20, #0x373c000       | X20 = 57917440 (0x373C000);             
            // 0x01C035D0: LDRB w8, [x20, #0x265]     | W8 = (bool)static_value_0373C265;       
            // 0x01C035D4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01C035D8: TBNZ w8, #0, #0x1c035f4    | if (static_value_0373C265 == true) goto label_0;
            // 0x01C035DC: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
            // 0x01C035E0: LDR x8, [x8, #0x90]        | X8 = 0x2B92F0C;                         
            // 0x01C035E4: LDR w0, [x8]               | W0 = 0x2288;                            
            // 0x01C035E8: BL #0x2782188              | X0 = sub_2782188( ?? 0x2288, ????);     
            // 0x01C035EC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C035F0: STRB w8, [x20, #0x265]     | static_value_0373C265 = true;            //  dest_result_addr=57918053
            label_0:
            // 0x01C035F4: ADRP x20, #0x35cd000       | X20 = 56414208 (0x35CD000);             
            // 0x01C035F8: LDR x19, [x19]             | X19 = X1;                               
            // 0x01C035FC: LDR x20, [x20, #0xd70]     | X20 = 1152921504904503296;              
            // 0x01C03600: CBZ x19, #0x1c03654        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01C03604: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C03608: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C0360C: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C03610: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C03614: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C03618: B.LO #0x1c03630            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C0361C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C03620: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C03624: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C03628: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C0362C: B.EQ #0x1c03658            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C03630: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C03634: MOV x8, sp                 | X8 = 1152921510258698960 (0x1000000150E06AD0);//ML01
            // 0x01C03638: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C0363C: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510258687008]
            // 0x01C03640: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C03644: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C03648: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C0364C: MOV x0, sp                 | X0 = 1152921510258698960 (0x1000000150E06AD0);//ML01
            // 0x01C03650: BL #0x299a140              | 
            label_1:
            // 0x01C03654: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150E06AD0, ????);
            label_3:
            // 0x01C03658: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C0365C: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C03660: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C03664: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C03668: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C0366C: B.LO #0x1c03698            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01C03670: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C03674: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C03678: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C0367C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C03680: B.NE #0x1c03698            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01C03684: LDR x0, [x19, #0x28]       | X0 = X1 + 40;                           
            // 0x01C03688: SUB sp, x29, #0x10         | SP = (1152921510258698992 - 16) = 1152921510258698976 (0x1000000150E06AE0);
            // 0x01C0368C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01C03690: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01C03694: RET                        |  return (System.Object)X1 + 40;         
            return (object)X1 + 40;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01C03698: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C0369C: ADD x8, sp, #8             | X8 = (1152921510258698960 + 8) = 1152921510258698968 (0x1000000150E06AD8);
            // 0x01C036A0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C036A4: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510258687008]
            // 0x01C036A8: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C036AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C036B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C036B4: ADD x0, sp, #8             | X0 = (1152921510258698960 + 8) = 1152921510258698968 (0x1000000150E06AD8);
            // 0x01C036B8: BL #0x299a140              | 
            // 0x01C036BC: MOV x19, x0                | X19 = 1152921510258698968 (0x1000000150E06AD8);//ML01
            // 0x01C036C0: MOV x0, sp                 | X0 = 1152921510258698960 (0x1000000150E06AD0);//ML01
            label_6:
            // 0x01C036C4: BL #0x299a140              | 
            // 0x01C036C8: MOV x0, x19                | X0 = 1152921510258698968 (0x1000000150E06AD8);//ML01
            // 0x01C036CC: BL #0x980800               | X0 = sub_980800( ?? 0x1000000150E06AD8, ????);
            // 0x01C036D0: MOV x19, x0                | X19 = 1152921510258698968 (0x1000000150E06AD8);//ML01
            // 0x01C036D4: ADD x0, sp, #8             | X0 = (1152921510258698960 + 8) = 1152921510258698968 (0x1000000150E06AD8);
            // 0x01C036D8: B #0x1c036c4               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C036DC (29374172), len: 392  VirtAddr: 0x01C036DC RVA: 0x01C036DC token: 100665099 methodIndex: 31148 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_icon_3(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x01C036DC: STP x22, x21, [sp, #-0x30]! | stack[1152921510258823088] = ???;  stack[1152921510258823096] = ???;  //  dest_result_addr=1152921510258823088 |  dest_result_addr=1152921510258823096
            // 0x01C036E0: STP x20, x19, [sp, #0x10]  | stack[1152921510258823104] = ???;  stack[1152921510258823112] = ???;  //  dest_result_addr=1152921510258823104 |  dest_result_addr=1152921510258823112
            // 0x01C036E4: STP x29, x30, [sp, #0x20]  | stack[1152921510258823120] = ???;  stack[1152921510258823128] = ???;  //  dest_result_addr=1152921510258823120 |  dest_result_addr=1152921510258823128
            // 0x01C036E8: ADD x29, sp, #0x20         | X29 = (1152921510258823088 + 32) = 1152921510258823120 (0x1000000150E24FD0);
            // 0x01C036EC: SUB sp, sp, #0x20          | SP = (1152921510258823088 - 32) = 1152921510258823056 (0x1000000150E24F90);
            // 0x01C036F0: ADRP x21, #0x373c000       | X21 = 57917440 (0x373C000);             
            // 0x01C036F4: LDRB w8, [x21, #0x266]     | W8 = (bool)static_value_0373C266;       
            // 0x01C036F8: MOV x19, x2                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01C036FC: MOV x20, x1                | X20 = v;//m1                            
            // 0x01C03700: TBNZ w8, #0, #0x1c0371c    | if (static_value_0373C266 == true) goto label_0;
            // 0x01C03704: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01C03708: LDR x8, [x8, #0xe68]       | X8 = 0x2B92F40;                         
            // 0x01C0370C: LDR w0, [x8]               | W0 = 0x2295;                            
            // 0x01C03710: BL #0x2782188              | X0 = sub_2782188( ?? 0x2295, ????);     
            // 0x01C03714: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C03718: STRB w8, [x21, #0x266]     | static_value_0373C266 = true;            //  dest_result_addr=57918054
            label_0:
            // 0x01C0371C: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x01C03720: CBZ x20, #0x1c037d4        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01C03724: ADRP x21, #0x35cd000       | X21 = 56414208 (0x35CD000);             
            // 0x01C03728: LDR x21, [x21, #0xd70]     | X21 = 1152921504904503296;              
            val_6 = 1152921504904503296;
            // 0x01C0372C: LDR x8, [x20]              | X8 = ;                                  
            // 0x01C03730: LDR x1, [x21]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C03734: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C03738: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C0373C: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C03740: B.LO #0x1c03758            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C03744: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C03748: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C0374C: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C03750: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C03754: B.EQ #0x1c03780            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C03758: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C0375C: ADD x8, sp, #8             | X8 = (1152921510258823056 + 8) = 1152921510258823064 (0x1000000150E24F98);
            // 0x01C03760: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C03764: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510258811136]
            // 0x01C03768: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C0376C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C03770: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C03774: ADD x0, sp, #8             | X0 = (1152921510258823056 + 8) = 1152921510258823064 (0x1000000150E24F98);
            // 0x01C03778: BL #0x299a140              | 
            // 0x01C0377C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150E24F98, ????);
            label_3:
            // 0x01C03780: LDR x8, [x20]              | X8 = ;                                  
            // 0x01C03784: LDR x1, [x21]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C03788: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C0378C: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C03790: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C03794: B.LO #0x1c037ac            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01C03798: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C0379C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C037A0: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C037A4: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C037A8: B.EQ #0x1c037dc            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01C037AC: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C037B0: ADD x8, sp, #0x10          | X8 = (1152921510258823056 + 16) = 1152921510258823072 (0x1000000150E24FA0);
            // 0x01C037B4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C037B8: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510258811136]
            // 0x01C037BC: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C037C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C037C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C037C8: ADD x0, sp, #0x10          | X0 = (1152921510258823056 + 16) = 1152921510258823072 (0x1000000150E24FA0);
            // 0x01C037CC: BL #0x299a140              | 
            // 0x01C037D0: B #0x1c037d8               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01C037D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2295, ????);     
            label_6:
            // 0x01C037D8: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_5:
            // 0x01C037DC: CBZ x19, #0x1c0381c        | if (X2 == 0) goto label_7;              
            if(val_7 == 0)
            {
                goto label_7;
            }
            // 0x01C037E0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01C037E4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01C037E8: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01C037EC: LDR x8, [x19]              | X8 = X2;                                
            // 0x01C037F0: CMP x8, x1                 | STATE = COMPARE(X2, typeof(System.String))
            // 0x01C037F4: B.EQ #0x1c03820            | if (val_7 == null) goto label_8;        
            if(val_7 == null)
            {
                goto label_8;
            }
            // 0x01C037F8: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01C037FC: ADD x8, sp, #0x18          | X8 = (1152921510258823056 + 24) = 1152921510258823080 (0x1000000150E24FA8);
            // 0x01C03800: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x01C03804: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510258811136]
            // 0x01C03808: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01C0380C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C03810: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01C03814: ADD x0, sp, #0x18          | X0 = (1152921510258823056 + 24) = 1152921510258823080 (0x1000000150E24FA8);
            // 0x01C03818: BL #0x299a140              | 
            label_7:
            // 0x01C0381C: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_8:
            // 0x01C03820: STR x19, [x20, #0x28]      | mem[40] = 0x0;                           //  dest_result_addr=40
            mem[40] = val_7;
            // 0x01C03824: SUB sp, x29, #0x20         | SP = (1152921510258823120 - 32) = 1152921510258823088 (0x1000000150E24FB0);
            // 0x01C03828: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01C0382C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01C03830: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01C03834: RET                        |  return;                                
            return;
            // 0x01C03838: MOV x19, x0                | 
            // 0x01C0383C: ADD x0, sp, #8             | 
            // 0x01C03840: B #0x1c03858               | 
            // 0x01C03844: MOV x19, x0                | 
            // 0x01C03848: ADD x0, sp, #0x10          | 
            // 0x01C0384C: B #0x1c03858               | 
            // 0x01C03850: MOV x19, x0                | 
            // 0x01C03854: ADD x0, sp, #0x18          | 
            label_10:
            // 0x01C03858: BL #0x299a140              | 
            // 0x01C0385C: MOV x0, x19                | 
            // 0x01C03860: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01C03864 (29374564), len: 312  VirtAddr: 0x01C03864 RVA: 0x01C03864 token: 100665100 methodIndex: 31149 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_rank_4(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01C03864: STP x20, x19, [sp, #-0x20]! | stack[1152921510258951328] = ???;  stack[1152921510258951336] = ???;  //  dest_result_addr=1152921510258951328 |  dest_result_addr=1152921510258951336
            // 0x01C03868: STP x29, x30, [sp, #0x10]  | stack[1152921510258951344] = ???;  stack[1152921510258951352] = ???;  //  dest_result_addr=1152921510258951344 |  dest_result_addr=1152921510258951352
            // 0x01C0386C: ADD x29, sp, #0x10         | X29 = (1152921510258951328 + 16) = 1152921510258951344 (0x1000000150E444B0);
            // 0x01C03870: SUB sp, sp, #0x20          | SP = (1152921510258951328 - 32) = 1152921510258951296 (0x1000000150E44480);
            // 0x01C03874: ADRP x20, #0x373c000       | X20 = 57917440 (0x373C000);             
            // 0x01C03878: LDRB w8, [x20, #0x267]     | W8 = (bool)static_value_0373C267;       
            // 0x01C0387C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01C03880: TBNZ w8, #0, #0x1c0389c    | if (static_value_0373C267 == true) goto label_0;
            // 0x01C03884: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x01C03888: LDR x8, [x8, #0xb8]        | X8 = 0x2B92F1C;                         
            // 0x01C0388C: LDR w0, [x8]               | W0 = 0x228C;                            
            // 0x01C03890: BL #0x2782188              | X0 = sub_2782188( ?? 0x228C, ????);     
            // 0x01C03894: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C03898: STRB w8, [x20, #0x267]     | static_value_0373C267 = true;            //  dest_result_addr=57918055
            label_0:
            // 0x01C0389C: ADRP x20, #0x35cd000       | X20 = 56414208 (0x35CD000);             
            // 0x01C038A0: LDR x19, [x19]             | X19 = X1;                               
            // 0x01C038A4: LDR x20, [x20, #0xd70]     | X20 = 1152921504904503296;              
            // 0x01C038A8: CBZ x19, #0x1c038fc        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01C038AC: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C038B0: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C038B4: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C038B8: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C038BC: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C038C0: B.LO #0x1c038d8            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C038C4: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C038C8: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C038CC: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C038D0: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C038D4: B.EQ #0x1c03900            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C038D8: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C038DC: ADD x8, sp, #0x10          | X8 = (1152921510258951296 + 16) = 1152921510258951312 (0x1000000150E44490);
            // 0x01C038E0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C038E4: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510258939360]
            // 0x01C038E8: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C038EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C038F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C038F4: ADD x0, sp, #0x10          | X0 = (1152921510258951296 + 16) = 1152921510258951312 (0x1000000150E44490);
            // 0x01C038F8: BL #0x299a140              | 
            label_1:
            // 0x01C038FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150E44490, ????);
            label_3:
            // 0x01C03900: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C03904: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C03908: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C0390C: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C03910: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C03914: B.LO #0x1c03958            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01C03918: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C0391C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C03920: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C03924: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C03928: B.NE #0x1c03958            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01C0392C: ADRP x9, #0x35e2000        | X9 = 56500224 (0x35E2000);              
            // 0x01C03930: LDR w8, [x19, #0x30]       | W8 = X1 + 48;                           
            // 0x01C03934: LDR x9, [x9, #0xe18]       | X9 = 1152921504607645696;               
            // 0x01C03938: ADD x1, sp, #0xc           | X1 = (1152921510258951296 + 12) = 1152921510258951308 (0x1000000150E4448C);
            // 0x01C0393C: STR w8, [sp, #0xc]         | stack[1152921510258951308] = X1 + 48;    //  dest_result_addr=1152921510258951308
            // 0x01C03940: LDR x0, [x9]               | X0 = typeof(System.UInt32);             
            // 0x01C03944: BL #0x27bc028              | X0 = 1152921510258999376 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.UInt32), X1 + 48);
            // 0x01C03948: SUB sp, x29, #0x10         | SP = (1152921510258951344 - 16) = 1152921510258951328 (0x1000000150E444A0);
            // 0x01C0394C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01C03950: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01C03954: RET                        |  return (System.Object)X1 + 48;         
            return (object)X1 + 48;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01C03958: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C0395C: ADD x8, sp, #0x18          | X8 = (1152921510258951296 + 24) = 1152921510258951320 (0x1000000150E44498);
            // 0x01C03960: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C03964: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510258939360]
            // 0x01C03968: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C0396C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C03970: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C03974: ADD x0, sp, #0x18          | X0 = (1152921510258951296 + 24) = 1152921510258951320 (0x1000000150E44498);
            // 0x01C03978: BL #0x299a140              | 
            // 0x01C0397C: MOV x19, x0                | X19 = 1152921510258951320 (0x1000000150E44498);//ML01
            // 0x01C03980: ADD x0, sp, #0x10          | X0 = (1152921510258951296 + 16) = 1152921510258951312 (0x1000000150E44490);
            label_6:
            // 0x01C03984: BL #0x299a140              | 
            // 0x01C03988: MOV x0, x19                | X0 = 1152921510258951320 (0x1000000150E44498);//ML01
            // 0x01C0398C: BL #0x980800               | X0 = sub_980800( ?? 0x1000000150E44498, ????);
            // 0x01C03990: MOV x19, x0                | X19 = 1152921510258951320 (0x1000000150E44498);//ML01
            // 0x01C03994: ADD x0, sp, #0x18          | X0 = (1152921510258951296 + 24) = 1152921510258951320 (0x1000000150E44498);
            // 0x01C03998: B #0x1c03984               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C0399C (29374876), len: 412  VirtAddr: 0x01C0399C RVA: 0x01C0399C token: 100665101 methodIndex: 31150 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_rank_4(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x01C0399C: STP x22, x21, [sp, #-0x30]! | stack[1152921510259079536] = ???;  stack[1152921510259079544] = ???;  //  dest_result_addr=1152921510259079536 |  dest_result_addr=1152921510259079544
            // 0x01C039A0: STP x20, x19, [sp, #0x10]  | stack[1152921510259079552] = ???;  stack[1152921510259079560] = ???;  //  dest_result_addr=1152921510259079552 |  dest_result_addr=1152921510259079560
            // 0x01C039A4: STP x29, x30, [sp, #0x20]  | stack[1152921510259079568] = ???;  stack[1152921510259079576] = ???;  //  dest_result_addr=1152921510259079568 |  dest_result_addr=1152921510259079576
            // 0x01C039A8: ADD x29, sp, #0x20         | X29 = (1152921510259079536 + 32) = 1152921510259079568 (0x1000000150E63990);
            // 0x01C039AC: SUB sp, sp, #0x20          | SP = (1152921510259079536 - 32) = 1152921510259079504 (0x1000000150E63950);
            // 0x01C039B0: ADRP x21, #0x373c000       | X21 = 57917440 (0x373C000);             
            // 0x01C039B4: LDRB w8, [x21, #0x268]     | W8 = (bool)static_value_0373C268;       
            // 0x01C039B8: MOV x19, x2                | X19 = X2;//m1                           
            // 0x01C039BC: MOV x20, x1                | X20 = v;//m1                            
            // 0x01C039C0: TBNZ w8, #0, #0x1c039dc    | if (static_value_0373C268 == true) goto label_0;
            // 0x01C039C4: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x01C039C8: LDR x8, [x8, #0xb58]       | X8 = 0x2B92F50;                         
            // 0x01C039CC: LDR w0, [x8]               | W0 = 0x2299;                            
            // 0x01C039D0: BL #0x2782188              | X0 = sub_2782188( ?? 0x2299, ????);     
            // 0x01C039D4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C039D8: STRB w8, [x21, #0x268]     | static_value_0373C268 = true;            //  dest_result_addr=57918056
            label_0:
            // 0x01C039DC: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x01C039E0: CBZ x21, #0x1c03a94        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01C039E4: ADRP x20, #0x35cd000       | X20 = 56414208 (0x35CD000);             
            // 0x01C039E8: LDR x20, [x20, #0xd70]     | X20 = 1152921504904503296;              
            // 0x01C039EC: LDR x8, [x21]              | X8 = ;                                  
            // 0x01C039F0: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C039F4: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C039F8: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C039FC: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C03A00: B.LO #0x1c03a18            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C03A04: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C03A08: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C03A0C: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C03A10: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C03A14: B.EQ #0x1c03a40            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C03A18: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C03A1C: ADD x8, sp, #8             | X8 = (1152921510259079504 + 8) = 1152921510259079512 (0x1000000150E63958);
            // 0x01C03A20: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C03A24: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510259067584]
            // 0x01C03A28: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C03A2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C03A30: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C03A34: ADD x0, sp, #8             | X0 = (1152921510259079504 + 8) = 1152921510259079512 (0x1000000150E63958);
            // 0x01C03A38: BL #0x299a140              | 
            // 0x01C03A3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150E63958, ????);
            label_3:
            // 0x01C03A40: LDR x8, [x21]              | X8 = ;                                  
            // 0x01C03A44: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C03A48: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C03A4C: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C03A50: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C03A54: B.LO #0x1c03a6c            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01C03A58: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C03A5C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C03A60: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C03A64: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C03A68: B.EQ #0x1c03a9c            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01C03A6C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C03A70: ADD x8, sp, #0x10          | X8 = (1152921510259079504 + 16) = 1152921510259079520 (0x1000000150E63960);
            // 0x01C03A74: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C03A78: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510259067584]
            // 0x01C03A7C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C03A80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C03A84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C03A88: ADD x0, sp, #0x10          | X0 = (1152921510259079504 + 16) = 1152921510259079520 (0x1000000150E63960);
            // 0x01C03A8C: BL #0x299a140              | 
            // 0x01C03A90: B #0x1c03a98               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01C03A94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2299, ????);     
            label_6:
            // 0x01C03A98: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x01C03A9C: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x01C03AA0: LDR x8, [x8, #0xe18]       | X8 = 1152921504607645696;               
            // 0x01C03AA4: LDR x20, [x8]              | X20 = typeof(System.UInt32);            
            // 0x01C03AA8: CBNZ x19, #0x1c03ab0       | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x01C03AAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2299, ????);     
            label_7:
            // 0x01C03AB0: LDR x8, [x19]              | X8 = X2;                                
            // 0x01C03AB4: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01C03AB8: LDR x8, [x20, #0x30]       | X8 = System.UInt32.__il2cppRuntimeField_element_class;
            // 0x01C03ABC: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.UInt32.__il2cppRuntimeField_element_class)
            // 0x01C03AC0: B.NE #0x1c03b08            | if (X2 + 48 != System.UInt32.__il2cppRuntimeField_element_class) goto label_8;
            // 0x01C03AC4: MOV x0, x19                | X0 = X2;//m1                            
            // 0x01C03AC8: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x01C03ACC: LDR w8, [x0]               | W8 = X2;                                
            // 0x01C03AD0: STR w8, [x21, #0x30]       | mem[48] = X2;                            //  dest_result_addr=48
            mem[48] = X2;
            // 0x01C03AD4: SUB sp, x29, #0x20         | SP = (1152921510259079568 - 32) = 1152921510259079536 (0x1000000150E63970);
            // 0x01C03AD8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01C03ADC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01C03AE0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01C03AE4: RET                        |  return;                                
            return;
            // 0x01C03AE8: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01C03AEC: ADD x0, sp, #8             | X0 = (1152921510259079584 + 8) = 1152921510259079592 (0x1000000150E639A8);
            // 0x01C03AF0: B #0x1c03afc               |  goto label_10;                         
            goto label_10;
            // 0x01C03AF4: MOV x19, x0                | X19 = 1152921510259079592 (0x1000000150E639A8);//ML01
            val_7;
            // 0x01C03AF8: ADD x0, sp, #0x10          | X0 = (1152921510259079584 + 16) = 1152921510259079600 (0x1000000150E639B0);
            label_10:
            // 0x01C03AFC: BL #0x299a140              | 
            // 0x01C03B00: MOV x0, x19                | X0 = 1152921510259079592 (0x1000000150E639A8);//ML01
            // 0x01C03B04: BL #0x980800               | X0 = sub_980800( ?? 0x1000000150E639A8, ????);
            label_8:
            // 0x01C03B08: ADD x8, sp, #0x18          | X8 = (1152921510259079584 + 24) = 1152921510259079608 (0x1000000150E639B8);
            // 0x01C03B0C: MOV x1, x20                | X1 = X20;//m1                           
            // 0x01C03B10: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000150E639A8, ????);
            // 0x01C03B14: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510259067584]
            // 0x01C03B18: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01C03B1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C03B20: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01C03B24: ADD x0, sp, #0x18          | X0 = (1152921510259079584 + 24) = 1152921510259079608 (0x1000000150E639B8);
            // 0x01C03B28: BL #0x299a140              | 
            // 0x01C03B2C: MOV x19, x0                | X19 = 1152921510259079608 (0x1000000150E639B8);//ML01
            // 0x01C03B30: ADD x0, sp, #0x18          | X0 = (1152921510259079584 + 24) = 1152921510259079608 (0x1000000150E639B8);
            // 0x01C03B34: B #0x1c03afc               |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C03B38 (29375288), len: 312  VirtAddr: 0x01C03B38 RVA: 0x01C03B38 token: 100665102 methodIndex: 31151 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_lv_5(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01C03B38: STP x20, x19, [sp, #-0x20]! | stack[1152921510259207776] = ???;  stack[1152921510259207784] = ???;  //  dest_result_addr=1152921510259207776 |  dest_result_addr=1152921510259207784
            // 0x01C03B3C: STP x29, x30, [sp, #0x10]  | stack[1152921510259207792] = ???;  stack[1152921510259207800] = ???;  //  dest_result_addr=1152921510259207792 |  dest_result_addr=1152921510259207800
            // 0x01C03B40: ADD x29, sp, #0x10         | X29 = (1152921510259207776 + 16) = 1152921510259207792 (0x1000000150E82E70);
            // 0x01C03B44: SUB sp, sp, #0x20          | SP = (1152921510259207776 - 32) = 1152921510259207744 (0x1000000150E82E40);
            // 0x01C03B48: ADRP x20, #0x373c000       | X20 = 57917440 (0x373C000);             
            // 0x01C03B4C: LDRB w8, [x20, #0x269]     | W8 = (bool)static_value_0373C269;       
            // 0x01C03B50: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01C03B54: TBNZ w8, #0, #0x1c03b70    | if (static_value_0373C269 == true) goto label_0;
            // 0x01C03B58: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x01C03B5C: LDR x8, [x8, #0xde8]       | X8 = 0x2B92F10;                         
            // 0x01C03B60: LDR w0, [x8]               | W0 = 0x2289;                            
            // 0x01C03B64: BL #0x2782188              | X0 = sub_2782188( ?? 0x2289, ????);     
            // 0x01C03B68: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C03B6C: STRB w8, [x20, #0x269]     | static_value_0373C269 = true;            //  dest_result_addr=57918057
            label_0:
            // 0x01C03B70: ADRP x20, #0x35cd000       | X20 = 56414208 (0x35CD000);             
            // 0x01C03B74: LDR x19, [x19]             | X19 = X1;                               
            // 0x01C03B78: LDR x20, [x20, #0xd70]     | X20 = 1152921504904503296;              
            // 0x01C03B7C: CBZ x19, #0x1c03bd0        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01C03B80: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C03B84: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C03B88: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C03B8C: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C03B90: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C03B94: B.LO #0x1c03bac            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C03B98: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C03B9C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C03BA0: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C03BA4: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C03BA8: B.EQ #0x1c03bd4            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C03BAC: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C03BB0: ADD x8, sp, #0x10          | X8 = (1152921510259207744 + 16) = 1152921510259207760 (0x1000000150E82E50);
            // 0x01C03BB4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C03BB8: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510259195808]
            // 0x01C03BBC: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C03BC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C03BC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C03BC8: ADD x0, sp, #0x10          | X0 = (1152921510259207744 + 16) = 1152921510259207760 (0x1000000150E82E50);
            // 0x01C03BCC: BL #0x299a140              | 
            label_1:
            // 0x01C03BD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150E82E50, ????);
            label_3:
            // 0x01C03BD4: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C03BD8: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C03BDC: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C03BE0: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C03BE4: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C03BE8: B.LO #0x1c03c2c            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01C03BEC: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C03BF0: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C03BF4: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C03BF8: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C03BFC: B.NE #0x1c03c2c            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01C03C00: ADRP x9, #0x35e2000        | X9 = 56500224 (0x35E2000);              
            // 0x01C03C04: LDR w8, [x19, #0x34]       | W8 = X1 + 52;                           
            // 0x01C03C08: LDR x9, [x9, #0xe18]       | X9 = 1152921504607645696;               
            // 0x01C03C0C: ADD x1, sp, #0xc           | X1 = (1152921510259207744 + 12) = 1152921510259207756 (0x1000000150E82E4C);
            // 0x01C03C10: STR w8, [sp, #0xc]         | stack[1152921510259207756] = X1 + 52;    //  dest_result_addr=1152921510259207756
            // 0x01C03C14: LDR x0, [x9]               | X0 = typeof(System.UInt32);             
            // 0x01C03C18: BL #0x27bc028              | X0 = 1152921510259255824 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.UInt32), X1 + 52);
            // 0x01C03C1C: SUB sp, x29, #0x10         | SP = (1152921510259207792 - 16) = 1152921510259207776 (0x1000000150E82E60);
            // 0x01C03C20: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01C03C24: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01C03C28: RET                        |  return (System.Object)X1 + 52;         
            return (object)X1 + 52;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01C03C2C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C03C30: ADD x8, sp, #0x18          | X8 = (1152921510259207744 + 24) = 1152921510259207768 (0x1000000150E82E58);
            // 0x01C03C34: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C03C38: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510259195808]
            // 0x01C03C3C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C03C40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C03C44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C03C48: ADD x0, sp, #0x18          | X0 = (1152921510259207744 + 24) = 1152921510259207768 (0x1000000150E82E58);
            // 0x01C03C4C: BL #0x299a140              | 
            // 0x01C03C50: MOV x19, x0                | X19 = 1152921510259207768 (0x1000000150E82E58);//ML01
            // 0x01C03C54: ADD x0, sp, #0x10          | X0 = (1152921510259207744 + 16) = 1152921510259207760 (0x1000000150E82E50);
            label_6:
            // 0x01C03C58: BL #0x299a140              | 
            // 0x01C03C5C: MOV x0, x19                | X0 = 1152921510259207768 (0x1000000150E82E58);//ML01
            // 0x01C03C60: BL #0x980800               | X0 = sub_980800( ?? 0x1000000150E82E58, ????);
            // 0x01C03C64: MOV x19, x0                | X19 = 1152921510259207768 (0x1000000150E82E58);//ML01
            // 0x01C03C68: ADD x0, sp, #0x18          | X0 = (1152921510259207744 + 24) = 1152921510259207768 (0x1000000150E82E58);
            // 0x01C03C6C: B #0x1c03c58               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C03C70 (29375600), len: 412  VirtAddr: 0x01C03C70 RVA: 0x01C03C70 token: 100665103 methodIndex: 31152 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_lv_5(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x01C03C70: STP x22, x21, [sp, #-0x30]! | stack[1152921510259335984] = ???;  stack[1152921510259335992] = ???;  //  dest_result_addr=1152921510259335984 |  dest_result_addr=1152921510259335992
            // 0x01C03C74: STP x20, x19, [sp, #0x10]  | stack[1152921510259336000] = ???;  stack[1152921510259336008] = ???;  //  dest_result_addr=1152921510259336000 |  dest_result_addr=1152921510259336008
            // 0x01C03C78: STP x29, x30, [sp, #0x20]  | stack[1152921510259336016] = ???;  stack[1152921510259336024] = ???;  //  dest_result_addr=1152921510259336016 |  dest_result_addr=1152921510259336024
            // 0x01C03C7C: ADD x29, sp, #0x20         | X29 = (1152921510259335984 + 32) = 1152921510259336016 (0x1000000150EA2350);
            // 0x01C03C80: SUB sp, sp, #0x20          | SP = (1152921510259335984 - 32) = 1152921510259335952 (0x1000000150EA2310);
            // 0x01C03C84: ADRP x21, #0x373c000       | X21 = 57917440 (0x373C000);             
            // 0x01C03C88: LDRB w8, [x21, #0x26a]     | W8 = (bool)static_value_0373C26A;       
            // 0x01C03C8C: MOV x19, x2                | X19 = X2;//m1                           
            // 0x01C03C90: MOV x20, x1                | X20 = v;//m1                            
            // 0x01C03C94: TBNZ w8, #0, #0x1c03cb0    | if (static_value_0373C26A == true) goto label_0;
            // 0x01C03C98: ADRP x8, #0x3603000        | X8 = 56635392 (0x3603000);              
            // 0x01C03C9C: LDR x8, [x8, #0x2b0]       | X8 = 0x2B92F44;                         
            // 0x01C03CA0: LDR w0, [x8]               | W0 = 0x2296;                            
            // 0x01C03CA4: BL #0x2782188              | X0 = sub_2782188( ?? 0x2296, ????);     
            // 0x01C03CA8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C03CAC: STRB w8, [x21, #0x26a]     | static_value_0373C26A = true;            //  dest_result_addr=57918058
            label_0:
            // 0x01C03CB0: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x01C03CB4: CBZ x21, #0x1c03d68        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01C03CB8: ADRP x20, #0x35cd000       | X20 = 56414208 (0x35CD000);             
            // 0x01C03CBC: LDR x20, [x20, #0xd70]     | X20 = 1152921504904503296;              
            // 0x01C03CC0: LDR x8, [x21]              | X8 = ;                                  
            // 0x01C03CC4: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C03CC8: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C03CCC: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C03CD0: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C03CD4: B.LO #0x1c03cec            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C03CD8: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C03CDC: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C03CE0: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C03CE4: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C03CE8: B.EQ #0x1c03d14            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C03CEC: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C03CF0: ADD x8, sp, #8             | X8 = (1152921510259335952 + 8) = 1152921510259335960 (0x1000000150EA2318);
            // 0x01C03CF4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C03CF8: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510259324032]
            // 0x01C03CFC: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C03D00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C03D04: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C03D08: ADD x0, sp, #8             | X0 = (1152921510259335952 + 8) = 1152921510259335960 (0x1000000150EA2318);
            // 0x01C03D0C: BL #0x299a140              | 
            // 0x01C03D10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150EA2318, ????);
            label_3:
            // 0x01C03D14: LDR x8, [x21]              | X8 = ;                                  
            // 0x01C03D18: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C03D1C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C03D20: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C03D24: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C03D28: B.LO #0x1c03d40            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01C03D2C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C03D30: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C03D34: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C03D38: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C03D3C: B.EQ #0x1c03d70            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01C03D40: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C03D44: ADD x8, sp, #0x10          | X8 = (1152921510259335952 + 16) = 1152921510259335968 (0x1000000150EA2320);
            // 0x01C03D48: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C03D4C: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510259324032]
            // 0x01C03D50: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C03D54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C03D58: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C03D5C: ADD x0, sp, #0x10          | X0 = (1152921510259335952 + 16) = 1152921510259335968 (0x1000000150EA2320);
            // 0x01C03D60: BL #0x299a140              | 
            // 0x01C03D64: B #0x1c03d6c               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01C03D68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2296, ????);     
            label_6:
            // 0x01C03D6C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x01C03D70: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x01C03D74: LDR x8, [x8, #0xe18]       | X8 = 1152921504607645696;               
            // 0x01C03D78: LDR x20, [x8]              | X20 = typeof(System.UInt32);            
            // 0x01C03D7C: CBNZ x19, #0x1c03d84       | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x01C03D80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2296, ????);     
            label_7:
            // 0x01C03D84: LDR x8, [x19]              | X8 = X2;                                
            // 0x01C03D88: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01C03D8C: LDR x8, [x20, #0x30]       | X8 = System.UInt32.__il2cppRuntimeField_element_class;
            // 0x01C03D90: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.UInt32.__il2cppRuntimeField_element_class)
            // 0x01C03D94: B.NE #0x1c03ddc            | if (X2 + 48 != System.UInt32.__il2cppRuntimeField_element_class) goto label_8;
            // 0x01C03D98: MOV x0, x19                | X0 = X2;//m1                            
            // 0x01C03D9C: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x01C03DA0: LDR w8, [x0]               | W8 = X2;                                
            // 0x01C03DA4: STR w8, [x21, #0x34]       | mem[52] = X2;                            //  dest_result_addr=52
            mem[52] = X2;
            // 0x01C03DA8: SUB sp, x29, #0x20         | SP = (1152921510259336016 - 32) = 1152921510259335984 (0x1000000150EA2330);
            // 0x01C03DAC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01C03DB0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01C03DB4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01C03DB8: RET                        |  return;                                
            return;
            // 0x01C03DBC: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01C03DC0: ADD x0, sp, #8             | X0 = (1152921510259336032 + 8) = 1152921510259336040 (0x1000000150EA2368);
            // 0x01C03DC4: B #0x1c03dd0               |  goto label_10;                         
            goto label_10;
            // 0x01C03DC8: MOV x19, x0                | X19 = 1152921510259336040 (0x1000000150EA2368);//ML01
            val_7;
            // 0x01C03DCC: ADD x0, sp, #0x10          | X0 = (1152921510259336032 + 16) = 1152921510259336048 (0x1000000150EA2370);
            label_10:
            // 0x01C03DD0: BL #0x299a140              | 
            // 0x01C03DD4: MOV x0, x19                | X0 = 1152921510259336040 (0x1000000150EA2368);//ML01
            // 0x01C03DD8: BL #0x980800               | X0 = sub_980800( ?? 0x1000000150EA2368, ????);
            label_8:
            // 0x01C03DDC: ADD x8, sp, #0x18          | X8 = (1152921510259336032 + 24) = 1152921510259336056 (0x1000000150EA2378);
            // 0x01C03DE0: MOV x1, x20                | X1 = X20;//m1                           
            // 0x01C03DE4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000150EA2368, ????);
            // 0x01C03DE8: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510259324032]
            // 0x01C03DEC: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01C03DF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C03DF4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01C03DF8: ADD x0, sp, #0x18          | X0 = (1152921510259336032 + 24) = 1152921510259336056 (0x1000000150EA2378);
            // 0x01C03DFC: BL #0x299a140              | 
            // 0x01C03E00: MOV x19, x0                | X19 = 1152921510259336056 (0x1000000150EA2378);//ML01
            // 0x01C03E04: ADD x0, sp, #0x18          | X0 = (1152921510259336032 + 24) = 1152921510259336056 (0x1000000150EA2378);
            // 0x01C03E08: B #0x1c03dd0               |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C03E0C (29376012), len: 312  VirtAddr: 0x01C03E0C RVA: 0x01C03E0C token: 100665104 methodIndex: 31153 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_vipLv_6(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01C03E0C: STP x20, x19, [sp, #-0x20]! | stack[1152921510259464224] = ???;  stack[1152921510259464232] = ???;  //  dest_result_addr=1152921510259464224 |  dest_result_addr=1152921510259464232
            // 0x01C03E10: STP x29, x30, [sp, #0x10]  | stack[1152921510259464240] = ???;  stack[1152921510259464248] = ???;  //  dest_result_addr=1152921510259464240 |  dest_result_addr=1152921510259464248
            // 0x01C03E14: ADD x29, sp, #0x10         | X29 = (1152921510259464224 + 16) = 1152921510259464240 (0x1000000150EC1830);
            // 0x01C03E18: SUB sp, sp, #0x20          | SP = (1152921510259464224 - 32) = 1152921510259464192 (0x1000000150EC1800);
            // 0x01C03E1C: ADRP x20, #0x373c000       | X20 = 57917440 (0x373C000);             
            // 0x01C03E20: LDRB w8, [x20, #0x26b]     | W8 = (bool)static_value_0373C26B;       
            // 0x01C03E24: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01C03E28: TBNZ w8, #0, #0x1c03e44    | if (static_value_0373C26B == true) goto label_0;
            // 0x01C03E2C: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
            // 0x01C03E30: LDR x8, [x8, #0x9b8]       | X8 = 0x2B92F30;                         
            // 0x01C03E34: LDR w0, [x8]               | W0 = 0x2291;                            
            // 0x01C03E38: BL #0x2782188              | X0 = sub_2782188( ?? 0x2291, ????);     
            // 0x01C03E3C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C03E40: STRB w8, [x20, #0x26b]     | static_value_0373C26B = true;            //  dest_result_addr=57918059
            label_0:
            // 0x01C03E44: ADRP x20, #0x35cd000       | X20 = 56414208 (0x35CD000);             
            // 0x01C03E48: LDR x19, [x19]             | X19 = X1;                               
            // 0x01C03E4C: LDR x20, [x20, #0xd70]     | X20 = 1152921504904503296;              
            // 0x01C03E50: CBZ x19, #0x1c03ea4        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01C03E54: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C03E58: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C03E5C: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C03E60: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C03E64: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C03E68: B.LO #0x1c03e80            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C03E6C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C03E70: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C03E74: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C03E78: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C03E7C: B.EQ #0x1c03ea8            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C03E80: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C03E84: ADD x8, sp, #0x10          | X8 = (1152921510259464192 + 16) = 1152921510259464208 (0x1000000150EC1810);
            // 0x01C03E88: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C03E8C: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510259452256]
            // 0x01C03E90: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C03E94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C03E98: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C03E9C: ADD x0, sp, #0x10          | X0 = (1152921510259464192 + 16) = 1152921510259464208 (0x1000000150EC1810);
            // 0x01C03EA0: BL #0x299a140              | 
            label_1:
            // 0x01C03EA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150EC1810, ????);
            label_3:
            // 0x01C03EA8: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C03EAC: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C03EB0: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C03EB4: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C03EB8: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C03EBC: B.LO #0x1c03f00            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01C03EC0: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C03EC4: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C03EC8: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C03ECC: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C03ED0: B.NE #0x1c03f00            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01C03ED4: ADRP x9, #0x35e2000        | X9 = 56500224 (0x35E2000);              
            // 0x01C03ED8: LDR w8, [x19, #0x38]       | W8 = X1 + 56;                           
            // 0x01C03EDC: LDR x9, [x9, #0xe18]       | X9 = 1152921504607645696;               
            // 0x01C03EE0: ADD x1, sp, #0xc           | X1 = (1152921510259464192 + 12) = 1152921510259464204 (0x1000000150EC180C);
            // 0x01C03EE4: STR w8, [sp, #0xc]         | stack[1152921510259464204] = X1 + 56;    //  dest_result_addr=1152921510259464204
            // 0x01C03EE8: LDR x0, [x9]               | X0 = typeof(System.UInt32);             
            // 0x01C03EEC: BL #0x27bc028              | X0 = 1152921510259512272 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.UInt32), X1 + 56);
            // 0x01C03EF0: SUB sp, x29, #0x10         | SP = (1152921510259464240 - 16) = 1152921510259464224 (0x1000000150EC1820);
            // 0x01C03EF4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01C03EF8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01C03EFC: RET                        |  return (System.Object)X1 + 56;         
            return (object)X1 + 56;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01C03F00: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C03F04: ADD x8, sp, #0x18          | X8 = (1152921510259464192 + 24) = 1152921510259464216 (0x1000000150EC1818);
            // 0x01C03F08: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C03F0C: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510259452256]
            // 0x01C03F10: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C03F14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C03F18: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C03F1C: ADD x0, sp, #0x18          | X0 = (1152921510259464192 + 24) = 1152921510259464216 (0x1000000150EC1818);
            // 0x01C03F20: BL #0x299a140              | 
            // 0x01C03F24: MOV x19, x0                | X19 = 1152921510259464216 (0x1000000150EC1818);//ML01
            // 0x01C03F28: ADD x0, sp, #0x10          | X0 = (1152921510259464192 + 16) = 1152921510259464208 (0x1000000150EC1810);
            label_6:
            // 0x01C03F2C: BL #0x299a140              | 
            // 0x01C03F30: MOV x0, x19                | X0 = 1152921510259464216 (0x1000000150EC1818);//ML01
            // 0x01C03F34: BL #0x980800               | X0 = sub_980800( ?? 0x1000000150EC1818, ????);
            // 0x01C03F38: MOV x19, x0                | X19 = 1152921510259464216 (0x1000000150EC1818);//ML01
            // 0x01C03F3C: ADD x0, sp, #0x18          | X0 = (1152921510259464192 + 24) = 1152921510259464216 (0x1000000150EC1818);
            // 0x01C03F40: B #0x1c03f2c               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C03F44 (29376324), len: 412  VirtAddr: 0x01C03F44 RVA: 0x01C03F44 token: 100665105 methodIndex: 31154 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_vipLv_6(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x01C03F44: STP x22, x21, [sp, #-0x30]! | stack[1152921510259592432] = ???;  stack[1152921510259592440] = ???;  //  dest_result_addr=1152921510259592432 |  dest_result_addr=1152921510259592440
            // 0x01C03F48: STP x20, x19, [sp, #0x10]  | stack[1152921510259592448] = ???;  stack[1152921510259592456] = ???;  //  dest_result_addr=1152921510259592448 |  dest_result_addr=1152921510259592456
            // 0x01C03F4C: STP x29, x30, [sp, #0x20]  | stack[1152921510259592464] = ???;  stack[1152921510259592472] = ???;  //  dest_result_addr=1152921510259592464 |  dest_result_addr=1152921510259592472
            // 0x01C03F50: ADD x29, sp, #0x20         | X29 = (1152921510259592432 + 32) = 1152921510259592464 (0x1000000150EE0D10);
            // 0x01C03F54: SUB sp, sp, #0x20          | SP = (1152921510259592432 - 32) = 1152921510259592400 (0x1000000150EE0CD0);
            // 0x01C03F58: ADRP x21, #0x373c000       | X21 = 57917440 (0x373C000);             
            // 0x01C03F5C: LDRB w8, [x21, #0x26c]     | W8 = (bool)static_value_0373C26C;       
            // 0x01C03F60: MOV x19, x2                | X19 = X2;//m1                           
            // 0x01C03F64: MOV x20, x1                | X20 = v;//m1                            
            // 0x01C03F68: TBNZ w8, #0, #0x1c03f84    | if (static_value_0373C26C == true) goto label_0;
            // 0x01C03F6C: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x01C03F70: LDR x8, [x8, #0x9e8]       | X8 = 0x2B92F64;                         
            // 0x01C03F74: LDR w0, [x8]               | W0 = 0x229E;                            
            // 0x01C03F78: BL #0x2782188              | X0 = sub_2782188( ?? 0x229E, ????);     
            // 0x01C03F7C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C03F80: STRB w8, [x21, #0x26c]     | static_value_0373C26C = true;            //  dest_result_addr=57918060
            label_0:
            // 0x01C03F84: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x01C03F88: CBZ x21, #0x1c0403c        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01C03F8C: ADRP x20, #0x35cd000       | X20 = 56414208 (0x35CD000);             
            // 0x01C03F90: LDR x20, [x20, #0xd70]     | X20 = 1152921504904503296;              
            // 0x01C03F94: LDR x8, [x21]              | X8 = ;                                  
            // 0x01C03F98: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C03F9C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C03FA0: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C03FA4: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C03FA8: B.LO #0x1c03fc0            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C03FAC: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C03FB0: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C03FB4: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C03FB8: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C03FBC: B.EQ #0x1c03fe8            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C03FC0: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C03FC4: ADD x8, sp, #8             | X8 = (1152921510259592400 + 8) = 1152921510259592408 (0x1000000150EE0CD8);
            // 0x01C03FC8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C03FCC: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510259580480]
            // 0x01C03FD0: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C03FD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C03FD8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C03FDC: ADD x0, sp, #8             | X0 = (1152921510259592400 + 8) = 1152921510259592408 (0x1000000150EE0CD8);
            // 0x01C03FE0: BL #0x299a140              | 
            // 0x01C03FE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150EE0CD8, ????);
            label_3:
            // 0x01C03FE8: LDR x8, [x21]              | X8 = ;                                  
            // 0x01C03FEC: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C03FF0: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C03FF4: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C03FF8: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C03FFC: B.LO #0x1c04014            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01C04000: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C04004: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C04008: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C0400C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C04010: B.EQ #0x1c04044            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01C04014: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C04018: ADD x8, sp, #0x10          | X8 = (1152921510259592400 + 16) = 1152921510259592416 (0x1000000150EE0CE0);
            // 0x01C0401C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C04020: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510259580480]
            // 0x01C04024: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C04028: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C0402C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C04030: ADD x0, sp, #0x10          | X0 = (1152921510259592400 + 16) = 1152921510259592416 (0x1000000150EE0CE0);
            // 0x01C04034: BL #0x299a140              | 
            // 0x01C04038: B #0x1c04040               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01C0403C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x229E, ????);     
            label_6:
            // 0x01C04040: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x01C04044: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x01C04048: LDR x8, [x8, #0xe18]       | X8 = 1152921504607645696;               
            // 0x01C0404C: LDR x20, [x8]              | X20 = typeof(System.UInt32);            
            // 0x01C04050: CBNZ x19, #0x1c04058       | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x01C04054: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x229E, ????);     
            label_7:
            // 0x01C04058: LDR x8, [x19]              | X8 = X2;                                
            // 0x01C0405C: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01C04060: LDR x8, [x20, #0x30]       | X8 = System.UInt32.__il2cppRuntimeField_element_class;
            // 0x01C04064: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.UInt32.__il2cppRuntimeField_element_class)
            // 0x01C04068: B.NE #0x1c040b0            | if (X2 + 48 != System.UInt32.__il2cppRuntimeField_element_class) goto label_8;
            // 0x01C0406C: MOV x0, x19                | X0 = X2;//m1                            
            // 0x01C04070: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x01C04074: LDR w8, [x0]               | W8 = X2;                                
            // 0x01C04078: STR w8, [x21, #0x38]       | mem[56] = X2;                            //  dest_result_addr=56
            mem[56] = X2;
            // 0x01C0407C: SUB sp, x29, #0x20         | SP = (1152921510259592464 - 32) = 1152921510259592432 (0x1000000150EE0CF0);
            // 0x01C04080: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01C04084: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01C04088: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01C0408C: RET                        |  return;                                
            return;
            // 0x01C04090: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01C04094: ADD x0, sp, #8             | X0 = (1152921510259592480 + 8) = 1152921510259592488 (0x1000000150EE0D28);
            // 0x01C04098: B #0x1c040a4               |  goto label_10;                         
            goto label_10;
            // 0x01C0409C: MOV x19, x0                | X19 = 1152921510259592488 (0x1000000150EE0D28);//ML01
            val_7;
            // 0x01C040A0: ADD x0, sp, #0x10          | X0 = (1152921510259592480 + 16) = 1152921510259592496 (0x1000000150EE0D30);
            label_10:
            // 0x01C040A4: BL #0x299a140              | 
            // 0x01C040A8: MOV x0, x19                | X0 = 1152921510259592488 (0x1000000150EE0D28);//ML01
            // 0x01C040AC: BL #0x980800               | X0 = sub_980800( ?? 0x1000000150EE0D28, ????);
            label_8:
            // 0x01C040B0: ADD x8, sp, #0x18          | X8 = (1152921510259592480 + 24) = 1152921510259592504 (0x1000000150EE0D38);
            // 0x01C040B4: MOV x1, x20                | X1 = X20;//m1                           
            // 0x01C040B8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000150EE0D28, ????);
            // 0x01C040BC: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510259580480]
            // 0x01C040C0: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01C040C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C040C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01C040CC: ADD x0, sp, #0x18          | X0 = (1152921510259592480 + 24) = 1152921510259592504 (0x1000000150EE0D38);
            // 0x01C040D0: BL #0x299a140              | 
            // 0x01C040D4: MOV x19, x0                | X19 = 1152921510259592504 (0x1000000150EE0D38);//ML01
            // 0x01C040D8: ADD x0, sp, #0x18          | X0 = (1152921510259592480 + 24) = 1152921510259592504 (0x1000000150EE0D38);
            // 0x01C040DC: B #0x1c040a4               |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C040E0 (29376736), len: 312  VirtAddr: 0x01C040E0 RVA: 0x01C040E0 token: 100665106 methodIndex: 31155 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_exp_7(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01C040E0: STP x20, x19, [sp, #-0x20]! | stack[1152921510259720672] = ???;  stack[1152921510259720680] = ???;  //  dest_result_addr=1152921510259720672 |  dest_result_addr=1152921510259720680
            // 0x01C040E4: STP x29, x30, [sp, #0x10]  | stack[1152921510259720688] = ???;  stack[1152921510259720696] = ???;  //  dest_result_addr=1152921510259720688 |  dest_result_addr=1152921510259720696
            // 0x01C040E8: ADD x29, sp, #0x10         | X29 = (1152921510259720672 + 16) = 1152921510259720688 (0x1000000150F001F0);
            // 0x01C040EC: SUB sp, sp, #0x20          | SP = (1152921510259720672 - 32) = 1152921510259720640 (0x1000000150F001C0);
            // 0x01C040F0: ADRP x20, #0x373c000       | X20 = 57917440 (0x373C000);             
            // 0x01C040F4: LDRB w8, [x20, #0x26d]     | W8 = (bool)static_value_0373C26D;       
            // 0x01C040F8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01C040FC: TBNZ w8, #0, #0x1c04118    | if (static_value_0373C26D == true) goto label_0;
            // 0x01C04100: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x01C04104: LDR x8, [x8, #0x850]       | X8 = 0x2B92F04;                         
            // 0x01C04108: LDR w0, [x8]               | W0 = 0x2286;                            
            // 0x01C0410C: BL #0x2782188              | X0 = sub_2782188( ?? 0x2286, ????);     
            // 0x01C04110: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C04114: STRB w8, [x20, #0x26d]     | static_value_0373C26D = true;            //  dest_result_addr=57918061
            label_0:
            // 0x01C04118: ADRP x20, #0x35cd000       | X20 = 56414208 (0x35CD000);             
            // 0x01C0411C: LDR x19, [x19]             | X19 = X1;                               
            // 0x01C04120: LDR x20, [x20, #0xd70]     | X20 = 1152921504904503296;              
            // 0x01C04124: CBZ x19, #0x1c04178        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01C04128: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C0412C: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C04130: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C04134: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C04138: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C0413C: B.LO #0x1c04154            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C04140: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C04144: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C04148: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C0414C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C04150: B.EQ #0x1c0417c            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C04154: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C04158: ADD x8, sp, #0x10          | X8 = (1152921510259720640 + 16) = 1152921510259720656 (0x1000000150F001D0);
            // 0x01C0415C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C04160: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510259708704]
            // 0x01C04164: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C04168: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C0416C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C04170: ADD x0, sp, #0x10          | X0 = (1152921510259720640 + 16) = 1152921510259720656 (0x1000000150F001D0);
            // 0x01C04174: BL #0x299a140              | 
            label_1:
            // 0x01C04178: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150F001D0, ????);
            label_3:
            // 0x01C0417C: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C04180: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C04184: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C04188: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C0418C: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C04190: B.LO #0x1c041d4            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01C04194: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C04198: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C0419C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C041A0: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C041A4: B.NE #0x1c041d4            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01C041A8: ADRP x9, #0x35e2000        | X9 = 56500224 (0x35E2000);              
            // 0x01C041AC: LDR w8, [x19, #0x3c]       | W8 = X1 + 60;                           
            // 0x01C041B0: LDR x9, [x9, #0xe18]       | X9 = 1152921504607645696;               
            // 0x01C041B4: ADD x1, sp, #0xc           | X1 = (1152921510259720640 + 12) = 1152921510259720652 (0x1000000150F001CC);
            // 0x01C041B8: STR w8, [sp, #0xc]         | stack[1152921510259720652] = X1 + 60;    //  dest_result_addr=1152921510259720652
            // 0x01C041BC: LDR x0, [x9]               | X0 = typeof(System.UInt32);             
            // 0x01C041C0: BL #0x27bc028              | X0 = 1152921510259768720 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.UInt32), X1 + 60);
            // 0x01C041C4: SUB sp, x29, #0x10         | SP = (1152921510259720688 - 16) = 1152921510259720672 (0x1000000150F001E0);
            // 0x01C041C8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01C041CC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01C041D0: RET                        |  return (System.Object)X1 + 60;         
            return (object)X1 + 60;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01C041D4: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C041D8: ADD x8, sp, #0x18          | X8 = (1152921510259720640 + 24) = 1152921510259720664 (0x1000000150F001D8);
            // 0x01C041DC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C041E0: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510259708704]
            // 0x01C041E4: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C041E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C041EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C041F0: ADD x0, sp, #0x18          | X0 = (1152921510259720640 + 24) = 1152921510259720664 (0x1000000150F001D8);
            // 0x01C041F4: BL #0x299a140              | 
            // 0x01C041F8: MOV x19, x0                | X19 = 1152921510259720664 (0x1000000150F001D8);//ML01
            // 0x01C041FC: ADD x0, sp, #0x10          | X0 = (1152921510259720640 + 16) = 1152921510259720656 (0x1000000150F001D0);
            label_6:
            // 0x01C04200: BL #0x299a140              | 
            // 0x01C04204: MOV x0, x19                | X0 = 1152921510259720664 (0x1000000150F001D8);//ML01
            // 0x01C04208: BL #0x980800               | X0 = sub_980800( ?? 0x1000000150F001D8, ????);
            // 0x01C0420C: MOV x19, x0                | X19 = 1152921510259720664 (0x1000000150F001D8);//ML01
            // 0x01C04210: ADD x0, sp, #0x18          | X0 = (1152921510259720640 + 24) = 1152921510259720664 (0x1000000150F001D8);
            // 0x01C04214: B #0x1c04200               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C04218 (29377048), len: 412  VirtAddr: 0x01C04218 RVA: 0x01C04218 token: 100665107 methodIndex: 31156 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_exp_7(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x01C04218: STP x22, x21, [sp, #-0x30]! | stack[1152921510259848880] = ???;  stack[1152921510259848888] = ???;  //  dest_result_addr=1152921510259848880 |  dest_result_addr=1152921510259848888
            // 0x01C0421C: STP x20, x19, [sp, #0x10]  | stack[1152921510259848896] = ???;  stack[1152921510259848904] = ???;  //  dest_result_addr=1152921510259848896 |  dest_result_addr=1152921510259848904
            // 0x01C04220: STP x29, x30, [sp, #0x20]  | stack[1152921510259848912] = ???;  stack[1152921510259848920] = ???;  //  dest_result_addr=1152921510259848912 |  dest_result_addr=1152921510259848920
            // 0x01C04224: ADD x29, sp, #0x20         | X29 = (1152921510259848880 + 32) = 1152921510259848912 (0x1000000150F1F6D0);
            // 0x01C04228: SUB sp, sp, #0x20          | SP = (1152921510259848880 - 32) = 1152921510259848848 (0x1000000150F1F690);
            // 0x01C0422C: ADRP x21, #0x373c000       | X21 = 57917440 (0x373C000);             
            // 0x01C04230: LDRB w8, [x21, #0x26e]     | W8 = (bool)static_value_0373C26E;       
            // 0x01C04234: MOV x19, x2                | X19 = X2;//m1                           
            // 0x01C04238: MOV x20, x1                | X20 = v;//m1                            
            // 0x01C0423C: TBNZ w8, #0, #0x1c04258    | if (static_value_0373C26E == true) goto label_0;
            // 0x01C04240: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
            // 0x01C04244: LDR x8, [x8, #0xa00]       | X8 = 0x2B92F38;                         
            // 0x01C04248: LDR w0, [x8]               | W0 = 0x2293;                            
            // 0x01C0424C: BL #0x2782188              | X0 = sub_2782188( ?? 0x2293, ????);     
            // 0x01C04250: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C04254: STRB w8, [x21, #0x26e]     | static_value_0373C26E = true;            //  dest_result_addr=57918062
            label_0:
            // 0x01C04258: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x01C0425C: CBZ x21, #0x1c04310        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01C04260: ADRP x20, #0x35cd000       | X20 = 56414208 (0x35CD000);             
            // 0x01C04264: LDR x20, [x20, #0xd70]     | X20 = 1152921504904503296;              
            // 0x01C04268: LDR x8, [x21]              | X8 = ;                                  
            // 0x01C0426C: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C04270: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C04274: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C04278: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C0427C: B.LO #0x1c04294            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C04280: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C04284: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C04288: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C0428C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C04290: B.EQ #0x1c042bc            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C04294: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C04298: ADD x8, sp, #8             | X8 = (1152921510259848848 + 8) = 1152921510259848856 (0x1000000150F1F698);
            // 0x01C0429C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C042A0: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510259836928]
            // 0x01C042A4: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C042A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C042AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C042B0: ADD x0, sp, #8             | X0 = (1152921510259848848 + 8) = 1152921510259848856 (0x1000000150F1F698);
            // 0x01C042B4: BL #0x299a140              | 
            // 0x01C042B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150F1F698, ????);
            label_3:
            // 0x01C042BC: LDR x8, [x21]              | X8 = ;                                  
            // 0x01C042C0: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C042C4: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C042C8: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C042CC: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C042D0: B.LO #0x1c042e8            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01C042D4: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C042D8: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C042DC: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C042E0: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C042E4: B.EQ #0x1c04318            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01C042E8: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C042EC: ADD x8, sp, #0x10          | X8 = (1152921510259848848 + 16) = 1152921510259848864 (0x1000000150F1F6A0);
            // 0x01C042F0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C042F4: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510259836928]
            // 0x01C042F8: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C042FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C04300: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C04304: ADD x0, sp, #0x10          | X0 = (1152921510259848848 + 16) = 1152921510259848864 (0x1000000150F1F6A0);
            // 0x01C04308: BL #0x299a140              | 
            // 0x01C0430C: B #0x1c04314               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01C04310: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2293, ????);     
            label_6:
            // 0x01C04314: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x01C04318: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x01C0431C: LDR x8, [x8, #0xe18]       | X8 = 1152921504607645696;               
            // 0x01C04320: LDR x20, [x8]              | X20 = typeof(System.UInt32);            
            // 0x01C04324: CBNZ x19, #0x1c0432c       | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x01C04328: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2293, ????);     
            label_7:
            // 0x01C0432C: LDR x8, [x19]              | X8 = X2;                                
            // 0x01C04330: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01C04334: LDR x8, [x20, #0x30]       | X8 = System.UInt32.__il2cppRuntimeField_element_class;
            // 0x01C04338: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.UInt32.__il2cppRuntimeField_element_class)
            // 0x01C0433C: B.NE #0x1c04384            | if (X2 + 48 != System.UInt32.__il2cppRuntimeField_element_class) goto label_8;
            // 0x01C04340: MOV x0, x19                | X0 = X2;//m1                            
            // 0x01C04344: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x01C04348: LDR w8, [x0]               | W8 = X2;                                
            // 0x01C0434C: STR w8, [x21, #0x3c]       | mem[60] = X2;                            //  dest_result_addr=60
            mem[60] = X2;
            // 0x01C04350: SUB sp, x29, #0x20         | SP = (1152921510259848912 - 32) = 1152921510259848880 (0x1000000150F1F6B0);
            // 0x01C04354: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01C04358: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01C0435C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01C04360: RET                        |  return;                                
            return;
            // 0x01C04364: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01C04368: ADD x0, sp, #8             | X0 = (1152921510259848928 + 8) = 1152921510259848936 (0x1000000150F1F6E8);
            // 0x01C0436C: B #0x1c04378               |  goto label_10;                         
            goto label_10;
            // 0x01C04370: MOV x19, x0                | X19 = 1152921510259848936 (0x1000000150F1F6E8);//ML01
            val_7;
            // 0x01C04374: ADD x0, sp, #0x10          | X0 = (1152921510259848928 + 16) = 1152921510259848944 (0x1000000150F1F6F0);
            label_10:
            // 0x01C04378: BL #0x299a140              | 
            // 0x01C0437C: MOV x0, x19                | X0 = 1152921510259848936 (0x1000000150F1F6E8);//ML01
            // 0x01C04380: BL #0x980800               | X0 = sub_980800( ?? 0x1000000150F1F6E8, ????);
            label_8:
            // 0x01C04384: ADD x8, sp, #0x18          | X8 = (1152921510259848928 + 24) = 1152921510259848952 (0x1000000150F1F6F8);
            // 0x01C04388: MOV x1, x20                | X1 = X20;//m1                           
            // 0x01C0438C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000150F1F6E8, ????);
            // 0x01C04390: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510259836928]
            // 0x01C04394: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01C04398: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C0439C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01C043A0: ADD x0, sp, #0x18          | X0 = (1152921510259848928 + 24) = 1152921510259848952 (0x1000000150F1F6F8);
            // 0x01C043A4: BL #0x299a140              | 
            // 0x01C043A8: MOV x19, x0                | X19 = 1152921510259848952 (0x1000000150F1F6F8);//ML01
            // 0x01C043AC: ADD x0, sp, #0x18          | X0 = (1152921510259848928 + 24) = 1152921510259848952 (0x1000000150F1F6F8);
            // 0x01C043B0: B #0x1c04378               |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C043B4 (29377460), len: 312  VirtAddr: 0x01C043B4 RVA: 0x01C043B4 token: 100665108 methodIndex: 31157 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_power_8(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01C043B4: STP x20, x19, [sp, #-0x20]! | stack[1152921510259977120] = ???;  stack[1152921510259977128] = ???;  //  dest_result_addr=1152921510259977120 |  dest_result_addr=1152921510259977128
            // 0x01C043B8: STP x29, x30, [sp, #0x10]  | stack[1152921510259977136] = ???;  stack[1152921510259977144] = ???;  //  dest_result_addr=1152921510259977136 |  dest_result_addr=1152921510259977144
            // 0x01C043BC: ADD x29, sp, #0x10         | X29 = (1152921510259977120 + 16) = 1152921510259977136 (0x1000000150F3EBB0);
            // 0x01C043C0: SUB sp, sp, #0x20          | SP = (1152921510259977120 - 32) = 1152921510259977088 (0x1000000150F3EB80);
            // 0x01C043C4: ADRP x20, #0x373c000       | X20 = 57917440 (0x373C000);             
            // 0x01C043C8: LDRB w8, [x20, #0x26f]     | W8 = (bool)static_value_0373C26F;       
            // 0x01C043CC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01C043D0: TBNZ w8, #0, #0x1c043ec    | if (static_value_0373C26F == true) goto label_0;
            // 0x01C043D4: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
            // 0x01C043D8: LDR x8, [x8, #0x750]       | X8 = 0x2B92F18;                         
            // 0x01C043DC: LDR w0, [x8]               | W0 = 0x228B;                            
            // 0x01C043E0: BL #0x2782188              | X0 = sub_2782188( ?? 0x228B, ????);     
            // 0x01C043E4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C043E8: STRB w8, [x20, #0x26f]     | static_value_0373C26F = true;            //  dest_result_addr=57918063
            label_0:
            // 0x01C043EC: ADRP x20, #0x35cd000       | X20 = 56414208 (0x35CD000);             
            // 0x01C043F0: LDR x19, [x19]             | X19 = X1;                               
            // 0x01C043F4: LDR x20, [x20, #0xd70]     | X20 = 1152921504904503296;              
            // 0x01C043F8: CBZ x19, #0x1c0444c        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01C043FC: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C04400: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C04404: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C04408: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C0440C: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C04410: B.LO #0x1c04428            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C04414: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C04418: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C0441C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C04420: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C04424: B.EQ #0x1c04450            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C04428: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C0442C: ADD x8, sp, #0x10          | X8 = (1152921510259977088 + 16) = 1152921510259977104 (0x1000000150F3EB90);
            // 0x01C04430: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C04434: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510259965152]
            // 0x01C04438: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C0443C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C04440: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C04444: ADD x0, sp, #0x10          | X0 = (1152921510259977088 + 16) = 1152921510259977104 (0x1000000150F3EB90);
            // 0x01C04448: BL #0x299a140              | 
            label_1:
            // 0x01C0444C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150F3EB90, ????);
            label_3:
            // 0x01C04450: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C04454: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C04458: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C0445C: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C04460: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C04464: B.LO #0x1c044a8            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01C04468: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C0446C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C04470: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C04474: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C04478: B.NE #0x1c044a8            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01C0447C: ADRP x9, #0x35e2000        | X9 = 56500224 (0x35E2000);              
            // 0x01C04480: LDR w8, [x19, #0x40]       | W8 = X1 + 64;                           
            // 0x01C04484: LDR x9, [x9, #0xe18]       | X9 = 1152921504607645696;               
            // 0x01C04488: ADD x1, sp, #0xc           | X1 = (1152921510259977088 + 12) = 1152921510259977100 (0x1000000150F3EB8C);
            // 0x01C0448C: STR w8, [sp, #0xc]         | stack[1152921510259977100] = X1 + 64;    //  dest_result_addr=1152921510259977100
            // 0x01C04490: LDR x0, [x9]               | X0 = typeof(System.UInt32);             
            // 0x01C04494: BL #0x27bc028              | X0 = 1152921510260025168 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.UInt32), X1 + 64);
            // 0x01C04498: SUB sp, x29, #0x10         | SP = (1152921510259977136 - 16) = 1152921510259977120 (0x1000000150F3EBA0);
            // 0x01C0449C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01C044A0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01C044A4: RET                        |  return (System.Object)X1 + 64;         
            return (object)X1 + 64;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01C044A8: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C044AC: ADD x8, sp, #0x18          | X8 = (1152921510259977088 + 24) = 1152921510259977112 (0x1000000150F3EB98);
            // 0x01C044B0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C044B4: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510259965152]
            // 0x01C044B8: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C044BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C044C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C044C4: ADD x0, sp, #0x18          | X0 = (1152921510259977088 + 24) = 1152921510259977112 (0x1000000150F3EB98);
            // 0x01C044C8: BL #0x299a140              | 
            // 0x01C044CC: MOV x19, x0                | X19 = 1152921510259977112 (0x1000000150F3EB98);//ML01
            // 0x01C044D0: ADD x0, sp, #0x10          | X0 = (1152921510259977088 + 16) = 1152921510259977104 (0x1000000150F3EB90);
            label_6:
            // 0x01C044D4: BL #0x299a140              | 
            // 0x01C044D8: MOV x0, x19                | X0 = 1152921510259977112 (0x1000000150F3EB98);//ML01
            // 0x01C044DC: BL #0x980800               | X0 = sub_980800( ?? 0x1000000150F3EB98, ????);
            // 0x01C044E0: MOV x19, x0                | X19 = 1152921510259977112 (0x1000000150F3EB98);//ML01
            // 0x01C044E4: ADD x0, sp, #0x18          | X0 = (1152921510259977088 + 24) = 1152921510259977112 (0x1000000150F3EB98);
            // 0x01C044E8: B #0x1c044d4               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C044EC (29377772), len: 412  VirtAddr: 0x01C044EC RVA: 0x01C044EC token: 100665109 methodIndex: 31158 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_power_8(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x01C044EC: STP x22, x21, [sp, #-0x30]! | stack[1152921510260105328] = ???;  stack[1152921510260105336] = ???;  //  dest_result_addr=1152921510260105328 |  dest_result_addr=1152921510260105336
            // 0x01C044F0: STP x20, x19, [sp, #0x10]  | stack[1152921510260105344] = ???;  stack[1152921510260105352] = ???;  //  dest_result_addr=1152921510260105344 |  dest_result_addr=1152921510260105352
            // 0x01C044F4: STP x29, x30, [sp, #0x20]  | stack[1152921510260105360] = ???;  stack[1152921510260105368] = ???;  //  dest_result_addr=1152921510260105360 |  dest_result_addr=1152921510260105368
            // 0x01C044F8: ADD x29, sp, #0x20         | X29 = (1152921510260105328 + 32) = 1152921510260105360 (0x1000000150F5E090);
            // 0x01C044FC: SUB sp, sp, #0x20          | SP = (1152921510260105328 - 32) = 1152921510260105296 (0x1000000150F5E050);
            // 0x01C04500: ADRP x21, #0x373c000       | X21 = 57917440 (0x373C000);             
            // 0x01C04504: LDRB w8, [x21, #0x270]     | W8 = (bool)static_value_0373C270;       
            // 0x01C04508: MOV x19, x2                | X19 = X2;//m1                           
            // 0x01C0450C: MOV x20, x1                | X20 = v;//m1                            
            // 0x01C04510: TBNZ w8, #0, #0x1c0452c    | if (static_value_0373C270 == true) goto label_0;
            // 0x01C04514: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x01C04518: LDR x8, [x8, #0xd00]       | X8 = 0x2B92F4C;                         
            // 0x01C0451C: LDR w0, [x8]               | W0 = 0x2298;                            
            // 0x01C04520: BL #0x2782188              | X0 = sub_2782188( ?? 0x2298, ????);     
            // 0x01C04524: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C04528: STRB w8, [x21, #0x270]     | static_value_0373C270 = true;            //  dest_result_addr=57918064
            label_0:
            // 0x01C0452C: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x01C04530: CBZ x21, #0x1c045e4        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01C04534: ADRP x20, #0x35cd000       | X20 = 56414208 (0x35CD000);             
            // 0x01C04538: LDR x20, [x20, #0xd70]     | X20 = 1152921504904503296;              
            // 0x01C0453C: LDR x8, [x21]              | X8 = ;                                  
            // 0x01C04540: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C04544: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C04548: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C0454C: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C04550: B.LO #0x1c04568            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C04554: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C04558: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C0455C: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C04560: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C04564: B.EQ #0x1c04590            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C04568: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C0456C: ADD x8, sp, #8             | X8 = (1152921510260105296 + 8) = 1152921510260105304 (0x1000000150F5E058);
            // 0x01C04570: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C04574: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510260093376]
            // 0x01C04578: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C0457C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C04580: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C04584: ADD x0, sp, #8             | X0 = (1152921510260105296 + 8) = 1152921510260105304 (0x1000000150F5E058);
            // 0x01C04588: BL #0x299a140              | 
            // 0x01C0458C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150F5E058, ????);
            label_3:
            // 0x01C04590: LDR x8, [x21]              | X8 = ;                                  
            // 0x01C04594: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C04598: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C0459C: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C045A0: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C045A4: B.LO #0x1c045bc            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01C045A8: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C045AC: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C045B0: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C045B4: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C045B8: B.EQ #0x1c045ec            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01C045BC: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C045C0: ADD x8, sp, #0x10          | X8 = (1152921510260105296 + 16) = 1152921510260105312 (0x1000000150F5E060);
            // 0x01C045C4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C045C8: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510260093376]
            // 0x01C045CC: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C045D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C045D4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C045D8: ADD x0, sp, #0x10          | X0 = (1152921510260105296 + 16) = 1152921510260105312 (0x1000000150F5E060);
            // 0x01C045DC: BL #0x299a140              | 
            // 0x01C045E0: B #0x1c045e8               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01C045E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2298, ????);     
            label_6:
            // 0x01C045E8: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x01C045EC: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x01C045F0: LDR x8, [x8, #0xe18]       | X8 = 1152921504607645696;               
            // 0x01C045F4: LDR x20, [x8]              | X20 = typeof(System.UInt32);            
            // 0x01C045F8: CBNZ x19, #0x1c04600       | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x01C045FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2298, ????);     
            label_7:
            // 0x01C04600: LDR x8, [x19]              | X8 = X2;                                
            // 0x01C04604: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01C04608: LDR x8, [x20, #0x30]       | X8 = System.UInt32.__il2cppRuntimeField_element_class;
            // 0x01C0460C: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.UInt32.__il2cppRuntimeField_element_class)
            // 0x01C04610: B.NE #0x1c04658            | if (X2 + 48 != System.UInt32.__il2cppRuntimeField_element_class) goto label_8;
            // 0x01C04614: MOV x0, x19                | X0 = X2;//m1                            
            // 0x01C04618: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x01C0461C: LDR w8, [x0]               | W8 = X2;                                
            // 0x01C04620: STR w8, [x21, #0x40]       | mem[64] = X2;                            //  dest_result_addr=64
            mem[64] = X2;
            // 0x01C04624: SUB sp, x29, #0x20         | SP = (1152921510260105360 - 32) = 1152921510260105328 (0x1000000150F5E070);
            // 0x01C04628: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01C0462C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01C04630: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01C04634: RET                        |  return;                                
            return;
            // 0x01C04638: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01C0463C: ADD x0, sp, #8             | X0 = (1152921510260105376 + 8) = 1152921510260105384 (0x1000000150F5E0A8);
            // 0x01C04640: B #0x1c0464c               |  goto label_10;                         
            goto label_10;
            // 0x01C04644: MOV x19, x0                | X19 = 1152921510260105384 (0x1000000150F5E0A8);//ML01
            val_7;
            // 0x01C04648: ADD x0, sp, #0x10          | X0 = (1152921510260105376 + 16) = 1152921510260105392 (0x1000000150F5E0B0);
            label_10:
            // 0x01C0464C: BL #0x299a140              | 
            // 0x01C04650: MOV x0, x19                | X0 = 1152921510260105384 (0x1000000150F5E0A8);//ML01
            // 0x01C04654: BL #0x980800               | X0 = sub_980800( ?? 0x1000000150F5E0A8, ????);
            label_8:
            // 0x01C04658: ADD x8, sp, #0x18          | X8 = (1152921510260105376 + 24) = 1152921510260105400 (0x1000000150F5E0B8);
            // 0x01C0465C: MOV x1, x20                | X1 = X20;//m1                           
            // 0x01C04660: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000150F5E0A8, ????);
            // 0x01C04664: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510260093376]
            // 0x01C04668: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01C0466C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C04670: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01C04674: ADD x0, sp, #0x18          | X0 = (1152921510260105376 + 24) = 1152921510260105400 (0x1000000150F5E0B8);
            // 0x01C04678: BL #0x299a140              | 
            // 0x01C0467C: MOV x19, x0                | X19 = 1152921510260105400 (0x1000000150F5E0B8);//ML01
            // 0x01C04680: ADD x0, sp, #0x18          | X0 = (1152921510260105376 + 24) = 1152921510260105400 (0x1000000150F5E0B8);
            // 0x01C04684: B #0x1c0464c               |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C04688 (29378184), len: 312  VirtAddr: 0x01C04688 RVA: 0x01C04688 token: 100665110 methodIndex: 31159 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_serviceId_9(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01C04688: STP x20, x19, [sp, #-0x20]! | stack[1152921510260233568] = ???;  stack[1152921510260233576] = ???;  //  dest_result_addr=1152921510260233568 |  dest_result_addr=1152921510260233576
            // 0x01C0468C: STP x29, x30, [sp, #0x10]  | stack[1152921510260233584] = ???;  stack[1152921510260233592] = ???;  //  dest_result_addr=1152921510260233584 |  dest_result_addr=1152921510260233592
            // 0x01C04690: ADD x29, sp, #0x10         | X29 = (1152921510260233568 + 16) = 1152921510260233584 (0x1000000150F7D570);
            // 0x01C04694: SUB sp, sp, #0x20          | SP = (1152921510260233568 - 32) = 1152921510260233536 (0x1000000150F7D540);
            // 0x01C04698: ADRP x20, #0x373c000       | X20 = 57917440 (0x373C000);             
            // 0x01C0469C: LDRB w8, [x20, #0x271]     | W8 = (bool)static_value_0373C271;       
            // 0x01C046A0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01C046A4: TBNZ w8, #0, #0x1c046c0    | if (static_value_0373C271 == true) goto label_0;
            // 0x01C046A8: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
            // 0x01C046AC: LDR x8, [x8, #0x890]       | X8 = 0x2B92F24;                         
            // 0x01C046B0: LDR w0, [x8]               | W0 = 0x228E;                            
            // 0x01C046B4: BL #0x2782188              | X0 = sub_2782188( ?? 0x228E, ????);     
            // 0x01C046B8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C046BC: STRB w8, [x20, #0x271]     | static_value_0373C271 = true;            //  dest_result_addr=57918065
            label_0:
            // 0x01C046C0: ADRP x20, #0x35cd000       | X20 = 56414208 (0x35CD000);             
            // 0x01C046C4: LDR x19, [x19]             | X19 = X1;                               
            // 0x01C046C8: LDR x20, [x20, #0xd70]     | X20 = 1152921504904503296;              
            // 0x01C046CC: CBZ x19, #0x1c04720        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01C046D0: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C046D4: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C046D8: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C046DC: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C046E0: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C046E4: B.LO #0x1c046fc            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C046E8: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C046EC: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C046F0: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C046F4: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C046F8: B.EQ #0x1c04724            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C046FC: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C04700: ADD x8, sp, #0x10          | X8 = (1152921510260233536 + 16) = 1152921510260233552 (0x1000000150F7D550);
            // 0x01C04704: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C04708: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510260221600]
            // 0x01C0470C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C04710: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C04714: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C04718: ADD x0, sp, #0x10          | X0 = (1152921510260233536 + 16) = 1152921510260233552 (0x1000000150F7D550);
            // 0x01C0471C: BL #0x299a140              | 
            label_1:
            // 0x01C04720: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150F7D550, ????);
            label_3:
            // 0x01C04724: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C04728: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C0472C: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C04730: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C04734: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C04738: B.LO #0x1c0477c            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01C0473C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C04740: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C04744: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C04748: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C0474C: B.NE #0x1c0477c            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01C04750: ADRP x9, #0x35e2000        | X9 = 56500224 (0x35E2000);              
            // 0x01C04754: LDR w8, [x19, #0x44]       | W8 = X1 + 68;                           
            // 0x01C04758: LDR x9, [x9, #0xe18]       | X9 = 1152921504607645696;               
            // 0x01C0475C: ADD x1, sp, #0xc           | X1 = (1152921510260233536 + 12) = 1152921510260233548 (0x1000000150F7D54C);
            // 0x01C04760: STR w8, [sp, #0xc]         | stack[1152921510260233548] = X1 + 68;    //  dest_result_addr=1152921510260233548
            // 0x01C04764: LDR x0, [x9]               | X0 = typeof(System.UInt32);             
            // 0x01C04768: BL #0x27bc028              | X0 = 1152921510260281616 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.UInt32), X1 + 68);
            // 0x01C0476C: SUB sp, x29, #0x10         | SP = (1152921510260233584 - 16) = 1152921510260233568 (0x1000000150F7D560);
            // 0x01C04770: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01C04774: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01C04778: RET                        |  return (System.Object)X1 + 68;         
            return (object)X1 + 68;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01C0477C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C04780: ADD x8, sp, #0x18          | X8 = (1152921510260233536 + 24) = 1152921510260233560 (0x1000000150F7D558);
            // 0x01C04784: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C04788: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510260221600]
            // 0x01C0478C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C04790: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C04794: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C04798: ADD x0, sp, #0x18          | X0 = (1152921510260233536 + 24) = 1152921510260233560 (0x1000000150F7D558);
            // 0x01C0479C: BL #0x299a140              | 
            // 0x01C047A0: MOV x19, x0                | X19 = 1152921510260233560 (0x1000000150F7D558);//ML01
            // 0x01C047A4: ADD x0, sp, #0x10          | X0 = (1152921510260233536 + 16) = 1152921510260233552 (0x1000000150F7D550);
            label_6:
            // 0x01C047A8: BL #0x299a140              | 
            // 0x01C047AC: MOV x0, x19                | X0 = 1152921510260233560 (0x1000000150F7D558);//ML01
            // 0x01C047B0: BL #0x980800               | X0 = sub_980800( ?? 0x1000000150F7D558, ????);
            // 0x01C047B4: MOV x19, x0                | X19 = 1152921510260233560 (0x1000000150F7D558);//ML01
            // 0x01C047B8: ADD x0, sp, #0x18          | X0 = (1152921510260233536 + 24) = 1152921510260233560 (0x1000000150F7D558);
            // 0x01C047BC: B #0x1c047a8               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C047C0 (29378496), len: 412  VirtAddr: 0x01C047C0 RVA: 0x01C047C0 token: 100665111 methodIndex: 31160 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_serviceId_9(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x01C047C0: STP x22, x21, [sp, #-0x30]! | stack[1152921510260361776] = ???;  stack[1152921510260361784] = ???;  //  dest_result_addr=1152921510260361776 |  dest_result_addr=1152921510260361784
            // 0x01C047C4: STP x20, x19, [sp, #0x10]  | stack[1152921510260361792] = ???;  stack[1152921510260361800] = ???;  //  dest_result_addr=1152921510260361792 |  dest_result_addr=1152921510260361800
            // 0x01C047C8: STP x29, x30, [sp, #0x20]  | stack[1152921510260361808] = ???;  stack[1152921510260361816] = ???;  //  dest_result_addr=1152921510260361808 |  dest_result_addr=1152921510260361816
            // 0x01C047CC: ADD x29, sp, #0x20         | X29 = (1152921510260361776 + 32) = 1152921510260361808 (0x1000000150F9CA50);
            // 0x01C047D0: SUB sp, sp, #0x20          | SP = (1152921510260361776 - 32) = 1152921510260361744 (0x1000000150F9CA10);
            // 0x01C047D4: ADRP x21, #0x373c000       | X21 = 57917440 (0x373C000);             
            // 0x01C047D8: LDRB w8, [x21, #0x272]     | W8 = (bool)static_value_0373C272;       
            // 0x01C047DC: MOV x19, x2                | X19 = X2;//m1                           
            // 0x01C047E0: MOV x20, x1                | X20 = v;//m1                            
            // 0x01C047E4: TBNZ w8, #0, #0x1c04800    | if (static_value_0373C272 == true) goto label_0;
            // 0x01C047E8: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x01C047EC: LDR x8, [x8, #0x638]       | X8 = 0x2B92F58;                         
            // 0x01C047F0: LDR w0, [x8]               | W0 = 0x229B;                            
            // 0x01C047F4: BL #0x2782188              | X0 = sub_2782188( ?? 0x229B, ????);     
            // 0x01C047F8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C047FC: STRB w8, [x21, #0x272]     | static_value_0373C272 = true;            //  dest_result_addr=57918066
            label_0:
            // 0x01C04800: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x01C04804: CBZ x21, #0x1c048b8        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01C04808: ADRP x20, #0x35cd000       | X20 = 56414208 (0x35CD000);             
            // 0x01C0480C: LDR x20, [x20, #0xd70]     | X20 = 1152921504904503296;              
            // 0x01C04810: LDR x8, [x21]              | X8 = ;                                  
            // 0x01C04814: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C04818: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C0481C: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C04820: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C04824: B.LO #0x1c0483c            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C04828: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C0482C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C04830: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C04834: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C04838: B.EQ #0x1c04864            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C0483C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C04840: ADD x8, sp, #8             | X8 = (1152921510260361744 + 8) = 1152921510260361752 (0x1000000150F9CA18);
            // 0x01C04844: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C04848: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510260349824]
            // 0x01C0484C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C04850: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C04854: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C04858: ADD x0, sp, #8             | X0 = (1152921510260361744 + 8) = 1152921510260361752 (0x1000000150F9CA18);
            // 0x01C0485C: BL #0x299a140              | 
            // 0x01C04860: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150F9CA18, ????);
            label_3:
            // 0x01C04864: LDR x8, [x21]              | X8 = ;                                  
            // 0x01C04868: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C0486C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C04870: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C04874: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C04878: B.LO #0x1c04890            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01C0487C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C04880: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C04884: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C04888: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C0488C: B.EQ #0x1c048c0            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01C04890: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C04894: ADD x8, sp, #0x10          | X8 = (1152921510260361744 + 16) = 1152921510260361760 (0x1000000150F9CA20);
            // 0x01C04898: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C0489C: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510260349824]
            // 0x01C048A0: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C048A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C048A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C048AC: ADD x0, sp, #0x10          | X0 = (1152921510260361744 + 16) = 1152921510260361760 (0x1000000150F9CA20);
            // 0x01C048B0: BL #0x299a140              | 
            // 0x01C048B4: B #0x1c048bc               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01C048B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x229B, ????);     
            label_6:
            // 0x01C048BC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x01C048C0: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x01C048C4: LDR x8, [x8, #0xe18]       | X8 = 1152921504607645696;               
            // 0x01C048C8: LDR x20, [x8]              | X20 = typeof(System.UInt32);            
            // 0x01C048CC: CBNZ x19, #0x1c048d4       | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x01C048D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x229B, ????);     
            label_7:
            // 0x01C048D4: LDR x8, [x19]              | X8 = X2;                                
            // 0x01C048D8: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01C048DC: LDR x8, [x20, #0x30]       | X8 = System.UInt32.__il2cppRuntimeField_element_class;
            // 0x01C048E0: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.UInt32.__il2cppRuntimeField_element_class)
            // 0x01C048E4: B.NE #0x1c0492c            | if (X2 + 48 != System.UInt32.__il2cppRuntimeField_element_class) goto label_8;
            // 0x01C048E8: MOV x0, x19                | X0 = X2;//m1                            
            // 0x01C048EC: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x01C048F0: LDR w8, [x0]               | W8 = X2;                                
            // 0x01C048F4: STR w8, [x21, #0x44]       | mem[68] = X2;                            //  dest_result_addr=68
            mem[68] = X2;
            // 0x01C048F8: SUB sp, x29, #0x20         | SP = (1152921510260361808 - 32) = 1152921510260361776 (0x1000000150F9CA30);
            // 0x01C048FC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01C04900: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01C04904: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01C04908: RET                        |  return;                                
            return;
            // 0x01C0490C: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01C04910: ADD x0, sp, #8             | X0 = (1152921510260361824 + 8) = 1152921510260361832 (0x1000000150F9CA68);
            // 0x01C04914: B #0x1c04920               |  goto label_10;                         
            goto label_10;
            // 0x01C04918: MOV x19, x0                | X19 = 1152921510260361832 (0x1000000150F9CA68);//ML01
            val_7;
            // 0x01C0491C: ADD x0, sp, #0x10          | X0 = (1152921510260361824 + 16) = 1152921510260361840 (0x1000000150F9CA70);
            label_10:
            // 0x01C04920: BL #0x299a140              | 
            // 0x01C04924: MOV x0, x19                | X0 = 1152921510260361832 (0x1000000150F9CA68);//ML01
            // 0x01C04928: BL #0x980800               | X0 = sub_980800( ?? 0x1000000150F9CA68, ????);
            label_8:
            // 0x01C0492C: ADD x8, sp, #0x18          | X8 = (1152921510260361824 + 24) = 1152921510260361848 (0x1000000150F9CA78);
            // 0x01C04930: MOV x1, x20                | X1 = X20;//m1                           
            // 0x01C04934: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000150F9CA68, ????);
            // 0x01C04938: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510260349824]
            // 0x01C0493C: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01C04940: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C04944: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01C04948: ADD x0, sp, #0x18          | X0 = (1152921510260361824 + 24) = 1152921510260361848 (0x1000000150F9CA78);
            // 0x01C0494C: BL #0x299a140              | 
            // 0x01C04950: MOV x19, x0                | X19 = 1152921510260361848 (0x1000000150F9CA78);//ML01
            // 0x01C04954: ADD x0, sp, #0x18          | X0 = (1152921510260361824 + 24) = 1152921510260361848 (0x1000000150F9CA78);
            // 0x01C04958: B #0x1c04920               |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C0495C (29378908), len: 288  VirtAddr: 0x01C0495C RVA: 0x01C0495C token: 100665112 methodIndex: 31161 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_serviceName_10(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01C0495C: STP x20, x19, [sp, #-0x20]! | stack[1152921510260485920] = ???;  stack[1152921510260485928] = ???;  //  dest_result_addr=1152921510260485920 |  dest_result_addr=1152921510260485928
            // 0x01C04960: STP x29, x30, [sp, #0x10]  | stack[1152921510260485936] = ???;  stack[1152921510260485944] = ???;  //  dest_result_addr=1152921510260485936 |  dest_result_addr=1152921510260485944
            // 0x01C04964: ADD x29, sp, #0x10         | X29 = (1152921510260485920 + 16) = 1152921510260485936 (0x1000000150FBAF30);
            // 0x01C04968: SUB sp, sp, #0x10          | SP = (1152921510260485920 - 16) = 1152921510260485904 (0x1000000150FBAF10);
            // 0x01C0496C: ADRP x20, #0x373c000       | X20 = 57917440 (0x373C000);             
            // 0x01C04970: LDRB w8, [x20, #0x273]     | W8 = (bool)static_value_0373C273;       
            // 0x01C04974: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01C04978: TBNZ w8, #0, #0x1c04994    | if (static_value_0373C273 == true) goto label_0;
            // 0x01C0497C: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x01C04980: LDR x8, [x8, #0x728]       | X8 = 0x2B92F28;                         
            // 0x01C04984: LDR w0, [x8]               | W0 = 0x228F;                            
            // 0x01C04988: BL #0x2782188              | X0 = sub_2782188( ?? 0x228F, ????);     
            // 0x01C0498C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C04990: STRB w8, [x20, #0x273]     | static_value_0373C273 = true;            //  dest_result_addr=57918067
            label_0:
            // 0x01C04994: ADRP x20, #0x35cd000       | X20 = 56414208 (0x35CD000);             
            // 0x01C04998: LDR x19, [x19]             | X19 = X1;                               
            // 0x01C0499C: LDR x20, [x20, #0xd70]     | X20 = 1152921504904503296;              
            // 0x01C049A0: CBZ x19, #0x1c049f4        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01C049A4: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C049A8: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C049AC: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C049B0: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C049B4: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C049B8: B.LO #0x1c049d0            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C049BC: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C049C0: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C049C4: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C049C8: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C049CC: B.EQ #0x1c049f8            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C049D0: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C049D4: MOV x8, sp                 | X8 = 1152921510260485904 (0x1000000150FBAF10);//ML01
            // 0x01C049D8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C049DC: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510260473952]
            // 0x01C049E0: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C049E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C049E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C049EC: MOV x0, sp                 | X0 = 1152921510260485904 (0x1000000150FBAF10);//ML01
            // 0x01C049F0: BL #0x299a140              | 
            label_1:
            // 0x01C049F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150FBAF10, ????);
            label_3:
            // 0x01C049F8: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C049FC: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C04A00: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C04A04: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C04A08: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C04A0C: B.LO #0x1c04a38            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01C04A10: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C04A14: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C04A18: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C04A1C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C04A20: B.NE #0x1c04a38            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01C04A24: LDR x0, [x19, #0x48]       | X0 = X1 + 72;                           
            // 0x01C04A28: SUB sp, x29, #0x10         | SP = (1152921510260485936 - 16) = 1152921510260485920 (0x1000000150FBAF20);
            // 0x01C04A2C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01C04A30: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01C04A34: RET                        |  return (System.Object)X1 + 72;         
            return (object)X1 + 72;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01C04A38: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C04A3C: ADD x8, sp, #8             | X8 = (1152921510260485904 + 8) = 1152921510260485912 (0x1000000150FBAF18);
            // 0x01C04A40: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C04A44: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510260473952]
            // 0x01C04A48: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C04A4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C04A50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C04A54: ADD x0, sp, #8             | X0 = (1152921510260485904 + 8) = 1152921510260485912 (0x1000000150FBAF18);
            // 0x01C04A58: BL #0x299a140              | 
            // 0x01C04A5C: MOV x19, x0                | X19 = 1152921510260485912 (0x1000000150FBAF18);//ML01
            // 0x01C04A60: MOV x0, sp                 | X0 = 1152921510260485904 (0x1000000150FBAF10);//ML01
            label_6:
            // 0x01C04A64: BL #0x299a140              | 
            // 0x01C04A68: MOV x0, x19                | X0 = 1152921510260485912 (0x1000000150FBAF18);//ML01
            // 0x01C04A6C: BL #0x980800               | X0 = sub_980800( ?? 0x1000000150FBAF18, ????);
            // 0x01C04A70: MOV x19, x0                | X19 = 1152921510260485912 (0x1000000150FBAF18);//ML01
            // 0x01C04A74: ADD x0, sp, #8             | X0 = (1152921510260485904 + 8) = 1152921510260485912 (0x1000000150FBAF18);
            // 0x01C04A78: B #0x1c04a64               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C04A7C (29379196), len: 392  VirtAddr: 0x01C04A7C RVA: 0x01C04A7C token: 100665113 methodIndex: 31162 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_serviceName_10(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x01C04A7C: STP x22, x21, [sp, #-0x30]! | stack[1152921510260610032] = ???;  stack[1152921510260610040] = ???;  //  dest_result_addr=1152921510260610032 |  dest_result_addr=1152921510260610040
            // 0x01C04A80: STP x20, x19, [sp, #0x10]  | stack[1152921510260610048] = ???;  stack[1152921510260610056] = ???;  //  dest_result_addr=1152921510260610048 |  dest_result_addr=1152921510260610056
            // 0x01C04A84: STP x29, x30, [sp, #0x20]  | stack[1152921510260610064] = ???;  stack[1152921510260610072] = ???;  //  dest_result_addr=1152921510260610064 |  dest_result_addr=1152921510260610072
            // 0x01C04A88: ADD x29, sp, #0x20         | X29 = (1152921510260610032 + 32) = 1152921510260610064 (0x1000000150FD9410);
            // 0x01C04A8C: SUB sp, sp, #0x20          | SP = (1152921510260610032 - 32) = 1152921510260610000 (0x1000000150FD93D0);
            // 0x01C04A90: ADRP x21, #0x373c000       | X21 = 57917440 (0x373C000);             
            // 0x01C04A94: LDRB w8, [x21, #0x274]     | W8 = (bool)static_value_0373C274;       
            // 0x01C04A98: MOV x19, x2                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01C04A9C: MOV x20, x1                | X20 = v;//m1                            
            // 0x01C04AA0: TBNZ w8, #0, #0x1c04abc    | if (static_value_0373C274 == true) goto label_0;
            // 0x01C04AA4: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x01C04AA8: LDR x8, [x8, #0xe98]       | X8 = 0x2B92F5C;                         
            // 0x01C04AAC: LDR w0, [x8]               | W0 = 0x229C;                            
            // 0x01C04AB0: BL #0x2782188              | X0 = sub_2782188( ?? 0x229C, ????);     
            // 0x01C04AB4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C04AB8: STRB w8, [x21, #0x274]     | static_value_0373C274 = true;            //  dest_result_addr=57918068
            label_0:
            // 0x01C04ABC: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x01C04AC0: CBZ x20, #0x1c04b74        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01C04AC4: ADRP x21, #0x35cd000       | X21 = 56414208 (0x35CD000);             
            // 0x01C04AC8: LDR x21, [x21, #0xd70]     | X21 = 1152921504904503296;              
            val_6 = 1152921504904503296;
            // 0x01C04ACC: LDR x8, [x20]              | X8 = ;                                  
            // 0x01C04AD0: LDR x1, [x21]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C04AD4: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C04AD8: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C04ADC: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C04AE0: B.LO #0x1c04af8            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C04AE4: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C04AE8: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C04AEC: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C04AF0: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C04AF4: B.EQ #0x1c04b20            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C04AF8: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C04AFC: ADD x8, sp, #8             | X8 = (1152921510260610000 + 8) = 1152921510260610008 (0x1000000150FD93D8);
            // 0x01C04B00: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C04B04: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510260598080]
            // 0x01C04B08: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C04B0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C04B10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C04B14: ADD x0, sp, #8             | X0 = (1152921510260610000 + 8) = 1152921510260610008 (0x1000000150FD93D8);
            // 0x01C04B18: BL #0x299a140              | 
            // 0x01C04B1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150FD93D8, ????);
            label_3:
            // 0x01C04B20: LDR x8, [x20]              | X8 = ;                                  
            // 0x01C04B24: LDR x1, [x21]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C04B28: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C04B2C: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C04B30: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C04B34: B.LO #0x1c04b4c            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01C04B38: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C04B3C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C04B40: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C04B44: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C04B48: B.EQ #0x1c04b7c            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01C04B4C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C04B50: ADD x8, sp, #0x10          | X8 = (1152921510260610000 + 16) = 1152921510260610016 (0x1000000150FD93E0);
            // 0x01C04B54: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C04B58: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510260598080]
            // 0x01C04B5C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C04B60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C04B64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C04B68: ADD x0, sp, #0x10          | X0 = (1152921510260610000 + 16) = 1152921510260610016 (0x1000000150FD93E0);
            // 0x01C04B6C: BL #0x299a140              | 
            // 0x01C04B70: B #0x1c04b78               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01C04B74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x229C, ????);     
            label_6:
            // 0x01C04B78: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_5:
            // 0x01C04B7C: CBZ x19, #0x1c04bbc        | if (X2 == 0) goto label_7;              
            if(val_7 == 0)
            {
                goto label_7;
            }
            // 0x01C04B80: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01C04B84: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01C04B88: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01C04B8C: LDR x8, [x19]              | X8 = X2;                                
            // 0x01C04B90: CMP x8, x1                 | STATE = COMPARE(X2, typeof(System.String))
            // 0x01C04B94: B.EQ #0x1c04bc0            | if (val_7 == null) goto label_8;        
            if(val_7 == null)
            {
                goto label_8;
            }
            // 0x01C04B98: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01C04B9C: ADD x8, sp, #0x18          | X8 = (1152921510260610000 + 24) = 1152921510260610024 (0x1000000150FD93E8);
            // 0x01C04BA0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x01C04BA4: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510260598080]
            // 0x01C04BA8: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01C04BAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C04BB0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01C04BB4: ADD x0, sp, #0x18          | X0 = (1152921510260610000 + 24) = 1152921510260610024 (0x1000000150FD93E8);
            // 0x01C04BB8: BL #0x299a140              | 
            label_7:
            // 0x01C04BBC: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_8:
            // 0x01C04BC0: STR x19, [x20, #0x48]      | mem[72] = 0x0;                           //  dest_result_addr=72
            mem[72] = val_7;
            // 0x01C04BC4: SUB sp, x29, #0x20         | SP = (1152921510260610064 - 32) = 1152921510260610032 (0x1000000150FD93F0);
            // 0x01C04BC8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01C04BCC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01C04BD0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01C04BD4: RET                        |  return;                                
            return;
            // 0x01C04BD8: MOV x19, x0                | 
            // 0x01C04BDC: ADD x0, sp, #8             | 
            // 0x01C04BE0: B #0x1c04bf8               | 
            // 0x01C04BE4: MOV x19, x0                | 
            // 0x01C04BE8: ADD x0, sp, #0x10          | 
            // 0x01C04BEC: B #0x1c04bf8               | 
            // 0x01C04BF0: MOV x19, x0                | 
            // 0x01C04BF4: ADD x0, sp, #0x18          | 
            label_10:
            // 0x01C04BF8: BL #0x299a140              | 
            // 0x01C04BFC: MOV x0, x19                | 
            // 0x01C04C00: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01C04C04 (29379588), len: 288  VirtAddr: 0x01C04C04 RVA: 0x01C04C04 token: 100665114 methodIndex: 31163 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_heroGroups_11(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01C04C04: STP x20, x19, [sp, #-0x20]! | stack[1152921510260734176] = ???;  stack[1152921510260734184] = ???;  //  dest_result_addr=1152921510260734176 |  dest_result_addr=1152921510260734184
            // 0x01C04C08: STP x29, x30, [sp, #0x10]  | stack[1152921510260734192] = ???;  stack[1152921510260734200] = ???;  //  dest_result_addr=1152921510260734192 |  dest_result_addr=1152921510260734200
            // 0x01C04C0C: ADD x29, sp, #0x10         | X29 = (1152921510260734176 + 16) = 1152921510260734192 (0x1000000150FF78F0);
            // 0x01C04C10: SUB sp, sp, #0x10          | SP = (1152921510260734176 - 16) = 1152921510260734160 (0x1000000150FF78D0);
            // 0x01C04C14: ADRP x20, #0x373c000       | X20 = 57917440 (0x373C000);             
            // 0x01C04C18: LDRB w8, [x20, #0x275]     | W8 = (bool)static_value_0373C275;       
            // 0x01C04C1C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01C04C20: TBNZ w8, #0, #0x1c04c3c    | if (static_value_0373C275 == true) goto label_0;
            // 0x01C04C24: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x01C04C28: LDR x8, [x8, #0x168]       | X8 = 0x2B92F08;                         
            // 0x01C04C2C: LDR w0, [x8]               | W0 = 0x2287;                            
            // 0x01C04C30: BL #0x2782188              | X0 = sub_2782188( ?? 0x2287, ????);     
            // 0x01C04C34: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C04C38: STRB w8, [x20, #0x275]     | static_value_0373C275 = true;            //  dest_result_addr=57918069
            label_0:
            // 0x01C04C3C: ADRP x20, #0x35cd000       | X20 = 56414208 (0x35CD000);             
            // 0x01C04C40: LDR x19, [x19]             | X19 = X1;                               
            // 0x01C04C44: LDR x20, [x20, #0xd70]     | X20 = 1152921504904503296;              
            // 0x01C04C48: CBZ x19, #0x1c04c9c        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01C04C4C: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C04C50: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C04C54: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C04C58: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C04C5C: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C04C60: B.LO #0x1c04c78            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C04C64: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C04C68: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C04C6C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C04C70: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C04C74: B.EQ #0x1c04ca0            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C04C78: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C04C7C: MOV x8, sp                 | X8 = 1152921510260734160 (0x1000000150FF78D0);//ML01
            // 0x01C04C80: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C04C84: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510260722208]
            // 0x01C04C88: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C04C8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C04C90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C04C94: MOV x0, sp                 | X0 = 1152921510260734160 (0x1000000150FF78D0);//ML01
            // 0x01C04C98: BL #0x299a140              | 
            label_1:
            // 0x01C04C9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150FF78D0, ????);
            label_3:
            // 0x01C04CA0: LDR x8, [x19]              | X8 = X1;                                
            // 0x01C04CA4: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C04CA8: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01C04CAC: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C04CB0: CMP w10, w9                | STATE = COMPARE(X1 + 260, CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C04CB4: B.LO #0x1c04ce0            | if (X1 + 260 < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01C04CB8: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01C04CBC: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C04CC0: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C04CC4: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C04CC8: B.NE #0x1c04ce0            | if ((X1 + 176 + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01C04CCC: LDR x0, [x19, #0x50]       | X0 = X1 + 80;                           
            // 0x01C04CD0: SUB sp, x29, #0x10         | SP = (1152921510260734192 - 16) = 1152921510260734176 (0x1000000150FF78E0);
            // 0x01C04CD4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01C04CD8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01C04CDC: RET                        |  return (System.Object)X1 + 80;         
            return (object)X1 + 80;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01C04CE0: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01C04CE4: ADD x8, sp, #8             | X8 = (1152921510260734160 + 8) = 1152921510260734168 (0x1000000150FF78D8);
            // 0x01C04CE8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01C04CEC: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510260722208]
            // 0x01C04CF0: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C04CF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C04CF8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C04CFC: ADD x0, sp, #8             | X0 = (1152921510260734160 + 8) = 1152921510260734168 (0x1000000150FF78D8);
            // 0x01C04D00: BL #0x299a140              | 
            // 0x01C04D04: MOV x19, x0                | X19 = 1152921510260734168 (0x1000000150FF78D8);//ML01
            // 0x01C04D08: MOV x0, sp                 | X0 = 1152921510260734160 (0x1000000150FF78D0);//ML01
            label_6:
            // 0x01C04D0C: BL #0x299a140              | 
            // 0x01C04D10: MOV x0, x19                | X0 = 1152921510260734168 (0x1000000150FF78D8);//ML01
            // 0x01C04D14: BL #0x980800               | X0 = sub_980800( ?? 0x1000000150FF78D8, ????);
            // 0x01C04D18: MOV x19, x0                | X19 = 1152921510260734168 (0x1000000150FF78D8);//ML01
            // 0x01C04D1C: ADD x0, sp, #8             | X0 = (1152921510260734160 + 8) = 1152921510260734168 (0x1000000150FF78D8);
            // 0x01C04D20: B #0x1c04d0c               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C04D24 (29379876), len: 404  VirtAddr: 0x01C04D24 RVA: 0x01C04D24 token: 100665115 methodIndex: 31164 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_heroGroups_11(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            // 0x01C04D24: STP x22, x21, [sp, #-0x30]! | stack[1152921510260862384] = ???;  stack[1152921510260862392] = ???;  //  dest_result_addr=1152921510260862384 |  dest_result_addr=1152921510260862392
            // 0x01C04D28: STP x20, x19, [sp, #0x10]  | stack[1152921510260862400] = ???;  stack[1152921510260862408] = ???;  //  dest_result_addr=1152921510260862400 |  dest_result_addr=1152921510260862408
            // 0x01C04D2C: STP x29, x30, [sp, #0x20]  | stack[1152921510260862416] = ???;  stack[1152921510260862424] = ???;  //  dest_result_addr=1152921510260862416 |  dest_result_addr=1152921510260862424
            // 0x01C04D30: ADD x29, sp, #0x20         | X29 = (1152921510260862384 + 32) = 1152921510260862416 (0x1000000151016DD0);
            // 0x01C04D34: SUB sp, sp, #0x20          | SP = (1152921510260862384 - 32) = 1152921510260862352 (0x1000000151016D90);
            // 0x01C04D38: ADRP x21, #0x373c000       | X21 = 57917440 (0x373C000);             
            // 0x01C04D3C: LDRB w8, [x21, #0x276]     | W8 = (bool)static_value_0373C276;       
            // 0x01C04D40: MOV x19, x2                | X19 = X2;//m1                           
            // 0x01C04D44: MOV x20, x1                | X20 = v;//m1                            
            // 0x01C04D48: TBNZ w8, #0, #0x1c04d64    | if (static_value_0373C276 == true) goto label_0;
            // 0x01C04D4C: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
            // 0x01C04D50: LDR x8, [x8, #0xfa8]       | X8 = 0x2B92F3C;                         
            // 0x01C04D54: LDR w0, [x8]               | W0 = 0x2294;                            
            // 0x01C04D58: BL #0x2782188              | X0 = sub_2782188( ?? 0x2294, ????);     
            // 0x01C04D5C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C04D60: STRB w8, [x21, #0x276]     | static_value_0373C276 = true;            //  dest_result_addr=57918070
            label_0:
            // 0x01C04D64: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x01C04D68: CBZ x21, #0x1c04e1c        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01C04D6C: ADRP x20, #0x35cd000       | X20 = 56414208 (0x35CD000);             
            // 0x01C04D70: LDR x20, [x20, #0xd70]     | X20 = 1152921504904503296;              
            // 0x01C04D74: LDR x8, [x21]              | X8 = ;                                  
            // 0x01C04D78: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C04D7C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C04D80: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C04D84: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C04D88: B.LO #0x1c04da0            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01C04D8C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C04D90: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C04D94: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C04D98: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C04D9C: B.EQ #0x1c04dc8            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01C04DA0: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C04DA4: ADD x8, sp, #8             | X8 = (1152921510260862352 + 8) = 1152921510260862360 (0x1000000151016D98);
            // 0x01C04DA8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C04DAC: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510260850432]
            // 0x01C04DB0: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01C04DB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C04DB8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01C04DBC: ADD x0, sp, #8             | X0 = (1152921510260862352 + 8) = 1152921510260862360 (0x1000000151016D98);
            // 0x01C04DC0: BL #0x299a140              | 
            // 0x01C04DC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000151016D98, ????);
            label_3:
            // 0x01C04DC8: LDR x8, [x21]              | X8 = ;                                  
            // 0x01C04DCC: LDR x1, [x20]              | X1 = typeof(CSAISPlayerData);           
            // 0x01C04DD0: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01C04DD4: LDRB w9, [x1, #0x104]      | W9 = CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C04DD8: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C04DDC: B.LO #0x1c04df4            | if (mem[null + 260] < CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01C04DE0: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01C04DE4: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01C04DE8: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C04DEC: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CSAISPlayerData))
            // 0x01C04DF0: B.EQ #0x1c04e24            | if ((mem[null + 176] + (CSAISPlayerData.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01C04DF4: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C04DF8: ADD x8, sp, #0x10          | X8 = (1152921510260862352 + 16) = 1152921510260862368 (0x1000000151016DA0);
            // 0x01C04DFC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01C04E00: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510260850432]
            // 0x01C04E04: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01C04E08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C04E0C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01C04E10: ADD x0, sp, #0x10          | X0 = (1152921510260862352 + 16) = 1152921510260862368 (0x1000000151016DA0);
            // 0x01C04E14: BL #0x299a140              | 
            // 0x01C04E18: B #0x1c04e20               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01C04E1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2294, ????);     
            label_6:
            // 0x01C04E20: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x01C04E24: CBZ x19, #0x1c04e70        | if (X2 == 0) goto label_7;              
            if(X2 == 0)
            {
                goto label_7;
            }
            // 0x01C04E28: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x01C04E2C: LDR x8, [x8, #0xd48]       | X8 = 1152921510260846336;               
            // 0x01C04E30: MOV x0, x19                | X0 = X2;//m1                            
            val_7 = X2;
            // 0x01C04E34: LDR x20, [x8]              | X20 = typeof(CSHeroUnit[]);             
            // 0x01C04E38: MOV x1, x20                | X1 = 1152921510260846336 (0x1000000151012F00);//ML01
            // 0x01C04E3C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X2, ????);         
            // 0x01C04E40: CBNZ x0, #0x1c04e74        | if (X2 != 0) goto label_8;              
            if(val_7 != 0)
            {
                goto label_8;
            }
            // 0x01C04E44: LDR x8, [x19]              | X8 = X2;                                
            // 0x01C04E48: MOV x1, x20                | X1 = 1152921510260846336 (0x1000000151012F00);//ML01
            // 0x01C04E4C: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01C04E50: ADD x8, sp, #0x18          | X8 = (1152921510260862352 + 24) = 1152921510260862376 (0x1000000151016DA8);
            // 0x01C04E54: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x01C04E58: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510260850432]
            // 0x01C04E5C: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01C04E60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C04E64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01C04E68: ADD x0, sp, #0x18          | X0 = (1152921510260862352 + 24) = 1152921510260862376 (0x1000000151016DA8);
            // 0x01C04E6C: BL #0x299a140              | 
            label_7:
            // 0x01C04E70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_7 = 0;
            label_8:
            // 0x01C04E74: STR x0, [x21, #0x50]       | mem[80] = 0x0;                           //  dest_result_addr=80
            mem[80] = val_7;
            // 0x01C04E78: SUB sp, x29, #0x20         | SP = (1152921510260862416 - 32) = 1152921510260862384 (0x1000000151016DB0);
            // 0x01C04E7C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01C04E80: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01C04E84: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01C04E88: RET                        |  return;                                
            return;
            // 0x01C04E8C: MOV x19, x0                | 
            // 0x01C04E90: ADD x0, sp, #8             | 
            // 0x01C04E94: B #0x1c04eac               | 
            // 0x01C04E98: MOV x19, x0                | 
            // 0x01C04E9C: ADD x0, sp, #0x10          | 
            // 0x01C04EA0: B #0x1c04eac               | 
            // 0x01C04EA4: MOV x19, x0                | 
            // 0x01C04EA8: ADD x0, sp, #0x18          | 
            label_10:
            // 0x01C04EAC: BL #0x299a140              | 
            // 0x01C04EB0: MOV x0, x19                | 
            // 0x01C04EB4: BL #0x980800               | 
        
        }
    
    }

}
