using UnityEngine;

namespace ILRuntime.Mono.Cecil
{
    public sealed class ArrayMarshalInfo : MarshalInfo
    {
        // Fields
        internal ILRuntime.Mono.Cecil.NativeType element_type; //  0x00000014
        internal int size_parameter_index; //  0x00000018
        internal int size; //  0x0000001C
        internal int size_parameter_multiplier; //  0x00000020
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E53FEC (15024108), len: 56  VirtAddr: 0x00E53FEC RVA: 0x00E53FEC token: 100663934 methodIndex: 19261 delegateWrapperIndex: 0 methodInvoker: 0
        public ArrayMarshalInfo()
        {
            //
            // Disasemble & Code
            // 0x00E53FEC: STP x20, x19, [sp, #-0x20]! | stack[1152921509485253104] = ???;  stack[1152921509485253112] = ???;  //  dest_result_addr=1152921509485253104 |  dest_result_addr=1152921509485253112
            // 0x00E53FF0: STP x29, x30, [sp, #0x10]  | stack[1152921509485253120] = ???;  stack[1152921509485253128] = ???;  //  dest_result_addr=1152921509485253120 |  dest_result_addr=1152921509485253128
            // 0x00E53FF4: ADD x29, sp, #0x10         | X29 = (1152921509485253104 + 16) = 1152921509485253120 (0x1000000122C69200);
            // 0x00E53FF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E53FFC: MOV x19, x0                | X19 = 1152921509485265136 (0x1000000122C6C0F0);//ML01
            // 0x00E54000: BL #0x16f59f0              | this..ctor();                           
            val_1 = new System.Object();
            // 0x00E54004: ADRP x8, #0x2a98000        | X8 = 44662784 (0x2A98000);              
            // 0x00E54008: LDR q0, [x8, #0x390]       | Q0 = ;                                  
            // 0x00E5400C: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
            // 0x00E54010: STR w8, [x19, #0x20]       | this.size_parameter_multiplier = 0;      //  dest_result_addr=1152921509485265168
            this.size_parameter_multiplier = 0;
            // 0x00E54014: STR q0, [x19, #0x10]       | mem[1152921509485265152] = ;             //  dest_result_addr=1152921509485265152
            mem[1152921509485265152] = ;
            // 0x00E54018: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5401C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E54020: RET                        |  return;                                
            return;
        
        }
    
    }

}
