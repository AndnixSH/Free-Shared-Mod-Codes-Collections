using UnityEngine;
public enum UICamera.ControlScheme
{
    // Fields
    Mouse = 0
    ,Touch = 1
    ,Controller = 2
    

}
