using UnityEngine;

namespace LitJson
{
    internal struct ArrayMetadata
    {
        // Fields
        private System.Type element_type; //  0x00000000
        private bool is_array; //  0x00000008
        private bool is_list; //  0x00000009
        
        // Properties
        public System.Type ElementType { get; set; }
        public bool IsArray { get; set; }
        public bool IsList { get; set; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00DA3D68 (14302568), len: 8  VirtAddr: 0x00DA3D68 RVA: 0x00DA3D68 token: 100687064 methodIndex: 46424 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Type get_ElementType()
        {
            //
            // Disasemble & Code
            // 0x00DA3D68: ADD x0, x0, #0x10          | X0 = (this + 16) = 1152921514034904768 (0x1000000231F4BEC0);
            // 0x00DA3D6C: B #0xda3cdc                | X0 = sub_DA3CDC( ?? (LitJson.ArrayMetadata)[1152921514034904752], ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x00DA3D70 (14302576), len: 8  VirtAddr: 0x00DA3D70 RVA: 0x00DA3D70 token: 100687065 methodIndex: 46425 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_ElementType(System.Type value)
        {
            //
            // Disasemble & Code
            // 0x00DA3D70: STR x1, [x0, #0x10]        | mem[1152921514035020864] = value;        //  dest_result_addr=1152921514035020864
            mem[1152921514035020864] = value;
            // 0x00DA3D74: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00DA3D78 (14302584), len: 8  VirtAddr: 0x00DA3D78 RVA: 0x00DA3D78 token: 100687066 methodIndex: 46426 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsArray()
        {
            //
            // Disasemble & Code
            // 0x00DA3D78: LDRB w0, [x0, #0x18]       | 
            // 0x00DA3D7C: RET                        |  return (System.Boolean)this;           
            return (bool)this;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00DA3D80 (14302592), len: 12  VirtAddr: 0x00DA3D80 RVA: 0x00DA3D80 token: 100687067 methodIndex: 46427 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_IsArray(bool value)
        {
            //
            // Disasemble & Code
            // 0x00DA3D80: AND w8, w1, #1             | W8 = (value & 1);                       
            bool val_1 = value;
            // 0x00DA3D84: STRB w8, [x0, #0x18]       | mem[1152921514035248968] = (value & 1);  //  dest_result_addr=1152921514035248968
            mem[1152921514035248968] = val_1;
            // 0x00DA3D88: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00DA3D8C (14302604), len: 8  VirtAddr: 0x00DA3D8C RVA: 0x00DA3D8C token: 100687068 methodIndex: 46428 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsList()
        {
            //
            // Disasemble & Code
            // 0x00DA3D8C: LDRB w0, [x0, #0x19]       | 
            // 0x00DA3D90: RET                        |  return (System.Boolean)this;           
            return (bool)this;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00DA3D94 (14302612), len: 12  VirtAddr: 0x00DA3D94 RVA: 0x00DA3D94 token: 100687069 methodIndex: 46429 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_IsList(bool value)
        {
            //
            // Disasemble & Code
            // 0x00DA3D94: AND w8, w1, #1             | W8 = (value & 1);                       
            bool val_1 = value;
            // 0x00DA3D98: STRB w8, [x0, #0x19]       | mem[1152921514035472969] = (value & 1);  //  dest_result_addr=1152921514035472969
            mem[1152921514035472969] = val_1;
            // 0x00DA3D9C: RET                        |  return;                                
            return;
        
        }
    
    }

}
