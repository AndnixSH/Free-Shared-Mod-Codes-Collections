using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class AnimatedAlpha_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate <>f__am$cache0; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate <>f__am$cache1; // static_offset: 0x00000020
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00BB7A84 (12286596), len: 8  VirtAddr: 0x00BB7A84 RVA: 0x00BB7A84 token: 100663735 methodIndex: 29780 delegateWrapperIndex: 0 methodInvoker: 0
        public AnimatedAlpha_Binding()
        {
            //
            // Disasemble & Code
            // 0x00BB7A84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB7A88: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB7A8C (12286604), len: 852  VirtAddr: 0x00BB7A8C RVA: 0x00BB7A8C token: 100663736 methodIndex: 29781 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_8;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_9;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_10;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_11;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_12;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_13;
            // 0x00BB7A8C: STP x24, x23, [sp, #-0x40]! | stack[1152921510040416480] = ???;  stack[1152921510040416488] = ???;  //  dest_result_addr=1152921510040416480 |  dest_result_addr=1152921510040416488
            // 0x00BB7A90: STP x22, x21, [sp, #0x10]  | stack[1152921510040416496] = ???;  stack[1152921510040416504] = ???;  //  dest_result_addr=1152921510040416496 |  dest_result_addr=1152921510040416504
            // 0x00BB7A94: STP x20, x19, [sp, #0x20]  | stack[1152921510040416512] = ???;  stack[1152921510040416520] = ???;  //  dest_result_addr=1152921510040416512 |  dest_result_addr=1152921510040416520
            // 0x00BB7A98: STP x29, x30, [sp, #0x30]  | stack[1152921510040416528] = ???;  stack[1152921510040416536] = ???;  //  dest_result_addr=1152921510040416528 |  dest_result_addr=1152921510040416536
            // 0x00BB7A9C: ADD x29, sp, #0x30         | X29 = (1152921510040416480 + 48) = 1152921510040416528 (0x1000000143DDB110);
            // 0x00BB7AA0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB7AA4: LDRB w8, [x20, #0xb47]     | W8 = (bool)static_value_03733B47;       
            // 0x00BB7AA8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB7AAC: TBNZ w8, #0, #0xbb7ac8     | if (static_value_03733B47 == true) goto label_0;
            // 0x00BB7AB0: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
            // 0x00BB7AB4: LDR x8, [x8, #0x318]       | X8 = 0x2B8AD60;                         
            // 0x00BB7AB8: LDR w0, [x8]               | W0 = 0x216;                             
            // 0x00BB7ABC: BL #0x2782188              | X0 = sub_2782188( ?? 0x216, ????);      
            // 0x00BB7AC0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB7AC4: STRB w8, [x20, #0xb47]     | static_value_03733B47 = true;            //  dest_result_addr=57883463
            label_0:
            // 0x00BB7AC8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BB7ACC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BB7AD0: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x00BB7AD4: ADRP x8, #0x35ca000        | X8 = 56401920 (0x35CA000);              
            // 0x00BB7AD8: LDR x8, [x8, #0x208]       | X8 = 1152921504877932544;               
            // 0x00BB7ADC: LDR x20, [x8]              | X20 = typeof(AnimatedAlpha);            
            // 0x00BB7AE0: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB7AE4: TBZ w8, #0, #0xbb7af4      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00BB7AE8: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB7AEC: CBNZ w8, #0xbb7af4         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00BB7AF0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00BB7AF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB7AF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB7AFC: MOV x1, x20                | X1 = 1152921504877932544 (0x1000000010287000);//ML01
            // 0x00BB7B00: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB7B04: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00BB7B08: CBNZ x20, #0xbb7b10        | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x00BB7B0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x00BB7B10: ADRP x9, #0x367b000        | X9 = 57126912 (0x367B000);              
            // 0x00BB7B14: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BB7B18: LDR x9, [x9, #0x430]       | X9 = (string**)(1152921510040395248)("alpha");
            // 0x00BB7B1C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB7B20: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB7B24: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BB7B28: LDR x1, [x9]               | X1 = "alpha";                           
            // 0x00BB7B2C: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BB7B30: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BB7B34: ADRP x24, #0x3634000       | X24 = 56836096 (0x3634000);             
            // 0x00BB7B38: LDR x24, [x24, #0x268]     | X24 = 1152921504782671872;              
            // 0x00BB7B3C: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BB7B40: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedAlpha_Binding);
            // 0x00BB7B44: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7B48: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__mg$cache0;
            val_8 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__mg$cache0;
            // 0x00BB7B4C: CBNZ x22, #0xbb7b98        | if (ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__mg$cache0 != null) goto label_4;
            if(val_8 != null)
            {
                goto label_4;
            }
            // 0x00BB7B50: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
            // 0x00BB7B54: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BB7B58: LDR x8, [x8, #0xf98]       | X8 = 1152921510040395328;               
            // 0x00BB7B5C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BB7B60: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimatedAlpha_Binding::get_alpha_0(ref object o);
            // 0x00BB7B64: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_2 = null;
            // 0x00BB7B68: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BB7B6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB7B70: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB7B74: MOV x2, x22                | X2 = 1152921510040395328 (0x1000000143DD5E40);//ML01
            // 0x00BB7B78: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_9 = val_2;
            // 0x00BB7B7C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedAlpha_Binding::get_alpha_0(ref object o));
            val_2 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedAlpha_Binding::get_alpha_0(ref object o));
            // 0x00BB7B80: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedAlpha_Binding);
            // 0x00BB7B84: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7B88: STR x23, [x8]              | ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782675968
            ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__mg$cache0 = val_9;
            // 0x00BB7B8C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedAlpha_Binding);
            // 0x00BB7B90: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7B94: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_8 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__mg$cache0;
            label_4:
            // 0x00BB7B98: CBNZ x19, #0xbb7ba0        | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x00BB7B9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedAlpha_Binding::get_alpha_0(ref object o)), ????);
            label_5:
            // 0x00BB7BA0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB7BA4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB7BA8: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB7BAC: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BB7BB0: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_8);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_8);
            // 0x00BB7BB4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedAlpha_Binding);
            // 0x00BB7BB8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7BBC: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__mg$cache1;
            val_10 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__mg$cache1;
            // 0x00BB7BC0: CBNZ x22, #0xbb7c0c        | if (ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__mg$cache1 != null) goto label_6;
            if(val_10 != null)
            {
                goto label_6;
            }
            // 0x00BB7BC4: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x00BB7BC8: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BB7BCC: LDR x8, [x8, #0xa60]       | X8 = 1152921510040396352;               
            // 0x00BB7BD0: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BB7BD4: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.AnimatedAlpha_Binding::set_alpha_0(ref object o, object v);
            // 0x00BB7BD8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_3 = null;
            // 0x00BB7BDC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BB7BE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB7BE4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB7BE8: MOV x2, x22                | X2 = 1152921510040396352 (0x1000000143DD6240);//ML01
            // 0x00BB7BEC: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_9 = val_3;
            // 0x00BB7BF0: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AnimatedAlpha_Binding::set_alpha_0(ref object o, object v));
            val_3 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AnimatedAlpha_Binding::set_alpha_0(ref object o, object v));
            // 0x00BB7BF4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedAlpha_Binding);
            // 0x00BB7BF8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7BFC: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782675976
            ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__mg$cache1 = val_9;
            // 0x00BB7C00: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedAlpha_Binding);
            // 0x00BB7C04: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7C08: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_10 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__mg$cache1;
            label_6:
            // 0x00BB7C0C: CBNZ x19, #0xbb7c14        | if (X1 != 0) goto label_7;              
            if(X1 != 0)
            {
                goto label_7;
            }
            // 0x00BB7C10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AnimatedAlpha_Binding::set_alpha_0(ref object o, object v)), ????);
            label_7:
            // 0x00BB7C14: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB7C18: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB7C1C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB7C20: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BB7C24: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_10);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_10);
            // 0x00BB7C28: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedAlpha_Binding);
            // 0x00BB7C2C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7C30: LDR x21, [x8, #0x18]       | X21 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__am$cache0;
            val_11 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__am$cache0;
            // 0x00BB7C34: CBNZ x21, #0xbb7c80        | if (ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__am$cache0 != null) goto label_8;
            if(val_11 != null)
            {
                goto label_8;
            }
            // 0x00BB7C38: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x00BB7C3C: ADRP x9, #0x3682000        | X9 = 57155584 (0x3682000);              
            // 0x00BB7C40: LDR x8, [x8, #0x5b0]       | X8 = 1152921510040397376;               
            // 0x00BB7C44: LDR x9, [x9, #0x9a0]       | X9 = 1152921504824152064;               
            // 0x00BB7C48: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.AnimatedAlpha_Binding::<Register>m__0();
            // 0x00BB7C4C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_4 = null;
            // 0x00BB7C50: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate), ????);
            // 0x00BB7C54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB7C58: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB7C5C: MOV x2, x21                | X2 = 1152921510040397376 (0x1000000143DD6640);//ML01
            // 0x00BB7C60: MOV x22, x0                | X22 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x00BB7C64: BL #0x28e8d84              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedAlpha_Binding::<Register>m__0());
            val_4 = new ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedAlpha_Binding::<Register>m__0());
            // 0x00BB7C68: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedAlpha_Binding);
            // 0x00BB7C6C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7C70: STR x22, [x8, #0x18]       | ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__am$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);  //  dest_result_addr=1152921504782675992
            ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__am$cache0 = val_4;
            // 0x00BB7C74: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedAlpha_Binding);
            // 0x00BB7C78: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7C7C: LDR x21, [x8, #0x18]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            val_11 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__am$cache0;
            label_8:
            // 0x00BB7C80: CBNZ x19, #0xbb7c88        | if (X1 != 0) goto label_9;              
            if(X1 != 0)
            {
                goto label_9;
            }
            // 0x00BB7C84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedAlpha_Binding::<Register>m__0()), ????);
            label_9:
            // 0x00BB7C88: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB7C8C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB7C90: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BB7C94: MOV x2, x21                | X2 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x00BB7C98: BL #0x28e5b28              | X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_11);
            X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_11);
            // 0x00BB7C9C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedAlpha_Binding);
            // 0x00BB7CA0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7CA4: LDR x21, [x8, #0x20]       | X21 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__am$cache1;
            val_12 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__am$cache1;
            // 0x00BB7CA8: CBNZ x21, #0xbb7cf4        | if (ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__am$cache1 != null) goto label_10;
            if(val_12 != null)
            {
                goto label_10;
            }
            // 0x00BB7CAC: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
            // 0x00BB7CB0: ADRP x9, #0x3651000        | X9 = 56954880 (0x3651000);              
            // 0x00BB7CB4: LDR x8, [x8, #0xf8]        | X8 = 1152921510040398400;               
            // 0x00BB7CB8: LDR x9, [x9, #0x3f8]       | X9 = 1152921504824205312;               
            // 0x00BB7CBC: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.AnimatedAlpha_Binding::<Register>m__1(int s);
            // 0x00BB7CC0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_5 = null;
            // 0x00BB7CC4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate), ????);
            // 0x00BB7CC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB7CCC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB7CD0: MOV x2, x21                | X2 = 1152921510040398400 (0x1000000143DD6A40);//ML01
            // 0x00BB7CD4: MOV x22, x0                | X22 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x00BB7CD8: BL #0x28e8ac8              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedAlpha_Binding::<Register>m__1(int s));
            val_5 = new ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedAlpha_Binding::<Register>m__1(int s));
            // 0x00BB7CDC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedAlpha_Binding);
            // 0x00BB7CE0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7CE4: STR x22, [x8, #0x20]       | ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__am$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);  //  dest_result_addr=1152921504782676000
            ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__am$cache1 = val_5;
            // 0x00BB7CE8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedAlpha_Binding);
            // 0x00BB7CEC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7CF0: LDR x21, [x8, #0x20]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            val_12 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__am$cache1;
            label_10:
            // 0x00BB7CF4: CBNZ x19, #0xbb7cfc        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BB7CF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedAlpha_Binding::<Register>m__1(int s)), ????);
            label_11:
            // 0x00BB7CFC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB7D00: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB7D04: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BB7D08: MOV x2, x21                | X2 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x00BB7D0C: BL #0x28e5bd8              | X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_12);
            X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_12);
            // 0x00BB7D10: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x00BB7D14: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x00BB7D18: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
            // 0x00BB7D1C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB7D20: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB7D24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB7D28: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB7D2C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB7D30: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB7D34: CBNZ x20, #0xbb7d3c        | if (val_1 != null) goto label_12;       
            if(val_1 != null)
            {
                goto label_12;
            }
            // 0x00BB7D38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_12:
            // 0x00BB7D3C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB7D40: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BB7D44: ORR w1, wzr, #0x1e         | W1 = 30(0x1E);                          
            // 0x00BB7D48: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB7D4C: MOV x3, x21                | X3 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB7D50: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB7D54: BL #0x1b6ea10              | X0 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.ConstructorInfo val_6 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB7D58: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedAlpha_Binding);
            // 0x00BB7D5C: MOV x20, x0                | X20 = val_6;//m1                        
            // 0x00BB7D60: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7D64: LDR x21, [x8, #0x10]       | X21 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__mg$cache2;
            val_13 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__mg$cache2;
            // 0x00BB7D68: CBNZ x21, #0xbb7db4        | if (ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__mg$cache2 != null) goto label_13;
            if(val_13 != null)
            {
                goto label_13;
            }
            // 0x00BB7D6C: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00BB7D70: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB7D74: LDR x8, [x8, #0x578]       | X8 = 1152921510040403520;               
            // 0x00BB7D78: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB7D7C: LDR x21, [x8]              | X21 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimatedAlpha_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB7D80: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_7 = null;
            // 0x00BB7D84: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB7D88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB7D8C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB7D90: MOV x2, x21                | X2 = 1152921510040403520 (0x1000000143DD7E40);//ML01
            // 0x00BB7D94: MOV x22, x0                | X22 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB7D98: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimatedAlpha_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_7 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimatedAlpha_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB7D9C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedAlpha_Binding);
            // 0x00BB7DA0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7DA4: STR x22, [x8, #0x10]       | ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782675984
            ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__mg$cache2 = val_7;
            // 0x00BB7DA8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedAlpha_Binding);
            // 0x00BB7DAC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB7DB0: LDR x21, [x8, #0x10]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_13 = ILRuntime.Runtime.Generated.AnimatedAlpha_Binding.<>f__mg$cache2;
            label_13:
            // 0x00BB7DB4: CBNZ x19, #0xbb7dbc        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00BB7DB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimatedAlpha_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_14:
            // 0x00BB7DBC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB7DC0: MOV x1, x20                | X1 = val_6;//m1                         
            // 0x00BB7DC4: MOV x2, x21                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB7DC8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB7DCC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB7DD0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BB7DD4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB7DD8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BB7DDC: B #0x28e3b20               | X1.RegisterCLRMethodRedirection(mi:  val_6, func:  val_13); return;
            X1.RegisterCLRMethodRedirection(mi:  val_6, func:  val_13);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB7DE0 (12287456), len: 312  VirtAddr: 0x00BB7DE0 RVA: 0x00BB7DE0 token: 100663737 methodIndex: 29782 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_alpha_0(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BB7DE0: STP x20, x19, [sp, #-0x20]! | stack[1152921510040548912] = ???;  stack[1152921510040548920] = ???;  //  dest_result_addr=1152921510040548912 |  dest_result_addr=1152921510040548920
            // 0x00BB7DE4: STP x29, x30, [sp, #0x10]  | stack[1152921510040548928] = ???;  stack[1152921510040548936] = ???;  //  dest_result_addr=1152921510040548928 |  dest_result_addr=1152921510040548936
            // 0x00BB7DE8: ADD x29, sp, #0x10         | X29 = (1152921510040548912 + 16) = 1152921510040548928 (0x1000000143DFB640);
            // 0x00BB7DEC: SUB sp, sp, #0x20          | SP = (1152921510040548912 - 32) = 1152921510040548880 (0x1000000143DFB610);
            // 0x00BB7DF0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB7DF4: LDRB w8, [x20, #0xb48]     | W8 = (bool)static_value_03733B48;       
            // 0x00BB7DF8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB7DFC: TBNZ w8, #0, #0xbb7e18     | if (static_value_03733B48 == true) goto label_0;
            // 0x00BB7E00: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x00BB7E04: LDR x8, [x8, #0x788]       | X8 = 0x2B8AD5C;                         
            // 0x00BB7E08: LDR w0, [x8]               | W0 = 0x215;                             
            // 0x00BB7E0C: BL #0x2782188              | X0 = sub_2782188( ?? 0x215, ????);      
            // 0x00BB7E10: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB7E14: STRB w8, [x20, #0xb48]     | static_value_03733B48 = true;            //  dest_result_addr=57883464
            label_0:
            // 0x00BB7E18: ADRP x20, #0x3618000       | X20 = 56721408 (0x3618000);             
            // 0x00BB7E1C: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BB7E20: LDR x20, [x20, #0xa98]     | X20 = 1152921504877932544;              
            // 0x00BB7E24: CBZ x19, #0xbb7e78         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BB7E28: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB7E2C: LDR x1, [x20]              | X1 = typeof(AnimatedAlpha);             
            // 0x00BB7E30: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB7E34: LDRB w9, [x1, #0x104]      | W9 = AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB7E38: CMP w10, w9                | STATE = COMPARE(X1 + 260, AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB7E3C: B.LO #0xbb7e54             | if (X1 + 260 < AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB7E40: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB7E44: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB7E48: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB7E4C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimatedAlpha))
            // 0x00BB7E50: B.EQ #0xbb7e7c             | if ((X1 + 176 + (AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB7E54: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB7E58: ADD x8, sp, #0x10          | X8 = (1152921510040548880 + 16) = 1152921510040548896 (0x1000000143DFB620);
            // 0x00BB7E5C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB7E60: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510040536944]
            // 0x00BB7E64: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB7E68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB7E6C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB7E70: ADD x0, sp, #0x10          | X0 = (1152921510040548880 + 16) = 1152921510040548896 (0x1000000143DFB620);
            // 0x00BB7E74: BL #0x299a140              | 
            label_1:
            // 0x00BB7E78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143DFB620, ????);
            label_3:
            // 0x00BB7E7C: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB7E80: LDR x1, [x20]              | X1 = typeof(AnimatedAlpha);             
            // 0x00BB7E84: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB7E88: LDRB w9, [x1, #0x104]      | W9 = AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB7E8C: CMP w10, w9                | STATE = COMPARE(X1 + 260, AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB7E90: B.LO #0xbb7ed4             | if (X1 + 260 < AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BB7E94: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB7E98: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB7E9C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB7EA0: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimatedAlpha))
            // 0x00BB7EA4: B.NE #0xbb7ed4             | if ((X1 + 176 + (AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BB7EA8: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x00BB7EAC: LDR w8, [x19, #0x18]       | W8 = X1 + 24;                           
            // 0x00BB7EB0: LDR x9, [x9, #0xce8]       | X9 = 1152921504608444416;               
            // 0x00BB7EB4: ADD x1, sp, #0xc           | X1 = (1152921510040548880 + 12) = 1152921510040548892 (0x1000000143DFB61C);
            // 0x00BB7EB8: STR w8, [sp, #0xc]         | stack[1152921510040548892] = X1 + 24;    //  dest_result_addr=1152921510040548892
            // 0x00BB7EBC: LDR x0, [x9]               | X0 = typeof(System.Single);             
            // 0x00BB7EC0: BL #0x27bc028              | X0 = 1152921510040596960 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), X1 + 24);
            // 0x00BB7EC4: SUB sp, x29, #0x10         | SP = (1152921510040548928 - 16) = 1152921510040548912 (0x1000000143DFB630);
            // 0x00BB7EC8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB7ECC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB7ED0: RET                        |  return (System.Object)X1 + 24;         
            return (object)X1 + 24;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BB7ED4: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB7ED8: ADD x8, sp, #0x18          | X8 = (1152921510040548880 + 24) = 1152921510040548904 (0x1000000143DFB628);
            // 0x00BB7EDC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB7EE0: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510040536944]
            // 0x00BB7EE4: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB7EE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB7EEC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB7EF0: ADD x0, sp, #0x18          | X0 = (1152921510040548880 + 24) = 1152921510040548904 (0x1000000143DFB628);
            // 0x00BB7EF4: BL #0x299a140              | 
            // 0x00BB7EF8: MOV x19, x0                | X19 = 1152921510040548904 (0x1000000143DFB628);//ML01
            // 0x00BB7EFC: ADD x0, sp, #0x10          | X0 = (1152921510040548880 + 16) = 1152921510040548896 (0x1000000143DFB620);
            label_6:
            // 0x00BB7F00: BL #0x299a140              | 
            // 0x00BB7F04: MOV x0, x19                | X0 = 1152921510040548904 (0x1000000143DFB628);//ML01
            // 0x00BB7F08: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143DFB628, ????);
            // 0x00BB7F0C: MOV x19, x0                | X19 = 1152921510040548904 (0x1000000143DFB628);//ML01
            // 0x00BB7F10: ADD x0, sp, #0x18          | X0 = (1152921510040548880 + 24) = 1152921510040548904 (0x1000000143DFB628);
            // 0x00BB7F14: B #0xbb7f00                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB7F18 (12287768), len: 412  VirtAddr: 0x00BB7F18 RVA: 0x00BB7F18 token: 100663738 methodIndex: 29783 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_alpha_0(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BB7F18: STP x22, x21, [sp, #-0x30]! | stack[1152921510040677120] = ???;  stack[1152921510040677128] = ???;  //  dest_result_addr=1152921510040677120 |  dest_result_addr=1152921510040677128
            // 0x00BB7F1C: STP x20, x19, [sp, #0x10]  | stack[1152921510040677136] = ???;  stack[1152921510040677144] = ???;  //  dest_result_addr=1152921510040677136 |  dest_result_addr=1152921510040677144
            // 0x00BB7F20: STP x29, x30, [sp, #0x20]  | stack[1152921510040677152] = ???;  stack[1152921510040677160] = ???;  //  dest_result_addr=1152921510040677152 |  dest_result_addr=1152921510040677160
            // 0x00BB7F24: ADD x29, sp, #0x20         | X29 = (1152921510040677120 + 32) = 1152921510040677152 (0x1000000143E1AB20);
            // 0x00BB7F28: SUB sp, sp, #0x20          | SP = (1152921510040677120 - 32) = 1152921510040677088 (0x1000000143E1AAE0);
            // 0x00BB7F2C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BB7F30: LDRB w8, [x21, #0xb49]     | W8 = (bool)static_value_03733B49;       
            // 0x00BB7F34: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BB7F38: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BB7F3C: TBNZ w8, #0, #0xbb7f58     | if (static_value_03733B49 == true) goto label_0;
            // 0x00BB7F40: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
            // 0x00BB7F44: LDR x8, [x8, #0x6a8]       | X8 = 0x2B8AD64;                         
            // 0x00BB7F48: LDR w0, [x8]               | W0 = 0x217;                             
            // 0x00BB7F4C: BL #0x2782188              | X0 = sub_2782188( ?? 0x217, ????);      
            // 0x00BB7F50: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB7F54: STRB w8, [x21, #0xb49]     | static_value_03733B49 = true;            //  dest_result_addr=57883465
            label_0:
            // 0x00BB7F58: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BB7F5C: CBZ x21, #0xbb8010         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BB7F60: ADRP x20, #0x3618000       | X20 = 56721408 (0x3618000);             
            // 0x00BB7F64: LDR x20, [x20, #0xa98]     | X20 = 1152921504877932544;              
            // 0x00BB7F68: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB7F6C: LDR x1, [x20]              | X1 = typeof(AnimatedAlpha);             
            // 0x00BB7F70: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB7F74: LDRB w9, [x1, #0x104]      | W9 = AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB7F78: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB7F7C: B.LO #0xbb7f94             | if (mem[null + 260] < AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB7F80: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB7F84: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB7F88: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB7F8C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimatedAlpha))
            // 0x00BB7F90: B.EQ #0xbb7fbc             | if ((mem[null + 176] + (AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB7F94: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB7F98: ADD x8, sp, #8             | X8 = (1152921510040677088 + 8) = 1152921510040677096 (0x1000000143E1AAE8);
            // 0x00BB7F9C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB7FA0: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510040665168]
            // 0x00BB7FA4: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB7FA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB7FAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB7FB0: ADD x0, sp, #8             | X0 = (1152921510040677088 + 8) = 1152921510040677096 (0x1000000143E1AAE8);
            // 0x00BB7FB4: BL #0x299a140              | 
            // 0x00BB7FB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143E1AAE8, ????);
            label_3:
            // 0x00BB7FBC: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB7FC0: LDR x1, [x20]              | X1 = typeof(AnimatedAlpha);             
            // 0x00BB7FC4: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB7FC8: LDRB w9, [x1, #0x104]      | W9 = AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB7FCC: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB7FD0: B.LO #0xbb7fe8             | if (mem[null + 260] < AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BB7FD4: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB7FD8: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB7FDC: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB7FE0: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimatedAlpha))
            // 0x00BB7FE4: B.EQ #0xbb8018             | if ((mem[null + 176] + (AnimatedAlpha.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BB7FE8: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB7FEC: ADD x8, sp, #0x10          | X8 = (1152921510040677088 + 16) = 1152921510040677104 (0x1000000143E1AAF0);
            // 0x00BB7FF0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB7FF4: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510040665168]
            // 0x00BB7FF8: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB7FFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8000: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB8004: ADD x0, sp, #0x10          | X0 = (1152921510040677088 + 16) = 1152921510040677104 (0x1000000143E1AAF0);
            // 0x00BB8008: BL #0x299a140              | 
            // 0x00BB800C: B #0xbb8014                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BB8010: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x217, ????);      
            label_6:
            // 0x00BB8014: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BB8018: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00BB801C: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
            // 0x00BB8020: LDR x20, [x8]              | X20 = typeof(System.Single);            
            // 0x00BB8024: CBNZ x19, #0xbb802c        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BB8028: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x217, ????);      
            label_7:
            // 0x00BB802C: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BB8030: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BB8034: LDR x8, [x20, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
            // 0x00BB8038: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Single.__il2cppRuntimeField_element_class)
            // 0x00BB803C: B.NE #0xbb8084             | if (X2 + 48 != System.Single.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BB8040: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BB8044: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BB8048: LDR w8, [x0]               | W8 = X2;                                
            // 0x00BB804C: STR w8, [x21, #0x18]       | mem[24] = X2;                            //  dest_result_addr=24
            mem[24] = X2;
            // 0x00BB8050: SUB sp, x29, #0x20         | SP = (1152921510040677152 - 32) = 1152921510040677120 (0x1000000143E1AB00);
            // 0x00BB8054: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB8058: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB805C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB8060: RET                        |  return;                                
            return;
            // 0x00BB8064: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BB8068: ADD x0, sp, #8             | X0 = (1152921510040677168 + 8) = 1152921510040677176 (0x1000000143E1AB38);
            // 0x00BB806C: B #0xbb8078                |  goto label_10;                         
            goto label_10;
            // 0x00BB8070: MOV x19, x0                | X19 = 1152921510040677176 (0x1000000143E1AB38);//ML01
            val_7;
            // 0x00BB8074: ADD x0, sp, #0x10          | X0 = (1152921510040677168 + 16) = 1152921510040677184 (0x1000000143E1AB40);
            label_10:
            // 0x00BB8078: BL #0x299a140              | 
            // 0x00BB807C: MOV x0, x19                | X0 = 1152921510040677176 (0x1000000143E1AB38);//ML01
            // 0x00BB8080: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143E1AB38, ????);
            label_8:
            // 0x00BB8084: ADD x8, sp, #0x18          | X8 = (1152921510040677168 + 24) = 1152921510040677192 (0x1000000143E1AB48);
            // 0x00BB8088: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BB808C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000143E1AB38, ????);
            // 0x00BB8090: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510040665168]
            // 0x00BB8094: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BB8098: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB809C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BB80A0: ADD x0, sp, #0x18          | X0 = (1152921510040677168 + 24) = 1152921510040677192 (0x1000000143E1AB48);
            // 0x00BB80A4: BL #0x299a140              | 
            // 0x00BB80A8: MOV x19, x0                | X19 = 1152921510040677192 (0x1000000143E1AB48);//ML01
            // 0x00BB80AC: ADD x0, sp, #0x18          | X0 = (1152921510040677168 + 24) = 1152921510040677192 (0x1000000143E1AB48);
            // 0x00BB80B0: B #0xbb8078                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB80B4 (12288180), len: 180  VirtAddr: 0x00BB80B4 RVA: 0x00BB80B4 token: 100663739 methodIndex: 29784 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            // 0x00BB80B4: STP x22, x21, [sp, #-0x30]! | stack[1152921510040813616] = ???;  stack[1152921510040813624] = ???;  //  dest_result_addr=1152921510040813616 |  dest_result_addr=1152921510040813624
            // 0x00BB80B8: STP x20, x19, [sp, #0x10]  | stack[1152921510040813632] = ???;  stack[1152921510040813640] = ???;  //  dest_result_addr=1152921510040813632 |  dest_result_addr=1152921510040813640
            // 0x00BB80BC: STP x29, x30, [sp, #0x20]  | stack[1152921510040813648] = ???;  stack[1152921510040813656] = ???;  //  dest_result_addr=1152921510040813648 |  dest_result_addr=1152921510040813656
            // 0x00BB80C0: ADD x29, sp, #0x20         | X29 = (1152921510040813616 + 32) = 1152921510040813648 (0x1000000143E3C050);
            // 0x00BB80C4: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00BB80C8: LDRB w8, [x22, #0xb4a]     | W8 = (bool)static_value_03733B4A;       
            // 0x00BB80CC: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00BB80D0: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BB80D4: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BB80D8: TBNZ w8, #0, #0xbb80f4     | if (static_value_03733B4A == true) goto label_0;
            // 0x00BB80DC: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x00BB80E0: LDR x8, [x8, #0xf78]       | X8 = 0x2B8AD58;                         
            // 0x00BB80E4: LDR w0, [x8]               | W0 = 0x214;                             
            // 0x00BB80E8: BL #0x2782188              | X0 = sub_2782188( ?? 0x214, ????);      
            // 0x00BB80EC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB80F0: STRB w8, [x22, #0xb4a]     | static_value_03733B4A = true;            //  dest_result_addr=57883466
            label_0:
            // 0x00BB80F4: CBNZ x21, #0xbb80fc        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BB80F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x214, ????);      
            label_1:
            // 0x00BB80FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8100: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BB8104: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BB8108: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB810C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00BB8110: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BB8114: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB8118: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            // 0x00BB811C: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00BB8120: LDR x8, [x8, #0xa98]       | X8 = 1152921504877932544;               
            // 0x00BB8124: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BB8128: LDR x8, [x8]               | X8 = typeof(AnimatedAlpha);             
            // 0x00BB812C: MOV x0, x8                 | X0 = 1152921504877932544 (0x1000000010287000);//ML01
            AnimatedAlpha val_3 = null;
            // 0x00BB8130: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AnimatedAlpha), ????);
            // 0x00BB8134: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8138: MOV x21, x0                | X21 = 1152921504877932544 (0x1000000010287000);//ML01
            // 0x00BB813C: BL #0xb272c4               | .ctor();                                
            val_3 = new AnimatedAlpha();
            // 0x00BB8140: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00BB8144: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00BB8148: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB814C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB8150: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB8154: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BB8158: MOV x3, x21                | X3 = 1152921504877932544 (0x1000000010287000);//ML01
            // 0x00BB815C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB8160: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB8164: B #0x1f657ec               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB8168 (12288360), len: 92  VirtAddr: 0x00BB8168 RVA: 0x00BB8168 token: 100663740 methodIndex: 29785 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__0()
        {
            //
            // Disasemble & Code
            // 0x00BB8168: STP x20, x19, [sp, #-0x20]! | stack[1152921510040942016] = ???;  stack[1152921510040942024] = ???;  //  dest_result_addr=1152921510040942016 |  dest_result_addr=1152921510040942024
            // 0x00BB816C: STP x29, x30, [sp, #0x10]  | stack[1152921510040942032] = ???;  stack[1152921510040942040] = ???;  //  dest_result_addr=1152921510040942032 |  dest_result_addr=1152921510040942040
            // 0x00BB8170: ADD x29, sp, #0x10         | X29 = (1152921510040942016 + 16) = 1152921510040942032 (0x1000000143E5B5D0);
            // 0x00BB8174: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BB8178: LDRB w8, [x19, #0xb4b]     | W8 = (bool)static_value_03733B4B;       
            // 0x00BB817C: TBNZ w8, #0, #0xbb8198     | if (static_value_03733B4B == true) goto label_0;
            // 0x00BB8180: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x00BB8184: LDR x8, [x8, #0xfc0]       | X8 = 0x2B8AD68;                         
            // 0x00BB8188: LDR w0, [x8]               | W0 = 0x218;                             
            // 0x00BB818C: BL #0x2782188              | X0 = sub_2782188( ?? 0x218, ????);      
            // 0x00BB8190: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB8194: STRB w8, [x19, #0xb4b]     | static_value_03733B4B = true;            //  dest_result_addr=57883467
            label_0:
            // 0x00BB8198: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00BB819C: LDR x8, [x8, #0xa98]       | X8 = 1152921504877932544;               
            // 0x00BB81A0: LDR x0, [x8]               | X0 = typeof(AnimatedAlpha);             
            AnimatedAlpha val_1 = null;
            // 0x00BB81A4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AnimatedAlpha), ????);
            // 0x00BB81A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB81AC: MOV x19, x0                | X19 = 1152921504877932544 (0x1000000010287000);//ML01
            // 0x00BB81B0: BL #0xb272c4               | .ctor();                                
            val_1 = new AnimatedAlpha();
            // 0x00BB81B4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB81B8: MOV x0, x19                | X0 = 1152921504877932544 (0x1000000010287000);//ML01
            // 0x00BB81BC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB81C0: RET                        |  return (System.Object)typeof(AnimatedAlpha);
            return (object)val_1;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB81C4 (12288452), len: 92  VirtAddr: 0x00BB81C4 RVA: 0x00BB81C4 token: 100663741 methodIndex: 29786 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__1(int s)
        {
            //
            // Disasemble & Code
            // 0x00BB81C4: STP x20, x19, [sp, #-0x20]! | stack[1152921510041058112] = ???;  stack[1152921510041058120] = ???;  //  dest_result_addr=1152921510041058112 |  dest_result_addr=1152921510041058120
            // 0x00BB81C8: STP x29, x30, [sp, #0x10]  | stack[1152921510041058128] = ???;  stack[1152921510041058136] = ???;  //  dest_result_addr=1152921510041058128 |  dest_result_addr=1152921510041058136
            // 0x00BB81CC: ADD x29, sp, #0x10         | X29 = (1152921510041058112 + 16) = 1152921510041058128 (0x1000000143E77B50);
            // 0x00BB81D0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB81D4: LDRB w8, [x20, #0xb4c]     | W8 = (bool)static_value_03733B4C;       
            // 0x00BB81D8: MOV w19, w1                | W19 = W1;//m1                           
            // 0x00BB81DC: TBNZ w8, #0, #0xbb81f8     | if (static_value_03733B4C == true) goto label_0;
            // 0x00BB81E0: ADRP x8, #0x3648000        | X8 = 56918016 (0x3648000);              
            // 0x00BB81E4: LDR x8, [x8, #0x38]        | X8 = 0x2B8AD6C;                         
            // 0x00BB81E8: LDR w0, [x8]               | W0 = 0x219;                             
            // 0x00BB81EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x219, ????);      
            // 0x00BB81F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB81F4: STRB w8, [x20, #0xb4c]     | static_value_03733B4C = true;            //  dest_result_addr=57883468
            label_0:
            // 0x00BB81F8: ADRP x8, #0x367e000        | X8 = 57139200 (0x367E000);              
            // 0x00BB81FC: LDR x8, [x8, #0x760]       | X8 = 1152921510041042048;               
            // 0x00BB8200: LDR x20, [x8]              | X20 = typeof(AnimatedAlpha[]);          
            // 0x00BB8204: MOV x0, x20                | X0 = 1152921510041042048 (0x1000000143E73C80);//ML01
            // 0x00BB8208: BL #0x277461c              | X0 = sub_277461C( ?? typeof(AnimatedAlpha[]), ????);
            // 0x00BB820C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB8210: MOV w1, w19                | W1 = W1;//m1                            
            // 0x00BB8214: MOV x0, x20                | X0 = 1152921510041042048 (0x1000000143E73C80);//ML01
            // 0x00BB8218: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB821C: B #0x27c1608               | X0 = sub_27C1608( ?? typeof(AnimatedAlpha[]), ????);
        
        }
    
    }

}
