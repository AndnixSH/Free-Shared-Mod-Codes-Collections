using UnityEngine;

namespace wxb
{
    internal class ArrayLongType : ArraySerialize<long>
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2BD40 (14859584), len: 80  VirtAddr: 0x00E2BD40 RVA: 0x00E2BD40 token: 100681213 methodIndex: 57213 delegateWrapperIndex: 0 methodInvoker: 0
        public ArrayLongType()
        {
            //
            // Disasemble & Code
            // 0x00E2BD40: STP x20, x19, [sp, #-0x20]! | stack[1152921513027251616] = ???;  stack[1152921513027251624] = ???;  //  dest_result_addr=1152921513027251616 |  dest_result_addr=1152921513027251624
            // 0x00E2BD44: STP x29, x30, [sp, #0x10]  | stack[1152921513027251632] = ???;  stack[1152921513027251640] = ???;  //  dest_result_addr=1152921513027251632 |  dest_result_addr=1152921513027251640
            // 0x00E2BD48: ADD x29, sp, #0x10         | X29 = (1152921513027251616 + 16) = 1152921513027251632 (0x10000001F5E52DB0);
            // 0x00E2BD4C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2BD50: LDRB w8, [x20, #0x8ef]     | W8 = (bool)static_value_037348EF;       
            // 0x00E2BD54: MOV x19, x0                | X19 = 1152921513027263648 (0x10000001F5E55CA0);//ML01
            // 0x00E2BD58: TBNZ w8, #0, #0xe2bd74     | if (static_value_037348EF == true) goto label_0;
            // 0x00E2BD5C: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x00E2BD60: LDR x8, [x8, #0x1f8]       | X8 = 0x2B8E7A4;                         
            // 0x00E2BD64: LDR w0, [x8]               | W0 = 0x10A7;                            
            // 0x00E2BD68: BL #0x2782188              | X0 = sub_2782188( ?? 0x10A7, ????);     
            // 0x00E2BD6C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2BD70: STRB w8, [x20, #0x8ef]     | static_value_037348EF = true;            //  dest_result_addr=57886959
            label_0:
            // 0x00E2BD74: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
            // 0x00E2BD78: LDR x8, [x8, #0xf88]       | X8 = 1152921513027238624;               
            // 0x00E2BD7C: MOV x0, x19                | X0 = 1152921513027263648 (0x10000001F5E55CA0);//ML01
            // 0x00E2BD80: LDR x1, [x8]               | X1 = System.Void wxb.ArraySerialize<System.Int64>::.ctor();
            // 0x00E2BD84: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2BD88: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2BD8C: B #0x1d870f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2BD90 (14859664), len: 8  VirtAddr: 0x00E2BD90 RVA: 0x00E2BD90 token: 100681214 methodIndex: 57214 delegateWrapperIndex: 0 methodInvoker: 0
        protected override int GetElementSize()
        {
            //
            // Disasemble & Code
            // 0x00E2BD90: ORR w0, wzr, #8            | W0 = 8(0x8);                            
            // 0x00E2BD94: RET                        |  return (System.Int32)8;                
            return (int)8;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2BD98 (14859672), len: 52  VirtAddr: 0x00E2BD98 RVA: 0x00E2BD98 token: 100681215 methodIndex: 57215 delegateWrapperIndex: 0 methodInvoker: 0
        protected override void Write(wxb.WRStream stream, long value)
        {
            //
            // Disasemble & Code
            // 0x00E2BD98: STP x20, x19, [sp, #-0x20]! | stack[1152921513027479712] = ???;  stack[1152921513027479720] = ???;  //  dest_result_addr=1152921513027479712 |  dest_result_addr=1152921513027479720
            // 0x00E2BD9C: STP x29, x30, [sp, #0x10]  | stack[1152921513027479728] = ???;  stack[1152921513027479736] = ???;  //  dest_result_addr=1152921513027479728 |  dest_result_addr=1152921513027479736
            // 0x00E2BDA0: ADD x29, sp, #0x10         | X29 = (1152921513027479712 + 16) = 1152921513027479728 (0x10000001F5E8A8B0);
            // 0x00E2BDA4: MOV x19, x2                | X19 = value;//m1                        
            // 0x00E2BDA8: MOV x20, x1                | X20 = stream;//m1                       
            // 0x00E2BDAC: CBNZ x20, #0xe2bdb4        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2BDB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2BDB4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2BDB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2BDBC: MOV x0, x20                | X0 = stream;//m1                        
            // 0x00E2BDC0: MOV x1, x19                | X1 = value;//m1                         
            // 0x00E2BDC4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2BDC8: B #0x269dbac               | stream.WriteInt64(value:  value); return;
            stream.WriteInt64(value:  value);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2BDCC (14859724), len: 44  VirtAddr: 0x00E2BDCC RVA: 0x00E2BDCC token: 100681216 methodIndex: 57216 delegateWrapperIndex: 0 methodInvoker: 0
        protected override long Read(wxb.WRStream stream)
        {
            //
            // Disasemble & Code
            // 0x00E2BDCC: STP x20, x19, [sp, #-0x20]! | stack[1152921513027599904] = ???;  stack[1152921513027599912] = ???;  //  dest_result_addr=1152921513027599904 |  dest_result_addr=1152921513027599912
            // 0x00E2BDD0: STP x29, x30, [sp, #0x10]  | stack[1152921513027599920] = ???;  stack[1152921513027599928] = ???;  //  dest_result_addr=1152921513027599920 |  dest_result_addr=1152921513027599928
            // 0x00E2BDD4: ADD x29, sp, #0x10         | X29 = (1152921513027599904 + 16) = 1152921513027599920 (0x10000001F5EA7E30);
            // 0x00E2BDD8: MOV x19, x1                | X19 = stream;//m1                       
            // 0x00E2BDDC: CBNZ x19, #0xe2bde4        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2BDE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2BDE4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2BDE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2BDEC: MOV x0, x19                | X0 = stream;//m1                        
            // 0x00E2BDF0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2BDF4: B #0x269dde0               | return stream.ReadInt64();              
            return stream.ReadInt64();
        
        }
    
    }

}
