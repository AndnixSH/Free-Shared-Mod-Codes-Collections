using UnityEngine;

namespace Pathfinding.Ionic.Zip
{
    public class AddProgressEventArgs : ZipProgressEventArgs
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x01970220 (26673696), len: 4  VirtAddr: 0x01970220 RVA: 0x01970220 token: 100663328 methodIndex: 20851 delegateWrapperIndex: 0 methodInvoker: 0
        private AddProgressEventArgs(string archiveName, Pathfinding.Ionic.Zip.ZipProgressEventType flavor)
        {
            //
            // Disasemble & Code
            // 0x01970220: B #0x1970224               | this..ctor(archiveName:  archiveName, flavor:  flavor); return;
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x019702A8 (26673832), len: 148  VirtAddr: 0x019702A8 RVA: 0x019702A8 token: 100663329 methodIndex: 20852 delegateWrapperIndex: 0 methodInvoker: 0
        internal static Pathfinding.Ionic.Zip.AddProgressEventArgs AfterEntry(string archiveName, Pathfinding.Ionic.Zip.ZipEntry entry, int entriesTotal)
        {
            //
            // Disasemble & Code
            // 0x019702A8: STP x22, x21, [sp, #-0x30]! | stack[1152921509627823776] = ???;  stack[1152921509627823784] = ???;  //  dest_result_addr=1152921509627823776 |  dest_result_addr=1152921509627823784
            // 0x019702AC: STP x20, x19, [sp, #0x10]  | stack[1152921509627823792] = ???;  stack[1152921509627823800] = ???;  //  dest_result_addr=1152921509627823792 |  dest_result_addr=1152921509627823800
            // 0x019702B0: STP x29, x30, [sp, #0x20]  | stack[1152921509627823808] = ???;  stack[1152921509627823816] = ???;  //  dest_result_addr=1152921509627823808 |  dest_result_addr=1152921509627823816
            // 0x019702B4: ADD x29, sp, #0x20         | X29 = (1152921509627823776 + 32) = 1152921509627823808 (0x100000012B4606C0);
            // 0x019702B8: ADRP x21, #0x3739000       | X21 = 57905152 (0x3739000);             
            // 0x019702BC: LDRB w8, [x21, #0x3e1]     | W8 = (bool)static_value_037393E1;       
            // 0x019702C0: MOV w20, w3                | W20 = W3;//m1                           
            // 0x019702C4: MOV x19, x2                | X19 = entriesTotal;//m1                 
            // 0x019702C8: MOV x22, x1                | X22 = entry;//m1                        
            // 0x019702CC: TBNZ w8, #0, #0x19702e8    | if (static_value_037393E1 == true) goto label_0;
            // 0x019702D0: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
            // 0x019702D4: LDR x8, [x8, #0x960]       | X8 = 0x2B8AA38;                         
            // 0x019702D8: LDR w0, [x8]               | W0 = 0x14C;                             
            // 0x019702DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x14C, ????);      
            // 0x019702E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019702E4: STRB w8, [x21, #0x3e1]     | static_value_037393E1 = true;            //  dest_result_addr=57906145
            label_0:
            // 0x019702E8: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
            // 0x019702EC: LDR x8, [x8, #0x6d8]       | X8 = 1152921504750616576;               
            // 0x019702F0: LDR x0, [x8]               | X0 = typeof(Pathfinding.Ionic.Zip.AddProgressEventArgs);
            Pathfinding.Ionic.Zip.ZipProgressEventArgs val_1 = null;
            // 0x019702F4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Ionic.Zip.AddProgressEventArgs), ????);
            // 0x019702F8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x019702FC: MOV x1, x22                | X1 = entry;//m1                         
            // 0x01970300: MOV x21, x0                | X21 = 1152921504750616576 (0x100000000891C000);//ML01
            // 0x01970304: BL #0x1970224              | .ctor(archiveName:  entry, flavor:  1); 
            val_1 = new Pathfinding.Ionic.Zip.ZipProgressEventArgs(archiveName:  entry, flavor:  1);
            // 0x01970308: CBZ x21, #0x1970314        | if ( == 0) goto label_1;                
            if(null == 0)
            {
                goto label_1;
            }
            // 0x0197030C: STR w20, [x21, #0x10]      | typeof(Pathfinding.Ionic.Zip.AddProgressEventArgs).__il2cppRuntimeField_10 = W3;  //  dest_result_addr=1152921504750616592
            typeof(Pathfinding.Ionic.Zip.AddProgressEventArgs).__il2cppRuntimeField_10 = W3;
            // 0x01970310: B #0x1970324               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x01970314: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(archiveName:  entry, flavor:  1), ????);
            // 0x01970318: ORR w8, wzr, #0x10         | W8 = 16(0x10);                          
            // 0x0197031C: STR w20, [x8]              | mem[16] = W3;                            //  dest_result_addr=16
            mem[16] = W3;
            // 0x01970320: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(archiveName:  entry, flavor:  1), ????);
            label_2:
            // 0x01970324: STR x19, [x21, #0x18]      | typeof(Pathfinding.Ionic.Zip.AddProgressEventArgs).__il2cppRuntimeField_18 = entriesTotal;  //  dest_result_addr=1152921504750616600
            typeof(Pathfinding.Ionic.Zip.AddProgressEventArgs).__il2cppRuntimeField_18 = entriesTotal;
            // 0x01970328: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0197032C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01970330: MOV x0, x21                | X0 = 1152921504750616576 (0x100000000891C000);//ML01
            // 0x01970334: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01970338: RET                        |  return (Pathfinding.Ionic.Zip.AddProgressEventArgs)typeof(Pathfinding.Ionic.Zip.AddProgressEventArgs);
            return (Pathfinding.Ionic.Zip.AddProgressEventArgs)val_1;
            //  |  // // {name=val_0, type=Pathfinding.Ionic.Zip.AddProgressEventArgs, size=8, nGRN=0 }
        
        }
    
    }

}
