using UnityEngine;
public abstract class BuglyCallback
{
    // Methods
    //
    // Offset in libil2cpp.so: 0x02730E88 (41094792), len: 8  VirtAddr: 0x02730E88 RVA: 0x02730E88 token: 100663346 methodIndex: 24314 delegateWrapperIndex: 0 methodInvoker: 0
    protected BuglyCallback()
    {
        //
        // Disasemble & Code
        // 0x02730E88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02730E8C: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    public abstract void OnApplicationLogCallbackHandler(string condition, string stackTrace, UnityEngine.LogType type); // 0

}
