using UnityEngine;
[UnityEngine.ExecuteInEditMode] // 0x2867324
public class AnimatedAlpha : MonoBehaviour
{
    // Fields
    [UnityEngine.RangeAttribute] // 0x2867334
    public float alpha; //  0x00000018
    private UIWidget mWidget; //  0x00000020
    private UIPanel mPanel; //  0x00000028
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B272C4 (11694788), len: 16  VirtAddr: 0x00B272C4 RVA: 0x00B272C4 token: 100688417 methodIndex: 24778 delegateWrapperIndex: 0 methodInvoker: 0
    public AnimatedAlpha()
    {
        //
        // Disasemble & Code
        // 0x00B272C4: ORR w8, wzr, #0x3f800000   | W8 = 1065353216(0x3F800000);            
        // 0x00B272C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B272CC: STR w8, [x0, #0x18]        | this.alpha = 1;                          //  dest_result_addr=1152921514236619576
        this.alpha = 1f;
        // 0x00B272D0: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B272D4 (11694804), len: 116  VirtAddr: 0x00B272D4 RVA: 0x00B272D4 token: 100688418 methodIndex: 24779 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnEnable()
    {
        //
        // Disasemble & Code
        // 0x00B272D4: STP x20, x19, [sp, #-0x20]! | stack[1152921514236727712] = ???;  stack[1152921514236727720] = ???;  //  dest_result_addr=1152921514236727712 |  dest_result_addr=1152921514236727720
        // 0x00B272D8: STP x29, x30, [sp, #0x10]  | stack[1152921514236727728] = ???;  stack[1152921514236727736] = ???;  //  dest_result_addr=1152921514236727728 |  dest_result_addr=1152921514236727736
        // 0x00B272DC: ADD x29, sp, #0x10         | X29 = (1152921514236727712 + 16) = 1152921514236727728 (0x100000023DFC51B0);
        // 0x00B272E0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B272E4: LDRB w8, [x20, #0x748]     | W8 = (bool)static_value_03733748;       
        // 0x00B272E8: MOV x19, x0                | X19 = 1152921514236739744 (0x100000023DFC80A0);//ML01
        // 0x00B272EC: TBNZ w8, #0, #0xb27308     | if (static_value_03733748 == true) goto label_0;
        // 0x00B272F0: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
        // 0x00B272F4: LDR x8, [x8, #0x108]       | X8 = 0x2B8AD74;                         
        // 0x00B272F8: LDR w0, [x8]               | W0 = 0x21B;                             
        // 0x00B272FC: BL #0x2782188              | X0 = sub_2782188( ?? 0x21B, ????);      
        // 0x00B27300: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B27304: STRB w8, [x20, #0x748]     | static_value_03733748 = true;            //  dest_result_addr=57882440
        label_0:
        // 0x00B27308: ADRP x8, #0x35c7000        | X8 = 56389632 (0x35C7000);              
        // 0x00B2730C: LDR x8, [x8, #0x940]       | X8 = 1152921511725110736;               
        // 0x00B27310: MOV x0, x19                | X0 = 1152921514236739744 (0x100000023DFC80A0);//ML01
        // 0x00B27314: LDR x1, [x8]               | X1 = public UIWidget UnityEngine.Component::GetComponent<UIWidget>();
        // 0x00B27318: BL #0x23d5410              | X0 = this.GetComponent<UIWidget>();     
        UIWidget val_1 = this.GetComponent<UIWidget>();
        // 0x00B2731C: STR x0, [x19, #0x20]       | this.mWidget = val_1;                    //  dest_result_addr=1152921514236739776
        this.mWidget = val_1;
        // 0x00B27320: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
        // 0x00B27324: LDR x8, [x8, #0x8c0]       | X8 = 1152921511724932176;               
        // 0x00B27328: MOV x0, x19                | X0 = 1152921514236739744 (0x100000023DFC80A0);//ML01
        // 0x00B2732C: LDR x1, [x8]               | X1 = public UIPanel UnityEngine.Component::GetComponent<UIPanel>();
        // 0x00B27330: BL #0x23d5410              | X0 = this.GetComponent<UIPanel>();      
        UIPanel val_2 = this.GetComponent<UIPanel>();
        // 0x00B27334: STR x0, [x19, #0x28]       | this.mPanel = val_2;                     //  dest_result_addr=1152921514236739784
        this.mPanel = val_2;
        // 0x00B27338: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2733C: MOV x0, x19                | X0 = 1152921514236739744 (0x100000023DFC80A0);//ML01
        // 0x00B27340: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B27344: B #0xb27348                | this.LateUpdate(); return;              
        this.LateUpdate();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27348 (11694920), len: 280  VirtAddr: 0x00B27348 RVA: 0x00B27348 token: 100688419 methodIndex: 24780 delegateWrapperIndex: 0 methodInvoker: 0
    private void LateUpdate()
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        //  | 
        var val_4;
        //  | 
        var val_5;
        //  | 
        var val_6;
        //  | 
        var val_7;
        //  | 
        var val_8;
        //  | 
        var val_9;
        //  | 
        var val_10;
        //  | 
        var val_11;
        //  | 
        var val_12;
        //  | 
        float val_13;
        // 0x00B27348: STP d9, d8, [sp, #-0x40]!  | stack[1152921514236864256] = ???;  stack[1152921514236864264] = ???;  //  dest_result_addr=1152921514236864256 |  dest_result_addr=1152921514236864264
        // 0x00B2734C: STP x22, x21, [sp, #0x10]  | stack[1152921514236864272] = ???;  stack[1152921514236864280] = ???;  //  dest_result_addr=1152921514236864272 |  dest_result_addr=1152921514236864280
        // 0x00B27350: STP x20, x19, [sp, #0x20]  | stack[1152921514236864288] = ???;  stack[1152921514236864296] = ???;  //  dest_result_addr=1152921514236864288 |  dest_result_addr=1152921514236864296
        // 0x00B27354: STP x29, x30, [sp, #0x30]  | stack[1152921514236864304] = ???;  stack[1152921514236864312] = ???;  //  dest_result_addr=1152921514236864304 |  dest_result_addr=1152921514236864312
        // 0x00B27358: ADD x29, sp, #0x30         | X29 = (1152921514236864256 + 48) = 1152921514236864304 (0x100000023DFE6730);
        // 0x00B2735C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B27360: LDRB w8, [x20, #0x749]     | W8 = (bool)static_value_03733749;       
        // 0x00B27364: MOV x19, x0                | X19 = 1152921514236876320 (0x100000023DFE9620);//ML01
        val_11 = this;
        // 0x00B27368: TBNZ w8, #0, #0xb27384     | if (static_value_03733749 == true) goto label_0;
        // 0x00B2736C: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
        // 0x00B27370: LDR x8, [x8, #0xfd0]       | X8 = 0x2B8AD70;                         
        // 0x00B27374: LDR w0, [x8]               | W0 = 0x21A;                             
        // 0x00B27378: BL #0x2782188              | X0 = sub_2782188( ?? 0x21A, ????);      
        // 0x00B2737C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B27380: STRB w8, [x20, #0x749]     | static_value_03733749 = true;            //  dest_result_addr=57882441
        label_0:
        // 0x00B27384: ADRP x21, #0x35fe000       | X21 = 56614912 (0x35FE000);             
        // 0x00B27388: LDR x21, [x21, #0x810]     | X21 = 1152921504697475072;              
        val_12 = 1152921504697475072;
        // 0x00B2738C: LDR x20, [x19, #0x20]      | X20 = this.mWidget; //P2                
        // 0x00B27390: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B27394: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B27398: TBZ w8, #0, #0xb273a8      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B2739C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B273A0: CBNZ w8, #0xb273a8         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B273A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B273A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B273AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B273B0: MOV x1, x20                | X1 = this.mWidget;//m1                  
        // 0x00B273B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B273B8: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mWidget);
        bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mWidget);
        // 0x00B273BC: TBZ w0, #0, #0xb273e4      | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x00B273C0: LDR x20, [x19, #0x20]      | X20 = this.mWidget; //P2                
        // 0x00B273C4: LDR s8, [x19, #0x18]       | S8 = this.alpha; //P2                   
        val_13 = this.alpha;
        // 0x00B273C8: CBNZ x20, #0xb273d0        | if (this.mWidget != null) goto label_4; 
        if(this.mWidget != null)
        {
            goto label_4;
        }
        // 0x00B273CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B273D0: LDR x8, [x20]              | X8 = typeof(UIWidget);                  
        // 0x00B273D4: MOV x0, x20                | X0 = this.mWidget;//m1                  
        // 0x00B273D8: MOV v0.16b, v8.16b         | V0 = this.alpha;//m1                    
        // 0x00B273DC: LDP x9, x1, [x8, #0x190]   | X9 = typeof(UIWidget).__il2cppRuntimeField_190; X1 = typeof(UIWidget).__il2cppRuntimeField_198; //  | 
        // 0x00B273E0: BLR x9                     | X0 = typeof(UIWidget).__il2cppRuntimeField_190();
        label_3:
        // 0x00B273E4: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B273E8: LDR x20, [x19, #0x28]      | X20 = this.mPanel; //P2                 
        // 0x00B273EC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B273F0: TBZ w8, #0, #0xb27400      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00B273F4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B273F8: CBNZ w8, #0xb27400         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00B273FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_6:
        // 0x00B27400: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B27404: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B27408: MOV x1, x20                | X1 = this.mPanel;//m1                   
        // 0x00B2740C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B27410: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mPanel);
        bool val_2 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mPanel);
        // 0x00B27414: TBZ w0, #0, #0xb2744c      | if (val_2 == false) goto label_7;       
        if(val_2 == false)
        {
            goto label_7;
        }
        // 0x00B27418: LDR x20, [x19, #0x28]      | X20 = this.mPanel; //P2                 
        // 0x00B2741C: LDR s8, [x19, #0x18]       | S8 = this.alpha; //P2                   
        // 0x00B27420: CBNZ x20, #0xb27428        | if (this.mPanel != null) goto label_8;  
        if(this.mPanel != null)
        {
            goto label_8;
        }
        // 0x00B27424: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_8:
        // 0x00B27428: LDR x8, [x20]              | X8 = typeof(UIPanel);                   
        // 0x00B2742C: MOV x0, x20                | X0 = this.mPanel;//m1                   
        // 0x00B27430: MOV v0.16b, v8.16b         | V0 = this.alpha;//m1                    
        // 0x00B27434: LDP x2, x1, [x8, #0x190]   | X2 = typeof(UIPanel).__il2cppRuntimeField_190; X1 = typeof(UIPanel).__il2cppRuntimeField_198; //  | 
        // 0x00B27438: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2743C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        val_11 = ???;
        // 0x00B27440: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        val_12 = ???;
        // 0x00B27444: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        val_13 = ???;
        // 0x00B27448: BR x2                      | goto typeof(UIPanel).__il2cppRuntimeField_190;
        goto typeof(UIPanel).__il2cppRuntimeField_190;
        label_7:
        // 0x00B2744C: LDP x29, x30, [sp, #0x30]  | X29 = val_3; X30 = val_4;                //  find_add[1152921514236852320] |  find_add[1152921514236852320]
        // 0x00B27450: LDP x20, x19, [sp, #0x20]  | X20 = val_5; X19 = val_6;                //  find_add[1152921514236852320] |  find_add[1152921514236852320]
        // 0x00B27454: LDP x22, x21, [sp, #0x10]  | X22 = val_7; X21 = val_8;                //  find_add[1152921514236852320] |  find_add[1152921514236852320]
        // 0x00B27458: LDP d9, d8, [sp], #0x40    | D9 = val_9; D8 = val_10;                 //  find_add[1152921514236852320] |  find_add[1152921514236852320]
        // 0x00B2745C: RET                        |  return;                                
        return;
    
    }

}
