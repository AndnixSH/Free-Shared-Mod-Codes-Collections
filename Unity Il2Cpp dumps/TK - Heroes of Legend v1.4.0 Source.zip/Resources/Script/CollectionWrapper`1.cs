using UnityEngine;

namespace Newtonsoft.Json.Utilities
{
    internal class CollectionWrapper<T> : ICollection<T>, IWrappedCollection, IEnumerable, IEnumerable<T>, IList, ICollection
    {
        // Fields
        private readonly System.Collections.IList _list; //  0x00000010
        private readonly System.Collections.Generic.ICollection<T> _genericCollection; //  0x00000010
        private object _syncRoot; //  0x00000010
        
        // Properties
        private bool System.Collections.IList.IsFixedSize { get; }
        private object System.Collections.IList.Item { get; set; }
        private bool System.Collections.ICollection.IsSynchronized { get; }
        private object System.Collections.ICollection.SyncRoot { get; }
        public virtual int Count { get; }
        public virtual bool IsReadOnly { get; }
        public object UnderlyingCollection { get; }
        
        // Methods
        // Generic instance method:
        //
        // file offset: 0x019E88B4 VirtAddr: 0x019E88B4 -RVA: 0x019E88B4 
        // -CollectionWrapper<object>..ctor
        //
        //
        // Offset in libil2cpp.so: 0x019E88B4 (27166900), len: 292  VirtAddr: 0x019E88B4 RVA: 0x019E88B4 token: 100686585 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public CollectionWrapper<T>(System.Collections.IList list)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            var val_2;
            //  | 
            var val_3;
            // 0x019E88B4: STP x22, x21, [sp, #-0x30]! | stack[1152921513968434416] = ???;  stack[1152921513968434424] = ???;  //  dest_result_addr=1152921513968434416 |  dest_result_addr=1152921513968434424
            // 0x019E88B8: STP x20, x19, [sp, #0x10]  | stack[1152921513968434432] = ???;  stack[1152921513968434440] = ???;  //  dest_result_addr=1152921513968434432 |  dest_result_addr=1152921513968434440
            // 0x019E88BC: STP x29, x30, [sp, #0x20]  | stack[1152921513968434448] = ???;  stack[1152921513968434456] = ???;  //  dest_result_addr=1152921513968434448 |  dest_result_addr=1152921513968434456
            // 0x019E88C0: ADD x29, sp, #0x20         | X29 = (1152921513968434416 + 32) = 1152921513968434448 (0x100000022DFE7D10);
            // 0x019E88C4: SUB sp, sp, #0x10          | SP = (1152921513968434416 - 16) = 1152921513968434400 (0x100000022DFE7CE0);
            // 0x019E88C8: ADRP x22, #0x3739000       | X22 = 57905152 (0x3739000);             
            // 0x019E88CC: LDRB w8, [x22, #0x662]     | W8 = (bool)static_value_03739662;       
            // 0x019E88D0: MOV x21, x2                | X21 = __RuntimeMethodHiddenParam;//m1   
            val_2 = __RuntimeMethodHiddenParam;
            // 0x019E88D4: MOV x20, x1                | X20 = list;//m1                         
            // 0x019E88D8: MOV x19, x0                | X19 = 1152921513968446464 (0x100000022DFEAC00);//ML01
            // 0x019E88DC: TBNZ w8, #0, #0x19e88f8    | if (static_value_03739662 == true) goto label_0;
            // 0x019E88E0: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
            // 0x019E88E4: LDR x8, [x8, #0xcf0]       | X8 = 0x2B91634;                         
            // 0x019E88E8: LDR w0, [x8]               | W0 = 0x1C51;                            
            // 0x019E88EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C51, ????);     
            // 0x019E88F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019E88F4: STRB w8, [x22, #0x662]     | static_value_03739662 = true;            //  dest_result_addr=57906786
            label_0:
            // 0x019E88F8: CBNZ x19, #0x19e8900       | if (this != null) goto label_1;         
            if(this != null)
            {
                goto label_1;
            }
            // 0x019E88FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C51, ????);     
            label_1:
            // 0x019E8900: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019E8904: MOV x0, x19                | X0 = 1152921513968446464 (0x100000022DFEAC00);//ML01
            // 0x019E8908: BL #0x16f59f0              | this..ctor();                           
            // 0x019E890C: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x019E8910: LDR x8, [x8, #0x958]       | X8 = (string**)(1152921511169504192)("list");
            // 0x019E8914: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x019E8918: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x019E891C: MOV x1, x20                | X1 = list;//m1                          
            // 0x019E8920: LDR x2, [x8]               | X2 = "list";                            
            // 0x019E8924: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  0, parameterName:  list);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  0, parameterName:  list);
            // 0x019E8928: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E892C: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8930: LDR x22, [x8]              | X22 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8934: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x019E8938: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168, ????);
            // 0x019E893C: MOV x0, x20                | X0 = list;//m1                          
            // 0x019E8940: MOV x1, x22                | X1 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x019E8944: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? list, ????);       
            // 0x019E8948: CBZ x0, #0x19e89ac         | if (list == null) goto label_2;         
            if(list == null)
            {
                goto label_2;
            }
            // 0x019E894C: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E8950: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8954: LDR x21, [x8]              | X21 = __RuntimeMethodHiddenParam + 24 + 168;
            val_2 = mem[__RuntimeMethodHiddenParam + 24 + 168];
            val_2 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8958: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x019E895C: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168, ????);
            // 0x019E8960: CBZ x20, #0x19e89a0        | if (list == null) goto label_3;         
            if(list == null)
            {
                goto label_3;
            }
            // 0x019E8964: MOV x0, x20                | X0 = list;//m1                          
            val_3 = list;
            // 0x019E8968: MOV x1, x21                | X1 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x019E896C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? list, ????);       
            // 0x019E8970: CBNZ x0, #0x19e89a4        | if (list != null) goto label_4;         
            if(val_3 != null)
            {
                goto label_4;
            }
            // 0x019E8974: LDR x8, [x20]              | X8 = typeof(System.Collections.IList);  
            // 0x019E8978: MOV x1, x21                | X1 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x019E897C: LDR x0, [x8, #0x30]        | X0 = System.Collections.IList.__il2cppRuntimeField_element_class;
            // 0x019E8980: ADD x8, sp, #8             | X8 = (1152921513968434400 + 8) = 1152921513968434408 (0x100000022DFE7CE8);
            // 0x019E8984: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Collections.IList.__il2cppRuntimeField_element_class, ????);
            // 0x019E8988: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921513968422464]
            // 0x019E898C: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x019E8990: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019E8994: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x019E8998: ADD x0, sp, #8             | X0 = (1152921513968434400 + 8) = 1152921513968434408 (0x100000022DFE7CE8);
            // 0x019E899C: BL #0x299a140              | 
            label_3:
            // 0x019E89A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_3 = 0;
            label_4:
            // 0x019E89A4: STR x0, [x19, #0x18]       | mem[1152921513968446488] = 0x0;          //  dest_result_addr=1152921513968446488
            mem[1152921513968446488] = val_3;
            // 0x019E89A8: B #0x19e89b0               |  goto label_5;                          
            goto label_5;
            label_2:
            // 0x019E89AC: STR x20, [x19, #0x10]      | mem[1152921513968446480] = list;         //  dest_result_addr=1152921513968446480
            mem[1152921513968446480] = list;
            label_5:
            // 0x019E89B0: SUB sp, x29, #0x20         | SP = (1152921513968434448 - 32) = 1152921513968434416 (0x100000022DFE7CF0);
            // 0x019E89B4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019E89B8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019E89BC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019E89C0: RET                        |  return;                                
            return;
            // 0x019E89C4: MOV x19, x0                | 
            // 0x019E89C8: ADD x0, sp, #8             | 
            // 0x019E89CC: BL #0x299a140              | 
            // 0x019E89D0: MOV x0, x19                | 
            // 0x019E89D4: BL #0x980800               | 
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E89D8 VirtAddr: 0x019E89D8 -RVA: 0x019E89D8 
        // -CollectionWrapper<object>..ctor
        //
        //
        // Offset in libil2cpp.so: 0x019E89D8 (27167192), len: 128  VirtAddr: 0x019E89D8 RVA: 0x019E89D8 token: 100686586 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public CollectionWrapper<T>(System.Collections.Generic.ICollection<T> list)
        {
            //
            // Disasemble & Code
            // 0x019E89D8: STP x22, x21, [sp, #-0x30]! | stack[1152921513968554608] = ???;  stack[1152921513968554616] = ???;  //  dest_result_addr=1152921513968554608 |  dest_result_addr=1152921513968554616
            // 0x019E89DC: STP x20, x19, [sp, #0x10]  | stack[1152921513968554624] = ???;  stack[1152921513968554632] = ???;  //  dest_result_addr=1152921513968554624 |  dest_result_addr=1152921513968554632
            // 0x019E89E0: STP x29, x30, [sp, #0x20]  | stack[1152921513968554640] = ???;  stack[1152921513968554648] = ???;  //  dest_result_addr=1152921513968554640 |  dest_result_addr=1152921513968554648
            // 0x019E89E4: ADD x29, sp, #0x20         | X29 = (1152921513968554608 + 32) = 1152921513968554640 (0x100000022E005290);
            // 0x019E89E8: ADRP x21, #0x3739000       | X21 = 57905152 (0x3739000);             
            // 0x019E89EC: LDRB w8, [x21, #0x663]     | W8 = (bool)static_value_03739663;       
            // 0x019E89F0: MOV x19, x1                | X19 = list;//m1                         
            // 0x019E89F4: MOV x20, x0                | X20 = 1152921513968566656 (0x100000022E008180);//ML01
            // 0x019E89F8: TBNZ w8, #0, #0x19e8a14    | if (static_value_03739663 == true) goto label_0;
            // 0x019E89FC: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x019E8A00: LDR x8, [x8, #0x88]        | X8 = 0x2B91630;                         
            // 0x019E8A04: LDR w0, [x8]               | W0 = 0x1C50;                            
            // 0x019E8A08: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C50, ????);     
            // 0x019E8A0C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019E8A10: STRB w8, [x21, #0x663]     | static_value_03739663 = true;            //  dest_result_addr=57906787
            label_0:
            // 0x019E8A14: CBNZ x20, #0x19e8a1c       | if (this != null) goto label_1;         
            if(this != null)
            {
                goto label_1;
            }
            // 0x019E8A18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C50, ????);     
            label_1:
            // 0x019E8A1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019E8A20: MOV x0, x20                | X0 = 1152921513968566656 (0x100000022E008180);//ML01
            // 0x019E8A24: BL #0x16f59f0              | this..ctor();                           
            // 0x019E8A28: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x019E8A2C: LDR x8, [x8, #0x958]       | X8 = (string**)(1152921511169504192)("list");
            // 0x019E8A30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x019E8A34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x019E8A38: MOV x1, x19                | X1 = list;//m1                          
            // 0x019E8A3C: LDR x2, [x8]               | X2 = "list";                            
            // 0x019E8A40: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  0, parameterName:  list);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  0, parameterName:  list);
            // 0x019E8A44: STR x19, [x20, #0x18]      | mem[1152921513968566680] = list;         //  dest_result_addr=1152921513968566680
            mem[1152921513968566680] = list;
            // 0x019E8A48: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019E8A4C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019E8A50: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019E8A54: RET                        |  return;                                
            return;
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E8A58 VirtAddr: 0x019E8A58 -RVA: 0x019E8A58 
        // -CollectionWrapper<object>.Add
        //
        //
        // Offset in libil2cpp.so: 0x019E8A58 (27167320), len: 312  VirtAddr: 0x019E8A58 RVA: 0x019E8A58 token: 100686587 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual void Add(T item)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            // 0x019E8A58: STP x22, x21, [sp, #-0x30]! | stack[1152921513968674800] = ???;  stack[1152921513968674808] = ???;  //  dest_result_addr=1152921513968674800 |  dest_result_addr=1152921513968674808
            // 0x019E8A5C: STP x20, x19, [sp, #0x10]  | stack[1152921513968674816] = ???;  stack[1152921513968674824] = ???;  //  dest_result_addr=1152921513968674816 |  dest_result_addr=1152921513968674824
            // 0x019E8A60: STP x29, x30, [sp, #0x20]  | stack[1152921513968674832] = ???;  stack[1152921513968674840] = ???;  //  dest_result_addr=1152921513968674832 |  dest_result_addr=1152921513968674840
            // 0x019E8A64: ADD x29, sp, #0x20         | X29 = (1152921513968674800 + 32) = 1152921513968674832 (0x100000022E022810);
            // 0x019E8A68: ADRP x20, #0x3739000       | X20 = 57905152 (0x3739000);             
            // 0x019E8A6C: LDRB w8, [x20, #0x664]     | W8 = (bool)static_value_03739664;       
            // 0x019E8A70: MOV x21, x2                | X21 = __RuntimeMethodHiddenParam;//m1   
            val_2 = __RuntimeMethodHiddenParam;
            // 0x019E8A74: MOV x19, x1                | X19 = item;//m1                         
            // 0x019E8A78: MOV x22, x0                | X22 = 1152921513968686848 (0x100000022E025700);//ML01
            // 0x019E8A7C: TBNZ w8, #0, #0x19e8a98    | if (static_value_03739664 == true) goto label_0;
            // 0x019E8A80: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
            // 0x019E8A84: LDR x8, [x8, #0xab8]       | X8 = 0x2B91638;                         
            // 0x019E8A88: LDR w0, [x8]               | W0 = 0x1C52;                            
            // 0x019E8A8C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C52, ????);     
            // 0x019E8A90: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019E8A94: STRB w8, [x20, #0x664]     | static_value_03739664 = true;            //  dest_result_addr=57906788
            label_0:
            // 0x019E8A98: LDR x20, [x22, #0x18]      | 
            // 0x019E8A9C: CBZ x20, #0x19e8af8        | if ( == 0) goto label_1;                
            if(==0)
            {
                goto label_1;
            }
            // 0x019E8AA0: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E8AA4: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8AA8: LDR x21, [x8]              | X21 = __RuntimeMethodHiddenParam + 24 + 168;
            val_2 = mem[__RuntimeMethodHiddenParam + 24 + 168];
            val_2 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8AAC: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x019E8AB0: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168, ????);
            // 0x019E8AB4: LDR x8, [x20]              | X8 = mem[57905152];                     
            val_4 = mem[57905152];
            // 0x019E8AB8: LDRH w9, [x8, #0x102]      | W9 = mem[57905152] + 258;               
            // 0x019E8ABC: CBZ x9, #0x19e8ae8         | if (mem[57905152] + 258 == 0) goto label_2;
            if((mem[57905152] + 258) == 0)
            {
                goto label_2;
            }
            // 0x019E8AC0: LDR x10, [x8, #0x98]       | X10 = mem[57905152] + 152;              
            var val_1 = mem[57905152] + 152;
            // 0x019E8AC4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x019E8AC8: ADD x10, x10, #8           | X10 = (mem[57905152] + 152 + 8);        
            val_1 = val_1 + 8;
            label_4:
            // 0x019E8ACC: LDUR x12, [x10, #-8]       | X12 = (mem[57905152] + 152 + 8) + -8;   
            // 0x019E8AD0: CMP x12, x21               | STATE = COMPARE((mem[57905152] + 152 + 8) + -8, __RuntimeMethodHiddenParam + 24 + 168)
            // 0x019E8AD4: B.EQ #0x19e8b54            | if ((mem[57905152] + 152 + 8) + -8 == val_2) goto label_3;
            if(((mem[57905152] + 152 + 8) + -8) == val_2)
            {
                goto label_3;
            }
            // 0x019E8AD8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x019E8ADC: ADD x10, x10, #0x10        | X10 = ((mem[57905152] + 152 + 8) + 16); 
            val_1 = val_1 + 16;
            // 0x019E8AE0: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[57905152] + 258)
            // 0x019E8AE4: B.LO #0x19e8acc            | if (0 < mem[57905152] + 258) goto label_4;
            if(val_2 < (mem[57905152] + 258))
            {
                goto label_4;
            }
            label_2:
            // 0x019E8AE8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x019E8AEC: MOV x0, x20                | X0 = 57905152 (0x3739000);//ML01        
            val_5 = 57905152;
            // 0x019E8AF0: MOV x1, x21                | X1 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x019E8AF4: B #0x19e8b4c               |  goto label_5;                          
            goto label_5;
            label_1:
            // 0x019E8AF8: LDR x20, [x22, #0x10]      | 
            // 0x019E8AFC: CBNZ x20, #0x19e8b04       | if ( != 0) goto label_6;                
            if(!=0)
            {
                goto label_6;
            }
            // 0x019E8B00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C52, ????);     
            label_6:
            // 0x019E8B04: ADRP x9, #0x3605000        | X9 = 56643584 (0x3605000);              
            // 0x019E8B08: LDR x8, [x20]              | X8 = mem[57905152];                     
            val_4 = mem[57905152];
            // 0x019E8B0C: LDR x9, [x9, #0x308]       | X9 = 1152921504609349632;               
            // 0x019E8B10: LDR x1, [x9]               | X1 = typeof(System.Collections.IList);  
            // 0x019E8B14: LDRH w9, [x8, #0x102]      | W9 = mem[57905152] + 258;               
            // 0x019E8B18: CBZ x9, #0x19e8b44         | if (mem[57905152] + 258 == 0) goto label_7;
            if((mem[57905152] + 258) == 0)
            {
                goto label_7;
            }
            // 0x019E8B1C: LDR x10, [x8, #0x98]       | X10 = mem[57905152] + 152;              
            var val_3 = mem[57905152] + 152;
            // 0x019E8B20: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_4 = 0;
            // 0x019E8B24: ADD x10, x10, #8           | X10 = (mem[57905152] + 152 + 8);        
            val_3 = val_3 + 8;
            label_9:
            // 0x019E8B28: LDUR x12, [x10, #-8]       | X12 = (mem[57905152] + 152 + 8) + -8;   
            // 0x019E8B2C: CMP x12, x1                | STATE = COMPARE((mem[57905152] + 152 + 8) + -8, typeof(System.Collections.IList))
            // 0x019E8B30: B.EQ #0x19e8b60            | if ((mem[57905152] + 152 + 8) + -8 == null) goto label_8;
            if(((mem[57905152] + 152 + 8) + -8) == null)
            {
                goto label_8;
            }
            // 0x019E8B34: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_4 = val_4 + 1;
            // 0x019E8B38: ADD x10, x10, #0x10        | X10 = ((mem[57905152] + 152 + 8) + 16); 
            val_3 = val_3 + 16;
            // 0x019E8B3C: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[57905152] + 258)
            // 0x019E8B40: B.LO #0x19e8b28            | if (0 < mem[57905152] + 258) goto label_9;
            if(val_4 < (mem[57905152] + 258))
            {
                goto label_9;
            }
            label_7:
            // 0x019E8B44: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x019E8B48: MOV x0, x20                | X0 = 57905152 (0x3739000);//ML01        
            val_5 = 57905152;
            label_5:
            // 0x019E8B4C: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x3739000, ????);  
            // 0x019E8B50: B #0x19e8b70               |  goto label_10;                         
            goto label_10;
            label_3:
            // 0x019E8B54: LDR w9, [x10]              | W9 = (mem[57905152] + 152 + 8);         
            // 0x019E8B58: ADD w9, w9, #2             | W9 = ((mem[57905152] + 152 + 8) + 2);   
            val_6 = val_1 + 2;
            // 0x019E8B5C: B #0x19e8b68               |  goto label_11;                         
            goto label_11;
            label_8:
            // 0x019E8B60: LDR w9, [x10]              | W9 = (mem[57905152] + 152 + 8);         
            // 0x019E8B64: ADD w9, w9, #4             | W9 = ((mem[57905152] + 152 + 8) + 4);   
            val_6 = val_3 + 4;
            label_11:
            // 0x019E8B68: ADD x8, x8, w9, uxtw #4    | X8 = (mem[57905152] + ((mem[57905152] + 152 + 8) + 4));
            val_4 = val_4 + val_6;
            // 0x019E8B6C: ADD x0, x8, #0x110         | X0 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 4)) + 272);
            val_5 = val_4 + 272;
            label_10:
            // 0x019E8B70: LDR x3, [x0]               | X3 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 4)) + 272);
            // 0x019E8B74: LDR x2, [x0, #8]           | X2 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 4)) + 272) + 8;
            // 0x019E8B78: MOV x0, x20                | X0 = 57905152 (0x3739000);//ML01        
            // 0x019E8B7C: MOV x1, x19                | X1 = item;//m1                          
            // 0x019E8B80: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019E8B84: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019E8B88: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019E8B8C: BR x3                      | goto ((mem[57905152] + ((mem[57905152] + 152 + 8) + 4)) + 272);
            goto ((mem[57905152] + ((mem[57905152] + 152 + 8) + 4)) + 272);
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E8B90 VirtAddr: 0x019E8B90 -RVA: 0x019E8B90 
        // -CollectionWrapper<object>.Clear
        //
        //
        // Offset in libil2cpp.so: 0x019E8B90 (27167632), len: 304  VirtAddr: 0x019E8B90 RVA: 0x019E8B90 token: 100686588 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual void Clear()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            var val_5;
            // 0x019E8B90: STP x22, x21, [sp, #-0x30]! | stack[1152921513968790896] = ???;  stack[1152921513968790904] = ???;  //  dest_result_addr=1152921513968790896 |  dest_result_addr=1152921513968790904
            // 0x019E8B94: STP x20, x19, [sp, #0x10]  | stack[1152921513968790912] = ???;  stack[1152921513968790920] = ???;  //  dest_result_addr=1152921513968790912 |  dest_result_addr=1152921513968790920
            // 0x019E8B98: STP x29, x30, [sp, #0x20]  | stack[1152921513968790928] = ???;  stack[1152921513968790936] = ???;  //  dest_result_addr=1152921513968790928 |  dest_result_addr=1152921513968790936
            // 0x019E8B9C: ADD x29, sp, #0x20         | X29 = (1152921513968790896 + 32) = 1152921513968790928 (0x100000022E03ED90);
            // 0x019E8BA0: ADRP x19, #0x3739000       | X19 = 57905152 (0x3739000);             
            // 0x019E8BA4: LDRB w8, [x19, #0x665]     | W8 = (bool)static_value_03739665;       
            // 0x019E8BA8: MOV x20, x1                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x019E8BAC: MOV x21, x0                | X21 = 1152921513968802944 (0x100000022E041C80);//ML01
            // 0x019E8BB0: TBNZ w8, #0, #0x19e8bcc    | if (static_value_03739665 == true) goto label_0;
            // 0x019E8BB4: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x019E8BB8: LDR x8, [x8, #0x9c0]       | X8 = 0x2B9163C;                         
            // 0x019E8BBC: LDR w0, [x8]               | W0 = 0x1C53;                            
            // 0x019E8BC0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C53, ????);     
            // 0x019E8BC4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019E8BC8: STRB w8, [x19, #0x665]     | static_value_03739665 = true;            //  dest_result_addr=57906789
            label_0:
            // 0x019E8BCC: LDR x19, [x21, #0x18]      | 
            // 0x019E8BD0: CBZ x19, #0x19e8c2c        | if ( == 0) goto label_1;                
            if(==0)
            {
                goto label_1;
            }
            // 0x019E8BD4: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E8BD8: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8BDC: LDR x20, [x8]              | X20 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8BE0: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x019E8BE4: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168, ????);
            // 0x019E8BE8: LDR x8, [x19]              | X8 = mem[57905152];                     
            val_3 = mem[57905152];
            // 0x019E8BEC: LDRH w9, [x8, #0x102]      | W9 = mem[57905152] + 258;               
            // 0x019E8BF0: CBZ x9, #0x19e8c1c         | if (mem[57905152] + 258 == 0) goto label_2;
            if((mem[57905152] + 258) == 0)
            {
                goto label_2;
            }
            // 0x019E8BF4: LDR x10, [x8, #0x98]       | X10 = mem[57905152] + 152;              
            var val_1 = mem[57905152] + 152;
            // 0x019E8BF8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x019E8BFC: ADD x10, x10, #8           | X10 = (mem[57905152] + 152 + 8);        
            val_1 = val_1 + 8;
            label_4:
            // 0x019E8C00: LDUR x12, [x10, #-8]       | X12 = (mem[57905152] + 152 + 8) + -8;   
            // 0x019E8C04: CMP x12, x20               | STATE = COMPARE((mem[57905152] + 152 + 8) + -8, __RuntimeMethodHiddenParam + 24 + 168)
            // 0x019E8C08: B.EQ #0x19e8c88            | if ((mem[57905152] + 152 + 8) + -8 == __RuntimeMethodHiddenParam + 24 + 168) goto label_3;
            if(((mem[57905152] + 152 + 8) + -8) == (__RuntimeMethodHiddenParam + 24 + 168))
            {
                goto label_3;
            }
            // 0x019E8C0C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x019E8C10: ADD x10, x10, #0x10        | X10 = ((mem[57905152] + 152 + 8) + 16); 
            val_1 = val_1 + 16;
            // 0x019E8C14: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[57905152] + 258)
            // 0x019E8C18: B.LO #0x19e8c00            | if (0 < mem[57905152] + 258) goto label_4;
            if(val_2 < (mem[57905152] + 258))
            {
                goto label_4;
            }
            label_2:
            // 0x019E8C1C: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x019E8C20: MOV x0, x19                | X0 = 57905152 (0x3739000);//ML01        
            val_4 = 57905152;
            // 0x019E8C24: MOV x1, x20                | X1 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x019E8C28: B #0x19e8c80               |  goto label_5;                          
            goto label_5;
            label_1:
            // 0x019E8C2C: LDR x19, [x21, #0x10]      | 
            // 0x019E8C30: CBNZ x19, #0x19e8c38       | if ( != 0) goto label_6;                
            if(!=0)
            {
                goto label_6;
            }
            // 0x019E8C34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C53, ????);     
            label_6:
            // 0x019E8C38: ADRP x9, #0x3605000        | X9 = 56643584 (0x3605000);              
            // 0x019E8C3C: LDR x8, [x19]              | X8 = mem[57905152];                     
            val_3 = mem[57905152];
            // 0x019E8C40: LDR x9, [x9, #0x308]       | X9 = 1152921504609349632;               
            // 0x019E8C44: LDR x1, [x9]               | X1 = typeof(System.Collections.IList);  
            // 0x019E8C48: LDRH w9, [x8, #0x102]      | W9 = mem[57905152] + 258;               
            // 0x019E8C4C: CBZ x9, #0x19e8c78         | if (mem[57905152] + 258 == 0) goto label_7;
            if((mem[57905152] + 258) == 0)
            {
                goto label_7;
            }
            // 0x019E8C50: LDR x10, [x8, #0x98]       | X10 = mem[57905152] + 152;              
            var val_3 = mem[57905152] + 152;
            // 0x019E8C54: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_4 = 0;
            // 0x019E8C58: ADD x10, x10, #8           | X10 = (mem[57905152] + 152 + 8);        
            val_3 = val_3 + 8;
            label_9:
            // 0x019E8C5C: LDUR x12, [x10, #-8]       | X12 = (mem[57905152] + 152 + 8) + -8;   
            // 0x019E8C60: CMP x12, x1                | STATE = COMPARE((mem[57905152] + 152 + 8) + -8, typeof(System.Collections.IList))
            // 0x019E8C64: B.EQ #0x19e8c94            | if ((mem[57905152] + 152 + 8) + -8 == null) goto label_8;
            if(((mem[57905152] + 152 + 8) + -8) == null)
            {
                goto label_8;
            }
            // 0x019E8C68: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_4 = val_4 + 1;
            // 0x019E8C6C: ADD x10, x10, #0x10        | X10 = ((mem[57905152] + 152 + 8) + 16); 
            val_3 = val_3 + 16;
            // 0x019E8C70: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[57905152] + 258)
            // 0x019E8C74: B.LO #0x19e8c5c            | if (0 < mem[57905152] + 258) goto label_9;
            if(val_4 < (mem[57905152] + 258))
            {
                goto label_9;
            }
            label_7:
            // 0x019E8C78: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x019E8C7C: MOV x0, x19                | X0 = 57905152 (0x3739000);//ML01        
            val_4 = 57905152;
            label_5:
            // 0x019E8C80: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x3739000, ????);  
            // 0x019E8C84: B #0x19e8ca4               |  goto label_10;                         
            goto label_10;
            label_3:
            // 0x019E8C88: LDR w9, [x10]              | W9 = (mem[57905152] + 152 + 8);         
            // 0x019E8C8C: ADD w9, w9, #3             | W9 = ((mem[57905152] + 152 + 8) + 3);   
            val_5 = val_1 + 3;
            // 0x019E8C90: B #0x19e8c9c               |  goto label_11;                         
            goto label_11;
            label_8:
            // 0x019E8C94: LDR w9, [x10]              | W9 = (mem[57905152] + 152 + 8);         
            // 0x019E8C98: ADD w9, w9, #5             | W9 = ((mem[57905152] + 152 + 8) + 5);   
            val_5 = val_3 + 5;
            label_11:
            // 0x019E8C9C: ADD x8, x8, w9, uxtw #4    | X8 = (mem[57905152] + ((mem[57905152] + 152 + 8) + 5));
            val_3 = val_3 + val_5;
            // 0x019E8CA0: ADD x0, x8, #0x110         | X0 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 5)) + 272);
            val_4 = val_3 + 272;
            label_10:
            // 0x019E8CA4: LDR x2, [x0]               | X2 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 5)) + 272);
            // 0x019E8CA8: LDR x1, [x0, #8]           | X1 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 5)) + 272) + 8;
            // 0x019E8CAC: MOV x0, x19                | X0 = 57905152 (0x3739000);//ML01        
            // 0x019E8CB0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019E8CB4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019E8CB8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019E8CBC: BR x2                      | goto ((mem[57905152] + ((mem[57905152] + 152 + 8) + 5)) + 272);
            goto ((mem[57905152] + ((mem[57905152] + 152 + 8) + 5)) + 272);
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E8CC0 VirtAddr: 0x019E8CC0 -RVA: 0x019E8CC0 
        // -CollectionWrapper<object>.Contains
        //
        //
        // Offset in libil2cpp.so: 0x019E8CC0 (27167936), len: 312  VirtAddr: 0x019E8CC0 RVA: 0x019E8CC0 token: 100686589 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual bool Contains(T item)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            // 0x019E8CC0: STP x22, x21, [sp, #-0x30]! | stack[1152921513968906992] = ???;  stack[1152921513968907000] = ???;  //  dest_result_addr=1152921513968906992 |  dest_result_addr=1152921513968907000
            // 0x019E8CC4: STP x20, x19, [sp, #0x10]  | stack[1152921513968907008] = ???;  stack[1152921513968907016] = ???;  //  dest_result_addr=1152921513968907008 |  dest_result_addr=1152921513968907016
            // 0x019E8CC8: STP x29, x30, [sp, #0x20]  | stack[1152921513968907024] = ???;  stack[1152921513968907032] = ???;  //  dest_result_addr=1152921513968907024 |  dest_result_addr=1152921513968907032
            // 0x019E8CCC: ADD x29, sp, #0x20         | X29 = (1152921513968906992 + 32) = 1152921513968907024 (0x100000022E05B310);
            // 0x019E8CD0: ADRP x20, #0x3739000       | X20 = 57905152 (0x3739000);             
            // 0x019E8CD4: LDRB w8, [x20, #0x666]     | W8 = (bool)static_value_03739666;       
            // 0x019E8CD8: MOV x21, x2                | X21 = __RuntimeMethodHiddenParam;//m1   
            val_2 = __RuntimeMethodHiddenParam;
            // 0x019E8CDC: MOV x19, x1                | X19 = item;//m1                         
            // 0x019E8CE0: MOV x22, x0                | X22 = 1152921513968919040 (0x100000022E05E200);//ML01
            // 0x019E8CE4: TBNZ w8, #0, #0x19e8d00    | if (static_value_03739666 == true) goto label_0;
            // 0x019E8CE8: ADRP x8, #0x367e000        | X8 = 57139200 (0x367E000);              
            // 0x019E8CEC: LDR x8, [x8, #0xd98]       | X8 = 0x2B91640;                         
            // 0x019E8CF0: LDR w0, [x8]               | W0 = 0x1C54;                            
            // 0x019E8CF4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C54, ????);     
            // 0x019E8CF8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019E8CFC: STRB w8, [x20, #0x666]     | static_value_03739666 = true;            //  dest_result_addr=57906790
            label_0:
            // 0x019E8D00: LDR x20, [x22, #0x18]      | 
            // 0x019E8D04: CBZ x20, #0x19e8d60        | if ( == 0) goto label_1;                
            if(==0)
            {
                goto label_1;
            }
            // 0x019E8D08: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E8D0C: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8D10: LDR x21, [x8]              | X21 = __RuntimeMethodHiddenParam + 24 + 168;
            val_2 = mem[__RuntimeMethodHiddenParam + 24 + 168];
            val_2 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8D14: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x019E8D18: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168, ????);
            // 0x019E8D1C: LDR x8, [x20]              | X8 = mem[57905152];                     
            val_4 = mem[57905152];
            // 0x019E8D20: LDRH w9, [x8, #0x102]      | W9 = mem[57905152] + 258;               
            // 0x019E8D24: CBZ x9, #0x19e8d50         | if (mem[57905152] + 258 == 0) goto label_2;
            if((mem[57905152] + 258) == 0)
            {
                goto label_2;
            }
            // 0x019E8D28: LDR x10, [x8, #0x98]       | X10 = mem[57905152] + 152;              
            var val_1 = mem[57905152] + 152;
            // 0x019E8D2C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x019E8D30: ADD x10, x10, #8           | X10 = (mem[57905152] + 152 + 8);        
            val_1 = val_1 + 8;
            label_4:
            // 0x019E8D34: LDUR x12, [x10, #-8]       | X12 = (mem[57905152] + 152 + 8) + -8;   
            // 0x019E8D38: CMP x12, x21               | STATE = COMPARE((mem[57905152] + 152 + 8) + -8, __RuntimeMethodHiddenParam + 24 + 168)
            // 0x019E8D3C: B.EQ #0x19e8dbc            | if ((mem[57905152] + 152 + 8) + -8 == val_2) goto label_3;
            if(((mem[57905152] + 152 + 8) + -8) == val_2)
            {
                goto label_3;
            }
            // 0x019E8D40: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x019E8D44: ADD x10, x10, #0x10        | X10 = ((mem[57905152] + 152 + 8) + 16); 
            val_1 = val_1 + 16;
            // 0x019E8D48: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[57905152] + 258)
            // 0x019E8D4C: B.LO #0x19e8d34            | if (0 < mem[57905152] + 258) goto label_4;
            if(val_2 < (mem[57905152] + 258))
            {
                goto label_4;
            }
            label_2:
            // 0x019E8D50: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x019E8D54: MOV x0, x20                | X0 = 57905152 (0x3739000);//ML01        
            val_5 = 57905152;
            // 0x019E8D58: MOV x1, x21                | X1 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x019E8D5C: B #0x19e8db4               |  goto label_5;                          
            goto label_5;
            label_1:
            // 0x019E8D60: LDR x20, [x22, #0x10]      | 
            // 0x019E8D64: CBNZ x20, #0x19e8d6c       | if ( != 0) goto label_6;                
            if(!=0)
            {
                goto label_6;
            }
            // 0x019E8D68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C54, ????);     
            label_6:
            // 0x019E8D6C: ADRP x9, #0x3605000        | X9 = 56643584 (0x3605000);              
            // 0x019E8D70: LDR x8, [x20]              | X8 = mem[57905152];                     
            val_4 = mem[57905152];
            // 0x019E8D74: LDR x9, [x9, #0x308]       | X9 = 1152921504609349632;               
            // 0x019E8D78: LDR x1, [x9]               | X1 = typeof(System.Collections.IList);  
            // 0x019E8D7C: LDRH w9, [x8, #0x102]      | W9 = mem[57905152] + 258;               
            // 0x019E8D80: CBZ x9, #0x19e8dac         | if (mem[57905152] + 258 == 0) goto label_7;
            if((mem[57905152] + 258) == 0)
            {
                goto label_7;
            }
            // 0x019E8D84: LDR x10, [x8, #0x98]       | X10 = mem[57905152] + 152;              
            var val_3 = mem[57905152] + 152;
            // 0x019E8D88: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_4 = 0;
            // 0x019E8D8C: ADD x10, x10, #8           | X10 = (mem[57905152] + 152 + 8);        
            val_3 = val_3 + 8;
            label_9:
            // 0x019E8D90: LDUR x12, [x10, #-8]       | X12 = (mem[57905152] + 152 + 8) + -8;   
            // 0x019E8D94: CMP x12, x1                | STATE = COMPARE((mem[57905152] + 152 + 8) + -8, typeof(System.Collections.IList))
            // 0x019E8D98: B.EQ #0x19e8dc8            | if ((mem[57905152] + 152 + 8) + -8 == null) goto label_8;
            if(((mem[57905152] + 152 + 8) + -8) == null)
            {
                goto label_8;
            }
            // 0x019E8D9C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_4 = val_4 + 1;
            // 0x019E8DA0: ADD x10, x10, #0x10        | X10 = ((mem[57905152] + 152 + 8) + 16); 
            val_3 = val_3 + 16;
            // 0x019E8DA4: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[57905152] + 258)
            // 0x019E8DA8: B.LO #0x19e8d90            | if (0 < mem[57905152] + 258) goto label_9;
            if(val_4 < (mem[57905152] + 258))
            {
                goto label_9;
            }
            label_7:
            // 0x019E8DAC: ORR w2, wzr, #6            | W2 = 6(0x6);                            
            // 0x019E8DB0: MOV x0, x20                | X0 = 57905152 (0x3739000);//ML01        
            val_5 = 57905152;
            label_5:
            // 0x019E8DB4: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x3739000, ????);  
            // 0x019E8DB8: B #0x19e8dd8               |  goto label_10;                         
            goto label_10;
            label_3:
            // 0x019E8DBC: LDR w9, [x10]              | W9 = (mem[57905152] + 152 + 8);         
            // 0x019E8DC0: ADD w9, w9, #4             | W9 = ((mem[57905152] + 152 + 8) + 4);   
            val_6 = val_1 + 4;
            // 0x019E8DC4: B #0x19e8dd0               |  goto label_11;                         
            goto label_11;
            label_8:
            // 0x019E8DC8: LDR w9, [x10]              | W9 = (mem[57905152] + 152 + 8);         
            // 0x019E8DCC: ADD w9, w9, #6             | W9 = ((mem[57905152] + 152 + 8) + 6);   
            val_6 = val_3 + 6;
            label_11:
            // 0x019E8DD0: ADD x8, x8, w9, uxtw #4    | X8 = (mem[57905152] + ((mem[57905152] + 152 + 8) + 6));
            val_4 = val_4 + val_6;
            // 0x019E8DD4: ADD x0, x8, #0x110         | X0 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 6)) + 272);
            val_5 = val_4 + 272;
            label_10:
            // 0x019E8DD8: LDR x3, [x0]               | X3 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 6)) + 272);
            // 0x019E8DDC: LDR x2, [x0, #8]           | X2 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 6)) + 272) + 8;
            // 0x019E8DE0: MOV x0, x20                | X0 = 57905152 (0x3739000);//ML01        
            // 0x019E8DE4: MOV x1, x19                | X1 = item;//m1                          
            // 0x019E8DE8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019E8DEC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019E8DF0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019E8DF4: BR x3                      | goto ((mem[57905152] + ((mem[57905152] + 152 + 8) + 6)) + 272);
            goto ((mem[57905152] + ((mem[57905152] + 152 + 8) + 6)) + 272);
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E8DF8 VirtAddr: 0x019E8DF8 -RVA: 0x019E8DF8 
        // -CollectionWrapper<object>.CopyTo
        //
        //
        // Offset in libil2cpp.so: 0x019E8DF8 (27168248), len: 328  VirtAddr: 0x019E8DF8 RVA: 0x019E8DF8 token: 100686590 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual void CopyTo(T[] array, int arrayIndex)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            var val_5;
            // 0x019E8DF8: STP x24, x23, [sp, #-0x40]! | stack[1152921513969059936] = ???;  stack[1152921513969059944] = ???;  //  dest_result_addr=1152921513969059936 |  dest_result_addr=1152921513969059944
            // 0x019E8DFC: STP x22, x21, [sp, #0x10]  | stack[1152921513969059952] = ???;  stack[1152921513969059960] = ???;  //  dest_result_addr=1152921513969059952 |  dest_result_addr=1152921513969059960
            // 0x019E8E00: STP x20, x19, [sp, #0x20]  | stack[1152921513969059968] = ???;  stack[1152921513969059976] = ???;  //  dest_result_addr=1152921513969059968 |  dest_result_addr=1152921513969059976
            // 0x019E8E04: STP x29, x30, [sp, #0x30]  | stack[1152921513969059984] = ???;  stack[1152921513969059992] = ???;  //  dest_result_addr=1152921513969059984 |  dest_result_addr=1152921513969059992
            // 0x019E8E08: ADD x29, sp, #0x30         | X29 = (1152921513969059936 + 48) = 1152921513969059984 (0x100000022E080890);
            // 0x019E8E0C: ADRP x21, #0x3739000       | X21 = 57905152 (0x3739000);             
            // 0x019E8E10: LDRB w8, [x21, #0x667]     | W8 = (bool)static_value_03739667;       
            // 0x019E8E14: MOV x22, x3                | X22 = __RuntimeMethodHiddenParam;//m1   
            // 0x019E8E18: MOV w19, w2                | W19 = arrayIndex;//m1                   
            // 0x019E8E1C: MOV x20, x1                | X20 = array;//m1                        
            // 0x019E8E20: MOV x23, x0                | X23 = 1152921513969072000 (0x100000022E083780);//ML01
            // 0x019E8E24: TBNZ w8, #0, #0x19e8e40    | if (static_value_03739667 == true) goto label_0;
            // 0x019E8E28: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x019E8E2C: LDR x8, [x8, #0xe28]       | X8 = 0x2B91644;                         
            // 0x019E8E30: LDR w0, [x8]               | W0 = 0x1C55;                            
            // 0x019E8E34: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C55, ????);     
            // 0x019E8E38: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019E8E3C: STRB w8, [x21, #0x667]     | static_value_03739667 = true;            //  dest_result_addr=57906791
            label_0:
            // 0x019E8E40: LDR x21, [x23, #0x18]      | 
            // 0x019E8E44: CBZ x21, #0x19e8ea0        | if ( == 0) goto label_1;                
            if(==0)
            {
                goto label_1;
            }
            // 0x019E8E48: LDR x8, [x22, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E8E4C: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8E50: LDR x22, [x8]              | X22 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8E54: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x019E8E58: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168, ????);
            // 0x019E8E5C: LDR x8, [x21]              | X8 = mem[57905152];                     
            val_3 = mem[57905152];
            // 0x019E8E60: LDRH w9, [x8, #0x102]      | W9 = mem[57905152] + 258;               
            // 0x019E8E64: CBZ x9, #0x19e8e90         | if (mem[57905152] + 258 == 0) goto label_2;
            if((mem[57905152] + 258) == 0)
            {
                goto label_2;
            }
            // 0x019E8E68: LDR x10, [x8, #0x98]       | X10 = mem[57905152] + 152;              
            var val_1 = mem[57905152] + 152;
            // 0x019E8E6C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x019E8E70: ADD x10, x10, #8           | X10 = (mem[57905152] + 152 + 8);        
            val_1 = val_1 + 8;
            label_4:
            // 0x019E8E74: LDUR x12, [x10, #-8]       | X12 = (mem[57905152] + 152 + 8) + -8;   
            // 0x019E8E78: CMP x12, x22               | STATE = COMPARE((mem[57905152] + 152 + 8) + -8, __RuntimeMethodHiddenParam + 24 + 168)
            // 0x019E8E7C: B.EQ #0x19e8efc            | if ((mem[57905152] + 152 + 8) + -8 == __RuntimeMethodHiddenParam + 24 + 168) goto label_3;
            if(((mem[57905152] + 152 + 8) + -8) == (__RuntimeMethodHiddenParam + 24 + 168))
            {
                goto label_3;
            }
            // 0x019E8E80: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x019E8E84: ADD x10, x10, #0x10        | X10 = ((mem[57905152] + 152 + 8) + 16); 
            val_1 = val_1 + 16;
            // 0x019E8E88: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[57905152] + 258)
            // 0x019E8E8C: B.LO #0x19e8e74            | if (0 < mem[57905152] + 258) goto label_4;
            if(val_2 < (mem[57905152] + 258))
            {
                goto label_4;
            }
            label_2:
            // 0x019E8E90: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x019E8E94: MOV x0, x21                | X0 = 57905152 (0x3739000);//ML01        
            val_4 = 57905152;
            // 0x019E8E98: MOV x1, x22                | X1 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x019E8E9C: B #0x19e8ef4               |  goto label_5;                          
            goto label_5;
            label_1:
            // 0x019E8EA0: LDR x21, [x23, #0x10]      | 
            // 0x019E8EA4: CBNZ x21, #0x19e8eac       | if ( != 0) goto label_6;                
            if(!=0)
            {
                goto label_6;
            }
            // 0x019E8EA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C55, ????);     
            label_6:
            // 0x019E8EAC: ADRP x9, #0x35db000        | X9 = 56471552 (0x35DB000);              
            // 0x019E8EB0: LDR x8, [x21]              | X8 = mem[57905152];                     
            val_3 = mem[57905152];
            // 0x019E8EB4: LDR x9, [x9, #0xd0]        | X9 = 1152921504609296384;               
            // 0x019E8EB8: LDR x1, [x9]               | X1 = typeof(System.Collections.ICollection);
            // 0x019E8EBC: LDRH w9, [x8, #0x102]      | W9 = mem[57905152] + 258;               
            // 0x019E8EC0: CBZ x9, #0x19e8eec         | if (mem[57905152] + 258 == 0) goto label_7;
            if((mem[57905152] + 258) == 0)
            {
                goto label_7;
            }
            // 0x019E8EC4: LDR x10, [x8, #0x98]       | X10 = mem[57905152] + 152;              
            var val_3 = mem[57905152] + 152;
            // 0x019E8EC8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_4 = 0;
            // 0x019E8ECC: ADD x10, x10, #8           | X10 = (mem[57905152] + 152 + 8);        
            val_3 = val_3 + 8;
            label_9:
            // 0x019E8ED0: LDUR x12, [x10, #-8]       | X12 = (mem[57905152] + 152 + 8) + -8;   
            // 0x019E8ED4: CMP x12, x1                | STATE = COMPARE((mem[57905152] + 152 + 8) + -8, typeof(System.Collections.ICollection))
            // 0x019E8ED8: B.EQ #0x19e8f08            | if ((mem[57905152] + 152 + 8) + -8 == null) goto label_8;
            if(((mem[57905152] + 152 + 8) + -8) == null)
            {
                goto label_8;
            }
            // 0x019E8EDC: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_4 = val_4 + 1;
            // 0x019E8EE0: ADD x10, x10, #0x10        | X10 = ((mem[57905152] + 152 + 8) + 16); 
            val_3 = val_3 + 16;
            // 0x019E8EE4: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[57905152] + 258)
            // 0x019E8EE8: B.LO #0x19e8ed0            | if (0 < mem[57905152] + 258) goto label_9;
            if(val_4 < (mem[57905152] + 258))
            {
                goto label_9;
            }
            label_7:
            // 0x019E8EEC: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x019E8EF0: MOV x0, x21                | X0 = 57905152 (0x3739000);//ML01        
            val_4 = 57905152;
            label_5:
            // 0x019E8EF4: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x3739000, ????);  
            // 0x019E8EF8: B #0x19e8f18               |  goto label_10;                         
            goto label_10;
            label_3:
            // 0x019E8EFC: LDR w9, [x10]              | W9 = (mem[57905152] + 152 + 8);         
            // 0x019E8F00: ADD w9, w9, #5             | W9 = ((mem[57905152] + 152 + 8) + 5);   
            val_5 = val_1 + 5;
            // 0x019E8F04: B #0x19e8f10               |  goto label_11;                         
            goto label_11;
            label_8:
            // 0x019E8F08: LDR w9, [x10]              | W9 = (mem[57905152] + 152 + 8);         
            // 0x019E8F0C: ADD w9, w9, #3             | W9 = ((mem[57905152] + 152 + 8) + 3);   
            val_5 = val_3 + 3;
            label_11:
            // 0x019E8F10: ADD x8, x8, w9, uxtw #4    | X8 = (mem[57905152] + ((mem[57905152] + 152 + 8) + 3));
            val_3 = val_3 + val_5;
            // 0x019E8F14: ADD x0, x8, #0x110         | X0 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 3)) + 272);
            val_4 = val_3 + 272;
            label_10:
            // 0x019E8F18: LDR x4, [x0]               | X4 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 3)) + 272);
            // 0x019E8F1C: LDR x3, [x0, #8]           | X3 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 3)) + 272) + 8;
            // 0x019E8F20: MOV x0, x21                | X0 = 57905152 (0x3739000);//ML01        
            // 0x019E8F24: MOV x1, x20                | X1 = array;//m1                         
            // 0x019E8F28: MOV w2, w19                | W2 = arrayIndex;//m1                    
            // 0x019E8F2C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x019E8F30: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x019E8F34: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x019E8F38: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x019E8F3C: BR x4                      | goto ((mem[57905152] + ((mem[57905152] + 152 + 8) + 3)) + 272);
            goto ((mem[57905152] + ((mem[57905152] + 152 + 8) + 3)) + 272);
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E8F40 VirtAddr: 0x019E8F40 -RVA: 0x019E8F40 
        // -CollectionWrapper<object>.get_Count
        //
        //
        // Offset in libil2cpp.so: 0x019E8F40 (27168576), len: 288  VirtAddr: 0x019E8F40 RVA: 0x019E8F40 token: 100686591 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual int get_Count()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            var val_5;
            // 0x019E8F40: STP x22, x21, [sp, #-0x30]! | stack[1152921513969208816] = ???;  stack[1152921513969208824] = ???;  //  dest_result_addr=1152921513969208816 |  dest_result_addr=1152921513969208824
            // 0x019E8F44: STP x20, x19, [sp, #0x10]  | stack[1152921513969208832] = ???;  stack[1152921513969208840] = ???;  //  dest_result_addr=1152921513969208832 |  dest_result_addr=1152921513969208840
            // 0x019E8F48: STP x29, x30, [sp, #0x20]  | stack[1152921513969208848] = ???;  stack[1152921513969208856] = ???;  //  dest_result_addr=1152921513969208848 |  dest_result_addr=1152921513969208856
            // 0x019E8F4C: ADD x29, sp, #0x20         | X29 = (1152921513969208816 + 32) = 1152921513969208848 (0x100000022E0A4E10);
            // 0x019E8F50: ADRP x19, #0x3739000       | X19 = 57905152 (0x3739000);             
            // 0x019E8F54: LDRB w8, [x19, #0x668]     | W8 = (bool)static_value_03739668;       
            // 0x019E8F58: MOV x20, x1                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x019E8F5C: MOV x21, x0                | X21 = 1152921513969220864 (0x100000022E0A7D00);//ML01
            // 0x019E8F60: TBNZ w8, #0, #0x19e8f7c    | if (static_value_03739668 == true) goto label_0;
            // 0x019E8F64: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
            // 0x019E8F68: LDR x8, [x8, #0x228]       | X8 = 0x2B91648;                         
            // 0x019E8F6C: LDR w0, [x8]               | W0 = 0x1C56;                            
            // 0x019E8F70: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C56, ????);     
            // 0x019E8F74: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019E8F78: STRB w8, [x19, #0x668]     | static_value_03739668 = true;            //  dest_result_addr=57906792
            label_0:
            // 0x019E8F7C: LDR x19, [x21, #0x18]      | 
            // 0x019E8F80: CBZ x19, #0x19e8fdc        | if ( == 0) goto label_1;                
            if(==0)
            {
                goto label_1;
            }
            // 0x019E8F84: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E8F88: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8F8C: LDR x20, [x8]              | X20 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8F90: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x019E8F94: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168, ????);
            // 0x019E8F98: LDR x8, [x19]              | X8 = mem[57905152];                     
            val_3 = mem[57905152];
            // 0x019E8F9C: LDRH w9, [x8, #0x102]      | W9 = mem[57905152] + 258;               
            // 0x019E8FA0: CBZ x9, #0x19e8fcc         | if (mem[57905152] + 258 == 0) goto label_2;
            if((mem[57905152] + 258) == 0)
            {
                goto label_2;
            }
            // 0x019E8FA4: LDR x10, [x8, #0x98]       | X10 = mem[57905152] + 152;              
            // 0x019E8FA8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_1 = 0;
            // 0x019E8FAC: ADD x10, x10, #8           | X10 = (mem[57905152] + 152 + 8);        
            val_4 = (mem[57905152] + 152) + 8;
            label_4:
            // 0x019E8FB0: LDUR x12, [x10, #-8]       | X12 = (mem[57905152] + 152 + 8) + -8;   
            // 0x019E8FB4: CMP x12, x20               | STATE = COMPARE((mem[57905152] + 152 + 8) + -8, __RuntimeMethodHiddenParam + 24 + 168)
            // 0x019E8FB8: B.EQ #0x19e9038            | if ((mem[57905152] + 152 + 8) + -8 == __RuntimeMethodHiddenParam + 24 + 168) goto label_8;
            if(((mem[57905152] + 152 + 8) + -8) == (__RuntimeMethodHiddenParam + 24 + 168))
            {
                goto label_8;
            }
            // 0x019E8FBC: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_1 = val_1 + 1;
            // 0x019E8FC0: ADD x10, x10, #0x10        | X10 = ((mem[57905152] + 152 + 8) + 16); 
            val_4 = val_4 + 16;
            // 0x019E8FC4: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[57905152] + 258)
            // 0x019E8FC8: B.LO #0x19e8fb0            | if (0 < mem[57905152] + 258) goto label_4;
            if(val_1 < (mem[57905152] + 258))
            {
                goto label_4;
            }
            label_2:
            // 0x019E8FCC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x019E8FD0: MOV x0, x19                | X0 = 57905152 (0x3739000);//ML01        
            val_5 = 57905152;
            // 0x019E8FD4: MOV x1, x20                | X1 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x019E8FD8: B #0x19e9030               |  goto label_5;                          
            goto label_5;
            label_1:
            // 0x019E8FDC: LDR x19, [x21, #0x10]      | 
            // 0x019E8FE0: CBNZ x19, #0x19e8fe8       | if ( != 0) goto label_6;                
            if(!=0)
            {
                goto label_6;
            }
            // 0x019E8FE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C56, ????);     
            label_6:
            // 0x019E8FE8: ADRP x9, #0x35db000        | X9 = 56471552 (0x35DB000);              
            // 0x019E8FEC: LDR x8, [x19]              | X8 = mem[57905152];                     
            val_3 = mem[57905152];
            // 0x019E8FF0: LDR x9, [x9, #0xd0]        | X9 = 1152921504609296384;               
            // 0x019E8FF4: LDR x1, [x9]               | X1 = typeof(System.Collections.ICollection);
            // 0x019E8FF8: LDRH w9, [x8, #0x102]      | W9 = mem[57905152] + 258;               
            // 0x019E8FFC: CBZ x9, #0x19e9028         | if (mem[57905152] + 258 == 0) goto label_7;
            if((mem[57905152] + 258) == 0)
            {
                goto label_7;
            }
            // 0x019E9000: LDR x10, [x8, #0x98]       | X10 = mem[57905152] + 152;              
            // 0x019E9004: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x019E9008: ADD x10, x10, #8           | X10 = (mem[57905152] + 152 + 8);        
            val_4 = (mem[57905152] + 152) + 8;
            label_9:
            // 0x019E900C: LDUR x12, [x10, #-8]       | X12 = (mem[57905152] + 152 + 8) + -8;   
            // 0x019E9010: CMP x12, x1                | STATE = COMPARE((mem[57905152] + 152 + 8) + -8, typeof(System.Collections.ICollection))
            // 0x019E9014: B.EQ #0x19e9038            | if ((mem[57905152] + 152 + 8) + -8 == null) goto label_8;
            if(((mem[57905152] + 152 + 8) + -8) == null)
            {
                goto label_8;
            }
            // 0x019E9018: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x019E901C: ADD x10, x10, #0x10        | X10 = ((mem[57905152] + 152 + 8) + 16); 
            val_4 = val_4 + 16;
            // 0x019E9020: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[57905152] + 258)
            // 0x019E9024: B.LO #0x19e900c            | if (0 < mem[57905152] + 258) goto label_9;
            if(val_2 < (mem[57905152] + 258))
            {
                goto label_9;
            }
            label_7:
            // 0x019E9028: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x019E902C: MOV x0, x19                | X0 = 57905152 (0x3739000);//ML01        
            val_5 = 57905152;
            label_5:
            // 0x019E9030: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x3739000, ????);  
            // 0x019E9034: B #0x19e9044               |  goto label_10;                         
            goto label_10;
            label_8:
            // 0x019E9038: LDR w9, [x10]              | W9 = (mem[57905152] + 152 + 8);         
            // 0x019E903C: ADD x8, x8, x9, lsl #4     | X8 = (mem[57905152] + ((mem[57905152] + 152 + 8)) << 4);
            val_3 = val_3 + (((mem[57905152] + 152 + 8)) << 4);
            // 0x019E9040: ADD x0, x8, #0x110         | X0 = ((mem[57905152] + ((mem[57905152] + 152 + 8)) << 4) + 272);
            val_5 = val_3 + 272;
            label_10:
            // 0x019E9044: LDR x2, [x0]               | X2 = ((mem[57905152] + ((mem[57905152] + 152 + 8)) << 4) + 272);
            // 0x019E9048: LDR x1, [x0, #8]           | X1 = ((mem[57905152] + ((mem[57905152] + 152 + 8)) << 4) + 272) + 8;
            // 0x019E904C: MOV x0, x19                | X0 = 57905152 (0x3739000);//ML01        
            // 0x019E9050: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019E9054: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019E9058: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019E905C: BR x2                      | goto ((mem[57905152] + ((mem[57905152] + 152 + 8)) << 4) + 272);
            goto ((mem[57905152] + ((mem[57905152] + 152 + 8)) << 4) + 272);
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E9060 VirtAddr: 0x019E9060 -RVA: 0x019E9060 
        // -CollectionWrapper<object>.get_IsReadOnly
        //
        //
        // Offset in libil2cpp.so: 0x019E9060 (27168864), len: 292  VirtAddr: 0x019E9060 RVA: 0x019E9060 token: 100686592 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual bool get_IsReadOnly()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            var val_5;
            // 0x019E9060: STP x22, x21, [sp, #-0x30]! | stack[1152921513969320816] = ???;  stack[1152921513969320824] = ???;  //  dest_result_addr=1152921513969320816 |  dest_result_addr=1152921513969320824
            // 0x019E9064: STP x20, x19, [sp, #0x10]  | stack[1152921513969320832] = ???;  stack[1152921513969320840] = ???;  //  dest_result_addr=1152921513969320832 |  dest_result_addr=1152921513969320840
            // 0x019E9068: STP x29, x30, [sp, #0x20]  | stack[1152921513969320848] = ???;  stack[1152921513969320856] = ???;  //  dest_result_addr=1152921513969320848 |  dest_result_addr=1152921513969320856
            // 0x019E906C: ADD x29, sp, #0x20         | X29 = (1152921513969320816 + 32) = 1152921513969320848 (0x100000022E0C0390);
            // 0x019E9070: ADRP x19, #0x3739000       | X19 = 57905152 (0x3739000);             
            // 0x019E9074: LDRB w8, [x19, #0x669]     | W8 = (bool)static_value_03739669;       
            // 0x019E9078: MOV x20, x1                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x019E907C: MOV x21, x0                | X21 = 1152921513969332864 (0x100000022E0C3280);//ML01
            // 0x019E9080: TBNZ w8, #0, #0x19e909c    | if (static_value_03739669 == true) goto label_0;
            // 0x019E9084: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
            // 0x019E9088: LDR x8, [x8, #0x4f8]       | X8 = 0x2B9164C;                         
            // 0x019E908C: LDR w0, [x8]               | W0 = 0x1C57;                            
            // 0x019E9090: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C57, ????);     
            // 0x019E9094: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019E9098: STRB w8, [x19, #0x669]     | static_value_03739669 = true;            //  dest_result_addr=57906793
            label_0:
            // 0x019E909C: LDR x19, [x21, #0x18]      | 
            // 0x019E90A0: CBZ x19, #0x19e90fc        | if ( == 0) goto label_1;                
            if(==0)
            {
                goto label_1;
            }
            // 0x019E90A4: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E90A8: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E90AC: LDR x20, [x8]              | X20 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E90B0: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x019E90B4: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168, ????);
            // 0x019E90B8: LDR x8, [x19]              | X8 = mem[57905152];                     
            val_3 = mem[57905152];
            // 0x019E90BC: LDRH w9, [x8, #0x102]      | W9 = mem[57905152] + 258;               
            // 0x019E90C0: CBZ x9, #0x19e90ec         | if (mem[57905152] + 258 == 0) goto label_2;
            if((mem[57905152] + 258) == 0)
            {
                goto label_2;
            }
            // 0x019E90C4: LDR x10, [x8, #0x98]       | X10 = mem[57905152] + 152;              
            // 0x019E90C8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_1 = 0;
            // 0x019E90CC: ADD x10, x10, #8           | X10 = (mem[57905152] + 152 + 8);        
            val_4 = (mem[57905152] + 152) + 8;
            label_4:
            // 0x019E90D0: LDUR x12, [x10, #-8]       | X12 = (mem[57905152] + 152 + 8) + -8;   
            // 0x019E90D4: CMP x12, x20               | STATE = COMPARE((mem[57905152] + 152 + 8) + -8, __RuntimeMethodHiddenParam + 24 + 168)
            // 0x019E90D8: B.EQ #0x19e9158            | if ((mem[57905152] + 152 + 8) + -8 == __RuntimeMethodHiddenParam + 24 + 168) goto label_8;
            if(((mem[57905152] + 152 + 8) + -8) == (__RuntimeMethodHiddenParam + 24 + 168))
            {
                goto label_8;
            }
            // 0x019E90DC: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_1 = val_1 + 1;
            // 0x019E90E0: ADD x10, x10, #0x10        | X10 = ((mem[57905152] + 152 + 8) + 16); 
            val_4 = val_4 + 16;
            // 0x019E90E4: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[57905152] + 258)
            // 0x019E90E8: B.LO #0x19e90d0            | if (0 < mem[57905152] + 258) goto label_4;
            if(val_1 < (mem[57905152] + 258))
            {
                goto label_4;
            }
            label_2:
            // 0x019E90EC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x019E90F0: MOV x0, x19                | X0 = 57905152 (0x3739000);//ML01        
            val_5 = 57905152;
            // 0x019E90F4: MOV x1, x20                | X1 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x019E90F8: B #0x19e9150               |  goto label_5;                          
            goto label_5;
            label_1:
            // 0x019E90FC: LDR x19, [x21, #0x10]      | 
            // 0x019E9100: CBNZ x19, #0x19e9108       | if ( != 0) goto label_6;                
            if(!=0)
            {
                goto label_6;
            }
            // 0x019E9104: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C57, ????);     
            label_6:
            // 0x019E9108: ADRP x9, #0x3605000        | X9 = 56643584 (0x3605000);              
            // 0x019E910C: LDR x8, [x19]              | X8 = mem[57905152];                     
            val_3 = mem[57905152];
            // 0x019E9110: LDR x9, [x9, #0x308]       | X9 = 1152921504609349632;               
            // 0x019E9114: LDR x1, [x9]               | X1 = typeof(System.Collections.IList);  
            // 0x019E9118: LDRH w9, [x8, #0x102]      | W9 = mem[57905152] + 258;               
            // 0x019E911C: CBZ x9, #0x19e9148         | if (mem[57905152] + 258 == 0) goto label_7;
            if((mem[57905152] + 258) == 0)
            {
                goto label_7;
            }
            // 0x019E9120: LDR x10, [x8, #0x98]       | X10 = mem[57905152] + 152;              
            // 0x019E9124: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x019E9128: ADD x10, x10, #8           | X10 = (mem[57905152] + 152 + 8);        
            val_4 = (mem[57905152] + 152) + 8;
            label_9:
            // 0x019E912C: LDUR x12, [x10, #-8]       | X12 = (mem[57905152] + 152 + 8) + -8;   
            // 0x019E9130: CMP x12, x1                | STATE = COMPARE((mem[57905152] + 152 + 8) + -8, typeof(System.Collections.IList))
            // 0x019E9134: B.EQ #0x19e9158            | if ((mem[57905152] + 152 + 8) + -8 == null) goto label_8;
            if(((mem[57905152] + 152 + 8) + -8) == null)
            {
                goto label_8;
            }
            // 0x019E9138: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x019E913C: ADD x10, x10, #0x10        | X10 = ((mem[57905152] + 152 + 8) + 16); 
            val_4 = val_4 + 16;
            // 0x019E9140: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[57905152] + 258)
            // 0x019E9144: B.LO #0x19e912c            | if (0 < mem[57905152] + 258) goto label_9;
            if(val_2 < (mem[57905152] + 258))
            {
                goto label_9;
            }
            label_7:
            // 0x019E9148: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x019E914C: MOV x0, x19                | X0 = 57905152 (0x3739000);//ML01        
            val_5 = 57905152;
            label_5:
            // 0x019E9150: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x3739000, ????);  
            // 0x019E9154: B #0x19e9168               |  goto label_10;                         
            goto label_10;
            label_8:
            // 0x019E9158: LDR w9, [x10]              | W9 = (mem[57905152] + 152 + 8);         
            var val_3 = val_4;
            // 0x019E915C: ADD w9, w9, #1             | W9 = ((mem[57905152] + 152 + 8) + 1);   
            val_3 = val_3 + 1;
            // 0x019E9160: ADD x8, x8, w9, uxtw #4    | X8 = (mem[57905152] + ((mem[57905152] + 152 + 8) + 1));
            val_3 = val_3 + val_3;
            // 0x019E9164: ADD x0, x8, #0x110         | X0 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 1)) + 272);
            val_5 = val_3 + 272;
            label_10:
            // 0x019E9168: LDR x2, [x0]               | X2 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 1)) + 272);
            // 0x019E916C: LDR x1, [x0, #8]           | X1 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 1)) + 272) + 8;
            // 0x019E9170: MOV x0, x19                | X0 = 57905152 (0x3739000);//ML01        
            // 0x019E9174: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019E9178: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019E917C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019E9180: BR x2                      | goto ((mem[57905152] + ((mem[57905152] + 152 + 8) + 1)) + 272);
            goto ((mem[57905152] + ((mem[57905152] + 152 + 8) + 1)) + 272);
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E9184 VirtAddr: 0x019E9184 -RVA: 0x019E9184 
        // -CollectionWrapper<object>.Remove
        //
        //
        // Offset in libil2cpp.so: 0x019E9184 (27169156), len: 480  VirtAddr: 0x019E9184 RVA: 0x019E9184 token: 100686593 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual bool Remove(T item)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            var val_20;
            //  | 
            var val_21;
            // 0x019E9184: STP x22, x21, [sp, #-0x30]! | stack[1152921513969436912] = ???;  stack[1152921513969436920] = ???;  //  dest_result_addr=1152921513969436912 |  dest_result_addr=1152921513969436920
            // 0x019E9188: STP x20, x19, [sp, #0x10]  | stack[1152921513969436928] = ???;  stack[1152921513969436936] = ???;  //  dest_result_addr=1152921513969436928 |  dest_result_addr=1152921513969436936
            // 0x019E918C: STP x29, x30, [sp, #0x20]  | stack[1152921513969436944] = ???;  stack[1152921513969436952] = ???;  //  dest_result_addr=1152921513969436944 |  dest_result_addr=1152921513969436952
            // 0x019E9190: ADD x29, sp, #0x20         | X29 = (1152921513969436912 + 32) = 1152921513969436944 (0x100000022E0DC910);
            // 0x019E9194: ADRP x21, #0x3739000       | X21 = 57905152 (0x3739000);             
            // 0x019E9198: LDRB w8, [x21, #0x66a]     | W8 = (bool)static_value_0373966A;       
            // 0x019E919C: MOV x22, x2                | X22 = __RuntimeMethodHiddenParam;//m1   
            // 0x019E91A0: MOV x19, x1                | X19 = item;//m1                         
            val_10 = item;
            // 0x019E91A4: MOV x20, x0                | X20 = 1152921513969448960 (0x100000022E0DF800);//ML01
            val_11 = this;
            // 0x019E91A8: TBNZ w8, #0, #0x19e91c4    | if (static_value_0373966A == true) goto label_0;
            // 0x019E91AC: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x019E91B0: LDR x8, [x8, #0xed8]       | X8 = 0x2B91654;                         
            // 0x019E91B4: LDR w0, [x8]               | W0 = 0x1C59;                            
            // 0x019E91B8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C59, ????);     
            // 0x019E91BC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019E91C0: STRB w8, [x21, #0x66a]     | static_value_0373966A = true;            //  dest_result_addr=57906794
            label_0:
            // 0x019E91C4: LDR x21, [x20, #0x18]      | 
            // 0x019E91C8: CBZ x21, #0x19e9228        | if ( == 0) goto label_1;                
            if(==0)
            {
                goto label_1;
            }
            // 0x019E91CC: LDR x8, [x22, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E91D0: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E91D4: LDR x20, [x8]              | X20 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E91D8: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x019E91DC: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168, ????);
            // 0x019E91E0: LDR x8, [x21]              | X8 = mem[57905152];                     
            val_12 = mem[57905152];
            // 0x019E91E4: LDRH w9, [x8, #0x102]      | W9 = mem[57905152] + 258;               
            // 0x019E91E8: CBZ x9, #0x19e9214         | if (mem[57905152] + 258 == 0) goto label_2;
            if((mem[57905152] + 258) == 0)
            {
                goto label_2;
            }
            // 0x019E91EC: LDR x10, [x8, #0x98]       | X10 = mem[57905152] + 152;              
            // 0x019E91F0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_7 = 0;
            // 0x019E91F4: ADD x10, x10, #8           | X10 = (mem[57905152] + 152 + 8);        
            val_13 = (mem[57905152] + 152) + 8;
            label_4:
            // 0x019E91F8: LDUR x12, [x10, #-8]       | X12 = (mem[57905152] + 152 + 8) + -8;   
            // 0x019E91FC: CMP x12, x20               | STATE = COMPARE((mem[57905152] + 152 + 8) + -8, __RuntimeMethodHiddenParam + 24 + 168)
            // 0x019E9200: B.EQ #0x19e9284            | if ((mem[57905152] + 152 + 8) + -8 == __RuntimeMethodHiddenParam + 24 + 168) goto label_3;
            if(((mem[57905152] + 152 + 8) + -8) == (__RuntimeMethodHiddenParam + 24 + 168))
            {
                goto label_3;
            }
            // 0x019E9204: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_7 = val_7 + 1;
            // 0x019E9208: ADD x10, x10, #0x10        | X10 = ((mem[57905152] + 152 + 8) + 16); 
            val_13 = val_13 + 16;
            // 0x019E920C: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[57905152] + 258)
            // 0x019E9210: B.LO #0x19e91f8            | if (0 < mem[57905152] + 258) goto label_4;
            if(val_7 < (mem[57905152] + 258))
            {
                goto label_4;
            }
            label_2:
            // 0x019E9214: ORR w2, wzr, #6            | W2 = 6(0x6);                            
            // 0x019E9218: MOV x0, x21                | X0 = 57905152 (0x3739000);//ML01        
            val_14 = 57905152;
            // 0x019E921C: MOV x1, x20                | X1 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x019E9220: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x3739000, ????);  
            // 0x019E9224: B #0x19e9294               |  goto label_5;                          
            goto label_5;
            label_1:
            // 0x019E9228: LDR x21, [x20, #0x10]      | 
            // 0x019E922C: CBNZ x21, #0x19e9234       | if ( != 0) goto label_6;                
            if(!=0)
            {
                goto label_6;
            }
            // 0x019E9230: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C59, ????);     
            label_6:
            // 0x019E9234: ADRP x22, #0x3605000       | X22 = 56643584 (0x3605000);             
            // 0x019E9238: LDR x8, [x21]              | X8 = mem[57905152];                     
            val_12 = mem[57905152];
            // 0x019E923C: LDR x22, [x22, #0x308]     | X22 = 1152921504609349632;              
            val_16 = 1152921504609349632;
            // 0x019E9240: LDRH w9, [x8, #0x102]      | W9 = mem[57905152] + 258;               
            // 0x019E9244: LDR x1, [x22]              | X1 = typeof(System.Collections.IList);  
            // 0x019E9248: CBZ x9, #0x19e9274         | if (mem[57905152] + 258 == 0) goto label_7;
            if((mem[57905152] + 258) == 0)
            {
                goto label_7;
            }
            // 0x019E924C: LDR x10, [x8, #0x98]       | X10 = mem[57905152] + 152;              
            // 0x019E9250: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_8 = 0;
            // 0x019E9254: ADD x10, x10, #8           | X10 = (mem[57905152] + 152 + 8);        
            val_13 = (mem[57905152] + 152) + 8;
            label_9:
            // 0x019E9258: LDUR x12, [x10, #-8]       | X12 = (mem[57905152] + 152 + 8) + -8;   
            // 0x019E925C: CMP x12, x1                | STATE = COMPARE((mem[57905152] + 152 + 8) + -8, typeof(System.Collections.IList))
            // 0x019E9260: B.EQ #0x19e92b0            | if ((mem[57905152] + 152 + 8) + -8 == null) goto label_8;
            if(((mem[57905152] + 152 + 8) + -8) == null)
            {
                goto label_8;
            }
            // 0x019E9264: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x019E9268: ADD x10, x10, #0x10        | X10 = ((mem[57905152] + 152 + 8) + 16); 
            val_13 = val_13 + 16;
            // 0x019E926C: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[57905152] + 258)
            // 0x019E9270: B.LO #0x19e9258            | if (0 < mem[57905152] + 258) goto label_9;
            if(val_8 < (mem[57905152] + 258))
            {
                goto label_9;
            }
            label_7:
            // 0x019E9274: ORR w2, wzr, #6            | W2 = 6(0x6);                            
            val_17 = 6;
            // 0x019E9278: MOV x0, x21                | X0 = 57905152 (0x3739000);//ML01        
            val_18 = 57905152;
            // 0x019E927C: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x3739000, ????);  
            // 0x019E9280: B #0x19e92c0               |  goto label_10;                         
            goto label_10;
            label_3:
            // 0x019E9284: LDR w9, [x10]              | W9 = (mem[57905152] + 152 + 8);         
            var val_9 = val_13;
            // 0x019E9288: ADD w9, w9, #6             | W9 = ((mem[57905152] + 152 + 8) + 6);   
            val_9 = val_9 + 6;
            // 0x019E928C: ADD x8, x8, w9, uxtw #4    | X8 = (mem[57905152] + ((mem[57905152] + 152 + 8) + 6));
            val_12 = val_12 + val_9;
            // 0x019E9290: ADD x0, x8, #0x110         | X0 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 6)) + 272);
            val_14 = val_12 + 272;
            label_5:
            // 0x019E9294: LDP x3, x2, [x0]           | X3 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 6)) + 272); X2 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 6)) + 272) + 8; //  | 
            val_17 = mem[((mem[57905152] + ((mem[57905152] + 152 + 8) + 6)) + 272) + 8];
            val_17 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 6)) + 272) + 8;
            // 0x019E9298: MOV x1, x19                | X1 = item;//m1                          
            // 0x019E929C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019E92A0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            val_11 = ???;
            val_10 = ???;
            // 0x019E92A4: MOV x0, x21                | X0 = 57905152 (0x3739000);//ML01        
            // 0x019E92A8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            val_16 = ???;
            val_15 = ???;
            // 0x019E92AC: BR x3                      | goto ((mem[57905152] + ((mem[57905152] + 152 + 8) + 6)) + 272);
            goto ((mem[57905152] + ((mem[57905152] + 152 + 8) + 6)) + 272);
            label_8:
            // 0x019E92B0: LDR w9, [x10]              | W9 = (mem[57905152] + 152 + 8);         
            var val_10 = val_13;
            // 0x019E92B4: ADD w9, w9, #6             | W9 = ((mem[57905152] + 152 + 8) + 6);   
            val_10 = val_10 + 6;
            // 0x019E92B8: ADD x8, x8, w9, uxtw #4    | X8 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 6)) + ((mem[57905152] + 152 + 8) + 6));
            val_12 = val_12 + val_10;
            // 0x019E92BC: ADD x0, x8, #0x110         | X0 = (((mem[57905152] + ((mem[57905152] + 152 + 8) + 6)) + ((mem[57905152] + 152 + 8) + 6)) + 272);
            val_18 = val_12 + 272;
            label_10:
            // 0x019E92C0: LDP x8, x2, [x0]           | X8 = (((mem[57905152] + ((mem[57905152] + 152 + 8) + 6)) + ((mem[57905152] + 152 + 8) + 6)) + 272); X2 = (((mem[57905152] + ((mem[57905152] + 152 + 8) + 6)) + ((mem[57905152] + 152 + 8) + 6)) + 272) + 8; //  | 
            val_19 = mem[(((mem[57905152] + ((mem[57905152] + 152 + 8) + 6)) + ((mem[57905152] + 152 + 8) + 6)) + 272) + 8];
            val_19 = (((mem[57905152] + ((mem[57905152] + 152 + 8) + 6)) + ((mem[57905152] + 152 + 8) + 6)) + 272) + 8;
            // 0x019E92C4: MOV x0, x21                | X0 = X21;//m1                           
            // 0x019E92C8: MOV x1, x19                | X1 = X19;//m1                           
            // 0x019E92CC: BLR x8                     | X0 = (((mem[57905152] + ((mem[57905152] + 152 + 8) + 6)) + ((mem[57905152] + 152 + 8) + 6)) + 272)();
            // 0x019E92D0: TBZ w0, #0, #0x19e9328     | if (( & 0x1) == 0) goto label_11;       
            if((val_15 & 1) == 0)
            {
                goto label_11;
            }
            // 0x019E92D4: LDR x20, [x20, #0x10]      | X20 = val_11 + 16;                      
            // 0x019E92D8: CBNZ x20, #0x19e92e0       | if (val_11 + 16 != 0) goto label_12;    
            if((val_11 + 16) != 0)
            {
                goto label_12;
            }
            // 0x019E92DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? , ????);           
            label_12:
            // 0x019E92E0: LDR x8, [x20]              | X8 = val_11 + 16;                       
            var val_14 = val_11 + 16;
            // 0x019E92E4: LDR x1, [x22]              | X1 = ;                                  
            // 0x019E92E8: LDRH w9, [x8, #0x102]      | W9 = val_11 + 16 + 258;                 
            // 0x019E92EC: CBZ x9, #0x19e9318         | if (val_11 + 16 + 258 == 0) goto label_13;
            if((val_11 + 16 + 258) == 0)
            {
                goto label_13;
            }
            // 0x019E92F0: LDR x10, [x8, #0x98]       | X10 = val_11 + 16 + 152;                
            var val_11 = val_11 + 16 + 152;
            // 0x019E92F4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_12 = 0;
            // 0x019E92F8: ADD x10, x10, #8           | X10 = (val_11 + 16 + 152 + 8);          
            val_11 = val_11 + 8;
            label_15:
            // 0x019E92FC: LDUR x12, [x10, #-8]       | X12 = (val_11 + 16 + 152 + 8) + -8;     
            // 0x019E9300: CMP x12, x1                | STATE = COMPARE((val_11 + 16 + 152 + 8) + -8, )
            // 0x019E9304: B.EQ #0x19e9330            | if ((val_11 + 16 + 152 + 8) + -8 == val_16) goto label_14;
            if(((val_11 + 16 + 152 + 8) + -8) == val_16)
            {
                goto label_14;
            }
            // 0x019E9308: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_12 = val_12 + 1;
            // 0x019E930C: ADD x10, x10, #0x10        | X10 = ((val_11 + 16 + 152 + 8) + 16);   
            val_11 = val_11 + 16;
            // 0x019E9310: CMP x11, x9                | STATE = COMPARE((0 + 1), val_11 + 16 + 258)
            // 0x019E9314: B.LO #0x19e92fc            | if (0 < val_11 + 16 + 258) goto label_15;
            if(val_12 < (val_11 + 16 + 258))
            {
                goto label_15;
            }
            label_13:
            // 0x019E9318: MOVZ w2, #0x9              | W2 = 9 (0x9);//ML01                     
            val_19 = 9;
            // 0x019E931C: MOV x0, x20                | X0 = val_11 + 16;//m1                   
            val_20 = val_11 + 16;
            // 0x019E9320: BL #0x2776c24              | X0 = sub_2776C24( ?? val_11 + 16, ????);
            // 0x019E9324: B #0x19e9340               |  goto label_16;                         
            goto label_16;
            label_11:
            // 0x019E9328: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_21 = 0;
            // 0x019E932C: B #0x19e9354               |  goto label_17;                         
            goto label_17;
            label_14:
            // 0x019E9330: LDR w9, [x10]              | W9 = (val_11 + 16 + 152 + 8);           
            var val_13 = val_11;
            // 0x019E9334: ADD w9, w9, #9             | W9 = ((val_11 + 16 + 152 + 8) + 9);     
            val_13 = val_13 + 9;
            // 0x019E9338: ADD x8, x8, w9, uxtw #4    | X8 = (val_11 + 16 + ((val_11 + 16 + 152 + 8) + 9));
            val_14 = val_14 + val_13;
            // 0x019E933C: ADD x0, x8, #0x110         | X0 = ((val_11 + 16 + ((val_11 + 16 + 152 + 8) + 9)) + 272);
            val_20 = val_14 + 272;
            label_16:
            // 0x019E9340: LDP x8, x2, [x0]           | X8 = ((val_11 + 16 + ((val_11 + 16 + 152 + 8) + 9)) + 272); X2 = ((val_11 + 16 + ((val_11 + 16 + 152 + 8) + 9)) + 272) + 8; //  | 
            // 0x019E9344: MOV x0, x20                | X0 = val_11 + 16;//m1                   
            // 0x019E9348: MOV x1, x19                | X1 = X19;//m1                           
            // 0x019E934C: BLR x8                     | X0 = ((val_11 + 16 + ((val_11 + 16 + 152 + 8) + 9)) + 272)();
            // 0x019E9350: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_21 = 1;
            label_17:
            // 0x019E9354: LDP x29, x30, [sp, #0x20]  | X29 = val_1; X30 = val_2;                //  find_add[1152921513969424960] |  find_add[1152921513969424960]
            // 0x019E9358: LDP x20, x19, [sp, #0x10]  | X20 = val_3; X19 = val_4;                //  find_add[1152921513969424960] |  find_add[1152921513969424960]
            // 0x019E935C: LDP x22, x21, [sp], #0x30  | X22 = val_5; X21 = val_6;                //  find_add[1152921513969424960] |  find_add[1152921513969424960]
            // 0x019E9360: RET                        |  return (System.Boolean)true;           
            return (bool)val_21;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E9364 VirtAddr: 0x019E9364 -RVA: 0x019E9364 
        // -CollectionWrapper<object>.GetEnumerator
        //
        //
        // Offset in libil2cpp.so: 0x019E9364 (27169636), len: 268  VirtAddr: 0x019E9364 RVA: 0x019E9364 token: 100686594 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual System.Collections.Generic.IEnumerator<T> GetEnumerator()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            // 0x019E9364: STP x20, x19, [sp, #-0x20]! | stack[1152921513969553024] = ???;  stack[1152921513969553032] = ???;  //  dest_result_addr=1152921513969553024 |  dest_result_addr=1152921513969553032
            // 0x019E9368: STP x29, x30, [sp, #0x10]  | stack[1152921513969553040] = ???;  stack[1152921513969553048] = ???;  //  dest_result_addr=1152921513969553040 |  dest_result_addr=1152921513969553048
            // 0x019E936C: ADD x29, sp, #0x10         | X29 = (1152921513969553024 + 16) = 1152921513969553040 (0x100000022E0F8E90);
            // 0x019E9370: LDR x19, [x0, #0x18]       | 
            // 0x019E9374: MOV x20, x1                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x019E9378: CBZ x19, #0x19e93c8        | if (X19 == 0) goto label_0;             
            if(X19 == 0)
            {
                goto label_0;
            }
            // 0x019E937C: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E9380: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E9384: LDR x20, [x8, #0x10]       | X20 = __RuntimeMethodHiddenParam + 24 + 168 + 16;
            val_3 = mem[__RuntimeMethodHiddenParam + 24 + 168 + 16];
            val_3 = __RuntimeMethodHiddenParam + 24 + 168 + 16;
            // 0x019E9388: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 16;//m1
            // 0x019E938C: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 16, ????);
            // 0x019E9390: LDR x8, [x19]              | X8 = X19;                               
            val_4 = mem[X19];
            val_4 = X19;
            // 0x019E9394: LDRH w9, [x8, #0x102]      | W9 = X19 + 258;                         
            // 0x019E9398: CBZ x9, #0x19e9438         | if (X19 + 258 == 0) goto label_6;       
            if((X19 + 258) == 0)
            {
                goto label_6;
            }
            // 0x019E939C: LDR x10, [x8, #0x98]       | X10 = X19 + 152;                        
            // 0x019E93A0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_1 = 0;
            // 0x019E93A4: ADD x10, x10, #8           | X10 = (X19 + 152 + 8);                  
            val_5 = (X19 + 152) + 8;
            label_3:
            // 0x019E93A8: LDUR x12, [x10, #-8]       | X12 = (X19 + 152 + 8) + -8;             
            // 0x019E93AC: CMP x12, x20               | STATE = COMPARE((X19 + 152 + 8) + -8, __RuntimeMethodHiddenParam + 24 + 168 + 16)
            // 0x019E93B0: B.EQ #0x19e944c            | if ((X19 + 152 + 8) + -8 == val_3) goto label_7;
            if(((X19 + 152 + 8) + -8) == val_3)
            {
                goto label_7;
            }
            // 0x019E93B4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_1 = val_1 + 1;
            // 0x019E93B8: ADD x10, x10, #0x10        | X10 = ((X19 + 152 + 8) + 16);           
            val_5 = val_5 + 16;
            // 0x019E93BC: CMP x11, x9                | STATE = COMPARE((0 + 1), X19 + 258)     
            // 0x019E93C0: B.LO #0x19e93a8            | if (0 < X19 + 258) goto label_3;        
            if(val_1 < (X19 + 258))
            {
                goto label_3;
            }
            // 0x019E93C4: B #0x19e9438               |  goto label_6;                          
            goto label_6;
            label_0:
            // 0x019E93C8: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E93CC: LDR x1, [x0, #0x10]        | 
            // 0x019E93D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x019E93D4: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E93D8: LDR x2, [x8, #0x18]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 24;
            // 0x019E93DC: LDR x8, [x2]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 24;
            // 0x019E93E0: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 24();
            // 0x019E93E4: MOV x19, x0                | X19 = 0 (0x0);//ML01                    
            val_2 = 0;
            // 0x019E93E8: CBNZ x19, #0x19e93f0       | if (0x0 != 0) goto label_5;             
            if(val_2 != 0)
            {
                goto label_5;
            }
            // 0x019E93EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_5:
            // 0x019E93F0: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E93F4: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E93F8: LDR x20, [x8, #0x10]       | X20 = __RuntimeMethodHiddenParam + 24 + 168 + 16;
            val_3 = mem[__RuntimeMethodHiddenParam + 24 + 168 + 16];
            val_3 = __RuntimeMethodHiddenParam + 24 + 168 + 16;
            // 0x019E93FC: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 16;//m1
            // 0x019E9400: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 16, ????);
            // 0x019E9404: LDR x8, [x19]              | X8 = 0x10102464C457F;                   
            val_4 = 1179403647;
            // 0x019E9408: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x019E940C: CBZ x9, #0x19e9438         | if (mem[282584257676929] == 0) goto label_6;
            if(mem[282584257676929] == 0)
            {
                goto label_6;
            }
            // 0x019E9410: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            // 0x019E9414: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x019E9418: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_5 = mem[282584257676823] + 8;
            label_8:
            // 0x019E941C: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x019E9420: CMP x12, x20               | STATE = COMPARE((mem[282584257676823] + 8) + -8, __RuntimeMethodHiddenParam + 24 + 168 + 16)
            // 0x019E9424: B.EQ #0x19e944c            | if ((mem[282584257676823] + 8) + -8 == val_3) goto label_7;
            if(((mem[282584257676823] + 8) + -8) == val_3)
            {
                goto label_7;
            }
            // 0x019E9428: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x019E942C: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_5 = val_5 + 16;
            // 0x019E9430: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x019E9434: B.LO #0x19e941c            | if (0 < mem[282584257676929]) goto label_8;
            if(val_2 < mem[282584257676929])
            {
                goto label_8;
            }
            label_6:
            // 0x019E9438: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x019E943C: MOV x0, x19                | X0 = 0 (0x0);//ML01                     
            val_6 = val_2;
            // 0x019E9440: MOV x1, x20                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 16;//m1
            // 0x019E9444: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x019E9448: B #0x19e9458               |  goto label_9;                          
            goto label_9;
            label_7:
            // 0x019E944C: LDR w9, [x10]              | W9 = (X19 + 152 + 8);                   
            // 0x019E9450: ADD x8, x8, x9, lsl #4     | X8 = (X19 + ((X19 + 152 + 8)) << 4);    
            val_4 = val_4 + (((X19 + 152 + 8)) << 4);
            // 0x019E9454: ADD x0, x8, #0x110         | X0 = ((X19 + ((X19 + 152 + 8)) << 4) + 272);
            val_6 = val_4 + 272;
            label_9:
            // 0x019E9458: LDR x2, [x0]               | X2 = ((X19 + ((X19 + 152 + 8)) << 4) + 272);
            // 0x019E945C: LDR x1, [x0, #8]           | X1 = ((X19 + ((X19 + 152 + 8)) << 4) + 272) + 8;
            // 0x019E9460: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x019E9464: MOV x0, x19                | X0 = X19;//m1                           
            // 0x019E9468: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x019E946C: BR x2                      | goto ((X19 + ((X19 + 152 + 8)) << 4) + 272);
            goto ((X19 + ((X19 + 152 + 8)) << 4) + 272);
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E9470 VirtAddr: 0x019E9470 -RVA: 0x019E9470 
        // -CollectionWrapper<object>.System.Collections.IEnumerable.GetEnumerator
        //
        //
        // Offset in libil2cpp.so: 0x019E9470 (27169904), len: 288  VirtAddr: 0x019E9470 RVA: 0x019E9470 token: 100686595 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            var val_5;
            // 0x019E9470: STP x22, x21, [sp, #-0x30]! | stack[1152921513969665008] = ???;  stack[1152921513969665016] = ???;  //  dest_result_addr=1152921513969665008 |  dest_result_addr=1152921513969665016
            // 0x019E9474: STP x20, x19, [sp, #0x10]  | stack[1152921513969665024] = ???;  stack[1152921513969665032] = ???;  //  dest_result_addr=1152921513969665024 |  dest_result_addr=1152921513969665032
            // 0x019E9478: STP x29, x30, [sp, #0x20]  | stack[1152921513969665040] = ???;  stack[1152921513969665048] = ???;  //  dest_result_addr=1152921513969665040 |  dest_result_addr=1152921513969665048
            // 0x019E947C: ADD x29, sp, #0x20         | X29 = (1152921513969665008 + 32) = 1152921513969665040 (0x100000022E114410);
            // 0x019E9480: ADRP x19, #0x3739000       | X19 = 57905152 (0x3739000);             
            // 0x019E9484: LDRB w8, [x19, #0x66b]     | W8 = (bool)static_value_0373966B;       
            // 0x019E9488: MOV x20, x1                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x019E948C: MOV x21, x0                | X21 = 1152921513969677056 (0x100000022E117300);//ML01
            // 0x019E9490: TBNZ w8, #0, #0x19e94ac    | if (static_value_0373966B == true) goto label_0;
            // 0x019E9494: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
            // 0x019E9498: LDR x8, [x8, #0xcd0]       | X8 = 0x2B9165C;                         
            // 0x019E949C: LDR w0, [x8]               | W0 = 0x1C5B;                            
            // 0x019E94A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C5B, ????);     
            // 0x019E94A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019E94A8: STRB w8, [x19, #0x66b]     | static_value_0373966B = true;            //  dest_result_addr=57906795
            label_0:
            // 0x019E94AC: LDR x19, [x21, #0x18]      | 
            // 0x019E94B0: CBZ x19, #0x19e950c        | if ( == 0) goto label_1;                
            if(==0)
            {
                goto label_1;
            }
            // 0x019E94B4: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E94B8: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E94BC: LDR x20, [x8, #0x10]       | X20 = __RuntimeMethodHiddenParam + 24 + 168 + 16;
            // 0x019E94C0: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 16;//m1
            // 0x019E94C4: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 16, ????);
            // 0x019E94C8: LDR x8, [x19]              | X8 = mem[57905152];                     
            val_3 = mem[57905152];
            // 0x019E94CC: LDRH w9, [x8, #0x102]      | W9 = mem[57905152] + 258;               
            // 0x019E94D0: CBZ x9, #0x19e94fc         | if (mem[57905152] + 258 == 0) goto label_2;
            if((mem[57905152] + 258) == 0)
            {
                goto label_2;
            }
            // 0x019E94D4: LDR x10, [x8, #0x98]       | X10 = mem[57905152] + 152;              
            // 0x019E94D8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_1 = 0;
            // 0x019E94DC: ADD x10, x10, #8           | X10 = (mem[57905152] + 152 + 8);        
            val_4 = (mem[57905152] + 152) + 8;
            label_4:
            // 0x019E94E0: LDUR x12, [x10, #-8]       | X12 = (mem[57905152] + 152 + 8) + -8;   
            // 0x019E94E4: CMP x12, x20               | STATE = COMPARE((mem[57905152] + 152 + 8) + -8, __RuntimeMethodHiddenParam + 24 + 168 + 16)
            // 0x019E94E8: B.EQ #0x19e9568            | if ((mem[57905152] + 152 + 8) + -8 == __RuntimeMethodHiddenParam + 24 + 168 + 16) goto label_8;
            if(((mem[57905152] + 152 + 8) + -8) == (__RuntimeMethodHiddenParam + 24 + 168 + 16))
            {
                goto label_8;
            }
            // 0x019E94EC: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_1 = val_1 + 1;
            // 0x019E94F0: ADD x10, x10, #0x10        | X10 = ((mem[57905152] + 152 + 8) + 16); 
            val_4 = val_4 + 16;
            // 0x019E94F4: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[57905152] + 258)
            // 0x019E94F8: B.LO #0x19e94e0            | if (0 < mem[57905152] + 258) goto label_4;
            if(val_1 < (mem[57905152] + 258))
            {
                goto label_4;
            }
            label_2:
            // 0x019E94FC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x019E9500: MOV x0, x19                | X0 = 57905152 (0x3739000);//ML01        
            val_5 = 57905152;
            // 0x019E9504: MOV x1, x20                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 16;//m1
            // 0x019E9508: B #0x19e9560               |  goto label_5;                          
            goto label_5;
            label_1:
            // 0x019E950C: LDR x19, [x21, #0x10]      | 
            // 0x019E9510: CBNZ x19, #0x19e9518       | if ( != 0) goto label_6;                
            if(!=0)
            {
                goto label_6;
            }
            // 0x019E9514: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C5B, ????);     
            label_6:
            // 0x019E9518: ADRP x9, #0x3682000        | X9 = 57155584 (0x3682000);              
            // 0x019E951C: LDR x8, [x19]              | X8 = mem[57905152];                     
            val_3 = mem[57905152];
            // 0x019E9520: LDR x9, [x9, #0xfb8]       | X9 = 1152921504608071680;               
            // 0x019E9524: LDR x1, [x9]               | X1 = typeof(System.Collections.IEnumerable);
            // 0x019E9528: LDRH w9, [x8, #0x102]      | W9 = mem[57905152] + 258;               
            // 0x019E952C: CBZ x9, #0x19e9558         | if (mem[57905152] + 258 == 0) goto label_7;
            if((mem[57905152] + 258) == 0)
            {
                goto label_7;
            }
            // 0x019E9530: LDR x10, [x8, #0x98]       | X10 = mem[57905152] + 152;              
            // 0x019E9534: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x019E9538: ADD x10, x10, #8           | X10 = (mem[57905152] + 152 + 8);        
            val_4 = (mem[57905152] + 152) + 8;
            label_9:
            // 0x019E953C: LDUR x12, [x10, #-8]       | X12 = (mem[57905152] + 152 + 8) + -8;   
            // 0x019E9540: CMP x12, x1                | STATE = COMPARE((mem[57905152] + 152 + 8) + -8, typeof(System.Collections.IEnumerable))
            // 0x019E9544: B.EQ #0x19e9568            | if ((mem[57905152] + 152 + 8) + -8 == null) goto label_8;
            if(((mem[57905152] + 152 + 8) + -8) == null)
            {
                goto label_8;
            }
            // 0x019E9548: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x019E954C: ADD x10, x10, #0x10        | X10 = ((mem[57905152] + 152 + 8) + 16); 
            val_4 = val_4 + 16;
            // 0x019E9550: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[57905152] + 258)
            // 0x019E9554: B.LO #0x19e953c            | if (0 < mem[57905152] + 258) goto label_9;
            if(val_2 < (mem[57905152] + 258))
            {
                goto label_9;
            }
            label_7:
            // 0x019E9558: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x019E955C: MOV x0, x19                | X0 = 57905152 (0x3739000);//ML01        
            val_5 = 57905152;
            label_5:
            // 0x019E9560: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x3739000, ????);  
            // 0x019E9564: B #0x19e9574               |  goto label_10;                         
            goto label_10;
            label_8:
            // 0x019E9568: LDR w9, [x10]              | W9 = (mem[57905152] + 152 + 8);         
            // 0x019E956C: ADD x8, x8, x9, lsl #4     | X8 = (mem[57905152] + ((mem[57905152] + 152 + 8)) << 4);
            val_3 = val_3 + (((mem[57905152] + 152 + 8)) << 4);
            // 0x019E9570: ADD x0, x8, #0x110         | X0 = ((mem[57905152] + ((mem[57905152] + 152 + 8)) << 4) + 272);
            val_5 = val_3 + 272;
            label_10:
            // 0x019E9574: LDR x2, [x0]               | X2 = ((mem[57905152] + ((mem[57905152] + 152 + 8)) << 4) + 272);
            // 0x019E9578: LDR x1, [x0, #8]           | X1 = ((mem[57905152] + ((mem[57905152] + 152 + 8)) << 4) + 272) + 8;
            // 0x019E957C: MOV x0, x19                | X0 = 57905152 (0x3739000);//ML01        
            // 0x019E9580: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019E9584: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019E9588: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019E958C: BR x2                      | goto ((mem[57905152] + ((mem[57905152] + 152 + 8)) << 4) + 272);
            goto ((mem[57905152] + ((mem[57905152] + 152 + 8)) << 4) + 272);
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E9590 VirtAddr: 0x019E9590 -RVA: 0x019E9590 
        // -CollectionWrapper<object>.System.Collections.IList.Add
        //
        //
        // Offset in libil2cpp.so: 0x019E9590 (27170192), len: 248  VirtAddr: 0x019E9590 RVA: 0x019E9590 token: 100686596 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private int System.Collections.IList.Add(object value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x019E9590: STP x22, x21, [sp, #-0x30]! | stack[1152921513969781104] = ???;  stack[1152921513969781112] = ???;  //  dest_result_addr=1152921513969781104 |  dest_result_addr=1152921513969781112
            // 0x019E9594: STP x20, x19, [sp, #0x10]  | stack[1152921513969781120] = ???;  stack[1152921513969781128] = ???;  //  dest_result_addr=1152921513969781120 |  dest_result_addr=1152921513969781128
            // 0x019E9598: STP x29, x30, [sp, #0x20]  | stack[1152921513969781136] = ???;  stack[1152921513969781144] = ???;  //  dest_result_addr=1152921513969781136 |  dest_result_addr=1152921513969781144
            // 0x019E959C: ADD x29, sp, #0x20         | X29 = (1152921513969781104 + 32) = 1152921513969781136 (0x100000022E130990);
            // 0x019E95A0: SUB sp, sp, #0x10          | SP = (1152921513969781104 - 16) = 1152921513969781088 (0x100000022E130960);
            // 0x019E95A4: MOV x21, x2                | X21 = __RuntimeMethodHiddenParam;//m1   
            // 0x019E95A8: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E95AC: MOV x19, x0                | X19 = 1152921513969793152 (0x100000022E133880);//ML01
            // 0x019E95B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x019E95B4: MOV x20, x1                | X20 = value;//m1                        
            // 0x019E95B8: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E95BC: LDR x2, [x8, #0x20]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 32;
            // 0x019E95C0: LDR x8, [x2]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 32;
            // 0x019E95C4: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 32();
            // 0x019E95C8: CBNZ x19, #0x19e95d0       | if (this != null) goto label_0;         
            if(this != null)
            {
                goto label_0;
            }
            // 0x019E95CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_0:
            // 0x019E95D0: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E95D4: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E95D8: LDR x21, [x8, #8]          | X21 = __RuntimeMethodHiddenParam + 24 + 168 + 8;
            // 0x019E95DC: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E95E0: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 8, ????);
            // 0x019E95E4: CBZ x20, #0x19e9628        | if (value == null) goto label_1;        
            if(value == null)
            {
                goto label_1;
            }
            // 0x019E95E8: MOV x0, x20                | X0 = value;//m1                         
            // 0x019E95EC: MOV x1, x21                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E95F0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
            // 0x019E95F4: MOV x1, x0                 | X1 = value;//m1                         
            // 0x019E95F8: CBNZ x1, #0x19e962c        | if (value != null) goto label_2;        
            if(value != null)
            {
                goto label_2;
            }
            // 0x019E95FC: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x019E9600: MOV x1, x21                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E9604: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x019E9608: ADD x8, sp, #8             | X8 = (1152921513969781088 + 8) = 1152921513969781096 (0x100000022E130968);
            // 0x019E960C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x019E9610: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921513969769152]
            // 0x019E9614: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x019E9618: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019E961C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x019E9620: ADD x0, sp, #8             | X0 = (1152921513969781088 + 8) = 1152921513969781096 (0x100000022E130968);
            // 0x019E9624: BL #0x299a140              | 
            label_1:
            // 0x019E9628: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            label_2:
            // 0x019E962C: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>);
            // 0x019E9630: MOV x0, x19                | X0 = 1152921513969793152 (0x100000022E133880);//ML01
            // 0x019E9634: LDR x9, [x8, #0x2e0]       | X9 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>).__il2cppRuntimeField_2E0;
            // 0x019E9638: LDR x2, [x8, #0x2e8]       | X2 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>).__il2cppRuntimeField_2E8;
            // 0x019E963C: BLR x9                     | X0 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>).__il2cppRuntimeField_2E0();
            // 0x019E9640: CBNZ x19, #0x19e9648       | if (this != null) goto label_3;         
            if(this != null)
            {
                goto label_3;
            }
            // 0x019E9644: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_3:
            // 0x019E9648: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>);
            // 0x019E964C: MOV x0, x19                | X0 = 1152921513969793152 (0x100000022E133880);//ML01
            // 0x019E9650: LDR x9, [x8, #0x320]       | X9 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>).__il2cppRuntimeField_320;
            // 0x019E9654: LDR x1, [x8, #0x328]       | X1 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>).__il2cppRuntimeField_328;
            // 0x019E9658: BLR x9                     | X0 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>).__il2cppRuntimeField_320();
            // 0x019E965C: SUB w0, w0, #1             | W0 = (this - 1) = 1152921513969793151 (0x100000022E13387F);
            // 0x019E9660: SUB sp, x29, #0x20         | SP = (1152921513969781136 - 32) = 1152921513969781104 (0x100000022E130970);
            // 0x019E9664: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019E9668: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019E966C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019E9670: RET                        |  return (System.Int32)(Newtonsoft.Json.Utilities.CollectionWrapper<T>)[1152921513969793152];
            return (int)1152921513969793151;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
            // 0x019E9674: MOV x19, x0                | 
            // 0x019E9678: ADD x0, sp, #8             | 
            // 0x019E967C: BL #0x299a140              | 
            // 0x019E9680: MOV x0, x19                | 
            // 0x019E9684: BL #0x980800               | 
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E9688 VirtAddr: 0x019E9688 -RVA: 0x019E9688 
        // -CollectionWrapper<object>.System.Collections.IList.Contains
        //
        //
        // Offset in libil2cpp.so: 0x019E9688 (27170440), len: 232  VirtAddr: 0x019E9688 RVA: 0x019E9688 token: 100686597 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private bool System.Collections.IList.Contains(object value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            var val_2;
            //  | 
            var val_3;
            // 0x019E9688: STP x22, x21, [sp, #-0x30]! | stack[1152921513969901296] = ???;  stack[1152921513969901304] = ???;  //  dest_result_addr=1152921513969901296 |  dest_result_addr=1152921513969901304
            // 0x019E968C: STP x20, x19, [sp, #0x10]  | stack[1152921513969901312] = ???;  stack[1152921513969901320] = ???;  //  dest_result_addr=1152921513969901312 |  dest_result_addr=1152921513969901320
            // 0x019E9690: STP x29, x30, [sp, #0x20]  | stack[1152921513969901328] = ???;  stack[1152921513969901336] = ???;  //  dest_result_addr=1152921513969901328 |  dest_result_addr=1152921513969901336
            // 0x019E9694: ADD x29, sp, #0x20         | X29 = (1152921513969901296 + 32) = 1152921513969901328 (0x100000022E14DF10);
            // 0x019E9698: SUB sp, sp, #0x10          | SP = (1152921513969901296 - 16) = 1152921513969901280 (0x100000022E14DEE0);
            // 0x019E969C: MOV x21, x2                | X21 = __RuntimeMethodHiddenParam;//m1   
            val_2 = __RuntimeMethodHiddenParam;
            // 0x019E96A0: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E96A4: MOV x19, x0                | X19 = 1152921513969913344 (0x100000022E150E00);//ML01
            // 0x019E96A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x019E96AC: MOV x20, x1                | X20 = value;//m1                        
            // 0x019E96B0: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E96B4: LDR x2, [x8, #0x40]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 64;
            // 0x019E96B8: LDR x8, [x2]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 64;
            // 0x019E96BC: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 64();
            // 0x019E96C0: TBZ w0, #0, #0x19e9740     | if ((0x0 & 0x1) == 0) goto label_0;     
            if((0 & 1) == 0)
            {
                goto label_0;
            }
            // 0x019E96C4: CBNZ x19, #0x19e96cc       | if (this != null) goto label_1;         
            if(this != null)
            {
                goto label_1;
            }
            // 0x019E96C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_1:
            // 0x019E96CC: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E96D0: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E96D4: LDR x21, [x8, #8]          | X21 = __RuntimeMethodHiddenParam + 24 + 168 + 8;
            val_2 = mem[__RuntimeMethodHiddenParam + 24 + 168 + 8];
            val_2 = __RuntimeMethodHiddenParam + 24 + 168 + 8;
            // 0x019E96D8: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E96DC: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 8, ????);
            // 0x019E96E0: CBZ x20, #0x19e9724        | if (value == null) goto label_2;        
            if(value == null)
            {
                goto label_2;
            }
            // 0x019E96E4: MOV x0, x20                | X0 = value;//m1                         
            // 0x019E96E8: MOV x1, x21                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E96EC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
            // 0x019E96F0: MOV x1, x0                 | X1 = value;//m1                         
            // 0x019E96F4: CBNZ x1, #0x19e9728        | if (value != null) goto label_3;        
            if(value != null)
            {
                goto label_3;
            }
            // 0x019E96F8: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x019E96FC: MOV x1, x21                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E9700: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x019E9704: ADD x8, sp, #8             | X8 = (1152921513969901280 + 8) = 1152921513969901288 (0x100000022E14DEE8);
            // 0x019E9708: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x019E970C: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921513969889344]
            // 0x019E9710: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x019E9714: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019E9718: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x019E971C: ADD x0, sp, #8             | X0 = (1152921513969901280 + 8) = 1152921513969901288 (0x100000022E14DEE8);
            // 0x019E9720: BL #0x299a140              | 
            label_2:
            // 0x019E9724: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            label_3:
            // 0x019E9728: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>);
            // 0x019E972C: MOV x0, x19                | X0 = 1152921513969913344 (0x100000022E150E00);//ML01
            val_3 = this;
            // 0x019E9730: LDR x9, [x8, #0x300]       | X9 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>).__il2cppRuntimeField_300;
            // 0x019E9734: LDR x2, [x8, #0x308]       | X2 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>).__il2cppRuntimeField_308;
            // 0x019E9738: BLR x9                     | X0 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>).__il2cppRuntimeField_300();
            // 0x019E973C: B #0x19e9744               |  goto label_4;                          
            goto label_4;
            label_0:
            // 0x019E9740: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_3 = 0;
            label_4:
            // 0x019E9744: AND w0, w0, #1             | W0 = (val_3 & 1);                       
            val_3 = val_3 & 1;
            // 0x019E9748: SUB sp, x29, #0x20         | SP = (1152921513969901328 - 32) = 1152921513969901296 (0x100000022E14DEF0);
            // 0x019E974C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019E9750: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019E9754: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019E9758: RET                        |  return (System.Boolean)(val_3 & 1);    
            return (bool)val_3;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            // 0x019E975C: MOV x19, x0                | 
            // 0x019E9760: ADD x0, sp, #8             | 
            // 0x019E9764: BL #0x299a140              | 
            // 0x019E9768: MOV x0, x19                | 
            // 0x019E976C: BL #0x980800               | 
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E9770 VirtAddr: 0x019E9770 -RVA: 0x019E9770 
        // -CollectionWrapper<object>.System.Collections.IList.IndexOf
        //
        //
        // Offset in libil2cpp.so: 0x019E9770 (27170672), len: 448  VirtAddr: 0x019E9770 RVA: 0x019E9770 token: 100686598 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private int System.Collections.IList.IndexOf(object value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x019E9770: STP x24, x23, [sp, #-0x40]! | stack[1152921513970022672] = ???;  stack[1152921513970022680] = ???;  //  dest_result_addr=1152921513970022672 |  dest_result_addr=1152921513970022680
            // 0x019E9774: STP x22, x21, [sp, #0x10]  | stack[1152921513970022688] = ???;  stack[1152921513970022696] = ???;  //  dest_result_addr=1152921513970022688 |  dest_result_addr=1152921513970022696
            // 0x019E9778: STP x20, x19, [sp, #0x20]  | stack[1152921513970022704] = ???;  stack[1152921513970022712] = ???;  //  dest_result_addr=1152921513970022704 |  dest_result_addr=1152921513970022712
            // 0x019E977C: STP x29, x30, [sp, #0x30]  | stack[1152921513970022720] = ???;  stack[1152921513970022728] = ???;  //  dest_result_addr=1152921513970022720 |  dest_result_addr=1152921513970022728
            // 0x019E9780: ADD x29, sp, #0x30         | X29 = (1152921513970022672 + 48) = 1152921513970022720 (0x100000022E16B940);
            // 0x019E9784: SUB sp, sp, #0x10          | SP = (1152921513970022672 - 16) = 1152921513970022656 (0x100000022E16B900);
            // 0x019E9788: ADRP x21, #0x3739000       | X21 = 57905152 (0x3739000);             
            // 0x019E978C: LDRB w8, [x21, #0x66c]     | W8 = (bool)static_value_0373966C;       
            // 0x019E9790: MOV x20, x2                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x019E9794: MOV x22, x1                | X22 = value;//m1                        
            // 0x019E9798: MOV x19, x0                | X19 = 1152921513970034736 (0x100000022E16E830);//ML01
            val_6 = this;
            // 0x019E979C: TBNZ w8, #0, #0x19e97b8    | if (static_value_0373966C == true) goto label_0;
            // 0x019E97A0: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x019E97A4: LDR x8, [x8, #0xf8]        | X8 = 0x2B91668;                         
            // 0x019E97A8: LDR w0, [x8]               | W0 = 0x1C5E;                            
            // 0x019E97AC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C5E, ????);     
            // 0x019E97B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019E97B4: STRB w8, [x21, #0x66c]     | static_value_0373966C = true;            //  dest_result_addr=57906796
            label_0:
            // 0x019E97B8: LDR x8, [x19, #0x18]       | 
            // 0x019E97BC: CBNZ x8, #0x19e98dc        | if (0x1 != 0) goto label_1;             
            if(true != 0)
            {
                goto label_1;
            }
            // 0x019E97C0: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E97C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x019E97C8: MOV x1, x22                | X1 = value;//m1                         
            // 0x019E97CC: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E97D0: LDR x2, [x8, #0x40]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 64;
            val_7 = mem[__RuntimeMethodHiddenParam + 24 + 168 + 64];
            val_7 = __RuntimeMethodHiddenParam + 24 + 168 + 64;
            // 0x019E97D4: LDR x8, [x2]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 64;
            // 0x019E97D8: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 64();
            // 0x019E97DC: TBZ w0, #0, #0x19e989c     | if ((0x0 & 0x1) == 0) goto label_2;     
            if((0 & 1) == 0)
            {
                goto label_2;
            }
            // 0x019E97E0: LDR x19, [x19, #0x10]      | 
            // 0x019E97E4: CBNZ x19, #0x19e97ec       | if (this != null) goto label_3;         
            if(this != null)
            {
                goto label_3;
            }
            // 0x019E97E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_3:
            // 0x019E97EC: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E97F0: ADRP x9, #0x3605000        | X9 = 56643584 (0x3605000);              
            // 0x019E97F4: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E97F8: LDR x9, [x9, #0x308]       | X9 = 1152921504609349632;               
            // 0x019E97FC: LDR x23, [x8, #8]          | X23 = __RuntimeMethodHiddenParam + 24 + 168 + 8;
            // 0x019E9800: LDR x20, [x9]              | X20 = typeof(System.Collections.IList); 
            // 0x019E9804: MOV x0, x23                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E9808: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 8, ????);
            // 0x019E980C: CBZ x22, #0x19e9850        | if (value == null) goto label_4;        
            if(value == null)
            {
                goto label_4;
            }
            // 0x019E9810: MOV x0, x22                | X0 = value;//m1                         
            // 0x019E9814: MOV x1, x23                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E9818: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
            // 0x019E981C: MOV x21, x0                | X21 = value;//m1                        
            val_5 = value;
            // 0x019E9820: CBNZ x21, #0x19e9854       | if (value != null) goto label_5;        
            if(val_5 != null)
            {
                goto label_5;
            }
            // 0x019E9824: LDR x8, [x22]              | X8 = typeof(System.Object);             
            // 0x019E9828: MOV x1, x23                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E982C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x019E9830: ADD x8, sp, #8             | X8 = (1152921513970022656 + 8) = 1152921513970022664 (0x100000022E16B908);
            // 0x019E9834: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x019E9838: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921513970010736]
            // 0x019E983C: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x019E9840: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019E9844: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x019E9848: ADD x0, sp, #8             | X0 = (1152921513970022656 + 8) = 1152921513970022664 (0x100000022E16B908);
            // 0x019E984C: BL #0x299a140              | 
            label_4:
            // 0x019E9850: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_5 = 0;
            label_5:
            // 0x019E9854: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>);
            // 0x019E9858: LDRH w9, [x8, #0x102]      | W9 = Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x019E985C: CBZ x9, #0x19e9888         | if (Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_6;
            // 0x019E9860: LDR x10, [x8, #0x98]       | X10 = Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x019E9864: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_5 = 0;
            // 0x019E9868: ADD x10, x10, #8           | X10 = (Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504867053576 (0x100000000F827008);
            label_8:
            // 0x019E986C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x019E9870: CMP x12, x20               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IList))
            // 0x019E9874: B.EQ #0x19e98a4            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_7;
            // 0x019E9878: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_5 = val_5 + 1;
            // 0x019E987C: ADD x10, x10, #0x10        | X10 = (1152921504867053576 + 16) = 1152921504867053592 (0x100000000F827018);
            // 0x019E9880: CMP x11, x9                | STATE = COMPARE((0 + 1), Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x019E9884: B.LO #0x19e986c            | if (0 < Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interface_offsets_count) goto label_8;
            label_6:
            // 0x019E9888: ORR w2, wzr, #7            | W2 = 7(0x7);                            
            val_7 = 7;
            // 0x019E988C: MOV x0, x19                | X0 = 1152921513970034736 (0x100000022E16E830);//ML01
            val_8 = val_6;
            // 0x019E9890: MOV x1, x20                | X1 = 1152921504609349632 (0x1000000000263000);//ML01
            // 0x019E9894: BL #0x2776c24              | X0 = sub_2776C24( ?? this, ????);       
            // 0x019E9898: B #0x19e98b4               |  goto label_9;                          
            goto label_9;
            label_2:
            // 0x019E989C: MOVN w0, #0                | W0 = 0 (0x0);//ML01                     
            val_9 = 0;
            // 0x019E98A0: B #0x19e98c4               |  goto label_10;                         
            goto label_10;
            label_7:
            // 0x019E98A4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x019E98A8: ADD w9, w9, #7             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 7);
            // 0x019E98AC: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504867016704 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 7));
            // 0x019E98B0: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504867016704 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 7)).272
            label_9:
            // 0x019E98B4: LDP x8, x2, [x0]           | X8 = val_1; X2 = ;                       //  find_add[1152921513970010736] | 
            // 0x019E98B8: MOV x0, x19                | X0 = 1152921513970034736 (0x100000022E16E830);//ML01
            val_9 = val_6;
            // 0x019E98BC: MOV x1, x21                | X1 = 0 (0x0);//ML01                     
            // 0x019E98C0: BLR x8                     | X0 = val_1();                           
            label_10:
            // 0x019E98C4: SUB sp, x29, #0x30         | SP = (1152921513970022720 - 48) = 1152921513970022672 (0x100000022E16B910);
            // 0x019E98C8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x019E98CC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x019E98D0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x019E98D4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x019E98D8: RET                        |  return (System.Int32)this;             
            return (int)val_9;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
            label_1:
            // 0x019E98DC: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x019E98E0: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x019E98E4: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_3 = null;
            // 0x019E98E8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x019E98EC: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
            // 0x019E98F0: LDR x8, [x8, #0xb28]       | X8 = (string**)(1152921513970009536)("Wrapped ICollection<T> does not support IndexOf.");
            // 0x019E98F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x019E98F8: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x019E98FC: LDR x1, [x8]               | X1 = "Wrapped ICollection<T> does not support IndexOf.";
            // 0x019E9900: BL #0x1c32b48              | .ctor(message:  "Wrapped ICollection<T> does not support IndexOf.");
            val_3 = new System.Exception(message:  "Wrapped ICollection<T> does not support IndexOf.");
            // 0x019E9904: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x019E9908: LDR x8, [x8, #0xf48]       | X8 = 1152921513970009712;               
            // 0x019E990C: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x019E9910: LDR x1, [x8]               | X1 = System.Int32 Newtonsoft.Json.Utilities.CollectionWrapper<System.Object>::System.Collections.IList.IndexOf(object value);
            // 0x019E9914: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x019E9918: BL #0x19e29cc              | X0 = System.Collections.IList.IndexOf(value:  System.Int32 Newtonsoft.Json.Utilities.CollectionWrapper<System.Object>::System.Collections.IList.IndexOf(object value));
            int val_4 = System.Collections.IList.IndexOf(value:  System.Int32 Newtonsoft.Json.Utilities.CollectionWrapper<System.Object>::System.Collections.IList.IndexOf(object value));
            // 0x019E991C: MOV x19, x0                | X19 = val_4;//m1                        
            // 0x019E9920: ADD x0, sp, #8             | X0 = (1152921513970022656 + 8) = 1152921513970022664 (0x100000022E16B908);
            // 0x019E9924: BL #0x299a140              | 
            // 0x019E9928: MOV x0, x19                | X0 = val_4;//m1                         
            // 0x019E992C: BL #0x980800               | X0 = sub_980800( ?? val_4, ????);       
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E9930 VirtAddr: 0x019E9930 -RVA: 0x019E9930 
        // -CollectionWrapper<object>.System.Collections.IList.RemoveAt
        //
        //
        // Offset in libil2cpp.so: 0x019E9930 (27171120), len: 268  VirtAddr: 0x019E9930 RVA: 0x019E9930 token: 100686599 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private void System.Collections.IList.RemoveAt(int index)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            // 0x019E9930: STP x22, x21, [sp, #-0x30]! | stack[1152921513970139984] = ???;  stack[1152921513970139992] = ???;  //  dest_result_addr=1152921513970139984 |  dest_result_addr=1152921513970139992
            // 0x019E9934: STP x20, x19, [sp, #0x10]  | stack[1152921513970140000] = ???;  stack[1152921513970140008] = ???;  //  dest_result_addr=1152921513970140000 |  dest_result_addr=1152921513970140008
            // 0x019E9938: STP x29, x30, [sp, #0x20]  | stack[1152921513970140016] = ???;  stack[1152921513970140024] = ???;  //  dest_result_addr=1152921513970140016 |  dest_result_addr=1152921513970140024
            // 0x019E993C: ADD x29, sp, #0x20         | X29 = (1152921513970139984 + 32) = 1152921513970140016 (0x100000022E188370);
            // 0x019E9940: ADRP x21, #0x3739000       | X21 = 57905152 (0x3739000);             
            // 0x019E9944: LDRB w8, [x21, #0x66d]     | W8 = (bool)static_value_0373966D;       
            // 0x019E9948: MOV w19, w1                | W19 = index;//m1                        
            // 0x019E994C: MOV x20, x0                | X20 = 1152921513970152032 (0x100000022E18B260);//ML01
            // 0x019E9950: TBNZ w8, #0, #0x19e996c    | if (static_value_0373966D == true) goto label_0;
            // 0x019E9954: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
            // 0x019E9958: LDR x8, [x8, #0xcc0]       | X8 = 0x2B91670;                         
            // 0x019E995C: LDR w0, [x8]               | W0 = 0x1C60;                            
            // 0x019E9960: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C60, ????);     
            // 0x019E9964: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019E9968: STRB w8, [x21, #0x66d]     | static_value_0373966D = true;            //  dest_result_addr=57906797
            label_0:
            // 0x019E996C: LDR x8, [x20, #0x18]       | 
            // 0x019E9970: CBNZ x8, #0x19e99fc        | if (0x1 != 0) goto label_1;             
            if(true != 0)
            {
                goto label_1;
            }
            // 0x019E9974: LDR x20, [x20, #0x10]      | 
            // 0x019E9978: CBNZ x20, #0x19e9980       | if (this != null) goto label_2;         
            if(this != null)
            {
                goto label_2;
            }
            // 0x019E997C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C60, ????);     
            label_2:
            // 0x019E9980: ADRP x9, #0x3605000        | X9 = 56643584 (0x3605000);              
            // 0x019E9984: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>);
            // 0x019E9988: LDR x9, [x9, #0x308]       | X9 = 1152921504609349632;               
            // 0x019E998C: LDR x1, [x9]               | X1 = typeof(System.Collections.IList);  
            // 0x019E9990: LDRH w9, [x8, #0x102]      | W9 = Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x019E9994: CBZ x9, #0x19e99c0         | if (Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_3;
            // 0x019E9998: LDR x10, [x8, #0x98]       | X10 = Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x019E999C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_3 = 0;
            // 0x019E99A0: ADD x10, x10, #8           | X10 = (Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504867053576 (0x100000000F827008);
            label_5:
            // 0x019E99A4: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x019E99A8: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IList))
            // 0x019E99AC: B.EQ #0x19e99d0            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_4;
            // 0x019E99B0: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_3 = val_3 + 1;
            // 0x019E99B4: ADD x10, x10, #0x10        | X10 = (1152921504867053576 + 16) = 1152921504867053592 (0x100000000F827018);
            // 0x019E99B8: CMP x11, x9                | STATE = COMPARE((0 + 1), Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x019E99BC: B.LO #0x19e99a4            | if (0 < Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interface_offsets_count) goto label_5;
            label_3:
            // 0x019E99C0: MOVZ w2, #0xa              | W2 = 10 (0xA);//ML01                    
            // 0x019E99C4: MOV x0, x20                | X0 = 1152921513970152032 (0x100000022E18B260);//ML01
            val_3 = this;
            // 0x019E99C8: BL #0x2776c24              | X0 = sub_2776C24( ?? this, ????);       
            // 0x019E99CC: B #0x19e99e0               |  goto label_6;                          
            goto label_6;
            label_4:
            // 0x019E99D0: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x019E99D4: ADD w9, w9, #0xa           | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 10);
            // 0x019E99D8: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504867016704 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 10));
            // 0x019E99DC: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504867016704 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 10)).272
            label_6:
            // 0x019E99E0: LDP x3, x2, [x0]           | X3 = 0x0; X2 = 0xA001200000E44;          //  | 
            // 0x019E99E4: MOV x0, x20                | X0 = 1152921513970152032 (0x100000022E18B260);//ML01
            // 0x019E99E8: MOV w1, w19                | W1 = index;//m1                         
            // 0x019E99EC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019E99F0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019E99F4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019E99F8: BR x3                      | goto ;                                  
            goto x3;
            label_1:
            // 0x019E99FC: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x019E9A00: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x019E9A04: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_2 = null;
            // 0x019E9A08: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x019E9A0C: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x019E9A10: LDR x8, [x8, #0x948]       | X8 = (string**)(1152921513970126832)("Wrapped ICollection<T> does not support RemoveAt.");
            // 0x019E9A14: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x019E9A18: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x019E9A1C: LDR x1, [x8]               | X1 = "Wrapped ICollection<T> does not support RemoveAt.";
            // 0x019E9A20: BL #0x1c32b48              | .ctor(message:  "Wrapped ICollection<T> does not support RemoveAt.");
            val_2 = new System.Exception(message:  "Wrapped ICollection<T> does not support RemoveAt.");
            // 0x019E9A24: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x019E9A28: LDR x8, [x8, #0x2b0]       | X8 = 1152921513970127008;               
            // 0x019E9A2C: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x019E9A30: LDR x1, [x8]               | X1 = System.Void Newtonsoft.Json.Utilities.CollectionWrapper<System.Object>::System.Collections.IList.RemoveAt(int index);
            // 0x019E9A34: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x019E9A38: BL #0x19e29cc              | System.Collections.IList.RemoveAt(index:  773345440);
            System.Collections.IList.RemoveAt(index:  773345440);
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E9A3C VirtAddr: 0x019E9A3C -RVA: 0x019E9A3C 
        // -CollectionWrapper<object>.System.Collections.IList.Insert
        //
        //
        // Offset in libil2cpp.so: 0x019E9A3C (27171388), len: 444  VirtAddr: 0x019E9A3C RVA: 0x019E9A3C token: 100686600 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private void System.Collections.IList.Insert(int index, object value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            var val_4;
            //  | 
            var val_5;
            // 0x019E9A3C: STP x24, x23, [sp, #-0x40]! | stack[1152921513970257264] = ???;  stack[1152921513970257272] = ???;  //  dest_result_addr=1152921513970257264 |  dest_result_addr=1152921513970257272
            // 0x019E9A40: STP x22, x21, [sp, #0x10]  | stack[1152921513970257280] = ???;  stack[1152921513970257288] = ???;  //  dest_result_addr=1152921513970257280 |  dest_result_addr=1152921513970257288
            // 0x019E9A44: STP x20, x19, [sp, #0x20]  | stack[1152921513970257296] = ???;  stack[1152921513970257304] = ???;  //  dest_result_addr=1152921513970257296 |  dest_result_addr=1152921513970257304
            // 0x019E9A48: STP x29, x30, [sp, #0x30]  | stack[1152921513970257312] = ???;  stack[1152921513970257320] = ???;  //  dest_result_addr=1152921513970257312 |  dest_result_addr=1152921513970257320
            // 0x019E9A4C: ADD x29, sp, #0x30         | X29 = (1152921513970257264 + 48) = 1152921513970257312 (0x100000022E1A4DA0);
            // 0x019E9A50: SUB sp, sp, #0x10          | SP = (1152921513970257264 - 16) = 1152921513970257248 (0x100000022E1A4D60);
            // 0x019E9A54: ADRP x22, #0x3739000       | X22 = 57905152 (0x3739000);             
            // 0x019E9A58: LDRB w8, [x22, #0x66e]     | W8 = (bool)static_value_0373966E;       
            // 0x019E9A5C: MOV x21, x3                | X21 = __RuntimeMethodHiddenParam;//m1   
            // 0x019E9A60: MOV x23, x2                | X23 = value;//m1                        
            // 0x019E9A64: MOV w19, w1                | W19 = index;//m1                        
            // 0x019E9A68: MOV x20, x0                | X20 = 1152921513970269328 (0x100000022E1A7C90);//ML01
            // 0x019E9A6C: TBNZ w8, #0, #0x19e9a88    | if (static_value_0373966E == true) goto label_0;
            // 0x019E9A70: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x019E9A74: LDR x8, [x8, #0x318]       | X8 = 0x2B9166C;                         
            // 0x019E9A78: LDR w0, [x8]               | W0 = 0x1C5F;                            
            // 0x019E9A7C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C5F, ????);     
            // 0x019E9A80: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019E9A84: STRB w8, [x22, #0x66e]     | static_value_0373966E = true;            //  dest_result_addr=57906798
            label_0:
            // 0x019E9A88: LDR x8, [x20, #0x18]       | 
            // 0x019E9A8C: CBNZ x8, #0x19e9ba4        | if (0x1 != 0) goto label_1;             
            if(true != 0)
            {
                goto label_1;
            }
            // 0x019E9A90: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E9A94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x019E9A98: MOV x1, x23                | X1 = value;//m1                         
            // 0x019E9A9C: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E9AA0: LDR x2, [x8, #0x20]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 32;
            // 0x019E9AA4: LDR x8, [x2]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 32;
            // 0x019E9AA8: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 32();
            // 0x019E9AAC: LDR x20, [x20, #0x10]      | 
            // 0x019E9AB0: CBNZ x20, #0x19e9ab8       | if (this != null) goto label_2;         
            if(this != null)
            {
                goto label_2;
            }
            // 0x019E9AB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_2:
            // 0x019E9AB8: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E9ABC: ADRP x9, #0x3605000        | X9 = 56643584 (0x3605000);              
            // 0x019E9AC0: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E9AC4: LDR x9, [x9, #0x308]       | X9 = 1152921504609349632;               
            // 0x019E9AC8: LDR x24, [x8, #8]          | X24 = __RuntimeMethodHiddenParam + 24 + 168 + 8;
            // 0x019E9ACC: LDR x21, [x9]              | X21 = typeof(System.Collections.IList); 
            // 0x019E9AD0: MOV x0, x24                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E9AD4: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 8, ????);
            // 0x019E9AD8: CBZ x23, #0x19e9b1c        | if (value == null) goto label_3;        
            if(value == null)
            {
                goto label_3;
            }
            // 0x019E9ADC: MOV x0, x23                | X0 = value;//m1                         
            // 0x019E9AE0: MOV x1, x24                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E9AE4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
            // 0x019E9AE8: MOV x22, x0                | X22 = value;//m1                        
            val_4 = value;
            // 0x019E9AEC: CBNZ x22, #0x19e9b20       | if (value != null) goto label_4;        
            if(val_4 != null)
            {
                goto label_4;
            }
            // 0x019E9AF0: LDR x8, [x23]              | X8 = typeof(System.Object);             
            // 0x019E9AF4: MOV x1, x24                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E9AF8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x019E9AFC: ADD x8, sp, #8             | X8 = (1152921513970257248 + 8) = 1152921513970257256 (0x100000022E1A4D68);
            // 0x019E9B00: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x019E9B04: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921513970245328]
            // 0x019E9B08: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x019E9B0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019E9B10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x019E9B14: ADD x0, sp, #8             | X0 = (1152921513970257248 + 8) = 1152921513970257256 (0x100000022E1A4D68);
            // 0x019E9B18: BL #0x299a140              | 
            label_3:
            // 0x019E9B1C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_4 = 0;
            label_4:
            // 0x019E9B20: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>);
            // 0x019E9B24: LDRH w9, [x8, #0x102]      | W9 = Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x019E9B28: CBZ x9, #0x19e9b54         | if (Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_5;
            // 0x019E9B2C: LDR x10, [x8, #0x98]       | X10 = Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x019E9B30: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_4 = 0;
            // 0x019E9B34: ADD x10, x10, #8           | X10 = (Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504867053576 (0x100000000F827008);
            label_7:
            // 0x019E9B38: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x019E9B3C: CMP x12, x21               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IList))
            // 0x019E9B40: B.EQ #0x19e9b68            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_6;
            // 0x019E9B44: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_4 = val_4 + 1;
            // 0x019E9B48: ADD x10, x10, #0x10        | X10 = (1152921504867053576 + 16) = 1152921504867053592 (0x100000000F827018);
            // 0x019E9B4C: CMP x11, x9                | STATE = COMPARE((0 + 1), Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x019E9B50: B.LO #0x19e9b38            | if (0 < Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interface_offsets_count) goto label_7;
            label_5:
            // 0x019E9B54: ORR w2, wzr, #8            | W2 = 8(0x8);                            
            // 0x019E9B58: MOV x0, x20                | X0 = 1152921513970269328 (0x100000022E1A7C90);//ML01
            val_5 = this;
            // 0x019E9B5C: MOV x1, x21                | X1 = 1152921504609349632 (0x1000000000263000);//ML01
            // 0x019E9B60: BL #0x2776c24              | X0 = sub_2776C24( ?? this, ????);       
            // 0x019E9B64: B #0x19e9b78               |  goto label_8;                          
            goto label_8;
            label_6:
            // 0x019E9B68: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x019E9B6C: ADD w9, w9, #8             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 8);
            // 0x019E9B70: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504867016704 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 8));
            // 0x019E9B74: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504867016704 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 8)).272
            label_8:
            // 0x019E9B78: LDP x8, x3, [x0]           | X8 = val_1; X3 = ;                       //  find_add[1152921513970245328] | 
            // 0x019E9B7C: MOV x0, x20                | X0 = 1152921513970269328 (0x100000022E1A7C90);//ML01
            // 0x019E9B80: MOV w1, w19                | W1 = index;//m1                         
            // 0x019E9B84: MOV x2, x22                | X2 = 0 (0x0);//ML01                     
            // 0x019E9B88: BLR x8                     | X0 = val_1();                           
            // 0x019E9B8C: SUB sp, x29, #0x30         | SP = (1152921513970257312 - 48) = 1152921513970257264 (0x100000022E1A4D70);
            // 0x019E9B90: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x019E9B94: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x019E9B98: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x019E9B9C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x019E9BA0: RET                        |  return;                                
            return;
            label_1:
            // 0x019E9BA4: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x019E9BA8: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x019E9BAC: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_3 = null;
            // 0x019E9BB0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x019E9BB4: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x019E9BB8: LDR x8, [x8, #0xa98]       | X8 = (string**)(1152921513970244128)("Wrapped ICollection<T> does not support Insert.");
            // 0x019E9BBC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x019E9BC0: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x019E9BC4: LDR x1, [x8]               | X1 = "Wrapped ICollection<T> does not support Insert.";
            // 0x019E9BC8: BL #0x1c32b48              | .ctor(message:  "Wrapped ICollection<T> does not support Insert.");
            val_3 = new System.Exception(message:  "Wrapped ICollection<T> does not support Insert.");
            // 0x019E9BCC: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
            // 0x019E9BD0: LDR x8, [x8, #0xee0]       | X8 = 1152921513970244304;               
            // 0x019E9BD4: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x019E9BD8: LDR x1, [x8]               | X1 = System.Void Newtonsoft.Json.Utilities.CollectionWrapper<System.Object>::System.Collections.IList.Insert(int index, object value);
            // 0x019E9BDC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x019E9BE0: BL #0x19e29cc              | System.Collections.IList.Insert(index:  773462736, value:  0);
            System.Collections.IList.Insert(index:  773462736, value:  0);
            // 0x019E9BE4: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x019E9BE8: ADD x0, sp, #8             | X0 = (1152921513970257248 + 8) = 1152921513970257256 (0x100000022E1A4D68);
            // 0x019E9BEC: BL #0x299a140              | 
            // 0x019E9BF0: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x019E9BF4: BL #0x980800               | X0 = sub_980800( ?? typeof(System.Exception), ????);
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E9BF8 VirtAddr: 0x019E9BF8 -RVA: 0x019E9BF8 
        // -CollectionWrapper<object>.System.Collections.IList.get_IsFixedSize
        //
        //
        // Offset in libil2cpp.so: 0x019E9BF8 (27171832), len: 308  VirtAddr: 0x019E9BF8 RVA: 0x019E9BF8 token: 100686601 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private bool System.Collections.IList.get_IsFixedSize()
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            //  | 
            var val_4;
            // 0x019E9BF8: STP x22, x21, [sp, #-0x30]! | stack[1152921513970373376] = ???;  stack[1152921513970373384] = ???;  //  dest_result_addr=1152921513970373376 |  dest_result_addr=1152921513970373384
            // 0x019E9BFC: STP x20, x19, [sp, #0x10]  | stack[1152921513970373392] = ???;  stack[1152921513970373400] = ???;  //  dest_result_addr=1152921513970373392 |  dest_result_addr=1152921513970373400
            // 0x019E9C00: STP x29, x30, [sp, #0x20]  | stack[1152921513970373408] = ???;  stack[1152921513970373416] = ???;  //  dest_result_addr=1152921513970373408 |  dest_result_addr=1152921513970373416
            // 0x019E9C04: ADD x29, sp, #0x20         | X29 = (1152921513970373376 + 32) = 1152921513970373408 (0x100000022E1C1320);
            // 0x019E9C08: ADRP x19, #0x3739000       | X19 = 57905152 (0x3739000);             
            // 0x019E9C0C: LDRB w8, [x19, #0x66f]     | W8 = (bool)static_value_0373966F;       
            // 0x019E9C10: MOV x20, x1                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x019E9C14: MOV x21, x0                | X21 = 1152921513970385424 (0x100000022E1C4210);//ML01
            // 0x019E9C18: TBNZ w8, #0, #0x19e9c34    | if (static_value_0373966F == true) goto label_0;
            // 0x019E9C1C: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x019E9C20: LDR x8, [x8, #0xde0]       | X8 = 0x2B91660;                         
            // 0x019E9C24: LDR w0, [x8]               | W0 = 0x1C5C;                            
            // 0x019E9C28: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C5C, ????);     
            // 0x019E9C2C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019E9C30: STRB w8, [x19, #0x66f]     | static_value_0373966F = true;            //  dest_result_addr=57906799
            label_0:
            // 0x019E9C34: LDR x19, [x21, #0x18]      | 
            // 0x019E9C38: CBZ x19, #0x19e9c94        | if ( == 0) goto label_1;                
            if(==0)
            {
                goto label_1;
            }
            // 0x019E9C3C: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E9C40: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E9C44: LDR x20, [x8]              | X20 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E9C48: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x019E9C4C: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168, ????);
            // 0x019E9C50: LDR x8, [x19]              | X8 = mem[57905152];                     
            var val_6 = mem[57905152];
            // 0x019E9C54: LDRH w9, [x8, #0x102]      | W9 = mem[57905152] + 258;               
            // 0x019E9C58: CBZ x9, #0x19e9c84         | if (mem[57905152] + 258 == 0) goto label_2;
            if((mem[57905152] + 258) == 0)
            {
                goto label_2;
            }
            // 0x019E9C5C: LDR x10, [x8, #0x98]       | X10 = mem[57905152] + 152;              
            var val_1 = mem[57905152] + 152;
            // 0x019E9C60: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x019E9C64: ADD x10, x10, #8           | X10 = (mem[57905152] + 152 + 8);        
            val_1 = val_1 + 8;
            label_4:
            // 0x019E9C68: LDUR x12, [x10, #-8]       | X12 = (mem[57905152] + 152 + 8) + -8;   
            // 0x019E9C6C: CMP x12, x20               | STATE = COMPARE((mem[57905152] + 152 + 8) + -8, __RuntimeMethodHiddenParam + 24 + 168)
            // 0x019E9C70: B.EQ #0x19e9cf0            | if ((mem[57905152] + 152 + 8) + -8 == __RuntimeMethodHiddenParam + 24 + 168) goto label_3;
            if(((mem[57905152] + 152 + 8) + -8) == (__RuntimeMethodHiddenParam + 24 + 168))
            {
                goto label_3;
            }
            // 0x019E9C74: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x019E9C78: ADD x10, x10, #0x10        | X10 = ((mem[57905152] + 152 + 8) + 16); 
            val_1 = val_1 + 16;
            // 0x019E9C7C: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[57905152] + 258)
            // 0x019E9C80: B.LO #0x19e9c68            | if (0 < mem[57905152] + 258) goto label_4;
            if(val_2 < (mem[57905152] + 258))
            {
                goto label_4;
            }
            label_2:
            // 0x019E9C84: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x019E9C88: MOV x0, x19                | X0 = 57905152 (0x3739000);//ML01        
            val_4 = 57905152;
            // 0x019E9C8C: MOV x1, x20                | X1 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x019E9C90: B #0x19e9ce8               |  goto label_5;                          
            goto label_5;
            label_1:
            // 0x019E9C94: LDR x19, [x21, #0x10]      | 
            // 0x019E9C98: CBNZ x19, #0x19e9ca0       | if ( != 0) goto label_6;                
            if(!=0)
            {
                goto label_6;
            }
            // 0x019E9C9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C5C, ????);     
            label_6:
            // 0x019E9CA0: ADRP x9, #0x3605000        | X9 = 56643584 (0x3605000);              
            // 0x019E9CA4: LDR x8, [x19]              | X8 = mem[57905152];                     
            var val_7 = mem[57905152];
            // 0x019E9CA8: LDR x9, [x9, #0x308]       | X9 = 1152921504609349632;               
            // 0x019E9CAC: LDR x1, [x9]               | X1 = typeof(System.Collections.IList);  
            // 0x019E9CB0: LDRH w9, [x8, #0x102]      | W9 = mem[57905152] + 258;               
            // 0x019E9CB4: CBZ x9, #0x19e9ce0         | if (mem[57905152] + 258 == 0) goto label_7;
            if((mem[57905152] + 258) == 0)
            {
                goto label_7;
            }
            // 0x019E9CB8: LDR x10, [x8, #0x98]       | X10 = mem[57905152] + 152;              
            var val_3 = mem[57905152] + 152;
            // 0x019E9CBC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_4 = 0;
            // 0x019E9CC0: ADD x10, x10, #8           | X10 = (mem[57905152] + 152 + 8);        
            val_3 = val_3 + 8;
            label_9:
            // 0x019E9CC4: LDUR x12, [x10, #-8]       | X12 = (mem[57905152] + 152 + 8) + -8;   
            // 0x019E9CC8: CMP x12, x1                | STATE = COMPARE((mem[57905152] + 152 + 8) + -8, typeof(System.Collections.IList))
            // 0x019E9CCC: B.EQ #0x19e9d04            | if ((mem[57905152] + 152 + 8) + -8 == null) goto label_8;
            if(((mem[57905152] + 152 + 8) + -8) == null)
            {
                goto label_8;
            }
            // 0x019E9CD0: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_4 = val_4 + 1;
            // 0x019E9CD4: ADD x10, x10, #0x10        | X10 = ((mem[57905152] + 152 + 8) + 16); 
            val_3 = val_3 + 16;
            // 0x019E9CD8: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[57905152] + 258)
            // 0x019E9CDC: B.LO #0x19e9cc4            | if (0 < mem[57905152] + 258) goto label_9;
            if(val_4 < (mem[57905152] + 258))
            {
                goto label_9;
            }
            label_7:
            // 0x019E9CE0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x019E9CE4: MOV x0, x19                | X0 = 57905152 (0x3739000);//ML01        
            val_4 = 57905152;
            label_5:
            // 0x019E9CE8: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x3739000, ????);  
            // 0x019E9CEC: B #0x19e9d10               |  goto label_11;                         
            goto label_11;
            label_3:
            // 0x019E9CF0: LDR w9, [x10]              | W9 = (mem[57905152] + 152 + 8);         
            var val_5 = val_1;
            // 0x019E9CF4: ADD w9, w9, #1             | W9 = ((mem[57905152] + 152 + 8) + 1);   
            val_5 = val_5 + 1;
            // 0x019E9CF8: ADD x8, x8, w9, uxtw #4    | X8 = (mem[57905152] + ((mem[57905152] + 152 + 8) + 1));
            val_6 = val_6 + val_5;
            // 0x019E9CFC: ADD x0, x8, #0x110         | X0 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 1)) + 272);
            val_4 = val_6 + 272;
            // 0x019E9D00: B #0x19e9d10               |  goto label_11;                         
            goto label_11;
            label_8:
            // 0x019E9D04: LDR w9, [x10]              | W9 = (mem[57905152] + 152 + 8);         
            // 0x019E9D08: ADD x8, x8, x9, lsl #4     | X8 = (mem[57905152] + ((mem[57905152] + 152 + 8)) << 4);
            val_7 = val_7 + (((mem[57905152] + 152 + 8)) << 4);
            // 0x019E9D0C: ADD x0, x8, #0x110         | X0 = ((mem[57905152] + ((mem[57905152] + 152 + 8)) << 4) + 272);
            val_4 = val_7 + 272;
            label_11:
            // 0x019E9D10: LDR x2, [x0]               | X2 = ((mem[57905152] + ((mem[57905152] + 152 + 8)) << 4) + 272);
            // 0x019E9D14: LDR x1, [x0, #8]           | X1 = ((mem[57905152] + ((mem[57905152] + 152 + 8)) << 4) + 272) + 8;
            // 0x019E9D18: MOV x0, x19                | X0 = 57905152 (0x3739000);//ML01        
            // 0x019E9D1C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019E9D20: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019E9D24: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019E9D28: BR x2                      | goto ((mem[57905152] + ((mem[57905152] + 152 + 8)) << 4) + 272);
            goto ((mem[57905152] + ((mem[57905152] + 152 + 8)) << 4) + 272);
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E9D2C VirtAddr: 0x019E9D2C -RVA: 0x019E9D2C 
        // -CollectionWrapper<object>.System.Collections.IList.Remove
        //
        //
        // Offset in libil2cpp.so: 0x019E9D2C (27172140), len: 220  VirtAddr: 0x019E9D2C RVA: 0x019E9D2C token: 100686602 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private void System.Collections.IList.Remove(object value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            var val_2;
            // 0x019E9D2C: STP x22, x21, [sp, #-0x30]! | stack[1152921513970489472] = ???;  stack[1152921513970489480] = ???;  //  dest_result_addr=1152921513970489472 |  dest_result_addr=1152921513970489480
            // 0x019E9D30: STP x20, x19, [sp, #0x10]  | stack[1152921513970489488] = ???;  stack[1152921513970489496] = ???;  //  dest_result_addr=1152921513970489488 |  dest_result_addr=1152921513970489496
            // 0x019E9D34: STP x29, x30, [sp, #0x20]  | stack[1152921513970489504] = ???;  stack[1152921513970489512] = ???;  //  dest_result_addr=1152921513970489504 |  dest_result_addr=1152921513970489512
            // 0x019E9D38: ADD x29, sp, #0x20         | X29 = (1152921513970489472 + 32) = 1152921513970489504 (0x100000022E1DD8A0);
            // 0x019E9D3C: SUB sp, sp, #0x10          | SP = (1152921513970489472 - 16) = 1152921513970489456 (0x100000022E1DD870);
            // 0x019E9D40: MOV x21, x2                | X21 = __RuntimeMethodHiddenParam;//m1   
            val_2 = __RuntimeMethodHiddenParam;
            // 0x019E9D44: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E9D48: MOV x19, x0                | X19 = 1152921513970501520 (0x100000022E1E0790);//ML01
            // 0x019E9D4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x019E9D50: MOV x20, x1                | X20 = value;//m1                        
            // 0x019E9D54: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E9D58: LDR x2, [x8, #0x40]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 64;
            // 0x019E9D5C: LDR x8, [x2]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 64;
            // 0x019E9D60: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 64();
            // 0x019E9D64: TBZ w0, #0, #0x19e9de0     | if ((0x0 & 0x1) == 0) goto label_0;     
            if((0 & 1) == 0)
            {
                goto label_0;
            }
            // 0x019E9D68: CBNZ x19, #0x19e9d70       | if (this != null) goto label_1;         
            if(this != null)
            {
                goto label_1;
            }
            // 0x019E9D6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_1:
            // 0x019E9D70: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E9D74: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E9D78: LDR x21, [x8, #8]          | X21 = __RuntimeMethodHiddenParam + 24 + 168 + 8;
            val_2 = mem[__RuntimeMethodHiddenParam + 24 + 168 + 8];
            val_2 = __RuntimeMethodHiddenParam + 24 + 168 + 8;
            // 0x019E9D7C: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E9D80: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 8, ????);
            // 0x019E9D84: CBZ x20, #0x19e9dc8        | if (value == null) goto label_2;        
            if(value == null)
            {
                goto label_2;
            }
            // 0x019E9D88: MOV x0, x20                | X0 = value;//m1                         
            // 0x019E9D8C: MOV x1, x21                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E9D90: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
            // 0x019E9D94: MOV x1, x0                 | X1 = value;//m1                         
            // 0x019E9D98: CBNZ x1, #0x19e9dcc        | if (value != null) goto label_3;        
            if(value != null)
            {
                goto label_3;
            }
            // 0x019E9D9C: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x019E9DA0: MOV x1, x21                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E9DA4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x019E9DA8: ADD x8, sp, #8             | X8 = (1152921513970489456 + 8) = 1152921513970489464 (0x100000022E1DD878);
            // 0x019E9DAC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x019E9DB0: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921513970477520]
            // 0x019E9DB4: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x019E9DB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019E9DBC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x019E9DC0: ADD x0, sp, #8             | X0 = (1152921513970489456 + 8) = 1152921513970489464 (0x100000022E1DD878);
            // 0x019E9DC4: BL #0x299a140              | 
            label_2:
            // 0x019E9DC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            label_3:
            // 0x019E9DCC: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>);
            // 0x019E9DD0: MOV x0, x19                | X0 = 1152921513970501520 (0x100000022E1E0790);//ML01
            // 0x019E9DD4: LDR x9, [x8, #0x340]       | X9 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>).__il2cppRuntimeField_340;
            // 0x019E9DD8: LDR x2, [x8, #0x348]       | X2 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>).__il2cppRuntimeField_348;
            // 0x019E9DDC: BLR x9                     | X0 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>).__il2cppRuntimeField_340();
            label_0:
            // 0x019E9DE0: SUB sp, x29, #0x20         | SP = (1152921513970489504 - 32) = 1152921513970489472 (0x100000022E1DD880);
            // 0x019E9DE4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019E9DE8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019E9DEC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019E9DF0: RET                        |  return;                                
            return;
            // 0x019E9DF4: MOV x19, x0                | 
            // 0x019E9DF8: ADD x0, sp, #8             | 
            // 0x019E9DFC: BL #0x299a140              | 
            // 0x019E9E00: MOV x0, x19                | 
            // 0x019E9E04: BL #0x980800               | 
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E9E08 VirtAddr: 0x019E9E08 -RVA: 0x019E9E08 
        // -CollectionWrapper<object>.System.Collections.IList.get_Item
        //
        //
        // Offset in libil2cpp.so: 0x019E9E08 (27172360), len: 268  VirtAddr: 0x019E9E08 RVA: 0x019E9E08 token: 100686603 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private object System.Collections.IList.get_Item(int index)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            // 0x019E9E08: STP x22, x21, [sp, #-0x30]! | stack[1152921513970610864] = ???;  stack[1152921513970610872] = ???;  //  dest_result_addr=1152921513970610864 |  dest_result_addr=1152921513970610872
            // 0x019E9E0C: STP x20, x19, [sp, #0x10]  | stack[1152921513970610880] = ???;  stack[1152921513970610888] = ???;  //  dest_result_addr=1152921513970610880 |  dest_result_addr=1152921513970610888
            // 0x019E9E10: STP x29, x30, [sp, #0x20]  | stack[1152921513970610896] = ???;  stack[1152921513970610904] = ???;  //  dest_result_addr=1152921513970610896 |  dest_result_addr=1152921513970610904
            // 0x019E9E14: ADD x29, sp, #0x20         | X29 = (1152921513970610864 + 32) = 1152921513970610896 (0x100000022E1FB2D0);
            // 0x019E9E18: ADRP x21, #0x3739000       | X21 = 57905152 (0x3739000);             
            // 0x019E9E1C: LDRB w8, [x21, #0x670]     | W8 = (bool)static_value_03739670;       
            // 0x019E9E20: MOV w19, w1                | W19 = index;//m1                        
            // 0x019E9E24: MOV x20, x0                | X20 = 1152921513970622912 (0x100000022E1FE1C0);//ML01
            // 0x019E9E28: TBNZ w8, #0, #0x19e9e44    | if (static_value_03739670 == true) goto label_0;
            // 0x019E9E2C: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x019E9E30: LDR x8, [x8, #0x440]       | X8 = 0x2B91664;                         
            // 0x019E9E34: LDR w0, [x8]               | W0 = 0x1C5D;                            
            // 0x019E9E38: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C5D, ????);     
            // 0x019E9E3C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019E9E40: STRB w8, [x21, #0x670]     | static_value_03739670 = true;            //  dest_result_addr=57906800
            label_0:
            // 0x019E9E44: LDR x8, [x20, #0x18]       | 
            // 0x019E9E48: CBNZ x8, #0x19e9ed4        | if (0x1 != 0) goto label_1;             
            if(true != 0)
            {
                goto label_1;
            }
            // 0x019E9E4C: LDR x20, [x20, #0x10]      | 
            // 0x019E9E50: CBNZ x20, #0x19e9e58       | if (this != null) goto label_2;         
            if(this != null)
            {
                goto label_2;
            }
            // 0x019E9E54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C5D, ????);     
            label_2:
            // 0x019E9E58: ADRP x9, #0x3605000        | X9 = 56643584 (0x3605000);              
            // 0x019E9E5C: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>);
            // 0x019E9E60: LDR x9, [x9, #0x308]       | X9 = 1152921504609349632;               
            // 0x019E9E64: LDR x1, [x9]               | X1 = typeof(System.Collections.IList);  
            // 0x019E9E68: LDRH w9, [x8, #0x102]      | W9 = Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x019E9E6C: CBZ x9, #0x19e9e98         | if (Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_3;
            // 0x019E9E70: LDR x10, [x8, #0x98]       | X10 = Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x019E9E74: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_4 = 0;
            // 0x019E9E78: ADD x10, x10, #8           | X10 = (Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504867053576 (0x100000000F827008);
            label_5:
            // 0x019E9E7C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x019E9E80: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IList))
            // 0x019E9E84: B.EQ #0x19e9ea8            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_4;
            // 0x019E9E88: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_4 = val_4 + 1;
            // 0x019E9E8C: ADD x10, x10, #0x10        | X10 = (1152921504867053576 + 16) = 1152921504867053592 (0x100000000F827018);
            // 0x019E9E90: CMP x11, x9                | STATE = COMPARE((0 + 1), Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x019E9E94: B.LO #0x19e9e7c            | if (0 < Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interface_offsets_count) goto label_5;
            label_3:
            // 0x019E9E98: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x019E9E9C: MOV x0, x20                | X0 = 1152921513970622912 (0x100000022E1FE1C0);//ML01
            val_4 = this;
            // 0x019E9EA0: BL #0x2776c24              | X0 = sub_2776C24( ?? this, ????);       
            // 0x019E9EA4: B #0x19e9eb8               |  goto label_6;                          
            goto label_6;
            label_4:
            // 0x019E9EA8: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x019E9EAC: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x019E9EB0: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504867016704 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x019E9EB4: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504867016704 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_6:
            // 0x019E9EB8: LDP x3, x2, [x0]           | X3 = 0x0; X2 = 0x1200000E44000000;       //  | 
            // 0x019E9EBC: MOV x0, x20                | X0 = 1152921513970622912 (0x100000022E1FE1C0);//ML01
            // 0x019E9EC0: MOV w1, w19                | W1 = index;//m1                         
            // 0x019E9EC4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019E9EC8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019E9ECC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019E9ED0: BR x3                      | goto ;                                  
            goto x3;
            label_1:
            // 0x019E9ED4: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x019E9ED8: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x019E9EDC: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_2 = null;
            // 0x019E9EE0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x019E9EE4: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x019E9EE8: LDR x8, [x8, #0x930]       | X8 = (string**)(1152921513970593616)("Wrapped ICollection<T> does not support indexer.");
            // 0x019E9EEC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x019E9EF0: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x019E9EF4: LDR x1, [x8]               | X1 = "Wrapped ICollection<T> does not support indexer.";
            // 0x019E9EF8: BL #0x1c32b48              | .ctor(message:  "Wrapped ICollection<T> does not support indexer.");
            val_2 = new System.Exception(message:  "Wrapped ICollection<T> does not support indexer.");
            // 0x019E9EFC: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x019E9F00: LDR x8, [x8, #0xac0]       | X8 = 1152921513970593792;               
            // 0x019E9F04: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x019E9F08: LDR x1, [x8]               | X1 = System.Object Newtonsoft.Json.Utilities.CollectionWrapper<System.Object>::System.Collections.IList.get_Item(int index);
            // 0x019E9F0C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x019E9F10: BL #0x19e29cc              | X0 = System.Collections.IList.get_Item(index:  773812224);
            object val_3 = System.Collections.IList.get_Item(index:  773812224);
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E9F14 VirtAddr: 0x019E9F14 -RVA: 0x019E9F14 
        // -CollectionWrapper<object>.System.Collections.IList.set_Item
        //
        //
        // Offset in libil2cpp.so: 0x019E9F14 (27172628), len: 444  VirtAddr: 0x019E9F14 RVA: 0x019E9F14 token: 100686604 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private void System.Collections.IList.set_Item(int index, object value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            var val_4;
            //  | 
            var val_5;
            // 0x019E9F14: STP x24, x23, [sp, #-0x40]! | stack[1152921513970732064] = ???;  stack[1152921513970732072] = ???;  //  dest_result_addr=1152921513970732064 |  dest_result_addr=1152921513970732072
            // 0x019E9F18: STP x22, x21, [sp, #0x10]  | stack[1152921513970732080] = ???;  stack[1152921513970732088] = ???;  //  dest_result_addr=1152921513970732080 |  dest_result_addr=1152921513970732088
            // 0x019E9F1C: STP x20, x19, [sp, #0x20]  | stack[1152921513970732096] = ???;  stack[1152921513970732104] = ???;  //  dest_result_addr=1152921513970732096 |  dest_result_addr=1152921513970732104
            // 0x019E9F20: STP x29, x30, [sp, #0x30]  | stack[1152921513970732112] = ???;  stack[1152921513970732120] = ???;  //  dest_result_addr=1152921513970732112 |  dest_result_addr=1152921513970732120
            // 0x019E9F24: ADD x29, sp, #0x30         | X29 = (1152921513970732064 + 48) = 1152921513970732112 (0x100000022E218C50);
            // 0x019E9F28: SUB sp, sp, #0x10          | SP = (1152921513970732064 - 16) = 1152921513970732048 (0x100000022E218C10);
            // 0x019E9F2C: ADRP x22, #0x3739000       | X22 = 57905152 (0x3739000);             
            // 0x019E9F30: LDRB w8, [x22, #0x671]     | W8 = (bool)static_value_03739671;       
            // 0x019E9F34: MOV x21, x3                | X21 = __RuntimeMethodHiddenParam;//m1   
            // 0x019E9F38: MOV x23, x2                | X23 = value;//m1                        
            // 0x019E9F3C: MOV w19, w1                | W19 = index;//m1                        
            // 0x019E9F40: MOV x20, x0                | X20 = 1152921513970744128 (0x100000022E21BB40);//ML01
            // 0x019E9F44: TBNZ w8, #0, #0x19e9f60    | if (static_value_03739671 == true) goto label_0;
            // 0x019E9F48: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x019E9F4C: LDR x8, [x8, #0x4b8]       | X8 = 0x2B91674;                         
            // 0x019E9F50: LDR w0, [x8]               | W0 = 0x1C61;                            
            // 0x019E9F54: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C61, ????);     
            // 0x019E9F58: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019E9F5C: STRB w8, [x22, #0x671]     | static_value_03739671 = true;            //  dest_result_addr=57906801
            label_0:
            // 0x019E9F60: LDR x8, [x20, #0x18]       | 
            // 0x019E9F64: CBNZ x8, #0x19ea07c        | if (0x1 != 0) goto label_1;             
            if(true != 0)
            {
                goto label_1;
            }
            // 0x019E9F68: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E9F6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x019E9F70: MOV x1, x23                | X1 = value;//m1                         
            // 0x019E9F74: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E9F78: LDR x2, [x8, #0x20]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 32;
            // 0x019E9F7C: LDR x8, [x2]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 32;
            // 0x019E9F80: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 32();
            // 0x019E9F84: LDR x20, [x20, #0x10]      | 
            // 0x019E9F88: CBNZ x20, #0x19e9f90       | if (this != null) goto label_2;         
            if(this != null)
            {
                goto label_2;
            }
            // 0x019E9F8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_2:
            // 0x019E9F90: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E9F94: ADRP x9, #0x3605000        | X9 = 56643584 (0x3605000);              
            // 0x019E9F98: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E9F9C: LDR x9, [x9, #0x308]       | X9 = 1152921504609349632;               
            // 0x019E9FA0: LDR x24, [x8, #8]          | X24 = __RuntimeMethodHiddenParam + 24 + 168 + 8;
            // 0x019E9FA4: LDR x21, [x9]              | X21 = typeof(System.Collections.IList); 
            // 0x019E9FA8: MOV x0, x24                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E9FAC: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 8, ????);
            // 0x019E9FB0: CBZ x23, #0x19e9ff4        | if (value == null) goto label_3;        
            if(value == null)
            {
                goto label_3;
            }
            // 0x019E9FB4: MOV x0, x23                | X0 = value;//m1                         
            // 0x019E9FB8: MOV x1, x24                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E9FBC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
            // 0x019E9FC0: MOV x22, x0                | X22 = value;//m1                        
            val_4 = value;
            // 0x019E9FC4: CBNZ x22, #0x19e9ff8       | if (value != null) goto label_4;        
            if(val_4 != null)
            {
                goto label_4;
            }
            // 0x019E9FC8: LDR x8, [x23]              | X8 = typeof(System.Object);             
            // 0x019E9FCC: MOV x1, x24                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E9FD0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x019E9FD4: ADD x8, sp, #8             | X8 = (1152921513970732048 + 8) = 1152921513970732056 (0x100000022E218C18);
            // 0x019E9FD8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x019E9FDC: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921513970720128]
            // 0x019E9FE0: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x019E9FE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019E9FE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x019E9FEC: ADD x0, sp, #8             | X0 = (1152921513970732048 + 8) = 1152921513970732056 (0x100000022E218C18);
            // 0x019E9FF0: BL #0x299a140              | 
            label_3:
            // 0x019E9FF4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_4 = 0;
            label_4:
            // 0x019E9FF8: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>);
            // 0x019E9FFC: LDRH w9, [x8, #0x102]      | W9 = Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x019EA000: CBZ x9, #0x19ea02c         | if (Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_5;
            // 0x019EA004: LDR x10, [x8, #0x98]       | X10 = Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x019EA008: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_4 = 0;
            // 0x019EA00C: ADD x10, x10, #8           | X10 = (Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504867053576 (0x100000000F827008);
            label_7:
            // 0x019EA010: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x019EA014: CMP x12, x21               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IList))
            // 0x019EA018: B.EQ #0x19ea040            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_6;
            // 0x019EA01C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_4 = val_4 + 1;
            // 0x019EA020: ADD x10, x10, #0x10        | X10 = (1152921504867053576 + 16) = 1152921504867053592 (0x100000000F827018);
            // 0x019EA024: CMP x11, x9                | STATE = COMPARE((0 + 1), Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x019EA028: B.LO #0x19ea010            | if (0 < Newtonsoft.Json.Utilities.CollectionWrapper<T>.__il2cppRuntimeField_interface_offsets_count) goto label_7;
            label_5:
            // 0x019EA02C: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x019EA030: MOV x0, x20                | X0 = 1152921513970744128 (0x100000022E21BB40);//ML01
            val_5 = this;
            // 0x019EA034: MOV x1, x21                | X1 = 1152921504609349632 (0x1000000000263000);//ML01
            // 0x019EA038: BL #0x2776c24              | X0 = sub_2776C24( ?? this, ????);       
            // 0x019EA03C: B #0x19ea050               |  goto label_8;                          
            goto label_8;
            label_6:
            // 0x019EA040: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x019EA044: ADD w9, w9, #3             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3);
            // 0x019EA048: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504867016704 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3));
            // 0x019EA04C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504867016704 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3)).272
            label_8:
            // 0x019EA050: LDP x8, x3, [x0]           | X8 = val_1; X3 = ;                       //  find_add[1152921513970720128] | 
            // 0x019EA054: MOV x0, x20                | X0 = 1152921513970744128 (0x100000022E21BB40);//ML01
            // 0x019EA058: MOV w1, w19                | W1 = index;//m1                         
            // 0x019EA05C: MOV x2, x22                | X2 = 0 (0x0);//ML01                     
            // 0x019EA060: BLR x8                     | X0 = val_1();                           
            // 0x019EA064: SUB sp, x29, #0x30         | SP = (1152921513970732112 - 48) = 1152921513970732064 (0x100000022E218C20);
            // 0x019EA068: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x019EA06C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x019EA070: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x019EA074: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x019EA078: RET                        |  return;                                
            return;
            label_1:
            // 0x019EA07C: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x019EA080: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x019EA084: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_3 = null;
            // 0x019EA088: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x019EA08C: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x019EA090: LDR x8, [x8, #0x930]       | X8 = (string**)(1152921513970593616)("Wrapped ICollection<T> does not support indexer.");
            // 0x019EA094: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x019EA098: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x019EA09C: LDR x1, [x8]               | X1 = "Wrapped ICollection<T> does not support indexer.";
            // 0x019EA0A0: BL #0x1c32b48              | .ctor(message:  "Wrapped ICollection<T> does not support indexer.");
            val_3 = new System.Exception(message:  "Wrapped ICollection<T> does not support indexer.");
            // 0x019EA0A4: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
            // 0x019EA0A8: LDR x8, [x8, #0x550]       | X8 = 1152921513970719104;               
            // 0x019EA0AC: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x019EA0B0: LDR x1, [x8]               | X1 = System.Void Newtonsoft.Json.Utilities.CollectionWrapper<System.Object>::System.Collections.IList.set_Item(int index, object value);
            // 0x019EA0B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x019EA0B8: BL #0x19e29cc              | System.Collections.IList.set_Item(index:  773937536, value:  0);
            System.Collections.IList.set_Item(index:  773937536, value:  0);
            // 0x019EA0BC: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x019EA0C0: ADD x0, sp, #8             | X0 = (1152921513970732048 + 8) = 1152921513970732056 (0x100000022E218C18);
            // 0x019EA0C4: BL #0x299a140              | 
            // 0x019EA0C8: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x019EA0CC: BL #0x980800               | X0 = sub_980800( ?? typeof(System.Exception), ????);
        
        }
        // Generic instance method:
        //
        // file offset: 0x019EA0D0 VirtAddr: 0x019EA0D0 -RVA: 0x019EA0D0 
        // -CollectionWrapper<object>.System.Collections.ICollection.CopyTo
        //
        //
        // Offset in libil2cpp.so: 0x019EA0D0 (27173072), len: 200  VirtAddr: 0x019EA0D0 RVA: 0x019EA0D0 token: 100686605 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private void System.Collections.ICollection.CopyTo(System.Array array, int arrayIndex)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x019EA0D0: STP x22, x21, [sp, #-0x30]! | stack[1152921513970852272] = ???;  stack[1152921513970852280] = ???;  //  dest_result_addr=1152921513970852272 |  dest_result_addr=1152921513970852280
            // 0x019EA0D4: STP x20, x19, [sp, #0x10]  | stack[1152921513970852288] = ???;  stack[1152921513970852296] = ???;  //  dest_result_addr=1152921513970852288 |  dest_result_addr=1152921513970852296
            // 0x019EA0D8: STP x29, x30, [sp, #0x20]  | stack[1152921513970852304] = ???;  stack[1152921513970852312] = ???;  //  dest_result_addr=1152921513970852304 |  dest_result_addr=1152921513970852312
            // 0x019EA0DC: ADD x29, sp, #0x20         | X29 = (1152921513970852272 + 32) = 1152921513970852304 (0x100000022E2361D0);
            // 0x019EA0E0: SUB sp, sp, #0x10          | SP = (1152921513970852272 - 16) = 1152921513970852256 (0x100000022E2361A0);
            // 0x019EA0E4: MOV x22, x3                | X22 = __RuntimeMethodHiddenParam;//m1   
            // 0x019EA0E8: MOV w19, w2                | W19 = arrayIndex;//m1                   
            // 0x019EA0EC: MOV x21, x1                | X21 = array;//m1                        
            // 0x019EA0F0: MOV x20, x0                | X20 = 1152921513970864320 (0x100000022E2390C0);//ML01
            // 0x019EA0F4: CBNZ x20, #0x19ea0fc       | if (this != null) goto label_0;         
            if(this != null)
            {
                goto label_0;
            }
            // 0x019EA0F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x019EA0FC: LDR x8, [x22, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019EA100: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019EA104: LDR x22, [x8, #0x58]       | X22 = __RuntimeMethodHiddenParam + 24 + 168 + 88;
            // 0x019EA108: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 88;//m1
            // 0x019EA10C: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 88, ????);
            // 0x019EA110: CBZ x21, #0x19ea154        | if (array == null) goto label_1;        
            if(array == null)
            {
                goto label_1;
            }
            // 0x019EA114: MOV x0, x21                | X0 = array;//m1                         
            // 0x019EA118: MOV x1, x22                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 88;//m1
            // 0x019EA11C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? array, ????);      
            // 0x019EA120: MOV x1, x0                 | X1 = array;//m1                         
            // 0x019EA124: CBNZ x1, #0x19ea158        | if (array != null) goto label_2;        
            if(array != null)
            {
                goto label_2;
            }
            // 0x019EA128: LDR x8, [x21]              | X8 = typeof(System.Array);              
            // 0x019EA12C: MOV x1, x22                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 88;//m1
            // 0x019EA130: LDR x0, [x8, #0x30]        | X0 = System.Array.__il2cppRuntimeField_element_class;
            // 0x019EA134: ADD x8, sp, #8             | X8 = (1152921513970852256 + 8) = 1152921513970852264 (0x100000022E2361A8);
            // 0x019EA138: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Array.__il2cppRuntimeField_element_class, ????);
            // 0x019EA13C: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921513970840320]
            // 0x019EA140: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x019EA144: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019EA148: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x019EA14C: ADD x0, sp, #8             | X0 = (1152921513970852256 + 8) = 1152921513970852264 (0x100000022E2361A8);
            // 0x019EA150: BL #0x299a140              | 
            label_1:
            // 0x019EA154: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            label_2:
            // 0x019EA158: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>);
            // 0x019EA15C: MOV x0, x20                | X0 = 1152921513970864320 (0x100000022E2390C0);//ML01
            // 0x019EA160: MOV w2, w19                | W2 = arrayIndex;//m1                    
            // 0x019EA164: LDR x9, [x8, #0x310]       | X9 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>).__il2cppRuntimeField_310;
            // 0x019EA168: LDR x3, [x8, #0x318]       | X3 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>).__il2cppRuntimeField_318;
            // 0x019EA16C: BLR x9                     | X0 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>).__il2cppRuntimeField_310();
            // 0x019EA170: SUB sp, x29, #0x20         | SP = (1152921513970852304 - 32) = 1152921513970852272 (0x100000022E2361B0);
            // 0x019EA174: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019EA178: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019EA17C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019EA180: RET                        |  return;                                
            return;
            // 0x019EA184: MOV x19, x0                | 
            // 0x019EA188: ADD x0, sp, #8             | 
            // 0x019EA18C: BL #0x299a140              | 
            // 0x019EA190: MOV x0, x19                | 
            // 0x019EA194: BL #0x980800               | 
        
        }
        // Generic instance method:
        //
        // file offset: 0x019EA198 VirtAddr: 0x019EA198 -RVA: 0x019EA198 
        // -CollectionWrapper<object>.System.Collections.ICollection.get_IsSynchronized
        //
        //
        // Offset in libil2cpp.so: 0x019EA198 (27173272), len: 8  VirtAddr: 0x019EA198 RVA: 0x019EA198 token: 100686606 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private bool System.Collections.ICollection.get_IsSynchronized()
        {
            //
            // Disasemble & Code
            // 0x019EA198: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x019EA19C: RET                        |  return (System.Boolean)false;          
            return (bool)0;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x019EA1A0 VirtAddr: 0x019EA1A0 -RVA: 0x019EA1A0 
        // -CollectionWrapper<object>.System.Collections.ICollection.get_SyncRoot
        //
        //
        // Offset in libil2cpp.so: 0x019EA1A0 (27173280), len: 128  VirtAddr: 0x019EA1A0 RVA: 0x019EA1A0 token: 100686607 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private object System.Collections.ICollection.get_SyncRoot()
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            // 0x019EA1A0: STP x20, x19, [sp, #-0x20]! | stack[1152921513971084480] = ???;  stack[1152921513971084488] = ???;  //  dest_result_addr=1152921513971084480 |  dest_result_addr=1152921513971084488
            // 0x019EA1A4: STP x29, x30, [sp, #0x10]  | stack[1152921513971084496] = ???;  stack[1152921513971084504] = ???;  //  dest_result_addr=1152921513971084496 |  dest_result_addr=1152921513971084504
            // 0x019EA1A8: ADD x29, sp, #0x10         | X29 = (1152921513971084480 + 16) = 1152921513971084496 (0x100000022E26ECD0);
            // 0x019EA1AC: ADRP x20, #0x3739000       | X20 = 57905152 (0x3739000);             
            // 0x019EA1B0: LDRB w8, [x20, #0x672]     | W8 = (bool)static_value_03739672;       
            // 0x019EA1B4: MOV x19, x0                | X19 = 1152921513971096512 (0x100000022E271BC0);//ML01
            // 0x019EA1B8: TBNZ w8, #0, #0x19ea1d4    | if (static_value_03739672 == true) goto label_0;
            // 0x019EA1BC: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
            // 0x019EA1C0: LDR x8, [x8, #0xe68]       | X8 = 0x2B91658;                         
            // 0x019EA1C4: LDR w0, [x8]               | W0 = 0x1C5A;                            
            // 0x019EA1C8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C5A, ????);     
            // 0x019EA1CC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019EA1D0: STRB w8, [x20, #0x672]     | static_value_03739672 = true;            //  dest_result_addr=57906802
            label_0:
            // 0x019EA1D4: LDR x0, [x19, #0x20]!      | 
            // 0x019EA1D8: CBNZ x0, #0x19ea214        | if (0x1C5A != 0) goto label_1;          
            if(7258 != 0)
            {
                goto label_1;
            }
            // 0x019EA1DC: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x019EA1E0: LDR x8, [x8, #0xf90]       | X8 = 1152921504606900224;               
            // 0x019EA1E4: LDR x0, [x8]               | X0 = typeof(System.Object);             
            object val_1 = null;
            // 0x019EA1E8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Object), ????);
            // 0x019EA1EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019EA1F0: MOV x20, x0                | X20 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x019EA1F4: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x019EA1F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            object val_2 = 0;
            // 0x019EA1FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x019EA200: MOV x1, x19                | X1 = 1152921513971096544 (0x100000022E271BE0);//ML01
            // 0x019EA204: MOV x2, x20                | X2 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x019EA208: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x019EA20C: BL #0x1b65ab0              | X0 = System.Threading.Interlocked.CompareExchange(location1: ref  object val_2 = 0, value:  1152921513971096544, comparand:  val_1);
            object val_3 = System.Threading.Interlocked.CompareExchange(location1: ref  val_2, value:  1152921513971096544, comparand:  val_1);
            // 0x019EA210: LDR x0, [x19]              |  //  find_add[1152921513971096512]
            label_1:
            // 0x019EA214: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x019EA218: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x019EA21C: RET                        |  return (System.Object)val_3;           
            return val_3;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x019EA220 VirtAddr: 0x019EA220 -RVA: 0x019EA220 
        // -CollectionWrapper<object>.VerifyValueType
        //
        //
        // Offset in libil2cpp.so: 0x019EA220 (27173408), len: 540  VirtAddr: 0x019EA220 RVA: 0x019EA220 token: 100686608 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private static void VerifyValueType(object value)
        {
            //
            // Disasemble & Code
            // 0x019EA220: STP x22, x21, [sp, #-0x30]! | stack[1152921513971218224] = ???;  stack[1152921513971218232] = ???;  //  dest_result_addr=1152921513971218224 |  dest_result_addr=1152921513971218232
            // 0x019EA224: STP x20, x19, [sp, #0x10]  | stack[1152921513971218240] = ???;  stack[1152921513971218248] = ???;  //  dest_result_addr=1152921513971218240 |  dest_result_addr=1152921513971218248
            // 0x019EA228: STP x29, x30, [sp, #0x20]  | stack[1152921513971218256] = ???;  stack[1152921513971218264] = ???;  //  dest_result_addr=1152921513971218256 |  dest_result_addr=1152921513971218264
            // 0x019EA22C: ADD x29, sp, #0x20         | X29 = (1152921513971218224 + 32) = 1152921513971218256 (0x100000022E28F750);
            // 0x019EA230: ADRP x21, #0x3739000       | X21 = 57905152 (0x3739000);             
            // 0x019EA234: LDRB w8, [x21, #0x673]     | W8 = (bool)static_value_03739673;       
            // 0x019EA238: MOV x20, x2                | X20 = X2;//m1                           
            // 0x019EA23C: MOV x19, x1                | X19 = __RuntimeMethodHiddenParam;//m1   
            // 0x019EA240: TBNZ w8, #0, #0x19ea25c    | if (static_value_03739673 == true) goto label_0;
            // 0x019EA244: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
            // 0x019EA248: LDR x8, [x8, #0x780]       | X8 = 0x2B91678;                         
            // 0x019EA24C: LDR w0, [x8]               | W0 = 0x1C62;                            
            // 0x019EA250: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C62, ????);     
            // 0x019EA254: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019EA258: STRB w8, [x21, #0x673]     | static_value_03739673 = true;            //  dest_result_addr=57906803
            label_0:
            // 0x019EA25C: LDR x21, [x20, #0x18]      | X21 = X2 + 24;                          
            // 0x019EA260: MOV x0, x21                | X0 = X2 + 24;//m1                       
            // 0x019EA264: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 24, ????);    
            // 0x019EA268: LDR x8, [x21, #0xa8]       | X8 = X2 + 24 + 168;                     
            // 0x019EA26C: LDR x21, [x20, #0x18]      | X21 = X2 + 24;                          
            // 0x019EA270: LDR x8, [x8, #0x40]        | X8 = X2 + 24 + 168 + 64;                
            // 0x019EA274: MOV x0, x21                | X0 = X2 + 24;//m1                       
            // 0x019EA278: LDR x22, [x8]              | X22 = X2 + 24 + 168 + 64;               
            // 0x019EA27C: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 24, ????);    
            // 0x019EA280: LDR x8, [x21, #0xa8]       | X8 = X2 + 24 + 168;                     
            // 0x019EA284: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x019EA288: MOV x1, x19                | X1 = __RuntimeMethodHiddenParam;//m1    
            // 0x019EA28C: LDR x2, [x8, #0x40]        | X2 = X2 + 24 + 168 + 64;                
            // 0x019EA290: BLR x22                    | X0 = X2 + 24 + 168 + 64();              
            // 0x019EA294: AND w8, w0, #1             | W8 = (0 & 1) = 0 (0x00000000);          
            // 0x019EA298: TBZ w8, #0, #0x19ea2ac     | if ((0x0 & 0x1) == 0) goto label_1;     
            if((0 & 1) == 0)
            {
                goto label_1;
            }
            // 0x019EA29C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019EA2A0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019EA2A4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019EA2A8: RET                        |  return;                                
            return;
            label_1:
            // 0x019EA2AC: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x019EA2B0: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x019EA2B4: MOV x21, x20               | X21 = X2;//m1                           
            // 0x019EA2B8: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x019EA2BC: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x019EA2C0: TBZ w8, #0, #0x19ea2d0     | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x019EA2C4: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x019EA2C8: CBNZ w8, #0x19ea2d0        | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x019EA2CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_3:
            // 0x019EA2D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x019EA2D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019EA2D8: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_1 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x019EA2DC: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x019EA2E0: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x019EA2E4: MOV x22, x0                | X22 = val_1;//m1                        
            // 0x019EA2E8: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
            // 0x019EA2EC: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x019EA2F0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x019EA2F4: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x019EA2F8: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x019EA2FC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x019EA300: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x019EA304: CBNZ x20, #0x19ea30c       | if ( != null) goto label_4;             
            if(null != null)
            {
                goto label_4;
            }
            // 0x019EA308: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_4:
            // 0x019EA30C: CBZ x19, #0x19ea330        | if (__RuntimeMethodHiddenParam == 0) goto label_6;
            if(__RuntimeMethodHiddenParam == 0)
            {
                goto label_6;
            }
            // 0x019EA310: LDR x8, [x20]              | X8 = ;                                  
            // 0x019EA314: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam;//m1    
            // 0x019EA318: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x019EA31C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? __RuntimeMethodHiddenParam, ????);
            // 0x019EA320: CBNZ x0, #0x19ea330        | if (__RuntimeMethodHiddenParam != 0) goto label_6;
            if(__RuntimeMethodHiddenParam != 0)
            {
                goto label_6;
            }
            // 0x019EA324: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? __RuntimeMethodHiddenParam, ????);
            // 0x019EA328: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019EA32C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? __RuntimeMethodHiddenParam, ????);
            label_6:
            // 0x019EA330: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x019EA334: CBNZ w8, #0x19ea344        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_7;
            // 0x019EA338: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? __RuntimeMethodHiddenParam, ????);
            // 0x019EA33C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019EA340: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? __RuntimeMethodHiddenParam, ????);
            label_7:
            // 0x019EA344: STR x19, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = __RuntimeMethodHiddenParam;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = __RuntimeMethodHiddenParam;
            // 0x019EA348: LDR x19, [x21, #0x18]      | X19 = X2 + 24;                          
            // 0x019EA34C: MOV x0, x19                | X0 = X2 + 24;//m1                       
            // 0x019EA350: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 24, ????);    
            // 0x019EA354: ADRP x9, #0x3620000        | X9 = 56754176 (0x3620000);              
            // 0x019EA358: LDR x8, [x19, #0xa8]       | X8 = X2 + 24 + 168;                     
            // 0x019EA35C: LDR x9, [x9, #0x340]       | X9 = 1152921504609562624;               
            // 0x019EA360: LDR x19, [x8, #0x68]       | X19 = X2 + 24 + 168 + 104;              
            // 0x019EA364: LDR x0, [x9]               | X0 = typeof(System.Type);               
            // 0x019EA368: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x019EA36C: TBZ w8, #0, #0x19ea37c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x019EA370: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x019EA374: CBNZ w8, #0x19ea37c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x019EA378: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_9:
            // 0x019EA37C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x019EA380: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x019EA384: MOV x1, x19                | X1 = X2 + 24 + 168 + 104;//m1           
            // 0x019EA388: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_2 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x019EA38C: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x019EA390: CBZ x19, #0x19ea3b4        | if (val_2 == null) goto label_11;       
            if(val_2 == null)
            {
                goto label_11;
            }
            // 0x019EA394: LDR x8, [x20]              | X8 = ;                                  
            // 0x019EA398: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x019EA39C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x019EA3A0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x019EA3A4: CBNZ x0, #0x19ea3b4        | if (val_2 != null) goto label_11;       
            if(val_2 != null)
            {
                goto label_11;
            }
            // 0x019EA3A8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
            // 0x019EA3AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019EA3B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_11:
            // 0x019EA3B4: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x019EA3B8: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x019EA3BC: B.HI #0x19ea3cc            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_12;
            // 0x019EA3C0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x019EA3C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019EA3C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_12:
            // 0x019EA3CC: STR x19, [x20, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_2;  //  dest_result_addr=1152921504954501304
            typeof(System.Object[]).__il2cppRuntimeField_28 = val_2;
            // 0x019EA3D0: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x019EA3D4: LDR x8, [x8, #0xbe8]       | X8 = (string**)(1152921513971200896)("The value \'{0}\' is not of type \'{1}\' and cannot be used in this generic collection.");
            // 0x019EA3D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x019EA3DC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x019EA3E0: MOV x2, x22                | X2 = val_1;//m1                         
            // 0x019EA3E4: LDR x1, [x8]               | X1 = "The value \'{0}\' is not of type \'{1}\' and cannot be used in this generic collection.";
            // 0x019EA3E8: MOV x3, x20                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x019EA3EC: BL #0x2900ac4              | X0 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  0, provider:  "The value \'{0}\' is not of type \'{1}\' and cannot be used in this generic collection.", args:  val_1);
            string val_3 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  0, provider:  "The value \'{0}\' is not of type \'{1}\' and cannot be used in this generic collection.", args:  val_1);
            // 0x019EA3F0: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x019EA3F4: LDR x8, [x8, #0x1b8]       | X8 = 1152921504651841536;               
            // 0x019EA3F8: MOV x19, x0                | X19 = val_3;//m1                        
            // 0x019EA3FC: LDR x8, [x8]               | X8 = typeof(System.ArgumentException);  
            // 0x019EA400: MOV x0, x8                 | X0 = 1152921504651841536 (0x1000000002AE9000);//ML01
            System.ArgumentException val_4 = null;
            // 0x019EA404: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentException), ????);
            // 0x019EA408: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
            // 0x019EA40C: LDR x8, [x8, #0x400]       | X8 = (string**)(1152921511191786896)("value");
            // 0x019EA410: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x019EA414: MOV x1, x19                | X1 = val_3;//m1                         
            // 0x019EA418: MOV x20, x0                | X20 = 1152921504651841536 (0x1000000002AE9000);//ML01
            // 0x019EA41C: LDR x2, [x8]               | X2 = "value";                           
            // 0x019EA420: BL #0x18b3ee4              | .ctor(message:  val_3, paramName:  "value");
            val_4 = new System.ArgumentException(message:  val_3, paramName:  "value");
            // 0x019EA424: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x019EA428: LDR x8, [x8, #0x3e0]       | X8 = 1152921513971205248;               
            // 0x019EA42C: MOV x0, x20                | X0 = 1152921504651841536 (0x1000000002AE9000);//ML01
            // 0x019EA430: LDR x1, [x8]               | X1 = static System.Void Newtonsoft.Json.Utilities.CollectionWrapper<System.Object>::VerifyValueType(object value);
            // 0x019EA434: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentException), ????);
            // 0x019EA438: BL #0x19e29cc              | Newtonsoft.Json.Utilities.CollectionWrapper<System.Object>.VerifyValueType(value:  val_4);
            Newtonsoft.Json.Utilities.CollectionWrapper<System.Object>.VerifyValueType(value:  val_4);
        
        }
        // Generic instance method:
        //
        // file offset: 0x019EA43C VirtAddr: 0x019EA43C -RVA: 0x019EA43C 
        // -CollectionWrapper<object>.IsCompatibleObject
        //
        //
        // Offset in libil2cpp.so: 0x019EA43C (27173948), len: 312  VirtAddr: 0x019EA43C RVA: 0x019EA43C token: 100686609 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private static bool IsCompatibleObject(object value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            // 0x019EA43C: STP x22, x21, [sp, #-0x30]! | stack[1152921513971358896] = ???;  stack[1152921513971358904] = ???;  //  dest_result_addr=1152921513971358896 |  dest_result_addr=1152921513971358904
            // 0x019EA440: STP x20, x19, [sp, #0x10]  | stack[1152921513971358912] = ???;  stack[1152921513971358920] = ???;  //  dest_result_addr=1152921513971358912 |  dest_result_addr=1152921513971358920
            // 0x019EA444: STP x29, x30, [sp, #0x20]  | stack[1152921513971358928] = ???;  stack[1152921513971358936] = ???;  //  dest_result_addr=1152921513971358928 |  dest_result_addr=1152921513971358936
            // 0x019EA448: ADD x29, sp, #0x20         | X29 = (1152921513971358896 + 32) = 1152921513971358928 (0x100000022E2B1CD0);
            // 0x019EA44C: ADRP x21, #0x3739000       | X21 = 57905152 (0x3739000);             
            // 0x019EA450: LDRB w8, [x21, #0x674]     | W8 = (bool)static_value_03739674;       
            // 0x019EA454: MOV x19, x2                | X19 = X2;//m1                           
            val_5 = X2;
            // 0x019EA458: MOV x20, x1                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x019EA45C: TBNZ w8, #0, #0x19ea478    | if (static_value_03739674 == true) goto label_0;
            // 0x019EA460: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x019EA464: LDR x8, [x8, #0x868]       | X8 = 0x2B91650;                         
            // 0x019EA468: LDR w0, [x8]               | W0 = 0x1C58;                            
            // 0x019EA46C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C58, ????);     
            // 0x019EA470: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019EA474: STRB w8, [x21, #0x674]     | static_value_03739674 = true;            //  dest_result_addr=57906804
            label_0:
            // 0x019EA478: LDR x21, [x19, #0x18]      | X21 = X2 + 24;                          
            // 0x019EA47C: MOV x0, x21                | X0 = X2 + 24;//m1                       
            // 0x019EA480: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 24, ????);    
            // 0x019EA484: LDR x8, [x21, #0xa8]       | X8 = X2 + 24 + 168;                     
            // 0x019EA488: LDR x21, [x8, #8]          | X21 = X2 + 24 + 168 + 8;                
            val_6 = mem[X2 + 24 + 168 + 8];
            val_6 = X2 + 24 + 168 + 8;
            // 0x019EA48C: MOV x0, x21                | X0 = X2 + 24 + 168 + 8;//m1             
            // 0x019EA490: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 24 + 168 + 8, ????);
            // 0x019EA494: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam;//m1    
            // 0x019EA498: MOV x1, x21                | X1 = X2 + 24 + 168 + 8;//m1             
            // 0x019EA49C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? __RuntimeMethodHiddenParam, ????);
            // 0x019EA4A0: CBNZ x0, #0x19ea558        | if (__RuntimeMethodHiddenParam != 0) goto label_6;
            if(__RuntimeMethodHiddenParam != 0)
            {
                goto label_6;
            }
            // 0x019EA4A4: CBNZ x20, #0x19ea560       | if (__RuntimeMethodHiddenParam != 0) goto label_9;
            if(__RuntimeMethodHiddenParam != 0)
            {
                goto label_9;
            }
            // 0x019EA4A8: LDR x20, [x19, #0x18]      | X20 = X2 + 24;                          
            // 0x019EA4AC: MOV x0, x20                | X0 = X2 + 24;//m1                       
            // 0x019EA4B0: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 24, ????);    
            // 0x019EA4B4: ADRP x21, #0x3620000       | X21 = 56754176 (0x3620000);             
            // 0x019EA4B8: LDR x8, [x20, #0xa8]       | X8 = X2 + 24 + 168;                     
            // 0x019EA4BC: LDR x21, [x21, #0x340]     | X21 = 1152921504609562624;              
            val_6 = 1152921504609562624;
            // 0x019EA4C0: LDR x20, [x8, #0x68]       | X20 = X2 + 24 + 168 + 104;              
            // 0x019EA4C4: LDR x0, [x21]              | X0 = typeof(System.Type);               
            // 0x019EA4C8: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x019EA4CC: TBZ w8, #0, #0x19ea4dc     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x019EA4D0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x019EA4D4: CBNZ w8, #0x19ea4dc        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x019EA4D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x019EA4DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x019EA4E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x019EA4E4: MOV x1, x20                | X1 = X2 + 24 + 168 + 104;//m1           
            // 0x019EA4E8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x019EA4EC: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x019EA4F0: CBNZ x20, #0x19ea4f8       | if (val_1 != null) goto label_5;        
            if(val_1 != null)
            {
                goto label_5;
            }
            // 0x019EA4F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_5:
            // 0x019EA4F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019EA4FC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x019EA500: BL #0x1b6d264              | X0 = val_1.get_IsValueType();           
            bool val_2 = val_1.IsValueType;
            // 0x019EA504: TBZ w0, #0, #0x19ea558     | if (val_2 == false) goto label_6;       
            if(val_2 == false)
            {
                goto label_6;
            }
            // 0x019EA508: LDR x19, [x19, #0x18]      | X19 = X2 + 24;                          
            // 0x019EA50C: MOV x0, x19                | X0 = X2 + 24;//m1                       
            // 0x019EA510: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 24, ????);    
            // 0x019EA514: LDR x8, [x19, #0xa8]       | X8 = X2 + 24 + 168;                     
            // 0x019EA518: LDR x0, [x21]              | X0 = typeof(System.Type);               
            // 0x019EA51C: LDR x19, [x8, #0x68]       | X19 = X2 + 24 + 168 + 104;              
            val_5 = mem[X2 + 24 + 168 + 104];
            val_5 = X2 + 24 + 168 + 104;
            // 0x019EA520: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x019EA524: TBZ w8, #0, #0x19ea534     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x019EA528: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x019EA52C: CBNZ w8, #0x19ea534        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x019EA530: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_8:
            // 0x019EA534: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x019EA538: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x019EA53C: MOV x1, x19                | X1 = X2 + 24 + 168 + 104;//m1           
            // 0x019EA540: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x019EA544: MOV x1, x0                 | X1 = val_3;//m1                         
            // 0x019EA548: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x019EA54C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x019EA550: BL #0x28fe064              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.IsNullableType(t:  0);
            bool val_4 = Newtonsoft.Json.Utilities.ReflectionUtils.IsNullableType(t:  0);
            // 0x019EA554: TBZ w0, #0, #0x19ea560     | if (val_4 == false) goto label_9;       
            if(val_4 == false)
            {
                goto label_9;
            }
            label_6:
            // 0x019EA558: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_7 = 1;
            // 0x019EA55C: B #0x19ea564               |  goto label_10;                         
            goto label_10;
            label_9:
            // 0x019EA560: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_7 = 0;
            label_10:
            // 0x019EA564: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019EA568: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019EA56C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019EA570: RET                        |  return (System.Boolean)false;          
            return (bool)val_7;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x019EA574 VirtAddr: 0x019EA574 -RVA: 0x019EA574 
        // -CollectionWrapper<object>.get_UnderlyingCollection
        //
        //
        // Offset in libil2cpp.so: 0x019EA574 (27174260), len: 20  VirtAddr: 0x019EA574 RVA: 0x019EA574 token: 100686610 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public object get_UnderlyingCollection()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x019EA574: MOV x8, x0                 | X8 = 1152921513971495232 (0x100000022E2D3140);//ML01
            // 0x019EA578: LDR x0, [x8, #0x18]        | 
            // 0x019EA57C: CBNZ x0, #0x19ea584        | if (this != null) goto label_0;         
            if(this != null)
            {
                goto label_0;
            }
            // 0x019EA580: LDR x0, [x8, #0x10]        | 
            label_0:
            // 0x019EA584: RET                        |  return (System.Object)this;            
            return (object)this;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
    
    }

}
