using UnityEngine;

namespace ILRuntime.Runtime.Enviorment
{
    public interface CrossBindingAdaptorType
    {
        // Properties
        public abstract ILRuntime.Runtime.Intepreter.ILTypeInstance ILInstance { get; }
        
        // Methods
        public abstract ILRuntime.Runtime.Intepreter.ILTypeInstance get_ILInstance(); // 0
    
    }

}
