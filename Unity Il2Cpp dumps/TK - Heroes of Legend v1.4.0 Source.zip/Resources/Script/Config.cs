using UnityEngine;
internal class DeflateManager.Config
{
    // Fields
    internal int GoodLength; //  0x00000010
    internal int MaxLazy; //  0x00000014
    internal int NiceLength; //  0x00000018
    internal int MaxChainLength; //  0x0000001C
    internal Pathfinding.Ionic.Zlib.DeflateFlavor Flavor; //  0x00000020
    private static readonly Pathfinding.Ionic.Zlib.DeflateManager.Config[] Table; // static_offset: 0x00000000
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x026C57A8 (40654760), len: 84  VirtAddr: 0x026C57A8 RVA: 0x026C57A8 token: 100663756 methodIndex: 21312 delegateWrapperIndex: 0 methodInvoker: 0
    private DeflateManager.Config(int goodLength, int maxLazy, int niceLength, int maxChainLength, Pathfinding.Ionic.Zlib.DeflateFlavor flavor)
    {
        //
        // Disasemble & Code
        // 0x026C57A8: STP x24, x23, [sp, #-0x40]! | stack[1152921509704600208] = ???;  stack[1152921509704600216] = ???;  //  dest_result_addr=1152921509704600208 |  dest_result_addr=1152921509704600216
        // 0x026C57AC: STP x22, x21, [sp, #0x10]  | stack[1152921509704600224] = ???;  stack[1152921509704600232] = ???;  //  dest_result_addr=1152921509704600224 |  dest_result_addr=1152921509704600232
        // 0x026C57B0: STP x20, x19, [sp, #0x20]  | stack[1152921509704600240] = ???;  stack[1152921509704600248] = ???;  //  dest_result_addr=1152921509704600240 |  dest_result_addr=1152921509704600248
        // 0x026C57B4: STP x29, x30, [sp, #0x30]  | stack[1152921509704600256] = ???;  stack[1152921509704600264] = ???;  //  dest_result_addr=1152921509704600256 |  dest_result_addr=1152921509704600264
        // 0x026C57B8: ADD x29, sp, #0x30         | X29 = (1152921509704600208 + 48) = 1152921509704600256 (0x100000012FD98AC0);
        // 0x026C57BC: MOV w23, w1                | W23 = goodLength;//m1                   
        // 0x026C57C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C57C4: MOV w19, w5                | W19 = flavor;//m1                       
        // 0x026C57C8: MOV w20, w4                | W20 = maxChainLength;//m1               
        // 0x026C57CC: MOV w21, w3                | W21 = niceLength;//m1                   
        // 0x026C57D0: MOV w22, w2                | W22 = maxLazy;//m1                      
        // 0x026C57D4: MOV x24, x0                | X24 = 1152921509704612272 (0x100000012FD9B9B0);//ML01
        // 0x026C57D8: BL #0x16f59f0              | this..ctor();                           
        // 0x026C57DC: STP w23, w22, [x24, #0x10] | this.GoodLength = goodLength;  this.MaxLazy = maxLazy;  //  dest_result_addr=1152921509704612288 |  dest_result_addr=1152921509704612292
        this.GoodLength = goodLength;
        this.MaxLazy = maxLazy;
        // 0x026C57E0: STP w21, w20, [x24, #0x18] | this.NiceLength = niceLength;  this.MaxChainLength = maxChainLength;  //  dest_result_addr=1152921509704612296 |  dest_result_addr=1152921509704612300
        this.NiceLength = niceLength;
        this.MaxChainLength = maxChainLength;
        // 0x026C57E4: STR w19, [x24, #0x20]      | this.Flavor = flavor;                    //  dest_result_addr=1152921509704612304
        this.Flavor = flavor;
        // 0x026C57E8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x026C57EC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x026C57F0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x026C57F4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x026C57F8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x026C57FC (40654844), len: 1164  VirtAddr: 0x026C57FC RVA: 0x026C57FC token: 100663757 methodIndex: 21313 delegateWrapperIndex: 0 methodInvoker: 0
    private static DeflateManager.Config()
    {
        //
        // Disasemble & Code
        // 0x026C57FC: STP x22, x21, [sp, #-0x30]! | stack[1152921509704720416] = ???;  stack[1152921509704720424] = ???;  //  dest_result_addr=1152921509704720416 |  dest_result_addr=1152921509704720424
        // 0x026C5800: STP x20, x19, [sp, #0x10]  | stack[1152921509704720432] = ???;  stack[1152921509704720440] = ???;  //  dest_result_addr=1152921509704720432 |  dest_result_addr=1152921509704720440
        // 0x026C5804: STP x29, x30, [sp, #0x20]  | stack[1152921509704720448] = ???;  stack[1152921509704720456] = ???;  //  dest_result_addr=1152921509704720448 |  dest_result_addr=1152921509704720456
        // 0x026C5808: ADD x29, sp, #0x20         | X29 = (1152921509704720416 + 32) = 1152921509704720448 (0x100000012FDB6040);
        // 0x026C580C: ADRP x19, #0x3742000       | X19 = 57942016 (0x3742000);             
        // 0x026C5810: LDRB w8, [x19, #0x5d1]     | W8 = (bool)static_value_037425D1;       
        // 0x026C5814: TBNZ w8, #0, #0x26c5830    | if (static_value_037425D1 == true) goto label_0;
        // 0x026C5818: ADRP x8, #0x3678000        | X8 = 57114624 (0x3678000);              
        // 0x026C581C: LDR x8, [x8, #0xc8]        | X8 = 0x2B92734;                         
        // 0x026C5820: LDR w0, [x8]               | W0 = 0x2092;                            
        // 0x026C5824: BL #0x2782188              | X0 = sub_2782188( ?? 0x2092, ????);     
        // 0x026C5828: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x026C582C: STRB w8, [x19, #0x5d1]     | static_value_037425D1 = true;            //  dest_result_addr=57943505
        label_0:
        // 0x026C5830: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
        // 0x026C5834: LDR x8, [x8, #0x940]       | X8 = 1152921509704704368;               
        // 0x026C5838: LDR x19, [x8]              | X19 = typeof(DeflateManager.Config[]);  
        // 0x026C583C: MOV x0, x19                | X0 = 1152921509704704368 (0x100000012FDB2170);//ML01
        // 0x026C5840: BL #0x277461c              | X0 = sub_277461C( ?? typeof(DeflateManager.Config[]), ????);
        // 0x026C5844: MOVZ w1, #0xa              | W1 = 10 (0xA);//ML01                    
        // 0x026C5848: MOV x0, x19                | X0 = 1152921509704704368 (0x100000012FDB2170);//ML01
        // 0x026C584C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(DeflateManager.Config[]), ????);
        // 0x026C5850: ADRP x21, #0x3648000       | X21 = 56918016 (0x3648000);             
        // 0x026C5854: LDR x21, [x21, #0xb58]     | X21 = 1152921504752533504;              
        // 0x026C5858: MOV x19, x0                | X19 = 1152921509704704368 (0x100000012FDB2170);//ML01
        // 0x026C585C: LDR x8, [x21]              | X8 = typeof(DeflateManager.Config);     
        // 0x026C5860: MOV x0, x8                 | X0 = 1152921504752533504 (0x1000000008AF0000);//ML01
        object val_1 = null;
        // 0x026C5864: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5868: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C586C: MOV x20, x0                | X20 = 1152921504752533504 (0x1000000008AF0000);//ML01
        // 0x026C5870: BL #0x16f59f0              | .ctor();                                
        val_1 = new System.Object();
        // 0x026C5874: MOVI v0.2d, #0000000000000000 | V0 = 0 (0x0);//ML01                     
        // 0x026C5878: STR q0, [x20, #0x10]       | typeof(DeflateManager.Config).__il2cppRuntimeField_10 = 0x0;  //  dest_result_addr=1152921504752533520
        typeof(DeflateManager.Config).__il2cppRuntimeField_10 = 0;
        // 0x026C587C: STR wzr, [x20, #0x20]      | typeof(DeflateManager.Config).__il2cppRuntimeField_20 = 0x0;  //  dest_result_addr=1152921504752533536
        typeof(DeflateManager.Config).__il2cppRuntimeField_20 = 0;
        // 0x026C5880: CBNZ x19, #0x26c5888       | if ( != null) goto label_1;             
        if(null != null)
        {
            goto label_1;
        }
        // 0x026C5884: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_1:
        // 0x026C5888: CBZ x20, #0x26c58ac        | if ( == 0) goto label_3;                
        if(null == 0)
        {
            goto label_3;
        }
        // 0x026C588C: LDR x8, [x19]              | X8 = ;                                  
        // 0x026C5890: MOV x0, x20                | X0 = 1152921504752533504 (0x1000000008AF0000);//ML01
        // 0x026C5894: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x026C5898: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(DeflateManager.Config), ????);
        // 0x026C589C: CBNZ x0, #0x26c58ac        | if ( != 0) goto label_3;                
        if(null != 0)
        {
            goto label_3;
        }
        // 0x026C58A0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C58A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C58A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(DeflateManager.Config), ????);
        label_3:
        // 0x026C58AC: LDR w8, [x19, #0x18]       | W8 = DeflateManager.Config[].__il2cppRuntimeField_namespaze;
        // 0x026C58B0: CBNZ w8, #0x26c58c0        | if (DeflateManager.Config[].__il2cppRuntimeField_namespaze != 0) goto label_4;
        // 0x026C58B4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C58B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C58BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(DeflateManager.Config), ????);
        label_4:
        // 0x026C58C0: STR x20, [x19, #0x20]      | typeof(DeflateManager.Config[]).__il2cppRuntimeField_20 = typeof(DeflateManager.Config);  //  dest_result_addr=1152921509704704400
        typeof(DeflateManager.Config[]).__il2cppRuntimeField_20 = val_1;
        // 0x026C58C4: LDR x0, [x21]              | X0 = typeof(DeflateManager.Config);     
        object val_2 = null;
        // 0x026C58C8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(DeflateManager.Config), ????);
        // 0x026C58CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C58D0: MOV x20, x0                | X20 = 1152921504752533504 (0x1000000008AF0000);//ML01
        // 0x026C58D4: BL #0x16f59f0              | .ctor();                                
        val_2 = new System.Object();
        // 0x026C58D8: ADRP x8, #0x2ad1000        | X8 = 44896256 (0x2AD1000);              
        // 0x026C58DC: LDR q0, [x8, #0x1e0]       | Q0 = ;                                  
        // 0x026C58E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x026C58E4: STR w8, [x20, #0x20]       | typeof(DeflateManager.Config).__il2cppRuntimeField_20 = 0x1;  //  dest_result_addr=1152921504752533536
        typeof(DeflateManager.Config).__il2cppRuntimeField_20 = 1;
        // 0x026C58E8: STR q0, [x20, #0x10]       | typeof(DeflateManager.Config).__il2cppRuntimeField_10 = ;  //  dest_result_addr=1152921504752533520
        typeof(DeflateManager.Config).__il2cppRuntimeField_10 = ;
        // 0x026C58EC: CBZ x20, #0x26c5910        | if ( == 0) goto label_6;                
        if(null == 0)
        {
            goto label_6;
        }
        // 0x026C58F0: LDR x8, [x19]              | X8 = ;                                  
        // 0x026C58F4: MOV x0, x20                | X0 = 1152921504752533504 (0x1000000008AF0000);//ML01
        // 0x026C58F8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x026C58FC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5900: CBNZ x0, #0x26c5910        | if ( != 0) goto label_6;                
        if(null != 0)
        {
            goto label_6;
        }
        // 0x026C5904: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5908: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C590C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(DeflateManager.Config), ????);
        label_6:
        // 0x026C5910: LDR w8, [x19, #0x18]       | W8 = DeflateManager.Config[].__il2cppRuntimeField_namespaze;
        // 0x026C5914: CMP w8, #1                 | STATE = COMPARE(DeflateManager.Config[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x026C5918: B.HI #0x26c5928            | if (DeflateManager.Config[].__il2cppRuntimeField_namespaze > 0x1) goto label_7;
        // 0x026C591C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5920: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5924: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(DeflateManager.Config), ????);
        label_7:
        // 0x026C5928: STR x20, [x19, #0x28]      | typeof(DeflateManager.Config[]).__il2cppRuntimeField_28 = typeof(DeflateManager.Config);  //  dest_result_addr=1152921509704704408
        typeof(DeflateManager.Config[]).__il2cppRuntimeField_28 = val_2;
        // 0x026C592C: LDR x0, [x21]              | X0 = typeof(DeflateManager.Config);     
        object val_3 = null;
        // 0x026C5930: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5934: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5938: MOV x20, x0                | X20 = 1152921504752533504 (0x1000000008AF0000);//ML01
        // 0x026C593C: BL #0x16f59f0              | .ctor();                                
        val_3 = new System.Object();
        // 0x026C5940: ADRP x8, #0x2ad1000        | X8 = 44896256 (0x2AD1000);              
        // 0x026C5944: LDR q0, [x8, #0x1f0]       | Q0 = ;                                  
        // 0x026C5948: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x026C594C: STR w8, [x20, #0x20]       | typeof(DeflateManager.Config).__il2cppRuntimeField_20 = 0x1;  //  dest_result_addr=1152921504752533536
        typeof(DeflateManager.Config).__il2cppRuntimeField_20 = 1;
        // 0x026C5950: STR q0, [x20, #0x10]       | typeof(DeflateManager.Config).__il2cppRuntimeField_10 = ;  //  dest_result_addr=1152921504752533520
        typeof(DeflateManager.Config).__il2cppRuntimeField_10 = ;
        // 0x026C5954: CBZ x20, #0x26c5978        | if ( == 0) goto label_9;                
        if(null == 0)
        {
            goto label_9;
        }
        // 0x026C5958: LDR x8, [x19]              | X8 = ;                                  
        // 0x026C595C: MOV x0, x20                | X0 = 1152921504752533504 (0x1000000008AF0000);//ML01
        // 0x026C5960: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x026C5964: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5968: CBNZ x0, #0x26c5978        | if ( != 0) goto label_9;                
        if(null != 0)
        {
            goto label_9;
        }
        // 0x026C596C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5970: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5974: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(DeflateManager.Config), ????);
        label_9:
        // 0x026C5978: LDR w8, [x19, #0x18]       | W8 = DeflateManager.Config[].__il2cppRuntimeField_namespaze;
        // 0x026C597C: CMP w8, #2                 | STATE = COMPARE(DeflateManager.Config[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x026C5980: B.HI #0x26c5990            | if (DeflateManager.Config[].__il2cppRuntimeField_namespaze > 0x2) goto label_10;
        // 0x026C5984: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5988: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C598C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(DeflateManager.Config), ????);
        label_10:
        // 0x026C5990: STR x20, [x19, #0x30]      | typeof(DeflateManager.Config[]).__il2cppRuntimeField_30 = typeof(DeflateManager.Config);  //  dest_result_addr=1152921509704704416
        typeof(DeflateManager.Config[]).__il2cppRuntimeField_30 = val_3;
        // 0x026C5994: LDR x0, [x21]              | X0 = typeof(DeflateManager.Config);     
        object val_4 = null;
        // 0x026C5998: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(DeflateManager.Config), ????);
        // 0x026C599C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C59A0: MOV x20, x0                | X20 = 1152921504752533504 (0x1000000008AF0000);//ML01
        // 0x026C59A4: BL #0x16f59f0              | .ctor();                                
        val_4 = new System.Object();
        // 0x026C59A8: ADRP x8, #0x2ad1000        | X8 = 44896256 (0x2AD1000);              
        // 0x026C59AC: LDR q0, [x8, #0x200]       | Q0 = ;                                  
        // 0x026C59B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x026C59B4: STR w8, [x20, #0x20]       | typeof(DeflateManager.Config).__il2cppRuntimeField_20 = 0x1;  //  dest_result_addr=1152921504752533536
        typeof(DeflateManager.Config).__il2cppRuntimeField_20 = 1;
        // 0x026C59B8: STR q0, [x20, #0x10]       | typeof(DeflateManager.Config).__il2cppRuntimeField_10 = ;  //  dest_result_addr=1152921504752533520
        typeof(DeflateManager.Config).__il2cppRuntimeField_10 = ;
        // 0x026C59BC: CBZ x20, #0x26c59e0        | if ( == 0) goto label_12;               
        if(null == 0)
        {
            goto label_12;
        }
        // 0x026C59C0: LDR x8, [x19]              | X8 = ;                                  
        // 0x026C59C4: MOV x0, x20                | X0 = 1152921504752533504 (0x1000000008AF0000);//ML01
        // 0x026C59C8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x026C59CC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(DeflateManager.Config), ????);
        // 0x026C59D0: CBNZ x0, #0x26c59e0        | if ( != 0) goto label_12;               
        if(null != 0)
        {
            goto label_12;
        }
        // 0x026C59D4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C59D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C59DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(DeflateManager.Config), ????);
        label_12:
        // 0x026C59E0: LDR w8, [x19, #0x18]       | W8 = DeflateManager.Config[].__il2cppRuntimeField_namespaze;
        // 0x026C59E4: CMP w8, #3                 | STATE = COMPARE(DeflateManager.Config[].__il2cppRuntimeField_namespaze, 0x3)
        // 0x026C59E8: B.HI #0x26c59f8            | if (DeflateManager.Config[].__il2cppRuntimeField_namespaze > 0x3) goto label_13;
        // 0x026C59EC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C59F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C59F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(DeflateManager.Config), ????);
        label_13:
        // 0x026C59F8: STR x20, [x19, #0x38]      | typeof(DeflateManager.Config[]).__il2cppRuntimeField_38 = typeof(DeflateManager.Config);  //  dest_result_addr=1152921509704704424
        typeof(DeflateManager.Config[]).__il2cppRuntimeField_38 = val_4;
        // 0x026C59FC: LDR x0, [x21]              | X0 = typeof(DeflateManager.Config);     
        object val_5 = null;
        // 0x026C5A00: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5A04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5A08: MOV x20, x0                | X20 = 1152921504752533504 (0x1000000008AF0000);//ML01
        // 0x026C5A0C: BL #0x16f59f0              | .ctor();                                
        val_5 = new System.Object();
        // 0x026C5A10: ADRP x8, #0x2ad1000        | X8 = 44896256 (0x2AD1000);              
        // 0x026C5A14: LDR q0, [x8, #0x210]       | Q0 = ;                                  
        // 0x026C5A18: ORR w8, wzr, #2            | W8 = 2(0x2);                            
        // 0x026C5A1C: STR w8, [x20, #0x20]       | typeof(DeflateManager.Config).__il2cppRuntimeField_20 = 0x2;  //  dest_result_addr=1152921504752533536
        typeof(DeflateManager.Config).__il2cppRuntimeField_20 = 2;
        // 0x026C5A20: STR q0, [x20, #0x10]       | typeof(DeflateManager.Config).__il2cppRuntimeField_10 = ;  //  dest_result_addr=1152921504752533520
        typeof(DeflateManager.Config).__il2cppRuntimeField_10 = ;
        // 0x026C5A24: CBZ x20, #0x26c5a48        | if ( == 0) goto label_15;               
        if(null == 0)
        {
            goto label_15;
        }
        // 0x026C5A28: LDR x8, [x19]              | X8 = ;                                  
        // 0x026C5A2C: MOV x0, x20                | X0 = 1152921504752533504 (0x1000000008AF0000);//ML01
        // 0x026C5A30: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x026C5A34: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5A38: CBNZ x0, #0x26c5a48        | if ( != 0) goto label_15;               
        if(null != 0)
        {
            goto label_15;
        }
        // 0x026C5A3C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5A40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5A44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(DeflateManager.Config), ????);
        label_15:
        // 0x026C5A48: LDR w8, [x19, #0x18]       | W8 = DeflateManager.Config[].__il2cppRuntimeField_namespaze;
        // 0x026C5A4C: CMP w8, #4                 | STATE = COMPARE(DeflateManager.Config[].__il2cppRuntimeField_namespaze, 0x4)
        // 0x026C5A50: B.HI #0x26c5a60            | if (DeflateManager.Config[].__il2cppRuntimeField_namespaze > 0x4) goto label_16;
        // 0x026C5A54: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5A58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5A5C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(DeflateManager.Config), ????);
        label_16:
        // 0x026C5A60: STR x20, [x19, #0x40]      | typeof(DeflateManager.Config[]).__il2cppRuntimeField_40 = typeof(DeflateManager.Config);  //  dest_result_addr=1152921509704704432
        typeof(DeflateManager.Config[]).__il2cppRuntimeField_40 = val_5;
        // 0x026C5A64: LDR x0, [x21]              | X0 = typeof(DeflateManager.Config);     
        object val_6 = null;
        // 0x026C5A68: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5A6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5A70: MOV x20, x0                | X20 = 1152921504752533504 (0x1000000008AF0000);//ML01
        // 0x026C5A74: BL #0x16f59f0              | .ctor();                                
        val_6 = new System.Object();
        // 0x026C5A78: ADRP x8, #0x2ad1000        | X8 = 44896256 (0x2AD1000);              
        // 0x026C5A7C: LDR q0, [x8, #0x220]       | Q0 = ;                                  
        // 0x026C5A80: ORR w8, wzr, #2            | W8 = 2(0x2);                            
        // 0x026C5A84: STR w8, [x20, #0x20]       | typeof(DeflateManager.Config).__il2cppRuntimeField_20 = 0x2;  //  dest_result_addr=1152921504752533536
        typeof(DeflateManager.Config).__il2cppRuntimeField_20 = 2;
        // 0x026C5A88: STR q0, [x20, #0x10]       | typeof(DeflateManager.Config).__il2cppRuntimeField_10 = ;  //  dest_result_addr=1152921504752533520
        typeof(DeflateManager.Config).__il2cppRuntimeField_10 = ;
        // 0x026C5A8C: CBZ x20, #0x26c5ab0        | if ( == 0) goto label_18;               
        if(null == 0)
        {
            goto label_18;
        }
        // 0x026C5A90: LDR x8, [x19]              | X8 = ;                                  
        // 0x026C5A94: MOV x0, x20                | X0 = 1152921504752533504 (0x1000000008AF0000);//ML01
        // 0x026C5A98: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x026C5A9C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5AA0: CBNZ x0, #0x26c5ab0        | if ( != 0) goto label_18;               
        if(null != 0)
        {
            goto label_18;
        }
        // 0x026C5AA4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5AA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5AAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(DeflateManager.Config), ????);
        label_18:
        // 0x026C5AB0: LDR w8, [x19, #0x18]       | W8 = DeflateManager.Config[].__il2cppRuntimeField_namespaze;
        // 0x026C5AB4: CMP w8, #5                 | STATE = COMPARE(DeflateManager.Config[].__il2cppRuntimeField_namespaze, 0x5)
        // 0x026C5AB8: B.HI #0x26c5ac8            | if (DeflateManager.Config[].__il2cppRuntimeField_namespaze > 0x5) goto label_19;
        // 0x026C5ABC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5AC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5AC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(DeflateManager.Config), ????);
        label_19:
        // 0x026C5AC8: STR x20, [x19, #0x48]      | typeof(DeflateManager.Config[]).__il2cppRuntimeField_48 = typeof(DeflateManager.Config);  //  dest_result_addr=1152921509704704440
        typeof(DeflateManager.Config[]).__il2cppRuntimeField_48 = val_6;
        // 0x026C5ACC: LDR x0, [x21]              | X0 = typeof(DeflateManager.Config);     
        object val_7 = null;
        // 0x026C5AD0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5AD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5AD8: MOV x20, x0                | X20 = 1152921504752533504 (0x1000000008AF0000);//ML01
        // 0x026C5ADC: BL #0x16f59f0              | .ctor();                                
        val_7 = new System.Object();
        // 0x026C5AE0: ADRP x8, #0x2ad1000        | X8 = 44896256 (0x2AD1000);              
        // 0x026C5AE4: LDR q0, [x8, #0x230]       | Q0 = ;                                  
        // 0x026C5AE8: ORR w8, wzr, #2            | W8 = 2(0x2);                            
        // 0x026C5AEC: STR w8, [x20, #0x20]       | typeof(DeflateManager.Config).__il2cppRuntimeField_20 = 0x2;  //  dest_result_addr=1152921504752533536
        typeof(DeflateManager.Config).__il2cppRuntimeField_20 = 2;
        // 0x026C5AF0: STR q0, [x20, #0x10]       | typeof(DeflateManager.Config).__il2cppRuntimeField_10 = ;  //  dest_result_addr=1152921504752533520
        typeof(DeflateManager.Config).__il2cppRuntimeField_10 = ;
        // 0x026C5AF4: CBZ x20, #0x26c5b18        | if ( == 0) goto label_21;               
        if(null == 0)
        {
            goto label_21;
        }
        // 0x026C5AF8: LDR x8, [x19]              | X8 = ;                                  
        // 0x026C5AFC: MOV x0, x20                | X0 = 1152921504752533504 (0x1000000008AF0000);//ML01
        // 0x026C5B00: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x026C5B04: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5B08: CBNZ x0, #0x26c5b18        | if ( != 0) goto label_21;               
        if(null != 0)
        {
            goto label_21;
        }
        // 0x026C5B0C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5B10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5B14: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(DeflateManager.Config), ????);
        label_21:
        // 0x026C5B18: LDR w8, [x19, #0x18]       | W8 = DeflateManager.Config[].__il2cppRuntimeField_namespaze;
        // 0x026C5B1C: CMP w8, #6                 | STATE = COMPARE(DeflateManager.Config[].__il2cppRuntimeField_namespaze, 0x6)
        // 0x026C5B20: B.HI #0x26c5b30            | if (DeflateManager.Config[].__il2cppRuntimeField_namespaze > 0x6) goto label_22;
        // 0x026C5B24: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5B28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5B2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(DeflateManager.Config), ????);
        label_22:
        // 0x026C5B30: STR x20, [x19, #0x50]      | typeof(DeflateManager.Config[]).__il2cppRuntimeField_50 = typeof(DeflateManager.Config);  //  dest_result_addr=1152921509704704448
        typeof(DeflateManager.Config[]).__il2cppRuntimeField_50 = val_7;
        // 0x026C5B34: LDR x0, [x21]              | X0 = typeof(DeflateManager.Config);     
        object val_8 = null;
        // 0x026C5B38: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5B3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5B40: MOV x20, x0                | X20 = 1152921504752533504 (0x1000000008AF0000);//ML01
        // 0x026C5B44: BL #0x16f59f0              | .ctor();                                
        val_8 = new System.Object();
        // 0x026C5B48: ADRP x8, #0x2ad1000        | X8 = 44896256 (0x2AD1000);              
        // 0x026C5B4C: LDR q0, [x8, #0x240]       | Q0 = ;                                  
        // 0x026C5B50: ORR w8, wzr, #2            | W8 = 2(0x2);                            
        // 0x026C5B54: STR w8, [x20, #0x20]       | typeof(DeflateManager.Config).__il2cppRuntimeField_20 = 0x2;  //  dest_result_addr=1152921504752533536
        typeof(DeflateManager.Config).__il2cppRuntimeField_20 = 2;
        // 0x026C5B58: STR q0, [x20, #0x10]       | typeof(DeflateManager.Config).__il2cppRuntimeField_10 = ;  //  dest_result_addr=1152921504752533520
        typeof(DeflateManager.Config).__il2cppRuntimeField_10 = ;
        // 0x026C5B5C: CBZ x20, #0x26c5b80        | if ( == 0) goto label_24;               
        if(null == 0)
        {
            goto label_24;
        }
        // 0x026C5B60: LDR x8, [x19]              | X8 = ;                                  
        // 0x026C5B64: MOV x0, x20                | X0 = 1152921504752533504 (0x1000000008AF0000);//ML01
        // 0x026C5B68: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x026C5B6C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5B70: CBNZ x0, #0x26c5b80        | if ( != 0) goto label_24;               
        if(null != 0)
        {
            goto label_24;
        }
        // 0x026C5B74: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5B78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5B7C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(DeflateManager.Config), ????);
        label_24:
        // 0x026C5B80: LDR w8, [x19, #0x18]       | W8 = DeflateManager.Config[].__il2cppRuntimeField_namespaze;
        // 0x026C5B84: CMP w8, #7                 | STATE = COMPARE(DeflateManager.Config[].__il2cppRuntimeField_namespaze, 0x7)
        // 0x026C5B88: B.HI #0x26c5b98            | if (DeflateManager.Config[].__il2cppRuntimeField_namespaze > 0x7) goto label_25;
        // 0x026C5B8C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5B90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5B94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(DeflateManager.Config), ????);
        label_25:
        // 0x026C5B98: STR x20, [x19, #0x58]      | typeof(DeflateManager.Config[]).__il2cppRuntimeField_58 = typeof(DeflateManager.Config);  //  dest_result_addr=1152921509704704456
        typeof(DeflateManager.Config[]).__il2cppRuntimeField_58 = val_8;
        // 0x026C5B9C: LDR x0, [x21]              | X0 = typeof(DeflateManager.Config);     
        object val_9 = null;
        // 0x026C5BA0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5BA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5BA8: MOV x20, x0                | X20 = 1152921504752533504 (0x1000000008AF0000);//ML01
        // 0x026C5BAC: BL #0x16f59f0              | .ctor();                                
        val_9 = new System.Object();
        // 0x026C5BB0: ADRP x8, #0x2ad1000        | X8 = 44896256 (0x2AD1000);              
        // 0x026C5BB4: LDR q0, [x8, #0x250]       | Q0 = ;                                  
        // 0x026C5BB8: ORR w8, wzr, #2            | W8 = 2(0x2);                            
        // 0x026C5BBC: STR w8, [x20, #0x20]       | typeof(DeflateManager.Config).__il2cppRuntimeField_20 = 0x2;  //  dest_result_addr=1152921504752533536
        typeof(DeflateManager.Config).__il2cppRuntimeField_20 = 2;
        // 0x026C5BC0: STR q0, [x20, #0x10]       | typeof(DeflateManager.Config).__il2cppRuntimeField_10 = ;  //  dest_result_addr=1152921504752533520
        typeof(DeflateManager.Config).__il2cppRuntimeField_10 = ;
        // 0x026C5BC4: CBZ x20, #0x26c5be8        | if ( == 0) goto label_27;               
        if(null == 0)
        {
            goto label_27;
        }
        // 0x026C5BC8: LDR x8, [x19]              | X8 = ;                                  
        // 0x026C5BCC: MOV x0, x20                | X0 = 1152921504752533504 (0x1000000008AF0000);//ML01
        // 0x026C5BD0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x026C5BD4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5BD8: CBNZ x0, #0x26c5be8        | if ( != 0) goto label_27;               
        if(null != 0)
        {
            goto label_27;
        }
        // 0x026C5BDC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5BE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5BE4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(DeflateManager.Config), ????);
        label_27:
        // 0x026C5BE8: LDR w8, [x19, #0x18]       | W8 = DeflateManager.Config[].__il2cppRuntimeField_namespaze;
        // 0x026C5BEC: CMP w8, #8                 | STATE = COMPARE(DeflateManager.Config[].__il2cppRuntimeField_namespaze, 0x8)
        // 0x026C5BF0: B.HI #0x26c5c00            | if (DeflateManager.Config[].__il2cppRuntimeField_namespaze > 0x8) goto label_28;
        // 0x026C5BF4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5BF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5BFC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(DeflateManager.Config), ????);
        label_28:
        // 0x026C5C00: STR x20, [x19, #0x60]      | typeof(DeflateManager.Config[]).__il2cppRuntimeField_60 = typeof(DeflateManager.Config);  //  dest_result_addr=1152921509704704464
        typeof(DeflateManager.Config[]).__il2cppRuntimeField_60 = val_9;
        // 0x026C5C04: LDR x0, [x21]              | X0 = typeof(DeflateManager.Config);     
        object val_10 = null;
        // 0x026C5C08: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5C0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5C10: MOV x20, x0                | X20 = 1152921504752533504 (0x1000000008AF0000);//ML01
        // 0x026C5C14: BL #0x16f59f0              | .ctor();                                
        val_10 = new System.Object();
        // 0x026C5C18: ADRP x8, #0x2ad1000        | X8 = 44896256 (0x2AD1000);              
        // 0x026C5C1C: LDR q0, [x8, #0x260]       | Q0 = ;                                  
        // 0x026C5C20: ORR w8, wzr, #2            | W8 = 2(0x2);                            
        // 0x026C5C24: STR w8, [x20, #0x20]       | typeof(DeflateManager.Config).__il2cppRuntimeField_20 = 0x2;  //  dest_result_addr=1152921504752533536
        typeof(DeflateManager.Config).__il2cppRuntimeField_20 = 2;
        // 0x026C5C28: STR q0, [x20, #0x10]       | typeof(DeflateManager.Config).__il2cppRuntimeField_10 = ;  //  dest_result_addr=1152921504752533520
        typeof(DeflateManager.Config).__il2cppRuntimeField_10 = ;
        // 0x026C5C2C: CBZ x20, #0x26c5c50        | if ( == 0) goto label_30;               
        if(null == 0)
        {
            goto label_30;
        }
        // 0x026C5C30: LDR x8, [x19]              | X8 = ;                                  
        // 0x026C5C34: MOV x0, x20                | X0 = 1152921504752533504 (0x1000000008AF0000);//ML01
        // 0x026C5C38: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x026C5C3C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5C40: CBNZ x0, #0x26c5c50        | if ( != 0) goto label_30;               
        if(null != 0)
        {
            goto label_30;
        }
        // 0x026C5C44: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5C48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5C4C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(DeflateManager.Config), ????);
        label_30:
        // 0x026C5C50: LDR w8, [x19, #0x18]       | W8 = DeflateManager.Config[].__il2cppRuntimeField_namespaze;
        // 0x026C5C54: CMP w8, #9                 | STATE = COMPARE(DeflateManager.Config[].__il2cppRuntimeField_namespaze, 0x9)
        // 0x026C5C58: B.HI #0x26c5c68            | if (DeflateManager.Config[].__il2cppRuntimeField_namespaze > 0x9) goto label_31;
        // 0x026C5C5C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5C60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5C64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(DeflateManager.Config), ????);
        label_31:
        // 0x026C5C68: STR x20, [x19, #0x68]      | typeof(DeflateManager.Config[]).__il2cppRuntimeField_68 = typeof(DeflateManager.Config);  //  dest_result_addr=1152921509704704472
        typeof(DeflateManager.Config[]).__il2cppRuntimeField_68 = val_10;
        // 0x026C5C6C: LDR x8, [x21]              | X8 = typeof(DeflateManager.Config);     
        // 0x026C5C70: LDR x8, [x8, #0xa0]        | X8 = DeflateManager.Config.__il2cppRuntimeField_static_fields;
        // 0x026C5C74: STR x19, [x8]              | DeflateManager.Config.Table = typeof(DeflateManager.Config[]);  //  dest_result_addr=1152921504752537600
        DeflateManager.Config.Table = null;
        // 0x026C5C78: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x026C5C7C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x026C5C80: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x026C5C84: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x026C5C88 (40656008), len: 160  VirtAddr: 0x026C5C88 RVA: 0x026C5C88 token: 100663758 methodIndex: 21314 delegateWrapperIndex: 0 methodInvoker: 0
    public static Pathfinding.Ionic.Zlib.DeflateManager.Config Lookup(Pathfinding.Ionic.Zlib.CompressionLevel level)
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        // 0x026C5C88: STP x22, x21, [sp, #-0x30]! | stack[1152921509704836512] = ???;  stack[1152921509704836520] = ???;  //  dest_result_addr=1152921509704836512 |  dest_result_addr=1152921509704836520
        // 0x026C5C8C: STP x20, x19, [sp, #0x10]  | stack[1152921509704836528] = ???;  stack[1152921509704836536] = ???;  //  dest_result_addr=1152921509704836528 |  dest_result_addr=1152921509704836536
        // 0x026C5C90: STP x29, x30, [sp, #0x20]  | stack[1152921509704836544] = ???;  stack[1152921509704836552] = ???;  //  dest_result_addr=1152921509704836544 |  dest_result_addr=1152921509704836552
        // 0x026C5C94: ADD x29, sp, #0x20         | X29 = (1152921509704836512 + 32) = 1152921509704836544 (0x100000012FDD25C0);
        // 0x026C5C98: ADRP x20, #0x3742000       | X20 = 57942016 (0x3742000);             
        // 0x026C5C9C: LDRB w8, [x20, #0x5d2]     | W8 = (bool)static_value_037425D2;       
        // 0x026C5CA0: MOV w19, w1                | W19 = W1;//m1                           
        // 0x026C5CA4: TBNZ w8, #0, #0x26c5cc0    | if (static_value_037425D2 == true) goto label_0;
        // 0x026C5CA8: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
        // 0x026C5CAC: LDR x8, [x8, #0xe8]        | X8 = 0x2B92738;                         
        // 0x026C5CB0: LDR w0, [x8]               | W0 = 0x2093;                            
        // 0x026C5CB4: BL #0x2782188              | X0 = sub_2782188( ?? 0x2093, ????);     
        // 0x026C5CB8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x026C5CBC: STRB w8, [x20, #0x5d2]     | static_value_037425D2 = true;            //  dest_result_addr=57943506
        label_0:
        // 0x026C5CC0: ADRP x20, #0x3648000       | X20 = 56918016 (0x3648000);             
        // 0x026C5CC4: LDR x20, [x20, #0xb58]     | X20 = 1152921504752533504;              
        // 0x026C5CC8: LDR x0, [x20]              | X0 = typeof(DeflateManager.Config);     
        val_2 = null;
        // 0x026C5CCC: LDRB w8, [x0, #0x10a]      | W8 = DeflateManager.Config.__il2cppRuntimeField_10A;
        // 0x026C5CD0: TBZ w8, #0, #0x26c5ce4     | if (DeflateManager.Config.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x026C5CD4: LDR w8, [x0, #0xbc]        | W8 = DeflateManager.Config.__il2cppRuntimeField_cctor_finished;
        // 0x026C5CD8: CBNZ w8, #0x26c5ce4        | if (DeflateManager.Config.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x026C5CDC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5CE0: LDR x0, [x20]              | X0 = typeof(DeflateManager.Config);     
        val_2 = null;
        label_2:
        // 0x026C5CE4: LDR x8, [x0, #0xa0]        | X8 = DeflateManager.Config.__il2cppRuntimeField_static_fields;
        // 0x026C5CE8: LDR x20, [x8]              | X20 = DeflateManager.Config.Table;      
        // 0x026C5CEC: CBNZ x20, #0x26c5cf4       | if (DeflateManager.Config.Table != null) goto label_3;
        if(DeflateManager.Config.Table != null)
        {
            goto label_3;
        }
        // 0x026C5CF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(DeflateManager.Config), ????);
        label_3:
        // 0x026C5CF4: LDR w8, [x20, #0x18]       | W8 = DeflateManager.Config.Table.Length;
        // 0x026C5CF8: SXTW x21, w19              | X21 = (long)(int)(W1);                  
        // 0x026C5CFC: CMP w8, w19                | STATE = COMPARE(DeflateManager.Config.Table.Length, W1)
        // 0x026C5D00: B.HI #0x26c5d10            | if (DeflateManager.Config.Table.Length > W1) goto label_4;
        if(DeflateManager.Config.Table.Length > W1)
        {
            goto label_4;
        }
        // 0x026C5D04: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(DeflateManager.Config), ????);
        // 0x026C5D08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C5D0C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(DeflateManager.Config), ????);
        label_4:
        // 0x026C5D10: ADD x8, x20, x21, lsl #3   | X8 = (DeflateManager.Config.Table + ((long)(int)(W1)) << 3);
        DeflateManager.Config[] val_1 = DeflateManager.Config.Table + (((long)(int)(W1)) << 3);
        // 0x026C5D14: LDR x0, [x8, #0x20]        | X0 = (DeflateManager.Config.Table + ((long)(int)(W1)) << 3) + 32; //  not_find_field!2:32
        // 0x026C5D18: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x026C5D1C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x026C5D20: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x026C5D24: RET                        |  return (DeflateManager.Config)(DeflateManager.Config.Table + ((long)(int)(W1)) << 3) + 32;
        return (DeflateManager.Config)(DeflateManager.Config.Table + ((long)(int)(W1)) << 3) + 32;
        //  |  // // {name=val_0, type=DeflateManager.Config, size=8, nGRN=0 }
    
    }

}
