using UnityEngine;
public enum Mixin.Argument
{
    // Fields
    name = 0
    ,fileName = 1
    ,fullName = 2
    ,stream = 3
    ,type = 4
    ,method = 5
    ,field = 6
    ,parameters = 7
    ,module = 8
    ,modifierType = 9
    ,eventType = 10
    ,fieldType = 11
    ,declaringType = 12
    ,returnType = 13
    ,propertyType = 14
    ,interfaceType = 15
    

}
