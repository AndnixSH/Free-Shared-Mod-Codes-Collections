using UnityEngine;

namespace ProtoBuf.Serializers
{
    internal sealed class BlobSerializer : IProtoSerializer
    {
        // Fields
        private static readonly System.Type expectedType; // static_offset: 0x00000000
        private readonly bool overwriteList; //  0x00000010
        
        // Properties
        private bool ProtoBuf.Serializers.IProtoSerializer.RequiresOldValue { get; }
        private bool ProtoBuf.Serializers.IProtoSerializer.ReturnsValue { get; }
        public System.Type ExpectedType { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x029838B0 (43530416), len: 48  VirtAddr: 0x029838B0 RVA: 0x029838B0 token: 100689800 methodIndex: 53999 delegateWrapperIndex: 0 methodInvoker: 0
        public BlobSerializer(ProtoBuf.Meta.TypeModel model, bool overwriteList)
        {
            //
            // Disasemble & Code
            // 0x029838B0: STP x20, x19, [sp, #-0x20]! | stack[1152921514433448448] = ???;  stack[1152921514433448456] = ???;  //  dest_result_addr=1152921514433448448 |  dest_result_addr=1152921514433448456
            // 0x029838B4: STP x29, x30, [sp, #0x10]  | stack[1152921514433448464] = ???;  stack[1152921514433448472] = ???;  //  dest_result_addr=1152921514433448464 |  dest_result_addr=1152921514433448472
            // 0x029838B8: ADD x29, sp, #0x10         | X29 = (1152921514433448448 + 16) = 1152921514433448464 (0x1000000249B60A10);
            // 0x029838BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029838C0: MOV w19, w2                | W19 = overwriteList;//m1                
            // 0x029838C4: MOV x20, x0                | X20 = 1152921514433460480 (0x1000000249B63900);//ML01
            // 0x029838C8: BL #0x16f59f0              | this..ctor();                           
            // 0x029838CC: AND w8, w19, #1            | W8 = (overwriteList & 1);               
            bool val_1 = overwriteList;
            // 0x029838D0: STRB w8, [x20, #0x10]      | this.overwriteList = (overwriteList & 1);  //  dest_result_addr=1152921514433460496
            this.overwriteList = val_1;
            // 0x029838D4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x029838D8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x029838DC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0298B338 (43561784), len: 104  VirtAddr: 0x0298B338 RVA: 0x0298B338 token: 100689801 methodIndex: 54000 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Type get_ExpectedType()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x0298B338: STP x20, x19, [sp, #-0x20]! | stack[1152921514433564544] = ???;  stack[1152921514433564552] = ???;  //  dest_result_addr=1152921514433564544 |  dest_result_addr=1152921514433564552
            // 0x0298B33C: STP x29, x30, [sp, #0x10]  | stack[1152921514433564560] = ???;  stack[1152921514433564568] = ???;  //  dest_result_addr=1152921514433564560 |  dest_result_addr=1152921514433564568
            // 0x0298B340: ADD x29, sp, #0x10         | X29 = (1152921514433564544 + 16) = 1152921514433564560 (0x1000000249B7CF90);
            // 0x0298B344: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x0298B348: LDRB w8, [x19, #0xf13]     | W8 = (bool)static_value_037B8F13;       
            // 0x0298B34C: TBNZ w8, #0, #0x298b368    | if (static_value_037B8F13 == true) goto label_0;
            // 0x0298B350: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x0298B354: LDR x8, [x8, #0x400]       | X8 = 0x2B8F644;                         
            // 0x0298B358: LDR w0, [x8]               | W0 = 0x1455;                            
            // 0x0298B35C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1455, ????);     
            // 0x0298B360: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0298B364: STRB w8, [x19, #0xf13]     | static_value_037B8F13 = true;            //  dest_result_addr=58429203
            label_0:
            // 0x0298B368: ADRP x19, #0x35f4000       | X19 = 56573952 (0x35F4000);             
            // 0x0298B36C: LDR x19, [x19, #0x8a0]     | X19 = 1152921504884801536;              
            // 0x0298B370: LDR x0, [x19]              | X0 = typeof(ProtoBuf.Serializers.BlobSerializer);
            val_1 = null;
            // 0x0298B374: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.Serializers.BlobSerializer.__il2cppRuntimeField_10A;
            // 0x0298B378: TBZ w8, #0, #0x298b38c     | if (ProtoBuf.Serializers.BlobSerializer.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0298B37C: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.Serializers.BlobSerializer.__il2cppRuntimeField_cctor_finished;
            // 0x0298B380: CBNZ w8, #0x298b38c        | if (ProtoBuf.Serializers.BlobSerializer.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0298B384: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.Serializers.BlobSerializer), ????);
            // 0x0298B388: LDR x0, [x19]              | X0 = typeof(ProtoBuf.Serializers.BlobSerializer);
            val_1 = null;
            label_2:
            // 0x0298B38C: LDR x8, [x0, #0xa0]        | X8 = ProtoBuf.Serializers.BlobSerializer.__il2cppRuntimeField_static_fields;
            // 0x0298B390: LDR x0, [x8]               | X0 = ProtoBuf.Serializers.BlobSerializer.expectedType;
            // 0x0298B394: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0298B398: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0298B39C: RET                        |  return (System.Type)ProtoBuf.Serializers.BlobSerializer.expectedType;
            return ProtoBuf.Serializers.BlobSerializer.expectedType;
            //  |  // // {name=val_0, type=System.Type, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0298B3A0 (43561888), len: 244  VirtAddr: 0x0298B3A0 RVA: 0x0298B3A0 token: 100689802 methodIndex: 54001 delegateWrapperIndex: 0 methodInvoker: 0
        public object Read(object value, ProtoBuf.ProtoReader source)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            ProtoBuf.ProtoReader val_3;
            // 0x0298B3A0: STP x22, x21, [sp, #-0x30]! | stack[1152921514433721584] = ???;  stack[1152921514433721592] = ???;  //  dest_result_addr=1152921514433721584 |  dest_result_addr=1152921514433721592
            // 0x0298B3A4: STP x20, x19, [sp, #0x10]  | stack[1152921514433721600] = ???;  stack[1152921514433721608] = ???;  //  dest_result_addr=1152921514433721600 |  dest_result_addr=1152921514433721608
            // 0x0298B3A8: STP x29, x30, [sp, #0x20]  | stack[1152921514433721616] = ???;  stack[1152921514433721624] = ???;  //  dest_result_addr=1152921514433721616 |  dest_result_addr=1152921514433721624
            // 0x0298B3AC: ADD x29, sp, #0x20         | X29 = (1152921514433721584 + 32) = 1152921514433721616 (0x1000000249BA3510);
            // 0x0298B3B0: SUB sp, sp, #0x10          | SP = (1152921514433721584 - 16) = 1152921514433721568 (0x1000000249BA34E0);
            // 0x0298B3B4: ADRP x22, #0x37b8000       | X22 = 58425344 (0x37B8000);             
            // 0x0298B3B8: LDRB w8, [x22, #0xf14]     | W8 = (bool)static_value_037B8F14;       
            // 0x0298B3BC: MOV x19, x2                | X19 = source;//m1                       
            // 0x0298B3C0: MOV x20, x1                | X20 = value;//m1                        
            // 0x0298B3C4: MOV x21, x0                | X21 = 1152921514433733632 (0x1000000249BA6400);//ML01
            // 0x0298B3C8: TBNZ w8, #0, #0x298b3e4    | if (static_value_037B8F14 == true) goto label_0;
            // 0x0298B3CC: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
            // 0x0298B3D0: LDR x8, [x8, #0x3a8]       | X8 = 0x2B8F648;                         
            // 0x0298B3D4: LDR w0, [x8]               | W0 = 0x1456;                            
            // 0x0298B3D8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1456, ????);     
            // 0x0298B3DC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0298B3E0: STRB w8, [x22, #0xf14]     | static_value_037B8F14 = true;            //  dest_result_addr=58429204
            label_0:
            // 0x0298B3E4: LDRB w8, [x21, #0x10]      | W8 = this.overwriteList; //P2           
            // 0x0298B3E8: CBNZ w8, #0x298b43c        | if (this.overwriteList == true) goto label_2;
            if(this.overwriteList == true)
            {
                goto label_2;
            }
            // 0x0298B3EC: CBZ x20, #0x298b43c        | if (value == null) goto label_2;        
            if(value == null)
            {
                goto label_2;
            }
            // 0x0298B3F0: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x0298B3F4: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x0298B3F8: MOV x0, x20                | X0 = value;//m1                         
            // 0x0298B3FC: LDR x22, [x8]              | X22 = typeof(System.Byte[]);            
            // 0x0298B400: MOV x1, x22                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0298B404: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
            // 0x0298B408: MOV x21, x0                | X21 = value;//m1                        
            val_3 = value;
            // 0x0298B40C: CBNZ x21, #0x298b440       | if (value != null) goto label_3;        
            if(val_3 != null)
            {
                goto label_3;
            }
            // 0x0298B410: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x0298B414: MOV x1, x22                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0298B418: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0298B41C: ADD x8, sp, #8             | X8 = (1152921514433721568 + 8) = 1152921514433721576 (0x1000000249BA34E8);
            // 0x0298B420: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0298B424: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921514433709632]
            // 0x0298B428: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x0298B42C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0298B430: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x0298B434: ADD x0, sp, #8             | X0 = (1152921514433721568 + 8) = 1152921514433721576 (0x1000000249BA34E8);
            // 0x0298B438: BL #0x299a140              | 
            label_2:
            // 0x0298B43C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_3 = 0;
            label_3:
            // 0x0298B440: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x0298B444: LDR x8, [x8, #0x668]       | X8 = 1152921504884375552;               
            // 0x0298B448: LDR x0, [x8]               | X0 = typeof(ProtoBuf.ProtoReader);      
            // 0x0298B44C: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_10A;
            // 0x0298B450: TBZ w8, #0, #0x298b460     | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0298B454: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished;
            // 0x0298B458: CBNZ w8, #0x298b460        | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0298B45C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoReader), ????);
            label_5:
            // 0x0298B460: MOV x1, x21                | X1 = 0 (0x0);//ML01                     
            // 0x0298B464: MOV x2, x19                | X2 = source;//m1                        
            // 0x0298B468: BL #0x297f46c              | X0 = ProtoBuf.ProtoReader.AppendBytes(value:  null, reader:  val_3);
            System.Byte[] val_2 = ProtoBuf.ProtoReader.AppendBytes(value:  null, reader:  val_3);
            // 0x0298B46C: SUB sp, x29, #0x20         | SP = (1152921514433721616 - 32) = 1152921514433721584 (0x1000000249BA34F0);
            // 0x0298B470: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0298B474: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0298B478: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0298B47C: RET                        |  return (System.Object)val_2;           
            return (object)val_2;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            // 0x0298B480: MOV x19, x0                | 
            // 0x0298B484: ADD x0, sp, #8             | 
            // 0x0298B488: BL #0x299a140              | 
            // 0x0298B48C: MOV x0, x19                | 
            // 0x0298B490: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0298B494 (43562132), len: 228  VirtAddr: 0x0298B494 RVA: 0x0298B494 token: 100689803 methodIndex: 54002 delegateWrapperIndex: 0 methodInvoker: 0
        public void Write(object value, ProtoBuf.ProtoWriter dest)
        {
            //
            // Disasemble & Code
            //  | 
            System.Byte[] val_1;
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            ProtoBuf.ProtoWriter val_4;
            // 0x0298B494: STP x22, x21, [sp, #-0x30]! | stack[1152921514433886832] = ???;  stack[1152921514433886840] = ???;  //  dest_result_addr=1152921514433886832 |  dest_result_addr=1152921514433886840
            // 0x0298B498: STP x20, x19, [sp, #0x10]  | stack[1152921514433886848] = ???;  stack[1152921514433886856] = ???;  //  dest_result_addr=1152921514433886848 |  dest_result_addr=1152921514433886856
            // 0x0298B49C: STP x29, x30, [sp, #0x20]  | stack[1152921514433886864] = ???;  stack[1152921514433886872] = ???;  //  dest_result_addr=1152921514433886864 |  dest_result_addr=1152921514433886872
            // 0x0298B4A0: ADD x29, sp, #0x20         | X29 = (1152921514433886832 + 32) = 1152921514433886864 (0x1000000249BCBA90);
            // 0x0298B4A4: SUB sp, sp, #0x10          | SP = (1152921514433886832 - 16) = 1152921514433886816 (0x1000000249BCBA60);
            // 0x0298B4A8: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x0298B4AC: LDRB w8, [x21, #0xf15]     | W8 = (bool)static_value_037B8F15;       
            // 0x0298B4B0: MOV x19, x2                | X19 = dest;//m1                         
            // 0x0298B4B4: MOV x20, x1                | X20 = value;//m1                        
            // 0x0298B4B8: TBNZ w8, #0, #0x298b4d4    | if (static_value_037B8F15 == true) goto label_0;
            // 0x0298B4BC: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
            // 0x0298B4C0: LDR x8, [x8, #0x178]       | X8 = 0x2B8F64C;                         
            // 0x0298B4C4: LDR w0, [x8]               | W0 = 0x1457;                            
            // 0x0298B4C8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1457, ????);     
            // 0x0298B4CC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0298B4D0: STRB w8, [x21, #0xf15]     | static_value_037B8F15 = true;            //  dest_result_addr=58429205
            label_0:
            // 0x0298B4D4: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
            // 0x0298B4D8: LDR x8, [x8, #0x778]       | X8 = 1152921504884428800;               
            // 0x0298B4DC: LDR x0, [x8]               | X0 = typeof(ProtoBuf.ProtoWriter);      
            val_3 = null;
            // 0x0298B4E0: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x0298B4E4: TBZ w8, #0, #0x298b4f4     | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0298B4E8: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x0298B4EC: CBNZ w8, #0x298b4f4        | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0298B4F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_2:
            // 0x0298B4F4: CBZ x20, #0x298b544        | if (value == null) goto label_3;        
            if(value == null)
            {
                goto label_3;
            }
            // 0x0298B4F8: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x0298B4FC: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x0298B500: MOV x0, x20                | X0 = value;//m1                         
            val_3 = value;
            // 0x0298B504: LDR x21, [x8]              | X21 = typeof(System.Byte[]);            
            val_2 = null;
            // 0x0298B508: MOV x1, x21                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0298B50C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
            // 0x0298B510: MOV x1, x0                 | X1 = value;//m1                         
            val_4 = val_3;
            // 0x0298B514: CBNZ x1, #0x298b548        | if (value != null) goto label_4;        
            if(val_4 != null)
            {
                goto label_4;
            }
            // 0x0298B518: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x0298B51C: MOV x1, x21                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0298B520: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0298B524: ADD x8, sp, #8             | X8 = (1152921514433886816 + 8) = 1152921514433886824 (0x1000000249BCBA68);
            // 0x0298B528: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0298B52C: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921514433874880]
            // 0x0298B530: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x0298B534: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0298B538: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x0298B53C: ADD x0, sp, #8             | X0 = (1152921514433886816 + 8) = 1152921514433886824 (0x1000000249BCBA68);
            // 0x0298B540: BL #0x299a140              | 
            label_3:
            // 0x0298B544: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_4 = 0;
            label_4:
            // 0x0298B548: MOV x2, x19                | X2 = dest;//m1                          
            // 0x0298B54C: BL #0x297961c              | ProtoBuf.ProtoWriter.WriteBytes(data:  System.Byte[] val_1, writer:  val_4 = 0);
            ProtoBuf.ProtoWriter.WriteBytes(data:  val_1, writer:  val_4);
            // 0x0298B550: SUB sp, x29, #0x20         | SP = (1152921514433886864 - 32) = 1152921514433886832 (0x1000000249BCBA70);
            // 0x0298B554: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0298B558: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0298B55C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0298B560: RET                        |  return;                                
            return;
            // 0x0298B564: MOV x19, x0                | 
            // 0x0298B568: ADD x0, sp, #8             | 
            // 0x0298B56C: BL #0x299a140              | 
            // 0x0298B570: MOV x0, x19                | 
            // 0x0298B574: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0298B578 (43562360), len: 16  VirtAddr: 0x0298B578 RVA: 0x0298B578 token: 100689804 methodIndex: 54003 delegateWrapperIndex: 0 methodInvoker: 0
        private bool ProtoBuf.Serializers.IProtoSerializer.get_RequiresOldValue()
        {
            //
            // Disasemble & Code
            // 0x0298B578: LDRB w8, [x0, #0x10]       | W8 = this.overwriteList; //P2           
            // 0x0298B57C: CMP w8, #0                 | STATE = COMPARE(this.overwriteList, 0x0)
            // 0x0298B580: CSET w0, eq                | W0 = this.overwriteList == false ? 1 : 0;
            var val_1 = (this.overwriteList == false) ? 1 : 0;
            // 0x0298B584: RET                        |  return (System.Boolean)this.overwriteList == false ? 1 : 0;
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0298B588 (43562376), len: 8  VirtAddr: 0x0298B588 RVA: 0x0298B588 token: 100689805 methodIndex: 54004 delegateWrapperIndex: 0 methodInvoker: 0
        private bool ProtoBuf.Serializers.IProtoSerializer.get_ReturnsValue()
        {
            //
            // Disasemble & Code
            // 0x0298B588: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            // 0x0298B58C: RET                        |  return (System.Boolean)true;           
            return (bool)1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0298B590 (43562384), len: 140  VirtAddr: 0x0298B590 RVA: 0x0298B590 token: 100689806 methodIndex: 54005 delegateWrapperIndex: 0 methodInvoker: 0
        private static BlobSerializer()
        {
            //
            // Disasemble & Code
            // 0x0298B590: STP x20, x19, [sp, #-0x20]! | stack[1152921514434235136] = ???;  stack[1152921514434235144] = ???;  //  dest_result_addr=1152921514434235136 |  dest_result_addr=1152921514434235144
            // 0x0298B594: STP x29, x30, [sp, #0x10]  | stack[1152921514434235152] = ???;  stack[1152921514434235160] = ???;  //  dest_result_addr=1152921514434235152 |  dest_result_addr=1152921514434235160
            // 0x0298B598: ADD x29, sp, #0x10         | X29 = (1152921514434235136 + 16) = 1152921514434235152 (0x1000000249C20B10);
            // 0x0298B59C: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x0298B5A0: LDRB w8, [x19, #0xf16]     | W8 = (bool)static_value_037B8F16;       
            // 0x0298B5A4: TBNZ w8, #0, #0x298b5c0    | if (static_value_037B8F16 == true) goto label_0;
            // 0x0298B5A8: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x0298B5AC: LDR x8, [x8, #0x3e0]       | X8 = 0x2B8F640;                         
            // 0x0298B5B0: LDR w0, [x8]               | W0 = 0x1454;                            
            // 0x0298B5B4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1454, ????);     
            // 0x0298B5B8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0298B5BC: STRB w8, [x19, #0xf16]     | static_value_037B8F16 = true;            //  dest_result_addr=58429206
            label_0:
            // 0x0298B5C0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0298B5C4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0298B5C8: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x0298B5CC: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
            // 0x0298B5D0: LDR x8, [x8, #0x888]       | X8 = 1152921504996170800;               
            // 0x0298B5D4: LDR x19, [x8]              | X19 = typeof(System.Byte[]);            
            // 0x0298B5D8: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0298B5DC: TBZ w8, #0, #0x298b5ec     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0298B5E0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0298B5E4: CBNZ w8, #0x298b5ec        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0298B5E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x0298B5EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0298B5F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0298B5F4: MOV x1, x19                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0298B5F8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0298B5FC: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
            // 0x0298B600: LDR x8, [x8, #0x8a0]       | X8 = 1152921504884801536;               
            // 0x0298B604: LDR x8, [x8]               | X8 = typeof(ProtoBuf.Serializers.BlobSerializer);
            // 0x0298B608: LDR x8, [x8, #0xa0]        | X8 = ProtoBuf.Serializers.BlobSerializer.__il2cppRuntimeField_static_fields;
            // 0x0298B60C: STR x0, [x8]               | ProtoBuf.Serializers.BlobSerializer.expectedType = val_1;  //  dest_result_addr=1152921504884805632
            ProtoBuf.Serializers.BlobSerializer.expectedType = val_1;
            // 0x0298B610: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0298B614: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0298B618: RET                        |  return;                                
            return;
        
        }
    
    }

}
