using UnityEngine;
public enum BarrierGat.BGOpenType
{
    // Fields
    BT_round_trigger = 1
    

}
