using UnityEngine;

namespace wxb
{
    internal class ArrayIntType : ArraySerialize<int>
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2BC88 (14859400), len: 80  VirtAddr: 0x00E2BC88 RVA: 0x00E2BC88 token: 100681177 methodIndex: 57209 delegateWrapperIndex: 0 methodInvoker: 0
        public ArrayIntType()
        {
            //
            // Disasemble & Code
            // 0x00E2BC88: STP x20, x19, [sp, #-0x20]! | stack[1152921513023062944] = ???;  stack[1152921513023062952] = ???;  //  dest_result_addr=1152921513023062944 |  dest_result_addr=1152921513023062952
            // 0x00E2BC8C: STP x29, x30, [sp, #0x10]  | stack[1152921513023062960] = ???;  stack[1152921513023062968] = ???;  //  dest_result_addr=1152921513023062960 |  dest_result_addr=1152921513023062968
            // 0x00E2BC90: ADD x29, sp, #0x10         | X29 = (1152921513023062944 + 16) = 1152921513023062960 (0x10000001F5A543B0);
            // 0x00E2BC94: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2BC98: LDRB w8, [x20, #0x8ee]     | W8 = (bool)static_value_037348EE;       
            // 0x00E2BC9C: MOV x19, x0                | X19 = 1152921513023074976 (0x10000001F5A572A0);//ML01
            // 0x00E2BCA0: TBNZ w8, #0, #0xe2bcbc     | if (static_value_037348EE == true) goto label_0;
            // 0x00E2BCA4: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
            // 0x00E2BCA8: LDR x8, [x8, #0x698]       | X8 = 0x2B8E740;                         
            // 0x00E2BCAC: LDR w0, [x8]               | W0 = 0x108E;                            
            // 0x00E2BCB0: BL #0x2782188              | X0 = sub_2782188( ?? 0x108E, ????);     
            // 0x00E2BCB4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2BCB8: STRB w8, [x20, #0x8ee]     | static_value_037348EE = true;            //  dest_result_addr=57886958
            label_0:
            // 0x00E2BCBC: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00E2BCC0: LDR x8, [x8, #0xa58]       | X8 = 1152921513023049952;               
            // 0x00E2BCC4: MOV x0, x19                | X0 = 1152921513023074976 (0x10000001F5A572A0);//ML01
            // 0x00E2BCC8: LDR x1, [x8]               | X1 = System.Void wxb.ArraySerialize<System.Int32>::.ctor();
            // 0x00E2BCCC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2BCD0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2BCD4: B #0x1d87074               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2BCD8 (14859480), len: 8  VirtAddr: 0x00E2BCD8 RVA: 0x00E2BCD8 token: 100681178 methodIndex: 57210 delegateWrapperIndex: 0 methodInvoker: 0
        protected override int GetElementSize()
        {
            //
            // Disasemble & Code
            // 0x00E2BCD8: ORR w0, wzr, #4            | W0 = 4(0x4);                            
            // 0x00E2BCDC: RET                        |  return (System.Int32)4;                
            return (int)4;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2BCE0 (14859488), len: 52  VirtAddr: 0x00E2BCE0 RVA: 0x00E2BCE0 token: 100681179 methodIndex: 57211 delegateWrapperIndex: 0 methodInvoker: 0
        protected override void Write(wxb.WRStream stream, int value)
        {
            //
            // Disasemble & Code
            // 0x00E2BCE0: STP x20, x19, [sp, #-0x20]! | stack[1152921513023291040] = ???;  stack[1152921513023291048] = ???;  //  dest_result_addr=1152921513023291040 |  dest_result_addr=1152921513023291048
            // 0x00E2BCE4: STP x29, x30, [sp, #0x10]  | stack[1152921513023291056] = ???;  stack[1152921513023291064] = ???;  //  dest_result_addr=1152921513023291056 |  dest_result_addr=1152921513023291064
            // 0x00E2BCE8: ADD x29, sp, #0x10         | X29 = (1152921513023291040 + 16) = 1152921513023291056 (0x10000001F5A8BEB0);
            // 0x00E2BCEC: MOV w19, w2                | W19 = value;//m1                        
            // 0x00E2BCF0: MOV x20, x1                | X20 = stream;//m1                       
            // 0x00E2BCF4: CBNZ x20, #0xe2bcfc        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2BCF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2BCFC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2BD00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2BD04: MOV x0, x20                | X0 = stream;//m1                        
            // 0x00E2BD08: MOV w1, w19                | W1 = value;//m1                         
            // 0x00E2BD0C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2BD10: B #0x269d1a0               | stream.WriteInt32(value:  value); return;
            stream.WriteInt32(value:  value);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2BD14 (14859540), len: 44  VirtAddr: 0x00E2BD14 RVA: 0x00E2BD14 token: 100681180 methodIndex: 57212 delegateWrapperIndex: 0 methodInvoker: 0
        protected override int Read(wxb.WRStream stream)
        {
            //
            // Disasemble & Code
            // 0x00E2BD14: STP x20, x19, [sp, #-0x20]! | stack[1152921513023411232] = ???;  stack[1152921513023411240] = ???;  //  dest_result_addr=1152921513023411232 |  dest_result_addr=1152921513023411240
            // 0x00E2BD18: STP x29, x30, [sp, #0x10]  | stack[1152921513023411248] = ???;  stack[1152921513023411256] = ???;  //  dest_result_addr=1152921513023411248 |  dest_result_addr=1152921513023411256
            // 0x00E2BD1C: ADD x29, sp, #0x10         | X29 = (1152921513023411232 + 16) = 1152921513023411248 (0x10000001F5AA9430);
            // 0x00E2BD20: MOV x19, x1                | X19 = stream;//m1                       
            // 0x00E2BD24: CBNZ x19, #0xe2bd2c        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2BD28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2BD2C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2BD30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2BD34: MOV x0, x19                | X0 = stream;//m1                        
            // 0x00E2BD38: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2BD3C: B #0x269d2e4               | return stream.ReadInt32();              
            return stream.ReadInt32();
        
        }
    
    }

}
