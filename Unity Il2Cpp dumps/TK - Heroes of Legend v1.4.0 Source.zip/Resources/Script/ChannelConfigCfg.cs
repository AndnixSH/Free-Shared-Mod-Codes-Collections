using UnityEngine;
public class ChannelConfigCfg : CsCfgBase
{
    // Fields
    public int id; //  0x00000010
    public string key; //  0x00000018
    public string value; //  0x00000020
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00D82268 (14164584), len: 8  VirtAddr: 0x00D82268 RVA: 0x00D82268 token: 100690512 methodIndex: 25966 delegateWrapperIndex: 0 methodInvoker: 0
    public ChannelConfigCfg()
    {
        //
        // Disasemble & Code
        // 0x00D82268: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8226C: B #0xb46154                | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D82270 (14164592), len: 236  VirtAddr: 0x00D82270 RVA: 0x00D82270 token: 100690513 methodIndex: 25967 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Init(System.Collections.Generic.Dictionary<string, string> _info)
    {
        //
        // Disasemble & Code
        // 0x00D82270: STP x22, x21, [sp, #-0x30]! | stack[1152921514530389120] = ???;  stack[1152921514530389128] = ???;  //  dest_result_addr=1152921514530389120 |  dest_result_addr=1152921514530389128
        // 0x00D82274: STP x20, x19, [sp, #0x10]  | stack[1152921514530389136] = ???;  stack[1152921514530389144] = ???;  //  dest_result_addr=1152921514530389136 |  dest_result_addr=1152921514530389144
        // 0x00D82278: STP x29, x30, [sp, #0x20]  | stack[1152921514530389152] = ???;  stack[1152921514530389160] = ???;  //  dest_result_addr=1152921514530389152 |  dest_result_addr=1152921514530389160
        // 0x00D8227C: ADD x29, sp, #0x20         | X29 = (1152921514530389120 + 32) = 1152921514530389152 (0x100000024F7D3CA0);
        // 0x00D82280: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D82284: LDRB w8, [x21, #0x42d]     | W8 = (bool)static_value_0373442D;       
        // 0x00D82288: MOV x20, x1                | X20 = _info;//m1                        
        // 0x00D8228C: MOV x19, x0                | X19 = 1152921514530401168 (0x100000024F7D6B90);//ML01
        // 0x00D82290: TBNZ w8, #0, #0xd822ac     | if (static_value_0373442D == true) goto label_0;
        // 0x00D82294: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
        // 0x00D82298: LDR x8, [x8, #0x3e8]       | X8 = 0x2B90554;                         
        // 0x00D8229C: LDR w0, [x8]               | W0 = 0x1819;                            
        // 0x00D822A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1819, ????);     
        // 0x00D822A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D822A8: STRB w8, [x21, #0x42d]     | static_value_0373442D = true;            //  dest_result_addr=57885741
        label_0:
        // 0x00D822AC: CBNZ x20, #0xd822b4        | if (_info != null) goto label_1;        
        if(_info != null)
        {
            goto label_1;
        }
        // 0x00D822B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1819, ????);     
        label_1:
        // 0x00D822B4: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
        // 0x00D822B8: ADRP x21, #0x3667000       | X21 = 57044992 (0x3667000);             
        // 0x00D822BC: LDR x8, [x8, #0xf28]       | X8 = (string**)(1152921510122275760)("id");
        // 0x00D822C0: LDR x21, [x21, #0x90]      | X21 = 1152921510817398768;              
        // 0x00D822C4: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D822C8: LDR x1, [x8]               | X1 = "id";                              
        // 0x00D822CC: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D822D0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "id");        
        string val_1 = _info.Item["id"];
        // 0x00D822D4: MOV x1, x0                 | X1 = val_1;//m1                         
        // 0x00D822D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D822DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D822E0: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_2 = System.Int32.Parse(s:  0);
        // 0x00D822E4: STR w0, [x19, #0x10]       | this.id = val_2;                         //  dest_result_addr=1152921514530401184
        this.id = val_2;
        // 0x00D822E8: CBZ x20, #0xd8230c         | if (_info == null) goto label_2;        
        if(_info == null)
        {
            goto label_2;
        }
        // 0x00D822EC: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00D822F0: LDR x8, [x8, #0x178]       | X8 = (string**)(1152921511282621584)("key");
        // 0x00D822F4: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D822F8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D822FC: LDR x1, [x8]               | X1 = "key";                             
        // 0x00D82300: BL #0x23fc26c              | X0 = _info.get_Item(key:  "key");       
        string val_3 = _info.Item["key"];
        // 0x00D82304: STR x0, [x19, #0x18]       | this.key = val_3;                        //  dest_result_addr=1152921514530401192
        this.key = val_3;
        // 0x00D82308: B #0xd82330                |  goto label_3;                          
        goto label_3;
        label_2:
        // 0x00D8230C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        // 0x00D82310: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00D82314: LDR x8, [x8, #0x178]       | X8 = (string**)(1152921511282621584)("key");
        // 0x00D82318: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D8231C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82320: LDR x1, [x8]               | X1 = "key";                             
        // 0x00D82324: BL #0x23fc26c              | X0 = _info.get_Item(key:  "key");       
        string val_4 = _info.Item["key"];
        // 0x00D82328: STR x0, [x19, #0x18]       | this.key = val_4;                        //  dest_result_addr=1152921514530401192
        this.key = val_4;
        // 0x00D8232C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_3:
        // 0x00D82330: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
        // 0x00D82334: LDR x8, [x8, #0x400]       | X8 = (string**)(1152921511191786896)("value");
        // 0x00D82338: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00D8233C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00D82340: LDR x1, [x8]               | X1 = "value";                           
        // 0x00D82344: BL #0x23fc26c              | X0 = _info.get_Item(key:  "value");     
        string val_5 = _info.Item["value"];
        // 0x00D82348: STR x0, [x19, #0x20]       | this.value = val_5;                      //  dest_result_addr=1152921514530401200
        this.value = val_5;
        // 0x00D8234C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D82350: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D82354: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D82358: RET                        |  return;                                
        return;
    
    }

}
