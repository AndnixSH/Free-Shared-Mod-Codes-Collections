using UnityEngine;

namespace SevenZip.Compression.RangeCoder
{
    internal struct BitDecoder
    {
        // Fields
        public const int kNumBitModelTotalBits = 11;
        public const uint kBitModelTotal = 2048;
        private const int kNumMoveBits = 5;
        private uint Prob; //  0x00000000
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AD7418 (11367448), len: 64  VirtAddr: 0x00AD7418 RVA: 0x00AD7418 token: 100681671 methodIndex: 54707 delegateWrapperIndex: 0 methodInvoker: 0
        public void UpdateModel(int numMoveBits, uint symbol)
        {
            //
            // Disasemble & Code
            //  | 
            int val_5;
            // 0x00AD7418: LDR w8, [x0, #0x10]        | 
            // 0x00AD741C: CBZ w2, #0xad7430          | if (symbol == 0) goto label_0;          
            if(symbol == 0)
            {
                goto label_0;
            }
            // 0x00AD7420: AND w9, w1, #0x1f          | W9 = (numMoveBits & 31);                
            int val_1 = numMoveBits & 31;
            // 0x00AD7424: LSR w9, w8, w9             | W9 = (W8 >> (numMoveBits & 31));        
            val_1 = W8 >> val_1;
            // 0x00AD7428: SUB w8, w8, w9             | W8 = (W8 - (W8 >> (numMoveBits & 31))); 
            val_5 = W8 - val_1;
            // 0x00AD742C: B #0xad7444                |  goto label_1;                          
            goto label_1;
            label_0:
            // 0x00AD7430: ORR w9, wzr, #0x800        | W9 = 2048(0x800);                       
            var val_3 = 2048;
            // 0x00AD7434: SUB w9, w9, w8             | W9 = (2048 - W8);                       
            val_3 = val_3 - W8;
            // 0x00AD7438: AND w10, w1, #0x1f         | W10 = (numMoveBits & 31);               
            int val_2 = numMoveBits & 31;
            // 0x00AD743C: LSR w9, w9, w10            | W9 = ((2048 - W8) >> (numMoveBits & 31));
            val_3 = val_3 >> val_2;
            // 0x00AD7440: ADD w8, w9, w8             | W8 = (((2048 - W8) >> (numMoveBits & 31)) + W8);
            val_5 = val_3 + W8;
            label_1:
            // 0x00AD7444: STR w8, [x0, #0x10]        | mem[1152921513109148832] = (((2048 - W8) >> (numMoveBits & 31)) + W8);  //  dest_result_addr=1152921513109148832
            mem[1152921513109148832] = val_5;
            // 0x00AD7448: RET                        |  return;                                
            return;
            // 0x00AD744C: ORR w8, wzr, #0x400        | 
            // 0x00AD7450: STR w8, [x0]               | 
            // 0x00AD7454: RET                        | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD7458 (11367512), len: 492  VirtAddr: 0x00AD7458 RVA: 0x00AD7458 token: 100681672 methodIndex: 54708 delegateWrapperIndex: 0 methodInvoker: 0
        public void Init()
        {
            //
            // Disasemble & Code
            // 0x00AD7458: ORR w8, wzr, #0x400        | W8 = 1024(0x400);                       
            // 0x00AD745C: STR w8, [x0, #0x10]        | mem[1152921513109260832] = 0x400;        //  dest_result_addr=1152921513109260832
            mem[1152921513109260832] = 1024;
            // 0x00AD7460: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD7644 (11368004), len: 8  VirtAddr: 0x00AD7644 RVA: 0x00AD7644 token: 100681673 methodIndex: 54709 delegateWrapperIndex: 0 methodInvoker: 0
        public uint Decode(SevenZip.Compression.RangeCoder.Decoder rangeDecoder)
        {
            //
            // Disasemble & Code
            // 0x00AD7644: ADD x0, x0, #0x10          | X0 = (this + 16) = 1152921513109376928 (0x10000001FACA4FA0);
            // 0x00AD7648: B #0xad7464                | goto label_SevenZip_Compression_RangeCoder_BitDecoder_Init_GL00AD7464;
        
        }
    
    }

}
