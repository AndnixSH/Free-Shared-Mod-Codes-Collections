using UnityEngine;

namespace wxb
{
    public class CacheType
    {
        // Fields
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x2859714
        private System.Type <type>k__BackingField; //  0x00000010
        private System.Collections.Generic.Dictionary<string, System.Reflection.MemberInfo> NameToMethodBase; //  0x00000018
        private System.Collections.Generic.List<System.Reflection.FieldInfo> serializes; //  0x00000020
        private static readonly System.Reflection.BindingFlags Flags; // static_offset: 0x00000000
        private wxb.CacheType.Ctor[] Ctors; //  0x00000028
        private System.Reflection.ConstructorInfo default_ctor; //  0x00000030
        private bool is_default_ctor; //  0x00000038
        
        // Properties
        public System.Type type { get; set; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2E1D0 (14868944), len: 132  VirtAddr: 0x00E2E1D0 RVA: 0x00E2E1D0 token: 100680904 methodIndex: 57306 delegateWrapperIndex: 0 methodInvoker: 0
        public CacheType(System.Type type)
        {
            //
            // Disasemble & Code
            // 0x00E2E1D0: STP x22, x21, [sp, #-0x30]! | stack[1152921512982535232] = ???;  stack[1152921512982535240] = ???;  //  dest_result_addr=1152921512982535232 |  dest_result_addr=1152921512982535240
            // 0x00E2E1D4: STP x20, x19, [sp, #0x10]  | stack[1152921512982535248] = ???;  stack[1152921512982535256] = ???;  //  dest_result_addr=1152921512982535248 |  dest_result_addr=1152921512982535256
            // 0x00E2E1D8: STP x29, x30, [sp, #0x20]  | stack[1152921512982535264] = ???;  stack[1152921512982535272] = ???;  //  dest_result_addr=1152921512982535264 |  dest_result_addr=1152921512982535272
            // 0x00E2E1DC: ADD x29, sp, #0x20         | X29 = (1152921512982535232 + 32) = 1152921512982535264 (0x10000001F33ADC60);
            // 0x00E2E1E0: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2E1E4: LDRB w8, [x21, #0x932]     | W8 = (bool)static_value_03734932;       
            // 0x00E2E1E8: MOV x19, x1                | X19 = type;//m1                         
            // 0x00E2E1EC: MOV x20, x0                | X20 = 1152921512982547280 (0x10000001F33B0B50);//ML01
            // 0x00E2E1F0: TBNZ w8, #0, #0xe2e20c     | if (static_value_03734932 == true) goto label_0;
            // 0x00E2E1F4: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x00E2E1F8: LDR x8, [x8, #0x828]       | X8 = 0x2B90038;                         
            // 0x00E2E1FC: LDR w0, [x8]               | W0 = 0x16D2;                            
            // 0x00E2E200: BL #0x2782188              | X0 = sub_2782188( ?? 0x16D2, ????);     
            // 0x00E2E204: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2E208: STRB w8, [x21, #0x932]     | static_value_03734932 = true;            //  dest_result_addr=57887026
            label_0:
            // 0x00E2E20C: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2E210: LDR x8, [x8, #0xbd8]       | X8 = 1152921504615792640;               
            // 0x00E2E214: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.String, System.Reflection.MemberInfo> val_1 = null;
            // 0x00E2E218: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x00E2E21C: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
            // 0x00E2E220: LDR x8, [x8, #0x278]       | X8 = 1152921509759181088;               
            // 0x00E2E224: MOV x21, x0                | X21 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x00E2E228: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Reflection.MemberInfo>::.ctor();
            // 0x00E2E22C: BL #0x23fb0c4              | .ctor();                                
            val_1 = new System.Collections.Generic.Dictionary<System.String, System.Reflection.MemberInfo>();
            // 0x00E2E230: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2E234: MOV x0, x20                | X0 = 1152921512982547280 (0x10000001F33B0B50);//ML01
            // 0x00E2E238: STR x21, [x20, #0x18]      | this.NameToMethodBase = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921512982547304
            this.NameToMethodBase = val_1;
            // 0x00E2E23C: BL #0x16f59f0              | this..ctor();                           
            // 0x00E2E240: STR x19, [x20, #0x10]      | this.<type>k__BackingField = type;       //  dest_result_addr=1152921512982547296
            this.<type>k__BackingField = type;
            // 0x00E2E244: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2E248: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2E24C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2E250: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2E25C (14869084), len: 8  VirtAddr: 0x00E2E25C RVA: 0x00E2E25C token: 100680905 methodIndex: 57307 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Type get_type()
        {
            //
            // Disasemble & Code
            // 0x00E2E25C: LDR x0, [x0, #0x10]        | X0 = this.<type>k__BackingField; //P2   
            // 0x00E2E260: RET                        |  return (System.Type)this.<type>k__BackingField;
            return this.<type>k__BackingField;
            //  |  // // {name=val_0, type=System.Type, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2E254 (14869076), len: 8  VirtAddr: 0x00E2E254 RVA: 0x00E2E254 token: 100680906 methodIndex: 57308 delegateWrapperIndex: 0 methodInvoker: 0
        private void set_type(System.Type value)
        {
            //
            // Disasemble & Code
            // 0x00E2E254: STR x1, [x0, #0x10]        | this.<type>k__BackingField = value;      //  dest_result_addr=1152921512982787680
            this.<type>k__BackingField = value;
            // 0x00E2E258: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2E264 (14869092), len: 228  VirtAddr: 0x00E2E264 RVA: 0x00E2E264 token: 100680907 methodIndex: 57309 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Reflection.ConstructorInfo GetCtor()
        {
            //
            // Disasemble & Code
            //  | 
            System.Reflection.ConstructorInfo val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            // 0x00E2E264: STP x22, x21, [sp, #-0x30]! | stack[1152921512982904000] = ???;  stack[1152921512982904008] = ???;  //  dest_result_addr=1152921512982904000 |  dest_result_addr=1152921512982904008
            // 0x00E2E268: STP x20, x19, [sp, #0x10]  | stack[1152921512982904016] = ???;  stack[1152921512982904024] = ???;  //  dest_result_addr=1152921512982904016 |  dest_result_addr=1152921512982904024
            // 0x00E2E26C: STP x29, x30, [sp, #0x20]  | stack[1152921512982904032] = ???;  stack[1152921512982904040] = ???;  //  dest_result_addr=1152921512982904032 |  dest_result_addr=1152921512982904040
            // 0x00E2E270: ADD x29, sp, #0x20         | X29 = (1152921512982904000 + 32) = 1152921512982904032 (0x10000001F3407CE0);
            // 0x00E2E274: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2E278: LDRB w8, [x20, #0x933]     | W8 = (bool)static_value_03734933;       
            // 0x00E2E27C: MOV x19, x0                | X19 = 1152921512982916048 (0x10000001F340ABD0);//ML01
            // 0x00E2E280: TBNZ w8, #0, #0xe2e29c     | if (static_value_03734933 == true) goto label_0;
            // 0x00E2E284: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
            // 0x00E2E288: LDR x8, [x8, #0x388]       | X8 = 0x2B9003C;                         
            // 0x00E2E28C: LDR w0, [x8]               | W0 = 0x16D3;                            
            // 0x00E2E290: BL #0x2782188              | X0 = sub_2782188( ?? 0x16D3, ????);     
            // 0x00E2E294: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2E298: STRB w8, [x20, #0x933]     | static_value_03734933 = true;            //  dest_result_addr=57887027
            label_0:
            // 0x00E2E29C: LDRB w8, [x19, #0x38]      | W8 = this.is_default_ctor; //P2         
            // 0x00E2E2A0: CBZ w8, #0xe2e2ac          | if (this.is_default_ctor == false) goto label_1;
            if(this.is_default_ctor == false)
            {
                goto label_1;
            }
            // 0x00E2E2A4: LDR x0, [x19, #0x30]       | X0 = this.default_ctor; //P2            
            val_2 = this.default_ctor;
            // 0x00E2E2A8: B #0xe2e338                |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x00E2E2AC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2E2B0: STRB w8, [x19, #0x38]      | this.is_default_ctor = true;             //  dest_result_addr=1152921512982916104
            this.is_default_ctor = true;
            // 0x00E2E2B4: ADRP x21, #0x3647000       | X21 = 56913920 (0x3647000);             
            // 0x00E2E2B8: LDR x21, [x21, #0xf28]     | X21 = 1152921504828198912;              
            // 0x00E2E2BC: LDR x20, [x19, #0x10]      | X20 = this.<type>k__BackingField; //P2  
            // 0x00E2E2C0: LDR x0, [x21]              | X0 = typeof(wxb.CacheType);             
            val_3 = null;
            // 0x00E2E2C4: LDRB w8, [x0, #0x10a]      | W8 = wxb.CacheType.__il2cppRuntimeField_10A;
            // 0x00E2E2C8: TBZ w8, #0, #0xe2e2dc      | if (wxb.CacheType.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00E2E2CC: LDR w8, [x0, #0xbc]        | W8 = wxb.CacheType.__il2cppRuntimeField_cctor_finished;
            // 0x00E2E2D0: CBNZ w8, #0xe2e2dc         | if (wxb.CacheType.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00E2E2D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(wxb.CacheType), ????);
            // 0x00E2E2D8: LDR x0, [x21]              | X0 = typeof(wxb.CacheType);             
            val_3 = null;
            label_4:
            // 0x00E2E2DC: ADRP x22, #0x3679000       | X22 = 57118720 (0x3679000);             
            // 0x00E2E2E0: LDR x8, [x0, #0xa0]        | X8 = wxb.CacheType.__il2cppRuntimeField_static_fields;
            // 0x00E2E2E4: LDR x22, [x22, #0xb60]     | X22 = 1152921504828358656;              
            // 0x00E2E2E8: LDR w21, [x8]              | W21 = wxb.CacheType.Flags;              
            // 0x00E2E2EC: LDR x0, [x22]              | X0 = typeof(wxb.IL.Help);               
            val_4 = null;
            // 0x00E2E2F0: LDRB w8, [x0, #0x10a]      | W8 = wxb.IL.Help.__il2cppRuntimeField_10A;
            // 0x00E2E2F4: TBZ w8, #0, #0xe2e308      | if (wxb.IL.Help.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00E2E2F8: LDR w8, [x0, #0xbc]        | W8 = wxb.IL.Help.__il2cppRuntimeField_cctor_finished;
            // 0x00E2E2FC: CBNZ w8, #0xe2e308         | if (wxb.IL.Help.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00E2E300: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(wxb.IL.Help), ????);
            // 0x00E2E304: LDR x0, [x22]              | X0 = typeof(wxb.IL.Help);               
            val_4 = null;
            label_6:
            // 0x00E2E308: LDR x8, [x0, #0xa0]        | X8 = wxb.IL.Help.__il2cppRuntimeField_static_fields;
            // 0x00E2E30C: LDR x22, [x8, #0x20]       | X22 = wxb.IL.Help.EmptyType;            
            // 0x00E2E310: CBNZ x20, #0xe2e318        | if (this.<type>k__BackingField != null) goto label_7;
            if((this.<type>k__BackingField) != null)
            {
                goto label_7;
            }
            // 0x00E2E314: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(wxb.IL.Help), ????);
            label_7:
            // 0x00E2E318: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2E31C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00E2E320: MOV x0, x20                | X0 = this.<type>k__BackingField;//m1    
            // 0x00E2E324: MOV w1, w21                | W1 = wxb.CacheType.Flags;//m1           
            // 0x00E2E328: MOV x3, x22                | X3 = wxb.IL.Help.EmptyType;//m1         
            // 0x00E2E32C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00E2E330: BL #0x1b6ea10              | X0 = this.<type>k__BackingField.GetConstructor(bindingAttr:  wxb.CacheType.Flags, binder:  0, types:  wxb.IL.Help.EmptyType, modifiers:  0);
            System.Reflection.ConstructorInfo val_1 = this.<type>k__BackingField.GetConstructor(bindingAttr:  wxb.CacheType.Flags, binder:  0, types:  wxb.IL.Help.EmptyType, modifiers:  0);
            // 0x00E2E334: STR x0, [x19, #0x30]       | this.default_ctor = val_1;               //  dest_result_addr=1152921512982916096
            this.default_ctor = val_1;
            label_2:
            // 0x00E2E338: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2E33C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2E340: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2E344: RET                        |  return (System.Reflection.ConstructorInfo)val_1;
            return val_1;
            //  |  // // {name=val_0, type=System.Reflection.ConstructorInfo, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2E348 (14869320), len: 688  VirtAddr: 0x00E2E348 RVA: 0x00E2E348 token: 100680908 methodIndex: 57310 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Reflection.ConstructorInfo GetCtor(System.Type param)
        {
            //
            // Disasemble & Code
            //  | 
            System.Type val_4;
            //  | 
            var val_5;
            //  | 
            Ctor[] val_6;
            //  | 
            int val_7;
            //  | 
            var val_8;
            //  | 
            System.Reflection.BindingFlags val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            Ctor val_12;
            // 0x00E2E348: STP x28, x27, [sp, #-0x60]! | stack[1152921512983078416] = ???;  stack[1152921512983078424] = ???;  //  dest_result_addr=1152921512983078416 |  dest_result_addr=1152921512983078424
            // 0x00E2E34C: STP x26, x25, [sp, #0x10]  | stack[1152921512983078432] = ???;  stack[1152921512983078440] = ???;  //  dest_result_addr=1152921512983078432 |  dest_result_addr=1152921512983078440
            // 0x00E2E350: STP x24, x23, [sp, #0x20]  | stack[1152921512983078448] = ???;  stack[1152921512983078456] = ???;  //  dest_result_addr=1152921512983078448 |  dest_result_addr=1152921512983078456
            // 0x00E2E354: STP x22, x21, [sp, #0x30]  | stack[1152921512983078464] = ???;  stack[1152921512983078472] = ???;  //  dest_result_addr=1152921512983078464 |  dest_result_addr=1152921512983078472
            // 0x00E2E358: STP x20, x19, [sp, #0x40]  | stack[1152921512983078480] = ???;  stack[1152921512983078488] = ???;  //  dest_result_addr=1152921512983078480 |  dest_result_addr=1152921512983078488
            // 0x00E2E35C: STP x29, x30, [sp, #0x50]  | stack[1152921512983078496] = ???;  stack[1152921512983078504] = ???;  //  dest_result_addr=1152921512983078496 |  dest_result_addr=1152921512983078504
            // 0x00E2E360: ADD x29, sp, #0x50         | X29 = (1152921512983078416 + 80) = 1152921512983078496 (0x10000001F3432660);
            // 0x00E2E364: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2E368: LDRB w8, [x20, #0x934]     | W8 = (bool)static_value_03734934;       
            // 0x00E2E36C: MOV x19, x1                | X19 = param;//m1                        
            val_4 = param;
            // 0x00E2E370: MOV x21, x0                | X21 = 1152921512983090512 (0x10000001F3435550);//ML01
            val_5 = this;
            // 0x00E2E374: TBNZ w8, #0, #0xe2e390     | if (static_value_03734934 == true) goto label_0;
            // 0x00E2E378: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
            // 0x00E2E37C: LDR x8, [x8, #0x260]       | X8 = 0x2B90040;                         
            // 0x00E2E380: LDR w0, [x8]               | W0 = 0x16D4;                            
            // 0x00E2E384: BL #0x2782188              | X0 = sub_2782188( ?? 0x16D4, ????);     
            // 0x00E2E388: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2E38C: STRB w8, [x20, #0x934]     | static_value_03734934 = true;            //  dest_result_addr=57887028
            label_0:
            // 0x00E2E390: MOV x20, x21               | X20 = 1152921512983090512 (0x10000001F3435550);//ML01
            // 0x00E2E394: LDR x24, [x20, #0x28]!     | X24 = this.Ctors; //P2                  
            val_6 = this.Ctors;
            // 0x00E2E398: CBZ x24, #0xe2e400         | if (this.Ctors == null) goto label_1;   
            if(val_6 == null)
            {
                goto label_1;
            }
            // 0x00E2E39C: LDR x26, [x24, #0x18]      | X26 = this.Ctors.Length; //P2           
            val_7 = this.Ctors.Length;
            // 0x00E2E3A0: CMP w26, #1                | STATE = COMPARE(this.Ctors.Length, 0x1) 
            // 0x00E2E3A4: B.LT #0xe2e404             | if (val_7 < 1) goto label_8;            
            if(val_7 < 1)
            {
                goto label_8;
            }
            // 0x00E2E3A8: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_8 = 0;
            // 0x00E2E3AC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            var val_7 = 0;
            // 0x00E2E3B0: SXTW x25, w26              | X25 = (long)(int)(this.Ctors.Length);   
            val_9 = (long)val_7;
            // 0x00E2E3B4: B #0xe2e3c0                |  goto label_3;                          
            goto label_3;
            label_7:
            // 0x00E2E3B8: LDR x24, [x20]             | X24 = this.Ctors;                       
            val_6 = val_6;
            // 0x00E2E3BC: ADD x22, x22, #0x10        | X22 = (val_8 + 16) = val_8 (0x00000010);
            val_8 = 16;
            label_3:
            // 0x00E2E3C0: CBNZ x24, #0xe2e3c8        | if (this.Ctors != null) goto label_4;   
            if(val_6 != null)
            {
                goto label_4;
            }
            // 0x00E2E3C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16D4, ????);     
            label_4:
            // 0x00E2E3C8: LDR w8, [x24, #0x18]       | W8 = this.Ctors.Length; //P2            
            // 0x00E2E3CC: CMP x23, x8                | STATE = COMPARE(0x0, this.Ctors.Length) 
            // 0x00E2E3D0: B.LO #0xe2e3e0             | if (0 < this.Ctors.Length) goto label_5;
            if(val_7 < this.Ctors.Length)
            {
                goto label_5;
            }
            // 0x00E2E3D4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x16D4, ????);     
            // 0x00E2E3D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2E3DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x16D4, ????);     
            label_5:
            // 0x00E2E3E0: ADD x8, x24, x22           | X8 = this.Ctors[0x10]; //PARR1          
            // 0x00E2E3E4: LDR x8, [x8, #0x20]        | X8 = this.Ctors[0x10][0]                
            Ctor val_6 = val_6[val_8];
            // 0x00E2E3E8: CMP x8, x19                | STATE = COMPARE(this.Ctors[0x10][0], param)
            // 0x00E2E3EC: B.EQ #0xe2e5ac             | if (val_6[val_8] == val_4) goto label_6;
            if(val_6 == val_4)
            {
                goto label_6;
            }
            // 0x00E2E3F0: ADD x23, x23, #1           | X23 = (0 + 1);                          
            val_7 = val_7 + 1;
            // 0x00E2E3F4: CMP x23, x25               | STATE = COMPARE((0 + 1), (long)(int)(this.Ctors.Length))
            // 0x00E2E3F8: B.LT #0xe2e3b8             | if (0 < val_9) goto label_7;            
            if(val_7 < val_9)
            {
                goto label_7;
            }
            // 0x00E2E3FC: B #0xe2e404                |  goto label_8;                          
            goto label_8;
            label_1:
            // 0x00E2E400: MOV w26, wzr               | W26 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_8:
            // 0x00E2E404: CBZ x19, #0xe2e508         | if (param == null) goto label_9;        
            if(val_4 == null)
            {
                goto label_9;
            }
            // 0x00E2E408: ADRP x27, #0x3679000       | X27 = 57118720 (0x3679000);             
            // 0x00E2E40C: ADRP x28, #0x3647000       | X28 = 56913920 (0x3647000);             
            // 0x00E2E410: LDR x27, [x27, #0xb60]     | X27 = 1152921504828358656;              
            // 0x00E2E414: LDR x28, [x28, #0xf28]     | X28 = 1152921504828198912;              
            // 0x00E2E418: MOV x22, x19               | X22 = param;//m1                        
            label_21:
            // 0x00E2E41C: LDR x0, [x27]              | X0 = typeof(wxb.IL.Help);               
            val_10 = null;
            // 0x00E2E420: LDRB w8, [x0, #0x10a]      | W8 = wxb.IL.Help.__il2cppRuntimeField_10A;
            // 0x00E2E424: TBZ w8, #0, #0xe2e438      | if (wxb.IL.Help.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x00E2E428: LDR w8, [x0, #0xbc]        | W8 = wxb.IL.Help.__il2cppRuntimeField_cctor_finished;
            // 0x00E2E42C: CBNZ w8, #0xe2e438         | if (wxb.IL.Help.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x00E2E430: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(wxb.IL.Help), ????);
            // 0x00E2E434: LDR x0, [x27]              | X0 = typeof(wxb.IL.Help);               
            val_10 = null;
            label_11:
            // 0x00E2E438: LDR x8, [x0, #0xa0]        | X8 = wxb.IL.Help.__il2cppRuntimeField_static_fields;
            // 0x00E2E43C: LDR x23, [x8, #0x18]       | X23 = wxb.IL.Help.OneType;              
            // 0x00E2E440: CBNZ x23, #0xe2e448        | if (wxb.IL.Help.OneType != null) goto label_12;
            if(wxb.IL.Help.OneType != null)
            {
                goto label_12;
            }
            // 0x00E2E444: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(wxb.IL.Help), ????);
            label_12:
            // 0x00E2E448: CBZ x22, #0xe2e46c         | if (param == null) goto label_14;       
            if(val_4 == null)
            {
                goto label_14;
            }
            // 0x00E2E44C: LDR x8, [x23]              | X8 =  typeof(System.Type[]);            
            // 0x00E2E450: MOV x0, x22                | X0 = param;//m1                         
            // 0x00E2E454: LDR x1, [x8, #0x30]        | X1 = System.Type[].__il2cppRuntimeField_element_class;
            // 0x00E2E458: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? param, ????);      
            // 0x00E2E45C: CBNZ x0, #0xe2e46c         | if (param != null) goto label_14;       
            if(val_4 != null)
            {
                goto label_14;
            }
            // 0x00E2E460: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? param, ????);      
            // 0x00E2E464: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2E468: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? param, ????);      
            label_14:
            // 0x00E2E46C: LDR w8, [x23, #0x18]       | W8 = wxb.IL.Help.OneType.Length;        
            // 0x00E2E470: CBNZ w8, #0xe2e480         | if (wxb.IL.Help.OneType.Length != 0) goto label_15;
            if(wxb.IL.Help.OneType.Length != 0)
            {
                goto label_15;
            }
            // 0x00E2E474: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? param, ????);      
            // 0x00E2E478: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2E47C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? param, ????);      
            label_15:
            // 0x00E2E480: STR x22, [x23, #0x20]      | wxb.IL.Help.OneType.__unknownFiledOffset_20 = param;  //  dest_result_addr=0
            wxb.IL.Help.OneType.__unknownFiledOffset_20 = val_4;
            // 0x00E2E484: LDR x0, [x28]              | X0 = typeof(wxb.CacheType);             
            val_11 = null;
            // 0x00E2E488: LDR x23, [x21, #0x10]      | X23 = this.<type>k__BackingField; //P2  
            // 0x00E2E48C: LDRB w8, [x0, #0x10a]      | W8 = wxb.CacheType.__il2cppRuntimeField_10A;
            // 0x00E2E490: TBZ w8, #0, #0xe2e4a4      | if (wxb.CacheType.__il2cppRuntimeField_has_cctor == 0) goto label_17;
            // 0x00E2E494: LDR w8, [x0, #0xbc]        | W8 = wxb.CacheType.__il2cppRuntimeField_cctor_finished;
            // 0x00E2E498: CBNZ w8, #0xe2e4a4         | if (wxb.CacheType.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
            // 0x00E2E49C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(wxb.CacheType), ????);
            // 0x00E2E4A0: LDR x0, [x28]              | X0 = typeof(wxb.CacheType);             
            val_11 = null;
            label_17:
            // 0x00E2E4A4: LDR x8, [x27]              | X8 = typeof(wxb.IL.Help);               
            // 0x00E2E4A8: LDR x9, [x0, #0xa0]        | X9 = wxb.CacheType.__il2cppRuntimeField_static_fields;
            // 0x00E2E4AC: LDR x8, [x8, #0xa0]        | X8 = wxb.IL.Help.__il2cppRuntimeField_static_fields;
            // 0x00E2E4B0: LDR w25, [x9]              | W25 = wxb.CacheType.Flags;              
            val_9 = wxb.CacheType.Flags;
            // 0x00E2E4B4: LDR x24, [x8, #0x18]       | X24 = wxb.IL.Help.OneType;              
            // 0x00E2E4B8: CBNZ x23, #0xe2e4c0        | if (this.<type>k__BackingField != null) goto label_18;
            if((this.<type>k__BackingField) != null)
            {
                goto label_18;
            }
            // 0x00E2E4BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(wxb.CacheType), ????);
            label_18:
            // 0x00E2E4C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2E4C4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00E2E4C8: MOV x0, x23                | X0 = this.<type>k__BackingField;//m1    
            // 0x00E2E4CC: MOV w1, w25                | W1 = wxb.CacheType.Flags;//m1           
            // 0x00E2E4D0: MOV x3, x24                | X3 = wxb.IL.Help.OneType;//m1           
            // 0x00E2E4D4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00E2E4D8: BL #0x1b6ea10              | X0 = this.<type>k__BackingField.GetConstructor(bindingAttr:  val_9, binder:  0, types:  wxb.IL.Help.OneType, modifiers:  0);
            System.Reflection.ConstructorInfo val_1 = this.<type>k__BackingField.GetConstructor(bindingAttr:  val_9, binder:  0, types:  wxb.IL.Help.OneType, modifiers:  0);
            // 0x00E2E4DC: MOV x23, x0                | X23 = val_1;//m1                        
            val_12 = val_1;
            // 0x00E2E4E0: CBNZ x23, #0xe2e55c        | if (val_1 != null) goto label_19;       
            if(val_12 != null)
            {
                goto label_19;
            }
            // 0x00E2E4E4: CBNZ x22, #0xe2e4ec        | if (param != null) goto label_20;       
            if(val_4 != null)
            {
                goto label_20;
            }
            // 0x00E2E4E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_20:
            // 0x00E2E4EC: LDR x8, [x22]              | X8 = typeof(System.Type);               
            // 0x00E2E4F0: MOV x0, x22                | X0 = param;//m1                         
            // 0x00E2E4F4: LDR x9, [x8, #0x220]       | X9 = typeof(System.Type).__il2cppRuntimeField_220;
            // 0x00E2E4F8: LDR x1, [x8, #0x228]       | X1 = typeof(System.Type).__il2cppRuntimeField_228;
            // 0x00E2E4FC: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_220();
            // 0x00E2E500: MOV x22, x0                | X22 = param;//m1                        
            // 0x00E2E504: CBNZ x22, #0xe2e41c        | if (param != null) goto label_21;       
            if(val_4 != null)
            {
                goto label_21;
            }
            label_9:
            // 0x00E2E508: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x00E2E50C: LDR x8, [x8, #0xf90]       | X8 = 1152921512983065488;               
            // 0x00E2E510: ADD w2, w26, #1            | W2 = (val_7 + 1);                       
            var val_2 = val_7 + 1;
            // 0x00E2E514: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            T[] val_3 = 0;
            // 0x00E2E518: MOV x1, x20                | X1 = 1152921512983090552 (0x10000001F3435578);//ML01
            // 0x00E2E51C: LDR x3, [x8]               | X3 = public static System.Void System.Array::Resize<Ctor>(ref T[] array, int newSize);
            // 0x00E2E520: BL #0x245dac0              | System.Array.Resize<Ctor>(array: ref  T[] val_3 = 0, newSize:  -213691016);
            System.Array.Resize<Ctor>(array: ref  val_3, newSize:  -213691016);
            // 0x00E2E524: LDR x20, [x20]             | X20 = this.Ctors;                       
            // 0x00E2E528: CBNZ x20, #0xe2e530        | if (this.Ctors != null) goto label_22;  
            if(val_6 != null)
            {
                goto label_22;
            }
            // 0x00E2E52C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_22:
            // 0x00E2E530: LDR w8, [x20, #0x18]       | W8 = this.Ctors.Length; //P2            
            // 0x00E2E534: SXTW x21, w26              | X21 = 0 (0x00000000);                   
            val_5 = 0;
            // 0x00E2E538: CMP w26, w8                | STATE = COMPARE(0x0, this.Ctors.Length) 
            // 0x00E2E53C: B.LO #0xe2e54c             | if (val_7 < this.Ctors.Length) goto label_23;
            if(val_7 < this.Ctors.Length)
            {
                goto label_23;
            }
            // 0x00E2E540: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x00E2E544: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2E548: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_23:
            // 0x00E2E54C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_12 = 0;
            // 0x00E2E550: ADD x8, x20, x21, lsl #4   | X8 = this.Ctors[0x0]; //PARR1           
            // 0x00E2E554: STP x19, xzr, [x8, #0x20]  | this.Ctors[0x0][0] = param;  this.Ctors[0x0][1] = new Ctor();  //  dest_result_addr=0 |  dest_result_addr=0
            val_6[0] = val_4;
            val_6[0] = 0;
            // 0x00E2E558: B #0xe2e5d8                |  goto label_27;                         
            goto label_27;
            label_19:
            // 0x00E2E55C: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x00E2E560: LDR x8, [x8, #0xf90]       | X8 = 1152921512983065488;               
            // 0x00E2E564: ADD w2, w26, #1            | W2 = (val_7 + 1);                       
            var val_4 = val_7 + 1;
            // 0x00E2E568: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            T[] val_5 = 0;
            // 0x00E2E56C: MOV x1, x20                | X1 = 1152921512983090552 (0x10000001F3435578);//ML01
            // 0x00E2E570: LDR x3, [x8]               | X3 = public static System.Void System.Array::Resize<Ctor>(ref T[] array, int newSize);
            // 0x00E2E574: BL #0x245dac0              | System.Array.Resize<Ctor>(array: ref  T[] val_5 = 0, newSize:  -213691016);
            System.Array.Resize<Ctor>(array: ref  val_5, newSize:  -213691016);
            // 0x00E2E578: LDR x20, [x20]             | X20 = this.Ctors;                       
            // 0x00E2E57C: CBNZ x20, #0xe2e584        | if (this.Ctors != null) goto label_25;  
            if(val_6 != null)
            {
                goto label_25;
            }
            // 0x00E2E580: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_25:
            // 0x00E2E584: LDR w8, [x20, #0x18]       | W8 = this.Ctors.Length; //P2            
            // 0x00E2E588: SXTW x21, w26              | X21 = 0 (0x00000000);                   
            val_5 = 0;
            // 0x00E2E58C: CMP w26, w8                | STATE = COMPARE(0x0, this.Ctors.Length) 
            // 0x00E2E590: B.LO #0xe2e5a0             | if (val_7 < this.Ctors.Length) goto label_26;
            if(val_7 < this.Ctors.Length)
            {
                goto label_26;
            }
            // 0x00E2E594: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x00E2E598: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2E59C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_26:
            // 0x00E2E5A0: ADD x8, x20, x21, lsl #4   | X8 = this.Ctors[0x0]; //PARR1           
            // 0x00E2E5A4: STP x19, x23, [x8, #0x20]  | this.Ctors[0x0][0] = param;  this.Ctors[0x0][1] = val_1;  //  dest_result_addr=0 |  dest_result_addr=0
            val_6[0] = val_4;
            val_6[0] = val_12;
            // 0x00E2E5A8: B #0xe2e5d8                |  goto label_27;                         
            goto label_27;
            label_6:
            // 0x00E2E5AC: LDR x19, [x20]             | X19 = this.Ctors;                       
            val_4 = val_6;
            // 0x00E2E5B0: CBNZ x19, #0xe2e5b8        | if (this.Ctors != null) goto label_28;  
            if(val_4 != null)
            {
                goto label_28;
            }
            // 0x00E2E5B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16D4, ????);     
            label_28:
            // 0x00E2E5B8: LDR w8, [x19, #0x18]       | W8 = this.Ctors.Length; //P2            
            // 0x00E2E5BC: CMP w23, w8                | STATE = COMPARE(0x0, this.Ctors.Length) 
            // 0x00E2E5C0: B.LO #0xe2e5d0             | if (0 < this.Ctors.Length) goto label_29;
            if(val_7 < this.Ctors.Length)
            {
                goto label_29;
            }
            // 0x00E2E5C4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x16D4, ????);     
            // 0x00E2E5C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2E5CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x16D4, ????);     
            label_29:
            // 0x00E2E5D0: ADD x8, x19, x22           | X8 = this.Ctors[0x10]; //PARR1          
            // 0x00E2E5D4: LDR x23, [x8, #0x28]       | X23 = this.Ctors[0x10][1]               
            val_12 = val_4[val_8];
            label_27:
            // 0x00E2E5D8: MOV x0, x23                | X0 = this.Ctors[0x10][1];//m1           
            // 0x00E2E5DC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2E5E0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2E5E4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00E2E5E8: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00E2E5EC: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00E2E5F0: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00E2E5F4: RET                        |  return (System.Reflection.ConstructorInfo)this.Ctors[0x10][1];
            return (System.Reflection.ConstructorInfo)val_12;
            //  |  // // {name=val_0, type=System.Reflection.ConstructorInfo, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2E5F8 (14870008), len: 536  VirtAddr: 0x00E2E5F8 RVA: 0x00E2E5F8 token: 100680909 methodIndex: 57311 delegateWrapperIndex: 0 methodInvoker: 0
        private static System.Reflection.MethodInfo GetMethodInfo(System.Type type, string name)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x00E2E5F8: STP x24, x23, [sp, #-0x40]! | stack[1152921512983251888] = ???;  stack[1152921512983251896] = ???;  //  dest_result_addr=1152921512983251888 |  dest_result_addr=1152921512983251896
            // 0x00E2E5FC: STP x22, x21, [sp, #0x10]  | stack[1152921512983251904] = ???;  stack[1152921512983251912] = ???;  //  dest_result_addr=1152921512983251904 |  dest_result_addr=1152921512983251912
            // 0x00E2E600: STP x20, x19, [sp, #0x20]  | stack[1152921512983251920] = ???;  stack[1152921512983251928] = ???;  //  dest_result_addr=1152921512983251920 |  dest_result_addr=1152921512983251928
            // 0x00E2E604: STP x29, x30, [sp, #0x30]  | stack[1152921512983251936] = ???;  stack[1152921512983251944] = ???;  //  dest_result_addr=1152921512983251936 |  dest_result_addr=1152921512983251944
            // 0x00E2E608: ADD x29, sp, #0x30         | X29 = (1152921512983251888 + 48) = 1152921512983251936 (0x10000001F345CBE0);
            // 0x00E2E60C: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2E610: LDRB w8, [x21, #0x935]     | W8 = (bool)static_value_03734935;       
            // 0x00E2E614: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00E2E618: MOV x20, x1                | X20 = name;//m1                         
            // 0x00E2E61C: TBNZ w8, #0, #0xe2e638     | if (static_value_03734935 == true) goto label_0;
            // 0x00E2E620: ADRP x8, #0x3684000        | X8 = 57163776 (0x3684000);              
            // 0x00E2E624: LDR x8, [x8, #0x520]       | X8 = 0x2B9004C;                         
            // 0x00E2E628: LDR w0, [x8]               | W0 = 0x16D7;                            
            // 0x00E2E62C: BL #0x2782188              | X0 = sub_2782188( ?? 0x16D7, ????);     
            // 0x00E2E630: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2E634: STRB w8, [x21, #0x935]     | static_value_03734935 = true;            //  dest_result_addr=57887029
            label_0:
            // 0x00E2E638: ADRP x22, #0x3647000       | X22 = 56913920 (0x3647000);             
            // 0x00E2E63C: LDR x22, [x22, #0xf28]     | X22 = 1152921504828198912;              
            // 0x00E2E640: LDR x0, [x22]              | X0 = typeof(wxb.CacheType);             
            val_2 = null;
            // 0x00E2E644: LDRB w8, [x0, #0x10a]      | W8 = wxb.CacheType.__il2cppRuntimeField_10A;
            // 0x00E2E648: TBZ w8, #0, #0xe2e65c      | if (wxb.CacheType.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E2E64C: LDR w8, [x0, #0xbc]        | W8 = wxb.CacheType.__il2cppRuntimeField_cctor_finished;
            // 0x00E2E650: CBNZ w8, #0xe2e65c         | if (wxb.CacheType.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E2E654: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(wxb.CacheType), ????);
            // 0x00E2E658: LDR x0, [x22]              | X0 = typeof(wxb.CacheType);             
            val_2 = null;
            label_2:
            // 0x00E2E65C: LDR x8, [x0, #0xa0]        | X8 = wxb.CacheType.__il2cppRuntimeField_static_fields;
            // 0x00E2E660: LDR w21, [x8]              | W21 = wxb.CacheType.Flags;              
            // 0x00E2E664: CBNZ x20, #0xe2e66c        | if (name != null) goto label_3;         
            if(name != null)
            {
                goto label_3;
            }
            // 0x00E2E668: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(wxb.CacheType), ????);
            label_3:
            // 0x00E2E66C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E2E670: MOV x0, x20                | X0 = name;//m1                          
            // 0x00E2E674: MOV x1, x19                | X1 = X2;//m1                            
            // 0x00E2E678: MOV w2, w21                | W2 = wxb.CacheType.Flags;//m1           
            // 0x00E2E67C: BL #0x1b6e098              | X0 = name.GetMethod(name:  X2, bindingAttr:  wxb.CacheType.Flags);
            System.Reflection.MethodInfo val_1 = name.GetMethod(name:  X2, bindingAttr:  wxb.CacheType.Flags);
            // 0x00E2E680: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2E684: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2E688: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00E2E68C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00E2E690: RET                        |  return (System.Reflection.MethodInfo)val_1;
            return val_1;
            //  |  // // {name=val_0, type=System.Reflection.MethodInfo, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2E810 (14870544), len: 404  VirtAddr: 0x00E2E810 RVA: 0x00E2E810 token: 100680910 methodIndex: 57312 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Reflection.MethodInfo GetMethod(string name)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            System.Reflection.MemberInfo val_6;
            // 0x00E2E810: STP x24, x23, [sp, #-0x40]! | stack[1152921512983397680] = ???;  stack[1152921512983397688] = ???;  //  dest_result_addr=1152921512983397680 |  dest_result_addr=1152921512983397688
            // 0x00E2E814: STP x22, x21, [sp, #0x10]  | stack[1152921512983397696] = ???;  stack[1152921512983397704] = ???;  //  dest_result_addr=1152921512983397696 |  dest_result_addr=1152921512983397704
            // 0x00E2E818: STP x20, x19, [sp, #0x20]  | stack[1152921512983397712] = ???;  stack[1152921512983397720] = ???;  //  dest_result_addr=1152921512983397712 |  dest_result_addr=1152921512983397720
            // 0x00E2E81C: STP x29, x30, [sp, #0x30]  | stack[1152921512983397728] = ???;  stack[1152921512983397736] = ???;  //  dest_result_addr=1152921512983397728 |  dest_result_addr=1152921512983397736
            // 0x00E2E820: ADD x29, sp, #0x30         | X29 = (1152921512983397680 + 48) = 1152921512983397728 (0x10000001F3480560);
            // 0x00E2E824: SUB sp, sp, #0x10          | SP = (1152921512983397680 - 16) = 1152921512983397664 (0x10000001F3480520);
            // 0x00E2E828: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2E82C: LDRB w8, [x21, #0x936]     | W8 = (bool)static_value_03734936;       
            // 0x00E2E830: MOV x19, x1                | X19 = name;//m1                         
            // 0x00E2E834: MOV x20, x0                | X20 = 1152921512983409744 (0x10000001F3483450);//ML01
            // 0x00E2E838: TBNZ w8, #0, #0xe2e854     | if (static_value_03734936 == true) goto label_0;
            // 0x00E2E83C: ADRP x8, #0x365c000        | X8 = 56999936 (0x365C000);              
            // 0x00E2E840: LDR x8, [x8, #0x508]       | X8 = 0x2B90048;                         
            // 0x00E2E844: LDR w0, [x8]               | W0 = 0x16D6;                            
            // 0x00E2E848: BL #0x2782188              | X0 = sub_2782188( ?? 0x16D6, ????);     
            // 0x00E2E84C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2E850: STRB w8, [x21, #0x936]     | static_value_03734936 = true;            //  dest_result_addr=57887030
            label_0:
            // 0x00E2E854: STR xzr, [sp]              | stack[1152921512983397664] = 0x0;        //  dest_result_addr=1152921512983397664
            System.Reflection.MemberInfo val_1 = 0;
            // 0x00E2E858: LDR x21, [x20, #0x18]      | X21 = this.NameToMethodBase; //P2       
            // 0x00E2E85C: CBNZ x21, #0xe2e864        | if (this.NameToMethodBase != null) goto label_1;
            if(this.NameToMethodBase != null)
            {
                goto label_1;
            }
            // 0x00E2E860: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16D6, ????);     
            label_1:
            // 0x00E2E864: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x00E2E868: LDR x8, [x8, #0xe50]       | X8 = 1152921509759349344;               
            // 0x00E2E86C: MOV x2, sp                 | X2 = 1152921512983397664 (0x10000001F3480520);//ML01
            // 0x00E2E870: MOV x0, x21                | X0 = this.NameToMethodBase;//m1         
            // 0x00E2E874: MOV x1, x19                | X1 = name;//m1                          
            // 0x00E2E878: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Reflection.MemberInfo>::TryGetValue(System.String key, out System.Reflection.MemberInfo value);
            // 0x00E2E87C: BL #0x23fe7ec              | X0 = this.NameToMethodBase.TryGetValue(key:  name, value: out  System.Reflection.MemberInfo val_1 = 0);
            bool val_2 = this.NameToMethodBase.TryGetValue(key:  name, value: out  val_1);
            // 0x00E2E880: TBZ w0, #0, #0xe2e8ec      | if (val_2 == false) goto label_2;       
            if(val_2 == false)
            {
                goto label_2;
            }
            // 0x00E2E884: LDR x21, [sp]              | X21 = 0x0;                              
            val_6 = val_1;
            // 0x00E2E888: CBZ x21, #0xe2e8e4         | if (0x0 == 0) goto label_3;             
            if(val_6 == 0)
            {
                goto label_3;
            }
            // 0x00E2E88C: ADRP x9, #0x35b8000        | X9 = 56328192 (0x35B8000);              
            // 0x00E2E890: LDR x9, [x9, #0x408]       | X9 = 1152921504627560448;               
            // 0x00E2E894: LDR x8, [x21]              | X8 = 0x10102464C457F;                   
            // 0x00E2E898: LDR x1, [x9]               | X1 = typeof(System.Reflection.MethodInfo);
            // 0x00E2E89C: LDRB w10, [x8, #0x104]     | W10 = (bool)mem[282584257676931];       
            // 0x00E2E8A0: LDRB w9, [x1, #0x104]      | W9 = System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00E2E8A4: CMP w10, w9                | STATE = COMPARE(mem[282584257676931], System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00E2E8A8: B.LO #0xe2e8c0             | if (mem[282584257676931] < System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00E2E8AC: LDR x10, [x8, #0xb0]       | X10 = mem[282584257676847];             
            // 0x00E2E8B0: ADD x9, x10, x9, lsl #3    | X9 = (mem[282584257676847] + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) 
            // 0x00E2E8B4: LDUR x9, [x9, #-8]         | X9 = (mem[282584257676847] + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00E2E8B8: CMP x9, x1                 | STATE = COMPARE((mem[282584257676847] + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Reflection.MethodInfo))
            // 0x00E2E8BC: B.EQ #0xe2e974             | if ((mem[282584257676847] + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_6;
            label_4:
            // 0x00E2E8C0: LDR x0, [x8, #0x30]        | X0 = mem[282584257676719];              
            // 0x00E2E8C4: ADD x8, sp, #8             | X8 = (1152921512983397664 + 8) = 1152921512983397672 (0x10000001F3480528);
            // 0x00E2E8C8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[282584257676719], ????);
            // 0x00E2E8CC: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921512983385744]
            // 0x00E2E8D0: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00E2E8D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2E8D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00E2E8DC: ADD x0, sp, #8             | X0 = (1152921512983397664 + 8) = 1152921512983397672 (0x10000001F3480528);
            // 0x00E2E8E0: BL #0x299a140              | 
            label_3:
            // 0x00E2E8E4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            // 0x00E2E8E8: B #0xe2e974                |  goto label_6;                          
            goto label_6;
            label_2:
            // 0x00E2E8EC: ADRP x23, #0x3647000       | X23 = 56913920 (0x3647000);             
            // 0x00E2E8F0: LDR x22, [x20, #0x10]      | X22 = this.<type>k__BackingField; //P2  
            // 0x00E2E8F4: LDR x23, [x23, #0xf28]     | X23 = 1152921504828198912;              
            label_11:
            // 0x00E2E8F8: LDR x0, [x23]              | X0 = typeof(wxb.CacheType);             
            // 0x00E2E8FC: LDRB w8, [x0, #0x10a]      | W8 = wxb.CacheType.__il2cppRuntimeField_10A;
            // 0x00E2E900: TBZ w8, #0, #0xe2e910      | if (wxb.CacheType.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00E2E904: LDR w8, [x0, #0xbc]        | W8 = wxb.CacheType.__il2cppRuntimeField_cctor_finished;
            // 0x00E2E908: CBNZ w8, #0xe2e910         | if (wxb.CacheType.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00E2E90C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(wxb.CacheType), ????);
            label_8:
            // 0x00E2E910: MOV x1, x22                | X1 = this.<type>k__BackingField;//m1    
            // 0x00E2E914: MOV x2, x19                | X2 = name;//m1                          
            // 0x00E2E918: BL #0xe2e5f8               | X0 = wxb.CacheType.GetMethodInfo(type:  null, name:  this.<type>k__BackingField);
            System.Reflection.MethodInfo val_5 = wxb.CacheType.GetMethodInfo(type:  null, name:  this.<type>k__BackingField);
            // 0x00E2E91C: MOV x21, x0                | X21 = val_5;//m1                        
            val_6 = val_5;
            // 0x00E2E920: CBNZ x21, #0xe2e94c        | if (val_5 != null) goto label_9;        
            if(val_6 != null)
            {
                goto label_9;
            }
            // 0x00E2E924: CBNZ x22, #0xe2e92c        | if (this.<type>k__BackingField != null) goto label_10;
            if((this.<type>k__BackingField) != null)
            {
                goto label_10;
            }
            // 0x00E2E928: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_10:
            // 0x00E2E92C: LDR x8, [x22]              | X8 = typeof(System.Type);               
            // 0x00E2E930: MOV x0, x22                | X0 = this.<type>k__BackingField;//m1    
            // 0x00E2E934: LDR x9, [x8, #0x220]       | X9 = typeof(System.Type).__il2cppRuntimeField_220;
            // 0x00E2E938: LDR x1, [x8, #0x228]       | X1 = typeof(System.Type).__il2cppRuntimeField_228;
            // 0x00E2E93C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_220();
            // 0x00E2E940: MOV x22, x0                | X22 = this.<type>k__BackingField;//m1   
            // 0x00E2E944: CBNZ x22, #0xe2e8f8        | if (this.<type>k__BackingField != null) goto label_11;
            if((this.<type>k__BackingField) != null)
            {
                goto label_11;
            }
            // 0x00E2E948: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_9:
            // 0x00E2E94C: LDR x20, [x20, #0x18]      | X20 = this.NameToMethodBase; //P2       
            // 0x00E2E950: CBNZ x20, #0xe2e958        | if (this.NameToMethodBase != null) goto label_12;
            if(this.NameToMethodBase != null)
            {
                goto label_12;
            }
            // 0x00E2E954: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.<type>k__BackingField, ????);
            label_12:
            // 0x00E2E958: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x00E2E95C: LDR x8, [x8, #0xb58]       | X8 = 1152921512983384720;               
            // 0x00E2E960: MOV x0, x20                | X0 = this.NameToMethodBase;//m1         
            // 0x00E2E964: MOV x1, x19                | X1 = name;//m1                          
            // 0x00E2E968: MOV x2, x21                | X2 = 0 (0x0);//ML01                     
            // 0x00E2E96C: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Reflection.MemberInfo>::Add(System.String key, System.Reflection.MemberInfo value);
            // 0x00E2E970: BL #0x23fd44c              | this.NameToMethodBase.Add(key:  name, value:  val_6);
            this.NameToMethodBase.Add(key:  name, value:  val_6);
            label_6:
            // 0x00E2E974: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00E2E978: SUB sp, x29, #0x30         | SP = (1152921512983397728 - 48) = 1152921512983397680 (0x10000001F3480530);
            // 0x00E2E97C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2E980: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2E984: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00E2E988: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00E2E98C: RET                        |  return (System.Reflection.MethodInfo)null;
            return (System.Reflection.MethodInfo)val_6;
            //  |  // // {name=val_0, type=System.Reflection.MethodInfo, size=8, nGRN=0 }
            // 0x00E2E990: MOV x19, x0                | 
            // 0x00E2E994: ADD x0, sp, #8             | 
            // 0x00E2E998: BL #0x299a140              | 
            // 0x00E2E99C: MOV x0, x19                | 
            // 0x00E2E9A0: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2E9A4 (14870948), len: 432  VirtAddr: 0x00E2E9A4 RVA: 0x00E2E9A4 token: 100680911 methodIndex: 57313 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Reflection.PropertyInfo GetProperty(string name)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            System.Collections.Generic.Dictionary<System.String, System.Reflection.MemberInfo> val_6;
            //  | 
            System.Reflection.MemberInfo val_7;
            //  | 
            var val_8;
            // 0x00E2E9A4: STP x24, x23, [sp, #-0x40]! | stack[1152921512983550640] = ???;  stack[1152921512983550648] = ???;  //  dest_result_addr=1152921512983550640 |  dest_result_addr=1152921512983550648
            // 0x00E2E9A8: STP x22, x21, [sp, #0x10]  | stack[1152921512983550656] = ???;  stack[1152921512983550664] = ???;  //  dest_result_addr=1152921512983550656 |  dest_result_addr=1152921512983550664
            // 0x00E2E9AC: STP x20, x19, [sp, #0x20]  | stack[1152921512983550672] = ???;  stack[1152921512983550680] = ???;  //  dest_result_addr=1152921512983550672 |  dest_result_addr=1152921512983550680
            // 0x00E2E9B0: STP x29, x30, [sp, #0x30]  | stack[1152921512983550688] = ???;  stack[1152921512983550696] = ???;  //  dest_result_addr=1152921512983550688 |  dest_result_addr=1152921512983550696
            // 0x00E2E9B4: ADD x29, sp, #0x30         | X29 = (1152921512983550640 + 48) = 1152921512983550688 (0x10000001F34A5AE0);
            // 0x00E2E9B8: SUB sp, sp, #0x10          | SP = (1152921512983550640 - 16) = 1152921512983550624 (0x10000001F34A5AA0);
            // 0x00E2E9BC: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2E9C0: LDRB w8, [x21, #0x937]     | W8 = (bool)static_value_03734937;       
            // 0x00E2E9C4: MOV x19, x1                | X19 = name;//m1                         
            // 0x00E2E9C8: MOV x20, x0                | X20 = 1152921512983562704 (0x10000001F34A89D0);//ML01
            // 0x00E2E9CC: TBNZ w8, #0, #0xe2e9e8     | if (static_value_03734937 == true) goto label_0;
            // 0x00E2E9D0: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
            // 0x00E2E9D4: LDR x8, [x8, #0x58]        | X8 = 0x2B90050;                         
            // 0x00E2E9D8: LDR w0, [x8]               | W0 = 0x16D8;                            
            // 0x00E2E9DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x16D8, ????);     
            // 0x00E2E9E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2E9E4: STRB w8, [x21, #0x937]     | static_value_03734937 = true;            //  dest_result_addr=57887031
            label_0:
            // 0x00E2E9E8: STR xzr, [sp]              | stack[1152921512983550624] = 0x0;        //  dest_result_addr=1152921512983550624
            System.Reflection.MemberInfo val_1 = 0;
            // 0x00E2E9EC: LDR x21, [x20, #0x18]      | X21 = this.NameToMethodBase; //P2       
            val_6 = this.NameToMethodBase;
            // 0x00E2E9F0: CBNZ x21, #0xe2e9f8        | if (this.NameToMethodBase != null) goto label_1;
            if(val_6 != null)
            {
                goto label_1;
            }
            // 0x00E2E9F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16D8, ????);     
            label_1:
            // 0x00E2E9F8: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x00E2E9FC: LDR x8, [x8, #0xe50]       | X8 = 1152921509759349344;               
            // 0x00E2EA00: MOV x2, sp                 | X2 = 1152921512983550624 (0x10000001F34A5AA0);//ML01
            // 0x00E2EA04: MOV x0, x21                | X0 = this.NameToMethodBase;//m1         
            // 0x00E2EA08: MOV x1, x19                | X1 = name;//m1                          
            // 0x00E2EA0C: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Reflection.MemberInfo>::TryGetValue(System.String key, out System.Reflection.MemberInfo value);
            // 0x00E2EA10: BL #0x23fe7ec              | X0 = this.NameToMethodBase.TryGetValue(key:  name, value: out  System.Reflection.MemberInfo val_1 = 0);
            bool val_2 = val_6.TryGetValue(key:  name, value: out  val_1);
            // 0x00E2EA14: TBZ w0, #0, #0xe2ea80      | if (val_2 == false) goto label_2;       
            if(val_2 == false)
            {
                goto label_2;
            }
            // 0x00E2EA18: LDR x22, [sp]              | X22 = 0x0;                              
            val_7 = val_1;
            // 0x00E2EA1C: CBZ x22, #0xe2ea78         | if (0x0 == 0) goto label_3;             
            if(val_7 == 0)
            {
                goto label_3;
            }
            // 0x00E2EA20: ADRP x9, #0x3635000        | X9 = 56840192 (0x3635000);              
            // 0x00E2EA24: LDR x9, [x9, #0x720]       | X9 = 1152921504628891648;               
            // 0x00E2EA28: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            // 0x00E2EA2C: LDR x1, [x9]               | X1 = typeof(System.Reflection.PropertyInfo);
            // 0x00E2EA30: LDRB w10, [x8, #0x104]     | W10 = (bool)mem[282584257676931];       
            // 0x00E2EA34: LDRB w9, [x1, #0x104]      | W9 = System.Reflection.PropertyInfo.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00E2EA38: CMP w10, w9                | STATE = COMPARE(mem[282584257676931], System.Reflection.PropertyInfo.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00E2EA3C: B.LO #0xe2ea54             | if (mem[282584257676931] < System.Reflection.PropertyInfo.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00E2EA40: LDR x10, [x8, #0xb0]       | X10 = mem[282584257676847];             
            // 0x00E2EA44: ADD x9, x10, x9, lsl #3    | X9 = (mem[282584257676847] + (System.Reflection.PropertyInfo.__il2cppRuntimeField_typeHierarchyDepth
            // 0x00E2EA48: LDUR x9, [x9, #-8]         | X9 = (mem[282584257676847] + (System.Reflection.PropertyInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00E2EA4C: CMP x9, x1                 | STATE = COMPARE((mem[282584257676847] + (System.Reflection.PropertyInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Reflection.PropertyInfo))
            // 0x00E2EA50: B.EQ #0xe2eb24             | if ((mem[282584257676847] + (System.Reflection.PropertyInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_6;
            label_4:
            // 0x00E2EA54: LDR x0, [x8, #0x30]        | X0 = mem[282584257676719];              
            // 0x00E2EA58: ADD x8, sp, #8             | X8 = (1152921512983550624 + 8) = 1152921512983550632 (0x10000001F34A5AA8);
            // 0x00E2EA5C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[282584257676719], ????);
            // 0x00E2EA60: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921512983538704]
            // 0x00E2EA64: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00E2EA68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2EA6C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00E2EA70: ADD x0, sp, #8             | X0 = (1152921512983550624 + 8) = 1152921512983550632 (0x10000001F34A5AA8);
            // 0x00E2EA74: BL #0x299a140              | 
            label_3:
            // 0x00E2EA78: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_7 = 0;
            // 0x00E2EA7C: B #0xe2eb24                |  goto label_6;                          
            goto label_6;
            label_2:
            // 0x00E2EA80: ADRP x23, #0x3647000       | X23 = 56913920 (0x3647000);             
            // 0x00E2EA84: LDR x21, [x20, #0x10]      | X21 = this.<type>k__BackingField; //P2  
            val_6 = this.<type>k__BackingField;
            // 0x00E2EA88: LDR x23, [x23, #0xf28]     | X23 = 1152921504828198912;              
            label_12:
            // 0x00E2EA8C: LDR x0, [x23]              | X0 = typeof(wxb.CacheType);             
            val_8 = null;
            // 0x00E2EA90: LDRB w8, [x0, #0x10a]      | W8 = wxb.CacheType.__il2cppRuntimeField_10A;
            // 0x00E2EA94: TBZ w8, #0, #0xe2eaa8      | if (wxb.CacheType.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00E2EA98: LDR w8, [x0, #0xbc]        | W8 = wxb.CacheType.__il2cppRuntimeField_cctor_finished;
            // 0x00E2EA9C: CBNZ w8, #0xe2eaa8         | if (wxb.CacheType.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00E2EAA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(wxb.CacheType), ????);
            // 0x00E2EAA4: LDR x0, [x23]              | X0 = typeof(wxb.CacheType);             
            val_8 = null;
            label_8:
            // 0x00E2EAA8: LDR x8, [x0, #0xa0]        | X8 = wxb.CacheType.__il2cppRuntimeField_static_fields;
            // 0x00E2EAAC: LDR w22, [x8]              | W22 = wxb.CacheType.Flags;              
            // 0x00E2EAB0: CBNZ x21, #0xe2eab8        | if (this.<type>k__BackingField != null) goto label_9;
            if(val_6 != null)
            {
                goto label_9;
            }
            // 0x00E2EAB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(wxb.CacheType), ????);
            label_9:
            // 0x00E2EAB8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E2EABC: MOV x0, x21                | X0 = this.<type>k__BackingField;//m1    
            // 0x00E2EAC0: MOV x1, x19                | X1 = name;//m1                          
            // 0x00E2EAC4: MOV w2, w22                | W2 = wxb.CacheType.Flags;//m1           
            // 0x00E2EAC8: BL #0x1b6e3b4              | X0 = this.<type>k__BackingField.GetProperty(name:  name, bindingAttr:  wxb.CacheType.Flags);
            System.Reflection.PropertyInfo val_5 = val_6.GetProperty(name:  name, bindingAttr:  wxb.CacheType.Flags);
            // 0x00E2EACC: MOV x22, x0                | X22 = val_5;//m1                        
            val_7 = val_5;
            // 0x00E2EAD0: CBNZ x22, #0xe2eafc        | if (val_5 != null) goto label_10;       
            if(val_7 != null)
            {
                goto label_10;
            }
            // 0x00E2EAD4: CBNZ x21, #0xe2eadc        | if (this.<type>k__BackingField != null) goto label_11;
            if(val_6 != null)
            {
                goto label_11;
            }
            // 0x00E2EAD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_11:
            // 0x00E2EADC: LDR x8, [x21]              | X8 = typeof(System.Type);               
            // 0x00E2EAE0: MOV x0, x21                | X0 = this.<type>k__BackingField;//m1    
            // 0x00E2EAE4: LDR x9, [x8, #0x220]       | X9 = typeof(System.Type).__il2cppRuntimeField_220;
            // 0x00E2EAE8: LDR x1, [x8, #0x228]       | X1 = typeof(System.Type).__il2cppRuntimeField_228;
            // 0x00E2EAEC: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_220();
            // 0x00E2EAF0: MOV x21, x0                | X21 = this.<type>k__BackingField;//m1   
            val_6 = val_6;
            // 0x00E2EAF4: CBNZ x21, #0xe2ea8c        | if (this.<type>k__BackingField != null) goto label_12;
            if(val_6 != null)
            {
                goto label_12;
            }
            // 0x00E2EAF8: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_10:
            // 0x00E2EAFC: LDR x20, [x20, #0x18]      | X20 = this.NameToMethodBase; //P2       
            // 0x00E2EB00: CBNZ x20, #0xe2eb08        | if (this.NameToMethodBase != null) goto label_13;
            if(this.NameToMethodBase != null)
            {
                goto label_13;
            }
            // 0x00E2EB04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.<type>k__BackingField, ????);
            label_13:
            // 0x00E2EB08: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x00E2EB0C: LDR x8, [x8, #0xb58]       | X8 = 1152921512983384720;               
            // 0x00E2EB10: MOV x0, x20                | X0 = this.NameToMethodBase;//m1         
            // 0x00E2EB14: MOV x1, x19                | X1 = name;//m1                          
            // 0x00E2EB18: MOV x2, x22                | X2 = 0 (0x0);//ML01                     
            // 0x00E2EB1C: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Reflection.MemberInfo>::Add(System.String key, System.Reflection.MemberInfo value);
            // 0x00E2EB20: BL #0x23fd44c              | this.NameToMethodBase.Add(key:  name, value:  val_7);
            this.NameToMethodBase.Add(key:  name, value:  val_7);
            label_6:
            // 0x00E2EB24: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00E2EB28: SUB sp, x29, #0x30         | SP = (1152921512983550688 - 48) = 1152921512983550640 (0x10000001F34A5AB0);
            // 0x00E2EB2C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2EB30: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2EB34: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00E2EB38: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00E2EB3C: RET                        |  return (System.Reflection.PropertyInfo)null;
            return (System.Reflection.PropertyInfo)val_7;
            //  |  // // {name=val_0, type=System.Reflection.PropertyInfo, size=8, nGRN=0 }
            // 0x00E2EB40: MOV x19, x0                | 
            // 0x00E2EB44: ADD x0, sp, #8             | 
            // 0x00E2EB48: BL #0x299a140              | 
            // 0x00E2EB4C: MOV x0, x19                | 
            // 0x00E2EB50: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2EB54 (14871380), len: 432  VirtAddr: 0x00E2EB54 RVA: 0x00E2EB54 token: 100680912 methodIndex: 57314 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Reflection.FieldInfo GetField(string name)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            System.Collections.Generic.Dictionary<System.String, System.Reflection.MemberInfo> val_5;
            //  | 
            System.Reflection.MemberInfo val_6;
            //  | 
            var val_7;
            // 0x00E2EB54: STP x24, x23, [sp, #-0x40]! | stack[1152921512983699504] = ???;  stack[1152921512983699512] = ???;  //  dest_result_addr=1152921512983699504 |  dest_result_addr=1152921512983699512
            // 0x00E2EB58: STP x22, x21, [sp, #0x10]  | stack[1152921512983699520] = ???;  stack[1152921512983699528] = ???;  //  dest_result_addr=1152921512983699520 |  dest_result_addr=1152921512983699528
            // 0x00E2EB5C: STP x20, x19, [sp, #0x20]  | stack[1152921512983699536] = ???;  stack[1152921512983699544] = ???;  //  dest_result_addr=1152921512983699536 |  dest_result_addr=1152921512983699544
            // 0x00E2EB60: STP x29, x30, [sp, #0x30]  | stack[1152921512983699552] = ???;  stack[1152921512983699560] = ???;  //  dest_result_addr=1152921512983699552 |  dest_result_addr=1152921512983699560
            // 0x00E2EB64: ADD x29, sp, #0x30         | X29 = (1152921512983699504 + 48) = 1152921512983699552 (0x10000001F34CA060);
            // 0x00E2EB68: SUB sp, sp, #0x10          | SP = (1152921512983699504 - 16) = 1152921512983699488 (0x10000001F34CA020);
            // 0x00E2EB6C: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2EB70: LDRB w8, [x21, #0x938]     | W8 = (bool)static_value_03734938;       
            // 0x00E2EB74: MOV x19, x1                | X19 = name;//m1                         
            // 0x00E2EB78: MOV x20, x0                | X20 = 1152921512983711568 (0x10000001F34CCF50);//ML01
            // 0x00E2EB7C: TBNZ w8, #0, #0xe2eb98     | if (static_value_03734938 == true) goto label_0;
            // 0x00E2EB80: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
            // 0x00E2EB84: LDR x8, [x8, #0xdb8]       | X8 = 0x2B90044;                         
            // 0x00E2EB88: LDR w0, [x8]               | W0 = 0x16D5;                            
            // 0x00E2EB8C: BL #0x2782188              | X0 = sub_2782188( ?? 0x16D5, ????);     
            // 0x00E2EB90: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2EB94: STRB w8, [x21, #0x938]     | static_value_03734938 = true;            //  dest_result_addr=57887032
            label_0:
            // 0x00E2EB98: STR xzr, [sp]              | stack[1152921512983699488] = 0x0;        //  dest_result_addr=1152921512983699488
            System.Reflection.MemberInfo val_1 = 0;
            // 0x00E2EB9C: LDR x21, [x20, #0x18]      | X21 = this.NameToMethodBase; //P2       
            val_5 = this.NameToMethodBase;
            // 0x00E2EBA0: CBNZ x21, #0xe2eba8        | if (this.NameToMethodBase != null) goto label_1;
            if(val_5 != null)
            {
                goto label_1;
            }
            // 0x00E2EBA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16D5, ????);     
            label_1:
            // 0x00E2EBA8: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x00E2EBAC: LDR x8, [x8, #0xe50]       | X8 = 1152921509759349344;               
            // 0x00E2EBB0: MOV x2, sp                 | X2 = 1152921512983699488 (0x10000001F34CA020);//ML01
            // 0x00E2EBB4: MOV x0, x21                | X0 = this.NameToMethodBase;//m1         
            // 0x00E2EBB8: MOV x1, x19                | X1 = name;//m1                          
            // 0x00E2EBBC: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Reflection.MemberInfo>::TryGetValue(System.String key, out System.Reflection.MemberInfo value);
            // 0x00E2EBC0: BL #0x23fe7ec              | X0 = this.NameToMethodBase.TryGetValue(key:  name, value: out  System.Reflection.MemberInfo val_1 = 0);
            bool val_2 = val_5.TryGetValue(key:  name, value: out  val_1);
            // 0x00E2EBC4: TBZ w0, #0, #0xe2ec30      | if (val_2 == false) goto label_2;       
            if(val_2 == false)
            {
                goto label_2;
            }
            // 0x00E2EBC8: LDR x22, [sp]              | X22 = 0x0;                              
            val_6 = val_1;
            // 0x00E2EBCC: CBZ x22, #0xe2ec28         | if (0x0 == 0) goto label_3;             
            if(val_6 == 0)
            {
                goto label_3;
            }
            // 0x00E2EBD0: ADRP x9, #0x362f000        | X9 = 56815616 (0x362F000);              
            // 0x00E2EBD4: LDR x9, [x9, #0x698]       | X9 = 1152921504627027968;               
            // 0x00E2EBD8: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            // 0x00E2EBDC: LDR x1, [x9]               | X1 = typeof(System.Reflection.FieldInfo);
            // 0x00E2EBE0: LDRB w10, [x8, #0x104]     | W10 = (bool)mem[282584257676931];       
            // 0x00E2EBE4: LDRB w9, [x1, #0x104]      | W9 = System.Reflection.FieldInfo.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00E2EBE8: CMP w10, w9                | STATE = COMPARE(mem[282584257676931], System.Reflection.FieldInfo.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00E2EBEC: B.LO #0xe2ec04             | if (mem[282584257676931] < System.Reflection.FieldInfo.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00E2EBF0: LDR x10, [x8, #0xb0]       | X10 = mem[282584257676847];             
            // 0x00E2EBF4: ADD x9, x10, x9, lsl #3    | X9 = (mem[282584257676847] + (System.Reflection.FieldInfo.__il2cppRuntimeField_typeHierarchyDepth) <
            // 0x00E2EBF8: LDUR x9, [x9, #-8]         | X9 = (mem[282584257676847] + (System.Reflection.FieldInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00E2EBFC: CMP x9, x1                 | STATE = COMPARE((mem[282584257676847] + (System.Reflection.FieldInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Reflection.FieldInfo))
            // 0x00E2EC00: B.EQ #0xe2ecd4             | if ((mem[282584257676847] + (System.Reflection.FieldInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_6;
            label_4:
            // 0x00E2EC04: LDR x0, [x8, #0x30]        | X0 = mem[282584257676719];              
            // 0x00E2EC08: ADD x8, sp, #8             | X8 = (1152921512983699488 + 8) = 1152921512983699496 (0x10000001F34CA028);
            // 0x00E2EC0C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[282584257676719], ????);
            // 0x00E2EC10: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921512983687568]
            // 0x00E2EC14: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00E2EC18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2EC1C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00E2EC20: ADD x0, sp, #8             | X0 = (1152921512983699488 + 8) = 1152921512983699496 (0x10000001F34CA028);
            // 0x00E2EC24: BL #0x299a140              | 
            label_3:
            // 0x00E2EC28: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_6 = 0;
            // 0x00E2EC2C: B #0xe2ecd4                |  goto label_6;                          
            goto label_6;
            label_2:
            // 0x00E2EC30: ADRP x23, #0x3647000       | X23 = 56913920 (0x3647000);             
            // 0x00E2EC34: LDR x21, [x20, #0x10]      | X21 = this.<type>k__BackingField; //P2  
            val_5 = this.<type>k__BackingField;
            // 0x00E2EC38: LDR x23, [x23, #0xf28]     | X23 = 1152921504828198912;              
            label_11:
            // 0x00E2EC3C: LDR x0, [x23]              | X0 = typeof(wxb.CacheType);             
            val_7 = null;
            // 0x00E2EC40: LDRB w8, [x0, #0x10a]      | W8 = wxb.CacheType.__il2cppRuntimeField_10A;
            // 0x00E2EC44: TBZ w8, #0, #0xe2ec58      | if (wxb.CacheType.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00E2EC48: LDR w8, [x0, #0xbc]        | W8 = wxb.CacheType.__il2cppRuntimeField_cctor_finished;
            // 0x00E2EC4C: CBNZ w8, #0xe2ec58         | if (wxb.CacheType.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00E2EC50: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(wxb.CacheType), ????);
            // 0x00E2EC54: LDR x0, [x23]              | X0 = typeof(wxb.CacheType);             
            val_7 = null;
            label_8:
            // 0x00E2EC58: LDR x8, [x0, #0xa0]        | X8 = wxb.CacheType.__il2cppRuntimeField_static_fields;
            // 0x00E2EC5C: LDR w22, [x8]              | W22 = wxb.CacheType.Flags;              
            // 0x00E2EC60: CBNZ x21, #0xe2ec68        | if (this.<type>k__BackingField != null) goto label_9;
            if(val_5 != null)
            {
                goto label_9;
            }
            // 0x00E2EC64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(wxb.CacheType), ????);
            label_9:
            // 0x00E2EC68: LDR x8, [x21]              | X8 = typeof(System.Type);               
            // 0x00E2EC6C: MOV x0, x21                | X0 = this.<type>k__BackingField;//m1    
            // 0x00E2EC70: MOV x1, x19                | X1 = name;//m1                          
            // 0x00E2EC74: MOV w2, w22                | W2 = wxb.CacheType.Flags;//m1           
            // 0x00E2EC78: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00E2EC7C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00E2EC80: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00E2EC84: MOV x22, x0                | X22 = this.<type>k__BackingField;//m1   
            val_6 = val_5;
            // 0x00E2EC88: CBNZ x22, #0xe2ecac        | if (this.<type>k__BackingField != null) goto label_10;
            if(val_6 != null)
            {
                goto label_10;
            }
            // 0x00E2EC8C: LDR x8, [x21]              | X8 = typeof(System.Type);               
            // 0x00E2EC90: MOV x0, x21                | X0 = this.<type>k__BackingField;//m1    
            // 0x00E2EC94: LDR x9, [x8, #0x220]       | X9 = typeof(System.Type).__il2cppRuntimeField_220;
            // 0x00E2EC98: LDR x1, [x8, #0x228]       | X1 = typeof(System.Type).__il2cppRuntimeField_228;
            // 0x00E2EC9C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_220();
            // 0x00E2ECA0: MOV x21, x0                | X21 = this.<type>k__BackingField;//m1   
            val_5 = val_5;
            // 0x00E2ECA4: CBNZ x21, #0xe2ec3c        | if (this.<type>k__BackingField != null) goto label_11;
            if(val_5 != null)
            {
                goto label_11;
            }
            // 0x00E2ECA8: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_10:
            // 0x00E2ECAC: LDR x20, [x20, #0x18]      | X20 = this.NameToMethodBase; //P2       
            // 0x00E2ECB0: CBNZ x20, #0xe2ecb8        | if (this.NameToMethodBase != null) goto label_12;
            if(this.NameToMethodBase != null)
            {
                goto label_12;
            }
            // 0x00E2ECB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.<type>k__BackingField, ????);
            label_12:
            // 0x00E2ECB8: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x00E2ECBC: LDR x8, [x8, #0xb58]       | X8 = 1152921512983384720;               
            // 0x00E2ECC0: MOV x0, x20                | X0 = this.NameToMethodBase;//m1         
            // 0x00E2ECC4: MOV x1, x19                | X1 = name;//m1                          
            // 0x00E2ECC8: MOV x2, x22                | X2 = 0 (0x0);//ML01                     
            // 0x00E2ECCC: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Reflection.MemberInfo>::Add(System.String key, System.Reflection.MemberInfo value);
            // 0x00E2ECD0: BL #0x23fd44c              | this.NameToMethodBase.Add(key:  name, value:  val_6);
            this.NameToMethodBase.Add(key:  name, value:  val_6);
            label_6:
            // 0x00E2ECD4: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00E2ECD8: SUB sp, x29, #0x30         | SP = (1152921512983699552 - 48) = 1152921512983699504 (0x10000001F34CA030);
            // 0x00E2ECDC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2ECE0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2ECE4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00E2ECE8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00E2ECEC: RET                        |  return (System.Reflection.FieldInfo)null;
            return (System.Reflection.FieldInfo)val_6;
            //  |  // // {name=val_0, type=System.Reflection.FieldInfo, size=8, nGRN=0 }
            // 0x00E2ECF0: MOV x19, x0                | 
            // 0x00E2ECF4: ADD x0, sp, #8             | 
            // 0x00E2ECF8: BL #0x299a140              | 
            // 0x00E2ECFC: MOV x0, x19                | 
            // 0x00E2ED00: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2ED04 (14871812), len: 288  VirtAddr: 0x00E2ED04 RVA: 0x00E2ED04 token: 100680913 methodIndex: 57315 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Collections.Generic.List<System.Reflection.FieldInfo> GetSerializeField()
        {
            //
            // Disasemble & Code
            //  | 
            System.Type val_2;
            //  | 
            System.Type val_3;
            // 0x00E2ED04: STP x22, x21, [sp, #-0x30]! | stack[1152921512983852480] = ???;  stack[1152921512983852488] = ???;  //  dest_result_addr=1152921512983852480 |  dest_result_addr=1152921512983852488
            // 0x00E2ED08: STP x20, x19, [sp, #0x10]  | stack[1152921512983852496] = ???;  stack[1152921512983852504] = ???;  //  dest_result_addr=1152921512983852496 |  dest_result_addr=1152921512983852504
            // 0x00E2ED0C: STP x29, x30, [sp, #0x20]  | stack[1152921512983852512] = ???;  stack[1152921512983852520] = ???;  //  dest_result_addr=1152921512983852512 |  dest_result_addr=1152921512983852520
            // 0x00E2ED10: ADD x29, sp, #0x20         | X29 = (1152921512983852480 + 32) = 1152921512983852512 (0x10000001F34EF5E0);
            // 0x00E2ED14: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2ED18: LDRB w8, [x20, #0x939]     | W8 = (bool)static_value_03734939;       
            // 0x00E2ED1C: MOV x19, x0                | X19 = 1152921512983864528 (0x10000001F34F24D0);//ML01
            // 0x00E2ED20: TBNZ w8, #0, #0xe2ed3c     | if (static_value_03734939 == true) goto label_0;
            // 0x00E2ED24: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x00E2ED28: LDR x8, [x8, #0x168]       | X8 = 0x2B90054;                         
            // 0x00E2ED2C: LDR w0, [x8]               | W0 = 0x16D9;                            
            // 0x00E2ED30: BL #0x2782188              | X0 = sub_2782188( ?? 0x16D9, ????);     
            // 0x00E2ED34: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2ED38: STRB w8, [x20, #0x939]     | static_value_03734939 = true;            //  dest_result_addr=57887033
            label_0:
            // 0x00E2ED3C: LDR x8, [x19, #0x20]       | X8 = this.serializes; //P2              
            // 0x00E2ED40: CBNZ x8, #0xe2ee10         | if (this.serializes != null) goto label_5;
            if(this.serializes != null)
            {
                goto label_5;
            }
            // 0x00E2ED44: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x00E2ED48: LDR x8, [x8, #0x410]       | X8 = 1152921504616644608;               
            // 0x00E2ED4C: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.Reflection.FieldInfo> val_1 = null;
            // 0x00E2ED50: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00E2ED54: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x00E2ED58: LDR x8, [x8, #0x30]        | X8 = 1152921512816215360;               
            // 0x00E2ED5C: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00E2ED60: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.Reflection.FieldInfo>::.ctor();
            // 0x00E2ED64: BL #0x25e9474              | .ctor();                                
            val_1 = new System.Collections.Generic.List<System.Reflection.FieldInfo>();
            // 0x00E2ED68: STR x20, [x19, #0x20]      | this.serializes = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921512983864560
            this.serializes = val_1;
            // 0x00E2ED6C: ADRP x22, #0x3679000       | X22 = 57118720 (0x3679000);             
            // 0x00E2ED70: LDR x22, [x22, #0xb60]     | X22 = 1152921504828358656;              
            // 0x00E2ED74: LDR x21, [x19, #0x10]      | X21 = this.<type>k__BackingField; //P2  
            val_2 = this.<type>k__BackingField;
            // 0x00E2ED78: LDR x0, [x22]              | X0 = typeof(wxb.IL.Help);               
            // 0x00E2ED7C: LDRB w8, [x0, #0x10a]      | W8 = wxb.IL.Help.__il2cppRuntimeField_10A;
            // 0x00E2ED80: TBZ w8, #0, #0xe2ed90      | if (wxb.IL.Help.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00E2ED84: LDR w8, [x0, #0xbc]        | W8 = wxb.IL.Help.__il2cppRuntimeField_cctor_finished;
            // 0x00E2ED88: CBNZ w8, #0xe2ed90         | if (wxb.IL.Help.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00E2ED8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(wxb.IL.Help), ????);
            label_3:
            // 0x00E2ED90: MOV x1, x21                | X1 = this.<type>k__BackingField;//m1    
            // 0x00E2ED94: MOV x2, x20                | X2 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00E2ED98: BL #0xe2ee24               | wxb.IL.Help.GetSerializeField(type:  null, fieldinfos:  val_2);
            wxb.IL.Help.GetSerializeField(type:  null, fieldinfos:  val_2);
            // 0x00E2ED9C: LDR x20, [x19, #0x10]      | X20 = this.<type>k__BackingField; //P2  
            // 0x00E2EDA0: CBNZ x20, #0xe2eda8        | if (this.<type>k__BackingField != null) goto label_4;
            if((this.<type>k__BackingField) != null)
            {
                goto label_4;
            }
            // 0x00E2EDA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(wxb.IL.Help), ????);
            label_4:
            // 0x00E2EDA8: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00E2EDAC: MOV x0, x20                | X0 = this.<type>k__BackingField;//m1    
            // 0x00E2EDB0: LDR x9, [x8, #0x220]       | X9 = typeof(System.Type).__il2cppRuntimeField_220;
            // 0x00E2EDB4: LDR x1, [x8, #0x228]       | X1 = typeof(System.Type).__il2cppRuntimeField_228;
            // 0x00E2EDB8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_220();
            // 0x00E2EDBC: CBZ x0, #0xe2ee10          | if (this.<type>k__BackingField == null) goto label_5;
            if((this.<type>k__BackingField) == null)
            {
                goto label_5;
            }
            // 0x00E2EDC0: LDR x20, [x19, #0x10]      | X20 = this.<type>k__BackingField; //P2  
            // 0x00E2EDC4: CBNZ x20, #0xe2edcc        | if (this.<type>k__BackingField != null) goto label_6;
            if((this.<type>k__BackingField) != null)
            {
                goto label_6;
            }
            // 0x00E2EDC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.<type>k__BackingField, ????);
            label_6:
            // 0x00E2EDCC: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00E2EDD0: MOV x0, x20                | X0 = this.<type>k__BackingField;//m1    
            val_3 = this.<type>k__BackingField;
            // 0x00E2EDD4: LDR x9, [x8, #0x220]       | X9 = typeof(System.Type).__il2cppRuntimeField_220;
            // 0x00E2EDD8: LDR x1, [x8, #0x228]       | X1 = typeof(System.Type).__il2cppRuntimeField_228;
            // 0x00E2EDDC: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_220();
            // 0x00E2EDE0: LDR x8, [x22]              | X8 = typeof(wxb.IL.Help);               
            // 0x00E2EDE4: LDR x20, [x19, #0x20]      | X20 = this.serializes; //P2             
            // 0x00E2EDE8: MOV x21, x0                | X21 = this.<type>k__BackingField;//m1   
            val_2 = val_3;
            // 0x00E2EDEC: LDRB w9, [x8, #0x10a]      | W9 = wxb.IL.Help.__il2cppRuntimeField_10A;
            // 0x00E2EDF0: TBZ w9, #0, #0xe2ee04      | if (wxb.IL.Help.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00E2EDF4: LDR w9, [x8, #0xbc]        | W9 = wxb.IL.Help.__il2cppRuntimeField_cctor_finished;
            // 0x00E2EDF8: CBNZ w9, #0xe2ee04         | if (wxb.IL.Help.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00E2EDFC: MOV x0, x8                 | X0 = 1152921504828358656 (0x100000000D340000);//ML01
            val_3 = null;
            // 0x00E2EE00: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(wxb.IL.Help), ????);
            label_8:
            // 0x00E2EE04: MOV x1, x21                | X1 = this.<type>k__BackingField;//m1    
            // 0x00E2EE08: MOV x2, x20                | X2 = this.serializes;//m1               
            // 0x00E2EE0C: BL #0xe2ee24               | wxb.IL.Help.GetSerializeField(type:  val_3 = null, fieldinfos:  val_2);
            wxb.IL.Help.GetSerializeField(type:  val_3, fieldinfos:  val_2);
            label_5:
            // 0x00E2EE10: LDR x0, [x19, #0x20]       | X0 = this.serializes; //P2              
            // 0x00E2EE14: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2EE18: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2EE1C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2EE20: RET                        |  return (System.Collections.Generic.List<System.Reflection.FieldInfo>)this.serializes;
            return this.serializes;
            //  |  // // {name=val_0, type=System.Collections.Generic.List<System.Reflection.FieldInfo>, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2F8F0 (14874864), len: 152  VirtAddr: 0x00E2F8F0 RVA: 0x00E2F8F0 token: 100680914 methodIndex: 57316 delegateWrapperIndex: 0 methodInvoker: 0
        private static CacheType()
        {
            //
            // Disasemble & Code
            // 0x00E2F8F0: STP x20, x19, [sp, #-0x20]! | stack[1152921512983989072] = ???;  stack[1152921512983989080] = ???;  //  dest_result_addr=1152921512983989072 |  dest_result_addr=1152921512983989080
            // 0x00E2F8F4: STP x29, x30, [sp, #0x10]  | stack[1152921512983989088] = ???;  stack[1152921512983989096] = ???;  //  dest_result_addr=1152921512983989088 |  dest_result_addr=1152921512983989096
            // 0x00E2F8F8: ADD x29, sp, #0x10         | X29 = (1152921512983989072 + 16) = 1152921512983989088 (0x10000001F3510B60);
            // 0x00E2F8FC: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00E2F900: LDRB w8, [x19, #0x93a]     | W8 = (bool)static_value_0373493A;       
            // 0x00E2F904: TBNZ w8, #0, #0xe2f920     | if (static_value_0373493A == true) goto label_0;
            // 0x00E2F908: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x00E2F90C: LDR x8, [x8, #0x5e8]       | X8 = 0x2B90034;                         
            // 0x00E2F910: LDR w0, [x8]               | W0 = 0x16D1;                            
            // 0x00E2F914: BL #0x2782188              | X0 = sub_2782188( ?? 0x16D1, ????);     
            // 0x00E2F918: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2F91C: STRB w8, [x19, #0x93a]     | static_value_0373493A = true;            //  dest_result_addr=57887034
            label_0:
            // 0x00E2F920: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
            // 0x00E2F924: LDR x8, [x8, #0xf28]       | X8 = 1152921504828198912;               
            // 0x00E2F928: ORR w9, wzr, #0x3c         | W9 = 60(0x3C);                          
            // 0x00E2F92C: LDR x8, [x8]               | X8 = typeof(wxb.CacheType);             
            // 0x00E2F930: LDR x8, [x8, #0xa0]        | X8 = wxb.CacheType.__il2cppRuntimeField_static_fields;
            // 0x00E2F934: STR w9, [x8]               | wxb.CacheType.Flags = 0x3C;              //  dest_result_addr=1152921504828203008
            wxb.CacheType.Flags = 60;
            // 0x00E2F938: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2F93C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2F940: RET                        |  return;                                
            return;
            // 0x00E2F944: STP x29, x30, [sp, #-0x10]! | 
            // 0x00E2F948: MOV x29, sp                | 
            // 0x00E2F94C: ADRP x0, #0x2a97000        | 
            // 0x00E2F950: ADD x0, x0, #0xca8         | 
            // 0x00E2F954: BL #0x27af3c8              | 
            // 0x00E2F958: MOV x1, xzr                | 
            // 0x00E2F95C: BL #0x27ae3bc              | 
            // 0x00E2F960: BL #0xe2f964               | 
            label_2:
            // 0x00E2F964: STP x29, x30, [sp, #-0x10]! | 
            // 0x00E2F968: MOV x29, sp                | 
            // 0x00E2F96C: ADRP x0, #0x2a97000        | 
            // 0x00E2F970: ADD x0, x0, #0xca8         | 
            // 0x00E2F974: BL #0x27af3c8              | 
            // 0x00E2F978: MOV x1, xzr                | 
            // 0x00E2F97C: BL #0x27ae3bc              | 
            // 0x00E2F980: BL #0xe2f964               | 
            // 0x00E2F984: RET                        | 
        
        }
    
    }

}
