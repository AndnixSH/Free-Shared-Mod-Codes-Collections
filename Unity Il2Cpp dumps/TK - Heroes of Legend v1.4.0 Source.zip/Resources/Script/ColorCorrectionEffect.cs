using UnityEngine;
[UnityEngine.ExecuteInEditMode] // 0x2819D64
[UnityEngine.AddComponentMenu] // 0x2819D64
public class ColorCorrectionEffect : ImageEffectBase
{
    // Fields
    public UnityEngine.Texture textureRamp; //  0x00000028
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x0273155C (41096540), len: 8  VirtAddr: 0x0273155C RVA: 0x0273155C token: 100663366 methodIndex: 24318 delegateWrapperIndex: 0 methodInvoker: 0
    public ColorCorrectionEffect()
    {
        //
        // Disasemble & Code
        // 0x0273155C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731560: B #0x1b76fd4               | this..ctor(); return;                   
        val_1 = new UnityEngine.MonoBehaviour();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0273156C (41096556), len: 208  VirtAddr: 0x0273156C RVA: 0x0273156C token: 100663367 methodIndex: 24319 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnRenderImage(UnityEngine.RenderTexture source, UnityEngine.RenderTexture destination)
    {
        //
        // Disasemble & Code
        // 0x0273156C: STP x24, x23, [sp, #-0x40]! | stack[1152921509934037024] = ???;  stack[1152921509934037032] = ???;  //  dest_result_addr=1152921509934037024 |  dest_result_addr=1152921509934037032
        // 0x02731570: STP x22, x21, [sp, #0x10]  | stack[1152921509934037040] = ???;  stack[1152921509934037048] = ???;  //  dest_result_addr=1152921509934037040 |  dest_result_addr=1152921509934037048
        // 0x02731574: STP x20, x19, [sp, #0x20]  | stack[1152921509934037056] = ???;  stack[1152921509934037064] = ???;  //  dest_result_addr=1152921509934037056 |  dest_result_addr=1152921509934037064
        // 0x02731578: STP x29, x30, [sp, #0x30]  | stack[1152921509934037072] = ???;  stack[1152921509934037080] = ???;  //  dest_result_addr=1152921509934037072 |  dest_result_addr=1152921509934037080
        // 0x0273157C: ADD x29, sp, #0x30         | X29 = (1152921509934037024 + 48) = 1152921509934037072 (0x100000013D867850);
        // 0x02731580: ADRP x22, #0x3743000       | X22 = 57946112 (0x3743000);             
        // 0x02731584: LDRB w8, [x22, #0xac7]     | W8 = (bool)static_value_03743AC7;       
        // 0x02731588: MOV x19, x2                | X19 = destination;//m1                  
        // 0x0273158C: MOV x20, x1                | X20 = source;//m1                       
        // 0x02731590: MOV x21, x0                | X21 = 1152921509934049088 (0x100000013D86A740);//ML01
        // 0x02731594: TBNZ w8, #0, #0x27315b0    | if (static_value_03743AC7 == true) goto label_0;
        // 0x02731598: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
        // 0x0273159C: LDR x8, [x8, #0xc38]       | X8 = 0x2B91728;                         
        // 0x027315A0: LDR w0, [x8]               | W0 = 0x1C8F;                            
        // 0x027315A4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C8F, ????);     
        // 0x027315A8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x027315AC: STRB w8, [x22, #0xac7]     | static_value_03743AC7 = true;            //  dest_result_addr=57948871
        label_0:
        // 0x027315B0: MOV x0, x21                | X0 = 1152921509934049088 (0x100000013D86A740);//ML01
        // 0x027315B4: BL #0x273163c              | X0 = this.get_material();               
        UnityEngine.Material val_1 = this.material;
        // 0x027315B8: LDR x22, [x21, #0x28]      | X22 = this.textureRamp; //P2            
        // 0x027315BC: MOV x23, x0                | X23 = val_1;//m1                        
        // 0x027315C0: CBNZ x23, #0x27315c8       | if (val_1 != null) goto label_1;        
        if(val_1 != null)
        {
            goto label_1;
        }
        // 0x027315C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x027315C8: ADRP x8, #0x365c000        | X8 = 56999936 (0x365C000);              
        // 0x027315CC: LDR x8, [x8, #0x558]       | X8 = (string**)(1152921509934020896)("_RampTex");
        // 0x027315D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x027315D4: MOV x0, x23                | X0 = val_1;//m1                         
        // 0x027315D8: MOV x2, x22                | X2 = this.textureRamp;//m1              
        // 0x027315DC: LDR x1, [x8]               | X1 = "_RampTex";                        
        // 0x027315E0: BL #0x1a780c4              | val_1.SetTexture(name:  "_RampTex", value:  this.textureRamp);
        val_1.SetTexture(name:  "_RampTex", value:  this.textureRamp);
        // 0x027315E4: MOV x0, x21                | X0 = 1152921509934049088 (0x100000013D86A740);//ML01
        // 0x027315E8: BL #0x273163c              | X0 = this.get_material();               
        UnityEngine.Material val_2 = this.material;
        // 0x027315EC: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x027315F0: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x027315F4: MOV x21, x0                | X21 = val_2;//m1                        
        // 0x027315F8: LDR x8, [x8]               | X8 = typeof(UnityEngine.Graphics);      
        // 0x027315FC: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02731600: TBZ w9, #0, #0x2731614     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x02731604: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02731608: CBNZ w9, #0x2731614        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x0273160C: MOV x0, x8                 | X0 = 1152921504693481472 (0x100000000529F000);//ML01
        // 0x02731610: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_3:
        // 0x02731614: MOV x1, x20                | X1 = source;//m1                        
        // 0x02731618: MOV x2, x19                | X2 = destination;//m1                   
        // 0x0273161C: MOV x3, x21                | X3 = val_2;//m1                         
        // 0x02731620: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x02731624: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x02731628: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x0273162C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731630: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02731634: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x02731638: B #0x1a6bc04               | UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  destination); return;
        UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  destination);
        return;
    
    }

}
