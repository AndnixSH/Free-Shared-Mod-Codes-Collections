using UnityEngine;

namespace Pathfinding.ClipperLib
{
    public class ClipperBase
    {
        // Fields
        protected const double horizontal = -3.4E+38;
        protected const int Skip = -2;
        protected const int Unassigned = -1;
        protected const double tolerance = 1E-20;
        internal const long loRange = 1073741823;
        internal const long hiRange = 4611686018427387903;
        internal Pathfinding.ClipperLib.LocalMinima m_MinimaList; //  0x00000010
        internal Pathfinding.ClipperLib.LocalMinima m_CurrentLM; //  0x00000018
        internal System.Collections.Generic.List<System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>> m_edges; //  0x00000020
        internal bool m_UseFullRange; //  0x00000028
        internal bool m_HasOpenPaths; //  0x00000029
        private bool <PreserveCollinear>k__BackingField; //  0x0000002A
        
        // Properties
        public bool PreserveCollinear { get; set; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x02701674 (40900212), len: 124  VirtAddr: 0x02701674 RVA: 0x02701674 token: 100663331 methodIndex: 20746 delegateWrapperIndex: 0 methodInvoker: 0
        internal ClipperBase()
        {
            //
            // Disasemble & Code
            // 0x02701674: STP x20, x19, [sp, #-0x20]! | stack[1152921509604897104] = ???;  stack[1152921509604897112] = ???;  //  dest_result_addr=1152921509604897104 |  dest_result_addr=1152921509604897112
            // 0x02701678: STP x29, x30, [sp, #0x10]  | stack[1152921509604897120] = ???;  stack[1152921509604897128] = ???;  //  dest_result_addr=1152921509604897120 |  dest_result_addr=1152921509604897128
            // 0x0270167C: ADD x29, sp, #0x10         | X29 = (1152921509604897104 + 16) = 1152921509604897120 (0x1000000129E83160);
            // 0x02701680: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
            // 0x02701684: LDRB w8, [x20, #0x16e]     | W8 = (bool)static_value_0374316E;       
            // 0x02701688: MOV x19, x0                | X19 = 1152921509604909136 (0x1000000129E86050);//ML01
            // 0x0270168C: TBNZ w8, #0, #0x27016a8    | if (static_value_0374316E == true) goto label_0;
            // 0x02701690: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x02701694: LDR x8, [x8, #0xa20]       | X8 = 0x2B90C34;                         
            // 0x02701698: LDR w0, [x8]               | W0 = 0x19D1;                            
            // 0x0270169C: BL #0x2782188              | X0 = sub_2782188( ?? 0x19D1, ????);     
            // 0x027016A0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x027016A4: STRB w8, [x20, #0x16e]     | static_value_0374316E = true;            //  dest_result_addr=57946478
            label_0:
            // 0x027016A8: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x027016AC: LDR x8, [x8, #0x170]       | X8 = 1152921504616644608;               
            // 0x027016B0: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>> val_1 = null;
            // 0x027016B4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x027016B8: ADRP x8, #0x366a000        | X8 = 57057280 (0x366A000);              
            // 0x027016BC: LDR x8, [x8, #0xde0]       | X8 = 1152921509604884112;               
            // 0x027016C0: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x027016C4: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>>::.ctor();
            // 0x027016C8: BL #0x25e9474              | .ctor();                                
            val_1 = new System.Collections.Generic.List<System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>>();
            // 0x027016CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x027016D0: MOV x0, x19                | X0 = 1152921509604909136 (0x1000000129E86050);//ML01
            // 0x027016D4: STR x20, [x19, #0x20]      | this.m_edges = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921509604909168
            this.m_edges = val_1;
            // 0x027016D8: BL #0x16f59f0              | this..ctor();                           
            // 0x027016DC: STRH wzr, [x19, #0x28]     | this.m_UseFullRange = false; this.m_HasOpenPaths = false;  //  dest_result_addr=1152921509604909176 dest_result_addr=1152921509604909177
            this.m_UseFullRange = false;
            this.m_HasOpenPaths = false;
            // 0x027016E0: STP xzr, xzr, [x19, #0x10] | this.m_MinimaList = null;  this.m_CurrentLM = null;  //  dest_result_addr=1152921509604909152 |  dest_result_addr=1152921509604909160
            this.m_MinimaList = 0;
            this.m_CurrentLM = 0;
            // 0x027016E4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x027016E8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x027016EC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x027080A8 (40927400), len: 8  VirtAddr: 0x027080A8 RVA: 0x027080A8 token: 100663332 methodIndex: 20747 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_PreserveCollinear()
        {
            //
            // Disasemble & Code
            // 0x027080A8: LDRB w0, [x0, #0x2a]       | W0 = this.<PreserveCollinear>k__BackingField; //P2 
            // 0x027080AC: RET                        |  return (System.Boolean)this.<PreserveCollinear>k__BackingField;
            return this.<PreserveCollinear>k__BackingField;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x02701708 (40900360), len: 12  VirtAddr: 0x02701708 RVA: 0x02701708 token: 100663333 methodIndex: 20748 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_PreserveCollinear(bool value)
        {
            //
            // Disasemble & Code
            // 0x02701708: AND w8, w1, #1             | W8 = (value & 1);                       
            bool val_1 = value;
            // 0x0270170C: STRB w8, [x0, #0x2a]       | this.<PreserveCollinear>k__BackingField = (value & 1);  //  dest_result_addr=1152921509605133178
            this.<PreserveCollinear>k__BackingField = val_1;
            // 0x02701710: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x027048E4 (40913124), len: 48  VirtAddr: 0x027048E4 RVA: 0x027048E4 token: 100663334 methodIndex: 20749 delegateWrapperIndex: 0 methodInvoker: 0
        internal static bool IsHorizontal(Pathfinding.ClipperLib.TEdge e)
        {
            //
            // Disasemble & Code
            // 0x027048E4: STP x20, x19, [sp, #-0x20]! | stack[1152921509605237200] = ???;  stack[1152921509605237208] = ???;  //  dest_result_addr=1152921509605237200 |  dest_result_addr=1152921509605237208
            // 0x027048E8: STP x29, x30, [sp, #0x10]  | stack[1152921509605237216] = ???;  stack[1152921509605237224] = ???;  //  dest_result_addr=1152921509605237216 |  dest_result_addr=1152921509605237224
            // 0x027048EC: ADD x29, sp, #0x10         | X29 = (1152921509605237200 + 16) = 1152921509605237216 (0x1000000129ED61E0);
            // 0x027048F0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x027048F4: CBNZ x19, #0x27048fc       | if (X1 != 0) goto label_0;              
            if(X1 != 0)
            {
                goto label_0;
            }
            // 0x027048F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? e, ????);          
            label_0:
            // 0x027048FC: LDR x8, [x19, #0x48]       | X8 = X1 + 72;                           
            // 0x02704900: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x02704904: CMP x8, #0                 | STATE = COMPARE(X1 + 72, 0x0)           
            // 0x02704908: CSET w0, eq                | W0 = X1 + 72 == 0x0 ? 1 : 0;            
            var val_1 = ((X1 + 72) == 0) ? 1 : 0;
            // 0x0270490C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x02704910: RET                        |  return (System.Boolean)X1 + 72 == 0x0 ? 1 : 0;
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0270977C (40933244), len: 316  VirtAddr: 0x0270977C RVA: 0x0270977C token: 100663335 methodIndex: 20750 delegateWrapperIndex: 0 methodInvoker: 0
        internal bool PointOnLineSegment(Pathfinding.ClipperLib.IntPoint pt, Pathfinding.ClipperLib.IntPoint linePt1, Pathfinding.ClipperLib.IntPoint linePt2, bool UseFullRange)
        {
            //
            // Disasemble & Code
            //  | 
            var val_22;
            // 0x0270977C: STP x24, x23, [sp, #-0x40]! | stack[1152921509605353264] = ???;  stack[1152921509605353272] = ???;  //  dest_result_addr=1152921509605353264 |  dest_result_addr=1152921509605353272
            // 0x02709780: STP x22, x21, [sp, #0x10]  | stack[1152921509605353280] = ???;  stack[1152921509605353288] = ???;  //  dest_result_addr=1152921509605353280 |  dest_result_addr=1152921509605353288
            // 0x02709784: STP x20, x19, [sp, #0x20]  | stack[1152921509605353296] = ???;  stack[1152921509605353304] = ???;  //  dest_result_addr=1152921509605353296 |  dest_result_addr=1152921509605353304
            // 0x02709788: STP x29, x30, [sp, #0x30]  | stack[1152921509605353312] = ???;  stack[1152921509605353320] = ???;  //  dest_result_addr=1152921509605353312 |  dest_result_addr=1152921509605353320
            // 0x0270978C: ADD x29, sp, #0x30         | X29 = (1152921509605353264 + 48) = 1152921509605353312 (0x1000000129EF2760);
            // 0x02709790: MOV x20, x3                | X20 = linePt1.X;//m1                    
            // 0x02709794: MOV x19, x5                | X19 = linePt2.X;//m1                    
            // 0x02709798: CMP x1, x20                | STATE = COMPARE(pt.X, linePt1.X)        
            // 0x0270979C: CSET w8, eq                | W8 = pt.X == linePt1.X ? 1 : 0;         
            var val_1 = (pt.X == linePt1.X) ? 1 : 0;
            // 0x027097A0: CMP x2, x4                 | STATE = COMPARE(pt.Y, linePt1.Y)        
            // 0x027097A4: CSET w9, eq                | W9 = pt.Y == linePt1.Y ? 1 : 0;         
            var val_2 = (pt.Y == linePt1.Y) ? 1 : 0;
            // 0x027097A8: AND w8, w8, w9             | W8 = (pt.X == linePt1.X ? 1 : 0 & pt.Y == linePt1.Y ? 1 : 0);
            val_1 = val_1 & val_2;
            // 0x027097AC: TBZ w7, #0, #0x2709838     | if (UseFullRange == false) goto label_0;
            if(UseFullRange == false)
            {
                goto label_0;
            }
            // 0x027097B0: TBNZ w8, #0, #0x270984c    | if (((pt.X == linePt1.X ? 1 : 0 & pt.Y == linePt1.Y ? 1 : 0) & 0x1) != 0) goto label_6;
            if((val_1 & 1) != 0)
            {
                goto label_6;
            }
            // 0x027097B4: CMP x1, x19                | STATE = COMPARE(pt.X, linePt2.X)        
            // 0x027097B8: B.NE #0x27097c4            | if (pt.X != linePt2.X) goto label_2;    
            if(pt.X != linePt2.X)
            {
                goto label_2;
            }
            // 0x027097BC: CMP x2, x6                 | STATE = COMPARE(pt.Y, linePt2.Y)        
            // 0x027097C0: B.EQ #0x270984c            | if (pt.Y == linePt2.Y) goto label_6;    
            if(pt.Y == linePt2.Y)
            {
                goto label_6;
            }
            label_2:
            // 0x027097C4: SUBS x8, x1, x20           | X8 = (pt.X - linePt1.X);                
            long val_3 = pt.X - linePt1.X;
            // 0x027097C8: CSET w9, gt                | W9 = pt.Y > linePt2.Y ? 1 : 0;          
            var val_4 = (pt.Y > linePt2.Y) ? 1 : 0;
            // 0x027097CC: CMP x1, x19                | STATE = COMPARE(pt.X, linePt2.X)        
            // 0x027097D0: CSET w10, lt               | W10 = pt.X < linePt2.X ? 1 : 0;         
            var val_5 = (pt.X < linePt2.X) ? 1 : 0;
            // 0x027097D4: EOR w9, w9, w10            | W9 = (pt.Y > linePt2.Y ? 1 : 0 ^ pt.X < linePt2.X ? 1 : 0);
            val_4 = val_4 ^ val_5;
            // 0x027097D8: TBNZ w9, #0, #0x2709884    | if (((pt.Y > linePt2.Y ? 1 : 0 ^ pt.X < linePt2.X ? 1 : 0) & 0x1) != 0) goto label_10;
            if((val_4 & 1) != 0)
            {
                goto label_10;
            }
            // 0x027097DC: SUBS x21, x2, x4           | X21 = (pt.Y - linePt1.Y);               
            long val_6 = pt.Y - linePt1.Y;
            // 0x027097E0: CSET w9, gt                | W9 = pt.X > linePt2.X ? 1 : 0;          
            var val_7 = (pt.X > linePt2.X) ? 1 : 0;
            // 0x027097E4: CMP x2, x6                 | STATE = COMPARE(pt.Y, linePt2.Y)        
            // 0x027097E8: CSET w10, lt               | W10 = pt.Y < linePt2.Y ? 1 : 0;         
            var val_8 = (pt.Y < linePt2.Y) ? 1 : 0;
            // 0x027097EC: EOR w9, w9, w10            | W9 = (pt.X > linePt2.X ? 1 : 0 ^ pt.Y < linePt2.Y ? 1 : 0);
            val_7 = val_7 ^ val_8;
            // 0x027097F0: TBNZ w9, #0, #0x2709884    | if (((pt.X > linePt2.X ? 1 : 0 ^ pt.Y < linePt2.Y ? 1 : 0) & 0x1) != 0) goto label_10;
            if((val_7 & 1) != 0)
            {
                goto label_10;
            }
            // 0x027097F4: SUB x2, x6, x4             | X2 = (linePt2.Y - linePt1.Y);           
            long val_9 = linePt2.Y - linePt1.Y;
            // 0x027097F8: MOV x1, x8                 | X1 = (pt.X - linePt1.X);//m1            
            // 0x027097FC: BL #0x27098b8              | X0 = Pathfinding.ClipperLib.Int128.Int128Mul(lhs:  this, rhs:  val_3);
            Pathfinding.ClipperLib.Int128 val_10 = Pathfinding.ClipperLib.Int128.Int128Mul(lhs:  this, rhs:  val_3);
            // 0x02709800: MOV x23, x1                | X23 = val_10.lo;//m1                    
            // 0x02709804: SUB x1, x19, x20           | X1 = (linePt2.X - linePt1.X);           
            long val_11 = linePt2.X - linePt1.X;
            // 0x02709808: MOV x2, x21                | X2 = (pt.Y - linePt1.Y);//m1            
            // 0x0270980C: MOV x22, x0                | X22 = val_10.hi;//m1                    
            // 0x02709810: BL #0x27098b8              | X0 = Pathfinding.ClipperLib.Int128.Int128Mul(lhs:  val_10.hi, rhs:  long val_11 = linePt2.X - linePt1.X);
            Pathfinding.ClipperLib.Int128 val_12 = Pathfinding.ClipperLib.Int128.Int128Mul(lhs:  val_10.hi, rhs:  val_11);
            // 0x02709814: MOV x4, x1                 | X4 = val_12.lo;//m1                     
            // 0x02709818: MOV x1, x22                | X1 = val_10.hi;//m1                     
            // 0x0270981C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x02709820: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x02709824: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x02709828: MOV x2, x23                | X2 = val_10.lo;//m1                     
            // 0x0270982C: MOV x3, x0                 | X3 = val_12.hi;//m1                     
            // 0x02709830: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x02709834: B #0x2709910               | return Pathfinding.ClipperLib.Int128.op_Equality(val1:  new Pathfinding.ClipperLib.Int128() {hi = val_12.hi, lo = val_10.hi}, val2:  new Pathfinding.ClipperLib.Int128() {hi = val_10.lo, lo = val_12.hi});
            return Pathfinding.ClipperLib.Int128.op_Equality(val1:  new Pathfinding.ClipperLib.Int128() {hi = val_12.hi, lo = val_10.hi}, val2:  new Pathfinding.ClipperLib.Int128() {hi = val_10.lo, lo = val_12.hi});
            label_0:
            // 0x02709838: TBNZ w8, #0, #0x270984c    | if (((pt.X == linePt1.X ? 1 : 0 & pt.Y == linePt1.Y ? 1 : 0) & 0x1) != 0) goto label_6;
            if((val_1 & 1) != 0)
            {
                goto label_6;
            }
            // 0x0270983C: CMP x1, x19                | STATE = COMPARE(pt.X, linePt2.X)        
            // 0x02709840: B.NE #0x2709854            | if (pt.X != linePt2.X) goto label_8;    
            if(pt.X != linePt2.X)
            {
                goto label_8;
            }
            // 0x02709844: CMP x2, x6                 | STATE = COMPARE(pt.Y, linePt2.Y)        
            // 0x02709848: B.NE #0x2709854            | if (pt.Y != linePt2.Y) goto label_8;    
            if(pt.Y != linePt2.Y)
            {
                goto label_8;
            }
            label_6:
            // 0x0270984C: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_22 = 1;
            // 0x02709850: B #0x2709888               |  goto label_12;                         
            goto label_12;
            label_8:
            // 0x02709854: SUBS x8, x1, x20           | X8 = (pt.X - linePt1.X);                
            long val_13 = pt.X - linePt1.X;
            // 0x02709858: CSET w9, gt                | W9 = pt.X > linePt2.X ? 1 : 0;          
            var val_14 = (pt.X > linePt2.X) ? 1 : 0;
            // 0x0270985C: CMP x1, x19                | STATE = COMPARE(pt.X, linePt2.X)        
            // 0x02709860: CSET w10, lt               | W10 = pt.X < linePt2.X ? 1 : 0;         
            var val_15 = (pt.X < linePt2.X) ? 1 : 0;
            // 0x02709864: EOR w9, w9, w10            | W9 = (pt.X > linePt2.X ? 1 : 0 ^ pt.X < linePt2.X ? 1 : 0);
            val_14 = val_14 ^ val_15;
            // 0x02709868: TBNZ w9, #0, #0x2709884    | if (((pt.X > linePt2.X ? 1 : 0 ^ pt.X < linePt2.X ? 1 : 0) & 0x1) != 0) goto label_10;
            if((val_14 & 1) != 0)
            {
                goto label_10;
            }
            // 0x0270986C: SUBS x9, x2, x4            | X9 = (pt.Y - linePt1.Y);                
            long val_16 = pt.Y - linePt1.Y;
            // 0x02709870: CSET w10, gt               | W10 = pt.X > linePt2.X ? 1 : 0;         
            var val_17 = (pt.X > linePt2.X) ? 1 : 0;
            // 0x02709874: CMP x2, x6                 | STATE = COMPARE(pt.Y, linePt2.Y)        
            // 0x02709878: CSET w11, lt               | W11 = pt.Y < linePt2.Y ? 1 : 0;         
            var val_18 = (pt.Y < linePt2.Y) ? 1 : 0;
            // 0x0270987C: EOR w10, w10, w11          | W10 = (pt.X > linePt2.X ? 1 : 0 ^ pt.Y < linePt2.Y ? 1 : 0);
            val_17 = val_17 ^ val_18;
            // 0x02709880: TBZ w10, #0, #0x270989c    | if (((pt.X > linePt2.X ? 1 : 0 ^ pt.Y < linePt2.Y ? 1 : 0) & 0x1) == 0) goto label_11;
            if((val_17 & 1) == 0)
            {
                goto label_11;
            }
            label_10:
            // 0x02709884: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_22 = 0;
            label_12:
            // 0x02709888: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0270988C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x02709890: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x02709894: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x02709898: RET                        |  return (System.Boolean)false;          
            return (bool)val_22;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_11:
            // 0x0270989C: SUB x10, x6, x4            | X10 = (linePt2.Y - linePt1.Y);          
            long val_19 = linePt2.Y - linePt1.Y;
            // 0x027098A0: SUB x11, x19, x20          | X11 = (linePt2.X - linePt1.X);          
            long val_20 = linePt2.X - linePt1.X;
            // 0x027098A4: MUL x8, x10, x8            | X8 = ((linePt2.Y - linePt1.Y) * (pt.X - linePt1.X));
            val_13 = val_19 * val_13;
            // 0x027098A8: MUL x9, x11, x9            | X9 = ((linePt2.X - linePt1.X) * (pt.Y - linePt1.Y));
            val_16 = val_20 * val_16;
            // 0x027098AC: CMP x8, x9                 | STATE = COMPARE(((linePt2.Y - linePt1.Y) * (pt.X - linePt1.X)), ((linePt2.X - linePt1.X) * (pt.Y - linePt1.Y)))
            // 0x027098B0: CSET w0, eq                | W0 = val_13 == val_16 ? 1 : 0;          
            var val_21 = (val_13 == val_16) ? 1 : 0;
            // 0x027098B4: B #0x2709888               |  goto label_12;                         
            goto label_12;
        
        }
        //
        // Offset in libil2cpp.so: 0x027091C8 (40931784), len: 200  VirtAddr: 0x027091C8 RVA: 0x027091C8 token: 100663336 methodIndex: 20751 delegateWrapperIndex: 0 methodInvoker: 0
        internal bool PointOnPolygon(Pathfinding.ClipperLib.IntPoint pt, Pathfinding.ClipperLib.OutPt pp, bool UseFullRange)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.ClipperLib.OutPt val_4;
            //  | 
            Pathfinding.ClipperLib.IntPoint val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            // 0x027091C8: STP x28, x27, [sp, #-0x60]! | stack[1152921509605477520] = ???;  stack[1152921509605477528] = ???;  //  dest_result_addr=1152921509605477520 |  dest_result_addr=1152921509605477528
            // 0x027091CC: STP x26, x25, [sp, #0x10]  | stack[1152921509605477536] = ???;  stack[1152921509605477544] = ???;  //  dest_result_addr=1152921509605477536 |  dest_result_addr=1152921509605477544
            // 0x027091D0: STP x24, x23, [sp, #0x20]  | stack[1152921509605477552] = ???;  stack[1152921509605477560] = ???;  //  dest_result_addr=1152921509605477552 |  dest_result_addr=1152921509605477560
            // 0x027091D4: STP x22, x21, [sp, #0x30]  | stack[1152921509605477568] = ???;  stack[1152921509605477576] = ???;  //  dest_result_addr=1152921509605477568 |  dest_result_addr=1152921509605477576
            // 0x027091D8: STP x20, x19, [sp, #0x40]  | stack[1152921509605477584] = ???;  stack[1152921509605477592] = ???;  //  dest_result_addr=1152921509605477584 |  dest_result_addr=1152921509605477592
            // 0x027091DC: STP x29, x30, [sp, #0x50]  | stack[1152921509605477600] = ???;  stack[1152921509605477608] = ???;  //  dest_result_addr=1152921509605477600 |  dest_result_addr=1152921509605477608
            // 0x027091E0: ADD x29, sp, #0x50         | X29 = (1152921509605477520 + 80) = 1152921509605477600 (0x1000000129F10CE0);
            // 0x027091E4: SUB sp, sp, #0x10          | SP = (1152921509605477520 - 16) = 1152921509605477504 (0x1000000129F10C80);
            // 0x027091E8: MOV x19, x3                | X19 = pp;//m1                           
            // 0x027091EC: MOV x20, x2                | X20 = pt.Y;//m1                         
            // 0x027091F0: MOV x21, x1                | X21 = pt.X;//m1                         
            // 0x027091F4: ORR w25, wzr, #0x18        | W25 = 24(0x18);                         
            // 0x027091F8: ORR w26, wzr, #0x20        | W26 = 32(0x20);                         
            // 0x027091FC: AND w22, w4, #1            | W22 = (UseFullRange & 1);               
            bool val_1 = UseFullRange;
            // 0x02709200: MOV x27, x19               | X27 = pp;//m1                           
            val_4 = pp;
            label_5:
            // 0x02709204: CBZ x27, #0x2709210        | if (pp == null) goto label_0;           
            if(val_4 == null)
            {
                goto label_0;
            }
            // 0x02709208: LDP x23, x24, [x27, #0x18] | X23 = pp.Pt; //P2                        //  | 
            val_5 = pp.Pt;
            // 0x0270920C: B #0x2709220               |  goto label_1;                          
            goto label_1;
            label_0:
            // 0x02709210: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02709214: LDR x23, [x25]             | X23 = 0x9814C0;                         
            val_5 = 9966784;
            // 0x02709218: LDR x24, [x26]             | X24 = 0x40;                             
            val_6 = 64;
            // 0x0270921C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x02709220: LDR x28, [x27, #0x28]      | X28 = pp.Next; //P2                     
            // 0x02709224: CBNZ x28, #0x270922c       | if (pp.Next != null) goto label_2;      
            if(pp.Next != null)
            {
                goto label_2;
            }
            // 0x02709228: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x0270922C: LDP x5, x6, [x28, #0x18]   | X5 = pp.Next.Pt; //P2                    //  | 
            // 0x02709230: MOV x1, x21                | X1 = pt.X;//m1                          
            // 0x02709234: MOV x2, x20                | X2 = pt.Y;//m1                          
            // 0x02709238: MOV x3, x23                | X3 = 9966784 (0x9814C0);//ML01          
            // 0x0270923C: MOV x4, x24                | X4 = 64 (0x40);//ML01                   
            // 0x02709240: MOV w7, w22                | W7 = (UseFullRange & 1);//m1            
            // 0x02709244: BL #0x270977c              | X0 = this.PointOnLineSegment(pt:  new Pathfinding.ClipperLib.IntPoint() {X = pt.X, Y = pt.Y}, linePt1:  new Pathfinding.ClipperLib.IntPoint() {X = 9966784, Y = 64}, linePt2:  new Pathfinding.ClipperLib.IntPoint() {X = pp.Next.Pt}, UseFullRange:  val_1);
            bool val_2 = this.PointOnLineSegment(pt:  new Pathfinding.ClipperLib.IntPoint() {X = pt.X, Y = pt.Y}, linePt1:  new Pathfinding.ClipperLib.IntPoint() {X = 9966784, Y = 64}, linePt2:  new Pathfinding.ClipperLib.IntPoint() {X = pp.Next.Pt}, UseFullRange:  val_1);
            // 0x02709248: AND w8, w0, #1             | W8 = (val_2 & 1);                       
            bool val_3 = val_2;
            // 0x0270924C: TBNZ w8, #0, #0x270926c    | if ((val_2 & 1) == true) goto label_3;  
            if(val_3 == true)
            {
                goto label_3;
            }
            // 0x02709250: CBNZ x27, #0x2709258       | if (pp != null) goto label_4;           
            if(val_4 != null)
            {
                goto label_4;
            }
            // 0x02709254: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_4:
            // 0x02709258: LDR x27, [x27, #0x28]      | X27 = pp.Next; //P2                     
            val_4 = pp.Next;
            // 0x0270925C: CMP x27, x19               | STATE = COMPARE(pp.Next, pp)            
            // 0x02709260: B.NE #0x2709204            | if (val_4 != pp) goto label_5;          
            if(val_4 != pp)
            {
                goto label_5;
            }
            // 0x02709264: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_7 = 0;
            // 0x02709268: B #0x2709270               |  goto label_6;                          
            goto label_6;
            label_3:
            // 0x0270926C: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_7 = 1;
            label_6:
            // 0x02709270: SUB sp, x29, #0x50         | SP = (1152921509605477600 - 80) = 1152921509605477520 (0x1000000129F10C90);
            // 0x02709274: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x02709278: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x0270927C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x02709280: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x02709284: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x02709288: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x0270928C: RET                        |  return (System.Boolean)true;           
            return (bool)val_7;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x02709290 (40931984), len: 608  VirtAddr: 0x02709290 RVA: 0x02709290 token: 100663337 methodIndex: 20752 delegateWrapperIndex: 0 methodInvoker: 0
        internal bool PointInPolygon(Pathfinding.ClipperLib.IntPoint pt, Pathfinding.ClipperLib.OutPt pp, bool UseFullRange)
        {
            //
            // Disasemble & Code
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            Pathfinding.ClipperLib.OutPt val_20;
            //  | 
            var val_21;
            //  | 
            Pathfinding.ClipperLib.IntPoint val_22;
            //  | 
            Pathfinding.ClipperLib.OutPt val_23;
            //  | 
            Pathfinding.ClipperLib.OutPt val_24;
            //  | 
            long val_25;
            //  | 
            Pathfinding.ClipperLib.OutPt val_26;
            //  | 
            var val_27;
            //  | 
            var val_28;
            //  | 
            var val_29;
            //  | 
            Pathfinding.ClipperLib.OutPt val_30;
            // 0x02709290: STP x28, x27, [sp, #-0x60]! | stack[1152921509605638672] = ???;  stack[1152921509605638680] = ???;  //  dest_result_addr=1152921509605638672 |  dest_result_addr=1152921509605638680
            // 0x02709294: STP x26, x25, [sp, #0x10]  | stack[1152921509605638688] = ???;  stack[1152921509605638696] = ???;  //  dest_result_addr=1152921509605638688 |  dest_result_addr=1152921509605638696
            // 0x02709298: STP x24, x23, [sp, #0x20]  | stack[1152921509605638704] = ???;  stack[1152921509605638712] = ???;  //  dest_result_addr=1152921509605638704 |  dest_result_addr=1152921509605638712
            // 0x0270929C: STP x22, x21, [sp, #0x30]  | stack[1152921509605638720] = ???;  stack[1152921509605638728] = ???;  //  dest_result_addr=1152921509605638720 |  dest_result_addr=1152921509605638728
            // 0x027092A0: STP x20, x19, [sp, #0x40]  | stack[1152921509605638736] = ???;  stack[1152921509605638744] = ???;  //  dest_result_addr=1152921509605638736 |  dest_result_addr=1152921509605638744
            // 0x027092A4: STP x29, x30, [sp, #0x50]  | stack[1152921509605638752] = ???;  stack[1152921509605638760] = ???;  //  dest_result_addr=1152921509605638752 |  dest_result_addr=1152921509605638760
            // 0x027092A8: ADD x29, sp, #0x50         | X29 = (1152921509605638672 + 80) = 1152921509605638752 (0x1000000129F38260);
            // 0x027092AC: SUB sp, sp, #0x10          | SP = (1152921509605638672 - 16) = 1152921509605638656 (0x1000000129F38200);
            // 0x027092B0: MOV x19, x3                | X19 = pp;//m1                           
            // 0x027092B4: MOV x20, x2                | X20 = pt.Y;//m1                         
            // 0x027092B8: STR x1, [sp, #8]           | stack[1152921509605638664] = pt.X;       //  dest_result_addr=1152921509605638664
            // 0x027092BC: TBZ w4, #0, #0x27093ec     | if (UseFullRange == false) goto label_0;
            if(UseFullRange == false)
            {
                goto label_0;
            }
            // 0x027092C0: MOV w8, wzr                | W8 = 0 (0x0);//ML01                     
            // 0x027092C4: MOV x27, x19               | X27 = pp;//m1                           
            // 0x027092C8: STR w8, [sp, #4]           | stack[1152921509605638660] = 0x0;        //  dest_result_addr=1152921509605638660
            label_11:
            // 0x027092CC: CBZ x27, #0x27092dc        | if (pp == null) goto label_1;           
            if(pp == null)
            {
                goto label_1;
            }
            // 0x027092D0: MOV x28, x27               | X28 = pp;//m1                           
            val_18 = pp;
            // 0x027092D4: LDR x22, [x28, #0x20]!     | 
            // 0x027092D8: B #0x27092f0               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x027092DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x027092E0: ORR w8, wzr, #0x20         | W8 = 32(0x20);                          
            // 0x027092E4: LDR x22, [x8]              | X22 = 0x40;                             
            val_19 = 64;
            // 0x027092E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x027092EC: ORR w28, wzr, #0x20        | W28 = 32(0x20);                         
            val_18 = 32;
            label_2:
            // 0x027092F0: LDR x21, [x27, #0x30]      | X21 = pp.Prev; //P2                     
            val_20 = pp.Prev;
            // 0x027092F4: CBNZ x21, #0x27092fc       | if (pp.Prev != null) goto label_3;      
            if(val_20 != null)
            {
                goto label_3;
            }
            // 0x027092F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_3:
            // 0x027092FC: LDR x8, [x21, #0x20]       | 
            // 0x02709300: CMP x22, x20               | STATE = COMPARE(0x40, pt.Y)             
            // 0x02709304: CSET w9, gt                | W9 = val_19 > pt.Y ? 1 : 0;             
            var val_1 = (64 > pt.Y) ? 1 : 0;
            // 0x02709308: CMP x8, x20                | STATE = COMPARE(0x20, pt.Y)             
            // 0x0270930C: CSET w8, gt                | W8 = 32 > pt.Y ? 1 : 0;                 
            var val_2 = (32 > pt.Y) ? 1 : 0;
            // 0x02709310: CMP w9, w8                 | STATE = COMPARE(val_19 > pt.Y ? 1 : 0, 32 > pt.Y ? 1 : 0)
            // 0x02709314: B.EQ #0x27093cc            | if (val_1 == val_2) goto label_9;       
            if(val_1 == val_2)
            {
                goto label_9;
            }
            // 0x02709318: CBZ x27, #0x2709328        | if (pp == null) goto label_5;           
            if(pp == null)
            {
                goto label_5;
            }
            // 0x0270931C: MOV x22, x27               | X22 = pp;//m1                           
            val_21 = pp;
            // 0x02709320: LDR x21, [x22, #0x18]!     | X21 = pp.Pt; //P2                       
            val_22 = pp.Pt;
            // 0x02709324: B #0x270933c               |  goto label_6;                          
            goto label_6;
            label_5:
            // 0x02709328: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270932C: ORR w8, wzr, #0x18         | W8 = 24(0x18);                          
            // 0x02709330: LDR x21, [x8]              | X21 = 0x9814C0;                         
            val_22 = 9966784;
            // 0x02709334: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02709338: ORR w22, wzr, #0x18        | W22 = 24(0x18);                         
            val_21 = 24;
            label_6:
            // 0x0270933C: LDR x23, [x27, #0x30]      | X23 = pp.Prev; //P2                     
            // 0x02709340: LDR x8, [sp, #8]           | X8 = pt.X;                              
            // 0x02709344: MOV x24, x23               | X24 = pp.Prev;//m1                      
            val_23 = pp.Prev;
            // 0x02709348: SUB x26, x8, x21           | X26 = (pt.X - val_22);                  
            long val_3 = pt.X - val_22;
            // 0x0270934C: CBNZ x23, #0x2709358       | if (pp.Prev != null) goto label_7;      
            if(pp.Prev != null)
            {
                goto label_7;
            }
            // 0x02709350: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02709354: LDR x24, [x27, #0x30]      | X24 = pp.Prev; //P2                     
            val_23 = pp.Prev;
            label_7:
            // 0x02709358: LDR x8, [x23, #0x18]       | X8 = pp.Prev.Pt; //P2                   
            // 0x0270935C: LDR x9, [x22]              | X9 = 0x9814C0;                          
            // 0x02709360: LDR x21, [x28]             | X21 = 0x40;                             
            // 0x02709364: ASR x25, x26, #0x3f        | X25 = ((pt.X - val_22) >> 63);          
            val_24 = val_3 >> 63;
            // 0x02709368: SUB x1, x8, x9             | X1 = (pp.Prev.Pt - val_21);             
            Pathfinding.ClipperLib.IntPoint val_4 = pp.Prev.Pt - val_21;
            // 0x0270936C: SUB x2, x20, x21           | X2 = (pt.Y - val_18);                   
            pt.Y = pt.Y - val_18;
            // 0x02709370: BL #0x27098b8              | X0 = Pathfinding.ClipperLib.Int128.Int128Mul(lhs:  this, rhs:  Pathfinding.ClipperLib.IntPoint val_4 = pp.Prev.Pt - val_21);
            Pathfinding.ClipperLib.Int128 val_5 = Pathfinding.ClipperLib.Int128.Int128Mul(lhs:  this, rhs:  val_4);
            // 0x02709374: MOV x22, x0                | X22 = val_5.hi;//m1                     
            // 0x02709378: MOV x23, x1                | X23 = val_5.lo;//m1                     
            val_25 = val_5.lo;
            // 0x0270937C: CBNZ x24, #0x2709388       | if (pp.Prev != null) goto label_8;      
            if(val_23 != null)
            {
                goto label_8;
            }
            // 0x02709380: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5.hi, ????);   
            // 0x02709384: LDR x21, [x28]             | X21 = 0x40;                             
            val_20 = 64;
            label_8:
            // 0x02709388: LDR x8, [x24, #0x20]       | 
            // 0x0270938C: MOV x1, x22                | X1 = val_5.hi;//m1                      
            // 0x02709390: MOV x2, x23                | X2 = val_5.lo;//m1                      
            // 0x02709394: SUB x4, x8, x21            | X4 = (pp.Prev.Pt - val_20);             
            Pathfinding.ClipperLib.IntPoint val_6 = pp.Prev.Pt - val_20;
            // 0x02709398: ASR x3, x4, #0x3f          | X3 = ((pp.Prev.Pt - val_20) >> 63);     
            Pathfinding.ClipperLib.IntPoint val_7 = val_6 >> 63;
            // 0x0270939C: BL #0x27099c8              | X0 = Pathfinding.ClipperLib.Int128.op_Division(lhs:  new Pathfinding.ClipperLib.Int128() {hi = val_5.hi, lo = val_5.hi}, rhs:  new Pathfinding.ClipperLib.Int128() {hi = val_25, lo = val_7});
            Pathfinding.ClipperLib.Int128 val_8 = Pathfinding.ClipperLib.Int128.op_Division(lhs:  new Pathfinding.ClipperLib.Int128() {hi = val_5.hi, lo = val_5.hi}, rhs:  new Pathfinding.ClipperLib.Int128() {hi = val_25, lo = val_7});
            // 0x027093A0: CMP x26, x1                | STATE = COMPARE((pt.X - val_22), val_8.lo)
            // 0x027093A4: CSET w8, lo                | W8 = val_3 < val_8.lo ? 1 : 0;          
            var val_9 = (val_3 < val_8.lo) ? 1 : 0;
            // 0x027093A8: CMP x25, x0                | STATE = COMPARE(((pt.X - val_22) >> 63), val_8.hi)
            // 0x027093AC: CSET w9, lt                | W9 = val_24 < val_8.hi ? 1 : 0;         
            var val_10 = (val_24 < val_8.hi) ? 1 : 0;
            // 0x027093B0: CSEL w8, w9, w8, ne        | W8 = val_24 != val_8.hi ? val_24 < val_8.hi ? 1 : 0 : val_3 < val_8.lo ? 1 : 0;
            var val_11 = (val_24 != val_8.hi) ? (val_10) : (val_9);
            // 0x027093B4: CMP w8, #1                 | STATE = COMPARE(val_24 != val_8.hi ? val_24 < val_8.hi ? 1 : 0 : val_3 < val_8.lo ? 1 : 0, 0x1)
            // 0x027093B8: B.NE #0x27093cc            | if (val_11 != 0x1) goto label_9;        
            if(val_11 != 1)
            {
                goto label_9;
            }
            // 0x027093BC: LDR w8, [sp, #4]           | W8 = 0x0;                               
            // 0x027093C0: MVN w8, w8                 | W8 = 0 (0x0);//ML01                     
            // 0x027093C4: AND w8, w8, #1             | W8 = (0 & 1) = 0 (0x00000000);          
            // 0x027093C8: STR w8, [sp, #4]           | stack[1152921509605638660] = 0x0;        //  dest_result_addr=1152921509605638660
            label_9:
            // 0x027093CC: CBNZ x27, #0x27093d4       | if (pp != null) goto label_10;          
            if(pp != null)
            {
                goto label_10;
            }
            // 0x027093D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8.hi, ????);   
            label_10:
            // 0x027093D4: LDR x27, [x27, #0x28]      | X27 = pp.Next; //P2                     
            val_26 = pp.Next;
            // 0x027093D8: CMP x27, x19               | STATE = COMPARE(pp.Next, pp)            
            // 0x027093DC: B.NE #0x27092cc            | if (val_26 != pp) goto label_11;        
            if(val_26 != pp)
            {
                goto label_11;
            }
            // 0x027093E0: LDR w8, [sp, #4]           | W8 = 0x0;                               
            // 0x027093E4: AND w22, w8, #1            | W22 = (0 & 1) = val_27 (0x00000000);    
            val_27 = 0;
            // 0x027093E8: B #0x27094c8               |  goto label_12;                         
            goto label_12;
            label_0:
            // 0x027093EC: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_27 = 0;
            // 0x027093F0: ORR w23, wzr, #0x20        | W23 = 32(0x20);                         
            val_25 = 32;
            // 0x027093F4: ORR w24, wzr, #0x18        | W24 = 24(0x18);                         
            // 0x027093F8: MOV x25, x19               | X25 = pp;//m1                           
            label_22:
            // 0x027093FC: CBZ x25, #0x270940c        | if (pp == null) goto label_13;          
            if(pp == null)
            {
                goto label_13;
            }
            // 0x02709400: MOV x26, x25               | X26 = pp;//m1                           
            val_28 = pp;
            // 0x02709404: LDR x27, [x26, #0x20]!     | 
            // 0x02709408: B #0x270941c               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x0270940C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02709410: LDR x27, [x23]             | X27 = 0x40;                             
            val_26 = 64;
            // 0x02709414: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02709418: ORR w26, wzr, #0x20        | W26 = 32(0x20);                         
            val_28 = 32;
            label_14:
            // 0x0270941C: LDR x21, [x25, #0x30]      | X21 = pp.Prev; //P2                     
            val_20 = pp.Prev;
            // 0x02709420: CBNZ x21, #0x2709428       | if (pp.Prev != null) goto label_15;     
            if(val_20 != null)
            {
                goto label_15;
            }
            // 0x02709424: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_15:
            // 0x02709428: LDR x8, [x21, #0x20]       | 
            // 0x0270942C: CMP x27, x20               | STATE = COMPARE(0x40, pt.Y)             
            // 0x02709430: CSET w9, gt                | W9 = val_26 > pt.Y ? 1 : 0;             
            var val_12 = (64 > pt.Y) ? 1 : 0;
            // 0x02709434: CMP x8, x20                | STATE = COMPARE(X8, pt.Y)               
            // 0x02709438: CSET w8, gt                | W8 = X8 > pt.Y ? 1 : 0;                 
            var val_13 = (X8 > pt.Y) ? 1 : 0;
            // 0x0270943C: CMP w9, w8                 | STATE = COMPARE(val_26 > pt.Y ? 1 : 0, X8 > pt.Y ? 1 : 0)
            // 0x02709440: B.EQ #0x27094b4            | if (val_12 == val_13) goto label_16;    
            if(val_12 == val_13)
            {
                goto label_16;
            }
            // 0x02709444: CBZ x25, #0x2709454        | if (pp == null) goto label_17;          
            if(pp == null)
            {
                goto label_17;
            }
            // 0x02709448: MOV x28, x25               | X28 = pp;//m1                           
            val_29 = pp;
            // 0x0270944C: LDR x27, [x28, #0x18]!     | X27 = pp.Pt; //P2                       
            val_26 = pp.Pt;
            // 0x02709450: B #0x2709464               |  goto label_18;                         
            goto label_18;
            label_17:
            // 0x02709454: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02709458: LDR x27, [x24]             | X27 = 0x9814C0;                         
            val_26 = 9966784;
            // 0x0270945C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02709460: ORR w28, wzr, #0x18        | W28 = 24(0x18);                         
            val_29 = 24;
            label_18:
            // 0x02709464: LDR x21, [x25, #0x30]      | X21 = pp.Prev; //P2                     
            val_20 = pp.Prev;
            // 0x02709468: MOV x8, x21                | X8 = pp.Prev;//m1                       
            val_30 = val_20;
            // 0x0270946C: CBNZ x21, #0x270947c       | if (pp.Prev != null) goto label_19;     
            if(val_20 != null)
            {
                goto label_19;
            }
            // 0x02709470: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02709474: LDR x8, [x25, #0x30]       | X8 = pp.Prev; //P2                      
            val_30 = pp.Prev;
            // 0x02709478: CBZ x8, #0x27094ec         | if (pp.Prev == null) goto label_20;     
            if(val_30 == null)
            {
                goto label_20;
            }
            label_19:
            // 0x0270947C: LDR x9, [x21, #0x18]       | X9 = pp.Prev.Pt; //P2                   
            Pathfinding.ClipperLib.IntPoint val_17 = pp.Prev.Pt;
            // 0x02709480: LDR x10, [x28]             | X10 = 0x9814C0;                         
            // 0x02709484: LDR x11, [x26]             | X11 = 0x40;                             
            // 0x02709488: LDR x8, [x8, #0x20]        | 
            // 0x0270948C: LDR x12, [sp, #8]          | X12 = pt.X;                             
            long val_18 = pt.X;
            // 0x02709490: SUB x9, x9, x10            | X9 = (pp.Prev.Pt - val_29);             
            val_17 = val_17 - val_29;
            // 0x02709494: SUB x10, x20, x11          | X10 = (pt.Y - val_28);                  
            long val_14 = pt.Y - val_28;
            // 0x02709498: MUL x9, x10, x9            | X9 = ((pt.Y - val_28) * (pp.Prev.Pt - val_29));
            val_17 = val_14 * val_17;
            // 0x0270949C: SUB x8, x8, x11            | X8 = (pp.Prev - val_28);                
            val_30 = val_30 - val_28;
            // 0x027094A0: SUB x12, x12, x27          | X12 = (pt.X - val_26);                  
            val_18 = val_18 - val_26;
            // 0x027094A4: SDIV x8, x9, x8            | X8 = (((pt.Y - val_28) * (pp.Prev.Pt - val_29)) / (pp.Prev - val_28));
            val_30 = val_17 / val_30;
            // 0x027094A8: CMP x12, x8                | STATE = COMPARE((pt.X - val_26), (((pt.Y - val_28) * (pp.Prev.Pt - val_29)) / (pp.Prev - val_28)))
            // 0x027094AC: CSET w8, lt                | W8 = pt.X < val_30 ? 1 : 0;             
            var val_15 = (val_18 < val_30) ? 1 : 0;
            // 0x027094B0: EOR w22, w22, w8           | W22 = (val_27 ^ pt.X < val_30 ? 1 : 0); 
            val_27 = val_27 ^ val_15;
            label_16:
            // 0x027094B4: CBNZ x25, #0x27094bc       | if (pp != null) goto label_21;          
            if(pp != null)
            {
                goto label_21;
            }
            // 0x027094B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_21:
            // 0x027094BC: LDR x25, [x25, #0x28]      | X25 = pp.Next; //P2                     
            val_24 = pp.Next;
            // 0x027094C0: CMP x25, x19               | STATE = COMPARE(pp.Next, pp)            
            // 0x027094C4: B.NE #0x27093fc            | if (val_24 != pp) goto label_22;        
            if(val_24 != pp)
            {
                goto label_22;
            }
            label_12:
            // 0x027094C8: AND w0, w22, #1            | W0 = ((val_27 ^ pt.X < val_30 ? 1 : 0) & 1);
            var val_16 = val_27 & 1;
            // 0x027094CC: SUB sp, x29, #0x50         | SP = (1152921509605638752 - 80) = 1152921509605638672 (0x1000000129F38210);
            // 0x027094D0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x027094D4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x027094D8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x027094DC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x027094E0: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x027094E4: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x027094E8: RET                        |  return (System.Boolean)((val_27 ^ pt.X < val_30 ? 1 : 0) & 1);
            return (bool)val_16;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_20:
            // 0x027094EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        
        }
        //
        // Offset in libil2cpp.so: 0x02704A2C (40913452), len: 188  VirtAddr: 0x02704A2C RVA: 0x02704A2C token: 100663338 methodIndex: 20753 delegateWrapperIndex: 0 methodInvoker: 0
        internal static bool SlopesEqual(Pathfinding.ClipperLib.TEdge e1, Pathfinding.ClipperLib.TEdge e2, bool UseFullRange)
        {
            //
            // Disasemble & Code
            // 0x02704A2C: STP x24, x23, [sp, #-0x40]! | stack[1152921509605795760] = ???;  stack[1152921509605795768] = ???;  //  dest_result_addr=1152921509605795760 |  dest_result_addr=1152921509605795768
            // 0x02704A30: STP x22, x21, [sp, #0x10]  | stack[1152921509605795776] = ???;  stack[1152921509605795784] = ???;  //  dest_result_addr=1152921509605795776 |  dest_result_addr=1152921509605795784
            // 0x02704A34: STP x20, x19, [sp, #0x20]  | stack[1152921509605795792] = ???;  stack[1152921509605795800] = ???;  //  dest_result_addr=1152921509605795792 |  dest_result_addr=1152921509605795800
            // 0x02704A38: STP x29, x30, [sp, #0x30]  | stack[1152921509605795808] = ???;  stack[1152921509605795816] = ???;  //  dest_result_addr=1152921509605795808 |  dest_result_addr=1152921509605795816
            // 0x02704A3C: ADD x29, sp, #0x30         | X29 = (1152921509605795760 + 48) = 1152921509605795808 (0x1000000129F5E7E0);
            // 0x02704A40: MOV w22, w3                | W22 = W3;//m1                           
            // 0x02704A44: MOV x19, x2                | X19 = UseFullRange;//m1                 
            // 0x02704A48: MOV x20, x1                | X20 = e2;//m1                           
            // 0x02704A4C: CBNZ x20, #0x2704a54       | if (e2 != null) goto label_0;           
            if(e2 != null)
            {
                goto label_0;
            }
            // 0x02704A50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? e1, ????);         
            label_0:
            // 0x02704A54: LDR x21, [x20, #0x48]      | 
            // 0x02704A58: CBNZ x19, #0x2704a60       | if (UseFullRange == true) goto label_1; 
            if(UseFullRange == true)
            {
                goto label_1;
            }
            // 0x02704A5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? e1, ????);         
            label_1:
            // 0x02704A60: LDR x23, [x19, #0x40]      | X23 = UseFullRange + 64;                
            // 0x02704A64: TBZ w22, #0, #0x2704ab4    | if ((W3 & 0x1) == 0) goto label_2;      
            if((W3 & 1) == 0)
            {
                goto label_2;
            }
            // 0x02704A68: MOV x1, x21                | X1 = X21;//m1                           
            // 0x02704A6C: MOV x2, x23                | X2 = UseFullRange + 64;//m1             
            // 0x02704A70: BL #0x27098b8              | X0 = Pathfinding.ClipperLib.Int128.Int128Mul(lhs:  e1, rhs:  X21);
            Pathfinding.ClipperLib.Int128 val_1 = Pathfinding.ClipperLib.Int128.Int128Mul(lhs:  e1, rhs:  X21);
            // 0x02704A74: MOV x21, x0                | X21 = val_1.hi;//m1                     
            // 0x02704A78: MOV x22, x1                | X22 = val_1.lo;//m1                     
            // 0x02704A7C: CBNZ x20, #0x2704a84       | if (e2 != null) goto label_3;           
            if(e2 != null)
            {
                goto label_3;
            }
            // 0x02704A80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1.hi, ????);   
            label_3:
            // 0x02704A84: LDR x1, [x20, #0x40]       | X1 = e2.Delta; //P2                     
            // 0x02704A88: LDR x2, [x19, #0x48]       | X2 = UseFullRange + 72;                 
            // 0x02704A8C: BL #0x27098b8              | X0 = Pathfinding.ClipperLib.Int128.Int128Mul(lhs:  val_1.hi, rhs:  e2.Delta);
            Pathfinding.ClipperLib.Int128 val_2 = Pathfinding.ClipperLib.Int128.Int128Mul(lhs:  val_1.hi, rhs:  e2.Delta);
            // 0x02704A90: MOV x4, x1                 | X4 = val_2.lo;//m1                      
            // 0x02704A94: MOV x1, x21                | X1 = val_1.hi;//m1                      
            // 0x02704A98: MOV x2, x22                | X2 = val_1.lo;//m1                      
            // 0x02704A9C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x02704AA0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x02704AA4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x02704AA8: MOV x3, x0                 | X3 = val_2.hi;//m1                      
            // 0x02704AAC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x02704AB0: B #0x2709910               | return Pathfinding.ClipperLib.Int128.op_Equality(val1:  new Pathfinding.ClipperLib.Int128() {hi = val_2.hi, lo = val_1.hi}, val2:  new Pathfinding.ClipperLib.Int128() {hi = val_1.lo, lo = val_2.hi});
            return Pathfinding.ClipperLib.Int128.op_Equality(val1:  new Pathfinding.ClipperLib.Int128() {hi = val_2.hi, lo = val_1.hi}, val2:  new Pathfinding.ClipperLib.Int128() {hi = val_1.lo, lo = val_2.hi});
            label_2:
            // 0x02704AB4: CBNZ x20, #0x2704abc       | if (e2 != null) goto label_4;           
            if(e2 != null)
            {
                goto label_4;
            }
            // 0x02704AB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? e1, ????);         
            label_4:
            // 0x02704ABC: LDR x8, [x20, #0x40]       | X8 = e2.Delta; //P2                     
            Pathfinding.ClipperLib.IntPoint val_5 = e2.Delta;
            // 0x02704AC0: LDR x9, [x19, #0x48]       | X9 = UseFullRange + 72;                 
            // 0x02704AC4: MUL x10, x23, x21          | X10 = (UseFullRange + 64 * X21);        
            var val_3 = (UseFullRange + 64) * X21;
            // 0x02704AC8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x02704ACC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x02704AD0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x02704AD4: MUL x8, x9, x8             | X8 = (UseFullRange + 72 * e2.Delta);    
            val_5 = (UseFullRange + 72) * val_5;
            // 0x02704AD8: CMP x10, x8                | STATE = COMPARE((UseFullRange + 64 * X21), (UseFullRange + 72 * e2.Delta))
            // 0x02704ADC: CSET w0, eq                | W0 = val_3 == e2.Delta ? 1 : 0;         
            var val_4 = (val_3 == val_5) ? 1 : 0;
            // 0x02704AE0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x02704AE4: RET                        |  return (System.Boolean)val_3 == e2.Delta ? 1 : 0;
            return (bool)val_4;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x02708010 (40927248), len: 152  VirtAddr: 0x02708010 RVA: 0x02708010 token: 100663339 methodIndex: 20754 delegateWrapperIndex: 0 methodInvoker: 0
        protected static bool SlopesEqual(Pathfinding.ClipperLib.IntPoint pt1, Pathfinding.ClipperLib.IntPoint pt2, Pathfinding.ClipperLib.IntPoint pt3, bool UseFullRange)
        {
            //
            // Disasemble & Code
            // 0x02708010: STP x24, x23, [sp, #-0x40]! | stack[1152921509605915952] = ???;  stack[1152921509605915960] = ???;  //  dest_result_addr=1152921509605915952 |  dest_result_addr=1152921509605915960
            // 0x02708014: STP x22, x21, [sp, #0x10]  | stack[1152921509605915968] = ???;  stack[1152921509605915976] = ???;  //  dest_result_addr=1152921509605915968 |  dest_result_addr=1152921509605915976
            // 0x02708018: STP x20, x19, [sp, #0x20]  | stack[1152921509605915984] = ???;  stack[1152921509605915992] = ???;  //  dest_result_addr=1152921509605915984 |  dest_result_addr=1152921509605915992
            // 0x0270801C: STP x29, x30, [sp, #0x30]  | stack[1152921509605916000] = ???;  stack[1152921509605916008] = ???;  //  dest_result_addr=1152921509605916000 |  dest_result_addr=1152921509605916008
            // 0x02708020: ADD x29, sp, #0x30         | X29 = (1152921509605915952 + 48) = 1152921509605916000 (0x1000000129F7BD60);
            // 0x02708024: MOV x20, x4                | X20 = pt3.X;//m1                        
            // 0x02708028: MOV x21, x3                | X21 = pt2.Y;//m1                        
            // 0x0270802C: MOV x19, x6                | X19 = UseFullRange;//m1                 
            // 0x02708030: MOV x22, x1                | X22 = pt1.Y;//m1                        
            // 0x02708034: SUB x1, x2, x20            | X1 = (pt2.X - pt3.X);                   
            long val_1 = pt2.X - pt3.X;
            // 0x02708038: SUB x2, x21, x5            | X2 = (pt2.Y - pt3.Y);                   
            long val_2 = pt2.Y - pt3.Y;
            // 0x0270803C: TBZ w7, #0, #0x270807c     | if ((W7 & 0x1) == 0) goto label_0;      
            if((W7 & 1) == 0)
            {
                goto label_0;
            }
            // 0x02708040: BL #0x27098b8              | X0 = Pathfinding.ClipperLib.Int128.Int128Mul(lhs:  pt1.X, rhs:  long val_1 = pt2.X - pt3.X);
            Pathfinding.ClipperLib.Int128 val_3 = Pathfinding.ClipperLib.Int128.Int128Mul(lhs:  pt1.X, rhs:  val_1);
            // 0x02708044: MOV x24, x1                | X24 = val_3.lo;//m1                     
            // 0x02708048: SUB x1, x22, x21           | X1 = (pt1.Y - pt2.Y);                   
            long val_4 = pt1.Y - pt2.Y;
            // 0x0270804C: SUB x2, x20, x19           | X2 = (pt3.X - UseFullRange);            
            long val_5 = pt3.X - UseFullRange;
            // 0x02708050: MOV x23, x0                | X23 = val_3.hi;//m1                     
            // 0x02708054: BL #0x27098b8              | X0 = Pathfinding.ClipperLib.Int128.Int128Mul(lhs:  val_3.hi, rhs:  long val_4 = pt1.Y - pt2.Y);
            Pathfinding.ClipperLib.Int128 val_6 = Pathfinding.ClipperLib.Int128.Int128Mul(lhs:  val_3.hi, rhs:  val_4);
            // 0x02708058: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0270805C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x02708060: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x02708064: MOV x4, x1                 | X4 = val_6.lo;//m1                      
            // 0x02708068: MOV x1, x23                | X1 = val_3.hi;//m1                      
            // 0x0270806C: MOV x2, x24                | X2 = val_3.lo;//m1                      
            // 0x02708070: MOV x3, x0                 | X3 = val_6.hi;//m1                      
            // 0x02708074: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x02708078: B #0x2709910               | return Pathfinding.ClipperLib.Int128.op_Equality(val1:  new Pathfinding.ClipperLib.Int128() {hi = val_6.hi, lo = val_3.hi}, val2:  new Pathfinding.ClipperLib.Int128() {hi = val_3.lo, lo = val_6.hi});
            return Pathfinding.ClipperLib.Int128.op_Equality(val1:  new Pathfinding.ClipperLib.Int128() {hi = val_6.hi, lo = val_3.hi}, val2:  new Pathfinding.ClipperLib.Int128() {hi = val_3.lo, lo = val_6.hi});
            label_0:
            // 0x0270807C: SUB x9, x22, x21           | X9 = (pt1.Y - pt2.Y);                   
            long val_7 = pt1.Y - pt2.Y;
            // 0x02708080: SUB x10, x20, x19          | X10 = (pt3.X - UseFullRange);           
            long val_8 = pt3.X - UseFullRange;
            // 0x02708084: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x02708088: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0270808C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x02708090: MUL x8, x2, x1             | X8 = ((pt2.Y - pt3.Y) * (pt2.X - pt3.X));
            long val_9 = val_2 * val_1;
            // 0x02708094: MUL x9, x10, x9            | X9 = ((pt3.X - UseFullRange) * (pt1.Y - pt2.Y));
            val_7 = val_8 * val_7;
            // 0x02708098: CMP x8, x9                 | STATE = COMPARE(((pt2.Y - pt3.Y) * (pt2.X - pt3.X)), ((pt3.X - UseFullRange) * (pt1.Y - pt2.Y)))
            // 0x0270809C: CSET w0, eq                | W0 = val_9 == val_7 ? 1 : 0;            
            var val_10 = (val_9 == val_7) ? 1 : 0;
            // 0x027080A0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x027080A4: RET                        |  return (System.Boolean)val_9 == val_7 ? 1 : 0;
            return (bool)val_10;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x02701834 (40900660), len: 392  VirtAddr: 0x02701834 RVA: 0x02701834 token: 100663340 methodIndex: 20755 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual void Clear()
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            var val_6;
            // 0x02701834: STP x28, x27, [sp, #-0x60]! | stack[1152921509606066832] = ???;  stack[1152921509606066840] = ???;  //  dest_result_addr=1152921509606066832 |  dest_result_addr=1152921509606066840
            // 0x02701838: STP x26, x25, [sp, #0x10]  | stack[1152921509606066848] = ???;  stack[1152921509606066856] = ???;  //  dest_result_addr=1152921509606066848 |  dest_result_addr=1152921509606066856
            // 0x0270183C: STP x24, x23, [sp, #0x20]  | stack[1152921509606066864] = ???;  stack[1152921509606066872] = ???;  //  dest_result_addr=1152921509606066864 |  dest_result_addr=1152921509606066872
            // 0x02701840: STP x22, x21, [sp, #0x30]  | stack[1152921509606066880] = ???;  stack[1152921509606066888] = ???;  //  dest_result_addr=1152921509606066880 |  dest_result_addr=1152921509606066888
            // 0x02701844: STP x20, x19, [sp, #0x40]  | stack[1152921509606066896] = ???;  stack[1152921509606066904] = ???;  //  dest_result_addr=1152921509606066896 |  dest_result_addr=1152921509606066904
            // 0x02701848: STP x29, x30, [sp, #0x50]  | stack[1152921509606066912] = ???;  stack[1152921509606066920] = ???;  //  dest_result_addr=1152921509606066912 |  dest_result_addr=1152921509606066920
            // 0x0270184C: ADD x29, sp, #0x50         | X29 = (1152921509606066832 + 80) = 1152921509606066912 (0x1000000129FA0AE0);
            // 0x02701850: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
            // 0x02701854: LDRB w8, [x20, #0x16f]     | W8 = (bool)static_value_0374316F;       
            // 0x02701858: MOV x19, x0                | X19 = 1152921509606078928 (0x1000000129FA39D0);//ML01
            // 0x0270185C: TBNZ w8, #0, #0x2701878    | if (static_value_0374316F == true) goto label_0;
            // 0x02701860: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x02701864: LDR x8, [x8, #0x1e8]       | X8 = 0x2B90C3C;                         
            // 0x02701868: LDR w0, [x8]               | W0 = 0x19D3;                            
            // 0x0270186C: BL #0x2782188              | X0 = sub_2782188( ?? 0x19D3, ????);     
            // 0x02701870: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02701874: STRB w8, [x20, #0x16f]     | static_value_0374316F = true;            //  dest_result_addr=57946479
            label_0:
            // 0x02701878: LDR x8, [x19, #0x10]       | X8 = this.m_MinimaList; //P2            
            // 0x0270187C: CBZ x8, #0x270188c         | if (this.m_MinimaList == null) goto label_1;
            if(this.m_MinimaList == null)
            {
                goto label_1;
            }
            label_2:
            // 0x02701880: LDR x8, [x8, #0x28]        | X8 = this.m_MinimaList.Next; //P2       
            // 0x02701884: STR x8, [x19, #0x10]       | this.m_MinimaList = this.m_MinimaList.Next;  //  dest_result_addr=1152921509606078944
            this.m_MinimaList = this.m_MinimaList.Next;
            // 0x02701888: CBNZ x8, #0x2701880        | if (this.m_MinimaList.Next != null) goto label_2;
            if(this.m_MinimaList.Next != null)
            {
                goto label_2;
            }
            label_1:
            // 0x0270188C: STR xzr, [x19, #0x18]      | this.m_CurrentLM = null;                 //  dest_result_addr=1152921509606078952
            this.m_CurrentLM = 0;
            // 0x02701890: ADRP x24, #0x362c000       | X24 = 56803328 (0x362C000);             
            // 0x02701894: ADRP x25, #0x35d3000       | X25 = 56438784 (0x35D3000);             
            // 0x02701898: ADRP x26, #0x35c4000       | X26 = 56377344 (0x35C4000);             
            // 0x0270189C: ADRP x27, #0x3629000       | X27 = 56791040 (0x3629000);             
            // 0x027018A0: ADRP x28, #0x367c000       | X28 = 57131008 (0x367C000);             
            // 0x027018A4: LDR x24, [x24, #0x870]     | X24 = 1152921509606024208;              
            // 0x027018A8: LDR x25, [x25, #0xc80]     | X25 = 1152921509606025232;              
            // 0x027018AC: LDR x26, [x26, #0x838]     | X26 = 1152921509606026256;              
            // 0x027018B0: LDR x27, [x27, #0x860]     | X27 = 1152921509606027280;              
            // 0x027018B4: LDR x28, [x28, #0x330]     | X28 = 1152921509606028304;              
            // 0x027018B8: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_5 = 0;
            // 0x027018BC: B #0x27018d0               |  goto label_3;                          
            goto label_3;
            label_12:
            // 0x027018C0: LDR x1, [x28]              | X1 = public System.Void System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>::Clear();
            // 0x027018C4: MOV x0, x23                | X0 = X23;//m1                           
            // 0x027018C8: BL #0x25ead28              | X23.Clear();                            
            X23.Clear();
            // 0x027018CC: ADD w20, w20, #1           | W20 = (val_5 + 1) = val_5 (0x00000001); 
            val_5 = 1;
            label_3:
            // 0x027018D0: LDR x21, [x19, #0x20]      | X21 = this.m_edges; //P2                
            // 0x027018D4: CBNZ x21, #0x27018dc       | if (this.m_edges != null) goto label_4; 
            if(this.m_edges != null)
            {
                goto label_4;
            }
            // 0x027018D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X23, ????);        
            label_4:
            // 0x027018DC: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>>::get_Count();
            // 0x027018E0: MOV x0, x21                | X0 = this.m_edges;//m1                  
            // 0x027018E4: BL #0x25ed72c              | X0 = this.m_edges.get_Count();          
            int val_1 = this.m_edges.Count;
            // 0x027018E8: CMP w20, w0                | STATE = COMPARE(0x1, val_1)             
            // 0x027018EC: B.GE #0x270197c            | if (val_5 >= val_1) goto label_5;       
            if(val_5 >= val_1)
            {
                goto label_5;
            }
            // 0x027018F0: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_6 = 0;
            // 0x027018F4: B #0x2701910               |  goto label_6;                          
            goto label_6;
            label_11:
            // 0x027018F8: LDR x3, [x27]              | X3 = public System.Void System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>::set_Item(int index, Pathfinding.ClipperLib.TEdge value);
            // 0x027018FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02701900: MOV x0, x23                | X0 = X23;//m1                           
            // 0x02701904: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
            // 0x02701908: BL #0x25ed7fc              | X23.set_Item(index:  0, value:  0);     
            X23.set_Item(index:  0, value:  0);
            // 0x0270190C: ADD w21, w21, #1           | W21 = (val_6 + 1) = val_6 (0x00000001); 
            val_6 = 1;
            label_6:
            // 0x02701910: LDR x22, [x19, #0x20]      | X22 = this.m_edges; //P2                
            // 0x02701914: CBNZ x22, #0x270191c       | if (this.m_edges != null) goto label_7; 
            if(this.m_edges != null)
            {
                goto label_7;
            }
            // 0x02701918: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X23, ????);        
            label_7:
            // 0x0270191C: LDR x2, [x25]              | X2 = public System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge> System.Collections.Generic.List<System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>>::get_Item(int index);
            // 0x02701920: MOV x0, x22                | X0 = this.m_edges;//m1                  
            // 0x02701924: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
            // 0x02701928: BL #0x25ed734              | X0 = this.m_edges.get_Item(index:  1);  
            System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge> val_2 = this.m_edges.Item[1];
            // 0x0270192C: MOV x22, x0                | X22 = val_2;//m1                        
            // 0x02701930: CBNZ x22, #0x2701938       | if (val_2 != null) goto label_8;        
            if(val_2 != null)
            {
                goto label_8;
            }
            // 0x02701934: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_8:
            // 0x02701938: LDR x1, [x26]              | X1 = public System.Int32 System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>::get_Count();
            // 0x0270193C: MOV x0, x22                | X0 = val_2;//m1                         
            // 0x02701940: BL #0x25ed72c              | X0 = val_2.get_Count();                 
            int val_3 = val_2.Count;
            // 0x02701944: LDR x23, [x19, #0x20]      | X23 = this.m_edges; //P2                
            // 0x02701948: MOV w22, w0                | W22 = val_3;//m1                        
            // 0x0270194C: CBNZ x23, #0x2701954       | if (this.m_edges != null) goto label_9; 
            if(this.m_edges != null)
            {
                goto label_9;
            }
            // 0x02701950: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_9:
            // 0x02701954: LDR x2, [x25]              | X2 = public System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge> System.Collections.Generic.List<System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>>::get_Item(int index);
            // 0x02701958: MOV x0, x23                | X0 = this.m_edges;//m1                  
            // 0x0270195C: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
            // 0x02701960: BL #0x25ed734              | X0 = this.m_edges.get_Item(index:  1);  
            System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge> val_4 = this.m_edges.Item[1];
            // 0x02701964: MOV x23, x0                | X23 = val_4;//m1                        
            // 0x02701968: CBNZ x23, #0x2701970       | if (val_4 != null) goto label_10;       
            if(val_4 != null)
            {
                goto label_10;
            }
            // 0x0270196C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_10:
            // 0x02701970: CMP w21, w22               | STATE = COMPARE(0x1, val_3)             
            // 0x02701974: B.LT #0x27018f8            | if (val_6 < val_3) goto label_11;       
            if(val_6 < val_3)
            {
                goto label_11;
            }
            // 0x02701978: B #0x27018c0               |  goto label_12;                         
            goto label_12;
            label_5:
            // 0x0270197C: LDR x20, [x19, #0x20]      | X20 = this.m_edges; //P2                
            // 0x02701980: CBNZ x20, #0x2701988       | if (this.m_edges != null) goto label_13;
            if(this.m_edges != null)
            {
                goto label_13;
            }
            // 0x02701984: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_13:
            // 0x02701988: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
            // 0x0270198C: LDR x8, [x8, #0x190]       | X8 = 1152921509606053904;               
            // 0x02701990: MOV x0, x20                | X0 = this.m_edges;//m1                  
            // 0x02701994: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>>::Clear();
            // 0x02701998: BL #0x25ead28              | this.m_edges.Clear();                   
            this.m_edges.Clear();
            // 0x0270199C: STRH wzr, [x19, #0x28]     | this.m_UseFullRange = false; this.m_HasOpenPaths = false;  //  dest_result_addr=1152921509606078968 dest_result_addr=1152921509606078969
            this.m_UseFullRange = false;
            this.m_HasOpenPaths = false;
            // 0x027019A0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x027019A4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x027019A8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x027019AC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x027019B0: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x027019B4: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x027019B8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x02709BC4 (40934340), len: 28  VirtAddr: 0x02709BC4 RVA: 0x02709BC4 token: 100663341 methodIndex: 20756 delegateWrapperIndex: 0 methodInvoker: 0
        private void DisposeLocalMinimaList()
        {
            //
            // Disasemble & Code
            // 0x02709BC4: LDR x8, [x0, #0x10]        | X8 = this.m_MinimaList; //P2            
            // 0x02709BC8: CBZ x8, #0x2709bd8         | if (this.m_MinimaList == null) goto label_0;
            if(this.m_MinimaList == null)
            {
                goto label_0;
            }
            label_1:
            // 0x02709BCC: LDR x8, [x8, #0x28]        | X8 = this.m_MinimaList.Next; //P2       
            // 0x02709BD0: STR x8, [x0, #0x10]        | this.m_MinimaList = this.m_MinimaList.Next;  //  dest_result_addr=1152921509606231904
            this.m_MinimaList = this.m_MinimaList.Next;
            // 0x02709BD4: CBNZ x8, #0x2709bcc        | if (this.m_MinimaList.Next != null) goto label_1;
            if(this.m_MinimaList.Next != null)
            {
                goto label_1;
            }
            label_0:
            // 0x02709BD8: STR xzr, [x0, #0x18]       | this.m_CurrentLM = null;                 //  dest_result_addr=1152921509606231912
            this.m_CurrentLM = 0;
            // 0x02709BDC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x02709BE0 (40934368), len: 292  VirtAddr: 0x02709BE0 RVA: 0x02709BE0 token: 100663342 methodIndex: 20757 delegateWrapperIndex: 0 methodInvoker: 0
        private void RangeTest(Pathfinding.ClipperLib.IntPoint Pt, ref bool useFullRange)
        {
            //
            // Disasemble & Code
            // 0x02709BE0: STP x28, x27, [sp, #-0x60]! | stack[1152921509606345184] = ???;  stack[1152921509606345192] = ???;  //  dest_result_addr=1152921509606345184 |  dest_result_addr=1152921509606345192
            // 0x02709BE4: STP x26, x25, [sp, #0x10]  | stack[1152921509606345200] = ???;  stack[1152921509606345208] = ???;  //  dest_result_addr=1152921509606345200 |  dest_result_addr=1152921509606345208
            // 0x02709BE8: STP x24, x23, [sp, #0x20]  | stack[1152921509606345216] = ???;  stack[1152921509606345224] = ???;  //  dest_result_addr=1152921509606345216 |  dest_result_addr=1152921509606345224
            // 0x02709BEC: STP x22, x21, [sp, #0x30]  | stack[1152921509606345232] = ???;  stack[1152921509606345240] = ???;  //  dest_result_addr=1152921509606345232 |  dest_result_addr=1152921509606345240
            // 0x02709BF0: STP x20, x19, [sp, #0x40]  | stack[1152921509606345248] = ???;  stack[1152921509606345256] = ???;  //  dest_result_addr=1152921509606345248 |  dest_result_addr=1152921509606345256
            // 0x02709BF4: STP x29, x30, [sp, #0x50]  | stack[1152921509606345264] = ???;  stack[1152921509606345272] = ???;  //  dest_result_addr=1152921509606345264 |  dest_result_addr=1152921509606345272
            // 0x02709BF8: ADD x29, sp, #0x50         | X29 = (1152921509606345184 + 80) = 1152921509606345264 (0x1000000129FE4A30);
            // 0x02709BFC: MOV x19, x2                | X19 = Pt.Y;//m1                         
            // 0x02709C00: MOV x20, x1                | X20 = Pt.X;//m1                         
            // 0x02709C04: ORR w8, wzr, #0x3fffffff   | W8 = 1073741823(0x3FFFFFFF);            
            // 0x02709C08: MOV x21, x3                | X21 = 1152921509606389280 (0x1000000129FEF620);//ML01
            // 0x02709C0C: NEG x22, x20               | X22 = -(Pt.X);                          
            // 0x02709C10: NEG x23, x19               | X23 = -(Pt.Y);                          
            // 0x02709C14: CMP x20, x8                | STATE = COMPARE(Pt.X, 0x3FFFFFFF)       
            // 0x02709C18: ADRP x28, #0x3743000       | X28 = 57946112 (0x3743000);             
            // 0x02709C1C: CSET w24, gt               | W24 = Pt.X > 1073741823 ? 1 : 0;        
            var val_1 = (Pt.X > 1073741823) ? 1 : 0;
            // 0x02709C20: CMP x19, x8                | STATE = COMPARE(Pt.Y, 0x3FFFFFFF)       
            // 0x02709C24: LDRB w9, [x28, #0x170]     | W9 = (bool)static_value_03743170;       
            // 0x02709C28: CSET w25, gt               | W25 = Pt.Y > 1073741823 ? 1 : 0;        
            var val_2 = (Pt.Y > 1073741823) ? 1 : 0;
            // 0x02709C2C: CMP x22, x8                | STATE = COMPARE(Pt.X, 0x3FFFFFFF)       
            // 0x02709C30: CSET w26, gt               | W26 = -Pt.X > 1073741823 ? 1 : 0;       
            var val_3 = ((-Pt.X) > 1073741823) ? 1 : 0;
            // 0x02709C34: CMP x23, x8                | STATE = COMPARE(Pt.Y, 0x3FFFFFFF)       
            // 0x02709C38: CSET w27, gt               | W27 = -Pt.Y > 1073741823 ? 1 : 0;       
            var val_4 = ((-Pt.Y) > 1073741823) ? 1 : 0;
            // 0x02709C3C: TBNZ w9, #0, #0x2709c58    | if (static_value_03743170 == true) goto label_0;
            // 0x02709C40: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
            // 0x02709C44: LDR x8, [x8, #0x120]       | X8 = 0x2B90C44;                         
            // 0x02709C48: LDR w0, [x8]               | W0 = 0x19D5;                            
            // 0x02709C4C: BL #0x2782188              | X0 = sub_2782188( ?? 0x19D5, ????);     
            // 0x02709C50: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02709C54: STRB w8, [x28, #0x170]     | static_value_03743170 = true;            //  dest_result_addr=57946480
            label_0:
            // 0x02709C58: LDRB w8, [x21]             | W8 = useFullRange;                      
            // 0x02709C5C: CBNZ w8, #0x2709c78        | if (useFullRange == true) goto label_1; 
            if(useFullRange == true)
            {
                goto label_1;
            }
            // 0x02709C60: ORR w8, w24, w25           | W8 = (Pt.X > 1073741823 ? 1 : 0 | Pt.Y > 1073741823 ? 1 : 0);
            var val_5 = val_1 | val_2;
            // 0x02709C64: ORR w8, w26, w8            | W8 = (-Pt.X > 1073741823 ? 1 : 0 | (Pt.X > 1073741823 ? 1 : 0 | Pt.Y > 1073741823 ? 1 : 0));
            val_5 = val_3 | val_5;
            // 0x02709C68: ORR w8, w27, w8            | W8 = (-Pt.Y > 1073741823 ? 1 : 0 | (-Pt.X > 1073741823 ? 1 : 0 | (Pt.X > 1073741823 ? 1 : 0 | Pt.Y >
            val_5 = val_4 | val_5;
            // 0x02709C6C: CBZ w8, #0x2709ca8         | if ((-Pt.Y > 1073741823 ? 1 : 0 | (-Pt.X > 1073741823 ? 1 : 0 | (Pt.X > 1073741823 ? 1 : 0 | Pt.Y > 1073741823 ? 1 : 0))) == 0) goto label_2;
            if(val_5 == 0)
            {
                goto label_2;
            }
            // 0x02709C70: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02709C74: STRB w8, [x21]             | useFullRange = true;                     //  dest_result_addr=1152921509606389280
            useFullRange = true;
            label_1:
            // 0x02709C78: ORR x11, xzr, #0x3fffffffffffffff | X11 = 4611686018427387903(0x3FFFFFFFFFFFFFFF);
            // 0x02709C7C: CMP x20, x11               | STATE = COMPARE(Pt.X, 0x3FFFFFFFFFFFFFFF)
            // 0x02709C80: CSET w8, gt                | W8 = Pt.X > 4611686018427387903 ? 1 : 0;
            var val_6 = (Pt.X > 4611686018427387903) ? 1 : 0;
            // 0x02709C84: CMP x19, x11               | STATE = COMPARE(Pt.Y, 0x3FFFFFFFFFFFFFFF)
            // 0x02709C88: CSET w9, gt                | W9 = Pt.Y > 4611686018427387903 ? 1 : 0;
            var val_7 = (Pt.Y > 4611686018427387903) ? 1 : 0;
            // 0x02709C8C: CMP x22, x11               | STATE = COMPARE(Pt.X, 0x3FFFFFFFFFFFFFFF)
            // 0x02709C90: CSET w10, gt               | W10 = -Pt.X > 4611686018427387903 ? 1 : 0;
            var val_8 = ((-Pt.X) > 4611686018427387903) ? 1 : 0;
            // 0x02709C94: CMP x23, x11               | STATE = COMPARE(Pt.Y, 0x3FFFFFFFFFFFFFFF)
            // 0x02709C98: B.GT #0x2709cc4            | if (-Pt.Y > 4611686018427387903) goto label_4;
            if((-Pt.Y) > 4611686018427387903)
            {
                goto label_4;
            }
            // 0x02709C9C: ORR w8, w8, w9             | W8 = (Pt.X > 4611686018427387903 ? 1 : 0 | Pt.Y > 4611686018427387903 ? 1 : 0);
            val_6 = val_6 | val_7;
            // 0x02709CA0: ORR w8, w10, w8            | W8 = (-Pt.X > 4611686018427387903 ? 1 : 0 | (Pt.X > 4611686018427387903 ? 1 : 0 | Pt.Y > 46116860184
            val_6 = val_8 | val_6;
            // 0x02709CA4: CBNZ w8, #0x2709cc4        | if ((-Pt.X > 4611686018427387903 ? 1 : 0 | (Pt.X > 4611686018427387903 ? 1 : 0 | Pt.Y > 4611686018427387903 ? 1 : 0)) != 0) goto label_4;
            if(val_6 != 0)
            {
                goto label_4;
            }
            label_2:
            // 0x02709CA8: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x02709CAC: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x02709CB0: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x02709CB4: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x02709CB8: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x02709CBC: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x02709CC0: RET                        |  return;                                
            return;
            label_4:
            // 0x02709CC4: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x02709CC8: LDR x8, [x8, #0xe00]       | X8 = 1152921504750084096;               
            // 0x02709CCC: LDR x0, [x8]               | X0 = typeof(Pathfinding.ClipperLib.ClipperException);
            System.Exception val_9 = null;
            // 0x02709CD0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.ClipperLib.ClipperException), ????);
            // 0x02709CD4: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x02709CD8: LDR x8, [x8, #0x570]       | X8 = (string**)(1152921509606332112)("Coordinate outside allowed range");
            // 0x02709CDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02709CE0: MOV x19, x0                | X19 = 1152921504750084096 (0x100000000889A000);//ML01
            // 0x02709CE4: LDR x1, [x8]               | X1 = "Coordinate outside allowed range";
            // 0x02709CE8: BL #0x1c32b48              | .ctor(message:  "Coordinate outside allowed range");
            val_9 = new System.Exception(message:  "Coordinate outside allowed range");
            // 0x02709CEC: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x02709CF0: LDR x8, [x8, #0xe28]       | X8 = 1152921509606332256;               
            // 0x02709CF4: MOV x0, x19                | X0 = 1152921504750084096 (0x100000000889A000);//ML01
            // 0x02709CF8: LDR x1, [x8]               | X1 = System.Void Pathfinding.ClipperLib.ClipperBase::RangeTest(Pathfinding.ClipperLib.IntPoint Pt, ref bool useFullRange);
            // 0x02709CFC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.ClipperLib.ClipperException), ????);
            // 0x02709D00: BL #0x2701d64              | X0 = ExecuteInternal();                 
            bool val_10 = ExecuteInternal();
        
        }
        //
        // Offset in libil2cpp.so: 0x02709D04 (40934660), len: 132  VirtAddr: 0x02709D04 RVA: 0x02709D04 token: 100663343 methodIndex: 20758 delegateWrapperIndex: 0 methodInvoker: 0
        private void InitEdge(Pathfinding.ClipperLib.TEdge e, Pathfinding.ClipperLib.TEdge eNext, Pathfinding.ClipperLib.TEdge ePrev, Pathfinding.ClipperLib.IntPoint pt)
        {
            //
            // Disasemble & Code
            // 0x02709D04: STP x24, x23, [sp, #-0x40]! | stack[1152921509606473536] = ???;  stack[1152921509606473544] = ???;  //  dest_result_addr=1152921509606473536 |  dest_result_addr=1152921509606473544
            // 0x02709D08: STP x22, x21, [sp, #0x10]  | stack[1152921509606473552] = ???;  stack[1152921509606473560] = ???;  //  dest_result_addr=1152921509606473552 |  dest_result_addr=1152921509606473560
            // 0x02709D0C: STP x20, x19, [sp, #0x20]  | stack[1152921509606473568] = ???;  stack[1152921509606473576] = ???;  //  dest_result_addr=1152921509606473568 |  dest_result_addr=1152921509606473576
            // 0x02709D10: STP x29, x30, [sp, #0x30]  | stack[1152921509606473584] = ???;  stack[1152921509606473592] = ???;  //  dest_result_addr=1152921509606473584 |  dest_result_addr=1152921509606473592
            // 0x02709D14: ADD x29, sp, #0x30         | X29 = (1152921509606473536 + 48) = 1152921509606473584 (0x100000012A003F70);
            // 0x02709D18: MOV x20, x5                | X20 = pt.Y;//m1                         
            // 0x02709D1C: MOV x21, x4                | X21 = pt.X;//m1                         
            // 0x02709D20: MOV x22, x3                | X22 = ePrev;//m1                        
            // 0x02709D24: MOV x23, x2                | X23 = eNext;//m1                        
            // 0x02709D28: MOV x19, x1                | X19 = e;//m1                            
            // 0x02709D2C: CBZ x19, #0x2709d3c        | if (e == null) goto label_0;            
            if(e == null)
            {
                goto label_0;
            }
            // 0x02709D30: STP x23, x22, [x19, #0x70] | e.Next = eNext;  e.Prev = ePrev;         //  dest_result_addr=0 |  dest_result_addr=0
            e.Next = eNext;
            e.Prev = ePrev;
            // 0x02709D34: STP x21, x20, [x19, #0x20] | e.Curr = pt;  mem2[0] = pt.Y;            //  dest_result_addr=0 |  dest_result_addr=0
            e.Curr = pt;
            mem2[0] = pt.Y;
            // 0x02709D38: B #0x2709d6c               |  goto label_1;                          
            goto label_1;
            label_0:
            // 0x02709D3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02709D40: ORR w8, wzr, #0x70         | W8 = 112(0x70);                         
            // 0x02709D44: STR x23, [x8]              | mem[112] = eNext;                        //  dest_result_addr=112
            mem[112] = eNext;
            // 0x02709D48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02709D4C: ORR w8, wzr, #0x78         | W8 = 120(0x78);                         
            // 0x02709D50: STR x22, [x8]              | mem[120] = ePrev;                        //  dest_result_addr=120
            mem[120] = ePrev;
            // 0x02709D54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02709D58: ORR w8, wzr, #0x20         | W8 = 32(0x20);                          
            // 0x02709D5C: MOVZ w9, #0x28             | W9 = 40 (0x28);//ML01                   
            // 0x02709D60: STR x21, [x8]              | mem[32] = pt.X;                          //  dest_result_addr=32
            mem[32] = pt.X;
            // 0x02709D64: STR x20, [x9]              | mem[40] = pt.Y;                          //  dest_result_addr=40
            mem[40] = pt.Y;
            // 0x02709D68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x02709D6C: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
            // 0x02709D70: STR w8, [x19, #0x6c]       | e.OutIdx = 0;                            //  dest_result_addr=0
            e.OutIdx = 0;
            // 0x02709D74: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x02709D78: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x02709D7C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x02709D80: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x02709D84: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x02709D88 (40934792), len: 160  VirtAddr: 0x02709D88 RVA: 0x02709D88 token: 100663344 methodIndex: 20759 delegateWrapperIndex: 0 methodInvoker: 0
        private void InitEdge2(Pathfinding.ClipperLib.TEdge e, Pathfinding.ClipperLib.PolyType polyType)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            Pathfinding.ClipperLib.TEdge val_2;
            // 0x02709D88: STP x22, x21, [sp, #-0x30]! | stack[1152921509606618320] = ???;  stack[1152921509606618328] = ???;  //  dest_result_addr=1152921509606618320 |  dest_result_addr=1152921509606618328
            // 0x02709D8C: STP x20, x19, [sp, #0x10]  | stack[1152921509606618336] = ???;  stack[1152921509606618344] = ???;  //  dest_result_addr=1152921509606618336 |  dest_result_addr=1152921509606618344
            // 0x02709D90: STP x29, x30, [sp, #0x20]  | stack[1152921509606618352] = ???;  stack[1152921509606618360] = ???;  //  dest_result_addr=1152921509606618352 |  dest_result_addr=1152921509606618360
            // 0x02709D94: ADD x29, sp, #0x20         | X29 = (1152921509606618320 + 32) = 1152921509606618352 (0x100000012A0274F0);
            // 0x02709D98: MOV w19, w2                | W19 = polyType;//m1                     
            // 0x02709D9C: MOV x20, x1                | X20 = e;//m1                            
            // 0x02709DA0: CBZ x20, #0x2709dac        | if (e == null) goto label_0;            
            if(e == null)
            {
                goto label_0;
            }
            // 0x02709DA4: LDR x21, [x20, #0x28]      | 
            // 0x02709DA8: B #0x2709dbc               |  goto label_1;                          
            goto label_1;
            label_0:
            // 0x02709DAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02709DB0: MOVZ w8, #0x28             | W8 = 40 (0x28);//ML01                   
            // 0x02709DB4: LDR x21, [x8]              | X21 = 0x3723290;                        
            val_1 = 57815696;
            // 0x02709DB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x02709DBC: LDR x22, [x20, #0x70]      | X22 = e.Next; //P2                      
            // 0x02709DC0: CBNZ x22, #0x2709dc8       | if (e.Next != null) goto label_2;       
            if(e.Next != null)
            {
                goto label_2;
            }
            // 0x02709DC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x02709DC8: LDR x10, [x22, #0x28]      | 
            // 0x02709DCC: LDP x8, x9, [x20, #0x20]   | X8 = e.Curr; //P2                        //  | 
            // 0x02709DD0: CMP x21, x10               | STATE = COMPARE(0x3723290, X10)         
            // 0x02709DD4: B.GE #0x2709df4            | if (val_1 >= X10) goto label_3;         
            if(val_1 >= X10)
            {
                goto label_3;
            }
            // 0x02709DD8: LDR x21, [x20, #0x70]      | X21 = e.Next; //P2                      
            val_2 = e.Next;
            // 0x02709DDC: STP x8, x9, [x20, #0x30]   | e.Top = e.Curr;  mem2[0] = ???;          //  dest_result_addr=0 |  dest_result_addr=0
            e.Top = e.Curr;
            mem2[0] = ???;
            // 0x02709DE0: CBNZ x21, #0x2709de8       | if (e.Next != null) goto label_4;       
            if(val_2 != null)
            {
                goto label_4;
            }
            // 0x02709DE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_4:
            // 0x02709DE8: LDP x8, x9, [x21, #0x20]   | X8 = e.Next.Curr; //P2                   //  | 
            // 0x02709DEC: STP x8, x9, [x20, #0x10]   | e.Bot = e.Next.Curr;  mem2[0] = ???;     //  dest_result_addr=0 |  dest_result_addr=0
            e.Bot = e.Next.Curr;
            mem2[0] = ???;
            // 0x02709DF0: B #0x2709e0c               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x02709DF4: LDR x21, [x20, #0x70]      | X21 = e.Next; //P2                      
            val_2 = e.Next;
            // 0x02709DF8: STP x8, x9, [x20, #0x10]   | e.Bot = e.Curr;  mem2[0] = ???;          //  dest_result_addr=0 |  dest_result_addr=0
            e.Bot = e.Curr;
            mem2[0] = ???;
            // 0x02709DFC: CBNZ x21, #0x2709e04       | if (e.Next != null) goto label_6;       
            if(val_2 != null)
            {
                goto label_6;
            }
            // 0x02709E00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_6:
            // 0x02709E04: LDP x8, x9, [x21, #0x20]   | X8 = e.Next.Curr; //P2                   //  | 
            // 0x02709E08: STP x8, x9, [x20, #0x30]   | e.Top = e.Next.Curr;  mem2[0] = ???;     //  dest_result_addr=0 |  dest_result_addr=0
            e.Top = e.Next.Curr;
            mem2[0] = ???;
            label_5:
            // 0x02709E0C: MOV x1, x20                | X1 = e;//m1                             
            // 0x02709E10: BL #0x2709e28              | this.SetDx(e:  e);                      
            this.SetDx(e:  e);
            // 0x02709E14: STR w19, [x20, #0x58]      | e.PolyTyp = polyType;                    //  dest_result_addr=0
            e.PolyTyp = polyType;
            // 0x02709E18: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x02709E1C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x02709E20: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x02709E24: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x02709F0C (40935180), len: 2892  VirtAddr: 0x02709F0C RVA: 0x02709F0C token: 100663345 methodIndex: 20760 delegateWrapperIndex: 0 methodInvoker: 0
        public bool AddPath(System.Collections.Generic.List<Pathfinding.ClipperLib.IntPoint> pg, Pathfinding.ClipperLib.PolyType polyType, bool Closed)
        {
            //
            // Disasemble & Code
            //  | 
            int val_57;
            //  | 
            var val_58;
            //  | 
            var val_59;
            //  | 
            var val_60;
            //  | 
            var val_61;
            //  | 
            var val_62;
            //  | 
            long val_63;
            //  | 
            long val_64;
            //  | 
            Pathfinding.ClipperLib.TEdge val_65;
            //  | 
            Pathfinding.ClipperLib.TEdge val_66;
            //  | 
            Pathfinding.ClipperLib.TEdge val_67;
            //  | 
            long val_68;
            //  | 
            Pathfinding.ClipperLib.TEdge val_69;
            //  | 
            var val_70;
            //  | 
            Pathfinding.ClipperLib.TEdge val_71;
            //  | 
            var val_72;
            //  | 
            var val_73;
            //  | 
            var val_74;
            //  | 
            var val_75;
            //  | 
            var val_76;
            // 0x02709F0C: STP x28, x27, [sp, #-0x60]! | stack[1152921509606893248] = ???;  stack[1152921509606893256] = ???;  //  dest_result_addr=1152921509606893248 |  dest_result_addr=1152921509606893256
            // 0x02709F10: STP x26, x25, [sp, #0x10]  | stack[1152921509606893264] = ???;  stack[1152921509606893272] = ???;  //  dest_result_addr=1152921509606893264 |  dest_result_addr=1152921509606893272
            // 0x02709F14: STP x24, x23, [sp, #0x20]  | stack[1152921509606893280] = ???;  stack[1152921509606893288] = ???;  //  dest_result_addr=1152921509606893280 |  dest_result_addr=1152921509606893288
            // 0x02709F18: STP x22, x21, [sp, #0x30]  | stack[1152921509606893296] = ???;  stack[1152921509606893304] = ???;  //  dest_result_addr=1152921509606893296 |  dest_result_addr=1152921509606893304
            // 0x02709F1C: STP x20, x19, [sp, #0x40]  | stack[1152921509606893312] = ???;  stack[1152921509606893320] = ???;  //  dest_result_addr=1152921509606893312 |  dest_result_addr=1152921509606893320
            // 0x02709F20: STP x29, x30, [sp, #0x50]  | stack[1152921509606893328] = ???;  stack[1152921509606893336] = ???;  //  dest_result_addr=1152921509606893328 |  dest_result_addr=1152921509606893336
            // 0x02709F24: ADD x29, sp, #0x50         | X29 = (1152921509606893248 + 80) = 1152921509606893328 (0x100000012A06A710);
            // 0x02709F28: SUB sp, sp, #0x30          | SP = (1152921509606893248 - 48) = 1152921509606893200 (0x100000012A06A690);
            // 0x02709F2C: ADRP x19, #0x3743000       | X19 = 57946112 (0x3743000);             
            // 0x02709F30: LDRB w8, [x19, #0x171]     | W8 = (bool)static_value_03743171;       
            // 0x02709F34: MOV w20, w3                | W20 = Closed;//m1                       
            // 0x02709F38: MOV w28, w2                | W28 = polyType;//m1                     
            // 0x02709F3C: MOV x23, x1                | X23 = pg;//m1                           
            // 0x02709F40: MOV x26, x0                | X26 = 1152921509606905344 (0x100000012A06D600);//ML01
            // 0x02709F44: TBNZ w8, #0, #0x2709f60    | if (static_value_03743171 == true) goto label_0;
            // 0x02709F48: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x02709F4C: LDR x8, [x8, #0xcb0]       | X8 = 0x2B90C38;                         
            // 0x02709F50: LDR w0, [x8]               | W0 = 0x19D2;                            
            // 0x02709F54: BL #0x2782188              | X0 = sub_2782188( ?? 0x19D2, ????);     
            // 0x02709F58: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02709F5C: STRB w8, [x19, #0x171]     | static_value_03743171 = true;            //  dest_result_addr=57946481
            label_0:
            // 0x02709F60: STR xzr, [sp, #0x28]       | stack[1152921509606893240] = 0x0;        //  dest_result_addr=1152921509606893240
            // 0x02709F64: AND w8, w20, #1            | W8 = (Closed & 1);                      
            bool val_1 = Closed;
            // 0x02709F68: TBZ w8, #0, #0x270aa04     | if ((Closed & 1) == false) goto label_1;
            if(val_1 == false)
            {
                goto label_1;
            }
            // 0x02709F6C: CBNZ x23, #0x2709f74       | if (pg != null) goto label_2;           
            if(pg != null)
            {
                goto label_2;
            }
            // 0x02709F70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x19D2, ????);     
            label_2:
            // 0x02709F74: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
            // 0x02709F78: LDR x8, [x8, #0x4b8]       | X8 = 1152921509606747040;               
            // 0x02709F7C: MOV x0, x23                | X0 = pg;//m1                            
            // 0x02709F80: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<Pathfinding.ClipperLib.IntPoint>::get_Count();
            // 0x02709F84: BL #0x25ae9f4              | X0 = pg.get_Count();                    
            int val_2 = pg.Count;
            // 0x02709F88: SUB w27, w0, #1            | W27 = (val_2 - 1);                      
            int val_3 = val_2 - 1;
            // 0x02709F8C: CMP w27, #1                | STATE = COMPARE((val_2 - 1), 0x1)       
            // 0x02709F90: B.LT #0x270a010            | if (val_3 < 1) goto label_3;            
            if(val_3 < 1)
            {
                goto label_3;
            }
            // 0x02709F94: ADRP x19, #0x35e0000       | X19 = 56492032 (0x35E0000);             
            // 0x02709F98: LDR x19, [x19, #0x390]     | X19 = 1152921509606748064;              
            // 0x02709F9C: MOV w21, w27               | W21 = (val_2 - 1);//m1                  
            val_57 = val_3;
            label_8:
            // 0x02709FA0: CBZ x23, #0x2709fc0        | if (pg == null) goto label_4;           
            if(pg == null)
            {
                goto label_4;
            }
            // 0x02709FA4: LDR x2, [x19]              | X2 = public Pathfinding.ClipperLib.IntPoint System.Collections.Generic.List<Pathfinding.ClipperLib.IntPoint>::get_Item(int index);
            // 0x02709FA8: MOV x0, x23                | X0 = pg;//m1                            
            // 0x02709FAC: MOV w1, w21                | W1 = (val_2 - 1);//m1                   
            // 0x02709FB0: BL #0x25ae9fc              | X0 = pg.get_Item(index:  val_57);       
            Pathfinding.ClipperLib.IntPoint val_4 = pg.Item[val_57];
            // 0x02709FB4: MOV x22, x0                | X22 = val_4.X;//m1                      
            val_58 = val_4.X;
            // 0x02709FB8: MOV x20, x1                | X20 = val_4.Y;//m1                      
            val_59 = val_4.Y;
            // 0x02709FBC: B #0x2709fe0               |  goto label_5;                          
            goto label_5;
            label_4:
            // 0x02709FC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            // 0x02709FC4: LDR x2, [x19]              | X2 = public Pathfinding.ClipperLib.IntPoint System.Collections.Generic.List<Pathfinding.ClipperLib.IntPoint>::get_Item(int index);
            // 0x02709FC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02709FCC: MOV w1, w21                | W1 = (val_2 - 1);//m1                   
            // 0x02709FD0: BL #0x25ae9fc              | X0 = 0.get_Item(index:  val_57);        
            Pathfinding.ClipperLib.IntPoint val_5 = 0.Item[val_57];
            // 0x02709FD4: MOV x22, x0                | X22 = val_5.X;//m1                      
            val_58 = val_5.X;
            // 0x02709FD8: MOV x20, x1                | X20 = val_5.Y;//m1                      
            val_59 = val_5.Y;
            // 0x02709FDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5.X, ????);    
            label_5:
            // 0x02709FE0: LDR x2, [x19]              | X2 = public Pathfinding.ClipperLib.IntPoint System.Collections.Generic.List<Pathfinding.ClipperLib.IntPoint>::get_Item(int index);
            // 0x02709FE4: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x02709FE8: MOV x0, x23                | X0 = pg;//m1                            
            // 0x02709FEC: BL #0x25ae9fc              | X0 = pg.get_Item(index:  0);            
            Pathfinding.ClipperLib.IntPoint val_6 = pg.Item[0];
            // 0x02709FF0: CMP x20, x1                | STATE = COMPARE(val_5.Y, val_6.Y)       
            // 0x02709FF4: B.NE #0x270a014            | if (val_59 != val_6.Y) goto label_9;    
            if(val_59 != val_6.Y)
            {
                goto label_9;
            }
            // 0x02709FF8: CMP x22, x0                | STATE = COMPARE(val_5.X, val_6.X)       
            // 0x02709FFC: B.NE #0x270a014            | if (val_58 != val_6.X) goto label_9;    
            if(val_58 != val_6.X)
            {
                goto label_9;
            }
            // 0x0270A000: SUB w21, w21, #1           | W21 = ((val_2 - 1) - 1);                
            val_57 = val_57 - 1;
            // 0x0270A004: CMP w21, #1                | STATE = COMPARE(((val_2 - 1) - 1), 0x1) 
            // 0x0270A008: B.GE #0x2709fa0            | if (val_57 >= 1) goto label_8;          
            if(val_57 >= 1)
            {
                goto label_8;
            }
            // 0x0270A00C: B #0x270a014               |  goto label_9;                          
            goto label_9;
            label_3:
            // 0x0270A010: MOV w21, w27               | W21 = (val_2 - 1);//m1                  
            val_57 = val_3;
            label_9:
            // 0x0270A014: ADRP x19, #0x35e0000       | X19 = 56492032 (0x35E0000);             
            // 0x0270A018: LDR x19, [x19, #0x390]     | X19 = 1152921509606748064;              
            val_60 = 1152921509606748064;
            // 0x0270A01C: SUB w24, w21, #1           | W24 = ((val_2 - 1) - 1);                
            int val_7 = val_57 - 1;
            label_14:
            // 0x0270A020: ADD w20, w24, #1           | W20 = (((val_2 - 1) - 1) + 1);          
            int val_8 = val_7 + 1;
            // 0x0270A024: CMP w20, #1                | STATE = COMPARE((((val_2 - 1) - 1) + 1), 0x1)
            // 0x0270A028: B.LT #0x270a43c            | if (val_8 < 1) goto label_88;           
            if(val_8 < 1)
            {
                goto label_88;
            }
            // 0x0270A02C: CBZ x23, #0x270a04c        | if (pg == null) goto label_11;          
            if(pg == null)
            {
                goto label_11;
            }
            // 0x0270A030: LDR x2, [x19]              | X2 = public Pathfinding.ClipperLib.IntPoint System.Collections.Generic.List<Pathfinding.ClipperLib.IntPoint>::get_Item(int index);
            // 0x0270A034: MOV x0, x23                | X0 = pg;//m1                            
            // 0x0270A038: MOV w1, w20                | W1 = (((val_2 - 1) - 1) + 1);//m1       
            // 0x0270A03C: BL #0x25ae9fc              | X0 = pg.get_Item(index:  val_8);        
            Pathfinding.ClipperLib.IntPoint val_9 = pg.Item[val_8];
            // 0x0270A040: MOV x21, x0                | X21 = val_9.X;//m1                      
            val_61 = val_9.X;
            // 0x0270A044: MOV x20, x1                | X20 = val_9.Y;//m1                      
            val_62 = val_9.Y;
            // 0x0270A048: B #0x270a06c               |  goto label_12;                         
            goto label_12;
            label_11:
            // 0x0270A04C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            // 0x0270A050: LDR x2, [x19]              | X2 = public Pathfinding.ClipperLib.IntPoint System.Collections.Generic.List<Pathfinding.ClipperLib.IntPoint>::get_Item(int index);
            // 0x0270A054: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0270A058: MOV w1, w20                | W1 = (((val_2 - 1) - 1) + 1);//m1       
            // 0x0270A05C: BL #0x25ae9fc              | X0 = 0.get_Item(index:  val_8);         
            Pathfinding.ClipperLib.IntPoint val_10 = 0.Item[val_8];
            // 0x0270A060: MOV x21, x0                | X21 = val_10.X;//m1                     
            val_61 = val_10.X;
            // 0x0270A064: MOV x20, x1                | X20 = val_10.Y;//m1                     
            val_62 = val_10.Y;
            // 0x0270A068: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10.X, ????);   
            label_12:
            // 0x0270A06C: LDR x2, [x19]              | X2 = public Pathfinding.ClipperLib.IntPoint System.Collections.Generic.List<Pathfinding.ClipperLib.IntPoint>::get_Item(int index);
            // 0x0270A070: MOV x0, x23                | X0 = pg;//m1                            
            // 0x0270A074: MOV w1, w24                | W1 = ((val_2 - 1) - 1);//m1             
            // 0x0270A078: BL #0x25ae9fc              | X0 = pg.get_Item(index:  val_7);        
            Pathfinding.ClipperLib.IntPoint val_11 = pg.Item[val_7];
            // 0x0270A07C: SUB w24, w24, #1           | W24 = (((val_2 - 1) - 1) - 1);          
            val_7 = val_7 - 1;
            // 0x0270A080: CMP x20, x1                | STATE = COMPARE(val_10.Y, val_11.Y)     
            // 0x0270A084: B.NE #0x270a090            | if (val_62 != val_11.Y) goto label_13;  
            if(val_62 != val_11.Y)
            {
                goto label_13;
            }
            // 0x0270A088: CMP x21, x0                | STATE = COMPARE(val_10.X, val_11.X)     
            // 0x0270A08C: B.EQ #0x270a020            | if (val_61 == val_11.X) goto label_14;  
            if(val_61 == val_11.X)
            {
                goto label_14;
            }
            label_13:
            // 0x0270A090: ADD w25, w24, #2           | W25 = ((((val_2 - 1) - 1) - 1) + 2);    
            int val_12 = val_7 + 2;
            // 0x0270A094: CMP w25, #2                | STATE = COMPARE(((((val_2 - 1) - 1) - 1) + 2), 0x2)
            // 0x0270A098: B.LT #0x270a43c            | if (val_12 < 2) goto label_88;          
            if(val_12 < 2)
            {
                goto label_88;
            }
            // 0x0270A09C: STP w28, w27, [sp, #0x20]  | stack[1152921509606893232] = polyType;  stack[1152921509606893236] = (val_2 - 1);  //  dest_result_addr=1152921509606893232 |  dest_result_addr=1152921509606893236
            // 0x0270A0A0: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x0270A0A4: LDR x8, [x8, #0x350]       | X8 = 1152921504616644608;               
            // 0x0270A0A8: MOV x28, x26               | X28 = 1152921509606905344 (0x100000012A06D600);//ML01
            // 0x0270A0AC: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge> val_14 = null;
            // 0x0270A0B0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x0270A0B4: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x0270A0B8: LDR x8, [x8, #0x30]        | X8 = 1152921509606749088;               
            // 0x0270A0BC: ADD w1, w24, #3            | W1 = ((((val_2 - 1) - 1) - 1) + 3);     
            int val_13 = val_7 + 3;
            // 0x0270A0C0: MOV x21, x0                | X21 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x0270A0C4: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>::.ctor(int capacity);
            // 0x0270A0C8: BL #0x25e9720              | .ctor(capacity:  int val_13 = val_7 + 3);
            val_14 = new System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>(capacity:  val_13);
            // 0x0270A0CC: ADRP x26, #0x35c3000       | X26 = 56373248 (0x35C3000);             
            // 0x0270A0D0: ADRP x27, #0x35c9000       | X27 = 56397824 (0x35C9000);             
            // 0x0270A0D4: LDR x26, [x26, #0x6b0]     | X26 = 1152921504749604864;              
            // 0x0270A0D8: LDR x27, [x27, #0x510]     | X27 = 1152921509606750112;              
            // 0x0270A0DC: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            var val_57 = 0;
            label_17:
            // 0x0270A0E0: LDR x0, [x26]              | X0 = typeof(Pathfinding.ClipperLib.TEdge);
            object val_15 = null;
            // 0x0270A0E4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.ClipperLib.TEdge), ????);
            // 0x0270A0E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0270A0EC: MOV x20, x0                | X20 = 1152921504749604864 (0x1000000008825000);//ML01
            // 0x0270A0F0: BL #0x16f59f0              | .ctor();                                
            val_15 = new System.Object();
            // 0x0270A0F4: CBNZ x21, #0x270a0fc       | if ( != 0) goto label_16;               
            if(null != 0)
            {
                goto label_16;
            }
            // 0x0270A0F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_16:
            // 0x0270A0FC: LDR x2, [x27]              | X2 = public System.Void System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>::Add(Pathfinding.ClipperLib.TEdge item);
            // 0x0270A100: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x0270A104: MOV x1, x20                | X1 = 1152921504749604864 (0x1000000008825000);//ML01
            // 0x0270A108: BL #0x25ea480              | Add(item:  val_15);                     
            Add(item:  val_15);
            // 0x0270A10C: ADD w22, w22, #1           | W22 = (0 + 1);                          
            val_57 = val_57 + 1;
            // 0x0270A110: CMP w22, w25               | STATE = COMPARE((0 + 1), ((((val_2 - 1) - 1) - 1) + 2))
            // 0x0270A114: B.LE #0x270a0e0            | if (0 <= val_12) goto label_17;         
            if(val_57 <= val_12)
            {
                goto label_17;
            }
            // 0x0270A118: CBNZ x21, #0x270a120       | if ( != 0) goto label_18;               
            if(null != 0)
            {
                goto label_18;
            }
            // 0x0270A11C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.List<T>), ????);
            label_18:
            // 0x0270A120: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x0270A124: LDR x8, [x8, #0xc68]       | X8 = 1152921509606751136;               
            // 0x0270A128: LDR x2, [x8]               | X2 = public Pathfinding.ClipperLib.TEdge System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>::get_Item(int index);
            // 0x0270A12C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x0270A130: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x0270A134: BL #0x25ed734              | X0 = get_Item(index:  1);               
            Pathfinding.ClipperLib.TEdge val_16 = Item[1];
            // 0x0270A138: MOV x22, x0                | X22 = val_16;//m1                       
            // 0x0270A13C: CBNZ x23, #0x270a144       | if (pg != null) goto label_19;          
            if(pg != null)
            {
                goto label_19;
            }
            // 0x0270A140: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_19:
            // 0x0270A144: LDR x2, [x19]              | X2 = public Pathfinding.ClipperLib.IntPoint System.Collections.Generic.List<Pathfinding.ClipperLib.IntPoint>::get_Item(int index);
            // 0x0270A148: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x0270A14C: MOV x0, x23                | X0 = pg;//m1                            
            // 0x0270A150: BL #0x25ae9fc              | X0 = pg.get_Item(index:  1);            
            Pathfinding.ClipperLib.IntPoint val_17 = pg.Item[1];
            // 0x0270A154: MOV x20, x0                | X20 = val_17.X;//m1                     
            // 0x0270A158: MOV x26, x1                | X26 = val_17.Y;//m1                     
            // 0x0270A15C: CBNZ x22, #0x270a164       | if (val_16 != null) goto label_20;      
            if(val_16 != null)
            {
                goto label_20;
            }
            // 0x0270A160: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17.X, ????);   
            label_20:
            // 0x0270A164: STP x20, x26, [x22, #0x20] | val_16.Curr = val_17;  mem2[0] = val_17.Y;  //  dest_result_addr=0 |  dest_result_addr=0
            val_16.Curr = val_17;
            mem2[0] = val_17.Y;
            // 0x0270A168: CBNZ x23, #0x270a170       | if (pg != null) goto label_21;          
            if(pg != null)
            {
                goto label_21;
            }
            // 0x0270A16C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17.X, ????);   
            label_21:
            // 0x0270A170: LDR x2, [x19]              | X2 = public Pathfinding.ClipperLib.IntPoint System.Collections.Generic.List<Pathfinding.ClipperLib.IntPoint>::get_Item(int index);
            // 0x0270A174: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x0270A178: MOV x0, x23                | X0 = pg;//m1                            
            // 0x0270A17C: BL #0x25ae9fc              | X0 = pg.get_Item(index:  0);            
            Pathfinding.ClipperLib.IntPoint val_18 = pg.Item[0];
            // 0x0270A180: MOV x2, x0                 | X2 = val_18.X;//m1                      
            // 0x0270A184: MOV x3, x1                 | X3 = val_18.Y;//m1                      
            // 0x0270A188: MOV x0, x28                | X0 = 1152921509606905344 (0x100000012A06D600);//ML01
            // 0x0270A18C: ADD x22, x0, #0x28         | X22 = this.m_UseFullRange;//AP2 res_addr=1152921509606905384
            // 0x0270A190: MOV x1, x2                 | X1 = val_18.X;//m1                      
            // 0x0270A194: MOV x2, x3                 | X2 = val_18.Y;//m1                      
            // 0x0270A198: MOV x3, x22                | X3 = this.m_UseFullRange;//m1           
            bool val_19 = this.m_UseFullRange;
            // 0x0270A19C: MOV x20, x0                | X20 = 1152921509606905344 (0x100000012A06D600);//ML01
            // 0x0270A1A0: BL #0x2709be0              | this.RangeTest(Pt:  new Pathfinding.ClipperLib.IntPoint() {X = val_18.X, Y = val_18.Y}, useFullRange: ref  bool val_19 = this.m_UseFullRange);
            this.RangeTest(Pt:  new Pathfinding.ClipperLib.IntPoint() {X = val_18.X, Y = val_18.Y}, useFullRange: ref  val_19);
            // 0x0270A1A4: CBNZ x23, #0x270a1ac       | if (pg != null) goto label_22;          
            if(pg != null)
            {
                goto label_22;
            }
            // 0x0270A1A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_22:
            // 0x0270A1AC: LDR x2, [x19]              | X2 = public Pathfinding.ClipperLib.IntPoint System.Collections.Generic.List<Pathfinding.ClipperLib.IntPoint>::get_Item(int index);
            // 0x0270A1B0: MOV x0, x23                | X0 = pg;//m1                            
            // 0x0270A1B4: MOV w1, w25                | W1 = ((((val_2 - 1) - 1) - 1) + 2);//m1 
            // 0x0270A1B8: BL #0x25ae9fc              | X0 = pg.get_Item(index:  val_12);       
            Pathfinding.ClipperLib.IntPoint val_20 = pg.Item[val_12];
            // 0x0270A1BC: MOV x2, x0                 | X2 = val_20.X;//m1                      
            // 0x0270A1C0: MOV x3, x1                 | X3 = val_20.Y;//m1                      
            // 0x0270A1C4: MOV x0, x20                | X0 = 1152921509606905344 (0x100000012A06D600);//ML01
            // 0x0270A1C8: MOV x1, x2                 | X1 = val_20.X;//m1                      
            // 0x0270A1CC: MOV x2, x3                 | X2 = val_20.Y;//m1                      
            // 0x0270A1D0: MOV x3, x22                | X3 = this.m_UseFullRange;//m1           
            bool val_21 = this.m_UseFullRange;
            // 0x0270A1D4: BL #0x2709be0              | this.RangeTest(Pt:  new Pathfinding.ClipperLib.IntPoint() {X = val_20.X, Y = val_20.Y}, useFullRange: ref  bool val_21 = this.m_UseFullRange);
            this.RangeTest(Pt:  new Pathfinding.ClipperLib.IntPoint() {X = val_20.X, Y = val_20.Y}, useFullRange: ref  val_21);
            // 0x0270A1D8: CBNZ x21, #0x270a1e0       | if ( != 0) goto label_23;               
            if(null != 0)
            {
                goto label_23;
            }
            // 0x0270A1DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_23:
            // 0x0270A1E0: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x0270A1E4: LDR x8, [x8, #0xc68]       | X8 = 1152921509606751136;               
            // 0x0270A1E8: LDR x2, [x8]               | X2 = public Pathfinding.ClipperLib.TEdge System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>::get_Item(int index);
            // 0x0270A1EC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x0270A1F0: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x0270A1F4: BL #0x25ed734              | X0 = get_Item(index:  0);               
            Pathfinding.ClipperLib.TEdge val_22 = Item[0];
            // 0x0270A1F8: MOV x26, x0                | X26 = val_22;//m1                       
            // 0x0270A1FC: CBNZ x21, #0x270a204       | if ( != 0) goto label_24;               
            if(null != 0)
            {
                goto label_24;
            }
            // 0x0270A200: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
            label_24:
            // 0x0270A204: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x0270A208: LDR x8, [x8, #0xc68]       | X8 = 1152921509606751136;               
            // 0x0270A20C: LDR x2, [x8]               | X2 = public Pathfinding.ClipperLib.TEdge System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>::get_Item(int index);
            // 0x0270A210: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x0270A214: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x0270A218: BL #0x25ed734              | X0 = get_Item(index:  1);               
            Pathfinding.ClipperLib.TEdge val_23 = Item[1];
            // 0x0270A21C: MOV x27, x0                | X27 = val_23;//m1                       
            // 0x0270A220: CBNZ x21, #0x270a228       | if ( != 0) goto label_25;               
            if(null != 0)
            {
                goto label_25;
            }
            // 0x0270A224: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_25:
            // 0x0270A228: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x0270A22C: LDR x8, [x8, #0xc68]       | X8 = 1152921509606751136;               
            // 0x0270A230: LDR x2, [x8]               | X2 = public Pathfinding.ClipperLib.TEdge System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>::get_Item(int index);
            // 0x0270A234: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x0270A238: MOV w1, w25                | W1 = ((((val_2 - 1) - 1) - 1) + 2);//m1 
            // 0x0270A23C: BL #0x25ed734              | X0 = get_Item(index:  val_12);          
            Pathfinding.ClipperLib.TEdge val_24 = Item[val_12];
            // 0x0270A240: MOV x28, x0                | X28 = val_24;//m1                       
            // 0x0270A244: CBNZ x23, #0x270a24c       | if (pg != null) goto label_26;          
            if(pg != null)
            {
                goto label_26;
            }
            // 0x0270A248: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
            label_26:
            // 0x0270A24C: LDR x2, [x19]              | X2 = public Pathfinding.ClipperLib.IntPoint System.Collections.Generic.List<Pathfinding.ClipperLib.IntPoint>::get_Item(int index);
            // 0x0270A250: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x0270A254: MOV x0, x23                | X0 = pg;//m1                            
            // 0x0270A258: BL #0x25ae9fc              | X0 = pg.get_Item(index:  0);            
            Pathfinding.ClipperLib.IntPoint val_25 = pg.Item[0];
            // 0x0270A25C: MOV x5, x1                 | X5 = val_25.Y;//m1                      
            // 0x0270A260: MOV x1, x26                | X1 = val_22;//m1                        
            // 0x0270A264: MOV x2, x27                | X2 = val_23;//m1                        
            // 0x0270A268: MOV x3, x28                | X3 = val_24;//m1                        
            // 0x0270A26C: MOV x4, x0                 | X4 = val_25.X;//m1                      
            // 0x0270A270: BL #0x2709d04              | val_25.X.InitEdge(e:  val_22, eNext:  val_23, ePrev:  val_24, pt:  new Pathfinding.ClipperLib.IntPoint() {X = val_25.X, Y = val_25.Y});
            val_25.X.InitEdge(e:  val_22, eNext:  val_23, ePrev:  val_24, pt:  new Pathfinding.ClipperLib.IntPoint() {X = val_25.X, Y = val_25.Y});
            // 0x0270A274: CBNZ x21, #0x270a27c       | if ( != 0) goto label_27;               
            if(null != 0)
            {
                goto label_27;
            }
            // 0x0270A278: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25.X, ????);   
            label_27:
            // 0x0270A27C: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x0270A280: LDR x8, [x8, #0xc68]       | X8 = 1152921509606751136;               
            // 0x0270A284: LDR x2, [x8]               | X2 = public Pathfinding.ClipperLib.TEdge System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>::get_Item(int index);
            // 0x0270A288: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x0270A28C: MOV w1, w25                | W1 = ((((val_2 - 1) - 1) - 1) + 2);//m1 
            // 0x0270A290: BL #0x25ed734              | X0 = get_Item(index:  val_12);          
            Pathfinding.ClipperLib.TEdge val_26 = Item[val_12];
            // 0x0270A294: MOV x26, x0                | X26 = val_26;//m1                       
            // 0x0270A298: CBNZ x21, #0x270a2a0       | if ( != 0) goto label_28;               
            if(null != 0)
            {
                goto label_28;
            }
            // 0x0270A29C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
            label_28:
            // 0x0270A2A0: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x0270A2A4: LDR x8, [x8, #0xc68]       | X8 = 1152921509606751136;               
            // 0x0270A2A8: LDR x2, [x8]               | X2 = public Pathfinding.ClipperLib.TEdge System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>::get_Item(int index);
            // 0x0270A2AC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x0270A2B0: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x0270A2B4: BL #0x25ed734              | X0 = get_Item(index:  0);               
            Pathfinding.ClipperLib.TEdge val_27 = Item[0];
            // 0x0270A2B8: MOV x27, x0                | X27 = val_27;//m1                       
            // 0x0270A2BC: CBNZ x21, #0x270a2c4       | if ( != 0) goto label_29;               
            if(null != 0)
            {
                goto label_29;
            }
            // 0x0270A2C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
            label_29:
            // 0x0270A2C4: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x0270A2C8: LDR x8, [x8, #0xc68]       | X8 = 1152921509606751136;               
            // 0x0270A2CC: ADD w24, w24, #1           | W24 = ((((val_2 - 1) - 1) - 1) + 1);    
            val_7 = val_7 + 1;
            // 0x0270A2D0: LDR x2, [x8]               | X2 = public Pathfinding.ClipperLib.TEdge System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>::get_Item(int index);
            // 0x0270A2D4: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x0270A2D8: MOV w1, w24                | W1 = ((((val_2 - 1) - 1) - 1) + 1);//m1 
            // 0x0270A2DC: BL #0x25ed734              | X0 = get_Item(index:  val_7);           
            Pathfinding.ClipperLib.TEdge val_28 = Item[val_7];
            // 0x0270A2E0: MOV x28, x0                | X28 = val_28;//m1                       
            // 0x0270A2E4: CBNZ x23, #0x270a2ec       | if (pg != null) goto label_30;          
            if(pg != null)
            {
                goto label_30;
            }
            // 0x0270A2E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
            label_30:
            // 0x0270A2EC: LDR x2, [x19]              | X2 = public Pathfinding.ClipperLib.IntPoint System.Collections.Generic.List<Pathfinding.ClipperLib.IntPoint>::get_Item(int index);
            // 0x0270A2F0: MOV x0, x23                | X0 = pg;//m1                            
            // 0x0270A2F4: MOV w1, w25                | W1 = ((((val_2 - 1) - 1) - 1) + 2);//m1 
            // 0x0270A2F8: BL #0x25ae9fc              | X0 = pg.get_Item(index:  val_12);       
            Pathfinding.ClipperLib.IntPoint val_29 = pg.Item[val_12];
            // 0x0270A2FC: MOV x5, x1                 | X5 = val_29.Y;//m1                      
            // 0x0270A300: MOV x1, x26                | X1 = val_26;//m1                        
            // 0x0270A304: MOV x2, x27                | X2 = val_27;//m1                        
            // 0x0270A308: MOV x3, x28                | X3 = val_28;//m1                        
            // 0x0270A30C: MOV x4, x0                 | X4 = val_29.X;//m1                      
            // 0x0270A310: BL #0x2709d04              | val_29.X.InitEdge(e:  val_26, eNext:  val_27, ePrev:  val_28, pt:  new Pathfinding.ClipperLib.IntPoint() {X = val_29.X, Y = val_29.Y});
            val_29.X.InitEdge(e:  val_26, eNext:  val_27, ePrev:  val_28, pt:  new Pathfinding.ClipperLib.IntPoint() {X = val_29.X, Y = val_29.Y});
            // 0x0270A314: MOV x28, x20               | X28 = 1152921509606905344 (0x100000012A06D600);//ML01
            label_37:
            // 0x0270A318: CMP w24, #1                | STATE = COMPARE(((((val_2 - 1) - 1) - 1) + 1), 0x1)
            // 0x0270A31C: B.LT #0x270a464            | if (val_7 < 1) goto label_31;           
            if(val_7 < 1)
            {
                goto label_31;
            }
            // 0x0270A320: CBNZ x23, #0x270a328       | if (pg != null) goto label_32;          
            if(pg != null)
            {
                goto label_32;
            }
            // 0x0270A324: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_29.X, ????);   
            label_32:
            // 0x0270A328: LDR x2, [x19]              | X2 = public Pathfinding.ClipperLib.IntPoint System.Collections.Generic.List<Pathfinding.ClipperLib.IntPoint>::get_Item(int index);
            // 0x0270A32C: MOV x0, x23                | X0 = pg;//m1                            
            // 0x0270A330: MOV w1, w24                | W1 = ((((val_2 - 1) - 1) - 1) + 1);//m1 
            // 0x0270A334: BL #0x25ae9fc              | X0 = pg.get_Item(index:  val_7);        
            Pathfinding.ClipperLib.IntPoint val_30 = pg.Item[val_7];
            // 0x0270A338: MOV x2, x0                 | X2 = val_30.X;//m1                      
            // 0x0270A33C: MOV x3, x1                 | X3 = val_30.Y;//m1                      
            // 0x0270A340: MOV x0, x28                | X0 = 1152921509606905344 (0x100000012A06D600);//ML01
            // 0x0270A344: MOV x1, x2                 | X1 = val_30.X;//m1                      
            // 0x0270A348: MOV x2, x3                 | X2 = val_30.Y;//m1                      
            // 0x0270A34C: MOV x3, x22                | X3 = this.m_UseFullRange;//m1           
            bool val_31 = this.m_UseFullRange;
            // 0x0270A350: BL #0x2709be0              | this.RangeTest(Pt:  new Pathfinding.ClipperLib.IntPoint() {X = val_30.X, Y = val_30.Y}, useFullRange: ref  bool val_31 = this.m_UseFullRange);
            this.RangeTest(Pt:  new Pathfinding.ClipperLib.IntPoint() {X = val_30.X, Y = val_30.Y}, useFullRange: ref  val_31);
            // 0x0270A354: CBNZ x21, #0x270a35c       | if ( != 0) goto label_33;               
            if(null != 0)
            {
                goto label_33;
            }
            // 0x0270A358: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_33:
            // 0x0270A35C: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x0270A360: LDR x8, [x8, #0xc68]       | X8 = 1152921509606751136;               
            // 0x0270A364: LDR x2, [x8]               | X2 = public Pathfinding.ClipperLib.TEdge System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>::get_Item(int index);
            // 0x0270A368: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x0270A36C: MOV w1, w24                | W1 = ((((val_2 - 1) - 1) - 1) + 1);//m1 
            // 0x0270A370: BL #0x25ed734              | X0 = get_Item(index:  val_7);           
            Pathfinding.ClipperLib.TEdge val_32 = Item[val_7];
            // 0x0270A374: MOV x25, x0                | X25 = val_32;//m1                       
            // 0x0270A378: CBNZ x21, #0x270a380       | if ( != 0) goto label_34;               
            if(null != 0)
            {
                goto label_34;
            }
            // 0x0270A37C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
            label_34:
            // 0x0270A380: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x0270A384: LDR x8, [x8, #0xc68]       | X8 = 1152921509606751136;               
            // 0x0270A388: ADD w20, w24, #1           | W20 = (((((val_2 - 1) - 1) - 1) + 1) + 1);
            int val_33 = val_7 + 1;
            // 0x0270A38C: LDR x2, [x8]               | X2 = public Pathfinding.ClipperLib.TEdge System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>::get_Item(int index);
            // 0x0270A390: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x0270A394: MOV w1, w20                | W1 = (((((val_2 - 1) - 1) - 1) + 1) + 1);//m1
            // 0x0270A398: BL #0x25ed734              | X0 = get_Item(index:  val_33);          
            Pathfinding.ClipperLib.TEdge val_34 = Item[val_33];
            // 0x0270A39C: MOV x26, x0                | X26 = val_34;//m1                       
            // 0x0270A3A0: CBNZ x21, #0x270a3a8       | if ( != 0) goto label_35;               
            if(null != 0)
            {
                goto label_35;
            }
            // 0x0270A3A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_34, ????);     
            label_35:
            // 0x0270A3A8: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x0270A3AC: LDR x8, [x8, #0xc68]       | X8 = 1152921509606751136;               
            // 0x0270A3B0: SUB w20, w20, #2           | W20 = ((((((val_2 - 1) - 1) - 1) + 1) + 1) - 2);
            val_33 = val_33 - 2;
            // 0x0270A3B4: LDR x2, [x8]               | X2 = public Pathfinding.ClipperLib.TEdge System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>::get_Item(int index);
            // 0x0270A3B8: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x0270A3BC: MOV w1, w20                | W1 = ((((((val_2 - 1) - 1) - 1) + 1) + 1) - 2);//m1
            // 0x0270A3C0: BL #0x25ed734              | X0 = get_Item(index:  val_33);          
            Pathfinding.ClipperLib.TEdge val_35 = Item[val_33];
            // 0x0270A3C4: MOV x27, x0                | X27 = val_35;//m1                       
            // 0x0270A3C8: CBNZ x23, #0x270a3d0       | if (pg != null) goto label_36;          
            if(pg != null)
            {
                goto label_36;
            }
            // 0x0270A3CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
            label_36:
            // 0x0270A3D0: LDR x2, [x19]              | X2 = public Pathfinding.ClipperLib.IntPoint System.Collections.Generic.List<Pathfinding.ClipperLib.IntPoint>::get_Item(int index);
            // 0x0270A3D4: ADD w20, w20, #1           | W20 = (((((((val_2 - 1) - 1) - 1) + 1) + 1) - 2) + 1);
            val_33 = val_33 + 1;
            // 0x0270A3D8: MOV x0, x23                | X0 = pg;//m1                            
            // 0x0270A3DC: MOV w1, w20                | W1 = (((((((val_2 - 1) - 1) - 1) + 1) + 1) - 2) + 1);//m1
            // 0x0270A3E0: BL #0x25ae9fc              | X0 = pg.get_Item(index:  val_33);       
            Pathfinding.ClipperLib.IntPoint val_36 = pg.Item[val_33];
            // 0x0270A3E4: MOV x5, x1                 | X5 = val_36.Y;//m1                      
            // 0x0270A3E8: SUB w24, w20, #1           | W24 = ((((((((val_2 - 1) - 1) - 1) + 1) + 1) - 2) + 1) - 1);
            val_7 = val_33 - 1;
            // 0x0270A3EC: MOV x1, x25                | X1 = val_32;//m1                        
            // 0x0270A3F0: MOV x2, x26                | X2 = val_34;//m1                        
            // 0x0270A3F4: MOV x3, x27                | X3 = val_35;//m1                        
            // 0x0270A3F8: MOV x4, x0                 | X4 = val_36.X;//m1                      
            // 0x0270A3FC: BL #0x2709d04              | val_36.X.InitEdge(e:  val_32, eNext:  val_34, ePrev:  val_35, pt:  new Pathfinding.ClipperLib.IntPoint() {X = val_36.X, Y = val_36.Y});
            val_36.X.InitEdge(e:  val_32, eNext:  val_34, ePrev:  val_35, pt:  new Pathfinding.ClipperLib.IntPoint() {X = val_36.X, Y = val_36.Y});
            // 0x0270A400: B #0x270a318               |  goto label_37;                         
            goto label_37;
            label_142:
            // 0x0270A404: MOV x19, x0                | X19 = val_36.X;//m1                     
            val_63 = val_36.X;
            // 0x0270A408: CMP w1, #1                 | STATE = COMPARE(val_32, 0x1)            
            // 0x0270A40C: B.NE #0x270aa4c            | if (val_32 != 0x1) goto label_38;       
            if(val_32 != 1)
            {
                goto label_38;
            }
            // 0x0270A410: MOV x0, x19                | X0 = val_36.X;//m1                      
            // 0x0270A414: BL #0x981060               | X0 = sub_981060( ?? val_36.X, ????);    
            // 0x0270A418: MOV x19, x0                | X19 = val_36.X;//m1                     
            val_64 = val_63;
            // 0x0270A41C: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
            // 0x0270A420: LDR x8, [x19]              | X8 = val_36.X;                          
            // 0x0270A424: LDR x9, [x9, #0xf90]       | X9 = 1152921504606900224;               
            // 0x0270A428: LDR x1, [x8]               | X1 = val_36.X;                          
            // 0x0270A42C: LDR x0, [x9]               | X0 = typeof(System.Object);             
            // 0x0270A430: BL #0x2774c70              | X0 = sub_2774C70( ?? typeof(System.Object), ????);
            // 0x0270A434: TBZ w0, #0, #0x270a9e4     | if ((typeof(System.Object) & 0x1) == 0) goto label_39;
            if((null & 1) == 0)
            {
                goto label_39;
            }
            // 0x0270A438: BL #0x980920               | X0 = sub_980920( ?? typeof(System.Object), ????);
            label_88:
            // 0x0270A43C: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            label_132:
            // 0x0270A440: MOV w0, w21                | W0 = 0 (0x0);//ML01                     
            // 0x0270A444: SUB sp, x29, #0x50         | SP = (1152921509606893328 - 80) = 1152921509606893248 (0x100000012A06A6C0);
            // 0x0270A448: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x0270A44C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x0270A450: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x0270A454: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x0270A458: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x0270A45C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x0270A460: RET                        |  return (System.Boolean)false;          
            return (bool)0;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_31:
            // 0x0270A464: CBNZ x21, #0x270a46c       | if ( != 0) goto label_40;               
            if(null != 0)
            {
                goto label_40;
            }
            // 0x0270A468: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_29.X, ????);   
            label_40:
            // 0x0270A46C: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x0270A470: LDR x8, [x8, #0xc68]       | X8 = 1152921509606751136;               
            // 0x0270A474: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x0270A478: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x0270A47C: LDR x2, [x8]               | X2 = public Pathfinding.ClipperLib.TEdge System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>::get_Item(int index);
            // 0x0270A480: BL #0x25ed734              | X0 = get_Item(index:  0);               
            Pathfinding.ClipperLib.TEdge val_37 = Item[0];
            // 0x0270A484: LDR w27, [sp, #0x24]       | W27 = (val_2 - 1);                      
            // 0x0270A488: MOV x20, x0                | X20 = val_37;//m1                       
            // 0x0270A48C: CMP w27, #0                | STATE = COMPARE((val_2 - 1), 0x0)       
            // 0x0270A490: B.GT #0x270a4b0            | if (val_3 > 0) goto label_41;           
            if(val_3 > 0)
            {
                goto label_41;
            }
            // 0x0270A494: CBNZ x20, #0x270a49c       | if (val_37 != null) goto label_42;      
            if(val_37 != null)
            {
                goto label_42;
            }
            // 0x0270A498: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
            label_42:
            // 0x0270A49C: LDR x19, [x20, #0x78]      | X19 = val_37.Prev; //P2                 
            val_65 = val_37.Prev;
            // 0x0270A4A0: CBNZ x19, #0x270a4a8       | if (val_37.Prev != null) goto label_43; 
            if(val_65 != null)
            {
                goto label_43;
            }
            // 0x0270A4A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
            label_43:
            // 0x0270A4A8: ORR w8, wzr, #0xfffffffe   | W8 = -2(0xFFFFFFFFFFFFFFFE);            
            // 0x0270A4AC: STR w8, [x19, #0x6c]       | val_37.Prev.OutIdx = -2;                 //  dest_result_addr=0
            val_37.Prev.OutIdx = -2;
            label_41:
            // 0x0270A4B0: STP x20, x28, [sp, #0x10]  | stack[1152921509606893216] = val_37;  stack[1152921509606893224] = this;  //  dest_result_addr=1152921509606893216 |  dest_result_addr=1152921509606893224
            // 0x0270A4B4: STR x20, [sp, #0x28]       | stack[1152921509606893240] = val_37;     //  dest_result_addr=1152921509606893240
            // 0x0270A4B8: MOV x25, x20               | X25 = val_37;//m1                       
            // 0x0270A4BC: MOV x24, x20               | X24 = val_37;//m1                       
            val_66 = val_37;
            // 0x0270A4C0: B #0x270a660               |  goto label_45;                         
            goto label_45;
            label_85:
            // 0x0270A4C4: STR x25, [sp, #0x28]       | stack[1152921509606893240] = val_37;     //  dest_result_addr=1152921509606893240
            // 0x0270A4C8: MOV x24, x25               | X24 = val_37;//m1                       
            val_66 = val_37;
            // 0x0270A4CC: B #0x270a660               |  goto label_45;                         
            goto label_45;
            label_81:
            // 0x0270A4D0: LDR x8, [x24, #0x70]       | X8 = val_37.Next; //P2                  
            // 0x0270A4D4: CMP x24, x8                | STATE = COMPARE(val_37, val_37.Next)    
            // 0x0270A4D8: B.EQ #0x270a6e4            | if (val_66 == val_37.Next) goto label_51;
            if(val_66 == val_37.Next)
            {
                goto label_51;
            }
            // 0x0270A4DC: LDR x9, [sp, #0x10]        | X9 = val_37;                            
            val_67 = val_37;
            // 0x0270A4E0: CMP x24, x9                | STATE = COMPARE(val_37, val_37)         
            // 0x0270A4E4: B.NE #0x270a4f4            | if (val_66 != val_67) goto label_47;    
            if(val_66 != val_67)
            {
                goto label_47;
            }
            // 0x0270A4E8: CBNZ x24, #0x270a4f0       | if (val_37 != null) goto label_48;      
            if(val_66 != null)
            {
                goto label_48;
            }
            // 0x0270A4EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
            label_48:
            // 0x0270A4F0: LDR x9, [x24, #0x70]       | X9 = val_37.Next; //P2                  
            val_67 = val_37.Next;
            label_47:
            // 0x0270A4F4: MOV x1, x24                | X1 = val_37;//m1                        
            // 0x0270A4F8: STR x9, [sp, #0x10]        | stack[1152921509606893216] = val_37.Next;  //  dest_result_addr=1152921509606893216
            // 0x0270A4FC: BL #0x270aa60              | X0 = val_37.RemoveEdge(e:  val_66);     
            Pathfinding.ClipperLib.TEdge val_38 = val_37.RemoveEdge(e:  val_66);
            // 0x0270A500: MOV x25, x0                | X25 = val_38;//m1                       
            // 0x0270A504: B #0x270a4c4               |  goto label_85;                         
            goto label_85;
            label_80:
            // 0x0270A508: LDR x19, [x24, #0x78]      | X19 = val_37.Prev; //P2                 
            // 0x0270A50C: CBNZ x24, #0x270a514       | if (val_37 != null) goto label_50;      
            if(val_66 != null)
            {
                goto label_50;
            }
            // 0x0270A510: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_50:
            // 0x0270A514: LDR x8, [x24, #0x70]       | X8 = val_37.Next; //P2                  
            // 0x0270A518: CMP x19, x8                | STATE = COMPARE(val_37.Prev, val_37.Next)
            // 0x0270A51C: B.EQ #0x270a6e4            | if (val_37.Prev == val_37.Next) goto label_51;
            if(val_37.Prev == val_37.Next)
            {
                goto label_51;
            }
            // 0x0270A520: CMP w27, #0                | STATE = COMPARE((val_2 - 1), 0x0)       
            // 0x0270A524: B.GT #0x270a57c            | if (val_3 > 0) goto label_52;           
            if(val_3 > 0)
            {
                goto label_52;
            }
            // 0x0270A528: CBNZ x24, #0x270a530       | if (val_37 != null) goto label_53;      
            if(val_66 != null)
            {
                goto label_53;
            }
            // 0x0270A52C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_53:
            // 0x0270A530: LDR x19, [x24, #0x78]      | X19 = val_37.Prev; //P2                 
            val_65 = val_37.Prev;
            // 0x0270A534: CBNZ x19, #0x270a53c       | if (val_37.Prev != null) goto label_54; 
            if(val_65 != null)
            {
                goto label_54;
            }
            // 0x0270A538: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_54:
            // 0x0270A53C: LDR w8, [x19, #0x6c]       | W8 = val_37.Prev.OutIdx; //P2           
            // 0x0270A540: CMN w8, #2                 | STATE = COMPARE(val_37.Prev.OutIdx, 0x2)
            // 0x0270A544: B.EQ #0x270a648            | if (val_37.Prev.OutIdx == 2) goto label_66;
            if(val_37.Prev.OutIdx == 2)
            {
                goto label_66;
            }
            // 0x0270A548: CBNZ x24, #0x270a550       | if (val_37 != null) goto label_56;      
            if(val_66 != null)
            {
                goto label_56;
            }
            // 0x0270A54C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_56:
            // 0x0270A550: LDR w8, [x24, #0x6c]       | W8 = val_37.OutIdx; //P2                
            // 0x0270A554: CMN w8, #2                 | STATE = COMPARE(val_37.OutIdx, 0x2)     
            // 0x0270A558: B.EQ #0x270a648            | if (val_37.OutIdx == 2) goto label_66;  
            if(val_37.OutIdx == 2)
            {
                goto label_66;
            }
            // 0x0270A55C: CBNZ x24, #0x270a564       | if (val_37 != null) goto label_58;      
            if(val_66 != null)
            {
                goto label_58;
            }
            // 0x0270A560: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_58:
            // 0x0270A564: LDR x19, [x24, #0x70]      | X19 = val_37.Next; //P2                 
            val_65 = val_37.Next;
            // 0x0270A568: CBNZ x19, #0x270a570       | if (val_37.Next != null) goto label_59; 
            if(val_65 != null)
            {
                goto label_59;
            }
            // 0x0270A56C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_59:
            // 0x0270A570: LDR w8, [x19, #0x6c]       | W8 = val_37.Next.OutIdx; //P2           
            // 0x0270A574: CMN w8, #2                 | STATE = COMPARE(val_37.Next.OutIdx, 0x2)
            // 0x0270A578: B.EQ #0x270a648            | if (val_37.Next.OutIdx == 2) goto label_66;
            if(val_37.Next.OutIdx == 2)
            {
                goto label_66;
            }
            label_52:
            // 0x0270A57C: CBNZ x24, #0x270a584       | if (val_37 != null) goto label_61;      
            if(val_66 != null)
            {
                goto label_61;
            }
            // 0x0270A580: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_61:
            // 0x0270A584: LDR x19, [x24, #0x78]      | X19 = val_37.Prev; //P2                 
            // 0x0270A588: MOV w23, w27               | W23 = (val_2 - 1);//m1                  
            // 0x0270A58C: CBNZ x19, #0x270a594       | if (val_37.Prev != null) goto label_62; 
            if(val_37.Prev != null)
            {
                goto label_62;
            }
            // 0x0270A590: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_62:
            // 0x0270A594: LDP x26, x27, [x19, #0x20] | X26 = val_37.Prev.Curr; //P2             //  | 
            // 0x0270A598: CBNZ x24, #0x270a5a0       | if (val_37 != null) goto label_63;      
            if(val_66 != null)
            {
                goto label_63;
            }
            // 0x0270A59C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_63:
            // 0x0270A5A0: LDP x28, x20, [x24, #0x20] | X28 = val_37.Curr; //P2                  //  | 
            // 0x0270A5A4: CBNZ x24, #0x270a5ac       | if (val_37 != null) goto label_64;      
            if(val_66 != null)
            {
                goto label_64;
            }
            // 0x0270A5A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_64:
            // 0x0270A5AC: LDR x19, [x24, #0x70]      | X19 = val_37.Next; //P2                 
            val_65 = val_37.Next;
            // 0x0270A5B0: CBNZ x19, #0x270a5b8       | if (val_37.Next != null) goto label_65; 
            if(val_65 != null)
            {
                goto label_65;
            }
            // 0x0270A5B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_65:
            // 0x0270A5B8: LDP x5, x6, [x19, #0x20]   | X5 = val_37.Next.Curr; //P2              //  | 
            // 0x0270A5BC: LDRB w7, [x22]             | W7 = this.m_UseFullRange;               
            // 0x0270A5C0: MOV x1, x26                | X1 = val_37.Prev.Curr;//m1              
            // 0x0270A5C4: MOV x2, x27                | X2 = (val_2 - 1);//m1                   
            // 0x0270A5C8: MOV x3, x28                | X3 = val_37.Curr;//m1                   
            // 0x0270A5CC: MOV x4, x20                | X4 = val_37;//m1                        
            // 0x0270A5D0: BL #0x2708010              | X0 = Pathfinding.ClipperLib.ClipperBase.SlopesEqual(pt1:  new Pathfinding.ClipperLib.IntPoint() {X = val_38, Y = val_37.Prev.Curr}, pt2:  new Pathfinding.ClipperLib.IntPoint() {X = val_3, Y = val_37.Curr}, pt3:  new Pathfinding.ClipperLib.IntPoint() {X = val_37, Y = val_37.Next.Curr}, UseFullRange:  false);
            bool val_39 = Pathfinding.ClipperLib.ClipperBase.SlopesEqual(pt1:  new Pathfinding.ClipperLib.IntPoint() {X = val_38, Y = val_37.Prev.Curr}, pt2:  new Pathfinding.ClipperLib.IntPoint() {X = val_3, Y = val_37.Curr}, pt3:  new Pathfinding.ClipperLib.IntPoint() {X = val_37, Y = val_37.Next.Curr}, UseFullRange:  false);
            // 0x0270A5D4: MOV w27, w23               | W27 = (val_2 - 1);//m1                  
            val_68 = val_3;
            // 0x0270A5D8: TBZ w0, #0, #0x270a648     | if (val_39 == false) goto label_66;     
            if(val_39 == false)
            {
                goto label_66;
            }
            // 0x0270A5DC: LDR x8, [sp, #0x18]        | X8 = this;                              
            // 0x0270A5E0: LDRB w8, [x8, #0x2a]       | W8 = (bool)mem[1152921509606905386];    
            // 0x0270A5E4: CBZ w8, #0x270a6a8         | if (mem[1152921509606905386] == false) goto label_73;
            if(mem[1152921509606905386] == false)
            {
                goto label_73;
            }
            // 0x0270A5E8: CBNZ x24, #0x270a5f0       | if (val_37 != null) goto label_68;      
            if(val_66 != null)
            {
                goto label_68;
            }
            // 0x0270A5EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
            label_68:
            // 0x0270A5F0: LDR x19, [x24, #0x78]      | X19 = val_37.Prev; //P2                 
            // 0x0270A5F4: MOV w23, w27               | W23 = (val_2 - 1);//m1                  
            // 0x0270A5F8: CBNZ x19, #0x270a600       | if (val_37.Prev != null) goto label_69; 
            if(val_37.Prev != null)
            {
                goto label_69;
            }
            // 0x0270A5FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
            label_69:
            // 0x0270A600: LDP x26, x27, [x19, #0x20] | X26 = val_37.Prev.Curr; //P2             //  | 
            // 0x0270A604: CBNZ x24, #0x270a60c       | if (val_37 != null) goto label_70;      
            if(val_66 != null)
            {
                goto label_70;
            }
            // 0x0270A608: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
            label_70:
            // 0x0270A60C: LDP x20, x28, [x24, #0x20] | X20 = val_37.Curr; //P2                  //  | 
            // 0x0270A610: CBNZ x24, #0x270a618       | if (val_37 != null) goto label_71;      
            if(val_66 != null)
            {
                goto label_71;
            }
            // 0x0270A614: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
            label_71:
            // 0x0270A618: LDR x19, [x24, #0x70]      | X19 = val_37.Next; //P2                 
            val_65 = val_37.Next;
            // 0x0270A61C: CBNZ x19, #0x270a624       | if (val_37.Next != null) goto label_72; 
            if(val_65 != null)
            {
                goto label_72;
            }
            // 0x0270A620: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
            label_72:
            // 0x0270A624: LDP x5, x6, [x19, #0x20]   | X5 = val_37.Next.Curr; //P2              //  | 
            // 0x0270A628: MOV x1, x26                | X1 = val_37.Prev.Curr;//m1              
            // 0x0270A62C: MOV x2, x27                | X2 = (val_2 - 1);//m1                   
            // 0x0270A630: MOV x3, x20                | X3 = val_37.Curr;//m1                   
            // 0x0270A634: MOV x4, x28                | X4 = val_37.Curr;//m1                   
            // 0x0270A638: BL #0x27080b0              | X0 = val_39.Pt2IsBetweenPt1AndPt3(pt1:  new Pathfinding.ClipperLib.IntPoint() {X = val_37.Prev.Curr, Y = val_68}, pt2:  new Pathfinding.ClipperLib.IntPoint() {X = val_37.Curr, Y = val_37.Curr}, pt3:  new Pathfinding.ClipperLib.IntPoint() {X = val_37.Next.Curr});
            bool val_40 = val_39.Pt2IsBetweenPt1AndPt3(pt1:  new Pathfinding.ClipperLib.IntPoint() {X = val_37.Prev.Curr, Y = val_68}, pt2:  new Pathfinding.ClipperLib.IntPoint() {X = val_37.Curr, Y = val_37.Curr}, pt3:  new Pathfinding.ClipperLib.IntPoint() {X = val_37.Next.Curr});
            // 0x0270A63C: MOV w27, w23               | W27 = (val_2 - 1);//m1                  
            val_68 = val_68;
            // 0x0270A640: AND w8, w0, #1             | W8 = (val_40 & 1);                      
            bool val_41 = val_40;
            // 0x0270A644: TBZ w8, #0, #0x270a6a8     | if ((val_40 & 1) == false) goto label_73;
            if(val_41 == false)
            {
                goto label_73;
            }
            label_66:
            // 0x0270A648: CBNZ x24, #0x270a650       | if (val_37 != null) goto label_74;      
            if(val_66 != null)
            {
                goto label_74;
            }
            // 0x0270A64C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
            label_74:
            // 0x0270A650: LDR x24, [x24, #0x70]      | X24 = val_37.Next; //P2                 
            val_66 = val_37.Next;
            // 0x0270A654: STR x24, [sp, #0x28]       | stack[1152921509606893240] = val_37.Next;  //  dest_result_addr=1152921509606893240
            // 0x0270A658: CMP x24, x25               | STATE = COMPARE(val_37.Next, val_38)    
            // 0x0270A65C: B.EQ #0x270a6e8            | if (val_66 == val_38) goto label_75;    
            if(val_66 == val_38)
            {
                goto label_75;
            }
            label_45:
            // 0x0270A660: CBNZ x24, #0x270a668       | if (val_37.Next != null) goto label_76; 
            if(val_66 != null)
            {
                goto label_76;
            }
            // 0x0270A664: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
            label_76:
            // 0x0270A668: LDP x20, x19, [x24, #0x20] | X20 = val_37.Next.Curr; //P2             //  | 
            // 0x0270A66C: CBNZ x24, #0x270a674       | if (val_37.Next != null) goto label_77; 
            if(val_66 != null)
            {
                goto label_77;
            }
            // 0x0270A670: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
            label_77:
            // 0x0270A674: LDR x26, [x24, #0x70]      | X26 = val_37.Next.Next; //P2            
            // 0x0270A678: CBNZ x26, #0x270a680       | if (val_37.Next.Next != null) goto label_78;
            if(val_37.Next.Next != null)
            {
                goto label_78;
            }
            // 0x0270A67C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
            label_78:
            // 0x0270A680: LDP x8, x9, [x26, #0x20]   | X8 = val_37.Next.Next.Curr; //P2         //  | 
            // 0x0270A684: CMP x20, x8                | STATE = COMPARE(val_37.Next.Curr, val_37.Next.Next.Curr)
            // 0x0270A688: CSET w8, eq                | W8 = val_37.Next.Curr == val_37.Next.Next.Curr ? 1 : 0;
            var val_42 = (val_37.Next.Curr == val_37.Next.Next.Curr) ? 1 : 0;
            // 0x0270A68C: CMP x19, x9                | STATE = COMPARE(val_37.Next, val_37.Next)
            // 0x0270A690: CSET w9, eq                | W9 = val_65 == val_67 ? 1 : 0;          
            var val_43 = (val_65 == val_67) ? 1 : 0;
            // 0x0270A694: AND w19, w8, w9            | W19 = (val_37.Next.Curr == val_37.Next.Next.Curr ? 1 : 0 & val_65 == val_67 ? 1 : 0);
            val_65 = val_42 & val_43;
            // 0x0270A698: CBNZ x24, #0x270a6a0       | if (val_37.Next != null) goto label_79; 
            if(val_66 != null)
            {
                goto label_79;
            }
            // 0x0270A69C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
            label_79:
            // 0x0270A6A0: TBZ w19, #0, #0x270a508    | if (((val_37.Next.Curr == val_37.Next.Next.Curr ? 1 : 0 & val_65 == val_67 ? 1 : 0) & 0x1) == 0) goto label_80;
            if((val_65 & 1) == 0)
            {
                goto label_80;
            }
            // 0x0270A6A4: B #0x270a4d0               |  goto label_81;                         
            goto label_81;
            label_73:
            // 0x0270A6A8: LDR x9, [sp, #0x10]        | X9 = val_37.Next;                       
            val_69 = val_67;
            // 0x0270A6AC: CMP x24, x9                | STATE = COMPARE(val_37, val_37.Next)    
            // 0x0270A6B0: B.NE #0x270a6c0            | if (val_66 != val_69) goto label_82;    
            if(val_66 != val_69)
            {
                goto label_82;
            }
            // 0x0270A6B4: CBNZ x24, #0x270a6bc       | if (val_37 != null) goto label_83;      
            if(val_66 != null)
            {
                goto label_83;
            }
            // 0x0270A6B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
            label_83:
            // 0x0270A6BC: LDR x9, [x24, #0x70]       | X9 = val_37.Next; //P2                  
            val_69 = val_37.Next;
            label_82:
            // 0x0270A6C0: MOV x1, x24                | X1 = val_37;//m1                        
            // 0x0270A6C4: STR x9, [sp, #0x10]        | stack[1152921509606893216] = val_37.Next;  //  dest_result_addr=1152921509606893216
            // 0x0270A6C8: BL #0x270aa60              | X0 = val_39.RemoveEdge(e:  val_66);     
            Pathfinding.ClipperLib.TEdge val_44 = val_39.RemoveEdge(e:  val_66);
            // 0x0270A6CC: MOV x20, x0                | X20 = val_44;//m1                       
            // 0x0270A6D0: STR x20, [sp, #0x28]       | stack[1152921509606893240] = val_44;     //  dest_result_addr=1152921509606893240
            // 0x0270A6D4: CBNZ x20, #0x270a6dc       | if (val_44 != null) goto label_84;      
            if(val_44 != null)
            {
                goto label_84;
            }
            // 0x0270A6D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_44, ????);     
            label_84:
            // 0x0270A6DC: LDR x25, [x20, #0x78]      | X25 = val_44.Prev; //P2                 
            // 0x0270A6E0: B #0x270a4c4               |  goto label_85;                         
            goto label_85;
            label_51:
            // 0x0270A6E4: MOV x25, x24               | X25 = val_37;//m1                       
            label_75:
            // 0x0270A6E8: LDR w22, [sp, #0x20]       | W22 = polyType;                         
            // 0x0270A6EC: CBNZ x25, #0x270a6f4       | if (val_37 != null) goto label_86;      
            if(val_66 != null)
            {
                goto label_86;
            }
            // 0x0270A6F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
            label_86:
            // 0x0270A6F4: LDR x19, [x25, #0x78]      | X19 = val_37.Prev; //P2                 
            // 0x0270A6F8: LDR x24, [sp, #0x18]       | X24 = this;                             
            // 0x0270A6FC: CBNZ x25, #0x270a704       | if (val_37 != null) goto label_87;      
            if(val_66 != null)
            {
                goto label_87;
            }
            // 0x0270A700: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
            label_87:
            // 0x0270A704: LDR x8, [x25, #0x70]       | X8 = val_37.Next; //P2                  
            // 0x0270A708: CMP x19, x8                | STATE = COMPARE(val_37.Prev, val_37.Next)
            // 0x0270A70C: B.EQ #0x270a43c            | if (val_37.Prev == val_37.Next) goto label_88;
            if(val_37.Prev == val_37.Next)
            {
                goto label_88;
            }
            // 0x0270A710: LDR x20, [x24, #0x20]      | X20 = mem[1152921509606905376];         
            // 0x0270A714: CBNZ x20, #0x270a71c       | if (mem[1152921509606905376] != 0) goto label_89;
            if(mem[1152921509606905376] != 0)
            {
                goto label_89;
            }
            // 0x0270A718: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
            label_89:
            // 0x0270A71C: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
            // 0x0270A720: LDR x8, [x8, #0x1b8]       | X8 = 1152921509606875040;               
            // 0x0270A724: MOV x0, x20                | X0 = mem[1152921509606905376];//m1      
            // 0x0270A728: MOV x1, x21                | X1 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x0270A72C: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge>>::Add(System.Collections.Generic.List<Pathfinding.ClipperLib.TEdge> item);
            // 0x0270A730: BL #0x25ea480              | mem[1152921509606905376].Add(item:  val_14);
            mem[1152921509606905376].Add(item:  val_14);
            // 0x0270A734: LDR x23, [sp, #0x10]       | X23 = val_37.Next;                      
            // 0x0270A738: MOV x21, x23               | X21 = val_37.Next;//m1                  
            // 0x0270A73C: MOV x19, x23               | X19 = val_37.Next;//m1                  
            // 0x0270A740: STR x23, [sp, #0x28]       | stack[1152921509606893240] = val_37.Next;  //  dest_result_addr=1152921509606893240
            label_92:
            // 0x0270A744: MOV x0, x24                | X0 = 1152921509606905344 (0x100000012A06D600);//ML01
            // 0x0270A748: MOV x1, x21                | X1 = val_37.Next;//m1                   
            // 0x0270A74C: MOV w2, w22                | W2 = polyType;//m1                      
            // 0x0270A750: BL #0x2709d88              | this.InitEdge2(e:  val_69, polyType:  polyType);
            this.InitEdge2(e:  val_69, polyType:  polyType);
            // 0x0270A754: CBNZ x21, #0x270a75c       | if (val_37.Next != 0) goto label_90;    
            if(val_69 != 0)
            {
                goto label_90;
            }
            // 0x0270A758: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_90:
            // 0x0270A75C: LDR x20, [x21, #0x38]      | X20 = val_37.Next + 56;                 
            // 0x0270A760: CBNZ x19, #0x270a768       | if (val_37.Next != 0) goto label_91;    
            if(val_69 != 0)
            {
                goto label_91;
            }
            // 0x0270A764: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_91:
            // 0x0270A768: LDR x8, [x19, #0x38]       | X8 = val_37.Next + 56;                  
            // 0x0270A76C: CMP x20, x8                | STATE = COMPARE(val_37.Next + 56, val_37.Next + 56)
            // 0x0270A770: CSEL x19, x21, x19, lt     | X19 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next;
            var val_45 = ((val_37.Next + 56) < (val_37.Next + 56)) ? (val_69) : (val_69);
            // 0x0270A774: LDR x21, [x21, #0x70]      | X21 = val_37.Next + 112;                
            // 0x0270A778: STR x21, [sp, #0x28]       | stack[1152921509606893240] = val_37.Next + 112;  //  dest_result_addr=1152921509606893240
            Pathfinding.ClipperLib.TEdge val_47 = val_37.Next + 112;
            // 0x0270A77C: CMP x21, x23               | STATE = COMPARE(val_37.Next + 112, val_37.Next)
            // 0x0270A780: B.NE #0x270a744            | if (val_37.Next + 112 != val_69) goto label_92;
            if((val_37.Next + 112) != val_69)
            {
                goto label_92;
            }
            // 0x0270A784: MOV x1, x23                | X1 = val_37.Next;//m1                   
            // 0x0270A788: BL #0x270aad0              | X0 = this.AllHorizontal(Edge:  val_69); 
            bool val_46 = this.AllHorizontal(Edge:  val_69);
            // 0x0270A78C: TBZ w0, #0, #0x270a7d0     | if (val_46 == false) goto label_93;     
            if(val_46 == false)
            {
                goto label_93;
            }
            // 0x0270A790: CMP w27, #1                | STATE = COMPARE((val_2 - 1), 0x1)       
            // 0x0270A794: B.LT #0x270a7b4            | if (val_3 < 1) goto label_94;           
            if(val_3 < 1)
            {
                goto label_94;
            }
            // 0x0270A798: CBNZ x23, #0x270a7a0       | if (val_37.Next != 0) goto label_95;    
            if(val_69 != 0)
            {
                goto label_95;
            }
            // 0x0270A79C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            label_95:
            // 0x0270A7A0: LDR x19, [x23, #0x78]      | X19 = val_37.Next + 120;                
            // 0x0270A7A4: CBNZ x19, #0x270a7ac       | if (val_37.Next + 120 != 0) goto label_96;
            if((val_37.Next + 120) != 0)
            {
                goto label_96;
            }
            // 0x0270A7A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            label_96:
            // 0x0270A7AC: ORR w8, wzr, #0xfffffffe   | W8 = -2(0xFFFFFFFFFFFFFFFE);            
            // 0x0270A7B0: STR w8, [x19, #0x6c]       | mem2[0] = 0xFFFFFFFFFFFFFFFE;            //  dest_result_addr=0
            mem2[0] = -2;
            label_94:
            // 0x0270A7B4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x0270A7B8: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
            // 0x0270A7BC: ADD x1, sp, #0x28          | X1 = (1152921509606893200 + 40) = 1152921509606893240 (0x100000012A06A6B8);
            // 0x0270A7C0: MOV x0, x24                | X0 = 1152921509606905344 (0x100000012A06D600);//ML01
            // 0x0270A7C4: BL #0x270ab2c              | this.AscendToMax(E: ref  Pathfinding.ClipperLib.TEdge val_47 = val_37.Next + 112, Appending:  false, IsClosed:  false);
            this.AscendToMax(E: ref  val_47, Appending:  false, IsClosed:  false);
            // 0x0270A7C8: ORR w21, wzr, #1           | W21 = 1(0x1);                           
            // 0x0270A7CC: B #0x270a440               |  goto label_132;                        
            goto label_132;
            label_93:
            // 0x0270A7D0: CBNZ x23, #0x270a7d8       | if (val_37.Next != 0) goto label_98;    
            if(val_69 != 0)
            {
                goto label_98;
            }
            // 0x0270A7D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            label_98:
            // 0x0270A7D8: LDR x21, [x23, #0x78]      | X21 = val_37.Next + 120;                
            // 0x0270A7DC: STR x21, [sp, #0x28]       | stack[1152921509606893240] = val_37.Next + 120;  //  dest_result_addr=1152921509606893240
            // 0x0270A7E0: CBZ x21, #0x270a7f0        | if (val_37.Next + 120 == 0) goto label_99;
            if((val_37.Next + 120) == 0)
            {
                goto label_99;
            }
            // 0x0270A7E4: MOV x22, x21               | X22 = val_37.Next + 120;//m1            
            val_70 = val_37.Next + 120;
            // 0x0270A7E8: LDR x20, [x22, #0x78]!     | X20 = val_37.Next + 120 + 120;          
            val_71 = mem[val_37.Next + 120 + 120];
            val_71 = val_37.Next + 120 + 120;
            // 0x0270A7EC: B #0x270a800               |  goto label_100;                        
            goto label_100;
            label_99:
            // 0x0270A7F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            // 0x0270A7F4: MOV x22, x21               | X22 = val_37.Next + 120;//m1            
            val_70 = val_37.Next + 120;
            // 0x0270A7F8: LDR x20, [x22, #0x78]!     | X20 = val_37.Next + 120 + 120;          
            val_71 = mem[val_37.Next + 120 + 120];
            val_71 = val_37.Next + 120 + 120;
            // 0x0270A7FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            label_100:
            // 0x0270A800: LDR x8, [x21, #0x70]       | X8 = val_37.Next + 120 + 112;           
            // 0x0270A804: CMP x20, x8                | STATE = COMPARE(val_37.Next + 120 + 120, val_37.Next + 120 + 112)
            // 0x0270A808: B.EQ #0x270a940            | if (val_71 == val_37.Next + 120 + 112) goto label_141;
            if(val_71 == (val_37.Next + 120 + 112))
            {
                goto label_141;
            }
            // 0x0270A80C: CMP w27, #0                | STATE = COMPARE((val_2 - 1), 0x0)       
            // 0x0270A810: B.GT #0x270a888            | if (val_3 > 0) goto label_104;          
            if(val_3 > 0)
            {
                goto label_104;
            }
            // 0x0270A814: LDR x20, [x21, #0x38]      | X20 = val_37.Next + 120 + 56;           
            // 0x0270A818: CBNZ x19, #0x270a820       | if (val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next != 0) goto label_103;
            if(val_45 != 0)
            {
                goto label_103;
            }
            // 0x0270A81C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            label_103:
            // 0x0270A820: LDR x8, [x19, #0x38]       | X8 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 56;
            // 0x0270A824: CMP x20, x8                | STATE = COMPARE(val_37.Next + 120 + 56, val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 56)
            // 0x0270A828: B.NE #0x270a888            | if (val_37.Next + 120 + 56 != val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 56) goto label_104;
            if((val_37.Next + 120 + 56) != (val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 56))
            {
                goto label_104;
            }
            // 0x0270A82C: CBNZ x21, #0x270a834       | if (val_37.Next + 120 != 0) goto label_105;
            if((val_37.Next + 120) != 0)
            {
                goto label_105;
            }
            // 0x0270A830: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            label_105:
            // 0x0270A834: LDR x8, [x21, #0x48]       | X8 = val_37.Next + 120 + 72;            
            // 0x0270A838: CBZ x8, #0x270a850         | if (val_37.Next + 120 + 72 == 0) goto label_106;
            if((val_37.Next + 120 + 72) == 0)
            {
                goto label_106;
            }
            // 0x0270A83C: LDR x20, [x21, #0x70]      | X20 = val_37.Next + 120 + 112;          
            val_72 = mem[val_37.Next + 120 + 112];
            val_72 = val_37.Next + 120 + 112;
            // 0x0270A840: CBNZ x20, #0x270a848       | if (val_37.Next + 120 + 112 != 0) goto label_107;
            if(val_72 != 0)
            {
                goto label_107;
            }
            // 0x0270A844: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            label_107:
            // 0x0270A848: LDR x8, [x20, #0x48]       | X8 = val_37.Next + 120 + 112 + 72;      
            // 0x0270A84C: CBNZ x8, #0x270a970        | if (val_37.Next + 120 + 112 + 72 != 0) goto label_112;
            if((val_37.Next + 120 + 112 + 72) != 0)
            {
                goto label_112;
            }
            label_106:
            // 0x0270A850: CBNZ x21, #0x270a858       | if (val_37.Next + 120 != 0) goto label_109;
            if((val_37.Next + 120) != 0)
            {
                goto label_109;
            }
            // 0x0270A854: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            label_109:
            // 0x0270A858: LDR x20, [x21, #0x70]      | X20 = val_37.Next + 120 + 112;          
            // 0x0270A85C: CBNZ x20, #0x270a864       | if (val_37.Next + 120 + 112 != 0) goto label_110;
            if((val_37.Next + 120 + 112) != 0)
            {
                goto label_110;
            }
            // 0x0270A860: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            label_110:
            // 0x0270A864: LDR x20, [x20, #0x18]      | X20 = val_37.Next + 120 + 112 + 24;     
            val_72 = mem[val_37.Next + 120 + 112 + 24];
            val_72 = val_37.Next + 120 + 112 + 24;
            // 0x0270A868: CBNZ x19, #0x270a870       | if (val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next != 0) goto label_111;
            if(val_45 != 0)
            {
                goto label_111;
            }
            // 0x0270A86C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            label_111:
            // 0x0270A870: LDR x8, [x19, #0x38]       | X8 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 56;
            // 0x0270A874: CMP x20, x8                | STATE = COMPARE(val_37.Next + 120 + 112 + 24, val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 56)
            // 0x0270A878: B.NE #0x270a970            | if (val_72 != val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 56) goto label_112;
            if(val_72 != (val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 56))
            {
                goto label_112;
            }
            // 0x0270A87C: CBNZ x21, #0x270a9d8       | if (val_37.Next + 120 != 0) goto label_139;
            if((val_37.Next + 120) != 0)
            {
                goto label_139;
            }
            // 0x0270A880: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            // 0x0270A884: B #0x270a9d8               |  goto label_139;                        
            goto label_139;
            label_104:
            // 0x0270A888: MOV x20, x19               | X20 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next;//m1
            val_71 = val_45;
            // 0x0270A88C: STR x19, [sp, #0x28]       | stack[1152921509606893240] = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next;  //  dest_result_addr=1152921509606893240
            label_126:
            // 0x0270A890: CBNZ x20, #0x270a898       | if (val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next != 0) goto label_115;
            if(val_71 != 0)
            {
                goto label_115;
            }
            // 0x0270A894: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            label_115:
            // 0x0270A898: LDR x8, [x20, #0x48]       | X8 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 72;
            // 0x0270A89C: CBZ x8, #0x270a904         | if (val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 72 == 0) goto label_119;
            if((val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 72) == 0)
            {
                goto label_119;
            }
            // 0x0270A8A0: LDP x23, x21, [x20, #0x30] | X23 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48; X21 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48 + 8; //  | 
            // 0x0270A8A4: LDR x22, [x20, #0x70]      | X22 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112;
            // 0x0270A8A8: CBNZ x22, #0x270a8b0       | if (val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 != 0) goto label_117;
            if((val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112) != 0)
            {
                goto label_117;
            }
            // 0x0270A8AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            label_117:
            // 0x0270A8B0: LDR x8, [x22, #0x30]       | X8 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 48;
            // 0x0270A8B4: CMP x23, x8                | STATE = COMPARE(val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48, val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 48)
            // 0x0270A8B8: B.NE #0x270a8c8            | if (val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48 != val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 48) goto label_118;
            if((val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48) != (val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 48))
            {
                goto label_118;
            }
            // 0x0270A8BC: LDR x8, [x22, #0x38]       | X8 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 56;
            // 0x0270A8C0: CMP x21, x8                | STATE = COMPARE(val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48 + 8, val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 56)
            // 0x0270A8C4: B.EQ #0x270a904            | if (val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48 + 8 == val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 56) goto label_119;
            if((val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48 + 8) == (val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 56))
            {
                goto label_119;
            }
            label_118:
            // 0x0270A8C8: CBZ x20, #0x270a8d4        | if (val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next == 0) goto label_120;
            if(val_71 == 0)
            {
                goto label_120;
            }
            // 0x0270A8CC: LDP x22, x21, [x20, #0x30] | X22 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48; X21 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48 + 8; //  | 
            val_73 = mem[val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48];
            val_73 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48;
            val_74 = mem[val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48 + 8];
            val_74 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48 + 8;
            // 0x0270A8D0: B #0x270a8e0               |  goto label_121;                        
            goto label_121;
            label_120:
            // 0x0270A8D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            // 0x0270A8D8: LDP x22, x21, [x20, #0x30] | X22 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48; X21 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48 + 8; //  | 
            val_73 = mem[val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48];
            val_73 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48;
            val_74 = mem[val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48 + 8];
            val_74 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48 + 8;
            // 0x0270A8DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            label_121:
            // 0x0270A8E0: LDR x23, [x20, #0x70]      | X23 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112;
            // 0x0270A8E4: CBNZ x23, #0x270a8ec       | if (val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 != 0) goto label_122;
            if((val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112) != 0)
            {
                goto label_122;
            }
            // 0x0270A8E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            label_122:
            // 0x0270A8EC: LDR x8, [x23, #0x10]       | X8 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 16;
            // 0x0270A8F0: CMP x22, x8                | STATE = COMPARE(val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48, val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 16)
            // 0x0270A8F4: B.NE #0x270a940            | if (val_73 != val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 16) goto label_141;
            if(val_73 != (val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 16))
            {
                goto label_141;
            }
            // 0x0270A8F8: LDR x8, [x23, #0x18]       | X8 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 24;
            // 0x0270A8FC: CMP x21, x8                | STATE = COMPARE(val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 48 + 8, val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 24)
            // 0x0270A900: B.NE #0x270a940            | if (val_74 != val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 24) goto label_141;
            if(val_74 != (val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 24))
            {
                goto label_141;
            }
            label_119:
            // 0x0270A904: CBNZ x20, #0x270a90c       | if (val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next != 0) goto label_125;
            if(val_71 != 0)
            {
                goto label_125;
            }
            // 0x0270A908: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            label_125:
            // 0x0270A90C: LDR x20, [x20, #0x70]      | X20 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112;
            val_71 = mem[val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112];
            val_71 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112;
            // 0x0270A910: CMP x20, x19               | STATE = COMPARE(val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112, val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next)
            // 0x0270A914: B.NE #0x270a890            | if (val_71 != val_45) goto label_126;   
            if(val_71 != val_45)
            {
                goto label_126;
            }
            // 0x0270A918: B #0x270a920               |  goto label_127;                        
            goto label_127;
            label_130:
            // 0x0270A91C: LDR x20, [x20, #0x70]      | X20 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 112;
            val_71 = mem[val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 112];
            val_71 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 112;
            label_127:
            // 0x0270A920: CBNZ x20, #0x270a928       | if (val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 112 != 0) goto label_128;
            if(val_71 != 0)
            {
                goto label_128;
            }
            // 0x0270A924: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            label_128:
            // 0x0270A928: LDR x8, [x20, #0x48]       | X8 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 112 + 72;
            // 0x0270A92C: CBZ x8, #0x270a91c         | if (val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 112 + 72 == 0) goto label_130;
            if((val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 112 + 72) == 0)
            {
                goto label_130;
            }
            // 0x0270A930: MOV x1, x20                | X1 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 112;//m1
            // 0x0270A934: BL #0x270ad84              | X0 = val_46.SharedVertWithPrevAtTop(Edge:  val_71);
            bool val_48 = val_46.SharedVertWithPrevAtTop(Edge:  val_71);
            // 0x0270A938: AND w8, w0, #1             | W8 = (val_48 & 1);                      
            bool val_49 = val_48;
            // 0x0270A93C: TBZ w8, #0, #0x270a91c     | if ((val_48 & 1) == false) goto label_130;
            if(val_49 == false)
            {
                goto label_130;
            }
            label_141:
            // 0x0270A940: MOV x8, x20                | X8 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 112;//m1
            // 0x0270A944: ORR w21, wzr, #1           | W21 = 1(0x1);                           
            // 0x0270A948: STR x20, [sp, #0x28]       | stack[1152921509606893240] = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 112;  //  dest_result_addr=1152921509606893240
            label_131:
            // 0x0270A94C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0270A950: MOV x0, x24                | X0 = 1152921509606905344 (0x100000012A06D600);//ML01
            // 0x0270A954: MOV x1, x8                 | X1 = val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 112;//m1
            // 0x0270A958: BL #0x270ae80              | X0 = this.AddBoundsToLML(E:  val_71, Closed:  true);
            Pathfinding.ClipperLib.TEdge val_50 = this.AddBoundsToLML(E:  val_71, Closed:  true);
            // 0x0270A95C: MOV x8, x0                 | X8 = val_50;//m1                        
            // 0x0270A960: STR x8, [sp, #0x28]        | stack[1152921509606893240] = val_50;     //  dest_result_addr=1152921509606893240
            // 0x0270A964: CMP x8, x20                | STATE = COMPARE(val_50, val_37.Next + 56 < val_37.Next + 56 ? val_37.Next : val_37.Next + 112 + 112)
            // 0x0270A968: B.NE #0x270a94c            | if (val_50 != val_71) goto label_131;   
            if(val_50 != val_71)
            {
                goto label_131;
            }
            // 0x0270A96C: B #0x270a440               |  goto label_132;                        
            goto label_132;
            label_112:
            // 0x0270A970: MOV x1, x21                | X1 = val_37.Next + 120;//m1             
            // 0x0270A974: BL #0x270ad84              | X0 = val_46.SharedVertWithPrevAtTop(Edge:  val_37.Next + 120);
            bool val_51 = val_46.SharedVertWithPrevAtTop(Edge:  val_37.Next + 120);
            // 0x0270A978: AND w8, w0, #1             | W8 = (val_51 & 1);                      
            bool val_52 = val_51;
            // 0x0270A97C: TBZ w8, #0, #0x270a988     | if ((val_51 & 1) == false) goto label_133;
            if(val_52 == false)
            {
                goto label_133;
            }
            // 0x0270A980: MOV x20, x21               | X20 = val_37.Next + 120;//m1            
            // 0x0270A984: B #0x270a940               |  goto label_141;                        
            goto label_141;
            label_133:
            // 0x0270A988: CBZ x21, #0x270a994        | if (val_37.Next + 120 == 0) goto label_135;
            if((val_37.Next + 120) == 0)
            {
                goto label_135;
            }
            // 0x0270A98C: LDP x19, x20, [x21, #0x30] | X19 = val_37.Next + 120 + 48; X20 = val_37.Next + 120 + 48 + 8; //  | 
            val_75 = mem[val_37.Next + 120 + 48];
            val_75 = val_37.Next + 120 + 48;
            val_76 = mem[val_37.Next + 120 + 48 + 8];
            val_76 = val_37.Next + 120 + 48 + 8;
            // 0x0270A990: B #0x270a9a0               |  goto label_136;                        
            goto label_136;
            label_135:
            // 0x0270A994: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_51, ????);     
            // 0x0270A998: LDP x19, x20, [x21, #0x30] | X19 = val_37.Next + 120 + 48; X20 = val_37.Next + 120 + 48 + 8; //  | 
            val_75 = mem[val_37.Next + 120 + 48];
            val_75 = val_37.Next + 120 + 48;
            val_76 = mem[val_37.Next + 120 + 48 + 8];
            val_76 = val_37.Next + 120 + 48 + 8;
            // 0x0270A99C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_51, ????);     
            label_136:
            // 0x0270A9A0: LDR x23, [x22]             | X23 = val_37.Next + 120 + 120;          
            // 0x0270A9A4: CBNZ x23, #0x270a9ac       | if (val_37.Next + 120 + 120 != 0) goto label_137;
            if((val_37.Next + 120 + 120) != 0)
            {
                goto label_137;
            }
            // 0x0270A9A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_51, ????);     
            label_137:
            // 0x0270A9AC: LDP x8, x9, [x23, #0x30]   | X8 = val_37.Next + 120 + 120 + 48; X9 = val_37.Next + 120 + 120 + 48 + 8; //  | 
            // 0x0270A9B0: CMP x19, x8                | STATE = COMPARE(val_37.Next + 120 + 48, val_37.Next + 120 + 120 + 48)
            // 0x0270A9B4: CSET w8, eq                | W8 = val_75 == val_37.Next + 120 + 120 + 48 ? 1 : 0;
            var val_53 = (val_75 == (val_37.Next + 120 + 120 + 48)) ? 1 : 0;
            // 0x0270A9B8: CMP x20, x9                | STATE = COMPARE(val_37.Next + 120 + 48 + 8, val_37.Next + 120 + 120 + 48 + 8)
            // 0x0270A9BC: CSET w9, eq                | W9 = val_76 == val_37.Next + 120 + 120 + 48 + 8 ? 1 : 0;
            var val_54 = (val_76 == (val_37.Next + 120 + 120 + 48 + 8)) ? 1 : 0;
            // 0x0270A9C0: AND w19, w8, w9            | W19 = (val_75 == val_37.Next + 120 + 120 + 48 ? 1 : 0 & val_76 == val_37.Next + 120 + 120 + 48 + 8 ?
            val_75 = val_53 & val_54;
            // 0x0270A9C4: CBNZ x21, #0x270a9cc       | if (val_37.Next + 120 != 0) goto label_138;
            if((val_37.Next + 120) != 0)
            {
                goto label_138;
            }
            // 0x0270A9C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_51, ????);     
            label_138:
            // 0x0270A9CC: CBZ w19, #0x270a9d8        | if ((val_75 == val_37.Next + 120 + 120 + 48 ? 1 : 0 & val_76 == val_37.Next + 120 + 120 + 48 + 8 ? 1 : 0) == 0) goto label_139;
            if(val_75 == 0)
            {
                goto label_139;
            }
            // 0x0270A9D0: LDR x20, [x22]             | X20 = val_37.Next + 120 + 120;          
            // 0x0270A9D4: B #0x270a940               |  goto label_141;                        
            goto label_141;
            label_139:
            // 0x0270A9D8: LDR x20, [x21, #0x70]      | X20 = val_37.Next + 120 + 112;          
            // 0x0270A9DC: B #0x270a940               |  goto label_141;                        
            goto label_141;
            // 0x0270A9E0: B #0x270a404               |  goto label_142;                        
            goto label_142;
            label_39:
            // 0x0270A9E4: ORR w0, wzr, #8            | W0 = 8(0x8);                            
            // 0x0270A9E8: BL #0x9802b0               | X0 = sub_9802B0( ?? 0x8, ????);         
            // 0x0270A9EC: LDR x8, [x19]              | X8 = val_36.X;                          
            // 0x0270A9F0: STR x8, [x0]               | mem[8] = val_36.X;                       //  dest_result_addr=8
            mem[8] = val_64;
            // 0x0270A9F4: ADRP x1, #0x3462000        | X1 = 54927360 (0x3462000);              
            // 0x0270A9F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0270A9FC: ADD x1, x1, #0xf8          | X1 = (54927360 + 248) = 54927608 (0x034620F8);
            // 0x0270AA00: BL #0x980e60               | X0 = sub_980E60( ?? 0x8, ????);         
            label_1:
            // 0x0270AA04: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x0270AA08: LDR x8, [x8, #0xe00]       | X8 = 1152921504750084096;               
            // 0x0270AA0C: LDR x0, [x8]               | X0 = typeof(Pathfinding.ClipperLib.ClipperException);
            System.Exception val_55 = null;
            // 0x0270AA10: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.ClipperLib.ClipperException), ????);
            // 0x0270AA14: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x0270AA18: LDR x8, [x8, #0xf50]       | X8 = (string**)(1152921509606880160)("AddPath: Open paths have been disabled.");
            // 0x0270AA1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0270AA20: MOV x19, x0                | X19 = 1152921504750084096 (0x100000000889A000);//ML01
            // 0x0270AA24: LDR x1, [x8]               | X1 = "AddPath: Open paths have been disabled.";
            // 0x0270AA28: BL #0x1c32b48              | .ctor(message:  "AddPath: Open paths have been disabled.");
            val_55 = new System.Exception(message:  "AddPath: Open paths have been disabled.");
            // 0x0270AA2C: ADRP x8, #0x3645000        | X8 = 56905728 (0x3645000);              
            // 0x0270AA30: LDR x8, [x8, #0xf50]       | X8 = 1152921509606880320;               
            // 0x0270AA34: MOV x0, x19                | X0 = 1152921504750084096 (0x100000000889A000);//ML01
            // 0x0270AA38: LDR x1, [x8]               | X1 = public System.Boolean Pathfinding.ClipperLib.ClipperBase::AddPath(System.Collections.Generic.List<Pathfinding.ClipperLib.IntPoint> pg, Pathfinding.ClipperLib.PolyType polyType, bool Closed);
            // 0x0270AA3C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.ClipperLib.ClipperException), ????);
            // 0x0270AA40: BL #0x2701d64              | X0 = ExecuteInternal();                 
            bool val_56 = ExecuteInternal();
            // 0x0270AA44: MOV x19, x0                | X19 = val_56;//m1                       
            val_63 = val_56;
            // 0x0270AA48: BL #0x980920               | X0 = sub_980920( ?? val_56, ????);      
            label_38:
            // 0x0270AA4C: MOV x0, x19                | X0 = val_56;//m1                        
            // 0x0270AA50: BL #0x980800               | X0 = sub_980800( ?? val_56, ????);      
            // 0x0270AA54: BL #0xab7a54               | X0 = label_Mihua_Assets_AssetUtil_LoadDataFromStreamPath_GL00AB7A54();
        
        }
        //
        // Offset in libil2cpp.so: 0x0270B140 (40939840), len: 8  VirtAddr: 0x0270B140 RVA: 0x0270B140 token: 100663346 methodIndex: 20761 delegateWrapperIndex: 0 methodInvoker: 0
        public bool AddPolygon(System.Collections.Generic.List<Pathfinding.ClipperLib.IntPoint> pg, Pathfinding.ClipperLib.PolyType polyType)
        {
            //
            // Disasemble & Code
            // 0x0270B140: ORR w3, wzr, #1            | W3 = 1(0x1);                            
            // 0x0270B144: B #0x2709f0c               | return this.AddPath(pg:  pg, polyType:  polyType, Closed:  true);
            return this.AddPath(pg:  pg, polyType:  polyType, Closed:  true);
        
        }
        //
        // Offset in libil2cpp.so: 0x027080B0 (40927408), len: 112  VirtAddr: 0x027080B0 RVA: 0x027080B0 token: 100663347 methodIndex: 20762 delegateWrapperIndex: 0 methodInvoker: 0
        internal bool Pt2IsBetweenPt1AndPt3(Pathfinding.ClipperLib.IntPoint pt1, Pathfinding.ClipperLib.IntPoint pt2, Pathfinding.ClipperLib.IntPoint pt3)
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            var val_6;
            // 0x027080B0: CMP x1, x5                 | STATE = COMPARE(pt1.X, pt3.X)           
            // 0x027080B4: B.NE #0x27080c4            | if (pt1.X != pt3.X) goto label_0;       
            if(pt1.X != pt3.X)
            {
                goto label_0;
            }
            // 0x027080B8: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_5 = 0;
            // 0x027080BC: CMP x2, x6                 | STATE = COMPARE(pt1.Y, pt3.Y)           
            // 0x027080C0: B.EQ #0x270811c            | if (pt1.Y == pt3.Y) goto label_5;       
            if(pt1.Y == pt3.Y)
            {
                goto label_5;
            }
            label_0:
            // 0x027080C4: CMP x2, x4                 | STATE = COMPARE(pt1.Y, pt2.Y)           
            // 0x027080C8: B.NE #0x27080d8            | if (pt1.Y != pt2.Y) goto label_2;       
            if(pt1.Y != pt2.Y)
            {
                goto label_2;
            }
            // 0x027080CC: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_5 = 0;
            // 0x027080D0: CMP x1, x3                 | STATE = COMPARE(pt1.X, pt2.X)           
            // 0x027080D4: B.EQ #0x270811c            | if (pt1.X == pt2.X) goto label_5;       
            if(pt1.X == pt2.X)
            {
                goto label_5;
            }
            label_2:
            // 0x027080D8: CMP x5, x3                 | STATE = COMPARE(pt3.X, pt2.X)           
            // 0x027080DC: B.NE #0x27080ec            | if (pt3.X != pt2.X) goto label_4;       
            if(pt3.X != pt2.X)
            {
                goto label_4;
            }
            // 0x027080E0: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_5 = 0;
            // 0x027080E4: CMP x6, x4                 | STATE = COMPARE(pt3.Y, pt2.Y)           
            // 0x027080E8: B.EQ #0x270811c            | if (pt3.Y == pt2.Y) goto label_5;       
            if(pt3.Y == pt2.Y)
            {
                goto label_5;
            }
            label_4:
            // 0x027080EC: CMP x1, x5                 | STATE = COMPARE(pt1.X, pt3.X)           
            // 0x027080F0: B.NE #0x2708104            | if (pt1.X != pt3.X) goto label_6;       
            if(pt1.X != pt3.X)
            {
                goto label_6;
            }
            // 0x027080F4: CMP x4, x2                 | STATE = COMPARE(pt2.Y, pt1.Y)           
            // 0x027080F8: CSET w8, gt                | W8 = pt2.Y > pt1.Y ? 1 : 0;             
            var val_1 = (pt2.Y > pt1.Y) ? 1 : 0;
            // 0x027080FC: CMP x4, x6                 | STATE = COMPARE(pt2.Y, pt3.Y)           
            // 0x02708100: B #0x2708110               |  goto label_7;                          
            goto label_7;
            label_6:
            // 0x02708104: CMP x3, x1                 | STATE = COMPARE(pt2.X, pt1.X)           
            // 0x02708108: CSET w8, gt                | W8 = pt2.X > pt1.X ? 1 : 0;             
            var val_2 = (pt2.X > pt1.X) ? 1 : 0;
            // 0x0270810C: CMP x3, x5                 | STATE = COMPARE(pt2.X, pt3.X)           
            label_7:
            // 0x02708110: CSET w9, lt                | W9 = pt2.X < pt3.X ? 1 : 0;             
            var val_3 = (pt2.X < pt3.X) ? 1 : 0;
            // 0x02708114: EOR w8, w8, w9             | W8 = (pt2.X > pt1.X ? 1 : 0 ^ pt2.X < pt3.X ? 1 : 0);
            val_2 = val_2 ^ val_3;
            // 0x02708118: EOR w0, w8, #1             | W0 = ((pt2.X > pt1.X ? 1 : 0 ^ pt2.X < pt3.X ? 1 : 0) ^ 1);
            val_5 = val_2 ^ 1;
            label_5:
            // 0x0270811C: RET                        |  return (System.Boolean)((pt2.X > pt1.X ? 1 : 0 ^ pt2.X < pt3.X ? 1 : 0) ^ 1);
            return (bool)val_5;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0270AA60 (40938080), len: 112  VirtAddr: 0x0270AA60 RVA: 0x0270AA60 token: 100663348 methodIndex: 20763 delegateWrapperIndex: 0 methodInvoker: 0
        private Pathfinding.ClipperLib.TEdge RemoveEdge(Pathfinding.ClipperLib.TEdge e)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.ClipperLib.TEdge val_1;
            //  | 
            Pathfinding.ClipperLib.TEdge val_2;
            // 0x0270AA60: STP x22, x21, [sp, #-0x30]! | stack[1152921509607401328] = ???;  stack[1152921509607401336] = ???;  //  dest_result_addr=1152921509607401328 |  dest_result_addr=1152921509607401336
            // 0x0270AA64: STP x20, x19, [sp, #0x10]  | stack[1152921509607401344] = ???;  stack[1152921509607401352] = ???;  //  dest_result_addr=1152921509607401344 |  dest_result_addr=1152921509607401352
            // 0x0270AA68: STP x29, x30, [sp, #0x20]  | stack[1152921509607401360] = ???;  stack[1152921509607401368] = ???;  //  dest_result_addr=1152921509607401360 |  dest_result_addr=1152921509607401368
            // 0x0270AA6C: ADD x29, sp, #0x20         | X29 = (1152921509607401328 + 32) = 1152921509607401360 (0x100000012A0E6790);
            // 0x0270AA70: MOV x19, x1                | X19 = e;//m1                            
            // 0x0270AA74: CBZ x19, #0x270aa84        | if (e == null) goto label_0;            
            if(e == null)
            {
                goto label_0;
            }
            // 0x0270AA78: MOV x20, x19               | X20 = e;//m1                            
            val_1 = e;
            // 0x0270AA7C: LDR x21, [x20, #0x78]!     | X21 = e.Prev; //P2                      
            val_2 = e.Prev;
            // 0x0270AA80: B #0x270aa94               |  goto label_1;                          
            goto label_1;
            label_0:
            // 0x0270AA84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270AA88: ORR w20, wzr, #0x78        | W20 = 120(0x78);                        
            val_1 = 120;
            // 0x0270AA8C: LDR x21, [x20]             | X21 = 0x600000001;                      
            val_2 = 1;
            // 0x0270AA90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x0270AA94: LDR x22, [x19, #0x70]      | X22 = e.Next; //P2                      
            // 0x0270AA98: CBNZ x21, #0x270aaa0       | if (0x600000001 != 0) goto label_2;     
            if(val_2 != 0)
            {
                goto label_2;
            }
            // 0x0270AA9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x0270AAA0: STR x22, [x21, #0x70]      | mem[25769803889] = e.Next;               //  dest_result_addr=25769803889
            mem[25769803889] = e.Next;
            // 0x0270AAA4: LDR x21, [x19, #0x70]      | X21 = e.Next; //P2                      
            // 0x0270AAA8: LDR x22, [x20]             | X22 = 0x600000001;                      
            // 0x0270AAAC: CBNZ x21, #0x270aab4       | if (e.Next != null) goto label_3;       
            if(e.Next != null)
            {
                goto label_3;
            }
            // 0x0270AAB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_3:
            // 0x0270AAB4: STR x22, [x21, #0x78]      | e.Next.Prev = 0x600000001;               //  dest_result_addr=0
            e.Next.Prev = val_1;
            // 0x0270AAB8: LDR x0, [x19, #0x70]       | X0 = e.Next; //P2                       
            // 0x0270AABC: STR xzr, [x20]             | mem[120] = 0x0;                          //  dest_result_addr=120
            mem[120] = 0;
            // 0x0270AAC0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0270AAC4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0270AAC8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0270AACC: RET                        |  return (Pathfinding.ClipperLib.TEdge)e.Next;
            return e.Next;
            //  |  // // {name=val_0, type=Pathfinding.ClipperLib.TEdge, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0270B148 (40939848), len: 112  VirtAddr: 0x0270B148 RVA: 0x0270B148 token: 100663349 methodIndex: 20764 delegateWrapperIndex: 0 methodInvoker: 0
        private Pathfinding.ClipperLib.TEdge GetLastHorz(Pathfinding.ClipperLib.TEdge Edge)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.ClipperLib.TEdge val_1;
            // 0x0270B148: STP x22, x21, [sp, #-0x30]! | stack[1152921509607546096] = ???;  stack[1152921509607546104] = ???;  //  dest_result_addr=1152921509607546096 |  dest_result_addr=1152921509607546104
            // 0x0270B14C: STP x20, x19, [sp, #0x10]  | stack[1152921509607546112] = ???;  stack[1152921509607546120] = ???;  //  dest_result_addr=1152921509607546112 |  dest_result_addr=1152921509607546120
            // 0x0270B150: STP x29, x30, [sp, #0x20]  | stack[1152921509607546128] = ???;  stack[1152921509607546136] = ???;  //  dest_result_addr=1152921509607546128 |  dest_result_addr=1152921509607546136
            // 0x0270B154: ADD x29, sp, #0x20         | X29 = (1152921509607546096 + 32) = 1152921509607546128 (0x100000012A109D10);
            // 0x0270B158: MOV x20, x1                | X20 = Edge;//m1                         
            // 0x0270B15C: MOV x19, x20               | X19 = Edge;//m1                         
            val_1 = Edge;
            // 0x0270B160: B #0x270b168               |  goto label_0;                          
            goto label_0;
            label_7:
            // 0x0270B164: LDR x19, [x19, #0x70]      | X19 = Edge.Next; //P2                   
            val_1 = Edge.Next;
            label_0:
            // 0x0270B168: CBNZ x19, #0x270b170       | if (Edge.Next != null) goto label_1;    
            if(val_1 != null)
            {
                goto label_1;
            }
            // 0x0270B16C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x0270B170: LDR w8, [x19, #0x6c]       | W8 = Edge.Next.OutIdx; //P2             
            // 0x0270B174: CMN w8, #2                 | STATE = COMPARE(Edge.Next.OutIdx, 0x2)  
            // 0x0270B178: B.EQ #0x270b1a4            | if (Edge.Next.OutIdx == 2) goto label_5;
            if(Edge.Next.OutIdx == 2)
            {
                goto label_5;
            }
            // 0x0270B17C: LDR x21, [x19, #0x70]      | X21 = Edge.Next.Next; //P2              
            // 0x0270B180: CMP x21, x20               | STATE = COMPARE(Edge.Next.Next, Edge)   
            // 0x0270B184: B.EQ #0x270b1a4            | if (Edge.Next.Next == Edge) goto label_5;
            if(Edge.Next.Next == Edge)
            {
                goto label_5;
            }
            // 0x0270B188: CBNZ x21, #0x270b190       | if (Edge.Next.Next != null) goto label_4;
            if(Edge.Next.Next != null)
            {
                goto label_4;
            }
            // 0x0270B18C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_4:
            // 0x0270B190: LDR x8, [x21, #0x48]       | 
            // 0x0270B194: CBNZ x8, #0x270b1a4        | if (Edge.Next.OutIdx != 0) goto label_5;
            if(Edge.Next.OutIdx != 0)
            {
                goto label_5;
            }
            // 0x0270B198: CBNZ x19, #0x270b164       | if (Edge.Next != null) goto label_7;    
            if(val_1 != null)
            {
                goto label_7;
            }
            // 0x0270B19C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270B1A0: B #0x270b164               |  goto label_7;                          
            goto label_7;
            label_5:
            // 0x0270B1A4: MOV x0, x19                | X0 = Edge.Next;//m1                     
            // 0x0270B1A8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0270B1AC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0270B1B0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0270B1B4: RET                        |  return (Pathfinding.ClipperLib.TEdge)Edge.Next;
            return (Pathfinding.ClipperLib.TEdge)val_1;
            //  |  // // {name=val_0, type=Pathfinding.ClipperLib.TEdge, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0270AD84 (40938884), len: 252  VirtAddr: 0x0270AD84 RVA: 0x0270AD84 token: 100663350 methodIndex: 20765 delegateWrapperIndex: 0 methodInvoker: 0
        private bool SharedVertWithPrevAtTop(Pathfinding.ClipperLib.TEdge Edge)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.ClipperLib.TEdge val_1;
            //  | 
            Pathfinding.ClipperLib.IntPoint val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            // 0x0270AD84: STP x26, x25, [sp, #-0x50]! | stack[1152921509607690832] = ???;  stack[1152921509607690840] = ???;  //  dest_result_addr=1152921509607690832 |  dest_result_addr=1152921509607690840
            // 0x0270AD88: STP x24, x23, [sp, #0x10]  | stack[1152921509607690848] = ???;  stack[1152921509607690856] = ???;  //  dest_result_addr=1152921509607690848 |  dest_result_addr=1152921509607690856
            // 0x0270AD8C: STP x22, x21, [sp, #0x20]  | stack[1152921509607690864] = ???;  stack[1152921509607690872] = ???;  //  dest_result_addr=1152921509607690864 |  dest_result_addr=1152921509607690872
            // 0x0270AD90: STP x20, x19, [sp, #0x30]  | stack[1152921509607690880] = ???;  stack[1152921509607690888] = ???;  //  dest_result_addr=1152921509607690880 |  dest_result_addr=1152921509607690888
            // 0x0270AD94: STP x29, x30, [sp, #0x40]  | stack[1152921509607690896] = ???;  stack[1152921509607690904] = ???;  //  dest_result_addr=1152921509607690896 |  dest_result_addr=1152921509607690904
            // 0x0270AD98: ADD x29, sp, #0x40         | X29 = (1152921509607690832 + 64) = 1152921509607690896 (0x100000012A12D290);
            // 0x0270AD9C: MOV x19, x1                | X19 = Edge;//m1                         
            // 0x0270ADA0: ORR w21, wzr, #0x10        | W21 = 16(0x10);                         
            // 0x0270ADA4: ORR w22, wzr, #0x18        | W22 = 24(0x18);                         
            // 0x0270ADA8: MOV x20, x19               | X20 = Edge;//m1                         
            val_1 = Edge;
            // 0x0270ADAC: B #0x270adb4               |  goto label_0;                          
            goto label_0;
            label_12:
            // 0x0270ADB0: LDR x20, [x20, #0x78]      | X20 = Edge.Prev; //P2                   
            val_1 = Edge.Prev;
            label_0:
            // 0x0270ADB4: CBNZ x20, #0x270adbc       | if (Edge.Prev != null) goto label_1;    
            if(val_1 != null)
            {
                goto label_1;
            }
            // 0x0270ADB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x0270ADBC: LDR x24, [x20, #0x78]      | X24 = Edge.Prev.Prev; //P2              
            // 0x0270ADC0: CMP x24, x19               | STATE = COMPARE(Edge.Prev.Prev, Edge)   
            // 0x0270ADC4: B.EQ #0x270ae40            | if (Edge.Prev.Prev == Edge) goto label_2;
            if(Edge.Prev.Prev == Edge)
            {
                goto label_2;
            }
            // 0x0270ADC8: LDP x26, x25, [x20, #0x30] | X26 = Edge.Prev.Top; //P2                //  | 
            // 0x0270ADCC: CBNZ x24, #0x270add4       | if (Edge.Prev.Prev != null) goto label_3;
            if(Edge.Prev.Prev != null)
            {
                goto label_3;
            }
            // 0x0270ADD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_3:
            // 0x0270ADD4: LDR x8, [x24, #0x30]       | X8 = Edge.Prev.Prev.Top; //P2           
            // 0x0270ADD8: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_3 = 0;
            // 0x0270ADDC: CMP x26, x8                | STATE = COMPARE(Edge.Prev.Top, Edge.Prev.Prev.Top)
            // 0x0270ADE0: B.NE #0x270ae4c            | if (Edge.Prev.Top != Edge.Prev.Prev.Top) goto label_13;
            if(Edge.Prev.Top != Edge.Prev.Prev.Top)
            {
                goto label_13;
            }
            // 0x0270ADE4: LDR x8, [x24, #0x38]       | 
            // 0x0270ADE8: CMP x25, x8                | STATE = COMPARE(X25, Edge.Prev.Prev.Top)
            // 0x0270ADEC: B.NE #0x270ae4c            | if (X25 != Edge.Prev.Prev.Top) goto label_13;
            if(X25 != Edge.Prev.Prev.Top)
            {
                goto label_13;
            }
            // 0x0270ADF0: CBZ x20, #0x270adfc        | if (Edge.Prev == null) goto label_6;    
            if(val_1 == null)
            {
                goto label_6;
            }
            // 0x0270ADF4: LDP x25, x24, [x20, #0x10] | X25 = Edge.Prev.Bot; //P2                //  | 
            val_2 = Edge.Prev.Bot;
            // 0x0270ADF8: B #0x270ae0c               |  goto label_7;                          
            goto label_7;
            label_6:
            // 0x0270ADFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270AE00: LDR x25, [x21]             | X25 = 0x100B70003;                      
            val_2 = 11993091;
            // 0x0270AE04: LDR x24, [x22]             | X24 = 0x9814C0;                         
            val_4 = 9966784;
            // 0x0270AE08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_7:
            // 0x0270AE0C: LDR x26, [x20, #0x78]      | X26 = Edge.Prev.Prev; //P2              
            // 0x0270AE10: CBNZ x26, #0x270ae18       | if (Edge.Prev.Prev != null) goto label_8;
            if(Edge.Prev.Prev != null)
            {
                goto label_8;
            }
            // 0x0270AE14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_8:
            // 0x0270AE18: LDR x8, [x26, #0x10]       | X8 = Edge.Prev.Prev.Bot; //P2           
            // 0x0270AE1C: ORR w23, wzr, #1           | W23 = 1(0x1);                           
            val_3 = 1;
            // 0x0270AE20: CMP x25, x8                | STATE = COMPARE(0x100B70003, Edge.Prev.Prev.Bot)
            // 0x0270AE24: B.NE #0x270ae4c            | if (val_2 != Edge.Prev.Prev.Bot) goto label_13;
            if(val_2 != Edge.Prev.Prev.Bot)
            {
                goto label_13;
            }
            // 0x0270AE28: LDR x8, [x26, #0x18]       | 
            // 0x0270AE2C: CMP x24, x8                | STATE = COMPARE(0x9814C0, Edge.Prev.Prev.Bot)
            // 0x0270AE30: B.NE #0x270ae4c            | if (val_4 != Edge.Prev.Prev.Bot) goto label_13;
            if(val_4 != Edge.Prev.Prev.Bot)
            {
                goto label_13;
            }
            // 0x0270AE34: CBNZ x20, #0x270adb0       | if (Edge.Prev != null) goto label_12;   
            if(val_1 != null)
            {
                goto label_12;
            }
            // 0x0270AE38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270AE3C: B #0x270adb0               |  goto label_12;                         
            goto label_12;
            label_2:
            // 0x0270AE40: ORR w23, wzr, #1           | W23 = 1(0x1);                           
            val_3 = 1;
            // 0x0270AE44: B #0x270ae4c               |  goto label_13;                         
            goto label_13;
            label_16:
            // 0x0270AE48: LDR x20, [x20, #0x70]      | X20 = Edge.Prev.Next; //P2              
            val_1 = Edge.Prev.Next;
            label_13:
            // 0x0270AE4C: CMP x20, x19               | STATE = COMPARE(Edge.Prev.Next, Edge)   
            // 0x0270AE50: B.EQ #0x270ae64            | if (val_1 == Edge) goto label_14;       
            if(val_1 == Edge)
            {
                goto label_14;
            }
            // 0x0270AE54: EOR w23, w23, #1           | W23 = (val_3 ^ 1);                      
            val_3 = val_3 ^ 1;
            // 0x0270AE58: CBNZ x20, #0x270ae48       | if (Edge.Prev.Next != null) goto label_16;
            if(val_1 != null)
            {
                goto label_16;
            }
            // 0x0270AE5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270AE60: B #0x270ae48               |  goto label_16;                         
            goto label_16;
            label_14:
            // 0x0270AE64: AND w0, w23, #1            | W0 = (val_3 & 1);                       
            var val_1 = val_3 & 1;
            // 0x0270AE68: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0270AE6C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0270AE70: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0270AE74: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0270AE78: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0270AE7C: RET                        |  return (System.Boolean)(val_3 & 1);    
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0270B1B8 (40939960), len: 288  VirtAddr: 0x0270B1B8 RVA: 0x0270B1B8 token: 100663351 methodIndex: 20766 delegateWrapperIndex: 0 methodInvoker: 0
        private bool SharedVertWithNextIsBot(Pathfinding.ClipperLib.TEdge Edge)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.ClipperLib.TEdge val_12;
            //  | 
            Pathfinding.ClipperLib.TEdge val_13;
            //  | 
            Pathfinding.ClipperLib.IntPoint val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            Pathfinding.ClipperLib.IntPoint val_17;
            //  | 
            var val_18;
            // 0x0270B1B8: STP x22, x21, [sp, #-0x30]! | stack[1152921509607856112] = ???;  stack[1152921509607856120] = ???;  //  dest_result_addr=1152921509607856112 |  dest_result_addr=1152921509607856120
            // 0x0270B1BC: STP x20, x19, [sp, #0x10]  | stack[1152921509607856128] = ???;  stack[1152921509607856136] = ???;  //  dest_result_addr=1152921509607856128 |  dest_result_addr=1152921509607856136
            // 0x0270B1C0: STP x29, x30, [sp, #0x20]  | stack[1152921509607856144] = ???;  stack[1152921509607856152] = ???;  //  dest_result_addr=1152921509607856144 |  dest_result_addr=1152921509607856152
            // 0x0270B1C4: ADD x29, sp, #0x20         | X29 = (1152921509607856112 + 32) = 1152921509607856144 (0x100000012A155810);
            // 0x0270B1C8: MOV x19, x1                | X19 = Edge;//m1                         
            // 0x0270B1CC: MOV x20, x19               | X20 = Edge;//m1                         
            val_12 = Edge;
            // 0x0270B1D0: B #0x270b1d8               |  goto label_0;                          
            goto label_0;
            label_8:
            // 0x0270B1D4: LDR x20, [x20, #0x78]      | X20 = Edge.Prev; //P2                   
            val_12 = Edge.Prev;
            label_0:
            // 0x0270B1D8: CBNZ x20, #0x270b1e0       | if (Edge.Prev != null) goto label_1;    
            if(val_12 != null)
            {
                goto label_1;
            }
            // 0x0270B1DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x0270B1E0: LDR x22, [x20, #0x78]      | X22 = Edge.Prev.Prev; //P2              
            val_13 = Edge.Prev.Prev;
            // 0x0270B1E4: CMP x22, x19               | STATE = COMPARE(Edge.Prev.Prev, Edge)   
            // 0x0270B1E8: B.EQ #0x270b2a0            | if (val_13 == Edge) goto label_2;       
            if(val_13 == Edge)
            {
                goto label_2;
            }
            // 0x0270B1EC: LDR x21, [x20, #0x70]      | X21 = Edge.Prev.Next; //P2              
            // 0x0270B1F0: CBNZ x21, #0x270b1fc       | if (Edge.Prev.Next != null) goto label_3;
            if(Edge.Prev.Next != null)
            {
                goto label_3;
            }
            // 0x0270B1F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270B1F8: LDR x22, [x20, #0x78]      | X22 = Edge.Prev.Prev; //P2              
            val_13 = Edge.Prev.Prev;
            label_3:
            // 0x0270B1FC: LDP x10, x11, [x21, #0x10] | X10 = Edge.Prev.Next.Bot; //P2           //  | 
            // 0x0270B200: LDP x8, x9, [x20, #0x10]   | X8 = Edge.Prev.Bot; //P2                 //  | 
            val_14 = Edge.Prev.Bot;
            // 0x0270B204: CMP x10, x8                | STATE = COMPARE(Edge.Prev.Next.Bot, Edge.Prev.Bot)
            // 0x0270B208: CSET w10, eq               | W10 = Edge.Prev.Next.Bot == val_14 ? 1 : 0;
            var val_1 = (Edge.Prev.Next.Bot == val_14) ? 1 : 0;
            // 0x0270B20C: CMP x11, x9                | STATE = COMPARE(X11, X9)                
            // 0x0270B210: CSET w11, eq               | W11 = X11 == X9 ? 1 : 0;                
            var val_2 = (X11 == X9) ? 1 : 0;
            // 0x0270B214: AND w21, w10, w11          | W21 = (Edge.Prev.Next.Bot == val_14 ? 1 : 0 & X11 == X9 ? 1 : 0);
            val_16 = val_1 & val_2;
            // 0x0270B218: CBNZ x22, #0x270b224       | if (Edge.Prev.Prev != null) goto label_4;
            if(val_13 != null)
            {
                goto label_4;
            }
            // 0x0270B21C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270B220: LDP x8, x9, [x20, #0x10]   | X8 = Edge.Prev.Bot; //P2                 //  | 
            val_14 = Edge.Prev.Bot;
            label_4:
            // 0x0270B224: LDP x10, x11, [x22, #0x10] | X10 = Edge.Prev.Prev.Bot; //P2           //  | 
            // 0x0270B228: CMP x10, x8                | STATE = COMPARE(Edge.Prev.Prev.Bot, Edge.Prev.Bot)
            // 0x0270B22C: CSET w8, eq                | W8 = Edge.Prev.Prev.Bot == val_14 ? 1 : 0;
            var val_3 = (Edge.Prev.Prev.Bot == val_14) ? 1 : 0;
            // 0x0270B230: CMP x11, x9                | STATE = COMPARE(X11 == X9 ? 1 : 0, X9)  
            // 0x0270B234: CSET w9, eq                | W9 = val_2 == X9 ? 1 : 0;               
            var val_4 = (val_2 == X9) ? 1 : 0;
            // 0x0270B238: AND w8, w8, w9             | W8 = (Edge.Prev.Prev.Bot == val_14 ? 1 : 0 & val_2 == X9 ? 1 : 0);
            val_3 = val_3 & val_4;
            // 0x0270B23C: CMP w21, w8                | STATE = COMPARE((Edge.Prev.Next.Bot == val_14 ? 1 : 0 & X11 == X9 ? 1 : 0), (Edge.Prev.Prev.Bot == val_14 ? 1 : 0 & val_2 == X9 ? 1 : 0))
            // 0x0270B240: B.NE #0x270b2ac            | if (val_16 != val_3) goto label_10;     
            if(val_16 != val_3)
            {
                goto label_10;
            }
            // 0x0270B244: LDR x21, [x20, #0x70]      | X21 = Edge.Prev.Next; //P2              
            // 0x0270B248: CBNZ x21, #0x270b250       | if (Edge.Prev.Next != null) goto label_6;
            if(Edge.Prev.Next != null)
            {
                goto label_6;
            }
            // 0x0270B24C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_6:
            // 0x0270B250: LDP x10, x11, [x21, #0x30] | X10 = Edge.Prev.Next.Top; //P2           //  | 
            // 0x0270B254: LDP x8, x9, [x20, #0x30]   | X8 = Edge.Prev.Top; //P2                 //  | 
            val_17 = Edge.Prev.Top;
            // 0x0270B258: LDR x21, [x20, #0x78]      | X21 = Edge.Prev.Prev; //P2              
            // 0x0270B25C: CMP x10, x8                | STATE = COMPARE(Edge.Prev.Next.Top, Edge.Prev.Top)
            // 0x0270B260: CSET w10, eq               | W10 = Edge.Prev.Next.Top == val_17 ? 1 : 0;
            var val_5 = (Edge.Prev.Next.Top == val_17) ? 1 : 0;
            // 0x0270B264: CMP x11, x9                | STATE = COMPARE(X11 == X9 ? 1 : 0, val_2 == X9 ? 1 : 0)
            // 0x0270B268: CSET w11, eq               | W11 = val_2 == val_4 ? 1 : 0;           
            var val_6 = (val_2 == val_4) ? 1 : 0;
            // 0x0270B26C: AND w22, w10, w11          | W22 = (Edge.Prev.Next.Top == val_17 ? 1 : 0 & val_2 == val_4 ? 1 : 0);
            var val_7 = val_5 & val_6;
            // 0x0270B270: CBNZ x21, #0x270b27c       | if (Edge.Prev.Prev != null) goto label_7;
            if(Edge.Prev.Prev != null)
            {
                goto label_7;
            }
            // 0x0270B274: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270B278: LDP x8, x9, [x20, #0x30]   | X8 = Edge.Prev.Top; //P2                 //  | 
            val_17 = Edge.Prev.Top;
            label_7:
            // 0x0270B27C: LDP x10, x11, [x21, #0x30] | X10 = Edge.Prev.Prev.Top; //P2           //  | 
            // 0x0270B280: CMP x10, x8                | STATE = COMPARE(Edge.Prev.Prev.Top, Edge.Prev.Top)
            // 0x0270B284: CSET w8, eq                | W8 = Edge.Prev.Prev.Top == val_17 ? 1 : 0;
            var val_8 = (Edge.Prev.Prev.Top == val_17) ? 1 : 0;
            // 0x0270B288: CMP x11, x9                | STATE = COMPARE(val_2 == val_4 ? 1 : 0, val_2 == X9 ? 1 : 0)
            // 0x0270B28C: CSET w9, eq                | W9 = val_6 == val_4 ? 1 : 0;            
            var val_9 = (val_6 == val_4) ? 1 : 0;
            // 0x0270B290: AND w21, w8, w9            | W21 = (Edge.Prev.Prev.Top == val_17 ? 1 : 0 & val_6 == val_4 ? 1 : 0);
            val_16 = val_8 & val_9;
            // 0x0270B294: CMP w22, w21               | STATE = COMPARE((Edge.Prev.Next.Top == val_17 ? 1 : 0 & val_2 == val_4 ? 1 : 0), (Edge.Prev.Prev.Top == val_17 ? 1 : 0 & val_6 == val_4 ? 1 : 0))
            // 0x0270B298: B.EQ #0x270b1d4            | if (val_7 == val_16) goto label_8;      
            if(val_7 == val_16)
            {
                goto label_8;
            }
            // 0x0270B29C: B #0x270b2ac               |  goto label_10;                         
            goto label_10;
            label_2:
            // 0x0270B2A0: ORR w21, wzr, #1           | W21 = 1(0x1);                           
            val_16 = 1;
            // 0x0270B2A4: B #0x270b2ac               |  goto label_10;                         
            goto label_10;
            label_13:
            // 0x0270B2A8: LDR x20, [x20, #0x70]      | X20 = Edge.Prev.Next; //P2              
            val_12 = Edge.Prev.Next;
            label_10:
            // 0x0270B2AC: CMP x20, x19               | STATE = COMPARE(Edge.Prev.Next, Edge)   
            // 0x0270B2B0: B.EQ #0x270b2c4            | if (val_12 == Edge) goto label_11;      
            if(val_12 == Edge)
            {
                goto label_11;
            }
            // 0x0270B2B4: EOR w21, w21, #1           | W21 = (val_16 ^ 1);                     
            val_16 = val_16 ^ 1;
            // 0x0270B2B8: CBNZ x20, #0x270b2a8       | if (Edge.Prev.Next != null) goto label_13;
            if(val_12 != null)
            {
                goto label_13;
            }
            // 0x0270B2BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270B2C0: B #0x270b2a8               |  goto label_13;                         
            goto label_13;
            label_11:
            // 0x0270B2C4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0270B2C8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0270B2CC: AND w0, w21, #1            | W0 = (val_16 & 1);                      
            var val_10 = val_16 & 1;
            // 0x0270B2D0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0270B2D4: RET                        |  return (System.Boolean)(val_16 & 1);   
            return (bool)val_10;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0270B2D8 (40940248), len: 256  VirtAddr: 0x0270B2D8 RVA: 0x0270B2D8 token: 100663352 methodIndex: 20767 delegateWrapperIndex: 0 methodInvoker: 0
        private bool MoreBelow(Pathfinding.ClipperLib.TEdge Edge)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.ClipperLib.IntPoint val_5;
            //  | 
            Pathfinding.ClipperLib.TEdge val_6;
            //  | 
            var val_7;
            //  | 
            Pathfinding.ClipperLib.TEdge val_8;
            //  | 
            var val_9;
            // 0x0270B2D8: STP x22, x21, [sp, #-0x30]! | stack[1152921509608029552] = ???;  stack[1152921509608029560] = ???;  //  dest_result_addr=1152921509608029552 |  dest_result_addr=1152921509608029560
            // 0x0270B2DC: STP x20, x19, [sp, #0x10]  | stack[1152921509608029568] = ???;  stack[1152921509608029576] = ???;  //  dest_result_addr=1152921509608029568 |  dest_result_addr=1152921509608029576
            // 0x0270B2E0: STP x29, x30, [sp, #0x20]  | stack[1152921509608029584] = ???;  stack[1152921509608029592] = ???;  //  dest_result_addr=1152921509608029584 |  dest_result_addr=1152921509608029592
            // 0x0270B2E4: ADD x29, sp, #0x20         | X29 = (1152921509608029552 + 32) = 1152921509608029584 (0x100000012A17FD90);
            // 0x0270B2E8: MOV x19, x1                | X19 = Edge;//m1                         
            // 0x0270B2EC: CBNZ x19, #0x270b2f4       | if (Edge != null) goto label_0;         
            if(Edge != null)
            {
                goto label_0;
            }
            // 0x0270B2F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x0270B2F4: LDR x8, [x19, #0x48]       | 
            // 0x0270B2F8: CBZ x8, #0x270b31c         | if (X8 == 0) goto label_8;              
            if(X8 == 0)
            {
                goto label_8;
            }
            // 0x0270B2FC: LDR x20, [x19, #0x70]      | X20 = Edge.Next; //P2                   
            // 0x0270B300: CBNZ x20, #0x270b308       | if (Edge.Next != null) goto label_2;    
            if(Edge.Next != null)
            {
                goto label_2;
            }
            // 0x0270B304: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x0270B308: LDR x8, [x20, #0x48]       | 
            // 0x0270B30C: CBZ x8, #0x270b348         | if (X8 == 0) goto label_12;             
            if(X8 == 0)
            {
                goto label_12;
            }
            // 0x0270B310: CBZ x19, #0x270b38c        | if (Edge == null) goto label_4;         
            if(Edge == null)
            {
                goto label_4;
            }
            // 0x0270B314: LDP x20, x21, [x19, #0x10] | X20 = Edge.Bot; //P2                     //  | 
            val_5 = Edge.Bot;
            // 0x0270B318: B #0x270b3a4               |  goto label_5;                          
            goto label_5;
            label_8:
            // 0x0270B31C: MOV x20, x19               | X20 = Edge;//m1                         
            val_7 = Edge;
            // 0x0270B320: CBNZ x20, #0x270b328       | if (Edge != null) goto label_6;         
            if(val_7 != null)
            {
                goto label_6;
            }
            // 0x0270B324: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_6:
            // 0x0270B328: LDR x21, [x20, #0x70]      | X21 = Edge.Next; //P2                   
            val_6 = Edge.Next;
            // 0x0270B32C: MOV x19, x21               | X19 = Edge.Next;//m1                    
            val_8 = val_6;
            // 0x0270B330: CBNZ x21, #0x270b33c       | if (Edge.Next != null) goto label_7;    
            if(val_6 != null)
            {
                goto label_7;
            }
            // 0x0270B334: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270B338: LDR x19, [x20, #0x70]      | X19 = Edge.Next; //P2                   
            val_8 = Edge.Next;
            label_7:
            // 0x0270B33C: LDR x8, [x21, #0x48]       | 
            // 0x0270B340: CBZ x8, #0x270b31c         | if (X8 == 0) goto label_8;              
            if(X8 == 0)
            {
                goto label_8;
            }
            // 0x0270B344: B #0x270b370               |  goto label_9;                          
            goto label_9;
            label_12:
            // 0x0270B348: MOV x20, x19               | X20 = Edge;//m1                         
            val_7 = Edge;
            // 0x0270B34C: CBNZ x20, #0x270b354       | if (Edge != null) goto label_10;        
            if(val_7 != null)
            {
                goto label_10;
            }
            // 0x0270B350: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_10:
            // 0x0270B354: LDR x21, [x20, #0x70]      | X21 = Edge.Next; //P2                   
            val_6 = Edge.Next;
            // 0x0270B358: MOV x19, x21               | X19 = Edge.Next;//m1                    
            val_8 = val_6;
            // 0x0270B35C: CBNZ x21, #0x270b368       | if (Edge.Next != null) goto label_11;   
            if(val_6 != null)
            {
                goto label_11;
            }
            // 0x0270B360: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270B364: LDR x19, [x20, #0x70]      | X19 = Edge.Next; //P2                   
            val_8 = Edge.Next;
            label_11:
            // 0x0270B368: LDR x8, [x21, #0x48]       | 
            // 0x0270B36C: CBZ x8, #0x270b348         | if (X8 == 0) goto label_12;             
            if(X8 == 0)
            {
                goto label_12;
            }
            label_9:
            // 0x0270B370: CBNZ x19, #0x270b378       | if (Edge.Next != null) goto label_13;   
            if(val_8 != null)
            {
                goto label_13;
            }
            // 0x0270B374: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_13:
            // 0x0270B378: LDR x8, [x19, #0x18]       | 
            // 0x0270B37C: LDR x9, [x20, #0x18]       | 
            // 0x0270B380: CMP x8, x9                 | STATE = COMPARE(X8, X9)                 
            // 0x0270B384: CSET w0, gt                | W0 = X8 > X9 ? 1 : 0;                   
            var val_1 = (X8 > X9) ? 1 : 0;
            // 0x0270B388: B #0x270b3c8               |  goto label_14;                         
            goto label_14;
            label_4:
            // 0x0270B38C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270B390: ORR w8, wzr, #0x10         | W8 = 16(0x10);                          
            // 0x0270B394: ORR w9, wzr, #0x18         | W9 = 24(0x18);                          
            // 0x0270B398: LDR x20, [x8]              | X20 = 0x100B70003;                      
            val_5 = 11993091;
            // 0x0270B39C: LDR x21, [x9]              | X21 = 0x9814C0;                         
            val_6 = 9966784;
            // 0x0270B3A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_5:
            // 0x0270B3A4: LDR x19, [x19, #0x70]      | X19 = Edge.Next; //P2                   
            val_8 = Edge.Next;
            // 0x0270B3A8: CBNZ x19, #0x270b3b0       | if (Edge.Next != null) goto label_15;   
            if(val_8 != null)
            {
                goto label_15;
            }
            // 0x0270B3AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_15:
            // 0x0270B3B0: LDP x8, x9, [x19, #0x30]   | X8 = Edge.Next.Top; //P2                 //  | 
            // 0x0270B3B4: CMP x20, x8                | STATE = COMPARE(0x100B70003, Edge.Next.Top)
            // 0x0270B3B8: CSET w8, eq                | W8 = val_5 == Edge.Next.Top ? 1 : 0;    
            var val_2 = (val_5 == Edge.Next.Top) ? 1 : 0;
            // 0x0270B3BC: CMP x21, x9                | STATE = COMPARE(0x9814C0, 0x18)         
            // 0x0270B3C0: CSET w9, eq                | W9 = val_6 == 24 ? 1 : 0;               
            var val_3 = (val_6 == 24) ? 1 : 0;
            // 0x0270B3C4: AND w0, w8, w9             | W0 = (val_5 == Edge.Next.Top ? 1 : 0 & val_6 == 24 ? 1 : 0);
            val_9 = val_2 & val_3;
            label_14:
            // 0x0270B3C8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0270B3CC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0270B3D0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0270B3D4: RET                        |  return (System.Boolean)(val_5 == Edge.Next.Top ? 1 : 0 & val_6 == 24 ? 1 : 0);
            return (bool)val_9;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0270B3D8 (40940504), len: 136  VirtAddr: 0x0270B3D8 RVA: 0x0270B3D8 token: 100663353 methodIndex: 20768 delegateWrapperIndex: 0 methodInvoker: 0
        private bool JustBeforeLocMin(Pathfinding.ClipperLib.TEdge Edge)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.ClipperLib.TEdge val_2;
            // 0x0270B3D8: STP x22, x21, [sp, #-0x30]! | stack[1152921509608182512] = ???;  stack[1152921509608182520] = ???;  //  dest_result_addr=1152921509608182512 |  dest_result_addr=1152921509608182520
            // 0x0270B3DC: STP x20, x19, [sp, #0x10]  | stack[1152921509608182528] = ???;  stack[1152921509608182536] = ???;  //  dest_result_addr=1152921509608182528 |  dest_result_addr=1152921509608182536
            // 0x0270B3E0: STP x29, x30, [sp, #0x20]  | stack[1152921509608182544] = ???;  stack[1152921509608182552] = ???;  //  dest_result_addr=1152921509608182544 |  dest_result_addr=1152921509608182552
            // 0x0270B3E4: ADD x29, sp, #0x20         | X29 = (1152921509608182512 + 32) = 1152921509608182544 (0x100000012A1A5310);
            // 0x0270B3E8: MOV x19, x1                | X19 = Edge;//m1                         
            // 0x0270B3EC: CBNZ x19, #0x270b3f4       | if (Edge != null) goto label_0;         
            if(Edge != null)
            {
                goto label_0;
            }
            // 0x0270B3F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x0270B3F4: LDR x8, [x19, #0x48]       | 
            // 0x0270B3F8: CBZ x8, #0x270b410         | if (X8 == 0) goto label_4;              
            if(X8 == 0)
            {
                goto label_4;
            }
            // 0x0270B3FC: MOV x1, x19                | X1 = Edge;//m1                          
            // 0x0270B400: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0270B404: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0270B408: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0270B40C: B #0x270b1b8               | return this.SharedVertWithNextIsBot(Edge:  Edge);
            return this.SharedVertWithNextIsBot(Edge:  Edge);
            label_4:
            // 0x0270B410: MOV x20, x19               | X20 = Edge;//m1                         
            // 0x0270B414: CBNZ x20, #0x270b41c       | if (Edge != null) goto label_2;         
            if(Edge != null)
            {
                goto label_2;
            }
            // 0x0270B418: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x0270B41C: LDR x21, [x20, #0x70]      | X21 = Edge.Next; //P2                   
            // 0x0270B420: MOV x19, x21               | X19 = Edge.Next;//m1                    
            val_2 = Edge.Next;
            // 0x0270B424: CBNZ x21, #0x270b430       | if (Edge.Next != null) goto label_3;    
            if(Edge.Next != null)
            {
                goto label_3;
            }
            // 0x0270B428: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270B42C: LDR x19, [x20, #0x70]      | X19 = Edge.Next; //P2                   
            val_2 = Edge.Next;
            label_3:
            // 0x0270B430: LDR x8, [x21, #0x48]       | 
            // 0x0270B434: CBZ x8, #0x270b410         | if (X8 == 0) goto label_4;              
            if(X8 == 0)
            {
                goto label_4;
            }
            // 0x0270B438: CBNZ x19, #0x270b440       | if (Edge.Next != null) goto label_5;    
            if(val_2 != null)
            {
                goto label_5;
            }
            // 0x0270B43C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_5:
            // 0x0270B440: LDR x8, [x19, #0x38]       | 
            // 0x0270B444: LDR x9, [x20, #0x18]       | 
            // 0x0270B448: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0270B44C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0270B450: CMP x8, x9                 | STATE = COMPARE(X8, X9)                 
            // 0x0270B454: CSET w0, lt                | W0 = X8 < X9 ? 1 : 0;                   
            var val_1 = (X8 < X9) ? 1 : 0;
            // 0x0270B458: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0270B45C: RET                        |  return (System.Boolean)X8 < X9 ? 1 : 0;
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0270B460 (40940640), len: 136  VirtAddr: 0x0270B460 RVA: 0x0270B460 token: 100663354 methodIndex: 20769 delegateWrapperIndex: 0 methodInvoker: 0
        private bool MoreAbove(Pathfinding.ClipperLib.TEdge Edge)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.ClipperLib.TEdge val_3;
            //  | 
            Pathfinding.ClipperLib.TEdge val_4;
            //  | 
            Pathfinding.ClipperLib.TEdge val_5;
            // 0x0270B460: STP x22, x21, [sp, #-0x30]! | stack[1152921509608327280] = ???;  stack[1152921509608327288] = ???;  //  dest_result_addr=1152921509608327280 |  dest_result_addr=1152921509608327288
            // 0x0270B464: STP x20, x19, [sp, #0x10]  | stack[1152921509608327296] = ???;  stack[1152921509608327304] = ???;  //  dest_result_addr=1152921509608327296 |  dest_result_addr=1152921509608327304
            // 0x0270B468: STP x29, x30, [sp, #0x20]  | stack[1152921509608327312] = ???;  stack[1152921509608327320] = ???;  //  dest_result_addr=1152921509608327312 |  dest_result_addr=1152921509608327320
            // 0x0270B46C: ADD x29, sp, #0x20         | X29 = (1152921509608327280 + 32) = 1152921509608327312 (0x100000012A1C8890);
            // 0x0270B470: MOV x19, x1                | X19 = Edge;//m1                         
            val_3 = Edge;
            // 0x0270B474: CBNZ x19, #0x270b47c       | if (Edge != null) goto label_0;         
            if(val_3 != null)
            {
                goto label_0;
            }
            // 0x0270B478: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x0270B47C: LDR x8, [x19, #0x48]       | 
            // 0x0270B480: CBZ x8, #0x270b4a8         | if (X8 == 0) goto label_1;              
            if(X8 == 0)
            {
                goto label_1;
            }
            // 0x0270B484: LDR x21, [x19, #0x70]      | X21 = Edge.Next; //P2                   
            // 0x0270B488: MOV x20, x21               | X20 = Edge.Next;//m1                    
            val_4 = Edge.Next;
            // 0x0270B48C: CBNZ x21, #0x270b498       | if (Edge.Next != null) goto label_2;    
            if(Edge.Next != null)
            {
                goto label_2;
            }
            // 0x0270B490: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270B494: LDR x20, [x19, #0x70]      | X20 = Edge.Next; //P2                   
            val_4 = Edge.Next;
            label_2:
            // 0x0270B498: LDR x8, [x21, #0x48]       | 
            // 0x0270B49C: CBNZ x8, #0x270b4c0        | if (X8 != 0) goto label_3;              
            if(X8 != 0)
            {
                goto label_3;
            }
            // 0x0270B4A0: MOV x1, x20                | X1 = Edge.Next;//m1                     
            val_5 = val_4;
            // 0x0270B4A4: B #0x270b4ac               |  goto label_4;                          
            goto label_4;
            label_1:
            // 0x0270B4A8: MOV x1, x19                | X1 = Edge;//m1                          
            val_5 = val_3;
            label_4:
            // 0x0270B4AC: BL #0x270b148              | X0 = this.GetLastHorz(Edge:  val_5 = val_3);
            Pathfinding.ClipperLib.TEdge val_1 = this.GetLastHorz(Edge:  val_5);
            // 0x0270B4B0: MOV x19, x0                | X19 = val_1;//m1                        
            val_3 = val_1;
            // 0x0270B4B4: CBNZ x19, #0x270b4bc       | if (val_1 != null) goto label_5;        
            if(val_3 != null)
            {
                goto label_5;
            }
            // 0x0270B4B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_5:
            // 0x0270B4BC: LDR x20, [x19, #0x70]      | X20 = val_1.Next; //P2                  
            val_4 = val_1.Next;
            label_3:
            // 0x0270B4C0: CBNZ x20, #0x270b4c8       | if (val_1.Next != null) goto label_6;   
            if(val_4 != null)
            {
                goto label_6;
            }
            // 0x0270B4C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_6:
            // 0x0270B4C8: LDR x8, [x20, #0x38]       | 
            // 0x0270B4CC: LDR x9, [x19, #0x38]       | 
            // 0x0270B4D0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0270B4D4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0270B4D8: CMP x8, x9                 | STATE = COMPARE(X8, X9)                 
            // 0x0270B4DC: CSET w0, lt                | W0 = X8 < X9 ? 1 : 0;                   
            var val_2 = (X8 < X9) ? 1 : 0;
            // 0x0270B4E0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0270B4E4: RET                        |  return (System.Boolean)X8 < X9 ? 1 : 0;
            return (bool)val_2;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0270AAD0 (40938192), len: 92  VirtAddr: 0x0270AAD0 RVA: 0x0270AAD0 token: 100663355 methodIndex: 20770 delegateWrapperIndex: 0 methodInvoker: 0
        private bool AllHorizontal(Pathfinding.ClipperLib.TEdge Edge)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.ClipperLib.TEdge val_1;
            //  | 
            var val_2;
            // 0x0270AAD0: STP x20, x19, [sp, #-0x20]! | stack[1152921509608472064] = ???;  stack[1152921509608472072] = ???;  //  dest_result_addr=1152921509608472064 |  dest_result_addr=1152921509608472072
            // 0x0270AAD4: STP x29, x30, [sp, #0x10]  | stack[1152921509608472080] = ???;  stack[1152921509608472088] = ???;  //  dest_result_addr=1152921509608472080 |  dest_result_addr=1152921509608472088
            // 0x0270AAD8: ADD x29, sp, #0x10         | X29 = (1152921509608472064 + 16) = 1152921509608472080 (0x100000012A1EBE10);
            // 0x0270AADC: MOV x19, x1                | X19 = Edge;//m1                         
            // 0x0270AAE0: CBNZ x19, #0x270aae8       | if (Edge != null) goto label_0;         
            if(Edge != null)
            {
                goto label_0;
            }
            // 0x0270AAE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x0270AAE8: LDR x8, [x19, #0x48]       | 
            // 0x0270AAEC: CBNZ x8, #0x270ab14        | if (X8 != 0) goto label_1;              
            if(X8 != 0)
            {
                goto label_1;
            }
            // 0x0270AAF0: LDR x20, [x19, #0x70]      | X20 = Edge.Next; //P2                   
            val_1 = Edge.Next;
            // 0x0270AAF4: B #0x270aafc               |  goto label_2;                          
            goto label_2;
            label_5:
            // 0x0270AAF8: LDR x20, [x20, #0x70]      | X20 = Edge.Next.Next; //P2              
            val_1 = Edge.Next.Next;
            label_2:
            // 0x0270AAFC: CMP x20, x19               | STATE = COMPARE(Edge.Next.Next, Edge)   
            // 0x0270AB00: B.EQ #0x270ab1c            | if (val_1 == Edge) goto label_3;        
            if(val_1 == Edge)
            {
                goto label_3;
            }
            // 0x0270AB04: CBNZ x20, #0x270ab0c       | if (Edge.Next.Next != null) goto label_4;
            if(val_1 != null)
            {
                goto label_4;
            }
            // 0x0270AB08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_4:
            // 0x0270AB0C: LDR x8, [x20, #0x48]       | 
            // 0x0270AB10: CBZ x8, #0x270aaf8         | if (X8 == 0) goto label_5;              
            if(X8 == 0)
            {
                goto label_5;
            }
            label_1:
            // 0x0270AB14: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_2 = 0;
            // 0x0270AB18: B #0x270ab20               |  goto label_6;                          
            goto label_6;
            label_3:
            // 0x0270AB1C: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_2 = 1;
            label_6:
            // 0x0270AB20: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0270AB24: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0270AB28: RET                        |  return (System.Boolean)true;           
            return (bool)val_2;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x02709E28 (40934952), len: 228  VirtAddr: 0x02709E28 RVA: 0x02709E28 token: 100663356 methodIndex: 20771 delegateWrapperIndex: 0 methodInvoker: 0
        private void SetDx(Pathfinding.ClipperLib.TEdge e)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.ClipperLib.IntPoint val_3;
            //  | 
            var val_4;
            // 0x02709E28: STP x22, x21, [sp, #-0x30]! | stack[1152921509608600432] = ???;  stack[1152921509608600440] = ???;  //  dest_result_addr=1152921509608600432 |  dest_result_addr=1152921509608600440
            // 0x02709E2C: STP x20, x19, [sp, #0x10]  | stack[1152921509608600448] = ???;  stack[1152921509608600456] = ???;  //  dest_result_addr=1152921509608600448 |  dest_result_addr=1152921509608600456
            // 0x02709E30: STP x29, x30, [sp, #0x20]  | stack[1152921509608600464] = ???;  stack[1152921509608600472] = ???;  //  dest_result_addr=1152921509608600464 |  dest_result_addr=1152921509608600472
            // 0x02709E34: ADD x29, sp, #0x20         | X29 = (1152921509608600432 + 32) = 1152921509608600464 (0x100000012A20B390);
            // 0x02709E38: MOV x19, x1                | X19 = e;//m1                            
            // 0x02709E3C: CBZ x19, #0x2709e5c        | if (e == null) goto label_0;            
            if(e == null)
            {
                goto label_0;
            }
            // 0x02709E40: LDP x8, x9, [x19, #0x30]   | X8 = e.Top; //P2                         //  | 
            // 0x02709E44: LDP x10, x11, [x19, #0x10] | X10 = e.Bot; //P2                        //  | 
            // 0x02709E48: SUB x20, x8, x10           | X20 = (e.Top - e.Bot);                  
            val_3 = e.Top - e.Bot;
            // 0x02709E4C: SUBS x21, x9, x11          | X21 = (X9 - X11);                       
            val_4 = X9 - X11;
            // 0x02709E50: STP x20, x21, [x19, #0x40] | e.Delta = (e.Top - e.Bot);  mem2[0] = (X9 - X11);  //  dest_result_addr=0 |  dest_result_addr=0
            e.Delta = val_3;
            mem2[0] = val_4;
            // 0x02709E54: B.EQ #0x2709ee8            | if ( == ) goto label_3;                 
            if()
            {
                goto label_3;
            }
            // 0x02709E58: B #0x2709ed4               |  goto label_2;                          
            goto label_2;
            label_0:
            // 0x02709E5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02709E60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02709E64: ORR w8, wzr, #0x30         | W8 = 48(0x30);                          
            // 0x02709E68: LDR x20, [x8]              | X20 = 0x38004000000000;                 
            // 0x02709E6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02709E70: ORR w8, wzr, #0x10         | W8 = 16(0x10);                          
            // 0x02709E74: LDR x8, [x8]               | X8 = 0x100B70003;                       
            // 0x02709E78: ORR w9, wzr, #0x40         | W9 = 64(0x40);                          
            // 0x02709E7C: SUB x8, x20, x8            | X8 = (0 - 11993091) = 15762869266743293 (0x38003EFF48FFFD);
            // 0x02709E80: STR x8, [x9]               | mem[64] = 0x38003EFF48FFFD;              //  dest_result_addr=64
            mem[64] = 15762869266743293;
            // 0x02709E84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02709E88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02709E8C: ORR w8, wzr, #0x38         | W8 = 56(0x38);                          
            // 0x02709E90: LDR x20, [x8]              | X20 = 0x19001A00400006;                 
            // 0x02709E94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02709E98: ORR w8, wzr, #0x18         | W8 = 24(0x18);                          
            // 0x02709E9C: LDR x8, [x8]               | X8 = 0x9814C0;                          
            // 0x02709EA0: SUB x8, x20, x8            | X8 = (4194310 - 9966784) = 7036986081143622 (0x190019FFA7EB46);
            // 0x02709EA4: MOVZ w20, #0x48            | W20 = 72 (0x48);//ML01                  
            // 0x02709EA8: STR x8, [x20]              | mem[72] = 0x190019FFA7EB46;              //  dest_result_addr=72
            mem[72] = 7036986081143622;
            // 0x02709EAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02709EB0: LDR x20, [x20]             | X20 = 0x190019FFA7EB46;                 
            // 0x02709EB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02709EB8: CBZ x20, #0x2709ee8        | if (0x190019FFA7EB46 == 0) goto label_3;
            if(mem[72] == 0)
            {
                goto label_3;
            }
            // 0x02709EBC: ORR w8, wzr, #0x40         | W8 = 64(0x40);                          
            // 0x02709EC0: LDR x20, [x8]              | X20 = 0x38003EFF48FFFD;                 
            val_3 = mem[64];
            // 0x02709EC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02709EC8: MOVZ w8, #0x48             | W8 = 72 (0x48);//ML01                   
            // 0x02709ECC: LDR x21, [x8]              | X21 = 0x190019FFA7EB46;                 
            val_4 = mem[72];
            // 0x02709ED0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x02709ED4: SCVTF d0, x20              | D0 = 1.57628692787364E+16;              
            double val_1 = 1.57628692787364E+16;
            // 0x02709ED8: SCVTF d1, x21              | D1 = 7.0369860869161E+15;               
            // 0x02709EDC: FDIV d0, d0, d1            | D0 = (1.57628692787364E+16 / 7.0369860869161E+15);
            val_1 = val_1 / (7.0369860869161E+15);
            // 0x02709EE0: STR d0, [x19, #0x50]       | e.Dx = (1.57628692787364E+16 / 7.0369860869161E+15);  //  dest_result_addr=0
            e.Dx = val_1;
            // 0x02709EE4: B #0x2709efc               |  goto label_4;                          
            goto label_4;
            label_3:
            // 0x02709EE8: MOVZ x8, #0xc7ef, lsl #48  | X8 = -4040010340728045568 (0xC7EF000000000000);//ML01
            // 0x02709EEC: MOVK x8, #0xf933, lsl #32  | X8 = -4039736343289397248 (0xC7EFF93300000000);
            // 0x02709EF0: MOVK x8, #0xc78c, lsl #16  | X8 = -4039736339941556224 (0xC7EFF933C78C0000);
            // 0x02709EF4: MOVK x8, #0xdfad           | X8 = -4039736339941498963 (0xC7EFF933C78CDFAD);
            // 0x02709EF8: STR x8, [x19, #0x50]       | e.Dx = -3.4E+38;                         //  dest_result_addr=0
            e.Dx = -3.4E+38;
            label_4:
            // 0x02709EFC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x02709F00: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x02709F04: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x02709F08: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0270B4E8 (40940776), len: 540  VirtAddr: 0x0270B4E8 RVA: 0x0270B4E8 token: 100663357 methodIndex: 20772 delegateWrapperIndex: 0 methodInvoker: 0
        private void DoMinimaLML(Pathfinding.ClipperLib.TEdge E1, Pathfinding.ClipperLib.TEdge E2, bool IsClosed)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.ClipperLib.TEdge val_4;
            //  | 
            Pathfinding.ClipperLib.TEdge val_5;
            //  | 
            Pathfinding.ClipperLib.LocalMinima val_6;
            //  | 
            var val_7;
            //  | 
            Pathfinding.ClipperLib.TEdge val_8;
            //  | 
            var val_9;
            // 0x0270B4E8: STP x24, x23, [sp, #-0x40]! | stack[1152921509608724704] = ???;  stack[1152921509608724712] = ???;  //  dest_result_addr=1152921509608724704 |  dest_result_addr=1152921509608724712
            // 0x0270B4EC: STP x22, x21, [sp, #0x10]  | stack[1152921509608724720] = ???;  stack[1152921509608724728] = ???;  //  dest_result_addr=1152921509608724720 |  dest_result_addr=1152921509608724728
            // 0x0270B4F0: STP x20, x19, [sp, #0x20]  | stack[1152921509608724736] = ???;  stack[1152921509608724744] = ???;  //  dest_result_addr=1152921509608724736 |  dest_result_addr=1152921509608724744
            // 0x0270B4F4: STP x29, x30, [sp, #0x30]  | stack[1152921509608724752] = ???;  stack[1152921509608724760] = ???;  //  dest_result_addr=1152921509608724752 |  dest_result_addr=1152921509608724760
            // 0x0270B4F8: ADD x29, sp, #0x30         | X29 = (1152921509608724704 + 48) = 1152921509608724752 (0x100000012A229910);
            // 0x0270B4FC: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
            // 0x0270B500: LDRB w8, [x20, #0x172]     | W8 = (bool)static_value_03743172;       
            // 0x0270B504: MOV w21, w3                | W21 = IsClosed;//m1                     
            val_4 = IsClosed;
            // 0x0270B508: MOV x22, x2                | X22 = E2;//m1                           
            // 0x0270B50C: MOV x23, x1                | X23 = E1;//m1                           
            val_5 = E1;
            // 0x0270B510: MOV x19, x0                | X19 = 1152921509608736768 (0x100000012A22C800);//ML01
            // 0x0270B514: TBNZ w8, #0, #0x270b530    | if (static_value_03743172 == true) goto label_0;
            // 0x0270B518: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x0270B51C: LDR x8, [x8, #0xb8]        | X8 = 0x2B90C40;                         
            // 0x0270B520: LDR w0, [x8]               | W0 = 0x19D4;                            
            // 0x0270B524: BL #0x2782188              | X0 = sub_2782188( ?? 0x19D4, ????);     
            // 0x0270B528: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0270B52C: STRB w8, [x20, #0x172]     | static_value_03743172 = true;            //  dest_result_addr=57946482
            label_0:
            // 0x0270B530: CBZ x23, #0x270b560        | if (E1 == null) goto label_1;           
            if(val_5 == null)
            {
                goto label_1;
            }
            // 0x0270B534: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x0270B538: LDR x8, [x8, #0xd8]        | X8 = 1152921504749711360;               
            // 0x0270B53C: LDR x0, [x8]               | X0 = typeof(Pathfinding.ClipperLib.LocalMinima);
            object val_1 = null;
            // 0x0270B540: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.ClipperLib.LocalMinima), ????);
            // 0x0270B544: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0270B548: MOV x20, x0                | X20 = 1152921504749711360 (0x100000000883F000);//ML01
            val_6 = val_1;
            // 0x0270B54C: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x0270B550: LDR x24, [x23, #0x18]      | 
            // 0x0270B554: CBZ x20, #0x270b5a0        | if ( == 0) goto label_2;                
            if(null == 0)
            {
                goto label_2;
            }
            // 0x0270B558: STR x24, [x20, #0x10]      | typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_10 = ???;  //  dest_result_addr=1152921504749711376
            typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_10 = ???;
            // 0x0270B55C: B #0x270b5b0               |  goto label_3;                          
            goto label_3;
            label_1:
            // 0x0270B560: CBZ x22, #0x270b66c        | if (E2 == null) goto label_4;           
            if(E2 == null)
            {
                goto label_4;
            }
            // 0x0270B564: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x0270B568: LDR x8, [x8, #0xd8]        | X8 = 1152921504749711360;               
            // 0x0270B56C: LDR x0, [x8]               | X0 = typeof(Pathfinding.ClipperLib.LocalMinima);
            object val_2 = null;
            // 0x0270B570: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.ClipperLib.LocalMinima), ????);
            // 0x0270B574: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0270B578: MOV x20, x0                | X20 = 1152921504749711360 (0x100000000883F000);//ML01
            val_6 = val_2;
            // 0x0270B57C: BL #0x16f59f0              | .ctor();                                
            val_2 = new System.Object();
            // 0x0270B580: CBNZ x20, #0x270b588       | if ( != 0) goto label_5;                
            if(null != 0)
            {
                goto label_5;
            }
            // 0x0270B584: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_5:
            // 0x0270B588: STR xzr, [x20, #0x28]      | typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_28 = 0x0;  //  dest_result_addr=1152921504749711400
            typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_28 = 0;
            // 0x0270B58C: LDR x8, [x22, #0x18]       | 
            // 0x0270B590: STP x8, xzr, [x20, #0x10]  | typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_10 = 1152921504749711360;  typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_18 = 0x0;  //  dest_result_addr=1152921504749711376 |  dest_result_addr=1152921504749711384
            typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_10 = 1152921504749711360;
            typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_18 = 0;
            // 0x0270B594: STR wzr, [x22, #0x60]      | E2.WindDelta = 0;                        //  dest_result_addr=0
            E2.WindDelta = 0;
            // 0x0270B598: STR x22, [x20, #0x20]      | typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_20 = E2;  //  dest_result_addr=1152921504749711392
            typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_20 = E2;
            // 0x0270B59C: B #0x270b6e8               |  goto label_6;                          
            goto label_6;
            label_2:
            // 0x0270B5A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x0270B5A4: ORR w8, wzr, #0x10         | W8 = 16(0x10);                          
            // 0x0270B5A8: STR x24, [x8]              | mem[16] = ???;                           //  dest_result_addr=16
            mem[16] = ???;
            // 0x0270B5AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_3:
            // 0x0270B5B0: STR xzr, [x20, #0x28]      | typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_28 = 0x0;  //  dest_result_addr=1152921504749711400
            typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_28 = 0;
            // 0x0270B5B4: CBZ x22, #0x270b5c4        | if (E2 == null) goto label_7;           
            if(E2 == null)
            {
                goto label_7;
            }
            // 0x0270B5B8: LDR x8, [x22, #0x48]       | 
            // 0x0270B5BC: CBNZ x8, #0x270b5d4        | if (0x10 != 0) goto label_8;            
            if(16 != 0)
            {
                goto label_8;
            }
            // 0x0270B5C0: B #0x270b5f0               |  goto label_10;                         
            goto label_10;
            label_7:
            // 0x0270B5C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x0270B5C8: LDR x24, [x22, #0x48]      | 
            // 0x0270B5CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x0270B5D0: CBZ x24, #0x270b5f0        | if (X24 == 0) goto label_10;            
            if(X24 == 0)
            {
                goto label_10;
            }
            label_8:
            // 0x0270B5D4: LDR d0, [x22, #0x50]       | D0 = E2.Dx; //P2                        
            // 0x0270B5D8: LDR d1, [x23, #0x50]       | D1 = E1.Dx; //P2                        
            // 0x0270B5DC: ADD x24, x20, #0x18        | X24 = (val_6 + 24) = val_7 (0x100000000883F018);
            val_7 = 1152921504749711384;
            // 0x0270B5E0: FCMP d0, d1                | STATE = COMPARE(E2.Dx, E1.Dx)           
            // 0x0270B5E4: B.PL #0x270b618            | if (E2.Dx >= 0) goto label_11;          
            if(E2.Dx >= 0)
            {
                goto label_11;
            }
            // 0x0270B5E8: STP x23, x22, [x20, #0x18] | typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_18 = E1;  typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_20 = E2;  //  dest_result_addr=1152921504749711384 |  dest_result_addr=1152921504749711392
            typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_18 = val_5;
            typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_20 = E2;
            // 0x0270B5EC: B #0x270b61c               |  goto label_14;                         
            goto label_14;
            label_10:
            // 0x0270B5F0: LDR x8, [x22, #0x10]       | X8 = E2.Bot; //P2                       
            // 0x0270B5F4: LDR x9, [x23, #0x10]       | X9 = E1.Bot; //P2                       
            // 0x0270B5F8: CMP x8, x9                 | STATE = COMPARE(E2.Bot, E1.Bot)         
            // 0x0270B5FC: B.EQ #0x270b608            | if (E2.Bot == E1.Bot) goto label_13;    
            if(E2.Bot == E1.Bot)
            {
                goto label_13;
            }
            // 0x0270B600: MOV x1, x22                | X1 = E2;//m1                            
            // 0x0270B604: BL #0x270b7d0              | .ctor().ReverseHorizontal(e:  E2);      
            val_1.ReverseHorizontal(e:  E2);
            label_13:
            // 0x0270B608: MOV x24, x20               | X24 = 1152921504749711360 (0x100000000883F000);//ML01
            val_7 = val_6;
            // 0x0270B60C: STR x23, [x24, #0x18]!     | typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_18 = E1;  //  dest_result_addr=1152921504749711384
            typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_18 = val_5;
            // 0x0270B610: STR x22, [x24, #8]         | Pathfinding.ClipperLib.LocalMinima.__il2cppRuntimeField_namespaze.__il2cppRuntimeField_8 = E2;  //  dest_result_addr=1152921504749711392
            Pathfinding.ClipperLib.LocalMinima.__il2cppRuntimeField_namespaze.__il2cppRuntimeField_8 = E2;
            // 0x0270B614: B #0x270b61c               |  goto label_14;                         
            goto label_14;
            label_11:
            // 0x0270B618: STP x22, x23, [x20, #0x18] | typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_18 = E2;  typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_20 = E1;  //  dest_result_addr=1152921504749711384 |  dest_result_addr=1152921504749711392
            typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_18 = E2;
            typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_20 = val_5;
            label_14:
            // 0x0270B61C: LDR x22, [x24]             | X22 = E2;                               
            // 0x0270B620: CBNZ x22, #0x270b628       | if (E2 != 0) goto label_15;             
            if(val_7 != 0)
            {
                goto label_15;
            }
            // 0x0270B624: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_15:
            // 0x0270B628: STR wzr, [x22, #0x5c]      | mem2[0] = 0x0;                           //  dest_result_addr=0
            mem2[0] = 0;
            // 0x0270B62C: LDR x22, [x20, #0x20]      | X22 = E1;                               
            // 0x0270B630: CBNZ x22, #0x270b638       | if (E1 != 0) goto label_16;             
            if(typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_20 != 0)
            {
                goto label_16;
            }
            // 0x0270B634: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_16:
            // 0x0270B638: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0270B63C: STR w8, [x22, #0x5c]       | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x0270B640: LDR x22, [x24]             | X22 = E2;                               
            // 0x0270B644: CBNZ x22, #0x270b64c       | if (E2 != 0) goto label_17;             
            if(typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_18 != 0)
            {
                goto label_17;
            }
            // 0x0270B648: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_17:
            // 0x0270B64C: AND w8, w21, #1            | W8 = (IsClosed & 1);                    
            bool val_3 = val_4;
            // 0x0270B650: TBZ w8, #0, #0x270b664     | if ((IsClosed & 1) == false) goto label_18;
            if(val_3 == false)
            {
                goto label_18;
            }
            // 0x0270B654: LDR x21, [x22, #0x70]      | X21 = E2 + 112;                         
            // 0x0270B658: CBZ x20, #0x270b680        | if ( == 0) goto label_19;               
            if(null == 0)
            {
                goto label_19;
            }
            // 0x0270B65C: LDR x22, [x20, #0x20]      | X22 = E1;                               
            val_8 = typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_20;
            // 0x0270B660: B #0x270b68c               |  goto label_20;                         
            goto label_20;
            label_18:
            // 0x0270B664: STR wzr, [x22, #0x60]      | mem2[0] = 0x0;                           //  dest_result_addr=0
            mem2[0] = 0;
            // 0x0270B668: B #0x270b6b0               |  goto label_21;                         
            goto label_21;
            label_4:
            // 0x0270B66C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0270B670: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0270B674: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0270B678: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0270B67C: RET                        |  return;                                
            return;
            label_19:
            // 0x0270B680: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x0270B684: LDR x22, [x20, #0x20]      | X22 = E1;                               
            val_8 = typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_20;
            // 0x0270B688: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_20:
            // 0x0270B68C: LDR x23, [x24]             | X23 = E2;                               
            val_5 = typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_18;
            // 0x0270B690: CBNZ x23, #0x270b698       | if (E2 != 0) goto label_22;             
            if(val_5 != 0)
            {
                goto label_22;
            }
            // 0x0270B694: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_22:
            // 0x0270B698: CMP x21, x22               | STATE = COMPARE(E2 + 112, E1)           
            // 0x0270B69C: B.EQ #0x270b6a8            | if (E2 + 112 == val_8) goto label_23;   
            if((E2 + 112) == val_8)
            {
                goto label_23;
            }
            // 0x0270B6A0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            val_9 = 1;
            // 0x0270B6A4: B #0x270b6ac               |  goto label_24;                         
            goto label_24;
            label_23:
            // 0x0270B6A8: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
            val_9 = 0;
            label_24:
            // 0x0270B6AC: STR w8, [x23, #0x60]       | mem2[0] = 0x0;                           //  dest_result_addr=0
            mem2[0] = val_9;
            label_21:
            // 0x0270B6B0: CBZ x20, #0x270b6bc        | if ( == 0) goto label_25;               
            if(null == 0)
            {
                goto label_25;
            }
            // 0x0270B6B4: LDR x21, [x20, #0x20]      | X21 = E1;                               
            val_4 = typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_20;
            // 0x0270B6B8: B #0x270b6c8               |  goto label_26;                         
            goto label_26;
            label_25:
            // 0x0270B6BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x0270B6C0: LDR x21, [x20, #0x20]      | X21 = E1;                               
            val_4 = typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_20;
            // 0x0270B6C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_26:
            // 0x0270B6C8: LDR x22, [x24]             | X22 = E2;                               
            // 0x0270B6CC: CBNZ x22, #0x270b6d4       | if (E2 != 0) goto label_27;             
            if(typeof(Pathfinding.ClipperLib.LocalMinima).__il2cppRuntimeField_18 != 0)
            {
                goto label_27;
            }
            // 0x0270B6D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_27:
            // 0x0270B6D4: LDR w22, [x22, #0x60]      | W22 = E2 + 96;                          
            // 0x0270B6D8: CBNZ x21, #0x270b6e0       | if (E1 != 0) goto label_28;             
            if(val_4 != 0)
            {
                goto label_28;
            }
            // 0x0270B6DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_28:
            // 0x0270B6E0: NEG w8, w22                | W8 = -(E2 + 96);                        
            // 0x0270B6E4: STR w8, [x21, #0x60]       | mem2[0] = E2 + 96;                       //  dest_result_addr=0
            mem2[0] = -(E2 + 96);
            label_6:
            // 0x0270B6E8: MOV x0, x19                | X0 = 1152921509608736768 (0x100000012A22C800);//ML01
            // 0x0270B6EC: MOV x1, x20                | X1 = 1152921504749711360 (0x100000000883F000);//ML01
            // 0x0270B6F0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0270B6F4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0270B6F8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0270B6FC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0270B700: B #0x270b70c               | this.InsertLocalMinima(newLm:  val_6); return;
            this.InsertLocalMinima(newLm:  val_6);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0270B830 (40941616), len: 712  VirtAddr: 0x0270B830 RVA: 0x0270B830 token: 100663358 methodIndex: 20773 delegateWrapperIndex: 0 methodInvoker: 0
        private Pathfinding.ClipperLib.TEdge DescendToMin(ref Pathfinding.ClipperLib.TEdge E)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.ClipperLib.TEdge val_2;
            //  | 
            Pathfinding.ClipperLib.TEdge val_3;
            //  | 
            Pathfinding.ClipperLib.TEdge val_4;
            //  | 
            Pathfinding.ClipperLib.TEdge val_5;
            //  | 
            Pathfinding.ClipperLib.TEdge val_6;
            //  | 
            Pathfinding.ClipperLib.TEdge val_7;
            //  | 
            Pathfinding.ClipperLib.TEdge val_8;
            //  | 
            Pathfinding.ClipperLib.TEdge val_9;
            // 0x0270B830: STP x24, x23, [sp, #-0x40]! | stack[1152921509608865296] = ???;  stack[1152921509608865304] = ???;  //  dest_result_addr=1152921509608865296 |  dest_result_addr=1152921509608865304
            // 0x0270B834: STP x22, x21, [sp, #0x10]  | stack[1152921509608865312] = ???;  stack[1152921509608865320] = ???;  //  dest_result_addr=1152921509608865312 |  dest_result_addr=1152921509608865320
            // 0x0270B838: STP x20, x19, [sp, #0x20]  | stack[1152921509608865328] = ???;  stack[1152921509608865336] = ???;  //  dest_result_addr=1152921509608865328 |  dest_result_addr=1152921509608865336
            // 0x0270B83C: STP x29, x30, [sp, #0x30]  | stack[1152921509608865344] = ???;  stack[1152921509608865352] = ???;  //  dest_result_addr=1152921509608865344 |  dest_result_addr=1152921509608865352
            // 0x0270B840: ADD x29, sp, #0x30         | X29 = (1152921509608865296 + 48) = 1152921509608865344 (0x100000012A24BE40);
            // 0x0270B844: MOV x19, x1                | X19 = 1152921509608909360 (0x100000012A256A30);//ML01
            // 0x0270B848: LDR x20, [x19]             | X20 = E;                                
            // 0x0270B84C: CBNZ x20, #0x270b854       | if (E != null) goto label_0;            
            if(E != null)
            {
                goto label_0;
            }
            // 0x0270B850: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x0270B854: STR xzr, [x20, #0x80]      | NextInLML = null;                        //  dest_result_addr=0
            NextInLML = 0;
            // 0x0270B858: LDR x20, [x19]             | X20 = E;                                
            // 0x0270B85C: CBNZ x20, #0x270b864       | if (E != null) goto label_1;            
            if(E != null)
            {
                goto label_1;
            }
            // 0x0270B860: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x0270B864: LDR x8, [x20, #0x48]       |  //  not_find_field!1:72
            // 0x0270B868: CBNZ x8, #0x270b8cc        | if (mem[E + 72] != 0) goto label_9;     
            if((mem[E + 72]) != 0)
            {
                goto label_9;
            }
            // 0x0270B86C: MOV x21, x19               | X21 = 1152921509608909360 (0x100000012A256A30);//ML01
            label_5:
            // 0x0270B870: LDR x20, [x21]             | X20 = E;                                
            // 0x0270B874: CBNZ x20, #0x270b87c       | if (E != null) goto label_3;            
            if(E != null)
            {
                goto label_3;
            }
            // 0x0270B878: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_3:
            // 0x0270B87C: MOV x21, x20               | X21 = E;//m1                            
            // 0x0270B880: LDR x22, [x21, #0x70]!     | X22 = E.Next;                           
            // 0x0270B884: CBNZ x22, #0x270b88c       | if (E.Next != null) goto label_4;       
            if(E.Next != null)
            {
                goto label_4;
            }
            // 0x0270B888: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_4:
            // 0x0270B88C: LDR x8, [x22, #0x48]       |  //  not_find_field!1:72
            // 0x0270B890: CBZ x8, #0x270b870         | if (mem[E.Next + 72] == 0) goto label_5;
            if((mem[E.Next + 72]) == 0)
            {
                goto label_5;
            }
            // 0x0270B894: LDP x22, x21, [x20, #0x10] | X22 = E.Bot;                             //  |  not_find_field!1:24
            val_2 = mem[E + 16 + 8];
            // 0x0270B898: LDR x20, [x20, #0x70]      | X20 = E.Next;                           
            // 0x0270B89C: CBNZ x20, #0x270b8a4       | if (E.Next != null) goto label_6;       
            if(E.Next != null)
            {
                goto label_6;
            }
            // 0x0270B8A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_6:
            // 0x0270B8A4: LDR x8, [x20, #0x30]       | X8 = E.Next.Top;                        
            // 0x0270B8A8: CMP x22, x8                | STATE = COMPARE(E.Bot, E.Next.Top)      
            // 0x0270B8AC: B.NE #0x270b8bc            | if (E.Bot != E.Next.Top) goto label_7;  
            if(E.Bot != E.Next.Top)
            {
                goto label_7;
            }
            // 0x0270B8B0: LDR x8, [x20, #0x38]       |  //  not_find_field!1:56
            // 0x0270B8B4: CMP x21, x8                | STATE = COMPARE(mem[E + 16 + 8], mem[E.Next + 56])
            // 0x0270B8B8: B.EQ #0x270b8cc            | if (val_2 == mem[E.Next + 56]) goto label_9;
            if(val_2 == (mem[E.Next + 56]))
            {
                goto label_9;
            }
            label_7:
            // 0x0270B8BC: LDR x1, [x19]              | X1 = E;                                 
            // 0x0270B8C0: BL #0x270b7d0              | this.ReverseHorizontal(e:  E);          
            this.ReverseHorizontal(e:  E);
            // 0x0270B8C4: B #0x270b8cc               |  goto label_9;                          
            goto label_9;
            label_48:
            // 0x0270B8C8: STR x20, [x22, #0x80]      | mem2[0] = E.Next;                        //  dest_result_addr=0
            mem2[0] = E.Next;
            label_9:
            // 0x0270B8CC: LDR x20, [x19]             | X20 = E;                                
            // 0x0270B8D0: CBNZ x20, #0x270b8d8       | if (E != null) goto label_10;           
            if(E != null)
            {
                goto label_10;
            }
            // 0x0270B8D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_10:
            // 0x0270B8D8: LDR x20, [x20, #0x70]      | X20 = E.Next;                           
            // 0x0270B8DC: STR x20, [x19]             | E = E.Next;                              //  dest_result_addr=1152921509608909360
            E = E.Next;
            // 0x0270B8E0: CBNZ x20, #0x270b8e8       | if (E.Next != null) goto label_11;      
            if(E.Next != null)
            {
                goto label_11;
            }
            // 0x0270B8E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_11:
            // 0x0270B8E8: LDR w8, [x20, #0x6c]       | W8 = E.Next.OutIdx;                     
            // 0x0270B8EC: CMN w8, #2                 | STATE = COMPARE(E.Next.OutIdx, 0x2)     
            // 0x0270B8F0: B.EQ #0x270bad0            | if (E.Next.OutIdx == 2) goto label_30;  
            if(E.Next.OutIdx == 2)
            {
                goto label_30;
            }
            // 0x0270B8F4: LDR x21, [x19]             | X21 = E.Next;                           
            // 0x0270B8F8: MOV x20, x21               | X20 = E.Next;//m1                       
            val_3 = E;
            // 0x0270B8FC: CBNZ x21, #0x270b908       | if (E.Next != null) goto label_13;      
            if(E != null)
            {
                goto label_13;
            }
            // 0x0270B900: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270B904: LDR x20, [x19]             | X20 = E.Next;                           
            val_3 = E;
            label_13:
            // 0x0270B908: LDR x8, [x21, #0x48]       |  //  not_find_field!1:72
            // 0x0270B90C: CBZ x8, #0x270b948         | if (mem[E.Next + 72] == 0) goto label_14;
            if((mem[E.Next + 72]) == 0)
            {
                goto label_14;
            }
            // 0x0270B910: MOV x8, x20                | X8 = E.Next;//m1                        
            val_4 = val_3;
            // 0x0270B914: CBNZ x20, #0x270b924       | if (E.Next != null) goto label_15;      
            if(val_3 != null)
            {
                goto label_15;
            }
            // 0x0270B918: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270B91C: LDR x8, [x19]              | X8 = E.Next;                            
            val_4 = E;
            // 0x0270B920: CBZ x8, #0x270baf4         | if (E.Next == null) goto label_42;      
            if(val_4 == null)
            {
                goto label_42;
            }
            label_15:
            // 0x0270B924: LDR x20, [x20, #0x18]      |  //  not_find_field!1:24
            // 0x0270B928: LDR x21, [x8, #0x78]       | X21 = E.Next.Prev;                      
            val_2 = mem[E.Next + 120];
            val_2 = E.Next.Prev;
            // 0x0270B92C: CBNZ x21, #0x270b934       | if (E.Next.Prev != null) goto label_17; 
            if(val_2 != null)
            {
                goto label_17;
            }
            // 0x0270B930: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_17:
            // 0x0270B934: LDR x8, [x21, #0x18]       |  //  not_find_field!1:24
            // 0x0270B938: CMP x20, x8                | STATE = COMPARE(mem[E.Next + 24], mem[E.Next.Prev + 24])
            // 0x0270B93C: B.EQ #0x270bad0            | if (mem[E.Next + 24] == mem[E.Next.Prev + 24]) goto label_30;
            if((mem[E.Next + 24]) == (mem[E.Next.Prev + 24]))
            {
                goto label_30;
            }
            // 0x0270B940: LDR x22, [x19]             | X22 = E.Next;                           
            val_5 = E;
            // 0x0270B944: B #0x270bab0               |  goto label_37;                         
            goto label_37;
            label_14:
            // 0x0270B948: MOV x1, x20                | X1 = E.Next;//m1                        
            // 0x0270B94C: BL #0x270b148              | X0 = this.GetLastHorz(Edge:  val_3);    
            Pathfinding.ClipperLib.TEdge val_1 = this.GetLastHorz(Edge:  val_3);
            // 0x0270B950: LDR x21, [x19]             | X21 = E.Next;                           
            val_2 = E;
            // 0x0270B954: MOV x20, x0                | X20 = val_1;//m1                        
            val_6 = val_1;
            // 0x0270B958: CBNZ x21, #0x270b960       | if (E.Next != null) goto label_20;      
            if(val_2 != null)
            {
                goto label_20;
            }
            // 0x0270B95C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_20:
            // 0x0270B960: LDR x8, [x21, #0x78]       | X8 = E.Next.Prev;                       
            // 0x0270B964: CMP x20, x8                | STATE = COMPARE(val_1, E.Next.Prev)     
            // 0x0270B968: B.EQ #0x270bad0            | if (val_6 == E.Next.Prev) goto label_30;
            if(val_6 == E.Next.Prev)
            {
                goto label_30;
            }
            // 0x0270B96C: CBNZ x20, #0x270b974       | if (val_1 != null) goto label_22;       
            if(val_6 != null)
            {
                goto label_22;
            }
            // 0x0270B970: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_22:
            // 0x0270B974: LDR x21, [x20, #0x70]      | X21 = val_1.Next; //P2                  
            // 0x0270B978: CBNZ x21, #0x270b980       | if (val_1.Next != null) goto label_23;  
            if(val_1.Next != null)
            {
                goto label_23;
            }
            // 0x0270B97C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_23:
            // 0x0270B980: LDR x21, [x21, #0x38]      | 
            // 0x0270B984: LDR x22, [x19]             | X22 = E.Next;                           
            // 0x0270B988: CBNZ x22, #0x270b990       | if (E.Next != null) goto label_24;      
            if(E != null)
            {
                goto label_24;
            }
            // 0x0270B98C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_24:
            // 0x0270B990: LDR x8, [x22, #0x38]       |  //  not_find_field!1:56
            // 0x0270B994: CMP x21, x8                | STATE = COMPARE(val_1.Next, mem[E.Next + 56])
            // 0x0270B998: B.GE #0x270b9d8            | if (val_1.Next >= mem[E.Next + 56]) goto label_25;
            if(val_1.Next >= (mem[E.Next + 56]))
            {
                goto label_25;
            }
            // 0x0270B99C: CBNZ x20, #0x270b9a4       | if (val_1 != null) goto label_26;       
            if(val_6 != null)
            {
                goto label_26;
            }
            // 0x0270B9A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_26:
            // 0x0270B9A4: LDR x21, [x20, #0x70]      | X21 = val_1.Next; //P2                  
            // 0x0270B9A8: CBNZ x21, #0x270b9b0       | if (val_1.Next != null) goto label_27;  
            if(val_1.Next != null)
            {
                goto label_27;
            }
            // 0x0270B9AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_27:
            // 0x0270B9B0: LDR x21, [x21, #0x10]      | X21 = val_1.Next.Bot; //P2              
            val_2 = val_1.Next.Bot;
            // 0x0270B9B4: LDR x22, [x19]             | X22 = E.Next;                           
            // 0x0270B9B8: CBNZ x22, #0x270b9c0       | if (E.Next != null) goto label_28;      
            if(E != null)
            {
                goto label_28;
            }
            // 0x0270B9BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_28:
            // 0x0270B9C0: LDR x22, [x22, #0x78]      | X22 = E.Next.Prev;                      
            // 0x0270B9C4: CBNZ x22, #0x270b9cc       | if (E.Next.Prev != null) goto label_29; 
            if(E.Next.Prev != null)
            {
                goto label_29;
            }
            // 0x0270B9C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_29:
            // 0x0270B9CC: LDR x8, [x22, #0x10]       | X8 = E.Next.Prev.Bot;                   
            // 0x0270B9D0: CMP x21, x8                | STATE = COMPARE(val_1.Next.Bot, E.Next.Prev.Bot)
            // 0x0270B9D4: B.GT #0x270bad0            | if (val_2 > E.Next.Prev.Bot) goto label_30;
            if(val_2 > E.Next.Prev.Bot)
            {
                goto label_30;
            }
            label_25:
            // 0x0270B9D8: LDR x21, [x19]             | X21 = E.Next;                           
            // 0x0270B9DC: MOV x8, x21                | X8 = E.Next;//m1                        
            val_7 = E;
            // 0x0270B9E0: CBNZ x21, #0x270b9f0       | if (E.Next != null) goto label_31;      
            if(E != null)
            {
                goto label_31;
            }
            // 0x0270B9E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            // 0x0270B9E8: LDR x8, [x19]              | X8 = E.Next;                            
            val_7 = E;
            // 0x0270B9EC: CBZ x8, #0x270baf4         | if (E.Next == null) goto label_42;      
            if(val_7 == null)
            {
                goto label_42;
            }
            label_31:
            // 0x0270B9F0: LDR x21, [x21, #0x30]      | X21 = E.Next.Top;                       
            // 0x0270B9F4: LDR x22, [x8, #0x78]       | X22 = E.Next.Prev;                      
            // 0x0270B9F8: CBNZ x22, #0x270ba00       | if (E.Next.Prev != null) goto label_33; 
            if(E.Next.Prev != null)
            {
                goto label_33;
            }
            // 0x0270B9FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_33:
            // 0x0270BA00: LDR x8, [x22, #0x10]       | X8 = E.Next.Prev.Bot;                   
            // 0x0270BA04: CMP x21, x8                | STATE = COMPARE(E.Next.Top, E.Next.Prev.Bot)
            // 0x0270BA08: B.EQ #0x270ba14            | if (E.Next.Top == E.Next.Prev.Bot) goto label_34;
            if(E.Next.Top == E.Next.Prev.Bot)
            {
                goto label_34;
            }
            // 0x0270BA0C: LDR x1, [x19]              | X1 = E.Next;                            
            // 0x0270BA10: BL #0x270b7d0              | val_1.ReverseHorizontal(e:  E);         
            val_1.ReverseHorizontal(e:  E);
            label_34:
            // 0x0270BA14: CBNZ x20, #0x270ba1c       | if (val_1 != null) goto label_35;       
            if(val_6 != null)
            {
                goto label_35;
            }
            // 0x0270BA18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_35:
            // 0x0270BA1C: LDR w8, [x20, #0x6c]       | W8 = val_1.OutIdx; //P2                 
            // 0x0270BA20: CMN w8, #2                 | STATE = COMPARE(val_1.OutIdx, 0x2)      
            // 0x0270BA24: B.NE #0x270ba2c            | if (val_1.OutIdx != 2) goto label_36;   
            if(val_1.OutIdx != 2)
            {
                goto label_36;
            }
            // 0x0270BA28: LDR x20, [x20, #0x78]      | X20 = val_1.Prev; //P2                  
            val_6 = val_1.Prev;
            label_36:
            // 0x0270BA2C: LDR x22, [x19]             | X22 = E.Next;                           
            val_5 = E;
            // 0x0270BA30: CMP x22, x20               | STATE = COMPARE(E.Next, val_1.Prev)     
            // 0x0270BA34: B.EQ #0x270bab0            | if (val_5 == val_6) goto label_37;      
            if(val_5 == val_6)
            {
                goto label_37;
            }
            // 0x0270BA38: ORR w21, wzr, #0x78        | W21 = 120(0x78);                        
            label_45:
            // 0x0270BA3C: CBZ x22, #0x270ba48        | if (E.Next == null) goto label_38;      
            if(val_5 == null)
            {
                goto label_38;
            }
            // 0x0270BA40: LDR x23, [x22, #0x78]      | X23 = E.Next.Prev;                      
            val_8 = mem[E.Next + 120];
            val_8 = E.Next.Prev;
            // 0x0270BA44: B #0x270ba54               |  goto label_39;                         
            goto label_39;
            label_38:
            // 0x0270BA48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            // 0x0270BA4C: LDR x23, [x21]             | X23 = 0x600000001;                      
            val_8 = 1;
            // 0x0270BA50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_39:
            // 0x0270BA54: STR x23, [x22, #0x80]      | NextInLML = 0x600000001;                 //  dest_result_addr=0
            NextInLML = val_8;
            // 0x0270BA58: LDR x22, [x19]             | X22 = E.Next;                           
            // 0x0270BA5C: CBNZ x22, #0x270ba64       | if (E.Next != null) goto label_40;      
            if(E != null)
            {
                goto label_40;
            }
            // 0x0270BA60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_40:
            // 0x0270BA64: LDR x22, [x22, #0x70]      | X22 = E.Next.Next;                      
            // 0x0270BA68: MOV x8, x22                | X8 = E.Next.Next;//m1                   
            val_9 = E.Next.Next;
            // 0x0270BA6C: STR x22, [x19]             | E = E.Next.Next;                         //  dest_result_addr=1152921509608909360
            E = E.Next.Next;
            // 0x0270BA70: CBNZ x22, #0x270ba80       | if (E.Next.Next != null) goto label_41; 
            if(E.Next.Next != null)
            {
                goto label_41;
            }
            // 0x0270BA74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            // 0x0270BA78: LDR x8, [x19]              | X8 = E.Next.Next;                       
            val_9 = E;
            // 0x0270BA7C: CBZ x8, #0x270baf4         | if (E.Next.Next == null) goto label_42; 
            if(val_9 == null)
            {
                goto label_42;
            }
            label_41:
            // 0x0270BA80: LDR x22, [x22, #0x30]      | X22 = E.Next.Next.Top;                  
            // 0x0270BA84: LDR x23, [x8, #0x78]       | X23 = E.Next.Next.Prev;                 
            // 0x0270BA88: CBNZ x23, #0x270ba90       | if (E.Next.Next.Prev != null) goto label_43;
            if(E.Next.Next.Prev != null)
            {
                goto label_43;
            }
            // 0x0270BA8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_43:
            // 0x0270BA90: LDR x8, [x23, #0x10]       | X8 = E.Next.Next.Prev.Bot;              
            // 0x0270BA94: CMP x22, x8                | STATE = COMPARE(E.Next.Next.Top, E.Next.Next.Prev.Bot)
            // 0x0270BA98: B.EQ #0x270baa4            | if (E.Next.Next.Top == E.Next.Next.Prev.Bot) goto label_44;
            if(E.Next.Next.Top == E.Next.Next.Prev.Bot)
            {
                goto label_44;
            }
            // 0x0270BA9C: LDR x1, [x19]              | X1 = E.Next.Next;                       
            // 0x0270BAA0: BL #0x270b7d0              | val_1.ReverseHorizontal(e:  E);         
            val_1.ReverseHorizontal(e:  E);
            label_44:
            // 0x0270BAA4: LDR x22, [x19]             | X22 = E.Next.Next;                      
            val_5 = E;
            // 0x0270BAA8: CMP x22, x20               | STATE = COMPARE(E.Next.Next, val_1.Prev)
            // 0x0270BAAC: B.NE #0x270ba3c            | if (val_5 != val_6) goto label_45;      
            if(val_5 != val_6)
            {
                goto label_45;
            }
            label_37:
            // 0x0270BAB0: CBZ x22, #0x270babc        | if (E.Next.Next == null) goto label_46; 
            if(val_5 == null)
            {
                goto label_46;
            }
            // 0x0270BAB4: LDR x20, [x22, #0x78]      | X20 = E.Next.Next.Prev;                 
            // 0x0270BAB8: B #0x270b8c8               |  goto label_48;                         
            goto label_48;
            label_46:
            // 0x0270BABC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            // 0x0270BAC0: ORR w8, wzr, #0x78         | W8 = 120(0x78);                         
            // 0x0270BAC4: LDR x20, [x8]              | X20 = 0x600000001;                      
            // 0x0270BAC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            // 0x0270BACC: B #0x270b8c8               |  goto label_48;                         
            goto label_48;
            label_30:
            // 0x0270BAD0: LDR x19, [x19]             | X19 = E.Next.Next;                      
            // 0x0270BAD4: CBNZ x19, #0x270badc       | if (E.Next.Next != null) goto label_49; 
            if(E != null)
            {
                goto label_49;
            }
            // 0x0270BAD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_49:
            // 0x0270BADC: LDR x0, [x19, #0x78]       | X0 = E.Next.Next.Prev;                  
            // 0x0270BAE0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0270BAE4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0270BAE8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0270BAEC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0270BAF0: RET                        |  return (Pathfinding.ClipperLib.TEdge)E.Next.Next.Prev;
            return E.Next.Next.Prev;
            //  |  // // {name=val_0, type=Pathfinding.ClipperLib.TEdge, size=8, nGRN=0 }
            label_42:
            // 0x0270BAF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        
        }
        //
        // Offset in libil2cpp.so: 0x0270AB2C (40938284), len: 600  VirtAddr: 0x0270AB2C RVA: 0x0270AB2C token: 100663359 methodIndex: 20774 delegateWrapperIndex: 0 methodInvoker: 0
        private void AscendToMax(ref Pathfinding.ClipperLib.TEdge E, bool Appending, bool IsClosed)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.ClipperLib.TEdge val_5;
            //  | 
            Pathfinding.ClipperLib.TEdge val_6;
            //  | 
            Pathfinding.ClipperLib.TEdge val_7;
            //  | 
            Pathfinding.ClipperLib.TEdge val_8;
            //  | 
            Pathfinding.ClipperLib.TEdge val_9;
            //  | 
            Pathfinding.ClipperLib.TEdge val_10;
            // 0x0270AB2C: STP x26, x25, [sp, #-0x50]! | stack[1152921509609001712] = ???;  stack[1152921509609001720] = ???;  //  dest_result_addr=1152921509609001712 |  dest_result_addr=1152921509609001720
            // 0x0270AB30: STP x24, x23, [sp, #0x10]  | stack[1152921509609001728] = ???;  stack[1152921509609001736] = ???;  //  dest_result_addr=1152921509609001728 |  dest_result_addr=1152921509609001736
            // 0x0270AB34: STP x22, x21, [sp, #0x20]  | stack[1152921509609001744] = ???;  stack[1152921509609001752] = ???;  //  dest_result_addr=1152921509609001744 |  dest_result_addr=1152921509609001752
            // 0x0270AB38: STP x20, x19, [sp, #0x30]  | stack[1152921509609001760] = ???;  stack[1152921509609001768] = ???;  //  dest_result_addr=1152921509609001760 |  dest_result_addr=1152921509609001768
            // 0x0270AB3C: STP x29, x30, [sp, #0x40]  | stack[1152921509609001776] = ???;  stack[1152921509609001784] = ???;  //  dest_result_addr=1152921509609001776 |  dest_result_addr=1152921509609001784
            // 0x0270AB40: ADD x29, sp, #0x40         | X29 = (1152921509609001712 + 64) = 1152921509609001776 (0x100000012A26D330);
            // 0x0270AB44: MOV x19, x1                | X19 = 1152921509609045792 (0x100000012A277F20);//ML01
            // 0x0270AB48: LDR x23, [x19]             | X23 = E;                                
            // 0x0270AB4C: MOV w21, w3                | W21 = IsClosed;//m1                     
            // 0x0270AB50: MOV w22, w2                | W22 = Appending;//m1                    
            // 0x0270AB54: MOV x20, x0                | X20 = 1152921509609013792 (0x100000012A270220);//ML01
            // 0x0270AB58: CBNZ x23, #0x270ab60       | if (E != null) goto label_0;            
            if(E != null)
            {
                goto label_0;
            }
            // 0x0270AB5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x0270AB60: LDR w8, [x23, #0x6c]       | W8 = E.OutIdx;                          
            // 0x0270AB64: CMN w8, #2                 | STATE = COMPARE(E.OutIdx, 0x2)          
            // 0x0270AB68: B.NE #0x270ab94            | if (E.OutIdx != 2) goto label_1;        
            if(E.OutIdx != 2)
            {
                goto label_1;
            }
            // 0x0270AB6C: LDR x23, [x19]             | X23 = E;                                
            // 0x0270AB70: CBNZ x23, #0x270ab78       | if (E != null) goto label_2;            
            if(E != null)
            {
                goto label_2;
            }
            // 0x0270AB74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x0270AB78: LDR x23, [x23, #0x70]      | X23 = E.Next;                           
            val_5 = mem[E + 112];
            val_5 = E.Next;
            // 0x0270AB7C: STR x23, [x19]             | E = E.Next;                              //  dest_result_addr=1152921509609045792
            E = val_5;
            // 0x0270AB80: CBNZ x23, #0x270ab88       | if (E.Next != null) goto label_3;       
            if(val_5 != null)
            {
                goto label_3;
            }
            // 0x0270AB84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_3:
            // 0x0270AB88: LDR x1, [x23, #0x78]       | X1 = E.Next.Prev;                       
            // 0x0270AB8C: BL #0x270b460              | X0 = this.MoreAbove(Edge:  E.Next.Prev);
            bool val_1 = this.MoreAbove(Edge:  E.Next.Prev);
            // 0x0270AB90: TBZ w0, #0, #0x270ad68     | if (val_1 == false) goto label_4;       
            if(val_1 == false)
            {
                goto label_4;
            }
            label_1:
            // 0x0270AB94: LDR x23, [x19]             | X23 = E.Next;                           
            // 0x0270AB98: CBNZ x23, #0x270aba0       | if (E.Next != null) goto label_5;       
            if(E != null)
            {
                goto label_5;
            }
            // 0x0270AB9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_5:
            // 0x0270ABA0: LDR x8, [x23, #0x48]       |  //  not_find_field!1:72
            // 0x0270ABA4: CBNZ x8, #0x270abfc        | if (mem[E.Next + 72] != 0) goto label_12;
            if((mem[E.Next + 72]) != 0)
            {
                goto label_12;
            }
            // 0x0270ABA8: EOR w8, w22, #1            | W8 = (Appending ^ 1);                   
            bool val_2 = Appending ^ 1;
            // 0x0270ABAC: AND w8, w8, #1             | W8 = ((Appending ^ 1) & 1);             
            bool val_3 = val_2;
            // 0x0270ABB0: TBNZ w8, #0, #0x270abfc    | if (((Appending ^ 1) & 1) == true) goto label_12;
            if(val_3 == true)
            {
                goto label_12;
            }
            // 0x0270ABB4: LDR x23, [x19]             | X23 = E.Next;                           
            // 0x0270ABB8: MOV x8, x23                | X8 = E.Next;//m1                        
            val_6 = E;
            // 0x0270ABBC: CBNZ x23, #0x270abcc       | if (E.Next != null) goto label_8;       
            if(E != null)
            {
                goto label_8;
            }
            // 0x0270ABC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            // 0x0270ABC4: LDR x8, [x19]              | X8 = E.Next;                            
            val_6 = E;
            // 0x0270ABC8: CBZ x8, #0x270ad80         | if (E.Next == null) goto label_30;      
            if(val_6 == null)
            {
                goto label_30;
            }
            label_8:
            // 0x0270ABCC: LDP x25, x23, [x23, #0x10] | X25 = E.Next.Bot;                        //  |  not_find_field!1:24
            // 0x0270ABD0: LDR x24, [x8, #0x78]       | X24 = E.Next.Prev;                      
            // 0x0270ABD4: CBNZ x24, #0x270abdc       | if (E.Next.Prev != null) goto label_10; 
            if(E.Next.Prev != null)
            {
                goto label_10;
            }
            // 0x0270ABD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_10:
            // 0x0270ABDC: LDR x8, [x24, #0x10]       | X8 = E.Next.Prev.Bot;                   
            // 0x0270ABE0: CMP x25, x8                | STATE = COMPARE(E.Next.Bot, E.Next.Prev.Bot)
            // 0x0270ABE4: B.NE #0x270abf4            | if (E.Next.Bot != E.Next.Prev.Bot) goto label_11;
            if(E.Next.Bot != E.Next.Prev.Bot)
            {
                goto label_11;
            }
            // 0x0270ABE8: LDR x8, [x24, #0x18]       |  //  not_find_field!1:24
            // 0x0270ABEC: CMP x23, x8                | STATE = COMPARE(mem[E.Next + 16 + 8], mem[E.Next.Prev + 24])
            // 0x0270ABF0: B.EQ #0x270abfc            | if (mem[E.Next + 16 + 8] == mem[E.Next.Prev + 24]) goto label_12;
            if((mem[E.Next + 16 + 8]) == (mem[E.Next.Prev + 24]))
            {
                goto label_12;
            }
            label_11:
            // 0x0270ABF4: LDR x1, [x19]              | X1 = E.Next;                            
            // 0x0270ABF8: BL #0x270b7d0              | val_1.ReverseHorizontal(e:  E);         
            val_1.ReverseHorizontal(e:  E);
            label_12:
            // 0x0270ABFC: LDR x23, [x19]             | X23 = E.Next;                           
            val_5 = E;
            // 0x0270AC00: ORR w24, wzr, #0x70        | W24 = 112(0x70);                        
            // 0x0270AC04: MOV x25, x23               | X25 = E.Next;//m1                       
            val_7 = val_5;
            // 0x0270AC08: B #0x270ac10               |  goto label_13;                         
            goto label_13;
            label_33:
            // 0x0270AC0C: LDR x25, [x19]             | X25 = E.Next;                           
            val_7 = E;
            label_13:
            // 0x0270AC10: CBNZ x25, #0x270ac18       | if (E.Next != null) goto label_14;      
            if(val_7 != null)
            {
                goto label_14;
            }
            // 0x0270AC14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_14:
            // 0x0270AC18: LDR x25, [x25, #0x70]      | X25 = E.Next.Next;                      
            val_8 = mem[E.Next + 112];
            val_8 = E.Next.Next;
            // 0x0270AC1C: CBNZ x25, #0x270ac24       | if (E.Next.Next != null) goto label_15; 
            if(val_8 != null)
            {
                goto label_15;
            }
            // 0x0270AC20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_15:
            // 0x0270AC24: LDR w8, [x25, #0x6c]       | W8 = E.Next.Next.OutIdx;                
            // 0x0270AC28: CMN w8, #2                 | STATE = COMPARE(E.Next.Next.OutIdx, 0x2)
            // 0x0270AC2C: B.EQ #0x270ad08            | if (E.Next.Next.OutIdx == 2) goto label_23;
            if(E.Next.Next.OutIdx == 2)
            {
                goto label_23;
            }
            // 0x0270AC30: LDR x25, [x19]             | X25 = E.Next;                           
            // 0x0270AC34: CBNZ x25, #0x270ac3c       | if (E.Next != null) goto label_17;      
            if(E != null)
            {
                goto label_17;
            }
            // 0x0270AC38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_17:
            // 0x0270AC3C: LDR x25, [x25, #0x70]      | X25 = E.Next.Next;                      
            // 0x0270AC40: CBNZ x25, #0x270ac48       | if (E.Next.Next != null) goto label_18; 
            if(E.Next.Next != null)
            {
                goto label_18;
            }
            // 0x0270AC44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_18:
            // 0x0270AC48: LDR x25, [x25, #0x38]      |  //  not_find_field!1:56
            // 0x0270AC4C: LDR x26, [x19]             | X26 = E.Next;                           
            // 0x0270AC50: CBNZ x26, #0x270ac58       | if (E.Next != null) goto label_19;      
            if(E != null)
            {
                goto label_19;
            }
            // 0x0270AC54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_19:
            // 0x0270AC58: LDR x8, [x26, #0x38]       |  //  not_find_field!1:56
            // 0x0270AC5C: CMP x25, x8                | STATE = COMPARE(mem[E.Next.Next + 56], mem[E.Next + 56])
            // 0x0270AC60: B.NE #0x270ac84            | if (mem[E.Next.Next + 56] != mem[E.Next + 56]) goto label_20;
            if((mem[E.Next.Next + 56]) != (mem[E.Next + 56]))
            {
                goto label_20;
            }
            // 0x0270AC64: LDR x25, [x19]             | X25 = E.Next;                           
            // 0x0270AC68: CBNZ x25, #0x270ac70       | if (E.Next != null) goto label_21;      
            if(E != null)
            {
                goto label_21;
            }
            // 0x0270AC6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_21:
            // 0x0270AC70: LDR x25, [x25, #0x70]      | X25 = E.Next.Next;                      
            val_8 = mem[E.Next + 112];
            val_8 = E.Next.Next;
            // 0x0270AC74: CBNZ x25, #0x270ac7c       | if (E.Next.Next != null) goto label_22; 
            if(val_8 != null)
            {
                goto label_22;
            }
            // 0x0270AC78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_22:
            // 0x0270AC7C: LDR x8, [x25, #0x48]       |  //  not_find_field!1:72
            // 0x0270AC80: CBNZ x8, #0x270ad08        | if (mem[E.Next.Next + 72] != 0) goto label_23;
            if((mem[E.Next.Next + 72]) != 0)
            {
                goto label_23;
            }
            label_20:
            // 0x0270AC84: LDR x25, [x19]             | X25 = E.Next;                           
            // 0x0270AC88: CBZ x25, #0x270ac94        | if (E.Next == null) goto label_24;      
            if(E == null)
            {
                goto label_24;
            }
            // 0x0270AC8C: LDR x26, [x25, #0x70]      | X26 = E.Next.Next;                      
            val_9 = mem[E.Next + 112];
            val_9 = E.Next.Next;
            // 0x0270AC90: B #0x270aca0               |  goto label_25;                         
            goto label_25;
            label_24:
            // 0x0270AC94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            // 0x0270AC98: LDR x26, [x24]             | X26 = 0x10000;                          
            val_9 = 65536;
            // 0x0270AC9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_25:
            // 0x0270ACA0: STR x26, [x25, #0x80]      | NextInLML = 0x10000;                     //  dest_result_addr=0
            NextInLML = val_9;
            // 0x0270ACA4: LDR x25, [x19]             | X25 = E.Next;                           
            // 0x0270ACA8: CBNZ x25, #0x270acb0       | if (E.Next != null) goto label_26;      
            if(E != null)
            {
                goto label_26;
            }
            // 0x0270ACAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_26:
            // 0x0270ACB0: LDR x25, [x25, #0x70]      | X25 = E.Next.Next;                      
            // 0x0270ACB4: STR x25, [x19]             | E = E.Next.Next;                         //  dest_result_addr=1152921509609045792
            E = E.Next.Next;
            // 0x0270ACB8: CBNZ x25, #0x270acc0       | if (E.Next.Next != null) goto label_27; 
            if(E.Next.Next != null)
            {
                goto label_27;
            }
            // 0x0270ACBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_27:
            // 0x0270ACC0: LDR x8, [x25, #0x48]       |  //  not_find_field!1:72
            // 0x0270ACC4: CBNZ x8, #0x270ac0c        | if (mem[E.Next.Next + 72] != 0) goto label_33;
            if((mem[E.Next.Next + 72]) != 0)
            {
                goto label_33;
            }
            // 0x0270ACC8: LDR x25, [x19]             | X25 = E.Next.Next;                      
            // 0x0270ACCC: MOV x8, x25                | X8 = E.Next.Next;//m1                   
            val_10 = E;
            // 0x0270ACD0: CBNZ x25, #0x270ace0       | if (E.Next.Next != null) goto label_29; 
            if(E != null)
            {
                goto label_29;
            }
            // 0x0270ACD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            // 0x0270ACD8: LDR x8, [x19]              | X8 = E.Next.Next;                       
            val_10 = E;
            // 0x0270ACDC: CBZ x8, #0x270ad80         | if (E.Next.Next == null) goto label_30; 
            if(val_10 == null)
            {
                goto label_30;
            }
            label_29:
            // 0x0270ACE0: LDR x25, [x25, #0x10]      | X25 = E.Next.Next.Bot;                  
            // 0x0270ACE4: LDR x26, [x8, #0x78]       | X26 = E.Next.Next.Prev;                 
            // 0x0270ACE8: CBNZ x26, #0x270acf0       | if (E.Next.Next.Prev != null) goto label_31;
            if(E.Next.Next.Prev != null)
            {
                goto label_31;
            }
            // 0x0270ACEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_31:
            // 0x0270ACF0: LDR x8, [x26, #0x30]       | X8 = E.Next.Next.Prev.Top;              
            // 0x0270ACF4: CMP x25, x8                | STATE = COMPARE(E.Next.Next.Bot, E.Next.Next.Prev.Top)
            // 0x0270ACF8: B.EQ #0x270ac0c            | if (E.Next.Next.Bot == E.Next.Next.Prev.Top) goto label_33;
            if(E.Next.Next.Bot == E.Next.Next.Prev.Top)
            {
                goto label_33;
            }
            // 0x0270ACFC: LDR x1, [x19]              | X1 = E.Next.Next;                       
            // 0x0270AD00: BL #0x270b7d0              | val_1.ReverseHorizontal(e:  E);         
            val_1.ReverseHorizontal(e:  E);
            // 0x0270AD04: B #0x270ac0c               |  goto label_33;                         
            goto label_33;
            label_23:
            // 0x0270AD08: AND w8, w22, #1            | W8 = (Appending & 1);                   
            bool val_4 = Appending;
            // 0x0270AD0C: TBNZ w8, #0, #0x270ad54    | if ((Appending & 1) == true) goto label_38;
            if(val_4 == true)
            {
                goto label_38;
            }
            // 0x0270AD10: CBNZ x23, #0x270ad18       | if (E.Next != null) goto label_35;      
            if(val_5 != null)
            {
                goto label_35;
            }
            // 0x0270AD14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_35:
            // 0x0270AD18: LDR w8, [x23, #0x6c]       | W8 = E.Next.OutIdx;                     
            // 0x0270AD1C: CMN w8, #2                 | STATE = COMPARE(E.Next.OutIdx, 0x2)     
            // 0x0270AD20: B.NE #0x270ad28            | if (E.Next.OutIdx != 2) goto label_36;  
            if(E.Next.OutIdx != 2)
            {
                goto label_36;
            }
            // 0x0270AD24: LDR x23, [x23, #0x70]      | X23 = E.Next.Next;                      
            val_5 = mem[E.Next + 112];
            val_5 = E.Next.Next;
            label_36:
            // 0x0270AD28: LDR x22, [x19]             | X22 = E.Next.Next;                      
            // 0x0270AD2C: CBNZ x22, #0x270ad34       | if (E.Next.Next != null) goto label_37; 
            if(E != null)
            {
                goto label_37;
            }
            // 0x0270AD30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_37:
            // 0x0270AD34: LDR x8, [x22, #0x70]       | X8 = E.Next.Next.Next;                  
            // 0x0270AD38: CMP x23, x8                | STATE = COMPARE(E.Next.Next, E.Next.Next.Next)
            // 0x0270AD3C: B.EQ #0x270ad54            | if (val_5 == E.Next.Next.Next) goto label_38;
            if(val_5 == E.Next.Next.Next)
            {
                goto label_38;
            }
            // 0x0270AD40: AND w3, w21, #1            | W3 = (IsClosed & 1);                    
            IsClosed = IsClosed;
            // 0x0270AD44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0270AD48: MOV x0, x20                | X0 = 1152921509609013792 (0x100000012A270220);//ML01
            // 0x0270AD4C: MOV x2, x23                | X2 = E.Next.Next;//m1                   
            // 0x0270AD50: BL #0x270b4e8              | this.DoMinimaLML(E1:  0, E2:  val_5, IsClosed:  IsClosed = IsClosed);
            this.DoMinimaLML(E1:  0, E2:  val_5, IsClosed:  IsClosed);
            label_38:
            // 0x0270AD54: LDR x20, [x19]             | X20 = E.Next.Next;                      
            // 0x0270AD58: CBNZ x20, #0x270ad60       | if (E.Next.Next != null) goto label_39; 
            if(E != null)
            {
                goto label_39;
            }
            // 0x0270AD5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_39:
            // 0x0270AD60: LDR x8, [x20, #0x70]       | X8 = E.Next.Next.Next;                  
            // 0x0270AD64: STR x8, [x19]              | E = E.Next.Next.Next;                    //  dest_result_addr=1152921509609045792
            E = E.Next.Next.Next;
            label_4:
            // 0x0270AD68: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0270AD6C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0270AD70: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0270AD74: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0270AD78: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0270AD7C: RET                        |  return;                                
            return;
            label_30:
            // 0x0270AD80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        
        }
        //
        // Offset in libil2cpp.so: 0x0270AE80 (40939136), len: 704  VirtAddr: 0x0270AE80 RVA: 0x0270AE80 token: 100663360 methodIndex: 20775 delegateWrapperIndex: 0 methodInvoker: 0
        private Pathfinding.ClipperLib.TEdge AddBoundsToLML(Pathfinding.ClipperLib.TEdge E, bool Closed)
        {
            //
            // Disasemble & Code
            //  | 
            var val_16;
            //  | 
            Pathfinding.ClipperLib.TEdge val_17;
            //  | 
            Pathfinding.ClipperLib.TEdge val_18;
            //  | 
            var val_19;
            //  | 
            Pathfinding.ClipperLib.TEdge val_20;
            //  | 
            Pathfinding.ClipperLib.TEdge val_21;
            //  | 
            bool val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            //  | 
            var val_25;
            //  | 
            var val_26;
            // 0x0270AE80: STP x24, x23, [sp, #-0x40]! | stack[1152921509609134144] = ???;  stack[1152921509609134152] = ???;  //  dest_result_addr=1152921509609134144 |  dest_result_addr=1152921509609134152
            // 0x0270AE84: STP x22, x21, [sp, #0x10]  | stack[1152921509609134160] = ???;  stack[1152921509609134168] = ???;  //  dest_result_addr=1152921509609134160 |  dest_result_addr=1152921509609134168
            // 0x0270AE88: STP x20, x19, [sp, #0x20]  | stack[1152921509609134176] = ???;  stack[1152921509609134184] = ???;  //  dest_result_addr=1152921509609134176 |  dest_result_addr=1152921509609134184
            // 0x0270AE8C: STP x29, x30, [sp, #0x30]  | stack[1152921509609134192] = ???;  stack[1152921509609134200] = ???;  //  dest_result_addr=1152921509609134192 |  dest_result_addr=1152921509609134200
            // 0x0270AE90: ADD x29, sp, #0x30         | X29 = (1152921509609134144 + 48) = 1152921509609134192 (0x100000012A28D870);
            // 0x0270AE94: SUB sp, sp, #0x10          | SP = (1152921509609134144 - 16) = 1152921509609134128 (0x100000012A28D830);
            // 0x0270AE98: MOV w20, w2                | W20 = Closed;//m1                       
            // 0x0270AE9C: MOV x21, x1                | X21 = E;//m1                            
            // 0x0270AEA0: MOV x19, x0                | X19 = 1152921509609146208 (0x100000012A290760);//ML01
            val_16 = this;
            // 0x0270AEA4: STR x21, [sp, #8]          | stack[1152921509609134136] = E;          //  dest_result_addr=1152921509609134136
            // 0x0270AEA8: CBNZ x21, #0x270aeb0       | if (E != null) goto label_0;            
            if(E != null)
            {
                goto label_0;
            }
            // 0x0270AEAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x0270AEB0: LDR w8, [x21, #0x6c]       | W8 = E.OutIdx; //P2                     
            // 0x0270AEB4: CMN w8, #2                 | STATE = COMPARE(E.OutIdx, 0x2)          
            // 0x0270AEB8: B.NE #0x270aed0            | if (E.OutIdx != 2) goto label_1;        
            if(E.OutIdx != 2)
            {
                goto label_1;
            }
            // 0x0270AEBC: MOV x1, x21                | X1 = E;//m1                             
            // 0x0270AEC0: BL #0x270b2d8              | X0 = this.MoreBelow(Edge:  E);          
            bool val_1 = this.MoreBelow(Edge:  E);
            // 0x0270AEC4: TBZ w0, #0, #0x270aee0     | if (val_1 == false) goto label_2;       
            if(val_1 == false)
            {
                goto label_2;
            }
            // 0x0270AEC8: LDR x8, [x21, #0x70]       | X8 = E.Next; //P2                       
            // 0x0270AECC: STR x8, [sp, #8]           | stack[1152921509609134136] = E.Next;     //  dest_result_addr=1152921509609134136
            Pathfinding.ClipperLib.TEdge val_2 = E.Next;
            label_1:
            // 0x0270AED0: ADD x1, sp, #8             | X1 = (1152921509609134128 + 8) = 1152921509609134136 (0x100000012A28D838);
            // 0x0270AED4: BL #0x270b830              | X0 = val_1.DescendToMin(E: ref  Pathfinding.ClipperLib.TEdge val_2 = E.Next);
            Pathfinding.ClipperLib.TEdge val_3 = val_1.DescendToMin(E: ref  val_2);
            // 0x0270AED8: MOV x21, x0                | X21 = val_3;//m1                        
            val_17 = val_3;
            // 0x0270AEDC: B #0x270aee4               |  goto label_3;                          
            goto label_3;
            label_2:
            // 0x0270AEE0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_17 = 0;
            label_3:
            // 0x0270AEE4: LDR x22, [sp, #8]          | X22 = E.Next;                           
            // 0x0270AEE8: CBNZ x22, #0x270aef0       | if (E.Next != 0) goto label_4;          
            if(val_2 != 0)
            {
                goto label_4;
            }
            // 0x0270AEEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_4:
            // 0x0270AEF0: LDR w8, [x22, #0x6c]       | W8 = E.Next + 108;                      
            // 0x0270AEF4: CMN w8, #2                 | STATE = COMPARE(E.Next + 108, 0x2)      
            // 0x0270AEF8: B.NE #0x270af8c            | if (E.Next + 108 != 0x2) goto label_5;  
            if((E.Next + 108) != 2)
            {
                goto label_5;
            }
            // 0x0270AEFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0270AF00: AND w3, w20, #1            | W3 = (Closed & 1);                      
            bool val_4 = Closed;
            // 0x0270AF04: MOV x0, x19                | X0 = 1152921509609146208 (0x100000012A290760);//ML01
            // 0x0270AF08: MOV x2, x21                | X2 = 0 (0x0);//ML01                     
            // 0x0270AF0C: BL #0x270b4e8              | this.DoMinimaLML(E1:  0, E2:  val_17, IsClosed:  bool val_4 = Closed);
            this.DoMinimaLML(E1:  0, E2:  val_17, IsClosed:  val_4);
            // 0x0270AF10: LDR x21, [sp, #8]          | X21 = E.Next;                           
            // 0x0270AF14: MOV x8, x21                | X8 = E.Next;//m1                        
            val_18 = val_2;
            // 0x0270AF18: CBNZ x21, #0x270af28       | if (E.Next != 0) goto label_6;          
            if(val_2 != 0)
            {
                goto label_6;
            }
            // 0x0270AF1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270AF20: LDR x8, [sp, #8]           | X8 = E.Next;                            
            val_18 = val_2;
            // 0x0270AF24: CBZ x8, #0x270b13c         | if (E.Next == 0) goto label_36;         
            if(val_18 == 0)
            {
                goto label_36;
            }
            label_6:
            // 0x0270AF28: LDP x23, x21, [x21, #0x10] | X23 = E.Next + 16; X21 = E.Next + 16 + 8; //  | 
            val_19 = mem[E.Next + 16];
            val_19 = E.Next + 16;
            // 0x0270AF2C: LDR x22, [x8, #0x78]       | X22 = E.Next + 120;                     
            // 0x0270AF30: CBNZ x22, #0x270af38       | if (E.Next + 120 != 0) goto label_8;    
            if((E.Next + 120) != 0)
            {
                goto label_8;
            }
            // 0x0270AF34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_8:
            // 0x0270AF38: LDR x8, [x22, #0x10]       | X8 = E.Next + 120 + 16;                 
            // 0x0270AF3C: CMP x23, x8                | STATE = COMPARE(E.Next + 16, E.Next + 120 + 16)
            // 0x0270AF40: B.NE #0x270af50            | if (val_19 != E.Next + 120 + 16) goto label_9;
            if(val_19 != (E.Next + 120 + 16))
            {
                goto label_9;
            }
            // 0x0270AF44: LDR x8, [x22, #0x18]       | X8 = E.Next + 120 + 24;                 
            // 0x0270AF48: CMP x21, x8                | STATE = COMPARE(E.Next + 16 + 8, E.Next + 120 + 24)
            // 0x0270AF4C: B.EQ #0x270afa8            | if (E.Next + 16 + 8 == E.Next + 120 + 24) goto label_11;
            if((E.Next + 16 + 8) == (E.Next + 120 + 24))
            {
                goto label_11;
            }
            label_9:
            // 0x0270AF50: LDR x1, [sp, #8]           | X1 = E.Next;                            
            // 0x0270AF54: BL #0x270b2d8              | X0 = this.MoreBelow(Edge:  val_2);      
            bool val_5 = this.MoreBelow(Edge:  val_2);
            // 0x0270AF58: TBZ w0, #0, #0x270afa8     | if (val_5 == false) goto label_11;      
            if(val_5 == false)
            {
                goto label_11;
            }
            // 0x0270AF5C: LDR x21, [sp, #8]          | X21 = E.Next;                           
            // 0x0270AF60: CBNZ x21, #0x270af68       | if (E.Next != 0) goto label_12;         
            if(val_2 != 0)
            {
                goto label_12;
            }
            // 0x0270AF64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_12:
            // 0x0270AF68: LDR x8, [x21, #0x70]       | X8 = E.Next + 112;                      
            // 0x0270AF6C: ADD x1, sp, #8             | X1 = (1152921509609134128 + 8) = 1152921509609134136 (0x100000012A28D838);
            // 0x0270AF70: STR x8, [sp, #8]           | stack[1152921509609134136] = E.Next + 112;  //  dest_result_addr=1152921509609134136
            Pathfinding.ClipperLib.TEdge val_6 = E.Next + 112;
            // 0x0270AF74: BL #0x270b830              | X0 = val_5.DescendToMin(E: ref  Pathfinding.ClipperLib.TEdge val_6 = E.Next + 112);
            Pathfinding.ClipperLib.TEdge val_7 = val_5.DescendToMin(E: ref  val_6);
            // 0x0270AF78: LDR x2, [sp, #8]           | X2 = E.Next + 112;                      
            val_20 = val_6;
            // 0x0270AF7C: MOV x1, x0                 | X1 = val_7;//m1                         
            val_21 = val_7;
            // 0x0270AF80: AND w3, w20, #1            | W3 = (Closed & 1);                      
            val_22 = Closed;
            // 0x0270AF84: MOV x0, x19                | X0 = 1152921509609146208 (0x100000012A290760);//ML01
            // 0x0270AF88: B #0x270af9c               |  goto label_13;                         
            goto label_13;
            label_5:
            // 0x0270AF8C: LDR x2, [sp, #8]           | X2 = E.Next + 112;                      
            val_20 = val_6;
            // 0x0270AF90: AND w3, w20, #1            | W3 = (Closed & 1);                      
            val_22 = Closed;
            // 0x0270AF94: MOV x0, x19                | X0 = 1152921509609146208 (0x100000012A290760);//ML01
            // 0x0270AF98: MOV x1, x21                | X1 = 0 (0x0);//ML01                     
            val_21 = val_17;
            label_13:
            // 0x0270AF9C: BL #0x270b4e8              | this.DoMinimaLML(E1:  val_21 = val_17, E2:  val_20 = val_6, IsClosed:  val_22 = Closed);
            this.DoMinimaLML(E1:  val_21, E2:  val_20, IsClosed:  val_22);
            // 0x0270AFA0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            val_23 = 1;
            // 0x0270AFA4: B #0x270afd4               |  goto label_17;                         
            goto label_17;
            label_11:
            // 0x0270AFA8: LDR x1, [sp, #8]           | X1 = E.Next + 112;                      
            // 0x0270AFAC: BL #0x270b3d8              | X0 = this.JustBeforeLocMin(Edge:  val_6);
            bool val_8 = this.JustBeforeLocMin(Edge:  val_6);
            // 0x0270AFB0: TBZ w0, #0, #0x270afd0     | if (val_8 == false) goto label_15;      
            if(val_8 == false)
            {
                goto label_15;
            }
            // 0x0270AFB4: LDR x21, [sp, #8]          | X21 = E.Next + 112;                     
            // 0x0270AFB8: CBNZ x21, #0x270afc0       | if (E.Next + 112 != 0) goto label_16;   
            if(val_6 != 0)
            {
                goto label_16;
            }
            // 0x0270AFBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_16:
            // 0x0270AFC0: LDR x8, [x21, #0x70]       | X8 = E.Next + 112 + 112;                
            // 0x0270AFC4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            val_23 = 0;
            // 0x0270AFC8: STR x8, [sp, #8]           | stack[1152921509609134136] = E.Next + 112 + 112;  //  dest_result_addr=1152921509609134136
            Pathfinding.ClipperLib.TEdge val_10 = E.Next + 112 + 112;
            // 0x0270AFCC: B #0x270afd4               |  goto label_17;                         
            goto label_17;
            label_15:
            // 0x0270AFD0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            val_23 = 0;
            label_17:
            // 0x0270AFD4: AND w3, w20, #1            | W3 = (Closed & 1);                      
            bool val_9 = Closed;
            // 0x0270AFD8: ADD x1, sp, #8             | X1 = (1152921509609134128 + 8) = 1152921509609134136 (0x100000012A28D838);
            // 0x0270AFDC: MOV x0, x19                | X0 = 1152921509609146208 (0x100000012A290760);//ML01
            // 0x0270AFE0: BL #0x270ab2c              | this.AscendToMax(E: ref  Pathfinding.ClipperLib.TEdge val_10 = E.Next + 112 + 112, Appending:  false, IsClosed:  bool val_9 = Closed);
            this.AscendToMax(E: ref  val_10, Appending:  false, IsClosed:  val_9);
            // 0x0270AFE4: LDR x21, [sp, #8]          | X21 = E.Next + 112 + 112;               
            val_24 = val_10;
            // 0x0270AFE8: CBNZ x21, #0x270aff0       | if (E.Next + 112 + 112 != 0) goto label_18;
            if(val_24 != 0)
            {
                goto label_18;
            }
            // 0x0270AFEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_18:
            // 0x0270AFF0: LDR w8, [x21, #0x6c]       | W8 = E.Next + 112 + 112 + 108;          
            // 0x0270AFF4: CMN w8, #2                 | STATE = COMPARE(E.Next + 112 + 112 + 108, 0x2)
            // 0x0270AFF8: B.NE #0x270b120            | if (E.Next + 112 + 112 + 108 != 0x2) goto label_39;
            if((E.Next + 112 + 112 + 108) != 2)
            {
                goto label_39;
            }
            // 0x0270AFFC: LDR x21, [sp, #8]          | X21 = E.Next + 112 + 112;               
            // 0x0270B000: MOV x8, x21                | X8 = E.Next + 112 + 112;//m1            
            val_25 = val_10;
            // 0x0270B004: CBNZ x21, #0x270b014       | if (E.Next + 112 + 112 != 0) goto label_20;
            if(val_10 != 0)
            {
                goto label_20;
            }
            // 0x0270B008: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270B00C: LDR x8, [sp, #8]           | X8 = E.Next + 112 + 112;                
            val_25 = val_10;
            // 0x0270B010: CBZ x8, #0x270b13c         | if (E.Next + 112 + 112 == 0) goto label_36;
            if(val_25 == 0)
            {
                goto label_36;
            }
            label_20:
            // 0x0270B014: LDP x23, x21, [x21, #0x30] | X23 = E.Next + 112 + 112 + 48; X21 = E.Next + 112 + 112 + 48 + 8; //  | 
            val_19 = mem[E.Next + 112 + 112 + 48];
            val_19 = E.Next + 112 + 112 + 48;
            val_24 = mem[E.Next + 112 + 112 + 48 + 8];
            val_24 = E.Next + 112 + 112 + 48 + 8;
            // 0x0270B018: LDR x22, [x8, #0x78]       | X22 = E.Next + 112 + 112 + 120;         
            // 0x0270B01C: CBNZ x22, #0x270b024       | if (E.Next + 112 + 112 + 120 != 0) goto label_22;
            if((E.Next + 112 + 112 + 120) != 0)
            {
                goto label_22;
            }
            // 0x0270B020: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_22:
            // 0x0270B024: LDR x8, [x22, #0x30]       | X8 = E.Next + 112 + 112 + 120 + 48;     
            // 0x0270B028: CMP x23, x8                | STATE = COMPARE(E.Next + 112 + 112 + 48, E.Next + 112 + 112 + 120 + 48)
            // 0x0270B02C: B.NE #0x270b03c            | if (val_19 != E.Next + 112 + 112 + 120 + 48) goto label_23;
            if(val_19 != (E.Next + 112 + 112 + 120 + 48))
            {
                goto label_23;
            }
            // 0x0270B030: LDR x8, [x22, #0x38]       | X8 = E.Next + 112 + 112 + 120 + 56;     
            // 0x0270B034: CMP x21, x8                | STATE = COMPARE(E.Next + 112 + 112 + 48 + 8, E.Next + 112 + 112 + 120 + 56)
            // 0x0270B038: B.EQ #0x270b120            | if (val_24 == E.Next + 112 + 112 + 120 + 56) goto label_39;
            if(val_24 == (E.Next + 112 + 112 + 120 + 56))
            {
                goto label_39;
            }
            label_23:
            // 0x0270B03C: LDR x1, [sp, #8]           | X1 = E.Next + 112 + 112;                
            // 0x0270B040: BL #0x270b460              | X0 = this.MoreAbove(Edge:  val_10);     
            bool val_11 = this.MoreAbove(Edge:  val_10);
            // 0x0270B044: LDR x22, [sp, #8]          | X22 = E.Next + 112 + 112;               
            // 0x0270B048: MOV w21, w0                | W21 = val_11;//m1                       
            val_24 = val_11;
            // 0x0270B04C: CBNZ x22, #0x270b054       | if (E.Next + 112 + 112 != 0) goto label_25;
            if(val_10 != 0)
            {
                goto label_25;
            }
            // 0x0270B050: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_25:
            // 0x0270B054: TBZ w21, #0, #0x270b078    | if (val_11 == false) goto label_26;     
            if(val_24 == false)
            {
                goto label_26;
            }
            // 0x0270B058: LDR x8, [x22, #0x70]       | X8 = E.Next + 112 + 112 + 112;          
            // 0x0270B05C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x0270B060: AND w3, w20, #1            | W3 = (Closed & 1);                      
            bool val_12 = Closed;
            // 0x0270B064: ADD x1, sp, #8             | X1 = (1152921509609134128 + 8) = 1152921509609134136 (0x100000012A28D838);
            // 0x0270B068: MOV x0, x19                | X0 = 1152921509609146208 (0x100000012A290760);//ML01
            // 0x0270B06C: STR x8, [sp, #8]           | stack[1152921509609134136] = E.Next + 112 + 112 + 112;  //  dest_result_addr=1152921509609134136
            Pathfinding.ClipperLib.TEdge val_13 = E.Next + 112 + 112 + 112;
            // 0x0270B070: BL #0x270ab2c              | this.AscendToMax(E: ref  Pathfinding.ClipperLib.TEdge val_13 = E.Next + 112 + 112 + 112, Appending:  false, IsClosed:  bool val_12 = Closed);
            this.AscendToMax(E: ref  val_13, Appending:  false, IsClosed:  val_12);
            // 0x0270B074: B #0x270b120               |  goto label_39;                         
            goto label_39;
            label_26:
            // 0x0270B078: LDP x20, x19, [x22, #0x30] | X20 = E.Next + 112 + 112 + 48; X19 = E.Next + 112 + 112 + 48 + 8; //  | 
            // 0x0270B07C: LDR x21, [sp, #8]          | X21 = E.Next + 112 + 112 + 112;         
            // 0x0270B080: CBNZ x21, #0x270b088       | if (E.Next + 112 + 112 + 112 != 0) goto label_28;
            if(val_13 != 0)
            {
                goto label_28;
            }
            // 0x0270B084: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_28:
            // 0x0270B088: LDR x21, [x21, #0x70]      | X21 = E.Next + 112 + 112 + 112 + 112;   
            val_24 = mem[E.Next + 112 + 112 + 112 + 112];
            val_24 = E.Next + 112 + 112 + 112 + 112;
            // 0x0270B08C: CBNZ x21, #0x270b094       | if (E.Next + 112 + 112 + 112 + 112 != 0) goto label_29;
            if(val_24 != 0)
            {
                goto label_29;
            }
            // 0x0270B090: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_29:
            // 0x0270B094: LDR x8, [x21, #0x30]       | X8 = E.Next + 112 + 112 + 112 + 112 + 48;
            // 0x0270B098: CMP x20, x8                | STATE = COMPARE(E.Next + 112 + 112 + 48, E.Next + 112 + 112 + 112 + 112 + 48)
            // 0x0270B09C: B.NE #0x270b0ac            | if (E.Next + 112 + 112 + 48 != E.Next + 112 + 112 + 112 + 112 + 48) goto label_30;
            if((E.Next + 112 + 112 + 48) != (E.Next + 112 + 112 + 112 + 112 + 48))
            {
                goto label_30;
            }
            // 0x0270B0A0: LDR x8, [x21, #0x38]       | X8 = E.Next + 112 + 112 + 112 + 112 + 56;
            // 0x0270B0A4: CMP x19, x8                | STATE = COMPARE(E.Next + 112 + 112 + 48 + 8, E.Next + 112 + 112 + 112 + 112 + 56)
            // 0x0270B0A8: B.EQ #0x270b10c            | if (E.Next + 112 + 112 + 48 + 8 == E.Next + 112 + 112 + 112 + 112 + 56) goto label_31;
            if((E.Next + 112 + 112 + 48 + 8) == (E.Next + 112 + 112 + 112 + 112 + 56))
            {
                goto label_31;
            }
            label_30:
            // 0x0270B0AC: LDR x19, [sp, #8]          | X19 = E.Next + 112 + 112 + 112;         
            // 0x0270B0B0: CBNZ x19, #0x270b0b8       | if (E.Next + 112 + 112 + 112 != 0) goto label_32;
            if(val_13 != 0)
            {
                goto label_32;
            }
            // 0x0270B0B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_32:
            // 0x0270B0B8: LDR x19, [x19, #0x70]      | X19 = E.Next + 112 + 112 + 112 + 112;   
            val_16 = mem[E.Next + 112 + 112 + 112 + 112];
            val_16 = E.Next + 112 + 112 + 112 + 112;
            // 0x0270B0BC: CBNZ x19, #0x270b0c4       | if (E.Next + 112 + 112 + 112 + 112 != 0) goto label_33;
            if(val_16 != 0)
            {
                goto label_33;
            }
            // 0x0270B0C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_33:
            // 0x0270B0C4: LDR x8, [x19, #0x48]       | X8 = E.Next + 112 + 112 + 112 + 112 + 72;
            // 0x0270B0C8: CBNZ x8, #0x270b120        | if (E.Next + 112 + 112 + 112 + 112 + 72 != 0) goto label_39;
            if((E.Next + 112 + 112 + 112 + 112 + 72) != 0)
            {
                goto label_39;
            }
            // 0x0270B0CC: LDR x19, [sp, #8]          | X19 = E.Next + 112 + 112 + 112;         
            // 0x0270B0D0: MOV x8, x19                | X8 = E.Next + 112 + 112 + 112;//m1      
            val_26 = val_13;
            // 0x0270B0D4: CBNZ x19, #0x270b0e4       | if (E.Next + 112 + 112 + 112 != 0) goto label_35;
            if(val_13 != 0)
            {
                goto label_35;
            }
            // 0x0270B0D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            // 0x0270B0DC: LDR x8, [sp, #8]           | X8 = E.Next + 112 + 112 + 112;          
            val_26 = val_13;
            // 0x0270B0E0: CBZ x8, #0x270b13c         | if (E.Next + 112 + 112 + 112 == 0) goto label_36;
            if(val_26 == 0)
            {
                goto label_36;
            }
            label_35:
            // 0x0270B0E4: LDP x21, x19, [x19, #0x30] | X21 = E.Next + 112 + 112 + 112 + 48; X19 = E.Next + 112 + 112 + 112 + 48 + 8; //  | 
            val_24 = mem[E.Next + 112 + 112 + 112 + 48];
            val_24 = E.Next + 112 + 112 + 112 + 48;
            val_16 = mem[E.Next + 112 + 112 + 112 + 48 + 8];
            val_16 = E.Next + 112 + 112 + 112 + 48 + 8;
            // 0x0270B0E8: LDR x20, [x8, #0x70]       | X20 = E.Next + 112 + 112 + 112 + 112;   
            // 0x0270B0EC: CBNZ x20, #0x270b0f4       | if (E.Next + 112 + 112 + 112 + 112 != 0) goto label_37;
            if((E.Next + 112 + 112 + 112 + 112) != 0)
            {
                goto label_37;
            }
            // 0x0270B0F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_37:
            // 0x0270B0F4: LDR x8, [x20, #0x10]       | X8 = E.Next + 112 + 112 + 112 + 112 + 16;
            // 0x0270B0F8: CMP x21, x8                | STATE = COMPARE(E.Next + 112 + 112 + 112 + 48, E.Next + 112 + 112 + 112 + 112 + 16)
            // 0x0270B0FC: B.NE #0x270b120            | if (val_24 != E.Next + 112 + 112 + 112 + 112 + 16) goto label_39;
            if(val_24 != (E.Next + 112 + 112 + 112 + 112 + 16))
            {
                goto label_39;
            }
            // 0x0270B100: LDR x8, [x20, #0x18]       | X8 = E.Next + 112 + 112 + 112 + 112 + 24;
            // 0x0270B104: CMP x19, x8                | STATE = COMPARE(E.Next + 112 + 112 + 112 + 48 + 8, E.Next + 112 + 112 + 112 + 112 + 24)
            // 0x0270B108: B.NE #0x270b120            | if (val_16 != E.Next + 112 + 112 + 112 + 112 + 24) goto label_39;
            if(val_16 != (E.Next + 112 + 112 + 112 + 112 + 24))
            {
                goto label_39;
            }
            label_31:
            // 0x0270B10C: LDR x19, [sp, #8]          | X19 = E.Next + 112 + 112 + 112;         
            val_16 = val_13;
            // 0x0270B110: CBNZ x19, #0x270b118       | if (E.Next + 112 + 112 + 112 != 0) goto label_40;
            if(val_16 != 0)
            {
                goto label_40;
            }
            // 0x0270B114: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_40:
            // 0x0270B118: LDR x8, [x19, #0x70]       | X8 = E.Next + 112 + 112 + 112 + 112;    
            // 0x0270B11C: STR x8, [sp, #8]           | stack[1152921509609134136] = E.Next + 112 + 112 + 112 + 112;  //  dest_result_addr=1152921509609134136
            label_39:
            // 0x0270B120: LDR x0, [sp, #8]           | X0 = E.Next + 112 + 112 + 112 + 112;    
            // 0x0270B124: SUB sp, x29, #0x30         | SP = (1152921509609134192 - 48) = 1152921509609134144 (0x100000012A28D840);
            // 0x0270B128: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0270B12C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0270B130: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0270B134: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0270B138: RET                        |  return (Pathfinding.ClipperLib.TEdge)E.Next + 112 + 112 + 112 + 112;
            return (Pathfinding.ClipperLib.TEdge)E.Next + 112 + 112 + 112 + 112;
            //  |  // // {name=val_0, type=Pathfinding.ClipperLib.TEdge, size=8, nGRN=0 }
            label_36:
            // 0x0270B13C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        
        }
        //
        // Offset in libil2cpp.so: 0x0270B70C (40941324), len: 196  VirtAddr: 0x0270B70C RVA: 0x0270B70C token: 100663361 methodIndex: 20776 delegateWrapperIndex: 0 methodInvoker: 0
        private void InsertLocalMinima(Pathfinding.ClipperLib.LocalMinima newLm)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.ClipperLib.LocalMinima val_1;
            //  | 
            Pathfinding.ClipperLib.LocalMinima val_2;
            // 0x0270B70C: STP x22, x21, [sp, #-0x30]! | stack[1152921509609291216] = ???;  stack[1152921509609291224] = ???;  //  dest_result_addr=1152921509609291216 |  dest_result_addr=1152921509609291224
            // 0x0270B710: STP x20, x19, [sp, #0x10]  | stack[1152921509609291232] = ???;  stack[1152921509609291240] = ???;  //  dest_result_addr=1152921509609291232 |  dest_result_addr=1152921509609291240
            // 0x0270B714: STP x29, x30, [sp, #0x20]  | stack[1152921509609291248] = ???;  stack[1152921509609291256] = ???;  //  dest_result_addr=1152921509609291248 |  dest_result_addr=1152921509609291256
            // 0x0270B718: ADD x29, sp, #0x20         | X29 = (1152921509609291216 + 32) = 1152921509609291248 (0x100000012A2B3DF0);
            // 0x0270B71C: MOV x20, x0                | X20 = 1152921509609303264 (0x100000012A2B6CE0);//ML01
            // 0x0270B720: LDR x21, [x20, #0x10]      | X21 = this.m_MinimaList; //P2           
            val_1 = this.m_MinimaList;
            // 0x0270B724: MOV x19, x1                | X19 = newLm;//m1                        
            // 0x0270B728: CBZ x21, #0x270b758        | if (this.m_MinimaList == null) goto label_0;
            if(val_1 == null)
            {
                goto label_0;
            }
            // 0x0270B72C: CBNZ x19, #0x270b73c       | if (newLm != null) goto label_1;        
            if(newLm != null)
            {
                goto label_1;
            }
            // 0x0270B730: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270B734: LDR x21, [x20, #0x10]      | X21 = this.m_MinimaList; //P2           
            val_1 = this.m_MinimaList;
            // 0x0270B738: CBZ x21, #0x270b7cc        | if (this.m_MinimaList == null) goto label_9;
            if(val_1 == null)
            {
                goto label_9;
            }
            label_1:
            // 0x0270B73C: LDR x8, [x19, #0x10]       | X8 = newLm.Y; //P2                      
            // 0x0270B740: LDR x9, [x21, #0x10]       | X9 = this.m_MinimaList.Y; //P2          
            // 0x0270B744: CMP x8, x9                 | STATE = COMPARE(newLm.Y, this.m_MinimaList.Y)
            // 0x0270B748: B.LT #0x270b764            | if (newLm.Y < this.m_MinimaList.Y) goto label_3;
            if(newLm.Y < this.m_MinimaList.Y)
            {
                goto label_3;
            }
            // 0x0270B74C: CBNZ x19, #0x270b754       | if (newLm != null) goto label_4;        
            if(newLm != null)
            {
                goto label_4;
            }
            // 0x0270B750: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_4:
            // 0x0270B754: STR x21, [x19, #0x28]      | newLm.Next = this.m_MinimaList;          //  dest_result_addr=0
            newLm.Next = val_1;
            label_0:
            // 0x0270B758: STR x19, [x20, #0x10]      | this.m_MinimaList = newLm;               //  dest_result_addr=1152921509609303280
            this.m_MinimaList = newLm;
            // 0x0270B75C: B #0x270b7bc               |  goto label_5;                          
            goto label_5;
            label_12:
            // 0x0270B760: LDR x21, [x21, #0x28]      | X21 = this.m_MinimaList.Next; //P2      
            val_1 = this.m_MinimaList.Next;
            label_3:
            // 0x0270B764: CBNZ x21, #0x270b76c       | if (this.m_MinimaList.Next != null) goto label_6;
            if(val_1 != null)
            {
                goto label_6;
            }
            // 0x0270B768: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_6:
            // 0x0270B76C: LDR x8, [x21, #0x28]       | X8 = this.m_MinimaList.Next.Next; //P2  
            val_2 = this.m_MinimaList.Next.Next;
            // 0x0270B770: CBZ x8, #0x270b7a0         | if (this.m_MinimaList.Next.Next == null) goto label_10;
            if(val_2 == null)
            {
                goto label_10;
            }
            // 0x0270B774: CBNZ x19, #0x270b784       | if (newLm != null) goto label_8;        
            if(newLm != null)
            {
                goto label_8;
            }
            // 0x0270B778: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270B77C: LDR x8, [x21, #0x28]       | X8 = this.m_MinimaList.Next.Next; //P2  
            val_2 = this.m_MinimaList.Next.Next;
            // 0x0270B780: CBZ x8, #0x270b7cc         | if (this.m_MinimaList.Next.Next == null) goto label_9;
            if(val_2 == null)
            {
                goto label_9;
            }
            label_8:
            // 0x0270B784: LDR x9, [x19, #0x10]       | X9 = newLm.Y; //P2                      
            // 0x0270B788: LDR x8, [x8, #0x10]        | X8 = this.m_MinimaList.Next.Next.Y; //P2 
            // 0x0270B78C: CMP x9, x8                 | STATE = COMPARE(newLm.Y, this.m_MinimaList.Next.Next.Y)
            // 0x0270B790: B.GE #0x270b7a0            | if (newLm.Y >= this.m_MinimaList.Next.Next.Y) goto label_10;
            if(newLm.Y >= this.m_MinimaList.Next.Next.Y)
            {
                goto label_10;
            }
            // 0x0270B794: CBNZ x21, #0x270b760       | if (this.m_MinimaList.Next != null) goto label_12;
            if(val_1 != null)
            {
                goto label_12;
            }
            // 0x0270B798: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270B79C: B #0x270b760               |  goto label_12;                         
            goto label_12;
            label_10:
            // 0x0270B7A0: CBNZ x21, #0x270b7a8       | if (this.m_MinimaList.Next != null) goto label_13;
            if(val_1 != null)
            {
                goto label_13;
            }
            // 0x0270B7A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_13:
            // 0x0270B7A8: LDR x20, [x21, #0x28]      | X20 = this.m_MinimaList.Next.Next; //P2 
            // 0x0270B7AC: CBNZ x19, #0x270b7b4       | if (newLm != null) goto label_14;       
            if(newLm != null)
            {
                goto label_14;
            }
            // 0x0270B7B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_14:
            // 0x0270B7B4: STR x20, [x19, #0x28]      | newLm.Next = this.m_MinimaList.Next.Next;  //  dest_result_addr=0
            newLm.Next = this.m_MinimaList.Next.Next;
            // 0x0270B7B8: STR x19, [x21, #0x28]      | this.m_MinimaList.Next.Next = newLm;     //  dest_result_addr=0
            this.m_MinimaList.Next.Next = newLm;
            label_5:
            // 0x0270B7BC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0270B7C0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0270B7C4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0270B7C8: RET                        |  return;                                
            return;
            label_9:
            // 0x0270B7CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        
        }
        //
        // Offset in libil2cpp.so: 0x02703EB0 (40910512), len: 20  VirtAddr: 0x02703EB0 RVA: 0x02703EB0 token: 100663362 methodIndex: 20777 delegateWrapperIndex: 0 methodInvoker: 0
        protected void PopLocalMinima()
        {
            //
            // Disasemble & Code
            // 0x02703EB0: LDR x8, [x0, #0x18]        | X8 = this.m_CurrentLM; //P2             
            // 0x02703EB4: CBZ x8, #0x2703ec0         | if (this.m_CurrentLM == null) goto label_0;
            if(this.m_CurrentLM == null)
            {
                goto label_0;
            }
            // 0x02703EB8: LDR x8, [x8, #0x28]        | X8 = this.m_CurrentLM.Next; //P2        
            // 0x02703EBC: STR x8, [x0, #0x18]        | this.m_CurrentLM = this.m_CurrentLM.Next;  //  dest_result_addr=1152921509609452152
            this.m_CurrentLM = this.m_CurrentLM.Next;
            label_0:
            // 0x02703EC0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0270B7D0 (40941520), len: 96  VirtAddr: 0x0270B7D0 RVA: 0x0270B7D0 token: 100663363 methodIndex: 20778 delegateWrapperIndex: 0 methodInvoker: 0
        private void ReverseHorizontal(Pathfinding.ClipperLib.TEdge e)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            var val_2;
            // 0x0270B7D0: STP x22, x21, [sp, #-0x30]! | stack[1152921509609564368] = ???;  stack[1152921509609564376] = ???;  //  dest_result_addr=1152921509609564368 |  dest_result_addr=1152921509609564376
            // 0x0270B7D4: STP x20, x19, [sp, #0x10]  | stack[1152921509609564384] = ???;  stack[1152921509609564392] = ???;  //  dest_result_addr=1152921509609564384 |  dest_result_addr=1152921509609564392
            // 0x0270B7D8: STP x29, x30, [sp, #0x20]  | stack[1152921509609564400] = ???;  stack[1152921509609564408] = ???;  //  dest_result_addr=1152921509609564400 |  dest_result_addr=1152921509609564408
            // 0x0270B7DC: ADD x29, sp, #0x20         | X29 = (1152921509609564368 + 32) = 1152921509609564400 (0x100000012A2F68F0);
            // 0x0270B7E0: MOV x19, x1                | X19 = e;//m1                            
            val_1 = e;
            // 0x0270B7E4: CBZ x19, #0x270b7f8        | if (e == null) goto label_0;            
            if(val_1 == null)
            {
                goto label_0;
            }
            // 0x0270B7E8: LDR x8, [x19, #0x10]!      | X8 = e.Bot; //P2                        
            // 0x0270B7EC: LDR x20, [x19, #0x20]      | X20 = e + 16 + 32;                      
            val_2 = mem[e + 16 + 32];
            val_2 = e + 16 + 32;
            // 0x0270B7F0: STR x8, [x19, #0x20]       | mem2[0] = e.Bot;                         //  dest_result_addr=0
            mem2[0] = e.Bot;
            // 0x0270B7F4: B #0x270b81c               |  goto label_1;                          
            goto label_1;
            label_0:
            // 0x0270B7F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270B7FC: ORR w21, wzr, #0x30        | W21 = 48(0x30);                         
            // 0x0270B800: LDR x20, [x21]             | X20 = 0x38004000000000;                 
            val_2 = 0;
            // 0x0270B804: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270B808: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0270B80C: ORR w19, wzr, #0x10        | W19 = 16(0x10);                         
            val_1 = 16;
            // 0x0270B810: LDR x8, [x19]              | X8 = 0x100B70003;                       
            // 0x0270B814: STR x8, [x21]              | mem[48] = 0x100B70003;                   //  dest_result_addr=48
            mem[48] = 11993091;
            // 0x0270B818: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x0270B81C: STR x20, [x19]             | mem[16] = 0x38004000000000;              //  dest_result_addr=16
            mem[16] = val_2;
            // 0x0270B820: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0270B824: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0270B828: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0270B82C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x02701A08 (40901128), len: 216  VirtAddr: 0x02701A08 RVA: 0x02701A08 token: 100663364 methodIndex: 20779 delegateWrapperIndex: 0 methodInvoker: 0
        protected virtual void Reset()
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.ClipperLib.LocalMinima val_1;
            // 0x02701A08: STP x28, x27, [sp, #-0x60]! | stack[1152921509609696800] = ???;  stack[1152921509609696808] = ???;  //  dest_result_addr=1152921509609696800 |  dest_result_addr=1152921509609696808
            // 0x02701A0C: STP x26, x25, [sp, #0x10]  | stack[1152921509609696816] = ???;  stack[1152921509609696824] = ???;  //  dest_result_addr=1152921509609696816 |  dest_result_addr=1152921509609696824
            // 0x02701A10: STP x24, x23, [sp, #0x20]  | stack[1152921509609696832] = ???;  stack[1152921509609696840] = ???;  //  dest_result_addr=1152921509609696832 |  dest_result_addr=1152921509609696840
            // 0x02701A14: STP x22, x21, [sp, #0x30]  | stack[1152921509609696848] = ???;  stack[1152921509609696856] = ???;  //  dest_result_addr=1152921509609696848 |  dest_result_addr=1152921509609696856
            // 0x02701A18: STP x20, x19, [sp, #0x40]  | stack[1152921509609696864] = ???;  stack[1152921509609696872] = ???;  //  dest_result_addr=1152921509609696864 |  dest_result_addr=1152921509609696872
            // 0x02701A1C: STP x29, x30, [sp, #0x50]  | stack[1152921509609696880] = ???;  stack[1152921509609696888] = ???;  //  dest_result_addr=1152921509609696880 |  dest_result_addr=1152921509609696888
            // 0x02701A20: ADD x29, sp, #0x50         | X29 = (1152921509609696800 + 80) = 1152921509609696880 (0x100000012A316E70);
            // 0x02701A24: LDR x19, [x0, #0x10]       | X19 = this.m_MinimaList; //P2           
            val_1 = this.m_MinimaList;
            // 0x02701A28: STR x19, [x0, #0x18]       | this.m_CurrentLM = this.m_MinimaList;    //  dest_result_addr=1152921509609708920
            this.m_CurrentLM = val_1;
            // 0x02701A2C: CBZ x19, #0x2701ac4        | if (this.m_MinimaList == null) goto label_0;
            if(val_1 == null)
            {
                goto label_0;
            }
            // 0x02701A30: ORR w21, wzr, #0x18        | W21 = 24(0x18);                         
            // 0x02701A34: ORR w22, wzr, #0x20        | W22 = 32(0x20);                         
            // 0x02701A38: MOVZ w23, #0x28            | W23 = 40 (0x28);//ML01                  
            // 0x02701A3C: MOVZ w24, #0x5c            | W24 = 92 (0x5C);//ML01                  
            // 0x02701A40: ORR w25, wzr, #1           | W25 = 1(0x1);                           
            // 0x02701A44: MOVN w26, #0               | W26 = 0 (0x0);//ML01                    
            label_6:
            // 0x02701A48: LDR x8, [x19, #0x18]       | X8 = this.m_MinimaList.LeftBound; //P2  
            // 0x02701A4C: CBZ x8, #0x2701a6c         | if (this.m_MinimaList.LeftBound == null) goto label_2;
            if(this.m_MinimaList.LeftBound == null)
            {
                goto label_2;
            }
            // 0x02701A50: LDP x9, x10, [x8, #0x10]   | X9 = this.m_MinimaList.LeftBound.Bot; //P2   //  | 
            // 0x02701A54: LDR w11, [x8, #0x6c]       | W11 = this.m_MinimaList.LeftBound.OutIdx; //P2 
            // 0x02701A58: STR wzr, [x8, #0x5c]       | this.m_MinimaList.LeftBound.Side = null;  //  dest_result_addr=0
            this.m_MinimaList.LeftBound.Side = 0;
            // 0x02701A5C: STP x9, x10, [x8, #0x20]   | this.m_MinimaList.LeftBound.Curr = this.m_MinimaList.LeftBound.Bot;  mem2[0] = ???;  //  dest_result_addr=0 |  dest_result_addr=0
            this.m_MinimaList.LeftBound.Curr = this.m_MinimaList.LeftBound.Bot;
            mem2[0] = ???;
            // 0x02701A60: CMN w11, #2                | STATE = COMPARE(this.m_MinimaList.LeftBound.OutIdx, 0x2)
            // 0x02701A64: B.EQ #0x2701a6c            | if (this.m_MinimaList.LeftBound.OutIdx == 2) goto label_2;
            if(this.m_MinimaList.LeftBound.OutIdx == 2)
            {
                goto label_2;
            }
            // 0x02701A68: STR w26, [x8, #0x6c]       | this.m_MinimaList.LeftBound.OutIdx = 0;  //  dest_result_addr=0
            this.m_MinimaList.LeftBound.OutIdx = 0;
            label_2:
            // 0x02701A6C: LDR x27, [x19, #0x20]      | X27 = this.m_MinimaList.RightBound; //P2 
            // 0x02701A70: CBZ x27, #0x2701a84        | if (this.m_MinimaList.RightBound == null) goto label_3;
            if(this.m_MinimaList.RightBound == null)
            {
                goto label_3;
            }
            // 0x02701A74: LDP x8, x9, [x27, #0x10]   | X8 = this.m_MinimaList.RightBound.Bot; //P2   //  | 
            // 0x02701A78: STR w25, [x27, #0x5c]      | this.m_MinimaList.RightBound.Side = 0x1;  //  dest_result_addr=0
            this.m_MinimaList.RightBound.Side = 1;
            // 0x02701A7C: STP x8, x9, [x27, #0x20]   | this.m_MinimaList.RightBound.Curr = this.m_MinimaList.RightBound.Bot;  mem2[0] = this.m_MinimaList.LeftBound.Bot;  //  dest_result_addr=0 |  dest_result_addr=0
            this.m_MinimaList.RightBound.Curr = this.m_MinimaList.RightBound.Bot;
            mem2[0] = this.m_MinimaList.LeftBound.Bot;
            // 0x02701A80: B #0x2701aac               |  goto label_4;                          
            goto label_4;
            label_3:
            // 0x02701A84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02701A88: ORR w8, wzr, #0x10         | W8 = 16(0x10);                          
            // 0x02701A8C: LDR x28, [x8]              | X28 = 0x100B70003;                      
            // 0x02701A90: LDR x20, [x21]             | X20 = 0x9814C0;                         
            // 0x02701A94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02701A98: STR x28, [x22]             | mem[32] = 0x100B70003;                   //  dest_result_addr=32
            mem[32] = 11993091;
            // 0x02701A9C: STR x20, [x23]             | mem[40] = 0x9814C0;                      //  dest_result_addr=40
            mem[40] = 9966784;
            // 0x02701AA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x02701AA4: STR w25, [x24]             | mem[92] = 0x1;                           //  dest_result_addr=92
            mem[92] = 1;
            // 0x02701AA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_4:
            // 0x02701AAC: LDR w8, [x27, #0x6c]       | W8 = this.m_MinimaList.RightBound.OutIdx; //P2 
            // 0x02701AB0: CMN w8, #2                 | STATE = COMPARE(this.m_MinimaList.RightBound.OutIdx, 0x2)
            // 0x02701AB4: B.EQ #0x2701abc            | if (this.m_MinimaList.RightBound.OutIdx == 2) goto label_5;
            if(this.m_MinimaList.RightBound.OutIdx == 2)
            {
                goto label_5;
            }
            // 0x02701AB8: STR w26, [x27, #0x6c]      | this.m_MinimaList.RightBound.OutIdx = 0;  //  dest_result_addr=0
            this.m_MinimaList.RightBound.OutIdx = 0;
            label_5:
            // 0x02701ABC: LDR x19, [x19, #0x28]      | X19 = this.m_MinimaList.Next; //P2      
            val_1 = this.m_MinimaList.Next;
            // 0x02701AC0: CBNZ x19, #0x2701a48       | if (this.m_MinimaList.Next != null) goto label_6;
            if(val_1 != null)
            {
                goto label_6;
            }
            label_0:
            // 0x02701AC4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x02701AC8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x02701ACC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x02701AD0: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x02701AD4: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x02701AD8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x02701ADC: RET                        |  return;                                
            return;
        
        }
    
    }

}
