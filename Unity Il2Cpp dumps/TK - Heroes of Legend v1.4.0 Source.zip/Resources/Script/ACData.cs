using UnityEngine;
public class ACData
{
    // Fields
    private uint value; //  0x00000010
    private uint acValue; //  0x00000014
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B1BDCC (11648460), len: 68  VirtAddr: 0x00B1BDCC RVA: 0x00B1BDCC token: 100693119 methodIndex: 24658 delegateWrapperIndex: 0 methodInvoker: 0
    public ACData(uint value, uint acValue)
    {
        //
        // Disasemble & Code
        // 0x00B1BDCC: STP x22, x21, [sp, #-0x30]! | stack[1152921514941606736] = ???;  stack[1152921514941606744] = ???;  //  dest_result_addr=1152921514941606736 |  dest_result_addr=1152921514941606744
        // 0x00B1BDD0: STP x20, x19, [sp, #0x10]  | stack[1152921514941606752] = ???;  stack[1152921514941606760] = ???;  //  dest_result_addr=1152921514941606752 |  dest_result_addr=1152921514941606760
        // 0x00B1BDD4: STP x29, x30, [sp, #0x20]  | stack[1152921514941606768] = ???;  stack[1152921514941606776] = ???;  //  dest_result_addr=1152921514941606768 |  dest_result_addr=1152921514941606776
        // 0x00B1BDD8: ADD x29, sp, #0x20         | X29 = (1152921514941606736 + 32) = 1152921514941606768 (0x1000000267FFEB70);
        // 0x00B1BDDC: MOV w20, w1                | W20 = value;//m1                        
        // 0x00B1BDE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1BDE4: MOV w19, w2                | W19 = acValue;//m1                      
        // 0x00B1BDE8: MOV x21, x0                | X21 = 1152921514941618784 (0x1000000268001A60);//ML01
        // 0x00B1BDEC: BL #0x16f59f0              | this..ctor();                           
        // 0x00B1BDF0: ADD w1, w19, w20           | W1 = (acValue + value);                 
        uint val_1 = acValue + value;
        // 0x00B1BDF4: STR w19, [x21, #0x14]      | this.acValue = acValue;                  //  dest_result_addr=1152921514941618804
        this.acValue = acValue;
        // 0x00B1BDF8: BL #0xb1be3c               | X0 = this.GetValueAdd(uValue:  uint val_1 = acValue + value);
        uint val_2 = this.GetValueAdd(uValue:  val_1);
        // 0x00B1BDFC: STR w0, [x21, #0x10]       | this.value = val_2;                      //  dest_result_addr=1152921514941618800
        this.value = val_2;
        // 0x00B1BE00: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1BE04: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1BE08: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B1BE0C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1BE10 (11648528), len: 44  VirtAddr: 0x00B1BE10 RVA: 0x00B1BE10 token: 100693120 methodIndex: 24659 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetValue(uint value, uint acValue)
    {
        //
        // Disasemble & Code
        // 0x00B1BE10: STP x20, x19, [sp, #-0x20]! | stack[1152921514941718752] = ???;  stack[1152921514941718760] = ???;  //  dest_result_addr=1152921514941718752 |  dest_result_addr=1152921514941718760
        // 0x00B1BE14: STP x29, x30, [sp, #0x10]  | stack[1152921514941718768] = ???;  stack[1152921514941718776] = ???;  //  dest_result_addr=1152921514941718768 |  dest_result_addr=1152921514941718776
        // 0x00B1BE18: ADD x29, sp, #0x10         | X29 = (1152921514941718752 + 16) = 1152921514941718768 (0x100000026801A0F0);
        // 0x00B1BE1C: MOV x19, x0                | X19 = 1152921514941730784 (0x100000026801CFE0);//ML01
        // 0x00B1BE20: ADD w1, w2, w1             | W1 = (acValue + value);                 
        value = acValue + value;
        // 0x00B1BE24: STR w2, [x19, #0x14]       | this.acValue = acValue;                  //  dest_result_addr=1152921514941730804
        this.acValue = acValue;
        // 0x00B1BE28: BL #0xb1be3c               | X0 = this.GetValueAdd(uValue:  value = acValue + value);
        uint val_1 = this.GetValueAdd(uValue:  value);
        // 0x00B1BE2C: STR w0, [x19, #0x10]       | this.value = val_1;                      //  dest_result_addr=1152921514941730800
        this.value = val_1;
        // 0x00B1BE30: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1BE34: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B1BE38: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1BFA8 (11648936), len: 44  VirtAddr: 0x00B1BFA8 RVA: 0x00B1BFA8 token: 100693121 methodIndex: 24660 delegateWrapperIndex: 0 methodInvoker: 0
    public uint GetValue()
    {
        //
        // Disasemble & Code
        // 0x00B1BFA8: STP x20, x19, [sp, #-0x20]! | stack[1152921514941830752] = ???;  stack[1152921514941830760] = ???;  //  dest_result_addr=1152921514941830752 |  dest_result_addr=1152921514941830760
        // 0x00B1BFAC: STP x29, x30, [sp, #0x10]  | stack[1152921514941830768] = ???;  stack[1152921514941830776] = ???;  //  dest_result_addr=1152921514941830768 |  dest_result_addr=1152921514941830776
        // 0x00B1BFB0: ADD x29, sp, #0x10         | X29 = (1152921514941830752 + 16) = 1152921514941830768 (0x1000000268035670);
        // 0x00B1BFB4: MOV x19, x0                | X19 = 1152921514941842784 (0x1000000268038560);//ML01
        // 0x00B1BFB8: LDR w1, [x19, #0x10]       | W1 = this.value; //P2                   
        // 0x00B1BFBC: BL #0xb1bfd4               | X0 = this.GetValueReduce(uValue:  this.value);
        uint val_1 = this.GetValueReduce(uValue:  this.value);
        // 0x00B1BFC0: LDR w8, [x19, #0x14]       | W8 = this.acValue; //P2                 
        // 0x00B1BFC4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1BFC8: SUB w0, w0, w8             | W0 = (val_1 - this.acValue);            
        val_1 = val_1 - this.acValue;
        // 0x00B1BFCC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B1BFD0: RET                        |  return (System.UInt32)(val_1 - this.acValue);
        return (uint)val_1;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1BE3C (11648572), len: 364  VirtAddr: 0x00B1BE3C RVA: 0x00B1BE3C token: 100693122 methodIndex: 24661 delegateWrapperIndex: 0 methodInvoker: 0
    public uint GetValueAdd(uint uValue)
    {
        //
        // Disasemble & Code
        //  | 
        int val_2;
        // 0x00B1BE3C: STP x22, x21, [sp, #-0x30]! | stack[1152921514941979600] = ???;  stack[1152921514941979608] = ???;  //  dest_result_addr=1152921514941979600 |  dest_result_addr=1152921514941979608
        // 0x00B1BE40: STP x20, x19, [sp, #0x10]  | stack[1152921514941979616] = ???;  stack[1152921514941979624] = ???;  //  dest_result_addr=1152921514941979616 |  dest_result_addr=1152921514941979624
        // 0x00B1BE44: STP x29, x30, [sp, #0x20]  | stack[1152921514941979632] = ???;  stack[1152921514941979640] = ???;  //  dest_result_addr=1152921514941979632 |  dest_result_addr=1152921514941979640
        // 0x00B1BE48: ADD x29, sp, #0x20         | X29 = (1152921514941979600 + 32) = 1152921514941979632 (0x1000000268059BF0);
        // 0x00B1BE4C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1BE50: LDRB w8, [x20, #0x700]     | W8 = (bool)static_value_03733700;       
        // 0x00B1BE54: MOV w19, w1                | W19 = uValue;//m1                       
        // 0x00B1BE58: TBNZ w8, #0, #0xb1be74     | if (static_value_03733700 == true) goto label_0;
        // 0x00B1BE5C: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B1BE60: LDR x8, [x8, #0x2e8]       | X8 = 0x2B8A798;                         
        // 0x00B1BE64: LDR w0, [x8]               | W0 = 0xA4;                              
        // 0x00B1BE68: BL #0x2782188              | X0 = sub_2782188( ?? 0xA4, ????);       
        // 0x00B1BE6C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1BE70: STRB w8, [x20, #0x700]     | static_value_03733700 = true;            //  dest_result_addr=57882368
        label_0:
        // 0x00B1BE74: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
        // 0x00B1BE78: LDR x8, [x8, #0xe08]       | X8 = 1152921504652320768;               
        // 0x00B1BE7C: LDR x0, [x8]               | X0 = typeof(System.BitConverter);       
        // 0x00B1BE80: LDRB w8, [x0, #0x10a]      | W8 = System.BitConverter.__il2cppRuntimeField_10A;
        // 0x00B1BE84: TBZ w8, #0, #0xb1be94      | if (System.BitConverter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B1BE88: LDR w8, [x0, #0xbc]        | W8 = System.BitConverter.__il2cppRuntimeField_cctor_finished;
        // 0x00B1BE8C: CBNZ w8, #0xb1be94         | if (System.BitConverter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B1BE90: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.BitConverter), ????);
        label_2:
        // 0x00B1BE94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1BE98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1BE9C: MOV w1, w19                | W1 = uValue;//m1                        
        // 0x00B1BEA0: BL #0x18d36a4              | X0 = System.BitConverter.GetBytes(value:  0);
        System.Byte[] val_1 = System.BitConverter.GetBytes(value:  0);
        // 0x00B1BEA4: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00B1BEA8: CBNZ x19, #0xb1beb0        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00B1BEAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B1BEB0: LDR x8, [x19, #0x18]       | X8 = val_1.Length; //P2                 
        val_2 = val_1.Length;
        // 0x00B1BEB4: CBNZ w8, #0xb1bec8         | if (val_1.Length != 0) goto label_4;    
        if(val_2 != 0)
        {
            goto label_4;
        }
        // 0x00B1BEB8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B1BEBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1BEC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        // 0x00B1BEC4: LDR x8, [x19, #0x18]       | X8 = val_1.Length; //P2                 
        val_2 = val_1.Length;
        label_4:
        // 0x00B1BEC8: LDRB w20, [x19, #0x20]     | W20 = val_1[0]                          
        byte val_2 = val_1[0];
        // 0x00B1BECC: CMP w8, #1                 | STATE = COMPARE(val_1.Length, 0x1)      
        // 0x00B1BED0: B.HI #0xb1bee4             | if (val_2 > 1) goto label_5;            
        if(val_2 > 1)
        {
            goto label_5;
        }
        // 0x00B1BED4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B1BED8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1BEDC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        // 0x00B1BEE0: LDR x8, [x19, #0x18]       | X8 = val_1.Length; //P2                 
        val_2 = val_1.Length;
        label_5:
        // 0x00B1BEE4: LDRB w21, [x19, #0x21]     | W21 = val_1[1]                          
        byte val_3 = val_1[1];
        // 0x00B1BEE8: CBNZ w8, #0xb1befc         | if (val_1.Length != 0) goto label_6;    
        if(val_2 != 0)
        {
            goto label_6;
        }
        // 0x00B1BEEC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B1BEF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1BEF4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        // 0x00B1BEF8: LDR x8, [x19, #0x18]       | X8 = val_1.Length; //P2                 
        val_2 = val_1.Length;
        label_6:
        // 0x00B1BEFC: STRB w21, [x19, #0x20]     | val_1[0] = val_1[1];                     //  dest_result_addr=0
        val_1[0] = val_3;
        // 0x00B1BF00: CMP w8, #2                 | STATE = COMPARE(val_1.Length, 0x2)      
        // 0x00B1BF04: B.HI #0xb1bf18             | if (val_2 > 2) goto label_7;            
        if(val_2 > 2)
        {
            goto label_7;
        }
        // 0x00B1BF08: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B1BF0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1BF10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        // 0x00B1BF14: LDR x8, [x19, #0x18]       | X8 = val_1.Length; //P2                 
        val_2 = val_1.Length;
        label_7:
        // 0x00B1BF18: LDRB w21, [x19, #0x22]     | W21 = val_1[2]                          
        byte val_4 = val_1[2];
        // 0x00B1BF1C: CMP w8, #1                 | STATE = COMPARE(val_1.Length, 0x1)      
        // 0x00B1BF20: B.HI #0xb1bf34             | if (val_2 > 1) goto label_8;            
        if(val_2 > 1)
        {
            goto label_8;
        }
        // 0x00B1BF24: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B1BF28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1BF2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        // 0x00B1BF30: LDR x8, [x19, #0x18]       | X8 = val_1.Length; //P2                 
        val_2 = val_1.Length;
        label_8:
        // 0x00B1BF34: STRB w21, [x19, #0x21]     | val_1[1] = val_1[2];                     //  dest_result_addr=0
        val_1[1] = val_4;
        // 0x00B1BF38: CMP w8, #3                 | STATE = COMPARE(val_1.Length, 0x3)      
        // 0x00B1BF3C: B.HI #0xb1bf50             | if (val_2 > 3) goto label_9;            
        if(val_2 > 3)
        {
            goto label_9;
        }
        // 0x00B1BF40: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B1BF44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1BF48: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        // 0x00B1BF4C: LDR x8, [x19, #0x18]       | X8 = val_1.Length; //P2                 
        val_2 = val_1.Length;
        label_9:
        // 0x00B1BF50: LDRB w21, [x19, #0x23]     | W21 = val_1[3]                          
        byte val_5 = val_1[3];
        // 0x00B1BF54: CMP w8, #2                 | STATE = COMPARE(val_1.Length, 0x2)      
        // 0x00B1BF58: B.HI #0xb1bf6c             | if (val_2 > 2) goto label_10;           
        if(val_2 > 2)
        {
            goto label_10;
        }
        // 0x00B1BF5C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B1BF60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1BF64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        // 0x00B1BF68: LDR x8, [x19, #0x18]       | X8 = val_1.Length; //P2                 
        val_2 = val_1.Length;
        label_10:
        // 0x00B1BF6C: STRB w21, [x19, #0x22]     | val_1[2] = val_1[3];                     //  dest_result_addr=0
        val_1[2] = val_5;
        // 0x00B1BF70: CMP w8, #3                 | STATE = COMPARE(val_1.Length, 0x3)      
        // 0x00B1BF74: B.HI #0xb1bf84             | if (val_2 > 3) goto label_11;           
        if(val_2 > 3)
        {
            goto label_11;
        }
        // 0x00B1BF78: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B1BF7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1BF80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        label_11:
        // 0x00B1BF84: STRB w20, [x19, #0x23]     | val_1[3] = val_1[0];                     //  dest_result_addr=0
        val_1[3] = val_2;
        // 0x00B1BF88: MOV x1, x19                | X1 = val_1;//m1                         
        // 0x00B1BF8C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1BF90: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1BF94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1BF98: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B1BF9C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1BFA0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B1BFA4: B #0x18d3b24               | return System.BitConverter.ToUInt32(value:  0, startIndex:  val_1);
        return System.BitConverter.ToUInt32(value:  0, startIndex:  val_1);
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1BFD4 (11648980), len: 364  VirtAddr: 0x00B1BFD4 RVA: 0x00B1BFD4 token: 100693123 methodIndex: 24662 delegateWrapperIndex: 0 methodInvoker: 0
    public uint GetValueReduce(uint uValue)
    {
        //
        // Disasemble & Code
        //  | 
        int val_2;
        // 0x00B1BFD4: STP x22, x21, [sp, #-0x30]! | stack[1152921514942165328] = ???;  stack[1152921514942165336] = ???;  //  dest_result_addr=1152921514942165328 |  dest_result_addr=1152921514942165336
        // 0x00B1BFD8: STP x20, x19, [sp, #0x10]  | stack[1152921514942165344] = ???;  stack[1152921514942165352] = ???;  //  dest_result_addr=1152921514942165344 |  dest_result_addr=1152921514942165352
        // 0x00B1BFDC: STP x29, x30, [sp, #0x20]  | stack[1152921514942165360] = ???;  stack[1152921514942165368] = ???;  //  dest_result_addr=1152921514942165360 |  dest_result_addr=1152921514942165368
        // 0x00B1BFE0: ADD x29, sp, #0x20         | X29 = (1152921514942165328 + 32) = 1152921514942165360 (0x1000000268087170);
        // 0x00B1BFE4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1BFE8: LDRB w8, [x20, #0x701]     | W8 = (bool)static_value_03733701;       
        // 0x00B1BFEC: MOV w19, w1                | W19 = uValue;//m1                       
        // 0x00B1BFF0: TBNZ w8, #0, #0xb1c00c     | if (static_value_03733701 == true) goto label_0;
        // 0x00B1BFF4: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
        // 0x00B1BFF8: LDR x8, [x8, #0x418]       | X8 = 0x2B8A79C;                         
        // 0x00B1BFFC: LDR w0, [x8]               | W0 = 0xA5;                              
        // 0x00B1C000: BL #0x2782188              | X0 = sub_2782188( ?? 0xA5, ????);       
        // 0x00B1C004: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1C008: STRB w8, [x20, #0x701]     | static_value_03733701 = true;            //  dest_result_addr=57882369
        label_0:
        // 0x00B1C00C: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
        // 0x00B1C010: LDR x8, [x8, #0xe08]       | X8 = 1152921504652320768;               
        // 0x00B1C014: LDR x0, [x8]               | X0 = typeof(System.BitConverter);       
        // 0x00B1C018: LDRB w8, [x0, #0x10a]      | W8 = System.BitConverter.__il2cppRuntimeField_10A;
        // 0x00B1C01C: TBZ w8, #0, #0xb1c02c      | if (System.BitConverter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B1C020: LDR w8, [x0, #0xbc]        | W8 = System.BitConverter.__il2cppRuntimeField_cctor_finished;
        // 0x00B1C024: CBNZ w8, #0xb1c02c         | if (System.BitConverter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B1C028: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.BitConverter), ????);
        label_2:
        // 0x00B1C02C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1C030: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1C034: MOV w1, w19                | W1 = uValue;//m1                        
        // 0x00B1C038: BL #0x18d36a4              | X0 = System.BitConverter.GetBytes(value:  0);
        System.Byte[] val_1 = System.BitConverter.GetBytes(value:  0);
        // 0x00B1C03C: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00B1C040: CBNZ x19, #0xb1c048        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00B1C044: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B1C048: LDR x8, [x19, #0x18]       | X8 = val_1.Length; //P2                 
        val_2 = val_1.Length;
        // 0x00B1C04C: CMP w8, #3                 | STATE = COMPARE(val_1.Length, 0x3)      
        // 0x00B1C050: B.HI #0xb1c064             | if (val_2 > 3) goto label_4;            
        if(val_2 > 3)
        {
            goto label_4;
        }
        // 0x00B1C054: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B1C058: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C05C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        // 0x00B1C060: LDR x8, [x19, #0x18]       | X8 = val_1.Length; //P2                 
        val_2 = val_1.Length;
        label_4:
        // 0x00B1C064: LDRB w20, [x19, #0x23]     | W20 = val_1[3]                          
        byte val_2 = val_1[3];
        // 0x00B1C068: CMP w8, #2                 | STATE = COMPARE(val_1.Length, 0x2)      
        // 0x00B1C06C: B.HI #0xb1c080             | if (val_2 > 2) goto label_5;            
        if(val_2 > 2)
        {
            goto label_5;
        }
        // 0x00B1C070: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B1C074: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C078: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        // 0x00B1C07C: LDR x8, [x19, #0x18]       | X8 = val_1.Length; //P2                 
        val_2 = val_1.Length;
        label_5:
        // 0x00B1C080: LDRB w21, [x19, #0x22]     | W21 = val_1[2]                          
        byte val_3 = val_1[2];
        // 0x00B1C084: CMP w8, #3                 | STATE = COMPARE(val_1.Length, 0x3)      
        // 0x00B1C088: B.HI #0xb1c09c             | if (val_2 > 3) goto label_6;            
        if(val_2 > 3)
        {
            goto label_6;
        }
        // 0x00B1C08C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B1C090: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C094: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        // 0x00B1C098: LDR x8, [x19, #0x18]       | X8 = val_1.Length; //P2                 
        val_2 = val_1.Length;
        label_6:
        // 0x00B1C09C: STRB w21, [x19, #0x23]     | val_1[3] = val_1[2];                     //  dest_result_addr=0
        val_1[3] = val_3;
        // 0x00B1C0A0: CMP w8, #1                 | STATE = COMPARE(val_1.Length, 0x1)      
        // 0x00B1C0A4: B.HI #0xb1c0b8             | if (val_2 > 1) goto label_7;            
        if(val_2 > 1)
        {
            goto label_7;
        }
        // 0x00B1C0A8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B1C0AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C0B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        // 0x00B1C0B4: LDR x8, [x19, #0x18]       | X8 = val_1.Length; //P2                 
        val_2 = val_1.Length;
        label_7:
        // 0x00B1C0B8: LDRB w21, [x19, #0x21]     | W21 = val_1[1]                          
        byte val_4 = val_1[1];
        // 0x00B1C0BC: CMP w8, #2                 | STATE = COMPARE(val_1.Length, 0x2)      
        // 0x00B1C0C0: B.HI #0xb1c0d4             | if (val_2 > 2) goto label_8;            
        if(val_2 > 2)
        {
            goto label_8;
        }
        // 0x00B1C0C4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B1C0C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C0CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        // 0x00B1C0D0: LDR x8, [x19, #0x18]       | X8 = val_1.Length; //P2                 
        val_2 = val_1.Length;
        label_8:
        // 0x00B1C0D4: STRB w21, [x19, #0x22]     | val_1[2] = val_1[1];                     //  dest_result_addr=0
        val_1[2] = val_4;
        // 0x00B1C0D8: CBNZ w8, #0xb1c0ec         | if (val_1.Length != 0) goto label_9;    
        if(val_2 != 0)
        {
            goto label_9;
        }
        // 0x00B1C0DC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B1C0E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C0E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        // 0x00B1C0E8: LDR x8, [x19, #0x18]       | X8 = val_1.Length; //P2                 
        val_2 = val_1.Length;
        label_9:
        // 0x00B1C0EC: LDRB w21, [x19, #0x20]     | W21 = val_1[0]                          
        byte val_5 = val_1[0];
        // 0x00B1C0F0: CMP w8, #1                 | STATE = COMPARE(val_1.Length, 0x1)      
        // 0x00B1C0F4: B.HI #0xb1c108             | if (val_2 > 1) goto label_10;           
        if(val_2 > 1)
        {
            goto label_10;
        }
        // 0x00B1C0F8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B1C0FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C100: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        // 0x00B1C104: LDR x8, [x19, #0x18]       | X8 = val_1.Length; //P2                 
        val_2 = val_1.Length;
        label_10:
        // 0x00B1C108: STRB w21, [x19, #0x21]     | val_1[1] = val_1[0];                     //  dest_result_addr=0
        val_1[1] = val_5;
        // 0x00B1C10C: CBNZ w8, #0xb1c11c         | if (val_1.Length != 0) goto label_11;   
        if(val_2 != 0)
        {
            goto label_11;
        }
        // 0x00B1C110: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B1C114: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C118: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        label_11:
        // 0x00B1C11C: STRB w20, [x19, #0x20]     | val_1[0] = val_1[3];                     //  dest_result_addr=0
        val_1[0] = val_2;
        // 0x00B1C120: MOV x1, x19                | X1 = val_1;//m1                         
        // 0x00B1C124: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1C128: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1C12C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1C130: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B1C134: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1C138: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B1C13C: B #0x18d3b24               | return System.BitConverter.ToUInt32(value:  0, startIndex:  val_1);
        return System.BitConverter.ToUInt32(value:  0, startIndex:  val_1);
    
    }

}
