using UnityEngine;
private class LzmaBench.CBitRandomGenerator
{
    // Fields
    private SevenZip.LzmaBench.CRandomGenerator RG; //  0x00000010
    private uint Value; //  0x00000018
    private int NumBits; //  0x0000001C
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00ADB7DC (11384796), len: 124  VirtAddr: 0x00ADB7DC RVA: 0x00ADB7DC token: 100681608 methodIndex: 54785 delegateWrapperIndex: 0 methodInvoker: 0
    public LzmaBench.CBitRandomGenerator()
    {
        //
        // Disasemble & Code
        // 0x00ADB7DC: STP x20, x19, [sp, #-0x20]! | stack[1152921513101540016] = ???;  stack[1152921513101540024] = ???;  //  dest_result_addr=1152921513101540016 |  dest_result_addr=1152921513101540024
        // 0x00ADB7E0: STP x29, x30, [sp, #0x10]  | stack[1152921513101540032] = ???;  stack[1152921513101540040] = ???;  //  dest_result_addr=1152921513101540032 |  dest_result_addr=1152921513101540040
        // 0x00ADB7E4: ADD x29, sp, #0x10         | X29 = (1152921513101540016 + 16) = 1152921513101540032 (0x10000001FA52BAC0);
        // 0x00ADB7E8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00ADB7EC: LDRB w8, [x20, #0x51f]     | W8 = (bool)static_value_0373351F;       
        // 0x00ADB7F0: MOV x19, x0                | X19 = 1152921513101552048 (0x10000001FA52E9B0);//ML01
        // 0x00ADB7F4: TBNZ w8, #0, #0xadb810     | if (static_value_0373351F == true) goto label_0;
        // 0x00ADB7F8: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
        // 0x00ADB7FC: LDR x8, [x8, #0xd30]       | X8 = 0x2B904B0;                         
        // 0x00ADB800: LDR w0, [x8]               | W0 = 0x17F0;                            
        // 0x00ADB804: BL #0x2782188              | X0 = sub_2782188( ?? 0x17F0, ????);     
        // 0x00ADB808: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00ADB80C: STRB w8, [x20, #0x51f]     | static_value_0373351F = true;            //  dest_result_addr=57881887
        label_0:
        // 0x00ADB810: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00ADB814: LDR x8, [x8, #0x1f8]       | X8 = 1152921504833843200;               
        // 0x00ADB818: LDR x0, [x8]               | X0 = typeof(LzmaBench.CRandomGenerator);
        object val_1 = null;
        // 0x00ADB81C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(LzmaBench.CRandomGenerator), ????);
        // 0x00ADB820: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00ADB824: MOV x20, x0                | X20 = 1152921504833843200 (0x100000000D87B000);//ML01
        // 0x00ADB828: BL #0x16f59f0              | .ctor();                                
        val_1 = new System.Object();
        // 0x00ADB82C: MOVZ w8, #0x159a, lsl #16  | W8 = 362414080 (0x159A0000);//ML01      
        // 0x00ADB830: MOVZ w9, #0x1f12, lsl #16  | W9 = 521273344 (0x1F120000);//ML01      
        // 0x00ADB834: MOVK w8, #0x55e5           | W8 = 362436069 (0x159A55E5);            
        // 0x00ADB838: MOVK w9, #0x3bb5           | W9 = 521288629 (0x1F123BB5);            
        // 0x00ADB83C: STP w8, w9, [x20, #0x10]   | typeof(LzmaBench.CRandomGenerator).__il2cppRuntimeField_10 = 0x159A55E5;  typeof(LzmaBench.CRandomGenerator).__il2cppRuntimeField_14 = 0x1F123BB5;  //  dest_result_addr=1152921504833843216 |  dest_result_addr=1152921504833843220
        typeof(LzmaBench.CRandomGenerator).__il2cppRuntimeField_10 = 362436069;
        typeof(LzmaBench.CRandomGenerator).__il2cppRuntimeField_14 = 521288629;
        // 0x00ADB840: STR x20, [x19, #0x10]      | this.RG = typeof(LzmaBench.CRandomGenerator);  //  dest_result_addr=1152921513101552064
        this.RG = val_1;
        // 0x00ADB844: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00ADB848: MOV x0, x19                | X0 = 1152921513101552048 (0x10000001FA52E9B0);//ML01
        // 0x00ADB84C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00ADB850: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00ADB854: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADBAB4 (11385524), len: 8  VirtAddr: 0x00ADBAB4 RVA: 0x00ADBAB4 token: 100681609 methodIndex: 54786 delegateWrapperIndex: 0 methodInvoker: 0
    public void Init()
    {
        //
        // Disasemble & Code
        // 0x00ADBAB4: STR xzr, [x0, #0x18]       | this.Value = null; this.NumBits = 0;     //  dest_result_addr=1152921513101664072 dest_result_addr=1152921513101664076
        this.Value = 0;
        this.NumBits = 0;
        // 0x00ADBAB8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADB884 (11384964), len: 208  VirtAddr: 0x00ADB884 RVA: 0x00ADB884 token: 100681610 methodIndex: 54787 delegateWrapperIndex: 0 methodInvoker: 0
    public uint GetRnd(int numBits)
    {
        //
        // Disasemble & Code
        //  | 
        var val_13;
        //  | 
        int val_14;
        // 0x00ADB884: STP x24, x23, [sp, #-0x40]! | stack[1152921513101768080] = ???;  stack[1152921513101768088] = ???;  //  dest_result_addr=1152921513101768080 |  dest_result_addr=1152921513101768088
        // 0x00ADB888: STP x22, x21, [sp, #0x10]  | stack[1152921513101768096] = ???;  stack[1152921513101768104] = ???;  //  dest_result_addr=1152921513101768096 |  dest_result_addr=1152921513101768104
        // 0x00ADB88C: STP x20, x19, [sp, #0x20]  | stack[1152921513101768112] = ???;  stack[1152921513101768120] = ???;  //  dest_result_addr=1152921513101768112 |  dest_result_addr=1152921513101768120
        // 0x00ADB890: STP x29, x30, [sp, #0x30]  | stack[1152921513101768128] = ???;  stack[1152921513101768136] = ???;  //  dest_result_addr=1152921513101768128 |  dest_result_addr=1152921513101768136
        // 0x00ADB894: ADD x29, sp, #0x30         | X29 = (1152921513101768080 + 48) = 1152921513101768128 (0x10000001FA5635C0);
        // 0x00ADB898: MOV x19, x0                | X19 = 1152921513101780144 (0x10000001FA5664B0);//ML01
        // 0x00ADB89C: LDR w8, [x19, #0x1c]       | W8 = this.NumBits; //P2                 
        // 0x00ADB8A0: CMP w8, w1                 | STATE = COMPARE(this.NumBits, numBits)  
        // 0x00ADB8A4: B.LE #0xadb8d0             | if (this.NumBits <= numBits) goto label_0;
        if(this.NumBits <= numBits)
        {
            goto label_0;
        }
        // 0x00ADB8A8: LDP w8, w9, [x19, #0x18]   | W8 = this.Value; //P2  W9 = this.NumBits; //P2  //  | 
        uint val_10 = this.Value;
        // 0x00ADB8AC: AND w10, w1, #0x1f         | W10 = (numBits & 31);                   
        int val_1 = numBits & 31;
        // 0x00ADB8B0: ORR w11, wzr, #1           | W11 = 1(0x1);                           
        var val_9 = 1;
        // 0x00ADB8B4: LSL w11, w11, w10          | W11 = (1 << (numBits & 31));            
        val_9 = val_9 << val_1;
        // 0x00ADB8B8: SUB w11, w11, #1           | W11 = ((1 << (numBits & 31)) - 1);      
        val_9 = val_9 - 1;
        // 0x00ADB8BC: AND w0, w8, w11            | W0 = (this.Value & ((1 << (numBits & 31)) - 1));
        val_13 = val_10 & val_9;
        // 0x00ADB8C0: LSR w8, w8, w10            | W8 = (this.Value >> (numBits & 31));    
        val_10 = val_10 >> val_1;
        // 0x00ADB8C4: STR w8, [x19, #0x18]       | this.Value = (this.Value >> (numBits & 31));  //  dest_result_addr=1152921513101780168
        this.Value = val_10;
        // 0x00ADB8C8: SUB w8, w9, w1             | W8 = (this.NumBits - numBits);          
        val_14 = this.NumBits - numBits;
        // 0x00ADB8CC: B #0xadb93c                |  goto label_1;                          
        goto label_1;
        label_0:
        // 0x00ADB8D0: LDR w9, [x19, #0x18]       | W9 = this.Value; //P2                   
        // 0x00ADB8D4: LDR x23, [x19, #0x10]      | X23 = this.RG; //P2                     
        // 0x00ADB8D8: SUB w20, w1, w8            | W20 = (numBits - this.NumBits);         
        int val_2 = numBits - this.NumBits;
        // 0x00ADB8DC: AND w21, w20, #0x1f        | W21 = ((numBits - this.NumBits) & 31);  
        int val_3 = val_2 & 31;
        // 0x00ADB8E0: LSL w22, w9, w21           | W22 = (this.Value << ((numBits - this.NumBits) & 31));
        uint val_4 = this.Value << val_3;
        // 0x00ADB8E4: CBNZ x23, #0xadb8ec        | if (this.RG != null) goto label_2;      
        if(this.RG != null)
        {
            goto label_2;
        }
        // 0x00ADB8E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_2:
        // 0x00ADB8EC: LDR x8, [x23, #0x10]       | X8 = this.RG.A1; //P2                   
        uint val_11 = this.RG.A1;
        // 0x00ADB8F0: MOVZ w9, #0x4650           | W9 = 18000 (0x4650);//ML01              
        // 0x00ADB8F4: UBFX x10, x8, #0x20, #0x10 | X10 = (ulong)((this.RG.A1>>32) & 0xFFFF);
        // 0x00ADB8F8: LSR x11, x8, #0x30         | X11 = (this.RG.A1 >> 48);               
        uint val_5 = val_11 >> 48;
        // 0x00ADB8FC: MADD w9, w10, w9, w11      | W9 = ((ulong)((this.RG.A1>>32) & 0xFFFF) * 18000) + (this.RG.A1 >> 48);
        uint val_6 = val_5 + (((ulong)(val_11 >> 32) & 65535) * 18000);
        // 0x00ADB900: MOVZ w10, #0x9069          | W10 = 36969 (0x9069);//ML01             
        // 0x00ADB904: AND w11, w8, #0xffff       | W11 = (this.RG.A1 & 65535);             
        uint val_7 = val_11 & 65535;
        // 0x00ADB908: MUL w10, w11, w10          | W10 = ((this.RG.A1 & 65535) * 36969);   
        uint val_8 = val_7 * 36969;
        // 0x00ADB90C: ORR w11, wzr, #1           | W11 = 1(0x1);                           
        var val_12 = 1;
        // 0x00ADB910: ADD w8, w10, w8, lsr #16   | W8 = (((this.RG.A1 & 65535) * 36969) + (this.RG.A1) >> 16);
        val_11 = val_8 + (val_11 >> 16);
        // 0x00ADB914: LSL w11, w11, w21          | W11 = (1 << ((numBits - this.NumBits) & 31));
        val_12 = val_12 << val_3;
        // 0x00ADB918: SUB w11, w11, #1           | W11 = ((1 << ((numBits - this.NumBits) & 31)) - 1);
        val_12 = val_12 - 1;
        // 0x00ADB91C: STP w8, w9, [x23, #0x10]   | this.RG.A1 = (((this.RG.A1 & 65535) * 36969) + (this.RG.A1) >> 16);  this.RG.A2 = ((ulong)((this.RG.A1>>32) & 0xFFFF) * 18000) + (this.RG.A1 >> 48);  //  dest_result_addr=0 |  dest_result_addr=0
        this.RG.A1 = val_11;
        this.RG.A2 = val_6;
        // 0x00ADB920: EOR w8, w9, w8, lsl #16    | W8 = (((ulong)((this.RG.A1>>32) & 0xFFFF) * 18000) + (this.RG.A1 >> 48) ^ ((((this.RG.A1 & 65535) * 
        val_11 = val_6 ^ (val_11 << 16);
        // 0x00ADB924: ORR w10, wzr, #0x20        | W10 = 32(0x20);                         
        // 0x00ADB928: AND w9, w8, w11            | W9 = ((((ulong)((this.RG.A1>>32) & 0xFFFF) * 18000) + (this.RG.A1 >> 48) ^ ((((this.RG.A1 & 65535) *
        val_6 = val_11 & val_12;
        // 0x00ADB92C: LSR w8, w8, w21            | W8 = ((((ulong)((this.RG.A1>>32) & 0xFFFF) * 18000) + (this.RG.A1 >> 48) ^ ((((this.RG.A1 & 65535) * 36969) + (this.RG.A1) >> 16)) << 16) >> ((numBits - this.NumBits) & 31));
        val_11 = val_11 >> val_3;
        // 0x00ADB930: ORR w0, w9, w22            | W0 = (((((ulong)((this.RG.A1>>32) & 0xFFFF) * 18000) + (this.RG.A1 >> 48) ^ ((((this.RG.A1 & 65535) 
        val_13 = val_6 | val_4;
        // 0x00ADB934: STR w8, [x19, #0x18]       | this.Value = ((((ulong)((this.RG.A1>>32) & 0xFFFF) * 18000) + (this.RG.A1 >> 48) ^ ((((this.RG.A1 & 65535) * 36969) + (this.RG.A1) >> 16)) << 16) >> ((numBits - this.NumBits) & 31));  //  dest_result_addr=1152921513101780168
        this.Value = val_11;
        // 0x00ADB938: SUB w8, w10, w20           | W8 = (32 - (numBits - this.NumBits));   
        val_14 = 32 - val_2;
        label_1:
        // 0x00ADB93C: STR w8, [x19, #0x1c]       | this.NumBits = (32 - (numBits - this.NumBits));  //  dest_result_addr=1152921513101780172
        this.NumBits = val_14;
        // 0x00ADB940: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00ADB944: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00ADB948: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00ADB94C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00ADB950: RET                        |  return (System.UInt32)(((((ulong)((this.RG.A1>>32) & 0xFFFF) * 18000) + (this.RG.A1 >> 48) ^ ((((this.RG.A1 & 65535) * 36969) + (this.RG.A1) >> 16)) << 16) & ((1 << ((numBits - this.NumBits) & 31)) - 1)) | (this.Value << (;
        return (uint)val_13;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
    
    }

}
