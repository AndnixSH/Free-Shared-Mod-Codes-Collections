using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class ConfigAssetMgr_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache4; // static_offset: 0x00000020
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache5; // static_offset: 0x00000028
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache6; // static_offset: 0x00000030
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache7; // static_offset: 0x00000038
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache8; // static_offset: 0x00000040
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache9; // static_offset: 0x00000048
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheA; // static_offset: 0x00000050
        private static ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate <>f__am$cache0; // static_offset: 0x00000058
        private static ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate <>f__am$cache1; // static_offset: 0x00000060
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x01BFF5E8 (29357544), len: 8  VirtAddr: 0x01BFF5E8 RVA: 0x01BFF5E8 token: 100665075 methodIndex: 31124 delegateWrapperIndex: 0 methodInvoker: 0
        public ConfigAssetMgr_Binding()
        {
            //
            // Disasemble & Code
            // 0x01BFF5E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFF5EC: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01BFF5F0 (29357552), len: 3276  VirtAddr: 0x01BFF5F0 RVA: 0x01BFF5F0 token: 100665076 methodIndex: 31125 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_32;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_33;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_34;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_35;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_36;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_37;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_38;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_39;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_40;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_41;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_42;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_43;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_44;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_45;
            // 0x01BFF5F0: STP x28, x27, [sp, #-0x60]! | stack[1152921510255239840] = ???;  stack[1152921510255239848] = ???;  //  dest_result_addr=1152921510255239840 |  dest_result_addr=1152921510255239848
            // 0x01BFF5F4: STP x26, x25, [sp, #0x10]  | stack[1152921510255239856] = ???;  stack[1152921510255239864] = ???;  //  dest_result_addr=1152921510255239856 |  dest_result_addr=1152921510255239864
            // 0x01BFF5F8: STP x24, x23, [sp, #0x20]  | stack[1152921510255239872] = ???;  stack[1152921510255239880] = ???;  //  dest_result_addr=1152921510255239872 |  dest_result_addr=1152921510255239880
            // 0x01BFF5FC: STP x22, x21, [sp, #0x30]  | stack[1152921510255239888] = ???;  stack[1152921510255239896] = ???;  //  dest_result_addr=1152921510255239888 |  dest_result_addr=1152921510255239896
            // 0x01BFF600: STP x20, x19, [sp, #0x40]  | stack[1152921510255239904] = ???;  stack[1152921510255239912] = ???;  //  dest_result_addr=1152921510255239904 |  dest_result_addr=1152921510255239912
            // 0x01BFF604: STP x29, x30, [sp, #0x50]  | stack[1152921510255239920] = ???;  stack[1152921510255239928] = ???;  //  dest_result_addr=1152921510255239920 |  dest_result_addr=1152921510255239928
            // 0x01BFF608: ADD x29, sp, #0x50         | X29 = (1152921510255239840 + 80) = 1152921510255239920 (0x1000000150ABA2F0);
            // 0x01BFF60C: ADRP x20, #0x373c000       | X20 = 57917440 (0x373C000);             
            // 0x01BFF610: LDRB w8, [x20, #0x250]     | W8 = (bool)static_value_0373C250;       
            // 0x01BFF614: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01BFF618: TBNZ w8, #0, #0x1bff634    | if (static_value_0373C250 == true) goto label_0;
            // 0x01BFF61C: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
            // 0x01BFF620: LDR x8, [x8, #0xeb8]       | X8 = 0x2B9276C;                         
            // 0x01BFF624: LDR w0, [x8]               | W0 = 0x20A0;                            
            // 0x01BFF628: BL #0x2782188              | X0 = sub_2782188( ?? 0x20A0, ????);     
            // 0x01BFF62C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01BFF630: STRB w8, [x20, #0x250]     | static_value_0373C250 = true;            //  dest_result_addr=57918032
            label_0:
            // 0x01BFF634: ADRP x26, #0x3620000       | X26 = 56754176 (0x3620000);             
            // 0x01BFF638: LDR x26, [x26, #0x340]     | X26 = 1152921504609562624;              
            // 0x01BFF63C: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x01BFF640: LDR x0, [x26]              | X0 = typeof(System.Type);               
            // 0x01BFF644: LDR x8, [x8, #0xc30]       | X8 = 1152921504904183808;               
            // 0x01BFF648: LDR x20, [x8]              | X20 = typeof(ConfigAssetMgr);           
            // 0x01BFF64C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01BFF650: TBZ w8, #0, #0x1bff660     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01BFF654: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01BFF658: CBNZ w8, #0x1bff660        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01BFF65C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x01BFF660: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01BFF664: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01BFF668: MOV x1, x20                | X1 = 1152921504904183808 (0x1000000011B90000);//ML01
            // 0x01BFF66C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01BFF670: ADRP x25, #0x35ef000       | X25 = 56553472 (0x35EF000);             
            // 0x01BFF674: LDR x25, [x25, #0xff0]     | X25 = 1152921504987155056;              
            // 0x01BFF678: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x01BFF67C: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x01BFF680: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFF684: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01BFF688: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFF68C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFF690: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01BFF694: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFF698: CBNZ x20, #0x1bff6a0       | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x01BFF69C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_3:
            // 0x01BFF6A0: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x01BFF6A4: LDR x8, [x8, #0x8a0]       | X8 = (string**)(1152921510255143936)("get_isLoaded");
            // 0x01BFF6A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFF6AC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01BFF6B0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01BFF6B4: LDR x1, [x8]               | X1 = "get_isLoaded";                    
            // 0x01BFF6B8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01BFF6BC: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFF6C0: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01BFF6C4: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_isLoaded", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_2 = val_1.GetMethod(name:  "get_isLoaded", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01BFF6C8: ADRP x24, #0x362e000       | X24 = 56811520 (0x362E000);             
            // 0x01BFF6CC: LDR x24, [x24, #0x880]     | X24 = 1152921504784216064;              
            // 0x01BFF6D0: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x01BFF6D4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFF6D8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFF6DC: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache0;
            val_32 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache0;
            // 0x01BFF6E0: CBNZ x22, #0x1bff72c       | if (ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache0 != null) goto label_4;
            if(val_32 != null)
            {
                goto label_4;
            }
            // 0x01BFF6E4: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
            // 0x01BFF6E8: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01BFF6EC: LDR x8, [x8, #0xc28]       | X8 = 1152921510255148128;               
            // 0x01BFF6F0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01BFF6F4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::get_isLoaded_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01BFF6F8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_3 = null;
            // 0x01BFF6FC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01BFF700: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFF704: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFF708: MOV x2, x22                | X2 = 1152921510255148128 (0x1000000150AA3C60);//ML01
            // 0x01BFF70C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_33 = val_3;
            // 0x01BFF710: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::get_isLoaded_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_3 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::get_isLoaded_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01BFF714: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFF718: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFF71C: STR x23, [x8]              | ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504784220160
            ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache0 = val_33;
            // 0x01BFF720: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFF724: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFF728: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_32 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache0;
            label_4:
            // 0x01BFF72C: CBNZ x19, #0x1bff734       | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x01BFF730: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::get_isLoaded_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_5:
            // 0x01BFF734: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFF738: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01BFF73C: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x01BFF740: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01BFF744: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_2, func:  val_32);
            X1.RegisterCLRMethodRedirection(mi:  val_2, func:  val_32);
            // 0x01BFF748: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x01BFF74C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFF750: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01BFF754: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFF758: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFF75C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01BFF760: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFF764: CBNZ x20, #0x1bff76c       | if (val_1 != null) goto label_6;        
            if(val_1 != null)
            {
                goto label_6;
            }
            // 0x01BFF768: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_6:
            // 0x01BFF76C: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x01BFF770: LDR x8, [x8, #0xe0]        | X8 = (string**)(1152921510255149152)("get_isLoading");
            // 0x01BFF774: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFF778: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01BFF77C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01BFF780: LDR x1, [x8]               | X1 = "get_isLoading";                   
            // 0x01BFF784: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01BFF788: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFF78C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01BFF790: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_isLoading", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_4 = val_1.GetMethod(name:  "get_isLoading", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01BFF794: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFF798: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x01BFF79C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFF7A0: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache1;
            val_34 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache1;
            // 0x01BFF7A4: CBNZ x22, #0x1bff7f0       | if (ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache1 != null) goto label_7;
            if(val_34 != null)
            {
                goto label_7;
            }
            // 0x01BFF7A8: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x01BFF7AC: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01BFF7B0: LDR x8, [x8, #0x5e0]       | X8 = 1152921510255153344;               
            // 0x01BFF7B4: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01BFF7B8: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::get_isLoading_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01BFF7BC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_5 = null;
            // 0x01BFF7C0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01BFF7C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFF7C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFF7CC: MOV x2, x22                | X2 = 1152921510255153344 (0x1000000150AA50C0);//ML01
            // 0x01BFF7D0: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_33 = val_5;
            // 0x01BFF7D4: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::get_isLoading_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_5 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::get_isLoading_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01BFF7D8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFF7DC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFF7E0: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504784220168
            ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache1 = val_33;
            // 0x01BFF7E4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFF7E8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFF7EC: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_34 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache1;
            label_7:
            // 0x01BFF7F0: CBNZ x19, #0x1bff7f8       | if (X1 != 0) goto label_8;              
            if(X1 != 0)
            {
                goto label_8;
            }
            // 0x01BFF7F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::get_isLoading_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_8:
            // 0x01BFF7F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFF7FC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01BFF800: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x01BFF804: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01BFF808: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_4, func:  val_34);
            X1.RegisterCLRMethodRedirection(mi:  val_4, func:  val_34);
            // 0x01BFF80C: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x01BFF810: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFF814: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01BFF818: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFF81C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFF820: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01BFF824: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFF828: CBNZ x20, #0x1bff830       | if (val_1 != null) goto label_9;        
            if(val_1 != null)
            {
                goto label_9;
            }
            // 0x01BFF82C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_9:
            // 0x01BFF830: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
            // 0x01BFF834: LDR x8, [x8, #0xe18]       | X8 = (string**)(1152921510255154368)("get_loadProgress");
            // 0x01BFF838: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFF83C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01BFF840: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01BFF844: LDR x1, [x8]               | X1 = "get_loadProgress";                
            // 0x01BFF848: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01BFF84C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFF850: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01BFF854: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_loadProgress", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_6 = val_1.GetMethod(name:  "get_loadProgress", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01BFF858: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFF85C: MOV x21, x0                | X21 = val_6;//m1                        
            // 0x01BFF860: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFF864: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache2;
            val_35 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache2;
            // 0x01BFF868: CBNZ x22, #0x1bff8b4       | if (ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache2 != null) goto label_10;
            if(val_35 != null)
            {
                goto label_10;
            }
            // 0x01BFF86C: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
            // 0x01BFF870: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01BFF874: LDR x8, [x8, #0x38]        | X8 = 1152921510255158576;               
            // 0x01BFF878: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01BFF87C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::get_loadProgress_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01BFF880: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_7 = null;
            // 0x01BFF884: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01BFF888: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFF88C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFF890: MOV x2, x22                | X2 = 1152921510255158576 (0x1000000150AA6530);//ML01
            // 0x01BFF894: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_33 = val_7;
            // 0x01BFF898: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::get_loadProgress_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_7 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::get_loadProgress_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01BFF89C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFF8A0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFF8A4: STR x23, [x8, #0x10]       | ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504784220176
            ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache2 = val_33;
            // 0x01BFF8A8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFF8AC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFF8B0: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_35 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache2;
            label_10:
            // 0x01BFF8B4: CBNZ x19, #0x1bff8bc       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x01BFF8B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::get_loadProgress_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_11:
            // 0x01BFF8BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFF8C0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01BFF8C4: MOV x1, x21                | X1 = val_6;//m1                         
            // 0x01BFF8C8: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01BFF8CC: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_6, func:  val_35);
            X1.RegisterCLRMethodRedirection(mi:  val_6, func:  val_35);
            // 0x01BFF8D0: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x01BFF8D4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFF8D8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01BFF8DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFF8E0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFF8E4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01BFF8E8: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFF8EC: CBNZ x20, #0x1bff8f4       | if (val_1 != null) goto label_12;       
            if(val_1 != null)
            {
                goto label_12;
            }
            // 0x01BFF8F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_12:
            // 0x01BFF8F4: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x01BFF8F8: LDR x8, [x8, #0xe90]       | X8 = (string**)(1152921510255159600)("LoadConfig");
            // 0x01BFF8FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFF900: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01BFF904: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01BFF908: LDR x1, [x8]               | X1 = "LoadConfig";                      
            // 0x01BFF90C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01BFF910: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFF914: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01BFF918: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "LoadConfig", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_8 = val_1.GetMethod(name:  "LoadConfig", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01BFF91C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFF920: MOV x21, x0                | X21 = val_8;//m1                        
            // 0x01BFF924: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFF928: LDR x22, [x8, #0x18]       | X22 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache3;
            val_36 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache3;
            // 0x01BFF92C: CBNZ x22, #0x1bff978       | if (ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache3 != null) goto label_13;
            if(val_36 != null)
            {
                goto label_13;
            }
            // 0x01BFF930: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x01BFF934: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01BFF938: LDR x8, [x8, #0xe48]       | X8 = 1152921510255163792;               
            // 0x01BFF93C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01BFF940: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::LoadConfig_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01BFF944: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_9 = null;
            // 0x01BFF948: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01BFF94C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFF950: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFF954: MOV x2, x22                | X2 = 1152921510255163792 (0x1000000150AA7990);//ML01
            // 0x01BFF958: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_33 = val_9;
            // 0x01BFF95C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::LoadConfig_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_9 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::LoadConfig_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01BFF960: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFF964: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFF968: STR x23, [x8, #0x18]       | ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504784220184
            ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache3 = val_33;
            // 0x01BFF96C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFF970: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFF974: LDR x22, [x8, #0x18]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_36 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache3;
            label_13:
            // 0x01BFF978: CBNZ x19, #0x1bff980       | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x01BFF97C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::LoadConfig_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_14:
            // 0x01BFF980: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFF984: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01BFF988: MOV x1, x21                | X1 = val_8;//m1                         
            // 0x01BFF98C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01BFF990: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_8, func:  val_36);
            X1.RegisterCLRMethodRedirection(mi:  val_8, func:  val_36);
            // 0x01BFF994: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x01BFF998: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFF99C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01BFF9A0: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x01BFF9A4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFF9A8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01BFF9AC: ADRP x27, #0x3607000       | X27 = 56651776 (0x3607000);             
            // 0x01BFF9B0: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x01BFF9B4: LDR x27, [x27, #0xbb8]     | X27 = 1152921504608284672;              
            // 0x01BFF9B8: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFF9BC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01BFF9C0: LDR x22, [x27]             | X22 = typeof(System.String);            
            // 0x01BFF9C4: TBZ w9, #0, #0x1bff9d8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x01BFF9C8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01BFF9CC: CBNZ w9, #0x1bff9d8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x01BFF9D0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01BFF9D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_16:
            // 0x01BFF9D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01BFF9DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01BFF9E0: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01BFF9E4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01BFF9E8: MOV x22, x0                | X22 = val_10;//m1                       
            // 0x01BFF9EC: CBNZ x21, #0x1bff9f4       | if ( != null) goto label_17;            
            if(null != null)
            {
                goto label_17;
            }
            // 0x01BFF9F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_17:
            // 0x01BFF9F4: CBZ x22, #0x1bffa18        | if (val_10 == null) goto label_19;      
            if(val_10 == null)
            {
                goto label_19;
            }
            // 0x01BFF9F8: LDR x8, [x21]              | X8 = ;                                  
            // 0x01BFF9FC: MOV x0, x22                | X0 = val_10;//m1                        
            // 0x01BFFA00: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01BFFA04: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_10, ????);     
            // 0x01BFFA08: CBNZ x0, #0x1bffa18        | if (val_10 != null) goto label_19;      
            if(val_10 != null)
            {
                goto label_19;
            }
            // 0x01BFFA0C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_10, ????);     
            // 0x01BFFA10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFFA14: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_19:
            // 0x01BFFA18: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01BFFA1C: CBNZ w8, #0x1bffa2c        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_20;
            // 0x01BFFA20: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_10, ????);     
            // 0x01BFFA24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFFA28: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_20:
            // 0x01BFFA2C: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_10;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_10;
            // 0x01BFFA30: CBNZ x20, #0x1bffa38       | if (val_1 != null) goto label_21;       
            if(val_1 != null)
            {
                goto label_21;
            }
            // 0x01BFFA34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_21:
            // 0x01BFFA38: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x01BFFA3C: LDR x8, [x8, #0xdd8]       | X8 = (string**)(1152921510255168912)("LoadPathToABPath");
            // 0x01BFFA40: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFFA44: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01BFFA48: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01BFFA4C: LDR x1, [x8]               | X1 = "LoadPathToABPath";                
            // 0x01BFFA50: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01BFFA54: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFFA58: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01BFFA5C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "LoadPathToABPath", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_11 = val_1.GetMethod(name:  "LoadPathToABPath", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01BFFA60: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFFA64: MOV x21, x0                | X21 = val_11;//m1                       
            // 0x01BFFA68: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFFA6C: LDR x22, [x8, #0x20]       | X22 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache4;
            val_37 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache4;
            // 0x01BFFA70: CBNZ x22, #0x1bffabc       | if (ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache4 != null) goto label_22;
            if(val_37 != null)
            {
                goto label_22;
            }
            // 0x01BFFA74: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
            // 0x01BFFA78: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01BFFA7C: LDR x8, [x8, #0xea0]       | X8 = 1152921510255173120;               
            // 0x01BFFA80: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01BFFA84: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::LoadPathToABPath_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01BFFA88: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_12 = null;
            // 0x01BFFA8C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01BFFA90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFFA94: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFFA98: MOV x2, x22                | X2 = 1152921510255173120 (0x1000000150AA9E00);//ML01
            // 0x01BFFA9C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_33 = val_12;
            // 0x01BFFAA0: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::LoadPathToABPath_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_12 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::LoadPathToABPath_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01BFFAA4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFFAA8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFFAAC: STR x23, [x8, #0x20]       | ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504784220192
            ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache4 = val_33;
            // 0x01BFFAB0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFFAB4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFFAB8: LDR x22, [x8, #0x20]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_37 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache4;
            label_22:
            // 0x01BFFABC: CBNZ x19, #0x1bffac4       | if (X1 != 0) goto label_23;             
            if(X1 != 0)
            {
                goto label_23;
            }
            // 0x01BFFAC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::LoadPathToABPath_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_23:
            // 0x01BFFAC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFFAC8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01BFFACC: MOV x1, x21                | X1 = val_11;//m1                        
            // 0x01BFFAD0: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01BFFAD4: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_11, func:  val_37);
            X1.RegisterCLRMethodRedirection(mi:  val_11, func:  val_37);
            // 0x01BFFAD8: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x01BFFADC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFFAE0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01BFFAE4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x01BFFAE8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFFAEC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01BFFAF0: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x01BFFAF4: LDR x22, [x27]             | X22 = typeof(System.String);            
            // 0x01BFFAF8: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFFAFC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01BFFB00: TBZ w9, #0, #0x1bffb14     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_25;
            // 0x01BFFB04: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01BFFB08: CBNZ w9, #0x1bffb14        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
            // 0x01BFFB0C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01BFFB10: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_25:
            // 0x01BFFB14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01BFFB18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01BFFB1C: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01BFFB20: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_13 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01BFFB24: MOV x22, x0                | X22 = val_13;//m1                       
            // 0x01BFFB28: CBNZ x21, #0x1bffb30       | if ( != null) goto label_26;            
            if(null != null)
            {
                goto label_26;
            }
            // 0x01BFFB2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_26:
            // 0x01BFFB30: CBZ x22, #0x1bffb54        | if (val_13 == null) goto label_28;      
            if(val_13 == null)
            {
                goto label_28;
            }
            // 0x01BFFB34: LDR x8, [x21]              | X8 = ;                                  
            // 0x01BFFB38: MOV x0, x22                | X0 = val_13;//m1                        
            // 0x01BFFB3C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01BFFB40: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_13, ????);     
            // 0x01BFFB44: CBNZ x0, #0x1bffb54        | if (val_13 != null) goto label_28;      
            if(val_13 != null)
            {
                goto label_28;
            }
            // 0x01BFFB48: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_13, ????);     
            // 0x01BFFB4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFFB50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            label_28:
            // 0x01BFFB54: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01BFFB58: CBNZ w8, #0x1bffb68        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_29;
            // 0x01BFFB5C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_13, ????);     
            // 0x01BFFB60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFFB64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            label_29:
            // 0x01BFFB68: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_13;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_13;
            // 0x01BFFB6C: CBNZ x20, #0x1bffb74       | if (val_1 != null) goto label_30;       
            if(val_1 != null)
            {
                goto label_30;
            }
            // 0x01BFFB70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_30:
            // 0x01BFFB74: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
            // 0x01BFFB78: LDR x8, [x8, #0xb80]       | X8 = (string**)(1152921510255178240)("LoadPathToABFullPath");
            // 0x01BFFB7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFFB80: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01BFFB84: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01BFFB88: LDR x1, [x8]               | X1 = "LoadPathToABFullPath";            
            // 0x01BFFB8C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01BFFB90: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFFB94: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01BFFB98: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "LoadPathToABFullPath", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_14 = val_1.GetMethod(name:  "LoadPathToABFullPath", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01BFFB9C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFFBA0: MOV x21, x0                | X21 = val_14;//m1                       
            // 0x01BFFBA4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFFBA8: LDR x22, [x8, #0x28]       | X22 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache5;
            val_38 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache5;
            // 0x01BFFBAC: CBNZ x22, #0x1bffbf8       | if (ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache5 != null) goto label_31;
            if(val_38 != null)
            {
                goto label_31;
            }
            // 0x01BFFBB0: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
            // 0x01BFFBB4: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01BFFBB8: LDR x8, [x8, #0xf30]       | X8 = 1152921510255182448;               
            // 0x01BFFBBC: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01BFFBC0: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::LoadPathToABFullPath_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01BFFBC4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_15 = null;
            // 0x01BFFBC8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01BFFBCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFFBD0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFFBD4: MOV x2, x22                | X2 = 1152921510255182448 (0x1000000150AAC270);//ML01
            // 0x01BFFBD8: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_33 = val_15;
            // 0x01BFFBDC: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::LoadPathToABFullPath_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_15 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::LoadPathToABFullPath_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01BFFBE0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFFBE4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFFBE8: STR x23, [x8, #0x28]       | ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache5 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504784220200
            ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache5 = val_33;
            // 0x01BFFBEC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFFBF0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFFBF4: LDR x22, [x8, #0x28]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_38 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache5;
            label_31:
            // 0x01BFFBF8: CBNZ x19, #0x1bffc00       | if (X1 != 0) goto label_32;             
            if(X1 != 0)
            {
                goto label_32;
            }
            // 0x01BFFBFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::LoadPathToABFullPath_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_32:
            // 0x01BFFC00: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFFC04: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01BFFC08: MOV x1, x21                | X1 = val_14;//m1                        
            // 0x01BFFC0C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01BFFC10: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_14, func:  val_38);
            X1.RegisterCLRMethodRedirection(mi:  val_14, func:  val_38);
            // 0x01BFFC14: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x01BFFC18: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFFC1C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01BFFC20: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x01BFFC24: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFFC28: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01BFFC2C: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x01BFFC30: LDR x22, [x27]             | X22 = typeof(System.String);            
            // 0x01BFFC34: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFFC38: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01BFFC3C: TBZ w9, #0, #0x1bffc50     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_34;
            // 0x01BFFC40: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01BFFC44: CBNZ w9, #0x1bffc50        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
            // 0x01BFFC48: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01BFFC4C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_34:
            // 0x01BFFC50: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01BFFC54: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01BFFC58: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01BFFC5C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_16 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01BFFC60: MOV x22, x0                | X22 = val_16;//m1                       
            // 0x01BFFC64: CBNZ x21, #0x1bffc6c       | if ( != null) goto label_35;            
            if(null != null)
            {
                goto label_35;
            }
            // 0x01BFFC68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_35:
            // 0x01BFFC6C: CBZ x22, #0x1bffc90        | if (val_16 == null) goto label_37;      
            if(val_16 == null)
            {
                goto label_37;
            }
            // 0x01BFFC70: LDR x8, [x21]              | X8 = ;                                  
            // 0x01BFFC74: MOV x0, x22                | X0 = val_16;//m1                        
            // 0x01BFFC78: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01BFFC7C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_16, ????);     
            // 0x01BFFC80: CBNZ x0, #0x1bffc90        | if (val_16 != null) goto label_37;      
            if(val_16 != null)
            {
                goto label_37;
            }
            // 0x01BFFC84: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_16, ????);     
            // 0x01BFFC88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFFC8C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            label_37:
            // 0x01BFFC90: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01BFFC94: CBNZ w8, #0x1bffca4        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_38;
            // 0x01BFFC98: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_16, ????);     
            // 0x01BFFC9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFFCA0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            label_38:
            // 0x01BFFCA4: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_16;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_16;
            // 0x01BFFCA8: CBNZ x20, #0x1bffcb0       | if (val_1 != null) goto label_39;       
            if(val_1 != null)
            {
                goto label_39;
            }
            // 0x01BFFCAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_39:
            // 0x01BFFCB0: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
            // 0x01BFFCB4: LDR x8, [x8, #0x9f0]       | X8 = (string**)(1152921510255187568)("LoadPathToAssetName");
            // 0x01BFFCB8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFFCBC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01BFFCC0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01BFFCC4: LDR x1, [x8]               | X1 = "LoadPathToAssetName";             
            // 0x01BFFCC8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01BFFCCC: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFFCD0: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01BFFCD4: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "LoadPathToAssetName", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_17 = val_1.GetMethod(name:  "LoadPathToAssetName", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01BFFCD8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFFCDC: MOV x21, x0                | X21 = val_17;//m1                       
            // 0x01BFFCE0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFFCE4: LDR x22, [x8, #0x30]       | X22 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache6;
            val_39 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache6;
            // 0x01BFFCE8: CBNZ x22, #0x1bffd34       | if (ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache6 != null) goto label_40;
            if(val_39 != null)
            {
                goto label_40;
            }
            // 0x01BFFCEC: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x01BFFCF0: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01BFFCF4: LDR x8, [x8, #0x820]       | X8 = 1152921510255191776;               
            // 0x01BFFCF8: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01BFFCFC: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::LoadPathToAssetName_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01BFFD00: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_18 = null;
            // 0x01BFFD04: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01BFFD08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFFD0C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFFD10: MOV x2, x22                | X2 = 1152921510255191776 (0x1000000150AAE6E0);//ML01
            // 0x01BFFD14: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_33 = val_18;
            // 0x01BFFD18: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::LoadPathToAssetName_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_18 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::LoadPathToAssetName_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01BFFD1C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFFD20: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFFD24: STR x23, [x8, #0x30]       | ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache6 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504784220208
            ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache6 = val_33;
            // 0x01BFFD28: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFFD2C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFFD30: LDR x22, [x8, #0x30]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_39 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache6;
            label_40:
            // 0x01BFFD34: CBNZ x19, #0x1bffd3c       | if (X1 != 0) goto label_41;             
            if(X1 != 0)
            {
                goto label_41;
            }
            // 0x01BFFD38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::LoadPathToAssetName_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_41:
            // 0x01BFFD3C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFFD40: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01BFFD44: MOV x1, x21                | X1 = val_17;//m1                        
            // 0x01BFFD48: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01BFFD4C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_17, func:  val_39);
            X1.RegisterCLRMethodRedirection(mi:  val_17, func:  val_39);
            // 0x01BFFD50: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x01BFFD54: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFFD58: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01BFFD5C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x01BFFD60: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFFD64: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01BFFD68: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x01BFFD6C: LDR x22, [x27]             | X22 = typeof(System.String);            
            // 0x01BFFD70: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFFD74: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01BFFD78: TBZ w9, #0, #0x1bffd8c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_43;
            // 0x01BFFD7C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01BFFD80: CBNZ w9, #0x1bffd8c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_43;
            // 0x01BFFD84: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01BFFD88: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_43:
            // 0x01BFFD8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01BFFD90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01BFFD94: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01BFFD98: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_19 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01BFFD9C: MOV x22, x0                | X22 = val_19;//m1                       
            // 0x01BFFDA0: CBNZ x21, #0x1bffda8       | if ( != null) goto label_44;            
            if(null != null)
            {
                goto label_44;
            }
            // 0x01BFFDA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
            label_44:
            // 0x01BFFDA8: CBZ x22, #0x1bffdcc        | if (val_19 == null) goto label_46;      
            if(val_19 == null)
            {
                goto label_46;
            }
            // 0x01BFFDAC: LDR x8, [x21]              | X8 = ;                                  
            // 0x01BFFDB0: MOV x0, x22                | X0 = val_19;//m1                        
            // 0x01BFFDB4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01BFFDB8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_19, ????);     
            // 0x01BFFDBC: CBNZ x0, #0x1bffdcc        | if (val_19 != null) goto label_46;      
            if(val_19 != null)
            {
                goto label_46;
            }
            // 0x01BFFDC0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_19, ????);     
            // 0x01BFFDC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFFDC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            label_46:
            // 0x01BFFDCC: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01BFFDD0: CBNZ w8, #0x1bffde0        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_47;
            // 0x01BFFDD4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_19, ????);     
            // 0x01BFFDD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFFDDC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            label_47:
            // 0x01BFFDE0: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_19;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_19;
            // 0x01BFFDE4: CBNZ x20, #0x1bffdec       | if (val_1 != null) goto label_48;       
            if(val_1 != null)
            {
                goto label_48;
            }
            // 0x01BFFDE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
            label_48:
            // 0x01BFFDEC: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
            // 0x01BFFDF0: LDR x8, [x8, #0x10]        | X8 = (string**)(1152921510255196896)("AssetNameToABPath");
            // 0x01BFFDF4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFFDF8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01BFFDFC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01BFFE00: LDR x1, [x8]               | X1 = "AssetNameToABPath";               
            // 0x01BFFE04: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01BFFE08: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFFE0C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01BFFE10: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "AssetNameToABPath", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_20 = val_1.GetMethod(name:  "AssetNameToABPath", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01BFFE14: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFFE18: MOV x21, x0                | X21 = val_20;//m1                       
            // 0x01BFFE1C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFFE20: LDR x22, [x8, #0x38]       | X22 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache7;
            val_40 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache7;
            // 0x01BFFE24: CBNZ x22, #0x1bffe70       | if (ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache7 != null) goto label_49;
            if(val_40 != null)
            {
                goto label_49;
            }
            // 0x01BFFE28: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x01BFFE2C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01BFFE30: LDR x8, [x8, #0x898]       | X8 = 1152921510255201104;               
            // 0x01BFFE34: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01BFFE38: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::AssetNameToABPath_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01BFFE3C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_21 = null;
            // 0x01BFFE40: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01BFFE44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFFE48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFFE4C: MOV x2, x22                | X2 = 1152921510255201104 (0x1000000150AB0B50);//ML01
            // 0x01BFFE50: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_33 = val_21;
            // 0x01BFFE54: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::AssetNameToABPath_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_21 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::AssetNameToABPath_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01BFFE58: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFFE5C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFFE60: STR x23, [x8, #0x38]       | ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache7 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504784220216
            ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache7 = val_33;
            // 0x01BFFE64: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFFE68: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFFE6C: LDR x22, [x8, #0x38]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_40 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache7;
            label_49:
            // 0x01BFFE70: CBNZ x19, #0x1bffe78       | if (X1 != 0) goto label_50;             
            if(X1 != 0)
            {
                goto label_50;
            }
            // 0x01BFFE74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::AssetNameToABPath_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_50:
            // 0x01BFFE78: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFFE7C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01BFFE80: MOV x1, x21                | X1 = val_20;//m1                        
            // 0x01BFFE84: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01BFFE88: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_20, func:  val_40);
            X1.RegisterCLRMethodRedirection(mi:  val_20, func:  val_40);
            // 0x01BFFE8C: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x01BFFE90: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFFE94: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01BFFE98: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x01BFFE9C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFFEA0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01BFFEA4: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x01BFFEA8: LDR x22, [x27]             | X22 = typeof(System.String);            
            // 0x01BFFEAC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFFEB0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01BFFEB4: TBZ w9, #0, #0x1bffec8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_52;
            // 0x01BFFEB8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01BFFEBC: CBNZ w9, #0x1bffec8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_52;
            // 0x01BFFEC0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01BFFEC4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_52:
            // 0x01BFFEC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01BFFECC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01BFFED0: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01BFFED4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_22 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01BFFED8: MOV x22, x0                | X22 = val_22;//m1                       
            // 0x01BFFEDC: CBNZ x21, #0x1bffee4       | if ( != null) goto label_53;            
            if(null != null)
            {
                goto label_53;
            }
            // 0x01BFFEE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
            label_53:
            // 0x01BFFEE4: CBZ x22, #0x1bfff08        | if (val_22 == null) goto label_55;      
            if(val_22 == null)
            {
                goto label_55;
            }
            // 0x01BFFEE8: LDR x8, [x21]              | X8 = ;                                  
            // 0x01BFFEEC: MOV x0, x22                | X0 = val_22;//m1                        
            // 0x01BFFEF0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01BFFEF4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_22, ????);     
            // 0x01BFFEF8: CBNZ x0, #0x1bfff08        | if (val_22 != null) goto label_55;      
            if(val_22 != null)
            {
                goto label_55;
            }
            // 0x01BFFEFC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_22, ????);     
            // 0x01BFFF00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFFF04: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_22, ????);     
            label_55:
            // 0x01BFFF08: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01BFFF0C: CBNZ w8, #0x1bfff1c        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_56;
            // 0x01BFFF10: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_22, ????);     
            // 0x01BFFF14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFFF18: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_22, ????);     
            label_56:
            // 0x01BFFF1C: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_22;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_22;
            // 0x01BFFF20: CBNZ x20, #0x1bfff28       | if (val_1 != null) goto label_57;       
            if(val_1 != null)
            {
                goto label_57;
            }
            // 0x01BFFF24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
            label_57:
            // 0x01BFFF28: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x01BFFF2C: LDR x8, [x8, #0xd28]       | X8 = (string**)(1152921510255206224)("GetIsCompressByABName");
            // 0x01BFFF30: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFFF34: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01BFFF38: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01BFFF3C: LDR x1, [x8]               | X1 = "GetIsCompressByABName";           
            // 0x01BFFF40: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01BFFF44: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFFF48: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01BFFF4C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "GetIsCompressByABName", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_23 = val_1.GetMethod(name:  "GetIsCompressByABName", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01BFFF50: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFFF54: MOV x21, x0                | X21 = val_23;//m1                       
            // 0x01BFFF58: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFFF5C: LDR x22, [x8, #0x40]       | X22 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache8;
            val_41 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache8;
            // 0x01BFFF60: CBNZ x22, #0x1bfffac       | if (ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache8 != null) goto label_58;
            if(val_41 != null)
            {
                goto label_58;
            }
            // 0x01BFFF64: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x01BFFF68: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01BFFF6C: LDR x8, [x8, #0xce0]       | X8 = 1152921510255210432;               
            // 0x01BFFF70: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01BFFF74: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::GetIsCompressByABName_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01BFFF78: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_24 = null;
            // 0x01BFFF7C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01BFFF80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFFF84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFFF88: MOV x2, x22                | X2 = 1152921510255210432 (0x1000000150AB2FC0);//ML01
            // 0x01BFFF8C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_33 = val_24;
            // 0x01BFFF90: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::GetIsCompressByABName_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_24 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::GetIsCompressByABName_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01BFFF94: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFFF98: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFFF9C: STR x23, [x8, #0x40]       | ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache8 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504784220224
            ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache8 = val_33;
            // 0x01BFFFA0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01BFFFA4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01BFFFA8: LDR x22, [x8, #0x40]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_41 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache8;
            label_58:
            // 0x01BFFFAC: CBNZ x19, #0x1bfffb4       | if (X1 != 0) goto label_59;             
            if(X1 != 0)
            {
                goto label_59;
            }
            // 0x01BFFFB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::GetIsCompressByABName_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_59:
            // 0x01BFFFB4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01BFFFB8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01BFFFBC: MOV x1, x21                | X1 = val_23;//m1                        
            // 0x01BFFFC0: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01BFFFC4: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_23, func:  val_41);
            X1.RegisterCLRMethodRedirection(mi:  val_23, func:  val_41);
            // 0x01BFFFC8: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x01BFFFCC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFFFD0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01BFFFD4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x01BFFFD8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFFFDC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01BFFFE0: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x01BFFFE4: LDR x22, [x27]             | X22 = typeof(System.String);            
            // 0x01BFFFE8: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01BFFFEC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01BFFFF0: TBZ w9, #0, #0x1c00004     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_61;
            // 0x01BFFFF4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01BFFFF8: CBNZ w9, #0x1c00004        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_61;
            // 0x01BFFFFC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01C00000: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_61:
            // 0x01C00004: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00008: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C0000C: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01C00010: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_25 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C00014: MOV x22, x0                | X22 = val_25;//m1                       
            // 0x01C00018: CBNZ x21, #0x1c00020       | if ( != null) goto label_62;            
            if(null != null)
            {
                goto label_62;
            }
            // 0x01C0001C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
            label_62:
            // 0x01C00020: CBZ x22, #0x1c00044        | if (val_25 == null) goto label_64;      
            if(val_25 == null)
            {
                goto label_64;
            }
            // 0x01C00024: LDR x8, [x21]              | X8 = ;                                  
            // 0x01C00028: MOV x0, x22                | X0 = val_25;//m1                        
            // 0x01C0002C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01C00030: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_25, ????);     
            // 0x01C00034: CBNZ x0, #0x1c00044        | if (val_25 != null) goto label_64;      
            if(val_25 != null)
            {
                goto label_64;
            }
            // 0x01C00038: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_25, ????);     
            // 0x01C0003C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C00040: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_25, ????);     
            label_64:
            // 0x01C00044: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01C00048: CBNZ w8, #0x1c00058        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_65;
            // 0x01C0004C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_25, ????);     
            // 0x01C00050: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C00054: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_25, ????);     
            label_65:
            // 0x01C00058: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_25;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_25;
            // 0x01C0005C: CBNZ x20, #0x1c00064       | if (val_1 != null) goto label_66;       
            if(val_1 != null)
            {
                goto label_66;
            }
            // 0x01C00060: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
            label_66:
            // 0x01C00064: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x01C00068: LDR x8, [x8, #0x3a0]       | X8 = (string**)(1152921510255215552)("IsNullAsset");
            // 0x01C0006C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C00070: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01C00074: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01C00078: LDR x1, [x8]               | X1 = "IsNullAsset";                     
            // 0x01C0007C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01C00080: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01C00084: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01C00088: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "IsNullAsset", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_26 = val_1.GetMethod(name:  "IsNullAsset", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01C0008C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01C00090: MOV x21, x0                | X21 = val_26;//m1                       
            // 0x01C00094: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C00098: LDR x22, [x8, #0x48]       | X22 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache9;
            val_42 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache9;
            // 0x01C0009C: CBNZ x22, #0x1c000e8       | if (ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache9 != null) goto label_67;
            if(val_42 != null)
            {
                goto label_67;
            }
            // 0x01C000A0: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
            // 0x01C000A4: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01C000A8: LDR x8, [x8, #0x5c0]       | X8 = 1152921510255219744;               
            // 0x01C000AC: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01C000B0: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::IsNullAsset_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01C000B4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_27 = null;
            // 0x01C000B8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01C000BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C000C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C000C4: MOV x2, x22                | X2 = 1152921510255219744 (0x1000000150AB5420);//ML01
            // 0x01C000C8: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_33 = val_27;
            // 0x01C000CC: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::IsNullAsset_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_27 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::IsNullAsset_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01C000D0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01C000D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C000D8: STR x23, [x8, #0x48]       | ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache9 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504784220232
            ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache9 = val_33;
            // 0x01C000DC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01C000E0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C000E4: LDR x22, [x8, #0x48]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_42 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cache9;
            label_67:
            // 0x01C000E8: CBNZ x19, #0x1c000f0       | if (X1 != 0) goto label_68;             
            if(X1 != 0)
            {
                goto label_68;
            }
            // 0x01C000EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::IsNullAsset_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_68:
            // 0x01C000F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C000F4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C000F8: MOV x1, x21                | X1 = val_26;//m1                        
            // 0x01C000FC: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01C00100: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_26, func:  val_42);
            X1.RegisterCLRMethodRedirection(mi:  val_26, func:  val_42);
            // 0x01C00104: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01C00108: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C0010C: LDR x21, [x8, #0x58]       | X21 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__am$cache0;
            val_43 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__am$cache0;
            // 0x01C00110: CBNZ x21, #0x1c0015c       | if (ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__am$cache0 != null) goto label_69;
            if(val_43 != null)
            {
                goto label_69;
            }
            // 0x01C00114: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x01C00118: ADRP x9, #0x3682000        | X9 = 57155584 (0x3682000);              
            // 0x01C0011C: LDR x8, [x8, #0xbc8]       | X8 = 1152921510255220768;               
            // 0x01C00120: LDR x9, [x9, #0x9a0]       | X9 = 1152921504824152064;               
            // 0x01C00124: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::<Register>m__0();
            // 0x01C00128: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_28 = null;
            // 0x01C0012C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate), ????);
            // 0x01C00130: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C00134: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C00138: MOV x2, x21                | X2 = 1152921510255220768 (0x1000000150AB5820);//ML01
            // 0x01C0013C: MOV x22, x0                | X22 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x01C00140: BL #0x28e8d84              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::<Register>m__0());
            val_28 = new ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::<Register>m__0());
            // 0x01C00144: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01C00148: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C0014C: STR x22, [x8, #0x58]       | ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__am$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);  //  dest_result_addr=1152921504784220248
            ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__am$cache0 = val_28;
            // 0x01C00150: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01C00154: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C00158: LDR x21, [x8, #0x58]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            val_43 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__am$cache0;
            label_69:
            // 0x01C0015C: CBNZ x19, #0x1c00164       | if (X1 != 0) goto label_70;             
            if(X1 != 0)
            {
                goto label_70;
            }
            // 0x01C00160: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::<Register>m__0()), ????);
            label_70:
            // 0x01C00164: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C00168: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C0016C: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x01C00170: MOV x2, x21                | X2 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x01C00174: BL #0x28e5b28              | X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_43);
            X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_43);
            // 0x01C00178: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01C0017C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C00180: LDR x21, [x8, #0x60]       | X21 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__am$cache1;
            val_44 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__am$cache1;
            // 0x01C00184: CBNZ x21, #0x1c001d0       | if (ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__am$cache1 != null) goto label_71;
            if(val_44 != null)
            {
                goto label_71;
            }
            // 0x01C00188: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
            // 0x01C0018C: ADRP x9, #0x3651000        | X9 = 56954880 (0x3651000);              
            // 0x01C00190: LDR x8, [x8, #0x678]       | X8 = 1152921510255221792;               
            // 0x01C00194: LDR x9, [x9, #0x3f8]       | X9 = 1152921504824205312;               
            // 0x01C00198: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::<Register>m__1(int s);
            // 0x01C0019C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_29 = null;
            // 0x01C001A0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate), ????);
            // 0x01C001A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C001A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C001AC: MOV x2, x21                | X2 = 1152921510255221792 (0x1000000150AB5C20);//ML01
            // 0x01C001B0: MOV x22, x0                | X22 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x01C001B4: BL #0x28e8ac8              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::<Register>m__1(int s));
            val_29 = new ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::<Register>m__1(int s));
            // 0x01C001B8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01C001BC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C001C0: STR x22, [x8, #0x60]       | ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__am$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);  //  dest_result_addr=1152921504784220256
            ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__am$cache1 = val_29;
            // 0x01C001C4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01C001C8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C001CC: LDR x21, [x8, #0x60]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            val_44 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__am$cache1;
            label_71:
            // 0x01C001D0: CBNZ x19, #0x1c001d8       | if (X1 != 0) goto label_72;             
            if(X1 != 0)
            {
                goto label_72;
            }
            // 0x01C001D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::<Register>m__1(int s)), ????);
            label_72:
            // 0x01C001D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C001DC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C001E0: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x01C001E4: MOV x2, x21                | X2 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x01C001E8: BL #0x28e5bd8              | X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_44);
            X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_44);
            // 0x01C001EC: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x01C001F0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01C001F4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01C001F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C001FC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01C00200: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01C00204: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01C00208: CBNZ x20, #0x1c00210       | if (val_1 != null) goto label_73;       
            if(val_1 != null)
            {
                goto label_73;
            }
            // 0x01C0020C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_73:
            // 0x01C00210: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C00214: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01C00218: ORR w1, wzr, #0x1e         | W1 = 30(0x1E);                          
            // 0x01C0021C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01C00220: MOV x3, x21                | X3 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01C00224: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01C00228: BL #0x1b6ea10              | X0 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.ConstructorInfo val_30 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01C0022C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01C00230: MOV x20, x0                | X20 = val_30;//m1                       
            // 0x01C00234: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C00238: LDR x21, [x8, #0x50]       | X21 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cacheA;
            val_45 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cacheA;
            // 0x01C0023C: CBNZ x21, #0x1c00288       | if (ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cacheA != null) goto label_74;
            if(val_45 != null)
            {
                goto label_74;
            }
            // 0x01C00240: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x01C00244: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01C00248: LDR x8, [x8, #0x368]       | X8 = 1152921510255226912;               
            // 0x01C0024C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01C00250: LDR x21, [x8]              | X21 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01C00254: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_31 = null;
            // 0x01C00258: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01C0025C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C00260: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C00264: MOV x2, x21                | X2 = 1152921510255226912 (0x1000000150AB7020);//ML01
            // 0x01C00268: MOV x22, x0                | X22 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01C0026C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_31 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01C00270: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01C00274: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C00278: STR x22, [x8, #0x50]       | ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cacheA = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504784220240
            ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cacheA = val_31;
            // 0x01C0027C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding);
            // 0x01C00280: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x01C00284: LDR x21, [x8, #0x50]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_45 = ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding.<>f__mg$cacheA;
            label_74:
            // 0x01C00288: CBNZ x19, #0x1c00290       | if (X1 != 0) goto label_75;             
            if(X1 != 0)
            {
                goto label_75;
            }
            // 0x01C0028C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ConfigAssetMgr_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_75:
            // 0x01C00290: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C00294: MOV x1, x20                | X1 = val_30;//m1                        
            // 0x01C00298: MOV x2, x21                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01C0029C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01C002A0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01C002A4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x01C002A8: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x01C002AC: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x01C002B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C002B4: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x01C002B8: B #0x28e3b20               | X1.RegisterCLRMethodRedirection(mi:  val_30, func:  val_45); return;
            X1.RegisterCLRMethodRedirection(mi:  val_30, func:  val_45);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01C002BC (29360828), len: 612  VirtAddr: 0x01C002BC RVA: 0x01C002BC token: 100665077 methodIndex: 31126 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_isLoaded_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            bool val_14;
            //  | 
            var val_15;
            // 0x01C002BC: STP x26, x25, [sp, #-0x50]! | stack[1152921510255458352] = ???;  stack[1152921510255458360] = ???;  //  dest_result_addr=1152921510255458352 |  dest_result_addr=1152921510255458360
            // 0x01C002C0: STP x24, x23, [sp, #0x10]  | stack[1152921510255458368] = ???;  stack[1152921510255458376] = ???;  //  dest_result_addr=1152921510255458368 |  dest_result_addr=1152921510255458376
            // 0x01C002C4: STP x22, x21, [sp, #0x20]  | stack[1152921510255458384] = ???;  stack[1152921510255458392] = ???;  //  dest_result_addr=1152921510255458384 |  dest_result_addr=1152921510255458392
            // 0x01C002C8: STP x20, x19, [sp, #0x30]  | stack[1152921510255458400] = ???;  stack[1152921510255458408] = ???;  //  dest_result_addr=1152921510255458400 |  dest_result_addr=1152921510255458408
            // 0x01C002CC: STP x29, x30, [sp, #0x40]  | stack[1152921510255458416] = ???;  stack[1152921510255458424] = ???;  //  dest_result_addr=1152921510255458416 |  dest_result_addr=1152921510255458424
            // 0x01C002D0: ADD x29, sp, #0x40         | X29 = (1152921510255458352 + 64) = 1152921510255458416 (0x1000000150AEF870);
            // 0x01C002D4: SUB sp, sp, #0x10          | SP = (1152921510255458352 - 16) = 1152921510255458336 (0x1000000150AEF820);
            // 0x01C002D8: ADRP x19, #0x373c000       | X19 = 57917440 (0x373C000);             
            // 0x01C002DC: LDRB w8, [x19, #0x251]     | W8 = (bool)static_value_0373C251;       
            // 0x01C002E0: MOV x22, x3                | X22 = X3;//m1                           
            // 0x01C002E4: MOV x21, x2                | X21 = X2;//m1                           
            // 0x01C002E8: MOV x20, x1                | X20 = X1;//m1                           
            // 0x01C002EC: TBNZ w8, #0, #0x1c00308    | if (static_value_0373C251 == true) goto label_0;
            // 0x01C002F0: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
            // 0x01C002F4: LDR x8, [x8, #0xb88]       | X8 = 0x2B92748;                         
            // 0x01C002F8: LDR w0, [x8]               | W0 = 0x2097;                            
            // 0x01C002FC: BL #0x2782188              | X0 = sub_2782188( ?? 0x2097, ????);     
            // 0x01C00300: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C00304: STRB w8, [x19, #0x251]     | static_value_0373C251 = true;            //  dest_result_addr=57918033
            label_0:
            // 0x01C00308: CBNZ x20, #0x1c00310       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01C0030C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2097, ????);     
            label_1:
            // 0x01C00310: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C00314: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C00318: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01C0031C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01C00320: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00324: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C00328: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01C0032C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01C00330: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C00334: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x01C00338: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C0033C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C00340: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01C00344: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01C00348: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C0034C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01C00350: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01C00354: ADRP x9, #0x35c9000        | X9 = 56397824 (0x35C9000);              
            // 0x01C00358: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x01C0035C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01C00360: LDR x9, [x9, #0xc30]       | X9 = 1152921504904183808;               
            // 0x01C00364: LDR x24, [x9]              | X24 = typeof(ConfigAssetMgr);           
            // 0x01C00368: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01C0036C: TBZ w9, #0, #0x1c00380     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01C00370: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01C00374: CBNZ w9, #0x1c00380        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01C00378: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01C0037C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01C00380: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00384: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C00388: MOV x1, x24                | X1 = 1152921504904183808 (0x1000000011B90000);//ML01
            // 0x01C0038C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C00390: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x01C00394: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x01C00398: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01C0039C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01C003A0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01C003A4: TBZ w9, #0, #0x1c003b8     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01C003A8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01C003AC: CBNZ w9, #0x1c003b8        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01C003B0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01C003B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01C003B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C003BC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01C003C0: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01C003C4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01C003C8: MOV x3, x22                | X3 = X3;//m1                            
            // 0x01C003CC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01C003D0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01C003D4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01C003D8: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x01C003DC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01C003E0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01C003E4: TBZ w9, #0, #0x1c003f8     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01C003E8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01C003EC: CBNZ w9, #0x1c003f8        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01C003F0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01C003F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01C003F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C003FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C00400: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01C00404: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x01C00408: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01C0040C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x01C00410: CBZ x0, #0x1c00474         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x01C00414: ADRP x9, #0x3654000        | X9 = 56967168 (0x3654000);              
            // 0x01C00418: LDR x9, [x9, #0xb08]       | X9 = 1152921504904183808;               
            // 0x01C0041C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01C00420: LDR x1, [x9]               | X1 = typeof(ConfigAssetMgr);            
            // 0x01C00424: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C00428: LDRB w9, [x1, #0x104]      | W9 = ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C0042C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C00430: B.LO #0x1c0044c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x01C00434: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01C00438: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHi
            // 0x01C0043C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C00440: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ConfigAssetMgr))
            // 0x01C00444: MOV x22, x0                | X22 = val_6;//m1                        
            val_13 = val_6;
            // 0x01C00448: B.EQ #0x1c00474            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x01C0044C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01C00450: ADD x8, sp, #8             | X8 = (1152921510255458336 + 8) = 1152921510255458344 (0x1000000150AEF828);
            // 0x01C00454: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01C00458: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510255446432]
            // 0x01C0045C: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x01C00460: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C00464: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x01C00468: ADD x0, sp, #8             | X0 = (1152921510255458336 + 8) = 1152921510255458344 (0x1000000150AEF828);
            // 0x01C0046C: BL #0x299a140              | 
            // 0x01C00470: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_10:
            // 0x01C00474: CBNZ x20, #0x1c0047c       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x01C00478: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150AEF828, ????);
            label_11:
            // 0x01C0047C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C00480: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C00484: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01C00488: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01C0048C: CBNZ x22, #0x1c00494       | if (0x0 != 0) goto label_12;            
            if(val_13 != 0)
            {
                goto label_12;
            }
            // 0x01C00490: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x01C00494: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C00498: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x01C0049C: BL #0xb42a8c               | X0 = val_13.get_isLoaded();             
            bool val_9 = val_13.isLoaded;
            // 0x01C004A0: MOV w20, w0                | W20 = val_9;//m1                        
            // 0x01C004A4: CBZ x19, #0x1c004b8        | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x01C004A8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C004AC: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x01C004B0: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x01C004B4: B #0x1c004cc               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x01C004B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x01C004BC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C004C0: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x01C004C4: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x01C004C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_14:
            // 0x01C004CC: STR w20, [x19, #4]         | mem2[0] = (val_9 & 1);                   //  dest_result_addr=0
            mem2[0] = val_14;
            // 0x01C004D0: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01C004D4: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_15 = 8;
            // 0x01C004D8: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x01C004DC: TBZ w9, #0, #0x1c004ec     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_15;
            // 0x01C004E0: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x01C004E4: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x01C004E8: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_15 = 219381744;
            label_15:
            // 0x01C004EC: ADD x0, x8, x19            | X0 = (val_15 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_15 + val_2;
            // 0x01C004F0: SUB sp, x29, #0x40         | SP = (1152921510255458416 - 64) = 1152921510255458352 (0x1000000150AEF830);
            // 0x01C004F4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01C004F8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01C004FC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01C00500: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01C00504: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x01C00508: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_15 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01C0050C: MOV x19, x0                | 
            // 0x01C00510: ADD x0, sp, #8             | 
            // 0x01C00514: BL #0x299a140              | 
            // 0x01C00518: MOV x0, x19                | 
            // 0x01C0051C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01C00520 (29361440), len: 612  VirtAddr: 0x01C00520 RVA: 0x01C00520 token: 100665078 methodIndex: 31127 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_isLoading_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            bool val_14;
            //  | 
            var val_15;
            // 0x01C00520: STP x26, x25, [sp, #-0x50]! | stack[1152921510255627696] = ???;  stack[1152921510255627704] = ???;  //  dest_result_addr=1152921510255627696 |  dest_result_addr=1152921510255627704
            // 0x01C00524: STP x24, x23, [sp, #0x10]  | stack[1152921510255627712] = ???;  stack[1152921510255627720] = ???;  //  dest_result_addr=1152921510255627712 |  dest_result_addr=1152921510255627720
            // 0x01C00528: STP x22, x21, [sp, #0x20]  | stack[1152921510255627728] = ???;  stack[1152921510255627736] = ???;  //  dest_result_addr=1152921510255627728 |  dest_result_addr=1152921510255627736
            // 0x01C0052C: STP x20, x19, [sp, #0x30]  | stack[1152921510255627744] = ???;  stack[1152921510255627752] = ???;  //  dest_result_addr=1152921510255627744 |  dest_result_addr=1152921510255627752
            // 0x01C00530: STP x29, x30, [sp, #0x40]  | stack[1152921510255627760] = ???;  stack[1152921510255627768] = ???;  //  dest_result_addr=1152921510255627760 |  dest_result_addr=1152921510255627768
            // 0x01C00534: ADD x29, sp, #0x40         | X29 = (1152921510255627696 + 64) = 1152921510255627760 (0x1000000150B18DF0);
            // 0x01C00538: SUB sp, sp, #0x10          | SP = (1152921510255627696 - 16) = 1152921510255627680 (0x1000000150B18DA0);
            // 0x01C0053C: ADRP x19, #0x373c000       | X19 = 57917440 (0x373C000);             
            // 0x01C00540: LDRB w8, [x19, #0x252]     | W8 = (bool)static_value_0373C252;       
            // 0x01C00544: MOV x22, x3                | X22 = X3;//m1                           
            // 0x01C00548: MOV x21, x2                | X21 = X2;//m1                           
            // 0x01C0054C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x01C00550: TBNZ w8, #0, #0x1c0056c    | if (static_value_0373C252 == true) goto label_0;
            // 0x01C00554: ADRP x8, #0x3648000        | X8 = 56918016 (0x3648000);              
            // 0x01C00558: LDR x8, [x8, #0xde8]       | X8 = 0x2B9274C;                         
            // 0x01C0055C: LDR w0, [x8]               | W0 = 0x2098;                            
            // 0x01C00560: BL #0x2782188              | X0 = sub_2782188( ?? 0x2098, ????);     
            // 0x01C00564: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C00568: STRB w8, [x19, #0x252]     | static_value_0373C252 = true;            //  dest_result_addr=57918034
            label_0:
            // 0x01C0056C: CBNZ x20, #0x1c00574       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01C00570: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2098, ????);     
            label_1:
            // 0x01C00574: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C00578: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C0057C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01C00580: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01C00584: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00588: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C0058C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01C00590: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01C00594: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C00598: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x01C0059C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C005A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C005A4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01C005A8: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01C005AC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C005B0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01C005B4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01C005B8: ADRP x9, #0x35c9000        | X9 = 56397824 (0x35C9000);              
            // 0x01C005BC: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x01C005C0: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01C005C4: LDR x9, [x9, #0xc30]       | X9 = 1152921504904183808;               
            // 0x01C005C8: LDR x24, [x9]              | X24 = typeof(ConfigAssetMgr);           
            // 0x01C005CC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01C005D0: TBZ w9, #0, #0x1c005e4     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01C005D4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01C005D8: CBNZ w9, #0x1c005e4        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01C005DC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01C005E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01C005E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C005E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C005EC: MOV x1, x24                | X1 = 1152921504904183808 (0x1000000011B90000);//ML01
            // 0x01C005F0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C005F4: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x01C005F8: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x01C005FC: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01C00600: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01C00604: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01C00608: TBZ w9, #0, #0x1c0061c     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01C0060C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01C00610: CBNZ w9, #0x1c0061c        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01C00614: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01C00618: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01C0061C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00620: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01C00624: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01C00628: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01C0062C: MOV x3, x22                | X3 = X3;//m1                            
            // 0x01C00630: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01C00634: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01C00638: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01C0063C: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x01C00640: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01C00644: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01C00648: TBZ w9, #0, #0x1c0065c     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01C0064C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01C00650: CBNZ w9, #0x1c0065c        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01C00654: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01C00658: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01C0065C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00660: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C00664: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01C00668: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x01C0066C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01C00670: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x01C00674: CBZ x0, #0x1c006d8         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x01C00678: ADRP x9, #0x3654000        | X9 = 56967168 (0x3654000);              
            // 0x01C0067C: LDR x9, [x9, #0xb08]       | X9 = 1152921504904183808;               
            // 0x01C00680: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01C00684: LDR x1, [x9]               | X1 = typeof(ConfigAssetMgr);            
            // 0x01C00688: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C0068C: LDRB w9, [x1, #0x104]      | W9 = ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C00690: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C00694: B.LO #0x1c006b0            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x01C00698: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01C0069C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHi
            // 0x01C006A0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C006A4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ConfigAssetMgr))
            // 0x01C006A8: MOV x22, x0                | X22 = val_6;//m1                        
            val_13 = val_6;
            // 0x01C006AC: B.EQ #0x1c006d8            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x01C006B0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01C006B4: ADD x8, sp, #8             | X8 = (1152921510255627680 + 8) = 1152921510255627688 (0x1000000150B18DA8);
            // 0x01C006B8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01C006BC: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510255615776]
            // 0x01C006C0: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x01C006C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C006C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x01C006CC: ADD x0, sp, #8             | X0 = (1152921510255627680 + 8) = 1152921510255627688 (0x1000000150B18DA8);
            // 0x01C006D0: BL #0x299a140              | 
            // 0x01C006D4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_10:
            // 0x01C006D8: CBNZ x20, #0x1c006e0       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x01C006DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150B18DA8, ????);
            label_11:
            // 0x01C006E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C006E4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C006E8: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01C006EC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01C006F0: CBNZ x22, #0x1c006f8       | if (0x0 != 0) goto label_12;            
            if(val_13 != 0)
            {
                goto label_12;
            }
            // 0x01C006F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x01C006F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C006FC: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x01C00700: BL #0xb42aa0               | X0 = val_13.get_isLoading();            
            bool val_9 = val_13.isLoading;
            // 0x01C00704: MOV w20, w0                | W20 = val_9;//m1                        
            // 0x01C00708: CBZ x19, #0x1c0071c        | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x01C0070C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C00710: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x01C00714: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x01C00718: B #0x1c00730               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x01C0071C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x01C00720: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C00724: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x01C00728: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x01C0072C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_14:
            // 0x01C00730: STR w20, [x19, #4]         | mem2[0] = (val_9 & 1);                   //  dest_result_addr=0
            mem2[0] = val_14;
            // 0x01C00734: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01C00738: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_15 = 8;
            // 0x01C0073C: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x01C00740: TBZ w9, #0, #0x1c00750     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_15;
            // 0x01C00744: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x01C00748: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x01C0074C: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_15 = 219381744;
            label_15:
            // 0x01C00750: ADD x0, x8, x19            | X0 = (val_15 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_15 + val_2;
            // 0x01C00754: SUB sp, x29, #0x40         | SP = (1152921510255627760 - 64) = 1152921510255627696 (0x1000000150B18DB0);
            // 0x01C00758: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01C0075C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01C00760: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01C00764: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01C00768: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x01C0076C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_15 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01C00770: MOV x19, x0                | 
            // 0x01C00774: ADD x0, sp, #8             | 
            // 0x01C00778: BL #0x299a140              | 
            // 0x01C0077C: MOV x0, x19                | 
            // 0x01C00780: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01C00784 (29362052), len: 588  VirtAddr: 0x01C00784 RVA: 0x01C00784 token: 100665079 methodIndex: 31128 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_loadProgress_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x01C00784: STP x26, x25, [sp, #-0x50]! | stack[1152921510255797040] = ???;  stack[1152921510255797048] = ???;  //  dest_result_addr=1152921510255797040 |  dest_result_addr=1152921510255797048
            // 0x01C00788: STP x24, x23, [sp, #0x10]  | stack[1152921510255797056] = ???;  stack[1152921510255797064] = ???;  //  dest_result_addr=1152921510255797056 |  dest_result_addr=1152921510255797064
            // 0x01C0078C: STP x22, x21, [sp, #0x20]  | stack[1152921510255797072] = ???;  stack[1152921510255797080] = ???;  //  dest_result_addr=1152921510255797072 |  dest_result_addr=1152921510255797080
            // 0x01C00790: STP x20, x19, [sp, #0x30]  | stack[1152921510255797088] = ???;  stack[1152921510255797096] = ???;  //  dest_result_addr=1152921510255797088 |  dest_result_addr=1152921510255797096
            // 0x01C00794: STP x29, x30, [sp, #0x40]  | stack[1152921510255797104] = ???;  stack[1152921510255797112] = ???;  //  dest_result_addr=1152921510255797104 |  dest_result_addr=1152921510255797112
            // 0x01C00798: ADD x29, sp, #0x40         | X29 = (1152921510255797040 + 64) = 1152921510255797104 (0x1000000150B42370);
            // 0x01C0079C: SUB sp, sp, #0x10          | SP = (1152921510255797040 - 16) = 1152921510255797024 (0x1000000150B42320);
            // 0x01C007A0: ADRP x19, #0x373c000       | X19 = 57917440 (0x373C000);             
            // 0x01C007A4: LDRB w8, [x19, #0x253]     | W8 = (bool)static_value_0373C253;       
            // 0x01C007A8: MOV x22, x3                | X22 = X3;//m1                           
            // 0x01C007AC: MOV x21, x2                | X21 = X2;//m1                           
            // 0x01C007B0: MOV x20, x1                | X20 = X1;//m1                           
            // 0x01C007B4: TBNZ w8, #0, #0x1c007d0    | if (static_value_0373C253 == true) goto label_0;
            // 0x01C007B8: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x01C007BC: LDR x8, [x8, #0x198]       | X8 = 0x2B92750;                         
            // 0x01C007C0: LDR w0, [x8]               | W0 = 0x2099;                            
            // 0x01C007C4: BL #0x2782188              | X0 = sub_2782188( ?? 0x2099, ????);     
            // 0x01C007C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C007CC: STRB w8, [x19, #0x253]     | static_value_0373C253 = true;            //  dest_result_addr=57918035
            label_0:
            // 0x01C007D0: CBNZ x20, #0x1c007d8       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01C007D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2099, ????);     
            label_1:
            // 0x01C007D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C007DC: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C007E0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01C007E4: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01C007E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C007EC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C007F0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01C007F4: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01C007F8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C007FC: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x01C00800: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00804: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C00808: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01C0080C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01C00810: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C00814: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01C00818: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01C0081C: ADRP x9, #0x35c9000        | X9 = 56397824 (0x35C9000);              
            // 0x01C00820: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x01C00824: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01C00828: LDR x9, [x9, #0xc30]       | X9 = 1152921504904183808;               
            // 0x01C0082C: LDR x24, [x9]              | X24 = typeof(ConfigAssetMgr);           
            // 0x01C00830: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01C00834: TBZ w9, #0, #0x1c00848     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01C00838: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01C0083C: CBNZ w9, #0x1c00848        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01C00840: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01C00844: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01C00848: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C0084C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C00850: MOV x1, x24                | X1 = 1152921504904183808 (0x1000000011B90000);//ML01
            // 0x01C00854: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C00858: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x01C0085C: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x01C00860: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01C00864: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01C00868: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01C0086C: TBZ w9, #0, #0x1c00880     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01C00870: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01C00874: CBNZ w9, #0x1c00880        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01C00878: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01C0087C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01C00880: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00884: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01C00888: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01C0088C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01C00890: MOV x3, x22                | X3 = X3;//m1                            
            // 0x01C00894: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01C00898: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01C0089C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01C008A0: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x01C008A4: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01C008A8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01C008AC: TBZ w9, #0, #0x1c008c0     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01C008B0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01C008B4: CBNZ w9, #0x1c008c0        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01C008B8: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01C008BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01C008C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C008C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C008C8: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01C008CC: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x01C008D0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01C008D4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x01C008D8: CBZ x0, #0x1c0093c         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x01C008DC: ADRP x9, #0x3654000        | X9 = 56967168 (0x3654000);              
            // 0x01C008E0: LDR x9, [x9, #0xb08]       | X9 = 1152921504904183808;               
            // 0x01C008E4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01C008E8: LDR x1, [x9]               | X1 = typeof(ConfigAssetMgr);            
            // 0x01C008EC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C008F0: LDRB w9, [x1, #0x104]      | W9 = ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C008F4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C008F8: B.LO #0x1c00914            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x01C008FC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01C00900: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHi
            // 0x01C00904: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C00908: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ConfigAssetMgr))
            // 0x01C0090C: MOV x22, x0                | X22 = val_6;//m1                        
            val_11 = val_6;
            // 0x01C00910: B.EQ #0x1c0093c            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x01C00914: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01C00918: ADD x8, sp, #8             | X8 = (1152921510255797024 + 8) = 1152921510255797032 (0x1000000150B42328);
            // 0x01C0091C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01C00920: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510255785120]
            // 0x01C00924: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x01C00928: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C0092C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x01C00930: ADD x0, sp, #8             | X0 = (1152921510255797024 + 8) = 1152921510255797032 (0x1000000150B42328);
            // 0x01C00934: BL #0x299a140              | 
            // 0x01C00938: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x01C0093C: CBNZ x20, #0x1c00944       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x01C00940: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150B42328, ????);
            label_11:
            // 0x01C00944: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C00948: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C0094C: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01C00950: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01C00954: CBNZ x22, #0x1c0095c       | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x01C00958: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x01C0095C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C00960: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x01C00964: BL #0xb42ab4               | X0 = val_11.get_loadProgress();         
            float val_9 = val_11.loadProgress;
            // 0x01C00968: CBZ x19, #0x1c009c8        | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x01C0096C: ORR w8, wzr, #3            | W8 = 3(0x3);                            
            // 0x01C00970: STR w8, [x19]              | mem2[0] = 0x3;                           //  dest_result_addr=0
            mem2[0] = 3;
            // 0x01C00974: STR s0, [x19, #4]          | mem2[0] = val_9;                         //  dest_result_addr=0
            mem2[0] = val_9;
            // 0x01C00978: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01C0097C: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x01C00980: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x01C00984: TBZ w9, #0, #0x1c00994     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_14;
            // 0x01C00988: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x01C0098C: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x01C00990: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_14:
            // 0x01C00994: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_12 + val_2;
            // 0x01C00998: SUB sp, x29, #0x40         | SP = (1152921510255797104 - 64) = 1152921510255797040 (0x1000000150B42330);
            // 0x01C0099C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01C009A0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01C009A4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01C009A8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01C009AC: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x01C009B0: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01C009B4: MOV x19, x0                | X19 = (val_12 + val_2);//m1             
            // 0x01C009B8: ADD x0, sp, #8             | X0 = (1152921510255797120 + 8) = 1152921510255797128 (0x1000000150B42388);
            // 0x01C009BC: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x1000000150B42388); //ERROR_TYPE
            // 0x01C009C0: MOV x0, x19                | X0 = (val_12 + val_2);//m1              
            // 0x01C009C4: BL #0x980800               | X0 = sub_980800( ?? (val_12 + val_2), ????);
            label_13:
            // 0x01C009C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_12 + val_2), ????);
            // 0x01C009CC: BRK #0x1                   | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01C009D0 (29362640), len: 528  VirtAddr: 0x01C009D0 RVA: 0x01C009D0 token: 100665080 methodIndex: 31129 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* LoadConfig_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x01C009D0: STP x24, x23, [sp, #-0x40]! | stack[1152921510255966400] = ???;  stack[1152921510255966408] = ???;  //  dest_result_addr=1152921510255966400 |  dest_result_addr=1152921510255966408
            // 0x01C009D4: STP x22, x21, [sp, #0x10]  | stack[1152921510255966416] = ???;  stack[1152921510255966424] = ???;  //  dest_result_addr=1152921510255966416 |  dest_result_addr=1152921510255966424
            // 0x01C009D8: STP x20, x19, [sp, #0x20]  | stack[1152921510255966432] = ???;  stack[1152921510255966440] = ???;  //  dest_result_addr=1152921510255966432 |  dest_result_addr=1152921510255966440
            // 0x01C009DC: STP x29, x30, [sp, #0x30]  | stack[1152921510255966448] = ???;  stack[1152921510255966456] = ???;  //  dest_result_addr=1152921510255966448 |  dest_result_addr=1152921510255966456
            // 0x01C009E0: ADD x29, sp, #0x30         | X29 = (1152921510255966400 + 48) = 1152921510255966448 (0x1000000150B6B8F0);
            // 0x01C009E4: SUB sp, sp, #0x10          | SP = (1152921510255966400 - 16) = 1152921510255966384 (0x1000000150B6B8B0);
            // 0x01C009E8: ADRP x20, #0x373c000       | X20 = 57917440 (0x373C000);             
            // 0x01C009EC: LDRB w8, [x20, #0x254]     | W8 = (bool)static_value_0373C254;       
            // 0x01C009F0: MOV x22, x3                | X22 = X3;//m1                           
            // 0x01C009F4: MOV x21, x2                | X21 = X2;//m1                           
            // 0x01C009F8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01C009FC: TBNZ w8, #0, #0x1c00a18    | if (static_value_0373C254 == true) goto label_0;
            // 0x01C00A00: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
            // 0x01C00A04: LDR x8, [x8, #0x298]       | X8 = 0x2B9275C;                         
            // 0x01C00A08: LDR w0, [x8]               | W0 = 0x209C;                            
            // 0x01C00A0C: BL #0x2782188              | X0 = sub_2782188( ?? 0x209C, ????);     
            // 0x01C00A10: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C00A14: STRB w8, [x20, #0x254]     | static_value_0373C254 = true;            //  dest_result_addr=57918036
            label_0:
            // 0x01C00A18: CBNZ x19, #0x1c00a20       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01C00A1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x209C, ????);     
            label_1:
            // 0x01C00A20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C00A24: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C00A28: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01C00A2C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01C00A30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00A34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C00A38: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01C00A3C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01C00A40: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C00A44: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01C00A48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00A4C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C00A50: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01C00A54: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01C00A58: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C00A5C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01C00A60: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01C00A64: ADRP x9, #0x35c9000        | X9 = 56397824 (0x35C9000);              
            // 0x01C00A68: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x01C00A6C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01C00A70: LDR x9, [x9, #0xc30]       | X9 = 1152921504904183808;               
            // 0x01C00A74: LDR x24, [x9]              | X24 = typeof(ConfigAssetMgr);           
            // 0x01C00A78: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01C00A7C: TBZ w9, #0, #0x1c00a90     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01C00A80: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01C00A84: CBNZ w9, #0x1c00a90        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01C00A88: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01C00A8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01C00A90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00A94: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C00A98: MOV x1, x24                | X1 = 1152921504904183808 (0x1000000011B90000);//ML01
            // 0x01C00A9C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C00AA0: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01C00AA4: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01C00AA8: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01C00AAC: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01C00AB0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01C00AB4: TBZ w9, #0, #0x1c00ac8     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01C00AB8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01C00ABC: CBNZ w9, #0x1c00ac8        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01C00AC0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01C00AC4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01C00AC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00ACC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01C00AD0: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01C00AD4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01C00AD8: MOV x3, x22                | X3 = X3;//m1                            
            // 0x01C00ADC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01C00AE0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01C00AE4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01C00AE8: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x01C00AEC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01C00AF0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01C00AF4: TBZ w9, #0, #0x1c00b08     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01C00AF8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01C00AFC: CBNZ w9, #0x1c00b08        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01C00B00: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01C00B04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01C00B08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00B0C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C00B10: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01C00B14: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x01C00B18: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01C00B1C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x01C00B20: CBZ x0, #0x1c00b84         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x01C00B24: ADRP x9, #0x3654000        | X9 = 56967168 (0x3654000);              
            // 0x01C00B28: LDR x9, [x9, #0xb08]       | X9 = 1152921504904183808;               
            // 0x01C00B2C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01C00B30: LDR x1, [x9]               | X1 = typeof(ConfigAssetMgr);            
            // 0x01C00B34: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C00B38: LDRB w9, [x1, #0x104]      | W9 = ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C00B3C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C00B40: B.LO #0x1c00b5c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x01C00B44: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01C00B48: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHi
            // 0x01C00B4C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C00B50: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ConfigAssetMgr))
            // 0x01C00B54: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x01C00B58: B.EQ #0x1c00b84            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x01C00B5C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01C00B60: ADD x8, sp, #8             | X8 = (1152921510255966384 + 8) = 1152921510255966392 (0x1000000150B6B8B8);
            // 0x01C00B64: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01C00B68: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510255954464]
            // 0x01C00B6C: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x01C00B70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C00B74: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x01C00B78: ADD x0, sp, #8             | X0 = (1152921510255966384 + 8) = 1152921510255966392 (0x1000000150B6B8B8);
            // 0x01C00B7C: BL #0x299a140              | 
            // 0x01C00B80: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x01C00B84: CBNZ x19, #0x1c00b8c       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x01C00B88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150B6B8B8, ????);
            label_11:
            // 0x01C00B8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C00B90: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01C00B94: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01C00B98: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01C00B9C: CBNZ x22, #0x1c00ba4       | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x01C00BA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x01C00BA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C00BA8: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x01C00BAC: BL #0xb42b10               | val_9.LoadConfig();                     
            val_9.LoadConfig();
            // 0x01C00BB0: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01C00BB4: SUB sp, x29, #0x30         | SP = (1152921510255966448 - 48) = 1152921510255966400 (0x1000000150B6B8C0);
            // 0x01C00BB8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01C00BBC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01C00BC0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01C00BC4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01C00BC8: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01C00BCC: MOV x19, x0                | 
            // 0x01C00BD0: ADD x0, sp, #8             | 
            // 0x01C00BD4: BL #0x299a140              | 
            // 0x01C00BD8: MOV x0, x19                | 
            // 0x01C00BDC: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01C00BE0 (29363168), len: 772  VirtAddr: 0x01C00BE0 RVA: 0x01C00BE0 token: 100665081 methodIndex: 31130 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* LoadPathToABPath_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_13;
            //  | 
            string val_16;
            //  | 
            var val_17;
            // 0x01C00BE0: STP x26, x25, [sp, #-0x50]! | stack[1152921510256152112] = ???;  stack[1152921510256152120] = ???;  //  dest_result_addr=1152921510256152112 |  dest_result_addr=1152921510256152120
            // 0x01C00BE4: STP x24, x23, [sp, #0x10]  | stack[1152921510256152128] = ???;  stack[1152921510256152136] = ???;  //  dest_result_addr=1152921510256152128 |  dest_result_addr=1152921510256152136
            // 0x01C00BE8: STP x22, x21, [sp, #0x20]  | stack[1152921510256152144] = ???;  stack[1152921510256152152] = ???;  //  dest_result_addr=1152921510256152144 |  dest_result_addr=1152921510256152152
            // 0x01C00BEC: STP x20, x19, [sp, #0x30]  | stack[1152921510256152160] = ???;  stack[1152921510256152168] = ???;  //  dest_result_addr=1152921510256152160 |  dest_result_addr=1152921510256152168
            // 0x01C00BF0: STP x29, x30, [sp, #0x40]  | stack[1152921510256152176] = ???;  stack[1152921510256152184] = ???;  //  dest_result_addr=1152921510256152176 |  dest_result_addr=1152921510256152184
            // 0x01C00BF4: ADD x29, sp, #0x40         | X29 = (1152921510256152112 + 64) = 1152921510256152176 (0x1000000150B98E70);
            // 0x01C00BF8: SUB sp, sp, #0x10          | SP = (1152921510256152112 - 16) = 1152921510256152096 (0x1000000150B98E20);
            // 0x01C00BFC: ADRP x21, #0x373c000       | X21 = 57917440 (0x373C000);             
            // 0x01C00C00: LDRB w8, [x21, #0x255]     | W8 = (bool)static_value_0373C255;       
            // 0x01C00C04: MOV x19, x3                | X19 = X3;//m1                           
            // 0x01C00C08: MOV x22, x2                | X22 = X2;//m1                           
            // 0x01C00C0C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x01C00C10: TBNZ w8, #0, #0x1c00c2c    | if (static_value_0373C255 == true) goto label_0;
            // 0x01C00C14: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x01C00C18: LDR x8, [x8, #0x548]       | X8 = 0x2B92764;                         
            // 0x01C00C1C: LDR w0, [x8]               | W0 = 0x209E;                            
            // 0x01C00C20: BL #0x2782188              | X0 = sub_2782188( ?? 0x209E, ????);     
            // 0x01C00C24: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C00C28: STRB w8, [x21, #0x255]     | static_value_0373C255 = true;            //  dest_result_addr=57918037
            label_0:
            // 0x01C00C2C: CBNZ x20, #0x1c00c34       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01C00C30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x209E, ????);     
            label_1:
            // 0x01C00C34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C00C38: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C00C3C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01C00C40: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01C00C44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00C48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C00C4C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01C00C50: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01C00C54: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C00C58: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x01C00C5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00C60: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C00C64: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01C00C68: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01C00C6C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C00C70: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01C00C74: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01C00C78: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x01C00C7C: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x01C00C80: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01C00C84: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x01C00C88: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x01C00C8C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01C00C90: TBZ w9, #0, #0x1c00ca4     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01C00C94: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01C00C98: CBNZ w9, #0x1c00ca4        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01C00C9C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01C00CA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01C00CA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00CA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C00CAC: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01C00CB0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C00CB4: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01C00CB8: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01C00CBC: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01C00CC0: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01C00CC4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01C00CC8: TBZ w9, #0, #0x1c00cdc     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01C00CCC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01C00CD0: CBNZ w9, #0x1c00cdc        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01C00CD4: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01C00CD8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01C00CDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00CE0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01C00CE4: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x01C00CE8: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01C00CEC: MOV x3, x19                | X3 = X3;//m1                            
            // 0x01C00CF0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01C00CF4: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01C00CF8: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01C00CFC: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x01C00D00: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01C00D04: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01C00D08: TBZ w9, #0, #0x1c00d1c     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01C00D0C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01C00D10: CBNZ w9, #0x1c00d1c        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01C00D14: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01C00D18: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01C00D1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00D20: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C00D24: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01C00D28: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x01C00D2C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01C00D30: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x01C00D34: CBZ x0, #0x1c00d7c         | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x01C00D38: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01C00D3C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01C00D40: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01C00D44: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01C00D48: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x01C00D4C: MOV x24, x0                | X24 = val_6;//m1                        
            val_16 = val_6;
            // 0x01C00D50: B.EQ #0x1c00d7c            | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x01C00D54: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01C00D58: MOV x8, sp                 | X8 = 1152921510256152096 (0x1000000150B98E20);//ML01
            // 0x01C00D5C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01C00D60: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510256140192]
            // 0x01C00D64: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x01C00D68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C00D6C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x01C00D70: MOV x0, sp                 | X0 = 1152921510256152096 (0x1000000150B98E20);//ML01
            // 0x01C00D74: BL #0x299a140              | 
            // 0x01C00D78: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_9:
            // 0x01C00D7C: CBNZ x20, #0x1c00d84       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x01C00D80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150B98E20, ????);
            label_10:
            // 0x01C00D84: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C00D88: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C00D8C: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x01C00D90: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01C00D94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00D98: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C00D9C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01C00DA0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01C00DA4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C00DA8: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x01C00DAC: LDR x8, [x8, #0xc30]       | X8 = 1152921504904183808;               
            // 0x01C00DB0: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x01C00DB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00DB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C00DBC: LDR x1, [x8]               | X1 = typeof(ConfigAssetMgr);            
            // 0x01C00DC0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C00DC4: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x01C00DC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00DCC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01C00DD0: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x01C00DD4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01C00DD8: MOV x3, x19                | X3 = X3;//m1                            
            // 0x01C00DDC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01C00DE0: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x01C00DE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00DE8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C00DEC: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x01C00DF0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x01C00DF4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x01C00DF8: CBZ x0, #0x1c00e5c         | if (val_11 == null) goto label_13;      
            if(val_11 == null)
            {
                goto label_13;
            }
            // 0x01C00DFC: ADRP x9, #0x3654000        | X9 = 56967168 (0x3654000);              
            // 0x01C00E00: LDR x9, [x9, #0xb08]       | X9 = 1152921504904183808;               
            // 0x01C00E04: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01C00E08: LDR x1, [x9]               | X1 = typeof(ConfigAssetMgr);            
            // 0x01C00E0C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C00E10: LDRB w9, [x1, #0x104]      | W9 = ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C00E14: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C00E18: B.LO #0x1c00e34            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x01C00E1C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01C00E20: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHi
            // 0x01C00E24: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C00E28: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ConfigAssetMgr))
            // 0x01C00E2C: MOV x23, x0                | X23 = val_11;//m1                       
            val_17 = val_11;
            // 0x01C00E30: B.EQ #0x1c00e5c            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x01C00E34: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01C00E38: ADD x8, sp, #8             | X8 = (1152921510256152096 + 8) = 1152921510256152104 (0x1000000150B98E28);
            // 0x01C00E3C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01C00E40: LDR x0, [sp, #8]           | X0 = val_13;                             //  find_add[1152921510256140192]
            // 0x01C00E44: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x01C00E48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C00E4C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x01C00E50: ADD x0, sp, #8             | X0 = (1152921510256152096 + 8) = 1152921510256152104 (0x1000000150B98E28);
            // 0x01C00E54: BL #0x299a140              | 
            // 0x01C00E58: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_17 = 0;
            label_13:
            // 0x01C00E5C: CBNZ x20, #0x1c00e64       | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x01C00E60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150B98E28, ????);
            label_14:
            // 0x01C00E64: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C00E68: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C00E6C: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x01C00E70: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01C00E74: CBNZ x23, #0x1c00e7c       | if (0x0 != 0) goto label_15;            
            if(val_17 != 0)
            {
                goto label_15;
            }
            // 0x01C00E78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_15:
            // 0x01C00E7C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C00E80: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x01C00E84: MOV x1, x24                | X1 = 0 (0x0);//ML01                     
            // 0x01C00E88: BL #0xb42c00               | X0 = val_17.LoadPathToABPath(path:  val_16);
            string val_14 = val_17.LoadPathToABPath(path:  val_16);
            // 0x01C00E8C: MOV x3, x0                 | X3 = val_14;//m1                        
            // 0x01C00E90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00E94: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x01C00E98: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x01C00E9C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x01C00EA0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01C00EA4: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_15 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x01C00EA8: SUB sp, x29, #0x40         | SP = (1152921510256152176 - 64) = 1152921510256152112 (0x1000000150B98E30);
            // 0x01C00EAC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01C00EB0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01C00EB4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01C00EB8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01C00EBC: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x01C00EC0: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_15;
            return val_15;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01C00EC4: MOV x19, x0                | 
            // 0x01C00EC8: ADD x0, sp, #8             | 
            // 0x01C00ECC: B #0x1c00ed8               | 
            // 0x01C00ED0: MOV x19, x0                | 
            // 0x01C00ED4: MOV x0, sp                 | 
            label_16:
            // 0x01C00ED8: BL #0x299a140              | 
            // 0x01C00EDC: MOV x0, x19                | 
            // 0x01C00EE0: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01C00EE4 (29363940), len: 772  VirtAddr: 0x01C00EE4 RVA: 0x01C00EE4 token: 100665082 methodIndex: 31131 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* LoadPathToABFullPath_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_13;
            //  | 
            string val_16;
            //  | 
            var val_17;
            // 0x01C00EE4: STP x26, x25, [sp, #-0x50]! | stack[1152921510256354224] = ???;  stack[1152921510256354232] = ???;  //  dest_result_addr=1152921510256354224 |  dest_result_addr=1152921510256354232
            // 0x01C00EE8: STP x24, x23, [sp, #0x10]  | stack[1152921510256354240] = ???;  stack[1152921510256354248] = ???;  //  dest_result_addr=1152921510256354240 |  dest_result_addr=1152921510256354248
            // 0x01C00EEC: STP x22, x21, [sp, #0x20]  | stack[1152921510256354256] = ???;  stack[1152921510256354264] = ???;  //  dest_result_addr=1152921510256354256 |  dest_result_addr=1152921510256354264
            // 0x01C00EF0: STP x20, x19, [sp, #0x30]  | stack[1152921510256354272] = ???;  stack[1152921510256354280] = ???;  //  dest_result_addr=1152921510256354272 |  dest_result_addr=1152921510256354280
            // 0x01C00EF4: STP x29, x30, [sp, #0x40]  | stack[1152921510256354288] = ???;  stack[1152921510256354296] = ???;  //  dest_result_addr=1152921510256354288 |  dest_result_addr=1152921510256354296
            // 0x01C00EF8: ADD x29, sp, #0x40         | X29 = (1152921510256354224 + 64) = 1152921510256354288 (0x1000000150BCA3F0);
            // 0x01C00EFC: SUB sp, sp, #0x10          | SP = (1152921510256354224 - 16) = 1152921510256354208 (0x1000000150BCA3A0);
            // 0x01C00F00: ADRP x21, #0x373c000       | X21 = 57917440 (0x373C000);             
            // 0x01C00F04: LDRB w8, [x21, #0x256]     | W8 = (bool)static_value_0373C256;       
            // 0x01C00F08: MOV x19, x3                | X19 = X3;//m1                           
            // 0x01C00F0C: MOV x22, x2                | X22 = X2;//m1                           
            // 0x01C00F10: MOV x20, x1                | X20 = X1;//m1                           
            // 0x01C00F14: TBNZ w8, #0, #0x1c00f30    | if (static_value_0373C256 == true) goto label_0;
            // 0x01C00F18: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
            // 0x01C00F1C: LDR x8, [x8, #0xdf8]       | X8 = 0x2B92760;                         
            // 0x01C00F20: LDR w0, [x8]               | W0 = 0x209D;                            
            // 0x01C00F24: BL #0x2782188              | X0 = sub_2782188( ?? 0x209D, ????);     
            // 0x01C00F28: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C00F2C: STRB w8, [x21, #0x256]     | static_value_0373C256 = true;            //  dest_result_addr=57918038
            label_0:
            // 0x01C00F30: CBNZ x20, #0x1c00f38       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01C00F34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x209D, ????);     
            label_1:
            // 0x01C00F38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C00F3C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C00F40: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01C00F44: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01C00F48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00F4C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C00F50: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01C00F54: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01C00F58: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C00F5C: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x01C00F60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00F64: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C00F68: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01C00F6C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01C00F70: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C00F74: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01C00F78: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01C00F7C: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x01C00F80: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x01C00F84: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01C00F88: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x01C00F8C: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x01C00F90: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01C00F94: TBZ w9, #0, #0x1c00fa8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01C00F98: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01C00F9C: CBNZ w9, #0x1c00fa8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01C00FA0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01C00FA4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01C00FA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00FAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C00FB0: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01C00FB4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C00FB8: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01C00FBC: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01C00FC0: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01C00FC4: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01C00FC8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01C00FCC: TBZ w9, #0, #0x1c00fe0     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01C00FD0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01C00FD4: CBNZ w9, #0x1c00fe0        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01C00FD8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01C00FDC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01C00FE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C00FE4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01C00FE8: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x01C00FEC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01C00FF0: MOV x3, x19                | X3 = X3;//m1                            
            // 0x01C00FF4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01C00FF8: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01C00FFC: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01C01000: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x01C01004: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01C01008: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01C0100C: TBZ w9, #0, #0x1c01020     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01C01010: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01C01014: CBNZ w9, #0x1c01020        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01C01018: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01C0101C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01C01020: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C01024: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C01028: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01C0102C: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x01C01030: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01C01034: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x01C01038: CBZ x0, #0x1c01080         | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x01C0103C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01C01040: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01C01044: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01C01048: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01C0104C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x01C01050: MOV x24, x0                | X24 = val_6;//m1                        
            val_16 = val_6;
            // 0x01C01054: B.EQ #0x1c01080            | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x01C01058: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01C0105C: MOV x8, sp                 | X8 = 1152921510256354208 (0x1000000150BCA3A0);//ML01
            // 0x01C01060: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01C01064: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510256342304]
            // 0x01C01068: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x01C0106C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C01070: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x01C01074: MOV x0, sp                 | X0 = 1152921510256354208 (0x1000000150BCA3A0);//ML01
            // 0x01C01078: BL #0x299a140              | 
            // 0x01C0107C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_9:
            // 0x01C01080: CBNZ x20, #0x1c01088       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x01C01084: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150BCA3A0, ????);
            label_10:
            // 0x01C01088: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C0108C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C01090: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x01C01094: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01C01098: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C0109C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C010A0: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01C010A4: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01C010A8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C010AC: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x01C010B0: LDR x8, [x8, #0xc30]       | X8 = 1152921504904183808;               
            // 0x01C010B4: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x01C010B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C010BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C010C0: LDR x1, [x8]               | X1 = typeof(ConfigAssetMgr);            
            // 0x01C010C4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C010C8: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x01C010CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C010D0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01C010D4: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x01C010D8: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01C010DC: MOV x3, x19                | X3 = X3;//m1                            
            // 0x01C010E0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01C010E4: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x01C010E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C010EC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C010F0: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x01C010F4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x01C010F8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x01C010FC: CBZ x0, #0x1c01160         | if (val_11 == null) goto label_13;      
            if(val_11 == null)
            {
                goto label_13;
            }
            // 0x01C01100: ADRP x9, #0x3654000        | X9 = 56967168 (0x3654000);              
            // 0x01C01104: LDR x9, [x9, #0xb08]       | X9 = 1152921504904183808;               
            // 0x01C01108: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01C0110C: LDR x1, [x9]               | X1 = typeof(ConfigAssetMgr);            
            // 0x01C01110: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C01114: LDRB w9, [x1, #0x104]      | W9 = ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C01118: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C0111C: B.LO #0x1c01138            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x01C01120: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01C01124: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHi
            // 0x01C01128: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C0112C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ConfigAssetMgr))
            // 0x01C01130: MOV x23, x0                | X23 = val_11;//m1                       
            val_17 = val_11;
            // 0x01C01134: B.EQ #0x1c01160            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x01C01138: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01C0113C: ADD x8, sp, #8             | X8 = (1152921510256354208 + 8) = 1152921510256354216 (0x1000000150BCA3A8);
            // 0x01C01140: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01C01144: LDR x0, [sp, #8]           | X0 = val_13;                             //  find_add[1152921510256342304]
            // 0x01C01148: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x01C0114C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C01150: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x01C01154: ADD x0, sp, #8             | X0 = (1152921510256354208 + 8) = 1152921510256354216 (0x1000000150BCA3A8);
            // 0x01C01158: BL #0x299a140              | 
            // 0x01C0115C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_17 = 0;
            label_13:
            // 0x01C01160: CBNZ x20, #0x1c01168       | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x01C01164: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150BCA3A8, ????);
            label_14:
            // 0x01C01168: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C0116C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C01170: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x01C01174: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01C01178: CBNZ x23, #0x1c01180       | if (0x0 != 0) goto label_15;            
            if(val_17 != 0)
            {
                goto label_15;
            }
            // 0x01C0117C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_15:
            // 0x01C01180: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C01184: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x01C01188: MOV x1, x24                | X1 = 0 (0x0);//ML01                     
            // 0x01C0118C: BL #0xb42c34               | X0 = val_17.LoadPathToABFullPath(path:  val_16);
            string val_14 = val_17.LoadPathToABFullPath(path:  val_16);
            // 0x01C01190: MOV x3, x0                 | X3 = val_14;//m1                        
            // 0x01C01194: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C01198: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x01C0119C: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x01C011A0: MOV x2, x19                | X2 = X3;//m1                            
            // 0x01C011A4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01C011A8: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_15 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x01C011AC: SUB sp, x29, #0x40         | SP = (1152921510256354288 - 64) = 1152921510256354224 (0x1000000150BCA3B0);
            // 0x01C011B0: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01C011B4: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01C011B8: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01C011BC: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01C011C0: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x01C011C4: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_15;
            return val_15;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01C011C8: MOV x19, x0                | 
            // 0x01C011CC: ADD x0, sp, #8             | 
            // 0x01C011D0: B #0x1c011dc               | 
            // 0x01C011D4: MOV x19, x0                | 
            // 0x01C011D8: MOV x0, sp                 | 
            label_16:
            // 0x01C011DC: BL #0x299a140              | 
            // 0x01C011E0: MOV x0, x19                | 
            // 0x01C011E4: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01C011E8 (29364712), len: 772  VirtAddr: 0x01C011E8 RVA: 0x01C011E8 token: 100665083 methodIndex: 31132 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* LoadPathToAssetName_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_13;
            //  | 
            string val_16;
            //  | 
            var val_17;
            // 0x01C011E8: STP x26, x25, [sp, #-0x50]! | stack[1152921510256556336] = ???;  stack[1152921510256556344] = ???;  //  dest_result_addr=1152921510256556336 |  dest_result_addr=1152921510256556344
            // 0x01C011EC: STP x24, x23, [sp, #0x10]  | stack[1152921510256556352] = ???;  stack[1152921510256556360] = ???;  //  dest_result_addr=1152921510256556352 |  dest_result_addr=1152921510256556360
            // 0x01C011F0: STP x22, x21, [sp, #0x20]  | stack[1152921510256556368] = ???;  stack[1152921510256556376] = ???;  //  dest_result_addr=1152921510256556368 |  dest_result_addr=1152921510256556376
            // 0x01C011F4: STP x20, x19, [sp, #0x30]  | stack[1152921510256556384] = ???;  stack[1152921510256556392] = ???;  //  dest_result_addr=1152921510256556384 |  dest_result_addr=1152921510256556392
            // 0x01C011F8: STP x29, x30, [sp, #0x40]  | stack[1152921510256556400] = ???;  stack[1152921510256556408] = ???;  //  dest_result_addr=1152921510256556400 |  dest_result_addr=1152921510256556408
            // 0x01C011FC: ADD x29, sp, #0x40         | X29 = (1152921510256556336 + 64) = 1152921510256556400 (0x1000000150BFB970);
            // 0x01C01200: SUB sp, sp, #0x10          | SP = (1152921510256556336 - 16) = 1152921510256556320 (0x1000000150BFB920);
            // 0x01C01204: ADRP x21, #0x373c000       | X21 = 57917440 (0x373C000);             
            // 0x01C01208: LDRB w8, [x21, #0x257]     | W8 = (bool)static_value_0373C257;       
            // 0x01C0120C: MOV x19, x3                | X19 = X3;//m1                           
            // 0x01C01210: MOV x22, x2                | X22 = X2;//m1                           
            // 0x01C01214: MOV x20, x1                | X20 = X1;//m1                           
            // 0x01C01218: TBNZ w8, #0, #0x1c01234    | if (static_value_0373C257 == true) goto label_0;
            // 0x01C0121C: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
            // 0x01C01220: LDR x8, [x8, #0x4b8]       | X8 = 0x2B92768;                         
            // 0x01C01224: LDR w0, [x8]               | W0 = 0x209F;                            
            // 0x01C01228: BL #0x2782188              | X0 = sub_2782188( ?? 0x209F, ????);     
            // 0x01C0122C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C01230: STRB w8, [x21, #0x257]     | static_value_0373C257 = true;            //  dest_result_addr=57918039
            label_0:
            // 0x01C01234: CBNZ x20, #0x1c0123c       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01C01238: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x209F, ????);     
            label_1:
            // 0x01C0123C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C01240: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C01244: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01C01248: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01C0124C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C01250: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C01254: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01C01258: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01C0125C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C01260: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x01C01264: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C01268: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C0126C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01C01270: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01C01274: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C01278: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01C0127C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01C01280: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x01C01284: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x01C01288: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01C0128C: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x01C01290: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x01C01294: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01C01298: TBZ w9, #0, #0x1c012ac     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01C0129C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01C012A0: CBNZ w9, #0x1c012ac        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01C012A4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01C012A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01C012AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C012B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C012B4: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01C012B8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C012BC: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01C012C0: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01C012C4: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01C012C8: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01C012CC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01C012D0: TBZ w9, #0, #0x1c012e4     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01C012D4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01C012D8: CBNZ w9, #0x1c012e4        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01C012DC: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01C012E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01C012E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C012E8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01C012EC: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x01C012F0: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01C012F4: MOV x3, x19                | X3 = X3;//m1                            
            // 0x01C012F8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01C012FC: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01C01300: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01C01304: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x01C01308: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01C0130C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01C01310: TBZ w9, #0, #0x1c01324     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01C01314: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01C01318: CBNZ w9, #0x1c01324        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01C0131C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01C01320: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01C01324: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C01328: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C0132C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01C01330: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x01C01334: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01C01338: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x01C0133C: CBZ x0, #0x1c01384         | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x01C01340: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01C01344: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01C01348: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01C0134C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01C01350: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x01C01354: MOV x24, x0                | X24 = val_6;//m1                        
            val_16 = val_6;
            // 0x01C01358: B.EQ #0x1c01384            | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x01C0135C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01C01360: MOV x8, sp                 | X8 = 1152921510256556320 (0x1000000150BFB920);//ML01
            // 0x01C01364: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01C01368: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510256544416]
            // 0x01C0136C: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x01C01370: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C01374: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x01C01378: MOV x0, sp                 | X0 = 1152921510256556320 (0x1000000150BFB920);//ML01
            // 0x01C0137C: BL #0x299a140              | 
            // 0x01C01380: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_9:
            // 0x01C01384: CBNZ x20, #0x1c0138c       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x01C01388: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150BFB920, ????);
            label_10:
            // 0x01C0138C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C01390: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C01394: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x01C01398: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01C0139C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C013A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C013A4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01C013A8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01C013AC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C013B0: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x01C013B4: LDR x8, [x8, #0xc30]       | X8 = 1152921504904183808;               
            // 0x01C013B8: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x01C013BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C013C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C013C4: LDR x1, [x8]               | X1 = typeof(ConfigAssetMgr);            
            // 0x01C013C8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C013CC: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x01C013D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C013D4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01C013D8: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x01C013DC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01C013E0: MOV x3, x19                | X3 = X3;//m1                            
            // 0x01C013E4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01C013E8: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x01C013EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C013F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C013F4: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x01C013F8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x01C013FC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x01C01400: CBZ x0, #0x1c01464         | if (val_11 == null) goto label_13;      
            if(val_11 == null)
            {
                goto label_13;
            }
            // 0x01C01404: ADRP x9, #0x3654000        | X9 = 56967168 (0x3654000);              
            // 0x01C01408: LDR x9, [x9, #0xb08]       | X9 = 1152921504904183808;               
            // 0x01C0140C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01C01410: LDR x1, [x9]               | X1 = typeof(ConfigAssetMgr);            
            // 0x01C01414: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C01418: LDRB w9, [x1, #0x104]      | W9 = ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C0141C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C01420: B.LO #0x1c0143c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x01C01424: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01C01428: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHi
            // 0x01C0142C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C01430: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ConfigAssetMgr))
            // 0x01C01434: MOV x23, x0                | X23 = val_11;//m1                       
            val_17 = val_11;
            // 0x01C01438: B.EQ #0x1c01464            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x01C0143C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01C01440: ADD x8, sp, #8             | X8 = (1152921510256556320 + 8) = 1152921510256556328 (0x1000000150BFB928);
            // 0x01C01444: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01C01448: LDR x0, [sp, #8]           | X0 = val_13;                             //  find_add[1152921510256544416]
            // 0x01C0144C: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x01C01450: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C01454: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x01C01458: ADD x0, sp, #8             | X0 = (1152921510256556320 + 8) = 1152921510256556328 (0x1000000150BFB928);
            // 0x01C0145C: BL #0x299a140              | 
            // 0x01C01460: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_17 = 0;
            label_13:
            // 0x01C01464: CBNZ x20, #0x1c0146c       | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x01C01468: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150BFB928, ????);
            label_14:
            // 0x01C0146C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C01470: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C01474: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x01C01478: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01C0147C: CBNZ x23, #0x1c01484       | if (0x0 != 0) goto label_15;            
            if(val_17 != 0)
            {
                goto label_15;
            }
            // 0x01C01480: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_15:
            // 0x01C01484: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C01488: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x01C0148C: MOV x1, x24                | X1 = 0 (0x0);//ML01                     
            // 0x01C01490: BL #0xb42c68               | X0 = val_17.LoadPathToAssetName(path:  val_16);
            string val_14 = val_17.LoadPathToAssetName(path:  val_16);
            // 0x01C01494: MOV x3, x0                 | X3 = val_14;//m1                        
            // 0x01C01498: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C0149C: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x01C014A0: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x01C014A4: MOV x2, x19                | X2 = X3;//m1                            
            // 0x01C014A8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01C014AC: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_15 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x01C014B0: SUB sp, x29, #0x40         | SP = (1152921510256556400 - 64) = 1152921510256556336 (0x1000000150BFB930);
            // 0x01C014B4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01C014B8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01C014BC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01C014C0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01C014C4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x01C014C8: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_15;
            return val_15;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01C014CC: MOV x19, x0                | 
            // 0x01C014D0: ADD x0, sp, #8             | 
            // 0x01C014D4: B #0x1c014e0               | 
            // 0x01C014D8: MOV x19, x0                | 
            // 0x01C014DC: MOV x0, sp                 | 
            label_16:
            // 0x01C014E0: BL #0x299a140              | 
            // 0x01C014E4: MOV x0, x19                | 
            // 0x01C014E8: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01C014EC (29365484), len: 772  VirtAddr: 0x01C014EC RVA: 0x01C014EC token: 100665084 methodIndex: 31133 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* AssetNameToABPath_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_13;
            //  | 
            string val_16;
            //  | 
            var val_17;
            // 0x01C014EC: STP x26, x25, [sp, #-0x50]! | stack[1152921510256758448] = ???;  stack[1152921510256758456] = ???;  //  dest_result_addr=1152921510256758448 |  dest_result_addr=1152921510256758456
            // 0x01C014F0: STP x24, x23, [sp, #0x10]  | stack[1152921510256758464] = ???;  stack[1152921510256758472] = ???;  //  dest_result_addr=1152921510256758464 |  dest_result_addr=1152921510256758472
            // 0x01C014F4: STP x22, x21, [sp, #0x20]  | stack[1152921510256758480] = ???;  stack[1152921510256758488] = ???;  //  dest_result_addr=1152921510256758480 |  dest_result_addr=1152921510256758488
            // 0x01C014F8: STP x20, x19, [sp, #0x30]  | stack[1152921510256758496] = ???;  stack[1152921510256758504] = ???;  //  dest_result_addr=1152921510256758496 |  dest_result_addr=1152921510256758504
            // 0x01C014FC: STP x29, x30, [sp, #0x40]  | stack[1152921510256758512] = ???;  stack[1152921510256758520] = ???;  //  dest_result_addr=1152921510256758512 |  dest_result_addr=1152921510256758520
            // 0x01C01500: ADD x29, sp, #0x40         | X29 = (1152921510256758448 + 64) = 1152921510256758512 (0x1000000150C2CEF0);
            // 0x01C01504: SUB sp, sp, #0x10          | SP = (1152921510256758448 - 16) = 1152921510256758432 (0x1000000150C2CEA0);
            // 0x01C01508: ADRP x21, #0x373c000       | X21 = 57917440 (0x373C000);             
            // 0x01C0150C: LDRB w8, [x21, #0x258]     | W8 = (bool)static_value_0373C258;       
            // 0x01C01510: MOV x19, x3                | X19 = X3;//m1                           
            // 0x01C01514: MOV x22, x2                | X22 = X2;//m1                           
            // 0x01C01518: MOV x20, x1                | X20 = X1;//m1                           
            // 0x01C0151C: TBNZ w8, #0, #0x1c01538    | if (static_value_0373C258 == true) goto label_0;
            // 0x01C01520: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
            // 0x01C01524: LDR x8, [x8, #0xe98]       | X8 = 0x2B92740;                         
            // 0x01C01528: LDR w0, [x8]               | W0 = 0x2095;                            
            // 0x01C0152C: BL #0x2782188              | X0 = sub_2782188( ?? 0x2095, ????);     
            // 0x01C01530: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C01534: STRB w8, [x21, #0x258]     | static_value_0373C258 = true;            //  dest_result_addr=57918040
            label_0:
            // 0x01C01538: CBNZ x20, #0x1c01540       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01C0153C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2095, ????);     
            label_1:
            // 0x01C01540: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C01544: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C01548: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01C0154C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01C01550: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C01554: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C01558: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01C0155C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01C01560: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C01564: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x01C01568: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C0156C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C01570: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01C01574: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01C01578: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C0157C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01C01580: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01C01584: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x01C01588: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x01C0158C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01C01590: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x01C01594: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x01C01598: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01C0159C: TBZ w9, #0, #0x1c015b0     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01C015A0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01C015A4: CBNZ w9, #0x1c015b0        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01C015A8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01C015AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01C015B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C015B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C015B8: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01C015BC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C015C0: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01C015C4: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01C015C8: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01C015CC: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01C015D0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01C015D4: TBZ w9, #0, #0x1c015e8     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01C015D8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01C015DC: CBNZ w9, #0x1c015e8        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01C015E0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01C015E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01C015E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C015EC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01C015F0: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x01C015F4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01C015F8: MOV x3, x19                | X3 = X3;//m1                            
            // 0x01C015FC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01C01600: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01C01604: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01C01608: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x01C0160C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01C01610: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01C01614: TBZ w9, #0, #0x1c01628     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01C01618: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01C0161C: CBNZ w9, #0x1c01628        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01C01620: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01C01624: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01C01628: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C0162C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C01630: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01C01634: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x01C01638: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01C0163C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x01C01640: CBZ x0, #0x1c01688         | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x01C01644: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01C01648: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01C0164C: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01C01650: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01C01654: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x01C01658: MOV x24, x0                | X24 = val_6;//m1                        
            val_16 = val_6;
            // 0x01C0165C: B.EQ #0x1c01688            | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x01C01660: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01C01664: MOV x8, sp                 | X8 = 1152921510256758432 (0x1000000150C2CEA0);//ML01
            // 0x01C01668: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01C0166C: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510256746528]
            // 0x01C01670: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x01C01674: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C01678: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x01C0167C: MOV x0, sp                 | X0 = 1152921510256758432 (0x1000000150C2CEA0);//ML01
            // 0x01C01680: BL #0x299a140              | 
            // 0x01C01684: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_9:
            // 0x01C01688: CBNZ x20, #0x1c01690       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x01C0168C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150C2CEA0, ????);
            label_10:
            // 0x01C01690: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C01694: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C01698: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x01C0169C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01C016A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C016A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C016A8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01C016AC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01C016B0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C016B4: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x01C016B8: LDR x8, [x8, #0xc30]       | X8 = 1152921504904183808;               
            // 0x01C016BC: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x01C016C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C016C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C016C8: LDR x1, [x8]               | X1 = typeof(ConfigAssetMgr);            
            // 0x01C016CC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C016D0: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x01C016D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C016D8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01C016DC: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x01C016E0: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01C016E4: MOV x3, x19                | X3 = X3;//m1                            
            // 0x01C016E8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01C016EC: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x01C016F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C016F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C016F8: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x01C016FC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x01C01700: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x01C01704: CBZ x0, #0x1c01768         | if (val_11 == null) goto label_13;      
            if(val_11 == null)
            {
                goto label_13;
            }
            // 0x01C01708: ADRP x9, #0x3654000        | X9 = 56967168 (0x3654000);              
            // 0x01C0170C: LDR x9, [x9, #0xb08]       | X9 = 1152921504904183808;               
            // 0x01C01710: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01C01714: LDR x1, [x9]               | X1 = typeof(ConfigAssetMgr);            
            // 0x01C01718: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C0171C: LDRB w9, [x1, #0x104]      | W9 = ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C01720: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C01724: B.LO #0x1c01740            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x01C01728: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01C0172C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHi
            // 0x01C01730: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C01734: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ConfigAssetMgr))
            // 0x01C01738: MOV x23, x0                | X23 = val_11;//m1                       
            val_17 = val_11;
            // 0x01C0173C: B.EQ #0x1c01768            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x01C01740: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01C01744: ADD x8, sp, #8             | X8 = (1152921510256758432 + 8) = 1152921510256758440 (0x1000000150C2CEA8);
            // 0x01C01748: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01C0174C: LDR x0, [sp, #8]           | X0 = val_13;                             //  find_add[1152921510256746528]
            // 0x01C01750: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x01C01754: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C01758: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x01C0175C: ADD x0, sp, #8             | X0 = (1152921510256758432 + 8) = 1152921510256758440 (0x1000000150C2CEA8);
            // 0x01C01760: BL #0x299a140              | 
            // 0x01C01764: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_17 = 0;
            label_13:
            // 0x01C01768: CBNZ x20, #0x1c01770       | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x01C0176C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150C2CEA8, ????);
            label_14:
            // 0x01C01770: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C01774: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C01778: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x01C0177C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01C01780: CBNZ x23, #0x1c01788       | if (0x0 != 0) goto label_15;            
            if(val_17 != 0)
            {
                goto label_15;
            }
            // 0x01C01784: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_15:
            // 0x01C01788: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C0178C: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x01C01790: MOV x1, x24                | X1 = 0 (0x0);//ML01                     
            // 0x01C01794: BL #0xb42c9c               | X0 = val_17.AssetNameToABPath(assetName:  val_16);
            string val_14 = val_17.AssetNameToABPath(assetName:  val_16);
            // 0x01C01798: MOV x3, x0                 | X3 = val_14;//m1                        
            // 0x01C0179C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C017A0: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x01C017A4: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x01C017A8: MOV x2, x19                | X2 = X3;//m1                            
            // 0x01C017AC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01C017B0: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_15 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x01C017B4: SUB sp, x29, #0x40         | SP = (1152921510256758512 - 64) = 1152921510256758448 (0x1000000150C2CEB0);
            // 0x01C017B8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01C017BC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01C017C0: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01C017C4: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01C017C8: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x01C017CC: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_15;
            return val_15;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01C017D0: MOV x19, x0                | 
            // 0x01C017D4: ADD x0, sp, #8             | 
            // 0x01C017D8: B #0x1c017e4               | 
            // 0x01C017DC: MOV x19, x0                | 
            // 0x01C017E0: MOV x0, sp                 | 
            label_16:
            // 0x01C017E4: BL #0x299a140              | 
            // 0x01C017E8: MOV x0, x19                | 
            // 0x01C017EC: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01C017F0 (29366256), len: 832  VirtAddr: 0x01C017F0 RVA: 0x01C017F0 token: 100665085 methodIndex: 31134 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* GetIsCompressByABName_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_13;
            //  | 
            string val_18;
            //  | 
            var val_19;
            //  | 
            bool val_20;
            //  | 
            var val_21;
            // 0x01C017F0: STP x28, x27, [sp, #-0x60]! | stack[1152921510256956448] = ???;  stack[1152921510256956456] = ???;  //  dest_result_addr=1152921510256956448 |  dest_result_addr=1152921510256956456
            // 0x01C017F4: STP x26, x25, [sp, #0x10]  | stack[1152921510256956464] = ???;  stack[1152921510256956472] = ???;  //  dest_result_addr=1152921510256956464 |  dest_result_addr=1152921510256956472
            // 0x01C017F8: STP x24, x23, [sp, #0x20]  | stack[1152921510256956480] = ???;  stack[1152921510256956488] = ???;  //  dest_result_addr=1152921510256956480 |  dest_result_addr=1152921510256956488
            // 0x01C017FC: STP x22, x21, [sp, #0x30]  | stack[1152921510256956496] = ???;  stack[1152921510256956504] = ???;  //  dest_result_addr=1152921510256956496 |  dest_result_addr=1152921510256956504
            // 0x01C01800: STP x20, x19, [sp, #0x40]  | stack[1152921510256956512] = ???;  stack[1152921510256956520] = ???;  //  dest_result_addr=1152921510256956512 |  dest_result_addr=1152921510256956520
            // 0x01C01804: STP x29, x30, [sp, #0x50]  | stack[1152921510256956528] = ???;  stack[1152921510256956536] = ???;  //  dest_result_addr=1152921510256956528 |  dest_result_addr=1152921510256956536
            // 0x01C01808: ADD x29, sp, #0x50         | X29 = (1152921510256956448 + 80) = 1152921510256956528 (0x1000000150C5D470);
            // 0x01C0180C: SUB sp, sp, #0x10          | SP = (1152921510256956448 - 16) = 1152921510256956432 (0x1000000150C5D410);
            // 0x01C01810: ADRP x19, #0x373c000       | X19 = 57917440 (0x373C000);             
            // 0x01C01814: LDRB w8, [x19, #0x259]     | W8 = (bool)static_value_0373C259;       
            // 0x01C01818: MOV x21, x3                | X21 = X3;//m1                           
            // 0x01C0181C: MOV x22, x2                | X22 = X2;//m1                           
            // 0x01C01820: MOV x20, x1                | X20 = X1;//m1                           
            // 0x01C01824: TBNZ w8, #0, #0x1c01840    | if (static_value_0373C259 == true) goto label_0;
            // 0x01C01828: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x01C0182C: LDR x8, [x8, #0xce8]       | X8 = 0x2B92754;                         
            // 0x01C01830: LDR w0, [x8]               | W0 = 0x209A;                            
            // 0x01C01834: BL #0x2782188              | X0 = sub_2782188( ?? 0x209A, ????);     
            // 0x01C01838: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C0183C: STRB w8, [x19, #0x259]     | static_value_0373C259 = true;            //  dest_result_addr=57918041
            label_0:
            // 0x01C01840: CBNZ x20, #0x1c01848       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01C01844: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x209A, ????);     
            label_1:
            // 0x01C01848: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C0184C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C01850: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01C01854: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01C01858: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C0185C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C01860: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01C01864: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01C01868: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C0186C: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x01C01870: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C01874: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C01878: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01C0187C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01C01880: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C01884: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01C01888: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01C0188C: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x01C01890: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x01C01894: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01C01898: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x01C0189C: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x01C018A0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01C018A4: TBZ w9, #0, #0x1c018b8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01C018A8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01C018AC: CBNZ w9, #0x1c018b8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01C018B0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01C018B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01C018B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C018BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C018C0: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01C018C4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C018C8: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
            // 0x01C018CC: LDR x27, [x27, #0x7a0]     | X27 = 1152921504826228736;              
            // 0x01C018D0: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01C018D4: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01C018D8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01C018DC: TBZ w9, #0, #0x1c018f0     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01C018E0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01C018E4: CBNZ w9, #0x1c018f0        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01C018E8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01C018EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01C018F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C018F4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01C018F8: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x01C018FC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01C01900: MOV x3, x21                | X3 = X3;//m1                            
            // 0x01C01904: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01C01908: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01C0190C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01C01910: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x01C01914: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01C01918: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01C0191C: TBZ w9, #0, #0x1c01930     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01C01920: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01C01924: CBNZ w9, #0x1c01930        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01C01928: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01C0192C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01C01930: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C01934: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C01938: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01C0193C: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x01C01940: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01C01944: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_18 = 0;
            // 0x01C01948: CBZ x0, #0x1c01990         | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x01C0194C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01C01950: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01C01954: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01C01958: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01C0195C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x01C01960: MOV x24, x0                | X24 = val_6;//m1                        
            val_18 = val_6;
            // 0x01C01964: B.EQ #0x1c01990            | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x01C01968: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01C0196C: MOV x8, sp                 | X8 = 1152921510256956432 (0x1000000150C5D410);//ML01
            // 0x01C01970: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01C01974: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510256944544]
            // 0x01C01978: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x01C0197C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C01980: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x01C01984: MOV x0, sp                 | X0 = 1152921510256956432 (0x1000000150C5D410);//ML01
            // 0x01C01988: BL #0x299a140              | 
            // 0x01C0198C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_18 = 0;
            label_9:
            // 0x01C01990: CBNZ x20, #0x1c01998       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x01C01994: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150C5D410, ????);
            label_10:
            // 0x01C01998: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C0199C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C019A0: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x01C019A4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01C019A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C019AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C019B0: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01C019B4: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01C019B8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C019BC: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x01C019C0: LDR x8, [x8, #0xc30]       | X8 = 1152921504904183808;               
            // 0x01C019C4: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x01C019C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C019CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C019D0: LDR x1, [x8]               | X1 = typeof(ConfigAssetMgr);            
            // 0x01C019D4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C019D8: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x01C019DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C019E0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01C019E4: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x01C019E8: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01C019EC: MOV x3, x21                | X3 = X3;//m1                            
            // 0x01C019F0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01C019F4: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x01C019F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C019FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C01A00: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x01C01A04: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x01C01A08: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_19 = 0;
            // 0x01C01A0C: CBZ x0, #0x1c01a70         | if (val_11 == null) goto label_13;      
            if(val_11 == null)
            {
                goto label_13;
            }
            // 0x01C01A10: ADRP x9, #0x3654000        | X9 = 56967168 (0x3654000);              
            // 0x01C01A14: LDR x9, [x9, #0xb08]       | X9 = 1152921504904183808;               
            // 0x01C01A18: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01C01A1C: LDR x1, [x9]               | X1 = typeof(ConfigAssetMgr);            
            // 0x01C01A20: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C01A24: LDRB w9, [x1, #0x104]      | W9 = ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C01A28: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C01A2C: B.LO #0x1c01a48            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x01C01A30: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01C01A34: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHi
            // 0x01C01A38: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C01A3C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ConfigAssetMgr))
            // 0x01C01A40: MOV x21, x0                | X21 = val_11;//m1                       
            val_19 = val_11;
            // 0x01C01A44: B.EQ #0x1c01a70            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x01C01A48: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01C01A4C: ADD x8, sp, #8             | X8 = (1152921510256956432 + 8) = 1152921510256956440 (0x1000000150C5D418);
            // 0x01C01A50: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01C01A54: LDR x0, [sp, #8]           | X0 = val_13;                             //  find_add[1152921510256944544]
            // 0x01C01A58: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x01C01A5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C01A60: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x01C01A64: ADD x0, sp, #8             | X0 = (1152921510256956432 + 8) = 1152921510256956440 (0x1000000150C5D418);
            // 0x01C01A68: BL #0x299a140              | 
            // 0x01C01A6C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_19 = 0;
            label_13:
            // 0x01C01A70: CBNZ x20, #0x1c01a78       | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x01C01A74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150C5D418, ????);
            label_14:
            // 0x01C01A78: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C01A7C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C01A80: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x01C01A84: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01C01A88: CBNZ x21, #0x1c01a90       | if (0x0 != 0) goto label_15;            
            if(val_19 != 0)
            {
                goto label_15;
            }
            // 0x01C01A8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_15:
            // 0x01C01A90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C01A94: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x01C01A98: MOV x1, x24                | X1 = 0 (0x0);//ML01                     
            // 0x01C01A9C: BL #0xb42cd0               | X0 = val_19.GetIsCompressByABName(abName:  val_18);
            bool val_14 = val_19.GetIsCompressByABName(abName:  val_18);
            // 0x01C01AA0: MOV w20, w0                | W20 = val_14;//m1                       
            // 0x01C01AA4: CBZ x19, #0x1c01ab8        | if (val_2 == 0) goto label_16;          
            if(val_2 == 0)
            {
                goto label_16;
            }
            // 0x01C01AA8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C01AAC: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x01C01AB0: AND w20, w20, #1           | W20 = (val_14 & 1);                     
            val_20 = val_14;
            // 0x01C01AB4: B #0x1c01acc               |  goto label_17;                         
            goto label_17;
            label_16:
            // 0x01C01AB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            // 0x01C01ABC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C01AC0: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x01C01AC4: AND w20, w20, #1           | W20 = (val_14 & 1);                     
            val_20 = val_14;
            // 0x01C01AC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_17:
            // 0x01C01ACC: STR w20, [x19, #4]         | mem2[0] = (val_14 & 1);                  //  dest_result_addr=0
            mem2[0] = val_20;
            // 0x01C01AD0: LDR x0, [x27]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01C01AD4: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_21 = 8;
            // 0x01C01AD8: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x01C01ADC: TBZ w9, #0, #0x1c01aec     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_18;
            // 0x01C01AE0: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x01C01AE4: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x01C01AE8: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_21 = 219381744;
            label_18:
            // 0x01C01AEC: ADD x0, x8, x19            | X0 = (val_21 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_15 = val_21 + val_2;
            // 0x01C01AF0: SUB sp, x29, #0x50         | SP = (1152921510256956528 - 80) = 1152921510256956448 (0x1000000150C5D420);
            // 0x01C01AF4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01C01AF8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01C01AFC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x01C01B00: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x01C01B04: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x01C01B08: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x01C01B0C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_21 + val_2);
            return val_15;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01C01B10: MOV x19, x0                | 
            // 0x01C01B14: ADD x0, sp, #8             | 
            // 0x01C01B18: B #0x1c01b24               | 
            // 0x01C01B1C: MOV x19, x0                | 
            // 0x01C01B20: MOV x0, sp                 | 
            label_19:
            // 0x01C01B24: BL #0x299a140              | 
            // 0x01C01B28: MOV x0, x19                | 
            // 0x01C01B2C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01C01B30 (29367088), len: 832  VirtAddr: 0x01C01B30 RVA: 0x01C01B30 token: 100665086 methodIndex: 31135 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* IsNullAsset_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_13;
            //  | 
            string val_18;
            //  | 
            var val_19;
            //  | 
            bool val_20;
            //  | 
            var val_21;
            // 0x01C01B30: STP x28, x27, [sp, #-0x60]! | stack[1152921510257150368] = ???;  stack[1152921510257150376] = ???;  //  dest_result_addr=1152921510257150368 |  dest_result_addr=1152921510257150376
            // 0x01C01B34: STP x26, x25, [sp, #0x10]  | stack[1152921510257150384] = ???;  stack[1152921510257150392] = ???;  //  dest_result_addr=1152921510257150384 |  dest_result_addr=1152921510257150392
            // 0x01C01B38: STP x24, x23, [sp, #0x20]  | stack[1152921510257150400] = ???;  stack[1152921510257150408] = ???;  //  dest_result_addr=1152921510257150400 |  dest_result_addr=1152921510257150408
            // 0x01C01B3C: STP x22, x21, [sp, #0x30]  | stack[1152921510257150416] = ???;  stack[1152921510257150424] = ???;  //  dest_result_addr=1152921510257150416 |  dest_result_addr=1152921510257150424
            // 0x01C01B40: STP x20, x19, [sp, #0x40]  | stack[1152921510257150432] = ???;  stack[1152921510257150440] = ???;  //  dest_result_addr=1152921510257150432 |  dest_result_addr=1152921510257150440
            // 0x01C01B44: STP x29, x30, [sp, #0x50]  | stack[1152921510257150448] = ???;  stack[1152921510257150456] = ???;  //  dest_result_addr=1152921510257150448 |  dest_result_addr=1152921510257150456
            // 0x01C01B48: ADD x29, sp, #0x50         | X29 = (1152921510257150368 + 80) = 1152921510257150448 (0x1000000150C8C9F0);
            // 0x01C01B4C: SUB sp, sp, #0x10          | SP = (1152921510257150368 - 16) = 1152921510257150352 (0x1000000150C8C990);
            // 0x01C01B50: ADRP x19, #0x373c000       | X19 = 57917440 (0x373C000);             
            // 0x01C01B54: LDRB w8, [x19, #0x25a]     | W8 = (bool)static_value_0373C25A;       
            // 0x01C01B58: MOV x21, x3                | X21 = X3;//m1                           
            // 0x01C01B5C: MOV x22, x2                | X22 = X2;//m1                           
            // 0x01C01B60: MOV x20, x1                | X20 = X1;//m1                           
            // 0x01C01B64: TBNZ w8, #0, #0x1c01b80    | if (static_value_0373C25A == true) goto label_0;
            // 0x01C01B68: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
            // 0x01C01B6C: LDR x8, [x8, #0xbe8]       | X8 = 0x2B92758;                         
            // 0x01C01B70: LDR w0, [x8]               | W0 = 0x209B;                            
            // 0x01C01B74: BL #0x2782188              | X0 = sub_2782188( ?? 0x209B, ????);     
            // 0x01C01B78: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C01B7C: STRB w8, [x19, #0x25a]     | static_value_0373C25A = true;            //  dest_result_addr=57918042
            label_0:
            // 0x01C01B80: CBNZ x20, #0x1c01b88       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01C01B84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x209B, ????);     
            label_1:
            // 0x01C01B88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C01B8C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C01B90: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01C01B94: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01C01B98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C01B9C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C01BA0: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01C01BA4: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01C01BA8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C01BAC: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x01C01BB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C01BB4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C01BB8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01C01BBC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01C01BC0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C01BC4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01C01BC8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01C01BCC: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x01C01BD0: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x01C01BD4: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01C01BD8: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x01C01BDC: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x01C01BE0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01C01BE4: TBZ w9, #0, #0x1c01bf8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01C01BE8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01C01BEC: CBNZ w9, #0x1c01bf8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01C01BF0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01C01BF4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01C01BF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C01BFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C01C00: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01C01C04: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C01C08: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
            // 0x01C01C0C: LDR x27, [x27, #0x7a0]     | X27 = 1152921504826228736;              
            // 0x01C01C10: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01C01C14: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01C01C18: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01C01C1C: TBZ w9, #0, #0x1c01c30     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01C01C20: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01C01C24: CBNZ w9, #0x1c01c30        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01C01C28: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01C01C2C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01C01C30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C01C34: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01C01C38: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x01C01C3C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01C01C40: MOV x3, x21                | X3 = X3;//m1                            
            // 0x01C01C44: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01C01C48: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01C01C4C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01C01C50: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x01C01C54: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01C01C58: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01C01C5C: TBZ w9, #0, #0x1c01c70     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01C01C60: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01C01C64: CBNZ w9, #0x1c01c70        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01C01C68: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01C01C6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01C01C70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C01C74: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C01C78: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01C01C7C: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x01C01C80: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01C01C84: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_18 = 0;
            // 0x01C01C88: CBZ x0, #0x1c01cd0         | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x01C01C8C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01C01C90: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01C01C94: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01C01C98: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01C01C9C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x01C01CA0: MOV x24, x0                | X24 = val_6;//m1                        
            val_18 = val_6;
            // 0x01C01CA4: B.EQ #0x1c01cd0            | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x01C01CA8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01C01CAC: MOV x8, sp                 | X8 = 1152921510257150352 (0x1000000150C8C990);//ML01
            // 0x01C01CB0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01C01CB4: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510257138464]
            // 0x01C01CB8: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x01C01CBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C01CC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x01C01CC4: MOV x0, sp                 | X0 = 1152921510257150352 (0x1000000150C8C990);//ML01
            // 0x01C01CC8: BL #0x299a140              | 
            // 0x01C01CCC: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_18 = 0;
            label_9:
            // 0x01C01CD0: CBNZ x20, #0x1c01cd8       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x01C01CD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150C8C990, ????);
            label_10:
            // 0x01C01CD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C01CDC: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C01CE0: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x01C01CE4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01C01CE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C01CEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C01CF0: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01C01CF4: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01C01CF8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01C01CFC: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x01C01D00: LDR x8, [x8, #0xc30]       | X8 = 1152921504904183808;               
            // 0x01C01D04: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x01C01D08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C01D0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C01D10: LDR x1, [x8]               | X1 = typeof(ConfigAssetMgr);            
            // 0x01C01D14: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01C01D18: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x01C01D1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C01D20: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01C01D24: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x01C01D28: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01C01D2C: MOV x3, x21                | X3 = X3;//m1                            
            // 0x01C01D30: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01C01D34: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x01C01D38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C01D3C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C01D40: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x01C01D44: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x01C01D48: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_19 = 0;
            // 0x01C01D4C: CBZ x0, #0x1c01db0         | if (val_11 == null) goto label_13;      
            if(val_11 == null)
            {
                goto label_13;
            }
            // 0x01C01D50: ADRP x9, #0x3654000        | X9 = 56967168 (0x3654000);              
            // 0x01C01D54: LDR x9, [x9, #0xb08]       | X9 = 1152921504904183808;               
            // 0x01C01D58: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01C01D5C: LDR x1, [x9]               | X1 = typeof(ConfigAssetMgr);            
            // 0x01C01D60: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C01D64: LDRB w9, [x1, #0x104]      | W9 = ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01C01D68: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01C01D6C: B.LO #0x1c01d88            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x01C01D70: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01C01D74: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHi
            // 0x01C01D78: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01C01D7C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ConfigAssetMgr))
            // 0x01C01D80: MOV x21, x0                | X21 = val_11;//m1                       
            val_19 = val_11;
            // 0x01C01D84: B.EQ #0x1c01db0            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ConfigAssetMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x01C01D88: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01C01D8C: ADD x8, sp, #8             | X8 = (1152921510257150352 + 8) = 1152921510257150360 (0x1000000150C8C998);
            // 0x01C01D90: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01C01D94: LDR x0, [sp, #8]           | X0 = val_13;                             //  find_add[1152921510257138464]
            // 0x01C01D98: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x01C01D9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C01DA0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x01C01DA4: ADD x0, sp, #8             | X0 = (1152921510257150352 + 8) = 1152921510257150360 (0x1000000150C8C998);
            // 0x01C01DA8: BL #0x299a140              | 
            // 0x01C01DAC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_19 = 0;
            label_13:
            // 0x01C01DB0: CBNZ x20, #0x1c01db8       | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x01C01DB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000150C8C998, ????);
            label_14:
            // 0x01C01DB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C01DBC: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01C01DC0: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x01C01DC4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01C01DC8: CBNZ x21, #0x1c01dd0       | if (0x0 != 0) goto label_15;            
            if(val_19 != 0)
            {
                goto label_15;
            }
            // 0x01C01DCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_15:
            // 0x01C01DD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01C01DD4: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x01C01DD8: MOV x1, x24                | X1 = 0 (0x0);//ML01                     
            // 0x01C01DDC: BL #0xb42d04               | X0 = val_19.IsNullAsset(path:  val_18); 
            bool val_14 = val_19.IsNullAsset(path:  val_18);
            // 0x01C01DE0: MOV w20, w0                | W20 = val_14;//m1                       
            // 0x01C01DE4: CBZ x19, #0x1c01df8        | if (val_2 == 0) goto label_16;          
            if(val_2 == 0)
            {
                goto label_16;
            }
            // 0x01C01DE8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C01DEC: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x01C01DF0: AND w20, w20, #1           | W20 = (val_14 & 1);                     
            val_20 = val_14;
            // 0x01C01DF4: B #0x1c01e0c               |  goto label_17;                         
            goto label_17;
            label_16:
            // 0x01C01DF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            // 0x01C01DFC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C01E00: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x01C01E04: AND w20, w20, #1           | W20 = (val_14 & 1);                     
            val_20 = val_14;
            // 0x01C01E08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_17:
            // 0x01C01E0C: STR w20, [x19, #4]         | mem2[0] = (val_14 & 1);                  //  dest_result_addr=0
            mem2[0] = val_20;
            // 0x01C01E10: LDR x0, [x27]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01C01E14: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_21 = 8;
            // 0x01C01E18: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x01C01E1C: TBZ w9, #0, #0x1c01e2c     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_18;
            // 0x01C01E20: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x01C01E24: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x01C01E28: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_21 = 219381744;
            label_18:
            // 0x01C01E2C: ADD x0, x8, x19            | X0 = (val_21 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_15 = val_21 + val_2;
            // 0x01C01E30: SUB sp, x29, #0x50         | SP = (1152921510257150448 - 80) = 1152921510257150368 (0x1000000150C8C9A0);
            // 0x01C01E34: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01C01E38: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01C01E3C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x01C01E40: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x01C01E44: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x01C01E48: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x01C01E4C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_21 + val_2);
            return val_15;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01C01E50: MOV x19, x0                | 
            // 0x01C01E54: ADD x0, sp, #8             | 
            // 0x01C01E58: B #0x1c01e64               | 
            // 0x01C01E5C: MOV x19, x0                | 
            // 0x01C01E60: MOV x0, sp                 | 
            label_19:
            // 0x01C01E64: BL #0x299a140              | 
            // 0x01C01E68: MOV x0, x19                | 
            // 0x01C01E6C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01C01E70 (29367920), len: 180  VirtAddr: 0x01C01E70 RVA: 0x01C01E70 token: 100665087 methodIndex: 31136 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            // 0x01C01E70: STP x22, x21, [sp, #-0x30]! | stack[1152921510257319760] = ???;  stack[1152921510257319768] = ???;  //  dest_result_addr=1152921510257319760 |  dest_result_addr=1152921510257319768
            // 0x01C01E74: STP x20, x19, [sp, #0x10]  | stack[1152921510257319776] = ???;  stack[1152921510257319784] = ???;  //  dest_result_addr=1152921510257319776 |  dest_result_addr=1152921510257319784
            // 0x01C01E78: STP x29, x30, [sp, #0x20]  | stack[1152921510257319792] = ???;  stack[1152921510257319800] = ???;  //  dest_result_addr=1152921510257319792 |  dest_result_addr=1152921510257319800
            // 0x01C01E7C: ADD x29, sp, #0x20         | X29 = (1152921510257319760 + 32) = 1152921510257319792 (0x1000000150CB5F70);
            // 0x01C01E80: ADRP x22, #0x373c000       | X22 = 57917440 (0x373C000);             
            // 0x01C01E84: LDRB w8, [x22, #0x25b]     | W8 = (bool)static_value_0373C25B;       
            // 0x01C01E88: MOV x19, x3                | X19 = X3;//m1                           
            // 0x01C01E8C: MOV x20, x2                | X20 = X2;//m1                           
            // 0x01C01E90: MOV x21, x1                | X21 = X1;//m1                           
            // 0x01C01E94: TBNZ w8, #0, #0x1c01eb0    | if (static_value_0373C25B == true) goto label_0;
            // 0x01C01E98: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x01C01E9C: LDR x8, [x8, #0x130]       | X8 = 0x2B92744;                         
            // 0x01C01EA0: LDR w0, [x8]               | W0 = 0x2096;                            
            // 0x01C01EA4: BL #0x2782188              | X0 = sub_2782188( ?? 0x2096, ????);     
            // 0x01C01EA8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C01EAC: STRB w8, [x22, #0x25b]     | static_value_0373C25B = true;            //  dest_result_addr=57918043
            label_0:
            // 0x01C01EB0: CBNZ x21, #0x1c01eb8       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01C01EB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2096, ????);     
            label_1:
            // 0x01C01EB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C01EBC: MOV x0, x21                | X0 = X1;//m1                            
            // 0x01C01EC0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01C01EC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C01EC8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x01C01ECC: MOV x1, x20                | X1 = X2;//m1                            
            // 0x01C01ED0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01C01ED4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            // 0x01C01ED8: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
            // 0x01C01EDC: LDR x8, [x8, #0xb08]       | X8 = 1152921504904183808;               
            // 0x01C01EE0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01C01EE4: LDR x8, [x8]               | X8 = typeof(ConfigAssetMgr);            
            // 0x01C01EE8: MOV x0, x8                 | X0 = 1152921504904183808 (0x1000000011B90000);//ML01
            ConfigAssetMgr val_3 = null;
            // 0x01C01EEC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ConfigAssetMgr), ????);
            // 0x01C01EF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C01EF4: MOV x21, x0                | X21 = 1152921504904183808 (0x1000000011B90000);//ML01
            // 0x01C01EF8: BL #0xb42a34               | .ctor();                                
            val_3 = new ConfigAssetMgr();
            // 0x01C01EFC: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x01C01F00: MOV x2, x19                | X2 = X3;//m1                            
            // 0x01C01F04: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01C01F08: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01C01F0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01C01F10: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x01C01F14: MOV x3, x21                | X3 = 1152921504904183808 (0x1000000011B90000);//ML01
            // 0x01C01F18: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01C01F1C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01C01F20: B #0x1f657ec               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
        
        }
        //
        // Offset in libil2cpp.so: 0x01C01F24 (29368100), len: 92  VirtAddr: 0x01C01F24 RVA: 0x01C01F24 token: 100665088 methodIndex: 31137 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__0()
        {
            //
            // Disasemble & Code
            // 0x01C01F24: STP x20, x19, [sp, #-0x20]! | stack[1152921510257448160] = ???;  stack[1152921510257448168] = ???;  //  dest_result_addr=1152921510257448160 |  dest_result_addr=1152921510257448168
            // 0x01C01F28: STP x29, x30, [sp, #0x10]  | stack[1152921510257448176] = ???;  stack[1152921510257448184] = ???;  //  dest_result_addr=1152921510257448176 |  dest_result_addr=1152921510257448184
            // 0x01C01F2C: ADD x29, sp, #0x10         | X29 = (1152921510257448160 + 16) = 1152921510257448176 (0x1000000150CD54F0);
            // 0x01C01F30: ADRP x19, #0x373c000       | X19 = 57917440 (0x373C000);             
            // 0x01C01F34: LDRB w8, [x19, #0x25c]     | W8 = (bool)static_value_0373C25C;       
            // 0x01C01F38: TBNZ w8, #0, #0x1c01f54    | if (static_value_0373C25C == true) goto label_0;
            // 0x01C01F3C: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x01C01F40: LDR x8, [x8, #0x4a8]       | X8 = 0x2B92770;                         
            // 0x01C01F44: LDR w0, [x8]               | W0 = 0x20A1;                            
            // 0x01C01F48: BL #0x2782188              | X0 = sub_2782188( ?? 0x20A1, ????);     
            // 0x01C01F4C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C01F50: STRB w8, [x19, #0x25c]     | static_value_0373C25C = true;            //  dest_result_addr=57918044
            label_0:
            // 0x01C01F54: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
            // 0x01C01F58: LDR x8, [x8, #0xb08]       | X8 = 1152921504904183808;               
            // 0x01C01F5C: LDR x0, [x8]               | X0 = typeof(ConfigAssetMgr);            
            ConfigAssetMgr val_1 = null;
            // 0x01C01F60: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ConfigAssetMgr), ????);
            // 0x01C01F64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01C01F68: MOV x19, x0                | X19 = 1152921504904183808 (0x1000000011B90000);//ML01
            // 0x01C01F6C: BL #0xb42a34               | .ctor();                                
            val_1 = new ConfigAssetMgr();
            // 0x01C01F70: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01C01F74: MOV x0, x19                | X0 = 1152921504904183808 (0x1000000011B90000);//ML01
            // 0x01C01F78: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01C01F7C: RET                        |  return (System.Object)typeof(ConfigAssetMgr);
            return (object)val_1;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01C01F80 (29368192), len: 92  VirtAddr: 0x01C01F80 RVA: 0x01C01F80 token: 100665089 methodIndex: 31138 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__1(int s)
        {
            //
            // Disasemble & Code
            // 0x01C01F80: STP x20, x19, [sp, #-0x20]! | stack[1152921510257564256] = ???;  stack[1152921510257564264] = ???;  //  dest_result_addr=1152921510257564256 |  dest_result_addr=1152921510257564264
            // 0x01C01F84: STP x29, x30, [sp, #0x10]  | stack[1152921510257564272] = ???;  stack[1152921510257564280] = ???;  //  dest_result_addr=1152921510257564272 |  dest_result_addr=1152921510257564280
            // 0x01C01F88: ADD x29, sp, #0x10         | X29 = (1152921510257564256 + 16) = 1152921510257564272 (0x1000000150CF1A70);
            // 0x01C01F8C: ADRP x20, #0x373c000       | X20 = 57917440 (0x373C000);             
            // 0x01C01F90: LDRB w8, [x20, #0x25d]     | W8 = (bool)static_value_0373C25D;       
            // 0x01C01F94: MOV w19, w1                | W19 = W1;//m1                           
            // 0x01C01F98: TBNZ w8, #0, #0x1c01fb4    | if (static_value_0373C25D == true) goto label_0;
            // 0x01C01F9C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01C01FA0: LDR x8, [x8, #0xff8]       | X8 = 0x2B92774;                         
            // 0x01C01FA4: LDR w0, [x8]               | W0 = 0x20A2;                            
            // 0x01C01FA8: BL #0x2782188              | X0 = sub_2782188( ?? 0x20A2, ????);     
            // 0x01C01FAC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01C01FB0: STRB w8, [x20, #0x25d]     | static_value_0373C25D = true;            //  dest_result_addr=57918045
            label_0:
            // 0x01C01FB4: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
            // 0x01C01FB8: LDR x8, [x8, #0x208]       | X8 = 1152921510257548192;               
            // 0x01C01FBC: LDR x20, [x8]              | X20 = typeof(ConfigAssetMgr[]);         
            // 0x01C01FC0: MOV x0, x20                | X0 = 1152921510257548192 (0x1000000150CEDBA0);//ML01
            // 0x01C01FC4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(ConfigAssetMgr[]), ????);
            // 0x01C01FC8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01C01FCC: MOV w1, w19                | W1 = W1;//m1                            
            // 0x01C01FD0: MOV x0, x20                | X0 = 1152921510257548192 (0x1000000150CEDBA0);//ML01
            // 0x01C01FD4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01C01FD8: B #0x27c1608               | X0 = sub_27C1608( ?? typeof(ConfigAssetMgr[]), ????);
        
        }
    
    }

}
