using UnityEngine;

namespace Pathfinding.Voxels
{
    public struct CompactVoxelSpan
    {
        // Fields
        public ushort y; //  0x00000000
        public uint con; //  0x00000004
        public uint h; //  0x00000008
        public int reg; //  0x0000000C
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00EDC838 (15583288), len: 20  VirtAddr: 0x00EDC838 RVA: 0x00EDC838 token: 100683283 methodIndex: 51356 delegateWrapperIndex: 0 methodInvoker: 0
        public CompactVoxelSpan(ushort bottom, uint height)
        {
            //
            // Disasemble & Code
            // 0x00EDC838: ORR w8, wzr, #0x18         | W8 = 24(0x18);                          
            // 0x00EDC83C: STRH w1, [x0, #0x10]       | mem[1152921513443667248] = bottom;       //  dest_result_addr=1152921513443667248
            mem[1152921513443667248] = bottom;
            // 0x00EDC840: STP w8, w2, [x0, #0x14]    | mem[1152921513443667252] = 0x18;  mem[1152921513443667256] = height;  //  dest_result_addr=1152921513443667252 |  dest_result_addr=1152921513443667256
            mem[1152921513443667252] = 24;
            mem[1152921513443667256] = height;
            // 0x00EDC844: STR wzr, [x0, #0x1c]       | mem[1152921513443667260] = 0x0;          //  dest_result_addr=1152921513443667260
            mem[1152921513443667260] = 0;
            // 0x00EDC848: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00EDC84C (15583308), len: 48  VirtAddr: 0x00EDC84C RVA: 0x00EDC84C token: 100683284 methodIndex: 51357 delegateWrapperIndex: 0 methodInvoker: 0
        public void SetConnection(int dir, uint value)
        {
            //
            // Disasemble & Code
            // 0x00EDC84C: ORR w8, wzr, #6            | W8 = 6(0x6);                            
            int val_3 = 6;
            // 0x00EDC850: LDR w9, [x0, #0x14]        | 
            // 0x00EDC854: MUL w8, w1, w8             | W8 = (dir * 6);                         
            val_3 = dir * val_3;
            // 0x00EDC858: ORR w10, wzr, #0x3f        | W10 = 63(0x3F);                         
            var val_4 = 63;
            // 0x00EDC85C: AND w8, w8, #0x1e          | W8 = ((dir * 6) & 30);                  
            val_3 = val_3 & 30;
            // 0x00EDC860: AND w11, w2, #0x3f         | W11 = (value & 63);                     
            uint val_1 = value & 63;
            // 0x00EDC864: LSL w10, w10, w8           | W10 = (63 << ((dir * 6) & 30));         
            val_4 = val_4 << val_3;
            // 0x00EDC868: BIC w9, w9, w10            | W9 = (W9 & (~(63 << ((dir * 6) & 30))));
            int val_2 = W9 & (~val_4);
            // 0x00EDC86C: LSL w8, w11, w8            | W8 = ((value & 63) << ((dir * 6) & 30));
            val_3 = val_1 << val_3;
            // 0x00EDC870: ORR w8, w9, w8             | W8 = ((W9 & (~(63 << ((dir * 6) & 30)))) | ((value & 63) << ((dir * 6) & 30)));
            val_3 = val_2 | val_3;
            // 0x00EDC874: STR w8, [x0, #0x14]        | mem[1152921513443779252] = ((W9 & (~(63 << ((dir * 6) & 30)))) | ((value & 63) << ((dir * 6) & 30)));  //  dest_result_addr=1152921513443779252
            mem[1152921513443779252] = val_3;
            // 0x00EDC878: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00EDC87C (15583356), len: 304  VirtAddr: 0x00EDC87C RVA: 0x00EDC87C token: 100683285 methodIndex: 51358 delegateWrapperIndex: 0 methodInvoker: 0
        public int GetConnection(int dir)
        {
            //
            // Disasemble & Code
            // 0x00EDC87C: LDR w8, [x0, #0x14]        | 
            // 0x00EDC880: ORR w9, wzr, #6            | W9 = 6(0x6);                            
            var val_3 = 6;
            // 0x00EDC884: MUL w9, w1, w9             | W9 = (dir * 6);                         
            val_3 = dir * val_3;
            // 0x00EDC888: AND w9, w9, #0x1e          | W9 = ((dir * 6) & 30);                  
            val_3 = val_3 & 30;
            // 0x00EDC88C: ASR w8, w8, w9             | W8 = (W8 >> ((dir * 6) & 30));          
            int val_1 = W8 >> val_3;
            // 0x00EDC890: AND w0, w8, #0x3f          | W0 = ((W8 >> ((dir * 6) & 30)) & 63);   
            int val_2 = val_1 & 63;
            // 0x00EDC894: RET                        |  return (System.Int32)((W8 >> ((dir * 6) & 30)) & 63);
            return val_2;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
    
    }

}
