using UnityEngine;
[ProtoBuf.ProtoContractAttribute] // 0x286D1B4
[Serializable]
public class CameraShotHeroOrNpcCfg : IExtensible
{
    // Fields
    private int _id; //  0x00000010
    private int _npcType; //  0x00000014
    private int _npcRoundIndex; //  0x00000018
    private int _npcId; //  0x0000001C
    private ProtoBuf.IExtension extensionObject; //  0x00000020
    
    // Properties
    [ProtoBuf.ProtoMemberAttribute] // 0x286D1F8
    [System.ComponentModel.DefaultValueAttribute] // 0x286D1F8
    public int id { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286D278
    [System.ComponentModel.DefaultValueAttribute] // 0x286D278
    public int npcType { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286D2F8
    [System.ComponentModel.DefaultValueAttribute] // 0x286D2F8
    public int npcRoundIndex { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286D378
    [System.ComponentModel.DefaultValueAttribute] // 0x286D378
    public int npcId { get; set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00D77398 (14119832), len: 8  VirtAddr: 0x00D77398 RVA: 0x00D77398 token: 100690400 methodIndex: 25796 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraShotHeroOrNpcCfg()
    {
        //
        // Disasemble & Code
        // 0x00D77398: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7739C: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D773A0 (14119840), len: 8  VirtAddr: 0x00D773A0 RVA: 0x00D773A0 token: 100690401 methodIndex: 25797 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_id()
    {
        //
        // Disasemble & Code
        // 0x00D773A0: LDR w0, [x0, #0x10]        | W0 = this._id; //P2                     
        // 0x00D773A4: RET                        |  return (System.Int32)this._id;         
        return this._id;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D773A8 (14119848), len: 8  VirtAddr: 0x00D773A8 RVA: 0x00D773A8 token: 100690402 methodIndex: 25798 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_id(int value)
    {
        //
        // Disasemble & Code
        // 0x00D773A8: STR w1, [x0, #0x10]        | this._id = value;                        //  dest_result_addr=1152921514517149360
        this._id = value;
        // 0x00D773AC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D773B0 (14119856), len: 8  VirtAddr: 0x00D773B0 RVA: 0x00D773B0 token: 100690403 methodIndex: 25799 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_npcType()
    {
        //
        // Disasemble & Code
        // 0x00D773B0: LDR w0, [x0, #0x14]        | W0 = this._npcType; //P2                
        // 0x00D773B4: RET                        |  return (System.Int32)this._npcType;    
        return this._npcType;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D773B8 (14119864), len: 8  VirtAddr: 0x00D773B8 RVA: 0x00D773B8 token: 100690404 methodIndex: 25800 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_npcType(int value)
    {
        //
        // Disasemble & Code
        // 0x00D773B8: STR w1, [x0, #0x14]        | this._npcType = value;                   //  dest_result_addr=1152921514517373364
        this._npcType = value;
        // 0x00D773BC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D773C0 (14119872), len: 8  VirtAddr: 0x00D773C0 RVA: 0x00D773C0 token: 100690405 methodIndex: 25801 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_npcRoundIndex()
    {
        //
        // Disasemble & Code
        // 0x00D773C0: LDR w0, [x0, #0x18]        | W0 = this._npcRoundIndex; //P2          
        // 0x00D773C4: RET                        |  return (System.Int32)this._npcRoundIndex;
        return this._npcRoundIndex;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D773C8 (14119880), len: 8  VirtAddr: 0x00D773C8 RVA: 0x00D773C8 token: 100690406 methodIndex: 25802 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_npcRoundIndex(int value)
    {
        //
        // Disasemble & Code
        // 0x00D773C8: STR w1, [x0, #0x18]        | this._npcRoundIndex = value;             //  dest_result_addr=1152921514517597368
        this._npcRoundIndex = value;
        // 0x00D773CC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D773D0 (14119888), len: 8  VirtAddr: 0x00D773D0 RVA: 0x00D773D0 token: 100690407 methodIndex: 25803 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_npcId()
    {
        //
        // Disasemble & Code
        // 0x00D773D0: LDR w0, [x0, #0x1c]        | W0 = this._npcId; //P2                  
        // 0x00D773D4: RET                        |  return (System.Int32)this._npcId;      
        return this._npcId;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D773D8 (14119896), len: 8  VirtAddr: 0x00D773D8 RVA: 0x00D773D8 token: 100690408 methodIndex: 25804 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_npcId(int value)
    {
        //
        // Disasemble & Code
        // 0x00D773D8: STR w1, [x0, #0x1c]        | this._npcId = value;                     //  dest_result_addr=1152921514517821372
        this._npcId = value;
        // 0x00D773DC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D773E0 (14119904), len: 24  VirtAddr: 0x00D773E0 RVA: 0x00D773E0 token: 100690409 methodIndex: 25805 delegateWrapperIndex: 0 methodInvoker: 0
    private ProtoBuf.IExtension ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
    {
        //
        // Disasemble & Code
        // 0x00D773E0: ADD x8, x0, #0x20          | X8 = this.extensionObject;//AP2 res_addr=1152921514517933376
        // 0x00D773E4: AND w2, w1, #1             | W2 = (createIfMissing & 1);             
        bool val_1 = createIfMissing;
        // 0x00D773E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        ProtoBuf.IExtension val_2 = 0;
        // 0x00D773EC: MOV x1, x8                 | X1 = this.extensionObject;//m1          
        // 0x00D773F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D773F4: B #0xc7c9f0                | return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  ProtoBuf.IExtension val_2 = 0, createIfMissing:  this.extensionObject);
        return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  val_2, createIfMissing:  this.extensionObject);
    
    }

}
