using UnityEngine;

namespace ILRuntime.Runtime.Enviorment
{
    public sealed class CLRRedirectionDelegate : MulticastDelegate
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x028E3B10 (42875664), len: 16  VirtAddr: 0x028E3B10 RVA: 0x028E3B10 token: 100680184 methodIndex: 29551 delegateWrapperIndex: 0 methodInvoker: 0
        public CLRRedirectionDelegate(object object, IntPtr method)
        {
            //
            // Disasemble & Code
            // 0x028E3B10: LDR x8, [x2]               | X8 = method;                            
            // 0x028E3B14: STP x1, x2, [x0, #0x20]    | mem[1152921512875024032] = object;  mem[1152921512875024040] = method;  //  dest_result_addr=1152921512875024032 |  dest_result_addr=1152921512875024040
            mem[1152921512875024032] = object;
            mem[1152921512875024040] = method;
            // 0x028E3B18: STR x8, [x0, #0x10]        | mem[1152921512875024016] = method;       //  dest_result_addr=1152921512875024016
            mem[1152921512875024016] = method;
            // 0x028E3B1C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028E9754 (42899284), len: 1104  VirtAddr: 0x028E9754 RVA: 0x028E9754 token: 100680185 methodIndex: 29552 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual ILRuntime.Runtime.Stack.StackObject* Invoke(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_24;
            //  | 
            var val_25;
            //  | 
            var val_26;
            //  | 
            var val_27;
            //  | 
            var val_28;
            //  | 
            var val_29;
            label_1:
            // 0x028E9754: STP x26, x25, [sp, #-0x50]! | stack[1152921512875156688] = ???;  stack[1152921512875156696] = ???;  //  dest_result_addr=1152921512875156688 |  dest_result_addr=1152921512875156696
            // 0x028E9758: STP x24, x23, [sp, #0x10]  | stack[1152921512875156704] = ???;  stack[1152921512875156712] = ???;  //  dest_result_addr=1152921512875156704 |  dest_result_addr=1152921512875156712
            // 0x028E975C: STP x22, x21, [sp, #0x20]  | stack[1152921512875156720] = ???;  stack[1152921512875156728] = ???;  //  dest_result_addr=1152921512875156720 |  dest_result_addr=1152921512875156728
            // 0x028E9760: STP x20, x19, [sp, #0x30]  | stack[1152921512875156736] = ???;  stack[1152921512875156744] = ???;  //  dest_result_addr=1152921512875156736 |  dest_result_addr=1152921512875156744
            // 0x028E9764: STP x29, x30, [sp, #0x40]  | stack[1152921512875156752] = ???;  stack[1152921512875156760] = ???;  //  dest_result_addr=1152921512875156752 |  dest_result_addr=1152921512875156760
            // 0x028E9768: ADD x29, sp, #0x40         | X29 = (1152921512875156688 + 64) = 1152921512875156752 (0x10000001ECD46510);
            // 0x028E976C: SUB sp, sp, #0x10          | SP = (1152921512875156688 - 16) = 1152921512875156672 (0x10000001ECD464C0);
            // 0x028E9770: MOV x26, x0                | X26 = 1152921512875168768 (0x10000001ECD49400);//ML01
            // 0x028E9774: LDR x0, [x26, #0x58]       | 
            // 0x028E9778: MOV w23, w5                | W23 = W5;//m1                           
            // 0x028E977C: MOV x19, x4                | X19 = X4;//m1                           
            // 0x028E9780: MOV x20, x3                | X20 = X3;//m1                           
            // 0x028E9784: MOV x21, x2                | X21 = X2;//m1                           
            // 0x028E9788: MOV x22, x1                | X22 = intp;//m1                         
            // 0x028E978C: CBZ x0, #0x28e97a8         | if (this == null) goto label_0;         
            if(this == null)
            {
                goto label_0;
            }
            // 0x028E9790: AND w5, w23, #1            | W5 = (W5 & 1);                          
            var val_1 = W5 & 1;
            // 0x028E9794: MOV x1, x22                | X1 = intp;//m1                          
            // 0x028E9798: MOV x2, x21                | X2 = X2;//m1                            
            // 0x028E979C: MOV x3, x20                | X3 = X3;//m1                            
            // 0x028E97A0: MOV x4, x19                | X4 = X4;//m1                            
            // 0x028E97A4: BL #0x28e9754              |  R0 = label_1();                        
            label_0:
            // 0x028E97A8: LDR x0, [x26, #0x10]       | 
            // 0x028E97AC: STR x0, [sp, #8]           | stack[1152921512875156680] = this;       //  dest_result_addr=1152921512875156680
            // 0x028E97B0: LDP x25, x24, [x26, #0x20] |                                          //  | 
            // 0x028E97B4: MOV x0, x24                | X0 = X24;//m1                           
            // 0x028E97B8: BL #0x2796f94              | X0 = sub_2796F94( ?? X24, ????);        
            // 0x028E97BC: MOV x0, x24                | X0 = X24;//m1                           
            // 0x028E97C0: BL #0x27c09a4              | X0 = sub_27C09A4( ?? X24, ????);        
            // 0x028E97C4: LDRB w9, [x24, #0x4e]      | W9 = X24 + 78;                          
            // 0x028E97C8: AND w8, w0, #1             | W8 = (X24 & 1);                         
            var val_2 = X24 & 1;
            // 0x028E97CC: TBZ w8, #0, #0x28e9868     | if (((X24 & 1) & 0x1) == 0) goto label_2;
            if((val_2 & 1) == 0)
            {
                goto label_2;
            }
            // 0x028E97D0: LDRH w8, [x24, #0x4c]      | W8 = X24 + 76;                          
            // 0x028E97D4: CMP w9, #5                 | STATE = COMPARE(X24 + 78, 0x5)          
            // 0x028E97D8: B.NE #0x28e987c            | if (X24 + 78 != 0x5) goto label_3;      
            if((X24 + 78) != 5)
            {
                goto label_3;
            }
            // 0x028E97DC: ORR w9, wzr, #0xffff       | W9 = 65535(0xFFFF);                     
            // 0x028E97E0: CMP w8, w9                 | STATE = COMPARE(X24 + 76, 0xFFFF)       
            // 0x028E97E4: B.EQ #0x28e9948            | if (X24 + 76 == 65535) goto label_7;    
            if((X24 + 76) == 65535)
            {
                goto label_7;
            }
            // 0x028E97E8: CBZ x25, #0x28e97f8        | if (X25 == 0) goto label_5;             
            if(X25 == 0)
            {
                goto label_5;
            }
            // 0x028E97EC: LDR x8, [x25]              | X8 = X25;                               
            // 0x028E97F0: LDRB w8, [x8, #0xed]       | W8 = X25 + 237;                         
            // 0x028E97F4: TBNZ w8, #0, #0x28e9948    | if ((X25 + 237 & 0x1) != 0) goto label_7;
            if(((X25 + 237) & 1) != 0)
            {
                goto label_7;
            }
            label_5:
            // 0x028E97F8: LDR x8, [x26, #0x18]       | 
            // 0x028E97FC: CBZ x8, #0x28e9948         | if (X25 + 237 == 0) goto label_7;       
            if((X25 + 237) == 0)
            {
                goto label_7;
            }
            // 0x028E9800: MOV x0, x24                | X0 = X24;//m1                           
            // 0x028E9804: BL #0x27c0990              | X0 = sub_27C0990( ?? X24, ????);        
            // 0x028E9808: MOV w26, w0                | W26 = X24;//m1                          
            // 0x028E980C: MOV x0, x24                | X0 = X24;//m1                           
            // 0x028E9810: BL #0x27c0a0c              | X0 = X24.get_pressedSprite();           
            UnityEngine.Sprite val_3 = X24.pressedSprite;
            // 0x028E9814: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_3, ????);      
            // 0x028E9818: TBZ w26, #0, #0x28e99bc    | if ((X24 & 0x1) == 0) goto label_8;     
            if((X24 & 1) == 0)
            {
                goto label_8;
            }
            // 0x028E981C: TBZ w0, #0, #0x28e9a74     | if ((val_3 & 0x1) == 0) goto label_9;   
            if((val_3 & 1) == 0)
            {
                goto label_9;
            }
            // 0x028E9820: LDR x8, [x25]              | X8 = X25;                               
            var val_30 = X25;
            // 0x028E9824: LDR x1, [x24, #0x18]       | X1 = X24 + 24;                          
            // 0x028E9828: LDRH w2, [x24, #0x4c]      | W2 = X24 + 76;                          
            // 0x028E982C: LDRH w9, [x8, #0x102]      | W9 = X25 + 258;                         
            // 0x028E9830: CBZ x9, #0x28e985c         | if (X25 + 258 == 0) goto label_10;      
            if((X25 + 258) == 0)
            {
                goto label_10;
            }
            // 0x028E9834: LDR x10, [x8, #0x98]       | X10 = X25 + 152;                        
            var val_22 = X25 + 152;
            // 0x028E9838: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_23 = 0;
            // 0x028E983C: ADD x10, x10, #8           | X10 = (X25 + 152 + 8);                  
            val_22 = val_22 + 8;
            label_12:
            // 0x028E9840: LDUR x12, [x10, #-8]       | X12 = (X25 + 152 + 8) + -8;             
            // 0x028E9844: CMP x12, x1                | STATE = COMPARE((X25 + 152 + 8) + -8, X24 + 24)
            // 0x028E9848: B.EQ #0x28e9ac4            | if ((X25 + 152 + 8) + -8 == X24 + 24) goto label_11;
            if(((X25 + 152 + 8) + -8) == (X24 + 24))
            {
                goto label_11;
            }
            // 0x028E984C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_23 = val_23 + 1;
            // 0x028E9850: ADD x10, x10, #0x10        | X10 = ((X25 + 152 + 8) + 16);           
            val_22 = val_22 + 16;
            // 0x028E9854: CMP x11, x9                | STATE = COMPARE((0 + 1), X25 + 258)     
            // 0x028E9858: B.LO #0x28e9840            | if (0 < X25 + 258) goto label_12;       
            if(val_23 < (X25 + 258))
            {
                goto label_12;
            }
            label_10:
            // 0x028E985C: MOV x0, x25                | X0 = X25;//m1                           
            val_24 = X25;
            // 0x028E9860: BL #0x2776c24              | X0 = sub_2776C24( ?? X25, ????);        
            // 0x028E9864: B #0x28e9ad4               |  goto label_13;                         
            goto label_13;
            label_2:
            // 0x028E9868: CMP w9, #5                 | STATE = COMPARE(X24 + 78, 0x5)          
            // 0x028E986C: B.NE #0x28e9908            | if (X24 + 78 != 0x5) goto label_14;     
            if((X24 + 78) != 5)
            {
                goto label_14;
            }
            // 0x028E9870: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028E9874: AND w5, w23, #1            | W5 = (W5 & 1);                          
            var val_4 = W5 & 1;
            // 0x028E9878: B #0x28e9950               |  goto label_15;                         
            goto label_15;
            label_3:
            // 0x028E987C: ORR w9, wzr, #0xffff       | W9 = 65535(0xFFFF);                     
            // 0x028E9880: CMP w8, w9                 | STATE = COMPARE(X24 + 76, 0xFFFF)       
            // 0x028E9884: B.EQ #0x28e9984            | if (X24 + 76 == 65535) goto label_19;   
            if((X24 + 76) == 65535)
            {
                goto label_19;
            }
            // 0x028E9888: CBZ x25, #0x28e9898        | if (X25 == 0) goto label_17;            
            if(X25 == 0)
            {
                goto label_17;
            }
            // 0x028E988C: LDR x8, [x25]              | X8 = X25;                               
            // 0x028E9890: LDRB w8, [x8, #0xed]       | W8 = X25 + 237;                         
            // 0x028E9894: TBNZ w8, #0, #0x28e9984    | if ((X25 + 237 & 0x1) != 0) goto label_19;
            if(((X25 + 237) & 1) != 0)
            {
                goto label_19;
            }
            label_17:
            // 0x028E9898: LDR x8, [x26, #0x18]       | 
            // 0x028E989C: CBZ x8, #0x28e9984         | if (X25 + 237 == 0) goto label_19;      
            if((X25 + 237) == 0)
            {
                goto label_19;
            }
            // 0x028E98A0: MOV x0, x24                | X0 = X24;//m1                           
            // 0x028E98A4: BL #0x27c0990              | X0 = sub_27C0990( ?? X24, ????);        
            // 0x028E98A8: MOV w25, w0                | W25 = X24;//m1                          
            // 0x028E98AC: MOV x0, x24                | X0 = X24;//m1                           
            // 0x028E98B0: BL #0x27c0a0c              | X0 = X24.get_pressedSprite();           
            UnityEngine.Sprite val_5 = X24.pressedSprite;
            // 0x028E98B4: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_5, ????);      
            // 0x028E98B8: TBZ w25, #0, #0x28e9a18    | if ((X24 & 0x1) == 0) goto label_20;    
            if((X24 & 1) == 0)
            {
                goto label_20;
            }
            // 0x028E98BC: TBZ w0, #0, #0x28e9a88     | if ((val_5 & 0x1) == 0) goto label_21;  
            if((val_5 & 1) == 0)
            {
                goto label_21;
            }
            // 0x028E98C0: LDR x8, [x22]              | X8 = typeof(ILRuntime.Runtime.Intepreter.ILIntepreter);
            // 0x028E98C4: LDR x1, [x24, #0x18]       | X1 = X24 + 24;                          
            // 0x028E98C8: LDRH w2, [x24, #0x4c]      | W2 = X24 + 76;                          
            // 0x028E98CC: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.Runtime.Intepreter.ILIntepreter.__il2cppRuntimeField_interface_offsets_count;
            // 0x028E98D0: CBZ x9, #0x28e98fc         | if (ILRuntime.Runtime.Intepreter.ILIntepreter.__il2cppRuntimeField_interface_offsets_count == 0) goto label_22;
            // 0x028E98D4: LDR x10, [x8, #0x98]       | X10 = ILRuntime.Runtime.Intepreter.ILIntepreter.__il2cppRuntimeField_interfaceOffsets;
            // 0x028E98D8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_24 = 0;
            // 0x028E98DC: ADD x10, x10, #8           | X10 = (ILRuntime.Runtime.Intepreter.ILIntepreter.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504825679880 (0x100000000D0B2008);
            label_24:
            // 0x028E98E0: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028E98E4: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X24 + 24)
            // 0x028E98E8: B.EQ #0x28e9b08            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X24 + 24) goto label_23;
            // 0x028E98EC: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_24 = val_24 + 1;
            // 0x028E98F0: ADD x10, x10, #0x10        | X10 = (1152921504825679880 + 16) = 1152921504825679896 (0x100000000D0B2018);
            // 0x028E98F4: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.Runtime.Intepreter.ILIntepreter.__il2cppRuntimeField_interface_offsets_count)
            // 0x028E98F8: B.LO #0x28e98e0            | if (0 < ILRuntime.Runtime.Intepreter.ILIntepreter.__il2cppRuntimeField_interface_offsets_count) goto label_24;
            label_22:
            // 0x028E98FC: MOV x0, x22                | X0 = intp;//m1                          
            val_25 = intp;
            // 0x028E9900: BL #0x2776c24              | X0 = sub_2776C24( ?? intp, ????);       
            // 0x028E9904: B #0x28e9b18               |  goto label_25;                         
            goto label_25;
            label_14:
            // 0x028E9908: LDR x8, [sp, #8]           | X8 = this;                              
            // 0x028E990C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028E9910: AND w6, w23, #1            | W6 = (W5 & 1);                          
            var val_6 = W5 & 1;
            // 0x028E9914: MOV x1, x25                | X1 = X25;//m1                           
            // 0x028E9918: MOV x2, x22                | X2 = intp;//m1                          
            // 0x028E991C: MOV x3, x21                | X3 = X2;//m1                            
            // 0x028E9920: MOV x4, x20                | X4 = X3;//m1                            
            // 0x028E9924: MOV x5, x19                | X5 = X4;//m1                            
            // 0x028E9928: MOV x7, x24                | X7 = X24;//m1                           
            // 0x028E992C: SUB sp, x29, #0x40         | SP = (1152921512875156752 - 64) = 1152921512875156688 (0x10000001ECD464D0);
            // 0x028E9930: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028E9934: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028E9938: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028E993C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028E9940: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028E9944: BR x8                      | X0 = this( ?? 0x0, ????);               
            label_7:
            // 0x028E9948: AND w5, w23, #1            | W5 = (W5 & 1);                          
            var val_7 = W5 & 1;
            // 0x028E994C: MOV x0, x25                | X0 = X25;//m1                           
            label_15:
            // 0x028E9950: LDR x7, [sp, #8]           | X7 = this;                              
            // 0x028E9954: MOV x1, x22                | X1 = intp;//m1                          
            // 0x028E9958: MOV x2, x21                | X2 = X2;//m1                            
            // 0x028E995C: MOV x3, x20                | X3 = X3;//m1                            
            // 0x028E9960: MOV x4, x19                | X4 = X4;//m1                            
            // 0x028E9964: MOV x6, x24                | X6 = X24;//m1                           
            label_42:
            // 0x028E9968: SUB sp, x29, #0x40         | SP = (1152921512875156752 - 64) = 1152921512875156688 (0x10000001ECD464D0);
            // 0x028E996C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028E9970: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028E9974: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028E9978: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028E997C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028E9980: BR x7                      | X0 = this( ?? X25, ????);               
            label_19:
            // 0x028E9984: LDR x6, [sp, #8]           | X6 = this;                              
            // 0x028E9988: AND w4, w23, #1            | W4 = (W5 & 1);                          
            var val_8 = W5 & 1;
            // 0x028E998C: MOV x0, x22                | X0 = intp;//m1                          
            // 0x028E9990: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028E9994: MOV x2, x20                | X2 = X3;//m1                            
            // 0x028E9998: MOV x3, x19                | X3 = X4;//m1                            
            // 0x028E999C: MOV x5, x24                | X5 = X24;//m1                           
            label_43:
            // 0x028E99A0: SUB sp, x29, #0x40         | SP = (1152921512875156752 - 64) = 1152921512875156688 (0x10000001ECD464D0);
            // 0x028E99A4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028E99A8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028E99AC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028E99B0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028E99B4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028E99B8: BR x6                      | X0 = this( ?? intp, ????);              
            label_8:
            // 0x028E99BC: LDRH w26, [x24, #0x4c]     | W26 = X24 + 76;                         
            // 0x028E99C0: TBZ w0, #0, #0x28e9a9c     | if ((val_3 & 0x1) == 0) goto label_26;  
            if((val_3 & 1) == 0)
            {
                goto label_26;
            }
            // 0x028E99C4: MOV x0, x24                | X0 = X24;//m1                           
            // 0x028E99C8: BL #0x27c0a0c              | X0 = X24.get_pressedSprite();           
            UnityEngine.Sprite val_9 = X24.pressedSprite;
            // 0x028E99CC: LDR x9, [x25]              | X9 = X25;                               
            // 0x028E99D0: MOV x8, x0                 | X8 = val_9;//m1                         
            // 0x028E99D4: LDRH w10, [x9, #0x102]     | W10 = X25 + 258;                        
            // 0x028E99D8: CBZ x10, #0x28e9a04        | if (X25 + 258 == 0) goto label_27;      
            if((X25 + 258) == 0)
            {
                goto label_27;
            }
            // 0x028E99DC: LDR x11, [x9, #0x98]       | X11 = X25 + 152;                        
            var val_25 = X25 + 152;
            // 0x028E99E0: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
            var val_26 = 0;
            // 0x028E99E4: ADD x11, x11, #8           | X11 = (X25 + 152 + 8);                  
            val_25 = val_25 + 8;
            label_29:
            // 0x028E99E8: LDUR x13, [x11, #-8]       | X13 = (X25 + 152 + 8) + -8;             
            // 0x028E99EC: CMP x13, x8                | STATE = COMPARE((X25 + 152 + 8) + -8, val_9)
            // 0x028E99F0: B.EQ #0x28e9b48            | if ((X25 + 152 + 8) + -8 == val_9) goto label_28;
            if(((X25 + 152 + 8) + -8) == val_9)
            {
                goto label_28;
            }
            // 0x028E99F4: ADD x12, x12, #1           | X12 = (0 + 1);                          
            val_26 = val_26 + 1;
            // 0x028E99F8: ADD x11, x11, #0x10        | X11 = ((X25 + 152 + 8) + 16);           
            val_25 = val_25 + 16;
            // 0x028E99FC: CMP x12, x10               | STATE = COMPARE((0 + 1), X25 + 258)     
            // 0x028E9A00: B.LO #0x28e99e8            | if (0 < X25 + 258) goto label_29;       
            if(val_26 < (X25 + 258))
            {
                goto label_29;
            }
            label_27:
            // 0x028E9A04: MOV x0, x25                | X0 = X25;//m1                           
            val_26 = X25;
            // 0x028E9A08: MOV x1, x8                 | X1 = val_9;//m1                         
            // 0x028E9A0C: MOV w2, w26                | W2 = X24 + 76;//m1                      
            // 0x028E9A10: BL #0x2776c24              | X0 = sub_2776C24( ?? X25, ????);        
            // 0x028E9A14: B #0x28e9b58               |  goto label_30;                         
            goto label_30;
            label_20:
            // 0x028E9A18: LDRH w25, [x24, #0x4c]     | W25 = X24 + 76;                         
            // 0x028E9A1C: TBZ w0, #0, #0x28e9ab0     | if ((val_5 & 0x1) == 0) goto label_31;  
            if((val_5 & 1) == 0)
            {
                goto label_31;
            }
            // 0x028E9A20: MOV x0, x24                | X0 = X24;//m1                           
            // 0x028E9A24: BL #0x27c0a0c              | X0 = X24.get_pressedSprite();           
            UnityEngine.Sprite val_10 = X24.pressedSprite;
            // 0x028E9A28: LDR x9, [x22]              | X9 = typeof(ILRuntime.Runtime.Intepreter.ILIntepreter);
            // 0x028E9A2C: MOV x8, x0                 | X8 = val_10;//m1                        
            // 0x028E9A30: LDRH w10, [x9, #0x102]     | W10 = ILRuntime.Runtime.Intepreter.ILIntepreter.__il2cppRuntimeField_interface_offsets_count;
            // 0x028E9A34: CBZ x10, #0x28e9a60        | if (ILRuntime.Runtime.Intepreter.ILIntepreter.__il2cppRuntimeField_interface_offsets_count == 0) goto label_32;
            // 0x028E9A38: LDR x11, [x9, #0x98]       | X11 = ILRuntime.Runtime.Intepreter.ILIntepreter.__il2cppRuntimeField_interfaceOffsets;
            // 0x028E9A3C: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
            var val_27 = 0;
            // 0x028E9A40: ADD x11, x11, #8           | X11 = (ILRuntime.Runtime.Intepreter.ILIntepreter.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504825679880 (0x100000000D0B2008);
            label_34:
            // 0x028E9A44: LDUR x13, [x11, #-8]       | X13 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028E9A48: CMP x13, x8                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, val_10)
            // 0x028E9A4C: B.EQ #0x28e9b78            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == val_10) goto label_33;
            // 0x028E9A50: ADD x12, x12, #1           | X12 = (0 + 1);                          
            val_27 = val_27 + 1;
            // 0x028E9A54: ADD x11, x11, #0x10        | X11 = (1152921504825679880 + 16) = 1152921504825679896 (0x100000000D0B2018);
            // 0x028E9A58: CMP x12, x10               | STATE = COMPARE((0 + 1), ILRuntime.Runtime.Intepreter.ILIntepreter.__il2cppRuntimeField_interface_offsets_count)
            // 0x028E9A5C: B.LO #0x28e9a44            | if (0 < ILRuntime.Runtime.Intepreter.ILIntepreter.__il2cppRuntimeField_interface_offsets_count) goto label_34;
            label_32:
            // 0x028E9A60: MOV x0, x22                | X0 = intp;//m1                          
            val_27 = intp;
            // 0x028E9A64: MOV x1, x8                 | X1 = val_10;//m1                        
            // 0x028E9A68: MOV w2, w25                | W2 = X24 + 76;//m1                      
            // 0x028E9A6C: BL #0x2776c24              | X0 = sub_2776C24( ?? intp, ????);       
            // 0x028E9A70: B #0x28e9b88               |  goto label_35;                         
            goto label_35;
            label_9:
            // 0x028E9A74: LDRH w8, [x24, #0x4c]      | W8 = X24 + 76;                          
            // 0x028E9A78: LDR x9, [x25]              | X9 = X25;                               
            // 0x028E9A7C: ADD x8, x9, x8, lsl #4     | X8 = (X25 + (X24 + 76) << 4);           
            var val_11 = X25 + ((X24 + 76) << 4);
            // 0x028E9A80: LDR x0, [x8, #0x118]       | X0 = (X25 + (X24 + 76) << 4) + 280;     
            val_28 = mem[(X25 + (X24 + 76) << 4) + 280];
            val_28 = (X25 + (X24 + 76) << 4) + 280;
            // 0x028E9A84: B #0x28e9ad8               |  goto label_36;                         
            goto label_36;
            label_21:
            // 0x028E9A88: LDRH w8, [x24, #0x4c]      | W8 = X24 + 76;                          
            // 0x028E9A8C: LDR x9, [x22]              | X9 = typeof(ILRuntime.Runtime.Intepreter.ILIntepreter);
            // 0x028E9A90: ADD x8, x9, x8, lsl #4     | X8 = (1152921504825643008 + (X24 + 76) << 4);
            ILRuntime.Runtime.Intepreter.ILIntepreter val_12 = 1152921504825643008 + ((X24 + 76) << 4);
            // 0x028E9A94: LDR x0, [x8, #0x118]       |  //  not_find_field!1:280
            val_29 = mem[(1152921504825643008 + (X24 + 76) << 4) + 280];
            // 0x028E9A98: B #0x28e9b1c               |  goto label_37;                         
            goto label_37;
            label_26:
            // 0x028E9A9C: LDR x8, [x25]              | X8 = X25;                               
            var val_28 = X25;
            // 0x028E9AA0: AND w5, w23, #1            | W5 = (W5 & 1);                          
            var val_13 = W5 & 1;
            // 0x028E9AA4: ADD x8, x8, w26, uxtw #4   | X8 = (X25 + X24 + 76);                  
            val_28 = val_28 + (X24 + 76);
            // 0x028E9AA8: LDP x7, x6, [x8, #0x110]   | X7 = (X25 + X24 + 76) + 272; X6 = (X25 + X24 + 76) + 272 + 8; //  | 
            // 0x028E9AAC: B #0x28e9b60               |  goto label_38;                         
            goto label_38;
            label_31:
            // 0x028E9AB0: LDR x8, [x22]              | X8 = typeof(ILRuntime.Runtime.Intepreter.ILIntepreter);
            // 0x028E9AB4: AND w4, w23, #1            | W4 = (W5 & 1);                          
            var val_14 = W5 & 1;
            // 0x028E9AB8: ADD x8, x8, w25, uxtw #4   | X8 = (1152921504825643008 + X24 + 76);  
            ILRuntime.Runtime.Intepreter.ILIntepreter val_15 = 1152921504825643008 + (X24 + 76);
            // 0x028E9ABC: LDP x6, x5, [x8, #0x110]   | X6 = addr_off(public System.Boolean System.Object::Equals(object obj));   //  |  not_find_field!1:280
            // 0x028E9AC0: B #0x28e9b90               |  goto label_39;                         
            goto label_39;
            label_11:
            // 0x028E9AC4: LDR w9, [x10]              | W9 = (X25 + 152 + 8);                   
            var val_29 = val_22;
            // 0x028E9AC8: ADD w9, w9, w2             | W9 = ((X25 + 152 + 8) + X24 + 76);      
            val_29 = val_29 + (X24 + 76);
            // 0x028E9ACC: ADD x8, x8, w9, uxtw #4    | X8 = (X25 + ((X25 + 152 + 8) + X24 + 76));
            val_30 = val_30 + val_29;
            // 0x028E9AD0: ADD x0, x8, #0x110         | X0 = ((X25 + ((X25 + 152 + 8) + X24 + 76)) + 272);
            val_24 = val_30 + 272;
            label_13:
            // 0x028E9AD4: LDR x0, [x0, #8]           | X0 = ((X25 + ((X25 + 152 + 8) + X24 + 76)) + 272) + 8;
            val_28 = mem[((X25 + ((X25 + 152 + 8) + X24 + 76)) + 272) + 8];
            val_28 = ((X25 + ((X25 + 152 + 8) + X24 + 76)) + 272) + 8;
            label_36:
            // 0x028E9AD8: MOV x1, x24                | X1 = X24;//m1                           
            // 0x028E9ADC: BL #0x2796ec8              | X0 = sub_2796EC8( ?? ((X25 + ((X25 + 152 + 8) + X24 + 76)) + 272) + 8, ????);
            // 0x028E9AE0: MOV x8, x0                 | X8 = ((X25 + ((X25 + 152 + 8) + X24 + 76)) + 272) + 8;//m1
            // 0x028E9AE4: LDR x7, [x8]               | X7 = ((X25 + ((X25 + 152 + 8) + X24 + 76)) + 272) + 8;
            // 0x028E9AE8: AND w5, w23, #1            | W5 = (W5 & 1);                          
            var val_16 = W5 & 1;
            // 0x028E9AEC: MOV x0, x25                | X0 = X25;//m1                           
            // 0x028E9AF0: MOV x1, x22                | X1 = intp;//m1                          
            // 0x028E9AF4: MOV x2, x21                | X2 = X2;//m1                            
            // 0x028E9AF8: MOV x3, x20                | X3 = X3;//m1                            
            // 0x028E9AFC: MOV x4, x19                | X4 = X4;//m1                            
            // 0x028E9B00: MOV x6, x8                 | X6 = ((X25 + ((X25 + 152 + 8) + X24 + 76)) + 272) + 8;//m1
            // 0x028E9B04: B #0x28e9968               |  goto label_42;                         
            goto label_42;
            label_23:
            // 0x028E9B08: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028E9B0C: ADD w9, w9, w2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X24 + 76);
            // 0x028E9B10: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504825643008 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X24 + 76));
            // 0x028E9B14: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504825643008 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X24 + 76)).272
            label_25:
            // 0x028E9B18: LDR x0, [x0, #8]           | 
            label_37:
            // 0x028E9B1C: MOV x1, x24                | X1 = X24;//m1                           
            // 0x028E9B20: BL #0x2796ec8              | X0 = sub_2796EC8( ?? val_5, ????);      
            // 0x028E9B24: MOV x8, x0                 | X8 = val_5;//m1                         
            // 0x028E9B28: LDR x6, [x8]               | X6 = typeof(UnityEngine.Sprite);        
            // 0x028E9B2C: AND w4, w23, #1            | W4 = (W5 & 1);                          
            var val_18 = W5 & 1;
            // 0x028E9B30: MOV x0, x22                | X0 = intp;//m1                          
            // 0x028E9B34: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028E9B38: MOV x2, x20                | X2 = X3;//m1                            
            // 0x028E9B3C: MOV x3, x19                | X3 = X4;//m1                            
            // 0x028E9B40: MOV x5, x8                 | X5 = val_5;//m1                         
            // 0x028E9B44: B #0x28e99a0               |  goto label_43;                         
            goto label_43;
            label_28:
            // 0x028E9B48: LDR w8, [x11]              | W8 = (X25 + 152 + 8);                   
            var val_31 = val_25;
            // 0x028E9B4C: ADD w8, w8, w26            | W8 = ((X25 + 152 + 8) + X24 + 76);      
            val_31 = val_31 + (X24 + 76);
            // 0x028E9B50: ADD x8, x9, w8, uxtw #4    | X8 = (X25 + ((X25 + 152 + 8) + X24 + 76));
            val_31 = X25 + val_31;
            // 0x028E9B54: ADD x0, x8, #0x110         | X0 = ((X25 + ((X25 + 152 + 8) + X24 + 76)) + 272);
            val_26 = val_31 + 272;
            label_30:
            // 0x028E9B58: LDP x7, x6, [x0]           | X7 = ((X25 + ((X25 + 152 + 8) + X24 + 76)) + 272); X6 = ((X25 + ((X25 + 152 + 8) + X24 + 76)) + 272) + 8; //  | 
            // 0x028E9B5C: AND w5, w23, #1            | W5 = (W5 & 1);                          
            var val_19 = W5 & 1;
            label_38:
            // 0x028E9B60: MOV x0, x25                | X0 = X25;//m1                           
            // 0x028E9B64: MOV x1, x22                | X1 = intp;//m1                          
            // 0x028E9B68: MOV x2, x21                | X2 = X2;//m1                            
            // 0x028E9B6C: MOV x3, x20                | X3 = X3;//m1                            
            // 0x028E9B70: MOV x4, x19                | X4 = X4;//m1                            
            // 0x028E9B74: B #0x28e9968               |  goto label_42;                         
            goto label_42;
            label_33:
            // 0x028E9B78: LDR w8, [x11]              | W8 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028E9B7C: ADD w8, w8, w25            | W8 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X24 + 76);
            // 0x028E9B80: ADD x8, x9, w8, uxtw #4    | X8 = (1152921504825643008 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X24 + 76));
            // 0x028E9B84: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504825643008 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X24 + 76)).272
            label_35:
            // 0x028E9B88: LDP x6, x5, [x0]           | X6 = typeof(UnityEngine.Sprite);         //  | 
            // 0x028E9B8C: AND w4, w23, #1            | W4 = (W5 & 1);                          
            var val_21 = W5 & 1;
            label_39:
            // 0x028E9B90: MOV x0, x22                | X0 = intp;//m1                          
            // 0x028E9B94: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028E9B98: MOV x2, x20                | X2 = X3;//m1                            
            // 0x028E9B9C: MOV x3, x19                | X3 = X4;//m1                            
            // 0x028E9BA0: B #0x28e99a0               |  goto label_43;                         
            goto label_43;
        
        }
        //
        // Offset in libil2cpp.so: 0x028E9BA4 (42900388), len: 196  VirtAddr: 0x028E9BA4 RVA: 0x028E9BA4 token: 100680186 methodIndex: 29553 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual System.IAsyncResult BeginInvoke(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj, System.AsyncCallback callback, object object)
        {
            //
            // Disasemble & Code
            // 0x028E9BA4: STP x26, x25, [sp, #-0x50]! | stack[1152921512875321936] = ???;  stack[1152921512875321944] = ???;  //  dest_result_addr=1152921512875321936 |  dest_result_addr=1152921512875321944
            // 0x028E9BA8: STP x24, x23, [sp, #0x10]  | stack[1152921512875321952] = ???;  stack[1152921512875321960] = ???;  //  dest_result_addr=1152921512875321952 |  dest_result_addr=1152921512875321960
            // 0x028E9BAC: STP x22, x21, [sp, #0x20]  | stack[1152921512875321968] = ???;  stack[1152921512875321976] = ???;  //  dest_result_addr=1152921512875321968 |  dest_result_addr=1152921512875321976
            // 0x028E9BB0: STP x20, x19, [sp, #0x30]  | stack[1152921512875321984] = ???;  stack[1152921512875321992] = ???;  //  dest_result_addr=1152921512875321984 |  dest_result_addr=1152921512875321992
            // 0x028E9BB4: STP x29, x30, [sp, #0x40]  | stack[1152921512875322000] = ???;  stack[1152921512875322008] = ???;  //  dest_result_addr=1152921512875322000 |  dest_result_addr=1152921512875322008
            // 0x028E9BB8: ADD x29, sp, #0x40         | X29 = (1152921512875321936 + 64) = 1152921512875322000 (0x10000001ECD6EA90);
            // 0x028E9BBC: SUB sp, sp, #0x40          | SP = (1152921512875321936 - 64) = 1152921512875321872 (0x10000001ECD6EA10);
            // 0x028E9BC0: ADRP x26, #0x37b8000       | X26 = 58425344 (0x37B8000);             
            // 0x028E9BC4: LDRB w8, [x26, #0x9fa]     | W8 = (bool)static_value_037B89FA;       
            // 0x028E9BC8: MOV x19, x7                | X19 = X7;//m1                           
            // 0x028E9BCC: MOV x20, x6                | X20 = X6;//m1                           
            // 0x028E9BD0: MOV x22, x4                | X22 = X4;//m1                           
            // 0x028E9BD4: MOV x23, x3                | X23 = X3;//m1                           
            // 0x028E9BD8: MOV x24, x2                | X24 = X2;//m1                           
            // 0x028E9BDC: MOV x25, x1                | X25 = intp;//m1                         
            // 0x028E9BE0: MOV x21, x0                | X21 = 1152921512875334016 (0x10000001ECD71980);//ML01
            // 0x028E9BE4: AND w9, w5, #1             | W9 = (W5 & 1);                          
            bool val_1 = W5 & 1;
            // 0x028E9BE8: STRB w9, [sp, #0x3f]       | stack[1152921512875321935] = (W5 & 1);   //  dest_result_addr=1152921512875321935
            // 0x028E9BEC: TBNZ w8, #0, #0x28e9c08    | if (static_value_037B89FA == true) goto label_0;
            // 0x028E9BF0: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x028E9BF4: LDR x8, [x8, #0x6d8]       | X8 = 0x2B90CB0;                         
            // 0x028E9BF8: LDR w0, [x8]               | W0 = 0x19F0;                            
            // 0x028E9BFC: BL #0x2782188              | X0 = sub_2782188( ?? 0x19F0, ????);     
            // 0x028E9C00: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028E9C04: STRB w8, [x26, #0x9fa]     | static_value_037B89FA = true;            //  dest_result_addr=58427898
            label_0:
            // 0x028E9C08: STP xzr, xzr, [sp, #0x28]  | stack[1152921512875321912] = 0x0;  stack[1152921512875321920] = 0x0;  //  dest_result_addr=1152921512875321912 |  dest_result_addr=1152921512875321920
            // 0x028E9C0C: STP xzr, xzr, [sp, #0x18]  | stack[1152921512875321896] = 0x0;  stack[1152921512875321904] = 0x0;  //  dest_result_addr=1152921512875321896 |  dest_result_addr=1152921512875321904
            // 0x028E9C10: STP xzr, xzr, [sp, #8]     | stack[1152921512875321880] = 0x0;  stack[1152921512875321888] = 0x0;  //  dest_result_addr=1152921512875321880 |  dest_result_addr=1152921512875321888
            // 0x028E9C14: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x028E9C18: STR x25, [sp, #8]          | stack[1152921512875321880] = intp;       //  dest_result_addr=1152921512875321880
            // 0x028E9C1C: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
            // 0x028E9C20: ADD x1, sp, #0x3f          | X1 = (1152921512875321872 + 63) = 1152921512875321935 (0x10000001ECD6EA4F);
            // 0x028E9C24: LDR x0, [x8]               | X0 = typeof(System.Boolean);            
            // 0x028E9C28: STP x24, x23, [sp, #0x10]  | stack[1152921512875321888] = X2;  stack[1152921512875321896] = X3;  //  dest_result_addr=1152921512875321888 |  dest_result_addr=1152921512875321896
            // 0x028E9C2C: STR x22, [sp, #0x20]       | stack[1152921512875321904] = X4;         //  dest_result_addr=1152921512875321904
            // 0x028E9C30: BL #0x27bc028              | X0 = 1152921512875386496 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Boolean), (W5 & 1));
            // 0x028E9C34: STR x0, [sp, #0x28]        | stack[1152921512875321912] = (W5 & 1); stack[1152921512875321913] = 0x10000001ECD7E6;  //  dest_result_addr=1152921512875321912 dest_result_addr=1152921512875321913
            // 0x028E9C38: ADD x1, sp, #8             | X1 = (1152921512875321872 + 8) = 1152921512875321880 (0x10000001ECD6EA18);
            // 0x028E9C3C: MOV x0, x21                | X0 = 1152921512875334016 (0x10000001ECD71980);//ML01
            // 0x028E9C40: MOV x2, x20                | X2 = X6;//m1                            
            // 0x028E9C44: MOV x3, x19                | X3 = X7;//m1                            
            // 0x028E9C48: BL #0x278fb00              | X0 = sub_278FB00( ?? this, ????);       
            // 0x028E9C4C: SUB sp, x29, #0x40         | SP = (1152921512875322000 - 64) = 1152921512875321936 (0x10000001ECD6EA50);
            // 0x028E9C50: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028E9C54: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028E9C58: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028E9C5C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028E9C60: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028E9C64: RET                        |  return (System.IAsyncResult)this;      
            return (System.IAsyncResult)this;
            //  |  // // {name=val_0, type=System.IAsyncResult, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028E9C68 (42900584), len: 16  VirtAddr: 0x028E9C68 RVA: 0x028E9C68 token: 100680187 methodIndex: 29554 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual ILRuntime.Runtime.Stack.StackObject* EndInvoke(System.IAsyncResult result)
        {
            //
            // Disasemble & Code
            // 0x028E9C68: MOV x8, x1                 | X8 = result;//m1                        
            // 0x028E9C6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028E9C70: MOV x0, x8                 | X0 = result;//m1                        
            // 0x028E9C74: B #0x278fde8               | X0 = sub_278FDE8( ?? result, ????);     
        
        }
    
    }

}
