using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class CameraHelper_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache4; // static_offset: 0x00000020
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache5; // static_offset: 0x00000028
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache6; // static_offset: 0x00000030
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache7; // static_offset: 0x00000038
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache8; // static_offset: 0x00000040
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache9; // static_offset: 0x00000048
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheA; // static_offset: 0x00000050
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheB; // static_offset: 0x00000058
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheC; // static_offset: 0x00000060
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheD; // static_offset: 0x00000068
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheE; // static_offset: 0x00000070
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheF; // static_offset: 0x00000078
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache10; // static_offset: 0x00000080
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache11; // static_offset: 0x00000088
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache12; // static_offset: 0x00000090
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache13; // static_offset: 0x00000098
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache14; // static_offset: 0x000000A0
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache15; // static_offset: 0x000000A8
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache16; // static_offset: 0x000000B0
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache17; // static_offset: 0x000000B8
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache18; // static_offset: 0x000000C0
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache19; // static_offset: 0x000000C8
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache1A; // static_offset: 0x000000D0
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x0142EC3C (21163068), len: 8  VirtAddr: 0x0142EC3C RVA: 0x0142EC3C token: 100664137 methodIndex: 30184 delegateWrapperIndex: 0 methodInvoker: 0
        public CameraHelper_Binding()
        {
            //
            // Disasemble & Code
            // 0x0142EC3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142EC40: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0142EC44 (21163076), len: 8152  VirtAddr: 0x0142EC44 RVA: 0x0142EC44 token: 100664138 methodIndex: 30185 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            var val_74;
            //  | 
            System.Reflection.FieldInfo val_75;
            //  | 
            var val_76;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_77;
            //  | 
            var val_78;
            //  | 
            var val_79;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_80;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_81;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_82;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_83;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_84;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_85;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_86;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_87;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_88;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_89;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_90;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_91;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_92;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_93;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_94;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_95;
            // 0x0142EC44: STP x28, x27, [sp, #-0x60]! | stack[1152921510108601392] = ???;  stack[1152921510108601400] = ???;  //  dest_result_addr=1152921510108601392 |  dest_result_addr=1152921510108601400
            // 0x0142EC48: STP x26, x25, [sp, #0x10]  | stack[1152921510108601408] = ???;  stack[1152921510108601416] = ???;  //  dest_result_addr=1152921510108601408 |  dest_result_addr=1152921510108601416
            // 0x0142EC4C: STP x24, x23, [sp, #0x20]  | stack[1152921510108601424] = ???;  stack[1152921510108601432] = ???;  //  dest_result_addr=1152921510108601424 |  dest_result_addr=1152921510108601432
            // 0x0142EC50: STP x22, x21, [sp, #0x30]  | stack[1152921510108601440] = ???;  stack[1152921510108601448] = ???;  //  dest_result_addr=1152921510108601440 |  dest_result_addr=1152921510108601448
            // 0x0142EC54: STP x20, x19, [sp, #0x40]  | stack[1152921510108601456] = ???;  stack[1152921510108601464] = ???;  //  dest_result_addr=1152921510108601456 |  dest_result_addr=1152921510108601464
            // 0x0142EC58: STP x29, x30, [sp, #0x50]  | stack[1152921510108601472] = ???;  stack[1152921510108601480] = ???;  //  dest_result_addr=1152921510108601472 |  dest_result_addr=1152921510108601480
            // 0x0142EC5C: ADD x29, sp, #0x50         | X29 = (1152921510108601392 + 80) = 1152921510108601472 (0x1000000147EE1C80);
            // 0x0142EC60: SUB sp, sp, #0x10          | SP = (1152921510108601392 - 16) = 1152921510108601376 (0x1000000147EE1C20);
            // 0x0142EC64: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0142EC68: LDRB w8, [x20, #0x29]      | W8 = (bool)static_value_03737029;       
            // 0x0142EC6C: MOV x19, x1                | X19 = X1;//m1                           
            val_74 = X1;
            // 0x0142EC70: TBNZ w8, #0, #0x142ec8c    | if (static_value_03737029 == true) goto label_0;
            // 0x0142EC74: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x0142EC78: LDR x8, [x8, #0x530]       | X8 = 0x2B901C0;                         
            // 0x0142EC7C: LDR w0, [x8]               | W0 = 0x1734;                            
            // 0x0142EC80: BL #0x2782188              | X0 = sub_2782188( ?? 0x1734, ????);     
            // 0x0142EC84: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142EC88: STRB w8, [x20, #0x29]      | static_value_03737029 = true;            //  dest_result_addr=57897001
            label_0:
            // 0x0142EC8C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142EC90: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142EC94: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x0142EC98: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x0142EC9C: LDR x8, [x8, #0x328]       | X8 = 1152921504887730176;               
            // 0x0142ECA0: LDR x20, [x8]              | X20 = typeof(CameraHelper);             
            // 0x0142ECA4: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142ECA8: TBZ w8, #0, #0x142ecb8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0142ECAC: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142ECB0: CBNZ w8, #0x142ecb8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0142ECB4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x0142ECB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142ECBC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142ECC0: MOV x1, x20                | X1 = 1152921504887730176 (0x1000000010BDF000);//ML01
            // 0x0142ECC4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142ECC8: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x0142ECCC: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x0142ECD0: MOV x20, x0                | X20 = val_1;//m1                        
            val_75 = val_1;
            // 0x0142ECD4: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
            // 0x0142ECD8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142ECDC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142ECE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142ECE4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142ECE8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142ECEC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142ECF0: CBNZ x20, #0x142ecf8       | if (val_1 != null) goto label_3;        
            if(val_75 != null)
            {
                goto label_3;
            }
            // 0x0142ECF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_3:
            // 0x0142ECF8: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
            // 0x0142ECFC: LDR x8, [x8, #0xd8]        | X8 = (string**)(1152921510108375536)("get_csf");
            // 0x0142ED00: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142ED04: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142ED08: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142ED0C: LDR x1, [x8]               | X1 = "get_csf";                         
            // 0x0142ED10: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0142ED14: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142ED18: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142ED1C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_csf", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_2 = val_75.GetMethod(name:  "get_csf", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0142ED20: ADRP x24, #0x3642000       | X24 = 56893440 (0x3642000);             
            // 0x0142ED24: LDR x24, [x24, #0xba0]     | X24 = 1152921504783630336;              
            val_76 = 1152921504783630336;
            // 0x0142ED28: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x0142ED2C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142ED30: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142ED34: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache0;
            // 0x0142ED38: CBNZ x22, #0x142ed84       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache0 != null) goto label_4;
            if((ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache0) != null)
            {
                goto label_4;
            }
            // 0x0142ED3C: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
            // 0x0142ED40: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142ED44: LDR x8, [x8, #0x600]       | X8 = 1152921510108379728;               
            // 0x0142ED48: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142ED4C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::get_csf_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142ED50: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_3 = null;
            // 0x0142ED54: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142ED58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142ED5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142ED60: MOV x2, x22                | X2 = 1152921510108379728 (0x1000000147EABA50);//ML01
            // 0x0142ED64: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142ED68: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::get_csf_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_3 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::get_csf_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142ED6C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142ED70: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142ED74: STR x23, [x8]              | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783634432
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache0 = val_3;
            // 0x0142ED78: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142ED7C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142ED80: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_4:
            // 0x0142ED84: CBNZ x19, #0x142ed8c       | if (X1 != 0) goto label_5;              
            if(val_74 != 0)
            {
                goto label_5;
            }
            // 0x0142ED88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::get_csf_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_5:
            // 0x0142ED8C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142ED90: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142ED94: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x0142ED98: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142ED9C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_2, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache0);
            val_74.RegisterCLRMethodRedirection(mi:  val_2, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache0);
            // 0x0142EDA0: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x0142EDA4: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x0142EDA8: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
            // 0x0142EDAC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142EDB0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142EDB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142EDB8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142EDBC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142EDC0: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142EDC4: CBNZ x20, #0x142edcc       | if (val_1 != null) goto label_6;        
            if(val_75 != null)
            {
                goto label_6;
            }
            // 0x0142EDC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_6:
            // 0x0142EDCC: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x0142EDD0: LDR x8, [x8, #0x618]       | X8 = (string**)(1152921510108380752)("get_inScaler");
            // 0x0142EDD4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142EDD8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142EDDC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142EDE0: LDR x1, [x8]               | X1 = "get_inScaler";                    
            // 0x0142EDE4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0142EDE8: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142EDEC: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142EDF0: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_inScaler", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_4 = val_75.GetMethod(name:  "get_inScaler", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0142EDF4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142EDF8: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x0142EDFC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142EE00: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache1;
            // 0x0142EE04: CBNZ x22, #0x142ee50       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache1 != null) goto label_7;
            if((ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache1) != null)
            {
                goto label_7;
            }
            // 0x0142EE08: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x0142EE0C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142EE10: LDR x8, [x8, #0xa98]       | X8 = 1152921510108384944;               
            // 0x0142EE14: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142EE18: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::get_inScaler_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142EE1C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_5 = null;
            // 0x0142EE20: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142EE24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142EE28: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142EE2C: MOV x2, x22                | X2 = 1152921510108384944 (0x1000000147EACEB0);//ML01
            // 0x0142EE30: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142EE34: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::get_inScaler_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_5 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::get_inScaler_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142EE38: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142EE3C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142EE40: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783634440
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache1 = val_5;
            // 0x0142EE44: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142EE48: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142EE4C: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_7:
            // 0x0142EE50: CBNZ x19, #0x142ee58       | if (X1 != 0) goto label_8;              
            if(val_74 != 0)
            {
                goto label_8;
            }
            // 0x0142EE54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::get_inScaler_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_8:
            // 0x0142EE58: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142EE5C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142EE60: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x0142EE64: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142EE68: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_4, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache1);
            val_74.RegisterCLRMethodRedirection(mi:  val_4, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache1);
            // 0x0142EE6C: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x0142EE70: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x0142EE74: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
            // 0x0142EE78: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142EE7C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142EE80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142EE84: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142EE88: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142EE8C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142EE90: CBNZ x20, #0x142ee98       | if (val_1 != null) goto label_9;        
            if(val_75 != null)
            {
                goto label_9;
            }
            // 0x0142EE94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_9:
            // 0x0142EE98: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
            // 0x0142EE9C: LDR x8, [x8, #0xc58]       | X8 = (string**)(1152921510108385968)("ScalerClear");
            // 0x0142EEA0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142EEA4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142EEA8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142EEAC: LDR x1, [x8]               | X1 = "ScalerClear";                     
            // 0x0142EEB0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0142EEB4: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142EEB8: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142EEBC: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "ScalerClear", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_6 = val_75.GetMethod(name:  "ScalerClear", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0142EEC0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142EEC4: MOV x21, x0                | X21 = val_6;//m1                        
            // 0x0142EEC8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142EECC: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache2;
            // 0x0142EED0: CBNZ x22, #0x142ef1c       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache2 != null) goto label_10;
            if((ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache2) != null)
            {
                goto label_10;
            }
            // 0x0142EED4: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
            // 0x0142EED8: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142EEDC: LDR x8, [x8, #0xfd8]       | X8 = 1152921510108390160;               
            // 0x0142EEE0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142EEE4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::ScalerClear_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142EEE8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_7 = null;
            // 0x0142EEEC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142EEF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142EEF4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142EEF8: MOV x2, x22                | X2 = 1152921510108390160 (0x1000000147EAE310);//ML01
            // 0x0142EEFC: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142EF00: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::ScalerClear_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_7 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::ScalerClear_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142EF04: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142EF08: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142EF0C: STR x23, [x8, #0x10]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783634448
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache2 = val_7;
            // 0x0142EF10: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142EF14: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142EF18: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_10:
            // 0x0142EF1C: CBNZ x19, #0x142ef24       | if (X1 != 0) goto label_11;             
            if(val_74 != 0)
            {
                goto label_11;
            }
            // 0x0142EF20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::ScalerClear_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_11:
            // 0x0142EF24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142EF28: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142EF2C: MOV x1, x21                | X1 = val_6;//m1                         
            // 0x0142EF30: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142EF34: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_6, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache2);
            val_74.RegisterCLRMethodRedirection(mi:  val_6, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache2);
            // 0x0142EF38: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x0142EF3C: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x0142EF40: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
            // 0x0142EF44: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142EF48: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142EF4C: MOVZ w1, #0x5              | W1 = 5 (0x5);//ML01                     
            // 0x0142EF50: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142EF54: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142EF58: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142EF5C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142EF60: ADRP x9, #0x3630000        | X9 = 56819712 (0x3630000);              
            // 0x0142EF64: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142EF68: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142EF6C: LDR x9, [x9, #0x8b8]       | X9 = 1152921504698060800;               
            // 0x0142EF70: LDR x22, [x9]              | X22 = typeof(UnityEngine.Transform);    
            // 0x0142EF74: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142EF78: TBZ w9, #0, #0x142ef8c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x0142EF7C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142EF80: CBNZ w9, #0x142ef8c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x0142EF84: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142EF88: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_13:
            // 0x0142EF8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142EF90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142EF94: MOV x1, x22                | X1 = 1152921504698060800 (0x10000000056FD000);//ML01
            // 0x0142EF98: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142EF9C: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x0142EFA0: CBNZ x21, #0x142efa8       | if ( != null) goto label_14;            
            if(null != null)
            {
                goto label_14;
            }
            // 0x0142EFA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_14:
            // 0x0142EFA8: CBZ x22, #0x142efcc        | if (val_8 == null) goto label_16;       
            if(val_8 == null)
            {
                goto label_16;
            }
            // 0x0142EFAC: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142EFB0: MOV x0, x22                | X0 = val_8;//m1                         
            // 0x0142EFB4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142EFB8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_8, ????);      
            // 0x0142EFBC: CBNZ x0, #0x142efcc        | if (val_8 != null) goto label_16;       
            if(val_8 != null)
            {
                goto label_16;
            }
            // 0x0142EFC0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_8, ????);      
            // 0x0142EFC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142EFC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            label_16:
            // 0x0142EFCC: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142EFD0: CBNZ w8, #0x142efe0        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_17;
            // 0x0142EFD4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_8, ????);      
            // 0x0142EFD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142EFDC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            label_17:
            // 0x0142EFE0: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_8;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_8;
            // 0x0142EFE4: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x0142EFE8: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x0142EFEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142EFF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142EFF4: LDR x1, [x8]               | X1 = typeof(System.Single);             
            // 0x0142EFF8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142EFFC: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x0142F000: CBZ x22, #0x142f024        | if (val_9 == null) goto label_19;       
            if(val_9 == null)
            {
                goto label_19;
            }
            // 0x0142F004: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142F008: MOV x0, x22                | X0 = val_9;//m1                         
            // 0x0142F00C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142F010: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x0142F014: CBNZ x0, #0x142f024        | if (val_9 != null) goto label_19;       
            if(val_9 != null)
            {
                goto label_19;
            }
            // 0x0142F018: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_9, ????);      
            // 0x0142F01C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F020: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_19:
            // 0x0142F024: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142F028: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x0142F02C: B.HI #0x142f03c            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_20;
            // 0x0142F030: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_9, ????);      
            // 0x0142F034: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F038: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_20:
            // 0x0142F03C: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_9;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_9;
            // 0x0142F040: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x0142F044: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x0142F048: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142F04C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142F050: LDR x1, [x8]               | X1 = typeof(System.Single);             
            // 0x0142F054: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142F058: MOV x22, x0                | X22 = val_10;//m1                       
            // 0x0142F05C: CBZ x22, #0x142f080        | if (val_10 == null) goto label_22;      
            if(val_10 == null)
            {
                goto label_22;
            }
            // 0x0142F060: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142F064: MOV x0, x22                | X0 = val_10;//m1                        
            // 0x0142F068: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142F06C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_10, ????);     
            // 0x0142F070: CBNZ x0, #0x142f080        | if (val_10 != null) goto label_22;      
            if(val_10 != null)
            {
                goto label_22;
            }
            // 0x0142F074: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_10, ????);     
            // 0x0142F078: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F07C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_22:
            // 0x0142F080: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142F084: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x0142F088: B.HI #0x142f098            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_23;
            // 0x0142F08C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_10, ????);     
            // 0x0142F090: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F094: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_23:
            // 0x0142F098: STR x22, [x21, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_10;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_10;
            // 0x0142F09C: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x0142F0A0: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x0142F0A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142F0A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142F0AC: LDR x1, [x8]               | X1 = typeof(System.Single);             
            // 0x0142F0B0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_11 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142F0B4: MOV x22, x0                | X22 = val_11;//m1                       
            // 0x0142F0B8: CBZ x22, #0x142f0dc        | if (val_11 == null) goto label_25;      
            if(val_11 == null)
            {
                goto label_25;
            }
            // 0x0142F0BC: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142F0C0: MOV x0, x22                | X0 = val_11;//m1                        
            // 0x0142F0C4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142F0C8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_11, ????);     
            // 0x0142F0CC: CBNZ x0, #0x142f0dc        | if (val_11 != null) goto label_25;      
            if(val_11 != null)
            {
                goto label_25;
            }
            // 0x0142F0D0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_11, ????);     
            // 0x0142F0D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F0D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            label_25:
            // 0x0142F0DC: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142F0E0: CMP w8, #3                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x0142F0E4: B.HI #0x142f0f4            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x3) goto label_26;
            // 0x0142F0E8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_11, ????);     
            // 0x0142F0EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F0F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            label_26:
            // 0x0142F0F4: STR x22, [x21, #0x38]      | typeof(System.Type[]).__il2cppRuntimeField_38 = val_11;  //  dest_result_addr=1152921504987155112
            typeof(System.Type[]).__il2cppRuntimeField_38 = val_11;
            // 0x0142F0F8: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
            // 0x0142F0FC: LDR x8, [x8, #0xef0]       | X8 = 1152921504695078912;               
            // 0x0142F100: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142F104: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142F108: LDR x1, [x8]               | X1 = typeof(UnityEngine.Vector3);       
            // 0x0142F10C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_12 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142F110: MOV x22, x0                | X22 = val_12;//m1                       
            // 0x0142F114: CBZ x22, #0x142f138        | if (val_12 == null) goto label_28;      
            if(val_12 == null)
            {
                goto label_28;
            }
            // 0x0142F118: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142F11C: MOV x0, x22                | X0 = val_12;//m1                        
            // 0x0142F120: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142F124: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_12, ????);     
            // 0x0142F128: CBNZ x0, #0x142f138        | if (val_12 != null) goto label_28;      
            if(val_12 != null)
            {
                goto label_28;
            }
            // 0x0142F12C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_12, ????);     
            // 0x0142F130: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F134: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            label_28:
            // 0x0142F138: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142F13C: CMP w8, #4                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x4)
            // 0x0142F140: B.HI #0x142f150            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x4) goto label_29;
            // 0x0142F144: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_12, ????);     
            // 0x0142F148: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F14C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            label_29:
            // 0x0142F150: STR x22, [x21, #0x40]      | typeof(System.Type[]).__il2cppRuntimeField_40 = val_12;  //  dest_result_addr=1152921504987155120
            typeof(System.Type[]).__il2cppRuntimeField_40 = val_12;
            // 0x0142F154: CBNZ x20, #0x142f15c       | if (val_1 != null) goto label_30;       
            if(val_75 != null)
            {
                goto label_30;
            }
            // 0x0142F158: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_30:
            // 0x0142F15C: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
            // 0x0142F160: LDR x8, [x8, #0x2f8]       | X8 = (string**)(1152921510108411664)("Scaler");
            // 0x0142F164: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142F168: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142F16C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142F170: LDR x1, [x8]               | X1 = "Scaler";                          
            // 0x0142F174: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0142F178: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F17C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142F180: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Scaler", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_13 = val_75.GetMethod(name:  "Scaler", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0142F184: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142F188: MOV x21, x0                | X21 = val_13;//m1                       
            // 0x0142F18C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142F190: LDR x22, [x8, #0x18]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache3;
            // 0x0142F194: CBNZ x22, #0x142f1e0       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache3 != null) goto label_31;
            if((ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache3) != null)
            {
                goto label_31;
            }
            // 0x0142F198: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
            // 0x0142F19C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142F1A0: LDR x8, [x8, #0xb60]       | X8 = 1152921510108415840;               
            // 0x0142F1A4: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142F1A8: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::Scaler_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142F1AC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_14 = null;
            // 0x0142F1B0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142F1B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F1B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142F1BC: MOV x2, x22                | X2 = 1152921510108415840 (0x1000000147EB4760);//ML01
            // 0x0142F1C0: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142F1C4: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::Scaler_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_14 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::Scaler_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142F1C8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142F1CC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142F1D0: STR x23, [x8, #0x18]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783634456
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache3 = val_14;
            // 0x0142F1D4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142F1D8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142F1DC: LDR x22, [x8, #0x18]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_31:
            // 0x0142F1E0: CBNZ x19, #0x142f1e8       | if (X1 != 0) goto label_32;             
            if(val_74 != 0)
            {
                goto label_32;
            }
            // 0x0142F1E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::Scaler_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_32:
            // 0x0142F1E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142F1EC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142F1F0: MOV x1, x21                | X1 = val_13;//m1                        
            // 0x0142F1F4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142F1F8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_13, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache3);
            val_74.RegisterCLRMethodRedirection(mi:  val_13, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache3);
            // 0x0142F1FC: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x0142F200: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x0142F204: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
            // 0x0142F208: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F20C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142F210: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x0142F214: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F218: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142F21C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142F220: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142F224: ADRP x9, #0x3630000        | X9 = 56819712 (0x3630000);              
            // 0x0142F228: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F22C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142F230: LDR x9, [x9, #0x8b8]       | X9 = 1152921504698060800;               
            // 0x0142F234: LDR x22, [x9]              | X22 = typeof(UnityEngine.Transform);    
            // 0x0142F238: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142F23C: TBZ w9, #0, #0x142f250     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_34;
            // 0x0142F240: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142F244: CBNZ w9, #0x142f250        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
            // 0x0142F248: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142F24C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_34:
            // 0x0142F250: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142F254: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142F258: MOV x1, x22                | X1 = 1152921504698060800 (0x10000000056FD000);//ML01
            // 0x0142F25C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_15 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142F260: MOV x22, x0                | X22 = val_15;//m1                       
            // 0x0142F264: CBNZ x21, #0x142f26c       | if ( != null) goto label_35;            
            if(null != null)
            {
                goto label_35;
            }
            // 0x0142F268: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_35:
            // 0x0142F26C: CBZ x22, #0x142f290        | if (val_15 == null) goto label_37;      
            if(val_15 == null)
            {
                goto label_37;
            }
            // 0x0142F270: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142F274: MOV x0, x22                | X0 = val_15;//m1                        
            // 0x0142F278: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142F27C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_15, ????);     
            // 0x0142F280: CBNZ x0, #0x142f290        | if (val_15 != null) goto label_37;      
            if(val_15 != null)
            {
                goto label_37;
            }
            // 0x0142F284: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_15, ????);     
            // 0x0142F288: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F28C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_37:
            // 0x0142F290: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142F294: CBNZ w8, #0x142f2a4        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_38;
            // 0x0142F298: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_15, ????);     
            // 0x0142F29C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F2A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_38:
            // 0x0142F2A4: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_15;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_15;
            // 0x0142F2A8: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x0142F2AC: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x0142F2B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142F2B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142F2B8: LDR x1, [x8]               | X1 = typeof(System.Single);             
            // 0x0142F2BC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_16 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142F2C0: MOV x22, x0                | X22 = val_16;//m1                       
            // 0x0142F2C4: CBZ x22, #0x142f2e8        | if (val_16 == null) goto label_40;      
            if(val_16 == null)
            {
                goto label_40;
            }
            // 0x0142F2C8: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142F2CC: MOV x0, x22                | X0 = val_16;//m1                        
            // 0x0142F2D0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142F2D4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_16, ????);     
            // 0x0142F2D8: CBNZ x0, #0x142f2e8        | if (val_16 != null) goto label_40;      
            if(val_16 != null)
            {
                goto label_40;
            }
            // 0x0142F2DC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_16, ????);     
            // 0x0142F2E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F2E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            label_40:
            // 0x0142F2E8: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142F2EC: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x0142F2F0: B.HI #0x142f300            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_41;
            // 0x0142F2F4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_16, ????);     
            // 0x0142F2F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F2FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            label_41:
            // 0x0142F300: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_16;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_16;
            // 0x0142F304: CBNZ x20, #0x142f30c       | if (val_1 != null) goto label_42;       
            if(val_75 != null)
            {
                goto label_42;
            }
            // 0x0142F308: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_42:
            // 0x0142F30C: ADRP x28, #0x366d000       | X28 = 57069568 (0x366D000);             
            // 0x0142F310: LDR x28, [x28, #0x3a0]     | X28 = (string**)(1152921510108425056)("MotionBlur");
            // 0x0142F314: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142F318: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142F31C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142F320: LDR x1, [x28]              | X1 = "MotionBlur";                      
            // 0x0142F324: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0142F328: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F32C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142F330: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "MotionBlur", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_17 = val_75.GetMethod(name:  "MotionBlur", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0142F334: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142F338: MOV x21, x0                | X21 = val_17;//m1                       
            // 0x0142F33C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142F340: LDR x22, [x8, #0x20]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache4;
            // 0x0142F344: CBNZ x22, #0x142f390       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache4 != null) goto label_43;
            if((ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache4) != null)
            {
                goto label_43;
            }
            // 0x0142F348: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x0142F34C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142F350: LDR x8, [x8, #0x358]       | X8 = 1152921510108429248;               
            // 0x0142F354: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142F358: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::MotionBlur_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142F35C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_18 = null;
            // 0x0142F360: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142F364: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F368: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142F36C: MOV x2, x22                | X2 = 1152921510108429248 (0x1000000147EB7BC0);//ML01
            // 0x0142F370: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142F374: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::MotionBlur_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_18 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::MotionBlur_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142F378: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142F37C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142F380: STR x23, [x8, #0x20]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783634464
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache4 = val_18;
            // 0x0142F384: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142F388: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142F38C: LDR x22, [x8, #0x20]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_43:
            // 0x0142F390: CBNZ x19, #0x142f398       | if (X1 != 0) goto label_44;             
            if(val_74 != 0)
            {
                goto label_44;
            }
            // 0x0142F394: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::MotionBlur_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_44:
            // 0x0142F398: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142F39C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142F3A0: MOV x1, x21                | X1 = val_17;//m1                        
            // 0x0142F3A4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142F3A8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_17, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache4);
            val_74.RegisterCLRMethodRedirection(mi:  val_17, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache4);
            // 0x0142F3AC: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x0142F3B0: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x0142F3B4: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
            // 0x0142F3B8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F3BC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142F3C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F3C4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F3C8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142F3CC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F3D0: CBNZ x20, #0x142f3d8       | if (val_1 != null) goto label_45;       
            if(val_75 != null)
            {
                goto label_45;
            }
            // 0x0142F3D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_45:
            // 0x0142F3D8: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x0142F3DC: LDR x8, [x8, #0xbf8]       | X8 = (string**)(1152921510108430272)("PlayTeamSkillCamera");
            // 0x0142F3E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142F3E4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142F3E8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142F3EC: LDR x1, [x8]               | X1 = "PlayTeamSkillCamera";             
            // 0x0142F3F0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0142F3F4: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F3F8: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142F3FC: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "PlayTeamSkillCamera", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_19 = val_75.GetMethod(name:  "PlayTeamSkillCamera", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0142F400: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142F404: MOV x21, x0                | X21 = val_19;//m1                       
            // 0x0142F408: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142F40C: LDR x22, [x8, #0x28]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache5;
            // 0x0142F410: CBNZ x22, #0x142f45c       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache5 != null) goto label_46;
            if((ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache5) != null)
            {
                goto label_46;
            }
            // 0x0142F414: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
            // 0x0142F418: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142F41C: LDR x8, [x8, #0xb20]       | X8 = 1152921510108434480;               
            // 0x0142F420: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142F424: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::PlayTeamSkillCamera_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142F428: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_20 = null;
            // 0x0142F42C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142F430: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F434: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142F438: MOV x2, x22                | X2 = 1152921510108434480 (0x1000000147EB9030);//ML01
            // 0x0142F43C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142F440: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::PlayTeamSkillCamera_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_20 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::PlayTeamSkillCamera_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142F444: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142F448: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142F44C: STR x23, [x8, #0x28]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache5 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783634472
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache5 = val_20;
            // 0x0142F450: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142F454: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142F458: LDR x22, [x8, #0x28]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_46:
            // 0x0142F45C: CBNZ x19, #0x142f464       | if (X1 != 0) goto label_47;             
            if(val_74 != 0)
            {
                goto label_47;
            }
            // 0x0142F460: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::PlayTeamSkillCamera_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_47:
            // 0x0142F464: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142F468: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142F46C: MOV x1, x21                | X1 = val_19;//m1                        
            // 0x0142F470: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142F474: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_19, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache5);
            val_74.RegisterCLRMethodRedirection(mi:  val_19, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache5);
            // 0x0142F478: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x0142F47C: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x0142F480: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
            // 0x0142F484: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F488: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142F48C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F490: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F494: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142F498: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F49C: CBNZ x20, #0x142f4a4       | if (val_1 != null) goto label_48;       
            if(val_75 != null)
            {
                goto label_48;
            }
            // 0x0142F4A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_48:
            // 0x0142F4A4: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x0142F4A8: LDR x8, [x8, #0x7e0]       | X8 = (string**)(1152921510108435504)("StopTeamSkillCamera");
            // 0x0142F4AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142F4B0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142F4B4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142F4B8: LDR x1, [x8]               | X1 = "StopTeamSkillCamera";             
            // 0x0142F4BC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0142F4C0: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F4C4: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142F4C8: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "StopTeamSkillCamera", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_21 = val_75.GetMethod(name:  "StopTeamSkillCamera", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0142F4CC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142F4D0: MOV x21, x0                | X21 = val_21;//m1                       
            // 0x0142F4D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142F4D8: LDR x22, [x8, #0x30]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache6;
            // 0x0142F4DC: CBNZ x22, #0x142f528       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache6 != null) goto label_49;
            if((ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache6) != null)
            {
                goto label_49;
            }
            // 0x0142F4E0: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
            // 0x0142F4E4: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142F4E8: LDR x8, [x8, #0x250]       | X8 = 1152921510108439712;               
            // 0x0142F4EC: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142F4F0: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::StopTeamSkillCamera_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142F4F4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_22 = null;
            // 0x0142F4F8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142F4FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F500: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142F504: MOV x2, x22                | X2 = 1152921510108439712 (0x1000000147EBA4A0);//ML01
            // 0x0142F508: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142F50C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::StopTeamSkillCamera_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_22 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::StopTeamSkillCamera_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142F510: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142F514: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142F518: STR x23, [x8, #0x30]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache6 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783634480
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache6 = val_22;
            // 0x0142F51C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142F520: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142F524: LDR x22, [x8, #0x30]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_49:
            // 0x0142F528: CBNZ x19, #0x142f530       | if (X1 != 0) goto label_50;             
            if(val_74 != 0)
            {
                goto label_50;
            }
            // 0x0142F52C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::StopTeamSkillCamera_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_50:
            // 0x0142F530: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142F534: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142F538: MOV x1, x21                | X1 = val_21;//m1                        
            // 0x0142F53C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142F540: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_21, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache6);
            val_74.RegisterCLRMethodRedirection(mi:  val_21, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache6);
            // 0x0142F544: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x0142F548: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x0142F54C: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
            // 0x0142F550: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F554: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142F558: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F55C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F560: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142F564: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F568: CBNZ x20, #0x142f570       | if (val_1 != null) goto label_51;       
            if(val_75 != null)
            {
                goto label_51;
            }
            // 0x0142F56C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_51:
            // 0x0142F570: ADRP x8, #0x3645000        | X8 = 56905728 (0x3645000);              
            // 0x0142F574: LDR x8, [x8, #0xb30]       | X8 = (string**)(1152921510108440736)("BreakTeamSkillCamera");
            // 0x0142F578: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142F57C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142F580: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142F584: LDR x1, [x8]               | X1 = "BreakTeamSkillCamera";            
            // 0x0142F588: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0142F58C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F590: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142F594: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "BreakTeamSkillCamera", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_23 = val_75.GetMethod(name:  "BreakTeamSkillCamera", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0142F598: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142F59C: MOV x21, x0                | X21 = val_23;//m1                       
            // 0x0142F5A0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142F5A4: LDR x22, [x8, #0x38]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache7;
            // 0x0142F5A8: CBNZ x22, #0x142f5f4       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache7 != null) goto label_52;
            if((ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache7) != null)
            {
                goto label_52;
            }
            // 0x0142F5AC: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
            // 0x0142F5B0: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142F5B4: LDR x8, [x8, #0x6d0]       | X8 = 1152921510108444944;               
            // 0x0142F5B8: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142F5BC: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::BreakTeamSkillCamera_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142F5C0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_24 = null;
            // 0x0142F5C4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142F5C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F5CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142F5D0: MOV x2, x22                | X2 = 1152921510108444944 (0x1000000147EBB910);//ML01
            // 0x0142F5D4: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142F5D8: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::BreakTeamSkillCamera_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_24 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::BreakTeamSkillCamera_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142F5DC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142F5E0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142F5E4: STR x23, [x8, #0x38]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache7 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783634488
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache7 = val_24;
            // 0x0142F5E8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142F5EC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142F5F0: LDR x22, [x8, #0x38]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_52:
            // 0x0142F5F4: CBNZ x19, #0x142f5fc       | if (X1 != 0) goto label_53;             
            if(val_74 != 0)
            {
                goto label_53;
            }
            // 0x0142F5F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::BreakTeamSkillCamera_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_53:
            // 0x0142F5FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142F600: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142F604: MOV x1, x21                | X1 = val_23;//m1                        
            // 0x0142F608: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142F60C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_23, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache7);
            val_74.RegisterCLRMethodRedirection(mi:  val_23, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache7);
            // 0x0142F610: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x0142F614: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x0142F618: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
            // 0x0142F61C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F620: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142F624: MOVZ w1, #0x5              | W1 = 5 (0x5);//ML01                     
            // 0x0142F628: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F62C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142F630: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142F634: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142F638: ADRP x23, #0x365e000       | X23 = 57008128 (0x365E000);             
            // 0x0142F63C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F640: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142F644: LDR x23, [x23, #0xcb8]     | X23 = 1152921504608604160;              
            val_77 = 1152921504608604160;
            // 0x0142F648: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142F64C: LDR x22, [x23]             | X22 = typeof(System.Boolean);           
            // 0x0142F650: TBZ w9, #0, #0x142f664     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_55;
            // 0x0142F654: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142F658: CBNZ w9, #0x142f664        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_55;
            // 0x0142F65C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142F660: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_55:
            // 0x0142F664: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142F668: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142F66C: MOV x1, x22                | X1 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x0142F670: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_25 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142F674: MOV x22, x0                | X22 = val_25;//m1                       
            // 0x0142F678: CBNZ x21, #0x142f680       | if ( != null) goto label_56;            
            if(null != null)
            {
                goto label_56;
            }
            // 0x0142F67C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
            label_56:
            // 0x0142F680: CBZ x22, #0x142f6a4        | if (val_25 == null) goto label_58;      
            if(val_25 == null)
            {
                goto label_58;
            }
            // 0x0142F684: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142F688: MOV x0, x22                | X0 = val_25;//m1                        
            // 0x0142F68C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142F690: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_25, ????);     
            // 0x0142F694: CBNZ x0, #0x142f6a4        | if (val_25 != null) goto label_58;      
            if(val_25 != null)
            {
                goto label_58;
            }
            // 0x0142F698: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_25, ????);     
            // 0x0142F69C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F6A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_25, ????);     
            label_58:
            // 0x0142F6A4: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142F6A8: CBNZ w8, #0x142f6b8        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_59;
            // 0x0142F6AC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_25, ????);     
            // 0x0142F6B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F6B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_25, ????);     
            label_59:
            // 0x0142F6B8: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_25;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_25;
            // 0x0142F6BC: ADRP x25, #0x3611000       | X25 = 56692736 (0x3611000);             
            // 0x0142F6C0: LDR x25, [x25, #0x9a8]     | X25 = 1152921504607113216;              
            val_78 = 1152921504607113216;
            // 0x0142F6C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142F6C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142F6CC: LDR x1, [x25]              | X1 = typeof(System.Int32);              
            // 0x0142F6D0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_26 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142F6D4: MOV x22, x0                | X22 = val_26;//m1                       
            // 0x0142F6D8: CBZ x22, #0x142f6fc        | if (val_26 == null) goto label_61;      
            if(val_26 == null)
            {
                goto label_61;
            }
            // 0x0142F6DC: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142F6E0: MOV x0, x22                | X0 = val_26;//m1                        
            // 0x0142F6E4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142F6E8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_26, ????);     
            // 0x0142F6EC: CBNZ x0, #0x142f6fc        | if (val_26 != null) goto label_61;      
            if(val_26 != null)
            {
                goto label_61;
            }
            // 0x0142F6F0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_26, ????);     
            // 0x0142F6F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F6F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_26, ????);     
            label_61:
            // 0x0142F6FC: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142F700: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x0142F704: B.HI #0x142f714            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_62;
            // 0x0142F708: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_26, ????);     
            // 0x0142F70C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F710: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_26, ????);     
            label_62:
            // 0x0142F714: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_26;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_26;
            // 0x0142F718: LDR x1, [x23]              | X1 = typeof(System.Boolean);            
            // 0x0142F71C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142F720: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142F724: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_27 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142F728: MOV x22, x0                | X22 = val_27;//m1                       
            // 0x0142F72C: CBZ x22, #0x142f750        | if (val_27 == null) goto label_64;      
            if(val_27 == null)
            {
                goto label_64;
            }
            // 0x0142F730: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142F734: MOV x0, x22                | X0 = val_27;//m1                        
            // 0x0142F738: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142F73C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_27, ????);     
            // 0x0142F740: CBNZ x0, #0x142f750        | if (val_27 != null) goto label_64;      
            if(val_27 != null)
            {
                goto label_64;
            }
            // 0x0142F744: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_27, ????);     
            // 0x0142F748: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F74C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_27, ????);     
            label_64:
            // 0x0142F750: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142F754: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x0142F758: B.HI #0x142f768            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_65;
            // 0x0142F75C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_27, ????);     
            // 0x0142F760: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F764: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_27, ????);     
            label_65:
            // 0x0142F768: STR x22, [x21, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_27;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_27;
            // 0x0142F76C: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x0142F770: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x0142F774: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142F778: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142F77C: LDR x1, [x8]               | X1 = typeof(System.Single);             
            // 0x0142F780: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_28 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142F784: MOV x22, x0                | X22 = val_28;//m1                       
            // 0x0142F788: CBZ x22, #0x142f7ac        | if (val_28 == null) goto label_67;      
            if(val_28 == null)
            {
                goto label_67;
            }
            // 0x0142F78C: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142F790: MOV x0, x22                | X0 = val_28;//m1                        
            // 0x0142F794: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142F798: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_28, ????);     
            // 0x0142F79C: CBNZ x0, #0x142f7ac        | if (val_28 != null) goto label_67;      
            if(val_28 != null)
            {
                goto label_67;
            }
            // 0x0142F7A0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_28, ????);     
            // 0x0142F7A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F7A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_28, ????);     
            label_67:
            // 0x0142F7AC: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142F7B0: CMP w8, #3                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x0142F7B4: B.HI #0x142f7c4            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x3) goto label_68;
            // 0x0142F7B8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_28, ????);     
            // 0x0142F7BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F7C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_28, ????);     
            label_68:
            // 0x0142F7C4: STR x22, [x21, #0x38]      | typeof(System.Type[]).__il2cppRuntimeField_38 = val_28;  //  dest_result_addr=1152921504987155112
            typeof(System.Type[]).__il2cppRuntimeField_38 = val_28;
            // 0x0142F7C8: LDR x1, [x25]              | X1 = typeof(System.Int32);              
            // 0x0142F7CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142F7D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142F7D4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_29 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142F7D8: MOV x22, x0                | X22 = val_29;//m1                       
            // 0x0142F7DC: CBZ x22, #0x142f800        | if (val_29 == null) goto label_70;      
            if(val_29 == null)
            {
                goto label_70;
            }
            // 0x0142F7E0: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142F7E4: MOV x0, x22                | X0 = val_29;//m1                        
            // 0x0142F7E8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142F7EC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_29, ????);     
            // 0x0142F7F0: CBNZ x0, #0x142f800        | if (val_29 != null) goto label_70;      
            if(val_29 != null)
            {
                goto label_70;
            }
            // 0x0142F7F4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_29, ????);     
            // 0x0142F7F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F7FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_29, ????);     
            label_70:
            // 0x0142F800: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142F804: CMP w8, #4                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x4)
            // 0x0142F808: B.HI #0x142f818            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x4) goto label_71;
            // 0x0142F80C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_29, ????);     
            // 0x0142F810: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F814: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_29, ????);     
            label_71:
            // 0x0142F818: STR x22, [x21, #0x40]      | typeof(System.Type[]).__il2cppRuntimeField_40 = val_29;  //  dest_result_addr=1152921504987155120
            typeof(System.Type[]).__il2cppRuntimeField_40 = val_29;
            // 0x0142F81C: CBNZ x20, #0x142f824       | if (val_1 != null) goto label_72;       
            if(val_75 != null)
            {
                goto label_72;
            }
            // 0x0142F820: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_29, ????);     
            label_72:
            // 0x0142F824: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
            // 0x0142F828: LDR x8, [x8, #0xbe0]       | X8 = (string**)(1152921510108466448)("MoveCamera");
            // 0x0142F82C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142F830: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142F834: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142F838: LDR x1, [x8]               | X1 = "MoveCamera";                      
            // 0x0142F83C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0142F840: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F844: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142F848: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "MoveCamera", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_30 = val_75.GetMethod(name:  "MoveCamera", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0142F84C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142F850: MOV x21, x0                | X21 = val_30;//m1                       
            // 0x0142F854: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142F858: LDR x22, [x8, #0x40]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache8;
            // 0x0142F85C: CBNZ x22, #0x142f8d0       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache8 != null) goto label_73;
            if((ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache8) != null)
            {
                goto label_73;
            }
            // 0x0142F860: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x0142F864: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142F868: LDR x8, [x8, #0x20]        | X8 = 1152921510108470640;               
            // 0x0142F86C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142F870: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::MoveCamera_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142F874: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_31 = null;
            // 0x0142F878: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142F87C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F880: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142F884: MOV x2, x22                | X2 = 1152921510108470640 (0x1000000147EC1D70);//ML01
            // 0x0142F888: MOV x27, x19               | X27 = X1;//m1                           
            // 0x0142F88C: MOV x19, x20               | X19 = val_1;//m1                        
            // 0x0142F890: MOV x20, x28               | X20 = 58349288 (0x37A56E8);//ML01       
            // 0x0142F894: MOV x28, x23               | X28 = 57965512 (0x3747BC8);//ML01       
            // 0x0142F898: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142F89C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::MoveCamera_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_31 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::MoveCamera_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142F8A0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142F8A4: ADRP x25, #0x3611000       | X25 = 56692736 (0x3611000);             
            // 0x0142F8A8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142F8AC: STR x23, [x8, #0x40]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache8 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783634496
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache8 = val_31;
            // 0x0142F8B0: LDR x25, [x25, #0x9a8]     | X25 = 1152921504607113216;              
            val_78 = 1152921504607113216;
            // 0x0142F8B4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142F8B8: MOV x23, x28               | X23 = 57965512 (0x3747BC8);//ML01       
            val_77 = val_77;
            // 0x0142F8BC: MOV x28, x20               | X28 = 58349288 (0x37A56E8);//ML01       
            // 0x0142F8C0: MOV x20, x19               | X20 = val_1;//m1                        
            val_75 = val_75;
            // 0x0142F8C4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142F8C8: MOV x19, x27               | X19 = X1;//m1                           
            val_74 = val_74;
            // 0x0142F8CC: LDR x22, [x8, #0x40]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_73:
            // 0x0142F8D0: CBNZ x19, #0x142f8d8       | if (X1 != 0) goto label_74;             
            if(val_74 != 0)
            {
                goto label_74;
            }
            // 0x0142F8D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::MoveCamera_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_74:
            // 0x0142F8D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142F8DC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142F8E0: MOV x1, x21                | X1 = val_30;//m1                        
            // 0x0142F8E4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142F8E8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_30, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache8);
            val_74.RegisterCLRMethodRedirection(mi:  val_30, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache8);
            // 0x0142F8EC: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x0142F8F0: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x0142F8F4: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
            // 0x0142F8F8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F8FC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142F900: MOVZ w1, #0x5              | W1 = 5 (0x5);//ML01                     
            // 0x0142F904: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F908: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142F90C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142F910: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142F914: LDR x22, [x23]             | X22 = typeof(System.Boolean);           
            // 0x0142F918: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142F91C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142F920: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142F924: TBZ w9, #0, #0x142f938     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_76;
            // 0x0142F928: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142F92C: CBNZ w9, #0x142f938        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_76;
            // 0x0142F930: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142F934: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_76:
            // 0x0142F938: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142F93C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142F940: MOV x1, x22                | X1 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x0142F944: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_32 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142F948: MOV x22, x0                | X22 = val_32;//m1                       
            // 0x0142F94C: CBNZ x21, #0x142f954       | if ( != null) goto label_77;            
            if(null != null)
            {
                goto label_77;
            }
            // 0x0142F950: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
            label_77:
            // 0x0142F954: CBZ x22, #0x142f978        | if (val_32 == null) goto label_79;      
            if(val_32 == null)
            {
                goto label_79;
            }
            // 0x0142F958: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142F95C: MOV x0, x22                | X0 = val_32;//m1                        
            // 0x0142F960: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142F964: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_32, ????);     
            // 0x0142F968: CBNZ x0, #0x142f978        | if (val_32 != null) goto label_79;      
            if(val_32 != null)
            {
                goto label_79;
            }
            // 0x0142F96C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_32, ????);     
            // 0x0142F970: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F974: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_32, ????);     
            label_79:
            // 0x0142F978: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142F97C: CBNZ w8, #0x142f98c        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_80;
            // 0x0142F980: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_32, ????);     
            // 0x0142F984: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F988: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_32, ????);     
            label_80:
            // 0x0142F98C: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_32;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_32;
            // 0x0142F990: LDR x1, [x25]              | X1 = typeof(System.Int32);              
            // 0x0142F994: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142F998: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142F99C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_33 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142F9A0: MOV x22, x0                | X22 = val_33;//m1                       
            // 0x0142F9A4: CBZ x22, #0x142f9c8        | if (val_33 == null) goto label_82;      
            if(val_33 == null)
            {
                goto label_82;
            }
            // 0x0142F9A8: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142F9AC: MOV x0, x22                | X0 = val_33;//m1                        
            // 0x0142F9B0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142F9B4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_33, ????);     
            // 0x0142F9B8: CBNZ x0, #0x142f9c8        | if (val_33 != null) goto label_82;      
            if(val_33 != null)
            {
                goto label_82;
            }
            // 0x0142F9BC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_33, ????);     
            // 0x0142F9C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F9C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_33, ????);     
            label_82:
            // 0x0142F9C8: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142F9CC: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x0142F9D0: B.HI #0x142f9e0            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_83;
            // 0x0142F9D4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_33, ????);     
            // 0x0142F9D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142F9DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_33, ????);     
            label_83:
            // 0x0142F9E0: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_33;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_33;
            // 0x0142F9E4: LDR x1, [x23]              | X1 = typeof(System.Boolean);            
            // 0x0142F9E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142F9EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142F9F0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_34 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142F9F4: MOV x22, x0                | X22 = val_34;//m1                       
            // 0x0142F9F8: CBZ x22, #0x142fa1c        | if (val_34 == null) goto label_85;      
            if(val_34 == null)
            {
                goto label_85;
            }
            // 0x0142F9FC: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142FA00: MOV x0, x22                | X0 = val_34;//m1                        
            // 0x0142FA04: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142FA08: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_34, ????);     
            // 0x0142FA0C: CBNZ x0, #0x142fa1c        | if (val_34 != null) goto label_85;      
            if(val_34 != null)
            {
                goto label_85;
            }
            // 0x0142FA10: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_34, ????);     
            // 0x0142FA14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142FA18: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_34, ????);     
            label_85:
            // 0x0142FA1C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142FA20: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x0142FA24: B.HI #0x142fa34            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_86;
            // 0x0142FA28: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_34, ????);     
            // 0x0142FA2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142FA30: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_34, ????);     
            label_86:
            // 0x0142FA34: STR x22, [x21, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_34;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_34;
            // 0x0142FA38: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x0142FA3C: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x0142FA40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142FA44: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142FA48: LDR x1, [x8]               | X1 = typeof(System.Single);             
            // 0x0142FA4C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_35 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142FA50: MOV x22, x0                | X22 = val_35;//m1                       
            // 0x0142FA54: CBZ x22, #0x142fa78        | if (val_35 == null) goto label_88;      
            if(val_35 == null)
            {
                goto label_88;
            }
            // 0x0142FA58: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142FA5C: MOV x0, x22                | X0 = val_35;//m1                        
            // 0x0142FA60: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142FA64: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_35, ????);     
            // 0x0142FA68: CBNZ x0, #0x142fa78        | if (val_35 != null) goto label_88;      
            if(val_35 != null)
            {
                goto label_88;
            }
            // 0x0142FA6C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_35, ????);     
            // 0x0142FA70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142FA74: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_35, ????);     
            label_88:
            // 0x0142FA78: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142FA7C: CMP w8, #3                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x0142FA80: B.HI #0x142fa90            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x3) goto label_89;
            // 0x0142FA84: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_35, ????);     
            // 0x0142FA88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142FA8C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_35, ????);     
            label_89:
            // 0x0142FA90: STR x22, [x21, #0x38]      | typeof(System.Type[]).__il2cppRuntimeField_38 = val_35;  //  dest_result_addr=1152921504987155112
            typeof(System.Type[]).__il2cppRuntimeField_38 = val_35;
            // 0x0142FA94: ADRP x27, #0x3607000       | X27 = 56651776 (0x3607000);             
            // 0x0142FA98: LDR x27, [x27, #0xbb8]     | X27 = 1152921504608284672;              
            val_79 = 1152921504608284672;
            // 0x0142FA9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142FAA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142FAA4: LDR x1, [x27]              | X1 = typeof(System.String);             
            // 0x0142FAA8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_36 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142FAAC: MOV x22, x0                | X22 = val_36;//m1                       
            // 0x0142FAB0: CBZ x22, #0x142fad4        | if (val_36 == null) goto label_91;      
            if(val_36 == null)
            {
                goto label_91;
            }
            // 0x0142FAB4: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142FAB8: MOV x0, x22                | X0 = val_36;//m1                        
            // 0x0142FABC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142FAC0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_36, ????);     
            // 0x0142FAC4: CBNZ x0, #0x142fad4        | if (val_36 != null) goto label_91;      
            if(val_36 != null)
            {
                goto label_91;
            }
            // 0x0142FAC8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_36, ????);     
            // 0x0142FACC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142FAD0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_36, ????);     
            label_91:
            // 0x0142FAD4: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142FAD8: CMP w8, #4                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x4)
            // 0x0142FADC: B.HI #0x142faec            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x4) goto label_92;
            // 0x0142FAE0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_36, ????);     
            // 0x0142FAE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142FAE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_36, ????);     
            label_92:
            // 0x0142FAEC: STR x22, [x21, #0x40]      | typeof(System.Type[]).__il2cppRuntimeField_40 = val_36;  //  dest_result_addr=1152921504987155120
            typeof(System.Type[]).__il2cppRuntimeField_40 = val_36;
            // 0x0142FAF0: CBNZ x20, #0x142faf8       | if (val_1 != null) goto label_93;       
            if(val_75 != null)
            {
                goto label_93;
            }
            // 0x0142FAF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_36, ????);     
            label_93:
            // 0x0142FAF8: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x0142FAFC: LDR x8, [x8, #0x6c0]       | X8 = (string**)(1152921510108492144)("ChangeCameraTarget");
            // 0x0142FB00: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142FB04: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142FB08: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142FB0C: LDR x1, [x8]               | X1 = "ChangeCameraTarget";              
            // 0x0142FB10: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0142FB14: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142FB18: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142FB1C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "ChangeCameraTarget", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_37 = val_75.GetMethod(name:  "ChangeCameraTarget", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0142FB20: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142FB24: MOV x21, x0                | X21 = val_37;//m1                       
            // 0x0142FB28: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142FB2C: LDR x22, [x8, #0x48]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache9;
            // 0x0142FB30: CBNZ x22, #0x142fbb4       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache9 != null) goto label_94;
            if((ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache9) != null)
            {
                goto label_94;
            }
            // 0x0142FB34: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
            // 0x0142FB38: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142FB3C: LDR x8, [x8, #0xd00]       | X8 = 1152921510108496352;               
            // 0x0142FB40: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142FB44: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::ChangeCameraTarget_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142FB48: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_38 = null;
            // 0x0142FB4C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142FB50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142FB54: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142FB58: MOV x2, x22                | X2 = 1152921510108496352 (0x1000000147EC81E0);//ML01
            // 0x0142FB5C: STR x19, [sp, #8]          | stack[1152921510108601384] = X1;         //  dest_result_addr=1152921510108601384
            // 0x0142FB60: MOV x19, x20               | X19 = val_1;//m1                        
            // 0x0142FB64: MOV x20, x28               | X20 = 58349288 (0x37A56E8);//ML01       
            // 0x0142FB68: MOV x26, x27               | X26 = 57965408 (0x3747B60);//ML01       
            // 0x0142FB6C: MOV x27, x24               | X27 = 57999920 (0x3750230);//ML01       
            // 0x0142FB70: MOV x24, x25               | X24 = 57965480 (0x3747BA8);//ML01       
            // 0x0142FB74: MOV x28, x23               | X28 = 57965512 (0x3747BC8);//ML01       
            // 0x0142FB78: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142FB7C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::ChangeCameraTarget_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_38 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::ChangeCameraTarget_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142FB80: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142FB84: MOV x25, x24               | X25 = 57965480 (0x3747BA8);//ML01       
            val_78 = val_78;
            // 0x0142FB88: MOV x24, x27               | X24 = 57999920 (0x3750230);//ML01       
            val_76 = val_76;
            // 0x0142FB8C: MOV x27, x26               | X27 = 57965408 (0x3747B60);//ML01       
            val_79 = val_79;
            // 0x0142FB90: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142FB94: STR x23, [x8, #0x48]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache9 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783634504
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache9 = val_38;
            // 0x0142FB98: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142FB9C: MOV x23, x28               | X23 = 57965512 (0x3747BC8);//ML01       
            val_77 = val_77;
            // 0x0142FBA0: MOV x28, x20               | X28 = 58349288 (0x37A56E8);//ML01       
            // 0x0142FBA4: MOV x20, x19               | X20 = val_1;//m1                        
            val_75 = val_75;
            // 0x0142FBA8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142FBAC: LDR x19, [sp, #8]          | X19 = X1;                               
            val_74 = val_74;
            // 0x0142FBB0: LDR x22, [x8, #0x48]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_94:
            // 0x0142FBB4: CBNZ x19, #0x142fbbc       | if (X1 != 0) goto label_95;             
            if(val_74 != 0)
            {
                goto label_95;
            }
            // 0x0142FBB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::ChangeCameraTarget_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_95:
            // 0x0142FBBC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142FBC0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142FBC4: MOV x1, x21                | X1 = val_37;//m1                        
            // 0x0142FBC8: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142FBCC: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_37, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache9);
            val_74.RegisterCLRMethodRedirection(mi:  val_37, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache9);
            // 0x0142FBD0: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x0142FBD4: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x0142FBD8: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
            // 0x0142FBDC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142FBE0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142FBE4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x0142FBE8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142FBEC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142FBF0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142FBF4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142FBF8: ADRP x9, #0x3630000        | X9 = 56819712 (0x3630000);              
            // 0x0142FBFC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142FC00: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142FC04: LDR x9, [x9, #0x8b8]       | X9 = 1152921504698060800;               
            // 0x0142FC08: LDR x22, [x9]              | X22 = typeof(UnityEngine.Transform);    
            // 0x0142FC0C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142FC10: TBZ w9, #0, #0x142fc24     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_97;
            // 0x0142FC14: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142FC18: CBNZ w9, #0x142fc24        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_97;
            // 0x0142FC1C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142FC20: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_97:
            // 0x0142FC24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142FC28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142FC2C: MOV x1, x22                | X1 = 1152921504698060800 (0x10000000056FD000);//ML01
            // 0x0142FC30: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_39 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142FC34: MOV x22, x0                | X22 = val_39;//m1                       
            // 0x0142FC38: CBNZ x21, #0x142fc40       | if ( != null) goto label_98;            
            if(null != null)
            {
                goto label_98;
            }
            // 0x0142FC3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
            label_98:
            // 0x0142FC40: CBZ x22, #0x142fc64        | if (val_39 == null) goto label_100;     
            if(val_39 == null)
            {
                goto label_100;
            }
            // 0x0142FC44: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142FC48: MOV x0, x22                | X0 = val_39;//m1                        
            // 0x0142FC4C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142FC50: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_39, ????);     
            // 0x0142FC54: CBNZ x0, #0x142fc64        | if (val_39 != null) goto label_100;     
            if(val_39 != null)
            {
                goto label_100;
            }
            // 0x0142FC58: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_39, ????);     
            // 0x0142FC5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142FC60: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_39, ????);     
            label_100:
            // 0x0142FC64: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142FC68: CBNZ w8, #0x142fc78        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_101;
            // 0x0142FC6C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_39, ????);     
            // 0x0142FC70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142FC74: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_39, ????);     
            label_101:
            // 0x0142FC78: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_39;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_39;
            // 0x0142FC7C: CBNZ x20, #0x142fc84       | if (val_1 != null) goto label_102;      
            if(val_75 != null)
            {
                goto label_102;
            }
            // 0x0142FC80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
            label_102:
            // 0x0142FC84: LDR x1, [x28]              | X1 = "MotionBlur";                      
            // 0x0142FC88: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142FC8C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142FC90: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142FC94: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0142FC98: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142FC9C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142FCA0: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "MotionBlur", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_40 = val_75.GetMethod(name:  "MotionBlur", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0142FCA4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142FCA8: MOV x21, x0                | X21 = val_40;//m1                       
            // 0x0142FCAC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142FCB0: LDR x22, [x8, #0x50]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheA;
            // 0x0142FCB4: CBNZ x22, #0x142fd08       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheA != null) goto label_103;
            if((ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheA) != null)
            {
                goto label_103;
            }
            // 0x0142FCB8: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x0142FCBC: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142FCC0: LDR x8, [x8, #0xd80]       | X8 = 1152921510108505568;               
            // 0x0142FCC4: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142FCC8: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::MotionBlur_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142FCCC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_41 = null;
            // 0x0142FCD0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142FCD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142FCD8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142FCDC: MOV x2, x22                | X2 = 1152921510108505568 (0x1000000147ECA5E0);//ML01
            // 0x0142FCE0: MOV x28, x23               | X28 = 57965512 (0x3747BC8);//ML01       
            // 0x0142FCE4: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142FCE8: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::MotionBlur_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_41 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::MotionBlur_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142FCEC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142FCF0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142FCF4: STR x23, [x8, #0x50]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheA = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783634512
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheA = val_41;
            // 0x0142FCF8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142FCFC: MOV x23, x28               | X23 = 57965512 (0x3747BC8);//ML01       
            val_77 = val_77;
            // 0x0142FD00: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142FD04: LDR x22, [x8, #0x50]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_103:
            // 0x0142FD08: CBNZ x19, #0x142fd10       | if (X1 != 0) goto label_104;            
            if(val_74 != 0)
            {
                goto label_104;
            }
            // 0x0142FD0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::MotionBlur_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_104:
            // 0x0142FD10: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142FD14: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142FD18: MOV x1, x21                | X1 = val_40;//m1                        
            // 0x0142FD1C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142FD20: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_40, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheA);
            val_74.RegisterCLRMethodRedirection(mi:  val_40, func:  ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheA);
            // 0x0142FD24: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x0142FD28: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x0142FD2C: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
            // 0x0142FD30: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142FD34: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142FD38: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x0142FD3C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142FD40: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142FD44: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142FD48: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142FD4C: ADRP x9, #0x3683000        | X9 = 57159680 (0x3683000);              
            // 0x0142FD50: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142FD54: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142FD58: LDR x9, [x9, #0xc48]       | X9 = 1152921504608444416;               
            // 0x0142FD5C: LDR x22, [x9]              | X22 = typeof(System.Single);            
            // 0x0142FD60: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142FD64: TBZ w9, #0, #0x142fd78     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_106;
            // 0x0142FD68: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142FD6C: CBNZ w9, #0x142fd78        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_106;
            // 0x0142FD70: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142FD74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_106:
            // 0x0142FD78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142FD7C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142FD80: MOV x1, x22                | X1 = 1152921504608444416 (0x1000000000186000);//ML01
            // 0x0142FD84: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_42 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142FD88: MOV x22, x0                | X22 = val_42;//m1                       
            // 0x0142FD8C: CBNZ x21, #0x142fd94       | if ( != null) goto label_107;           
            if(null != null)
            {
                goto label_107;
            }
            // 0x0142FD90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            label_107:
            // 0x0142FD94: CBZ x22, #0x142fdb8        | if (val_42 == null) goto label_109;     
            if(val_42 == null)
            {
                goto label_109;
            }
            // 0x0142FD98: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142FD9C: MOV x0, x22                | X0 = val_42;//m1                        
            // 0x0142FDA0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142FDA4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_42, ????);     
            // 0x0142FDA8: CBNZ x0, #0x142fdb8        | if (val_42 != null) goto label_109;     
            if(val_42 != null)
            {
                goto label_109;
            }
            // 0x0142FDAC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_42, ????);     
            // 0x0142FDB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142FDB4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            label_109:
            // 0x0142FDB8: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142FDBC: CBNZ w8, #0x142fdcc        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_110;
            // 0x0142FDC0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_42, ????);     
            // 0x0142FDC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142FDC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            label_110:
            // 0x0142FDCC: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_42;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_42;
            // 0x0142FDD0: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x0142FDD4: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x0142FDD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142FDDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142FDE0: LDR x1, [x8]               | X1 = typeof(System.Single);             
            // 0x0142FDE4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_43 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142FDE8: MOV x22, x0                | X22 = val_43;//m1                       
            // 0x0142FDEC: CBZ x22, #0x142fe10        | if (val_43 == null) goto label_112;     
            if(val_43 == null)
            {
                goto label_112;
            }
            // 0x0142FDF0: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142FDF4: MOV x0, x22                | X0 = val_43;//m1                        
            // 0x0142FDF8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142FDFC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_43, ????);     
            // 0x0142FE00: CBNZ x0, #0x142fe10        | if (val_43 != null) goto label_112;     
            if(val_43 != null)
            {
                goto label_112;
            }
            // 0x0142FE04: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_43, ????);     
            // 0x0142FE08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142FE0C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_43, ????);     
            label_112:
            // 0x0142FE10: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142FE14: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x0142FE18: B.HI #0x142fe28            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_113;
            // 0x0142FE1C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_43, ????);     
            // 0x0142FE20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142FE24: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_43, ????);     
            label_113:
            // 0x0142FE28: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_43;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_43;
            // 0x0142FE2C: CBNZ x20, #0x142fe34       | if (val_1 != null) goto label_114;      
            if(val_75 != null)
            {
                goto label_114;
            }
            // 0x0142FE30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_43, ????);     
            label_114:
            // 0x0142FE34: ADRP x26, #0x3628000       | X26 = 56786944 (0x3628000);             
            // 0x0142FE38: LDR x26, [x26, #0x4c8]     | X26 = (string**)(1152921510108514784)("ScreenShake");
            // 0x0142FE3C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142FE40: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142FE44: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142FE48: LDR x1, [x26]              | X1 = "ScreenShake";                     
            // 0x0142FE4C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0142FE50: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142FE54: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142FE58: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "ScreenShake", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_44 = val_75.GetMethod(name:  "ScreenShake", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0142FE5C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142FE60: MOV x21, x0                | X21 = val_44;//m1                       
            // 0x0142FE64: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142FE68: LDR x22, [x8, #0x58]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheB;
            val_80 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheB;
            // 0x0142FE6C: CBNZ x22, #0x142fed8       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheB != null) goto label_115;
            if(val_80 != null)
            {
                goto label_115;
            }
            // 0x0142FE70: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
            // 0x0142FE74: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142FE78: LDR x8, [x8, #0x150]       | X8 = 1152921510108518976;               
            // 0x0142FE7C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142FE80: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::ScreenShake_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142FE84: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_45 = null;
            // 0x0142FE88: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142FE8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142FE90: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142FE94: MOV x2, x22                | X2 = 1152921510108518976 (0x1000000147ECDA40);//ML01
            // 0x0142FE98: MOV x28, x27               | X28 = 57965408 (0x3747B60);//ML01       
            // 0x0142FE9C: MOV x27, x24               | X27 = 57999920 (0x3750230);//ML01       
            // 0x0142FEA0: MOV x24, x25               | X24 = 57965480 (0x3747BA8);//ML01       
            // 0x0142FEA4: MOV x25, x23               | X25 = 57965512 (0x3747BC8);//ML01       
            // 0x0142FEA8: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142FEAC: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::ScreenShake_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_45 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::ScreenShake_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142FEB0: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142FEB4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142FEB8: STR x23, [x8, #0x58]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheB = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783634520
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheB = val_45;
            // 0x0142FEBC: MOV x23, x25               | X23 = 57965512 (0x3747BC8);//ML01       
            val_77 = val_77;
            // 0x0142FEC0: MOV x25, x24               | X25 = 57965480 (0x3747BA8);//ML01       
            val_78 = val_78;
            // 0x0142FEC4: MOV x24, x27               | X24 = 57999920 (0x3750230);//ML01       
            val_76 = val_76;
            // 0x0142FEC8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0142FECC: MOV x27, x28               | X27 = 57965408 (0x3747B60);//ML01       
            val_79 = val_79;
            // 0x0142FED0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142FED4: LDR x22, [x8, #0x58]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_80 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheB;
            label_115:
            // 0x0142FED8: CBNZ x19, #0x142fee0       | if (X1 != 0) goto label_116;            
            if(val_74 != 0)
            {
                goto label_116;
            }
            // 0x0142FEDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::ScreenShake_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_116:
            // 0x0142FEE0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142FEE4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142FEE8: MOV x1, x21                | X1 = val_44;//m1                        
            // 0x0142FEEC: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142FEF0: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_44, func:  val_80);
            val_74.RegisterCLRMethodRedirection(mi:  val_44, func:  val_80);
            // 0x0142FEF4: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x0142FEF8: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x0142FEFC: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
            // 0x0142FF00: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142FF04: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142FF08: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x0142FF0C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142FF10: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142FF14: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142FF18: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142FF1C: ADRP x9, #0x3683000        | X9 = 57159680 (0x3683000);              
            // 0x0142FF20: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142FF24: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142FF28: LDR x9, [x9, #0xc48]       | X9 = 1152921504608444416;               
            // 0x0142FF2C: LDR x22, [x9]              | X22 = typeof(System.Single);            
            // 0x0142FF30: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142FF34: TBZ w9, #0, #0x142ff48     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_118;
            // 0x0142FF38: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142FF3C: CBNZ w9, #0x142ff48        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_118;
            // 0x0142FF40: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142FF44: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_118:
            // 0x0142FF48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142FF4C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142FF50: MOV x1, x22                | X1 = 1152921504608444416 (0x1000000000186000);//ML01
            // 0x0142FF54: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_46 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142FF58: MOV x22, x0                | X22 = val_46;//m1                       
            // 0x0142FF5C: CBNZ x21, #0x142ff64       | if ( != null) goto label_119;           
            if(null != null)
            {
                goto label_119;
            }
            // 0x0142FF60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            label_119:
            // 0x0142FF64: CBZ x22, #0x142ff88        | if (val_46 == null) goto label_121;     
            if(val_46 == null)
            {
                goto label_121;
            }
            // 0x0142FF68: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142FF6C: MOV x0, x22                | X0 = val_46;//m1                        
            // 0x0142FF70: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142FF74: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_46, ????);     
            // 0x0142FF78: CBNZ x0, #0x142ff88        | if (val_46 != null) goto label_121;     
            if(val_46 != null)
            {
                goto label_121;
            }
            // 0x0142FF7C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_46, ????);     
            // 0x0142FF80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142FF84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_46, ????);     
            label_121:
            // 0x0142FF88: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142FF8C: CBNZ w8, #0x142ff9c        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_122;
            // 0x0142FF90: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_46, ????);     
            // 0x0142FF94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142FF98: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_46, ????);     
            label_122:
            // 0x0142FF9C: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_46;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_46;
            // 0x0142FFA0: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x0142FFA4: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x0142FFA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142FFAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142FFB0: LDR x1, [x8]               | X1 = typeof(System.Single);             
            // 0x0142FFB4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_47 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142FFB8: MOV x22, x0                | X22 = val_47;//m1                       
            // 0x0142FFBC: CBZ x22, #0x142ffe0        | if (val_47 == null) goto label_124;     
            if(val_47 == null)
            {
                goto label_124;
            }
            // 0x0142FFC0: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142FFC4: MOV x0, x22                | X0 = val_47;//m1                        
            // 0x0142FFC8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142FFCC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_47, ????);     
            // 0x0142FFD0: CBNZ x0, #0x142ffe0        | if (val_47 != null) goto label_124;     
            if(val_47 != null)
            {
                goto label_124;
            }
            // 0x0142FFD4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_47, ????);     
            // 0x0142FFD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142FFDC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_47, ????);     
            label_124:
            // 0x0142FFE0: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142FFE4: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x0142FFE8: B.HI #0x142fff8            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_125;
            // 0x0142FFEC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_47, ????);     
            // 0x0142FFF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142FFF4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_47, ????);     
            label_125:
            // 0x0142FFF8: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_47;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_47;
            // 0x0142FFFC: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x01430000: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x01430004: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01430008: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143000C: LDR x1, [x8]               | X1 = typeof(System.Single);             
            // 0x01430010: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_48 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01430014: MOV x22, x0                | X22 = val_48;//m1                       
            // 0x01430018: CBZ x22, #0x143003c        | if (val_48 == null) goto label_127;     
            if(val_48 == null)
            {
                goto label_127;
            }
            // 0x0143001C: LDR x8, [x21]              | X8 = ;                                  
            // 0x01430020: MOV x0, x22                | X0 = val_48;//m1                        
            // 0x01430024: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01430028: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_48, ????);     
            // 0x0143002C: CBNZ x0, #0x143003c        | if (val_48 != null) goto label_127;     
            if(val_48 != null)
            {
                goto label_127;
            }
            // 0x01430030: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_48, ????);     
            // 0x01430034: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430038: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_48, ????);     
            label_127:
            // 0x0143003C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01430040: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x01430044: B.HI #0x1430054            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_128;
            // 0x01430048: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_48, ????);     
            // 0x0143004C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430050: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_48, ????);     
            label_128:
            // 0x01430054: STR x22, [x21, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_48;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_48;
            // 0x01430058: CBNZ x20, #0x1430060       | if (val_1 != null) goto label_129;      
            if(val_75 != null)
            {
                goto label_129;
            }
            // 0x0143005C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_48, ????);     
            label_129:
            // 0x01430060: LDR x1, [x26]              | X1 = "ScreenShake";                     
            // 0x01430064: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430068: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0143006C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01430070: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01430074: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01430078: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0143007C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "ScreenShake", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_49 = val_75.GetMethod(name:  "ScreenShake", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01430080: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430084: MOV x21, x0                | X21 = val_49;//m1                       
            // 0x01430088: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143008C: LDR x22, [x8, #0x60]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheC;
            val_81 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheC;
            // 0x01430090: CBNZ x22, #0x14300f4       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheC != null) goto label_130;
            if(val_81 != null)
            {
                goto label_130;
            }
            // 0x01430094: ADRP x8, #0x35e4000        | X8 = 56508416 (0x35E4000);              
            // 0x01430098: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0143009C: LDR x8, [x8, #0x4f8]       | X8 = 1152921510108536384;               
            // 0x014300A0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x014300A4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::ScreenShake_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x014300A8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_50 = null;
            // 0x014300AC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x014300B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014300B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014300B8: MOV x2, x22                | X2 = 1152921510108536384 (0x1000000147ED1E40);//ML01
            // 0x014300BC: MOV x26, x24               | X26 = 57999920 (0x3750230);//ML01       
            // 0x014300C0: MOV x24, x25               | X24 = 57965480 (0x3747BA8);//ML01       
            // 0x014300C4: MOV x25, x23               | X25 = 57965512 (0x3747BC8);//ML01       
            // 0x014300C8: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x014300CC: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::ScreenShake_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_50 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::ScreenShake_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x014300D0: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x014300D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x014300D8: STR x23, [x8, #0x60]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheC = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783634528
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheC = val_50;
            // 0x014300DC: MOV x23, x25               | X23 = 57965512 (0x3747BC8);//ML01       
            val_77 = val_77;
            // 0x014300E0: MOV x25, x24               | X25 = 57965480 (0x3747BA8);//ML01       
            val_78 = val_78;
            // 0x014300E4: MOV x24, x26               | X24 = 57999920 (0x3750230);//ML01       
            val_76 = val_76;
            // 0x014300E8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x014300EC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x014300F0: LDR x22, [x8, #0x60]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_81 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheC;
            label_130:
            // 0x014300F4: ADRP x28, #0x3620000       | X28 = 56754176 (0x3620000);             
            // 0x014300F8: LDR x28, [x28, #0x340]     | X28 = 1152921504609562624;              
            // 0x014300FC: CBNZ x19, #0x1430104       | if (X1 != 0) goto label_131;            
            if(val_74 != 0)
            {
                goto label_131;
            }
            // 0x01430100: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::ScreenShake_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_131:
            // 0x01430104: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430108: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143010C: MOV x1, x21                | X1 = val_49;//m1                        
            // 0x01430110: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01430114: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_49, func:  val_81);
            val_74.RegisterCLRMethodRedirection(mi:  val_49, func:  val_81);
            // 0x01430118: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x0143011C: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x01430120: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
            // 0x01430124: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01430128: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0143012C: ORR w1, wzr, #7            | W1 = 7(0x7);                            
            // 0x01430130: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01430134: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01430138: LDR x8, [x28]              | X8 = typeof(System.Type);               
            // 0x0143013C: LDR x22, [x23]             | X22 = typeof(System.Boolean);           
            // 0x01430140: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01430144: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01430148: TBZ w9, #0, #0x143015c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_133;
            // 0x0143014C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01430150: CBNZ w9, #0x143015c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_133;
            // 0x01430154: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01430158: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_133:
            // 0x0143015C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01430160: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01430164: MOV x1, x22                | X1 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x01430168: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_51 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143016C: MOV x22, x0                | X22 = val_51;//m1                       
            // 0x01430170: CBNZ x21, #0x1430178       | if ( != null) goto label_134;           
            if(null != null)
            {
                goto label_134;
            }
            // 0x01430174: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_51, ????);     
            label_134:
            // 0x01430178: CBZ x22, #0x143019c        | if (val_51 == null) goto label_136;     
            if(val_51 == null)
            {
                goto label_136;
            }
            // 0x0143017C: LDR x8, [x21]              | X8 = ;                                  
            // 0x01430180: MOV x0, x22                | X0 = val_51;//m1                        
            // 0x01430184: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01430188: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_51, ????);     
            // 0x0143018C: CBNZ x0, #0x143019c        | if (val_51 != null) goto label_136;     
            if(val_51 != null)
            {
                goto label_136;
            }
            // 0x01430190: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_51, ????);     
            // 0x01430194: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430198: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_51, ????);     
            label_136:
            // 0x0143019C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x014301A0: CBNZ w8, #0x14301b0        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_137;
            // 0x014301A4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_51, ????);     
            // 0x014301A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014301AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_51, ????);     
            label_137:
            // 0x014301B0: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_51;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_51;
            // 0x014301B4: LDR x1, [x25]              | X1 = typeof(System.Int32);              
            // 0x014301B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014301BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014301C0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_52 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x014301C4: MOV x22, x0                | X22 = val_52;//m1                       
            // 0x014301C8: CBZ x22, #0x14301ec        | if (val_52 == null) goto label_139;     
            if(val_52 == null)
            {
                goto label_139;
            }
            // 0x014301CC: LDR x8, [x21]              | X8 = ;                                  
            // 0x014301D0: MOV x0, x22                | X0 = val_52;//m1                        
            // 0x014301D4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x014301D8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_52, ????);     
            // 0x014301DC: CBNZ x0, #0x14301ec        | if (val_52 != null) goto label_139;     
            if(val_52 != null)
            {
                goto label_139;
            }
            // 0x014301E0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_52, ????);     
            // 0x014301E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014301E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_52, ????);     
            label_139:
            // 0x014301EC: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x014301F0: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x014301F4: B.HI #0x1430204            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_140;
            // 0x014301F8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_52, ????);     
            // 0x014301FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430200: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_52, ????);     
            label_140:
            // 0x01430204: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_52;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_52;
            // 0x01430208: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x0143020C: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x01430210: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01430214: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01430218: LDR x1, [x8]               | X1 = typeof(System.Single);             
            // 0x0143021C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_53 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01430220: MOV x22, x0                | X22 = val_53;//m1                       
            // 0x01430224: CBZ x22, #0x1430248        | if (val_53 == null) goto label_142;     
            if(val_53 == null)
            {
                goto label_142;
            }
            // 0x01430228: LDR x8, [x21]              | X8 = ;                                  
            // 0x0143022C: MOV x0, x22                | X0 = val_53;//m1                        
            // 0x01430230: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01430234: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_53, ????);     
            // 0x01430238: CBNZ x0, #0x1430248        | if (val_53 != null) goto label_142;     
            if(val_53 != null)
            {
                goto label_142;
            }
            // 0x0143023C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_53, ????);     
            // 0x01430240: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430244: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_53, ????);     
            label_142:
            // 0x01430248: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0143024C: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x01430250: B.HI #0x1430260            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_143;
            // 0x01430254: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_53, ????);     
            // 0x01430258: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143025C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_53, ????);     
            label_143:
            // 0x01430260: STR x22, [x21, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_53;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_53;
            // 0x01430264: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x01430268: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x0143026C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01430270: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01430274: LDR x1, [x8]               | X1 = typeof(System.Single);             
            // 0x01430278: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_54 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143027C: MOV x22, x0                | X22 = val_54;//m1                       
            // 0x01430280: CBZ x22, #0x14302a4        | if (val_54 == null) goto label_145;     
            if(val_54 == null)
            {
                goto label_145;
            }
            // 0x01430284: LDR x8, [x21]              | X8 = ;                                  
            // 0x01430288: MOV x0, x22                | X0 = val_54;//m1                        
            // 0x0143028C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01430290: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_54, ????);     
            // 0x01430294: CBNZ x0, #0x14302a4        | if (val_54 != null) goto label_145;     
            if(val_54 != null)
            {
                goto label_145;
            }
            // 0x01430298: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_54, ????);     
            // 0x0143029C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014302A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_54, ????);     
            label_145:
            // 0x014302A4: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x014302A8: CMP w8, #3                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x014302AC: B.HI #0x14302bc            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x3) goto label_146;
            // 0x014302B0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_54, ????);     
            // 0x014302B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014302B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_54, ????);     
            label_146:
            // 0x014302BC: STR x22, [x21, #0x38]      | typeof(System.Type[]).__il2cppRuntimeField_38 = val_54;  //  dest_result_addr=1152921504987155112
            typeof(System.Type[]).__il2cppRuntimeField_38 = val_54;
            // 0x014302C0: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x014302C4: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x014302C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014302CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014302D0: LDR x1, [x8]               | X1 = typeof(System.Single);             
            // 0x014302D4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_55 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x014302D8: MOV x22, x0                | X22 = val_55;//m1                       
            // 0x014302DC: CBZ x22, #0x1430300        | if (val_55 == null) goto label_148;     
            if(val_55 == null)
            {
                goto label_148;
            }
            // 0x014302E0: LDR x8, [x21]              | X8 = ;                                  
            // 0x014302E4: MOV x0, x22                | X0 = val_55;//m1                        
            // 0x014302E8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x014302EC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_55, ????);     
            // 0x014302F0: CBNZ x0, #0x1430300        | if (val_55 != null) goto label_148;     
            if(val_55 != null)
            {
                goto label_148;
            }
            // 0x014302F4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_55, ????);     
            // 0x014302F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014302FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_55, ????);     
            label_148:
            // 0x01430300: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01430304: CMP w8, #4                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x4)
            // 0x01430308: B.HI #0x1430318            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x4) goto label_149;
            // 0x0143030C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_55, ????);     
            // 0x01430310: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430314: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_55, ????);     
            label_149:
            // 0x01430318: STR x22, [x21, #0x40]      | typeof(System.Type[]).__il2cppRuntimeField_40 = val_55;  //  dest_result_addr=1152921504987155120
            typeof(System.Type[]).__il2cppRuntimeField_40 = val_55;
            // 0x0143031C: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x01430320: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x01430324: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01430328: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143032C: LDR x1, [x8]               | X1 = typeof(System.Single);             
            // 0x01430330: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_56 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01430334: MOV x22, x0                | X22 = val_56;//m1                       
            // 0x01430338: CBZ x22, #0x143035c        | if (val_56 == null) goto label_151;     
            if(val_56 == null)
            {
                goto label_151;
            }
            // 0x0143033C: LDR x8, [x21]              | X8 = ;                                  
            // 0x01430340: MOV x0, x22                | X0 = val_56;//m1                        
            // 0x01430344: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01430348: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_56, ????);     
            // 0x0143034C: CBNZ x0, #0x143035c        | if (val_56 != null) goto label_151;     
            if(val_56 != null)
            {
                goto label_151;
            }
            // 0x01430350: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_56, ????);     
            // 0x01430354: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430358: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_56, ????);     
            label_151:
            // 0x0143035C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01430360: CMP w8, #5                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x5)
            // 0x01430364: B.HI #0x1430374            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x5) goto label_152;
            // 0x01430368: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_56, ????);     
            // 0x0143036C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430370: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_56, ????);     
            label_152:
            // 0x01430374: STR x22, [x21, #0x48]      | typeof(System.Type[]).__il2cppRuntimeField_48 = val_56;  //  dest_result_addr=1152921504987155128
            typeof(System.Type[]).__il2cppRuntimeField_48 = val_56;
            // 0x01430378: LDR x1, [x27]              | X1 = typeof(System.String);             
            // 0x0143037C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01430380: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01430384: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_57 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01430388: MOV x22, x0                | X22 = val_57;//m1                       
            // 0x0143038C: CBZ x22, #0x14303b0        | if (val_57 == null) goto label_154;     
            if(val_57 == null)
            {
                goto label_154;
            }
            // 0x01430390: LDR x8, [x21]              | X8 = ;                                  
            // 0x01430394: MOV x0, x22                | X0 = val_57;//m1                        
            // 0x01430398: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0143039C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_57, ????);     
            // 0x014303A0: CBNZ x0, #0x14303b0        | if (val_57 != null) goto label_154;     
            if(val_57 != null)
            {
                goto label_154;
            }
            // 0x014303A4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_57, ????);     
            // 0x014303A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014303AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_57, ????);     
            label_154:
            // 0x014303B0: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x014303B4: CMP w8, #6                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x6)
            // 0x014303B8: B.HI #0x14303c8            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x6) goto label_155;
            // 0x014303BC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_57, ????);     
            // 0x014303C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014303C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_57, ????);     
            label_155:
            // 0x014303C8: STR x22, [x21, #0x50]      | typeof(System.Type[]).__il2cppRuntimeField_50 = val_57;  //  dest_result_addr=1152921504987155136
            typeof(System.Type[]).__il2cppRuntimeField_50 = val_57;
            // 0x014303CC: CBNZ x20, #0x14303d4       | if (val_1 != null) goto label_156;      
            if(val_75 != null)
            {
                goto label_156;
            }
            // 0x014303D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_57, ????);     
            label_156:
            // 0x014303D4: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x014303D8: LDR x8, [x8, #0x2d8]       | X8 = (string**)(1152921510108566080)("LockView");
            // 0x014303DC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014303E0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x014303E4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x014303E8: LDR x1, [x8]               | X1 = "LockView";                        
            // 0x014303EC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x014303F0: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x014303F4: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x014303F8: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "LockView", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_58 = val_75.GetMethod(name:  "LockView", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x014303FC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430400: MOV x21, x0                | X21 = val_58;//m1                       
            // 0x01430404: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430408: LDR x22, [x8, #0x68]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheD;
            val_82 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheD;
            // 0x0143040C: CBNZ x22, #0x1430458       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheD != null) goto label_157;
            if(val_82 != null)
            {
                goto label_157;
            }
            // 0x01430410: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x01430414: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01430418: LDR x8, [x8, #0x4b0]       | X8 = 1152921510108570272;               
            // 0x0143041C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01430420: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::LockView_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01430424: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_59 = null;
            // 0x01430428: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0143042C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430430: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430434: MOV x2, x22                | X2 = 1152921510108570272 (0x1000000147EDA2A0);//ML01
            // 0x01430438: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_77 = val_59;
            // 0x0143043C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::LockView_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_59 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::LockView_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01430440: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430444: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430448: STR x23, [x8, #0x68]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheD = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783634536
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheD = val_77;
            // 0x0143044C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430450: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430454: LDR x22, [x8, #0x68]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_82 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheD;
            label_157:
            // 0x01430458: CBNZ x19, #0x1430460       | if (X1 != 0) goto label_158;            
            if(val_74 != 0)
            {
                goto label_158;
            }
            // 0x0143045C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::LockView_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_158:
            // 0x01430460: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430464: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01430468: MOV x1, x21                | X1 = val_58;//m1                        
            // 0x0143046C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01430470: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_58, func:  val_82);
            val_74.RegisterCLRMethodRedirection(mi:  val_58, func:  val_82);
            // 0x01430474: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x01430478: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x0143047C: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
            // 0x01430480: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01430484: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01430488: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143048C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01430490: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01430494: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01430498: CBNZ x20, #0x14304a0       | if (val_1 != null) goto label_159;      
            if(val_75 != null)
            {
                goto label_159;
            }
            // 0x0143049C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_159:
            // 0x014304A0: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x014304A4: LDR x8, [x8, #0xc88]       | X8 = (string**)(1152921510108571296)("UnLockView");
            // 0x014304A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014304AC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x014304B0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x014304B4: LDR x1, [x8]               | X1 = "UnLockView";                      
            // 0x014304B8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x014304BC: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x014304C0: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x014304C4: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "UnLockView", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_60 = val_75.GetMethod(name:  "UnLockView", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x014304C8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x014304CC: MOV x21, x0                | X21 = val_60;//m1                       
            // 0x014304D0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x014304D4: LDR x22, [x8, #0x70]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheE;
            val_83 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheE;
            // 0x014304D8: CBNZ x22, #0x1430524       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheE != null) goto label_160;
            if(val_83 != null)
            {
                goto label_160;
            }
            // 0x014304DC: ADRP x8, #0x3643000        | X8 = 56897536 (0x3643000);              
            // 0x014304E0: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x014304E4: LDR x8, [x8, #0x880]       | X8 = 1152921510108575488;               
            // 0x014304E8: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x014304EC: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::UnLockView_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x014304F0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_61 = null;
            // 0x014304F4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x014304F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014304FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430500: MOV x2, x22                | X2 = 1152921510108575488 (0x1000000147EDB700);//ML01
            // 0x01430504: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_77 = val_61;
            // 0x01430508: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::UnLockView_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_61 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::UnLockView_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0143050C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430510: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430514: STR x23, [x8, #0x70]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheE = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783634544
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheE = val_77;
            // 0x01430518: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0143051C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430520: LDR x22, [x8, #0x70]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_83 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheE;
            label_160:
            // 0x01430524: CBNZ x19, #0x143052c       | if (X1 != 0) goto label_161;            
            if(val_74 != 0)
            {
                goto label_161;
            }
            // 0x01430528: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CameraHelper_Binding::UnLockView_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_161:
            // 0x0143052C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430530: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01430534: MOV x1, x21                | X1 = val_60;//m1                        
            // 0x01430538: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0143053C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_60, func:  val_83);
            val_74.RegisterCLRMethodRedirection(mi:  val_60, func:  val_83);
            // 0x01430540: CBNZ x20, #0x1430548       | if (val_1 != null) goto label_162;      
            if(val_75 != null)
            {
                goto label_162;
            }
            // 0x01430544: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_162:
            // 0x01430548: ADRP x9, #0x360b000        | X9 = 56668160 (0x360B000);              
            // 0x0143054C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01430550: LDR x9, [x9, #0x328]       | X9 = (string**)(1152921510108576512)("MOVE_COMPLETE");
            // 0x01430554: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01430558: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0143055C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01430560: LDR x1, [x9]               | X1 = "MOVE_COMPLETE";                   
            // 0x01430564: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01430568: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x0143056C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430570: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01430574: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430578: LDR x22, [x8, #0x78]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheF;
            val_84 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheF;
            // 0x0143057C: CBNZ x22, #0x14305c8       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheF != null) goto label_163;
            if(val_84 != null)
            {
                goto label_163;
            }
            // 0x01430580: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x01430584: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01430588: LDR x8, [x8, #0x468]       | X8 = 1152921510108576608;               
            // 0x0143058C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01430590: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_MOVE_COMPLETE_0(ref object o);
            // 0x01430594: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_62 = null;
            // 0x01430598: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x0143059C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014305A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014305A4: MOV x2, x22                | X2 = 1152921510108576608 (0x1000000147EDBB60);//ML01
            // 0x014305A8: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_77 = val_62;
            // 0x014305AC: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_MOVE_COMPLETE_0(ref object o));
            val_62 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_MOVE_COMPLETE_0(ref object o));
            // 0x014305B0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x014305B4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x014305B8: STR x23, [x8, #0x78]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheF = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783634552
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheF = val_77;
            // 0x014305BC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x014305C0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x014305C4: LDR x22, [x8, #0x78]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_84 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cacheF;
            label_163:
            // 0x014305C8: CBNZ x19, #0x14305d0       | if (X1 != 0) goto label_164;            
            if(val_74 != 0)
            {
                goto label_164;
            }
            // 0x014305CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_MOVE_COMPLETE_0(ref object o)), ????);
            label_164:
            // 0x014305D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014305D4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014305D8: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x014305DC: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x014305E0: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_75, getter:  val_84);
            val_74.RegisterCLRFieldGetter(f:  val_75, getter:  val_84);
            // 0x014305E4: CBNZ x20, #0x14305ec       | if (val_1 != null) goto label_165;      
            if(val_75 != null)
            {
                goto label_165;
            }
            // 0x014305E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_165:
            // 0x014305EC: ADRP x9, #0x35f5000        | X9 = 56578048 (0x35F5000);              
            // 0x014305F0: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x014305F4: LDR x9, [x9, #0xb40]       | X9 = (string**)(1152921510108577632)("CHANGE_TARGET_COMPLETE");
            // 0x014305F8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x014305FC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01430600: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01430604: LDR x1, [x9]               | X1 = "CHANGE_TARGET_COMPLETE";          
            // 0x01430608: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x0143060C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01430610: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430614: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01430618: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143061C: LDR x22, [x8, #0x80]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache10;
            val_85 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache10;
            // 0x01430620: CBNZ x22, #0x143066c       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache10 != null) goto label_166;
            if(val_85 != null)
            {
                goto label_166;
            }
            // 0x01430624: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
            // 0x01430628: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x0143062C: LDR x8, [x8, #0xfd8]       | X8 = 1152921510108577744;               
            // 0x01430630: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01430634: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_CHANGE_TARGET_COMPLETE_1(ref object o);
            // 0x01430638: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_63 = null;
            // 0x0143063C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01430640: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430644: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430648: MOV x2, x22                | X2 = 1152921510108577744 (0x1000000147EDBFD0);//ML01
            // 0x0143064C: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_77 = val_63;
            // 0x01430650: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_CHANGE_TARGET_COMPLETE_1(ref object o));
            val_63 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_CHANGE_TARGET_COMPLETE_1(ref object o));
            // 0x01430654: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430658: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143065C: STR x23, [x8, #0x80]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache10 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783634560
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache10 = val_77;
            // 0x01430660: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430664: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430668: LDR x22, [x8, #0x80]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_85 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache10;
            label_166:
            // 0x0143066C: CBNZ x19, #0x1430674       | if (X1 != 0) goto label_167;            
            if(val_74 != 0)
            {
                goto label_167;
            }
            // 0x01430670: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_CHANGE_TARGET_COMPLETE_1(ref object o)), ????);
            label_167:
            // 0x01430674: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430678: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143067C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01430680: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01430684: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_75, getter:  val_85);
            val_74.RegisterCLRFieldGetter(f:  val_75, getter:  val_85);
            // 0x01430688: CBNZ x20, #0x1430690       | if (val_1 != null) goto label_168;      
            if(val_75 != null)
            {
                goto label_168;
            }
            // 0x0143068C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_168:
            // 0x01430690: ADRP x9, #0x35e9000        | X9 = 56528896 (0x35E9000);              
            // 0x01430694: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01430698: LDR x9, [x9, #0xc88]       | X9 = (string**)(1152921510108578768)("fieldMin");
            // 0x0143069C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x014306A0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x014306A4: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x014306A8: LDR x1, [x9]               | X1 = "fieldMin";                        
            // 0x014306AC: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x014306B0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x014306B4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x014306B8: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x014306BC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x014306C0: LDR x22, [x8, #0x88]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache11;
            val_86 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache11;
            // 0x014306C4: CBNZ x22, #0x1430710       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache11 != null) goto label_169;
            if(val_86 != null)
            {
                goto label_169;
            }
            // 0x014306C8: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x014306CC: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x014306D0: LDR x8, [x8, #0x108]       | X8 = 1152921510108578864;               
            // 0x014306D4: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x014306D8: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_fieldMin_2(ref object o);
            // 0x014306DC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_64 = null;
            // 0x014306E0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x014306E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014306E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014306EC: MOV x2, x22                | X2 = 1152921510108578864 (0x1000000147EDC430);//ML01
            // 0x014306F0: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_77 = val_64;
            // 0x014306F4: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_fieldMin_2(ref object o));
            val_64 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_fieldMin_2(ref object o));
            // 0x014306F8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x014306FC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430700: STR x23, [x8, #0x88]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache11 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783634568
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache11 = val_77;
            // 0x01430704: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430708: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143070C: LDR x22, [x8, #0x88]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_86 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache11;
            label_169:
            // 0x01430710: CBNZ x19, #0x1430718       | if (X1 != 0) goto label_170;            
            if(val_74 != 0)
            {
                goto label_170;
            }
            // 0x01430714: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_fieldMin_2(ref object o)), ????);
            label_170:
            // 0x01430718: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143071C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01430720: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01430724: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01430728: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_75, getter:  val_86);
            val_74.RegisterCLRFieldGetter(f:  val_75, getter:  val_86);
            // 0x0143072C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430730: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430734: LDR x22, [x8, #0x90]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache12;
            val_87 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache12;
            // 0x01430738: CBNZ x22, #0x1430784       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache12 != null) goto label_171;
            if(val_87 != null)
            {
                goto label_171;
            }
            // 0x0143073C: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x01430740: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01430744: LDR x8, [x8, #0x428]       | X8 = 1152921510108579888;               
            // 0x01430748: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x0143074C: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CameraHelper_Binding::set_fieldMin_2(ref object o, object v);
            // 0x01430750: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_65 = null;
            // 0x01430754: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01430758: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143075C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430760: MOV x2, x22                | X2 = 1152921510108579888 (0x1000000147EDC830);//ML01
            // 0x01430764: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_77 = val_65;
            // 0x01430768: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraHelper_Binding::set_fieldMin_2(ref object o, object v));
            val_65 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraHelper_Binding::set_fieldMin_2(ref object o, object v));
            // 0x0143076C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430770: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430774: STR x23, [x8, #0x90]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache12 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783634576
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache12 = val_77;
            // 0x01430778: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0143077C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430780: LDR x22, [x8, #0x90]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_87 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache12;
            label_171:
            // 0x01430784: CBNZ x19, #0x143078c       | if (X1 != 0) goto label_172;            
            if(val_74 != 0)
            {
                goto label_172;
            }
            // 0x01430788: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraHelper_Binding::set_fieldMin_2(ref object o, object v)), ????);
            label_172:
            // 0x0143078C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430790: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01430794: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01430798: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x0143079C: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_75, setter:  val_87);
            val_74.RegisterCLRFieldSetter(f:  val_75, setter:  val_87);
            // 0x014307A0: CBNZ x20, #0x14307a8       | if (val_1 != null) goto label_173;      
            if(val_75 != null)
            {
                goto label_173;
            }
            // 0x014307A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_173:
            // 0x014307A8: ADRP x9, #0x3681000        | X9 = 57151488 (0x3681000);              
            // 0x014307AC: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x014307B0: LDR x9, [x9, #0xa18]       | X9 = (string**)(1152921510108580912)("timeScale");
            // 0x014307B4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x014307B8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x014307BC: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x014307C0: LDR x1, [x9]               | X1 = "timeScale";                       
            // 0x014307C4: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x014307C8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x014307CC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x014307D0: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x014307D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x014307D8: LDR x22, [x8, #0x98]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache13;
            val_88 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache13;
            // 0x014307DC: CBNZ x22, #0x1430828       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache13 != null) goto label_174;
            if(val_88 != null)
            {
                goto label_174;
            }
            // 0x014307E0: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x014307E4: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x014307E8: LDR x8, [x8, #0x618]       | X8 = 1152921510108581008;               
            // 0x014307EC: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x014307F0: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_timeScale_3(ref object o);
            // 0x014307F4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_66 = null;
            // 0x014307F8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x014307FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430800: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430804: MOV x2, x22                | X2 = 1152921510108581008 (0x1000000147EDCC90);//ML01
            // 0x01430808: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_77 = val_66;
            // 0x0143080C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_timeScale_3(ref object o));
            val_66 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_timeScale_3(ref object o));
            // 0x01430810: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430814: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430818: STR x23, [x8, #0x98]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache13 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783634584
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache13 = val_77;
            // 0x0143081C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430820: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430824: LDR x22, [x8, #0x98]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_88 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache13;
            label_174:
            // 0x01430828: CBNZ x19, #0x1430830       | if (X1 != 0) goto label_175;            
            if(val_74 != 0)
            {
                goto label_175;
            }
            // 0x0143082C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_timeScale_3(ref object o)), ????);
            label_175:
            // 0x01430830: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430834: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01430838: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x0143083C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01430840: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_75, getter:  val_88);
            val_74.RegisterCLRFieldGetter(f:  val_75, getter:  val_88);
            // 0x01430844: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430848: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143084C: LDR x22, [x8, #0xa0]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache14;
            val_89 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache14;
            // 0x01430850: CBNZ x22, #0x143089c       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache14 != null) goto label_176;
            if(val_89 != null)
            {
                goto label_176;
            }
            // 0x01430854: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x01430858: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x0143085C: LDR x8, [x8, #0x368]       | X8 = 1152921510108582032;               
            // 0x01430860: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01430864: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CameraHelper_Binding::set_timeScale_3(ref object o, object v);
            // 0x01430868: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_67 = null;
            // 0x0143086C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01430870: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430874: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430878: MOV x2, x22                | X2 = 1152921510108582032 (0x1000000147EDD090);//ML01
            // 0x0143087C: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_77 = val_67;
            // 0x01430880: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraHelper_Binding::set_timeScale_3(ref object o, object v));
            val_67 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraHelper_Binding::set_timeScale_3(ref object o, object v));
            // 0x01430884: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430888: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143088C: STR x23, [x8, #0xa0]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache14 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783634592
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache14 = val_77;
            // 0x01430890: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430894: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430898: LDR x22, [x8, #0xa0]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_89 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache14;
            label_176:
            // 0x0143089C: CBNZ x19, #0x14308a4       | if (X1 != 0) goto label_177;            
            if(val_74 != 0)
            {
                goto label_177;
            }
            // 0x014308A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraHelper_Binding::set_timeScale_3(ref object o, object v)), ????);
            label_177:
            // 0x014308A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014308A8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014308AC: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x014308B0: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x014308B4: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_75, setter:  val_89);
            val_74.RegisterCLRFieldSetter(f:  val_75, setter:  val_89);
            // 0x014308B8: CBNZ x20, #0x14308c0       | if (val_1 != null) goto label_178;      
            if(val_75 != null)
            {
                goto label_178;
            }
            // 0x014308BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_178:
            // 0x014308C0: ADRP x9, #0x3613000        | X9 = 56700928 (0x3613000);              
            // 0x014308C4: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x014308C8: LDR x9, [x9, #0x6d0]       | X9 = (string**)(1152921510108583056)("effectCamera");
            // 0x014308CC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x014308D0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x014308D4: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x014308D8: LDR x1, [x9]               | X1 = "effectCamera";                    
            // 0x014308DC: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x014308E0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x014308E4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x014308E8: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x014308EC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x014308F0: LDR x22, [x8, #0xa8]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache15;
            val_90 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache15;
            // 0x014308F4: CBNZ x22, #0x1430940       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache15 != null) goto label_179;
            if(val_90 != null)
            {
                goto label_179;
            }
            // 0x014308F8: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
            // 0x014308FC: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01430900: LDR x8, [x8, #0x5b8]       | X8 = 1152921510108583152;               
            // 0x01430904: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01430908: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_effectCamera_4(ref object o);
            // 0x0143090C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_68 = null;
            // 0x01430910: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01430914: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430918: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143091C: MOV x2, x22                | X2 = 1152921510108583152 (0x1000000147EDD4F0);//ML01
            // 0x01430920: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_77 = val_68;
            // 0x01430924: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_effectCamera_4(ref object o));
            val_68 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_effectCamera_4(ref object o));
            // 0x01430928: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x0143092C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430930: STR x23, [x8, #0xa8]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache15 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783634600
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache15 = val_77;
            // 0x01430934: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430938: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143093C: LDR x22, [x8, #0xa8]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_90 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache15;
            label_179:
            // 0x01430940: CBNZ x19, #0x1430948       | if (X1 != 0) goto label_180;            
            if(val_74 != 0)
            {
                goto label_180;
            }
            // 0x01430944: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_effectCamera_4(ref object o)), ????);
            label_180:
            // 0x01430948: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143094C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01430950: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01430954: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01430958: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_75, getter:  val_90);
            val_74.RegisterCLRFieldGetter(f:  val_75, getter:  val_90);
            // 0x0143095C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430960: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430964: LDR x22, [x8, #0xb0]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache16;
            val_91 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache16;
            // 0x01430968: CBNZ x22, #0x14309b4       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache16 != null) goto label_181;
            if(val_91 != null)
            {
                goto label_181;
            }
            // 0x0143096C: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
            // 0x01430970: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01430974: LDR x8, [x8, #0xca8]       | X8 = 1152921510108584176;               
            // 0x01430978: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x0143097C: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CameraHelper_Binding::set_effectCamera_4(ref object o, object v);
            // 0x01430980: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_69 = null;
            // 0x01430984: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01430988: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143098C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430990: MOV x2, x22                | X2 = 1152921510108584176 (0x1000000147EDD8F0);//ML01
            // 0x01430994: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_77 = val_69;
            // 0x01430998: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraHelper_Binding::set_effectCamera_4(ref object o, object v));
            val_69 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraHelper_Binding::set_effectCamera_4(ref object o, object v));
            // 0x0143099C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x014309A0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x014309A4: STR x23, [x8, #0xb0]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache16 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783634608
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache16 = val_77;
            // 0x014309A8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x014309AC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x014309B0: LDR x22, [x8, #0xb0]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_91 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache16;
            label_181:
            // 0x014309B4: CBNZ x19, #0x14309bc       | if (X1 != 0) goto label_182;            
            if(val_74 != 0)
            {
                goto label_182;
            }
            // 0x014309B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraHelper_Binding::set_effectCamera_4(ref object o, object v)), ????);
            label_182:
            // 0x014309BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014309C0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014309C4: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x014309C8: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x014309CC: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_75, setter:  val_91);
            val_74.RegisterCLRFieldSetter(f:  val_75, setter:  val_91);
            // 0x014309D0: CBNZ x20, #0x14309d8       | if (val_1 != null) goto label_183;      
            if(val_75 != null)
            {
                goto label_183;
            }
            // 0x014309D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_183:
            // 0x014309D8: ADRP x9, #0x3671000        | X9 = 57085952 (0x3671000);              
            // 0x014309DC: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x014309E0: LDR x9, [x9, #0x508]       | X9 = (string**)(1152921510108585200)("instance");
            // 0x014309E4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x014309E8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x014309EC: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x014309F0: LDR x1, [x9]               | X1 = "instance";                        
            // 0x014309F4: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x014309F8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x014309FC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430A00: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01430A04: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430A08: LDR x22, [x8, #0xb8]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache17;
            val_92 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache17;
            // 0x01430A0C: CBNZ x22, #0x1430a58       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache17 != null) goto label_184;
            if(val_92 != null)
            {
                goto label_184;
            }
            // 0x01430A10: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x01430A14: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01430A18: LDR x8, [x8, #0xd58]       | X8 = 1152921510108585296;               
            // 0x01430A1C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01430A20: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_instance_5(ref object o);
            // 0x01430A24: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_70 = null;
            // 0x01430A28: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01430A2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430A30: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430A34: MOV x2, x22                | X2 = 1152921510108585296 (0x1000000147EDDD50);//ML01
            // 0x01430A38: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_77 = val_70;
            // 0x01430A3C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_instance_5(ref object o));
            val_70 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_instance_5(ref object o));
            // 0x01430A40: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430A44: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430A48: STR x23, [x8, #0xb8]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache17 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783634616
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache17 = val_77;
            // 0x01430A4C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430A50: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430A54: LDR x22, [x8, #0xb8]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_92 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache17;
            label_184:
            // 0x01430A58: CBNZ x19, #0x1430a60       | if (X1 != 0) goto label_185;            
            if(val_74 != 0)
            {
                goto label_185;
            }
            // 0x01430A5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_instance_5(ref object o)), ????);
            label_185:
            // 0x01430A60: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430A64: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01430A68: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01430A6C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01430A70: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_75, getter:  val_92);
            val_74.RegisterCLRFieldGetter(f:  val_75, getter:  val_92);
            // 0x01430A74: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430A78: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430A7C: LDR x22, [x8, #0xc0]       | X22 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache18;
            val_93 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache18;
            // 0x01430A80: CBNZ x22, #0x1430acc       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache18 != null) goto label_186;
            if(val_93 != null)
            {
                goto label_186;
            }
            // 0x01430A84: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
            // 0x01430A88: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01430A8C: LDR x8, [x8, #0x90]        | X8 = 1152921510108586320;               
            // 0x01430A90: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01430A94: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CameraHelper_Binding::set_instance_5(ref object o, object v);
            // 0x01430A98: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_71 = null;
            // 0x01430A9C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01430AA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430AA4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430AA8: MOV x2, x22                | X2 = 1152921510108586320 (0x1000000147EDE150);//ML01
            // 0x01430AAC: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_77 = val_71;
            // 0x01430AB0: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraHelper_Binding::set_instance_5(ref object o, object v));
            val_71 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraHelper_Binding::set_instance_5(ref object o, object v));
            // 0x01430AB4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430AB8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430ABC: STR x23, [x8, #0xc0]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache18 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783634624
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache18 = val_77;
            // 0x01430AC0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430AC4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430AC8: LDR x22, [x8, #0xc0]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_93 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache18;
            label_186:
            // 0x01430ACC: CBNZ x19, #0x1430ad4       | if (X1 != 0) goto label_187;            
            if(val_74 != 0)
            {
                goto label_187;
            }
            // 0x01430AD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraHelper_Binding::set_instance_5(ref object o, object v)), ????);
            label_187:
            // 0x01430AD4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430AD8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01430ADC: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01430AE0: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01430AE4: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_75, setter:  val_93);
            val_74.RegisterCLRFieldSetter(f:  val_75, setter:  val_93);
            // 0x01430AE8: CBNZ x20, #0x1430af0       | if (val_1 != null) goto label_188;      
            if(val_75 != null)
            {
                goto label_188;
            }
            // 0x01430AEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_188:
            // 0x01430AF0: ADRP x9, #0x3669000        | X9 = 57053184 (0x3669000);              
            // 0x01430AF4: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01430AF8: LDR x9, [x9, #0xd80]       | X9 = (string**)(1152921510108587344)("motionBluring");
            // 0x01430AFC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01430B00: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01430B04: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01430B08: LDR x1, [x9]               | X1 = "motionBluring";                   
            // 0x01430B0C: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01430B10: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01430B14: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430B18: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x01430B1C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430B20: LDR x21, [x8, #0xc8]       | X21 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache19;
            val_94 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache19;
            // 0x01430B24: CBNZ x21, #0x1430b70       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache19 != null) goto label_189;
            if(val_94 != null)
            {
                goto label_189;
            }
            // 0x01430B28: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01430B2C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01430B30: LDR x8, [x8, #0xb40]       | X8 = 1152921510108587440;               
            // 0x01430B34: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01430B38: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_motionBluring_6(ref object o);
            // 0x01430B3C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_72 = null;
            // 0x01430B40: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01430B44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430B48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430B4C: MOV x2, x21                | X2 = 1152921510108587440 (0x1000000147EDE5B0);//ML01
            // 0x01430B50: MOV x22, x0                | X22 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01430B54: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_motionBluring_6(ref object o));
            val_72 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_motionBluring_6(ref object o));
            // 0x01430B58: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430B5C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430B60: STR x22, [x8, #0xc8]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache19 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783634632
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache19 = val_72;
            // 0x01430B64: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430B68: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430B6C: LDR x21, [x8, #0xc8]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_94 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache19;
            label_189:
            // 0x01430B70: CBNZ x19, #0x1430b78       | if (X1 != 0) goto label_190;            
            if(val_74 != 0)
            {
                goto label_190;
            }
            // 0x01430B74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CameraHelper_Binding::get_motionBluring_6(ref object o)), ????);
            label_190:
            // 0x01430B78: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430B7C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01430B80: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x01430B84: MOV x2, x21                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01430B88: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_75, getter:  val_94);
            val_74.RegisterCLRFieldGetter(f:  val_75, getter:  val_94);
            // 0x01430B8C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430B90: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430B94: LDR x21, [x8, #0xd0]       | X21 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache1A;
            val_95 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache1A;
            // 0x01430B98: CBNZ x21, #0x1430be4       | if (ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache1A != null) goto label_191;
            if(val_95 != null)
            {
                goto label_191;
            }
            // 0x01430B9C: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x01430BA0: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01430BA4: LDR x8, [x8, #0xb50]       | X8 = 1152921510108588464;               
            // 0x01430BA8: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01430BAC: LDR x21, [x8]              | X21 = static System.Void ILRuntime.Runtime.Generated.CameraHelper_Binding::set_motionBluring_6(ref object o, object v);
            // 0x01430BB0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_73 = null;
            // 0x01430BB4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01430BB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430BBC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430BC0: MOV x2, x21                | X2 = 1152921510108588464 (0x1000000147EDE9B0);//ML01
            // 0x01430BC4: MOV x22, x0                | X22 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01430BC8: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraHelper_Binding::set_motionBluring_6(ref object o, object v));
            val_73 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraHelper_Binding::set_motionBluring_6(ref object o, object v));
            // 0x01430BCC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430BD0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430BD4: STR x22, [x8, #0xd0]       | ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache1A = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783634640
            ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache1A = val_73;
            // 0x01430BD8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CameraHelper_Binding);
            // 0x01430BDC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CameraHelper_Binding.__il2cppRuntimeField_static_fields;
            // 0x01430BE0: LDR x21, [x8, #0xd0]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_95 = ILRuntime.Runtime.Generated.CameraHelper_Binding.<>f__mg$cache1A;
            label_191:
            // 0x01430BE4: CBNZ x19, #0x1430bec       | if (X1 != 0) goto label_192;            
            if(val_74 != 0)
            {
                goto label_192;
            }
            // 0x01430BE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CameraHelper_Binding::set_motionBluring_6(ref object o, object v)), ????);
            label_192:
            // 0x01430BEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430BF0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01430BF4: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x01430BF8: MOV x2, x21                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01430BFC: SUB sp, x29, #0x50         | SP = (1152921510108601472 - 80) = 1152921510108601392 (0x1000000147EE1C30);
            // 0x01430C00: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01430C04: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01430C08: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x01430C0C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x01430C10: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x01430C14: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x01430C18: B #0x28e59c8               | X1.RegisterCLRFieldSetter(f:  val_75, setter:  val_95); return;
            val_74.RegisterCLRFieldSetter(f:  val_75, setter:  val_95);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01430C1C (21171228), len: 876  VirtAddr: 0x01430C1C RVA: 0x01430C1C token: 100664139 methodIndex: 30186 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_csf_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            // 0x01430C1C: STP x24, x23, [sp, #-0x40]! | stack[1152921510108938704] = ???;  stack[1152921510108938712] = ???;  //  dest_result_addr=1152921510108938704 |  dest_result_addr=1152921510108938712
            // 0x01430C20: STP x22, x21, [sp, #0x10]  | stack[1152921510108938720] = ???;  stack[1152921510108938728] = ???;  //  dest_result_addr=1152921510108938720 |  dest_result_addr=1152921510108938728
            // 0x01430C24: STP x20, x19, [sp, #0x20]  | stack[1152921510108938736] = ???;  stack[1152921510108938744] = ???;  //  dest_result_addr=1152921510108938736 |  dest_result_addr=1152921510108938744
            // 0x01430C28: STP x29, x30, [sp, #0x30]  | stack[1152921510108938752] = ???;  stack[1152921510108938760] = ???;  //  dest_result_addr=1152921510108938752 |  dest_result_addr=1152921510108938760
            // 0x01430C2C: ADD x29, sp, #0x30         | X29 = (1152921510108938704 + 48) = 1152921510108938752 (0x1000000147F34200);
            // 0x01430C30: SUB sp, sp, #0x20          | SP = (1152921510108938704 - 32) = 1152921510108938672 (0x1000000147F341B0);
            // 0x01430C34: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01430C38: LDRB w8, [x20, #0x2a]      | W8 = (bool)static_value_0373702A;       
            // 0x01430C3C: MOV x19, x3                | X19 = X3;//m1                           
            // 0x01430C40: MOV x22, x2                | X22 = X2;//m1                           
            // 0x01430C44: MOV x21, x1                | X21 = X1;//m1                           
            val_14 = X1;
            // 0x01430C48: TBNZ w8, #0, #0x1430c64    | if (static_value_0373702A == true) goto label_0;
            // 0x01430C4C: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x01430C50: LDR x8, [x8, #0x598]       | X8 = 0x2B9018C;                         
            // 0x01430C54: LDR w0, [x8]               | W0 = 0x1727;                            
            // 0x01430C58: BL #0x2782188              | X0 = sub_2782188( ?? 0x1727, ????);     
            // 0x01430C5C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01430C60: STRB w8, [x20, #0x2a]      | static_value_0373702A = true;            //  dest_result_addr=57897002
            label_0:
            // 0x01430C64: CBNZ x21, #0x1430c6c       | if (X1 != 0) goto label_1;              
            if(val_14 != 0)
            {
                goto label_1;
            }
            // 0x01430C68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1727, ????);     
            label_1:
            // 0x01430C6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430C70: MOV x0, x21                | X0 = X1;//m1                            
            // 0x01430C74: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = val_14.AppDomain;
            // 0x01430C78: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01430C7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01430C80: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430C84: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01430C88: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01430C8C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01430C90: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01430C94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01430C98: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430C9C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01430CA0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01430CA4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01430CA8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01430CAC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01430CB0: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
            // 0x01430CB4: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x01430CB8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01430CBC: LDR x9, [x9, #0x328]       | X9 = 1152921504887730176;               
            // 0x01430CC0: LDR x24, [x9]              | X24 = typeof(CameraHelper);             
            // 0x01430CC4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01430CC8: TBZ w9, #0, #0x1430cdc     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01430CCC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01430CD0: CBNZ w9, #0x1430cdc        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01430CD4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01430CD8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01430CDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01430CE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01430CE4: MOV x1, x24                | X1 = 1152921504887730176 (0x1000000010BDF000);//ML01
            // 0x01430CE8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01430CEC: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01430CF0: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01430CF4: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01430CF8: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01430CFC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01430D00: TBZ w9, #0, #0x1430d14     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01430D04: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01430D08: CBNZ w9, #0x1430d14        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01430D0C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01430D10: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01430D14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01430D18: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01430D1C: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x01430D20: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01430D24: MOV x3, x19                | X3 = X3;//m1                            
            // 0x01430D28: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x01430D2C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01430D30: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01430D34: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x01430D38: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01430D3C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01430D40: TBZ w9, #0, #0x1430d54     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01430D44: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01430D48: CBNZ w9, #0x1430d54        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01430D4C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01430D50: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01430D54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01430D58: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430D5C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01430D60: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x01430D64: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01430D68: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x01430D6C: CBZ x0, #0x1430dd0         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x01430D70: ADRP x9, #0x3611000        | X9 = 56692736 (0x3611000);              
            // 0x01430D74: LDR x9, [x9, #0x430]       | X9 = 1152921504887730176;               
            // 0x01430D78: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01430D7C: LDR x1, [x9]               | X1 = typeof(CameraHelper);              
            // 0x01430D80: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01430D84: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01430D88: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01430D8C: B.LO #0x1430da8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x01430D90: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01430D94: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHier
            // 0x01430D98: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01430D9C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01430DA0: MOV x23, x0                | X23 = val_6;//m1                        
            val_15 = val_6;
            // 0x01430DA4: B.EQ #0x1430dd0            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x01430DA8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01430DAC: ADD x8, sp, #8             | X8 = (1152921510108938672 + 8) = 1152921510108938680 (0x1000000147F341B8);
            // 0x01430DB0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01430DB4: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510108926768]
            // 0x01430DB8: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x01430DBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430DC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x01430DC4: ADD x0, sp, #8             | X0 = (1152921510108938672 + 8) = 1152921510108938680 (0x1000000147F341B8);
            // 0x01430DC8: BL #0x299a140              | 
            // 0x01430DCC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_10:
            // 0x01430DD0: CBNZ x21, #0x1430dd8       | if (X1 != 0) goto label_11;             
            if(val_14 != 0)
            {
                goto label_11;
            }
            // 0x01430DD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147F341B8, ????);
            label_11:
            // 0x01430DD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01430DDC: MOV x0, x21                | X0 = X1;//m1                            
            // 0x01430DE0: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x01430DE4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_14.Free(esp:  null);
            // 0x01430DE8: CBNZ x23, #0x1430df0       | if (0x0 != 0) goto label_12;            
            if(val_15 != 0)
            {
                goto label_12;
            }
            // 0x01430DEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x01430DF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430DF4: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x01430DF8: BL #0xba9af4               | X0 = val_15.get_csf();                  
            CameraSmoothFollow val_9 = val_15.csf;
            // 0x01430DFC: ADRP x23, #0x365d000       | X23 = 57004032 (0x365D000);             
            // 0x01430E00: LDR x23, [x23, #0xa58]     | X23 = 1152921504824418304;              
            val_16 = 1152921504824418304;
            // 0x01430E04: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x01430E08: LDR x1, [x23]              | X1 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_17 = null;
            // 0x01430E0C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x01430E10: CBZ x0, #0x1430ea4         | if (val_9 == null) goto label_13;       
            if(val_9 == null)
            {
                goto label_13;
            }
            // 0x01430E14: CBZ x22, #0x1430ebc        | if (val_9 == null) goto label_14;       
            if(val_9 == null)
            {
                goto label_14;
            }
            // 0x01430E18: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            // 0x01430E1C: MOV x0, x22                | X0 = val_9;//m1                         
            // 0x01430E20: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x01430E24: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x01430E28: CBNZ x0, #0x1430e5c        | if (val_9 != null) goto label_15;       
            if(val_9 != null)
            {
                goto label_15;
            }
            // 0x01430E2C: LDR x8, [x22]              | X8 = typeof(CameraSmoothFollow);        
            // 0x01430E30: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x01430E34: LDR x0, [x8, #0x30]        | X0 = CameraSmoothFollow.__il2cppRuntimeField_element_class;
            // 0x01430E38: ADD x8, sp, #0x10          | X8 = (1152921510108938672 + 16) = 1152921510108938688 (0x1000000147F341C0);
            // 0x01430E3C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? CameraSmoothFollow.__il2cppRuntimeField_element_class, ????);
            // 0x01430E40: LDR x0, [sp, #0x10]        | X0 = val_10;                             //  find_add[1152921510108926768]
            // 0x01430E44: BL #0x27af090              | X0 = sub_27AF090( ?? val_10, ????);     
            // 0x01430E48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430E4C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            // 0x01430E50: ADD x0, sp, #0x10          | X0 = (1152921510108938672 + 16) = 1152921510108938688 (0x1000000147F341C0);
            // 0x01430E54: BL #0x299a140              | 
            // 0x01430E58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147F341C0, ????);
            label_15:
            // 0x01430E5C: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_14 = null;
            // 0x01430E60: MOV x0, x22                | X0 = val_9;//m1                         
            // 0x01430E64: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_17 = val_14;
            // 0x01430E68: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x01430E6C: MOV x23, x0                | X23 = val_9;//m1                        
            val_16 = val_9;
            // 0x01430E70: CBNZ x23, #0x1430ec8       | if (val_9 != null) goto label_16;       
            if(val_16 != null)
            {
                goto label_16;
            }
            // 0x01430E74: LDR x8, [x22]              | X8 = typeof(CameraSmoothFollow);        
            // 0x01430E78: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x01430E7C: LDR x0, [x8, #0x30]        | X0 = CameraSmoothFollow.__il2cppRuntimeField_element_class;
            // 0x01430E80: ADD x8, sp, #0x18          | X8 = (1152921510108938672 + 24) = 1152921510108938696 (0x1000000147F341C8);
            // 0x01430E84: BL #0x27d96d4              | X0 = sub_27D96D4( ?? CameraSmoothFollow.__il2cppRuntimeField_element_class, ????);
            // 0x01430E88: LDR x0, [sp, #0x18]        | X0 = val_11;                             //  find_add[1152921510108926768]
            // 0x01430E8C: BL #0x27af090              | X0 = sub_27AF090( ?? val_11, ????);     
            // 0x01430E90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_17 = 0;
            // 0x01430E94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            // 0x01430E98: ADD x0, sp, #0x18          | X0 = (1152921510108938672 + 24) = 1152921510108938696 (0x1000000147F341C8);
            // 0x01430E9C: BL #0x299a140              | 
            // 0x01430EA0: B #0x1430ec4               |  goto label_17;                         
            goto label_17;
            label_13:
            // 0x01430EA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01430EA8: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x01430EAC: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x01430EB0: MOV x2, x19                | X2 = X3;//m1                            
            // 0x01430EB4: MOV x3, x22                | X3 = val_9;//m1                         
            // 0x01430EB8: B #0x1430f3c               |  goto label_18;                         
            goto label_18;
            label_14:
            // 0x01430EBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x01430EC0: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_14 = null;
            label_17:
            // 0x01430EC4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_16:
            // 0x01430EC8: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x01430ECC: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x01430ED0: CBZ x9, #0x1430efc         | if (mem[282584257676929] == 0) goto label_19;
            if(mem[282584257676929] == 0)
            {
                goto label_19;
            }
            // 0x01430ED4: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_13 = mem[282584257676823];
            // 0x01430ED8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_14 = 0;
            // 0x01430EDC: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_13 = val_13 + 8;
            label_21:
            // 0x01430EE0: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x01430EE4: CMP x12, x21               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType))
            // 0x01430EE8: B.EQ #0x1430f10            | if ((mem[282584257676823] + 8) + -8 == val_14) goto label_20;
            if(((mem[282584257676823] + 8) + -8) == val_14)
            {
                goto label_20;
            }
            // 0x01430EEC: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_14 = val_14 + 1;
            // 0x01430EF0: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_13 = val_13 + 16;
            // 0x01430EF4: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x01430EF8: B.LO #0x1430ee0            | if (0 < mem[282584257676929]) goto label_21;
            if(val_14 < mem[282584257676929])
            {
                goto label_21;
            }
            label_19:
            // 0x01430EFC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x01430F00: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_18 = val_16;
            // 0x01430F04: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_17 = val_14;
            // 0x01430F08: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x01430F0C: B #0x1430f1c               |  goto label_22;                         
            goto label_22;
            label_20:
            // 0x01430F10: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            // 0x01430F14: ADD x8, x8, x9, lsl #4     | X8 = (val_16 + ((mem[282584257676823] + 8)) << 4);
            val_16 = val_16 + (((mem[282584257676823] + 8)) << 4);
            // 0x01430F18: ADD x0, x8, #0x110         | X0 = ((val_16 + ((mem[282584257676823] + 8)) << 4) + 272);
            val_18 = val_16 + 272;
            label_22:
            // 0x01430F1C: LDP x8, x1, [x0]           | X8 = ((val_16 + ((mem[282584257676823] + 8)) << 4) + 272); X1 = ((val_16 + ((mem[282584257676823] + 8)) << 4) + 272) + 8; //  | 
            // 0x01430F20: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x01430F24: BLR x8                     | X0 = ((val_16 + ((mem[282584257676823] + 8)) << 4) + 272)();
            // 0x01430F28: MOV x3, x0                 | X3 = 0 (0x0);//ML01                     
            // 0x01430F2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01430F30: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x01430F34: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x01430F38: MOV x2, x19                | X2 = X3;//m1                            
            label_18:
            // 0x01430F3C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01430F40: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            ILRuntime.Runtime.Stack.StackObject* val_12 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            // 0x01430F44: SUB sp, x29, #0x30         | SP = (1152921510108938752 - 48) = 1152921510108938704 (0x1000000147F341D0);
            // 0x01430F48: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01430F4C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01430F50: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01430F54: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01430F58: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_12;
            return val_12;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01430F5C: MOV x19, x0                | 
            // 0x01430F60: ADD x0, sp, #8             | 
            // 0x01430F64: B #0x1430f7c               | 
            // 0x01430F68: MOV x19, x0                | 
            // 0x01430F6C: ADD x0, sp, #0x10          | 
            // 0x01430F70: B #0x1430f7c               | 
            // 0x01430F74: MOV x19, x0                | 
            // 0x01430F78: ADD x0, sp, #0x18          | 
            label_24:
            // 0x01430F7C: BL #0x299a140              | 
            // 0x01430F80: MOV x0, x19                | 
            // 0x01430F84: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01430F88 (21172104), len: 612  VirtAddr: 0x01430F88 RVA: 0x01430F88 token: 100664140 methodIndex: 30187 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_inScaler_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            bool val_14;
            //  | 
            var val_15;
            // 0x01430F88: STP x26, x25, [sp, #-0x50]! | stack[1152921510109112128] = ???;  stack[1152921510109112136] = ???;  //  dest_result_addr=1152921510109112128 |  dest_result_addr=1152921510109112136
            // 0x01430F8C: STP x24, x23, [sp, #0x10]  | stack[1152921510109112144] = ???;  stack[1152921510109112152] = ???;  //  dest_result_addr=1152921510109112144 |  dest_result_addr=1152921510109112152
            // 0x01430F90: STP x22, x21, [sp, #0x20]  | stack[1152921510109112160] = ???;  stack[1152921510109112168] = ???;  //  dest_result_addr=1152921510109112160 |  dest_result_addr=1152921510109112168
            // 0x01430F94: STP x20, x19, [sp, #0x30]  | stack[1152921510109112176] = ???;  stack[1152921510109112184] = ???;  //  dest_result_addr=1152921510109112176 |  dest_result_addr=1152921510109112184
            // 0x01430F98: STP x29, x30, [sp, #0x40]  | stack[1152921510109112192] = ???;  stack[1152921510109112200] = ???;  //  dest_result_addr=1152921510109112192 |  dest_result_addr=1152921510109112200
            // 0x01430F9C: ADD x29, sp, #0x40         | X29 = (1152921510109112128 + 64) = 1152921510109112192 (0x1000000147F5E780);
            // 0x01430FA0: SUB sp, sp, #0x10          | SP = (1152921510109112128 - 16) = 1152921510109112112 (0x1000000147F5E730);
            // 0x01430FA4: ADRP x19, #0x3737000       | X19 = 57896960 (0x3737000);             
            // 0x01430FA8: LDRB w8, [x19, #0x2b]      | W8 = (bool)static_value_0373702B;       
            // 0x01430FAC: MOV x22, x3                | X22 = X3;//m1                           
            // 0x01430FB0: MOV x21, x2                | X21 = X2;//m1                           
            // 0x01430FB4: MOV x20, x1                | X20 = X1;//m1                           
            // 0x01430FB8: TBNZ w8, #0, #0x1430fd4    | if (static_value_0373702B == true) goto label_0;
            // 0x01430FBC: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
            // 0x01430FC0: LDR x8, [x8, #0x760]       | X8 = 0x2B90198;                         
            // 0x01430FC4: LDR w0, [x8]               | W0 = 0x172A;                            
            // 0x01430FC8: BL #0x2782188              | X0 = sub_2782188( ?? 0x172A, ????);     
            // 0x01430FCC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01430FD0: STRB w8, [x19, #0x2b]      | static_value_0373702B = true;            //  dest_result_addr=57897003
            label_0:
            // 0x01430FD4: CBNZ x20, #0x1430fdc       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01430FD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x172A, ????);     
            label_1:
            // 0x01430FDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01430FE0: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01430FE4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01430FE8: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01430FEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01430FF0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01430FF4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01430FF8: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01430FFC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01431000: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x01431004: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431008: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143100C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01431010: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01431014: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01431018: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0143101C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01431020: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
            // 0x01431024: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x01431028: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0143102C: LDR x9, [x9, #0x328]       | X9 = 1152921504887730176;               
            // 0x01431030: LDR x24, [x9]              | X24 = typeof(CameraHelper);             
            // 0x01431034: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01431038: TBZ w9, #0, #0x143104c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0143103C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01431040: CBNZ w9, #0x143104c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01431044: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01431048: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0143104C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431050: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01431054: MOV x1, x24                | X1 = 1152921504887730176 (0x1000000010BDF000);//ML01
            // 0x01431058: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143105C: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x01431060: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x01431064: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01431068: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0143106C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01431070: TBZ w9, #0, #0x1431084     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01431074: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01431078: CBNZ w9, #0x1431084        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0143107C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01431080: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01431084: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431088: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143108C: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01431090: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01431094: MOV x3, x22                | X3 = X3;//m1                            
            // 0x01431098: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0143109C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x014310A0: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x014310A4: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x014310A8: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x014310AC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x014310B0: TBZ w9, #0, #0x14310c4     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x014310B4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x014310B8: CBNZ w9, #0x14310c4        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x014310BC: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x014310C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x014310C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014310C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014310CC: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x014310D0: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x014310D4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x014310D8: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x014310DC: CBZ x0, #0x1431140         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x014310E0: ADRP x9, #0x3611000        | X9 = 56692736 (0x3611000);              
            // 0x014310E4: LDR x9, [x9, #0x430]       | X9 = 1152921504887730176;               
            // 0x014310E8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x014310EC: LDR x1, [x9]               | X1 = typeof(CameraHelper);              
            // 0x014310F0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014310F4: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014310F8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014310FC: B.LO #0x1431118            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x01431100: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01431104: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHier
            // 0x01431108: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0143110C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01431110: MOV x22, x0                | X22 = val_6;//m1                        
            val_13 = val_6;
            // 0x01431114: B.EQ #0x1431140            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x01431118: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0143111C: ADD x8, sp, #8             | X8 = (1152921510109112112 + 8) = 1152921510109112120 (0x1000000147F5E738);
            // 0x01431120: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01431124: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510109100208]
            // 0x01431128: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x0143112C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01431130: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x01431134: ADD x0, sp, #8             | X0 = (1152921510109112112 + 8) = 1152921510109112120 (0x1000000147F5E738);
            // 0x01431138: BL #0x299a140              | 
            // 0x0143113C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_10:
            // 0x01431140: CBNZ x20, #0x1431148       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x01431144: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147F5E738, ????);
            label_11:
            // 0x01431148: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143114C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01431150: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01431154: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01431158: CBNZ x22, #0x1431160       | if (0x0 != 0) goto label_12;            
            if(val_13 != 0)
            {
                goto label_12;
            }
            // 0x0143115C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x01431160: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01431164: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x01431168: BL #0xba9afc               | X0 = val_13.get_inScaler();             
            bool val_9 = val_13.inScaler;
            // 0x0143116C: MOV w20, w0                | W20 = val_9;//m1                        
            // 0x01431170: CBZ x19, #0x1431184        | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x01431174: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01431178: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x0143117C: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x01431180: B #0x1431198               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x01431184: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x01431188: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143118C: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x01431190: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x01431194: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_14:
            // 0x01431198: STR w20, [x19, #4]         | mem2[0] = (val_9 & 1);                   //  dest_result_addr=0
            mem2[0] = val_14;
            // 0x0143119C: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x014311A0: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_15 = 8;
            // 0x014311A4: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x014311A8: TBZ w9, #0, #0x14311b8     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_15;
            // 0x014311AC: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x014311B0: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x014311B4: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_15 = 219381744;
            label_15:
            // 0x014311B8: ADD x0, x8, x19            | X0 = (val_15 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_15 + val_2;
            // 0x014311BC: SUB sp, x29, #0x40         | SP = (1152921510109112192 - 64) = 1152921510109112128 (0x1000000147F5E740);
            // 0x014311C0: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x014311C4: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x014311C8: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x014311CC: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x014311D0: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x014311D4: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_15 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x014311D8: MOV x19, x0                | 
            // 0x014311DC: ADD x0, sp, #8             | 
            // 0x014311E0: BL #0x299a140              | 
            // 0x014311E4: MOV x0, x19                | 
            // 0x014311E8: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x014311EC (21172716), len: 528  VirtAddr: 0x014311EC RVA: 0x014311EC token: 100664141 methodIndex: 30188 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* ScalerClear_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x014311EC: STP x24, x23, [sp, #-0x40]! | stack[1152921510109281488] = ???;  stack[1152921510109281496] = ???;  //  dest_result_addr=1152921510109281488 |  dest_result_addr=1152921510109281496
            // 0x014311F0: STP x22, x21, [sp, #0x10]  | stack[1152921510109281504] = ???;  stack[1152921510109281512] = ???;  //  dest_result_addr=1152921510109281504 |  dest_result_addr=1152921510109281512
            // 0x014311F4: STP x20, x19, [sp, #0x20]  | stack[1152921510109281520] = ???;  stack[1152921510109281528] = ???;  //  dest_result_addr=1152921510109281520 |  dest_result_addr=1152921510109281528
            // 0x014311F8: STP x29, x30, [sp, #0x30]  | stack[1152921510109281536] = ???;  stack[1152921510109281544] = ???;  //  dest_result_addr=1152921510109281536 |  dest_result_addr=1152921510109281544
            // 0x014311FC: ADD x29, sp, #0x30         | X29 = (1152921510109281488 + 48) = 1152921510109281536 (0x1000000147F87D00);
            // 0x01431200: SUB sp, sp, #0x10          | SP = (1152921510109281488 - 16) = 1152921510109281472 (0x1000000147F87CC0);
            // 0x01431204: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01431208: LDRB w8, [x20, #0x2c]      | W8 = (bool)static_value_0373702C;       
            // 0x0143120C: MOV x22, x3                | X22 = X3;//m1                           
            // 0x01431210: MOV x21, x2                | X21 = X2;//m1                           
            // 0x01431214: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01431218: TBNZ w8, #0, #0x1431234    | if (static_value_0373702C == true) goto label_0;
            // 0x0143121C: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
            // 0x01431220: LDR x8, [x8, #0x530]       | X8 = 0x2B901C8;                         
            // 0x01431224: LDR w0, [x8]               | W0 = 0x1736;                            
            // 0x01431228: BL #0x2782188              | X0 = sub_2782188( ?? 0x1736, ????);     
            // 0x0143122C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01431230: STRB w8, [x20, #0x2c]      | static_value_0373702C = true;            //  dest_result_addr=57897004
            label_0:
            // 0x01431234: CBNZ x19, #0x143123c       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01431238: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1736, ????);     
            label_1:
            // 0x0143123C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01431240: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01431244: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01431248: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0143124C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431250: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01431254: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01431258: MOV x1, x21                | X1 = X2;//m1                            
            // 0x0143125C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01431260: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01431264: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431268: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143126C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01431270: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01431274: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01431278: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0143127C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01431280: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
            // 0x01431284: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x01431288: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0143128C: LDR x9, [x9, #0x328]       | X9 = 1152921504887730176;               
            // 0x01431290: LDR x24, [x9]              | X24 = typeof(CameraHelper);             
            // 0x01431294: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01431298: TBZ w9, #0, #0x14312ac     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0143129C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x014312A0: CBNZ w9, #0x14312ac        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x014312A4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x014312A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x014312AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014312B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014312B4: MOV x1, x24                | X1 = 1152921504887730176 (0x1000000010BDF000);//ML01
            // 0x014312B8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x014312BC: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x014312C0: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x014312C4: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x014312C8: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x014312CC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x014312D0: TBZ w9, #0, #0x14312e4     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x014312D4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x014312D8: CBNZ w9, #0x14312e4        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x014312DC: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x014312E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x014312E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014312E8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x014312EC: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x014312F0: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x014312F4: MOV x3, x22                | X3 = X3;//m1                            
            // 0x014312F8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x014312FC: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01431300: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01431304: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x01431308: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0143130C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01431310: TBZ w9, #0, #0x1431324     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01431314: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01431318: CBNZ w9, #0x1431324        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0143131C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01431320: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01431324: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431328: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143132C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01431330: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x01431334: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01431338: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x0143133C: CBZ x0, #0x14313a0         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x01431340: ADRP x9, #0x3611000        | X9 = 56692736 (0x3611000);              
            // 0x01431344: LDR x9, [x9, #0x430]       | X9 = 1152921504887730176;               
            // 0x01431348: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0143134C: LDR x1, [x9]               | X1 = typeof(CameraHelper);              
            // 0x01431350: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01431354: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01431358: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0143135C: B.LO #0x1431378            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x01431360: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01431364: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHier
            // 0x01431368: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0143136C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01431370: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x01431374: B.EQ #0x14313a0            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x01431378: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0143137C: ADD x8, sp, #8             | X8 = (1152921510109281472 + 8) = 1152921510109281480 (0x1000000147F87CC8);
            // 0x01431380: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01431384: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510109269552]
            // 0x01431388: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x0143138C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01431390: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x01431394: ADD x0, sp, #8             | X0 = (1152921510109281472 + 8) = 1152921510109281480 (0x1000000147F87CC8);
            // 0x01431398: BL #0x299a140              | 
            // 0x0143139C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x014313A0: CBNZ x19, #0x14313a8       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x014313A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147F87CC8, ????);
            label_11:
            // 0x014313A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014313AC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014313B0: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x014313B4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x014313B8: CBNZ x22, #0x14313c0       | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x014313BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x014313C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014313C4: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x014313C8: BL #0xbaa4f8               | val_9.ScalerClear();                    
            val_9.ScalerClear();
            // 0x014313CC: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x014313D0: SUB sp, x29, #0x30         | SP = (1152921510109281536 - 48) = 1152921510109281488 (0x1000000147F87CD0);
            // 0x014313D4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x014313D8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x014313DC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x014313E0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x014313E4: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x014313E8: MOV x19, x0                | 
            // 0x014313EC: ADD x0, sp, #8             | 
            // 0x014313F0: BL #0x299a140              | 
            // 0x014313F4: MOV x0, x19                | 
            // 0x014313F8: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x014313FC (21173244), len: 1160  VirtAddr: 0x014313FC RVA: 0x014313FC token: 100664142 methodIndex: 30189 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Scaler_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_15;
            //  | 
            var val_21;
            //  | 
            UnityEngine.Transform val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            //  | 
            var val_25;
            // 0x014313FC: STP d13, d12, [sp, #-0x80]! | stack[1152921510109479440] = ???;  stack[1152921510109479448] = ???;  //  dest_result_addr=1152921510109479440 |  dest_result_addr=1152921510109479448
            // 0x01431400: STP d11, d10, [sp, #0x10]  | stack[1152921510109479456] = ???;  stack[1152921510109479464] = ???;  //  dest_result_addr=1152921510109479456 |  dest_result_addr=1152921510109479464
            // 0x01431404: STP d9, d8, [sp, #0x20]    | stack[1152921510109479472] = ???;  stack[1152921510109479480] = ???;  //  dest_result_addr=1152921510109479472 |  dest_result_addr=1152921510109479480
            // 0x01431408: STP x26, x25, [sp, #0x30]  | stack[1152921510109479488] = ???;  stack[1152921510109479496] = ???;  //  dest_result_addr=1152921510109479488 |  dest_result_addr=1152921510109479496
            // 0x0143140C: STP x24, x23, [sp, #0x40]  | stack[1152921510109479504] = ???;  stack[1152921510109479512] = ???;  //  dest_result_addr=1152921510109479504 |  dest_result_addr=1152921510109479512
            // 0x01431410: STP x22, x21, [sp, #0x50]  | stack[1152921510109479520] = ???;  stack[1152921510109479528] = ???;  //  dest_result_addr=1152921510109479520 |  dest_result_addr=1152921510109479528
            // 0x01431414: STP x20, x19, [sp, #0x60]  | stack[1152921510109479536] = ???;  stack[1152921510109479544] = ???;  //  dest_result_addr=1152921510109479536 |  dest_result_addr=1152921510109479544
            // 0x01431418: STP x29, x30, [sp, #0x70]  | stack[1152921510109479552] = ???;  stack[1152921510109479560] = ???;  //  dest_result_addr=1152921510109479552 |  dest_result_addr=1152921510109479560
            // 0x0143141C: ADD x29, sp, #0x70         | X29 = (1152921510109479440 + 112) = 1152921510109479552 (0x1000000147FB8280);
            // 0x01431420: SUB sp, sp, #0x20          | SP = (1152921510109479440 - 32) = 1152921510109479408 (0x1000000147FB81F0);
            // 0x01431424: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01431428: LDRB w8, [x20, #0x2d]      | W8 = (bool)static_value_0373702D;       
            // 0x0143142C: MOV x21, x3                | X21 = X3;//m1                           
            // 0x01431430: MOV x22, x2                | X22 = X2;//m1                           
            // 0x01431434: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01431438: TBNZ w8, #0, #0x1431454    | if (static_value_0373702D == true) goto label_0;
            // 0x0143143C: ADRP x8, #0x365c000        | X8 = 56999936 (0x365C000);              
            // 0x01431440: LDR x8, [x8, #0xc70]       | X8 = 0x2B901C4;                         
            // 0x01431444: LDR w0, [x8]               | W0 = 0x1735;                            
            // 0x01431448: BL #0x2782188              | X0 = sub_2782188( ?? 0x1735, ????);     
            // 0x0143144C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01431450: STRB w8, [x20, #0x2d]      | static_value_0373702D = true;            //  dest_result_addr=57897005
            label_0:
            // 0x01431454: CBNZ x19, #0x143145c       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01431458: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1735, ????);     
            label_1:
            // 0x0143145C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01431460: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01431464: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01431468: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0143146C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431470: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01431474: ORR w2, wzr, #6            | W2 = 6(0x6);                            
            // 0x01431478: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0143147C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01431480: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01431484: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431488: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143148C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01431490: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01431494: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01431498: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0143149C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x014314A0: ADRP x9, #0x3635000        | X9 = 56840192 (0x3635000);              
            // 0x014314A4: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x014314A8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x014314AC: LDR x9, [x9, #0xef0]       | X9 = 1152921504695078912;               
            // 0x014314B0: LDR x25, [x9]              | X25 = typeof(UnityEngine.Vector3);      
            // 0x014314B4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x014314B8: TBZ w9, #0, #0x14314cc     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x014314BC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x014314C0: CBNZ w9, #0x14314cc        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x014314C4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x014314C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x014314CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014314D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014314D4: MOV x1, x25                | X1 = 1152921504695078912 (0x1000000005425000);//ML01
            // 0x014314D8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x014314DC: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x014314E0: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x014314E4: MOV x25, x0                | X25 = val_4;//m1                        
            // 0x014314E8: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x014314EC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x014314F0: TBZ w9, #0, #0x1431504     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x014314F4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x014314F8: CBNZ w9, #0x1431504        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x014314FC: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01431500: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01431504: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431508: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143150C: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x01431510: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01431514: MOV x3, x21                | X3 = X3;//m1                            
            // 0x01431518: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x0143151C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01431520: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01431524: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x01431528: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0143152C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01431530: TBZ w9, #0, #0x1431544     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01431534: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01431538: CBNZ w9, #0x1431544        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0143153C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01431540: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01431544: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431548: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143154C: MOV x1, x25                | X1 = val_4;//m1                         
            // 0x01431550: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x01431554: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01431558: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x0143155C: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x01431560: MOV x26, x0                | X26 = val_6;//m1                        
            // 0x01431564: LDR x25, [x8]              | X25 = typeof(UnityEngine.Vector3);      
            // 0x01431568: CBNZ x26, #0x1431570       | if (val_6 != null) goto label_8;        
            if(val_6 != null)
            {
                goto label_8;
            }
            // 0x0143156C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_8:
            // 0x01431570: LDR x8, [x26]              | X8 = typeof(System.Object);             
            // 0x01431574: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01431578: LDR x8, [x25, #0x30]       | X8 = UnityEngine.Vector3.__il2cppRuntimeField_element_class;
            // 0x0143157C: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, UnityEngine.Vector3.__il2cppRuntimeField_element_class)
            // 0x01431580: B.NE #0x1431854            | if (System.Object.__il2cppRuntimeField_element_class != UnityEngine.Vector3.__il2cppRuntimeField_element_class) goto label_9;
            // 0x01431584: MOV x0, x26                | X0 = val_6;//m1                         
            // 0x01431588: BL #0x27bc4e8              | val_6.System.IDisposable.Dispose();     
            val_6.System.IDisposable.Dispose();
            // 0x0143158C: LDP s8, s9, [x0]           | S8 = typeof(System.Object);              //  | 
            // 0x01431590: LDR s10, [x0, #8]          | 
            // 0x01431594: CBNZ x19, #0x143159c       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x01431598: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_10:
            // 0x0143159C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014315A0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014315A4: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x014315A8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x014315AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014315B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014315B4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x014315B8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x014315BC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_7 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014315C0: MOV x24, x0                | X24 = val_7;//m1                        
            // 0x014315C4: CBNZ x24, #0x14315cc       | if (val_7 != 0) goto label_11;          
            if(val_7 != 0)
            {
                goto label_11;
            }
            // 0x014315C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_11:
            // 0x014315CC: LDR s11, [x24, #4]         | S11 = val_7 + 4;                        
            // 0x014315D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014315D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014315D8: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x014315DC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x014315E0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014315E4: MOV x24, x0                | X24 = val_8;//m1                        
            // 0x014315E8: CBNZ x24, #0x14315f0       | if (val_8 != 0) goto label_12;          
            if(val_8 != 0)
            {
                goto label_12;
            }
            // 0x014315EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_12:
            // 0x014315F0: LDR s12, [x24, #4]         | S12 = val_8 + 4;                        
            // 0x014315F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014315F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014315FC: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x01431600: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01431604: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01431608: MOV x24, x0                | X24 = val_9;//m1                        
            // 0x0143160C: CBNZ x24, #0x1431614       | if (val_9 != 0) goto label_13;          
            if(val_9 != 0)
            {
                goto label_13;
            }
            // 0x01431610: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_13:
            // 0x01431614: LDR s13, [x24, #4]         | S13 = val_9 + 4;                        
            // 0x01431618: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143161C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01431620: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x01431624: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01431628: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_10 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143162C: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x01431630: LDR x8, [x8, #0x8b8]       | X8 = 1152921504698060800;               
            // 0x01431634: MOV x25, x0                | X25 = val_10;//m1                       
            // 0x01431638: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143163C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01431640: LDR x1, [x8]               | X1 = typeof(UnityEngine.Transform);     
            // 0x01431644: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_11 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01431648: MOV x24, x0                | X24 = val_11;//m1                       
            // 0x0143164C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431650: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01431654: MOV x1, x25                | X1 = val_10;//m1                        
            // 0x01431658: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0143165C: MOV x3, x21                | X3 = X3;//m1                            
            // 0x01431660: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_12 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x01431664: MOV x2, x0                 | X2 = val_12;//m1                        
            // 0x01431668: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143166C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01431670: MOV x1, x24                | X1 = val_11;//m1                        
            // 0x01431674: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_11);
            object val_13 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_11);
            // 0x01431678: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x0143167C: CBZ x0, #0x14316e0         | if (val_13 == null) goto label_16;      
            if(val_13 == null)
            {
                goto label_16;
            }
            // 0x01431680: ADRP x9, #0x35e5000        | X9 = 56512512 (0x35E5000);              
            // 0x01431684: LDR x9, [x9, #0xe58]       | X9 = 1152921504698060800;               
            // 0x01431688: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0143168C: LDR x1, [x9]               | X1 = typeof(UnityEngine.Transform);     
            // 0x01431690: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01431694: LDRB w9, [x1, #0x104]      | W9 = UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01431698: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0143169C: B.LO #0x14316b8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) goto label_15;
            // 0x014316A0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x014316A4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Transform.__il2cppRuntimeField
            // 0x014316A8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014316AC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(UnityEngine.Transform))
            // 0x014316B0: MOV x24, x0                | X24 = val_13;//m1                       
            val_22 = val_13;
            // 0x014316B4: B.EQ #0x14316e0            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_16;
            label_15:
            // 0x014316B8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x014316BC: ADD x8, sp, #0x10          | X8 = (1152921510109479408 + 16) = 1152921510109479424 (0x1000000147FB8200);
            // 0x014316C0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x014316C4: LDR x0, [sp, #0x10]        | X0 = val_15;                             //  find_add[1152921510109467568]
            // 0x014316C8: BL #0x27af090              | X0 = sub_27AF090( ?? val_15, ????);     
            // 0x014316CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014316D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            // 0x014316D4: ADD x0, sp, #0x10          | X0 = (1152921510109479408 + 16) = 1152921510109479424 (0x1000000147FB8200);
            // 0x014316D8: BL #0x299a140              | 
            // 0x014316DC: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_22 = 0;
            label_16:
            // 0x014316E0: CBNZ x19, #0x14316e8       | if (X1 != 0) goto label_17;             
            if(X1 != 0)
            {
                goto label_17;
            }
            // 0x014316E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147FB8200, ????);
            label_17:
            // 0x014316E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014316EC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014316F0: MOV x1, x25                | X1 = val_10;//m1                        
            // 0x014316F4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x014316F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014316FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01431700: ORR w2, wzr, #6            | W2 = 6(0x6);                            
            // 0x01431704: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01431708: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_16 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143170C: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x01431710: LDR x8, [x8, #0x328]       | X8 = 1152921504887730176;               
            // 0x01431714: MOV x22, x0                | X22 = val_16;//m1                       
            // 0x01431718: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143171C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01431720: LDR x1, [x8]               | X1 = typeof(CameraHelper);              
            // 0x01431724: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_17 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01431728: MOV x25, x0                | X25 = val_17;//m1                       
            // 0x0143172C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431730: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01431734: MOV x1, x22                | X1 = val_16;//m1                        
            // 0x01431738: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0143173C: MOV x3, x21                | X3 = X3;//m1                            
            // 0x01431740: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_18 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x01431744: MOV x2, x0                 | X2 = val_18;//m1                        
            // 0x01431748: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143174C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01431750: MOV x1, x25                | X1 = val_17;//m1                        
            // 0x01431754: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_17);
            object val_19 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_17);
            // 0x01431758: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_23 = 0;
            // 0x0143175C: CBZ x0, #0x14317c0         | if (val_19 == null) goto label_20;      
            if(val_19 == null)
            {
                goto label_20;
            }
            // 0x01431760: ADRP x9, #0x3611000        | X9 = 56692736 (0x3611000);              
            // 0x01431764: LDR x9, [x9, #0x430]       | X9 = 1152921504887730176;               
            // 0x01431768: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0143176C: LDR x1, [x9]               | X1 = typeof(CameraHelper);              
            // 0x01431770: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01431774: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01431778: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0143177C: B.LO #0x1431798            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_19;
            // 0x01431780: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01431784: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHier
            // 0x01431788: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0143178C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01431790: MOV x21, x0                | X21 = val_19;//m1                       
            val_23 = val_19;
            // 0x01431794: B.EQ #0x14317c0            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_20;
            label_19:
            // 0x01431798: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0143179C: ADD x8, sp, #0x18          | X8 = (1152921510109479408 + 24) = 1152921510109479432 (0x1000000147FB8208);
            // 0x014317A0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x014317A4: LDR x0, [sp, #0x18]        | X0 = val_21;                             //  find_add[1152921510109467568]
            // 0x014317A8: BL #0x27af090              | X0 = sub_27AF090( ?? val_21, ????);     
            // 0x014317AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014317B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_21, ????);     
            // 0x014317B4: ADD x0, sp, #0x18          | X0 = (1152921510109479408 + 24) = 1152921510109479432 (0x1000000147FB8208);
            // 0x014317B8: BL #0x299a140              | 
            // 0x014317BC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_23 = 0;
            label_20:
            // 0x014317C0: CBNZ x19, #0x14317c8       | if (X1 != 0) goto label_21;             
            if(X1 != 0)
            {
                goto label_21;
            }
            // 0x014317C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147FB8208, ????);
            label_21:
            // 0x014317C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014317CC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014317D0: MOV x1, x22                | X1 = val_16;//m1                        
            // 0x014317D4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x014317D8: CBNZ x21, #0x14317e0       | if (0x0 != 0) goto label_22;            
            if(val_23 != 0)
            {
                goto label_22;
            }
            // 0x014317DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_22:
            // 0x014317E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014317E4: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x014317E8: MOV x1, x24                | X1 = 0 (0x0);//ML01                     
            // 0x014317EC: MOV v0.16b, v13.16b        | V0 = val_9 + 4;//m1                     
            // 0x014317F0: MOV v1.16b, v12.16b        | V1 = val_8 + 4;//m1                     
            // 0x014317F4: MOV v2.16b, v11.16b        | V2 = val_7 + 4;//m1                     
            // 0x014317F8: MOV v3.16b, v8.16b         | V3 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x014317FC: MOV v4.16b, v9.16b         | V4 = V9.16B;//m1                        
            // 0x01431800: MOV v5.16b, v10.16b        | V5 = V10.16B;//m1                       
            // 0x01431804: BL #0xbaa89c               | val_23.Scaler(target:  val_22, zoomInTime:  val_9 + 4, waitTime:  val_8 + 4, zoomOutTime:  val_7 + 4, zoominoffset:  new UnityEngine.Vector3() {x = 7.461634E-41f, y = V9.16B, z = V10.16B});
            val_23.Scaler(target:  val_22, zoomInTime:  val_9 + 4, waitTime:  val_8 + 4, zoomOutTime:  val_7 + 4, zoominoffset:  new UnityEngine.Vector3() {x = 7.461634E-41f, y = V9.16B, z = V10.16B});
            // 0x01431808: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0143180C: SUB sp, x29, #0x70         | SP = (1152921510109479552 - 112) = 1152921510109479440 (0x1000000147FB8210);
            // 0x01431810: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
            // 0x01431814: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
            // 0x01431818: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
            // 0x0143181C: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
            // 0x01431820: LDP x26, x25, [sp, #0x30]  | X26 = ; X25 = ;                          //  | 
            // 0x01431824: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
            // 0x01431828: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
            // 0x0143182C: LDP d13, d12, [sp], #0x80  | D13 = ; D12 = ;                          //  | 
            // 0x01431830: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01431834: MOV x19, x0                | X19 = val_2;//m1                        
            val_24 = val_2;
            // 0x01431838: ADD x0, sp, #0x10          | X0 = (1152921510109479568 + 16) = 1152921510109479584 (0x1000000147FB82A0);
            // 0x0143183C: B #0x1431848               |  goto label_24;                         
            goto label_24;
            // 0x01431840: MOV x19, x0                | X19 = 1152921510109479584 (0x1000000147FB82A0);//ML01
            val_24;
            // 0x01431844: ADD x0, sp, #0x18          | X0 = (1152921510109479568 + 24) = 1152921510109479592 (0x1000000147FB82A8);
            label_24:
            // 0x01431848: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)typeof(System.Boolean));
            // 0x0143184C: MOV x0, x19                | X0 = 1152921510109479584 (0x1000000147FB82A0);//ML01
            // 0x01431850: BL #0x980800               | X0 = sub_980800( ?? 0x1000000147FB82A0, ????);
            label_9:
            // 0x01431854: ADD x8, sp, #8             | X8 = (1152921510109479568 + 8) = 1152921510109479576 (0x1000000147FB8298);
            // 0x01431858: MOV x1, x25                | X1 = X25;//m1                           
            // 0x0143185C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000147FB82A0, ????);
            // 0x01431860: LDR x0, [sp, #8]           | X0 = __mStack;                          
            // 0x01431864: BL #0x27af090              | X0 = sub_27AF090( ?? __mStack, ????);   
            // 0x01431868: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143186C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? __mStack, ????);   
            // 0x01431870: ADD x0, sp, #8             | X0 = (1152921510109479568 + 8) = 1152921510109479576 (0x1000000147FB8298);
            // 0x01431874: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x1000000147FB8298); //ERROR_TYPE
            // 0x01431878: MOV x19, x0                | X19 = 1152921510109479576 (0x1000000147FB8298);//ML01
            // 0x0143187C: ADD x0, sp, #8             | X0 = (1152921510109479568 + 8) = 1152921510109479576 (0x1000000147FB8298);
            // 0x01431880: B #0x1431848               |  goto label_24;                         
            goto label_24;
        
        }
        //
        // Offset in libil2cpp.so: 0x01431884 (21174404), len: 824  VirtAddr: 0x01431884 RVA: 0x01431884 token: 100664143 methodIndex: 30190 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* MotionBlur_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_15;
            //  | 
            UnityEngine.Transform val_16;
            //  | 
            var val_17;
            // 0x01431884: STP d9, d8, [sp, #-0x60]!  | stack[1152921510109689776] = ???;  stack[1152921510109689784] = ???;  //  dest_result_addr=1152921510109689776 |  dest_result_addr=1152921510109689784
            // 0x01431888: STP x26, x25, [sp, #0x10]  | stack[1152921510109689792] = ???;  stack[1152921510109689800] = ???;  //  dest_result_addr=1152921510109689792 |  dest_result_addr=1152921510109689800
            // 0x0143188C: STP x24, x23, [sp, #0x20]  | stack[1152921510109689808] = ???;  stack[1152921510109689816] = ???;  //  dest_result_addr=1152921510109689808 |  dest_result_addr=1152921510109689816
            // 0x01431890: STP x22, x21, [sp, #0x30]  | stack[1152921510109689824] = ???;  stack[1152921510109689832] = ???;  //  dest_result_addr=1152921510109689824 |  dest_result_addr=1152921510109689832
            // 0x01431894: STP x20, x19, [sp, #0x40]  | stack[1152921510109689840] = ???;  stack[1152921510109689848] = ???;  //  dest_result_addr=1152921510109689840 |  dest_result_addr=1152921510109689848
            // 0x01431898: STP x29, x30, [sp, #0x50]  | stack[1152921510109689856] = ???;  stack[1152921510109689864] = ???;  //  dest_result_addr=1152921510109689856 |  dest_result_addr=1152921510109689864
            // 0x0143189C: ADD x29, sp, #0x50         | X29 = (1152921510109689776 + 80) = 1152921510109689856 (0x1000000147FEB800);
            // 0x014318A0: SUB sp, sp, #0x10          | SP = (1152921510109689776 - 16) = 1152921510109689760 (0x1000000147FEB7A0);
            // 0x014318A4: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x014318A8: LDRB w8, [x20, #0x2e]      | W8 = (bool)static_value_0373702E;       
            // 0x014318AC: MOV x21, x3                | X21 = X3;//m1                           
            // 0x014318B0: MOV x22, x2                | X22 = X2;//m1                           
            // 0x014318B4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x014318B8: TBNZ w8, #0, #0x14318d4    | if (static_value_0373702E == true) goto label_0;
            // 0x014318BC: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x014318C0: LDR x8, [x8, #0xe20]       | X8 = 0x2B901B4;                         
            // 0x014318C4: LDR w0, [x8]               | W0 = 0x1731;                            
            // 0x014318C8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1731, ????);     
            // 0x014318CC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x014318D0: STRB w8, [x20, #0x2e]      | static_value_0373702E = true;            //  dest_result_addr=57897006
            label_0:
            // 0x014318D4: CBNZ x19, #0x14318dc       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x014318D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1731, ????);     
            label_1:
            // 0x014318DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014318E0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014318E4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x014318E8: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x014318EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014318F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014318F4: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x014318F8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x014318FC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01431900: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01431904: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431908: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143190C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01431910: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01431914: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01431918: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x0143191C: CBNZ x24, #0x1431924       | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x01431920: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x01431924: LDR s8, [x24, #4]          | S8 = val_3 + 4;                         
            // 0x01431928: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143192C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01431930: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01431934: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01431938: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143193C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01431940: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01431944: ADRP x9, #0x3630000        | X9 = 56819712 (0x3630000);              
            // 0x01431948: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x0143194C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01431950: LDR x9, [x9, #0x8b8]       | X9 = 1152921504698060800;               
            // 0x01431954: LDR x25, [x9]              | X25 = typeof(UnityEngine.Transform);    
            // 0x01431958: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0143195C: TBZ w9, #0, #0x1431970     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x01431960: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01431964: CBNZ w9, #0x1431970        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x01431968: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0143196C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x01431970: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431974: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01431978: MOV x1, x25                | X1 = 1152921504698060800 (0x10000000056FD000);//ML01
            // 0x0143197C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01431980: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01431984: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01431988: MOV x25, x0                | X25 = val_5;//m1                        
            // 0x0143198C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01431990: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01431994: TBZ w9, #0, #0x14319a8     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x01431998: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0143199C: CBNZ w9, #0x14319a8        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x014319A0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x014319A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x014319A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014319AC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x014319B0: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x014319B4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x014319B8: MOV x3, x21                | X3 = X3;//m1                            
            // 0x014319BC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x014319C0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x014319C4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x014319C8: MOV x26, x0                | X26 = val_6;//m1                        
            // 0x014319CC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x014319D0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x014319D4: TBZ w9, #0, #0x14319e8     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x014319D8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x014319DC: CBNZ w9, #0x14319e8        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x014319E0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x014319E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x014319E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014319EC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014319F0: MOV x1, x25                | X1 = val_5;//m1                         
            // 0x014319F4: MOV x2, x26                | X2 = val_6;//m1                         
            // 0x014319F8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x014319FC: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x01431A00: CBZ x0, #0x1431a64         | if (val_7 == null) goto label_11;       
            if(val_7 == null)
            {
                goto label_11;
            }
            // 0x01431A04: ADRP x9, #0x35e5000        | X9 = 56512512 (0x35E5000);              
            // 0x01431A08: LDR x9, [x9, #0xe58]       | X9 = 1152921504698060800;               
            // 0x01431A0C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01431A10: LDR x1, [x9]               | X1 = typeof(UnityEngine.Transform);     
            // 0x01431A14: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01431A18: LDRB w9, [x1, #0x104]      | W9 = UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01431A1C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01431A20: B.LO #0x1431a3c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x01431A24: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01431A28: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Transform.__il2cppRuntimeField
            // 0x01431A2C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01431A30: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(UnityEngine.Transform))
            // 0x01431A34: MOV x25, x0                | X25 = val_7;//m1                        
            val_16 = val_7;
            // 0x01431A38: B.EQ #0x1431a64            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x01431A3C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01431A40: MOV x8, sp                 | X8 = 1152921510109689760 (0x1000000147FEB7A0);//ML01
            // 0x01431A44: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01431A48: LDR x0, [sp]               | X0 = val_9;                              //  find_add[1152921510109677872]
            // 0x01431A4C: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x01431A50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01431A54: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x01431A58: MOV x0, sp                 | X0 = 1152921510109689760 (0x1000000147FEB7A0);//ML01
            // 0x01431A5C: BL #0x299a140              | 
            // 0x01431A60: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_11:
            // 0x01431A64: CBNZ x19, #0x1431a6c       | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x01431A68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147FEB7A0, ????);
            label_12:
            // 0x01431A6C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01431A70: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01431A74: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01431A78: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01431A7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431A80: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01431A84: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x01431A88: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01431A8C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_10 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01431A90: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x01431A94: LDR x8, [x8, #0x328]       | X8 = 1152921504887730176;               
            // 0x01431A98: MOV x22, x0                | X22 = val_10;//m1                       
            // 0x01431A9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431AA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01431AA4: LDR x1, [x8]               | X1 = typeof(CameraHelper);              
            // 0x01431AA8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_11 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01431AAC: MOV x24, x0                | X24 = val_11;//m1                       
            // 0x01431AB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431AB4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01431AB8: MOV x1, x22                | X1 = val_10;//m1                        
            // 0x01431ABC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01431AC0: MOV x3, x21                | X3 = X3;//m1                            
            // 0x01431AC4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_12 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01431AC8: MOV x2, x0                 | X2 = val_12;//m1                        
            // 0x01431ACC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431AD0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01431AD4: MOV x1, x24                | X1 = val_11;//m1                        
            // 0x01431AD8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_11);
            object val_13 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_11);
            // 0x01431ADC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x01431AE0: CBZ x0, #0x1431b44         | if (val_13 == null) goto label_15;      
            if(val_13 == null)
            {
                goto label_15;
            }
            // 0x01431AE4: ADRP x9, #0x3611000        | X9 = 56692736 (0x3611000);              
            // 0x01431AE8: LDR x9, [x9, #0x430]       | X9 = 1152921504887730176;               
            // 0x01431AEC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01431AF0: LDR x1, [x9]               | X1 = typeof(CameraHelper);              
            // 0x01431AF4: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01431AF8: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01431AFC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01431B00: B.LO #0x1431b1c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_14;
            // 0x01431B04: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01431B08: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHier
            // 0x01431B0C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01431B10: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01431B14: MOV x21, x0                | X21 = val_13;//m1                       
            val_17 = val_13;
            // 0x01431B18: B.EQ #0x1431b44            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_15;
            label_14:
            // 0x01431B1C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01431B20: ADD x8, sp, #8             | X8 = (1152921510109689760 + 8) = 1152921510109689768 (0x1000000147FEB7A8);
            // 0x01431B24: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01431B28: LDR x0, [sp, #8]           | X0 = val_15;                             //  find_add[1152921510109677872]
            // 0x01431B2C: BL #0x27af090              | X0 = sub_27AF090( ?? val_15, ????);     
            // 0x01431B30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01431B34: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            // 0x01431B38: ADD x0, sp, #8             | X0 = (1152921510109689760 + 8) = 1152921510109689768 (0x1000000147FEB7A8);
            // 0x01431B3C: BL #0x299a140              | 
            // 0x01431B40: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_17 = 0;
            label_15:
            // 0x01431B44: CBNZ x19, #0x1431b4c       | if (X1 != 0) goto label_16;             
            if(X1 != 0)
            {
                goto label_16;
            }
            // 0x01431B48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147FEB7A8, ????);
            label_16:
            // 0x01431B4C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01431B50: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01431B54: MOV x1, x22                | X1 = val_10;//m1                        
            // 0x01431B58: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01431B5C: CBNZ x21, #0x1431b64       | if (0x0 != 0) goto label_17;            
            if(val_17 != 0)
            {
                goto label_17;
            }
            // 0x01431B60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_17:
            // 0x01431B64: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01431B68: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x01431B6C: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            // 0x01431B70: MOV v0.16b, v8.16b         | V0 = val_3 + 4;//m1                     
            // 0x01431B74: BL #0xbab070               | val_17.MotionBlur(target:  val_16, distance:  val_3 + 4);
            val_17.MotionBlur(target:  val_16, distance:  val_3 + 4);
            // 0x01431B78: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01431B7C: SUB sp, x29, #0x50         | SP = (1152921510109689856 - 80) = 1152921510109689776 (0x1000000147FEB7B0);
            // 0x01431B80: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01431B84: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01431B88: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x01431B8C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x01431B90: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x01431B94: LDP d9, d8, [sp], #0x60    | D9 = ; D8 = ;                            //  | 
            // 0x01431B98: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01431B9C: MOV x19, x0                | 
            // 0x01431BA0: MOV x0, sp                 | 
            // 0x01431BA4: B #0x1431bb0               | 
            // 0x01431BA8: MOV x19, x0                | 
            // 0x01431BAC: ADD x0, sp, #8             | 
            label_18:
            // 0x01431BB0: BL #0x299a140              | 
            // 0x01431BB4: MOV x0, x19                | 
            // 0x01431BB8: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01431BBC (21175228), len: 528  VirtAddr: 0x01431BBC RVA: 0x01431BBC token: 100664144 methodIndex: 30191 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* PlayTeamSkillCamera_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x01431BBC: STP x24, x23, [sp, #-0x40]! | stack[1152921510109871440] = ???;  stack[1152921510109871448] = ???;  //  dest_result_addr=1152921510109871440 |  dest_result_addr=1152921510109871448
            // 0x01431BC0: STP x22, x21, [sp, #0x10]  | stack[1152921510109871456] = ???;  stack[1152921510109871464] = ???;  //  dest_result_addr=1152921510109871456 |  dest_result_addr=1152921510109871464
            // 0x01431BC4: STP x20, x19, [sp, #0x20]  | stack[1152921510109871472] = ???;  stack[1152921510109871480] = ???;  //  dest_result_addr=1152921510109871472 |  dest_result_addr=1152921510109871480
            // 0x01431BC8: STP x29, x30, [sp, #0x30]  | stack[1152921510109871488] = ???;  stack[1152921510109871496] = ???;  //  dest_result_addr=1152921510109871488 |  dest_result_addr=1152921510109871496
            // 0x01431BCC: ADD x29, sp, #0x30         | X29 = (1152921510109871440 + 48) = 1152921510109871488 (0x1000000148017D80);
            // 0x01431BD0: SUB sp, sp, #0x10          | SP = (1152921510109871440 - 16) = 1152921510109871424 (0x1000000148017D40);
            // 0x01431BD4: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01431BD8: LDRB w8, [x20, #0x2f]      | W8 = (bool)static_value_0373702F;       
            // 0x01431BDC: MOV x22, x3                | X22 = X3;//m1                           
            // 0x01431BE0: MOV x21, x2                | X21 = X2;//m1                           
            // 0x01431BE4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01431BE8: TBNZ w8, #0, #0x1431c04    | if (static_value_0373702F == true) goto label_0;
            // 0x01431BEC: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
            // 0x01431BF0: LDR x8, [x8, #0x8b0]       | X8 = 0x2B901BC;                         
            // 0x01431BF4: LDR w0, [x8]               | W0 = 0x1733;                            
            // 0x01431BF8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1733, ????);     
            // 0x01431BFC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01431C00: STRB w8, [x20, #0x2f]      | static_value_0373702F = true;            //  dest_result_addr=57897007
            label_0:
            // 0x01431C04: CBNZ x19, #0x1431c0c       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01431C08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1733, ????);     
            label_1:
            // 0x01431C0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01431C10: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01431C14: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01431C18: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01431C1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431C20: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01431C24: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01431C28: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01431C2C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01431C30: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01431C34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431C38: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01431C3C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01431C40: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01431C44: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01431C48: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01431C4C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01431C50: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
            // 0x01431C54: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x01431C58: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01431C5C: LDR x9, [x9, #0x328]       | X9 = 1152921504887730176;               
            // 0x01431C60: LDR x24, [x9]              | X24 = typeof(CameraHelper);             
            // 0x01431C64: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01431C68: TBZ w9, #0, #0x1431c7c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01431C6C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01431C70: CBNZ w9, #0x1431c7c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01431C74: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01431C78: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01431C7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431C80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01431C84: MOV x1, x24                | X1 = 1152921504887730176 (0x1000000010BDF000);//ML01
            // 0x01431C88: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01431C8C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01431C90: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01431C94: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01431C98: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01431C9C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01431CA0: TBZ w9, #0, #0x1431cb4     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01431CA4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01431CA8: CBNZ w9, #0x1431cb4        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01431CAC: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01431CB0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01431CB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431CB8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01431CBC: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01431CC0: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01431CC4: MOV x3, x22                | X3 = X3;//m1                            
            // 0x01431CC8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01431CCC: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01431CD0: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01431CD4: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x01431CD8: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01431CDC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01431CE0: TBZ w9, #0, #0x1431cf4     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01431CE4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01431CE8: CBNZ w9, #0x1431cf4        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01431CEC: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01431CF0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01431CF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431CF8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01431CFC: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01431D00: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x01431D04: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01431D08: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x01431D0C: CBZ x0, #0x1431d70         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x01431D10: ADRP x9, #0x3611000        | X9 = 56692736 (0x3611000);              
            // 0x01431D14: LDR x9, [x9, #0x430]       | X9 = 1152921504887730176;               
            // 0x01431D18: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01431D1C: LDR x1, [x9]               | X1 = typeof(CameraHelper);              
            // 0x01431D20: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01431D24: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01431D28: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01431D2C: B.LO #0x1431d48            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x01431D30: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01431D34: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHier
            // 0x01431D38: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01431D3C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01431D40: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x01431D44: B.EQ #0x1431d70            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x01431D48: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01431D4C: ADD x8, sp, #8             | X8 = (1152921510109871424 + 8) = 1152921510109871432 (0x1000000148017D48);
            // 0x01431D50: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01431D54: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510109859504]
            // 0x01431D58: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x01431D5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01431D60: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x01431D64: ADD x0, sp, #8             | X0 = (1152921510109871424 + 8) = 1152921510109871432 (0x1000000148017D48);
            // 0x01431D68: BL #0x299a140              | 
            // 0x01431D6C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x01431D70: CBNZ x19, #0x1431d78       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x01431D74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148017D48, ????);
            label_11:
            // 0x01431D78: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01431D7C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01431D80: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01431D84: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01431D88: CBNZ x22, #0x1431d90       | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x01431D8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x01431D90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01431D94: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x01431D98: BL #0xbab184               | val_9.PlayTeamSkillCamera();            
            val_9.PlayTeamSkillCamera();
            // 0x01431D9C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01431DA0: SUB sp, x29, #0x30         | SP = (1152921510109871488 - 48) = 1152921510109871440 (0x1000000148017D50);
            // 0x01431DA4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01431DA8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01431DAC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01431DB0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01431DB4: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01431DB8: MOV x19, x0                | 
            // 0x01431DBC: ADD x0, sp, #8             | 
            // 0x01431DC0: BL #0x299a140              | 
            // 0x01431DC4: MOV x0, x19                | 
            // 0x01431DC8: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01431DCC (21175756), len: 528  VirtAddr: 0x01431DCC RVA: 0x01431DCC token: 100664145 methodIndex: 30192 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* StopTeamSkillCamera_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x01431DCC: STP x24, x23, [sp, #-0x40]! | stack[1152921510110040784] = ???;  stack[1152921510110040792] = ???;  //  dest_result_addr=1152921510110040784 |  dest_result_addr=1152921510110040792
            // 0x01431DD0: STP x22, x21, [sp, #0x10]  | stack[1152921510110040800] = ???;  stack[1152921510110040808] = ???;  //  dest_result_addr=1152921510110040800 |  dest_result_addr=1152921510110040808
            // 0x01431DD4: STP x20, x19, [sp, #0x20]  | stack[1152921510110040816] = ???;  stack[1152921510110040824] = ???;  //  dest_result_addr=1152921510110040816 |  dest_result_addr=1152921510110040824
            // 0x01431DD8: STP x29, x30, [sp, #0x30]  | stack[1152921510110040832] = ???;  stack[1152921510110040840] = ???;  //  dest_result_addr=1152921510110040832 |  dest_result_addr=1152921510110040840
            // 0x01431DDC: ADD x29, sp, #0x30         | X29 = (1152921510110040784 + 48) = 1152921510110040832 (0x1000000148041300);
            // 0x01431DE0: SUB sp, sp, #0x10          | SP = (1152921510110040784 - 16) = 1152921510110040768 (0x10000001480412C0);
            // 0x01431DE4: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01431DE8: LDRB w8, [x20, #0x30]      | W8 = (bool)static_value_03737030;       
            // 0x01431DEC: MOV x22, x3                | X22 = X3;//m1                           
            // 0x01431DF0: MOV x21, x2                | X21 = X2;//m1                           
            // 0x01431DF4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01431DF8: TBNZ w8, #0, #0x1431e14    | if (static_value_03737030 == true) goto label_0;
            // 0x01431DFC: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x01431E00: LDR x8, [x8, #0xb98]       | X8 = 0x2B901E8;                         
            // 0x01431E04: LDR w0, [x8]               | W0 = 0x173E;                            
            // 0x01431E08: BL #0x2782188              | X0 = sub_2782188( ?? 0x173E, ????);     
            // 0x01431E0C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01431E10: STRB w8, [x20, #0x30]      | static_value_03737030 = true;            //  dest_result_addr=57897008
            label_0:
            // 0x01431E14: CBNZ x19, #0x1431e1c       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01431E18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x173E, ????);     
            label_1:
            // 0x01431E1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01431E20: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01431E24: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01431E28: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01431E2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431E30: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01431E34: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01431E38: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01431E3C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01431E40: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01431E44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431E48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01431E4C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01431E50: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01431E54: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01431E58: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01431E5C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01431E60: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
            // 0x01431E64: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x01431E68: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01431E6C: LDR x9, [x9, #0x328]       | X9 = 1152921504887730176;               
            // 0x01431E70: LDR x24, [x9]              | X24 = typeof(CameraHelper);             
            // 0x01431E74: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01431E78: TBZ w9, #0, #0x1431e8c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01431E7C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01431E80: CBNZ w9, #0x1431e8c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01431E84: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01431E88: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01431E8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431E90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01431E94: MOV x1, x24                | X1 = 1152921504887730176 (0x1000000010BDF000);//ML01
            // 0x01431E98: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01431E9C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01431EA0: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01431EA4: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01431EA8: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01431EAC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01431EB0: TBZ w9, #0, #0x1431ec4     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01431EB4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01431EB8: CBNZ w9, #0x1431ec4        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01431EBC: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01431EC0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01431EC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431EC8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01431ECC: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01431ED0: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01431ED4: MOV x3, x22                | X3 = X3;//m1                            
            // 0x01431ED8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01431EDC: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01431EE0: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01431EE4: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x01431EE8: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01431EEC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01431EF0: TBZ w9, #0, #0x1431f04     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01431EF4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01431EF8: CBNZ w9, #0x1431f04        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01431EFC: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01431F00: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01431F04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01431F08: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01431F0C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01431F10: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x01431F14: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01431F18: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x01431F1C: CBZ x0, #0x1431f80         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x01431F20: ADRP x9, #0x3611000        | X9 = 56692736 (0x3611000);              
            // 0x01431F24: LDR x9, [x9, #0x430]       | X9 = 1152921504887730176;               
            // 0x01431F28: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01431F2C: LDR x1, [x9]               | X1 = typeof(CameraHelper);              
            // 0x01431F30: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01431F34: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01431F38: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01431F3C: B.LO #0x1431f58            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x01431F40: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01431F44: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHier
            // 0x01431F48: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01431F4C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01431F50: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x01431F54: B.EQ #0x1431f80            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x01431F58: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01431F5C: ADD x8, sp, #8             | X8 = (1152921510110040768 + 8) = 1152921510110040776 (0x10000001480412C8);
            // 0x01431F60: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01431F64: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510110028848]
            // 0x01431F68: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x01431F6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01431F70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x01431F74: ADD x0, sp, #8             | X0 = (1152921510110040768 + 8) = 1152921510110040776 (0x10000001480412C8);
            // 0x01431F78: BL #0x299a140              | 
            // 0x01431F7C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x01431F80: CBNZ x19, #0x1431f88       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x01431F84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001480412C8, ????);
            label_11:
            // 0x01431F88: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01431F8C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01431F90: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01431F94: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01431F98: CBNZ x22, #0x1431fa0       | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x01431F9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x01431FA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01431FA4: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x01431FA8: BL #0xbab6ac               | val_9.StopTeamSkillCamera();            
            val_9.StopTeamSkillCamera();
            // 0x01431FAC: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01431FB0: SUB sp, x29, #0x30         | SP = (1152921510110040832 - 48) = 1152921510110040784 (0x10000001480412D0);
            // 0x01431FB4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01431FB8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01431FBC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01431FC0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01431FC4: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01431FC8: MOV x19, x0                | 
            // 0x01431FCC: ADD x0, sp, #8             | 
            // 0x01431FD0: BL #0x299a140              | 
            // 0x01431FD4: MOV x0, x19                | 
            // 0x01431FD8: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01431FDC (21176284), len: 528  VirtAddr: 0x01431FDC RVA: 0x01431FDC token: 100664146 methodIndex: 30193 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* BreakTeamSkillCamera_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x01431FDC: STP x24, x23, [sp, #-0x40]! | stack[1152921510110210128] = ???;  stack[1152921510110210136] = ???;  //  dest_result_addr=1152921510110210128 |  dest_result_addr=1152921510110210136
            // 0x01431FE0: STP x22, x21, [sp, #0x10]  | stack[1152921510110210144] = ???;  stack[1152921510110210152] = ???;  //  dest_result_addr=1152921510110210144 |  dest_result_addr=1152921510110210152
            // 0x01431FE4: STP x20, x19, [sp, #0x20]  | stack[1152921510110210160] = ???;  stack[1152921510110210168] = ???;  //  dest_result_addr=1152921510110210160 |  dest_result_addr=1152921510110210168
            // 0x01431FE8: STP x29, x30, [sp, #0x30]  | stack[1152921510110210176] = ???;  stack[1152921510110210184] = ???;  //  dest_result_addr=1152921510110210176 |  dest_result_addr=1152921510110210184
            // 0x01431FEC: ADD x29, sp, #0x30         | X29 = (1152921510110210128 + 48) = 1152921510110210176 (0x100000014806A880);
            // 0x01431FF0: SUB sp, sp, #0x10          | SP = (1152921510110210128 - 16) = 1152921510110210112 (0x100000014806A840);
            // 0x01431FF4: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01431FF8: LDRB w8, [x20, #0x31]      | W8 = (bool)static_value_03737031;       
            // 0x01431FFC: MOV x22, x3                | X22 = X3;//m1                           
            // 0x01432000: MOV x21, x2                | X21 = X2;//m1                           
            // 0x01432004: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01432008: TBNZ w8, #0, #0x1432024    | if (static_value_03737031 == true) goto label_0;
            // 0x0143200C: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
            // 0x01432010: LDR x8, [x8, #0x948]       | X8 = 0x2B90180;                         
            // 0x01432014: LDR w0, [x8]               | W0 = 0x1724;                            
            // 0x01432018: BL #0x2782188              | X0 = sub_2782188( ?? 0x1724, ????);     
            // 0x0143201C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01432020: STRB w8, [x20, #0x31]      | static_value_03737031 = true;            //  dest_result_addr=57897009
            label_0:
            // 0x01432024: CBNZ x19, #0x143202c       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01432028: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1724, ????);     
            label_1:
            // 0x0143202C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01432030: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01432034: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01432038: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0143203C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432040: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432044: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01432048: MOV x1, x21                | X1 = X2;//m1                            
            // 0x0143204C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01432050: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01432054: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432058: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143205C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01432060: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01432064: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01432068: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0143206C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01432070: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
            // 0x01432074: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x01432078: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0143207C: LDR x9, [x9, #0x328]       | X9 = 1152921504887730176;               
            // 0x01432080: LDR x24, [x9]              | X24 = typeof(CameraHelper);             
            // 0x01432084: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01432088: TBZ w9, #0, #0x143209c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0143208C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01432090: CBNZ w9, #0x143209c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01432094: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01432098: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0143209C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014320A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014320A4: MOV x1, x24                | X1 = 1152921504887730176 (0x1000000010BDF000);//ML01
            // 0x014320A8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x014320AC: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x014320B0: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x014320B4: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x014320B8: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x014320BC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x014320C0: TBZ w9, #0, #0x14320d4     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x014320C4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x014320C8: CBNZ w9, #0x14320d4        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x014320CC: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x014320D0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x014320D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014320D8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x014320DC: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x014320E0: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x014320E4: MOV x3, x22                | X3 = X3;//m1                            
            // 0x014320E8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x014320EC: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x014320F0: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x014320F4: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x014320F8: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x014320FC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01432100: TBZ w9, #0, #0x1432114     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01432104: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01432108: CBNZ w9, #0x1432114        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0143210C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01432110: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01432114: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432118: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143211C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01432120: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x01432124: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01432128: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x0143212C: CBZ x0, #0x1432190         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x01432130: ADRP x9, #0x3611000        | X9 = 56692736 (0x3611000);              
            // 0x01432134: LDR x9, [x9, #0x430]       | X9 = 1152921504887730176;               
            // 0x01432138: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0143213C: LDR x1, [x9]               | X1 = typeof(CameraHelper);              
            // 0x01432140: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01432144: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01432148: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0143214C: B.LO #0x1432168            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x01432150: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01432154: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHier
            // 0x01432158: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0143215C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01432160: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x01432164: B.EQ #0x1432190            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x01432168: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0143216C: ADD x8, sp, #8             | X8 = (1152921510110210112 + 8) = 1152921510110210120 (0x100000014806A848);
            // 0x01432170: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01432174: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510110198192]
            // 0x01432178: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x0143217C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01432180: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x01432184: ADD x0, sp, #8             | X0 = (1152921510110210112 + 8) = 1152921510110210120 (0x100000014806A848);
            // 0x01432188: BL #0x299a140              | 
            // 0x0143218C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x01432190: CBNZ x19, #0x1432198       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x01432194: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014806A848, ????);
            label_11:
            // 0x01432198: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143219C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014321A0: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x014321A4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x014321A8: CBNZ x22, #0x14321b0       | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x014321AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x014321B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014321B4: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x014321B8: BL #0xbabac4               | val_9.BreakTeamSkillCamera();           
            val_9.BreakTeamSkillCamera();
            // 0x014321BC: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x014321C0: SUB sp, x29, #0x30         | SP = (1152921510110210176 - 48) = 1152921510110210128 (0x100000014806A850);
            // 0x014321C4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x014321C8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x014321CC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x014321D0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x014321D4: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x014321D8: MOV x19, x0                | 
            // 0x014321DC: ADD x0, sp, #8             | 
            // 0x014321E0: BL #0x299a140              | 
            // 0x014321E4: MOV x0, x19                | 
            // 0x014321E8: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x014321EC (21176812), len: 760  VirtAddr: 0x014321EC RVA: 0x014321EC token: 100664147 methodIndex: 30194 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* MoveCamera_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_13;
            //  | 
            var val_16;
            // 0x014321EC: STP d9, d8, [sp, #-0x70]!  | stack[1152921510110379424] = ???;  stack[1152921510110379432] = ???;  //  dest_result_addr=1152921510110379424 |  dest_result_addr=1152921510110379432
            // 0x014321F0: STP x28, x27, [sp, #0x10]  | stack[1152921510110379440] = ???;  stack[1152921510110379448] = ???;  //  dest_result_addr=1152921510110379440 |  dest_result_addr=1152921510110379448
            // 0x014321F4: STP x26, x25, [sp, #0x20]  | stack[1152921510110379456] = ???;  stack[1152921510110379464] = ???;  //  dest_result_addr=1152921510110379456 |  dest_result_addr=1152921510110379464
            // 0x014321F8: STP x24, x23, [sp, #0x30]  | stack[1152921510110379472] = ???;  stack[1152921510110379480] = ???;  //  dest_result_addr=1152921510110379472 |  dest_result_addr=1152921510110379480
            // 0x014321FC: STP x22, x21, [sp, #0x40]  | stack[1152921510110379488] = ???;  stack[1152921510110379496] = ???;  //  dest_result_addr=1152921510110379488 |  dest_result_addr=1152921510110379496
            // 0x01432200: STP x20, x19, [sp, #0x50]  | stack[1152921510110379504] = ???;  stack[1152921510110379512] = ???;  //  dest_result_addr=1152921510110379504 |  dest_result_addr=1152921510110379512
            // 0x01432204: STP x29, x30, [sp, #0x60]  | stack[1152921510110379520] = ???;  stack[1152921510110379528] = ???;  //  dest_result_addr=1152921510110379520 |  dest_result_addr=1152921510110379528
            // 0x01432208: ADD x29, sp, #0x60         | X29 = (1152921510110379424 + 96) = 1152921510110379520 (0x1000000148093E00);
            // 0x0143220C: SUB sp, sp, #0x10          | SP = (1152921510110379424 - 16) = 1152921510110379408 (0x1000000148093D90);
            // 0x01432210: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01432214: LDRB w8, [x20, #0x32]      | W8 = (bool)static_value_03737032;       
            // 0x01432218: MOV x23, x3                | X23 = X3;//m1                           
            // 0x0143221C: MOV x25, x2                | X25 = X2;//m1                           
            // 0x01432220: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01432224: TBNZ w8, #0, #0x1432240    | if (static_value_03737032 == true) goto label_0;
            // 0x01432228: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
            // 0x0143222C: LDR x8, [x8, #0x280]       | X8 = 0x2B901B8;                         
            // 0x01432230: LDR w0, [x8]               | W0 = 0x1732;                            
            // 0x01432234: BL #0x2782188              | X0 = sub_2782188( ?? 0x1732, ????);     
            // 0x01432238: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143223C: STRB w8, [x20, #0x32]      | static_value_03737032 = true;            //  dest_result_addr=57897010
            label_0:
            // 0x01432240: CBNZ x19, #0x1432248       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01432244: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1732, ????);     
            label_1:
            // 0x01432248: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143224C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01432250: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01432254: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x01432258: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143225C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432260: ORR w2, wzr, #6            | W2 = 6(0x6);                            
            // 0x01432264: MOV x1, x25                | X1 = X2;//m1                            
            // 0x01432268: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143226C: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01432270: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432274: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432278: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0143227C: MOV x1, x25                | X1 = X2;//m1                            
            // 0x01432280: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01432284: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x01432288: CBNZ x21, #0x1432290       | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x0143228C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x01432290: LDR w21, [x21, #4]         | W21 = val_3 + 4;                        
            // 0x01432294: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432298: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143229C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x014322A0: MOV x1, x25                | X1 = X2;//m1                            
            // 0x014322A4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014322A8: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x014322AC: CBNZ x22, #0x14322b4       | if (val_4 != 0) goto label_3;           
            if(val_4 != 0)
            {
                goto label_3;
            }
            // 0x014322B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_3:
            // 0x014322B4: LDR s8, [x22, #4]          | S8 = val_4 + 4;                         
            // 0x014322B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014322BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014322C0: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x014322C4: MOV x1, x25                | X1 = X2;//m1                            
            // 0x014322C8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_5 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014322CC: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x014322D0: CBNZ x22, #0x14322d8       | if (val_5 != 0) goto label_4;           
            if(val_5 != 0)
            {
                goto label_4;
            }
            // 0x014322D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_4:
            // 0x014322D8: LDR w27, [x22, #4]         | W27 = val_5 + 4;                        
            // 0x014322DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014322E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014322E4: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x014322E8: MOV x1, x25                | X1 = X2;//m1                            
            // 0x014322EC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_6 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014322F0: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x014322F4: CBNZ x22, #0x14322fc       | if (val_6 != 0) goto label_5;           
            if(val_6 != 0)
            {
                goto label_5;
            }
            // 0x014322F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_5:
            // 0x014322FC: LDR w22, [x22, #4]         | W22 = val_6 + 4;                        
            // 0x01432300: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432304: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432308: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x0143230C: MOV x1, x25                | X1 = X2;//m1                            
            // 0x01432310: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_7 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01432314: MOV x26, x0                | X26 = val_7;//m1                        
            // 0x01432318: CBNZ x26, #0x1432320       | if (val_7 != 0) goto label_6;           
            if(val_7 != 0)
            {
                goto label_6;
            }
            // 0x0143231C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_6:
            // 0x01432320: LDR w28, [x26, #4]         | W28 = val_7 + 4;                        
            // 0x01432324: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432328: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143232C: ORR w2, wzr, #6            | W2 = 6(0x6);                            
            // 0x01432330: MOV x1, x25                | X1 = X2;//m1                            
            // 0x01432334: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01432338: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0143233C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01432340: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
            // 0x01432344: MOV x25, x0                | X25 = val_8;//m1                        
            // 0x01432348: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0143234C: LDR x9, [x9, #0x328]       | X9 = 1152921504887730176;               
            // 0x01432350: LDR x26, [x9]              | X26 = typeof(CameraHelper);             
            // 0x01432354: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01432358: TBZ w9, #0, #0x143236c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x0143235C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01432360: CBNZ w9, #0x143236c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x01432364: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01432368: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_8:
            // 0x0143236C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432370: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01432374: MOV x1, x26                | X1 = 1152921504887730176 (0x1000000010BDF000);//ML01
            // 0x01432378: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143237C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01432380: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01432384: MOV x26, x0                | X26 = val_9;//m1                        
            // 0x01432388: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0143238C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01432390: TBZ w9, #0, #0x14323a4     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x01432394: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01432398: CBNZ w9, #0x14323a4        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x0143239C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x014323A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_10:
            // 0x014323A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014323A8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x014323AC: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x014323B0: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x014323B4: MOV x3, x23                | X3 = X3;//m1                            
            // 0x014323B8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x014323BC: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x014323C0: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x014323C4: MOV x23, x0                | X23 = val_10;//m1                       
            // 0x014323C8: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x014323CC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x014323D0: TBZ w9, #0, #0x14323e4     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x014323D4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x014323D8: CBNZ w9, #0x14323e4        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x014323DC: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x014323E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_12:
            // 0x014323E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014323E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014323EC: MOV x1, x26                | X1 = val_9;//m1                         
            // 0x014323F0: MOV x2, x23                | X2 = val_10;//m1                        
            // 0x014323F4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x014323F8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x014323FC: CBZ x0, #0x1432460         | if (val_11 == null) goto label_15;      
            if(val_11 == null)
            {
                goto label_15;
            }
            // 0x01432400: ADRP x9, #0x3611000        | X9 = 56692736 (0x3611000);              
            // 0x01432404: LDR x9, [x9, #0x430]       | X9 = 1152921504887730176;               
            // 0x01432408: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0143240C: LDR x1, [x9]               | X1 = typeof(CameraHelper);              
            // 0x01432410: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01432414: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01432418: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0143241C: B.LO #0x1432438            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_14;
            // 0x01432420: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01432424: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHier
            // 0x01432428: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0143242C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01432430: MOV x23, x0                | X23 = val_11;//m1                       
            val_16 = val_11;
            // 0x01432434: B.EQ #0x1432460            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_15;
            label_14:
            // 0x01432438: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0143243C: ADD x8, sp, #8             | X8 = (1152921510110379408 + 8) = 1152921510110379416 (0x1000000148093D98);
            // 0x01432440: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01432444: LDR x0, [sp, #8]           | X0 = val_13;                             //  find_add[1152921510110367536]
            // 0x01432448: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x0143244C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01432450: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x01432454: ADD x0, sp, #8             | X0 = (1152921510110379408 + 8) = 1152921510110379416 (0x1000000148093D98);
            // 0x01432458: BL #0x299a140              | 
            // 0x0143245C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_15:
            // 0x01432460: CBNZ x19, #0x1432468       | if (X1 != 0) goto label_16;             
            if(X1 != 0)
            {
                goto label_16;
            }
            // 0x01432464: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148093D98, ????);
            label_16:
            // 0x01432468: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143246C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01432470: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x01432474: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01432478: CBNZ x23, #0x1432480       | if (0x0 != 0) goto label_17;            
            if(val_16 != 0)
            {
                goto label_17;
            }
            // 0x0143247C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_17:
            // 0x01432480: CMP w28, #1                | STATE = COMPARE(val_7 + 4, 0x1)         
            // 0x01432484: CSET w1, eq                | W1 = val_7 + 4 == 0x1 ? 1 : 0;          
            bool val_14 = ((val_7 + 4) == 1) ? 1 : 0;
            // 0x01432488: CMP w27, #1                | STATE = COMPARE(val_5 + 4, 0x1)         
            // 0x0143248C: CSET w3, eq                | W3 = val_5 + 4 == 0x1 ? 1 : 0;          
            bool val_15 = ((val_5 + 4) == 1) ? 1 : 0;
            // 0x01432490: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01432494: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x01432498: MOV w2, w22                | W2 = val_6 + 4;//m1                     
            // 0x0143249C: MOV v0.16b, v8.16b         | V0 = val_4 + 4;//m1                     
            // 0x014324A0: MOV w4, w21                | W4 = val_3 + 4;//m1                     
            // 0x014324A4: BL #0xbabac8               | val_16.MoveCamera(isHero:  bool val_14 = ((val_7 + 4) == 1) ? 1 : 0, id:  val_6 + 4, isMove:  bool val_15 = ((val_5 + 4) == 1) ? 1 : 0, time:  val_4 + 4, AIid:  val_3 + 4);
            val_16.MoveCamera(isHero:  val_14, id:  val_6 + 4, isMove:  val_15, time:  val_4 + 4, AIid:  val_3 + 4);
            // 0x014324A8: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x014324AC: SUB sp, x29, #0x60         | SP = (1152921510110379520 - 96) = 1152921510110379424 (0x1000000148093DA0);
            // 0x014324B0: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
            // 0x014324B4: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
            // 0x014324B8: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
            // 0x014324BC: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
            // 0x014324C0: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
            // 0x014324C4: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
            // 0x014324C8: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
            // 0x014324CC: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x014324D0: MOV x19, x0                | 
            // 0x014324D4: ADD x0, sp, #8             | 
            // 0x014324D8: BL #0x299a140              | 
            // 0x014324DC: MOV x0, x19                | 
            // 0x014324E0: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x014324E4 (21177572), len: 932  VirtAddr: 0x014324E4 RVA: 0x014324E4 token: 100664148 methodIndex: 30195 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* ChangeCameraTarget_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_17;
            //  | 
            string val_20;
            //  | 
            var val_21;
            // 0x014324E4: STP d9, d8, [sp, #-0x70]!  | stack[1152921510110561056] = ???;  stack[1152921510110561064] = ???;  //  dest_result_addr=1152921510110561056 |  dest_result_addr=1152921510110561064
            // 0x014324E8: STP x28, x27, [sp, #0x10]  | stack[1152921510110561072] = ???;  stack[1152921510110561080] = ???;  //  dest_result_addr=1152921510110561072 |  dest_result_addr=1152921510110561080
            // 0x014324EC: STP x26, x25, [sp, #0x20]  | stack[1152921510110561088] = ???;  stack[1152921510110561096] = ???;  //  dest_result_addr=1152921510110561088 |  dest_result_addr=1152921510110561096
            // 0x014324F0: STP x24, x23, [sp, #0x30]  | stack[1152921510110561104] = ???;  stack[1152921510110561112] = ???;  //  dest_result_addr=1152921510110561104 |  dest_result_addr=1152921510110561112
            // 0x014324F4: STP x22, x21, [sp, #0x40]  | stack[1152921510110561120] = ???;  stack[1152921510110561128] = ???;  //  dest_result_addr=1152921510110561120 |  dest_result_addr=1152921510110561128
            // 0x014324F8: STP x20, x19, [sp, #0x50]  | stack[1152921510110561136] = ???;  stack[1152921510110561144] = ???;  //  dest_result_addr=1152921510110561136 |  dest_result_addr=1152921510110561144
            // 0x014324FC: STP x29, x30, [sp, #0x60]  | stack[1152921510110561152] = ???;  stack[1152921510110561160] = ???;  //  dest_result_addr=1152921510110561152 |  dest_result_addr=1152921510110561160
            // 0x01432500: ADD x29, sp, #0x60         | X29 = (1152921510110561056 + 96) = 1152921510110561152 (0x10000001480C0380);
            // 0x01432504: SUB sp, sp, #0x10          | SP = (1152921510110561056 - 16) = 1152921510110561040 (0x10000001480C0310);
            // 0x01432508: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0143250C: LDRB w8, [x20, #0x33]      | W8 = (bool)static_value_03737033;       
            // 0x01432510: MOV x21, x3                | X21 = X3;//m1                           
            // 0x01432514: MOV x22, x2                | X22 = X2;//m1                           
            // 0x01432518: MOV x19, x1                | X19 = X1;//m1                           
            // 0x0143251C: TBNZ w8, #0, #0x1432538    | if (static_value_03737033 == true) goto label_0;
            // 0x01432520: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x01432524: LDR x8, [x8, #0xb70]       | X8 = 0x2B90184;                         
            // 0x01432528: LDR w0, [x8]               | W0 = 0x1725;                            
            // 0x0143252C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1725, ????);     
            // 0x01432530: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01432534: STRB w8, [x20, #0x33]      | static_value_03737033 = true;            //  dest_result_addr=57897011
            label_0:
            // 0x01432538: CBNZ x19, #0x1432540       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0143253C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1725, ????);     
            label_1:
            // 0x01432540: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01432544: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01432548: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0143254C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01432550: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432554: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432558: ORR w2, wzr, #6            | W2 = 6(0x6);                            
            // 0x0143255C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01432560: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01432564: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01432568: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143256C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432570: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01432574: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01432578: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143257C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01432580: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01432584: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x01432588: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x0143258C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01432590: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x01432594: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x01432598: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0143259C: TBZ w9, #0, #0x14325b0     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x014325A0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x014325A4: CBNZ w9, #0x14325b0        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x014325A8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x014325AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x014325B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014325B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014325B8: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x014325BC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x014325C0: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x014325C4: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x014325C8: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x014325CC: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x014325D0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x014325D4: TBZ w9, #0, #0x14325e8     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x014325D8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x014325DC: CBNZ w9, #0x14325e8        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x014325E0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x014325E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x014325E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014325EC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x014325F0: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x014325F4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x014325F8: MOV x3, x21                | X3 = X3;//m1                            
            // 0x014325FC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01432600: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01432604: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01432608: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x0143260C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01432610: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01432614: TBZ w9, #0, #0x1432628     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01432618: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0143261C: CBNZ w9, #0x1432628        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01432620: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01432624: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01432628: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143262C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432630: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01432634: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x01432638: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x0143263C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_20 = 0;
            // 0x01432640: CBZ x0, #0x1432688         | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x01432644: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01432648: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0143264C: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01432650: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01432654: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x01432658: MOV x24, x0                | X24 = val_6;//m1                        
            val_20 = val_6;
            // 0x0143265C: B.EQ #0x1432688            | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x01432660: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01432664: MOV x8, sp                 | X8 = 1152921510110561040 (0x10000001480C0310);//ML01
            // 0x01432668: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0143266C: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510110549168]
            // 0x01432670: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x01432674: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01432678: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x0143267C: MOV x0, sp                 | X0 = 1152921510110561040 (0x10000001480C0310);//ML01
            // 0x01432680: BL #0x299a140              | 
            // 0x01432684: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_20 = 0;
            label_9:
            // 0x01432688: CBNZ x19, #0x1432690       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x0143268C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001480C0310, ????);
            label_10:
            // 0x01432690: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01432694: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01432698: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x0143269C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x014326A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014326A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014326A8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x014326AC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x014326B0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014326B4: MOV x25, x0                | X25 = val_8;//m1                        
            // 0x014326B8: CBNZ x25, #0x14326c0       | if (val_8 != 0) goto label_11;          
            if(val_8 != 0)
            {
                goto label_11;
            }
            // 0x014326BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_11:
            // 0x014326C0: LDR s8, [x25, #4]          | S8 = val_8 + 4;                         
            // 0x014326C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014326C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014326CC: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x014326D0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x014326D4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014326D8: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x014326DC: CBNZ x25, #0x14326e4       | if (val_9 != 0) goto label_12;          
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x014326E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_12:
            // 0x014326E4: LDR w27, [x25, #4]         | W27 = val_9 + 4;                        
            // 0x014326E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014326EC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014326F0: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x014326F4: MOV x1, x22                | X1 = X2;//m1                            
            // 0x014326F8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_10 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014326FC: MOV x25, x0                | X25 = val_10;//m1                       
            // 0x01432700: CBNZ x25, #0x1432708       | if (val_10 != 0) goto label_13;         
            if(val_10 != 0)
            {
                goto label_13;
            }
            // 0x01432704: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_13:
            // 0x01432708: LDR w25, [x25, #4]         | W25 = val_10 + 4;                       
            // 0x0143270C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432710: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432714: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x01432718: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0143271C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_11 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01432720: MOV x26, x0                | X26 = val_11;//m1                       
            // 0x01432724: CBNZ x26, #0x143272c       | if (val_11 != 0) goto label_14;         
            if(val_11 != 0)
            {
                goto label_14;
            }
            // 0x01432728: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_14:
            // 0x0143272C: LDR w28, [x26, #4]         | W28 = val_11 + 4;                       
            // 0x01432730: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432734: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432738: ORR w2, wzr, #6            | W2 = 6(0x6);                            
            // 0x0143273C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01432740: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_12 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01432744: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x01432748: LDR x8, [x8, #0x328]       | X8 = 1152921504887730176;               
            // 0x0143274C: MOV x22, x0                | X22 = val_12;//m1                       
            // 0x01432750: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432754: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01432758: LDR x1, [x8]               | X1 = typeof(CameraHelper);              
            // 0x0143275C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_13 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01432760: MOV x26, x0                | X26 = val_13;//m1                       
            // 0x01432764: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432768: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143276C: MOV x1, x22                | X1 = val_12;//m1                        
            // 0x01432770: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01432774: MOV x3, x21                | X3 = X3;//m1                            
            // 0x01432778: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_14 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0143277C: MOV x2, x0                 | X2 = val_14;//m1                        
            // 0x01432780: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432784: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432788: MOV x1, x26                | X1 = val_13;//m1                        
            // 0x0143278C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_13);
            object val_15 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_13);
            // 0x01432790: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_21 = 0;
            // 0x01432794: CBZ x0, #0x14327f8         | if (val_15 == null) goto label_17;      
            if(val_15 == null)
            {
                goto label_17;
            }
            // 0x01432798: ADRP x9, #0x3611000        | X9 = 56692736 (0x3611000);              
            // 0x0143279C: LDR x9, [x9, #0x430]       | X9 = 1152921504887730176;               
            // 0x014327A0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x014327A4: LDR x1, [x9]               | X1 = typeof(CameraHelper);              
            // 0x014327A8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014327AC: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014327B0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014327B4: B.LO #0x14327d0            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_16;
            // 0x014327B8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x014327BC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHier
            // 0x014327C0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014327C4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x014327C8: MOV x21, x0                | X21 = val_15;//m1                       
            val_21 = val_15;
            // 0x014327CC: B.EQ #0x14327f8            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_17;
            label_16:
            // 0x014327D0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x014327D4: ADD x8, sp, #8             | X8 = (1152921510110561040 + 8) = 1152921510110561048 (0x10000001480C0318);
            // 0x014327D8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x014327DC: LDR x0, [sp, #8]           | X0 = val_17;                             //  find_add[1152921510110549168]
            // 0x014327E0: BL #0x27af090              | X0 = sub_27AF090( ?? val_17, ????);     
            // 0x014327E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014327E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            // 0x014327EC: ADD x0, sp, #8             | X0 = (1152921510110561040 + 8) = 1152921510110561048 (0x10000001480C0318);
            // 0x014327F0: BL #0x299a140              | 
            // 0x014327F4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_21 = 0;
            label_17:
            // 0x014327F8: CBNZ x19, #0x1432800       | if (X1 != 0) goto label_18;             
            if(X1 != 0)
            {
                goto label_18;
            }
            // 0x014327FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001480C0318, ????);
            label_18:
            // 0x01432800: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01432804: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01432808: MOV x1, x22                | X1 = val_12;//m1                        
            // 0x0143280C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01432810: CBNZ x21, #0x1432818       | if (0x0 != 0) goto label_19;            
            if(val_21 != 0)
            {
                goto label_19;
            }
            // 0x01432814: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_19:
            // 0x01432818: CMP w28, #1                | STATE = COMPARE(val_11 + 4, 0x1)        
            // 0x0143281C: CSET w1, eq                | W1 = val_11 + 4 == 0x1 ? 1 : 0;         
            bool val_18 = ((val_11 + 4) == 1) ? 1 : 0;
            // 0x01432820: CMP w27, #1                | STATE = COMPARE(val_9 + 4, 0x1)         
            // 0x01432824: CSET w3, eq                | W3 = val_9 + 4 == 0x1 ? 1 : 0;          
            bool val_19 = ((val_9 + 4) == 1) ? 1 : 0;
            // 0x01432828: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0143282C: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x01432830: MOV w2, w25                | W2 = val_10 + 4;//m1                    
            // 0x01432834: MOV v0.16b, v8.16b         | V0 = val_8 + 4;//m1                     
            // 0x01432838: MOV x4, x24                | X4 = 0 (0x0);//ML01                     
            // 0x0143283C: BL #0xbabed0               | val_21.ChangeCameraTarget(isHero:  bool val_18 = ((val_11 + 4) == 1) ? 1 : 0, id:  val_10 + 4, isMove:  bool val_19 = ((val_9 + 4) == 1) ? 1 : 0, time:  val_8 + 4, objName:  val_20);
            val_21.ChangeCameraTarget(isHero:  val_18, id:  val_10 + 4, isMove:  val_19, time:  val_8 + 4, objName:  val_20);
            // 0x01432840: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01432844: SUB sp, x29, #0x60         | SP = (1152921510110561152 - 96) = 1152921510110561056 (0x10000001480C0320);
            // 0x01432848: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
            // 0x0143284C: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
            // 0x01432850: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
            // 0x01432854: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
            // 0x01432858: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
            // 0x0143285C: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
            // 0x01432860: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
            // 0x01432864: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01432868: MOV x19, x0                | 
            // 0x0143286C: ADD x0, sp, #8             | 
            // 0x01432870: B #0x143287c               | 
            // 0x01432874: MOV x19, x0                | 
            // 0x01432878: MOV x0, sp                 | 
            label_20:
            // 0x0143287C: BL #0x299a140              | 
            // 0x01432880: MOV x0, x19                | 
            // 0x01432884: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01432888 (21178504), len: 776  VirtAddr: 0x01432888 RVA: 0x01432888 token: 100664149 methodIndex: 30196 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* MotionBlur_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_14;
            //  | 
            UnityEngine.Transform val_15;
            //  | 
            var val_16;
            // 0x01432888: STP x26, x25, [sp, #-0x50]! | stack[1152921510110755008] = ???;  stack[1152921510110755016] = ???;  //  dest_result_addr=1152921510110755008 |  dest_result_addr=1152921510110755016
            // 0x0143288C: STP x24, x23, [sp, #0x10]  | stack[1152921510110755024] = ???;  stack[1152921510110755032] = ???;  //  dest_result_addr=1152921510110755024 |  dest_result_addr=1152921510110755032
            // 0x01432890: STP x22, x21, [sp, #0x20]  | stack[1152921510110755040] = ???;  stack[1152921510110755048] = ???;  //  dest_result_addr=1152921510110755040 |  dest_result_addr=1152921510110755048
            // 0x01432894: STP x20, x19, [sp, #0x30]  | stack[1152921510110755056] = ???;  stack[1152921510110755064] = ???;  //  dest_result_addr=1152921510110755056 |  dest_result_addr=1152921510110755064
            // 0x01432898: STP x29, x30, [sp, #0x40]  | stack[1152921510110755072] = ???;  stack[1152921510110755080] = ???;  //  dest_result_addr=1152921510110755072 |  dest_result_addr=1152921510110755080
            // 0x0143289C: ADD x29, sp, #0x40         | X29 = (1152921510110755008 + 64) = 1152921510110755072 (0x10000001480EF900);
            // 0x014328A0: SUB sp, sp, #0x10          | SP = (1152921510110755008 - 16) = 1152921510110754992 (0x10000001480EF8B0);
            // 0x014328A4: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x014328A8: LDRB w8, [x20, #0x34]      | W8 = (bool)static_value_03737034;       
            // 0x014328AC: MOV x21, x3                | X21 = X3;//m1                           
            // 0x014328B0: MOV x22, x2                | X22 = X2;//m1                           
            // 0x014328B4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x014328B8: TBNZ w8, #0, #0x14328d4    | if (static_value_03737034 == true) goto label_0;
            // 0x014328BC: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x014328C0: LDR x8, [x8, #0x580]       | X8 = 0x2B901B0;                         
            // 0x014328C4: LDR w0, [x8]               | W0 = 0x1730;                            
            // 0x014328C8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1730, ????);     
            // 0x014328CC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x014328D0: STRB w8, [x20, #0x34]      | static_value_03737034 = true;            //  dest_result_addr=57897012
            label_0:
            // 0x014328D4: CBNZ x19, #0x14328dc       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x014328D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1730, ????);     
            label_1:
            // 0x014328DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014328E0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014328E4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x014328E8: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x014328EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014328F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014328F4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x014328F8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x014328FC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01432900: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01432904: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432908: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143290C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01432910: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01432914: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01432918: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0143291C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01432920: ADRP x9, #0x3630000        | X9 = 56819712 (0x3630000);              
            // 0x01432924: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x01432928: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0143292C: LDR x9, [x9, #0x8b8]       | X9 = 1152921504698060800;               
            // 0x01432930: LDR x25, [x9]              | X25 = typeof(UnityEngine.Transform);    
            // 0x01432934: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01432938: TBZ w9, #0, #0x143294c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0143293C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01432940: CBNZ w9, #0x143294c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01432944: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01432948: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0143294C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432950: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01432954: MOV x1, x25                | X1 = 1152921504698060800 (0x10000000056FD000);//ML01
            // 0x01432958: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143295C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01432960: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01432964: MOV x25, x0                | X25 = val_4;//m1                        
            // 0x01432968: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0143296C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01432970: TBZ w9, #0, #0x1432984     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01432974: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01432978: CBNZ w9, #0x1432984        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0143297C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01432980: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01432984: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432988: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143298C: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x01432990: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01432994: MOV x3, x21                | X3 = X3;//m1                            
            // 0x01432998: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0143299C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x014329A0: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x014329A4: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x014329A8: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x014329AC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x014329B0: TBZ w9, #0, #0x14329c4     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x014329B4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x014329B8: CBNZ w9, #0x14329c4        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x014329BC: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x014329C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x014329C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014329C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014329CC: MOV x1, x25                | X1 = val_4;//m1                         
            // 0x014329D0: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x014329D4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x014329D8: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x014329DC: CBZ x0, #0x1432a40         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x014329E0: ADRP x9, #0x35e5000        | X9 = 56512512 (0x35E5000);              
            // 0x014329E4: LDR x9, [x9, #0xe58]       | X9 = 1152921504698060800;               
            // 0x014329E8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x014329EC: LDR x1, [x9]               | X1 = typeof(UnityEngine.Transform);     
            // 0x014329F0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014329F4: LDRB w9, [x1, #0x104]      | W9 = UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014329F8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014329FC: B.LO #0x1432a18            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x01432A00: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01432A04: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Transform.__il2cppRuntimeField
            // 0x01432A08: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01432A0C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(UnityEngine.Transform))
            // 0x01432A10: MOV x25, x0                | X25 = val_6;//m1                        
            val_15 = val_6;
            // 0x01432A14: B.EQ #0x1432a40            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x01432A18: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01432A1C: MOV x8, sp                 | X8 = 1152921510110754992 (0x10000001480EF8B0);//ML01
            // 0x01432A20: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01432A24: LDR x0, [sp]               | X0 = val_8;                              //  find_add[1152921510110743088]
            // 0x01432A28: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x01432A2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01432A30: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x01432A34: MOV x0, sp                 | X0 = 1152921510110754992 (0x10000001480EF8B0);//ML01
            // 0x01432A38: BL #0x299a140              | 
            // 0x01432A3C: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_10:
            // 0x01432A40: CBNZ x19, #0x1432a48       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x01432A44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001480EF8B0, ????);
            label_11:
            // 0x01432A48: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01432A4C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01432A50: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x01432A54: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01432A58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432A5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432A60: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01432A64: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01432A68: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01432A6C: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x01432A70: LDR x8, [x8, #0x328]       | X8 = 1152921504887730176;               
            // 0x01432A74: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x01432A78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432A7C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01432A80: LDR x1, [x8]               | X1 = typeof(CameraHelper);              
            // 0x01432A84: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01432A88: MOV x24, x0                | X24 = val_10;//m1                       
            // 0x01432A8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432A90: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01432A94: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x01432A98: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01432A9C: MOV x3, x21                | X3 = X3;//m1                            
            // 0x01432AA0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_11 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01432AA4: MOV x2, x0                 | X2 = val_11;//m1                        
            // 0x01432AA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432AAC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432AB0: MOV x1, x24                | X1 = val_10;//m1                        
            // 0x01432AB4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            object val_12 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            // 0x01432AB8: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x01432ABC: CBZ x0, #0x1432b20         | if (val_12 == null) goto label_14;      
            if(val_12 == null)
            {
                goto label_14;
            }
            // 0x01432AC0: ADRP x9, #0x3611000        | X9 = 56692736 (0x3611000);              
            // 0x01432AC4: LDR x9, [x9, #0x430]       | X9 = 1152921504887730176;               
            // 0x01432AC8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01432ACC: LDR x1, [x9]               | X1 = typeof(CameraHelper);              
            // 0x01432AD0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01432AD4: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01432AD8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01432ADC: B.LO #0x1432af8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x01432AE0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01432AE4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHier
            // 0x01432AE8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01432AEC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01432AF0: MOV x21, x0                | X21 = val_12;//m1                       
            val_16 = val_12;
            // 0x01432AF4: B.EQ #0x1432b20            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_14;
            label_13:
            // 0x01432AF8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01432AFC: ADD x8, sp, #8             | X8 = (1152921510110754992 + 8) = 1152921510110755000 (0x10000001480EF8B8);
            // 0x01432B00: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01432B04: LDR x0, [sp, #8]           | X0 = val_14;                             //  find_add[1152921510110743088]
            // 0x01432B08: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x01432B0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01432B10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x01432B14: ADD x0, sp, #8             | X0 = (1152921510110754992 + 8) = 1152921510110755000 (0x10000001480EF8B8);
            // 0x01432B18: BL #0x299a140              | 
            // 0x01432B1C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_14:
            // 0x01432B20: CBNZ x19, #0x1432b28       | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x01432B24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001480EF8B8, ????);
            label_15:
            // 0x01432B28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01432B2C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01432B30: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x01432B34: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01432B38: CBNZ x21, #0x1432b40       | if (0x0 != 0) goto label_16;            
            if(val_16 != 0)
            {
                goto label_16;
            }
            // 0x01432B3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_16:
            // 0x01432B40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01432B44: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x01432B48: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            // 0x01432B4C: BL #0xb939cc               | val_16.MotionBlur(target:  val_15);     
            val_16.MotionBlur(target:  val_15);
            // 0x01432B50: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01432B54: SUB sp, x29, #0x40         | SP = (1152921510110755072 - 64) = 1152921510110755008 (0x10000001480EF8C0);
            // 0x01432B58: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01432B5C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01432B60: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01432B64: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01432B68: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x01432B6C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01432B70: MOV x19, x0                | 
            // 0x01432B74: MOV x0, sp                 | 
            // 0x01432B78: B #0x1432b84               | 
            // 0x01432B7C: MOV x19, x0                | 
            // 0x01432B80: ADD x0, sp, #8             | 
            label_17:
            // 0x01432B84: BL #0x299a140              | 
            // 0x01432B88: MOV x0, x19                | 
            // 0x01432B8C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01432B90 (21179280), len: 616  VirtAddr: 0x01432B90 RVA: 0x01432B90 token: 100664150 methodIndex: 30197 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* ScreenShake_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_10;
            //  | 
            var val_11;
            // 0x01432B90: STP d9, d8, [sp, #-0x50]!  | stack[1152921510110936640] = ???;  stack[1152921510110936648] = ???;  //  dest_result_addr=1152921510110936640 |  dest_result_addr=1152921510110936648
            // 0x01432B94: STP x24, x23, [sp, #0x10]  | stack[1152921510110936656] = ???;  stack[1152921510110936664] = ???;  //  dest_result_addr=1152921510110936656 |  dest_result_addr=1152921510110936664
            // 0x01432B98: STP x22, x21, [sp, #0x20]  | stack[1152921510110936672] = ???;  stack[1152921510110936680] = ???;  //  dest_result_addr=1152921510110936672 |  dest_result_addr=1152921510110936680
            // 0x01432B9C: STP x20, x19, [sp, #0x30]  | stack[1152921510110936688] = ???;  stack[1152921510110936696] = ???;  //  dest_result_addr=1152921510110936688 |  dest_result_addr=1152921510110936696
            // 0x01432BA0: STP x29, x30, [sp, #0x40]  | stack[1152921510110936704] = ???;  stack[1152921510110936712] = ???;  //  dest_result_addr=1152921510110936704 |  dest_result_addr=1152921510110936712
            // 0x01432BA4: ADD x29, sp, #0x40         | X29 = (1152921510110936640 + 64) = 1152921510110936704 (0x100000014811BE80);
            // 0x01432BA8: SUB sp, sp, #0x10          | SP = (1152921510110936640 - 16) = 1152921510110936624 (0x100000014811BE30);
            // 0x01432BAC: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01432BB0: LDRB w8, [x20, #0x35]      | W8 = (bool)static_value_03737035;       
            // 0x01432BB4: MOV x22, x3                | X22 = X3;//m1                           
            // 0x01432BB8: MOV x21, x2                | X21 = X2;//m1                           
            // 0x01432BBC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01432BC0: TBNZ w8, #0, #0x1432bdc    | if (static_value_03737035 == true) goto label_0;
            // 0x01432BC4: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x01432BC8: LDR x8, [x8, #0x7c8]       | X8 = 0x2B901CC;                         
            // 0x01432BCC: LDR w0, [x8]               | W0 = 0x1737;                            
            // 0x01432BD0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1737, ????);     
            // 0x01432BD4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01432BD8: STRB w8, [x20, #0x35]      | static_value_03737035 = true;            //  dest_result_addr=57897013
            label_0:
            // 0x01432BDC: CBNZ x19, #0x1432be4       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01432BE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1737, ????);     
            label_1:
            // 0x01432BE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01432BE8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01432BEC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01432BF0: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01432BF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432BF8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432BFC: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x01432C00: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01432C04: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01432C08: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01432C0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432C10: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432C14: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01432C18: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01432C1C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01432C20: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x01432C24: CBNZ x24, #0x1432c2c       | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x01432C28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x01432C2C: LDR s8, [x24, #4]          | S8 = val_3 + 4;                         
            // 0x01432C30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432C34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432C38: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01432C3C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01432C40: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01432C44: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01432C48: CBNZ x24, #0x1432c50       | if (val_4 != 0) goto label_3;           
            if(val_4 != 0)
            {
                goto label_3;
            }
            // 0x01432C4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_3:
            // 0x01432C50: LDR s9, [x24, #4]          | S9 = val_4 + 4;                         
            // 0x01432C54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432C58: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432C5C: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x01432C60: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01432C64: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_5 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01432C68: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01432C6C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01432C70: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
            // 0x01432C74: MOV x21, x0                | X21 = val_5;//m1                        
            // 0x01432C78: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01432C7C: LDR x9, [x9, #0x328]       | X9 = 1152921504887730176;               
            // 0x01432C80: LDR x24, [x9]              | X24 = typeof(CameraHelper);             
            // 0x01432C84: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01432C88: TBZ w9, #0, #0x1432c9c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01432C8C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01432C90: CBNZ w9, #0x1432c9c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01432C94: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01432C98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_5:
            // 0x01432C9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432CA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01432CA4: MOV x1, x24                | X1 = 1152921504887730176 (0x1000000010BDF000);//ML01
            // 0x01432CA8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01432CAC: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01432CB0: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01432CB4: MOV x24, x0                | X24 = val_6;//m1                        
            // 0x01432CB8: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01432CBC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01432CC0: TBZ w9, #0, #0x1432cd4     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01432CC4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01432CC8: CBNZ w9, #0x1432cd4        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01432CCC: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01432CD0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_7:
            // 0x01432CD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432CD8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01432CDC: MOV x1, x21                | X1 = val_5;//m1                         
            // 0x01432CE0: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01432CE4: MOV x3, x22                | X3 = X3;//m1                            
            // 0x01432CE8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_7 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01432CEC: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01432CF0: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01432CF4: MOV x22, x0                | X22 = val_7;//m1                        
            // 0x01432CF8: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01432CFC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01432D00: TBZ w9, #0, #0x1432d14     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x01432D04: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01432D08: CBNZ w9, #0x1432d14        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x01432D0C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01432D10: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_9:
            // 0x01432D14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432D18: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432D1C: MOV x1, x24                | X1 = val_6;//m1                         
            // 0x01432D20: MOV x2, x22                | X2 = val_7;//m1                         
            // 0x01432D24: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_6);
            object val_8 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_6);
            // 0x01432D28: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x01432D2C: CBZ x0, #0x1432d90         | if (val_8 == null) goto label_12;       
            if(val_8 == null)
            {
                goto label_12;
            }
            // 0x01432D30: ADRP x9, #0x3611000        | X9 = 56692736 (0x3611000);              
            // 0x01432D34: LDR x9, [x9, #0x430]       | X9 = 1152921504887730176;               
            // 0x01432D38: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01432D3C: LDR x1, [x9]               | X1 = typeof(CameraHelper);              
            // 0x01432D40: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01432D44: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01432D48: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01432D4C: B.LO #0x1432d68            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_11;
            // 0x01432D50: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01432D54: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHier
            // 0x01432D58: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01432D5C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01432D60: MOV x22, x0                | X22 = val_8;//m1                        
            val_11 = val_8;
            // 0x01432D64: B.EQ #0x1432d90            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_12;
            label_11:
            // 0x01432D68: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01432D6C: ADD x8, sp, #8             | X8 = (1152921510110936624 + 8) = 1152921510110936632 (0x100000014811BE38);
            // 0x01432D70: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01432D74: LDR x0, [sp, #8]           | X0 = val_10;                             //  find_add[1152921510110924720]
            // 0x01432D78: BL #0x27af090              | X0 = sub_27AF090( ?? val_10, ????);     
            // 0x01432D7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01432D80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            // 0x01432D84: ADD x0, sp, #8             | X0 = (1152921510110936624 + 8) = 1152921510110936632 (0x100000014811BE38);
            // 0x01432D88: BL #0x299a140              | 
            // 0x01432D8C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_12:
            // 0x01432D90: CBNZ x19, #0x1432d98       | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x01432D94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014811BE38, ????);
            label_13:
            // 0x01432D98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01432D9C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01432DA0: MOV x1, x21                | X1 = val_5;//m1                         
            // 0x01432DA4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01432DA8: CBNZ x22, #0x1432db0       | if (0x0 != 0) goto label_14;            
            if(val_11 != 0)
            {
                goto label_14;
            }
            // 0x01432DAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_14:
            // 0x01432DB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01432DB4: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x01432DB8: MOV v0.16b, v9.16b         | V0 = val_4 + 4;//m1                     
            // 0x01432DBC: MOV v1.16b, v8.16b         | V1 = val_3 + 4;//m1                     
            // 0x01432DC0: BL #0xbac05c               | val_11.ScreenShake(_fps:  val_4 + 4, _shakeTime:  val_3 + 4);
            val_11.ScreenShake(_fps:  val_4 + 4, _shakeTime:  val_3 + 4);
            // 0x01432DC4: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01432DC8: SUB sp, x29, #0x40         | SP = (1152921510110936704 - 64) = 1152921510110936640 (0x100000014811BE40);
            // 0x01432DCC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01432DD0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01432DD4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01432DD8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01432DDC: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
            // 0x01432DE0: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01432DE4: MOV x19, x0                | 
            // 0x01432DE8: ADD x0, sp, #8             | 
            // 0x01432DEC: BL #0x299a140              | 
            // 0x01432DF0: MOV x0, x19                | 
            // 0x01432DF4: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01432DF8 (21179896), len: 664  VirtAddr: 0x01432DF8 RVA: 0x01432DF8 token: 100664151 methodIndex: 30198 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* ScreenShake_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x01432DF8: STP d11, d10, [sp, #-0x60]! | stack[1152921510111105968] = ???;  stack[1152921510111105976] = ???;  //  dest_result_addr=1152921510111105968 |  dest_result_addr=1152921510111105976
            // 0x01432DFC: STP d9, d8, [sp, #0x10]    | stack[1152921510111105984] = ???;  stack[1152921510111105992] = ???;  //  dest_result_addr=1152921510111105984 |  dest_result_addr=1152921510111105992
            // 0x01432E00: STP x24, x23, [sp, #0x20]  | stack[1152921510111106000] = ???;  stack[1152921510111106008] = ???;  //  dest_result_addr=1152921510111106000 |  dest_result_addr=1152921510111106008
            // 0x01432E04: STP x22, x21, [sp, #0x30]  | stack[1152921510111106016] = ???;  stack[1152921510111106024] = ???;  //  dest_result_addr=1152921510111106016 |  dest_result_addr=1152921510111106024
            // 0x01432E08: STP x20, x19, [sp, #0x40]  | stack[1152921510111106032] = ???;  stack[1152921510111106040] = ???;  //  dest_result_addr=1152921510111106032 |  dest_result_addr=1152921510111106040
            // 0x01432E0C: STP x29, x30, [sp, #0x50]  | stack[1152921510111106048] = ???;  stack[1152921510111106056] = ???;  //  dest_result_addr=1152921510111106048 |  dest_result_addr=1152921510111106056
            // 0x01432E10: ADD x29, sp, #0x50         | X29 = (1152921510111105968 + 80) = 1152921510111106048 (0x1000000148145400);
            // 0x01432E14: SUB sp, sp, #0x10          | SP = (1152921510111105968 - 16) = 1152921510111105952 (0x10000001481453A0);
            // 0x01432E18: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01432E1C: LDRB w8, [x20, #0x36]      | W8 = (bool)static_value_03737036;       
            // 0x01432E20: MOV x21, x3                | X21 = X3;//m1                           
            // 0x01432E24: MOV x22, x2                | X22 = X2;//m1                           
            // 0x01432E28: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01432E2C: TBNZ w8, #0, #0x1432e48    | if (static_value_03737036 == true) goto label_0;
            // 0x01432E30: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x01432E34: LDR x8, [x8, #0xb98]       | X8 = 0x2B901D0;                         
            // 0x01432E38: LDR w0, [x8]               | W0 = 0x1738;                            
            // 0x01432E3C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1738, ????);     
            // 0x01432E40: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01432E44: STRB w8, [x20, #0x36]      | static_value_03737036 = true;            //  dest_result_addr=57897014
            label_0:
            // 0x01432E48: CBNZ x19, #0x1432e50       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01432E4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1738, ????);     
            label_1:
            // 0x01432E50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01432E54: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01432E58: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01432E5C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01432E60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432E64: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432E68: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x01432E6C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01432E70: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01432E74: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01432E78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432E7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432E80: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01432E84: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01432E88: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01432E8C: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x01432E90: CBNZ x24, #0x1432e98       | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x01432E94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x01432E98: LDR s8, [x24, #4]          | S8 = val_3 + 4;                         
            // 0x01432E9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432EA0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432EA4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01432EA8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01432EAC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01432EB0: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01432EB4: CBNZ x24, #0x1432ebc       | if (val_4 != 0) goto label_3;           
            if(val_4 != 0)
            {
                goto label_3;
            }
            // 0x01432EB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_3:
            // 0x01432EBC: LDR s9, [x24, #4]          | S9 = val_4 + 4;                         
            // 0x01432EC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432EC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432EC8: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x01432ECC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01432ED0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_5 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01432ED4: MOV x24, x0                | X24 = val_5;//m1                        
            // 0x01432ED8: CBNZ x24, #0x1432ee0       | if (val_5 != 0) goto label_4;           
            if(val_5 != 0)
            {
                goto label_4;
            }
            // 0x01432EDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_4:
            // 0x01432EE0: LDR s10, [x24, #4]         | S10 = val_5 + 4;                        
            // 0x01432EE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432EE8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432EEC: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x01432EF0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01432EF4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_6 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01432EF8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01432EFC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01432F00: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
            // 0x01432F04: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x01432F08: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01432F0C: LDR x9, [x9, #0x328]       | X9 = 1152921504887730176;               
            // 0x01432F10: LDR x24, [x9]              | X24 = typeof(CameraHelper);             
            // 0x01432F14: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01432F18: TBZ w9, #0, #0x1432f2c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x01432F1C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01432F20: CBNZ w9, #0x1432f2c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x01432F24: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01432F28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_6:
            // 0x01432F2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432F30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01432F34: MOV x1, x24                | X1 = 1152921504887730176 (0x1000000010BDF000);//ML01
            // 0x01432F38: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_7 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01432F3C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01432F40: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01432F44: MOV x24, x0                | X24 = val_7;//m1                        
            // 0x01432F48: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01432F4C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01432F50: TBZ w9, #0, #0x1432f64     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x01432F54: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01432F58: CBNZ w9, #0x1432f64        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x01432F5C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01432F60: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_8:
            // 0x01432F64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432F68: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01432F6C: MOV x1, x22                | X1 = val_6;//m1                         
            // 0x01432F70: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01432F74: MOV x3, x21                | X3 = X3;//m1                            
            // 0x01432F78: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_8 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01432F7C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01432F80: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01432F84: MOV x21, x0                | X21 = val_8;//m1                        
            // 0x01432F88: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01432F8C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01432F90: TBZ w9, #0, #0x1432fa4     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x01432F94: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01432F98: CBNZ w9, #0x1432fa4        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x01432F9C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01432FA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_10:
            // 0x01432FA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01432FA8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01432FAC: MOV x1, x24                | X1 = val_7;//m1                         
            // 0x01432FB0: MOV x2, x21                | X2 = val_8;//m1                         
            // 0x01432FB4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_7);
            object val_9 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_7);
            // 0x01432FB8: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_12 = 0;
            // 0x01432FBC: CBZ x0, #0x1433020         | if (val_9 == null) goto label_13;       
            if(val_9 == null)
            {
                goto label_13;
            }
            // 0x01432FC0: ADRP x9, #0x3611000        | X9 = 56692736 (0x3611000);              
            // 0x01432FC4: LDR x9, [x9, #0x430]       | X9 = 1152921504887730176;               
            // 0x01432FC8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01432FCC: LDR x1, [x9]               | X1 = typeof(CameraHelper);              
            // 0x01432FD0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01432FD4: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01432FD8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01432FDC: B.LO #0x1432ff8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x01432FE0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01432FE4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHier
            // 0x01432FE8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01432FEC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01432FF0: MOV x21, x0                | X21 = val_9;//m1                        
            val_12 = val_9;
            // 0x01432FF4: B.EQ #0x1433020            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x01432FF8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01432FFC: ADD x8, sp, #8             | X8 = (1152921510111105952 + 8) = 1152921510111105960 (0x10000001481453A8);
            // 0x01433000: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01433004: LDR x0, [sp, #8]           | X0 = val_11;                             //  find_add[1152921510111094064]
            // 0x01433008: BL #0x27af090              | X0 = sub_27AF090( ?? val_11, ????);     
            // 0x0143300C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01433010: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            // 0x01433014: ADD x0, sp, #8             | X0 = (1152921510111105952 + 8) = 1152921510111105960 (0x10000001481453A8);
            // 0x01433018: BL #0x299a140              | 
            // 0x0143301C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_12 = 0;
            label_13:
            // 0x01433020: CBNZ x19, #0x1433028       | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x01433024: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001481453A8, ????);
            label_14:
            // 0x01433028: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143302C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01433030: MOV x1, x22                | X1 = val_6;//m1                         
            // 0x01433034: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01433038: CBNZ x21, #0x1433040       | if (0x0 != 0) goto label_15;            
            if(val_12 != 0)
            {
                goto label_15;
            }
            // 0x0143303C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_15:
            // 0x01433040: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01433044: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x01433048: MOV v0.16b, v10.16b        | V0 = val_5 + 4;//m1                     
            // 0x0143304C: MOV v1.16b, v9.16b         | V1 = val_4 + 4;//m1                     
            // 0x01433050: MOV v2.16b, v8.16b         | V2 = val_3 + 4;//m1                     
            // 0x01433054: BL #0xbac14c               | val_12.ScreenShake(_fps:  val_5 + 4, _shakeTime:  val_4 + 4, _shakeDelta:  val_3 + 4);
            val_12.ScreenShake(_fps:  val_5 + 4, _shakeTime:  val_4 + 4, _shakeDelta:  val_3 + 4);
            // 0x01433058: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0143305C: SUB sp, x29, #0x50         | SP = (1152921510111106048 - 80) = 1152921510111105968 (0x10000001481453B0);
            // 0x01433060: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01433064: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01433068: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x0143306C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x01433070: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x01433074: LDP d11, d10, [sp], #0x60  | D11 = ; D10 = ;                          //  | 
            // 0x01433078: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0143307C: MOV x19, x0                | 
            // 0x01433080: ADD x0, sp, #8             | 
            // 0x01433084: BL #0x299a140              | 
            // 0x01433088: MOV x0, x19                | 
            // 0x0143308C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01433090 (21180560), len: 1016  VirtAddr: 0x01433090 RVA: 0x01433090 token: 100664152 methodIndex: 30199 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* LockView_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_19;
            //  | 
            string val_21;
            //  | 
            var val_22;
            // 0x01433090: STP d11, d10, [sp, #-0x80]! | stack[1152921510111287568] = ???;  stack[1152921510111287576] = ???;  //  dest_result_addr=1152921510111287568 |  dest_result_addr=1152921510111287576
            // 0x01433094: STP d9, d8, [sp, #0x10]    | stack[1152921510111287584] = ???;  stack[1152921510111287592] = ???;  //  dest_result_addr=1152921510111287584 |  dest_result_addr=1152921510111287592
            // 0x01433098: STP x28, x27, [sp, #0x20]  | stack[1152921510111287600] = ???;  stack[1152921510111287608] = ???;  //  dest_result_addr=1152921510111287600 |  dest_result_addr=1152921510111287608
            // 0x0143309C: STP x26, x25, [sp, #0x30]  | stack[1152921510111287616] = ???;  stack[1152921510111287624] = ???;  //  dest_result_addr=1152921510111287616 |  dest_result_addr=1152921510111287624
            // 0x014330A0: STP x24, x23, [sp, #0x40]  | stack[1152921510111287632] = ???;  stack[1152921510111287640] = ???;  //  dest_result_addr=1152921510111287632 |  dest_result_addr=1152921510111287640
            // 0x014330A4: STP x22, x21, [sp, #0x50]  | stack[1152921510111287648] = ???;  stack[1152921510111287656] = ???;  //  dest_result_addr=1152921510111287648 |  dest_result_addr=1152921510111287656
            // 0x014330A8: STP x20, x19, [sp, #0x60]  | stack[1152921510111287664] = ???;  stack[1152921510111287672] = ???;  //  dest_result_addr=1152921510111287664 |  dest_result_addr=1152921510111287672
            // 0x014330AC: STP x29, x30, [sp, #0x70]  | stack[1152921510111287680] = ???;  stack[1152921510111287688] = ???;  //  dest_result_addr=1152921510111287680 |  dest_result_addr=1152921510111287688
            // 0x014330B0: ADD x29, sp, #0x70         | X29 = (1152921510111287568 + 112) = 1152921510111287680 (0x1000000148171980);
            // 0x014330B4: SUB sp, sp, #0x10          | SP = (1152921510111287568 - 16) = 1152921510111287552 (0x1000000148171900);
            // 0x014330B8: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x014330BC: LDRB w8, [x20, #0x37]      | W8 = (bool)static_value_03737037;       
            // 0x014330C0: MOV x21, x3                | X21 = X3;//m1                           
            // 0x014330C4: MOV x22, x2                | X22 = X2;//m1                           
            // 0x014330C8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x014330CC: TBNZ w8, #0, #0x14330e8    | if (static_value_03737037 == true) goto label_0;
            // 0x014330D0: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x014330D4: LDR x8, [x8, #0xdd0]       | X8 = 0x2B901AC;                         
            // 0x014330D8: LDR w0, [x8]               | W0 = 0x172F;                            
            // 0x014330DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x172F, ????);     
            // 0x014330E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x014330E4: STRB w8, [x20, #0x37]      | static_value_03737037 = true;            //  dest_result_addr=57897015
            label_0:
            // 0x014330E8: CBNZ x19, #0x14330f0       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x014330EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x172F, ????);     
            label_1:
            // 0x014330F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014330F4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014330F8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x014330FC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01433100: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01433104: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01433108: ORR w2, wzr, #8            | W2 = 8(0x8);                            
            // 0x0143310C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01433110: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01433114: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01433118: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143311C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01433120: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01433124: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01433128: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143312C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01433130: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01433134: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x01433138: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x0143313C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01433140: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x01433144: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x01433148: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0143314C: TBZ w9, #0, #0x1433160     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01433150: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01433154: CBNZ w9, #0x1433160        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01433158: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0143315C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01433160: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01433164: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01433168: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0143316C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01433170: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01433174: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01433178: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x0143317C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01433180: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01433184: TBZ w9, #0, #0x1433198     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01433188: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0143318C: CBNZ w9, #0x1433198        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01433190: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01433194: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01433198: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143319C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x014331A0: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x014331A4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x014331A8: MOV x3, x21                | X3 = X3;//m1                            
            // 0x014331AC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x014331B0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x014331B4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x014331B8: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x014331BC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x014331C0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x014331C4: TBZ w9, #0, #0x14331d8     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x014331C8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x014331CC: CBNZ w9, #0x14331d8        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x014331D0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x014331D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x014331D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014331DC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014331E0: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x014331E4: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x014331E8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x014331EC: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_21 = 0;
            // 0x014331F0: CBZ x0, #0x1433238         | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x014331F4: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x014331F8: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x014331FC: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01433200: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01433204: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x01433208: MOV x24, x0                | X24 = val_6;//m1                        
            val_21 = val_6;
            // 0x0143320C: B.EQ #0x1433238            | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x01433210: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01433214: MOV x8, sp                 | X8 = 1152921510111287552 (0x1000000148171900);//ML01
            // 0x01433218: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0143321C: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510111275696]
            // 0x01433220: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x01433224: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01433228: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x0143322C: MOV x0, sp                 | X0 = 1152921510111287552 (0x1000000148171900);//ML01
            // 0x01433230: BL #0x299a140              | 
            // 0x01433234: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_21 = 0;
            label_9:
            // 0x01433238: CBNZ x19, #0x1433240       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x0143323C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148171900, ????);
            label_10:
            // 0x01433240: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01433244: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01433248: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x0143324C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01433250: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01433254: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01433258: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0143325C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01433260: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01433264: MOV x25, x0                | X25 = val_8;//m1                        
            // 0x01433268: CBNZ x25, #0x1433270       | if (val_8 != 0) goto label_11;          
            if(val_8 != 0)
            {
                goto label_11;
            }
            // 0x0143326C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_11:
            // 0x01433270: LDR s8, [x25, #4]          | S8 = val_8 + 4;                         
            // 0x01433274: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01433278: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143327C: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x01433280: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01433284: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01433288: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x0143328C: CBNZ x25, #0x1433294       | if (val_9 != 0) goto label_12;          
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x01433290: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_12:
            // 0x01433294: LDR s9, [x25, #4]          | S9 = val_9 + 4;                         
            // 0x01433298: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143329C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014332A0: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x014332A4: MOV x1, x22                | X1 = X2;//m1                            
            // 0x014332A8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_10 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014332AC: MOV x25, x0                | X25 = val_10;//m1                       
            // 0x014332B0: CBNZ x25, #0x14332b8       | if (val_10 != 0) goto label_13;         
            if(val_10 != 0)
            {
                goto label_13;
            }
            // 0x014332B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_13:
            // 0x014332B8: LDR s10, [x25, #4]         | S10 = val_10 + 4;                       
            // 0x014332BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014332C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014332C4: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x014332C8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x014332CC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_11 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014332D0: MOV x25, x0                | X25 = val_11;//m1                       
            // 0x014332D4: CBNZ x25, #0x14332dc       | if (val_11 != 0) goto label_14;         
            if(val_11 != 0)
            {
                goto label_14;
            }
            // 0x014332D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_14:
            // 0x014332DC: LDR s11, [x25, #4]         | S11 = val_11 + 4;                       
            // 0x014332E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014332E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014332E8: ORR w2, wzr, #6            | W2 = 6(0x6);                            
            // 0x014332EC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x014332F0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_12 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014332F4: MOV x25, x0                | X25 = val_12;//m1                       
            // 0x014332F8: CBNZ x25, #0x1433300       | if (val_12 != 0) goto label_15;         
            if(val_12 != 0)
            {
                goto label_15;
            }
            // 0x014332FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_15:
            // 0x01433300: LDR w25, [x25, #4]         | W25 = val_12 + 4;                       
            // 0x01433304: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01433308: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143330C: ORR w2, wzr, #7            | W2 = 7(0x7);                            
            // 0x01433310: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01433314: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_13 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01433318: MOV x26, x0                | X26 = val_13;//m1                       
            // 0x0143331C: CBNZ x26, #0x1433324       | if (val_13 != 0) goto label_16;         
            if(val_13 != 0)
            {
                goto label_16;
            }
            // 0x01433320: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_16:
            // 0x01433324: LDR w27, [x26, #4]         | W27 = val_13 + 4;                       
            // 0x01433328: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143332C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01433330: ORR w2, wzr, #8            | W2 = 8(0x8);                            
            // 0x01433334: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01433338: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_14 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143333C: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x01433340: LDR x8, [x8, #0x328]       | X8 = 1152921504887730176;               
            // 0x01433344: MOV x22, x0                | X22 = val_14;//m1                       
            // 0x01433348: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143334C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01433350: LDR x1, [x8]               | X1 = typeof(CameraHelper);              
            // 0x01433354: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_15 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01433358: MOV x26, x0                | X26 = val_15;//m1                       
            // 0x0143335C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01433360: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01433364: MOV x1, x22                | X1 = val_14;//m1                        
            // 0x01433368: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0143336C: MOV x3, x21                | X3 = X3;//m1                            
            // 0x01433370: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_16 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01433374: MOV x2, x0                 | X2 = val_16;//m1                        
            // 0x01433378: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143337C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01433380: MOV x1, x26                | X1 = val_15;//m1                        
            // 0x01433384: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_15);
            object val_17 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_15);
            // 0x01433388: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x0143338C: CBZ x0, #0x14333f0         | if (val_17 == null) goto label_19;      
            if(val_17 == null)
            {
                goto label_19;
            }
            // 0x01433390: ADRP x9, #0x3611000        | X9 = 56692736 (0x3611000);              
            // 0x01433394: LDR x9, [x9, #0x430]       | X9 = 1152921504887730176;               
            // 0x01433398: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0143339C: LDR x1, [x9]               | X1 = typeof(CameraHelper);              
            // 0x014333A0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014333A4: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014333A8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014333AC: B.LO #0x14333c8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_18;
            // 0x014333B0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x014333B4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHier
            // 0x014333B8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014333BC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x014333C0: MOV x21, x0                | X21 = val_17;//m1                       
            val_22 = val_17;
            // 0x014333C4: B.EQ #0x14333f0            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_19;
            label_18:
            // 0x014333C8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x014333CC: ADD x8, sp, #8             | X8 = (1152921510111287552 + 8) = 1152921510111287560 (0x1000000148171908);
            // 0x014333D0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x014333D4: LDR x0, [sp, #8]           | X0 = val_19;                             //  find_add[1152921510111275696]
            // 0x014333D8: BL #0x27af090              | X0 = sub_27AF090( ?? val_19, ????);     
            // 0x014333DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014333E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            // 0x014333E4: ADD x0, sp, #8             | X0 = (1152921510111287552 + 8) = 1152921510111287560 (0x1000000148171908);
            // 0x014333E8: BL #0x299a140              | 
            // 0x014333EC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_22 = 0;
            label_19:
            // 0x014333F0: CBNZ x19, #0x14333f8       | if (X1 != 0) goto label_20;             
            if(X1 != 0)
            {
                goto label_20;
            }
            // 0x014333F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148171908, ????);
            label_20:
            // 0x014333F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014333FC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01433400: MOV x1, x22                | X1 = val_14;//m1                        
            // 0x01433404: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01433408: CBNZ x21, #0x1433410       | if (0x0 != 0) goto label_21;            
            if(val_22 != 0)
            {
                goto label_21;
            }
            // 0x0143340C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_21:
            // 0x01433410: CMP w27, #1                | STATE = COMPARE(val_13 + 4, 0x1)        
            // 0x01433414: CSET w1, eq                | W1 = val_13 + 4 == 0x1 ? 1 : 0;         
            bool val_20 = ((val_13 + 4) == 1) ? 1 : 0;
            // 0x01433418: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143341C: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x01433420: MOV w2, w25                | W2 = val_12 + 4;//m1                    
            // 0x01433424: MOV v0.16b, v11.16b        | V0 = val_11 + 4;//m1                    
            // 0x01433428: MOV v1.16b, v10.16b        | V1 = val_10 + 4;//m1                    
            // 0x0143342C: MOV v2.16b, v9.16b         | V2 = val_9 + 4;//m1                     
            // 0x01433430: MOV v3.16b, v8.16b         | V3 = val_8 + 4;//m1                     
            // 0x01433434: MOV x3, x24                | X3 = 0 (0x0);//ML01                     
            // 0x01433438: BL #0xbac24c               | val_22.LockView(isHero:  bool val_20 = ((val_13 + 4) == 1) ? 1 : 0, id:  val_12 + 4, fov:  val_11 + 4, dis:  val_10 + 4, rx:  val_9 + 4, ry:  val_8 + 4, objName:  val_21);
            val_22.LockView(isHero:  val_20, id:  val_12 + 4, fov:  val_11 + 4, dis:  val_10 + 4, rx:  val_9 + 4, ry:  val_8 + 4, objName:  val_21);
            // 0x0143343C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01433440: SUB sp, x29, #0x70         | SP = (1152921510111287680 - 112) = 1152921510111287568 (0x1000000148171910);
            // 0x01433444: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
            // 0x01433448: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
            // 0x0143344C: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
            // 0x01433450: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
            // 0x01433454: LDP x26, x25, [sp, #0x30]  | X26 = ; X25 = ;                          //  | 
            // 0x01433458: LDP x28, x27, [sp, #0x20]  | X28 = ; X27 = ;                          //  | 
            // 0x0143345C: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x01433460: LDP d11, d10, [sp], #0x80  | D11 = ; D10 = ;                          //  | 
            // 0x01433464: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01433468: MOV x19, x0                | 
            // 0x0143346C: ADD x0, sp, #8             | 
            // 0x01433470: B #0x143347c               | 
            // 0x01433474: MOV x19, x0                | 
            // 0x01433478: MOV x0, sp                 | 
            label_22:
            // 0x0143347C: BL #0x299a140              | 
            // 0x01433480: MOV x0, x19                | 
            // 0x01433484: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01433488 (21181576), len: 528  VirtAddr: 0x01433488 RVA: 0x01433488 token: 100664153 methodIndex: 30200 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* UnLockView_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x01433488: STP x24, x23, [sp, #-0x40]! | stack[1152921510111469264] = ???;  stack[1152921510111469272] = ???;  //  dest_result_addr=1152921510111469264 |  dest_result_addr=1152921510111469272
            // 0x0143348C: STP x22, x21, [sp, #0x10]  | stack[1152921510111469280] = ???;  stack[1152921510111469288] = ???;  //  dest_result_addr=1152921510111469280 |  dest_result_addr=1152921510111469288
            // 0x01433490: STP x20, x19, [sp, #0x20]  | stack[1152921510111469296] = ???;  stack[1152921510111469304] = ???;  //  dest_result_addr=1152921510111469296 |  dest_result_addr=1152921510111469304
            // 0x01433494: STP x29, x30, [sp, #0x30]  | stack[1152921510111469312] = ???;  stack[1152921510111469320] = ???;  //  dest_result_addr=1152921510111469312 |  dest_result_addr=1152921510111469320
            // 0x01433498: ADD x29, sp, #0x30         | X29 = (1152921510111469264 + 48) = 1152921510111469312 (0x100000014819DF00);
            // 0x0143349C: SUB sp, sp, #0x10          | SP = (1152921510111469264 - 16) = 1152921510111469248 (0x100000014819DEC0);
            // 0x014334A0: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x014334A4: LDRB w8, [x20, #0x38]      | W8 = (bool)static_value_03737038;       
            // 0x014334A8: MOV x22, x3                | X22 = X3;//m1                           
            // 0x014334AC: MOV x21, x2                | X21 = X2;//m1                           
            // 0x014334B0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x014334B4: TBNZ w8, #0, #0x14334d0    | if (static_value_03737038 == true) goto label_0;
            // 0x014334B8: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x014334BC: LDR x8, [x8, #0x538]       | X8 = 0x2B901EC;                         
            // 0x014334C0: LDR w0, [x8]               | W0 = 0x173F;                            
            // 0x014334C4: BL #0x2782188              | X0 = sub_2782188( ?? 0x173F, ????);     
            // 0x014334C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x014334CC: STRB w8, [x20, #0x38]      | static_value_03737038 = true;            //  dest_result_addr=57897016
            label_0:
            // 0x014334D0: CBNZ x19, #0x14334d8       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x014334D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x173F, ????);     
            label_1:
            // 0x014334D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014334DC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014334E0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x014334E4: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x014334E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014334EC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014334F0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x014334F4: MOV x1, x21                | X1 = X2;//m1                            
            // 0x014334F8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014334FC: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01433500: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01433504: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01433508: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0143350C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01433510: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01433514: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01433518: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0143351C: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
            // 0x01433520: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x01433524: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01433528: LDR x9, [x9, #0x328]       | X9 = 1152921504887730176;               
            // 0x0143352C: LDR x24, [x9]              | X24 = typeof(CameraHelper);             
            // 0x01433530: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01433534: TBZ w9, #0, #0x1433548     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01433538: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0143353C: CBNZ w9, #0x1433548        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01433540: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01433544: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01433548: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143354C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01433550: MOV x1, x24                | X1 = 1152921504887730176 (0x1000000010BDF000);//ML01
            // 0x01433554: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01433558: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0143355C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01433560: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01433564: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01433568: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0143356C: TBZ w9, #0, #0x1433580     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01433570: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01433574: CBNZ w9, #0x1433580        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01433578: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0143357C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01433580: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01433584: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01433588: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x0143358C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01433590: MOV x3, x22                | X3 = X3;//m1                            
            // 0x01433594: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01433598: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0143359C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x014335A0: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x014335A4: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x014335A8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x014335AC: TBZ w9, #0, #0x14335c0     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x014335B0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x014335B4: CBNZ w9, #0x14335c0        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x014335B8: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x014335BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x014335C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014335C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014335C8: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x014335CC: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x014335D0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x014335D4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x014335D8: CBZ x0, #0x143363c         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x014335DC: ADRP x9, #0x3611000        | X9 = 56692736 (0x3611000);              
            // 0x014335E0: LDR x9, [x9, #0x430]       | X9 = 1152921504887730176;               
            // 0x014335E4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x014335E8: LDR x1, [x9]               | X1 = typeof(CameraHelper);              
            // 0x014335EC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014335F0: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014335F4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014335F8: B.LO #0x1433614            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x014335FC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01433600: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHier
            // 0x01433604: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01433608: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x0143360C: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x01433610: B.EQ #0x143363c            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x01433614: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01433618: ADD x8, sp, #8             | X8 = (1152921510111469248 + 8) = 1152921510111469256 (0x100000014819DEC8);
            // 0x0143361C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01433620: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510111457328]
            // 0x01433624: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x01433628: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143362C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x01433630: ADD x0, sp, #8             | X0 = (1152921510111469248 + 8) = 1152921510111469256 (0x100000014819DEC8);
            // 0x01433634: BL #0x299a140              | 
            // 0x01433638: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x0143363C: CBNZ x19, #0x1433644       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x01433640: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014819DEC8, ????);
            label_11:
            // 0x01433644: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01433648: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143364C: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01433650: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01433654: CBNZ x22, #0x143365c       | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x01433658: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x0143365C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01433660: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x01433664: BL #0xbac66c               | val_9.UnLockView();                     
            val_9.UnLockView();
            // 0x01433668: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0143366C: SUB sp, x29, #0x30         | SP = (1152921510111469312 - 48) = 1152921510111469264 (0x100000014819DED0);
            // 0x01433670: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01433674: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01433678: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0143367C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01433680: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01433684: MOV x19, x0                | 
            // 0x01433688: ADD x0, sp, #8             | 
            // 0x0143368C: BL #0x299a140              | 
            // 0x01433690: MOV x0, x19                | 
            // 0x01433694: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01433698 (21182104), len: 72  VirtAddr: 0x01433698 RVA: 0x01433698 token: 100664154 methodIndex: 30201 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_MOVE_COMPLETE_0(ref object o)
        {
            //
            // Disasemble & Code
            // 0x01433698: STP x20, x19, [sp, #-0x20]! | stack[1152921510111614096] = ???;  stack[1152921510111614104] = ???;  //  dest_result_addr=1152921510111614096 |  dest_result_addr=1152921510111614104
            // 0x0143369C: STP x29, x30, [sp, #0x10]  | stack[1152921510111614112] = ???;  stack[1152921510111614120] = ???;  //  dest_result_addr=1152921510111614112 |  dest_result_addr=1152921510111614120
            // 0x014336A0: ADD x29, sp, #0x10         | X29 = (1152921510111614096 + 16) = 1152921510111614112 (0x10000001481C14A0);
            // 0x014336A4: ADRP x19, #0x3737000       | X19 = 57896960 (0x3737000);             
            // 0x014336A8: LDRB w8, [x19, #0x39]      | W8 = (bool)static_value_03737039;       
            // 0x014336AC: TBNZ w8, #0, #0x14336c8    | if (static_value_03737039 == true) goto label_0;
            // 0x014336B0: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x014336B4: LDR x8, [x8, #0x360]       | X8 = 0x2B901A4;                         
            // 0x014336B8: LDR w0, [x8]               | W0 = 0x172D;                            
            // 0x014336BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x172D, ????);     
            // 0x014336C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x014336C4: STRB w8, [x19, #0x39]      | static_value_03737039 = true;            //  dest_result_addr=57897017
            label_0:
            // 0x014336C8: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
            // 0x014336CC: LDR x8, [x8, #0x618]       | X8 = (string**)(1152921510111602016)("Camera_MOVE_COMPLETE");
            // 0x014336D0: LDR x0, [x8]               | X0 = "Camera_MOVE_COMPLETE";            
            // 0x014336D4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x014336D8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x014336DC: RET                        |  return (System.Object)"Camera_MOVE_COMPLETE";
            return (object)"Camera_MOVE_COMPLETE";
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x014336E0 (21182176), len: 72  VirtAddr: 0x014336E0 RVA: 0x014336E0 token: 100664155 methodIndex: 30202 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_CHANGE_TARGET_COMPLETE_1(ref object o)
        {
            //
            // Disasemble & Code
            // 0x014336E0: STP x20, x19, [sp, #-0x20]! | stack[1152921510111734128] = ???;  stack[1152921510111734136] = ???;  //  dest_result_addr=1152921510111734128 |  dest_result_addr=1152921510111734136
            // 0x014336E4: STP x29, x30, [sp, #0x10]  | stack[1152921510111734144] = ???;  stack[1152921510111734152] = ???;  //  dest_result_addr=1152921510111734144 |  dest_result_addr=1152921510111734152
            // 0x014336E8: ADD x29, sp, #0x10         | X29 = (1152921510111734128 + 16) = 1152921510111734144 (0x10000001481DE980);
            // 0x014336EC: ADRP x19, #0x3737000       | X19 = 57896960 (0x3737000);             
            // 0x014336F0: LDRB w8, [x19, #0x3a]      | W8 = (bool)static_value_0373703A;       
            // 0x014336F4: TBNZ w8, #0, #0x1433710    | if (static_value_0373703A == true) goto label_0;
            // 0x014336F8: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x014336FC: LDR x8, [x8, #0x218]       | X8 = 0x2B90188;                         
            // 0x01433700: LDR w0, [x8]               | W0 = 0x1726;                            
            // 0x01433704: BL #0x2782188              | X0 = sub_2782188( ?? 0x1726, ????);     
            // 0x01433708: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143370C: STRB w8, [x19, #0x3a]      | static_value_0373703A = true;            //  dest_result_addr=57897018
            label_0:
            // 0x01433710: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
            // 0x01433714: LDR x8, [x8, #0xb40]       | X8 = (string**)(1152921510108577632)("CHANGE_TARGET_COMPLETE");
            // 0x01433718: LDR x0, [x8]               | X0 = "CHANGE_TARGET_COMPLETE";          
            // 0x0143371C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01433720: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01433724: RET                        |  return (System.Object)"CHANGE_TARGET_COMPLETE";
            return (object)"CHANGE_TARGET_COMPLETE";
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01433728 (21182248), len: 312  VirtAddr: 0x01433728 RVA: 0x01433728 token: 100664156 methodIndex: 30203 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_fieldMin_2(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01433728: STP x20, x19, [sp, #-0x20]! | stack[1152921510111858256] = ???;  stack[1152921510111858264] = ???;  //  dest_result_addr=1152921510111858256 |  dest_result_addr=1152921510111858264
            // 0x0143372C: STP x29, x30, [sp, #0x10]  | stack[1152921510111858272] = ???;  stack[1152921510111858280] = ???;  //  dest_result_addr=1152921510111858272 |  dest_result_addr=1152921510111858280
            // 0x01433730: ADD x29, sp, #0x10         | X29 = (1152921510111858256 + 16) = 1152921510111858272 (0x10000001481FCE60);
            // 0x01433734: SUB sp, sp, #0x20          | SP = (1152921510111858256 - 32) = 1152921510111858224 (0x10000001481FCE30);
            // 0x01433738: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0143373C: LDRB w8, [x20, #0x3b]      | W8 = (bool)static_value_0373703B;       
            // 0x01433740: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01433744: TBNZ w8, #0, #0x1433760    | if (static_value_0373703B == true) goto label_0;
            // 0x01433748: ADRP x8, #0x35d0000        | X8 = 56426496 (0x35D0000);              
            // 0x0143374C: LDR x8, [x8, #0x10]        | X8 = 0x2B90194;                         
            // 0x01433750: LDR w0, [x8]               | W0 = 0x1729;                            
            // 0x01433754: BL #0x2782188              | X0 = sub_2782188( ?? 0x1729, ????);     
            // 0x01433758: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143375C: STRB w8, [x20, #0x3b]      | static_value_0373703B = true;            //  dest_result_addr=57897019
            label_0:
            // 0x01433760: ADRP x20, #0x3611000       | X20 = 56692736 (0x3611000);             
            // 0x01433764: LDR x19, [x19]             | X19 = X1;                               
            // 0x01433768: LDR x20, [x20, #0x430]     | X20 = 1152921504887730176;              
            // 0x0143376C: CBZ x19, #0x14337c0        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01433770: LDR x8, [x19]              | X8 = X1;                                
            // 0x01433774: LDR x1, [x20]              | X1 = typeof(CameraHelper);              
            // 0x01433778: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x0143377C: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01433780: CMP w10, w9                | STATE = COMPARE(X1 + 260, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01433784: B.LO #0x143379c            | if (X1 + 260 < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01433788: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x0143378C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01433790: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01433794: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01433798: B.EQ #0x14337c4            | if ((X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x0143379C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x014337A0: ADD x8, sp, #0x10          | X8 = (1152921510111858224 + 16) = 1152921510111858240 (0x10000001481FCE40);
            // 0x014337A4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x014337A8: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510111846288]
            // 0x014337AC: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x014337B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014337B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x014337B8: ADD x0, sp, #0x10          | X0 = (1152921510111858224 + 16) = 1152921510111858240 (0x10000001481FCE40);
            // 0x014337BC: BL #0x299a140              | 
            label_1:
            // 0x014337C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001481FCE40, ????);
            label_3:
            // 0x014337C4: LDR x8, [x19]              | X8 = X1;                                
            // 0x014337C8: LDR x1, [x20]              | X1 = typeof(CameraHelper);              
            // 0x014337CC: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x014337D0: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014337D4: CMP w10, w9                | STATE = COMPARE(X1 + 260, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014337D8: B.LO #0x143381c            | if (X1 + 260 < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x014337DC: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x014337E0: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x014337E4: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014337E8: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x014337EC: B.NE #0x143381c            | if ((X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x014337F0: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x014337F4: LDR w8, [x19, #0x18]       | W8 = X1 + 24;                           
            // 0x014337F8: LDR x9, [x9, #0xce8]       | X9 = 1152921504608444416;               
            // 0x014337FC: ADD x1, sp, #0xc           | X1 = (1152921510111858224 + 12) = 1152921510111858236 (0x10000001481FCE3C);
            // 0x01433800: STR w8, [sp, #0xc]         | stack[1152921510111858236] = X1 + 24;    //  dest_result_addr=1152921510111858236
            // 0x01433804: LDR x0, [x9]               | X0 = typeof(System.Single);             
            // 0x01433808: BL #0x27bc028              | X0 = 1152921510111906304 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), X1 + 24);
            // 0x0143380C: SUB sp, x29, #0x10         | SP = (1152921510111858272 - 16) = 1152921510111858256 (0x10000001481FCE50);
            // 0x01433810: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01433814: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01433818: RET                        |  return (System.Object)X1 + 24;         
            return (object)X1 + 24;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x0143381C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01433820: ADD x8, sp, #0x18          | X8 = (1152921510111858224 + 24) = 1152921510111858248 (0x10000001481FCE48);
            // 0x01433824: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01433828: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510111846288]
            // 0x0143382C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01433830: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01433834: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01433838: ADD x0, sp, #0x18          | X0 = (1152921510111858224 + 24) = 1152921510111858248 (0x10000001481FCE48);
            // 0x0143383C: BL #0x299a140              | 
            // 0x01433840: MOV x19, x0                | X19 = 1152921510111858248 (0x10000001481FCE48);//ML01
            // 0x01433844: ADD x0, sp, #0x10          | X0 = (1152921510111858224 + 16) = 1152921510111858240 (0x10000001481FCE40);
            label_6:
            // 0x01433848: BL #0x299a140              | 
            // 0x0143384C: MOV x0, x19                | X0 = 1152921510111858248 (0x10000001481FCE48);//ML01
            // 0x01433850: BL #0x980800               | X0 = sub_980800( ?? 0x10000001481FCE48, ????);
            // 0x01433854: MOV x19, x0                | X19 = 1152921510111858248 (0x10000001481FCE48);//ML01
            // 0x01433858: ADD x0, sp, #0x18          | X0 = (1152921510111858224 + 24) = 1152921510111858248 (0x10000001481FCE48);
            // 0x0143385C: B #0x1433848               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01433860 (21182560), len: 412  VirtAddr: 0x01433860 RVA: 0x01433860 token: 100664157 methodIndex: 30204 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_fieldMin_2(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x01433860: STP x22, x21, [sp, #-0x30]! | stack[1152921510111986464] = ???;  stack[1152921510111986472] = ???;  //  dest_result_addr=1152921510111986464 |  dest_result_addr=1152921510111986472
            // 0x01433864: STP x20, x19, [sp, #0x10]  | stack[1152921510111986480] = ???;  stack[1152921510111986488] = ???;  //  dest_result_addr=1152921510111986480 |  dest_result_addr=1152921510111986488
            // 0x01433868: STP x29, x30, [sp, #0x20]  | stack[1152921510111986496] = ???;  stack[1152921510111986504] = ???;  //  dest_result_addr=1152921510111986496 |  dest_result_addr=1152921510111986504
            // 0x0143386C: ADD x29, sp, #0x20         | X29 = (1152921510111986464 + 32) = 1152921510111986496 (0x100000014821C340);
            // 0x01433870: SUB sp, sp, #0x20          | SP = (1152921510111986464 - 32) = 1152921510111986432 (0x100000014821C300);
            // 0x01433874: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x01433878: LDRB w8, [x21, #0x3c]      | W8 = (bool)static_value_0373703C;       
            // 0x0143387C: MOV x19, x2                | X19 = X2;//m1                           
            // 0x01433880: MOV x20, x1                | X20 = v;//m1                            
            // 0x01433884: TBNZ w8, #0, #0x14338a0    | if (static_value_0373703C == true) goto label_0;
            // 0x01433888: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
            // 0x0143388C: LDR x8, [x8, #0x4c8]       | X8 = 0x2B901D8;                         
            // 0x01433890: LDR w0, [x8]               | W0 = 0x173A;                            
            // 0x01433894: BL #0x2782188              | X0 = sub_2782188( ?? 0x173A, ????);     
            // 0x01433898: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143389C: STRB w8, [x21, #0x3c]      | static_value_0373703C = true;            //  dest_result_addr=57897020
            label_0:
            // 0x014338A0: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x014338A4: CBZ x21, #0x1433958        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x014338A8: ADRP x20, #0x3611000       | X20 = 56692736 (0x3611000);             
            // 0x014338AC: LDR x20, [x20, #0x430]     | X20 = 1152921504887730176;              
            // 0x014338B0: LDR x8, [x21]              | X8 = ;                                  
            // 0x014338B4: LDR x1, [x20]              | X1 = typeof(CameraHelper);              
            // 0x014338B8: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x014338BC: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014338C0: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014338C4: B.LO #0x14338dc            | if (mem[null + 260] < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x014338C8: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x014338CC: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x014338D0: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014338D4: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x014338D8: B.EQ #0x1433904            | if ((mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x014338DC: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x014338E0: ADD x8, sp, #8             | X8 = (1152921510111986432 + 8) = 1152921510111986440 (0x100000014821C308);
            // 0x014338E4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x014338E8: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510111974512]
            // 0x014338EC: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x014338F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014338F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x014338F8: ADD x0, sp, #8             | X0 = (1152921510111986432 + 8) = 1152921510111986440 (0x100000014821C308);
            // 0x014338FC: BL #0x299a140              | 
            // 0x01433900: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014821C308, ????);
            label_3:
            // 0x01433904: LDR x8, [x21]              | X8 = ;                                  
            // 0x01433908: LDR x1, [x20]              | X1 = typeof(CameraHelper);              
            // 0x0143390C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01433910: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01433914: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01433918: B.LO #0x1433930            | if (mem[null + 260] < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x0143391C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01433920: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01433924: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01433928: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x0143392C: B.EQ #0x1433960            | if ((mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01433930: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01433934: ADD x8, sp, #0x10          | X8 = (1152921510111986432 + 16) = 1152921510111986448 (0x100000014821C310);
            // 0x01433938: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x0143393C: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510111974512]
            // 0x01433940: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01433944: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01433948: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x0143394C: ADD x0, sp, #0x10          | X0 = (1152921510111986432 + 16) = 1152921510111986448 (0x100000014821C310);
            // 0x01433950: BL #0x299a140              | 
            // 0x01433954: B #0x143395c               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01433958: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x173A, ????);     
            label_6:
            // 0x0143395C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x01433960: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x01433964: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
            // 0x01433968: LDR x20, [x8]              | X20 = typeof(System.Single);            
            // 0x0143396C: CBNZ x19, #0x1433974       | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x01433970: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x173A, ????);     
            label_7:
            // 0x01433974: LDR x8, [x19]              | X8 = X2;                                
            // 0x01433978: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x0143397C: LDR x8, [x20, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
            // 0x01433980: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Single.__il2cppRuntimeField_element_class)
            // 0x01433984: B.NE #0x14339cc            | if (X2 + 48 != System.Single.__il2cppRuntimeField_element_class) goto label_8;
            // 0x01433988: MOV x0, x19                | X0 = X2;//m1                            
            // 0x0143398C: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x01433990: LDR w8, [x0]               | W8 = X2;                                
            // 0x01433994: STR w8, [x21, #0x18]       | mem[24] = X2;                            //  dest_result_addr=24
            mem[24] = X2;
            // 0x01433998: SUB sp, x29, #0x20         | SP = (1152921510111986496 - 32) = 1152921510111986464 (0x100000014821C320);
            // 0x0143399C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x014339A0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x014339A4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x014339A8: RET                        |  return;                                
            return;
            // 0x014339AC: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x014339B0: ADD x0, sp, #8             | X0 = (1152921510111986512 + 8) = 1152921510111986520 (0x100000014821C358);
            // 0x014339B4: B #0x14339c0               |  goto label_10;                         
            goto label_10;
            // 0x014339B8: MOV x19, x0                | X19 = 1152921510111986520 (0x100000014821C358);//ML01
            val_7;
            // 0x014339BC: ADD x0, sp, #0x10          | X0 = (1152921510111986512 + 16) = 1152921510111986528 (0x100000014821C360);
            label_10:
            // 0x014339C0: BL #0x299a140              | 
            // 0x014339C4: MOV x0, x19                | X0 = 1152921510111986520 (0x100000014821C358);//ML01
            // 0x014339C8: BL #0x980800               | X0 = sub_980800( ?? 0x100000014821C358, ????);
            label_8:
            // 0x014339CC: ADD x8, sp, #0x18          | X8 = (1152921510111986512 + 24) = 1152921510111986536 (0x100000014821C368);
            // 0x014339D0: MOV x1, x20                | X1 = X20;//m1                           
            // 0x014339D4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x100000014821C358, ????);
            // 0x014339D8: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510111974512]
            // 0x014339DC: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x014339E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014339E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x014339E8: ADD x0, sp, #0x18          | X0 = (1152921510111986512 + 24) = 1152921510111986536 (0x100000014821C368);
            // 0x014339EC: BL #0x299a140              | 
            // 0x014339F0: MOV x19, x0                | X19 = 1152921510111986536 (0x100000014821C368);//ML01
            // 0x014339F4: ADD x0, sp, #0x18          | X0 = (1152921510111986512 + 24) = 1152921510111986536 (0x100000014821C368);
            // 0x014339F8: B #0x14339c0               |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x014339FC (21182972), len: 312  VirtAddr: 0x014339FC RVA: 0x014339FC token: 100664158 methodIndex: 30205 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_timeScale_3(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x014339FC: STP x20, x19, [sp, #-0x20]! | stack[1152921510112114704] = ???;  stack[1152921510112114712] = ???;  //  dest_result_addr=1152921510112114704 |  dest_result_addr=1152921510112114712
            // 0x01433A00: STP x29, x30, [sp, #0x10]  | stack[1152921510112114720] = ???;  stack[1152921510112114728] = ???;  //  dest_result_addr=1152921510112114720 |  dest_result_addr=1152921510112114728
            // 0x01433A04: ADD x29, sp, #0x10         | X29 = (1152921510112114704 + 16) = 1152921510112114720 (0x100000014823B820);
            // 0x01433A08: SUB sp, sp, #0x20          | SP = (1152921510112114704 - 32) = 1152921510112114672 (0x100000014823B7F0);
            // 0x01433A0C: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01433A10: LDRB w8, [x20, #0x3d]      | W8 = (bool)static_value_0373703D;       
            // 0x01433A14: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01433A18: TBNZ w8, #0, #0x1433a34    | if (static_value_0373703D == true) goto label_0;
            // 0x01433A1C: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
            // 0x01433A20: LDR x8, [x8, #0xb20]       | X8 = 0x2B901A8;                         
            // 0x01433A24: LDR w0, [x8]               | W0 = 0x172E;                            
            // 0x01433A28: BL #0x2782188              | X0 = sub_2782188( ?? 0x172E, ????);     
            // 0x01433A2C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01433A30: STRB w8, [x20, #0x3d]      | static_value_0373703D = true;            //  dest_result_addr=57897021
            label_0:
            // 0x01433A34: ADRP x20, #0x3611000       | X20 = 56692736 (0x3611000);             
            // 0x01433A38: LDR x19, [x19]             | X19 = X1;                               
            // 0x01433A3C: LDR x20, [x20, #0x430]     | X20 = 1152921504887730176;              
            // 0x01433A40: CBZ x19, #0x1433a94        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01433A44: LDR x8, [x19]              | X8 = X1;                                
            // 0x01433A48: LDR x1, [x20]              | X1 = typeof(CameraHelper);              
            // 0x01433A4C: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01433A50: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01433A54: CMP w10, w9                | STATE = COMPARE(X1 + 260, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01433A58: B.LO #0x1433a70            | if (X1 + 260 < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01433A5C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01433A60: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01433A64: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01433A68: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01433A6C: B.EQ #0x1433a98            | if ((X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01433A70: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01433A74: ADD x8, sp, #0x10          | X8 = (1152921510112114672 + 16) = 1152921510112114688 (0x100000014823B800);
            // 0x01433A78: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01433A7C: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510112102736]
            // 0x01433A80: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01433A84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01433A88: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01433A8C: ADD x0, sp, #0x10          | X0 = (1152921510112114672 + 16) = 1152921510112114688 (0x100000014823B800);
            // 0x01433A90: BL #0x299a140              | 
            label_1:
            // 0x01433A94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014823B800, ????);
            label_3:
            // 0x01433A98: LDR x8, [x19]              | X8 = X1;                                
            // 0x01433A9C: LDR x1, [x20]              | X1 = typeof(CameraHelper);              
            // 0x01433AA0: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01433AA4: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01433AA8: CMP w10, w9                | STATE = COMPARE(X1 + 260, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01433AAC: B.LO #0x1433af0            | if (X1 + 260 < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01433AB0: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01433AB4: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01433AB8: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01433ABC: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01433AC0: B.NE #0x1433af0            | if ((X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01433AC4: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x01433AC8: LDR w8, [x19, #0x1c]       | W8 = X1 + 28;                           
            // 0x01433ACC: LDR x9, [x9, #0xce8]       | X9 = 1152921504608444416;               
            // 0x01433AD0: ADD x1, sp, #0xc           | X1 = (1152921510112114672 + 12) = 1152921510112114684 (0x100000014823B7FC);
            // 0x01433AD4: STR w8, [sp, #0xc]         | stack[1152921510112114684] = X1 + 28;    //  dest_result_addr=1152921510112114684
            // 0x01433AD8: LDR x0, [x9]               | X0 = typeof(System.Single);             
            // 0x01433ADC: BL #0x27bc028              | X0 = 1152921510112162752 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), X1 + 28);
            // 0x01433AE0: SUB sp, x29, #0x10         | SP = (1152921510112114720 - 16) = 1152921510112114704 (0x100000014823B810);
            // 0x01433AE4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01433AE8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01433AEC: RET                        |  return (System.Object)X1 + 28;         
            return (object)X1 + 28;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01433AF0: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01433AF4: ADD x8, sp, #0x18          | X8 = (1152921510112114672 + 24) = 1152921510112114696 (0x100000014823B808);
            // 0x01433AF8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01433AFC: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510112102736]
            // 0x01433B00: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01433B04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01433B08: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01433B0C: ADD x0, sp, #0x18          | X0 = (1152921510112114672 + 24) = 1152921510112114696 (0x100000014823B808);
            // 0x01433B10: BL #0x299a140              | 
            // 0x01433B14: MOV x19, x0                | X19 = 1152921510112114696 (0x100000014823B808);//ML01
            // 0x01433B18: ADD x0, sp, #0x10          | X0 = (1152921510112114672 + 16) = 1152921510112114688 (0x100000014823B800);
            label_6:
            // 0x01433B1C: BL #0x299a140              | 
            // 0x01433B20: MOV x0, x19                | X0 = 1152921510112114696 (0x100000014823B808);//ML01
            // 0x01433B24: BL #0x980800               | X0 = sub_980800( ?? 0x100000014823B808, ????);
            // 0x01433B28: MOV x19, x0                | X19 = 1152921510112114696 (0x100000014823B808);//ML01
            // 0x01433B2C: ADD x0, sp, #0x18          | X0 = (1152921510112114672 + 24) = 1152921510112114696 (0x100000014823B808);
            // 0x01433B30: B #0x1433b1c               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01433B34 (21183284), len: 412  VirtAddr: 0x01433B34 RVA: 0x01433B34 token: 100664159 methodIndex: 30206 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_timeScale_3(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x01433B34: STP x22, x21, [sp, #-0x30]! | stack[1152921510112242912] = ???;  stack[1152921510112242920] = ???;  //  dest_result_addr=1152921510112242912 |  dest_result_addr=1152921510112242920
            // 0x01433B38: STP x20, x19, [sp, #0x10]  | stack[1152921510112242928] = ???;  stack[1152921510112242936] = ???;  //  dest_result_addr=1152921510112242928 |  dest_result_addr=1152921510112242936
            // 0x01433B3C: STP x29, x30, [sp, #0x20]  | stack[1152921510112242944] = ???;  stack[1152921510112242952] = ???;  //  dest_result_addr=1152921510112242944 |  dest_result_addr=1152921510112242952
            // 0x01433B40: ADD x29, sp, #0x20         | X29 = (1152921510112242912 + 32) = 1152921510112242944 (0x100000014825AD00);
            // 0x01433B44: SUB sp, sp, #0x20          | SP = (1152921510112242912 - 32) = 1152921510112242880 (0x100000014825ACC0);
            // 0x01433B48: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x01433B4C: LDRB w8, [x21, #0x3e]      | W8 = (bool)static_value_0373703E;       
            // 0x01433B50: MOV x19, x2                | X19 = X2;//m1                           
            // 0x01433B54: MOV x20, x1                | X20 = v;//m1                            
            // 0x01433B58: TBNZ w8, #0, #0x1433b74    | if (static_value_0373703E == true) goto label_0;
            // 0x01433B5C: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x01433B60: LDR x8, [x8, #0xc20]       | X8 = 0x2B901E4;                         
            // 0x01433B64: LDR w0, [x8]               | W0 = 0x173D;                            
            // 0x01433B68: BL #0x2782188              | X0 = sub_2782188( ?? 0x173D, ????);     
            // 0x01433B6C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01433B70: STRB w8, [x21, #0x3e]      | static_value_0373703E = true;            //  dest_result_addr=57897022
            label_0:
            // 0x01433B74: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x01433B78: CBZ x21, #0x1433c2c        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01433B7C: ADRP x20, #0x3611000       | X20 = 56692736 (0x3611000);             
            // 0x01433B80: LDR x20, [x20, #0x430]     | X20 = 1152921504887730176;              
            // 0x01433B84: LDR x8, [x21]              | X8 = ;                                  
            // 0x01433B88: LDR x1, [x20]              | X1 = typeof(CameraHelper);              
            // 0x01433B8C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01433B90: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01433B94: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01433B98: B.LO #0x1433bb0            | if (mem[null + 260] < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01433B9C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01433BA0: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01433BA4: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01433BA8: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01433BAC: B.EQ #0x1433bd8            | if ((mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01433BB0: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01433BB4: ADD x8, sp, #8             | X8 = (1152921510112242880 + 8) = 1152921510112242888 (0x100000014825ACC8);
            // 0x01433BB8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01433BBC: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510112230960]
            // 0x01433BC0: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01433BC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01433BC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01433BCC: ADD x0, sp, #8             | X0 = (1152921510112242880 + 8) = 1152921510112242888 (0x100000014825ACC8);
            // 0x01433BD0: BL #0x299a140              | 
            // 0x01433BD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014825ACC8, ????);
            label_3:
            // 0x01433BD8: LDR x8, [x21]              | X8 = ;                                  
            // 0x01433BDC: LDR x1, [x20]              | X1 = typeof(CameraHelper);              
            // 0x01433BE0: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01433BE4: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01433BE8: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01433BEC: B.LO #0x1433c04            | if (mem[null + 260] < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01433BF0: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01433BF4: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01433BF8: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01433BFC: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01433C00: B.EQ #0x1433c34            | if ((mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01433C04: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01433C08: ADD x8, sp, #0x10          | X8 = (1152921510112242880 + 16) = 1152921510112242896 (0x100000014825ACD0);
            // 0x01433C0C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01433C10: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510112230960]
            // 0x01433C14: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01433C18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01433C1C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01433C20: ADD x0, sp, #0x10          | X0 = (1152921510112242880 + 16) = 1152921510112242896 (0x100000014825ACD0);
            // 0x01433C24: BL #0x299a140              | 
            // 0x01433C28: B #0x1433c30               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01433C2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x173D, ????);     
            label_6:
            // 0x01433C30: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x01433C34: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x01433C38: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
            // 0x01433C3C: LDR x20, [x8]              | X20 = typeof(System.Single);            
            // 0x01433C40: CBNZ x19, #0x1433c48       | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x01433C44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x173D, ????);     
            label_7:
            // 0x01433C48: LDR x8, [x19]              | X8 = X2;                                
            // 0x01433C4C: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01433C50: LDR x8, [x20, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
            // 0x01433C54: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Single.__il2cppRuntimeField_element_class)
            // 0x01433C58: B.NE #0x1433ca0            | if (X2 + 48 != System.Single.__il2cppRuntimeField_element_class) goto label_8;
            // 0x01433C5C: MOV x0, x19                | X0 = X2;//m1                            
            // 0x01433C60: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x01433C64: LDR w8, [x0]               | W8 = X2;                                
            // 0x01433C68: STR w8, [x21, #0x1c]       | mem[28] = X2;                            //  dest_result_addr=28
            mem[28] = X2;
            // 0x01433C6C: SUB sp, x29, #0x20         | SP = (1152921510112242944 - 32) = 1152921510112242912 (0x100000014825ACE0);
            // 0x01433C70: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01433C74: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01433C78: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01433C7C: RET                        |  return;                                
            return;
            // 0x01433C80: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01433C84: ADD x0, sp, #8             | X0 = (1152921510112242960 + 8) = 1152921510112242968 (0x100000014825AD18);
            // 0x01433C88: B #0x1433c94               |  goto label_10;                         
            goto label_10;
            // 0x01433C8C: MOV x19, x0                | X19 = 1152921510112242968 (0x100000014825AD18);//ML01
            val_7;
            // 0x01433C90: ADD x0, sp, #0x10          | X0 = (1152921510112242960 + 16) = 1152921510112242976 (0x100000014825AD20);
            label_10:
            // 0x01433C94: BL #0x299a140              | 
            // 0x01433C98: MOV x0, x19                | X0 = 1152921510112242968 (0x100000014825AD18);//ML01
            // 0x01433C9C: BL #0x980800               | X0 = sub_980800( ?? 0x100000014825AD18, ????);
            label_8:
            // 0x01433CA0: ADD x8, sp, #0x18          | X8 = (1152921510112242960 + 24) = 1152921510112242984 (0x100000014825AD28);
            // 0x01433CA4: MOV x1, x20                | X1 = X20;//m1                           
            // 0x01433CA8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x100000014825AD18, ????);
            // 0x01433CAC: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510112230960]
            // 0x01433CB0: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01433CB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01433CB8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01433CBC: ADD x0, sp, #0x18          | X0 = (1152921510112242960 + 24) = 1152921510112242984 (0x100000014825AD28);
            // 0x01433CC0: BL #0x299a140              | 
            // 0x01433CC4: MOV x19, x0                | X19 = 1152921510112242984 (0x100000014825AD28);//ML01
            // 0x01433CC8: ADD x0, sp, #0x18          | X0 = (1152921510112242960 + 24) = 1152921510112242984 (0x100000014825AD28);
            // 0x01433CCC: B #0x1433c94               |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x01433CD0 (21183696), len: 288  VirtAddr: 0x01433CD0 RVA: 0x01433CD0 token: 100664160 methodIndex: 30207 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_effectCamera_4(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01433CD0: STP x20, x19, [sp, #-0x20]! | stack[1152921510112367056] = ???;  stack[1152921510112367064] = ???;  //  dest_result_addr=1152921510112367056 |  dest_result_addr=1152921510112367064
            // 0x01433CD4: STP x29, x30, [sp, #0x10]  | stack[1152921510112367072] = ???;  stack[1152921510112367080] = ???;  //  dest_result_addr=1152921510112367072 |  dest_result_addr=1152921510112367080
            // 0x01433CD8: ADD x29, sp, #0x10         | X29 = (1152921510112367056 + 16) = 1152921510112367072 (0x10000001482791E0);
            // 0x01433CDC: SUB sp, sp, #0x10          | SP = (1152921510112367056 - 16) = 1152921510112367040 (0x10000001482791C0);
            // 0x01433CE0: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01433CE4: LDRB w8, [x20, #0x3f]      | W8 = (bool)static_value_0373703F;       
            // 0x01433CE8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01433CEC: TBNZ w8, #0, #0x1433d08    | if (static_value_0373703F == true) goto label_0;
            // 0x01433CF0: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
            // 0x01433CF4: LDR x8, [x8, #0x8a8]       | X8 = 0x2B90190;                         
            // 0x01433CF8: LDR w0, [x8]               | W0 = 0x1728;                            
            // 0x01433CFC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1728, ????);     
            // 0x01433D00: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01433D04: STRB w8, [x20, #0x3f]      | static_value_0373703F = true;            //  dest_result_addr=57897023
            label_0:
            // 0x01433D08: ADRP x20, #0x3611000       | X20 = 56692736 (0x3611000);             
            // 0x01433D0C: LDR x19, [x19]             | X19 = X1;                               
            // 0x01433D10: LDR x20, [x20, #0x430]     | X20 = 1152921504887730176;              
            // 0x01433D14: CBZ x19, #0x1433d68        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01433D18: LDR x8, [x19]              | X8 = X1;                                
            // 0x01433D1C: LDR x1, [x20]              | X1 = typeof(CameraHelper);              
            // 0x01433D20: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01433D24: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01433D28: CMP w10, w9                | STATE = COMPARE(X1 + 260, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01433D2C: B.LO #0x1433d44            | if (X1 + 260 < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01433D30: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01433D34: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01433D38: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01433D3C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01433D40: B.EQ #0x1433d6c            | if ((X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01433D44: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01433D48: MOV x8, sp                 | X8 = 1152921510112367040 (0x10000001482791C0);//ML01
            // 0x01433D4C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01433D50: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510112355088]
            // 0x01433D54: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01433D58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01433D5C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01433D60: MOV x0, sp                 | X0 = 1152921510112367040 (0x10000001482791C0);//ML01
            // 0x01433D64: BL #0x299a140              | 
            label_1:
            // 0x01433D68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001482791C0, ????);
            label_3:
            // 0x01433D6C: LDR x8, [x19]              | X8 = X1;                                
            // 0x01433D70: LDR x1, [x20]              | X1 = typeof(CameraHelper);              
            // 0x01433D74: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01433D78: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01433D7C: CMP w10, w9                | STATE = COMPARE(X1 + 260, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01433D80: B.LO #0x1433dac            | if (X1 + 260 < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01433D84: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01433D88: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01433D8C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01433D90: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01433D94: B.NE #0x1433dac            | if ((X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01433D98: LDR x0, [x19, #0x70]       | X0 = X1 + 112;                          
            // 0x01433D9C: SUB sp, x29, #0x10         | SP = (1152921510112367072 - 16) = 1152921510112367056 (0x10000001482791D0);
            // 0x01433DA0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01433DA4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01433DA8: RET                        |  return (System.Object)X1 + 112;        
            return (object)X1 + 112;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01433DAC: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01433DB0: ADD x8, sp, #8             | X8 = (1152921510112367040 + 8) = 1152921510112367048 (0x10000001482791C8);
            // 0x01433DB4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01433DB8: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510112355088]
            // 0x01433DBC: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01433DC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01433DC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01433DC8: ADD x0, sp, #8             | X0 = (1152921510112367040 + 8) = 1152921510112367048 (0x10000001482791C8);
            // 0x01433DCC: BL #0x299a140              | 
            // 0x01433DD0: MOV x19, x0                | X19 = 1152921510112367048 (0x10000001482791C8);//ML01
            // 0x01433DD4: MOV x0, sp                 | X0 = 1152921510112367040 (0x10000001482791C0);//ML01
            label_6:
            // 0x01433DD8: BL #0x299a140              | 
            // 0x01433DDC: MOV x0, x19                | X0 = 1152921510112367048 (0x10000001482791C8);//ML01
            // 0x01433DE0: BL #0x980800               | X0 = sub_980800( ?? 0x10000001482791C8, ????);
            // 0x01433DE4: MOV x19, x0                | X19 = 1152921510112367048 (0x10000001482791C8);//ML01
            // 0x01433DE8: ADD x0, sp, #8             | X0 = (1152921510112367040 + 8) = 1152921510112367048 (0x10000001482791C8);
            // 0x01433DEC: B #0x1433dd8               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01433DF0 (21183984), len: 392  VirtAddr: 0x01433DF0 RVA: 0x01433DF0 token: 100664161 methodIndex: 30208 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_effectCamera_4(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x01433DF0: STP x22, x21, [sp, #-0x30]! | stack[1152921510112491168] = ???;  stack[1152921510112491176] = ???;  //  dest_result_addr=1152921510112491168 |  dest_result_addr=1152921510112491176
            // 0x01433DF4: STP x20, x19, [sp, #0x10]  | stack[1152921510112491184] = ???;  stack[1152921510112491192] = ???;  //  dest_result_addr=1152921510112491184 |  dest_result_addr=1152921510112491192
            // 0x01433DF8: STP x29, x30, [sp, #0x20]  | stack[1152921510112491200] = ???;  stack[1152921510112491208] = ???;  //  dest_result_addr=1152921510112491200 |  dest_result_addr=1152921510112491208
            // 0x01433DFC: ADD x29, sp, #0x20         | X29 = (1152921510112491168 + 32) = 1152921510112491200 (0x10000001482976C0);
            // 0x01433E00: SUB sp, sp, #0x20          | SP = (1152921510112491168 - 32) = 1152921510112491136 (0x1000000148297680);
            // 0x01433E04: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x01433E08: LDRB w8, [x21, #0x40]      | W8 = (bool)static_value_03737040;       
            // 0x01433E0C: MOV x19, x2                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01433E10: MOV x20, x1                | X20 = v;//m1                            
            // 0x01433E14: TBNZ w8, #0, #0x1433e30    | if (static_value_03737040 == true) goto label_0;
            // 0x01433E18: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
            // 0x01433E1C: LDR x8, [x8, #0xab0]       | X8 = 0x2B901D4;                         
            // 0x01433E20: LDR w0, [x8]               | W0 = 0x1739;                            
            // 0x01433E24: BL #0x2782188              | X0 = sub_2782188( ?? 0x1739, ????);     
            // 0x01433E28: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01433E2C: STRB w8, [x21, #0x40]      | static_value_03737040 = true;            //  dest_result_addr=57897024
            label_0:
            // 0x01433E30: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x01433E34: CBZ x20, #0x1433ee8        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01433E38: ADRP x21, #0x3611000       | X21 = 56692736 (0x3611000);             
            // 0x01433E3C: LDR x21, [x21, #0x430]     | X21 = 1152921504887730176;              
            val_6 = 1152921504887730176;
            // 0x01433E40: LDR x8, [x20]              | X8 = ;                                  
            // 0x01433E44: LDR x1, [x21]              | X1 = typeof(CameraHelper);              
            // 0x01433E48: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01433E4C: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01433E50: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01433E54: B.LO #0x1433e6c            | if (mem[null + 260] < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01433E58: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01433E5C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01433E60: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01433E64: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01433E68: B.EQ #0x1433e94            | if ((mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01433E6C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01433E70: ADD x8, sp, #8             | X8 = (1152921510112491136 + 8) = 1152921510112491144 (0x1000000148297688);
            // 0x01433E74: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01433E78: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510112479216]
            // 0x01433E7C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01433E80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01433E84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01433E88: ADD x0, sp, #8             | X0 = (1152921510112491136 + 8) = 1152921510112491144 (0x1000000148297688);
            // 0x01433E8C: BL #0x299a140              | 
            // 0x01433E90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148297688, ????);
            label_3:
            // 0x01433E94: LDR x8, [x20]              | X8 = ;                                  
            // 0x01433E98: LDR x1, [x21]              | X1 = typeof(CameraHelper);              
            // 0x01433E9C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01433EA0: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01433EA4: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01433EA8: B.LO #0x1433ec0            | if (mem[null + 260] < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01433EAC: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01433EB0: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01433EB4: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01433EB8: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01433EBC: B.EQ #0x1433ef0            | if ((mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01433EC0: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01433EC4: ADD x8, sp, #0x10          | X8 = (1152921510112491136 + 16) = 1152921510112491152 (0x1000000148297690);
            // 0x01433EC8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01433ECC: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510112479216]
            // 0x01433ED0: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01433ED4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01433ED8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01433EDC: ADD x0, sp, #0x10          | X0 = (1152921510112491136 + 16) = 1152921510112491152 (0x1000000148297690);
            // 0x01433EE0: BL #0x299a140              | 
            // 0x01433EE4: B #0x1433eec               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01433EE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1739, ????);     
            label_6:
            // 0x01433EEC: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_5:
            // 0x01433EF0: CBZ x19, #0x1433f30        | if (X2 == 0) goto label_7;              
            if(val_7 == 0)
            {
                goto label_7;
            }
            // 0x01433EF4: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x01433EF8: LDR x8, [x8, #0xee0]       | X8 = 1152921504691671040;               
            // 0x01433EFC: LDR x1, [x8]               | X1 = typeof(UnityEngine.Camera);        
            // 0x01433F00: LDR x8, [x19]              | X8 = X2;                                
            // 0x01433F04: CMP x8, x1                 | STATE = COMPARE(X2, typeof(UnityEngine.Camera))
            // 0x01433F08: B.EQ #0x1433f34            | if (val_7 == null) goto label_8;        
            if(val_7 == null)
            {
                goto label_8;
            }
            // 0x01433F0C: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01433F10: ADD x8, sp, #0x18          | X8 = (1152921510112491136 + 24) = 1152921510112491160 (0x1000000148297698);
            // 0x01433F14: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x01433F18: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510112479216]
            // 0x01433F1C: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01433F20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01433F24: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01433F28: ADD x0, sp, #0x18          | X0 = (1152921510112491136 + 24) = 1152921510112491160 (0x1000000148297698);
            // 0x01433F2C: BL #0x299a140              | 
            label_7:
            // 0x01433F30: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_8:
            // 0x01433F34: STR x19, [x20, #0x70]      | mem[112] = 0x0;                          //  dest_result_addr=112
            mem[112] = val_7;
            // 0x01433F38: SUB sp, x29, #0x20         | SP = (1152921510112491200 - 32) = 1152921510112491168 (0x10000001482976A0);
            // 0x01433F3C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01433F40: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01433F44: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01433F48: RET                        |  return;                                
            return;
            // 0x01433F4C: MOV x19, x0                | 
            // 0x01433F50: ADD x0, sp, #8             | 
            // 0x01433F54: B #0x1433f6c               | 
            // 0x01433F58: MOV x19, x0                | 
            // 0x01433F5C: ADD x0, sp, #0x10          | 
            // 0x01433F60: B #0x1433f6c               | 
            // 0x01433F64: MOV x19, x0                | 
            // 0x01433F68: ADD x0, sp, #0x18          | 
            label_10:
            // 0x01433F6C: BL #0x299a140              | 
            // 0x01433F70: MOV x0, x19                | 
            // 0x01433F74: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01433F78 (21184376), len: 104  VirtAddr: 0x01433F78 RVA: 0x01433F78 token: 100664162 methodIndex: 30209 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_instance_5(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x01433F78: STP x20, x19, [sp, #-0x20]! | stack[1152921510112615312] = ???;  stack[1152921510112615320] = ???;  //  dest_result_addr=1152921510112615312 |  dest_result_addr=1152921510112615320
            // 0x01433F7C: STP x29, x30, [sp, #0x10]  | stack[1152921510112615328] = ???;  stack[1152921510112615336] = ???;  //  dest_result_addr=1152921510112615328 |  dest_result_addr=1152921510112615336
            // 0x01433F80: ADD x29, sp, #0x10         | X29 = (1152921510112615312 + 16) = 1152921510112615328 (0x10000001482B5BA0);
            // 0x01433F84: ADRP x19, #0x3737000       | X19 = 57896960 (0x3737000);             
            // 0x01433F88: LDRB w8, [x19, #0x41]      | W8 = (bool)static_value_03737041;       
            // 0x01433F8C: TBNZ w8, #0, #0x1433fa8    | if (static_value_03737041 == true) goto label_0;
            // 0x01433F90: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01433F94: LDR x8, [x8, #0x208]       | X8 = 0x2B9019C;                         
            // 0x01433F98: LDR w0, [x8]               | W0 = 0x172B;                            
            // 0x01433F9C: BL #0x2782188              | X0 = sub_2782188( ?? 0x172B, ????);     
            // 0x01433FA0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01433FA4: STRB w8, [x19, #0x41]      | static_value_03737041 = true;            //  dest_result_addr=57897025
            label_0:
            // 0x01433FA8: ADRP x19, #0x3611000       | X19 = 56692736 (0x3611000);             
            // 0x01433FAC: LDR x19, [x19, #0x430]     | X19 = 1152921504887730176;              
            // 0x01433FB0: LDR x0, [x19]              | X0 = typeof(CameraHelper);              
            val_1 = null;
            // 0x01433FB4: LDRB w8, [x0, #0x10a]      | W8 = CameraHelper.__il2cppRuntimeField_10A;
            // 0x01433FB8: TBZ w8, #0, #0x1433fcc     | if (CameraHelper.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01433FBC: LDR w8, [x0, #0xbc]        | W8 = CameraHelper.__il2cppRuntimeField_cctor_finished;
            // 0x01433FC0: CBNZ w8, #0x1433fcc        | if (CameraHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01433FC4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraHelper), ????);
            // 0x01433FC8: LDR x0, [x19]              | X0 = typeof(CameraHelper);              
            val_1 = null;
            label_2:
            // 0x01433FCC: LDR x8, [x0, #0xa0]        | X8 = CameraHelper.__il2cppRuntimeField_static_fields;
            // 0x01433FD0: LDR x0, [x8]               | X0 = CameraHelper.instance;             
            // 0x01433FD4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01433FD8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01433FDC: RET                        |  return (System.Object)CameraHelper.instance;
            return (object)CameraHelper.instance;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01433FE0 (21184480), len: 224  VirtAddr: 0x01433FE0 RVA: 0x01433FE0 token: 100664163 methodIndex: 30210 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_instance_5(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            CameraHelper val_3;
            //  | 
            var val_4;
            // 0x01433FE0: STP x20, x19, [sp, #-0x20]! | stack[1152921510112739440] = ???;  stack[1152921510112739448] = ???;  //  dest_result_addr=1152921510112739440 |  dest_result_addr=1152921510112739448
            // 0x01433FE4: STP x29, x30, [sp, #0x10]  | stack[1152921510112739456] = ???;  stack[1152921510112739464] = ???;  //  dest_result_addr=1152921510112739456 |  dest_result_addr=1152921510112739464
            // 0x01433FE8: ADD x29, sp, #0x10         | X29 = (1152921510112739440 + 16) = 1152921510112739456 (0x10000001482D4080);
            // 0x01433FEC: SUB sp, sp, #0x10          | SP = (1152921510112739440 - 16) = 1152921510112739424 (0x10000001482D4060);
            // 0x01433FF0: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01433FF4: LDRB w8, [x20, #0x42]      | W8 = (bool)static_value_03737042;       
            // 0x01433FF8: MOV x19, x2                | X19 = X2;//m1                           
            val_3 = X2;
            // 0x01433FFC: TBNZ w8, #0, #0x1434018    | if (static_value_03737042 == true) goto label_0;
            // 0x01434000: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x01434004: LDR x8, [x8, #0xba8]       | X8 = 0x2B901DC;                         
            // 0x01434008: LDR w0, [x8]               | W0 = 0x173B;                            
            // 0x0143400C: BL #0x2782188              | X0 = sub_2782188( ?? 0x173B, ????);     
            // 0x01434010: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01434014: STRB w8, [x20, #0x42]      | static_value_03737042 = true;            //  dest_result_addr=57897026
            label_0:
            // 0x01434018: ADRP x20, #0x3611000       | X20 = 56692736 (0x3611000);             
            // 0x0143401C: LDR x20, [x20, #0x430]     | X20 = 1152921504887730176;              
            // 0x01434020: LDR x1, [x20]              | X1 = typeof(CameraHelper);              
            val_4 = null;
            // 0x01434024: LDRB w8, [x1, #0x10a]      | W8 = CameraHelper.__il2cppRuntimeField_10A;
            // 0x01434028: TBZ w8, #0, #0x1434040     | if (CameraHelper.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0143402C: LDR w8, [x1, #0xbc]        | W8 = CameraHelper.__il2cppRuntimeField_cctor_finished;
            // 0x01434030: CBNZ w8, #0x1434040        | if (CameraHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01434034: MOV x0, x1                 | X0 = 1152921504887730176 (0x1000000010BDF000);//ML01
            // 0x01434038: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraHelper), ????);
            // 0x0143403C: LDR x1, [x20]              | X1 = typeof(CameraHelper);              
            val_4 = null;
            label_2:
            // 0x01434040: LDR x20, [x1, #0xa0]       | X20 = CameraHelper.__il2cppRuntimeField_static_fields;
            // 0x01434044: CBZ x19, #0x1434094        | if (X2 == 0) goto label_3;              
            if(val_3 == 0)
            {
                goto label_3;
            }
            // 0x01434048: LDR x8, [x19]              | X8 = X2;                                
            // 0x0143404C: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01434050: LDRB w10, [x8, #0x104]     | W10 = X2 + 260;                         
            // 0x01434054: CMP w10, w9                | STATE = COMPARE(X2 + 260, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01434058: B.LO #0x1434070            | if (X2 + 260 < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x0143405C: LDR x10, [x8, #0xb0]       | X10 = X2 + 176;                         
            // 0x01434060: ADD x9, x10, x9, lsl #3    | X9 = (X2 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01434064: LDUR x9, [x9, #-8]         | X9 = (X2 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01434068: CMP x9, x1                 | STATE = COMPARE((X2 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x0143406C: B.EQ #0x1434098            | if ((X2 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == val_4) goto label_5;
            label_4:
            // 0x01434070: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01434074: ADD x8, sp, #8             | X8 = (1152921510112739424 + 8) = 1152921510112739432 (0x10000001482D4068);
            // 0x01434078: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x0143407C: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510112727472]
            // 0x01434080: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01434084: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01434088: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x0143408C: ADD x0, sp, #8             | X0 = (1152921510112739424 + 8) = 1152921510112739432 (0x10000001482D4068);
            // 0x01434090: BL #0x299a140              | 
            label_3:
            // 0x01434094: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_3 = 0;
            label_5:
            // 0x01434098: STR x19, [x20]             | CameraHelper.instance = null;            //  dest_result_addr=1152921504887734272
            CameraHelper.instance = val_3;
            // 0x0143409C: SUB sp, x29, #0x10         | SP = (1152921510112739456 - 16) = 1152921510112739440 (0x10000001482D4070);
            // 0x014340A0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x014340A4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x014340A8: RET                        |  return;                                
            return;
            // 0x014340AC: MOV x19, x0                | 
            // 0x014340B0: ADD x0, sp, #8             | 
            // 0x014340B4: BL #0x299a140              | 
            // 0x014340B8: MOV x0, x19                | 
            // 0x014340BC: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x014340C0 (21184704), len: 312  VirtAddr: 0x014340C0 RVA: 0x014340C0 token: 100664164 methodIndex: 30211 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_motionBluring_6(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x014340C0: STP x20, x19, [sp, #-0x20]! | stack[1152921510112867664] = ???;  stack[1152921510112867672] = ???;  //  dest_result_addr=1152921510112867664 |  dest_result_addr=1152921510112867672
            // 0x014340C4: STP x29, x30, [sp, #0x10]  | stack[1152921510112867680] = ???;  stack[1152921510112867688] = ???;  //  dest_result_addr=1152921510112867680 |  dest_result_addr=1152921510112867688
            // 0x014340C8: ADD x29, sp, #0x10         | X29 = (1152921510112867664 + 16) = 1152921510112867680 (0x10000001482F3560);
            // 0x014340CC: SUB sp, sp, #0x20          | SP = (1152921510112867664 - 32) = 1152921510112867632 (0x10000001482F3530);
            // 0x014340D0: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x014340D4: LDRB w8, [x20, #0x43]      | W8 = (bool)static_value_03737043;       
            // 0x014340D8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x014340DC: TBNZ w8, #0, #0x14340f8    | if (static_value_03737043 == true) goto label_0;
            // 0x014340E0: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x014340E4: LDR x8, [x8, #0xde8]       | X8 = 0x2B901A0;                         
            // 0x014340E8: LDR w0, [x8]               | W0 = 0x172C;                            
            // 0x014340EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x172C, ????);     
            // 0x014340F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x014340F4: STRB w8, [x20, #0x43]      | static_value_03737043 = true;            //  dest_result_addr=57897027
            label_0:
            // 0x014340F8: ADRP x20, #0x3611000       | X20 = 56692736 (0x3611000);             
            // 0x014340FC: LDR x19, [x19]             | X19 = X1;                               
            // 0x01434100: LDR x20, [x20, #0x430]     | X20 = 1152921504887730176;              
            // 0x01434104: CBZ x19, #0x1434158        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01434108: LDR x8, [x19]              | X8 = X1;                                
            // 0x0143410C: LDR x1, [x20]              | X1 = typeof(CameraHelper);              
            // 0x01434110: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01434114: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01434118: CMP w10, w9                | STATE = COMPARE(X1 + 260, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0143411C: B.LO #0x1434134            | if (X1 + 260 < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01434120: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01434124: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01434128: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0143412C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01434130: B.EQ #0x143415c            | if ((X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01434134: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01434138: ADD x8, sp, #0x10          | X8 = (1152921510112867632 + 16) = 1152921510112867648 (0x10000001482F3540);
            // 0x0143413C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01434140: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510112855696]
            // 0x01434144: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01434148: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143414C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01434150: ADD x0, sp, #0x10          | X0 = (1152921510112867632 + 16) = 1152921510112867648 (0x10000001482F3540);
            // 0x01434154: BL #0x299a140              | 
            label_1:
            // 0x01434158: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001482F3540, ????);
            label_3:
            // 0x0143415C: LDR x8, [x19]              | X8 = X1;                                
            // 0x01434160: LDR x1, [x20]              | X1 = typeof(CameraHelper);              
            // 0x01434164: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01434168: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143416C: CMP w10, w9                | STATE = COMPARE(X1 + 260, CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01434170: B.LO #0x14341b4            | if (X1 + 260 < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01434174: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01434178: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x0143417C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01434180: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01434184: B.NE #0x14341b4            | if ((X1 + 176 + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01434188: ADRP x9, #0x3626000        | X9 = 56778752 (0x3626000);              
            // 0x0143418C: LDRB w8, [x19, #0x78]      | W8 = X1 + 120;                          
            // 0x01434190: LDR x9, [x9, #0x7d8]       | X9 = 1152921504608604160;               
            // 0x01434194: ADD x1, sp, #0xf           | X1 = (1152921510112867632 + 15) = 1152921510112867647 (0x10000001482F353F);
            // 0x01434198: STRB w8, [sp, #0xf]        | stack[1152921510112867647] = X1 + 120;   //  dest_result_addr=1152921510112867647
            // 0x0143419C: LDR x0, [x9]               | X0 = typeof(System.Boolean);            
            // 0x014341A0: BL #0x27bc028              | X0 = 1152921510112915712 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Boolean), X1 + 120);
            // 0x014341A4: SUB sp, x29, #0x10         | SP = (1152921510112867680 - 16) = 1152921510112867664 (0x10000001482F3550);
            // 0x014341A8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x014341AC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x014341B0: RET                        |  return (System.Object)X1 + 120;        
            return (object)X1 + 120;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x014341B4: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x014341B8: ADD x8, sp, #0x18          | X8 = (1152921510112867632 + 24) = 1152921510112867656 (0x10000001482F3548);
            // 0x014341BC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x014341C0: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510112855696]
            // 0x014341C4: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x014341C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014341CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x014341D0: ADD x0, sp, #0x18          | X0 = (1152921510112867632 + 24) = 1152921510112867656 (0x10000001482F3548);
            // 0x014341D4: BL #0x299a140              | 
            // 0x014341D8: MOV x19, x0                | X19 = 1152921510112867656 (0x10000001482F3548);//ML01
            // 0x014341DC: ADD x0, sp, #0x10          | X0 = (1152921510112867632 + 16) = 1152921510112867648 (0x10000001482F3540);
            label_6:
            // 0x014341E0: BL #0x299a140              | 
            // 0x014341E4: MOV x0, x19                | X0 = 1152921510112867656 (0x10000001482F3548);//ML01
            // 0x014341E8: BL #0x980800               | X0 = sub_980800( ?? 0x10000001482F3548, ????);
            // 0x014341EC: MOV x19, x0                | X19 = 1152921510112867656 (0x10000001482F3548);//ML01
            // 0x014341F0: ADD x0, sp, #0x18          | X0 = (1152921510112867632 + 24) = 1152921510112867656 (0x10000001482F3548);
            // 0x014341F4: B #0x14341e0               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x014341F8 (21185016), len: 412  VirtAddr: 0x014341F8 RVA: 0x014341F8 token: 100664165 methodIndex: 30212 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_motionBluring_6(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x014341F8: STP x22, x21, [sp, #-0x30]! | stack[1152921510112995872] = ???;  stack[1152921510112995880] = ???;  //  dest_result_addr=1152921510112995872 |  dest_result_addr=1152921510112995880
            // 0x014341FC: STP x20, x19, [sp, #0x10]  | stack[1152921510112995888] = ???;  stack[1152921510112995896] = ???;  //  dest_result_addr=1152921510112995888 |  dest_result_addr=1152921510112995896
            // 0x01434200: STP x29, x30, [sp, #0x20]  | stack[1152921510112995904] = ???;  stack[1152921510112995912] = ???;  //  dest_result_addr=1152921510112995904 |  dest_result_addr=1152921510112995912
            // 0x01434204: ADD x29, sp, #0x20         | X29 = (1152921510112995872 + 32) = 1152921510112995904 (0x1000000148312A40);
            // 0x01434208: SUB sp, sp, #0x20          | SP = (1152921510112995872 - 32) = 1152921510112995840 (0x1000000148312A00);
            // 0x0143420C: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x01434210: LDRB w8, [x21, #0x44]      | W8 = (bool)static_value_03737044;       
            // 0x01434214: MOV x19, x2                | X19 = X2;//m1                           
            // 0x01434218: MOV x20, x1                | X20 = v;//m1                            
            // 0x0143421C: TBNZ w8, #0, #0x1434238    | if (static_value_03737044 == true) goto label_0;
            // 0x01434220: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
            // 0x01434224: LDR x8, [x8, #0x360]       | X8 = 0x2B901E0;                         
            // 0x01434228: LDR w0, [x8]               | W0 = 0x173C;                            
            // 0x0143422C: BL #0x2782188              | X0 = sub_2782188( ?? 0x173C, ????);     
            // 0x01434230: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01434234: STRB w8, [x21, #0x44]      | static_value_03737044 = true;            //  dest_result_addr=57897028
            label_0:
            // 0x01434238: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x0143423C: CBZ x21, #0x14342f0        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01434240: ADRP x20, #0x3611000       | X20 = 56692736 (0x3611000);             
            // 0x01434244: LDR x20, [x20, #0x430]     | X20 = 1152921504887730176;              
            // 0x01434248: LDR x8, [x21]              | X8 = ;                                  
            // 0x0143424C: LDR x1, [x20]              | X1 = typeof(CameraHelper);              
            // 0x01434250: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01434254: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01434258: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0143425C: B.LO #0x1434274            | if (mem[null + 260] < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01434260: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01434264: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01434268: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0143426C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x01434270: B.EQ #0x143429c            | if ((mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01434274: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01434278: ADD x8, sp, #8             | X8 = (1152921510112995840 + 8) = 1152921510112995848 (0x1000000148312A08);
            // 0x0143427C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01434280: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510112983920]
            // 0x01434284: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01434288: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143428C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01434290: ADD x0, sp, #8             | X0 = (1152921510112995840 + 8) = 1152921510112995848 (0x1000000148312A08);
            // 0x01434294: BL #0x299a140              | 
            // 0x01434298: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148312A08, ????);
            label_3:
            // 0x0143429C: LDR x8, [x21]              | X8 = ;                                  
            // 0x014342A0: LDR x1, [x20]              | X1 = typeof(CameraHelper);              
            // 0x014342A4: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x014342A8: LDRB w9, [x1, #0x104]      | W9 = CameraHelper.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014342AC: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CameraHelper.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014342B0: B.LO #0x14342c8            | if (mem[null + 260] < CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x014342B4: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x014342B8: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x014342BC: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014342C0: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CameraHelper))
            // 0x014342C4: B.EQ #0x14342f8            | if ((mem[null + 176] + (CameraHelper.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x014342C8: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x014342CC: ADD x8, sp, #0x10          | X8 = (1152921510112995840 + 16) = 1152921510112995856 (0x1000000148312A10);
            // 0x014342D0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x014342D4: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510112983920]
            // 0x014342D8: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x014342DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014342E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x014342E4: ADD x0, sp, #0x10          | X0 = (1152921510112995840 + 16) = 1152921510112995856 (0x1000000148312A10);
            // 0x014342E8: BL #0x299a140              | 
            // 0x014342EC: B #0x14342f4               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x014342F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x173C, ????);     
            label_6:
            // 0x014342F4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x014342F8: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x014342FC: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
            // 0x01434300: LDR x20, [x8]              | X20 = typeof(System.Boolean);           
            // 0x01434304: CBNZ x19, #0x143430c       | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x01434308: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x173C, ????);     
            label_7:
            // 0x0143430C: LDR x8, [x19]              | X8 = X2;                                
            // 0x01434310: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01434314: LDR x8, [x20, #0x30]       | X8 = System.Boolean.__il2cppRuntimeField_element_class;
            // 0x01434318: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Boolean.__il2cppRuntimeField_element_class)
            // 0x0143431C: B.NE #0x1434364            | if (X2 + 48 != System.Boolean.__il2cppRuntimeField_element_class) goto label_8;
            // 0x01434320: MOV x0, x19                | X0 = X2;//m1                            
            // 0x01434324: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x01434328: LDRB w8, [x0]              | W8 = X2;                                
            // 0x0143432C: STRB w8, [x21, #0x78]      | mem[120] = X2;                           //  dest_result_addr=120
            mem[120] = X2;
            // 0x01434330: SUB sp, x29, #0x20         | SP = (1152921510112995904 - 32) = 1152921510112995872 (0x1000000148312A20);
            // 0x01434334: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01434338: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0143433C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01434340: RET                        |  return;                                
            return;
            // 0x01434344: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01434348: ADD x0, sp, #8             | X0 = (1152921510112995920 + 8) = 1152921510112995928 (0x1000000148312A58);
            // 0x0143434C: B #0x1434358               |  goto label_10;                         
            goto label_10;
            // 0x01434350: MOV x19, x0                | X19 = 1152921510112995928 (0x1000000148312A58);//ML01
            val_7;
            // 0x01434354: ADD x0, sp, #0x10          | X0 = (1152921510112995920 + 16) = 1152921510112995936 (0x1000000148312A60);
            label_10:
            // 0x01434358: BL #0x299a140              | 
            // 0x0143435C: MOV x0, x19                | X0 = 1152921510112995928 (0x1000000148312A58);//ML01
            // 0x01434360: BL #0x980800               | X0 = sub_980800( ?? 0x1000000148312A58, ????);
            label_8:
            // 0x01434364: ADD x8, sp, #0x18          | X8 = (1152921510112995920 + 24) = 1152921510112995944 (0x1000000148312A68);
            // 0x01434368: MOV x1, x20                | X1 = X20;//m1                           
            // 0x0143436C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000148312A58, ????);
            // 0x01434370: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510112983920]
            // 0x01434374: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01434378: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143437C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01434380: ADD x0, sp, #0x18          | X0 = (1152921510112995920 + 24) = 1152921510112995944 (0x1000000148312A68);
            // 0x01434384: BL #0x299a140              | 
            // 0x01434388: MOV x19, x0                | X19 = 1152921510112995944 (0x1000000148312A68);//ML01
            // 0x0143438C: ADD x0, sp, #0x18          | X0 = (1152921510112995920 + 24) = 1152921510112995944 (0x1000000148312A68);
            // 0x01434390: B #0x1434358               |  goto label_10;                         
            goto label_10;
        
        }
    
    }

}
