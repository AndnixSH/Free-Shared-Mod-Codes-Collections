using UnityEngine;

namespace Pathfinding.Serialization
{
    public class BoundsConverter : JsonConverter
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x028BE0B4 (42721460), len: 8  VirtAddr: 0x028BE0B4 RVA: 0x028BE0B4 token: 100682597 methodIndex: 51197 delegateWrapperIndex: 0 methodInvoker: 0
        public BoundsConverter()
        {
            //
            // Disasemble & Code
            // 0x028BE0B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BE0B8: B #0x26d4920               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028C2790 (42739600), len: 140  VirtAddr: 0x028C2790 RVA: 0x028C2790 token: 100682598 methodIndex: 51198 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool CanConvert(System.Type type)
        {
            //
            // Disasemble & Code
            // 0x028C2790: STP x20, x19, [sp, #-0x20]! | stack[1152921513268217040] = ???;  stack[1152921513268217048] = ???;  //  dest_result_addr=1152921513268217040 |  dest_result_addr=1152921513268217048
            // 0x028C2794: STP x29, x30, [sp, #0x10]  | stack[1152921513268217056] = ???;  stack[1152921513268217064] = ???;  //  dest_result_addr=1152921513268217056 |  dest_result_addr=1152921513268217064
            // 0x028C2798: ADD x29, sp, #0x10         | X29 = (1152921513268217040 + 16) = 1152921513268217056 (0x10000002044204E0);
            // 0x028C279C: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028C27A0: LDRB w8, [x20, #0x953]     | W8 = (bool)static_value_037B8953;       
            // 0x028C27A4: MOV x19, x1                | X19 = type;//m1                         
            // 0x028C27A8: TBNZ w8, #0, #0x28c27c4    | if (static_value_037B8953 == true) goto label_0;
            // 0x028C27AC: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
            // 0x028C27B0: LDR x8, [x8, #0x988]       | X8 = 0x2B8F93C;                         
            // 0x028C27B4: LDR w0, [x8]               | W0 = 0x1513;                            
            // 0x028C27B8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1513, ????);     
            // 0x028C27BC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028C27C0: STRB w8, [x20, #0x953]     | static_value_037B8953 = true;            //  dest_result_addr=58427731
            label_0:
            // 0x028C27C4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028C27C8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028C27CC: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x028C27D0: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
            // 0x028C27D4: LDR x8, [x8, #0x2f0]       | X8 = 1152921504695291904;               
            // 0x028C27D8: LDR x20, [x8]              | X20 = typeof(UnityEngine.Bounds);       
            // 0x028C27DC: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x028C27E0: TBZ w8, #0, #0x28c27f0     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x028C27E4: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028C27E8: CBNZ w8, #0x28c27f0        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x028C27EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x028C27F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028C27F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C27F8: MOV x1, x20                | X1 = 1152921504695291904 (0x1000000005459000);//ML01
            // 0x028C27FC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028C2800: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028C2804: MOV x2, x0                 | X2 = val_1;//m1                         
            // 0x028C2808: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028C280C: MOV x1, x19                | X1 = type;//m1                          
            // 0x028C2810: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028C2814: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028C2818: B #0x1708de4               | return System.Object.Equals(objA:  0, objB:  type);
            return System.Object.Equals(objA:  0, objB:  type);
        
        }
        //
        // Offset in libil2cpp.so: 0x028C281C (42739740), len: 552  VirtAddr: 0x028C281C RVA: 0x028C281C token: 100682599 methodIndex: 51199 delegateWrapperIndex: 0 methodInvoker: 0
        public override object ReadJson(System.Type objectType, System.Collections.Generic.Dictionary<string, object> values)
        {
            //
            // Disasemble & Code
            // 0x028C281C: STP d9, d8, [sp, #-0x40]!  | stack[1152921513268374544] = ???;  stack[1152921513268374552] = ???;  //  dest_result_addr=1152921513268374544 |  dest_result_addr=1152921513268374552
            // 0x028C2820: STP x22, x21, [sp, #0x10]  | stack[1152921513268374560] = ???;  stack[1152921513268374568] = ???;  //  dest_result_addr=1152921513268374560 |  dest_result_addr=1152921513268374568
            // 0x028C2824: STP x20, x19, [sp, #0x20]  | stack[1152921513268374576] = ???;  stack[1152921513268374584] = ???;  //  dest_result_addr=1152921513268374576 |  dest_result_addr=1152921513268374584
            // 0x028C2828: STP x29, x30, [sp, #0x30]  | stack[1152921513268374592] = ???;  stack[1152921513268374600] = ???;  //  dest_result_addr=1152921513268374592 |  dest_result_addr=1152921513268374600
            // 0x028C282C: ADD x29, sp, #0x30         | X29 = (1152921513268374544 + 48) = 1152921513268374592 (0x1000000204446C40);
            // 0x028C2830: SUB sp, sp, #0x50          | SP = (1152921513268374544 - 80) = 1152921513268374464 (0x1000000204446BC0);
            // 0x028C2834: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028C2838: LDRB w8, [x21, #0x954]     | W8 = (bool)static_value_037B8954;       
            // 0x028C283C: MOV x20, x2                | X20 = values;//m1                       
            // 0x028C2840: MOV x19, x0                | X19 = 1152921513268386608 (0x1000000204449B30);//ML01
            // 0x028C2844: TBNZ w8, #0, #0x28c2860    | if (static_value_037B8954 == true) goto label_0;
            // 0x028C2848: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x028C284C: LDR x8, [x8, #0x460]       | X8 = 0x2B8F940;                         
            // 0x028C2850: LDR w0, [x8]               | W0 = 0x1514;                            
            // 0x028C2854: BL #0x2782188              | X0 = sub_2782188( ?? 0x1514, ????);     
            // 0x028C2858: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028C285C: STRB w8, [x21, #0x954]     | static_value_037B8954 = true;            //  dest_result_addr=58427732
            label_0:
            // 0x028C2860: STP xzr, xzr, [sp, #0x40]  | stack[1152921513268374528] = 0x0;  stack[1152921513268374536] = 0x0;  //  dest_result_addr=1152921513268374528 |  dest_result_addr=1152921513268374536
            // 0x028C2864: STR xzr, [sp, #0x38]       | stack[1152921513268374520] = 0x0;        //  dest_result_addr=1152921513268374520
            // 0x028C2868: CBNZ x20, #0x28c2870       | if (values != null) goto label_1;       
            if(values != null)
            {
                goto label_1;
            }
            // 0x028C286C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1514, ????);     
            label_1:
            // 0x028C2870: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x028C2874: ADRP x21, #0x35bf000       | X21 = 56356864 (0x35BF000);             
            // 0x028C2878: LDR x8, [x8, #0x7c0]       | X8 = (string**)(1152921513268333456)("cx");
            // 0x028C287C: LDR x21, [x21, #0xf58]     | X21 = 1152921513266218032;              
            // 0x028C2880: MOV x0, x20                | X0 = values;//m1                        
            // 0x028C2884: LDR x1, [x8]               | X1 = "cx";                              
            // 0x028C2888: LDR x2, [x21]              | X2 = public System.Object System.Collections.Generic.Dictionary<System.String, System.Object>::get_Item(System.String key);
            // 0x028C288C: BL #0x23fc26c              | X0 = values.get_Item(key:  "cx");       
            object val_1 = values.Item["cx"];
            // 0x028C2890: MOV x1, x0                 | X1 = val_1;//m1                         
            // 0x028C2894: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C2898: MOV x0, x19                | X0 = 1152921513268386608 (0x1000000204449B30);//ML01
            // 0x028C289C: BL #0x26d49a4              | X0 = this.CastFloat(o:  val_1);         
            float val_2 = this.CastFloat(o:  val_1);
            // 0x028C28A0: MOV v8.16b, v0.16b         | V8 = val_2;//m1                         
            // 0x028C28A4: CBNZ x20, #0x28c28ac       | if (values != null) goto label_2;       
            if(values != null)
            {
                goto label_2;
            }
            // 0x028C28A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x028C28AC: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x028C28B0: LDR x8, [x8, #0xaa8]       | X8 = (string**)(1152921513268337632)("cy");
            // 0x028C28B4: LDR x2, [x21]              | X2 = public System.Object System.Collections.Generic.Dictionary<System.String, System.Object>::get_Item(System.String key);
            // 0x028C28B8: MOV x0, x20                | X0 = values;//m1                        
            // 0x028C28BC: LDR x1, [x8]               | X1 = "cy";                              
            // 0x028C28C0: BL #0x23fc26c              | X0 = values.get_Item(key:  "cy");       
            object val_3 = values.Item["cy"];
            // 0x028C28C4: MOV x1, x0                 | X1 = val_3;//m1                         
            // 0x028C28C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C28CC: MOV x0, x19                | X0 = 1152921513268386608 (0x1000000204449B30);//ML01
            // 0x028C28D0: BL #0x26d49a4              | X0 = this.CastFloat(o:  val_3);         
            float val_4 = this.CastFloat(o:  val_3);
            // 0x028C28D4: MOV v9.16b, v0.16b         | V9 = val_4;//m1                         
            // 0x028C28D8: CBNZ x20, #0x28c28e0       | if (values != null) goto label_3;       
            if(values != null)
            {
                goto label_3;
            }
            // 0x028C28DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_3:
            // 0x028C28E0: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x028C28E4: LDR x8, [x8, #0x6f8]       | X8 = (string**)(1152921513268341808)("cz");
            // 0x028C28E8: LDR x2, [x21]              | X2 = public System.Object System.Collections.Generic.Dictionary<System.String, System.Object>::get_Item(System.String key);
            // 0x028C28EC: MOV x0, x20                | X0 = values;//m1                        
            // 0x028C28F0: LDR x1, [x8]               | X1 = "cz";                              
            // 0x028C28F4: BL #0x23fc26c              | X0 = values.get_Item(key:  "cz");       
            object val_5 = values.Item["cz"];
            // 0x028C28F8: MOV x1, x0                 | X1 = val_5;//m1                         
            // 0x028C28FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C2900: MOV x0, x19                | X0 = 1152921513268386608 (0x1000000204449B30);//ML01
            // 0x028C2904: BL #0x26d49a4              | X0 = this.CastFloat(o:  val_5);         
            float val_6 = this.CastFloat(o:  val_5);
            // 0x028C2908: MOV v2.16b, v0.16b         | V2 = val_6;//m1                         
            // 0x028C290C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C2910: ADD x0, sp, #0x28          | X0 = (1152921513268374464 + 40) = 1152921513268374504 (0x1000000204446BE8);
            // 0x028C2914: MOV v0.16b, v8.16b         | V0 = val_2;//m1                         
            // 0x028C2918: MOV v1.16b, v9.16b         | V1 = val_4;//m1                         
            // 0x028C291C: STR wzr, [sp, #0x30]       | stack[1152921513268374512] = 0x0;        //  dest_result_addr=1152921513268374512
            // 0x028C2920: STR xzr, [sp, #0x28]       | stack[1152921513268374504] = 0x0;        //  dest_result_addr=1152921513268374504
            // 0x028C2924: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x028C2928: LDP s0, s1, [sp, #0x28]    | S0 = 0; S1 = 0;                          //  | 
            // 0x028C292C: LDR s2, [sp, #0x30]        | S2 = 0;                                 
            // 0x028C2930: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C2934: ADD x0, sp, #0x38          | X0 = (1152921513268374464 + 56) = 1152921513268374520 (0x1000000204446BF8);
            // 0x028C2938: BL #0x20cc120              | X0 = label_UnityEngine_Bounds_get_center_GL020CC120();
            // 0x028C293C: CBNZ x20, #0x28c2944       | if (values != null) goto label_4;       
            if(values != null)
            {
                goto label_4;
            }
            // 0x028C2940: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000204446BF8, ????);
            label_4:
            // 0x028C2944: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
            // 0x028C2948: LDR x8, [x8, #0x930]       | X8 = (string**)(1152921513268345984)("ex");
            // 0x028C294C: LDR x2, [x21]              | X2 = public System.Object System.Collections.Generic.Dictionary<System.String, System.Object>::get_Item(System.String key);
            // 0x028C2950: MOV x0, x20                | X0 = values;//m1                        
            // 0x028C2954: LDR x1, [x8]               | X1 = "ex";                              
            // 0x028C2958: BL #0x23fc26c              | X0 = values.get_Item(key:  "ex");       
            object val_7 = values.Item["ex"];
            // 0x028C295C: MOV x1, x0                 | X1 = val_7;//m1                         
            // 0x028C2960: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C2964: MOV x0, x19                | X0 = 1152921513268386608 (0x1000000204449B30);//ML01
            // 0x028C2968: BL #0x26d49a4              | X0 = this.CastFloat(o:  val_7);         
            float val_8 = this.CastFloat(o:  val_7);
            // 0x028C296C: MOV v8.16b, v0.16b         | V8 = val_8;//m1                         
            // 0x028C2970: CBNZ x20, #0x28c2978       | if (values != null) goto label_5;       
            if(values != null)
            {
                goto label_5;
            }
            // 0x028C2974: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_5:
            // 0x028C2978: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
            // 0x028C297C: LDR x8, [x8, #0x640]       | X8 = (string**)(1152921513268350160)("ey");
            // 0x028C2980: LDR x2, [x21]              | X2 = public System.Object System.Collections.Generic.Dictionary<System.String, System.Object>::get_Item(System.String key);
            // 0x028C2984: MOV x0, x20                | X0 = values;//m1                        
            // 0x028C2988: LDR x1, [x8]               | X1 = "ey";                              
            // 0x028C298C: BL #0x23fc26c              | X0 = values.get_Item(key:  "ey");       
            object val_9 = values.Item["ey"];
            // 0x028C2990: MOV x1, x0                 | X1 = val_9;//m1                         
            // 0x028C2994: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C2998: MOV x0, x19                | X0 = 1152921513268386608 (0x1000000204449B30);//ML01
            // 0x028C299C: BL #0x26d49a4              | X0 = this.CastFloat(o:  val_9);         
            float val_10 = this.CastFloat(o:  val_9);
            // 0x028C29A0: MOV v9.16b, v0.16b         | V9 = val_10;//m1                        
            // 0x028C29A4: CBNZ x20, #0x28c29ac       | if (values != null) goto label_6;       
            if(values != null)
            {
                goto label_6;
            }
            // 0x028C29A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_6:
            // 0x028C29AC: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x028C29B0: LDR x8, [x8, #0x2e8]       | X8 = (string**)(1152921513268354336)("ez");
            // 0x028C29B4: LDR x2, [x21]              | X2 = public System.Object System.Collections.Generic.Dictionary<System.String, System.Object>::get_Item(System.String key);
            // 0x028C29B8: MOV x0, x20                | X0 = values;//m1                        
            // 0x028C29BC: LDR x1, [x8]               | X1 = "ez";                              
            // 0x028C29C0: BL #0x23fc26c              | X0 = values.get_Item(key:  "ez");       
            object val_11 = values.Item["ez"];
            // 0x028C29C4: MOV x1, x0                 | X1 = val_11;//m1                        
            // 0x028C29C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C29CC: MOV x0, x19                | X0 = 1152921513268386608 (0x1000000204449B30);//ML01
            // 0x028C29D0: BL #0x26d49a4              | X0 = this.CastFloat(o:  val_11);        
            float val_12 = this.CastFloat(o:  val_11);
            // 0x028C29D4: MOV v2.16b, v0.16b         | V2 = val_12;//m1                        
            // 0x028C29D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C29DC: ADD x0, sp, #0x18          | X0 = (1152921513268374464 + 24) = 1152921513268374488 (0x1000000204446BD8);
            // 0x028C29E0: MOV v0.16b, v8.16b         | V0 = val_8;//m1                         
            // 0x028C29E4: MOV v1.16b, v9.16b         | V1 = val_10;//m1                        
            // 0x028C29E8: STR wzr, [sp, #0x20]       | stack[1152921513268374496] = 0x0;        //  dest_result_addr=1152921513268374496
            // 0x028C29EC: STR xzr, [sp, #0x18]       | stack[1152921513268374488] = 0x0;        //  dest_result_addr=1152921513268374488
            // 0x028C29F0: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x028C29F4: LDP s0, s1, [sp, #0x18]    | S0 = 0; S1 = 0;                          //  | 
            // 0x028C29F8: LDR s2, [sp, #0x20]        | S2 = 0;                                 
            // 0x028C29FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C2A00: ADD x0, sp, #0x38          | X0 = (1152921513268374464 + 56) = 1152921513268374520 (0x1000000204446BF8);
            // 0x028C2A04: BL #0x20cc284              | X0 = label_UnityEngine_Bounds_get_extents_GL020CC284();
            // 0x028C2A08: ADRP x9, #0x3661000        | X9 = 57020416 (0x3661000);              
            // 0x028C2A0C: LDR x8, [sp, #0x48]        | X8 = 0x0;                               
            // 0x028C2A10: LDUR q0, [sp, #0x38]       | Q0 = 0x0;                               
            // 0x028C2A14: LDR x9, [x9, #0x8c8]       | X9 = 1152921504695291904;               
            // 0x028C2A18: MOV x1, sp                 | X1 = 1152921513268374464 (0x1000000204446BC0);//ML01
            // 0x028C2A1C: STR x8, [sp, #0x10]        | stack[1152921513268374480] = 0x0;        //  dest_result_addr=1152921513268374480
            // 0x028C2A20: LDR x0, [x9]               | X0 = typeof(UnityEngine.Bounds);        
            // 0x028C2A24: STR q0, [sp]               | stack[1152921513268374464] = 0x0;        //  dest_result_addr=1152921513268374464
            // 0x028C2A28: BL #0x27bc028              | X0 = 1152921513268451376 = (Il2CppObject*)Box((RuntimeClass*)typeof(UnityEngine.Bounds), null);
            // 0x028C2A2C: SUB sp, x29, #0x30         | SP = (1152921513268374592 - 48) = 1152921513268374544 (0x1000000204446C10);
            // 0x028C2A30: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028C2A34: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028C2A38: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028C2A3C: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
            // 0x028C2A40: RET                        |  return (System.Object)null;            
            return (object)0;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028C2A44 (42740292), len: 680  VirtAddr: 0x028C2A44 RVA: 0x028C2A44 token: 100682600 methodIndex: 51200 delegateWrapperIndex: 0 methodInvoker: 0
        public override System.Collections.Generic.Dictionary<string, object> WriteJson(System.Type type, object value)
        {
            //
            // Disasemble & Code
            //  | 
            object val_1;
            //  | 
            var val_3;
            // 0x028C2A44: STP x22, x21, [sp, #-0x30]! | stack[1152921513268558240] = ???;  stack[1152921513268558248] = ???;  //  dest_result_addr=1152921513268558240 |  dest_result_addr=1152921513268558248
            // 0x028C2A48: STP x20, x19, [sp, #0x10]  | stack[1152921513268558256] = ???;  stack[1152921513268558264] = ???;  //  dest_result_addr=1152921513268558256 |  dest_result_addr=1152921513268558264
            // 0x028C2A4C: STP x29, x30, [sp, #0x20]  | stack[1152921513268558272] = ???;  stack[1152921513268558280] = ???;  //  dest_result_addr=1152921513268558272 |  dest_result_addr=1152921513268558280
            // 0x028C2A50: ADD x29, sp, #0x20         | X29 = (1152921513268558240 + 32) = 1152921513268558272 (0x10000002044739C0);
            // 0x028C2A54: SUB sp, sp, #0x40          | SP = (1152921513268558240 - 64) = 1152921513268558176 (0x1000000204473960);
            // 0x028C2A58: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028C2A5C: LDRB w8, [x20, #0x955]     | W8 = (bool)static_value_037B8955;       
            // 0x028C2A60: MOV x19, x2                | X19 = value;//m1                        
            // 0x028C2A64: TBNZ w8, #0, #0x28c2a80    | if (static_value_037B8955 == true) goto label_0;
            // 0x028C2A68: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x028C2A6C: LDR x8, [x8, #0xa68]       | X8 = 0x2B8F944;                         
            // 0x028C2A70: LDR w0, [x8]               | W0 = 0x1515;                            
            // 0x028C2A74: BL #0x2782188              | X0 = sub_2782188( ?? 0x1515, ????);     
            // 0x028C2A78: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028C2A7C: STRB w8, [x20, #0x955]     | static_value_037B8955 = true;            //  dest_result_addr=58427733
            label_0:
            // 0x028C2A80: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x028C2A84: LDR x8, [x8, #0x8c8]       | X8 = 1152921504695291904;               
            // 0x028C2A88: LDR x20, [x8]              | X20 = typeof(UnityEngine.Bounds);       
            // 0x028C2A8C: STP xzr, xzr, [sp, #0x28]  | stack[1152921513268558216] = 0x0;  stack[1152921513268558224] = 0x0;  //  dest_result_addr=1152921513268558216 |  dest_result_addr=1152921513268558224
            // 0x028C2A90: STR xzr, [sp, #0x20]       | stack[1152921513268558208] = 0x0;        //  dest_result_addr=1152921513268558208
            // 0x028C2A94: CBNZ x19, #0x28c2a9c       | if (value != null) goto label_1;        
            if(value != null)
            {
                goto label_1;
            }
            // 0x028C2A98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1515, ????);     
            label_1:
            // 0x028C2A9C: LDR x8, [x19]              | X8 = typeof(System.Object);             
            // 0x028C2AA0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028C2AA4: LDR x8, [x20, #0x30]       | X8 = UnityEngine.Bounds.__il2cppRuntimeField_element_class;
            // 0x028C2AA8: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, UnityEngine.Bounds.__il2cppRuntimeField_element_class)
            // 0x028C2AAC: B.EQ #0x28c2adc            | if (System.Object.__il2cppRuntimeField_element_class == UnityEngine.Bounds.__il2cppRuntimeField_element_class) goto label_2;
            // 0x028C2AB0: SUB x8, x29, #0x28         | X8 = (1152921513268558272 - 40) = 1152921513268558232 (0x1000000204473998);
            // 0x028C2AB4: MOV x1, x20                | X1 = 1152921504695291904 (0x1000000005459000);//ML01
            // 0x028C2AB8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028C2ABC: LDUR x0, [x29, #-0x28]     | X0 = val_1;                              //  find_add[1152921513268546288]
            // 0x028C2AC0: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x028C2AC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C2AC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x028C2ACC: SUB x0, x29, #0x28         | X0 = (1152921513268558272 - 40) = 1152921513268558232 (0x1000000204473998);
            // 0x028C2AD0: BL #0x299a140              | 
            // 0x028C2AD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_3 = 0;
            // 0x028C2AD8: B #0x28c2ae4               |  goto label_3;                          
            goto label_3;
            label_2:
            // 0x028C2ADC: MOV x0, x19                | X0 = value;//m1                         
            val_3 = value;
            // 0x028C2AE0: BL #0x27bc4e8              | value.System.IDisposable.Dispose();     
            val_3.System.IDisposable.Dispose();
            label_3:
            // 0x028C2AE4: LDR x8, [x0, #0x10]        | 
            // 0x028C2AE8: STR x8, [sp, #0x30]        | stack[1152921513268558224] = UnityEngine.Bounds.__il2cppRuntimeField_element_class;  //  dest_result_addr=1152921513268558224
            // 0x028C2AEC: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
            // 0x028C2AF0: LDR q0, [x0]               | Q0 = typeof(System.Object);             
            // 0x028C2AF4: LDR x8, [x8, #0xa10]       | X8 = 1152921504615792640;               
            // 0x028C2AF8: STR q0, [sp, #0x20]        | stack[1152921513268558208] = typeof(System.Object);  //  dest_result_addr=1152921513268558208
            // 0x028C2AFC: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.String, System.Object> val_2 = null;
            // 0x028C2B00: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x028C2B04: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
            // 0x028C2B08: LDR x8, [x8, #0xf70]       | X8 = 1152921509667012816;               
            // 0x028C2B0C: MOV x19, x0                | X19 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x028C2B10: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Object>::.ctor();
            // 0x028C2B14: BL #0x23fb0c4              | .ctor();                                
            val_2 = new System.Collections.Generic.Dictionary<System.String, System.Object>();
            // 0x028C2B18: ADD x0, sp, #0x20          | X0 = (1152921513268558176 + 32) = 1152921513268558208 (0x1000000204473980);
            // 0x028C2B1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C2B20: BL #0x20cbfcc              | X0 = label_UnityEngine_Bounds_ClosestPoint_GL020CBFCC();
            // 0x028C2B24: ADRP x21, #0x35e6000       | X21 = 56516608 (0x35E6000);             
            // 0x028C2B28: LDR x21, [x21, #0xce8]     | X21 = 1152921504608444416;              
            // 0x028C2B2C: SUB x1, x29, #0x28         | X1 = (1152921513268558272 - 40) = 1152921513268558232 (0x1000000204473998);
            // 0x028C2B30: STUR s0, [x29, #-0x28]     | val_1 = typeof(System.Object);           //  dest_result_addr=1152921513268558232
            val_1 = null;
            // 0x028C2B34: LDR x0, [x21]              | X0 = typeof(System.Single);             
            // 0x028C2B38: BL #0x27bc028              | X0 = 1152921513268611504 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), typeof(System.Object));
            // 0x028C2B3C: MOV x20, x0                | X20 = 1152921513268611504 (0x10000002044809B0);//ML01
            // 0x028C2B40: CBNZ x19, #0x28c2b48       | if ( != 0) goto label_4;                
            if(null != 0)
            {
                goto label_4;
            }
            // 0x028C2B44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object), ????);
            label_4:
            // 0x028C2B48: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x028C2B4C: ADRP x22, #0x3646000       | X22 = 56909824 (0x3646000);             
            // 0x028C2B50: LDR x8, [x8, #0x7c0]       | X8 = (string**)(1152921513268333456)("cx");
            // 0x028C2B54: LDR x22, [x22, #0x8e0]     | X22 = 1152921509667013840;              
            // 0x028C2B58: MOV x0, x19                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x028C2B5C: MOV x2, x20                | X2 = 1152921513268611504 (0x10000002044809B0);//ML01
            // 0x028C2B60: LDR x1, [x8]               | X1 = "cx";                              
            // 0x028C2B64: LDR x3, [x22]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Object>::Add(System.String key, System.Object value);
            // 0x028C2B68: BL #0x23fd44c              | Add(key:  "cx", value:  val_1 = null);  
            Add(key:  "cx", value:  val_1);
            // 0x028C2B6C: ADD x0, sp, #0x20          | X0 = (1152921513268558176 + 32) = 1152921513268558208 (0x1000000204473980);
            // 0x028C2B70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C2B74: BL #0x20cbfcc              | X0 = label_UnityEngine_Bounds_ClosestPoint_GL020CBFCC();
            // 0x028C2B78: LDR x0, [x21]              | X0 = typeof(System.Single);             
            // 0x028C2B7C: ADD x1, sp, #0x1c          | X1 = (1152921513268558176 + 28) = 1152921513268558204 (0x100000020447397C);
            // 0x028C2B80: STR s1, [sp, #0x1c]        | stack[1152921513268558204] = ???;        //  dest_result_addr=1152921513268558204
            // 0x028C2B84: BL #0x27bc028              | X0 = 1152921513268615600 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), );
            // 0x028C2B88: MOV x20, x0                | X20 = 1152921513268615600 (0x10000002044819B0);//ML01
            // 0x028C2B8C: CBNZ x19, #0x28c2b94       | if ( != 0) goto label_5;                
            if(null != 0)
            {
                goto label_5;
            }
            // 0x028C2B90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ???, ????);        
            label_5:
            // 0x028C2B94: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x028C2B98: LDR x8, [x8, #0xaa8]       | X8 = (string**)(1152921513268337632)("cy");
            // 0x028C2B9C: LDR x3, [x22]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Object>::Add(System.String key, System.Object value);
            // 0x028C2BA0: MOV x0, x19                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x028C2BA4: MOV x2, x20                | X2 = 1152921513268615600 (0x10000002044819B0);//ML01
            // 0x028C2BA8: LDR x1, [x8]               | X1 = "cy";                              
            // 0x028C2BAC: BL #0x23fd44c              | Add(key:  "cy", value:  ???);           
            Add(key:  "cy", value:  ???);
            // 0x028C2BB0: ADD x0, sp, #0x20          | X0 = (1152921513268558176 + 32) = 1152921513268558208 (0x1000000204473980);
            // 0x028C2BB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C2BB8: BL #0x20cbfcc              | X0 = label_UnityEngine_Bounds_ClosestPoint_GL020CBFCC();
            // 0x028C2BBC: LDR x0, [x21]              | X0 = typeof(System.Single);             
            // 0x028C2BC0: ADD x1, sp, #0x18          | X1 = (1152921513268558176 + 24) = 1152921513268558200 (0x1000000204473978);
            // 0x028C2BC4: STR s2, [sp, #0x18]        | stack[1152921513268558200] = ???;        //  dest_result_addr=1152921513268558200
            // 0x028C2BC8: BL #0x27bc028              | X0 = 1152921513268619696 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), );
            // 0x028C2BCC: MOV x20, x0                | X20 = 1152921513268619696 (0x10000002044829B0);//ML01
            // 0x028C2BD0: CBNZ x19, #0x28c2bd8       | if ( != 0) goto label_6;                
            if(null != 0)
            {
                goto label_6;
            }
            // 0x028C2BD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ???, ????);        
            label_6:
            // 0x028C2BD8: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x028C2BDC: LDR x8, [x8, #0x6f8]       | X8 = (string**)(1152921513268341808)("cz");
            // 0x028C2BE0: LDR x3, [x22]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Object>::Add(System.String key, System.Object value);
            // 0x028C2BE4: MOV x0, x19                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x028C2BE8: MOV x2, x20                | X2 = 1152921513268619696 (0x10000002044829B0);//ML01
            // 0x028C2BEC: LDR x1, [x8]               | X1 = "cz";                              
            // 0x028C2BF0: BL #0x23fd44c              | Add(key:  "cz", value:  ???);           
            Add(key:  "cz", value:  ???);
            // 0x028C2BF4: ADD x0, sp, #0x20          | X0 = (1152921513268558176 + 32) = 1152921513268558208 (0x1000000204473980);
            // 0x028C2BF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C2BFC: BL #0x20cbfd8              | X0 = label_UnityEngine_Bounds_ClosestPoint_GL020CBFD8();
            // 0x028C2C00: LDR x0, [x21]              | X0 = typeof(System.Single);             
            // 0x028C2C04: ADD x1, sp, #0x14          | X1 = (1152921513268558176 + 20) = 1152921513268558196 (0x1000000204473974);
            // 0x028C2C08: STR s0, [sp, #0x14]        | stack[1152921513268558196] = typeof(System.Object);  //  dest_result_addr=1152921513268558196
            // 0x028C2C0C: BL #0x27bc028              | X0 = 1152921513268624816 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), typeof(System.Object));
            // 0x028C2C10: MOV x20, x0                | X20 = 1152921513268624816 (0x1000000204483DB0);//ML01
            // 0x028C2C14: CBNZ x19, #0x28c2c1c       | if ( != 0) goto label_7;                
            if(null != 0)
            {
                goto label_7;
            }
            // 0x028C2C18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object), ????);
            label_7:
            // 0x028C2C1C: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
            // 0x028C2C20: LDR x8, [x8, #0x930]       | X8 = (string**)(1152921513268345984)("ex");
            // 0x028C2C24: LDR x3, [x22]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Object>::Add(System.String key, System.Object value);
            // 0x028C2C28: MOV x0, x19                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x028C2C2C: MOV x2, x20                | X2 = 1152921513268624816 (0x1000000204483DB0);//ML01
            // 0x028C2C30: LDR x1, [x8]               | X1 = "ex";                              
            // 0x028C2C34: BL #0x23fd44c              | Add(key:  "ex", value:  null);          
            Add(key:  "ex", value:  null);
            // 0x028C2C38: ADD x0, sp, #0x20          | X0 = (1152921513268558176 + 32) = 1152921513268558208 (0x1000000204473980);
            // 0x028C2C3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C2C40: BL #0x20cbfd8              | X0 = label_UnityEngine_Bounds_ClosestPoint_GL020CBFD8();
            // 0x028C2C44: LDR x0, [x21]              | X0 = typeof(System.Single);             
            // 0x028C2C48: ADD x1, sp, #0x10          | X1 = (1152921513268558176 + 16) = 1152921513268558192 (0x1000000204473970);
            // 0x028C2C4C: STR s1, [sp, #0x10]        | stack[1152921513268558192] = ???;        //  dest_result_addr=1152921513268558192
            // 0x028C2C50: BL #0x27bc028              | X0 = 1152921513268628912 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), );
            // 0x028C2C54: MOV x20, x0                | X20 = 1152921513268628912 (0x1000000204484DB0);//ML01
            // 0x028C2C58: CBNZ x19, #0x28c2c60       | if ( != 0) goto label_8;                
            if(null != 0)
            {
                goto label_8;
            }
            // 0x028C2C5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ???, ????);        
            label_8:
            // 0x028C2C60: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
            // 0x028C2C64: LDR x8, [x8, #0x640]       | X8 = (string**)(1152921513268350160)("ey");
            // 0x028C2C68: LDR x3, [x22]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Object>::Add(System.String key, System.Object value);
            // 0x028C2C6C: MOV x0, x19                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x028C2C70: MOV x2, x20                | X2 = 1152921513268628912 (0x1000000204484DB0);//ML01
            // 0x028C2C74: LDR x1, [x8]               | X1 = "ey";                              
            // 0x028C2C78: BL #0x23fd44c              | Add(key:  "ey", value:  ???);           
            Add(key:  "ey", value:  ???);
            // 0x028C2C7C: ADD x0, sp, #0x20          | X0 = (1152921513268558176 + 32) = 1152921513268558208 (0x1000000204473980);
            // 0x028C2C80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C2C84: BL #0x20cbfd8              | X0 = label_UnityEngine_Bounds_ClosestPoint_GL020CBFD8();
            // 0x028C2C88: LDR x0, [x21]              | X0 = typeof(System.Single);             
            // 0x028C2C8C: ADD x1, sp, #0xc           | X1 = (1152921513268558176 + 12) = 1152921513268558188 (0x100000020447396C);
            // 0x028C2C90: STR s2, [sp, #0xc]         | stack[1152921513268558188] = ???;        //  dest_result_addr=1152921513268558188
            // 0x028C2C94: BL #0x27bc028              | X0 = 1152921513268633008 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), );
            // 0x028C2C98: MOV x20, x0                | X20 = 1152921513268633008 (0x1000000204485DB0);//ML01
            // 0x028C2C9C: CBNZ x19, #0x28c2ca4       | if ( != 0) goto label_9;                
            if(null != 0)
            {
                goto label_9;
            }
            // 0x028C2CA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ???, ????);        
            label_9:
            // 0x028C2CA4: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x028C2CA8: LDR x8, [x8, #0x2e8]       | X8 = (string**)(1152921513268354336)("ez");
            // 0x028C2CAC: LDR x3, [x22]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Object>::Add(System.String key, System.Object value);
            // 0x028C2CB0: MOV x0, x19                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x028C2CB4: MOV x2, x20                | X2 = 1152921513268633008 (0x1000000204485DB0);//ML01
            // 0x028C2CB8: LDR x1, [x8]               | X1 = "ez";                              
            // 0x028C2CBC: BL #0x23fd44c              | Add(key:  "ez", value:  ???);           
            Add(key:  "ez", value:  ???);
            // 0x028C2CC0: MOV x0, x19                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x028C2CC4: SUB sp, x29, #0x20         | SP = (1152921513268558272 - 32) = 1152921513268558240 (0x10000002044739A0);
            // 0x028C2CC8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028C2CCC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028C2CD0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028C2CD4: RET                        |  return (System.Collections.Generic.Dictionary<System.String, System.Object>)typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            return (System.Collections.Generic.Dictionary<System.String, System.Object>)val_2;
            //  |  // // {name=val_0, type=System.Collections.Generic.Dictionary<System.String, System.Object>, size=8, nGRN=0 }
            // 0x028C2CD8: MOV x19, x0                | 
            // 0x028C2CDC: SUB x0, x29, #0x28         | 
            // 0x028C2CE0: BL #0x299a140              | 
            // 0x028C2CE4: MOV x0, x19                | 
            // 0x028C2CE8: BL #0x980800               | 
        
        }
    
    }

}
