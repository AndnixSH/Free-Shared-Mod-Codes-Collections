using UnityEngine;
public class BuglyInit : MonoBehaviour
{
    // Fields
    private const string BuglyAppID = "YOUR APP ID GOES HERE";
    private static System.Func<System.Collections.Generic.Dictionary<string, string>> <>f__mg$cache0; // static_offset: 0x00000000
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x02730E90 (41094800), len: 8  VirtAddr: 0x02730E90 RVA: 0x02730E90 token: 100663348 methodIndex: 24315 delegateWrapperIndex: 0 methodInvoker: 0
    public BuglyInit()
    {
        //
        // Disasemble & Code
        // 0x02730E90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02730E94: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02730E98 (41094808), len: 392  VirtAddr: 0x02730E98 RVA: 0x02730E98 token: 100663349 methodIndex: 24316 delegateWrapperIndex: 0 methodInvoker: 0
    private void Awake()
    {
        //
        // Disasemble & Code
        //  | 
        string val_2;
        //  | 
        System.Func<System.Collections.Generic.Dictionary<System.String, System.String>> val_3;
        // 0x02730E98: STP x24, x23, [sp, #-0x40]! | stack[1152921509931487440] = ???;  stack[1152921509931487448] = ???;  //  dest_result_addr=1152921509931487440 |  dest_result_addr=1152921509931487448
        // 0x02730E9C: STP x22, x21, [sp, #0x10]  | stack[1152921509931487456] = ???;  stack[1152921509931487464] = ???;  //  dest_result_addr=1152921509931487456 |  dest_result_addr=1152921509931487464
        // 0x02730EA0: STP x20, x19, [sp, #0x20]  | stack[1152921509931487472] = ???;  stack[1152921509931487480] = ???;  //  dest_result_addr=1152921509931487472 |  dest_result_addr=1152921509931487480
        // 0x02730EA4: STP x29, x30, [sp, #0x30]  | stack[1152921509931487488] = ???;  stack[1152921509931487496] = ???;  //  dest_result_addr=1152921509931487488 |  dest_result_addr=1152921509931487496
        // 0x02730EA8: ADD x29, sp, #0x30         | X29 = (1152921509931487440 + 48) = 1152921509931487488 (0x100000013D5F9100);
        // 0x02730EAC: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x02730EB0: LDRB w8, [x20, #0xac5]     | W8 = (bool)static_value_03743AC5;       
        // 0x02730EB4: MOV x19, x0                | X19 = 1152921509931499504 (0x100000013D5FBFF0);//ML01
        // 0x02730EB8: TBNZ w8, #0, #0x2730ed4    | if (static_value_03743AC5 == true) goto label_0;
        // 0x02730EBC: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
        // 0x02730EC0: LDR x8, [x8, #0x970]       | X8 = 0x2B8FE80;                         
        // 0x02730EC4: LDR w0, [x8]               | W0 = 0x1664;                            
        // 0x02730EC8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1664, ????);     
        // 0x02730ECC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02730ED0: STRB w8, [x20, #0xac5]     | static_value_03743AC5 = true;            //  dest_result_addr=57948869
        label_0:
        // 0x02730ED4: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
        // 0x02730ED8: LDR x22, [x22, #0x938]     | X22 = 1152921504776761344;              
        // 0x02730EDC: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_2 = null;
        // 0x02730EE0: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x02730EE4: TBZ w8, #0, #0x2730ef4     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x02730EE8: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x02730EEC: CBNZ w8, #0x2730ef4        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x02730EF0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_2:
        // 0x02730EF4: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x02730EF8: BL #0x272e640              | BuglyAgent.ConfigDebugMode(enable:  false);
        BuglyAgent.ConfigDebugMode(enable:  false);
        // 0x02730EFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02730F00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02730F04: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02730F08: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02730F0C: BL #0x272e9fc              | BuglyAgent.ConfigDefault(channel:  val_2 = null, version:  0, user:  0, delay:  0);
        BuglyAgent.ConfigDefault(channel:  val_2, version:  0, user:  0, delay:  0);
        // 0x02730F10: MOVZ w1, #0x5              | W1 = 5 (0x5);//ML01                     
        // 0x02730F14: BL #0x272e990              | BuglyAgent.ConfigAutoReportLogLevel(level:  val_2);
        BuglyAgent.ConfigAutoReportLogLevel(level:  val_2);
        // 0x02730F18: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x02730F1C: BL #0x272e920              | BuglyAgent.ConfigAutoQuitApplication(autoQuit:  false);
        BuglyAgent.ConfigAutoQuitApplication(autoQuit:  false);
        // 0x02730F20: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x02730F24: LDRB w8, [x20, #0xa9d]     | W8 = (bool)static_value_03743A9D;       
        // 0x02730F28: TBNZ w8, #0, #0x2730f44    | if (static_value_03743A9D == true) goto label_3;
        // 0x02730F2C: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
        // 0x02730F30: LDR x8, [x8, #0x550]       | X8 = 0x2B8FE50;                         
        // 0x02730F34: LDR w0, [x8]               | W0 = 0x1658;                            
        val_2 = 5720;
        // 0x02730F38: BL #0x2782188              | X0 = sub_2782188( ?? 0x1658, ????);     
        // 0x02730F3C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02730F40: STRB w8, [x20, #0xa9d]     | static_value_03743A9D = true;            //  dest_result_addr=57948829
        label_3:
        // 0x02730F44: ADRP x8, #0x35ca000        | X8 = 56401920 (0x35CA000);              
        // 0x02730F48: LDR x8, [x8, #0x920]       | X8 = (string**)(1152921509931473344)("YOUR APP ID GOES HERE");
        // 0x02730F4C: LDR x1, [x8]               | X1 = "YOUR APP ID GOES HERE";           
        // 0x02730F50: BL #0x272b768              | BuglyAgent.InitWithAppId(appId:  val_2 = 5720);
        BuglyAgent.InitWithAppId(appId:  val_2);
        // 0x02730F54: BL #0x272c098              | BuglyAgent.EnableExceptionHandler();    
        BuglyAgent.EnableExceptionHandler();
        // 0x02730F58: ADRP x23, #0x367f000       | X23 = 57143296 (0x367F000);             
        // 0x02730F5C: LDR x23, [x23, #0x4e8]     | X23 = 1152921504776921088;              
        // 0x02730F60: LDR x8, [x23]              | X8 = typeof(BuglyInit);                 
        // 0x02730F64: LDR x8, [x8, #0xa0]        | X8 = BuglyInit.__il2cppRuntimeField_static_fields;
        // 0x02730F68: LDR x20, [x8]              | X20 = BuglyInit.<>f__mg$cache0;         
        val_3 = BuglyInit.<>f__mg$cache0;
        // 0x02730F6C: CBNZ x20, #0x2730fc0       | if (BuglyInit.<>f__mg$cache0 != null) goto label_4;
        if(val_3 != null)
        {
            goto label_4;
        }
        // 0x02730F70: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
        // 0x02730F74: ADRP x9, #0x3650000        | X9 = 56950784 (0x3650000);              
        // 0x02730F78: LDR x8, [x8, #0xa30]       | X8 = 1152921509931473456;               
        // 0x02730F7C: LDR x9, [x9, #0x520]       | X9 = 1152921504688050176;               
        // 0x02730F80: LDR x20, [x8]              | X20 = static System.Collections.Generic.Dictionary<System.String, System.String> BuglyInit::MyLogCallbackExtrasHandler();
        // 0x02730F84: LDR x0, [x9]               | X0 = typeof(System.Func<TResult>);      
        System.Func<System.Collections.Generic.Dictionary<System.String, System.String>> val_1 = null;
        // 0x02730F88: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Func<TResult>), ????);
        // 0x02730F8C: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x02730F90: LDR x8, [x8, #0xdf0]       | X8 = 1152921509931474480;               
        // 0x02730F94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02730F98: MOV x2, x20                | X2 = 1152921509931473456 (0x100000013D5F5A30);//ML01
        // 0x02730F9C: MOV x21, x0                | X21 = 1152921504688050176 (0x1000000004D71000);//ML01
        // 0x02730FA0: LDR x3, [x8]               | X3 = public System.Void System.Func<System.Collections.Generic.Dictionary<System.String, System.String>>::.ctor(object object, IntPtr method);
        // 0x02730FA4: BL #0x2259264              | .ctor(object:  0, method:  static System.Collections.Generic.Dictionary<System.String, System.String> BuglyInit::MyLogCallbackExtrasHandler());
        val_1 = new System.Func<System.Collections.Generic.Dictionary<System.String, System.String>>(object:  0, method:  static System.Collections.Generic.Dictionary<System.String, System.String> BuglyInit::MyLogCallbackExtrasHandler());
        // 0x02730FA8: LDR x8, [x23]              | X8 = typeof(BuglyInit);                 
        // 0x02730FAC: LDR x8, [x8, #0xa0]        | X8 = BuglyInit.__il2cppRuntimeField_static_fields;
        // 0x02730FB0: STR x21, [x8]              | BuglyInit.<>f__mg$cache0 = typeof(System.Func<TResult>);  //  dest_result_addr=1152921504776925184
        BuglyInit.<>f__mg$cache0 = val_1;
        // 0x02730FB4: LDR x8, [x23]              | X8 = typeof(BuglyInit);                 
        // 0x02730FB8: LDR x8, [x8, #0xa0]        | X8 = BuglyInit.__il2cppRuntimeField_static_fields;
        // 0x02730FBC: LDR x20, [x8]              | X20 = typeof(System.Func<TResult>);     
        val_3 = BuglyInit.<>f__mg$cache0;
        label_4:
        // 0x02730FC0: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        // 0x02730FC4: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x02730FC8: TBZ w8, #0, #0x2730fd8     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x02730FCC: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x02730FD0: CBNZ w8, #0x2730fd8        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x02730FD4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_6:
        // 0x02730FD8: MOV x1, x20                | X1 = 1152921504688050176 (0x1000000004D71000);//ML01
        // 0x02730FDC: BL #0x272c3e4              | BuglyAgent.SetLogCallbackExtrasHandler(handler:  null);
        BuglyAgent.SetLogCallbackExtrasHandler(handler:  null);
        // 0x02730FE0: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x02730FE4: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x02730FE8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x02730FEC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02730FF0: TBZ w8, #0, #0x2731000     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x02730FF4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02730FF8: CBNZ w8, #0x2731000        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x02730FFC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_8:
        // 0x02731000: MOV x1, x19                | X1 = 1152921509931499504 (0x100000013D5FBFF0);//ML01
        // 0x02731004: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x02731008: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x0273100C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x02731010: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731014: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02731018: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x0273101C: B #0x1b78acc               | UnityEngine.Object.Destroy(obj:  0); return;
        UnityEngine.Object.Destroy(obj:  0);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02731020 (41095200), len: 1340  VirtAddr: 0x02731020 RVA: 0x02731020 token: 100663350 methodIndex: 24317 delegateWrapperIndex: 0 methodInvoker: 0
    private static System.Collections.Generic.Dictionary<string, string> MyLogCallbackExtrasHandler()
    {
        //
        // Disasemble & Code
        // 0x02731020: STP x24, x23, [sp, #-0x40]! | stack[1152921509931688928] = ???;  stack[1152921509931688936] = ???;  //  dest_result_addr=1152921509931688928 |  dest_result_addr=1152921509931688936
        // 0x02731024: STP x22, x21, [sp, #0x10]  | stack[1152921509931688944] = ???;  stack[1152921509931688952] = ???;  //  dest_result_addr=1152921509931688944 |  dest_result_addr=1152921509931688952
        // 0x02731028: STP x20, x19, [sp, #0x20]  | stack[1152921509931688960] = ???;  stack[1152921509931688968] = ???;  //  dest_result_addr=1152921509931688960 |  dest_result_addr=1152921509931688968
        // 0x0273102C: STP x29, x30, [sp, #0x30]  | stack[1152921509931688976] = ???;  stack[1152921509931688984] = ???;  //  dest_result_addr=1152921509931688976 |  dest_result_addr=1152921509931688984
        // 0x02731030: ADD x29, sp, #0x30         | X29 = (1152921509931688928 + 48) = 1152921509931688976 (0x100000013D62A410);
        // 0x02731034: SUB sp, sp, #0x20          | SP = (1152921509931688928 - 32) = 1152921509931688896 (0x100000013D62A3C0);
        // 0x02731038: ADRP x19, #0x3743000       | X19 = 57946112 (0x3743000);             
        // 0x0273103C: LDRB w8, [x19, #0xac6]     | W8 = (bool)static_value_03743AC6;       
        // 0x02731040: TBNZ w8, #0, #0x273105c    | if (static_value_03743AC6 == true) goto label_0;
        // 0x02731044: ADRP x8, #0x3655000        | X8 = 56971264 (0x3655000);              
        // 0x02731048: LDR x8, [x8, #0x3c0]       | X8 = 0x2B8FE84;                         
        // 0x0273104C: LDR w0, [x8]               | W0 = 0x1665;                            
        // 0x02731050: BL #0x2782188              | X0 = sub_2782188( ?? 0x1665, ????);     
        // 0x02731054: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02731058: STRB w8, [x19, #0xac6]     | static_value_03743AC6 = true;            //  dest_result_addr=57948870
        label_0:
        // 0x0273105C: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x02731060: LDR x8, [x8, #0x938]       | X8 = 1152921504776761344;               
        // 0x02731064: STR wzr, [sp, #0x1c]       | stack[1152921509931688924] = 0x0;        //  dest_result_addr=1152921509931688924
        // 0x02731068: LDR x0, [x8]               | X0 = typeof(BuglyAgent);                
        // 0x0273106C: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x02731070: TBZ w8, #0, #0x2731080     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x02731074: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x02731078: CBNZ w8, #0x2731080        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0273107C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_2:
        // 0x02731080: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
        // 0x02731084: ADRP x22, #0x3630000       | X22 = 56819712 (0x3630000);             
        // 0x02731088: LDR x8, [x8, #0x170]       | X8 = (string**)(1152921509931587504)("extra handler");
        // 0x0273108C: LDR x22, [x22, #0x3d0]     | X22 = 1152921504954501264;              
        // 0x02731090: LDR x19, [x8]              | X19 = "extra handler";                  
        // 0x02731094: LDR x20, [x22]             | X20 = typeof(System.Object[]);          
        // 0x02731098: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0273109C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x027310A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x027310A4: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x027310A8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x027310AC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x027310B0: MOV x2, x19                | X2 = 1152921509931587504 (0x100000013D6117B0);//ML01
        // 0x027310B4: MOV x3, x0                 | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x027310B8: BL #0x272ec9c              | BuglyAgent.PrintLog(level:  null, format:  0, args:  "extra handler");
        BuglyAgent.PrintLog(level:  null, format:  0, args:  "extra handler");
        // 0x027310BC: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
        // 0x027310C0: LDR x8, [x8, #0xf18]       | X8 = 1152921504615792640;               
        // 0x027310C4: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<System.String, System.String> val_1 = null;
        // 0x027310C8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x027310CC: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x027310D0: LDR x8, [x8, #0x9f8]       | X8 = 1152921509931587600;               
        // 0x027310D4: MOV x19, x0                | X19 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x027310D8: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::.ctor();
        // 0x027310DC: BL #0x23fb0c4              | .ctor();                                
        val_1 = new System.Collections.Generic.Dictionary<System.String, System.String>();
        // 0x027310E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x027310E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x027310E8: BL #0x1b8b7e0              | X0 = UnityEngine.Screen.get_width();    
        int val_2 = UnityEngine.Screen.width;
        // 0x027310EC: ADRP x23, #0x3652000       | X23 = 56958976 (0x3652000);             
        // 0x027310F0: LDR x23, [x23, #0x140]     | X23 = 1152921504607113216;              
        // 0x027310F4: STR w0, [sp, #0x18]        | stack[1152921509931688920] = val_2;      //  dest_result_addr=1152921509931688920
        // 0x027310F8: ADD x1, sp, #0x18          | X1 = (1152921509931688896 + 24) = 1152921509931688920 (0x100000013D62A3D8);
        // 0x027310FC: LDR x8, [x23]              | X8 = typeof(System.Int32);              
        // 0x02731100: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x02731104: BL #0x27bc028              | X0 = 1152921509931732992 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), val_2);
        // 0x02731108: MOV x20, x0                | X20 = 1152921509931732992 (0x100000013D635000);//ML01
        // 0x0273110C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731110: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731114: BL #0x1b8b83c              | X0 = UnityEngine.Screen.get_height();   
        int val_3 = UnityEngine.Screen.height;
        // 0x02731118: LDR x8, [x23]              | X8 = typeof(System.Int32);              
        // 0x0273111C: STR w0, [sp, #0x14]        | stack[1152921509931688916] = val_3;      //  dest_result_addr=1152921509931688916
        // 0x02731120: ADD x1, sp, #0x14          | X1 = (1152921509931688896 + 20) = 1152921509931688916 (0x100000013D62A3D4);
        // 0x02731124: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x02731128: BL #0x27bc028              | X0 = 1152921509931737088 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), val_3);
        // 0x0273112C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x02731130: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x02731134: MOV x21, x0                | X21 = 1152921509931737088 (0x100000013D636000);//ML01
        // 0x02731138: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x0273113C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x02731140: TBZ w9, #0, #0x2731154     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x02731144: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x02731148: CBNZ w9, #0x2731154        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x0273114C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x02731150: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_4:
        // 0x02731154: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
        // 0x02731158: LDR x8, [x8, #0x7e8]       | X8 = (string**)(1152921509931596816)("{0}x{1}");
        // 0x0273115C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731160: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02731164: MOV x2, x20                | X2 = 1152921509931732992 (0x100000013D635000);//ML01
        // 0x02731168: LDR x1, [x8]               | X1 = "{0}x{1}";                         
        // 0x0273116C: MOV x3, x21                | X3 = 1152921509931737088 (0x100000013D636000);//ML01
        // 0x02731170: BL #0x18af348              | X0 = System.String.Format(format:  0, arg0:  "{0}x{1}", arg1:  val_2);
        string val_4 = System.String.Format(format:  0, arg0:  "{0}x{1}", arg1:  val_2);
        // 0x02731174: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x02731178: CBNZ x19, #0x2731180       | if ( != 0) goto label_5;                
        if(null != 0)
        {
            goto label_5;
        }
        // 0x0273117C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_5:
        // 0x02731180: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
        // 0x02731184: ADRP x24, #0x363b000       | X24 = 56864768 (0x363B000);             
        // 0x02731188: LDR x8, [x8, #0xcb0]       | X8 = (string**)(1152921509931601008)("ScreenSolution");
        // 0x0273118C: LDR x24, [x24, #0x310]     | X24 = 1152921509931601104;              
        // 0x02731190: MOV x0, x19                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x02731194: MOV x2, x20                | X2 = val_4;//m1                         
        // 0x02731198: LDR x1, [x8]               | X1 = "ScreenSolution";                  
        // 0x0273119C: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x027311A0: BL #0x23fd44c              | Add(key:  "ScreenSolution", value:  val_4);
        Add(key:  "ScreenSolution", value:  val_4);
        // 0x027311A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x027311A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x027311AC: BL #0x268e4e0              | X0 = UnityEngine.SystemInfo.get_deviceModel();
        string val_5 = UnityEngine.SystemInfo.deviceModel;
        // 0x027311B0: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x027311B4: CBNZ x19, #0x27311bc       | if ( != 0) goto label_6;                
        if(null != 0)
        {
            goto label_6;
        }
        // 0x027311B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_6:
        // 0x027311BC: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x027311C0: LDR x8, [x8, #0xed8]       | X8 = (string**)(1152921509931606224)("deviceModel");
        // 0x027311C4: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x027311C8: MOV x0, x19                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x027311CC: MOV x2, x20                | X2 = val_5;//m1                         
        // 0x027311D0: LDR x1, [x8]               | X1 = "deviceModel";                     
        // 0x027311D4: BL #0x23fd44c              | Add(key:  "deviceModel", value:  val_5);
        Add(key:  "deviceModel", value:  val_5);
        // 0x027311D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x027311DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x027311E0: BL #0x268e484              | X0 = UnityEngine.SystemInfo.get_deviceName();
        string val_6 = UnityEngine.SystemInfo.deviceName;
        // 0x027311E4: MOV x20, x0                | X20 = val_6;//m1                        
        // 0x027311E8: CBNZ x19, #0x27311f0       | if ( != 0) goto label_7;                
        if(null != 0)
        {
            goto label_7;
        }
        // 0x027311EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_7:
        // 0x027311F0: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
        // 0x027311F4: LDR x8, [x8, #0xbf8]       | X8 = (string**)(1152921509931610416)("deviceName");
        // 0x027311F8: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x027311FC: MOV x0, x19                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x02731200: MOV x2, x20                | X2 = val_6;//m1                         
        // 0x02731204: LDR x1, [x8]               | X1 = "deviceName";                      
        // 0x02731208: BL #0x23fd44c              | Add(key:  "deviceName", value:  val_6); 
        Add(key:  "deviceName", value:  val_6);
        // 0x0273120C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731210: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731214: BL #0x268e708              | X0 = UnityEngine.SystemInfo.get_deviceType();
        UnityEngine.DeviceType val_7 = UnityEngine.SystemInfo.deviceType;
        // 0x02731218: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
        // 0x0273121C: LDR x8, [x8, #0x7c0]       | X8 = 1152921504700030976;               
        // 0x02731220: STR w0, [sp, #0x1c]        | stack[1152921509931688924] = val_7;      //  dest_result_addr=1152921509931688924
        // 0x02731224: ADD x1, sp, #0x1c          | X1 = (1152921509931688896 + 28) = 1152921509931688924 (0x100000013D62A3DC);
        // 0x02731228: LDR x8, [x8]               | X8 = typeof(UnityEngine.DeviceType);    
        // 0x0273122C: MOV x0, x8                 | X0 = 1152921504700030976 (0x10000000058DE000);//ML01
        // 0x02731230: BL #0x27bc028              | X0 = 1152921509931757568 = (Il2CppObject*)Box((RuntimeClass*)typeof(UnityEngine.DeviceType), val_7);
        // 0x02731234: MOV x21, x0                | X21 = 1152921509931757568 (0x100000013D63B000);//ML01
        // 0x02731238: CBNZ x21, #0x2731240       | if (val_7 != 0) goto label_8;           
        if(val_7 != 0)
        {
            goto label_8;
        }
        // 0x0273123C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_8:
        // 0x02731240: LDR x8, [x21]              | X8 = typeof(UnityEngine.DeviceType);    
        // 0x02731244: MOV x0, x21                | X0 = 1152921509931757568 (0x100000013D63B000);//ML01
        // 0x02731248: LDP x9, x1, [x8, #0x140]   | X9 = public System.String System.Enum::ToString(); X1 = public System.String System.Enum::ToString(); //  | 
        // 0x0273124C: BLR x9                     | X0 = val_7.ToString();                  
        string val_8 = val_7.ToString();
        // 0x02731250: MOV x20, x0                | X20 = val_8;//m1                        
        // 0x02731254: CBNZ x21, #0x273125c       | if (val_7 != 0) goto label_9;           
        if(val_7 != 0)
        {
            goto label_9;
        }
        // 0x02731258: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_9:
        // 0x0273125C: MOV x0, x21                | X0 = 1152921509931757568 (0x100000013D63B000);//ML01
        // 0x02731260: BL #0x27bc4e8              | val_7.System.IDisposable.Dispose();     
        val_7.System.IDisposable.Dispose();
        // 0x02731264: LDR w8, [x0]               | W8 = typeof(UnityEngine.DeviceType);    
        // 0x02731268: STR w8, [sp, #0x1c]        | stack[1152921509931688924] = typeof(UnityEngine.DeviceType);  //  dest_result_addr=1152921509931688924
        // 0x0273126C: CBNZ x19, #0x2731274       | if ( != 0) goto label_10;               
        if(null != 0)
        {
            goto label_10;
        }
        // 0x02731270: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_10:
        // 0x02731274: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
        // 0x02731278: LDR x8, [x8, #0xa8]        | X8 = (string**)(1152921509931622800)("deviceType");
        // 0x0273127C: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x02731280: MOV x0, x19                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x02731284: MOV x2, x20                | X2 = val_8;//m1                         
        // 0x02731288: LDR x1, [x8]               | X1 = "deviceType";                      
        // 0x0273128C: BL #0x23fd44c              | Add(key:  "deviceType", value:  val_8); 
        Add(key:  "deviceType", value:  val_8);
        // 0x02731290: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731294: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731298: BL #0x268e428              | X0 = UnityEngine.SystemInfo.get_deviceUniqueIdentifier();
        string val_9 = UnityEngine.SystemInfo.deviceUniqueIdentifier;
        // 0x0273129C: MOV x20, x0                | X20 = val_9;//m1                        
        // 0x027312A0: CBNZ x19, #0x27312a8       | if ( != 0) goto label_11;               
        if(null != 0)
        {
            goto label_11;
        }
        // 0x027312A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_11:
        // 0x027312A8: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
        // 0x027312AC: LDR x8, [x8, #0x80]        | X8 = (string**)(1152921509931626992)("deviceUId");
        // 0x027312B0: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x027312B4: MOV x0, x19                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x027312B8: MOV x2, x20                | X2 = val_9;//m1                         
        // 0x027312BC: LDR x1, [x8]               | X1 = "deviceUId";                       
        // 0x027312C0: BL #0x23fd44c              | Add(key:  "deviceUId", value:  val_9);  
        Add(key:  "deviceUId", value:  val_9);
        // 0x027312C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x027312C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x027312CC: BL #0x268d998              | X0 = UnityEngine.SystemInfo.get_graphicsDeviceID();
        int val_10 = UnityEngine.SystemInfo.graphicsDeviceID;
        // 0x027312D0: LDR x8, [x23]              | X8 = typeof(System.Int32);              
        // 0x027312D4: STR w0, [sp, #0x10]        | stack[1152921509931688912] = val_10;     //  dest_result_addr=1152921509931688912
        // 0x027312D8: ADD x1, sp, #0x10          | X1 = (1152921509931688896 + 16) = 1152921509931688912 (0x100000013D62A3D0);
        // 0x027312DC: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x027312E0: BL #0x27bc028              | X0 = 1152921509931769856 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), val_10);
        // 0x027312E4: ADRP x21, #0x3631000       | X21 = 56823808 (0x3631000);             
        // 0x027312E8: LDR x21, [x21, #0x6b8]     | X21 = (string**)(1152921509929946528)("{0}");
        // 0x027312EC: MOV x2, x0                 | X2 = 1152921509931769856 (0x100000013D63E000);//ML01
        // 0x027312F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x027312F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x027312F8: LDR x1, [x21]              | X1 = "{0}";                             
        // 0x027312FC: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "{0}");
        string val_11 = System.String.Format(format:  0, arg0:  "{0}");
        // 0x02731300: MOV x20, x0                | X20 = val_11;//m1                       
        // 0x02731304: CBNZ x19, #0x273130c       | if ( != 0) goto label_12;               
        if(null != 0)
        {
            goto label_12;
        }
        // 0x02731308: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_12:
        // 0x0273130C: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
        // 0x02731310: LDR x8, [x8, #0xfb8]       | X8 = (string**)(1152921509931635280)("gDId");
        // 0x02731314: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x02731318: MOV x0, x19                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x0273131C: MOV x2, x20                | X2 = val_11;//m1                        
        // 0x02731320: LDR x1, [x8]               | X1 = "gDId";                            
        // 0x02731324: BL #0x23fd44c              | Add(key:  "gDId", value:  val_11);      
        Add(key:  "gDId", value:  val_11);
        // 0x02731328: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0273132C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731330: BL #0x268d8e0              | X0 = UnityEngine.SystemInfo.get_graphicsDeviceName();
        string val_12 = UnityEngine.SystemInfo.graphicsDeviceName;
        // 0x02731334: MOV x20, x0                | X20 = val_12;//m1                       
        // 0x02731338: CBNZ x19, #0x2731340       | if ( != 0) goto label_13;               
        if(null != 0)
        {
            goto label_13;
        }
        // 0x0273133C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_13:
        // 0x02731340: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
        // 0x02731344: LDR x8, [x8, #0x808]       | X8 = (string**)(1152921509931639456)("gDName");
        // 0x02731348: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x0273134C: MOV x0, x19                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x02731350: MOV x2, x20                | X2 = val_12;//m1                        
        // 0x02731354: LDR x1, [x8]               | X1 = "gDName";                          
        // 0x02731358: BL #0x23fd44c              | Add(key:  "gDName", value:  val_12);    
        Add(key:  "gDName", value:  val_12);
        // 0x0273135C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731360: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731364: BL #0x268d93c              | X0 = UnityEngine.SystemInfo.get_graphicsDeviceVendor();
        string val_13 = UnityEngine.SystemInfo.graphicsDeviceVendor;
        // 0x02731368: MOV x20, x0                | X20 = val_13;//m1                       
        // 0x0273136C: CBNZ x19, #0x2731374       | if ( != 0) goto label_14;               
        if(null != 0)
        {
            goto label_14;
        }
        // 0x02731370: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_14:
        // 0x02731374: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
        // 0x02731378: LDR x8, [x8, #0xdf8]       | X8 = (string**)(1152921509931643632)("gDVdr");
        // 0x0273137C: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x02731380: MOV x0, x19                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x02731384: MOV x2, x20                | X2 = val_13;//m1                        
        // 0x02731388: LDR x1, [x8]               | X1 = "gDVdr";                           
        // 0x0273138C: BL #0x23fd44c              | Add(key:  "gDVdr", value:  val_13);     
        Add(key:  "gDVdr", value:  val_13);
        // 0x02731390: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731394: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731398: BL #0x268db08              | X0 = UnityEngine.SystemInfo.get_graphicsDeviceVersion();
        string val_14 = UnityEngine.SystemInfo.graphicsDeviceVersion;
        // 0x0273139C: MOV x20, x0                | X20 = val_14;//m1                       
        // 0x027313A0: CBNZ x19, #0x27313a8       | if ( != 0) goto label_15;               
        if(null != 0)
        {
            goto label_15;
        }
        // 0x027313A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_15:
        // 0x027313A8: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
        // 0x027313AC: LDR x8, [x8, #0x848]       | X8 = (string**)(1152921509931647808)("gDVer");
        // 0x027313B0: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x027313B4: MOV x0, x19                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x027313B8: MOV x2, x20                | X2 = val_14;//m1                        
        // 0x027313BC: LDR x1, [x8]               | X1 = "gDVer";                           
        // 0x027313C0: BL #0x23fd44c              | Add(key:  "gDVer", value:  val_14);     
        Add(key:  "gDVer", value:  val_14);
        // 0x027313C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x027313C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x027313CC: BL #0x268d9f4              | X0 = UnityEngine.SystemInfo.get_graphicsDeviceVendorID();
        int val_15 = UnityEngine.SystemInfo.graphicsDeviceVendorID;
        // 0x027313D0: LDR x8, [x23]              | X8 = typeof(System.Int32);              
        // 0x027313D4: STR w0, [sp, #0xc]         | stack[1152921509931688908] = val_15;     //  dest_result_addr=1152921509931688908
        // 0x027313D8: ADD x1, sp, #0xc           | X1 = (1152921509931688896 + 12) = 1152921509931688908 (0x100000013D62A3CC);
        // 0x027313DC: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x027313E0: BL #0x27bc028              | X0 = 1152921509931790336 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), val_15);
        // 0x027313E4: LDR x1, [x21]              | X1 = "{0}";                             
        // 0x027313E8: MOV x2, x0                 | X2 = 1152921509931790336 (0x100000013D643000);//ML01
        // 0x027313EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x027313F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x027313F4: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "{0}");
        string val_16 = System.String.Format(format:  0, arg0:  "{0}");
        // 0x027313F8: MOV x20, x0                | X20 = val_16;//m1                       
        // 0x027313FC: CBNZ x19, #0x2731404       | if ( != 0) goto label_16;               
        if(null != 0)
        {
            goto label_16;
        }
        // 0x02731400: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_16:
        // 0x02731404: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
        // 0x02731408: LDR x8, [x8, #0x650]       | X8 = (string**)(1152921509931656080)("gDVdrID");
        // 0x0273140C: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x02731410: MOV x0, x19                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x02731414: MOV x2, x20                | X2 = val_16;//m1                        
        // 0x02731418: LDR x1, [x8]               | X1 = "gDVdrID";                         
        // 0x0273141C: BL #0x23fd44c              | Add(key:  "gDVdrID", value:  val_16);   
        Add(key:  "gDVdrID", value:  val_16);
        // 0x02731420: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731424: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731428: BL #0x268d884              | X0 = UnityEngine.SystemInfo.get_graphicsMemorySize();
        int val_17 = UnityEngine.SystemInfo.graphicsMemorySize;
        // 0x0273142C: LDR x8, [x23]              | X8 = typeof(System.Int32);              
        // 0x02731430: STR w0, [sp, #8]           | stack[1152921509931688904] = val_17;     //  dest_result_addr=1152921509931688904
        // 0x02731434: ADD x1, sp, #8             | X1 = (1152921509931688896 + 8) = 1152921509931688904 (0x100000013D62A3C8);
        // 0x02731438: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x0273143C: BL #0x27bc028              | X0 = 1152921509931798528 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), val_17);
        // 0x02731440: LDR x1, [x21]              | X1 = "{0}";                             
        // 0x02731444: MOV x2, x0                 | X2 = 1152921509931798528 (0x100000013D645000);//ML01
        // 0x02731448: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0273144C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02731450: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "{0}");
        string val_18 = System.String.Format(format:  0, arg0:  "{0}");
        // 0x02731454: MOV x20, x0                | X20 = val_18;//m1                       
        // 0x02731458: CBNZ x19, #0x2731460       | if ( != 0) goto label_17;               
        if(null != 0)
        {
            goto label_17;
        }
        // 0x0273145C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_17:
        // 0x02731460: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
        // 0x02731464: LDR x8, [x8, #0xe38]       | X8 = (string**)(1152921509931664368)("graphicsMemorySize");
        // 0x02731468: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x0273146C: MOV x0, x19                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x02731470: MOV x2, x20                | X2 = val_18;//m1                        
        // 0x02731474: LDR x1, [x8]               | X1 = "graphicsMemorySize";              
        // 0x02731478: BL #0x23fd44c              | Add(key:  "graphicsMemorySize", value:  val_18);
        Add(key:  "graphicsMemorySize", value:  val_18);
        // 0x0273147C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02731480: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731484: BL #0x268d828              | X0 = UnityEngine.SystemInfo.get_systemMemorySize();
        int val_19 = UnityEngine.SystemInfo.systemMemorySize;
        // 0x02731488: LDR x8, [x23]              | X8 = typeof(System.Int32);              
        // 0x0273148C: STR w0, [sp, #4]           | stack[1152921509931688900] = val_19;     //  dest_result_addr=1152921509931688900
        // 0x02731490: ADD x1, sp, #4             | X1 = (1152921509931688896 + 4) = 1152921509931688900 (0x100000013D62A3C4);
        // 0x02731494: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x02731498: BL #0x27bc028              | X0 = 1152921509931806720 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), val_19);
        // 0x0273149C: LDR x1, [x21]              | X1 = "{0}";                             
        // 0x027314A0: MOV x2, x0                 | X2 = 1152921509931806720 (0x100000013D647000);//ML01
        // 0x027314A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x027314A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x027314AC: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "{0}");
        string val_20 = System.String.Format(format:  0, arg0:  "{0}");
        // 0x027314B0: MOV x20, x0                | X20 = val_20;//m1                       
        // 0x027314B4: CBNZ x19, #0x27314bc       | if ( != 0) goto label_18;               
        if(null != 0)
        {
            goto label_18;
        }
        // 0x027314B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_18:
        // 0x027314BC: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
        // 0x027314C0: LDR x8, [x8, #0x308]       | X8 = (string**)(1152921509931672672)("systemMemorySize");
        // 0x027314C4: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x027314C8: MOV x0, x19                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x027314CC: MOV x2, x20                | X2 = val_20;//m1                        
        // 0x027314D0: LDR x1, [x8]               | X1 = "systemMemorySize";                
        // 0x027314D4: BL #0x23fd44c              | Add(key:  "systemMemorySize", value:  val_20);
        Add(key:  "systemMemorySize", value:  val_20);
        // 0x027314D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x027314DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x027314E0: BL #0x20c7568              | X0 = UnityEngine.Application.get_unityVersion();
        string val_21 = UnityEngine.Application.unityVersion;
        // 0x027314E4: MOV x20, x0                | X20 = val_21;//m1                       
        // 0x027314E8: CBNZ x19, #0x27314f0       | if ( != 0) goto label_19;               
        if(null != 0)
        {
            goto label_19;
        }
        // 0x027314EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_19:
        // 0x027314F0: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
        // 0x027314F4: LDR x8, [x8, #0x4e0]       | X8 = (string**)(1152921509927629520)("UnityVersion");
        // 0x027314F8: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x027314FC: MOV x0, x19                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x02731500: MOV x2, x20                | X2 = val_21;//m1                        
        // 0x02731504: LDR x1, [x8]               | X1 = "UnityVersion";                    
        // 0x02731508: BL #0x23fd44c              | Add(key:  "UnityVersion", value:  val_21);
        Add(key:  "UnityVersion", value:  val_21);
        // 0x0273150C: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
        // 0x02731510: LDR x8, [x8, #0xbc8]       | X8 = (string**)(1152921509931676880)("Package extra data");
        // 0x02731514: LDR x21, [x22]             | X21 = typeof(System.Object[]);          
        // 0x02731518: LDR x20, [x8]              | X20 = "Package extra data";             
        // 0x0273151C: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x02731520: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x02731524: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02731528: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0273152C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x02731530: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x02731534: MOV x2, x20                | X2 = 1152921509931676880 (0x100000013D6274D0);//ML01
        // 0x02731538: MOV x3, x0                 | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0273153C: BL #0x272ec9c              | BuglyAgent.PrintLog(level:  null, format:  2, args:  "Package extra data");
        BuglyAgent.PrintLog(level:  null, format:  2, args:  "Package extra data");
        // 0x02731540: MOV x0, x19                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x02731544: SUB sp, x29, #0x30         | SP = (1152921509931688976 - 48) = 1152921509931688928 (0x100000013D62A3E0);
        // 0x02731548: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x0273154C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x02731550: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x02731554: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x02731558: RET                        |  return (System.Collections.Generic.Dictionary<System.String, System.String>)typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        return (System.Collections.Generic.Dictionary<System.String, System.String>)val_1;
        //  |  // // {name=val_0, type=System.Collections.Generic.Dictionary<System.String, System.String>, size=8, nGRN=0 }
    
    }

}
