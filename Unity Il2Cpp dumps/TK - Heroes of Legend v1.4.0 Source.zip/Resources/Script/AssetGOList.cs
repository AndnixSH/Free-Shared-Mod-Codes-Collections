using UnityEngine;
public class AssetGOList : MonoBehaviour
{
    // Fields
    public UnityEngine.GameObject[] goList; //  0x00000018
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B32B64 (11742052), len: 108  VirtAddr: 0x00B32B64 RVA: 0x00B32B64 token: 100696530 methodIndex: 24942 delegateWrapperIndex: 0 methodInvoker: 0
    public AssetGOList()
    {
        //
        // Disasemble & Code
        // 0x00B32B64: STP x20, x19, [sp, #-0x20]! | stack[1152921515546482448] = ???;  stack[1152921515546482456] = ???;  //  dest_result_addr=1152921515546482448 |  dest_result_addr=1152921515546482456
        // 0x00B32B68: STP x29, x30, [sp, #0x10]  | stack[1152921515546482464] = ???;  stack[1152921515546482472] = ???;  //  dest_result_addr=1152921515546482464 |  dest_result_addr=1152921515546482472
        // 0x00B32B6C: ADD x29, sp, #0x10         | X29 = (1152921515546482448 + 16) = 1152921515546482464 (0x100000028C0D9720);
        // 0x00B32B70: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B32B74: LDRB w8, [x20, #0x799]     | W8 = (bool)static_value_03733799;       
        // 0x00B32B78: MOV x19, x0                | X19 = 1152921515546494480 (0x100000028C0DC610);//ML01
        // 0x00B32B7C: TBNZ w8, #0, #0xb32b98     | if (static_value_03733799 == true) goto label_0;
        // 0x00B32B80: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
        // 0x00B32B84: LDR x8, [x8, #0xab0]       | X8 = 0x2B8EAF4;                         
        // 0x00B32B88: LDR w0, [x8]               | W0 = 0x117D;                            
        // 0x00B32B8C: BL #0x2782188              | X0 = sub_2782188( ?? 0x117D, ????);     
        // 0x00B32B90: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B32B94: STRB w8, [x20, #0x799]     | static_value_03733799 = true;            //  dest_result_addr=57882521
        label_0:
        // 0x00B32B98: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
        // 0x00B32B9C: LDR x8, [x8, #0xb30]       | X8 = 1152921505607026400;               
        // 0x00B32BA0: LDR x20, [x8]              | X20 = typeof(UnityEngine.GameObject[]); 
        // 0x00B32BA4: MOV x0, x20                | X0 = 1152921505607026400 (0x100000003B9D86E0);//ML01
        // 0x00B32BA8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(UnityEngine.GameObject[]), ????);
        // 0x00B32BAC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B32BB0: MOV x0, x20                | X0 = 1152921505607026400 (0x100000003B9D86E0);//ML01
        // 0x00B32BB4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(UnityEngine.GameObject[]), ????);
        // 0x00B32BB8: STR x0, [x19, #0x18]       | this.goList = typeof(UnityEngine.GameObject[]);  //  dest_result_addr=1152921515546494504
        this.goList = null;
        // 0x00B32BBC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B32BC0: MOV x0, x19                | X0 = 1152921515546494480 (0x100000028C0DC610);//ML01
        // 0x00B32BC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B32BC8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B32BCC: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }

}
