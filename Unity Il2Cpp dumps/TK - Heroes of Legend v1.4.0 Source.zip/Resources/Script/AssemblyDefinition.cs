using UnityEngine;

namespace ILRuntime.Mono.Cecil
{
    public sealed class AssemblyDefinition : ICustomAttributeProvider, IMetadataTokenProvider, ISecurityDeclarationProvider, IDisposable
    {
        // Fields
        private ILRuntime.Mono.Cecil.AssemblyNameDefinition name; //  0x00000010
        internal ILRuntime.Mono.Cecil.ModuleDefinition main_module; //  0x00000018
        private ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition> modules; //  0x00000020
        private ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.CustomAttribute> custom_attributes; //  0x00000028
        private ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.SecurityDeclaration> security_declarations; //  0x00000030
        
        // Properties
        public ILRuntime.Mono.Cecil.AssemblyNameDefinition Name { get; set; }
        public string FullName { get; }
        public ILRuntime.Mono.Cecil.MetadataToken MetadataToken { get; }
        public ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition> Modules { get; }
        public ILRuntime.Mono.Cecil.ModuleDefinition MainModule { get; }
        public bool HasCustomAttributes { get; }
        public ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.CustomAttribute> CustomAttributes { get; }
        public bool HasSecurityDeclarations { get; }
        public ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.SecurityDeclaration> SecurityDeclarations { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E546E4 (15025892), len: 8  VirtAddr: 0x00E546E4 RVA: 0x00E546E4 token: 100663445 methodIndex: 19273 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Mono.Cecil.AssemblyNameDefinition get_Name()
        {
            //
            // Disasemble & Code
            // 0x00E546E4: LDR x0, [x0, #0x10]        | X0 = this.name; //P2                    
            // 0x00E546E8: RET                        |  return (ILRuntime.Mono.Cecil.AssemblyNameDefinition)this.name;
            return this.name;
            //  |  // // {name=val_0, type=ILRuntime.Mono.Cecil.AssemblyNameDefinition, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E546EC (15025900), len: 8  VirtAddr: 0x00E546EC RVA: 0x00E546EC token: 100663446 methodIndex: 19274 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_Name(ILRuntime.Mono.Cecil.AssemblyNameDefinition value)
        {
            //
            // Disasemble & Code
            // 0x00E546EC: STR x1, [x0, #0x10]        | this.name = value;                       //  dest_result_addr=1152921509419920528
            this.name = value;
            // 0x00E546F0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E546F4 (15025908), len: 128  VirtAddr: 0x00E546F4 RVA: 0x00E546F4 token: 100663447 methodIndex: 19275 delegateWrapperIndex: 0 methodInvoker: 0
        public string get_FullName()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x00E546F4: STP x20, x19, [sp, #-0x20]! | stack[1152921509420028672] = ???;  stack[1152921509420028680] = ???;  //  dest_result_addr=1152921509420028672 |  dest_result_addr=1152921509420028680
            // 0x00E546F8: STP x29, x30, [sp, #0x10]  | stack[1152921509420028688] = ???;  stack[1152921509420028696] = ???;  //  dest_result_addr=1152921509420028688 |  dest_result_addr=1152921509420028696
            // 0x00E546FC: ADD x29, sp, #0x10         | X29 = (1152921509420028672 + 16) = 1152921509420028688 (0x100000011EE35310);
            // 0x00E54700: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E54704: LDRB w8, [x20, #0xab0]     | W8 = (bool)static_value_03734AB0;       
            // 0x00E54708: MOV x19, x0                | X19 = 1152921509420040704 (0x100000011EE38200);//ML01
            // 0x00E5470C: TBNZ w8, #0, #0xe54728     | if (static_value_03734AB0 == true) goto label_0;
            // 0x00E54710: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x00E54714: LDR x8, [x8, #0x750]       | X8 = 0x2B8E9E0;                         
            // 0x00E54718: LDR w0, [x8]               | W0 = 0x1136;                            
            // 0x00E5471C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1136, ????);     
            // 0x00E54720: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E54724: STRB w8, [x20, #0xab0]     | static_value_03734AB0 = true;            //  dest_result_addr=57887408
            label_0:
            // 0x00E54728: LDR x0, [x19, #0x10]       | X0 = this.name; //P2                    
            // 0x00E5472C: CBZ x0, #0xe5473c          | if (this.name == null) goto label_1;    
            if(this.name == null)
            {
                goto label_1;
            }
            // 0x00E54730: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E54734: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E54738: B #0xe54774                | return this.name.get_FullName();        
            return this.name.FullName;
            label_1:
            // 0x00E5473C: ADRP x19, #0x35d6000       | X19 = 56451072 (0x35D6000);             
            // 0x00E54740: LDR x19, [x19, #0xe38]     | X19 = 1152921504608284672;              
            // 0x00E54744: LDR x0, [x19]              | X0 = typeof(System.String);             
            val_1 = null;
            // 0x00E54748: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00E5474C: TBZ w8, #0, #0xe54760      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00E54750: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E54754: CBNZ w8, #0xe54760         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00E54758: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            // 0x00E5475C: LDR x0, [x19]              | X0 = typeof(System.String);             
            val_1 = null;
            label_3:
            // 0x00E54760: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
            // 0x00E54764: LDR x0, [x8]               | X0 = System.String.Empty;               
            // 0x00E54768: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5476C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E54770: RET                        |  return (System.String)System.String.Empty;
            return System.String.Empty;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E54B40 (15027008), len: 52  VirtAddr: 0x00E54B40 RVA: 0x00E54B40 token: 100663448 methodIndex: 19276 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Mono.Cecil.MetadataToken get_MetadataToken()
        {
            //
            // Disasemble & Code
            // 0x00E54B40: STP x29, x30, [sp, #-0x10]! | stack[1152921509420144784] = ???;  stack[1152921509420144792] = ???;  //  dest_result_addr=1152921509420144784 |  dest_result_addr=1152921509420144792
            // 0x00E54B44: MOV x29, sp                | X29 = 1152921509420144784 (0x100000011EE51890);//ML01
            // 0x00E54B48: SUB sp, sp, #0x10          | SP = (1152921509420144784 - 16) = 1152921509420144768 (0x100000011EE51880);
            // 0x00E54B4C: ADD x0, sp, #8             | X0 = (1152921509420144768 + 8) = 1152921509420144776 (0x100000011EE51888);
            // 0x00E54B50: ORR w1, wzr, #0x20000000   | W1 = 536870912(0x20000000);             
            // 0x00E54B54: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00E54B58: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E54B5C: STR wzr, [sp, #8]          | stack[1152921509420144776] = 0x0;        //  dest_result_addr=1152921509420144776
            // 0x00E54B60: BL #0x11d58ec              | null..ctor(type:  536870912, rid:  1);  
            ILRuntime.Mono.Cecil.MetadataToken val_1 = new ILRuntime.Mono.Cecil.MetadataToken(type:  536870912, rid:  1);
            // 0x00E54B64: LDR w0, [sp, #8]           | W0 = val_1.token;                       
            // 0x00E54B68: MOV sp, x29                | SP = 1152921509420144784 (0x100000011EE51890);//ML01
            // 0x00E54B6C: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x00E54B70: RET                        |  return (ILRuntime.Mono.Cecil.MetadataToken)val_1.token;
            return (ILRuntime.Mono.Cecil.MetadataToken)val_1.token;
            //  |  // // {name=val_0.token, type=System.UInt32, size=4, nGRN=0 offset=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E54B74 (15027060), len: 412  VirtAddr: 0x00E54B74 RVA: 0x00E54B74 token: 100663449 methodIndex: 19277 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition> get_Modules()
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition> val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            System.Func<ILRuntime.Mono.Cecil.AssemblyDefinition, ILRuntime.Mono.Cecil.MetadataReader, ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition>> val_9;
            // 0x00E54B74: STP x26, x25, [sp, #-0x50]! | stack[1152921509420282320] = ???;  stack[1152921509420282328] = ???;  //  dest_result_addr=1152921509420282320 |  dest_result_addr=1152921509420282328
            // 0x00E54B78: STP x24, x23, [sp, #0x10]  | stack[1152921509420282336] = ???;  stack[1152921509420282344] = ???;  //  dest_result_addr=1152921509420282336 |  dest_result_addr=1152921509420282344
            // 0x00E54B7C: STP x22, x21, [sp, #0x20]  | stack[1152921509420282352] = ???;  stack[1152921509420282360] = ???;  //  dest_result_addr=1152921509420282352 |  dest_result_addr=1152921509420282360
            // 0x00E54B80: STP x20, x19, [sp, #0x30]  | stack[1152921509420282368] = ???;  stack[1152921509420282376] = ???;  //  dest_result_addr=1152921509420282368 |  dest_result_addr=1152921509420282376
            // 0x00E54B84: STP x29, x30, [sp, #0x40]  | stack[1152921509420282384] = ???;  stack[1152921509420282392] = ???;  //  dest_result_addr=1152921509420282384 |  dest_result_addr=1152921509420282392
            // 0x00E54B88: ADD x29, sp, #0x40         | X29 = (1152921509420282320 + 64) = 1152921509420282384 (0x100000011EE73210);
            // 0x00E54B8C: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00E54B90: LDRB w8, [x19, #0xab1]     | W8 = (bool)static_value_03734AB1;       
            // 0x00E54B94: MOV x20, x0                | X20 = 1152921509420294400 (0x100000011EE76100);//ML01
            // 0x00E54B98: TBNZ w8, #0, #0xe54bb4     | if (static_value_03734AB1 == true) goto label_0;
            // 0x00E54B9C: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
            // 0x00E54BA0: LDR x8, [x8, #0x670]       | X8 = 0x2B8E9EC;                         
            // 0x00E54BA4: LDR w0, [x8]               | W0 = 0x1139;                            
            // 0x00E54BA8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1139, ????);     
            // 0x00E54BAC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E54BB0: STRB w8, [x19, #0xab1]     | static_value_03734AB1 = true;            //  dest_result_addr=57887409
            label_0:
            // 0x00E54BB4: MOV x19, x20               | X19 = 1152921509420294400 (0x100000011EE76100);//ML01
            // 0x00E54BB8: LDR x21, [x19, #0x20]!     | X21 = this.modules; //P2                
            val_6 = this.modules;
            // 0x00E54BBC: CBNZ x21, #0xe54cf4        | if (this.modules != null) goto label_10;
            if(val_6 != null)
            {
                goto label_10;
            }
            // 0x00E54BC0: LDR x21, [x20, #0x18]      | X21 = this.main_module; //P2            
            // 0x00E54BC4: CBNZ x21, #0xe54bcc        | if (this.main_module != null) goto label_2;
            if(this.main_module != null)
            {
                goto label_2;
            }
            // 0x00E54BC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1139, ????);     
            label_2:
            // 0x00E54BCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E54BD0: MOV x0, x21                | X0 = this.main_module;//m1              
            // 0x00E54BD4: BL #0x11da464              | X0 = this.main_module.get_HasImage();   
            bool val_1 = this.main_module.HasImage;
            // 0x00E54BD8: TBZ w0, #0, #0xe54ca4      | if (val_1 == false) goto label_3;       
            if(val_1 == false)
            {
                goto label_3;
            }
            // 0x00E54BDC: ADRP x25, #0x35b9000       | X25 = 56332288 (0x35B9000);             
            // 0x00E54BE0: LDR x25, [x25, #0xde8]     | X25 = 1152921504737411072;              
            // 0x00E54BE4: LDR x21, [x20, #0x18]      | X21 = this.main_module; //P2            
            // 0x00E54BE8: LDR x0, [x25]              | X0 = typeof(AssemblyDefinition.<>c);    
            val_7 = null;
            // 0x00E54BEC: LDRB w8, [x0, #0x10a]      | W8 = AssemblyDefinition.<>c.__il2cppRuntimeField_10A;
            // 0x00E54BF0: TBZ w8, #0, #0xe54c04      | if (AssemblyDefinition.<>c.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00E54BF4: LDR w8, [x0, #0xbc]        | W8 = AssemblyDefinition.<>c.__il2cppRuntimeField_cctor_finished;
            // 0x00E54BF8: CBNZ w8, #0xe54c04         | if (AssemblyDefinition.<>c.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00E54BFC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AssemblyDefinition.<>c), ????);
            // 0x00E54C00: LDR x0, [x25]              | X0 = typeof(AssemblyDefinition.<>c);    
            val_7 = null;
            label_5:
            // 0x00E54C04: LDR x8, [x0, #0xa0]        | X8 = AssemblyDefinition.<>c.__il2cppRuntimeField_static_fields;
            // 0x00E54C08: LDR x22, [x8, #8]          | X22 = AssemblyDefinition.<>c.<>9__14_0; 
            val_9 = AssemblyDefinition.<>c.<>9__14_0;
            // 0x00E54C0C: CBNZ x22, #0xe54c74        | if (AssemblyDefinition.<>c.<>9__14_0 != null) goto label_6;
            if(val_9 != null)
            {
                goto label_6;
            }
            // 0x00E54C10: LDRB w9, [x0, #0x10a]      | W9 = AssemblyDefinition.<>c.__il2cppRuntimeField_10A;
            // 0x00E54C14: TBZ w9, #0, #0xe54c2c      | if (AssemblyDefinition.<>c.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00E54C18: LDR w9, [x0, #0xbc]        | W9 = AssemblyDefinition.<>c.__il2cppRuntimeField_cctor_finished;
            // 0x00E54C1C: CBNZ w9, #0xe54c2c         | if (AssemblyDefinition.<>c.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00E54C20: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AssemblyDefinition.<>c), ????);
            // 0x00E54C24: LDR x8, [x25]              | X8 = typeof(AssemblyDefinition.<>c);    
            // 0x00E54C28: LDR x8, [x8, #0xa0]        | X8 = AssemblyDefinition.<>c.__il2cppRuntimeField_static_fields;
            label_8:
            // 0x00E54C2C: LDR x23, [x8]              | X23 = AssemblyDefinition.<>c.<>9;       
            // 0x00E54C30: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
            // 0x00E54C34: ADRP x9, #0x363b000        | X9 = 56864768 (0x363B000);              
            // 0x00E54C38: LDR x8, [x8, #0x7b0]       | X8 = 1152921509420257088;               
            // 0x00E54C3C: LDR x9, [x9, #0xea8]       | X9 = 1152921504688156672;               
            // 0x00E54C40: LDR x24, [x8]              | X24 = ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition> AssemblyDefinition.<>c::<get_Modules>b__14_0(ILRuntime.Mono.Cecil.AssemblyDefinition _, ILRuntime.Mono.Cecil.MetadataReader reader);
            // 0x00E54C44: LDR x0, [x9]               | X0 = typeof(System.Func<T1, T2, TResult>);
            System.Func<ILRuntime.Mono.Cecil.AssemblyDefinition, ILRuntime.Mono.Cecil.MetadataReader, ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition>> val_2 = null;
            // 0x00E54C48: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Func<T1, T2, TResult>), ????);
            // 0x00E54C4C: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x00E54C50: LDR x8, [x8, #0x800]       | X8 = 1152921509420258112;               
            // 0x00E54C54: MOV x1, x23                | X1 = AssemblyDefinition.<>c.<>9;//m1    
            // 0x00E54C58: MOV x2, x24                | X2 = 1152921509420257088 (0x100000011EE6CF40);//ML01
            // 0x00E54C5C: MOV x22, x0                | X22 = 1152921504688156672 (0x1000000004D8B000);//ML01
            val_9 = val_2;
            // 0x00E54C60: LDR x3, [x8]               | X3 = public System.Void System.Func<ILRuntime.Mono.Cecil.AssemblyDefinition, ILRuntime.Mono.Cecil.MetadataReader, ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition>>::.ctor(object object, IntPtr method);
            // 0x00E54C64: BL #0x21d5d94              | .ctor(object:  AssemblyDefinition.<>c.__il2cppRuntimeField_static_fields, method:  ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition> AssemblyDefinition.<>c::<get_Modules>b__14_0(ILRuntime.Mono.Cecil.AssemblyDefinition _, ILRuntime.Mono.Cecil.MetadataReader reader));
            val_2 = new System.Func<ILRuntime.Mono.Cecil.AssemblyDefinition, ILRuntime.Mono.Cecil.MetadataReader, ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition>>(object:  AssemblyDefinition.<>c.__il2cppRuntimeField_static_fields, method:  ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition> AssemblyDefinition.<>c::<get_Modules>b__14_0(ILRuntime.Mono.Cecil.AssemblyDefinition _, ILRuntime.Mono.Cecil.MetadataReader reader));
            // 0x00E54C68: LDR x8, [x25]              | X8 = typeof(AssemblyDefinition.<>c);    
            // 0x00E54C6C: LDR x8, [x8, #0xa0]        | X8 = AssemblyDefinition.<>c.__il2cppRuntimeField_static_fields;
            // 0x00E54C70: STR x22, [x8, #8]          | AssemblyDefinition.<>c.<>9__14_0 = typeof(System.Func<T1, T2, TResult>);  //  dest_result_addr=1152921504737415176
            AssemblyDefinition.<>c.<>9__14_0 = val_9;
            label_6:
            // 0x00E54C74: CBNZ x21, #0xe54c7c        | if (this.main_module != null) goto label_9;
            if(this.main_module != null)
            {
                goto label_9;
            }
            // 0x00E54C78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  AssemblyDefinition.<>c.__il2cppRuntimeField_static_fields, method:  ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition> AssemblyDefinition.<>c::<get_Modules>b__14_0(ILRuntime.Mono.Cecil.AssemblyDefinition _, ILRuntime.Mono.Cecil.MetadataReader reader)), ????);
            label_9:
            // 0x00E54C7C: ADRP x8, #0x35b7000        | X8 = 56324096 (0x35B7000);              
            // 0x00E54C80: LDR x8, [x8, #0xd40]       | X8 = 1152921509420259136;               
            // 0x00E54C84: MOV x0, x21                | X0 = this.main_module;//m1              
            // 0x00E54C88: MOV x1, x19                | X1 = 1152921509420294432 (0x100000011EE76120);//ML01
            // 0x00E54C8C: MOV x2, x20                | X2 = 1152921509420294400 (0x100000011EE76100);//ML01
            // 0x00E54C90: LDR x4, [x8]               | X4 = ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition> ILRuntime.Mono.Cecil.ModuleDefinition::Read<ILRuntime.Mono.Cecil.AssemblyDefinition, ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition>>(ref ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition> variable, ILRuntime.Mono.Cecil.AssemblyDefinition item, System.Func<TItem, ILRuntime.Mono.Cecil.MetadataReader, TRet> read);
            // 0x00E54C94: MOV x3, x22                | X3 = 1152921504688156672 (0x1000000004D8B000);//ML01
            // 0x00E54C98: BL #0x23daf0c              | X0 = this.main_module.Read<ILRuntime.Mono.Cecil.AssemblyDefinition, ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition>>(variable: ref  val_6 = this.modules, item:  this, read:  val_9);
            ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition> val_3 = this.main_module.Read<ILRuntime.Mono.Cecil.AssemblyDefinition, ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition>>(variable: ref  val_6, item:  this, read:  val_9);
            // 0x00E54C9C: MOV x21, x0                | X21 = val_3;//m1                        
            val_6 = val_3;
            // 0x00E54CA0: B #0xe54cf4                |  goto label_10;                         
            goto label_10;
            label_3:
            // 0x00E54CA4: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x00E54CA8: LDR x8, [x8, #0xbf8]       | X8 = 1152921504736985088;               
            // 0x00E54CAC: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);
            ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition> val_4 = null;
            // 0x00E54CB0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Mono.Collections.Generic.Collection<T>), ????);
            // 0x00E54CB4: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
            // 0x00E54CB8: LDR x8, [x8, #0xa08]       | X8 = 1152921509420264256;               
            // 0x00E54CBC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00E54CC0: MOV x21, x0                | X21 = 1152921504736985088 (0x1000000007C1C000);//ML01
            val_6 = val_4;
            // 0x00E54CC4: LDR x2, [x8]               | X2 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition>::.ctor(int capacity);
            // 0x00E54CC8: BL #0x1d47070              | .ctor(capacity:  1);                    
            val_4 = new ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition>(capacity:  1);
            // 0x00E54CCC: LDR x20, [x20, #0x18]      | X20 = this.main_module; //P2            
            // 0x00E54CD0: CBNZ x21, #0xe54cd8        | if ( != 0) goto label_11;               
            if(null != 0)
            {
                goto label_11;
            }
            // 0x00E54CD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(capacity:  1), ????);
            label_11:
            // 0x00E54CD8: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x00E54CDC: LDR x8, [x8, #0x770]       | X8 = 1152921509420269376;               
            // 0x00E54CE0: MOV x0, x21                | X0 = 1152921504736985088 (0x1000000007C1C000);//ML01
            // 0x00E54CE4: MOV x1, x20                | X1 = this.main_module;//m1              
            // 0x00E54CE8: LDR x2, [x8]               | X2 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition>::Add(ILRuntime.Mono.Cecil.ModuleDefinition item);
            // 0x00E54CEC: BL #0x1d47324              | Add(item:  this.main_module);           
            Add(item:  this.main_module);
            // 0x00E54CF0: STR x21, [x19]             | this.modules = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);  //  dest_result_addr=1152921509420294432
            this.modules = val_6;
            label_10:
            // 0x00E54CF4: MOV x0, x21                | X0 = 1152921504736985088 (0x1000000007C1C000);//ML01
            // 0x00E54CF8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00E54CFC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00E54D00: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00E54D04: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00E54D08: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00E54D0C: RET                        |  return (ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition>)typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);
            return (ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition>)val_6;
            //  |  // // {name=val_0, type=ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition>, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E54D10 (15027472), len: 8  VirtAddr: 0x00E54D10 RVA: 0x00E54D10 token: 100663450 methodIndex: 19278 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Mono.Cecil.ModuleDefinition get_MainModule()
        {
            //
            // Disasemble & Code
            // 0x00E54D10: LDR x0, [x0, #0x18]        | X0 = this.main_module; //P2             
            // 0x00E54D14: RET                        |  return (ILRuntime.Mono.Cecil.ModuleDefinition)this.main_module;
            return this.main_module;
            //  |  // // {name=val_0, type=ILRuntime.Mono.Cecil.ModuleDefinition, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E54D18 (15027480), len: 160  VirtAddr: 0x00E54D18 RVA: 0x00E54D18 token: 100663451 methodIndex: 19279 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_HasCustomAttributes()
        {
            //
            // Disasemble & Code
            // 0x00E54D18: STP x20, x19, [sp, #-0x20]! | stack[1152921509420544256] = ???;  stack[1152921509420544264] = ???;  //  dest_result_addr=1152921509420544256 |  dest_result_addr=1152921509420544264
            // 0x00E54D1C: STP x29, x30, [sp, #0x10]  | stack[1152921509420544272] = ???;  stack[1152921509420544280] = ???;  //  dest_result_addr=1152921509420544272 |  dest_result_addr=1152921509420544280
            // 0x00E54D20: ADD x29, sp, #0x10         | X29 = (1152921509420544256 + 16) = 1152921509420544272 (0x100000011EEB3110);
            // 0x00E54D24: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E54D28: LDRB w8, [x20, #0xab2]     | W8 = (bool)static_value_03734AB2;       
            // 0x00E54D2C: MOV x19, x0                | X19 = 1152921509420556288 (0x100000011EEB6000);//ML01
            // 0x00E54D30: TBNZ w8, #0, #0xe54d4c     | if (static_value_03734AB2 == true) goto label_0;
            // 0x00E54D34: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
            // 0x00E54D38: LDR x8, [x8, #0xa50]       | X8 = 0x2B8E9E4;                         
            // 0x00E54D3C: LDR w0, [x8]               | W0 = 0x1137;                            
            // 0x00E54D40: BL #0x2782188              | X0 = sub_2782188( ?? 0x1137, ????);     
            // 0x00E54D44: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E54D48: STRB w8, [x20, #0xab2]     | static_value_03734AB2 = true;            //  dest_result_addr=57887410
            label_0:
            // 0x00E54D4C: LDR x0, [x19, #0x28]       | X0 = this.custom_attributes; //P2       
            // 0x00E54D50: CBZ x0, #0xe54d78          | if (this.custom_attributes == null) goto label_1;
            if(this.custom_attributes == null)
            {
                goto label_1;
            }
            // 0x00E54D54: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
            // 0x00E54D58: LDR x8, [x8, #0x268]       | X8 = 1152921509420527168;               
            // 0x00E54D5C: LDR x1, [x8]               | X1 = public System.Int32 ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.CustomAttribute>::get_Count();
            // 0x00E54D60: BL #0x1d46b60              | X0 = this.custom_attributes.get_Count();
            int val_1 = this.custom_attributes.Count;
            // 0x00E54D64: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E54D68: CMP w0, #0                 | STATE = COMPARE(val_1, 0x0)             
            // 0x00E54D6C: CSET w0, gt                | W0 = val_1 > 0 ? 1 : 0;                 
            var val_2 = (val_1 > 0) ? 1 : 0;
            // 0x00E54D70: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E54D74: RET                        |  return (System.Boolean)val_1 > 0 ? 1 : 0;
            return (bool)val_2;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_1:
            // 0x00E54D78: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E54D7C: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x00E54D80: LDR x20, [x19, #0x18]      | X20 = this.main_module; //P2            
            // 0x00E54D84: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E54D88: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E54D8C: TBZ w8, #0, #0xe54d9c      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00E54D90: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E54D94: CBNZ w8, #0xe54d9c         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00E54D98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_3:
            // 0x00E54D9C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E54DA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E54DA4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E54DA8: MOV x1, x19                | X1 = 1152921509420556288 (0x100000011EEB6000);//ML01
            // 0x00E54DAC: MOV x2, x20                | X2 = this.main_module;//m1              
            // 0x00E54DB0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E54DB4: B #0x11d6238               | return ILRuntime.Mono.Cecil.Mixin.GetHasCustomAttributes(self:  0, module:  this);
            return ILRuntime.Mono.Cecil.Mixin.GetHasCustomAttributes(self:  0, module:  this);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E54DB8 (15027640), len: 156  VirtAddr: 0x00E54DB8 RVA: 0x00E54DB8 token: 100663452 methodIndex: 19280 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.CustomAttribute> get_CustomAttributes()
        {
            //
            // Disasemble & Code
            // 0x00E54DB8: STP x22, x21, [sp, #-0x30]! | stack[1152921509420672624] = ???;  stack[1152921509420672632] = ???;  //  dest_result_addr=1152921509420672624 |  dest_result_addr=1152921509420672632
            // 0x00E54DBC: STP x20, x19, [sp, #0x10]  | stack[1152921509420672640] = ???;  stack[1152921509420672648] = ???;  //  dest_result_addr=1152921509420672640 |  dest_result_addr=1152921509420672648
            // 0x00E54DC0: STP x29, x30, [sp, #0x20]  | stack[1152921509420672656] = ???;  stack[1152921509420672664] = ???;  //  dest_result_addr=1152921509420672656 |  dest_result_addr=1152921509420672664
            // 0x00E54DC4: ADD x29, sp, #0x20         | X29 = (1152921509420672624 + 32) = 1152921509420672656 (0x100000011EED2690);
            // 0x00E54DC8: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E54DCC: LDRB w8, [x20, #0xab3]     | W8 = (bool)static_value_03734AB3;       
            // 0x00E54DD0: MOV x19, x0                | X19 = 1152921509420684672 (0x100000011EED5580);//ML01
            // 0x00E54DD4: TBNZ w8, #0, #0xe54df0     | if (static_value_03734AB3 == true) goto label_0;
            // 0x00E54DD8: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x00E54DDC: LDR x8, [x8, #0xb20]       | X8 = 0x2B8E9DC;                         
            // 0x00E54DE0: LDR w0, [x8]               | W0 = 0x1135;                            
            // 0x00E54DE4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1135, ????);     
            // 0x00E54DE8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E54DEC: STRB w8, [x20, #0xab3]     | static_value_03734AB3 = true;            //  dest_result_addr=57887411
            label_0:
            // 0x00E54DF0: MOV x20, x19               | X20 = 1152921509420684672 (0x100000011EED5580);//ML01
            // 0x00E54DF4: LDR x0, [x20, #0x28]!      | X0 = this.custom_attributes; //P2       
            // 0x00E54DF8: CBZ x0, #0xe54e0c          | if (this.custom_attributes == null) goto label_1;
            if(this.custom_attributes == null)
            {
                goto label_1;
            }
            // 0x00E54DFC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E54E00: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E54E04: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E54E08: RET                        |  return (ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.CustomAttribute>)this.custom_attributes;
            return this.custom_attributes;
            //  |  // // {name=val_0, type=ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.CustomAttribute>, size=8, nGRN=0 }
            label_1:
            // 0x00E54E0C: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E54E10: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x00E54E14: LDR x21, [x19, #0x18]      | X21 = this.main_module; //P2            
            // 0x00E54E18: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E54E1C: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E54E20: TBZ w8, #0, #0xe54e30      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00E54E24: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E54E28: CBNZ w8, #0xe54e30         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00E54E2C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_3:
            // 0x00E54E30: MOV x1, x19                | X1 = 1152921509420684672 (0x100000011EED5580);//ML01
            // 0x00E54E34: MOV x2, x20                | X2 = 1152921509420684712 (0x100000011EED55A8);//ML01
            // 0x00E54E38: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E54E3C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E54E40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E54E44: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00E54E48: MOV x3, x21                | X3 = this.main_module;//m1              
            // 0x00E54E4C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E54E50: B #0x11d6424               | return ILRuntime.Mono.Cecil.Mixin.GetCustomAttributes(self:  0, variable: ref  ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.CustomAttribute> val_1 = this, module:  this.custom_attributes);
            return ILRuntime.Mono.Cecil.Mixin.GetCustomAttributes(self:  0, variable: ref  ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.CustomAttribute> val_1 = this, module:  this.custom_attributes);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E54E54 (15027796), len: 160  VirtAddr: 0x00E54E54 RVA: 0x00E54E54 token: 100663453 methodIndex: 19281 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_HasSecurityDeclarations()
        {
            //
            // Disasemble & Code
            // 0x00E54E54: STP x20, x19, [sp, #-0x20]! | stack[1152921509420802048] = ???;  stack[1152921509420802056] = ???;  //  dest_result_addr=1152921509420802048 |  dest_result_addr=1152921509420802056
            // 0x00E54E58: STP x29, x30, [sp, #0x10]  | stack[1152921509420802064] = ???;  stack[1152921509420802072] = ???;  //  dest_result_addr=1152921509420802064 |  dest_result_addr=1152921509420802072
            // 0x00E54E5C: ADD x29, sp, #0x10         | X29 = (1152921509420802048 + 16) = 1152921509420802064 (0x100000011EEF2010);
            // 0x00E54E60: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E54E64: LDRB w8, [x20, #0xab4]     | W8 = (bool)static_value_03734AB4;       
            // 0x00E54E68: MOV x19, x0                | X19 = 1152921509420814080 (0x100000011EEF4F00);//ML01
            // 0x00E54E6C: TBNZ w8, #0, #0xe54e88     | if (static_value_03734AB4 == true) goto label_0;
            // 0x00E54E70: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
            // 0x00E54E74: LDR x8, [x8, #0x240]       | X8 = 0x2B8E9E8;                         
            // 0x00E54E78: LDR w0, [x8]               | W0 = 0x1138;                            
            // 0x00E54E7C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1138, ????);     
            // 0x00E54E80: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E54E84: STRB w8, [x20, #0xab4]     | static_value_03734AB4 = true;            //  dest_result_addr=57887412
            label_0:
            // 0x00E54E88: LDR x0, [x19, #0x30]       | X0 = this.security_declarations; //P2   
            // 0x00E54E8C: CBZ x0, #0xe54eb4          | if (this.security_declarations == null) goto label_1;
            if(this.security_declarations == null)
            {
                goto label_1;
            }
            // 0x00E54E90: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x00E54E94: LDR x8, [x8, #0x9a8]       | X8 = 1152921509420784960;               
            // 0x00E54E98: LDR x1, [x8]               | X1 = public System.Int32 ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.SecurityDeclaration>::get_Count();
            // 0x00E54E9C: BL #0x1d46b60              | X0 = this.security_declarations.get_Count();
            int val_1 = this.security_declarations.Count;
            // 0x00E54EA0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E54EA4: CMP w0, #0                 | STATE = COMPARE(val_1, 0x0)             
            // 0x00E54EA8: CSET w0, gt                | W0 = val_1 > 0 ? 1 : 0;                 
            var val_2 = (val_1 > 0) ? 1 : 0;
            // 0x00E54EAC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E54EB0: RET                        |  return (System.Boolean)val_1 > 0 ? 1 : 0;
            return (bool)val_2;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_1:
            // 0x00E54EB4: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E54EB8: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x00E54EBC: LDR x20, [x19, #0x18]      | X20 = this.main_module; //P2            
            // 0x00E54EC0: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E54EC4: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E54EC8: TBZ w8, #0, #0xe54ed8      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00E54ECC: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E54ED0: CBNZ w8, #0xe54ed8         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00E54ED4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_3:
            // 0x00E54ED8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E54EDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E54EE0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E54EE4: MOV x1, x19                | X1 = 1152921509420814080 (0x100000011EEF4F00);//ML01
            // 0x00E54EE8: MOV x2, x20                | X2 = this.main_module;//m1              
            // 0x00E54EEC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E54EF0: B #0x11d5e20               | return ILRuntime.Mono.Cecil.Mixin.GetHasSecurityDeclarations(self:  0, module:  this);
            return ILRuntime.Mono.Cecil.Mixin.GetHasSecurityDeclarations(self:  0, module:  this);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E54EF4 (15027956), len: 156  VirtAddr: 0x00E54EF4 RVA: 0x00E54EF4 token: 100663454 methodIndex: 19282 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.SecurityDeclaration> get_SecurityDeclarations()
        {
            //
            // Disasemble & Code
            // 0x00E54EF4: STP x22, x21, [sp, #-0x30]! | stack[1152921509420930416] = ???;  stack[1152921509420930424] = ???;  //  dest_result_addr=1152921509420930416 |  dest_result_addr=1152921509420930424
            // 0x00E54EF8: STP x20, x19, [sp, #0x10]  | stack[1152921509420930432] = ???;  stack[1152921509420930440] = ???;  //  dest_result_addr=1152921509420930432 |  dest_result_addr=1152921509420930440
            // 0x00E54EFC: STP x29, x30, [sp, #0x20]  | stack[1152921509420930448] = ???;  stack[1152921509420930456] = ???;  //  dest_result_addr=1152921509420930448 |  dest_result_addr=1152921509420930456
            // 0x00E54F00: ADD x29, sp, #0x20         | X29 = (1152921509420930416 + 32) = 1152921509420930448 (0x100000011EF11590);
            // 0x00E54F04: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E54F08: LDRB w8, [x20, #0xab5]     | W8 = (bool)static_value_03734AB5;       
            // 0x00E54F0C: MOV x19, x0                | X19 = 1152921509420942464 (0x100000011EF14480);//ML01
            // 0x00E54F10: TBNZ w8, #0, #0xe54f2c     | if (static_value_03734AB5 == true) goto label_0;
            // 0x00E54F14: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
            // 0x00E54F18: LDR x8, [x8, #0x530]       | X8 = 0x2B8E9F0;                         
            // 0x00E54F1C: LDR w0, [x8]               | W0 = 0x113A;                            
            // 0x00E54F20: BL #0x2782188              | X0 = sub_2782188( ?? 0x113A, ????);     
            // 0x00E54F24: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E54F28: STRB w8, [x20, #0xab5]     | static_value_03734AB5 = true;            //  dest_result_addr=57887413
            label_0:
            // 0x00E54F2C: MOV x20, x19               | X20 = 1152921509420942464 (0x100000011EF14480);//ML01
            // 0x00E54F30: LDR x0, [x20, #0x30]!      | X0 = this.security_declarations; //P2   
            // 0x00E54F34: CBZ x0, #0xe54f48          | if (this.security_declarations == null) goto label_1;
            if(this.security_declarations == null)
            {
                goto label_1;
            }
            // 0x00E54F38: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E54F3C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E54F40: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E54F44: RET                        |  return (ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.SecurityDeclaration>)this.security_declarations;
            return this.security_declarations;
            //  |  // // {name=val_0, type=ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.SecurityDeclaration>, size=8, nGRN=0 }
            label_1:
            // 0x00E54F48: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E54F4C: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x00E54F50: LDR x21, [x19, #0x18]      | X21 = this.main_module; //P2            
            // 0x00E54F54: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E54F58: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E54F5C: TBZ w8, #0, #0xe54f6c      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00E54F60: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E54F64: CBNZ w8, #0xe54f6c         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00E54F68: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_3:
            // 0x00E54F6C: MOV x1, x19                | X1 = 1152921509420942464 (0x100000011EF14480);//ML01
            // 0x00E54F70: MOV x2, x20                | X2 = 1152921509420942512 (0x100000011EF144B0);//ML01
            // 0x00E54F74: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E54F78: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E54F7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E54F80: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00E54F84: MOV x3, x21                | X3 = this.main_module;//m1              
            // 0x00E54F88: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E54F8C: B #0x11d600c               | return ILRuntime.Mono.Cecil.Mixin.GetSecurityDeclarations(self:  0, variable: ref  ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.SecurityDeclaration> val_1 = this, module:  this.security_declarations);
            return ILRuntime.Mono.Cecil.Mixin.GetSecurityDeclarations(self:  0, variable: ref  ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.SecurityDeclaration> val_1 = this, module:  this.security_declarations);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E54F90 (15028112), len: 8  VirtAddr: 0x00E54F90 RVA: 0x00E54F90 token: 100663455 methodIndex: 19283 delegateWrapperIndex: 0 methodInvoker: 0
        internal AssemblyDefinition()
        {
            //
            // Disasemble & Code
            // 0x00E54F90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E54F94: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E54F98 (15028120), len: 248  VirtAddr: 0x00E54F98 RVA: 0x00E54F98 token: 100663456 methodIndex: 19284 delegateWrapperIndex: 0 methodInvoker: 0
        public void Dispose()
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            // 0x00E54F98: STP x24, x23, [sp, #-0x40]! | stack[1152921509421181024] = ???;  stack[1152921509421181032] = ???;  //  dest_result_addr=1152921509421181024 |  dest_result_addr=1152921509421181032
            // 0x00E54F9C: STP x22, x21, [sp, #0x10]  | stack[1152921509421181040] = ???;  stack[1152921509421181048] = ???;  //  dest_result_addr=1152921509421181040 |  dest_result_addr=1152921509421181048
            // 0x00E54FA0: STP x20, x19, [sp, #0x20]  | stack[1152921509421181056] = ???;  stack[1152921509421181064] = ???;  //  dest_result_addr=1152921509421181056 |  dest_result_addr=1152921509421181064
            // 0x00E54FA4: STP x29, x30, [sp, #0x30]  | stack[1152921509421181072] = ???;  stack[1152921509421181080] = ???;  //  dest_result_addr=1152921509421181072 |  dest_result_addr=1152921509421181080
            // 0x00E54FA8: ADD x29, sp, #0x30         | X29 = (1152921509421181024 + 48) = 1152921509421181072 (0x100000011EF4E890);
            // 0x00E54FAC: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E54FB0: LDRB w8, [x20, #0xab6]     | W8 = (bool)static_value_03734AB6;       
            // 0x00E54FB4: MOV x19, x0                | X19 = 1152921509421193088 (0x100000011EF51780);//ML01
            // 0x00E54FB8: TBNZ w8, #0, #0xe54fd4     | if (static_value_03734AB6 == true) goto label_0;
            // 0x00E54FBC: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
            // 0x00E54FC0: LDR x8, [x8, #0x320]       | X8 = 0x2B8E9D8;                         
            // 0x00E54FC4: LDR w0, [x8]               | W0 = 0x1134;                            
            // 0x00E54FC8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1134, ????);     
            // 0x00E54FCC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E54FD0: STRB w8, [x20, #0xab6]     | static_value_03734AB6 = true;            //  dest_result_addr=57887414
            label_0:
            // 0x00E54FD4: LDR x8, [x19, #0x20]       | X8 = this.modules; //P2                 
            // 0x00E54FD8: CBZ x8, #0xe55068          | if (this.modules == null) goto label_1; 
            if(this.modules == null)
            {
                goto label_1;
            }
            // 0x00E54FDC: MOV x0, x19                | X0 = 1152921509421193088 (0x100000011EF51780);//ML01
            // 0x00E54FE0: BL #0xe54b74               | X0 = this.get_Modules();                
            ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition> val_1 = this.Modules;
            // 0x00E54FE4: ADRP x22, #0x35c7000       | X22 = 56389632 (0x35C7000);             
            // 0x00E54FE8: ADRP x23, #0x35f0000       | X23 = 56557568 (0x35F0000);             
            // 0x00E54FEC: LDR x22, [x22, #0xd30]     | X22 = 1152921509421158848;              
            // 0x00E54FF0: LDR x23, [x23, #0x518]     | X23 = 1152921509421159872;              
            // 0x00E54FF4: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x00E54FF8: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_4 = 0;
            // 0x00E54FFC: B #0xe55010                |  goto label_2;                          
            goto label_2;
            label_7:
            // 0x00E55000: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E55004: MOV x0, x21                | X0 = X21;//m1                           
            // 0x00E55008: BL #0x11dde24              | X21.Dispose();                          
            X21.Dispose();
            // 0x00E5500C: ADD w20, w20, #1           | W20 = (val_4 + 1) = val_4 (0x00000001); 
            val_4 = 1;
            label_2:
            // 0x00E55010: CBNZ x19, #0xe55018        | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x00E55014: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X21, ????);        
            label_3:
            // 0x00E55018: LDR x1, [x22]              | X1 = public System.Int32 ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition>::get_Count();
            // 0x00E5501C: MOV x0, x19                | X0 = val_1;//m1                         
            // 0x00E55020: BL #0x1d46b60              | X0 = val_1.get_Count();                 
            int val_2 = val_1.Count;
            // 0x00E55024: CMP w20, w0                | STATE = COMPARE(0x1, val_2)             
            // 0x00E55028: B.GE #0xe55054             | if (val_4 >= val_2) goto label_4;       
            if(val_4 >= val_2)
            {
                goto label_4;
            }
            // 0x00E5502C: CBNZ x19, #0xe55034        | if (val_1 != null) goto label_5;        
            if(val_1 != null)
            {
                goto label_5;
            }
            // 0x00E55030: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_5:
            // 0x00E55034: LDR x2, [x23]              | X2 = public ILRuntime.Mono.Cecil.ModuleDefinition ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ModuleDefinition>::get_Item(int index);
            // 0x00E55038: MOV x0, x19                | X0 = val_1;//m1                         
            // 0x00E5503C: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
            // 0x00E55040: BL #0x1d46b68              | X0 = val_1.get_Item(index:  1);         
            ILRuntime.Mono.Cecil.ModuleDefinition val_3 = val_1.Item[1];
            // 0x00E55044: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00E55048: CBNZ x21, #0xe55000        | if (val_3 != null) goto label_7;        
            if(val_3 != null)
            {
                goto label_7;
            }
            // 0x00E5504C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            // 0x00E55050: B #0xe55000                |  goto label_7;                          
            goto label_7;
            label_4:
            // 0x00E55054: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00E55058: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5505C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00E55060: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00E55064: RET                        |  return;                                
            return;
            label_1:
            // 0x00E55068: LDR x19, [x19, #0x18]      | X19 = this.main_module; //P2            
            // 0x00E5506C: CBNZ x19, #0xe55074        | if (this.main_module != null) goto label_8;
            if(this.main_module != null)
            {
                goto label_8;
            }
            // 0x00E55070: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1134, ????);     
            label_8:
            // 0x00E55074: MOV x0, x19                | X0 = this.main_module;//m1              
            // 0x00E55078: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5507C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00E55080: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00E55084: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E55088: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00E5508C: B #0x11dde24               | this.main_module.Dispose(); return;     
            this.main_module.Dispose();
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E55090 (15028368), len: 4  VirtAddr: 0x00E55090 RVA: 0x00E55090 token: 100663457 methodIndex: 19285 delegateWrapperIndex: 0 methodInvoker: 0
        public override string ToString()
        {
            //
            // Disasemble & Code
            // 0x00E55090: B #0xe546f4                | return this.get_FullName();             
            return this.FullName;
        
        }
    
    }

}
