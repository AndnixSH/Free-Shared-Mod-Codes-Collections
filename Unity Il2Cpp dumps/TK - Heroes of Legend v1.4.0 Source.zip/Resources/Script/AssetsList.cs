using UnityEngine;
public class AssetsList : MonoBehaviour
{
    // Fields
    public string[] keys; //  0x00000018
    public string[] assets; //  0x00000020
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B347B0 (11749296), len: 8  VirtAddr: 0x00B347B0 RVA: 0x00B347B0 token: 100696532 methodIndex: 24956 delegateWrapperIndex: 0 methodInvoker: 0
    public AssetsList()
    {
        //
        // Disasemble & Code
        // 0x00B347B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B347B4: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B347B8 (11749304), len: 208  VirtAddr: 0x00B347B8 RVA: 0x00B347B8 token: 100696533 methodIndex: 24957 delegateWrapperIndex: 0 methodInvoker: 0
    public string GetAsset(string key)
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        //  | 
        System.String[] val_3;
        //  | 
        var val_4;
        //  | 
        var val_5;
        // 0x00B347B8: STP x22, x21, [sp, #-0x30]! | stack[1152921515546901376] = ???;  stack[1152921515546901384] = ???;  //  dest_result_addr=1152921515546901376 |  dest_result_addr=1152921515546901384
        // 0x00B347BC: STP x20, x19, [sp, #0x10]  | stack[1152921515546901392] = ???;  stack[1152921515546901400] = ???;  //  dest_result_addr=1152921515546901392 |  dest_result_addr=1152921515546901400
        // 0x00B347C0: STP x29, x30, [sp, #0x20]  | stack[1152921515546901408] = ???;  stack[1152921515546901416] = ???;  //  dest_result_addr=1152921515546901408 |  dest_result_addr=1152921515546901416
        // 0x00B347C4: ADD x29, sp, #0x20         | X29 = (1152921515546901376 + 32) = 1152921515546901408 (0x100000028C13FBA0);
        // 0x00B347C8: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B347CC: LDRB w8, [x21, #0x7a4]     | W8 = (bool)static_value_037337A4;       
        // 0x00B347D0: MOV x20, x1                | X20 = key;//m1                          
        // 0x00B347D4: MOV x19, x0                | X19 = 1152921515546913424 (0x100000028C142A90);//ML01
        // 0x00B347D8: TBNZ w8, #0, #0xb347f4     | if (static_value_037337A4 == true) goto label_0;
        // 0x00B347DC: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
        // 0x00B347E0: LDR x8, [x8, #0x7e0]       | X8 = 0x2B8EBBC;                         
        // 0x00B347E4: LDR w0, [x8]               | W0 = 0x11AF;                            
        // 0x00B347E8: BL #0x2782188              | X0 = sub_2782188( ?? 0x11AF, ????);     
        // 0x00B347EC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B347F0: STRB w8, [x21, #0x7a4]     | static_value_037337A4 = true;            //  dest_result_addr=57882532
        label_0:
        // 0x00B347F4: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
        // 0x00B347F8: LDR x1, [x19, #0x18]       | X1 = this.keys; //P2                    
        // 0x00B347FC: LDR x8, [x8, #0x1c8]       | X8 = 1152921515546851536;               
        // 0x00B34800: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34804: MOV x2, x20                | X2 = key;//m1                           
        // 0x00B34808: LDR x3, [x8]               | X3 = public static System.Int32 EArray::IndexOf<System.String>(T[] array, System.String value);
        // 0x00B3480C: BL #0xb7d608               | X0 = EArray.IndexOf<System.String>(array:  0, value:  this.keys);
        int val_1 = EArray.IndexOf<System.String>(array:  0, value:  this.keys);
        // 0x00B34810: MOV w20, w0                | W20 = val_1;//m1                        
        // 0x00B34814: TBNZ w20, #0x1f, #0xb3484c | if ((val_1 & 0x80000000) != 0) goto label_1;
        if((val_1 & 2147483648) != 0)
        {
            goto label_1;
        }
        // 0x00B34818: LDR x19, [x19, #0x20]      | X19 = this.assets; //P2                 
        val_3 = this.assets;
        // 0x00B3481C: CBNZ x19, #0xb34824        | if (this.assets != null) goto label_2;  
        if(val_3 != null)
        {
            goto label_2;
        }
        // 0x00B34820: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_2:
        // 0x00B34824: LDR w8, [x19, #0x18]       | W8 = this.assets.Length; //P2           
        // 0x00B34828: SXTW x21, w20              | X21 = (long)(int)(val_1);               
        val_2 = (long)val_1;
        // 0x00B3482C: CMP w20, w8                | STATE = COMPARE(val_1, this.assets.Length)
        // 0x00B34830: B.LO #0xb34840             | if (val_1 < this.assets.Length) goto label_3;
        if(val_1 < this.assets.Length)
        {
            goto label_3;
        }
        // 0x00B34834: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B34838: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3483C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        label_3:
        // 0x00B34840: ADD x8, x19, x21, lsl #3   | X8 = this.assets[(long)(int)(val_1)]; //PARR1 
        // 0x00B34844: ADD x8, x8, #0x20          | X8 = this.assets[(long)(int)(val_1)][0x20]; //PARR1 
        // 0x00B34848: B #0xb34874                |  goto label_4;                          
        goto label_4;
        label_1:
        // 0x00B3484C: ADRP x19, #0x35d6000       | X19 = 56451072 (0x35D6000);             
        // 0x00B34850: LDR x19, [x19, #0xe38]     | X19 = 1152921504608284672;              
        val_3 = 1152921504608284672;
        // 0x00B34854: LDR x0, [x19]              | X0 = typeof(System.String);             
        val_5 = null;
        // 0x00B34858: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B3485C: TBZ w8, #0, #0xb34870      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00B34860: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B34864: CBNZ w8, #0xb34870         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00B34868: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00B3486C: LDR x0, [x19]              | X0 = typeof(System.String);             
        val_5 = null;
        label_6:
        // 0x00B34870: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        label_4:
        // 0x00B34874: LDR x0, [x8]               | X0 = System.String.Empty;               
        // 0x00B34878: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B3487C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B34880: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B34884: RET                        |  return (System.String)System.String.Empty;
        return (string)System.String.__il2cppRuntimeField_static_fields;
        //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B34888 (11749512), len: 8  VirtAddr: 0x00B34888 RVA: 0x00B34888 token: 100696534 methodIndex: 24958 delegateWrapperIndex: 0 methodInvoker: 0
    public void Clear()
    {
        //
        // Disasemble & Code
        // 0x00B34888: STP xzr, xzr, [x0, #0x18]  | this.keys = null;  this.assets = null;   //  dest_result_addr=1152921515547103272 |  dest_result_addr=1152921515547103280
        this.keys = 0;
        this.assets = 0;
        // 0x00B3488C: RET                        |  return;                                
        return;
    
    }

}
