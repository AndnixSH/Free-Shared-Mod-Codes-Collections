using UnityEngine;
[UnityEngine.AddComponentMenu] // 0x281A31C
[UnityEngine.RequireComponent] // 0x281A31C
[UnityEngine.ExecuteInEditMode] // 0x281A31C
[Serializable]
public class AmbientObscurance : PostEffectsBase
{
    // Fields
    [UnityEngine.RangeAttribute] // 0x281A3B4
    public float intensity; //  0x0000001C
    [UnityEngine.RangeAttribute] // 0x281A3CC
    public float radius; //  0x00000020
    [UnityEngine.RangeAttribute] // 0x281A3E8
    public int blurIterations; //  0x00000024
    [UnityEngine.RangeAttribute] // 0x281A400
    public float blurFilterDistance; //  0x00000028
    [UnityEngine.RangeAttribute] // 0x281A418
    public int downsample; //  0x0000002C
    public UnityEngine.Texture2D rand; //  0x00000030
    public UnityEngine.Shader aoShader; //  0x00000038
    private UnityEngine.Material aoMaterial; //  0x00000040
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x0267146C (40309868), len: 76  VirtAddr: 0x0267146C RVA: 0x0267146C token: 100663297 methodIndex: 24381 delegateWrapperIndex: 0 methodInvoker: 0
    public AmbientObscurance()
    {
        //
        // Disasemble & Code
        // 0x0267146C: STP x20, x19, [sp, #-0x20]! | stack[1152921509942865152] = ???;  stack[1152921509942865160] = ???;  //  dest_result_addr=1152921509942865152 |  dest_result_addr=1152921509942865160
        // 0x02671470: STP x29, x30, [sp, #0x10]  | stack[1152921509942865168] = ???;  stack[1152921509942865176] = ???;  //  dest_result_addr=1152921509942865168 |  dest_result_addr=1152921509942865176
        // 0x02671474: ADD x29, sp, #0x10         | X29 = (1152921509942865152 + 16) = 1152921509942865168 (0x100000013E0D2D10);
        // 0x02671478: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267147C: MOV x19, x0                | X19 = 1152921509942877184 (0x100000013E0D5C00);//ML01
        // 0x02671480: BL #0x1b76fd4              | this..ctor();                           
        val_1 = new UnityEngine.MonoBehaviour();
        // 0x02671484: MOVZ w10, #0x3e4c, lsl #16 | W10 = 1045168128 (0x3E4C0000);//ML01    
        // 0x02671488: MOVZ x11, #0x3fa0, lsl #48 | X11 = 4584664420663164928 (0x3FA0000000000000);//ML01
        // 0x0267148C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02671490: ORR w9, wzr, #0x3f000000   | W9 = 1056964608(0x3F000000);            
        // 0x02671494: MOVK w10, #0xcccd          | W10 = 1045220557 (0x3E4CCCCD);          
        // 0x02671498: MOVK x11, #0x1             | X11 = 4584664420663164929 (0x3FA0000000000001);
        // 0x0267149C: STRB w8, [x19, #0x18]      | mem[1152921509942877208] = 0x1;          //  dest_result_addr=1152921509942877208
        mem[1152921509942877208] = 1;
        // 0x026714A0: STRB w8, [x19, #0x1a]      | mem[1152921509942877210] = 0x1;          //  dest_result_addr=1152921509942877210
        mem[1152921509942877210] = 1;
        // 0x026714A4: STP w9, w10, [x19, #0x1c]  | this.intensity = 0.5;  this.radius = 0.2;  //  dest_result_addr=1152921509942877212 |  dest_result_addr=1152921509942877216
        this.intensity = 0.5f;
        this.radius = 0.2f;
        // 0x026714A8: STUR x11, [x19, #0x24]     | this.blurIterations = 1; this.blurFilterDistance = 1.25;  //  dest_result_addr=1152921509942877220 dest_result_addr=1152921509942877224
        this.blurIterations = 1;
        this.blurFilterDistance = 1.25f;
        // 0x026714AC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x026714B0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x026714B4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x026714E8 (40309992), len: 104  VirtAddr: 0x026714E8 RVA: 0x026714E8 token: 100663298 methodIndex: 24382 delegateWrapperIndex: 0 methodInvoker: 0
    public override bool CheckResources()
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        // 0x026714E8: STP x20, x19, [sp, #-0x20]! | stack[1152921509942985344] = ???;  stack[1152921509942985352] = ???;  //  dest_result_addr=1152921509942985344 |  dest_result_addr=1152921509942985352
        // 0x026714EC: STP x29, x30, [sp, #0x10]  | stack[1152921509942985360] = ???;  stack[1152921509942985368] = ???;  //  dest_result_addr=1152921509942985360 |  dest_result_addr=1152921509942985368
        // 0x026714F0: ADD x29, sp, #0x10         | X29 = (1152921509942985344 + 16) = 1152921509942985360 (0x100000013E0F0290);
        // 0x026714F4: MOV x19, x0                | X19 = 1152921509942997376 (0x100000013E0F3180);//ML01
        // 0x026714F8: LDR x8, [x19]              | X8 = typeof(AmbientObscurance);         
        // 0x026714FC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x02671500: LDP x9, x2, [x8, #0x1b0]   | X9 = typeof(AmbientObscurance).__il2cppRuntimeField_1B0; X2 = typeof(AmbientObscurance).__il2cppRuntimeField_1B8; //  | 
        // 0x02671504: BLR x9                     | X0 = typeof(AmbientObscurance).__il2cppRuntimeField_1B0();
        // 0x02671508: LDR x8, [x19]              | X8 = typeof(AmbientObscurance);         
        // 0x0267150C: LDP x1, x2, [x19, #0x38]   | X1 = this.aoShader; //P2  X2 = this.aoMaterial; //P2  //  | 
        // 0x02671510: MOV x0, x19                | X0 = 1152921509942997376 (0x100000013E0F3180);//ML01
        // 0x02671514: LDP x9, x3, [x8, #0x150]   | X9 = typeof(AmbientObscurance).__il2cppRuntimeField_150; X3 = typeof(AmbientObscurance).__il2cppRuntimeField_158; //  | 
        // 0x02671518: BLR x9                     | X0 = typeof(AmbientObscurance).__il2cppRuntimeField_150();
        // 0x0267151C: LDRB w8, [x19, #0x1a]      | 
        // 0x02671520: STR x0, [x19, #0x40]       | this.aoMaterial = this;                  //  dest_result_addr=1152921509942997440
        this.aoMaterial = this;
        // 0x02671524: CBNZ w8, #0x267153c        | if (typeof(AmbientObscurance) != null) goto label_0;
        if(null != null)
        {
            goto label_0;
        }
        // 0x02671528: LDR x8, [x19]              | X8 = typeof(AmbientObscurance);         
        // 0x0267152C: MOV x0, x19                | X0 = 1152921509942997376 (0x100000013E0F3180);//ML01
        // 0x02671530: LDP x9, x1, [x8, #0x1e0]   | X9 = typeof(AmbientObscurance).__il2cppRuntimeField_1E0; X1 = typeof(AmbientObscurance).__il2cppRuntimeField_1E8; //  | 
        // 0x02671534: BLR x9                     | X0 = typeof(AmbientObscurance).__il2cppRuntimeField_1E0();
        // 0x02671538: LDRB w8, [x19, #0x1a]      | 
        label_0:
        // 0x0267153C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02671540: CMP w8, #0                 | STATE = COMPARE(typeof(AmbientObscurance), 0x0)
        // 0x02671544: CSET w0, ne                | W0 = typeof(AmbientObscurance) != null ? 1 : 0;
        var val_1 = (null != 0) ? 1 : 0;
        // 0x02671548: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0267154C: RET                        |  return (System.Boolean)typeof(AmbientObscurance) != null ? 1 : 0;
        return (bool)val_1;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x02671550 (40310096), len: 176  VirtAddr: 0x02671550 RVA: 0x02671550 token: 100663299 methodIndex: 24383 delegateWrapperIndex: 0 methodInvoker: 0
    public override void OnDisable()
    {
        //
        // Disasemble & Code
        // 0x02671550: STP x22, x21, [sp, #-0x30]! | stack[1152921509943113712] = ???;  stack[1152921509943113720] = ???;  //  dest_result_addr=1152921509943113712 |  dest_result_addr=1152921509943113720
        // 0x02671554: STP x20, x19, [sp, #0x10]  | stack[1152921509943113728] = ???;  stack[1152921509943113736] = ???;  //  dest_result_addr=1152921509943113728 |  dest_result_addr=1152921509943113736
        // 0x02671558: STP x29, x30, [sp, #0x20]  | stack[1152921509943113744] = ???;  stack[1152921509943113752] = ???;  //  dest_result_addr=1152921509943113744 |  dest_result_addr=1152921509943113752
        // 0x0267155C: ADD x29, sp, #0x20         | X29 = (1152921509943113712 + 32) = 1152921509943113744 (0x100000013E10F810);
        // 0x02671560: ADRP x20, #0x3740000       | X20 = 57933824 (0x3740000);             
        // 0x02671564: LDRB w8, [x20, #0xe43]     | W8 = (bool)static_value_03740E43;       
        // 0x02671568: MOV x19, x0                | X19 = 1152921509943125760 (0x100000013E112700);//ML01
        // 0x0267156C: TBNZ w8, #0, #0x2671588    | if (static_value_03740E43 == true) goto label_0;
        // 0x02671570: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
        // 0x02671574: LDR x8, [x8, #0xa60]       | X8 = 0x2B8AC3C;                         
        // 0x02671578: LDR w0, [x8]               | W0 = 0x1CD;                             
        // 0x0267157C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1CD, ????);      
        // 0x02671580: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02671584: STRB w8, [x20, #0xe43]     | static_value_03740E43 = true;            //  dest_result_addr=57937475
        label_0:
        // 0x02671588: ADRP x21, #0x35fe000       | X21 = 56614912 (0x35FE000);             
        // 0x0267158C: LDR x21, [x21, #0x810]     | X21 = 1152921504697475072;              
        // 0x02671590: LDR x20, [x19, #0x40]      | X20 = this.aoMaterial; //P2             
        // 0x02671594: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02671598: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x0267159C: TBZ w8, #0, #0x26715ac     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x026715A0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x026715A4: CBNZ w8, #0x26715ac        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x026715A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x026715AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026715B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026715B4: MOV x1, x20                | X1 = this.aoMaterial;//m1               
        // 0x026715B8: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_1 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x026715BC: TBZ w0, #0, #0x26715ec     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x026715C0: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x026715C4: LDR x20, [x19, #0x40]      | X20 = this.aoMaterial; //P2             
        // 0x026715C8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x026715CC: TBZ w8, #0, #0x26715dc     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x026715D0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x026715D4: CBNZ w8, #0x26715dc        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x026715D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_5:
        // 0x026715DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026715E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026715E4: MOV x1, x20                | X1 = this.aoMaterial;//m1               
        // 0x026715E8: BL #0x1b78bac              | UnityEngine.Object.DestroyImmediate(obj:  0);
        UnityEngine.Object.DestroyImmediate(obj:  0);
        label_3:
        // 0x026715EC: STR xzr, [x19, #0x40]      | this.aoMaterial = null;                  //  dest_result_addr=1152921509943125824
        this.aoMaterial = 0;
        // 0x026715F0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x026715F4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x026715F8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x026715FC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02671600 (40310272), len: 1764  VirtAddr: 0x02671600 RVA: 0x02671600 token: 100663300 methodIndex: 24384 delegateWrapperIndex: 0 methodInvoker: 0
    [UnityEngine.ImageEffectOpaque] // 0x281A430
    public override void OnRenderImage(UnityEngine.RenderTexture source, UnityEngine.RenderTexture destination)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        //  | 
        var val_4;
        //  | 
        var val_5;
        //  | 
        var val_6;
        //  | 
        float val_7;
        //  | 
        float val_8;
        //  | 
        float val_9;
        //  | 
        float val_10;
        //  | 
        var val_30;
        //  | 
        var val_31;
        //  | 
        UnityEngine.Material val_32;
        //  | 
        float val_33;
        //  | 
        float val_34;
        //  | 
        float val_35;
        //  | 
        UnityEngine.Material val_36;
        //  | 
        UnityEngine.Material val_37;
        //  | 
        var val_38;
        //  | 
        UnityEngine.RenderTexture val_39;
        // 0x02671600: STP d13, d12, [sp, #-0x90]! | stack[1152921509943332896] = ???;  stack[1152921509943332904] = ???;  //  dest_result_addr=1152921509943332896 |  dest_result_addr=1152921509943332904
        // 0x02671604: STP d11, d10, [sp, #0x10]  | stack[1152921509943332912] = ???;  stack[1152921509943332920] = ???;  //  dest_result_addr=1152921509943332912 |  dest_result_addr=1152921509943332920
        // 0x02671608: STP d9, d8, [sp, #0x20]    | stack[1152921509943332928] = ???;  stack[1152921509943332936] = ???;  //  dest_result_addr=1152921509943332928 |  dest_result_addr=1152921509943332936
        // 0x0267160C: STP x28, x27, [sp, #0x30]  | stack[1152921509943332944] = ???;  stack[1152921509943332952] = ???;  //  dest_result_addr=1152921509943332944 |  dest_result_addr=1152921509943332952
        // 0x02671610: STP x26, x25, [sp, #0x40]  | stack[1152921509943332960] = ???;  stack[1152921509943332968] = ???;  //  dest_result_addr=1152921509943332960 |  dest_result_addr=1152921509943332968
        // 0x02671614: STP x24, x23, [sp, #0x50]  | stack[1152921509943332976] = ???;  stack[1152921509943332984] = ???;  //  dest_result_addr=1152921509943332976 |  dest_result_addr=1152921509943332984
        // 0x02671618: STP x22, x21, [sp, #0x60]  | stack[1152921509943332992] = ???;  stack[1152921509943333000] = ???;  //  dest_result_addr=1152921509943332992 |  dest_result_addr=1152921509943333000
        // 0x0267161C: STP x20, x19, [sp, #0x70]  | stack[1152921509943333008] = ???;  stack[1152921509943333016] = ???;  //  dest_result_addr=1152921509943333008 |  dest_result_addr=1152921509943333016
        // 0x02671620: STP x29, x30, [sp, #0x80]  | stack[1152921509943333024] = ???;  stack[1152921509943333032] = ???;  //  dest_result_addr=1152921509943333024 |  dest_result_addr=1152921509943333032
        // 0x02671624: ADD x29, sp, #0x80         | X29 = (1152921509943332896 + 128) = 1152921509943333024 (0x100000013E1450A0);
        // 0x02671628: SUB sp, sp, #0x1b0         | SP = (1152921509943332896 - 432) = 1152921509943332464 (0x100000013E144E70);
        // 0x0267162C: ADRP x19, #0x3740000       | X19 = 57933824 (0x3740000);             
        // 0x02671630: LDRB w8, [x19, #0xe44]     | W8 = (bool)static_value_03740E44;       
        // 0x02671634: MOV x20, x2                | X20 = destination;//m1                  
        // 0x02671638: MOV x28, x1                | X28 = source;//m1                       
        // 0x0267163C: MOV x21, x0                | X21 = 1152921509943345040 (0x100000013E147F90);//ML01
        val_32 = this;
        // 0x02671640: TBNZ w8, #0, #0x267165c    | if (static_value_03740E44 == true) goto label_0;
        // 0x02671644: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
        // 0x02671648: LDR x8, [x8, #0x588]       | X8 = 0x2B8AC40;                         
        // 0x0267164C: LDR w0, [x8]               | W0 = 0x1CE;                             
        // 0x02671650: BL #0x2782188              | X0 = sub_2782188( ?? 0x1CE, ????);      
        // 0x02671654: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02671658: STRB w8, [x19, #0xe44]     | static_value_03740E44 = true;            //  dest_result_addr=57937476
        label_0:
        // 0x0267165C: STP xzr, xzr, [x29, #-0x90] | stack[1152921509943332880] = 0x0;  stack[1152921509943332888] = 0x0;  //  dest_result_addr=1152921509943332880 |  dest_result_addr=1152921509943332888
        // 0x02671660: STP xzr, xzr, [x29, #-0xa0] | stack[1152921509943332864] = 0x0;  stack[1152921509943332872] = 0x0;  //  dest_result_addr=1152921509943332864 |  dest_result_addr=1152921509943332872
        // 0x02671664: STP xzr, xzr, [x29, #-0xb0] | stack[1152921509943332848] = 0x0;  stack[1152921509943332856] = 0x0;  //  dest_result_addr=1152921509943332848 |  dest_result_addr=1152921509943332856
        // 0x02671668: STP xzr, xzr, [x29, #-0xc0] | stack[1152921509943332832] = 0x0;  stack[1152921509943332840] = 0x0;  //  dest_result_addr=1152921509943332832 |  dest_result_addr=1152921509943332840
        // 0x0267166C: STP xzr, xzr, [x29, #-0xd0] | stack[1152921509943332816] = 0x0;  stack[1152921509943332824] = 0x0;  //  dest_result_addr=1152921509943332816 |  dest_result_addr=1152921509943332824
        // 0x02671670: STP xzr, xzr, [x29, #-0xe0] | stack[1152921509943332800] = 0x0;  stack[1152921509943332808] = 0x0;  //  dest_result_addr=1152921509943332800 |  dest_result_addr=1152921509943332808
        // 0x02671674: STP xzr, xzr, [x29, #-0xf0] | stack[1152921509943332784] = 0x0;  stack[1152921509943332792] = 0x0;  //  dest_result_addr=1152921509943332784 |  dest_result_addr=1152921509943332792
        // 0x02671678: STP xzr, xzr, [x29, #-0x100] | stack[1152921509943332768] = 0x0;  stack[1152921509943332776] = 0x0;  //  dest_result_addr=1152921509943332768 |  dest_result_addr=1152921509943332776
        // 0x0267167C: LDR x8, [x21]              | X8 = typeof(AmbientObscurance);         
        // 0x02671680: MOV x0, x21                | X0 = 1152921509943345040 (0x100000013E147F90);//ML01
        // 0x02671684: LDP x9, x1, [x8, #0x190]   | X9 = typeof(AmbientObscurance).__il2cppRuntimeField_190; X1 = typeof(AmbientObscurance).__il2cppRuntimeField_198; //  | 
        // 0x02671688: BLR x9                     | X0 = typeof(AmbientObscurance).__il2cppRuntimeField_190();
        // 0x0267168C: AND w8, w0, #1             | W8 = (this & 1) = 0 (0x00000000);       
        // 0x02671690: TBZ w8, #0, #0x2671a38     | if (((AmbientObscurance)[1152921509943345040] & 0x1) == 0) goto label_1;
        if((0 & 1) == 0)
        {
            goto label_1;
        }
        // 0x02671694: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x02671698: LDR x8, [x8, #0x338]       | X8 = 1152921509941328016;               
        // 0x0267169C: MOV x0, x21                | X0 = 1152921509943345040 (0x100000013E147F90);//ML01
        // 0x026716A0: LDR x1, [x8]               | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x026716A4: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_1 = this.GetComponent<UnityEngine.Camera>();
        // 0x026716A8: MOV x22, x0                | X22 = val_1;//m1                        
        // 0x026716AC: CBNZ x22, #0x26716b4       | if (val_1 != null) goto label_2;        
        if(val_1 != null)
        {
            goto label_2;
        }
        // 0x026716B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_2:
        // 0x026716B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026716B8: ADD x8, sp, #0xf0          | X8 = (1152921509943332464 + 240) = 1152921509943332704 (0x100000013E144F60);
        // 0x026716BC: MOV x0, x22                | X0 = val_1;//m1                         
        // 0x026716C0: BL #0x20d0368              | X0 = val_1.get_projectionMatrix();      
        UnityEngine.Matrix4x4 val_2 = val_1.projectionMatrix;
        // 0x026716C4: LDP q1, q0, [sp, #0x110]   | Q1 = val_3; Q0 = val_4;                  //  find_add[1152921509943321040] |  find_add[1152921509943321040]
        // 0x026716C8: LDP q3, q2, [sp, #0xf0]    | Q3 = val_5; Q2 = val_6;                  //  find_add[1152921509943321040] |  find_add[1152921509943321040]
        // 0x026716CC: ADD x8, sp, #0xb0          | X8 = (1152921509943332464 + 176) = 1152921509943332640 (0x100000013E144F20);
        // 0x026716D0: SUB x0, x29, #0xc0         | X0 = (1152921509943333024 - 192) = 1152921509943332832 (0x100000013E144FE0);
        // 0x026716D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026716D8: STP q1, q0, [x29, #-0xa0]  | stack[1152921509943332864] = val_3;  stack[1152921509943332880] = val_4;  //  dest_result_addr=1152921509943332864 |  dest_result_addr=1152921509943332880
        // 0x026716DC: STP q3, q2, [x29, #-0xc0]  | stack[1152921509943332832] = val_5;  stack[1152921509943332848] = val_6;  //  dest_result_addr=1152921509943332832 |  dest_result_addr=1152921509943332848
        // 0x026716E0: BL #0x1b6fc34              | X0 = label_UnityEngine_Matrix4x4_INTERNAL_CALL_Transpose_GL01B6FC34();
        // 0x026716E4: LDP q1, q0, [sp, #0xd0]    | Q1 = val_7; Q0 = val_8;                  //  find_add[1152921509943321040] |  find_add[1152921509943321040]
        // 0x026716E8: LDP q3, q2, [sp, #0xb0]    | Q3 = val_9; Q2 = val_10;                 //  find_add[1152921509943321040] |  find_add[1152921509943321040]
        // 0x026716EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026716F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026716F4: STP q1, q0, [x29, #-0xe0]  | stack[1152921509943332800] = val_7;  stack[1152921509943332816] = val_8;  //  dest_result_addr=1152921509943332800 |  dest_result_addr=1152921509943332816
        // 0x026716F8: STP q3, q2, [x29, #-0x100] | stack[1152921509943332768] = val_9;  stack[1152921509943332784] = val_10;  //  dest_result_addr=1152921509943332768 |  dest_result_addr=1152921509943332784
        // 0x026716FC: BL #0x1b8b7e0              | X0 = UnityEngine.Screen.get_width();    
        int val_11 = UnityEngine.Screen.width;
        // 0x02671700: MOV w22, w0                | W22 = val_11;//m1                       
        // 0x02671704: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x02671708: SUB x0, x29, #0xc0         | X0 = (1152921509943333024 - 192) = 1152921509943332832 (0x100000013E144FE0);
        // 0x0267170C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02671710: BL #0x1b70e00              | X0 = label_UnityEngine_Matrix4x4_set_Item_GL01B70E00();
        // 0x02671714: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02671718: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267171C: MOV v8.16b, v0.16b         | V8 = val_8;//m1                         
        // 0x02671720: BL #0x1b8b83c              | X0 = UnityEngine.Screen.get_height();   
        int val_12 = UnityEngine.Screen.height;
        // 0x02671724: MOV w23, w0                | W23 = val_12;//m1                       
        // 0x02671728: SUB x0, x29, #0xc0         | X0 = (1152921509943333024 - 192) = 1152921509943332832 (0x100000013E144FE0);
        // 0x0267172C: MOVZ w1, #0x5              | W1 = 5 (0x5);//ML01                     
        // 0x02671730: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02671734: BL #0x1b70e00              | X0 = label_UnityEngine_Matrix4x4_set_Item_GL01B70E00();
        // 0x02671738: SUB x0, x29, #0xc0         | X0 = (1152921509943333024 - 192) = 1152921509943332832 (0x100000013E144FE0);
        // 0x0267173C: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x02671740: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02671744: MOV v9.16b, v0.16b         | V9 = val_8;//m1                         
        // 0x02671748: BL #0x1b70e00              | X0 = label_UnityEngine_Matrix4x4_set_Item_GL01B70E00();
        // 0x0267174C: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x02671750: SUB x0, x29, #0xc0         | X0 = (1152921509943333024 - 192) = 1152921509943332832 (0x100000013E144FE0);
        // 0x02671754: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02671758: MOV v10.16b, v0.16b        | V10 = val_8;//m1                        
        // 0x0267175C: BL #0x1b70e00              | X0 = label_UnityEngine_Matrix4x4_set_Item_GL01B70E00();
        // 0x02671760: SUB x0, x29, #0xc0         | X0 = (1152921509943333024 - 192) = 1152921509943332832 (0x100000013E144FE0);
        // 0x02671764: ORR w1, wzr, #6            | W1 = 6(0x6);                            
        // 0x02671768: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0267176C: MOV v11.16b, v0.16b        | V11 = val_8;//m1                        
        // 0x02671770: BL #0x1b70e00              | X0 = label_UnityEngine_Matrix4x4_set_Item_GL01B70E00();
        // 0x02671774: SUB x0, x29, #0xc0         | X0 = (1152921509943333024 - 192) = 1152921509943332832 (0x100000013E144FE0);
        // 0x02671778: MOVZ w1, #0x5              | W1 = 5 (0x5);//ML01                     
        // 0x0267177C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02671780: MOV v12.16b, v0.16b        | V12 = val_8;//m1                        
        val_33 = val_8;
        // 0x02671784: BL #0x1b70e00              | X0 = label_UnityEngine_Matrix4x4_set_Item_GL01B70E00();
        // 0x02671788: SCVTF s1, w22              | S1 = (float)(val_11);                   
        float val_30 = (float)val_11;
        // 0x0267178C: FMOV s2, #-2.00000000      | S2 = -2;                                
        // 0x02671790: SCVTF s3, w23              | S3 = (float)(val_12);                   
        float val_31 = (float)val_12;
        // 0x02671794: FMOV s4, #1.00000000       | S4 = 1;                                 
        // 0x02671798: FMUL s1, s1, s8            | S1 = (val_11 * val_8);                  
        val_30 = val_30 * val_8;
        // 0x0267179C: FMUL s3, s3, s9            | S3 = (val_12 * val_8);                  
        val_31 = val_31 * val_8;
        // 0x026717A0: FSUB s5, s4, s10           | S5 = (1f - val_8);                      
        float val_13 = 1f - val_8;
        // 0x026717A4: FADD s6, s12, s4           | S6 = (val_8 + 1f);                      
        float val_14 = val_33 + 1f;
        // 0x026717A8: FDIV s4, s2, s1            | S4 = (-2f / (val_11 * val_8));          
        float val_15 = (-2f) / val_30;
        // 0x026717AC: FDIV s1, s2, s3            | S1 = (-2f / (val_12 * val_8));          
        float val_16 = (-2f) / val_31;
        // 0x026717B0: FDIV s2, s5, s11           | S2 = ((1f - val_8) / val_8);            
        float val_17 = val_13 / val_8;
        // 0x026717B4: FDIV s3, s6, s0            | S3 = ((val_8 + 1f) / val_8);            
        float val_18 = val_14 / val_8;
        // 0x026717B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026717BC: ADD x0, sp, #0xa0          | X0 = (1152921509943332464 + 160) = 1152921509943332624 (0x100000013E144F10);
        // 0x026717C0: MOV v0.16b, v4.16b         | V0 = (-2f / (val_11 * val_8));//m1      
        // 0x026717C4: STP xzr, xzr, [sp, #0xa0]  | stack[1152921509943332624] = 0x0;  stack[1152921509943332632] = 0x0;  //  dest_result_addr=1152921509943332624 |  dest_result_addr=1152921509943332632
        // 0x026717C8: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x026717CC: LDP s8, s9, [sp, #0xa0]    | S8 = 0; S9 = 0;                          //  | 
        // 0x026717D0: LDP s10, s11, [sp, #0xa8]  | S10 = 0; S11 = 0;                        //  | 
        val_34 = 0f;
        // 0x026717D4: LDR x22, [x21, #0x40]      | X22 = this.aoMaterial; //P2             
        // 0x026717D8: CBNZ x22, #0x26717e0       | if (this.aoMaterial != null) goto label_3;
        if(this.aoMaterial != null)
        {
            goto label_3;
        }
        // 0x026717DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E144F10, ????);
        label_3:
        // 0x026717E0: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
        // 0x026717E4: LDR x8, [x8, #0xc0]        | X8 = (string**)(1152921509943242480)("_ProjInfo");
        // 0x026717E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026717EC: MOV x0, x22                | X0 = this.aoMaterial;//m1               
        // 0x026717F0: MOV v0.16b, v8.16b         | V0 = 0 (0x0);//ML01                     
        // 0x026717F4: LDR x1, [x8]               | X1 = "_ProjInfo";                       
        // 0x026717F8: MOV v1.16b, v9.16b         | V1 = 0 (0x0);//ML01                     
        // 0x026717FC: MOV v2.16b, v10.16b        | V2 = 0 (0x0);//ML01                     
        // 0x02671800: MOV v3.16b, v11.16b        | V3 = 0 (0x0);//ML01                     
        // 0x02671804: BL #0x1a79fa8              | this.aoMaterial.SetVector(name:  "_ProjInfo", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = val_34, w = 0f});
        this.aoMaterial.SetVector(name:  "_ProjInfo", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = val_34, w = 0f});
        // 0x02671808: LDR x22, [x21, #0x40]      | X22 = this.aoMaterial; //P2             
        // 0x0267180C: LDP q1, q0, [x29, #-0xe0]  | Q1 = val_7; Q0 = val_8;                  //  | 
        // 0x02671810: LDP q3, q2, [x29, #-0x100] | Q3 = val_9; Q2 = val_10;                 //  | 
        // 0x02671814: STP q1, q0, [sp, #0x80]    | stack[1152921509943332592] = val_7;  stack[1152921509943332608] = val_8;  //  dest_result_addr=1152921509943332592 |  dest_result_addr=1152921509943332608
        // 0x02671818: STP q3, q2, [sp, #0x60]    | stack[1152921509943332560] = val_9;  stack[1152921509943332576] = val_10;  //  dest_result_addr=1152921509943332560 |  dest_result_addr=1152921509943332576
        // 0x0267181C: CBNZ x22, #0x2671824       | if (this.aoMaterial != null) goto label_4;
        if(this.aoMaterial != null)
        {
            goto label_4;
        }
        // 0x02671820: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.aoMaterial, ????);
        label_4:
        // 0x02671824: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
        // 0x02671828: LDR x8, [x8, #0xe0]        | X8 = (string**)(1152921509943246672)("_ProjectionInv");
        // 0x0267182C: LDP q1, q0, [sp, #0x80]    | Q1 = val_7; Q0 = val_8;                  //  | 
        // 0x02671830: LDP q3, q2, [sp, #0x60]    | Q3 = val_9; Q2 = val_10;                 //  | 
        // 0x02671834: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02671838: LDR x1, [x8]               | X1 = "_ProjectionInv";                  
        // 0x0267183C: ADD x2, sp, #0x20          | X2 = (1152921509943332464 + 32) = 1152921509943332496 (0x100000013E144E90);
        // 0x02671840: MOV x0, x22                | X0 = this.aoMaterial;//m1               
        // 0x02671844: STP q1, q0, [sp, #0x40]    | stack[1152921509943332528] = val_7;  stack[1152921509943332544] = val_8;  //  dest_result_addr=1152921509943332528 |  dest_result_addr=1152921509943332544
        // 0x02671848: STP q3, q2, [sp, #0x20]    | stack[1152921509943332496] = val_9;  stack[1152921509943332512] = val_10;  //  dest_result_addr=1152921509943332496 |  dest_result_addr=1152921509943332512
        // 0x0267184C: BL #0x1a7a040              | this.aoMaterial.SetMatrix(name:  "_ProjectionInv", value:  new UnityEngine.Matrix4x4() {m00 = val_9, m10 = val_9, m20 = val_9, m30 = val_9, m01 = val_10, m11 = val_10, m21 = val_10, m31 = val_10, m02 = val_7, m12 = val_7, m22 = val_7, m32 = val_7, m03 = val_8, m13 = val_8, m23 = val_8, m33 = val_8});
        this.aoMaterial.SetMatrix(name:  "_ProjectionInv", value:  new UnityEngine.Matrix4x4() {m00 = val_9, m10 = val_9, m20 = val_9, m30 = val_9, m01 = val_10, m11 = val_10, m21 = val_10, m31 = val_10, m02 = val_7, m12 = val_7, m22 = val_7, m32 = val_7, m03 = val_8, m13 = val_8, m23 = val_8, m33 = val_8});
        // 0x02671850: LDR x22, [x21, #0x40]      | X22 = this.aoMaterial; //P2             
        // 0x02671854: LDR x23, [x21, #0x30]      | X23 = this.rand; //P2                   
        // 0x02671858: CBNZ x22, #0x2671860       | if (this.aoMaterial != null) goto label_5;
        if(this.aoMaterial != null)
        {
            goto label_5;
        }
        // 0x0267185C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.aoMaterial, ????);
        label_5:
        // 0x02671860: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
        // 0x02671864: LDR x8, [x8, #0x348]       | X8 = (string**)(1152921509943254960)("_Rand");
        // 0x02671868: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0267186C: MOV x0, x22                | X0 = this.aoMaterial;//m1               
        // 0x02671870: MOV x2, x23                | X2 = this.rand;//m1                     
        // 0x02671874: LDR x1, [x8]               | X1 = "_Rand";                           
        // 0x02671878: BL #0x1a780c4              | this.aoMaterial.SetTexture(name:  "_Rand", value:  this.rand);
        this.aoMaterial.SetTexture(name:  "_Rand", value:  this.rand);
        // 0x0267187C: LDR x22, [x21, #0x40]      | X22 = this.aoMaterial; //P2             
        // 0x02671880: LDR s8, [x21, #0x20]       | S8 = this.radius; //P2                  
        // 0x02671884: CBNZ x22, #0x267188c       | if (this.aoMaterial != null) goto label_6;
        if(this.aoMaterial != null)
        {
            goto label_6;
        }
        // 0x02671888: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.aoMaterial, ????);
        label_6:
        // 0x0267188C: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
        // 0x02671890: LDR x8, [x8, #0xa38]       | X8 = (string**)(1152921509943259136)("_Radius");
        // 0x02671894: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02671898: MOV x0, x22                | X0 = this.aoMaterial;//m1               
        // 0x0267189C: MOV v0.16b, v8.16b         | V0 = this.radius;//m1                   
        // 0x026718A0: LDR x1, [x8]               | X1 = "_Radius";                         
        // 0x026718A4: BL #0x1a79ef8              | this.aoMaterial.SetFloat(name:  "_Radius", value:  this.radius);
        this.aoMaterial.SetFloat(name:  "_Radius", value:  this.radius);
        // 0x026718A8: LDR x22, [x21, #0x40]      | X22 = this.aoMaterial; //P2             
        // 0x026718AC: LDR s8, [x21, #0x20]       | S8 = this.radius; //P2                  
        // 0x026718B0: CBNZ x22, #0x26718b8       | if (this.aoMaterial != null) goto label_7;
        if(this.aoMaterial != null)
        {
            goto label_7;
        }
        // 0x026718B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.aoMaterial, ????);
        label_7:
        // 0x026718B8: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
        // 0x026718BC: LDR x8, [x8, #0x8c8]       | X8 = (string**)(1152921509943263328)("_Radius2");
        // 0x026718C0: FMUL s0, s8, s8            | S0 = (this.radius * this.radius);       
        float val_19 = this.radius * this.radius;
        // 0x026718C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026718C8: MOV x0, x22                | X0 = this.aoMaterial;//m1               
        // 0x026718CC: LDR x1, [x8]               | X1 = "_Radius2";                        
        // 0x026718D0: BL #0x1a79ef8              | this.aoMaterial.SetFloat(name:  "_Radius2", value:  float val_19 = this.radius * this.radius);
        this.aoMaterial.SetFloat(name:  "_Radius2", value:  val_19);
        // 0x026718D4: LDR x22, [x21, #0x40]      | X22 = this.aoMaterial; //P2             
        // 0x026718D8: LDR s8, [x21, #0x1c]       | S8 = this.intensity; //P2               
        // 0x026718DC: CBNZ x22, #0x26718e4       | if (this.aoMaterial != null) goto label_8;
        if(this.aoMaterial != null)
        {
            goto label_8;
        }
        // 0x026718E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.aoMaterial, ????);
        label_8:
        // 0x026718E4: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
        // 0x026718E8: LDR x8, [x8, #0x720]       | X8 = (string**)(1152921509940329520)("_Intensity");
        // 0x026718EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026718F0: MOV x0, x22                | X0 = this.aoMaterial;//m1               
        // 0x026718F4: MOV v0.16b, v8.16b         | V0 = this.intensity;//m1                
        // 0x026718F8: LDR x1, [x8]               | X1 = "_Intensity";                      
        // 0x026718FC: BL #0x1a79ef8              | this.aoMaterial.SetFloat(name:  "_Intensity", value:  this.intensity);
        this.aoMaterial.SetFloat(name:  "_Intensity", value:  this.intensity);
        // 0x02671900: LDR x22, [x21, #0x40]      | X22 = this.aoMaterial; //P2             
        // 0x02671904: LDR s8, [x21, #0x28]       | S8 = this.blurFilterDistance; //P2      
        val_35 = this.blurFilterDistance;
        // 0x02671908: CBNZ x22, #0x2671910       | if (this.aoMaterial != null) goto label_9;
        if(this.aoMaterial != null)
        {
            goto label_9;
        }
        // 0x0267190C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.aoMaterial, ????);
        label_9:
        // 0x02671910: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x02671914: LDR x8, [x8, #0xc30]       | X8 = (string**)(1152921509943271616)("_BlurFilterDistance");
        // 0x02671918: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0267191C: MOV x0, x22                | X0 = this.aoMaterial;//m1               
        // 0x02671920: MOV v0.16b, v8.16b         | V0 = this.blurFilterDistance;//m1       
        // 0x02671924: LDR x1, [x8]               | X1 = "_BlurFilterDistance";             
        // 0x02671928: BL #0x1a79ef8              | this.aoMaterial.SetFloat(name:  "_BlurFilterDistance", value:  val_35);
        this.aoMaterial.SetFloat(name:  "_BlurFilterDistance", value:  val_35);
        // 0x0267192C: CBNZ x28, #0x2671934       | if (source != null) goto label_10;      
        if(source != null)
        {
            goto label_10;
        }
        // 0x02671930: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.aoMaterial, ????);
        label_10:
        // 0x02671934: LDR x8, [x28]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02671938: MOV x0, x28                | X0 = source;//m1                        
        // 0x0267193C: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x02671940: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x02671944: MOV w22, w0                | W22 = source;//m1                       
        // 0x02671948: CBNZ x28, #0x2671950       | if (source != null) goto label_11;      
        if(source != null)
        {
            goto label_11;
        }
        // 0x0267194C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_11:
        // 0x02671950: LDR x8, [x28]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02671954: MOV x0, x28                | X0 = source;//m1                        
        // 0x02671958: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x0267195C: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x02671960: LDR w8, [x21, #0x2c]       | W8 = this.downsample; //P2              
        // 0x02671964: MOV w23, w0                | W23 = source;//m1                       
        // 0x02671968: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267196C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02671970: ASR w1, w22, w8            | W1 = (source >> this.downsample);       
        UnityEngine.RenderTexture val_20 = source >> this.downsample;
        // 0x02671974: ASR w2, w23, w8            | W2 = (source >> this.downsample);       
        UnityEngine.RenderTexture val_21 = source >> this.downsample;
        // 0x02671978: BL #0x1b89198              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  UnityEngine.RenderTexture val_20 = source >> this.downsample);
        UnityEngine.RenderTexture val_22 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_20);
        // 0x0267197C: ADRP x27, #0x3641000       | X27 = 56889344 (0x3641000);             
        // 0x02671980: LDR x27, [x27, #0x800]     | X27 = 1152921504693481472;              
        // 0x02671984: LDR x24, [x21, #0x40]      | X24 = this.aoMaterial; //P2             
        // 0x02671988: MOV x25, x0                | X25 = val_22;//m1                       
        // 0x0267198C: LDR x8, [x27]              | X8 = typeof(UnityEngine.Graphics);      
        // 0x02671990: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02671994: TBZ w9, #0, #0x26719a8     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x02671998: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x0267199C: CBNZ w9, #0x26719a8        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x026719A0: MOV x0, x8                 | X0 = 1152921504693481472 (0x100000000529F000);//ML01
        // 0x026719A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_13:
        // 0x026719A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026719AC: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
        // 0x026719B0: MOV x1, x28                | X1 = source;//m1                        
        // 0x026719B4: MOV x2, x25                | X2 = val_22;//m1                        
        // 0x026719B8: MOV x3, x24                | X3 = this.aoMaterial;//m1               
        // 0x026719BC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026719C0: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  val_22, pass:  this.aoMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  val_22, pass:  this.aoMaterial);
        // 0x026719C4: LDR w8, [x21, #0x2c]       | W8 = this.downsample; //P2              
        // 0x026719C8: CMP w8, #1                 | STATE = COMPARE(this.downsample, 0x1)   
        // 0x026719CC: B.LT #0x2671a70            | if (this.downsample < 1) goto label_14; 
        if(this.downsample < 1)
        {
            goto label_14;
        }
        // 0x026719D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026719D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x026719D8: MOV w1, w22                | W1 = source;//m1                        
        // 0x026719DC: MOV w2, w23                | W2 = source;//m1                        
        // 0x026719E0: BL #0x1b89198              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  source);
        UnityEngine.RenderTexture val_23 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  source);
        // 0x026719E4: LDR x8, [x27]              | X8 = typeof(UnityEngine.Graphics);      
        // 0x026719E8: LDR x26, [x21, #0x40]      | X26 = this.aoMaterial; //P2             
        // 0x026719EC: MOV x24, x0                | X24 = val_23;//m1                       
        val_36 = val_23;
        // 0x026719F0: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x026719F4: TBZ w9, #0, #0x2671a08     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_16;
        // 0x026719F8: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x026719FC: CBNZ w9, #0x2671a08        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
        // 0x02671A00: MOV x0, x8                 | X0 = 1152921504693481472 (0x100000000529F000);//ML01
        // 0x02671A04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_16:
        // 0x02671A08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02671A0C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02671A10: ORR w4, wzr, #4            | W4 = 4(0x4);                            
        // 0x02671A14: MOV x1, x25                | X1 = val_22;//m1                        
        // 0x02671A18: MOV x2, x24                | X2 = val_23;//m1                        
        // 0x02671A1C: MOV x3, x26                | X3 = this.aoMaterial;//m1               
        // 0x02671A20: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_22, mat:  val_36, pass:  this.aoMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_22, mat:  val_36, pass:  this.aoMaterial);
        // 0x02671A24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02671A28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02671A2C: MOV x1, x25                | X1 = val_22;//m1                        
        // 0x02671A30: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x02671A34: B #0x2671a74               |  goto label_17;                         
        goto label_17;
        label_1:
        // 0x02671A38: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02671A3C: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02671A40: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02671A44: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02671A48: TBZ w8, #0, #0x2671a58     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_19;
        // 0x02671A4C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02671A50: CBNZ w8, #0x2671a58        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
        // 0x02671A54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_19:
        // 0x02671A58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02671A5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02671A60: MOV x1, x28                | X1 = source;//m1                        
        // 0x02671A64: MOV x2, x20                | X2 = destination;//m1                   
        // 0x02671A68: BL #0x1a6ba68              | UnityEngine.Graphics.Blit(source:  0, dest:  source);
        UnityEngine.Graphics.Blit(source:  0, dest:  source);
        // 0x02671A6C: B #0x2671cb8               |  goto label_20;                         
        goto label_20;
        label_14:
        // 0x02671A70: MOV x24, x25               | X24 = val_22;//m1                       
        val_36 = val_22;
        label_17:
        // 0x02671A74: LDR w8, [x21, #0x24]       | W8 = this.blurIterations; //P2          
        // 0x02671A78: LDR x25, [x21, #0x40]      | X25 = this.aoMaterial; //P2             
        val_37 = this.aoMaterial;
        // 0x02671A7C: STR x20, [sp, #0x18]       | stack[1152921509943332488] = destination;  //  dest_result_addr=1152921509943332488
        // 0x02671A80: CMP w8, #1                 | STATE = COMPARE(this.blurIterations, 0x1)
        // 0x02671A84: B.LT #0x2671c44            | if (this.blurIterations < 1) goto label_21;
        if(this.blurIterations < 1)
        {
            goto label_21;
        }
        // 0x02671A88: ADRP x19, #0x3673000       | X19 = 57094144 (0x3673000);             
        // 0x02671A8C: ADRP x20, #0x3642000       | X20 = 56893440 (0x3642000);             
        // 0x02671A90: STR x28, [sp, #0x10]       | stack[1152921509943332480] = source;     //  dest_result_addr=1152921509943332480
        // 0x02671A94: LDR x19, [x19, #0xb10]     | X19 = 1152921504708763648;              
        val_38 = 1152921504708763648;
        // 0x02671A98: LDR x20, [x20, #0x8a0]     | X20 = (string**)(1152921509943292208)("_Axis");
        // 0x02671A9C: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
        var val_32 = 0;
        // 0x02671AA0: FMOV s8, #1.00000000       | S8 = 1;                                 
        val_35 = 1f;
        // 0x02671AA4: FMOV s9, wzr               | S9 = 0f;                                
        label_28:
        // 0x02671AA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02671AAC: ADD x0, sp, #0xf0          | X0 = (1152921509943332464 + 240) = 1152921509943332704 (0x100000013E144F60);
        // 0x02671AB0: MOV v0.16b, v8.16b         | V0 = 1;//m1                             
        // 0x02671AB4: MOV v1.16b, v9.16b         | V1 = 0;//m1                             
        // 0x02671AB8: STR xzr, [sp, #0xf0]       | val_5 = 0x0;                             //  dest_result_addr=1152921509943332704
        val_5 = 0;
        // 0x02671ABC: BL #0x2697148              | null..ctor(_x:  val_35, _y:  0f);       
        Geometric.Point val_24 = new Geometric.Point(_x:  val_35, _y:  0f);
        // 0x02671AC0: LDR x0, [x19]              | X0 = typeof(UnityEngine.Vector4);       
        // 0x02671AC4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector4.__il2cppRuntimeField_10A;
        // 0x02671AC8: TBZ w8, #0, #0x2671ad8     | if (UnityEngine.Vector4.__il2cppRuntimeField_has_cctor == 0) goto label_23;
        // 0x02671ACC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector4.__il2cppRuntimeField_cctor_finished;
        // 0x02671AD0: CBNZ w8, #0x2671ad8        | if (UnityEngine.Vector4.__il2cppRuntimeField_cctor_finished != 0) goto label_23;
        // 0x02671AD4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector4), ????);
        label_23:
        // 0x02671AD8: LDP s0, s1, [sp, #0xf0]    | S0 = val_24.x; S1 = val_24.y;            //  | 
        // 0x02671ADC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02671AE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02671AE4: BL #0x269c4a4              | X0 = UnityEngine.Vector4.op_Implicit(v:  new UnityEngine.Vector2() {x = val_24.x, y = val_24.y});
        UnityEngine.Vector4 val_25 = UnityEngine.Vector4.op_Implicit(v:  new UnityEngine.Vector2() {x = val_24.x, y = val_24.y});
        // 0x02671AE8: MOV v10.16b, v0.16b        | V10 = val_25.x;//m1                     
        // 0x02671AEC: MOV v11.16b, v1.16b        | V11 = val_25.y;//m1                     
        // 0x02671AF0: MOV v12.16b, v2.16b        | V12 = val_25.z;//m1                     
        // 0x02671AF4: MOV v13.16b, v3.16b        | V13 = val_25.w;//m1                     
        // 0x02671AF8: CBNZ x25, #0x2671b00       | if (this.aoMaterial != null) goto label_24;
        if(val_37 != null)
        {
            goto label_24;
        }
        // 0x02671AFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_24:
        // 0x02671B00: LDR x1, [x20]              | X1 = "_Axis";                           
        // 0x02671B04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02671B08: MOV x0, x25                | X0 = this.aoMaterial;//m1               
        // 0x02671B0C: MOV v0.16b, v10.16b        | V0 = val_25.x;//m1                      
        // 0x02671B10: MOV v1.16b, v11.16b        | V1 = val_25.y;//m1                      
        // 0x02671B14: MOV v2.16b, v12.16b        | V2 = val_25.z;//m1                      
        // 0x02671B18: MOV v3.16b, v13.16b        | V3 = val_25.w;//m1                      
        // 0x02671B1C: BL #0x1a79fa8              | this.aoMaterial.SetVector(name:  "_Axis", value:  new UnityEngine.Vector4() {x = val_25.x, y = val_25.y, z = val_25.z, w = val_25.w});
        val_37.SetVector(name:  "_Axis", value:  new UnityEngine.Vector4() {x = val_25.x, y = val_25.y, z = val_25.z, w = val_25.w});
        // 0x02671B20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02671B24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02671B28: MOV w1, w22                | W1 = source;//m1                        
        // 0x02671B2C: MOV w2, w23                | W2 = source;//m1                        
        // 0x02671B30: BL #0x1b89198              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  source);
        UnityEngine.RenderTexture val_26 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  source);
        // 0x02671B34: LDR x8, [x27]              | X8 = typeof(UnityEngine.Graphics);      
        // 0x02671B38: LDR x26, [x21, #0x40]      | X26 = this.aoMaterial; //P2             
        // 0x02671B3C: MOV x25, x0                | X25 = val_26;//m1                       
        // 0x02671B40: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02671B44: TBZ w9, #0, #0x2671b58     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_26;
        // 0x02671B48: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02671B4C: CBNZ w9, #0x2671b58        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_26;
        // 0x02671B50: MOV x0, x8                 | X0 = 1152921504693481472 (0x100000000529F000);//ML01
        // 0x02671B54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_26:
        // 0x02671B58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02671B5C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02671B60: ORR w4, wzr, #1            | W4 = 1(0x1);                            
        // 0x02671B64: MOV x1, x24                | X1 = val_22;//m1                        
        // 0x02671B68: MOV x2, x25                | X2 = val_26;//m1                        
        // 0x02671B6C: MOV x3, x26                | X3 = this.aoMaterial;//m1               
        // 0x02671B70: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_36, mat:  val_26, pass:  this.aoMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_36, mat:  val_26, pass:  this.aoMaterial);
        // 0x02671B74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02671B78: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02671B7C: MOV x1, x24                | X1 = val_22;//m1                        
        // 0x02671B80: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x02671B84: LDR x24, [x21, #0x40]      | X24 = this.aoMaterial; //P2             
        // 0x02671B88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02671B8C: ADD x0, sp, #0xb0          | X0 = (1152921509943332464 + 176) = 1152921509943332640 (0x100000013E144F20);
        // 0x02671B90: MOV v0.16b, v9.16b         | V0 = 0;//m1                             
        // 0x02671B94: MOV v1.16b, v8.16b         | V1 = 1;//m1                             
        // 0x02671B98: STR xzr, [sp, #0xb0]       | val_9 = 0x0;                             //  dest_result_addr=1152921509943332640
        val_9 = 0;
        // 0x02671B9C: BL #0x2697148              | null..ctor(_x:  0f, _y:  val_35);       
        Geometric.Point val_27 = new Geometric.Point(_x:  0f, _y:  val_35);
        // 0x02671BA0: LDP s0, s1, [sp, #0xb0]    | S0 = val_27.x; S1 = val_27.y;            //  | 
        // 0x02671BA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02671BA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02671BAC: BL #0x269c4a4              | X0 = UnityEngine.Vector4.op_Implicit(v:  new UnityEngine.Vector2() {x = val_27.x, y = val_27.y});
        UnityEngine.Vector4 val_28 = UnityEngine.Vector4.op_Implicit(v:  new UnityEngine.Vector2() {x = val_27.x, y = val_27.y});
        // 0x02671BB0: MOV v10.16b, v0.16b        | V10 = val_28.x;//m1                     
        val_34 = val_28.x;
        // 0x02671BB4: MOV v11.16b, v1.16b        | V11 = val_28.y;//m1                     
        // 0x02671BB8: MOV v12.16b, v2.16b        | V12 = val_28.z;//m1                     
        val_33 = val_28.z;
        // 0x02671BBC: MOV v13.16b, v3.16b        | V13 = val_28.w;//m1                     
        // 0x02671BC0: CBNZ x24, #0x2671bc8       | if (this.aoMaterial != null) goto label_27;
        if(this.aoMaterial != null)
        {
            goto label_27;
        }
        // 0x02671BC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_27:
        // 0x02671BC8: LDR x1, [x20]              | X1 = "_Axis";                           
        // 0x02671BCC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02671BD0: MOV x0, x24                | X0 = this.aoMaterial;//m1               
        // 0x02671BD4: MOV v0.16b, v10.16b        | V0 = val_28.x;//m1                      
        // 0x02671BD8: MOV v1.16b, v11.16b        | V1 = val_28.y;//m1                      
        // 0x02671BDC: MOV v2.16b, v12.16b        | V2 = val_28.z;//m1                      
        // 0x02671BE0: MOV v3.16b, v13.16b        | V3 = val_28.w;//m1                      
        // 0x02671BE4: BL #0x1a79fa8              | this.aoMaterial.SetVector(name:  "_Axis", value:  new UnityEngine.Vector4() {x = val_34, y = val_28.y, z = val_33, w = val_28.w});
        this.aoMaterial.SetVector(name:  "_Axis", value:  new UnityEngine.Vector4() {x = val_34, y = val_28.y, z = val_33, w = val_28.w});
        // 0x02671BE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02671BEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02671BF0: MOV w1, w22                | W1 = source;//m1                        
        // 0x02671BF4: MOV w2, w23                | W2 = source;//m1                        
        // 0x02671BF8: BL #0x1b89198              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  source);
        UnityEngine.RenderTexture val_29 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  source);
        // 0x02671BFC: LDR x3, [x21, #0x40]       | X3 = this.aoMaterial; //P2              
        // 0x02671C00: MOV x24, x0                | X24 = val_29;//m1                       
        val_36 = val_29;
        // 0x02671C04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02671C08: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02671C0C: ORR w4, wzr, #1            | W4 = 1(0x1);                            
        // 0x02671C10: MOV x1, x25                | X1 = val_26;//m1                        
        // 0x02671C14: MOV x2, x24                | X2 = val_29;//m1                        
        // 0x02671C18: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_26, mat:  val_36, pass:  this.aoMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_26, mat:  val_36, pass:  this.aoMaterial);
        // 0x02671C1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02671C20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02671C24: MOV x1, x25                | X1 = val_26;//m1                        
        // 0x02671C28: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x02671C2C: LDR w8, [x21, #0x24]       | W8 = this.blurIterations; //P2          
        // 0x02671C30: LDR x25, [x21, #0x40]      | X25 = this.aoMaterial; //P2             
        val_37 = this.aoMaterial;
        // 0x02671C34: ADD w28, w28, #1           | W28 = (0 + 1);                          
        val_32 = val_32 + 1;
        // 0x02671C38: CMP w28, w8                | STATE = COMPARE((0 + 1), this.blurIterations)
        // 0x02671C3C: B.LT #0x2671aa8            | if (0 < this.blurIterations) goto label_28;
        if(val_32 < this.blurIterations)
        {
            goto label_28;
        }
        // 0x02671C40: B #0x2671c48               |  goto label_29;                         
        goto label_29;
        label_21:
        // 0x02671C44: STR x28, [sp, #0x10]       | stack[1152921509943332480] = source;     //  dest_result_addr=1152921509943332480
        label_29:
        // 0x02671C48: CBNZ x25, #0x2671c50       | if (this.aoMaterial != null) goto label_30;
        if(val_37 != null)
        {
            goto label_30;
        }
        // 0x02671C4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_30:
        // 0x02671C50: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
        // 0x02671C54: LDR x8, [x8, #0xb40]       | X8 = (string**)(1152921509943316864)("_AOTex");
        // 0x02671C58: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02671C5C: MOV x0, x25                | X0 = this.aoMaterial;//m1               
        // 0x02671C60: MOV x2, x24                | X2 = val_22;//m1                        
        // 0x02671C64: LDR x1, [x8]               | X1 = "_AOTex";                          
        // 0x02671C68: BL #0x1a780c4              | this.aoMaterial.SetTexture(name:  "_AOTex", value:  val_36);
        val_37.SetTexture(name:  "_AOTex", value:  val_36);
        // 0x02671C6C: LDR x0, [x27]              | X0 = typeof(UnityEngine.Graphics);      
        // 0x02671C70: LDR x21, [x21, #0x40]      | X21 = this.aoMaterial; //P2             
        val_32 = this.aoMaterial;
        // 0x02671C74: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02671C78: LDP x20, x19, [sp, #0x10]  | X20 = source; X19 = destination;         //  | 
        val_39 = destination;
        // 0x02671C7C: TBZ w8, #0, #0x2671c8c     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_32;
        // 0x02671C80: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02671C84: CBNZ w8, #0x2671c8c        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_32;
        // 0x02671C88: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_32:
        // 0x02671C8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02671C90: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02671C94: ORR w4, wzr, #2            | W4 = 2(0x2);                            
        // 0x02671C98: MOV x1, x20                | X1 = source;//m1                        
        // 0x02671C9C: MOV x2, x19                | X2 = destination;//m1                   
        // 0x02671CA0: MOV x3, x21                | X3 = this.aoMaterial;//m1               
        // 0x02671CA4: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  val_39, pass:  val_32);
        UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  val_39, pass:  val_32);
        // 0x02671CA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02671CAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02671CB0: MOV x1, x24                | X1 = val_22;//m1                        
        // 0x02671CB4: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        label_20:
        // 0x02671CB8: SUB sp, x29, #0x80         | SP = (1152921509943333024 - 128) = 1152921509943332896 (0x100000013E145020);
        // 0x02671CBC: LDP x29, x30, [sp, #0x80]  | X29 = ; X30 = ;                          //  | 
        // 0x02671CC0: LDP x20, x19, [sp, #0x70]  | X20 = ; X19 = ;                          //  | 
        // 0x02671CC4: LDP x22, x21, [sp, #0x60]  | X22 = ; X21 = ;                          //  | 
        // 0x02671CC8: LDP x24, x23, [sp, #0x50]  | X24 = ; X23 = ;                          //  | 
        // 0x02671CCC: LDP x26, x25, [sp, #0x40]  | X26 = ; X25 = ;                          //  | 
        // 0x02671CD0: LDP x28, x27, [sp, #0x30]  | X28 = ; X27 = ;                          //  | 
        // 0x02671CD4: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x02671CD8: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x02671CDC: LDP d13, d12, [sp], #0x90  | D13 = ; D12 = ;                          //  | 
        // 0x02671CE0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02671CE4 (40312036), len: 4  VirtAddr: 0x02671CE4 RVA: 0x02671CE4 token: 100663301 methodIndex: 24385 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Main()
    {
        //
        // Disasemble & Code
        // 0x02671CE4: RET                        |  return;                                
        return;
    
    }

}
