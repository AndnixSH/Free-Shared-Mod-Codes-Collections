using UnityEngine;

namespace Newtonsoft.Json.ObservableSupport
{
    public class AddingNewEventArgs
    {
        // Fields
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x28602A0
        private object <NewObject>k__BackingField; //  0x00000010
        
        // Properties
        public object NewObject { get; set; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x02936ADC (43215580), len: 8  VirtAddr: 0x02936ADC RVA: 0x02936ADC token: 100685891 methodIndex: 48492 delegateWrapperIndex: 0 methodInvoker: 0
        public AddingNewEventArgs()
        {
            //
            // Disasemble & Code
            // 0x02936ADC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02936AE0: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x02936AE4 (43215588), len: 44  VirtAddr: 0x02936AE4 RVA: 0x02936AE4 token: 100685892 methodIndex: 48493 delegateWrapperIndex: 0 methodInvoker: 0
        public AddingNewEventArgs(object newObject)
        {
            //
            // Disasemble & Code
            // 0x02936AE4: STP x20, x19, [sp, #-0x20]! | stack[1152921513871559424] = ???;  stack[1152921513871559432] = ???;  //  dest_result_addr=1152921513871559424 |  dest_result_addr=1152921513871559432
            // 0x02936AE8: STP x29, x30, [sp, #0x10]  | stack[1152921513871559440] = ???;  stack[1152921513871559448] = ???;  //  dest_result_addr=1152921513871559440 |  dest_result_addr=1152921513871559448
            // 0x02936AEC: ADD x29, sp, #0x10         | X29 = (1152921513871559424 + 16) = 1152921513871559440 (0x1000000228384B10);
            // 0x02936AF0: MOV x19, x1                | X19 = newObject;//m1                    
            // 0x02936AF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02936AF8: MOV x20, x0                | X20 = 1152921513871571456 (0x1000000228387A00);//ML01
            // 0x02936AFC: BL #0x16f59f0              | this..ctor();                           
            // 0x02936B00: STR x19, [x20, #0x10]      | this.<NewObject>k__BackingField = newObject;  //  dest_result_addr=1152921513871571472
            this.<NewObject>k__BackingField = newObject;
            // 0x02936B04: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x02936B08: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x02936B0C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x02936B18 (43215640), len: 8  VirtAddr: 0x02936B18 RVA: 0x02936B18 token: 100685893 methodIndex: 48494 delegateWrapperIndex: 0 methodInvoker: 0
        public object get_NewObject()
        {
            //
            // Disasemble & Code
            // 0x02936B18: LDR x0, [x0, #0x10]        | X0 = this.<NewObject>k__BackingField; //P2 
            // 0x02936B1C: RET                        |  return (System.Object)this.<NewObject>k__BackingField;
            return this.<NewObject>k__BackingField;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x02936B10 (43215632), len: 8  VirtAddr: 0x02936B10 RVA: 0x02936B10 token: 100685894 methodIndex: 48495 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_NewObject(object value)
        {
            //
            // Disasemble & Code
            // 0x02936B10: STR x1, [x0, #0x10]        | this.<NewObject>k__BackingField = value;  //  dest_result_addr=1152921513871811856
            this.<NewObject>k__BackingField = value;
            // 0x02936B14: RET                        |  return;                                
            return;
        
        }
    
    }

}
