using UnityEngine;
[ProtoBuf.ProtoContractAttribute] // 0x286DB98
[Serializable]
public class CameraShotMoveCfg : IExtensible
{
    // Fields
    private int _id; //  0x00000010
    private int _heroOrNpcId; //  0x00000014
    private int _isHero; //  0x00000018
    private float _posX; //  0x0000001C
    private float _posY; //  0x00000020
    private float _posZ; //  0x00000024
    private ProtoBuf.IExtension extensionObject; //  0x00000028
    
    // Properties
    [ProtoBuf.ProtoMemberAttribute] // 0x286DBDC
    [System.ComponentModel.DefaultValueAttribute] // 0x286DBDC
    public int id { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286DC5C
    [System.ComponentModel.DefaultValueAttribute] // 0x286DC5C
    public int heroOrNpcId { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286DCDC
    [System.ComponentModel.DefaultValueAttribute] // 0x286DCDC
    public int isHero { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286DD5C
    [System.ComponentModel.DefaultValueAttribute] // 0x286DD5C
    public float posX { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286DDDC
    [System.ComponentModel.DefaultValueAttribute] // 0x286DDDC
    public float posY { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286DE5C
    [System.ComponentModel.DefaultValueAttribute] // 0x286DE5C
    public float posZ { get; set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00D7EFF0 (14151664), len: 8  VirtAddr: 0x00D7EFF0 RVA: 0x00D7EFF0 token: 100690444 methodIndex: 25852 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraShotMoveCfg()
    {
        //
        // Disasemble & Code
        // 0x00D7EFF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7EFF4: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7EFF8 (14151672), len: 8  VirtAddr: 0x00D7EFF8 RVA: 0x00D7EFF8 token: 100690445 methodIndex: 25853 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_id()
    {
        //
        // Disasemble & Code
        // 0x00D7EFF8: LDR w0, [x0, #0x10]        | W0 = this._id; //P2                     
        // 0x00D7EFFC: RET                        |  return (System.Int32)this._id;         
        return this._id;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F000 (14151680), len: 8  VirtAddr: 0x00D7F000 RVA: 0x00D7F000 token: 100690446 methodIndex: 25854 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_id(int value)
    {
        //
        // Disasemble & Code
        // 0x00D7F000: STR w1, [x0, #0x10]        | this._id = value;                        //  dest_result_addr=1152921514522093744
        this._id = value;
        // 0x00D7F004: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F008 (14151688), len: 8  VirtAddr: 0x00D7F008 RVA: 0x00D7F008 token: 100690447 methodIndex: 25855 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_heroOrNpcId()
    {
        //
        // Disasemble & Code
        // 0x00D7F008: LDR w0, [x0, #0x14]        | W0 = this._heroOrNpcId; //P2            
        // 0x00D7F00C: RET                        |  return (System.Int32)this._heroOrNpcId;
        return this._heroOrNpcId;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F010 (14151696), len: 8  VirtAddr: 0x00D7F010 RVA: 0x00D7F010 token: 100690448 methodIndex: 25856 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_heroOrNpcId(int value)
    {
        //
        // Disasemble & Code
        // 0x00D7F010: STR w1, [x0, #0x14]        | this._heroOrNpcId = value;               //  dest_result_addr=1152921514522317748
        this._heroOrNpcId = value;
        // 0x00D7F014: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F018 (14151704), len: 8  VirtAddr: 0x00D7F018 RVA: 0x00D7F018 token: 100690449 methodIndex: 25857 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_isHero()
    {
        //
        // Disasemble & Code
        // 0x00D7F018: LDR w0, [x0, #0x18]        | W0 = this._isHero; //P2                 
        // 0x00D7F01C: RET                        |  return (System.Int32)this._isHero;     
        return this._isHero;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F020 (14151712), len: 8  VirtAddr: 0x00D7F020 RVA: 0x00D7F020 token: 100690450 methodIndex: 25858 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_isHero(int value)
    {
        //
        // Disasemble & Code
        // 0x00D7F020: STR w1, [x0, #0x18]        | this._isHero = value;                    //  dest_result_addr=1152921514522541752
        this._isHero = value;
        // 0x00D7F024: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F028 (14151720), len: 8  VirtAddr: 0x00D7F028 RVA: 0x00D7F028 token: 100690451 methodIndex: 25859 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_posX()
    {
        //
        // Disasemble & Code
        // 0x00D7F028: LDR s0, [x0, #0x1c]        | S0 = this._posX; //P2                   
        // 0x00D7F02C: RET                        |  return (System.Single)this._posX;      
        return this._posX;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F030 (14151728), len: 8  VirtAddr: 0x00D7F030 RVA: 0x00D7F030 token: 100690452 methodIndex: 25860 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_posX(float value)
    {
        //
        // Disasemble & Code
        // 0x00D7F030: STR s0, [x0, #0x1c]        | this._posX = value;                      //  dest_result_addr=1152921514522765756
        this._posX = value;
        // 0x00D7F034: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F038 (14151736), len: 8  VirtAddr: 0x00D7F038 RVA: 0x00D7F038 token: 100690453 methodIndex: 25861 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_posY()
    {
        //
        // Disasemble & Code
        // 0x00D7F038: LDR s0, [x0, #0x20]        | S0 = this._posY; //P2                   
        // 0x00D7F03C: RET                        |  return (System.Single)this._posY;      
        return this._posY;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F040 (14151744), len: 8  VirtAddr: 0x00D7F040 RVA: 0x00D7F040 token: 100690454 methodIndex: 25862 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_posY(float value)
    {
        //
        // Disasemble & Code
        // 0x00D7F040: STR s0, [x0, #0x20]        | this._posY = value;                      //  dest_result_addr=1152921514522989760
        this._posY = value;
        // 0x00D7F044: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F048 (14151752), len: 8  VirtAddr: 0x00D7F048 RVA: 0x00D7F048 token: 100690455 methodIndex: 25863 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_posZ()
    {
        //
        // Disasemble & Code
        // 0x00D7F048: LDR s0, [x0, #0x24]        | S0 = this._posZ; //P2                   
        // 0x00D7F04C: RET                        |  return (System.Single)this._posZ;      
        return this._posZ;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F050 (14151760), len: 8  VirtAddr: 0x00D7F050 RVA: 0x00D7F050 token: 100690456 methodIndex: 25864 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_posZ(float value)
    {
        //
        // Disasemble & Code
        // 0x00D7F050: STR s0, [x0, #0x24]        | this._posZ = value;                      //  dest_result_addr=1152921514523213764
        this._posZ = value;
        // 0x00D7F054: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F058 (14151768), len: 24  VirtAddr: 0x00D7F058 RVA: 0x00D7F058 token: 100690457 methodIndex: 25865 delegateWrapperIndex: 0 methodInvoker: 0
    private ProtoBuf.IExtension ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
    {
        //
        // Disasemble & Code
        // 0x00D7F058: ADD x8, x0, #0x28          | X8 = this.extensionObject;//AP2 res_addr=1152921514523325768
        // 0x00D7F05C: AND w2, w1, #1             | W2 = (createIfMissing & 1);             
        bool val_1 = createIfMissing;
        // 0x00D7F060: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        ProtoBuf.IExtension val_2 = 0;
        // 0x00D7F064: MOV x1, x8                 | X1 = this.extensionObject;//m1          
        // 0x00D7F068: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7F06C: B #0xc7c9f0                | return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  ProtoBuf.IExtension val_2 = 0, createIfMissing:  this.extensionObject);
        return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  val_2, createIfMissing:  this.extensionObject);
    
    }

}
