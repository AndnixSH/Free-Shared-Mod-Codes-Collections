using UnityEngine;

namespace Newtonsoft.Json.Utilities
{
    internal sealed class Creator<T> : MulticastDelegate
    {
        // Methods
        // Generic instance method:
        //
        // file offset: 0x019EA8E8 VirtAddr: 0x019EA8E8 -RVA: 0x019EA8E8 
        // -Creator<object>..ctor
        //
        //
        // Offset in libil2cpp.so: 0x019EA8E8 (27175144), len: 16  VirtAddr: 0x019EA8E8 RVA: 0x019EA8E8 token: 100686791 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public Creator<T>(object object, IntPtr method)
        {
            //
            // Disasemble & Code
            // 0x019EA8E8: LDR x8, [x2]               | X8 = method;                            
            // 0x019EA8EC: STP x1, x2, [x0, #0x20]    | mem[1152921513999928672] = object;  mem[1152921513999928680] = method;  //  dest_result_addr=1152921513999928672 |  dest_result_addr=1152921513999928680
            mem[1152921513999928672] = object;
            mem[1152921513999928680] = method;
            // 0x019EA8F0: STR x8, [x0, #0x10]        | mem[1152921513999928656] = method;       //  dest_result_addr=1152921513999928656
            mem[1152921513999928656] = method;
            // 0x019EA8F4: RET                        |  return;                                
            return;
        
        }
        // Generic instance method:
        //
        // file offset: 0x019EA8F8 VirtAddr: 0x019EA8F8 -RVA: 0x019EA8F8 
        // -Creator<object>.Invoke
        //
        //
        // Offset in libil2cpp.so: 0x019EA8F8 (27175160), len: 504  VirtAddr: 0x019EA8F8 RVA: 0x019EA8F8 token: 100686792 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual T Invoke()
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            label_1:
            // 0x019EA8F8: STP x22, x21, [sp, #-0x30]! | stack[1152921514000040880] = ???;  stack[1152921514000040888] = ???;  //  dest_result_addr=1152921514000040880 |  dest_result_addr=1152921514000040888
            // 0x019EA8FC: STP x20, x19, [sp, #0x10]  | stack[1152921514000040896] = ???;  stack[1152921514000040904] = ???;  //  dest_result_addr=1152921514000040896 |  dest_result_addr=1152921514000040904
            // 0x019EA900: STP x29, x30, [sp, #0x20]  | stack[1152921514000040912] = ???;  stack[1152921514000040920] = ???;  //  dest_result_addr=1152921514000040912 |  dest_result_addr=1152921514000040920
            // 0x019EA904: ADD x29, sp, #0x20         | X29 = (1152921514000040880 + 32) = 1152921514000040912 (0x100000022FE0C3D0);
            // 0x019EA908: SUB sp, sp, #0x10          | SP = (1152921514000040880 - 16) = 1152921514000040864 (0x100000022FE0C3A0);
            // 0x019EA90C: MOV x21, x0                | X21 = 1152921514000052928 (0x100000022FE0F2C0);//ML01
            // 0x019EA910: LDR x0, [x21, #0x58]       | 
            // 0x019EA914: CBZ x0, #0x19ea91c         | if (this == null) goto label_0;         
            if(this == null)
            {
                goto label_0;
            }
            // 0x019EA918: BL #0x19ea8f8              |  R0 = label_1();                        
            label_0:
            // 0x019EA91C: LDR x0, [x21, #0x10]       | 
            // 0x019EA920: STR x0, [sp, #8]           | stack[1152921514000040872] = this;       //  dest_result_addr=1152921514000040872
            // 0x019EA924: LDP x19, x20, [x21, #0x20] |                                          //  | 
            // 0x019EA928: MOV x0, x20                | X0 = X20;//m1                           
            // 0x019EA92C: BL #0x2796f94              | X0 = sub_2796F94( ?? X20, ????);        
            // 0x019EA930: MOV x0, x20                | X0 = X20;//m1                           
            // 0x019EA934: BL #0x27c09a4              | X0 = sub_27C09A4( ?? X20, ????);        
            // 0x019EA938: AND w8, w0, #1             | W8 = (X20 & 1);                         
            var val_1 = X20 & 1;
            // 0x019EA93C: TBZ w8, #0, #0x19ea9cc     | if (((X20 & 1) & 0x1) == 0) goto label_2;
            if((val_1 & 1) == 0)
            {
                goto label_2;
            }
            // 0x019EA940: LDRSH w8, [x20, #0x4c]     | W8 = X20 + 76;                          
            // 0x019EA944: CMN w8, #1                 | STATE = COMPARE(X20 + 76, 0x1)          
            // 0x019EA948: B.EQ #0x19ea9f8            | if (X20 + 76 == 0x1) goto label_6;      
            if((X20 + 76) == 1)
            {
                goto label_6;
            }
            // 0x019EA94C: CBZ x19, #0x19ea95c        | if (X19 == 0) goto label_4;             
            if(X19 == 0)
            {
                goto label_4;
            }
            // 0x019EA950: LDR x8, [x19]              | X8 = X19;                               
            // 0x019EA954: LDRB w8, [x8, #0xed]       | W8 = X19 + 237;                         
            // 0x019EA958: TBNZ w8, #0, #0x19ea9f8    | if ((X19 + 237 & 0x1) != 0) goto label_6;
            if(((X19 + 237) & 1) != 0)
            {
                goto label_6;
            }
            label_4:
            // 0x019EA95C: LDR x8, [x21, #0x18]       | 
            // 0x019EA960: CBZ x8, #0x19ea9f8         | if (X19 + 237 == 0) goto label_6;       
            if((X19 + 237) == 0)
            {
                goto label_6;
            }
            // 0x019EA964: MOV x0, x20                | X0 = X20;//m1                           
            // 0x019EA968: BL #0x27c0990              | X0 = sub_27C0990( ?? X20, ????);        
            // 0x019EA96C: MOV w21, w0                | W21 = X20;//m1                          
            // 0x019EA970: MOV x0, x20                | X0 = X20;//m1                           
            // 0x019EA974: BL #0x27c0a0c              | X0 = X20.get_pressedSprite();           
            UnityEngine.Sprite val_2 = X20.pressedSprite;
            // 0x019EA978: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_2, ????);      
            // 0x019EA97C: TBZ w21, #0, #0x19eaa20    | if ((X20 & 0x1) == 0) goto label_7;     
            if((X20 & 1) == 0)
            {
                goto label_7;
            }
            // 0x019EA980: TBZ w0, #0, #0x19eaa7c     | if ((val_2 & 0x1) == 0) goto label_8;   
            if((val_2 & 1) == 0)
            {
                goto label_8;
            }
            // 0x019EA984: LDR x8, [x19]              | X8 = X19;                               
            var val_11 = X19;
            // 0x019EA988: LDR x1, [x20, #0x18]       | X1 = X20 + 24;                          
            // 0x019EA98C: LDRH w2, [x20, #0x4c]      | W2 = X20 + 76;                          
            // 0x019EA990: LDRH w9, [x8, #0x102]      | W9 = X19 + 258;                         
            // 0x019EA994: CBZ x9, #0x19ea9c0         | if (X19 + 258 == 0) goto label_9;       
            if((X19 + 258) == 0)
            {
                goto label_9;
            }
            // 0x019EA998: LDR x10, [x8, #0x98]       | X10 = X19 + 152;                        
            var val_5 = X19 + 152;
            // 0x019EA99C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_6 = 0;
            // 0x019EA9A0: ADD x10, x10, #8           | X10 = (X19 + 152 + 8);                  
            val_5 = val_5 + 8;
            label_11:
            // 0x019EA9A4: LDUR x12, [x10, #-8]       | X12 = (X19 + 152 + 8) + -8;             
            // 0x019EA9A8: CMP x12, x1                | STATE = COMPARE((X19 + 152 + 8) + -8, X20 + 24)
            // 0x019EA9AC: B.EQ #0x19eaaa4            | if ((X19 + 152 + 8) + -8 == X20 + 24) goto label_10;
            if(((X19 + 152 + 8) + -8) == (X20 + 24))
            {
                goto label_10;
            }
            // 0x019EA9B0: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_6 = val_6 + 1;
            // 0x019EA9B4: ADD x10, x10, #0x10        | X10 = ((X19 + 152 + 8) + 16);           
            val_5 = val_5 + 16;
            // 0x019EA9B8: CMP x11, x9                | STATE = COMPARE((0 + 1), X19 + 258)     
            // 0x019EA9BC: B.LO #0x19ea9a4            | if (0 < X19 + 258) goto label_11;       
            if(val_6 < (X19 + 258))
            {
                goto label_11;
            }
            label_9:
            // 0x019EA9C0: MOV x0, x19                | X0 = X19;//m1                           
            val_7 = X19;
            // 0x019EA9C4: BL #0x2776c24              | X0 = sub_2776C24( ?? X19, ????);        
            // 0x019EA9C8: B #0x19eaab4               |  goto label_12;                         
            goto label_12;
            label_2:
            // 0x019EA9CC: LDRB w8, [x20, #0x4e]      | W8 = X20 + 78;                          
            // 0x019EA9D0: CBZ w8, #0x19eaa00         | if (X20 + 78 == 0) goto label_13;       
            if((X20 + 78) == 0)
            {
                goto label_13;
            }
            // 0x019EA9D4: LDR x3, [sp, #8]           | X3 = this;                              
            // 0x019EA9D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x019EA9DC: MOV x1, x19                | X1 = X19;//m1                           
            // 0x019EA9E0: MOV x2, x20                | X2 = X20;//m1                           
            // 0x019EA9E4: SUB sp, x29, #0x20         | SP = (1152921514000040912 - 32) = 1152921514000040880 (0x100000022FE0C3B0);
            // 0x019EA9E8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019EA9EC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019EA9F0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019EA9F4: BR x3                      | X0 = this( ?? 0x0, ????);               
            label_6:
            // 0x019EA9F8: MOV x0, x19                | X0 = X19;//m1                           
            // 0x019EA9FC: B #0x19eaa04               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x019EAA00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            label_14:
            // 0x019EAA04: LDR x2, [sp, #8]           | X2 = this;                              
            // 0x019EAA08: MOV x1, x20                | X1 = X20;//m1                           
            label_23:
            // 0x019EAA0C: SUB sp, x29, #0x20         | SP = (1152921514000040912 - 32) = 1152921514000040880 (0x100000022FE0C3B0);
            // 0x019EAA10: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019EAA14: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019EAA18: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019EAA1C: BR x2                      | X0 = this( ?? 0x0, ????);               
            label_7:
            // 0x019EAA20: LDRH w21, [x20, #0x4c]     | W21 = X20 + 76;                         
            // 0x019EAA24: TBZ w0, #0, #0x19eaa90     | if ((val_2 & 0x1) == 0) goto label_15;  
            if((val_2 & 1) == 0)
            {
                goto label_15;
            }
            // 0x019EAA28: MOV x0, x20                | X0 = X20;//m1                           
            // 0x019EAA2C: BL #0x27c0a0c              | X0 = X20.get_pressedSprite();           
            UnityEngine.Sprite val_3 = X20.pressedSprite;
            // 0x019EAA30: LDR x9, [x19]              | X9 = X19;                               
            // 0x019EAA34: MOV x8, x0                 | X8 = val_3;//m1                         
            // 0x019EAA38: LDRH w10, [x9, #0x102]     | W10 = X19 + 258;                        
            // 0x019EAA3C: CBZ x10, #0x19eaa68        | if (X19 + 258 == 0) goto label_16;      
            if((X19 + 258) == 0)
            {
                goto label_16;
            }
            // 0x019EAA40: LDR x11, [x9, #0x98]       | X11 = X19 + 152;                        
            var val_7 = X19 + 152;
            // 0x019EAA44: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
            var val_8 = 0;
            // 0x019EAA48: ADD x11, x11, #8           | X11 = (X19 + 152 + 8);                  
            val_7 = val_7 + 8;
            label_18:
            // 0x019EAA4C: LDUR x13, [x11, #-8]       | X13 = (X19 + 152 + 8) + -8;             
            // 0x019EAA50: CMP x13, x8                | STATE = COMPARE((X19 + 152 + 8) + -8, val_3)
            // 0x019EAA54: B.EQ #0x19eaad4            | if ((X19 + 152 + 8) + -8 == val_3) goto label_17;
            if(((X19 + 152 + 8) + -8) == val_3)
            {
                goto label_17;
            }
            // 0x019EAA58: ADD x12, x12, #1           | X12 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x019EAA5C: ADD x11, x11, #0x10        | X11 = ((X19 + 152 + 8) + 16);           
            val_7 = val_7 + 16;
            // 0x019EAA60: CMP x12, x10               | STATE = COMPARE((0 + 1), X19 + 258)     
            // 0x019EAA64: B.LO #0x19eaa4c            | if (0 < X19 + 258) goto label_18;       
            if(val_8 < (X19 + 258))
            {
                goto label_18;
            }
            label_16:
            // 0x019EAA68: MOV x0, x19                | X0 = X19;//m1                           
            val_8 = X19;
            // 0x019EAA6C: MOV x1, x8                 | X1 = val_3;//m1                         
            // 0x019EAA70: MOV w2, w21                | W2 = X20 + 76;//m1                      
            // 0x019EAA74: BL #0x2776c24              | X0 = sub_2776C24( ?? X19, ????);        
            // 0x019EAA78: B #0x19eaae4               |  goto label_19;                         
            goto label_19;
            label_8:
            // 0x019EAA7C: LDRH w8, [x20, #0x4c]      | W8 = X20 + 76;                          
            // 0x019EAA80: LDR x9, [x19]              | X9 = X19;                               
            // 0x019EAA84: ADD x8, x9, x8, lsl #4     | X8 = (X19 + (X20 + 76) << 4);           
            var val_4 = X19 + ((X20 + 76) << 4);
            // 0x019EAA88: LDR x0, [x8, #0x118]       | X0 = (X19 + (X20 + 76) << 4) + 280;     
            val_9 = mem[(X19 + (X20 + 76) << 4) + 280];
            val_9 = (X19 + (X20 + 76) << 4) + 280;
            // 0x019EAA8C: B #0x19eaab8               |  goto label_20;                         
            goto label_20;
            label_15:
            // 0x019EAA90: LDR x8, [x19]              | X8 = X19;                               
            var val_9 = X19;
            // 0x019EAA94: MOV x0, x19                | X0 = X19;//m1                           
            // 0x019EAA98: ADD x8, x8, w21, uxtw #4   | X8 = (X19 + X20 + 76);                  
            val_9 = val_9 + (X20 + 76);
            // 0x019EAA9C: LDP x2, x1, [x8, #0x110]   | X2 = (X19 + X20 + 76) + 272; X1 = (X19 + X20 + 76) + 272 + 8; //  | 
            // 0x019EAAA0: B #0x19eaa0c               |  goto label_23;                         
            goto label_23;
            label_10:
            // 0x019EAAA4: LDR w9, [x10]              | W9 = (X19 + 152 + 8);                   
            var val_10 = val_5;
            // 0x019EAAA8: ADD w9, w9, w2             | W9 = ((X19 + 152 + 8) + X20 + 76);      
            val_10 = val_10 + (X20 + 76);
            // 0x019EAAAC: ADD x8, x8, w9, uxtw #4    | X8 = (X19 + ((X19 + 152 + 8) + X20 + 76));
            val_11 = val_11 + val_10;
            // 0x019EAAB0: ADD x0, x8, #0x110         | X0 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272);
            val_7 = val_11 + 272;
            label_12:
            // 0x019EAAB4: LDR x0, [x0, #8]           | X0 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8;
            val_9 = mem[((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8];
            val_9 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8;
            label_20:
            // 0x019EAAB8: MOV x1, x20                | X1 = X20;//m1                           
            // 0x019EAABC: BL #0x2796ec8              | X0 = sub_2796EC8( ?? ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8, ????);
            // 0x019EAAC0: MOV x8, x0                 | X8 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8;//m1
            // 0x019EAAC4: LDR x2, [x8]               | X2 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8;
            // 0x019EAAC8: MOV x0, x19                | X0 = X19;//m1                           
            // 0x019EAACC: MOV x1, x8                 | X1 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8;//m1
            // 0x019EAAD0: B #0x19eaa0c               |  goto label_23;                         
            goto label_23;
            label_17:
            // 0x019EAAD4: LDR w8, [x11]              | W8 = (X19 + 152 + 8);                   
            var val_12 = val_7;
            // 0x019EAAD8: ADD w8, w8, w21            | W8 = ((X19 + 152 + 8) + X20 + 76);      
            val_12 = val_12 + (X20 + 76);
            // 0x019EAADC: ADD x8, x9, w8, uxtw #4    | X8 = (X19 + ((X19 + 152 + 8) + X20 + 76));
            val_12 = X19 + val_12;
            // 0x019EAAE0: ADD x0, x8, #0x110         | X0 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272);
            val_8 = val_12 + 272;
            label_19:
            // 0x019EAAE4: LDP x2, x1, [x0]           | X2 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272); X1 = ((X19 + ((X19 + 152 + 8) + X20 + 76)) + 272) + 8; //  | 
            // 0x019EAAE8: MOV x0, x19                | X0 = X19;//m1                           
            // 0x019EAAEC: B #0x19eaa0c               |  goto label_23;                         
            goto label_23;
        
        }
        // Generic instance method:
        //
        // file offset: 0x019EAAF0 VirtAddr: 0x019EAAF0 -RVA: 0x019EAAF0 
        // -Creator<object>.BeginInvoke
        //
        //
        // Offset in libil2cpp.so: 0x019EAAF0 (27175664), len: 52  VirtAddr: 0x019EAAF0 RVA: 0x019EAAF0 token: 100686793 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual System.IAsyncResult BeginInvoke(System.AsyncCallback callback, object object)
        {
            //
            // Disasemble & Code
            // 0x019EAAF0: STP x29, x30, [sp, #-0x10]! | stack[1152921514000169296] = ???;  stack[1152921514000169304] = ???;  //  dest_result_addr=1152921514000169296 |  dest_result_addr=1152921514000169304
            // 0x019EAAF4: MOV x29, sp                | X29 = 1152921514000169296 (0x100000022FE2B950);//ML01
            // 0x019EAAF8: SUB sp, sp, #0x10          | SP = (1152921514000169296 - 16) = 1152921514000169280 (0x100000022FE2B940);
            // 0x019EAAFC: MOV x8, x2                 | X8 = object;//m1                        
            // 0x019EAB00: MOV x9, x1                 | X9 = callback;//m1                      
            // 0x019EAB04: ADD x1, sp, #8             | X1 = (1152921514000169280 + 8) = 1152921514000169288 (0x100000022FE2B948);
            // 0x019EAB08: MOV x2, x9                 | X2 = callback;//m1                      
            // 0x019EAB0C: MOV x3, x8                 | X3 = object;//m1                        
            // 0x019EAB10: STR xzr, [sp, #8]          | stack[1152921514000169288] = 0x0;        //  dest_result_addr=1152921514000169288
            // 0x019EAB14: BL #0x278fb00              | X0 = sub_278FB00( ?? this, ????);       
            // 0x019EAB18: MOV sp, x29                | SP = 1152921514000169296 (0x100000022FE2B950);//ML01
            // 0x019EAB1C: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x019EAB20: RET                        |  return (System.IAsyncResult)this;      
            return (System.IAsyncResult)this;
            //  |  // // {name=val_0, type=System.IAsyncResult, size=8, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x019EAB24 VirtAddr: 0x019EAB24 -RVA: 0x019EAB24 
        // -Creator<object>.EndInvoke
        //
        //
        // Offset in libil2cpp.so: 0x019EAB24 (27175716), len: 124  VirtAddr: 0x019EAB24 RVA: 0x019EAB24 token: 100686794 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual T EndInvoke(System.IAsyncResult result)
        {
            //
            // Disasemble & Code
            // 0x019EAB24: MOV x8, x1                 | X8 = result;//m1                        
            // 0x019EAB28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019EAB2C: MOV x0, x8                 | X0 = result;//m1                        
            // 0x019EAB30: B #0x278fde8               | X0 = sub_278FDE8( ?? result, ????);     
            label_Newtonsoft_Json_Utilities_Creator<System_Object>_EndInvoke_GL019EAB34:
            // 0x019EAB34: STP x22, x21, [sp, #-0x30]! | stack[1152921514000293552] = ???;  stack[1152921514000293560] = ???;  //  dest_result_addr=1152921514000293552 |  dest_result_addr=1152921514000293560
            // 0x019EAB38: STP x20, x19, [sp, #0x10]  | stack[1152921514000293568] = ???;  stack[1152921514000293576] = ???;  //  dest_result_addr=1152921514000293568 |  dest_result_addr=1152921514000293576
            // 0x019EAB3C: STP x29, x30, [sp, #0x20]  | stack[1152921514000293584] = ???;  stack[1152921514000293592] = ???;  //  dest_result_addr=1152921514000293584 |  dest_result_addr=1152921514000293592
            // 0x019EAB40: ADD x29, sp, #0x20         | X29 = (1152921514000293552 + 32) = 1152921514000293584 (0x100000022FE49ED0);
            // 0x019EAB44: ADRP x21, #0x3739000       | X21 = 57905152 (0x3739000);             
            // 0x019EAB48: LDRB w8, [x21, #0x677]     | W8 = (bool)static_value_03739677;       
            // 0x019EAB4C: MOV x19, x1                | X19 = 0 (0x0);//ML01                    
            // 0x019EAB50: MOV x20, x0                | X20 = result;//m1                       
            // 0x019EAB54: TBNZ w8, #0, #0x19eab70    | if (static_value_03739677 == true) goto label_0;
            // 0x019EAB58: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
            // 0x019EAB5C: LDR x8, [x8, #0x4c0]       | X8 = 0x2B96AFC;                         
            // 0x019EAB60: LDR w0, [x8]               | W0 = 0x3187;                            
            // 0x019EAB64: BL #0x2782188              | X0 = sub_2782188( ?? 0x3187, ????);     
            // 0x019EAB68: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019EAB6C: STRB w8, [x21, #0x677]     | static_value_03739677 = true;            //  dest_result_addr=57906807
            label_0:
            // 0x019EAB70: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x019EAB74: LDR x8, [x8, #0x1e8]       | X8 = (string**)(1152921513099622368)("e");
            // 0x019EAB78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x019EAB7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x019EAB80: MOV x1, x19                | X1 = 0 (0x0);//ML01                     
            // 0x019EAB84: LDR x2, [x8]               | X2 = "e";                               
            // 0x019EAB88: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  0, parameterName:  0);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  0, parameterName:  0);
            // 0x019EAB8C: STR x19, [x20]             | mem2[0] = 0x0;                           //  dest_result_addr=0
            mem2[0] = 0;
            // 0x019EAB90: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019EAB94: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019EAB98: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019EAB9C: RET                        |  return (System.Object)null;            
            return 0;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
    
    }

}
