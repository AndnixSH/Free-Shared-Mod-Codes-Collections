using UnityEngine;
public class Bootstrap
{
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B92DFC (12135932), len: 8  VirtAddr: 0x00B92DFC RVA: 0x00B92DFC token: 100690110 methodIndex: 25201 delegateWrapperIndex: 0 methodInvoker: 0
    public Bootstrap()
    {
        //
        // Disasemble & Code
        // 0x00B92DFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B92E00: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B92E04 (12135940), len: 160  VirtAddr: 0x00B92E04 RVA: 0x00B92E04 token: 100690111 methodIndex: 25202 delegateWrapperIndex: 0 methodInvoker: 0
    public static extern string get_arch_abi()
    {
        //
        // Disasemble & Code
        // 0x00B92E04: STP x20, x19, [sp, #-0x20]! | stack[1152921514474071456] = ???;  stack[1152921514474071464] = ???;  //  dest_result_addr=1152921514474071456 |  dest_result_addr=1152921514474071464
        // 0x00B92E08: STP x29, x30, [sp, #0x10]  | stack[1152921514474071472] = ???;  stack[1152921514474071480] = ???;  //  dest_result_addr=1152921514474071472 |  dest_result_addr=1152921514474071480
        // 0x00B92E0C: ADD x29, sp, #0x10         | X29 = (1152921514474071456 + 16) = 1152921514474071472 (0x100000024C21E5B0);
        // 0x00B92E10: SUB sp, sp, #0x30          | SP = (1152921514474071456 - 48) = 1152921514474071408 (0x100000024C21E570);
        // 0x00B92E14: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B92E18: LDR x0, [x19, #0xa50]      | X0 = static_value_03733A50;             
        // 0x00B92E1C: CBNZ x0, #0xb92e60         | if (static_value_03733A50 != 0) goto label_0;
        // 0x00B92E20: ADRP x8, #0x2a93000        | X8 = 44642304 (0x2A93000);              
        // 0x00B92E24: ADRP x10, #0x2a93000       | X10 = 44642304 (0x2A93000);             
        // 0x00B92E28: ADD x8, x8, #0xb0          | X8 = (44642304 + 176) = 44642480 (0x02A930B0);
        // 0x00B92E2C: MOVZ w9, #0x9              | W9 = 9 (0x9);//ML01                     
        // 0x00B92E30: ADD x10, x10, #0xba        | X10 = (44642304 + 186) = 44642490 (0x02A930BA);
        // 0x00B92E34: ORR w11, wzr, #0xc         | W11 = 12(0xC);                          
        // 0x00B92E38: ORR w12, wzr, #1           | W12 = 1(0x1);                           
        // 0x00B92E3C: MOV x0, sp                 | X0 = 1152921514474071408 (0x100000024C21E570);//ML01
        // 0x00B92E40: STP x8, x9, [sp]           | stack[1152921514474071408] = 0x2A930B0;  stack[1152921514474071416] = 0x9;  //  dest_result_addr=1152921514474071408 |  dest_result_addr=1152921514474071416
        // 0x00B92E44: STP x10, x11, [sp, #0x10]  | stack[1152921514474071424] = 0x2A930BA;  stack[1152921514474071432] = 0xC;  //  dest_result_addr=1152921514474071424 |  dest_result_addr=1152921514474071432
        // 0x00B92E48: STP wzr, w12, [sp, #0x20]  | stack[1152921514474071440] = 0x0;  stack[1152921514474071444] = 0x1;  //  dest_result_addr=1152921514474071440 |  dest_result_addr=1152921514474071444
        // 0x00B92E4C: STR wzr, [sp, #0x28]       | stack[1152921514474071448] = 0x0;        //  dest_result_addr=1152921514474071448
        // 0x00B92E50: STRB wzr, [sp, #0x2c]      | stack[1152921514474071452] = 0x0;        //  dest_result_addr=1152921514474071452
        // 0x00B92E54: BL #0x27b0d50              | X0 = sub_27B0D50( ?? 0x100000024C21E570, ????);
        // 0x00B92E58: STR x0, [x19, #0xa50]      | static_value_03733A50 = 0x100000024C21E570;  //  dest_result_addr=57883216
        // 0x00B92E5C: CBZ x0, #0xb92e8c          | if (0x2A930B0 == 0) goto label_1;       
        if(44642480 == 0)
        {
            goto label_1;
        }
        label_0:
        // 0x00B92E60: BLR x0                     | X0 = sub_100000024C21E570( ?? 0x100000024C21E570, ????);
        // 0x00B92E64: MOV x19, x0                | X19 = 1152921514474071408 (0x100000024C21E570);//ML01
        // 0x00B92E68: BL #0x27b10b4              | X0 = sub_27B10B4( ?? 0x100000024C21E570, ????);
        // 0x00B92E6C: MOV x20, x0                | X20 = 1152921514474071408 (0x100000024C21E570);//ML01
        // 0x00B92E70: MOV x0, x19                | X0 = 1152921514474071408 (0x100000024C21E570);//ML01
        // 0x00B92E74: BL #0x27b102c              | X0 = sub_27B102C( ?? 0x100000024C21E570, ????);
        // 0x00B92E78: MOV x0, x20                | X0 = 1152921514474071408 (0x100000024C21E570);//ML01
        // 0x00B92E7C: SUB sp, x29, #0x10         | SP = (1152921514474071472 - 16) = 1152921514474071456 (0x100000024C21E5A0);
        // 0x00B92E80: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B92E84: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B92E88: RET                        |  return (System.String)0x100000024C21E570;
        return (string);
        //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        label_1:
        // 0x00B92E8C: ADRP x0, #0x2a93000        | X0 = 44642304 (0x2A93000);              
        // 0x00B92E90: ADD x0, x0, #0xc7          | X0 = (44642304 + 199) = 44642503 (0x02A930C7);
        // 0x00B92E94: BL #0x27af1b0              | X0 = sub_27AF1B0( ?? 0x2A930C7, ????);  
        // 0x00B92E98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B92E9C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x2A930C7, ????);  
        // 0x00B92EA0: BL #0xb8bb04               | X0 = System.Collections.Generic.IEnumerator<object>.get_Current();
        object val_1 = System.Collections.Generic.IEnumerator<object>.get_Current();
    
    }
    //
    // Offset in libil2cpp.so: 0x00B92EA4 (12136100), len: 232  VirtAddr: 0x00B92EA4 RVA: 0x00B92EA4 token: 100690112 methodIndex: 25203 delegateWrapperIndex: 0 methodInvoker: 0
    public static extern string use_data_dir(string _data_path, string _apk_path)
    {
        //
        // Disasemble & Code
        // 0x00B92EA4: STP x22, x21, [sp, #-0x30]! | stack[1152921514474199824] = ???;  stack[1152921514474199832] = ???;  //  dest_result_addr=1152921514474199824 |  dest_result_addr=1152921514474199832
        // 0x00B92EA8: STP x20, x19, [sp, #0x10]  | stack[1152921514474199840] = ???;  stack[1152921514474199848] = ???;  //  dest_result_addr=1152921514474199840 |  dest_result_addr=1152921514474199848
        // 0x00B92EAC: STP x29, x30, [sp, #0x20]  | stack[1152921514474199856] = ???;  stack[1152921514474199864] = ???;  //  dest_result_addr=1152921514474199856 |  dest_result_addr=1152921514474199864
        // 0x00B92EB0: ADD x29, sp, #0x20         | X29 = (1152921514474199824 + 32) = 1152921514474199856 (0x100000024C23DB30);
        // 0x00B92EB4: SUB sp, sp, #0x30          | SP = (1152921514474199824 - 48) = 1152921514474199776 (0x100000024C23DAE0);
        // 0x00B92EB8: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B92EBC: LDR x8, [x21, #0xa58]      | X8 = static_value_03733A58;             
        // 0x00B92EC0: MOV x19, x2                | X19 = X2;//m1                           
        // 0x00B92EC4: MOV x20, x1                | X20 = _apk_path;//m1                    
        // 0x00B92EC8: CBNZ x8, #0xb92f10         | if (static_value_03733A58 != 0) goto label_0;
        // 0x00B92ECC: ADRP x8, #0x2a93000        | X8 = 44642304 (0x2A93000);              
        // 0x00B92ED0: ADRP x10, #0x2a93000       | X10 = 44642304 (0x2A93000);             
        // 0x00B92ED4: ADD x8, x8, #0xb0          | X8 = (44642304 + 176) = 44642480 (0x02A930B0);
        // 0x00B92ED8: MOVZ w9, #0x9              | W9 = 9 (0x9);//ML01                     
        // 0x00B92EDC: ADD x10, x10, #0xfa        | X10 = (44642304 + 250) = 44642554 (0x02A930FA);
        // 0x00B92EE0: ORR w11, wzr, #0xc         | W11 = 12(0xC);                          
        // 0x00B92EE4: ORR w12, wzr, #1           | W12 = 1(0x1);                           
        // 0x00B92EE8: ORR w13, wzr, #0x10        | W13 = 16(0x10);                         
        // 0x00B92EEC: MOV x0, sp                 | X0 = 1152921514474199776 (0x100000024C23DAE0);//ML01
        // 0x00B92EF0: STP x8, x9, [sp]           | stack[1152921514474199776] = 0x2A930B0;  stack[1152921514474199784] = 0x9;  //  dest_result_addr=1152921514474199776 |  dest_result_addr=1152921514474199784
        // 0x00B92EF4: STP x10, x11, [sp, #0x10]  | stack[1152921514474199792] = 0x2A930FA;  stack[1152921514474199800] = 0xC;  //  dest_result_addr=1152921514474199792 |  dest_result_addr=1152921514474199800
        // 0x00B92EF8: STP wzr, w12, [sp, #0x20]  | stack[1152921514474199808] = 0x0;  stack[1152921514474199812] = 0x1;  //  dest_result_addr=1152921514474199808 |  dest_result_addr=1152921514474199812
        // 0x00B92EFC: STR w13, [sp, #0x28]       | stack[1152921514474199816] = 0x10;       //  dest_result_addr=1152921514474199816
        // 0x00B92F00: STRB wzr, [sp, #0x2c]      | stack[1152921514474199820] = 0x0;        //  dest_result_addr=1152921514474199820
        // 0x00B92F04: BL #0x27b0d50              | X0 = sub_27B0D50( ?? 0x100000024C23DAE0, ????);
        // 0x00B92F08: STR x0, [x21, #0xa58]      | static_value_03733A58 = 0x100000024C23DAE0;  //  dest_result_addr=57883224
        // 0x00B92F0C: CBZ x0, #0xb92f74          | if (0x2A930B0 == 0) goto label_1;       
        if(44642480 == 0)
        {
            goto label_1;
        }
        label_0:
        // 0x00B92F10: MOV x0, x20                | X0 = _apk_path;//m1                     
        // 0x00B92F14: BL #0x27b1038              | X0 = sub_27B1038( ?? _apk_path, ????);  
        // 0x00B92F18: MOV x20, x0                | X20 = _apk_path;//m1                    
        // 0x00B92F1C: MOV x0, x19                | X0 = X2;//m1                            
        // 0x00B92F20: BL #0x27b1038              | X0 = sub_27B1038( ?? X2, ????);         
        // 0x00B92F24: LDR x8, [x21, #0xa58]      | X8 = static_value_03733A58;             
        // 0x00B92F28: MOV x19, x0                | X19 = X2;//m1                           
        // 0x00B92F2C: MOV x0, x20                | X0 = _apk_path;//m1                     
        // 0x00B92F30: MOV x1, x19                | X1 = X2;//m1                            
        // 0x00B92F34: BLR x8                     | X0 = static_value_03733A58();           
        // 0x00B92F38: MOV x21, x0                | X21 = _apk_path;//m1                    
        // 0x00B92F3C: BL #0x27b10b4              | X0 = sub_27B10B4( ?? _apk_path, ????);  
        // 0x00B92F40: MOV x22, x0                | X22 = _apk_path;//m1                    
        // 0x00B92F44: MOV x0, x21                | X0 = _apk_path;//m1                     
        // 0x00B92F48: BL #0x27b102c              | X0 = sub_27B102C( ?? _apk_path, ????);  
        // 0x00B92F4C: MOV x0, x20                | X0 = _apk_path;//m1                     
        // 0x00B92F50: BL #0x27b102c              | X0 = sub_27B102C( ?? _apk_path, ????);  
        // 0x00B92F54: MOV x0, x19                | X0 = X2;//m1                            
        // 0x00B92F58: BL #0x27b102c              | X0 = sub_27B102C( ?? X2, ????);         
        // 0x00B92F5C: MOV x0, x22                | X0 = _apk_path;//m1                     
        // 0x00B92F60: SUB sp, x29, #0x20         | SP = (1152921514474199856 - 32) = 1152921514474199824 (0x100000024C23DB10);
        // 0x00B92F64: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B92F68: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B92F6C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B92F70: RET                        |  return (System.String)_apk_path;       
        return (string)_apk_path;
        //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        label_1:
        // 0x00B92F74: ADRP x0, #0x2a93000        | X0 = 44642304 (0x2A93000);              
        // 0x00B92F78: ADD x0, x0, #0x107         | X0 = (44642304 + 263) = 44642567 (0x02A93107);
        // 0x00B92F7C: BL #0x27af1b0              | X0 = sub_27AF1B0( ?? 0x2A93107, ????);  
        // 0x00B92F80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B92F84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x2A93107, ????);  
        // 0x00B92F88: BL #0xb8bb04               | X0 = System.Collections.Generic.IEnumerator<object>.get_Current();
        object val_1 = System.Collections.Generic.IEnumerator<object>.get_Current();
    
    }
    //
    // Offset in libil2cpp.so: 0x00B92F8C (12136332), len: 2248  VirtAddr: 0x00B92F8C RVA: 0x00B92F8C token: 100690113 methodIndex: 25204 delegateWrapperIndex: 0 methodInvoker: 0
    public static void reboot_app()
    {
        //
        // Disasemble & Code
        //  | 
        var val_16;
        // 0x00B92F8C: STP x28, x27, [sp, #-0x60]! | stack[1152921514474396432] = ???;  stack[1152921514474396440] = ???;  //  dest_result_addr=1152921514474396432 |  dest_result_addr=1152921514474396440
        // 0x00B92F90: STP x26, x25, [sp, #0x10]  | stack[1152921514474396448] = ???;  stack[1152921514474396456] = ???;  //  dest_result_addr=1152921514474396448 |  dest_result_addr=1152921514474396456
        // 0x00B92F94: STP x24, x23, [sp, #0x20]  | stack[1152921514474396464] = ???;  stack[1152921514474396472] = ???;  //  dest_result_addr=1152921514474396464 |  dest_result_addr=1152921514474396472
        // 0x00B92F98: STP x22, x21, [sp, #0x30]  | stack[1152921514474396480] = ???;  stack[1152921514474396488] = ???;  //  dest_result_addr=1152921514474396480 |  dest_result_addr=1152921514474396488
        // 0x00B92F9C: STP x20, x19, [sp, #0x40]  | stack[1152921514474396496] = ???;  stack[1152921514474396504] = ???;  //  dest_result_addr=1152921514474396496 |  dest_result_addr=1152921514474396504
        // 0x00B92FA0: STP x29, x30, [sp, #0x50]  | stack[1152921514474396512] = ???;  stack[1152921514474396520] = ???;  //  dest_result_addr=1152921514474396512 |  dest_result_addr=1152921514474396520
        // 0x00B92FA4: ADD x29, sp, #0x50         | X29 = (1152921514474396432 + 80) = 1152921514474396512 (0x100000024C26DB60);
        // 0x00B92FA8: SUB sp, sp, #0x30          | SP = (1152921514474396432 - 48) = 1152921514474396384 (0x100000024C26DAE0);
        // 0x00B92FAC: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B92FB0: LDRB w8, [x19, #0xa60]     | W8 = (bool)static_value_03733A60;       
        // 0x00B92FB4: TBNZ w8, #0, #0xb92fd0     | if (static_value_03733A60 == true) goto label_0;
        // 0x00B92FB8: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
        // 0x00B92FBC: LDR x8, [x8, #0x7a8]       | X8 = 0x2B8F888;                         
        // 0x00B92FC0: LDR w0, [x8]               | W0 = 0x14E6;                            
        // 0x00B92FC4: BL #0x2782188              | X0 = sub_2782188( ?? 0x14E6, ????);     
        // 0x00B92FC8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B92FCC: STRB w8, [x19, #0xa60]     | static_value_03733A60 = true;            //  dest_result_addr=57883232
        label_0:
        // 0x00B92FD0: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B92FD4: LDR x8, [x8, #0xa30]       | X8 = 1152921504690233344;               
        // 0x00B92FD8: LDR x0, [x8]               | X0 = typeof(UnityEngine.AndroidJavaClass);
        UnityEngine.AndroidJavaClass val_1 = null;
        // 0x00B92FDC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00B92FE0: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
        // 0x00B92FE4: LDR x8, [x8, #0xe30]       | X8 = (string**)(1152921514474312160)("com.unity3d.player.UnityPlayer");
        // 0x00B92FE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B92FEC: MOV x19, x0                | X19 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B92FF0: LDR x1, [x8]               | X1 = "com.unity3d.player.UnityPlayer";  
        // 0x00B92FF4: BL #0x20b9834              | .ctor(className:  "com.unity3d.player.UnityPlayer");
        val_1 = new UnityEngine.AndroidJavaClass(className:  "com.unity3d.player.UnityPlayer");
        // 0x00B92FF8: CBNZ x19, #0xb93000        | if ( != 0) goto label_1;                
        if(null != 0)
        {
            goto label_1;
        }
        // 0x00B92FFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(className:  "com.unity3d.player.UnityPlayer"), ????);
        label_1:
        // 0x00B93000: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
        // 0x00B93004: LDR x8, [x8, #0xb8]        | X8 = (string**)(1152921514474312288)("currentActivity");
        // 0x00B93008: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
        // 0x00B9300C: LDR x9, [x9, #0x458]       | X9 = 1152921514474312400;               
        // 0x00B93010: LDR x1, [x8]               | X1 = "currentActivity";                 
        // 0x00B93014: LDR x2, [x9]               | X2 = public UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::GetStatic<UnityEngine.AndroidJavaObject>(string fieldName);
        // 0x00B93018: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B9301C: BL #0x12e3528              | X0 = GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  "currentActivity");
        UnityEngine.AndroidJavaObject val_2 = GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  "currentActivity");
        // 0x00B93020: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B93024: CBNZ x20, #0xb9302c        | if (val_2 != null) goto label_2;        
        if(val_2 != null)
        {
            goto label_2;
        }
        // 0x00B93028: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_2:
        // 0x00B9302C: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B93030: ADRP x26, #0x3630000       | X26 = 56819712 (0x3630000);             
        // 0x00B93034: LDR x8, [x8, #0xd8]        | X8 = (string**)(1152921514474317520)("getPackageManager");
        // 0x00B93038: LDR x26, [x26, #0x3d0]     | X26 = 1152921504954501264;              
        // 0x00B9303C: LDR x21, [x8]              | X21 = "getPackageManager";              
        // 0x00B93040: LDR x22, [x26]             | X22 = typeof(System.Object[]);          
        // 0x00B93044: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B93048: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B9304C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93050: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B93054: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B93058: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B9305C: ADRP x25, #0x3608000       | X25 = 56655872 (0x3608000);             
        // 0x00B93060: LDR x25, [x25, #0x710]     | X25 = 1152921514474317632;              
        // 0x00B93064: LDR x3, [x25]              | X3 = public UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::Call<UnityEngine.AndroidJavaObject>(string methodName, object[] args);
        // 0x00B93068: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B9306C: MOV x1, x21                | X1 = 1152921514474317520 (0x100000024C25A6D0);//ML01
        // 0x00B93070: BL #0x12f5e74              | X0 = val_2.Call<UnityEngine.AndroidJavaObject>(methodName:  "getPackageManager", args:  null);
        UnityEngine.AndroidJavaObject val_3 = val_2.Call<UnityEngine.AndroidJavaObject>(methodName:  "getPackageManager", args:  null);
        // 0x00B93074: MOV x21, x0                | X21 = val_3;//m1                        
        // 0x00B93078: LDR x22, [x26]             | X22 = typeof(System.Object[]);          
        // 0x00B9307C: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B93080: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B93084: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B93088: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B9308C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B93090: MOV x22, x0                | X22 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B93094: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B93098: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9309C: BL #0x20c767c              | X0 = UnityEngine.Application.get_identifier();
        string val_4 = UnityEngine.Application.identifier;
        // 0x00B930A0: MOV x23, x0                | X23 = val_4;//m1                        
        // 0x00B930A4: CBNZ x22, #0xb930ac        | if ( != null) goto label_3;             
        if(null != null)
        {
            goto label_3;
        }
        // 0x00B930A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_3:
        // 0x00B930AC: CBZ x23, #0xb930d0         | if (val_4 == null) goto label_5;        
        if(val_4 == null)
        {
            goto label_5;
        }
        // 0x00B930B0: LDR x8, [x22]              | X8 = ;                                  
        // 0x00B930B4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B930B8: MOV x0, x23                | X0 = val_4;//m1                         
        // 0x00B930BC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_4, ????);      
        // 0x00B930C0: CBNZ x0, #0xb930d0         | if (val_4 != null) goto label_5;        
        if(val_4 != null)
        {
            goto label_5;
        }
        // 0x00B930C4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_4, ????);      
        // 0x00B930C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B930CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
        label_5:
        // 0x00B930D0: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B930D4: CBNZ w8, #0xb930e4         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_6;
        // 0x00B930D8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
        // 0x00B930DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B930E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
        label_6:
        // 0x00B930E4: STR x23, [x22, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_4;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_4;
        // 0x00B930E8: CBNZ x21, #0xb930f0        | if (val_3 != null) goto label_7;        
        if(val_3 != null)
        {
            goto label_7;
        }
        // 0x00B930EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_7:
        // 0x00B930F0: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
        // 0x00B930F4: LDR x8, [x8, #0x5a0]       | X8 = (string**)(1152921514474326848)("getLaunchIntentForPackage");
        // 0x00B930F8: LDR x3, [x25]              | X3 = public UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::Call<UnityEngine.AndroidJavaObject>(string methodName, object[] args);
        // 0x00B930FC: LDR x1, [x8]               | X1 = "getLaunchIntentForPackage";       
        // 0x00B93100: MOV x0, x21                | X0 = val_3;//m1                         
        // 0x00B93104: MOV x2, x22                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B93108: BL #0x12f5e74              | X0 = val_3.Call<UnityEngine.AndroidJavaObject>(methodName:  "getLaunchIntentForPackage", args:  null);
        UnityEngine.AndroidJavaObject val_5 = val_3.Call<UnityEngine.AndroidJavaObject>(methodName:  "getLaunchIntentForPackage", args:  null);
        // 0x00B9310C: MOV x21, x0                | X21 = val_5;//m1                        
        // 0x00B93110: LDR x22, [x26]             | X22 = typeof(System.Object[]);          
        // 0x00B93114: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B93118: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B9311C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B93120: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B93124: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B93128: MOV x22, x0                | X22 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B9312C: ADRP x28, #0x3652000       | X28 = 56958976 (0x3652000);             
        // 0x00B93130: LDR x28, [x28, #0x140]     | X28 = 1152921504607113216;              
        // 0x00B93134: ORR w8, wzr, #0x20000000   | W8 = 536870912(0x20000000);             
        // 0x00B93138: STR w8, [sp, #0x2c]        | stack[1152921514474396428] = 0x20000000;  //  dest_result_addr=1152921514474396428
        // 0x00B9313C: LDR x0, [x28]              | X0 = typeof(System.Int32);              
        // 0x00B93140: ADD x1, sp, #0x2c          | X1 = (1152921514474396384 + 44) = 1152921514474396428 (0x100000024C26DB0C);
        // 0x00B93144: BL #0x27bc028              | X0 = 1152921514474456912 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 536870912);
        // 0x00B93148: MOV x23, x0                | X23 = 1152921514474456912 (0x100000024C27C750);//ML01
        // 0x00B9314C: CBNZ x22, #0xb93154        | if ( != null) goto label_8;             
        if(null != null)
        {
            goto label_8;
        }
        // 0x00B93150: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 536870912, ????);  
        label_8:
        // 0x00B93154: CBZ x23, #0xb93178         | if (536870912 == 0) goto label_10;      
        if(536870912 == 0)
        {
            goto label_10;
        }
        // 0x00B93158: LDR x8, [x22]              | X8 = ;                                  
        // 0x00B9315C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B93160: MOV x0, x23                | X0 = 1152921514474456912 (0x100000024C27C750);//ML01
        // 0x00B93164: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 536870912, ????);  
        // 0x00B93168: CBNZ x0, #0xb93178         | if (536870912 != 0) goto label_10;      
        if(536870912 != 0)
        {
            goto label_10;
        }
        // 0x00B9316C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 536870912, ????);  
        // 0x00B93170: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93174: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 536870912, ????);  
        label_10:
        // 0x00B93178: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B9317C: CBNZ w8, #0xb9318c         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_11;
        // 0x00B93180: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 536870912, ????);  
        // 0x00B93184: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93188: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 536870912, ????);  
        label_11:
        // 0x00B9318C: STR x23, [x22, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = 536870912; typeof(System.Object[]).__il2cppRuntimeField_24 = 0x10000002;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501300
        typeof(System.Object[]).__il2cppRuntimeField_20 = 536870912;
        typeof(System.Object[]).__il2cppRuntimeField_24 = 268435458;
        // 0x00B93190: CBNZ x21, #0xb93198        | if (val_5 != null) goto label_12;       
        if(val_5 != null)
        {
            goto label_12;
        }
        // 0x00B93194: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 536870912, ????);  
        label_12:
        // 0x00B93198: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
        // 0x00B9319C: LDR x8, [x8, #0x6b8]       | X8 = (string**)(1152921514474335168)("setFlags");
        // 0x00B931A0: LDR x3, [x25]              | X3 = public UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::Call<UnityEngine.AndroidJavaObject>(string methodName, object[] args);
        // 0x00B931A4: LDR x1, [x8]               | X1 = "setFlags";                        
        // 0x00B931A8: MOV x0, x21                | X0 = val_5;//m1                         
        // 0x00B931AC: MOV x2, x22                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B931B0: BL #0x12f5e74              | X0 = val_5.Call<UnityEngine.AndroidJavaObject>(methodName:  "setFlags", args:  null);
        UnityEngine.AndroidJavaObject val_6 = val_5.Call<UnityEngine.AndroidJavaObject>(methodName:  "setFlags", args:  null);
        // 0x00B931B4: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B931B8: LDR x8, [x8, #0xa30]       | X8 = 1152921504690233344;               
        // 0x00B931BC: LDR x0, [x8]               | X0 = typeof(UnityEngine.AndroidJavaClass);
        // 0x00B931C0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00B931C4: MOV x22, x0                | X22 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B931C8: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
        // 0x00B931CC: LDR x8, [x8, #0x7f0]       | X8 = (string**)(1152921514474339360)("android.app.PendingIntent");
        // 0x00B931D0: LDR x1, [x8]               | X1 = "android.app.PendingIntent";       
        // 0x00B931D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B931D8: MOV x0, x22                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        UnityEngine.AndroidJavaClass val_7 = null;
        // 0x00B931DC: BL #0x20b9834              | .ctor(className:  "android.app.PendingIntent");
        val_7 = new UnityEngine.AndroidJavaClass(className:  "android.app.PendingIntent");
        // 0x00B931E0: LDR x23, [x26]             | X23 = typeof(System.Object[]);          
        // 0x00B931E4: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B931E8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B931EC: ORR w1, wzr, #4            | W1 = 4(0x4);                            
        // 0x00B931F0: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B931F4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B931F8: MOV x23, x0                | X23 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B931FC: CBNZ x23, #0xb93204        | if ( != null) goto label_13;            
        if(null != null)
        {
            goto label_13;
        }
        // 0x00B93200: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_13:
        // 0x00B93204: CBZ x20, #0xb93228         | if (val_2 == null) goto label_15;       
        if(val_2 == null)
        {
            goto label_15;
        }
        // 0x00B93208: LDR x8, [x23]              | X8 = ;                                  
        // 0x00B9320C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B93210: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B93214: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
        // 0x00B93218: CBNZ x0, #0xb93228         | if (val_2 != null) goto label_15;       
        if(val_2 != null)
        {
            goto label_15;
        }
        // 0x00B9321C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
        // 0x00B93220: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93224: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_15:
        // 0x00B93228: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B9322C: CBNZ w8, #0xb9323c         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_16;
        // 0x00B93230: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
        // 0x00B93234: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93238: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_16:
        // 0x00B9323C: STR x20, [x23, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;
        // 0x00B93240: LDR x0, [x28]              | X0 = typeof(System.Int32);              
        // 0x00B93244: STR wzr, [sp, #0x28]       | stack[1152921514474396424] = 0x0;        //  dest_result_addr=1152921514474396424
        // 0x00B93248: ADD x1, sp, #0x28          | X1 = (1152921514474396384 + 40) = 1152921514474396424 (0x100000024C26DB08);
        // 0x00B9324C: BL #0x27bc028              | X0 = 1152921514474465104 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 0);
        // 0x00B93250: MOV x24, x0                | X24 = 1152921514474465104 (0x100000024C27E750);//ML01
        // 0x00B93254: CBZ x24, #0xb93278         | if (0 == 0) goto label_18;              
        if(0 == 0)
        {
            goto label_18;
        }
        // 0x00B93258: LDR x8, [x23]              | X8 = ;                                  
        // 0x00B9325C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B93260: MOV x0, x24                | X0 = 1152921514474465104 (0x100000024C27E750);//ML01
        // 0x00B93264: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0, ????);          
        // 0x00B93268: CBNZ x0, #0xb93278         | if (0 != 0) goto label_18;              
        if(0 != 0)
        {
            goto label_18;
        }
        // 0x00B9326C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 0, ????);          
        // 0x00B93270: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93274: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0, ????);          
        label_18:
        // 0x00B93278: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B9327C: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B93280: B.HI #0xb93290             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_19;
        // 0x00B93284: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0, ????);          
        // 0x00B93288: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9328C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0, ????);          
        label_19:
        // 0x00B93290: STR x24, [x23, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = 0; typeof(System.Object[]).__il2cppRuntimeField_2C = 0x10000002;  //  dest_result_addr=1152921504954501304 dest_result_addr=1152921504954501308
        typeof(System.Object[]).__il2cppRuntimeField_28 = 0;
        typeof(System.Object[]).__il2cppRuntimeField_2C = 268435458;
        // 0x00B93294: CBZ x21, #0xb932b8         | if (val_5 == null) goto label_21;       
        if(val_5 == null)
        {
            goto label_21;
        }
        // 0x00B93298: LDR x8, [x23]              | X8 = ;                                  
        // 0x00B9329C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B932A0: MOV x0, x21                | X0 = val_5;//m1                         
        // 0x00B932A4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_5, ????);      
        // 0x00B932A8: CBNZ x0, #0xb932b8         | if (val_5 != null) goto label_21;       
        if(val_5 != null)
        {
            goto label_21;
        }
        // 0x00B932AC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_5, ????);      
        // 0x00B932B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B932B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
        label_21:
        // 0x00B932B8: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B932BC: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x00B932C0: B.HI #0xb932d0             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_22;
        // 0x00B932C4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_5, ????);      
        // 0x00B932C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B932CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
        label_22:
        // 0x00B932D0: STR x21, [x23, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = val_5;  //  dest_result_addr=1152921504954501312
        typeof(System.Object[]).__il2cppRuntimeField_30 = val_5;
        // 0x00B932D4: LDR x0, [x28]              | X0 = typeof(System.Int32);              
        // 0x00B932D8: ORR w8, wzr, #0x8000000    | W8 = 134217728(0x8000000);              
        // 0x00B932DC: STR w8, [sp, #0x24]        | stack[1152921514474396420] = 0x8000000;  //  dest_result_addr=1152921514474396420
        // 0x00B932E0: ADD x1, sp, #0x24          | X1 = (1152921514474396384 + 36) = 1152921514474396420 (0x100000024C26DB04);
        // 0x00B932E4: BL #0x27bc028              | X0 = 1152921514474469200 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 134217728);
        // 0x00B932E8: MOV x21, x0                | X21 = 1152921514474469200 (0x100000024C27F750);//ML01
        // 0x00B932EC: CBZ x21, #0xb93310         | if (134217728 == 0) goto label_24;      
        if(134217728 == 0)
        {
            goto label_24;
        }
        // 0x00B932F0: LDR x8, [x23]              | X8 = ;                                  
        // 0x00B932F4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B932F8: MOV x0, x21                | X0 = 1152921514474469200 (0x100000024C27F750);//ML01
        // 0x00B932FC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 134217728, ????);  
        // 0x00B93300: CBNZ x0, #0xb93310         | if (134217728 != 0) goto label_24;      
        if(134217728 != 0)
        {
            goto label_24;
        }
        // 0x00B93304: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 134217728, ????);  
        // 0x00B93308: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9330C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 134217728, ????);  
        label_24:
        // 0x00B93310: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B93314: CMP w8, #3                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x3)
        // 0x00B93318: B.HI #0xb93328             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x3) goto label_25;
        // 0x00B9331C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 134217728, ????);  
        // 0x00B93320: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93324: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 134217728, ????);  
        label_25:
        // 0x00B93328: STR x21, [x23, #0x38]      | typeof(System.Object[]).__il2cppRuntimeField_38 = 134217728; typeof(System.Object[]).__il2cppRuntimeField_3C = 0x10000002;  //  dest_result_addr=1152921504954501320 dest_result_addr=1152921504954501324
        typeof(System.Object[]).__il2cppRuntimeField_38 = 134217728;
        typeof(System.Object[]).__il2cppRuntimeField_3C = 268435458;
        // 0x00B9332C: CBNZ x22, #0xb93334        | if ( != 0) goto label_26;               
        if(null != 0)
        {
            goto label_26;
        }
        // 0x00B93330: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 134217728, ????);  
        label_26:
        // 0x00B93334: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
        // 0x00B93338: LDR x8, [x8, #0xac0]       | X8 = (string**)(1152921514474347680)("getActivity");
        // 0x00B9333C: ADRP x9, #0x35ef000        | X9 = 56553472 (0x35EF000);              
        // 0x00B93340: LDR x9, [x9, #0x188]       | X9 = 1152921514474347776;               
        // 0x00B93344: LDR x1, [x8]               | X1 = "getActivity";                     
        // 0x00B93348: LDR x3, [x9]               | X3 = public UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::CallStatic<UnityEngine.AndroidJavaObject>(string methodName, object[] args);
        // 0x00B9334C: MOV x0, x22                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B93350: MOV x2, x23                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B93354: BL #0x12f6004              | X0 = CallStatic<UnityEngine.AndroidJavaObject>(methodName:  "getActivity", args:  null);
        UnityEngine.AndroidJavaObject val_8 = CallStatic<UnityEngine.AndroidJavaObject>(methodName:  "getActivity", args:  null);
        // 0x00B93358: MOV x21, x0                | X21 = val_8;//m1                        
        // 0x00B9335C: LDR x22, [x26]             | X22 = typeof(System.Object[]);          
        // 0x00B93360: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B93364: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B93368: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B9336C: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B93370: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B93374: MOV x22, x0                | X22 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B93378: CBNZ x22, #0xb93380        | if ( != null) goto label_27;            
        if(null != null)
        {
            goto label_27;
        }
        // 0x00B9337C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_27:
        // 0x00B93380: ADRP x23, #0x363b000       | X23 = 56864768 (0x363B000);             
        // 0x00B93384: LDR x23, [x23, #0x8f8]     | X23 = (string**)(1152921514474352896)("alarm");
        // 0x00B93388: LDR x0, [x23]              | X0 = "alarm";                           
        // 0x00B9338C: CBZ x0, #0xb933ac          | if ("alarm" == null) goto label_29;     
        // 0x00B93390: LDR x8, [x22]              | X8 = ;                                  
        // 0x00B93394: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B93398: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "alarm", ????);    
        // 0x00B9339C: CBNZ x0, #0xb933ac         | if ("alarm" != null) goto label_29;     
        if("alarm" != null)
        {
            goto label_29;
        }
        // 0x00B933A0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "alarm", ????);    
        // 0x00B933A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B933A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "alarm", ????);    
        label_29:
        // 0x00B933AC: LDR x23, [x23]             | X23 = "alarm";                          
        // 0x00B933B0: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B933B4: CBNZ w8, #0xb933c4         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_30;
        // 0x00B933B8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "alarm", ????);    
        // 0x00B933BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B933C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "alarm", ????);    
        label_30:
        // 0x00B933C4: STR x23, [x22, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = "alarm";  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = "alarm";
        // 0x00B933C8: CBNZ x20, #0xb933d0        | if (val_2 != null) goto label_31;       
        if(val_2 != null)
        {
            goto label_31;
        }
        // 0x00B933CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "alarm", ????);    
        label_31:
        // 0x00B933D0: ADRP x8, #0x35c5000        | X8 = 56381440 (0x35C5000);              
        // 0x00B933D4: LDR x8, [x8, #0x690]       | X8 = (string**)(1152921514474352976)("getSystemService");
        // 0x00B933D8: LDR x3, [x25]              | X3 = public UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::Call<UnityEngine.AndroidJavaObject>(string methodName, object[] args);
        // 0x00B933DC: LDR x1, [x8]               | X1 = "getSystemService";                
        // 0x00B933E0: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B933E4: MOV x2, x22                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B933E8: BL #0x12f5e74              | X0 = val_2.Call<UnityEngine.AndroidJavaObject>(methodName:  "getSystemService", args:  null);
        UnityEngine.AndroidJavaObject val_9 = val_2.Call<UnityEngine.AndroidJavaObject>(methodName:  "getSystemService", args:  null);
        // 0x00B933EC: MOV x22, x0                | X22 = val_9;//m1                        
        // 0x00B933F0: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B933F4: LDR x8, [x8, #0xa30]       | X8 = 1152921504690233344;               
        // 0x00B933F8: LDR x0, [x8]               | X0 = typeof(UnityEngine.AndroidJavaClass);
        // 0x00B933FC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00B93400: MOV x23, x0                | X23 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B93404: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
        // 0x00B93408: LDR x8, [x8, #0xaf8]       | X8 = (string**)(1152921514474357184)("java.lang.System");
        // 0x00B9340C: LDR x1, [x8]               | X1 = "java.lang.System";                
        // 0x00B93410: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B93414: MOV x0, x23                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        UnityEngine.AndroidJavaClass val_10 = null;
        // 0x00B93418: BL #0x20b9834              | .ctor(className:  "java.lang.System");  
        val_10 = new UnityEngine.AndroidJavaClass(className:  "java.lang.System");
        // 0x00B9341C: CBNZ x23, #0xb93424        | if ( != 0) goto label_32;               
        if(null != 0)
        {
            goto label_32;
        }
        // 0x00B93420: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(className:  "java.lang.System"), ????);
        label_32:
        // 0x00B93424: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
        // 0x00B93428: LDR x8, [x8, #0x728]       | X8 = (string**)(1152921514474357296)("currentTimeMillis");
        // 0x00B9342C: LDR x25, [x26]             | X25 = typeof(System.Object[]);          
        // 0x00B93430: LDR x24, [x8]              | X24 = "currentTimeMillis";              
        // 0x00B93434: MOV x0, x25                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B93438: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B9343C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93440: MOV x0, x25                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B93444: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B93448: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B9344C: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
        // 0x00B93450: LDR x8, [x8, #0x4e8]       | X8 = 1152921514474357408;               
        // 0x00B93454: LDR x3, [x8]               | X3 = public System.Int64 UnityEngine.AndroidJavaObject::CallStatic<System.Int64>(string methodName, object[] args);
        // 0x00B93458: MOV x0, x23                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B9345C: MOV x1, x24                | X1 = 1152921514474357296 (0x100000024C264230);//ML01
        // 0x00B93460: BL #0x12f5fb4              | X0 = CallStatic<System.Int64>(methodName:  "currentTimeMillis", args:  null);
        long val_11 = CallStatic<System.Int64>(methodName:  "currentTimeMillis", args:  null);
        // 0x00B93464: MOV x23, x0                | X23 = val_11;//m1                       
        // 0x00B93468: LDR x24, [x26]             | X24 = typeof(System.Object[]);          
        // 0x00B9346C: MOV x0, x24                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B93470: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B93474: ORR w1, wzr, #3            | W1 = 3(0x3);                            
        // 0x00B93478: MOV x0, x24                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B9347C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B93480: MOV x24, x0                | X24 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B93484: LDR x0, [x28]              | X0 = typeof(System.Int32);              
        // 0x00B93488: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B9348C: STR w8, [sp, #0x20]        | stack[1152921514474396416] = 0x1;        //  dest_result_addr=1152921514474396416
        // 0x00B93490: ADD x1, sp, #0x20          | X1 = (1152921514474396384 + 32) = 1152921514474396416 (0x100000024C26DB00);
        // 0x00B93494: BL #0x27bc028              | X0 = 1152921514474481488 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1);
        // 0x00B93498: MOV x25, x0                | X25 = 1152921514474481488 (0x100000024C282750);//ML01
        // 0x00B9349C: CBNZ x24, #0xb934a4        | if ( != null) goto label_33;            
        if(null != null)
        {
            goto label_33;
        }
        // 0x00B934A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 1, ????);          
        label_33:
        // 0x00B934A4: CBZ x25, #0xb934c8         | if (1 == 0) goto label_35;              
        if(1 == 0)
        {
            goto label_35;
        }
        // 0x00B934A8: LDR x8, [x24]              | X8 = ;                                  
        // 0x00B934AC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B934B0: MOV x0, x25                | X0 = 1152921514474481488 (0x100000024C282750);//ML01
        // 0x00B934B4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 1, ????);          
        // 0x00B934B8: CBNZ x0, #0xb934c8         | if (1 != 0) goto label_35;              
        if(1 != 0)
        {
            goto label_35;
        }
        // 0x00B934BC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 1, ????);          
        // 0x00B934C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B934C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 1, ????);          
        label_35:
        // 0x00B934C8: LDR w8, [x24, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B934CC: CBNZ w8, #0xb934dc         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_36;
        // 0x00B934D0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 1, ????);          
        // 0x00B934D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B934D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 1, ????);          
        label_36:
        // 0x00B934DC: STR x25, [x24, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = 1; typeof(System.Object[]).__il2cppRuntimeField_24 = 0x10000002;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501300
        typeof(System.Object[]).__il2cppRuntimeField_20 = 1;
        typeof(System.Object[]).__il2cppRuntimeField_24 = 268435458;
        // 0x00B934E0: ADRP x27, #0x3632000       | X27 = 56827904 (0x3632000);             
        // 0x00B934E4: LDR x27, [x27, #0x4b0]     | X27 = 1152921504607592448;              
        // 0x00B934E8: ADD x8, x23, #0x3e8        | X8 = (val_11 + 1000);                   
        long val_12 = val_11 + 1000;
        // 0x00B934EC: STR x8, [sp, #0x18]        | stack[1152921514474396408] = (val_11 + 1000);  //  dest_result_addr=1152921514474396408
        // 0x00B934F0: LDR x0, [x27]              | X0 = typeof(System.Int64);              
        // 0x00B934F4: ADD x1, sp, #0x18          | X1 = (1152921514474396384 + 24) = 1152921514474396408 (0x100000024C26DAF8);
        // 0x00B934F8: BL #0x27bc028              | X0 = 1152921514474485584 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int64), (val_11 + 1000));
        // 0x00B934FC: MOV x25, x0                | X25 = 1152921514474485584 (0x100000024C283750);//ML01
        // 0x00B93500: CBZ x25, #0xb93524         | if ((val_11 + 1000) == 0) goto label_38;
        if(val_12 == 0)
        {
            goto label_38;
        }
        // 0x00B93504: LDR x8, [x24]              | X8 = ;                                  
        // 0x00B93508: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B9350C: MOV x0, x25                | X0 = 1152921514474485584 (0x100000024C283750);//ML01
        // 0x00B93510: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? (val_11 + 1000), ????);
        // 0x00B93514: CBNZ x0, #0xb93524         | if ((val_11 + 1000) != 0) goto label_38;
        if(val_12 != 0)
        {
            goto label_38;
        }
        // 0x00B93518: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? (val_11 + 1000), ????);
        // 0x00B9351C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93520: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (val_11 + 1000), ????);
        label_38:
        // 0x00B93524: LDR w8, [x24, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B93528: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B9352C: B.HI #0xb9353c             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_39;
        // 0x00B93530: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? (val_11 + 1000), ????);
        // 0x00B93534: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93538: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (val_11 + 1000), ????);
        label_39:
        // 0x00B9353C: STR x25, [x24, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = (val_11 + 1000);  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_12;
        // 0x00B93540: CBZ x21, #0xb93564         | if (val_8 == null) goto label_41;       
        if(val_8 == null)
        {
            goto label_41;
        }
        // 0x00B93544: LDR x8, [x24]              | X8 = ;                                  
        // 0x00B93548: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B9354C: MOV x0, x21                | X0 = val_8;//m1                         
        // 0x00B93550: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_8, ????);      
        // 0x00B93554: CBNZ x0, #0xb93564         | if (val_8 != null) goto label_41;       
        if(val_8 != null)
        {
            goto label_41;
        }
        // 0x00B93558: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_8, ????);      
        // 0x00B9355C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93560: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
        label_41:
        // 0x00B93564: LDR w8, [x24, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B93568: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x00B9356C: B.HI #0xb9357c             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_42;
        // 0x00B93570: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_8, ????);      
        // 0x00B93574: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93578: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
        label_42:
        // 0x00B9357C: STR x21, [x24, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = val_8;  //  dest_result_addr=1152921504954501312
        typeof(System.Object[]).__il2cppRuntimeField_30 = val_8;
        // 0x00B93580: CBNZ x22, #0xb93588        | if (val_9 != null) goto label_43;       
        if(val_9 != null)
        {
            goto label_43;
        }
        // 0x00B93584: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_43:
        // 0x00B93588: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
        // 0x00B9358C: LDR x8, [x8, #0x70]        | X8 = (string**)(1152921512830010544)("set");
        // 0x00B93590: LDR x1, [x8]               | X1 = "set";                             
        // 0x00B93594: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B93598: MOV x0, x22                | X0 = val_9;//m1                         
        // 0x00B9359C: MOV x2, x24                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B935A0: BL #0x20bdbd4              | val_9.Call(methodName:  "set", args:  null);
        val_9.Call(methodName:  "set", args:  null);
        // 0x00B935A4: LDR x0, [x27]              | X0 = typeof(System.Int64);              
        // 0x00B935A8: STR x23, [sp, #0x10]       | stack[1152921514474396400] = val_11;     //  dest_result_addr=1152921514474396400
        // 0x00B935AC: ADD x1, sp, #0x10          | X1 = (1152921514474396384 + 16) = 1152921514474396400 (0x100000024C26DAF0);
        // 0x00B935B0: BL #0x27bc028              | X0 = 1152921514474489680 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int64), val_11);
        // 0x00B935B4: MOV x21, x0                | X21 = 1152921514474489680 (0x100000024C284750);//ML01
        // 0x00B935B8: LDR x0, [x28]              | X0 = typeof(System.Int32);              
        // 0x00B935BC: MOVZ w8, #0x3e8            | W8 = 1000 (0x3E8);//ML01                
        // 0x00B935C0: STR w8, [sp, #0xc]         | stack[1152921514474396396] = 0x3E8;      //  dest_result_addr=1152921514474396396
        // 0x00B935C4: ADD x1, sp, #0xc           | X1 = (1152921514474396384 + 12) = 1152921514474396396 (0x100000024C26DAEC);
        // 0x00B935C8: BL #0x27bc028              | X0 = 1152921514474493776 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1000);
        // 0x00B935CC: MOV x22, x0                | X22 = 1152921514474493776 (0x100000024C285750);//ML01
        // 0x00B935D0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B935D4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B935D8: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B935DC: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B935E0: TBZ w8, #0, #0xb935f0      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_45;
        // 0x00B935E4: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B935E8: CBNZ w8, #0xb935f0         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_45;
        // 0x00B935EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_45:
        // 0x00B935F0: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
        // 0x00B935F4: LDR x8, [x8, #0xcf0]       | X8 = (string**)(1152921514474374816)("alarm_manager set time ");
        // 0x00B935F8: LDR x1, [x8]               | X1 = "alarm_manager set time ";         
        // 0x00B935FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B93600: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B93604: MOV x2, x21                | X2 = 1152921514474489680 (0x100000024C284750);//ML01
        // 0x00B93608: MOV x3, x22                | X3 = 1152921514474493776 (0x100000024C285750);//ML01
        // 0x00B9360C: BL #0x18a8bac              | X0 = System.String.Concat(arg0:  0, arg1:  "alarm_manager set time ", arg2:  val_11);
        string val_13 = System.String.Concat(arg0:  0, arg1:  "alarm_manager set time ", arg2:  val_11);
        // 0x00B93610: MOV x21, x0                | X21 = val_13;//m1                       
        // 0x00B93614: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
        // 0x00B93618: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
        // 0x00B9361C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Debug);         
        // 0x00B93620: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
        // 0x00B93624: TBZ w8, #0, #0xb93634      | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_47;
        // 0x00B93628: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
        // 0x00B9362C: CBNZ w8, #0xb93634         | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_47;
        // 0x00B93630: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
        label_47:
        // 0x00B93634: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B93638: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B9363C: MOV x1, x21                | X1 = val_13;//m1                        
        // 0x00B93640: BL #0x1a5d504              | UnityEngine.Debug.LogError(message:  0);
        UnityEngine.Debug.LogError(message:  0);
        // 0x00B93644: CBNZ x20, #0xb9364c        | if (val_2 != null) goto label_48;       
        if(val_2 != null)
        {
            goto label_48;
        }
        // 0x00B93648: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_48:
        // 0x00B9364C: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
        // 0x00B93650: LDR x8, [x8, #0xb00]       | X8 = (string**)(1152921514474379040)("finish");
        // 0x00B93654: LDR x22, [x26]             | X22 = typeof(System.Object[]);          
        // 0x00B93658: LDR x21, [x8]              | X21 = "finish";                         
        // 0x00B9365C: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B93660: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B93664: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93668: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B9366C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B93670: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B93674: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B93678: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B9367C: MOV x1, x21                | X1 = 1152921514474379040 (0x100000024C269720);//ML01
        // 0x00B93680: BL #0x20bdbd4              | val_2.Call(methodName:  "finish", args:  null);
        val_2.Call(methodName:  "finish", args:  null);
        // 0x00B93684: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B93688: LDR x8, [x8, #0xa30]       | X8 = 1152921504690233344;               
        // 0x00B9368C: LDR x0, [x8]               | X0 = typeof(UnityEngine.AndroidJavaClass);
        // 0x00B93690: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00B93694: MOV x20, x0                | X20 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B93698: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
        // 0x00B9369C: LDR x8, [x8, #0x958]       | X8 = (string**)(1152921514474379120)("android.os.Process");
        // 0x00B936A0: LDR x1, [x8]               | X1 = "android.os.Process";              
        // 0x00B936A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B936A8: MOV x0, x20                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        UnityEngine.AndroidJavaClass val_14 = null;
        // 0x00B936AC: BL #0x20b9834              | .ctor(className:  "android.os.Process");
        val_14 = new UnityEngine.AndroidJavaClass(className:  "android.os.Process");
        // 0x00B936B0: CBNZ x20, #0xb936b8        | if ( != 0) goto label_49;               
        if(null != 0)
        {
            goto label_49;
        }
        // 0x00B936B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(className:  "android.os.Process"), ????);
        label_49:
        // 0x00B936B8: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00B936BC: LDR x8, [x8, #0xc68]       | X8 = (string**)(1152921514474379232)("myPid");
        // 0x00B936C0: LDR x22, [x26]             | X22 = typeof(System.Object[]);          
        // 0x00B936C4: LDR x21, [x8]              | X21 = "myPid";                          
        // 0x00B936C8: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B936CC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B936D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B936D4: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B936D8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B936DC: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B936E0: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
        // 0x00B936E4: LDR x8, [x8, #0x908]       | X8 = 1152921514474379312;               
        // 0x00B936E8: LDR x3, [x8]               | X3 = public System.Int32 UnityEngine.AndroidJavaObject::CallStatic<System.Int32>(string methodName, object[] args);
        // 0x00B936EC: MOV x0, x20                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B936F0: MOV x1, x21                | X1 = 1152921514474379232 (0x100000024C2697E0);//ML01
        // 0x00B936F4: BL #0x12f5f64              | X0 = CallStatic<System.Int32>(methodName:  "myPid", args:  null);
        int val_15 = CallStatic<System.Int32>(methodName:  "myPid", args:  null);
        // 0x00B936F8: MOV w22, w0                | W22 = val_15;//m1                       
        // 0x00B936FC: LDR x21, [x26]             | X21 = typeof(System.Object[]);          
        // 0x00B93700: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B93704: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B93708: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B9370C: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B93710: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B93714: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B93718: LDR x0, [x28]              | X0 = typeof(System.Int32);              
        // 0x00B9371C: STR w22, [sp, #8]          | stack[1152921514474396392] = val_15;     //  dest_result_addr=1152921514474396392
        // 0x00B93720: ADD x1, sp, #8             | X1 = (1152921514474396384 + 8) = 1152921514474396392 (0x100000024C26DAE8);
        // 0x00B93724: BL #0x27bc028              | X0 = 1152921514474501968 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), val_15);
        // 0x00B93728: MOV x22, x0                | X22 = 1152921514474501968 (0x100000024C287750);//ML01
        // 0x00B9372C: CBNZ x21, #0xb93734        | if ( != null) goto label_50;            
        if(null != null)
        {
            goto label_50;
        }
        // 0x00B93730: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_50:
        // 0x00B93734: CBZ x22, #0xb93758         | if (val_15 == 0) goto label_52;         
        if(val_15 == 0)
        {
            goto label_52;
        }
        // 0x00B93738: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B9373C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B93740: MOV x0, x22                | X0 = 1152921514474501968 (0x100000024C287750);//ML01
        // 0x00B93744: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_15, ????);     
        // 0x00B93748: CBNZ x0, #0xb93758         | if (val_15 != 0) goto label_52;         
        if(val_15 != 0)
        {
            goto label_52;
        }
        // 0x00B9374C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_15, ????);     
        // 0x00B93750: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93754: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
        label_52:
        // 0x00B93758: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B9375C: CBNZ w8, #0xb9376c         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_53;
        // 0x00B93760: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_15, ????);     
        // 0x00B93764: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93768: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
        label_53:
        // 0x00B9376C: STR x22, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_15; typeof(System.Object[]).__il2cppRuntimeField_24 = 0x10000002;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501300
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_15;
        typeof(System.Object[]).__il2cppRuntimeField_24 = 268435458;
        // 0x00B93770: CBNZ x20, #0xb93778        | if ( != 0) goto label_54;               
        if(null != 0)
        {
            goto label_54;
        }
        // 0x00B93774: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_54:
        // 0x00B93778: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
        // 0x00B9377C: LDR x8, [x8, #0xb50]       | X8 = (string**)(1152921514474384432)("killProcess");
        // 0x00B93780: LDR x1, [x8]               | X1 = "killProcess";                     
        // 0x00B93784: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B93788: MOV x0, x20                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B9378C: MOV x2, x21                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B93790: BL #0x20bdcfc              | CallStatic(methodName:  "killProcess", args:  null);
        CallStatic(methodName:  "killProcess", args:  null);
        // 0x00B93794: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
        // 0x00B93798: MOVZ w21, #0x18b           | W21 = 395 (0x18B);//ML01                
        label_62:
        // 0x00B9379C: CBZ x19, #0xb93808         | if ( == 0) goto label_55;               
        if(null == 0)
        {
            goto label_55;
        }
        // 0x00B937A0: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
        // 0x00B937A4: LDR x8, [x19]              | X8 = ;                                  
        UnityEngine.AndroidJavaClass val_18 = null;
        // 0x00B937A8: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
        // 0x00B937AC: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
        // 0x00B937B0: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
        // 0x00B937B4: CBZ x9, #0xb937e0          | if (mem[null + 258] == 0) goto label_56;
        if((mem[null + 258]) == 0)
        {
            goto label_56;
        }
        // 0x00B937B8: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
        var val_16 = mem[null + 152];
        // 0x00B937BC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_17 = 0;
        // 0x00B937C0: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
        val_16 = val_16 + 8;
        label_58:
        // 0x00B937C4: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
        // 0x00B937C8: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
        // 0x00B937CC: B.EQ #0xb937f0             | if ((mem[null + 152] + 8) + -8 == null) goto label_57;
        if(((mem[null + 152] + 8) + -8) == null)
        {
            goto label_57;
        }
        // 0x00B937D0: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_17 = val_17 + 1;
        // 0x00B937D4: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
        val_16 = val_16 + 16;
        // 0x00B937D8: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
        // 0x00B937DC: B.LO #0xb937c4             | if (0 < mem[null + 258]) goto label_58; 
        if(val_17 < (mem[null + 258]))
        {
            goto label_58;
        }
        label_56:
        // 0x00B937E0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B937E4: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        val_16 = val_1;
        // 0x00B937E8: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00B937EC: B #0xb937fc                |  goto label_59;                         
        goto label_59;
        label_57:
        // 0x00B937F0: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
        // 0x00B937F4: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
        val_18 = val_18 + (((mem[null + 152] + 8)) << 4);
        // 0x00B937F8: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
        label_59:
        // 0x00B937FC: LDP x8, x1, [x0]           | X8 = ; X1 = UnityEngine.AndroidJavaClass.__il2cppRuntimeField_gc_desc; //  | 
        // 0x00B93800: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00B93804: BLR x8                     | X0 = x8();                              
        label_55:
        // 0x00B93808: CMP w21, #0x18b            | STATE = COMPARE(0x18B, 0x18B)           
        // 0x00B9380C: B.EQ #0xb93820             | if (0x18B == 0x18B) goto label_61;      
        if(395 == 395)
        {
            goto label_61;
        }
        // 0x00B93810: CBZ x20, #0xb93820         | if (0x0 == 0) goto label_61;            
        if(0 == 0)
        {
            goto label_61;
        }
        // 0x00B93814: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93818: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
        // 0x00B9381C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_61:
        // 0x00B93820: SUB sp, x29, #0x50         | SP = (1152921514474396512 - 80) = 1152921514474396432 (0x100000024C26DB10);
        // 0x00B93824: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B93828: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B9382C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B93830: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B93834: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B93838: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B9383C: RET                        |  return;                                
        return;
        // 0x00B93840: BL #0x981060               | 
        // 0x00B93844: LDR x20, [x0]              | 
        // 0x00B93848: BL #0x980920               | 
        // 0x00B9384C: MOV w21, wzr               | 
        // 0x00B93850: B #0xb9379c                | 
    
    }

}
