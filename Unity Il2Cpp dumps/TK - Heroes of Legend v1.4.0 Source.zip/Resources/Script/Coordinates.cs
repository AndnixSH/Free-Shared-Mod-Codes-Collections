using UnityEngine;
private enum UIAtlas.Coordinates
{
    // Fields
    Pixels = 0
    ,TexCoords = 1
    

}
