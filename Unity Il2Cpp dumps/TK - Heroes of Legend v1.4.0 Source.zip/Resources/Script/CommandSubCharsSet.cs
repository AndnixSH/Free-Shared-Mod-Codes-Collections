using UnityEngine;

namespace SevenZip.CommandLineParser
{
    internal class CommandSubCharsSet
    {
        // Fields
        public string Chars; //  0x00000010
        public bool EmptyAllowed; //  0x00000018
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00CA7878 (13269112), len: 120  VirtAddr: 0x00CA7878 RVA: 0x00CA7878 token: 100681422 methodIndex: 54573 delegateWrapperIndex: 0 methodInvoker: 0
        public CommandSubCharsSet()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x00CA7878: STP x20, x19, [sp, #-0x20]! | stack[1152921513058973584] = ???;  stack[1152921513058973592] = ???;  //  dest_result_addr=1152921513058973584 |  dest_result_addr=1152921513058973592
            // 0x00CA787C: STP x29, x30, [sp, #0x10]  | stack[1152921513058973600] = ???;  stack[1152921513058973608] = ???;  //  dest_result_addr=1152921513058973600 |  dest_result_addr=1152921513058973608
            // 0x00CA7880: ADD x29, sp, #0x10         | X29 = (1152921513058973584 + 16) = 1152921513058973600 (0x10000001F7C937A0);
            // 0x00CA7884: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00CA7888: LDRB w8, [x20, #0xa9]      | W8 = (bool)static_value_037340A9;       
            // 0x00CA788C: MOV x19, x0                | X19 = 1152921513058985616 (0x10000001F7C96690);//ML01
            // 0x00CA7890: TBNZ w8, #0, #0xca78ac     | if (static_value_037340A9 == true) goto label_0;
            // 0x00CA7894: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x00CA7898: LDR x8, [x8, #0xd80]       | X8 = 0x2B92360;                         
            // 0x00CA789C: LDR w0, [x8]               | W0 = 0x1F9D;                            
            // 0x00CA78A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1F9D, ????);     
            // 0x00CA78A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00CA78A8: STRB w8, [x20, #0xa9]      | static_value_037340A9 = true;            //  dest_result_addr=57884841
            label_0:
            // 0x00CA78AC: ADRP x20, #0x35d6000       | X20 = 56451072 (0x35D6000);             
            // 0x00CA78B0: LDR x20, [x20, #0xe38]     | X20 = 1152921504608284672;              
            // 0x00CA78B4: LDR x0, [x20]              | X0 = typeof(System.String);             
            val_1 = null;
            // 0x00CA78B8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00CA78BC: TBZ w8, #0, #0xca78d0      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00CA78C0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00CA78C4: CBNZ w8, #0xca78d0         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00CA78C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            // 0x00CA78CC: LDR x0, [x20]              | X0 = typeof(System.String);             
            val_1 = null;
            label_2:
            // 0x00CA78D0: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
            // 0x00CA78D4: MOV x0, x19                | X0 = 1152921513058985616 (0x10000001F7C96690);//ML01
            // 0x00CA78D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA78DC: LDR x8, [x8]               | X8 = System.String.Empty;               
            // 0x00CA78E0: STR x8, [x19, #0x10]       | this.Chars = System.String.Empty;        //  dest_result_addr=1152921513058985632
            this.Chars = System.String.Empty;
            // 0x00CA78E4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00CA78E8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00CA78EC: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
    
    }

}
