using UnityEngine;

namespace Newtonsoft.Json.Utilities
{
    [System.Runtime.CompilerServices.ExtensionAttribute] // 0x2863298
    internal static class CollectionUtils
    {
        // Methods
        // Generic instance method:
        //
        // file offset: 0x00B6EBE4 VirtAddr: 0x00B6EBE4 -RVA: 0x00B6EBE4 
        // -CollectionUtils.CastValid<object>
        // -CollectionUtils.CastValid<Newtonsoft.Json.Converters.IXmlElement>
        //
        //
        // Offset in libil2cpp.so: 0x00B6EBE4 (11987940), len: 264  VirtAddr: 0x00B6EBE4 RVA: 0x00B6EBE4 token: 100686545 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x28632A8
        public static System.Collections.Generic.IEnumerable<T> CastValid<T>(System.Collections.IEnumerable enumerable)
        {
            //
            // Disasemble & Code
            // 0x00B6EBE4: STP x22, x21, [sp, #-0x30]! | stack[1152921513961689232] = ???;  stack[1152921513961689240] = ???;  //  dest_result_addr=1152921513961689232 |  dest_result_addr=1152921513961689240
            // 0x00B6EBE8: STP x20, x19, [sp, #0x10]  | stack[1152921513961689248] = ???;  stack[1152921513961689256] = ???;  //  dest_result_addr=1152921513961689248 |  dest_result_addr=1152921513961689256
            // 0x00B6EBEC: STP x29, x30, [sp, #0x20]  | stack[1152921513961689264] = ???;  stack[1152921513961689272] = ???;  //  dest_result_addr=1152921513961689264 |  dest_result_addr=1152921513961689272
            // 0x00B6EBF0: ADD x29, sp, #0x20         | X29 = (1152921513961689232 + 32) = 1152921513961689264 (0x100000022D9790B0);
            // 0x00B6EBF4: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00B6EBF8: LDRB w8, [x21, #0x9b7]     | W8 = (bool)static_value_037339B7;       
            // 0x00B6EBFC: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00B6EC00: MOV x20, x1                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x00B6EC04: TBNZ w8, #0, #0xb6ec20     | if (static_value_037339B7 == true) goto label_0;
            // 0x00B6EC08: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
            // 0x00B6EC0C: LDR x8, [x8, #0xac0]       | X8 = 0x2B915DC;                         
            // 0x00B6EC10: LDR w0, [x8]               | W0 = 0x1C3B;                            
            // 0x00B6EC14: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C3B, ????);     
            // 0x00B6EC18: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00B6EC1C: STRB w8, [x21, #0x9b7]     | static_value_037339B7 = true;            //  dest_result_addr=57883063
            label_0:
            // 0x00B6EC20: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
            // 0x00B6EC24: LDR x8, [x8, #0x2b8]       | X8 = (string**)(1152921513961671040)("enumerable");
            // 0x00B6EC28: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B6EC2C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00B6EC30: MOV x1, x20                | X1 = __RuntimeMethodHiddenParam;//m1    
            // 0x00B6EC34: LDR x2, [x8]               | X2 = "enumerable";                      
            // 0x00B6EC38: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  0, parameterName:  __RuntimeMethodHiddenParam);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  0, parameterName:  __RuntimeMethodHiddenParam);
            // 0x00B6EC3C: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
            // 0x00B6EC40: LDR x8, [x8, #0xed0]       | X8 = 1152921513919976368;               
            // 0x00B6EC44: MOV x1, x20                | X1 = __RuntimeMethodHiddenParam;//m1    
            // 0x00B6EC48: LDR x2, [x8]               | X2 = public static System.Collections.Generic.IEnumerable<TResult> System.Linq.Enumerable::Cast<System.Object>(System.Collections.IEnumerable source);
            // 0x00B6EC4C: BL #0xb6ecec               | X0 = System.Linq.Enumerable.Cast<System.Reflection.MemberInfo>(source:  0);
            System.Collections.Generic.IEnumerable<TResult> val_1 = System.Linq.Enumerable.Cast<System.Reflection.MemberInfo>(source:  0);
            // 0x00B6EC50: ADRP x9, #0x3673000        | X9 = 57094144 (0x3673000);              
            // 0x00B6EC54: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
            // 0x00B6EC58: LDR x9, [x9, #0x788]       | X9 = 1152921504688103424;               
            // 0x00B6EC5C: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00B6EC60: LDR x20, [x8]              | X20 = X2 + 48;                          
            // 0x00B6EC64: LDR x8, [x9]               | X8 = typeof(System.Func<T, TResult>);   
            // 0x00B6EC68: MOV x0, x8                 | X0 = 1152921504688103424 (0x1000000004D7E000);//ML01
            System.Func<System.Object, System.Boolean> val_2 = null;
            // 0x00B6EC6C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Func<T, TResult>), ????);
            // 0x00B6EC70: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
            // 0x00B6EC74: LDR x8, [x8, #0x2d8]       | X8 = 1152921513961675232;               
            // 0x00B6EC78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B6EC7C: MOV x2, x20                | X2 = X2 + 48;//m1                       
            // 0x00B6EC80: MOV x22, x0                | X22 = 1152921504688103424 (0x1000000004D7E000);//ML01
            // 0x00B6EC84: LDR x3, [x8]               | X3 = public System.Void System.Func<System.Object, System.Boolean>::.ctor(object object, IntPtr method);
            // 0x00B6EC88: BL #0x21cb02c              | .ctor(object:  0, method:  X2 + 48);    
            val_2 = new System.Func<System.Object, System.Boolean>(object:  0, method:  X2 + 48);
            // 0x00B6EC8C: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
            // 0x00B6EC90: LDR x8, [x8, #0xf28]       | X8 = 1152921513961676256;               
            // 0x00B6EC94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B6EC98: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00B6EC9C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00B6ECA0: LDR x20, [x8]              | X20 = public static System.Collections.Generic.IEnumerable<TSource> System.Linq.Enumerable::Where<System.Object>(System.Collections.Generic.IEnumerable<TSource> source, System.Func<TSource, bool> predicate);
            // 0x00B6ECA4: MOV x2, x22                | X2 = 1152921504688103424 (0x1000000004D7E000);//ML01
            // 0x00B6ECA8: BL #0x26e3488              | System.Linq.Check.SourceAndPredicate(source:  0, predicate:  val_1);
            System.Linq.Check.SourceAndPredicate(source:  0, predicate:  val_1);
            // 0x00B6ECAC: LDR x8, [x20, #0x30]       | X8 = public static System.Collections.Generic.IEnumerable<TSource> System.Linq.Enumerable::Where<System.Object>(System.Collections.Generic.IEnumerable<TSource> source, System.Func<TSource, bool> predicate).__il2cppRuntimeField_30;
            // 0x00B6ECB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B6ECB4: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00B6ECB8: MOV x2, x22                | X2 = 1152921504688103424 (0x1000000004D7E000);//ML01
            // 0x00B6ECBC: LDR x3, [x8]               | X3 = public static System.Collections.Generic.IEnumerable<TSource> System.Linq.Enumerable::Where<System.Object>(System.Collections.Generic.IEnumerable<TSource> source, System.Func<TSource, bool> predicate).__il2cppRuntimeField_30;
            // 0x00B6ECC0: LDR x8, [x3]               | X8 = public static System.Collections.Generic.IEnumerable<TSource> System.Linq.Enumerable::Where<System.Object>(System.Collections.Generic.IEnumerable<TSource> source, System.Func<TSource, bool> predicate).__il2cppRuntimeField_30;
            // 0x00B6ECC4: BLR x8                     | X0 = public static System.Collections.Generic.IEnumerable<TSource> System.Linq.Enumerable::Where<System.Object>(System.Collections.Generic.IEnumerable<TSource> source, System.Func<TSource, bool> predicate).__il2cppRuntimeField_30();
            // 0x00B6ECC8: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
            // 0x00B6ECCC: MOV x1, x0                 | X1 = 0 (0x0);//ML01                     
            // 0x00B6ECD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B6ECD4: LDR x2, [x8, #8]           | X2 = X2 + 48 + 8;                       
            // 0x00B6ECD8: LDR x3, [x2]               | X3 = X2 + 48 + 8;                       
            // 0x00B6ECDC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00B6ECE0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00B6ECE4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00B6ECE8: BR x3                      | goto X2 + 48 + 8;                       
            goto X2 + 48 + 8;
        
        }
        // Generic instance method:
        //
        // file offset: 0x00B7A5A8 VirtAddr: 0x00B7A5A8 -RVA: 0x00B7A5A8 
        // -CollectionUtils.CreateList<object>
        //
        //
        // Offset in libil2cpp.so: 0x00B7A5A8 (12035496), len: 92  VirtAddr: 0x00B7A5A8 RVA: 0x00B7A5A8 token: 100686546 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static System.Collections.Generic.List<T> CreateList<T>(T[] values)
        {
            //
            // Disasemble & Code
            // 0x00B7A5A8: STP x22, x21, [sp, #-0x30]! | stack[1152921513961846288] = ???;  stack[1152921513961846296] = ???;  //  dest_result_addr=1152921513961846288 |  dest_result_addr=1152921513961846296
            // 0x00B7A5AC: STP x20, x19, [sp, #0x10]  | stack[1152921513961846304] = ???;  stack[1152921513961846312] = ???;  //  dest_result_addr=1152921513961846304 |  dest_result_addr=1152921513961846312
            // 0x00B7A5B0: STP x29, x30, [sp, #0x20]  | stack[1152921513961846320] = ???;  stack[1152921513961846328] = ???;  //  dest_result_addr=1152921513961846320 |  dest_result_addr=1152921513961846328
            // 0x00B7A5B4: ADD x29, sp, #0x20         | X29 = (1152921513961846288 + 32) = 1152921513961846320 (0x100000022D99F630);
            // 0x00B7A5B8: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00B7A5BC: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
            // 0x00B7A5C0: MOV x21, x1                | X21 = __RuntimeMethodHiddenParam;//m1   
            // 0x00B7A5C4: LDR x20, [x8]              | X20 = X2 + 48;                          
            // 0x00B7A5C8: MOV x0, x20                | X0 = X2 + 48;//m1                       
            // 0x00B7A5CC: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 48, ????);    
            // 0x00B7A5D0: MOV x0, x20                | X0 = X2 + 48;//m1                       
            // 0x00B7A5D4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X2 + 48, ????);
            // 0x00B7A5D8: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
            // 0x00B7A5DC: MOV x1, x21                | X1 = __RuntimeMethodHiddenParam;//m1    
            // 0x00B7A5E0: MOV x19, x0                | X19 = X2 + 48;//m1                      
            // 0x00B7A5E4: LDR x2, [x8, #8]           | X2 = X2 + 48 + 8;                       
            // 0x00B7A5E8: LDR x8, [x2]               | X8 = X2 + 48 + 8;                       
            // 0x00B7A5EC: BLR x8                     | X0 = X2 + 48 + 8();                     
            // 0x00B7A5F0: MOV x0, x19                | X0 = X2 + 48;//m1                       
            // 0x00B7A5F4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00B7A5F8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00B7A5FC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00B7A600: RET                        |  return (System.Collections.Generic.List<T>)X2 + 48;
            return (System.Collections.Generic.List<T>)X2 + 48;
            //  |  // // {name=val_0, type=System.Collections.Generic.List<T>, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x02911CCC (43064524), len: 188  VirtAddr: 0x02911CCC RVA: 0x02911CCC token: 100686547 methodIndex: 49116 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool IsNullOrEmpty(System.Collections.ICollection collection)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            //  | 
            var val_4;
            // 0x02911CCC: STP x20, x19, [sp, #-0x20]! | stack[1152921513961999264] = ???;  stack[1152921513961999272] = ???;  //  dest_result_addr=1152921513961999264 |  dest_result_addr=1152921513961999272
            // 0x02911CD0: STP x29, x30, [sp, #0x10]  | stack[1152921513961999280] = ???;  stack[1152921513961999288] = ???;  //  dest_result_addr=1152921513961999280 |  dest_result_addr=1152921513961999288
            // 0x02911CD4: ADD x29, sp, #0x10         | X29 = (1152921513961999264 + 16) = 1152921513961999280 (0x100000022D9C4BB0);
            // 0x02911CD8: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x02911CDC: LDRB w8, [x20, #0xaec]     | W8 = (bool)static_value_037B8AEC;       
            // 0x02911CE0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x02911CE4: TBNZ w8, #0, #0x2911d00    | if (static_value_037B8AEC == true) goto label_0;
            // 0x02911CE8: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
            // 0x02911CEC: LDR x8, [x8, #0x128]       | X8 = 0x2B91620;                         
            // 0x02911CF0: LDR w0, [x8]               | W0 = 0x1C4C;                            
            // 0x02911CF4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C4C, ????);     
            // 0x02911CF8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02911CFC: STRB w8, [x20, #0xaec]     | static_value_037B8AEC = true;            //  dest_result_addr=58428140
            label_0:
            // 0x02911D00: CBZ x19, #0x2911d54        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x02911D04: ADRP x9, #0x35db000        | X9 = 56471552 (0x35DB000);              
            // 0x02911D08: LDR x8, [x19]              | X8 = X1;                                
            var val_4 = X1;
            // 0x02911D0C: LDR x9, [x9, #0xd0]        | X9 = 1152921504609296384;               
            // 0x02911D10: LDR x1, [x9]               | X1 = typeof(System.Collections.ICollection);
            // 0x02911D14: LDRH w9, [x8, #0x102]      | W9 = X1 + 258;                          
            // 0x02911D18: CBZ x9, #0x2911d44         | if (X1 + 258 == 0) goto label_2;        
            if((X1 + 258) == 0)
            {
                goto label_2;
            }
            // 0x02911D1C: LDR x10, [x8, #0x98]       | X10 = X1 + 152;                         
            var val_2 = X1 + 152;
            // 0x02911D20: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_3 = 0;
            // 0x02911D24: ADD x10, x10, #8           | X10 = (X1 + 152 + 8);                   
            val_2 = val_2 + 8;
            label_4:
            // 0x02911D28: LDUR x12, [x10, #-8]       | X12 = (X1 + 152 + 8) + -8;              
            // 0x02911D2C: CMP x12, x1                | STATE = COMPARE((X1 + 152 + 8) + -8, typeof(System.Collections.ICollection))
            // 0x02911D30: B.EQ #0x2911d5c            | if ((X1 + 152 + 8) + -8 == null) goto label_3;
            if(((X1 + 152 + 8) + -8) == null)
            {
                goto label_3;
            }
            // 0x02911D34: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_3 = val_3 + 1;
            // 0x02911D38: ADD x10, x10, #0x10        | X10 = ((X1 + 152 + 8) + 16);            
            val_2 = val_2 + 16;
            // 0x02911D3C: CMP x11, x9                | STATE = COMPARE((0 + 1), X1 + 258)      
            // 0x02911D40: B.LO #0x2911d28            | if (0 < X1 + 258) goto label_4;         
            if(val_3 < (X1 + 258))
            {
                goto label_4;
            }
            label_2:
            // 0x02911D44: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x02911D48: MOV x0, x19                | X0 = X1;//m1                            
            val_3 = X1;
            // 0x02911D4C: BL #0x2776c24              | X0 = sub_2776C24( ?? X1, ????);         
            // 0x02911D50: B #0x2911d68               |  goto label_5;                          
            goto label_5;
            label_1:
            // 0x02911D54: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_4 = 1;
            // 0x02911D58: B #0x2911d7c               |  goto label_6;                          
            goto label_6;
            label_3:
            // 0x02911D5C: LDR w9, [x10]              | W9 = (X1 + 152 + 8);                    
            // 0x02911D60: ADD x8, x8, x9, lsl #4     | X8 = (X1 + ((X1 + 152 + 8)) << 4);      
            val_4 = val_4 + (((X1 + 152 + 8)) << 4);
            // 0x02911D64: ADD x0, x8, #0x110         | X0 = ((X1 + ((X1 + 152 + 8)) << 4) + 272);
            val_3 = val_4 + 272;
            label_5:
            // 0x02911D68: LDP x8, x1, [x0]           | X8 = ((X1 + ((X1 + 152 + 8)) << 4) + 272); X1 = ((X1 + ((X1 + 152 + 8)) << 4) + 272) + 8; //  | 
            // 0x02911D6C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x02911D70: BLR x8                     | X0 = ((X1 + ((X1 + 152 + 8)) << 4) + 272)();
            // 0x02911D74: CMP w0, #0                 | STATE = COMPARE(X1, 0x0)                
            // 0x02911D78: CSET w0, eq                | W0 = X1 == 0x0 ? 1 : 0;                 
            var val_1 = (X1 == 0) ? 1 : 0;
            label_6:
            // 0x02911D7C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x02911D80: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x02911D84: RET                        |  return (System.Boolean)X1 == 0x0 ? 1 : 0;
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x012F9E34 VirtAddr: 0x012F9E34 -RVA: 0x012F9E34 
        // -CollectionUtils.IsNullOrEmpty<object>
        // -CollectionUtils.IsNullOrEmpty<Newtonsoft.Json.Converters.IXmlNode>
        // -CollectionUtils.IsNullOrEmpty<Newtonsoft.Json.JsonConverter>
        // -CollectionUtils.IsNullOrEmpty<Newtonsoft.Json.Schema.JsonSchemaModel>
        // -CollectionUtils.IsNullOrEmpty<Newtonsoft.Json.Schema.JsonSchema>
        // -CollectionUtils.IsNullOrEmpty<System.Reflection.ParameterInfo>
        //
        //
        // Offset in libil2cpp.so: 0x012F9E34 (19897908), len: 160  VirtAddr: 0x012F9E34 RVA: 0x012F9E34 token: 100686548 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool IsNullOrEmpty<T>(System.Collections.Generic.ICollection<T> collection)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            //  | 
            var val_4;
            // 0x012F9E34: STP x20, x19, [sp, #-0x20]! | stack[1152921513962119456] = ???;  stack[1152921513962119464] = ???;  //  dest_result_addr=1152921513962119456 |  dest_result_addr=1152921513962119464
            // 0x012F9E38: STP x29, x30, [sp, #0x10]  | stack[1152921513962119472] = ???;  stack[1152921513962119480] = ???;  //  dest_result_addr=1152921513962119472 |  dest_result_addr=1152921513962119480
            // 0x012F9E3C: ADD x29, sp, #0x10         | X29 = (1152921513962119456 + 16) = 1152921513962119472 (0x100000022D9E2130);
            // 0x012F9E40: MOV x19, x1                | X19 = __RuntimeMethodHiddenParam;//m1   
            // 0x012F9E44: CBZ x19, #0x12f9ea0        | if (__RuntimeMethodHiddenParam == 0) goto label_0;
            if(__RuntimeMethodHiddenParam == 0)
            {
                goto label_0;
            }
            // 0x012F9E48: LDR x8, [x2, #0x30]        | X8 = X2 + 48;                           
            // 0x012F9E4C: LDR x20, [x8]              | X20 = X2 + 48;                          
            // 0x012F9E50: MOV x0, x20                | X0 = X2 + 48;//m1                       
            // 0x012F9E54: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 48, ????);    
            // 0x012F9E58: LDR x8, [x19]              | X8 = __RuntimeMethodHiddenParam;        
            var val_4 = __RuntimeMethodHiddenParam;
            // 0x012F9E5C: LDRH w9, [x8, #0x102]      | W9 = __RuntimeMethodHiddenParam + 258;  
            // 0x012F9E60: CBZ x9, #0x12f9e8c         | if (__RuntimeMethodHiddenParam + 258 == 0) goto label_1;
            if((__RuntimeMethodHiddenParam + 258) == 0)
            {
                goto label_1;
            }
            // 0x012F9E64: LDR x10, [x8, #0x98]       | X10 = __RuntimeMethodHiddenParam + 152; 
            var val_2 = __RuntimeMethodHiddenParam + 152;
            // 0x012F9E68: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_3 = 0;
            // 0x012F9E6C: ADD x10, x10, #8           | X10 = (__RuntimeMethodHiddenParam + 152 + 8);
            val_2 = val_2 + 8;
            label_3:
            // 0x012F9E70: LDUR x12, [x10, #-8]       | X12 = (__RuntimeMethodHiddenParam + 152 + 8) + -8;
            // 0x012F9E74: CMP x12, x20               | STATE = COMPARE((__RuntimeMethodHiddenParam + 152 + 8) + -8, X2 + 48)
            // 0x012F9E78: B.EQ #0x12f9ea8            | if ((__RuntimeMethodHiddenParam + 152 + 8) + -8 == X2 + 48) goto label_2;
            if(((__RuntimeMethodHiddenParam + 152 + 8) + -8) == (X2 + 48))
            {
                goto label_2;
            }
            // 0x012F9E7C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_3 = val_3 + 1;
            // 0x012F9E80: ADD x10, x10, #0x10        | X10 = ((__RuntimeMethodHiddenParam + 152 + 8) + 16);
            val_2 = val_2 + 16;
            // 0x012F9E84: CMP x11, x9                | STATE = COMPARE((0 + 1), __RuntimeMethodHiddenParam + 258)
            // 0x012F9E88: B.LO #0x12f9e70            | if (0 < __RuntimeMethodHiddenParam + 258) goto label_3;
            if(val_3 < (__RuntimeMethodHiddenParam + 258))
            {
                goto label_3;
            }
            label_1:
            // 0x012F9E8C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x012F9E90: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam;//m1    
            val_3 = __RuntimeMethodHiddenParam;
            // 0x012F9E94: MOV x1, x20                | X1 = X2 + 48;//m1                       
            // 0x012F9E98: BL #0x2776c24              | X0 = sub_2776C24( ?? __RuntimeMethodHiddenParam, ????);
            // 0x012F9E9C: B #0x12f9eb4               |  goto label_4;                          
            goto label_4;
            label_0:
            // 0x012F9EA0: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_4 = 1;
            // 0x012F9EA4: B #0x12f9ec8               |  goto label_5;                          
            goto label_5;
            label_2:
            // 0x012F9EA8: LDR w9, [x10]              | W9 = (__RuntimeMethodHiddenParam + 152 + 8);
            // 0x012F9EAC: ADD x8, x8, x9, lsl #4     | X8 = (__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4);
            val_4 = val_4 + (((__RuntimeMethodHiddenParam + 152 + 8)) << 4);
            // 0x012F9EB0: ADD x0, x8, #0x110         | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272);
            val_3 = val_4 + 272;
            label_4:
            // 0x012F9EB4: LDP x8, x1, [x0]           | X8 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272); X1 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272) + 8; //  | 
            // 0x012F9EB8: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam;//m1    
            // 0x012F9EBC: BLR x8                     | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272)();
            // 0x012F9EC0: CMP w0, #0                 | STATE = COMPARE(__RuntimeMethodHiddenParam, 0x0)
            // 0x012F9EC4: CSET w0, eq                | W0 = __RuntimeMethodHiddenParam == 0x0 ? 1 : 0;
            var val_1 = (__RuntimeMethodHiddenParam == 0) ? 1 : 0;
            label_5:
            // 0x012F9EC8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x012F9ECC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x012F9ED0: RET                        |  return (System.Boolean)__RuntimeMethodHiddenParam == 0x0 ? 1 : 0;
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x012F9ED4 VirtAddr: 0x012F9ED4 -RVA: 0x012F9ED4 
        // -CollectionUtils.IsNullOrEmptyOrDefault<object>
        //
        //
        // Offset in libil2cpp.so: 0x012F9ED4 (19898068), len: 96  VirtAddr: 0x012F9ED4 RVA: 0x012F9ED4 token: 100686549 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool IsNullOrEmptyOrDefault<T>(System.Collections.Generic.IList<T> list)
        {
            //
            // Disasemble & Code
            // 0x012F9ED4: STP x20, x19, [sp, #-0x20]! | stack[1152921513962239648] = ???;  stack[1152921513962239656] = ???;  //  dest_result_addr=1152921513962239648 |  dest_result_addr=1152921513962239656
            // 0x012F9ED8: STP x29, x30, [sp, #0x10]  | stack[1152921513962239664] = ???;  stack[1152921513962239672] = ???;  //  dest_result_addr=1152921513962239664 |  dest_result_addr=1152921513962239672
            // 0x012F9EDC: ADD x29, sp, #0x10         | X29 = (1152921513962239648 + 16) = 1152921513962239664 (0x100000022D9FF6B0);
            // 0x012F9EE0: MOV x19, x2                | X19 = X2;//m1                           
            // 0x012F9EE4: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
            // 0x012F9EE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x012F9EEC: MOV x20, x1                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x012F9EF0: LDR x2, [x8]               | X2 = X2 + 48;                           
            // 0x012F9EF4: LDR x8, [x2]               | X8 = X2 + 48;                           
            // 0x012F9EF8: BLR x8                     | X0 = X2 + 48();                         
            // 0x012F9EFC: AND w8, w0, #1             | W8 = (0 & 1) = 0 (0x00000000);          
            // 0x012F9F00: TBZ w8, #0, #0x12f9f14     | if ((0x0 & 0x1) == 0) goto label_0;     
            if((0 & 1) == 0)
            {
                goto label_0;
            }
            // 0x012F9F04: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x012F9F08: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            // 0x012F9F0C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x012F9F10: RET                        |  return (System.Boolean)true;           
            return (bool)1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_0:
            // 0x012F9F14: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
            // 0x012F9F18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x012F9F1C: MOV x1, x20                | X1 = __RuntimeMethodHiddenParam;//m1    
            // 0x012F9F20: LDR x2, [x8, #8]           | X2 = X2 + 48 + 8;                       
            // 0x012F9F24: LDR x3, [x2]               | X3 = X2 + 48 + 8;                       
            // 0x012F9F28: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x012F9F2C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x012F9F30: BR x3                      | goto X2 + 48 + 8;                       
            goto X2 + 48 + 8;
        
        }
        // Generic instance method:
        //
        // file offset: 0x00B7943C VirtAddr: 0x00B7943C -RVA: 0x00B7943C 
        // -CollectionUtils.Slice<object>
        //
        //
        // Offset in libil2cpp.so: 0x00B7943C (12031036), len: 24  VirtAddr: 0x00B7943C RVA: 0x00B7943C token: 100686550 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static System.Collections.Generic.IList<T> Slice<T>(System.Collections.Generic.IList<T> list, System.Nullable<int> start, System.Nullable<int> end)
        {
            //
            // Disasemble & Code
            // 0x00B7943C: LDR x8, [x4, #0x30]        | X8 = X4 + 48;                           
            // 0x00B79440: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B79444: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00B79448: LDR x5, [x8]               | X5 = X4 + 48;                           
            // 0x00B7944C: LDR x6, [x5]               | X6 = X4 + 48;                           
            // 0x00B79450: BR x6                      | goto X4 + 48;                           
            goto X4 + 48;
        
        }
        // Generic instance method:
        //
        // file offset: 0x00B79454 VirtAddr: 0x00B79454 -RVA: 0x00B79454 
        // -CollectionUtils.Slice<object>
        //
        //
        // Offset in libil2cpp.so: 0x00B79454 (12031060), len: 1280  VirtAddr: 0x00B79454 RVA: 0x00B79454 token: 100686551 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static System.Collections.Generic.IList<T> Slice<T>(System.Collections.Generic.IList<T> list, System.Nullable<int> start, System.Nullable<int> end, System.Nullable<int> step)
        {
            //
            // Disasemble & Code
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            int val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            int val_20;
            //  | 
            var val_21;
            //  | 
            var val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            //  | 
            int val_25;
            //  | 
            var val_26;
            //  | 
            var val_27;
            //  | 
            var val_28;
            //  | 
            var val_29;
            //  | 
            string val_30;
            //  | 
            System.Collections.Generic.IList<T> val_31;
            // 0x00B79454: STP x26, x25, [sp, #-0x50]! | stack[1152921513962485296] = ???;  stack[1152921513962485304] = ???;  //  dest_result_addr=1152921513962485296 |  dest_result_addr=1152921513962485304
            // 0x00B79458: STP x24, x23, [sp, #0x10]  | stack[1152921513962485312] = ???;  stack[1152921513962485320] = ???;  //  dest_result_addr=1152921513962485312 |  dest_result_addr=1152921513962485320
            // 0x00B7945C: STP x22, x21, [sp, #0x20]  | stack[1152921513962485328] = ???;  stack[1152921513962485336] = ???;  //  dest_result_addr=1152921513962485328 |  dest_result_addr=1152921513962485336
            // 0x00B79460: STP x20, x19, [sp, #0x30]  | stack[1152921513962485344] = ???;  stack[1152921513962485352] = ???;  //  dest_result_addr=1152921513962485344 |  dest_result_addr=1152921513962485352
            // 0x00B79464: STP x29, x30, [sp, #0x40]  | stack[1152921513962485360] = ???;  stack[1152921513962485368] = ???;  //  dest_result_addr=1152921513962485360 |  dest_result_addr=1152921513962485368
            // 0x00B79468: ADD x29, sp, #0x40         | X29 = (1152921513962485296 + 64) = 1152921513962485360 (0x100000022DA3B670);
            // 0x00B7946C: SUB sp, sp, #0x20          | SP = (1152921513962485296 - 32) = 1152921513962485264 (0x100000022DA3B610);
            // 0x00B79470: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00B79474: LDRB w8, [x21, #0x9bc]     | W8 = (bool)static_value_037339BC;       
            // 0x00B79478: MOV x19, x5                | X19 = X5;//m1                           
            // 0x00B7947C: MOV x20, x1                | X20 = start.HasValue;//m1               
            // 0x00B79480: STP x3, x2, [sp, #0x10]    | stack[1152921513962485280] = step.HasValue;  stack[1152921513962485288] = end.HasValue;  //  dest_result_addr=1152921513962485280 |  dest_result_addr=1152921513962485288
            // 0x00B79484: STR x4, [sp, #8]           | stack[1152921513962485272] = __RuntimeMethodHiddenParam;  //  dest_result_addr=1152921513962485272
            // 0x00B79488: TBNZ w8, #0, #0xb794a4     | if (static_value_037339BC == true) goto label_0;
            // 0x00B7948C: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
            // 0x00B79490: LDR x8, [x8, #0xa48]       | X8 = 0x2B91628;                         
            // 0x00B79494: LDR w0, [x8]               | W0 = 0x1C4E;                            
            // 0x00B79498: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C4E, ????);     
            // 0x00B7949C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00B794A0: STRB w8, [x21, #0x9bc]     | static_value_037339BC = true;            //  dest_result_addr=57883068
            label_0:
            // 0x00B794A4: CBZ x20, #0xb798dc         | if (start.HasValue == false) goto label_1;
            if(start.HasValue == false)
            {
                goto label_1;
            }
            // 0x00B794A8: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
            // 0x00B794AC: LDR x8, [x8, #0xdb0]       | X8 = 1152921509457530416;               
            // 0x00B794B0: ADD x0, sp, #8             | X0 = (1152921513962485264 + 8) = 1152921513962485272 (0x100000022DA3B618);
            // 0x00B794B4: LDR x1, [x8]               | X1 = public System.Int32 System.Nullable<System.Int32>::GetValueOrDefault();
            // 0x00B794B8: BL #0x1d6c58c              | X0 = sub_1D6C58C( ?? 0x100000022DA3B618, ????);
            // 0x00B794BC: CBNZ w0, #0xb794d8         | if (__RuntimeMethodHiddenParam != 0) goto label_2;
            if(__RuntimeMethodHiddenParam != 0)
            {
                goto label_2;
            }
            // 0x00B794C0: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x00B794C4: LDR x8, [x8, #0x908]       | X8 = 1152921509457529392;               
            // 0x00B794C8: ADD x0, sp, #8             | X0 = (1152921513962485264 + 8) = 1152921513962485272 (0x100000022DA3B618);
            // 0x00B794CC: LDR x1, [x8]               | X1 = public System.Boolean System.Nullable<System.Int32>::get_HasValue();
            // 0x00B794D0: BL #0x1d6c184              | X0 = sub_1D6C184( ?? 0x100000022DA3B618, ????);
            // 0x00B794D4: TBNZ w0, #0, #0xb79908     | if ((0x100000022DA3B618 & 0x1) != 0) goto label_3;
            if((765703704 & 1) != 0)
            {
                goto label_3;
            }
            label_2:
            // 0x00B794D8: LDR x8, [x19, #0x30]       | X8 = X5 + 48;                           
            // 0x00B794DC: LDR x21, [x8]              | X21 = X5 + 48;                          
            // 0x00B794E0: MOV x0, x21                | X0 = X5 + 48;//m1                       
            // 0x00B794E4: BL #0x277461c              | X0 = sub_277461C( ?? X5 + 48, ????);    
            // 0x00B794E8: MOV x0, x21                | X0 = X5 + 48;//m1                       
            // 0x00B794EC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X5 + 48, ????);
            // 0x00B794F0: LDR x8, [x19, #0x30]       | X8 = X5 + 48;                           
            // 0x00B794F4: MOV x21, x0                | X21 = X5 + 48;//m1                      
            // 0x00B794F8: LDR x1, [x8, #8]           | X1 = X5 + 48 + 8;                       
            val_13 = mem[X5 + 48 + 8];
            val_13 = X5 + 48 + 8;
            // 0x00B794FC: LDR x8, [x1]               | X8 = X5 + 48 + 8;                       
            // 0x00B79500: BLR x8                     | X0 = X5 + 48 + 8();                     
            // 0x00B79504: LDR x8, [x19, #0x30]       | X8 = X5 + 48;                           
            // 0x00B79508: LDR x22, [x8, #0x10]       | X22 = X5 + 48 + 16;                     
            // 0x00B7950C: MOV x0, x22                | X0 = X5 + 48 + 16;//m1                  
            // 0x00B79510: BL #0x277461c              | X0 = sub_277461C( ?? X5 + 48 + 16, ????);
            // 0x00B79514: LDR x8, [x20]              | X8 = start.HasValue;                    
            var val_8 = start.HasValue;
            // 0x00B79518: LDRH w9, [x8, #0x102]      | W9 = start.HasValue + 258;              
            // 0x00B7951C: CBZ x9, #0xb79548          | if (start.HasValue + 258 == 0) goto label_4;
            if((start.HasValue + 258) == 0)
            {
                goto label_4;
            }
            // 0x00B79520: LDR x10, [x8, #0x98]       | X10 = start.HasValue + 152;             
            var val_6 = start.HasValue + 152;
            // 0x00B79524: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_7 = 0;
            // 0x00B79528: ADD x10, x10, #8           | X10 = (start.HasValue + 152 + 8);       
            val_6 = val_6 + 8;
            label_6:
            // 0x00B7952C: LDUR x12, [x10, #-8]       | X12 = (start.HasValue + 152 + 8) + -8;  
            // 0x00B79530: CMP x12, x22               | STATE = COMPARE((start.HasValue + 152 + 8) + -8, X5 + 48 + 16)
            // 0x00B79534: B.EQ #0xb7955c             | if ((start.HasValue + 152 + 8) + -8 == X5 + 48 + 16) goto label_5;
            if(((start.HasValue + 152 + 8) + -8) == (X5 + 48 + 16))
            {
                goto label_5;
            }
            // 0x00B79538: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_7 = val_7 + 1;
            // 0x00B7953C: ADD x10, x10, #0x10        | X10 = ((start.HasValue + 152 + 8) + 16);
            val_6 = val_6 + 16;
            // 0x00B79540: CMP x11, x9                | STATE = COMPARE((0 + 1), start.HasValue + 258)
            // 0x00B79544: B.LO #0xb7952c             | if (0 < start.HasValue + 258) goto label_6;
            if(val_7 < (start.HasValue + 258))
            {
                goto label_6;
            }
            label_4:
            // 0x00B79548: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B7954C: MOV x0, x20                | X0 = start.HasValue;//m1                
            val_14 = start.HasValue;
            // 0x00B79550: MOV x1, x22                | X1 = X5 + 48 + 16;//m1                  
            val_13 = X5 + 48 + 16;
            // 0x00B79554: BL #0x2776c24              | X0 = sub_2776C24( ?? start.HasValue, ????);
            // 0x00B79558: B #0xb79568                |  goto label_7;                          
            goto label_7;
            label_5:
            // 0x00B7955C: LDR w9, [x10]              | W9 = (start.HasValue + 152 + 8);        
            // 0x00B79560: ADD x8, x8, x9, lsl #4     | X8 = (start.HasValue + ((start.HasValue + 152 + 8)) << 4);
            val_8 = val_8 + (((start.HasValue + 152 + 8)) << 4);
            // 0x00B79564: ADD x0, x8, #0x110         | X0 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272);
            val_14 = val_8 + 272;
            label_7:
            // 0x00B79568: LDP x8, x1, [x0]           | X8 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272); X1 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272) + 8; //  | 
            // 0x00B7956C: MOV x0, x20                | X0 = start.HasValue;//m1                
            // 0x00B79570: BLR x8                     | X0 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272)();
            // 0x00B79574: CBZ w0, #0xb798bc          | if (start.HasValue == false) goto label_34;
            if(start.HasValue == false)
            {
                goto label_34;
            }
            // 0x00B79578: ADRP x24, #0x367f000       | X24 = 57143296 (0x367F000);             
            // 0x00B7957C: LDR x24, [x24, #0x908]     | X24 = 1152921509457529392;              
            // 0x00B79580: ADD x0, sp, #8             | X0 = (1152921513962485264 + 8) = 1152921513962485272 (0x100000022DA3B618);
            // 0x00B79584: LDR x1, [x24]              | X1 = public System.Boolean System.Nullable<System.Int32>::get_HasValue();
            // 0x00B79588: BL #0x1d6c184              | X0 = sub_1D6C184( ?? 0x100000022DA3B618, ????);
            // 0x00B7958C: TBZ w0, #0, #0xb795ac      | if ((0x100000022DA3B618 & 0x1) == 0) goto label_9;
            if((765703704 & 1) == 0)
            {
                goto label_9;
            }
            // 0x00B79590: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x00B79594: LDR x8, [x8, #0x3b8]       | X8 = 1152921509577802208;               
            // 0x00B79598: ADD x0, sp, #8             | X0 = (1152921513962485264 + 8) = 1152921513962485272 (0x100000022DA3B618);
            // 0x00B7959C: LDR x1, [x8]               | X1 = public System.Int32 System.Nullable<System.Int32>::get_Value();
            // 0x00B795A0: BL #0x1d6c1b0              | X0 = sub_1D6C1B0( ?? 0x100000022DA3B618, ????);
            // 0x00B795A4: MOV w22, w0                | W22 = 1152921513962485272 (0x100000022DA3B618);//ML01
            // 0x00B795A8: B #0xb795b0                |  goto label_10;                         
            goto label_10;
            label_9:
            // 0x00B795AC: ORR w22, wzr, #1           | W22 = 1(0x1);                           
            label_10:
            // 0x00B795B0: LDR x1, [x24]              | X1 = public System.Boolean System.Nullable<System.Int32>::get_HasValue();
            // 0x00B795B4: ADD x0, sp, #0x18          | X0 = (1152921513962485264 + 24) = 1152921513962485288 (0x100000022DA3B628);
            // 0x00B795B8: BL #0x1d6c184              | X0 = sub_1D6C184( ?? 0x100000022DA3B628, ????);
            // 0x00B795BC: TBZ w0, #0, #0xb795dc      | if ((0x100000022DA3B628 & 0x1) == 0) goto label_11;
            if((765703720 & 1) == 0)
            {
                goto label_11;
            }
            // 0x00B795C0: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x00B795C4: LDR x8, [x8, #0x3b8]       | X8 = 1152921509577802208;               
            // 0x00B795C8: ADD x0, sp, #0x18          | X0 = (1152921513962485264 + 24) = 1152921513962485288 (0x100000022DA3B628);
            // 0x00B795CC: LDR x1, [x8]               | X1 = public System.Int32 System.Nullable<System.Int32>::get_Value();
            // 0x00B795D0: BL #0x1d6c1b0              | X0 = sub_1D6C1B0( ?? 0x100000022DA3B628, ????);
            // 0x00B795D4: MOV w23, w0                | W23 = 1152921513962485288 (0x100000022DA3B628);//ML01
            val_15;
            // 0x00B795D8: B #0xb795e0                |  goto label_12;                         
            goto label_12;
            label_11:
            // 0x00B795DC: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_12:
            // 0x00B795E0: LDR x1, [x24]              | X1 = public System.Boolean System.Nullable<System.Int32>::get_HasValue();
            val_16 = public System.Boolean System.Nullable<System.Int32>::get_HasValue();
            // 0x00B795E4: ADD x0, sp, #0x10          | X0 = (1152921513962485264 + 16) = 1152921513962485280 (0x100000022DA3B620);
            // 0x00B795E8: BL #0x1d6c184              | X0 = sub_1D6C184( ?? 0x100000022DA3B620, ????);
            // 0x00B795EC: TBZ w0, #0, #0xb79608      | if ((0x100000022DA3B620 & 0x1) == 0) goto label_13;
            if((765703712 & 1) == 0)
            {
                goto label_13;
            }
            // 0x00B795F0: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x00B795F4: LDR x8, [x8, #0x3b8]       | X8 = 1152921509577802208;               
            // 0x00B795F8: ADD x0, sp, #0x10          | X0 = (1152921513962485264 + 16) = 1152921513962485280 (0x100000022DA3B620);
            // 0x00B795FC: LDR x1, [x8]               | X1 = public System.Int32 System.Nullable<System.Int32>::get_Value();
            val_18 = public System.Int32 System.Nullable<System.Int32>::get_Value();
            // 0x00B79600: BL #0x1d6c1b0              | X0 = sub_1D6C1B0( ?? 0x100000022DA3B620, ????);
            // 0x00B79604: B #0xb79678                |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x00B79608: LDR x8, [x19, #0x30]       | X8 = X5 + 48;                           
            // 0x00B7960C: LDR x24, [x8, #0x10]       | X24 = X5 + 48 + 16;                     
            // 0x00B79610: MOV x0, x24                | X0 = X5 + 48 + 16;//m1                  
            // 0x00B79614: BL #0x277461c              | X0 = sub_277461C( ?? X5 + 48 + 16, ????);
            // 0x00B79618: LDR x8, [x20]              | X8 = start.HasValue;                    
            var val_11 = start.HasValue;
            // 0x00B7961C: LDRH w9, [x8, #0x102]      | W9 = start.HasValue + 258;              
            // 0x00B79620: CBZ x9, #0xb7964c          | if (start.HasValue + 258 == 0) goto label_15;
            if((start.HasValue + 258) == 0)
            {
                goto label_15;
            }
            // 0x00B79624: LDR x10, [x8, #0x98]       | X10 = start.HasValue + 152;             
            var val_9 = start.HasValue + 152;
            // 0x00B79628: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_10 = 0;
            // 0x00B7962C: ADD x10, x10, #8           | X10 = (start.HasValue + 152 + 8);       
            val_9 = val_9 + 8;
            label_17:
            // 0x00B79630: LDUR x12, [x10, #-8]       | X12 = (start.HasValue + 152 + 8) + -8;  
            // 0x00B79634: CMP x12, x24               | STATE = COMPARE((start.HasValue + 152 + 8) + -8, X5 + 48 + 16)
            // 0x00B79638: B.EQ #0xb79660             | if ((start.HasValue + 152 + 8) + -8 == X5 + 48 + 16) goto label_16;
            if(((start.HasValue + 152 + 8) + -8) == (X5 + 48 + 16))
            {
                goto label_16;
            }
            // 0x00B7963C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_10 = val_10 + 1;
            // 0x00B79640: ADD x10, x10, #0x10        | X10 = ((start.HasValue + 152 + 8) + 16);
            val_9 = val_9 + 16;
            // 0x00B79644: CMP x11, x9                | STATE = COMPARE((0 + 1), start.HasValue + 258)
            // 0x00B79648: B.LO #0xb79630             | if (0 < start.HasValue + 258) goto label_17;
            if(val_10 < (start.HasValue + 258))
            {
                goto label_17;
            }
            label_15:
            // 0x00B7964C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B79650: MOV x0, x20                | X0 = start.HasValue;//m1                
            val_19 = start.HasValue;
            // 0x00B79654: MOV x1, x24                | X1 = X5 + 48 + 16;//m1                  
            val_16 = X5 + 48 + 16;
            // 0x00B79658: BL #0x2776c24              | X0 = sub_2776C24( ?? start.HasValue, ????);
            // 0x00B7965C: B #0xb7966c                |  goto label_18;                         
            goto label_18;
            label_16:
            // 0x00B79660: LDR w9, [x10]              | W9 = (start.HasValue + 152 + 8);        
            // 0x00B79664: ADD x8, x8, x9, lsl #4     | X8 = (start.HasValue + ((start.HasValue + 152 + 8)) << 4);
            val_11 = val_11 + (((start.HasValue + 152 + 8)) << 4);
            // 0x00B79668: ADD x0, x8, #0x110         | X0 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272);
            val_19 = val_11 + 272;
            label_18:
            // 0x00B7966C: LDP x8, x1, [x0]           | X8 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272); X1 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272) + 8; //  | 
            val_18 = mem[((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272) + 8];
            val_18 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272) + 8;
            // 0x00B79670: MOV x0, x20                | X0 = start.HasValue;//m1                
            val_17 = start.HasValue;
            // 0x00B79674: BLR x8                     | X0 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272)();
            label_14:
            // 0x00B79678: MOV w24, w0                | W24 = start.HasValue;//m1               
            val_20 = val_17;
            // 0x00B7967C: TBZ w23, #0x1f, #0xb796f4  | if ((0x0 & 0x80000000) == 0) goto label_19;
            if((val_15 & 2147483648) == 0)
            {
                goto label_19;
            }
            // 0x00B79680: LDR x8, [x19, #0x30]       | X8 = X5 + 48;                           
            // 0x00B79684: LDR x25, [x8, #0x10]       | X25 = X5 + 48 + 16;                     
            // 0x00B79688: MOV x0, x25                | X0 = X5 + 48 + 16;//m1                  
            // 0x00B7968C: BL #0x277461c              | X0 = sub_277461C( ?? X5 + 48 + 16, ????);
            // 0x00B79690: LDR x8, [x20]              | X8 = start.HasValue;                    
            var val_14 = start.HasValue;
            // 0x00B79694: LDRH w9, [x8, #0x102]      | W9 = start.HasValue + 258;              
            // 0x00B79698: CBZ x9, #0xb796c4          | if (start.HasValue + 258 == 0) goto label_20;
            if((start.HasValue + 258) == 0)
            {
                goto label_20;
            }
            // 0x00B7969C: LDR x10, [x8, #0x98]       | X10 = start.HasValue + 152;             
            var val_12 = start.HasValue + 152;
            // 0x00B796A0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_13 = 0;
            // 0x00B796A4: ADD x10, x10, #8           | X10 = (start.HasValue + 152 + 8);       
            val_12 = val_12 + 8;
            label_22:
            // 0x00B796A8: LDUR x12, [x10, #-8]       | X12 = (start.HasValue + 152 + 8) + -8;  
            // 0x00B796AC: CMP x12, x25               | STATE = COMPARE((start.HasValue + 152 + 8) + -8, X5 + 48 + 16)
            // 0x00B796B0: B.EQ #0xb796d8             | if ((start.HasValue + 152 + 8) + -8 == X5 + 48 + 16) goto label_21;
            if(((start.HasValue + 152 + 8) + -8) == (X5 + 48 + 16))
            {
                goto label_21;
            }
            // 0x00B796B4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_13 = val_13 + 1;
            // 0x00B796B8: ADD x10, x10, #0x10        | X10 = ((start.HasValue + 152 + 8) + 16);
            val_12 = val_12 + 16;
            // 0x00B796BC: CMP x11, x9                | STATE = COMPARE((0 + 1), start.HasValue + 258)
            // 0x00B796C0: B.LO #0xb796a8             | if (0 < start.HasValue + 258) goto label_22;
            if(val_13 < (start.HasValue + 258))
            {
                goto label_22;
            }
            label_20:
            // 0x00B796C4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B796C8: MOV x0, x20                | X0 = start.HasValue;//m1                
            val_21 = start.HasValue;
            // 0x00B796CC: MOV x1, x25                | X1 = X5 + 48 + 16;//m1                  
            val_22 = X5 + 48 + 16;
            // 0x00B796D0: BL #0x2776c24              | X0 = sub_2776C24( ?? start.HasValue, ????);
            // 0x00B796D4: B #0xb796e4                |  goto label_23;                         
            goto label_23;
            label_21:
            // 0x00B796D8: LDR w9, [x10]              | W9 = (start.HasValue + 152 + 8);        
            // 0x00B796DC: ADD x8, x8, x9, lsl #4     | X8 = (start.HasValue + ((start.HasValue + 152 + 8)) << 4);
            val_14 = val_14 + (((start.HasValue + 152 + 8)) << 4);
            // 0x00B796E0: ADD x0, x8, #0x110         | X0 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272);
            val_21 = val_14 + 272;
            label_23:
            // 0x00B796E4: LDP x8, x1, [x0]           | X8 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272); X1 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272) + 8; //  | 
            val_23 = mem[((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272) + 8];
            val_23 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272) + 8;
            // 0x00B796E8: MOV x0, x20                | X0 = start.HasValue;//m1                
            // 0x00B796EC: BLR x8                     | X0 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272)();
            // 0x00B796F0: ADD w23, w0, w23           | W23 = (start.HasValue + val_15);        
            val_15 = start.HasValue + val_15;
            label_19:
            // 0x00B796F4: TBZ w24, #0x1f, #0xb7976c  | if ((start.HasValue & 0x80000000) == 0) goto label_24;
            if((val_20 & 2147483648) == 0)
            {
                goto label_24;
            }
            // 0x00B796F8: LDR x8, [x19, #0x30]       | X8 = X5 + 48;                           
            // 0x00B796FC: LDR x25, [x8, #0x10]       | X25 = X5 + 48 + 16;                     
            // 0x00B79700: MOV x0, x25                | X0 = X5 + 48 + 16;//m1                  
            // 0x00B79704: BL #0x277461c              | X0 = sub_277461C( ?? X5 + 48 + 16, ????);
            // 0x00B79708: LDR x8, [x20]              | X8 = start.HasValue;                    
            var val_17 = start.HasValue;
            // 0x00B7970C: LDRH w9, [x8, #0x102]      | W9 = start.HasValue + 258;              
            // 0x00B79710: CBZ x9, #0xb7973c          | if (start.HasValue + 258 == 0) goto label_25;
            if((start.HasValue + 258) == 0)
            {
                goto label_25;
            }
            // 0x00B79714: LDR x10, [x8, #0x98]       | X10 = start.HasValue + 152;             
            var val_15 = start.HasValue + 152;
            // 0x00B79718: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_16 = 0;
            // 0x00B7971C: ADD x10, x10, #8           | X10 = (start.HasValue + 152 + 8);       
            val_15 = val_15 + 8;
            label_27:
            // 0x00B79720: LDUR x12, [x10, #-8]       | X12 = (start.HasValue + 152 + 8) + -8;  
            // 0x00B79724: CMP x12, x25               | STATE = COMPARE((start.HasValue + 152 + 8) + -8, X5 + 48 + 16)
            // 0x00B79728: B.EQ #0xb79750             | if ((start.HasValue + 152 + 8) + -8 == X5 + 48 + 16) goto label_26;
            if(((start.HasValue + 152 + 8) + -8) == (X5 + 48 + 16))
            {
                goto label_26;
            }
            // 0x00B7972C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_16 = val_16 + 1;
            // 0x00B79730: ADD x10, x10, #0x10        | X10 = ((start.HasValue + 152 + 8) + 16);
            val_15 = val_15 + 16;
            // 0x00B79734: CMP x11, x9                | STATE = COMPARE((0 + 1), start.HasValue + 258)
            // 0x00B79738: B.LO #0xb79720             | if (0 < start.HasValue + 258) goto label_27;
            if(val_16 < (start.HasValue + 258))
            {
                goto label_27;
            }
            label_25:
            // 0x00B7973C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B79740: MOV x0, x20                | X0 = start.HasValue;//m1                
            val_24 = start.HasValue;
            // 0x00B79744: MOV x1, x25                | X1 = X5 + 48 + 16;//m1                  
            val_23 = X5 + 48 + 16;
            // 0x00B79748: BL #0x2776c24              | X0 = sub_2776C24( ?? start.HasValue, ????);
            // 0x00B7974C: B #0xb7975c                |  goto label_28;                         
            goto label_28;
            label_26:
            // 0x00B79750: LDR w9, [x10]              | W9 = (start.HasValue + 152 + 8);        
            // 0x00B79754: ADD x8, x8, x9, lsl #4     | X8 = (start.HasValue + ((start.HasValue + 152 + 8)) << 4);
            val_17 = val_17 + (((start.HasValue + 152 + 8)) << 4);
            // 0x00B79758: ADD x0, x8, #0x110         | X0 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272);
            val_24 = val_17 + 272;
            label_28:
            // 0x00B7975C: LDP x8, x1, [x0]           | X8 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272); X1 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272) + 8; //  | 
            // 0x00B79760: MOV x0, x20                | X0 = start.HasValue;//m1                
            // 0x00B79764: BLR x8                     | X0 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272)();
            // 0x00B79768: ADD w24, w0, w24           | W24 = (start.HasValue + start.HasValue);
            val_20 = start.HasValue + val_20;
            label_24:
            // 0x00B7976C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B79770: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B79774: MOV w1, w23                | W1 = (start.HasValue + val_15);//m1     
            val_25 = val_15;
            // 0x00B79778: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00B7977C: BL #0x16f9490              | X0 = System.Math.Max(val1:  0, val2:  val_25 = val_15);
            int val_1 = System.Math.Max(val1:  0, val2:  val_25);
            // 0x00B79780: LDR x8, [x19, #0x30]       | X8 = X5 + 48;                           
            // 0x00B79784: MOV w23, w0                | W23 = val_1;//m1                        
            val_26 = val_1;
            // 0x00B79788: LDR x25, [x8, #0x10]       | X25 = X5 + 48 + 16;                     
            // 0x00B7978C: MOV x0, x25                | X0 = X5 + 48 + 16;//m1                  
            // 0x00B79790: BL #0x277461c              | X0 = sub_277461C( ?? X5 + 48 + 16, ????);
            // 0x00B79794: LDR x8, [x20]              | X8 = start.HasValue;                    
            var val_20 = start.HasValue;
            // 0x00B79798: LDRH w9, [x8, #0x102]      | W9 = start.HasValue + 258;              
            // 0x00B7979C: CBZ x9, #0xb797c8          | if (start.HasValue + 258 == 0) goto label_29;
            if((start.HasValue + 258) == 0)
            {
                goto label_29;
            }
            // 0x00B797A0: LDR x10, [x8, #0x98]       | X10 = start.HasValue + 152;             
            var val_18 = start.HasValue + 152;
            // 0x00B797A4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_19 = 0;
            // 0x00B797A8: ADD x10, x10, #8           | X10 = (start.HasValue + 152 + 8);       
            val_18 = val_18 + 8;
            label_31:
            // 0x00B797AC: LDUR x12, [x10, #-8]       | X12 = (start.HasValue + 152 + 8) + -8;  
            // 0x00B797B0: CMP x12, x25               | STATE = COMPARE((start.HasValue + 152 + 8) + -8, X5 + 48 + 16)
            // 0x00B797B4: B.EQ #0xb797dc             | if ((start.HasValue + 152 + 8) + -8 == X5 + 48 + 16) goto label_30;
            if(((start.HasValue + 152 + 8) + -8) == (X5 + 48 + 16))
            {
                goto label_30;
            }
            // 0x00B797B8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_19 = val_19 + 1;
            // 0x00B797BC: ADD x10, x10, #0x10        | X10 = ((start.HasValue + 152 + 8) + 16);
            val_18 = val_18 + 16;
            // 0x00B797C0: CMP x11, x9                | STATE = COMPARE((0 + 1), start.HasValue + 258)
            // 0x00B797C4: B.LO #0xb797ac             | if (0 < start.HasValue + 258) goto label_31;
            if(val_19 < (start.HasValue + 258))
            {
                goto label_31;
            }
            label_29:
            // 0x00B797C8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B797CC: MOV x0, x20                | X0 = start.HasValue;//m1                
            val_27 = start.HasValue;
            // 0x00B797D0: MOV x1, x25                | X1 = X5 + 48 + 16;//m1                  
            val_25 = X5 + 48 + 16;
            // 0x00B797D4: BL #0x2776c24              | X0 = sub_2776C24( ?? start.HasValue, ????);
            // 0x00B797D8: B #0xb797e8                |  goto label_32;                         
            goto label_32;
            label_30:
            // 0x00B797DC: LDR w9, [x10]              | W9 = (start.HasValue + 152 + 8);        
            // 0x00B797E0: ADD x8, x8, x9, lsl #4     | X8 = (start.HasValue + ((start.HasValue + 152 + 8)) << 4);
            val_20 = val_20 + (((start.HasValue + 152 + 8)) << 4);
            // 0x00B797E4: ADD x0, x8, #0x110         | X0 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272);
            val_27 = val_20 + 272;
            label_32:
            // 0x00B797E8: LDP x8, x1, [x0]           | X8 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272); X1 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272) + 8; //  | 
            // 0x00B797EC: MOV x0, x20                | X0 = start.HasValue;//m1                
            // 0x00B797F0: BLR x8                     | X0 = ((start.HasValue + ((start.HasValue + 152 + 8)) << 4) + 272)();
            // 0x00B797F4: SUB w2, w0, #1             | W2 = (start.HasValue - 1);              
            val_28 = start.HasValue - 1;
            // 0x00B797F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B797FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00B79800: MOV w1, w24                | W1 = (start.HasValue + start.HasValue);//m1
            // 0x00B79804: BL #0x16f965c              | X0 = System.Math.Min(val1:  0, val2:  val_20);
            int val_2 = System.Math.Min(val1:  0, val2:  val_20);
            // 0x00B79808: MOV w24, w0                | W24 = val_2;//m1                        
            // 0x00B7980C: B #0xb7982c                |  goto label_33;                         
            goto label_33;
            label_40:
            // 0x00B79810: LDR x8, [x19, #0x30]       | X8 = X5 + 48;                           
            // 0x00B79814: MOV x0, x21                | X0 = X5 + 48;//m1                       
            // 0x00B79818: MOV x1, x25                | X1 = X5 + 48 + 16;//m1                  
            // 0x00B7981C: LDR x2, [x8, #0x20]        | X2 = X5 + 48 + 32;                      
            val_28 = mem[X5 + 48 + 32];
            val_28 = X5 + 48 + 32;
            // 0x00B79820: LDR x8, [x2]               | X8 = X5 + 48 + 32;                      
            // 0x00B79824: BLR x8                     | X0 = X5 + 48 + 32();                    
            // 0x00B79828: ADD w23, w23, w22          | W23 = (val_1 + 1);                      
            val_26 = val_26 + 1;
            label_33:
            // 0x00B7982C: CMP w23, w24               | STATE = COMPARE((val_1 + 1), val_2)     
            // 0x00B79830: B.GE #0xb798bc             | if (val_26 >= val_2) goto label_34;     
            if(val_26 >= val_2)
            {
                goto label_34;
            }
            // 0x00B79834: LDR x8, [x19, #0x30]       | X8 = X5 + 48;                           
            // 0x00B79838: LDR x25, [x8, #0x18]       | X25 = X5 + 48 + 24;                     
            // 0x00B7983C: MOV x0, x25                | X0 = X5 + 48 + 24;//m1                  
            // 0x00B79840: BL #0x277461c              | X0 = sub_277461C( ?? X5 + 48 + 24, ????);
            // 0x00B79844: LDR x8, [x20]              | X8 = start.HasValue;                    
            var val_24 = start.HasValue;
            // 0x00B79848: LDRH w9, [x8, #0x102]      | W9 = start.HasValue + 258;              
            // 0x00B7984C: CBZ x9, #0xb79878          | if (start.HasValue + 258 == 0) goto label_35;
            if((start.HasValue + 258) == 0)
            {
                goto label_35;
            }
            // 0x00B79850: LDR x10, [x8, #0x98]       | X10 = start.HasValue + 152;             
            var val_21 = start.HasValue + 152;
            // 0x00B79854: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_22 = 0;
            // 0x00B79858: ADD x10, x10, #8           | X10 = (start.HasValue + 152 + 8);       
            val_21 = val_21 + 8;
            label_37:
            // 0x00B7985C: LDUR x12, [x10, #-8]       | X12 = (start.HasValue + 152 + 8) + -8;  
            // 0x00B79860: CMP x12, x25               | STATE = COMPARE((start.HasValue + 152 + 8) + -8, X5 + 48 + 24)
            // 0x00B79864: B.EQ #0xb7988c             | if ((start.HasValue + 152 + 8) + -8 == X5 + 48 + 24) goto label_36;
            if(((start.HasValue + 152 + 8) + -8) == (X5 + 48 + 24))
            {
                goto label_36;
            }
            // 0x00B79868: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_22 = val_22 + 1;
            // 0x00B7986C: ADD x10, x10, #0x10        | X10 = ((start.HasValue + 152 + 8) + 16);
            val_21 = val_21 + 16;
            // 0x00B79870: CMP x11, x9                | STATE = COMPARE((0 + 1), start.HasValue + 258)
            // 0x00B79874: B.LO #0xb7985c             | if (0 < start.HasValue + 258) goto label_37;
            if(val_22 < (start.HasValue + 258))
            {
                goto label_37;
            }
            label_35:
            // 0x00B79878: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            val_28 = 3;
            // 0x00B7987C: MOV x0, x20                | X0 = start.HasValue;//m1                
            val_29 = start.HasValue;
            // 0x00B79880: MOV x1, x25                | X1 = X5 + 48 + 24;//m1                  
            // 0x00B79884: BL #0x2776c24              | X0 = sub_2776C24( ?? start.HasValue, ????);
            // 0x00B79888: B #0xb7989c                |  goto label_38;                         
            goto label_38;
            label_36:
            // 0x00B7988C: LDR w9, [x10]              | W9 = (start.HasValue + 152 + 8);        
            var val_23 = val_21;
            // 0x00B79890: ADD w9, w9, #3             | W9 = ((start.HasValue + 152 + 8) + 3);  
            val_23 = val_23 + 3;
            // 0x00B79894: ADD x8, x8, w9, uxtw #4    | X8 = (start.HasValue + ((start.HasValue + 152 + 8) + 3));
            val_24 = val_24 + val_23;
            // 0x00B79898: ADD x0, x8, #0x110         | X0 = ((start.HasValue + ((start.HasValue + 152 + 8) + 3)) + 272);
            val_29 = val_24 + 272;
            label_38:
            // 0x00B7989C: LDP x8, x2, [x0]           | X8 = ((start.HasValue + ((start.HasValue + 152 + 8) + 3)) + 272); X2 = ((start.HasValue + ((start.HasValue + 152 + 8) + 3)) + 272) + 8; //  | 
            // 0x00B798A0: MOV x0, x20                | X0 = start.HasValue;//m1                
            // 0x00B798A4: MOV w1, w23                | W1 = (val_1 + 1);//m1                   
            // 0x00B798A8: BLR x8                     | X0 = ((start.HasValue + ((start.HasValue + 152 + 8) + 3)) + 272)();
            // 0x00B798AC: MOV x25, x0                | X25 = start.HasValue;//m1               
            // 0x00B798B0: CBNZ x21, #0xb79810        | if (X5 + 48 != 0) goto label_40;        
            if((X5 + 48) != 0)
            {
                goto label_40;
            }
            // 0x00B798B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? start.HasValue, ????);
            // 0x00B798B8: B #0xb79810                |  goto label_40;                         
            goto label_40;
            label_34:
            // 0x00B798BC: MOV x0, x21                | X0 = X5 + 48;//m1                       
            // 0x00B798C0: SUB sp, x29, #0x40         | SP = (1152921513962485360 - 64) = 1152921513962485296 (0x100000022DA3B630);
            // 0x00B798C4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00B798C8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00B798CC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00B798D0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00B798D4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00B798D8: RET                        |  return (System.Collections.Generic.IList<T>)X5 + 48;
            return (System.Collections.Generic.IList<T>)X5 + 48;
            //  |  // // {name=val_0, type=System.Collections.Generic.IList<T>, size=8, nGRN=0 }
            label_1:
            // 0x00B798DC: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00B798E0: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x00B798E4: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            System.ArgumentNullException val_3 = null;
            // 0x00B798E8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x00B798EC: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x00B798F0: LDR x8, [x8, #0x958]       | X8 = (string**)(1152921511169504192)("list");
            // 0x00B798F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_30 = 0;
            // 0x00B798F8: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            val_31 = val_3;
            // 0x00B798FC: LDR x1, [x8]               | X1 = "list";                            
            // 0x00B79900: BL #0x18b3df0              | .ctor(paramName:  "list");              
            val_3 = new System.ArgumentNullException(paramName:  "list");
            // 0x00B79904: B #0xb7993c                |  goto label_41;                         
            goto label_41;
            label_3:
            // 0x00B79908: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x00B7990C: LDR x8, [x8, #0x1b8]       | X8 = 1152921504651841536;               
            // 0x00B79910: LDR x0, [x8]               | X0 = typeof(System.ArgumentException);  
            System.ArgumentException val_4 = null;
            // 0x00B79914: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentException), ????);
            // 0x00B79918: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x00B7991C: ADRP x9, #0x35c2000        | X9 = 56369152 (0x35C2000);              
            // 0x00B79920: LDR x8, [x8, #0x5b0]       | X8 = (string**)(1152921513962468064)("Step cannot be zero.");
            // 0x00B79924: LDR x9, [x9, #0x5f8]       | X9 = (string**)(1152921513962468176)("step");
            // 0x00B79928: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00B7992C: MOV x19, x0                | X19 = 1152921504651841536 (0x1000000002AE9000);//ML01
            val_31 = val_4;
            // 0x00B79930: LDR x1, [x8]               | X1 = "Step cannot be zero.";            
            // 0x00B79934: LDR x2, [x9]               | X2 = "step";                            
            val_30 = "step";
            // 0x00B79938: BL #0x18b3ee4              | .ctor(message:  "Step cannot be zero.", paramName:  val_30 = "step");
            val_4 = new System.ArgumentException(message:  "Step cannot be zero.", paramName:  val_30);
            label_41:
            // 0x00B7993C: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
            // 0x00B79940: LDR x8, [x8, #0x68]        | X8 = 1152921513962468256;               
            // 0x00B79944: MOV x0, x19                | X0 = 1152921504651841536 (0x1000000002AE9000);//ML01
            // 0x00B79948: LDR x1, [x8]               | X1 = public static System.Collections.Generic.IList<T> Newtonsoft.Json.Utilities.CollectionUtils::Slice<System.Object>(System.Collections.Generic.IList<T> list, System.Nullable<int> start, System.Nullable<int> end, System.Nullable<int> step);
            // 0x00B7994C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentException), ????);
            // 0x00B79950: BL #0xb693a0               | X0 = Newtonsoft.Json.Utilities.CollectionUtils.Slice<System.Object>(list:  val_31, start:  new System.Nullable<System.Int32>() {HasValue = true}, end:  new System.Nullable<System.Int32>() {HasValue = true}, step:  new System.Nullable<System.Int32>() {HasValue = false});
            System.Collections.Generic.IList<T> val_5 = Newtonsoft.Json.Utilities.CollectionUtils.Slice<System.Object>(list:  val_31, start:  new System.Nullable<System.Int32>() {HasValue = true}, end:  new System.Nullable<System.Int32>() {HasValue = true}, step:  new System.Nullable<System.Int32>() {HasValue = false});
        
        }
        // Generic instance method:
        //
        // file offset: 0x00B6D58C VirtAddr: 0x00B6D58C -RVA: 0x00B6D58C 
        // -CollectionUtils.GroupBy<object, object>
        //
        //
        // Offset in libil2cpp.so: 0x00B6D58C (11982220), len: 956  VirtAddr: 0x00B6D58C RVA: 0x00B6D58C token: 100686552 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static System.Collections.Generic.Dictionary<K, System.Collections.Generic.List<V>> GroupBy<K, V>(System.Collections.Generic.ICollection<V> source, System.Func<V, K> keySelector)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            // 0x00B6D58C: STP x26, x25, [sp, #-0x50]! | stack[1152921513962618896] = ???;  stack[1152921513962618904] = ???;  //  dest_result_addr=1152921513962618896 |  dest_result_addr=1152921513962618904
            // 0x00B6D590: STP x24, x23, [sp, #0x10]  | stack[1152921513962618912] = ???;  stack[1152921513962618920] = ???;  //  dest_result_addr=1152921513962618912 |  dest_result_addr=1152921513962618920
            // 0x00B6D594: STP x22, x21, [sp, #0x20]  | stack[1152921513962618928] = ???;  stack[1152921513962618936] = ???;  //  dest_result_addr=1152921513962618928 |  dest_result_addr=1152921513962618936
            // 0x00B6D598: STP x20, x19, [sp, #0x30]  | stack[1152921513962618944] = ???;  stack[1152921513962618952] = ???;  //  dest_result_addr=1152921513962618944 |  dest_result_addr=1152921513962618952
            // 0x00B6D59C: STP x29, x30, [sp, #0x40]  | stack[1152921513962618960] = ???;  stack[1152921513962618968] = ???;  //  dest_result_addr=1152921513962618960 |  dest_result_addr=1152921513962618968
            // 0x00B6D5A0: ADD x29, sp, #0x40         | X29 = (1152921513962618896 + 64) = 1152921513962618960 (0x100000022DA5C050);
            // 0x00B6D5A4: SUB sp, sp, #0x10          | SP = (1152921513962618896 - 16) = 1152921513962618880 (0x100000022DA5C000);
            // 0x00B6D5A8: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00B6D5AC: LDRB w8, [x19, #0x9b0]     | W8 = (bool)static_value_037339B0;       
            // 0x00B6D5B0: MOV x20, x3                | X20 = X3;//m1                           
            // 0x00B6D5B4: MOV x21, x2                | X21 = __RuntimeMethodHiddenParam;//m1   
            // 0x00B6D5B8: MOV x22, x1                | X22 = keySelector;//m1                  
            // 0x00B6D5BC: TBNZ w8, #0, #0xb6d5d8     | if (static_value_037339B0 == true) goto label_0;
            // 0x00B6D5C0: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x00B6D5C4: LDR x8, [x8, #0xc88]       | X8 = 0x2B91608;                         
            // 0x00B6D5C8: LDR w0, [x8]               | W0 = 0x1C46;                            
            // 0x00B6D5CC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C46, ????);     
            // 0x00B6D5D0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00B6D5D4: STRB w8, [x19, #0x9b0]     | static_value_037339B0 = true;            //  dest_result_addr=57883056
            label_0:
            // 0x00B6D5D8: STR xzr, [sp, #8]          | stack[1152921513962618888] = 0x0;        //  dest_result_addr=1152921513962618888
            // 0x00B6D5DC: CBZ x21, #0xb6d908         | if (__RuntimeMethodHiddenParam == 0) goto label_1;
            if(__RuntimeMethodHiddenParam == 0)
            {
                goto label_1;
            }
            // 0x00B6D5E0: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x00B6D5E4: LDR x19, [x8]              | X19 = X3 + 48;                          
            // 0x00B6D5E8: MOV x0, x19                | X0 = X3 + 48;//m1                       
            // 0x00B6D5EC: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48, ????);    
            // 0x00B6D5F0: MOV x0, x19                | X0 = X3 + 48;//m1                       
            // 0x00B6D5F4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X3 + 48, ????);
            // 0x00B6D5F8: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x00B6D5FC: MOV x19, x0                | X19 = X3 + 48;//m1                      
            // 0x00B6D600: LDR x1, [x8, #8]           | X1 = X3 + 48 + 8;                       
            val_9 = mem[X3 + 48 + 8];
            val_9 = X3 + 48 + 8;
            // 0x00B6D604: LDR x8, [x1]               | X8 = X3 + 48 + 8;                       
            // 0x00B6D608: BLR x8                     | X0 = X3 + 48 + 8();                     
            // 0x00B6D60C: CBNZ x22, #0xb6d614        | if (keySelector != null) goto label_2;  
            if(keySelector != null)
            {
                goto label_2;
            }
            // 0x00B6D610: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X3 + 48, ????);    
            label_2:
            // 0x00B6D614: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x00B6D618: LDR x23, [x8, #0x10]       | X23 = X3 + 48 + 16;                     
            // 0x00B6D61C: MOV x0, x23                | X0 = X3 + 48 + 16;//m1                  
            // 0x00B6D620: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 16, ????);
            // 0x00B6D624: LDR x8, [x22]              | X8 = typeof(System.Func<V, K>);         
            // 0x00B6D628: LDRH w9, [x8, #0x102]      | W9 = System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00B6D62C: CBZ x9, #0xb6d658          | if (System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_3;
            // 0x00B6D630: LDR x10, [x8, #0x98]       | X10 = System.Func<T, TResult>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00B6D634: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_9 = 0;
            // 0x00B6D638: ADD x10, x10, #8           | X10 = (System.Func<T, TResult>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504688140296 (0x1000000004D87008);
            label_5:
            // 0x00B6D63C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00B6D640: CMP x12, x23               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X3 + 48 + 16)
            // 0x00B6D644: B.EQ #0xb6d66c             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X3 + 48 + 16) goto label_4;
            // 0x00B6D648: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_9 = val_9 + 1;
            // 0x00B6D64C: ADD x10, x10, #0x10        | X10 = (1152921504688140296 + 16) = 1152921504688140312 (0x1000000004D87018);
            // 0x00B6D650: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00B6D654: B.LO #0xb6d63c             | if (0 < System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count) goto label_5;
            label_3:
            // 0x00B6D658: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B6D65C: MOV x0, x22                | X0 = keySelector;//m1                   
            val_10 = keySelector;
            // 0x00B6D660: MOV x1, x23                | X1 = X3 + 48 + 16;//m1                  
            val_9 = X3 + 48 + 16;
            // 0x00B6D664: BL #0x2776c24              | X0 = sub_2776C24( ?? keySelector, ????);
            // 0x00B6D668: B #0xb6d678                |  goto label_6;                          
            goto label_6;
            label_4:
            // 0x00B6D66C: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00B6D670: ADD x8, x8, x9, lsl #4     | X8 = (1152921504688103424 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00B6D674: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504688103424 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_6:
            // 0x00B6D678: LDP x8, x1, [x0]           | X8 = X3 + 48 + 16; X1 = X3 + 48 + 16 + 8; //  | 
            // 0x00B6D67C: MOV x0, x22                | X0 = keySelector;//m1                   
            // 0x00B6D680: BLR x8                     | X0 = X3 + 48 + 16();                    
            // 0x00B6D684: ADRP x26, #0x361c000       | X26 = 56737792 (0x361C000);             
            // 0x00B6D688: LDR x26, [x26, #0x358]     | X26 = 1152921504608018432;              
            // 0x00B6D68C: MOV x22, x0                | X22 = keySelector;//m1                  
            label_22:
            // 0x00B6D690: CBNZ x22, #0xb6d698        | if (keySelector != null) goto label_7;  
            if(keySelector != null)
            {
                goto label_7;
            }
            // 0x00B6D694: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? keySelector, ????);
            label_7:
            // 0x00B6D698: LDR x8, [x22]              | X8 = typeof(System.Func<V, K>);         
            // 0x00B6D69C: LDR x1, [x26]              | X1 = typeof(System.Collections.IEnumerator);
            // 0x00B6D6A0: LDRH w9, [x8, #0x102]      | W9 = System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00B6D6A4: CBZ x9, #0xb6d6d0          | if (System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_8;
            // 0x00B6D6A8: LDR x10, [x8, #0x98]       | X10 = System.Func<T, TResult>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00B6D6AC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_10 = 0;
            // 0x00B6D6B0: ADD x10, x10, #8           | X10 = (System.Func<T, TResult>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504688140296 (0x1000000004D87008);
            label_10:
            // 0x00B6D6B4: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00B6D6B8: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IEnumerator))
            // 0x00B6D6BC: B.EQ #0xb6d6e0             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_9;
            // 0x00B6D6C0: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_10 = val_10 + 1;
            // 0x00B6D6C4: ADD x10, x10, #0x10        | X10 = (1152921504688140296 + 16) = 1152921504688140312 (0x1000000004D87018);
            // 0x00B6D6C8: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00B6D6CC: B.LO #0xb6d6b4             | if (0 < System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count) goto label_10;
            label_8:
            // 0x00B6D6D0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00B6D6D4: MOV x0, x22                | X0 = keySelector;//m1                   
            val_11 = keySelector;
            // 0x00B6D6D8: BL #0x2776c24              | X0 = sub_2776C24( ?? keySelector, ????);
            // 0x00B6D6DC: B #0xb6d6f0                |  goto label_11;                         
            goto label_11;
            label_9:
            // 0x00B6D6E0: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00B6D6E4: ADD w9, w9, #1             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1);
            // 0x00B6D6E8: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504688103424 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1));
            // 0x00B6D6EC: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504688103424 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1)).272
            label_11:
            // 0x00B6D6F0: LDP x8, x1, [x0]           | X8 = typeof(System.Func<V, K>);          //  | 
            // 0x00B6D6F4: MOV x0, x22                | X0 = keySelector;//m1                   
            // 0x00B6D6F8: BLR x8                     | X0 = sub_1000000004D7E000( ?? keySelector, ????);
            // 0x00B6D6FC: AND w8, w0, #1             | W8 = (keySelector & 1);                 
            System.Func<V, K> val_3 = keySelector & 1;
            // 0x00B6D700: TBZ w8, #0, #0xb6d8fc      | if (((keySelector & 1) & 0x1) == 0) goto label_12;
            if((val_3 & 1) == 0)
            {
                goto label_12;
            }
            // 0x00B6D704: CBNZ x22, #0xb6d70c        | if (keySelector != null) goto label_13; 
            if(keySelector != null)
            {
                goto label_13;
            }
            // 0x00B6D708: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? keySelector, ????);
            label_13:
            // 0x00B6D70C: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x00B6D710: LDR x23, [x8, #0x18]       | X23 = X3 + 48 + 24;                     
            // 0x00B6D714: MOV x0, x23                | X0 = X3 + 48 + 24;//m1                  
            // 0x00B6D718: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 24, ????);
            // 0x00B6D71C: LDR x8, [x22]              | X8 = typeof(System.Func<V, K>);         
            // 0x00B6D720: LDRH w9, [x8, #0x102]      | W9 = System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00B6D724: CBZ x9, #0xb6d750          | if (System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_14;
            // 0x00B6D728: LDR x10, [x8, #0x98]       | X10 = System.Func<T, TResult>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00B6D72C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_11 = 0;
            // 0x00B6D730: ADD x10, x10, #8           | X10 = (System.Func<T, TResult>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504688140296 (0x1000000004D87008);
            label_16:
            // 0x00B6D734: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00B6D738: CMP x12, x23               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X3 + 48 + 24)
            // 0x00B6D73C: B.EQ #0xb6d764             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X3 + 48 + 24) goto label_15;
            // 0x00B6D740: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_11 = val_11 + 1;
            // 0x00B6D744: ADD x10, x10, #0x10        | X10 = (1152921504688140296 + 16) = 1152921504688140312 (0x1000000004D87018);
            // 0x00B6D748: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00B6D74C: B.LO #0xb6d734             | if (0 < System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count) goto label_16;
            label_14:
            // 0x00B6D750: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B6D754: MOV x0, x22                | X0 = keySelector;//m1                   
            val_13 = keySelector;
            // 0x00B6D758: MOV x1, x23                | X1 = X3 + 48 + 24;//m1                  
            val_12 = X3 + 48 + 24;
            // 0x00B6D75C: BL #0x2776c24              | X0 = sub_2776C24( ?? keySelector, ????);
            // 0x00B6D760: B #0xb6d770                |  goto label_17;                         
            goto label_17;
            label_15:
            // 0x00B6D764: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00B6D768: ADD x8, x8, x9, lsl #4     | X8 = (1152921504688103424 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00B6D76C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504688103424 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_17:
            // 0x00B6D770: LDP x8, x1, [x0]           | X8 = X3 + 48 + 24; X1 = X3 + 48 + 24 + 8; //  | 
            // 0x00B6D774: MOV x0, x22                | X0 = keySelector;//m1                   
            // 0x00B6D778: BLR x8                     | X0 = X3 + 48 + 24();                    
            // 0x00B6D77C: MOV x23, x0                | X23 = keySelector;//m1                  
            // 0x00B6D780: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x00B6D784: LDR x2, [x8, #0x20]        | X2 = X3 + 48 + 32;                      
            // 0x00B6D788: LDR x8, [x2]               | X8 = X3 + 48 + 32;                      
            // 0x00B6D78C: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam;//m1    
            // 0x00B6D790: MOV x1, x23                | X1 = keySelector;//m1                   
            // 0x00B6D794: BLR x8                     | X0 = X3 + 48 + 32();                    
            // 0x00B6D798: MOV x24, x0                | X24 = __RuntimeMethodHiddenParam;//m1   
            // 0x00B6D79C: CBNZ x19, #0xb6d7a4        | if (X3 + 48 != 0) goto label_18;        
            if((X3 + 48) != 0)
            {
                goto label_18;
            }
            // 0x00B6D7A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? __RuntimeMethodHiddenParam, ????);
            label_18:
            // 0x00B6D7A4: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x00B6D7A8: LDR x3, [x8, #0x28]        | X3 = X3 + 48 + 40;                      
            // 0x00B6D7AC: LDR x8, [x3]               | X8 = X3 + 48 + 40;                      
            // 0x00B6D7B0: ADD x2, sp, #8             | X2 = (1152921513962618880 + 8) = 1152921513962618888 (0x100000022DA5C008);
            // 0x00B6D7B4: MOV x0, x19                | X0 = X3 + 48;//m1                       
            // 0x00B6D7B8: MOV x1, x24                | X1 = __RuntimeMethodHiddenParam;//m1    
            // 0x00B6D7BC: BLR x8                     | X0 = X3 + 48 + 40();                    
            // 0x00B6D7C0: AND w8, w0, #1             | W8 = (X3 + 48 & 1);                     
            var val_5 = (X3 + 48) & 1;
            // 0x00B6D7C4: TBNZ w8, #0, #0xb6d820     | if (((X3 + 48 & 1) & 0x1) != 0) goto label_19;
            if((val_5 & 1) != 0)
            {
                goto label_19;
            }
            // 0x00B6D7C8: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x00B6D7CC: LDR x25, [x8, #0x30]       | X25 = X3 + 48 + 48;                     
            // 0x00B6D7D0: MOV x0, x25                | X0 = X3 + 48 + 48;//m1                  
            // 0x00B6D7D4: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 48, ????);
            // 0x00B6D7D8: MOV x0, x25                | X0 = X3 + 48 + 48;//m1                  
            // 0x00B6D7DC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X3 + 48 + 48, ????);
            // 0x00B6D7E0: MOV x25, x0                | X25 = X3 + 48 + 48;//m1                 
            // 0x00B6D7E4: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x00B6D7E8: LDR x1, [x8, #0x38]        | X1 = X3 + 48 + 56;                      
            // 0x00B6D7EC: LDR x8, [x1]               | X8 = X3 + 48 + 56;                      
            // 0x00B6D7F0: MOV x0, x25                | X0 = X3 + 48 + 48;//m1                  
            // 0x00B6D7F4: BLR x8                     | X0 = X3 + 48 + 56();                    
            // 0x00B6D7F8: STR x25, [sp, #8]          | stack[1152921513962618888] = X3 + 48 + 48;  //  dest_result_addr=1152921513962618888
            // 0x00B6D7FC: CBNZ x19, #0xb6d804        | if (X3 + 48 != 0) goto label_20;        
            if((X3 + 48) != 0)
            {
                goto label_20;
            }
            // 0x00B6D800: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X3 + 48 + 48, ????);
            label_20:
            // 0x00B6D804: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x00B6D808: LDR x3, [x8, #0x40]        | X3 = X3 + 48 + 64;                      
            // 0x00B6D80C: LDR x8, [x3]               | X8 = X3 + 48 + 64;                      
            // 0x00B6D810: MOV x0, x19                | X0 = X3 + 48;//m1                       
            // 0x00B6D814: MOV x1, x24                | X1 = __RuntimeMethodHiddenParam;//m1    
            // 0x00B6D818: MOV x2, x25                | X2 = X3 + 48 + 48;//m1                  
            // 0x00B6D81C: BLR x8                     | X0 = X3 + 48 + 64();                    
            label_19:
            // 0x00B6D820: LDR x24, [sp, #8]          | X24 = X3 + 48 + 48;                     
            // 0x00B6D824: CBNZ x24, #0xb6d82c        | if (X3 + 48 + 48 != 0) goto label_21;   
            if((X3 + 48 + 48) != 0)
            {
                goto label_21;
            }
            // 0x00B6D828: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X3 + 48, ????);    
            label_21:
            // 0x00B6D82C: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x00B6D830: LDR x2, [x8, #0x48]        | X2 = X3 + 48 + 72;                      
            // 0x00B6D834: LDR x8, [x2]               | X8 = X3 + 48 + 72;                      
            // 0x00B6D838: MOV x0, x24                | X0 = X3 + 48 + 48;//m1                  
            // 0x00B6D83C: MOV x1, x23                | X1 = keySelector;//m1                   
            // 0x00B6D840: BLR x8                     | X0 = X3 + 48 + 72();                    
            // 0x00B6D844: B #0xb6d690                |  goto label_22;                         
            goto label_22;
            // 0x00B6D848: BL #0x981060               | X0 = sub_981060( ?? X3 + 48 + 48, ????);
            // 0x00B6D84C: LDR x20, [x0]              | X20 = X3 + 48 + 48;                     
            // 0x00B6D850: BL #0x980920               | X0 = sub_980920( ?? X3 + 48 + 48, ????);
            // 0x00B6D854: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            label_30:
            // 0x00B6D858: CBZ x22, #0xb6d8c4         | if (keySelector == null) goto label_23; 
            if(keySelector == null)
            {
                goto label_23;
            }
            // 0x00B6D85C: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x00B6D860: LDR x8, [x22]              | X8 = typeof(System.Func<V, K>);         
            // 0x00B6D864: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x00B6D868: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x00B6D86C: LDRH w9, [x8, #0x102]      | W9 = System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00B6D870: CBZ x9, #0xb6d89c          | if (System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_24;
            // 0x00B6D874: LDR x10, [x8, #0x98]       | X10 = System.Func<T, TResult>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00B6D878: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_12 = 0;
            // 0x00B6D87C: ADD x10, x10, #8           | X10 = (System.Func<T, TResult>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504688140296 (0x1000000004D87008);
            label_26:
            // 0x00B6D880: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00B6D884: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
            // 0x00B6D888: B.EQ #0xb6d8ac             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_25;
            // 0x00B6D88C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_12 = val_12 + 1;
            // 0x00B6D890: ADD x10, x10, #0x10        | X10 = (1152921504688140296 + 16) = 1152921504688140312 (0x1000000004D87018);
            // 0x00B6D894: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00B6D898: B.LO #0xb6d880             | if (0 < System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count) goto label_26;
            label_24:
            // 0x00B6D89C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B6D8A0: MOV x0, x22                | X0 = keySelector;//m1                   
            val_14 = keySelector;
            // 0x00B6D8A4: BL #0x2776c24              | X0 = sub_2776C24( ?? keySelector, ????);
            // 0x00B6D8A8: B #0xb6d8b8                |  goto label_27;                         
            goto label_27;
            label_25:
            // 0x00B6D8AC: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00B6D8B0: ADD x8, x8, x9, lsl #4     | X8 = (1152921504688103424 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00B6D8B4: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504688103424 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_27:
            // 0x00B6D8B8: LDP x8, x1, [x0]           | X8 = X3 + 48 + 48; X1 = X3 + 48 + 48 + 8; //  | 
            // 0x00B6D8BC: MOV x0, x22                | X0 = keySelector;//m1                   
            // 0x00B6D8C0: BLR x8                     | X0 = X3 + 48 + 48();                    
            label_23:
            // 0x00B6D8C4: CMP w21, #0x75             | STATE = COMPARE(0x0, 0x75)              
            // 0x00B6D8C8: B.EQ #0xb6d8dc             | if (0 == 0x75) goto label_29;           
            if(0 == 117)
            {
                goto label_29;
            }
            // 0x00B6D8CC: CBZ x20, #0xb6d8dc         | if (X3 + 48 + 48 == 0) goto label_29;   
            if((X3 + 48 + 48) == 0)
            {
                goto label_29;
            }
            // 0x00B6D8D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B6D8D4: MOV x0, x20                | X0 = X3 + 48 + 48;//m1                  
            // 0x00B6D8D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X3 + 48 + 48, ????);
            label_29:
            // 0x00B6D8DC: MOV x0, x19                | X0 = X3 + 48;//m1                       
            // 0x00B6D8E0: SUB sp, x29, #0x40         | SP = (1152921513962618960 - 64) = 1152921513962618896 (0x100000022DA5C010);
            // 0x00B6D8E4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00B6D8E8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00B6D8EC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00B6D8F0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00B6D8F4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00B6D8F8: RET                        |  return (System.Collections.Generic.Dictionary<K, System.Collections.Generic.List<V>>)X3 + 48;
            return (System.Collections.Generic.Dictionary<K, System.Collections.Generic.List<V>>)X3 + 48;
            //  |  // // {name=val_0, type=System.Collections.Generic.Dictionary<K, System.Collections.Generic.List<V>>, size=8, nGRN=0 }
            label_12:
            // 0x00B6D8FC: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            // 0x00B6D900: MOVZ w21, #0x75            | W21 = 117 (0x75);//ML01                 
            // 0x00B6D904: B #0xb6d858                |  goto label_30;                         
            goto label_30;
            label_1:
            // 0x00B6D908: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00B6D90C: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x00B6D910: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            System.ArgumentNullException val_7 = null;
            // 0x00B6D914: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x00B6D918: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x00B6D91C: LDR x8, [x8, #0x5d8]       | X8 = (string**)(1152921513962601760)("keySelector");
            // 0x00B6D920: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00B6D924: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x00B6D928: LDR x1, [x8]               | X1 = "keySelector";                     
            // 0x00B6D92C: BL #0x18b3df0              | .ctor(paramName:  "keySelector");       
            val_7 = new System.ArgumentNullException(paramName:  "keySelector");
            // 0x00B6D930: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
            // 0x00B6D934: LDR x8, [x8, #0x400]       | X8 = 1152921513962601856;               
            // 0x00B6D938: MOV x0, x19                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x00B6D93C: LDR x1, [x8]               | X1 = public static System.Collections.Generic.Dictionary<K, System.Collections.Generic.List<V>> Newtonsoft.Json.Utilities.CollectionUtils::GroupBy<System.Object, System.Object>(System.Collections.Generic.ICollection<V> source, System.Func<V, K> keySelector);
            // 0x00B6D940: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentNullException), ????);
            // 0x00B6D944: BL #0xb693a0               | X0 = Newtonsoft.Json.Utilities.CollectionUtils.GroupBy<System.Object, System.Object>(source:  val_7, keySelector:  public static System.Collections.Generic.Dictionary<K, System.Collections.Generic.List<V>> Newtonsoft.Json.Utilities.CollectionUtils::GroupBy<System.Object, System.Object>(System.Collections.Generic.ICollection<V> source, System.Func<V, K> keySelector));
            System.Collections.Generic.Dictionary<K, System.Collections.Generic.List<V>> val_8 = Newtonsoft.Json.Utilities.CollectionUtils.GroupBy<System.Object, System.Object>(source:  val_7, keySelector:  public static System.Collections.Generic.Dictionary<K, System.Collections.Generic.List<V>> Newtonsoft.Json.Utilities.CollectionUtils::GroupBy<System.Object, System.Object>(System.Collections.Generic.ICollection<V> source, System.Func<V, K> keySelector));
        
        }
        // Generic instance method:
        //
        // file offset: 0x010D68A0 VirtAddr: 0x010D68A0 -RVA: 0x010D68A0 
        // -CollectionUtils.AddRange<object>
        // -CollectionUtils.AddRange<Newtonsoft.Json.JsonConverter>
        // -CollectionUtils.AddRange<Newtonsoft.Json.Serialization.JsonProperty>
        // -CollectionUtils.AddRange<System.Reflection.MemberInfo>
        //
        //
        // Offset in libil2cpp.so: 0x010D68A0 (17655968), len: 824  VirtAddr: 0x010D68A0 RVA: 0x010D68A0 token: 100686553 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x28632C8
        public static void AddRange<T>(System.Collections.Generic.IList<T> initial, System.Collections.Generic.IEnumerable<T> collection)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            var val_20;
            //  | 
            var val_21;
            //  | 
            var val_22;
            //  | 
            var val_23;
            // 0x010D68A0: STP x24, x23, [sp, #-0x40]! | stack[1152921513962752512] = ???;  stack[1152921513962752520] = ???;  //  dest_result_addr=1152921513962752512 |  dest_result_addr=1152921513962752520
            // 0x010D68A4: STP x22, x21, [sp, #0x10]  | stack[1152921513962752528] = ???;  stack[1152921513962752536] = ???;  //  dest_result_addr=1152921513962752528 |  dest_result_addr=1152921513962752536
            // 0x010D68A8: STP x20, x19, [sp, #0x20]  | stack[1152921513962752544] = ???;  stack[1152921513962752552] = ???;  //  dest_result_addr=1152921513962752544 |  dest_result_addr=1152921513962752552
            // 0x010D68AC: STP x29, x30, [sp, #0x30]  | stack[1152921513962752560] = ???;  stack[1152921513962752568] = ???;  //  dest_result_addr=1152921513962752560 |  dest_result_addr=1152921513962752568
            // 0x010D68B0: ADD x29, sp, #0x30         | X29 = (1152921513962752512 + 48) = 1152921513962752560 (0x100000022DA7CA30);
            // 0x010D68B4: ADRP x22, #0x3735000       | X22 = 57888768 (0x3735000);             
            // 0x010D68B8: LDRB w8, [x22, #0x924]     | W8 = (bool)static_value_03735924;       
            // 0x010D68BC: MOV x20, x3                | X20 = X3;//m1                           
            // 0x010D68C0: MOV x19, x2                | X19 = __RuntimeMethodHiddenParam;//m1   
            val_15 = __RuntimeMethodHiddenParam;
            // 0x010D68C4: MOV x21, x1                | X21 = collection;//m1                   
            val_16 = collection;
            // 0x010D68C8: TBNZ w8, #0, #0x10d68e4    | if (static_value_03735924 == true) goto label_0;
            // 0x010D68CC: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x010D68D0: LDR x8, [x8, #0xd28]       | X8 = 0x2B915D4;                         
            // 0x010D68D4: LDR w0, [x8]               | W0 = 0x1C39;                            
            // 0x010D68D8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C39, ????);     
            // 0x010D68DC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010D68E0: STRB w8, [x22, #0x924]     | static_value_03735924 = true;            //  dest_result_addr=57891108
            label_0:
            // 0x010D68E4: CBZ x21, #0x10d6b98        | if (collection == null) goto label_1;   
            if(val_16 == null)
            {
                goto label_1;
            }
            // 0x010D68E8: CBZ x19, #0x10d6b78        | if (__RuntimeMethodHiddenParam == 0) goto label_29;
            if(val_15 == 0)
            {
                goto label_29;
            }
            // 0x010D68EC: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x010D68F0: LDR x22, [x8]              | X22 = X3 + 48;                          
            // 0x010D68F4: MOV x0, x22                | X0 = X3 + 48;//m1                       
            // 0x010D68F8: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48, ????);    
            // 0x010D68FC: LDR x8, [x19]              | X8 = __RuntimeMethodHiddenParam;        
            var val_14 = val_15;
            // 0x010D6900: LDRH w9, [x8, #0x102]      | W9 = __RuntimeMethodHiddenParam + 258;  
            // 0x010D6904: CBZ x9, #0x10d6930         | if (__RuntimeMethodHiddenParam + 258 == 0) goto label_3;
            if((__RuntimeMethodHiddenParam + 258) == 0)
            {
                goto label_3;
            }
            // 0x010D6908: LDR x10, [x8, #0x98]       | X10 = __RuntimeMethodHiddenParam + 152; 
            var val_12 = __RuntimeMethodHiddenParam + 152;
            // 0x010D690C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_13 = 0;
            // 0x010D6910: ADD x10, x10, #8           | X10 = (__RuntimeMethodHiddenParam + 152 + 8);
            val_12 = val_12 + 8;
            label_5:
            // 0x010D6914: LDUR x12, [x10, #-8]       | X12 = (__RuntimeMethodHiddenParam + 152 + 8) + -8;
            // 0x010D6918: CMP x12, x22               | STATE = COMPARE((__RuntimeMethodHiddenParam + 152 + 8) + -8, X3 + 48)
            // 0x010D691C: B.EQ #0x10d6944            | if ((__RuntimeMethodHiddenParam + 152 + 8) + -8 == X3 + 48) goto label_4;
            if(((__RuntimeMethodHiddenParam + 152 + 8) + -8) == (X3 + 48))
            {
                goto label_4;
            }
            // 0x010D6920: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_13 = val_13 + 1;
            // 0x010D6924: ADD x10, x10, #0x10        | X10 = ((__RuntimeMethodHiddenParam + 152 + 8) + 16);
            val_12 = val_12 + 16;
            // 0x010D6928: CMP x11, x9                | STATE = COMPARE((0 + 1), __RuntimeMethodHiddenParam + 258)
            // 0x010D692C: B.LO #0x10d6914            | if (0 < __RuntimeMethodHiddenParam + 258) goto label_5;
            if(val_13 < (__RuntimeMethodHiddenParam + 258))
            {
                goto label_5;
            }
            label_3:
            // 0x010D6930: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            val_17 = 0;
            // 0x010D6934: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam;//m1    
            val_18 = val_15;
            // 0x010D6938: MOV x1, x22                | X1 = X3 + 48;//m1                       
            // 0x010D693C: BL #0x2776c24              | X0 = sub_2776C24( ?? __RuntimeMethodHiddenParam, ????);
            // 0x010D6940: B #0x10d6950               |  goto label_6;                          
            goto label_6;
            label_4:
            // 0x010D6944: LDR w9, [x10]              | W9 = (__RuntimeMethodHiddenParam + 152 + 8);
            // 0x010D6948: ADD x8, x8, x9, lsl #4     | X8 = (__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4);
            val_14 = val_14 + (((__RuntimeMethodHiddenParam + 152 + 8)) << 4);
            // 0x010D694C: ADD x0, x8, #0x110         | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272);
            val_18 = val_14 + 272;
            label_6:
            // 0x010D6950: LDP x8, x1, [x0]           | X8 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272); X1 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272) + 8; //  | 
            // 0x010D6954: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam;//m1    
            // 0x010D6958: BLR x8                     | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272)();
            // 0x010D695C: ADRP x24, #0x361c000       | X24 = 56737792 (0x361C000);             
            // 0x010D6960: LDR x24, [x24, #0x358]     | X24 = 1152921504608018432;              
            // 0x010D6964: MOV x19, x0                | X19 = __RuntimeMethodHiddenParam;//m1   
            label_22:
            // 0x010D6968: CBNZ x19, #0x10d6970       | if (__RuntimeMethodHiddenParam != 0) goto label_7;
            if(val_15 != 0)
            {
                goto label_7;
            }
            // 0x010D696C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? __RuntimeMethodHiddenParam, ????);
            label_7:
            // 0x010D6970: LDR x8, [x19]              | X8 = __RuntimeMethodHiddenParam;        
            var val_18 = val_15;
            // 0x010D6974: LDR x1, [x24]              | X1 = typeof(System.Collections.IEnumerator);
            // 0x010D6978: LDRH w9, [x8, #0x102]      | W9 = __RuntimeMethodHiddenParam + 258;  
            // 0x010D697C: CBZ x9, #0x10d69a8         | if (__RuntimeMethodHiddenParam + 258 == 0) goto label_8;
            if((__RuntimeMethodHiddenParam + 258) == 0)
            {
                goto label_8;
            }
            // 0x010D6980: LDR x10, [x8, #0x98]       | X10 = __RuntimeMethodHiddenParam + 152; 
            var val_15 = __RuntimeMethodHiddenParam + 152;
            // 0x010D6984: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_16 = 0;
            // 0x010D6988: ADD x10, x10, #8           | X10 = (__RuntimeMethodHiddenParam + 152 + 8);
            val_15 = val_15 + 8;
            label_10:
            // 0x010D698C: LDUR x12, [x10, #-8]       | X12 = (__RuntimeMethodHiddenParam + 152 + 8) + -8;
            // 0x010D6990: CMP x12, x1                | STATE = COMPARE((__RuntimeMethodHiddenParam + 152 + 8) + -8, typeof(System.Collections.IEnumerator))
            // 0x010D6994: B.EQ #0x10d69b8            | if ((__RuntimeMethodHiddenParam + 152 + 8) + -8 == null) goto label_9;
            if(((__RuntimeMethodHiddenParam + 152 + 8) + -8) == null)
            {
                goto label_9;
            }
            // 0x010D6998: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_16 = val_16 + 1;
            // 0x010D699C: ADD x10, x10, #0x10        | X10 = ((__RuntimeMethodHiddenParam + 152 + 8) + 16);
            val_15 = val_15 + 16;
            // 0x010D69A0: CMP x11, x9                | STATE = COMPARE((0 + 1), __RuntimeMethodHiddenParam + 258)
            // 0x010D69A4: B.LO #0x10d698c            | if (0 < __RuntimeMethodHiddenParam + 258) goto label_10;
            if(val_16 < (__RuntimeMethodHiddenParam + 258))
            {
                goto label_10;
            }
            label_8:
            // 0x010D69A8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            val_17 = 1;
            // 0x010D69AC: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam;//m1    
            val_19 = val_15;
            // 0x010D69B0: BL #0x2776c24              | X0 = sub_2776C24( ?? __RuntimeMethodHiddenParam, ????);
            // 0x010D69B4: B #0x10d69c8               |  goto label_11;                         
            goto label_11;
            label_9:
            // 0x010D69B8: LDR w9, [x10]              | W9 = (__RuntimeMethodHiddenParam + 152 + 8);
            var val_17 = val_15;
            // 0x010D69BC: ADD w9, w9, #1             | W9 = ((__RuntimeMethodHiddenParam + 152 + 8) + 1);
            val_17 = val_17 + 1;
            // 0x010D69C0: ADD x8, x8, w9, uxtw #4    | X8 = (__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 1));
            val_18 = val_18 + val_17;
            // 0x010D69C4: ADD x0, x8, #0x110         | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 1)) + 272);
            val_19 = val_18 + 272;
            label_11:
            // 0x010D69C8: LDP x8, x1, [x0]           | X8 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 1)) + 272); X1 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 1)) + 272) + 8; //  | 
            val_20 = mem[((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 1)) + 272) + 8];
            val_20 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 1)) + 272) + 8;
            // 0x010D69CC: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam;//m1    
            // 0x010D69D0: BLR x8                     | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 1)) + 272)();
            // 0x010D69D4: AND w8, w0, #1             | W8 = (__RuntimeMethodHiddenParam & 1);  
            var val_1 = val_15 & 1;
            // 0x010D69D8: TBZ w8, #0, #0x10d6b8c     | if (((__RuntimeMethodHiddenParam & 1) & 0x1) == 0) goto label_12;
            if((val_1 & 1) == 0)
            {
                goto label_12;
            }
            // 0x010D69DC: CBNZ x19, #0x10d69e4       | if (__RuntimeMethodHiddenParam != 0) goto label_13;
            if(val_15 != 0)
            {
                goto label_13;
            }
            // 0x010D69E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? __RuntimeMethodHiddenParam, ????);
            label_13:
            // 0x010D69E4: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x010D69E8: LDR x22, [x8, #8]          | X22 = X3 + 48 + 8;                      
            // 0x010D69EC: MOV x0, x22                | X0 = X3 + 48 + 8;//m1                   
            // 0x010D69F0: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 8, ????);
            // 0x010D69F4: LDR x8, [x19]              | X8 = __RuntimeMethodHiddenParam;        
            var val_21 = val_15;
            // 0x010D69F8: LDRH w9, [x8, #0x102]      | W9 = __RuntimeMethodHiddenParam + 258;  
            // 0x010D69FC: CBZ x9, #0x10d6a28         | if (__RuntimeMethodHiddenParam + 258 == 0) goto label_14;
            if((__RuntimeMethodHiddenParam + 258) == 0)
            {
                goto label_14;
            }
            // 0x010D6A00: LDR x10, [x8, #0x98]       | X10 = __RuntimeMethodHiddenParam + 152; 
            var val_19 = __RuntimeMethodHiddenParam + 152;
            // 0x010D6A04: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_20 = 0;
            // 0x010D6A08: ADD x10, x10, #8           | X10 = (__RuntimeMethodHiddenParam + 152 + 8);
            val_19 = val_19 + 8;
            label_16:
            // 0x010D6A0C: LDUR x12, [x10, #-8]       | X12 = (__RuntimeMethodHiddenParam + 152 + 8) + -8;
            // 0x010D6A10: CMP x12, x22               | STATE = COMPARE((__RuntimeMethodHiddenParam + 152 + 8) + -8, X3 + 48 + 8)
            // 0x010D6A14: B.EQ #0x10d6a3c            | if ((__RuntimeMethodHiddenParam + 152 + 8) + -8 == X3 + 48 + 8) goto label_15;
            if(((__RuntimeMethodHiddenParam + 152 + 8) + -8) == (X3 + 48 + 8))
            {
                goto label_15;
            }
            // 0x010D6A18: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_20 = val_20 + 1;
            // 0x010D6A1C: ADD x10, x10, #0x10        | X10 = ((__RuntimeMethodHiddenParam + 152 + 8) + 16);
            val_19 = val_19 + 16;
            // 0x010D6A20: CMP x11, x9                | STATE = COMPARE((0 + 1), __RuntimeMethodHiddenParam + 258)
            // 0x010D6A24: B.LO #0x10d6a0c            | if (0 < __RuntimeMethodHiddenParam + 258) goto label_16;
            if(val_20 < (__RuntimeMethodHiddenParam + 258))
            {
                goto label_16;
            }
            label_14:
            // 0x010D6A28: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            val_17 = 0;
            // 0x010D6A2C: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam;//m1    
            val_21 = val_15;
            // 0x010D6A30: MOV x1, x22                | X1 = X3 + 48 + 8;//m1                   
            val_20 = X3 + 48 + 8;
            // 0x010D6A34: BL #0x2776c24              | X0 = sub_2776C24( ?? __RuntimeMethodHiddenParam, ????);
            // 0x010D6A38: B #0x10d6a48               |  goto label_17;                         
            goto label_17;
            label_15:
            // 0x010D6A3C: LDR w9, [x10]              | W9 = (__RuntimeMethodHiddenParam + 152 + 8);
            // 0x010D6A40: ADD x8, x8, x9, lsl #4     | X8 = (__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4);
            val_21 = val_21 + (((__RuntimeMethodHiddenParam + 152 + 8)) << 4);
            // 0x010D6A44: ADD x0, x8, #0x110         | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272);
            val_21 = val_21 + 272;
            label_17:
            // 0x010D6A48: LDP x8, x1, [x0]           | X8 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272); X1 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272) + 8; //  | 
            // 0x010D6A4C: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam;//m1    
            // 0x010D6A50: BLR x8                     | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272)();
            // 0x010D6A54: MOV x22, x0                | X22 = __RuntimeMethodHiddenParam;//m1   
            // 0x010D6A58: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x010D6A5C: LDR x23, [x8, #0x10]       | X23 = X3 + 48 + 16;                     
            // 0x010D6A60: MOV x0, x23                | X0 = X3 + 48 + 16;//m1                  
            // 0x010D6A64: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 16, ????);
            // 0x010D6A68: LDR x8, [x21]              | X8 = typeof(System.Collections.Generic.IEnumerable<T>);
            // 0x010D6A6C: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x010D6A70: CBZ x9, #0x10d6a9c         | if (System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_18;
            // 0x010D6A74: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x010D6A78: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_22 = 0;
            // 0x010D6A7C: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608428040 (0x1000000000182008);
            label_20:
            // 0x010D6A80: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010D6A84: CMP x12, x23               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X3 + 48 + 16)
            // 0x010D6A88: B.EQ #0x10d6ab0            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X3 + 48 + 16) goto label_19;
            // 0x010D6A8C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_22 = val_22 + 1;
            // 0x010D6A90: ADD x10, x10, #0x10        | X10 = (1152921504608428040 + 16) = 1152921504608428056 (0x1000000000182018);
            // 0x010D6A94: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x010D6A98: B.LO #0x10d6a80            | if (0 < System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interface_offsets_count) goto label_20;
            label_18:
            // 0x010D6A9C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            val_17 = 2;
            // 0x010D6AA0: MOV x0, x21                | X0 = collection;//m1                    
            val_22 = val_16;
            // 0x010D6AA4: MOV x1, x23                | X1 = X3 + 48 + 16;//m1                  
            // 0x010D6AA8: BL #0x2776c24              | X0 = sub_2776C24( ?? collection, ????); 
            // 0x010D6AAC: B #0x10d6ac0               |  goto label_21;                         
            goto label_21;
            label_19:
            // 0x010D6AB0: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010D6AB4: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x010D6AB8: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504608391168 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x010D6ABC: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608391168 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_21:
            // 0x010D6AC0: LDP x8, x2, [x0]           | X8 = X3 + 48 + 16; X2 = X3 + 48 + 16 + 8; //  | 
            // 0x010D6AC4: MOV x0, x21                | X0 = collection;//m1                    
            // 0x010D6AC8: MOV x1, x22                | X1 = __RuntimeMethodHiddenParam;//m1    
            // 0x010D6ACC: BLR x8                     | X0 = X3 + 48 + 16();                    
            // 0x010D6AD0: B #0x10d6968               |  goto label_22;                         
            goto label_22;
            // 0x010D6AD4: BL #0x981060               | X0 = sub_981060( ?? collection, ????);  
            // 0x010D6AD8: LDR x20, [x0]              | X20 = typeof(System.Collections.Generic.IEnumerable<T>);
            // 0x010D6ADC: BL #0x980920               | X0 = sub_980920( ?? collection, ????);  
            // 0x010D6AE0: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_30:
            // 0x010D6AE4: CBZ x19, #0x10d6b50        | if (__RuntimeMethodHiddenParam == 0) goto label_23;
            if(val_15 == 0)
            {
                goto label_23;
            }
            // 0x010D6AE8: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x010D6AEC: LDR x8, [x19]              | X8 = __RuntimeMethodHiddenParam;        
            var val_25 = val_15;
            // 0x010D6AF0: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x010D6AF4: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x010D6AF8: LDRH w9, [x8, #0x102]      | W9 = __RuntimeMethodHiddenParam + 258;  
            // 0x010D6AFC: CBZ x9, #0x10d6b28         | if (__RuntimeMethodHiddenParam + 258 == 0) goto label_24;
            if((__RuntimeMethodHiddenParam + 258) == 0)
            {
                goto label_24;
            }
            // 0x010D6B00: LDR x10, [x8, #0x98]       | X10 = __RuntimeMethodHiddenParam + 152; 
            var val_23 = __RuntimeMethodHiddenParam + 152;
            // 0x010D6B04: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_24 = 0;
            // 0x010D6B08: ADD x10, x10, #8           | X10 = (__RuntimeMethodHiddenParam + 152 + 8);
            val_23 = val_23 + 8;
            label_26:
            // 0x010D6B0C: LDUR x12, [x10, #-8]       | X12 = (__RuntimeMethodHiddenParam + 152 + 8) + -8;
            // 0x010D6B10: CMP x12, x1                | STATE = COMPARE((__RuntimeMethodHiddenParam + 152 + 8) + -8, typeof(System.IDisposable))
            // 0x010D6B14: B.EQ #0x10d6b38            | if ((__RuntimeMethodHiddenParam + 152 + 8) + -8 == null) goto label_25;
            if(((__RuntimeMethodHiddenParam + 152 + 8) + -8) == null)
            {
                goto label_25;
            }
            // 0x010D6B18: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_24 = val_24 + 1;
            // 0x010D6B1C: ADD x10, x10, #0x10        | X10 = ((__RuntimeMethodHiddenParam + 152 + 8) + 16);
            val_23 = val_23 + 16;
            // 0x010D6B20: CMP x11, x9                | STATE = COMPARE((0 + 1), __RuntimeMethodHiddenParam + 258)
            // 0x010D6B24: B.LO #0x10d6b0c            | if (0 < __RuntimeMethodHiddenParam + 258) goto label_26;
            if(val_24 < (__RuntimeMethodHiddenParam + 258))
            {
                goto label_26;
            }
            label_24:
            // 0x010D6B28: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x010D6B2C: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam;//m1    
            val_23 = val_15;
            // 0x010D6B30: BL #0x2776c24              | X0 = sub_2776C24( ?? __RuntimeMethodHiddenParam, ????);
            // 0x010D6B34: B #0x10d6b44               |  goto label_27;                         
            goto label_27;
            label_25:
            // 0x010D6B38: LDR w9, [x10]              | W9 = (__RuntimeMethodHiddenParam + 152 + 8);
            // 0x010D6B3C: ADD x8, x8, x9, lsl #4     | X8 = (__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4);
            val_25 = val_25 + (((__RuntimeMethodHiddenParam + 152 + 8)) << 4);
            // 0x010D6B40: ADD x0, x8, #0x110         | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272);
            val_23 = val_25 + 272;
            label_27:
            // 0x010D6B44: LDP x8, x1, [x0]           | X8 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272); X1 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272) + 8; //  | 
            // 0x010D6B48: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam;//m1    
            // 0x010D6B4C: BLR x8                     | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272)();
            label_23:
            // 0x010D6B50: CMP w21, #0x4f             | STATE = COMPARE(0x0, 0x4F)              
            // 0x010D6B54: B.EQ #0x10d6b78            | if (val_16 == 0x4F) goto label_29;      
            if(val_16 == 79)
            {
                goto label_29;
            }
            // 0x010D6B58: CBZ x20, #0x10d6b78        | if (typeof(System.Collections.Generic.IEnumerable<T>) == null) goto label_29;
            if(null == null)
            {
                goto label_29;
            }
            // 0x010D6B5C: MOV x0, x20                | X0 = 1152921504608391168 (0x1000000000179000);//ML01
            // 0x010D6B60: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x010D6B64: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            val_15 = ???;
            // 0x010D6B68: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            val_16 = ???;
            // 0x010D6B6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010D6B70: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x010D6B74: B #0x27ae3bc               | X0 = sub_27AE3BC( ?? typeof(System.Collections.Generic.IEnumerable<T>), ????);
            label_29:
            // 0x010D6B78: LDP x29, x30, [sp, #0x30]  | X29 = val_3; X30 = val_4;                //  find_add[1152921513962740576] |  find_add[1152921513962740576]
            // 0x010D6B7C: LDP x20, x19, [sp, #0x20]  | X20 = val_5; X19 = val_6;                //  find_add[1152921513962740576] |  find_add[1152921513962740576]
            // 0x010D6B80: LDP x22, x21, [sp, #0x10]  | X22 = val_7; X21 = val_8;                //  find_add[1152921513962740576] |  find_add[1152921513962740576]
            // 0x010D6B84: LDP x24, x23, [sp], #0x40  | X24 = val_9; X23 = val_10;               //  find_add[1152921513962740576] |  find_add[1152921513962740576]
            // 0x010D6B88: RET                        |  return;                                
            return;
            label_12:
            // 0x010D6B8C: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            // 0x010D6B90: MOVZ w21, #0x4f            | W21 = 79 (0x4F);//ML01                  
            // 0x010D6B94: B #0x10d6ae4               |  goto label_30;                         
            goto label_30;
            label_1:
            // 0x010D6B98: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x010D6B9C: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x010D6BA0: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            System.ArgumentNullException val_11 = null;
            // 0x010D6BA4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x010D6BA8: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x010D6BAC: LDR x8, [x8, #0x758]       | X8 = (string**)(1152921513962739456)("initial");
            // 0x010D6BB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010D6BB4: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x010D6BB8: LDR x1, [x8]               | X1 = "initial";                         
            // 0x010D6BBC: BL #0x18b3df0              | .ctor(paramName:  "initial");           
            val_11 = new System.ArgumentNullException(paramName:  "initial");
            // 0x010D6BC0: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x010D6BC4: LDR x8, [x8, #0xd58]       | X8 = 1152921513962739552;               
            // 0x010D6BC8: MOV x0, x19                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x010D6BCC: LDR x1, [x8]               | X1 = public static System.Void Newtonsoft.Json.Utilities.CollectionUtils::AddRange<System.Object>(System.Collections.Generic.IList<T> initial, System.Collections.Generic.IEnumerable<T> collection);
            // 0x010D6BD0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentNullException), ????);
            // 0x010D6BD4: BL #0x10d0140              | Newtonsoft.Json.Utilities.CollectionUtils.AddRange<System.Object>(initial:  val_11, collection:  public static System.Void Newtonsoft.Json.Utilities.CollectionUtils::AddRange<System.Object>(System.Collections.Generic.IList<T> initial, System.Collections.Generic.IEnumerable<T> collection));
            Newtonsoft.Json.Utilities.CollectionUtils.AddRange<System.Object>(initial:  val_11, collection:  public static System.Void Newtonsoft.Json.Utilities.CollectionUtils::AddRange<System.Object>(System.Collections.Generic.IList<T> initial, System.Collections.Generic.IEnumerable<T> collection));
        
        }
        //
        // Offset in libil2cpp.so: 0x02911D88 (43064712), len: 184  VirtAddr: 0x02911D88 RVA: 0x02911D88 token: 100686554 methodIndex: 49117 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x28632D8
        public static void AddRange(System.Collections.IList initial, System.Collections.IEnumerable collection)
        {
            //
            // Disasemble & Code
            // 0x02911D88: STP x22, x21, [sp, #-0x30]! | stack[1152921513962886032] = ???;  stack[1152921513962886040] = ???;  //  dest_result_addr=1152921513962886032 |  dest_result_addr=1152921513962886040
            // 0x02911D8C: STP x20, x19, [sp, #0x10]  | stack[1152921513962886048] = ???;  stack[1152921513962886056] = ???;  //  dest_result_addr=1152921513962886048 |  dest_result_addr=1152921513962886056
            // 0x02911D90: STP x29, x30, [sp, #0x20]  | stack[1152921513962886064] = ???;  stack[1152921513962886072] = ???;  //  dest_result_addr=1152921513962886064 |  dest_result_addr=1152921513962886072
            // 0x02911D94: ADD x29, sp, #0x20         | X29 = (1152921513962886032 + 32) = 1152921513962886064 (0x100000022DA9D3B0);
            // 0x02911D98: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x02911D9C: LDRB w8, [x21, #0xaed]     | W8 = (bool)static_value_037B8AED;       
            // 0x02911DA0: MOV x19, x2                | X19 = X2;//m1                           
            // 0x02911DA4: MOV x20, x1                | X20 = collection;//m1                   
            // 0x02911DA8: TBNZ w8, #0, #0x2911dc4    | if (static_value_037B8AED == true) goto label_0;
            // 0x02911DAC: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
            // 0x02911DB0: LDR x8, [x8, #0xea0]       | X8 = 0x2B915D0;                         
            // 0x02911DB4: LDR w0, [x8]               | W0 = 0x1C38;                            
            // 0x02911DB8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C38, ????);     
            // 0x02911DBC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02911DC0: STRB w8, [x21, #0xaed]     | static_value_037B8AED = true;            //  dest_result_addr=58428141
            label_0:
            // 0x02911DC4: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x02911DC8: LDR x8, [x8, #0x758]       | X8 = (string**)(1152921513962739456)("initial");
            // 0x02911DCC: MOV x1, x20                | X1 = collection;//m1                    
            // 0x02911DD0: LDR x2, [x8]               | X2 = "initial";                         
            // 0x02911DD4: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  7224, parameterName:  collection);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  7224, parameterName:  collection);
            // 0x02911DD8: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
            // 0x02911DDC: LDR x8, [x8, #0x880]       | X8 = 1152921504868827136;               
            // 0x02911DE0: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Utilities.ListWrapper<T>);
            Newtonsoft.Json.Utilities.ListWrapper<System.Object> val_1 = null;
            // 0x02911DE4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Utilities.ListWrapper<T>), ????);
            // 0x02911DE8: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x02911DEC: LDR x8, [x8, #0x758]       | X8 = 1152921513962868960;               
            // 0x02911DF0: MOV x1, x20                | X1 = collection;//m1                    
            // 0x02911DF4: MOV x21, x0                | X21 = 1152921504868827136 (0x100000000F9D8000);//ML01
            // 0x02911DF8: LDR x2, [x8]               | X2 = public System.Void Newtonsoft.Json.Utilities.ListWrapper<System.Object>::.ctor(System.Collections.IList list);
            // 0x02911DFC: BL #0x19eeb68              | .ctor(list:  collection);               
            val_1 = new Newtonsoft.Json.Utilities.ListWrapper<System.Object>(list:  collection);
            // 0x02911E00: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
            // 0x02911E04: LDR x8, [x8, #0xed0]       | X8 = 1152921513919976368;               
            // 0x02911E08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02911E0C: MOV x1, x19                | X1 = X2;//m1                            
            // 0x02911E10: LDR x2, [x8]               | X2 = public static System.Collections.Generic.IEnumerable<TResult> System.Linq.Enumerable::Cast<System.Object>(System.Collections.IEnumerable source);
            // 0x02911E14: BL #0xb6ecec               | X0 = System.Linq.Enumerable.Cast<System.Reflection.MemberInfo>(source:  0);
            System.Collections.Generic.IEnumerable<TResult> val_2 = System.Linq.Enumerable.Cast<System.Reflection.MemberInfo>(source:  0);
            // 0x02911E18: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x02911E1C: LDR x8, [x8, #0xd58]       | X8 = 1152921513962739552;               
            // 0x02911E20: MOV x2, x0                 | X2 = val_2;//m1                         
            // 0x02911E24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02911E28: MOV x1, x21                | X1 = 1152921504868827136 (0x100000000F9D8000);//ML01
            // 0x02911E2C: LDR x3, [x8]               | X3 = public static System.Void Newtonsoft.Json.Utilities.CollectionUtils::AddRange<System.Object>(System.Collections.Generic.IList<T> initial, System.Collections.Generic.IEnumerable<T> collection);
            // 0x02911E30: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x02911E34: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x02911E38: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x02911E3C: B #0x10d68a0               | Newtonsoft.Json.Utilities.CollectionUtils.AddRange<System.Reflection.MemberInfo>(initial:  0, collection:  val_1); return;
            Newtonsoft.Json.Utilities.CollectionUtils.AddRange<System.Reflection.MemberInfo>(initial:  0, collection:  val_1);
            return;
        
        }
        // Generic instance method:
        //
        // file offset: 0x00B7A604 VirtAddr: 0x00B7A604 -RVA: 0x00B7A604 
        // -CollectionUtils.Distinct<object>
        //
        //
        // Offset in libil2cpp.so: 0x00B7A604 (12035588), len: 536  VirtAddr: 0x00B7A604 RVA: 0x00B7A604 token: 100686555 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static System.Collections.Generic.List<T> Distinct<T>(System.Collections.Generic.List<T> collection)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            var val_2;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00B7A604: STP x24, x23, [sp, #-0x40]! | stack[1152921513963018496] = ???;  stack[1152921513963018504] = ???;  //  dest_result_addr=1152921513963018496 |  dest_result_addr=1152921513963018504
            // 0x00B7A608: STP x22, x21, [sp, #0x10]  | stack[1152921513963018512] = ???;  stack[1152921513963018520] = ???;  //  dest_result_addr=1152921513963018512 |  dest_result_addr=1152921513963018520
            // 0x00B7A60C: STP x20, x19, [sp, #0x20]  | stack[1152921513963018528] = ???;  stack[1152921513963018536] = ???;  //  dest_result_addr=1152921513963018528 |  dest_result_addr=1152921513963018536
            // 0x00B7A610: STP x29, x30, [sp, #0x30]  | stack[1152921513963018544] = ???;  stack[1152921513963018552] = ???;  //  dest_result_addr=1152921513963018544 |  dest_result_addr=1152921513963018552
            // 0x00B7A614: ADD x29, sp, #0x30         | X29 = (1152921513963018496 + 48) = 1152921513963018544 (0x100000022DABD930);
            // 0x00B7A618: SUB sp, sp, #0x50          | SP = (1152921513963018496 - 80) = 1152921513963018416 (0x100000022DABD8B0);
            // 0x00B7A61C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00B7A620: LDRB w8, [x19, #0x9c1]     | W8 = (bool)static_value_037339C1;       
            // 0x00B7A624: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00B7A628: MOV x21, x1                | X21 = __RuntimeMethodHiddenParam;//m1   
            // 0x00B7A62C: TBNZ w8, #0, #0xb7a648     | if (static_value_037339C1 == true) goto label_0;
            // 0x00B7A630: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
            // 0x00B7A634: LDR x8, [x8, #0x398]       | X8 = 0x2B91600;                         
            // 0x00B7A638: LDR w0, [x8]               | W0 = 0x1C44;                            
            // 0x00B7A63C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C44, ????);     
            // 0x00B7A640: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00B7A644: STRB w8, [x19, #0x9c1]     | static_value_037339C1 = true;            //  dest_result_addr=57883073
            label_0:
            // 0x00B7A648: STP xzr, xzr, [sp, #0x38]  | stack[1152921513963018472] = 0x0;  stack[1152921513963018480] = 0x0;  //  dest_result_addr=1152921513963018472 |  dest_result_addr=1152921513963018480
            // 0x00B7A64C: STR xzr, [sp, #0x30]       | stack[1152921513963018464] = 0x0;        //  dest_result_addr=1152921513963018464
            // 0x00B7A650: LDR x8, [x20, #0x30]       | X8 = X2 + 48;                           
            // 0x00B7A654: LDR x19, [x8]              | X19 = X2 + 48;                          
            // 0x00B7A658: MOV x0, x19                | X0 = X2 + 48;//m1                       
            // 0x00B7A65C: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 48, ????);    
            // 0x00B7A660: MOV x0, x19                | X0 = X2 + 48;//m1                       
            // 0x00B7A664: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X2 + 48, ????);
            // 0x00B7A668: LDR x8, [x20, #0x30]       | X8 = X2 + 48;                           
            // 0x00B7A66C: MOV x19, x0                | X19 = X2 + 48;//m1                      
            // 0x00B7A670: LDR x1, [x8, #8]           | X1 = X2 + 48 + 8;                       
            // 0x00B7A674: LDR x8, [x1]               | X8 = X2 + 48 + 8;                       
            // 0x00B7A678: BLR x8                     | X0 = X2 + 48 + 8();                     
            // 0x00B7A67C: CBNZ x21, #0xb7a684        | if (__RuntimeMethodHiddenParam != 0) goto label_1;
            if(__RuntimeMethodHiddenParam != 0)
            {
                goto label_1;
            }
            // 0x00B7A680: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X2 + 48, ????);    
            label_1:
            // 0x00B7A684: LDR x8, [x20, #0x30]       | X8 = X2 + 48;                           
            // 0x00B7A688: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam;//m1    
            // 0x00B7A68C: LDR x1, [x8, #0x10]        | X1 = X2 + 48 + 16;                      
            // 0x00B7A690: ADD x8, sp, #8             | X8 = (1152921513963018416 + 8) = 1152921513963018424 (0x100000022DABD8B8);
            // 0x00B7A694: LDR x9, [x1]               | X9 = X2 + 48 + 16;                      
            // 0x00B7A698: BLR x9                     | X0 = X2 + 48 + 16();                    
            // 0x00B7A69C: LDR x8, [sp, #0x18]        | X8 = val_1;                              //  find_add[1152921513963006560]
            // 0x00B7A6A0: LDUR q0, [sp, #8]          | Q0 = val_2;                              //  find_add[1152921513963006560]
            // 0x00B7A6A4: STR x8, [sp, #0x40]        | stack[1152921513963018480] = val_1;      //  dest_result_addr=1152921513963018480
            // 0x00B7A6A8: STR q0, [sp, #0x30]        | stack[1152921513963018464] = val_2;      //  dest_result_addr=1152921513963018464
            label_6:
            // 0x00B7A6AC: LDR x8, [x20, #0x30]       | X8 = X2 + 48;                           
            // 0x00B7A6B0: LDR x1, [x8, #0x30]        | X1 = X2 + 48 + 48;                      
            // 0x00B7A6B4: ADD x0, sp, #0x30          | X0 = (1152921513963018416 + 48) = 1152921513963018464 (0x100000022DABD8E0);
            // 0x00B7A6B8: BL #0x133720c              | X0 = label_List_Enumerator<System_Object>_VerifyState_GL0133720C();
            // 0x00B7A6BC: AND w8, w0, #1             | W8 = (1152921513963018464 & 1) = 0 (0x00000000);
            // 0x00B7A6C0: TBZ w8, #0, #0xb7a738      | if ((0x0 & 0x1) == 0) goto label_2;     
            if((0 & 1) == 0)
            {
                goto label_2;
            }
            // 0x00B7A6C4: LDR x8, [x20, #0x30]       | X8 = X2 + 48;                           
            // 0x00B7A6C8: LDR x1, [x8, #0x18]        | X1 = X2 + 48 + 24;                      
            // 0x00B7A6CC: ADD x0, sp, #0x30          | X0 = (1152921513963018416 + 48) = 1152921513963018464 (0x100000022DABD8E0);
            // 0x00B7A6D0: BL #0x13372d8              | X0 = val_2.get_InitialType();           
            System.Type val_3 = val_2.InitialType;
            // 0x00B7A6D4: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00B7A6D8: CBNZ x19, #0xb7a6e0        | if (X2 + 48 != 0) goto label_3;         
            if((X2 + 48) != 0)
            {
                goto label_3;
            }
            // 0x00B7A6DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_3:
            // 0x00B7A6E0: LDR x8, [x20, #0x30]       | X8 = X2 + 48;                           
            // 0x00B7A6E4: LDR x2, [x8, #0x20]        | X2 = X2 + 48 + 32;                      
            // 0x00B7A6E8: LDR x8, [x2]               | X8 = X2 + 48 + 32;                      
            // 0x00B7A6EC: MOV x0, x19                | X0 = X2 + 48;//m1                       
            // 0x00B7A6F0: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00B7A6F4: BLR x8                     | X0 = X2 + 48 + 32();                    
            // 0x00B7A6F8: AND w8, w0, #1             | W8 = (X2 + 48 & 1);                     
            var val_4 = (X2 + 48) & 1;
            // 0x00B7A6FC: TBNZ w8, #0, #0xb7a6ac     | if (((X2 + 48 & 1) & 0x1) != 0) goto label_6;
            if((val_4 & 1) != 0)
            {
                goto label_6;
            }
            // 0x00B7A700: CBNZ x19, #0xb7a708        | if (X2 + 48 != 0) goto label_5;         
            if((X2 + 48) != 0)
            {
                goto label_5;
            }
            // 0x00B7A704: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X2 + 48, ????);    
            label_5:
            // 0x00B7A708: LDR x8, [x20, #0x30]       | X8 = X2 + 48;                           
            // 0x00B7A70C: LDR x2, [x8, #0x28]        | X2 = X2 + 48 + 40;                      
            // 0x00B7A710: LDR x8, [x2]               | X8 = X2 + 48 + 40;                      
            // 0x00B7A714: MOV x0, x19                | X0 = X2 + 48;//m1                       
            // 0x00B7A718: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00B7A71C: BLR x8                     | X0 = X2 + 48 + 40();                    
            // 0x00B7A720: B #0xb7a6ac                |  goto label_6;                          
            goto label_6;
            // 0x00B7A724: BL #0x981060               | X0 = sub_981060( ?? X2 + 48, ????);     
            // 0x00B7A728: LDR x21, [x0]              | X21 = X2 + 48;                          
            val_7 = mem[X2 + 48];
            val_7 = X2 + 48;
            // 0x00B7A72C: BL #0x980920               | X0 = sub_980920( ?? X2 + 48, ????);     
            // 0x00B7A730: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_8 = 0;
            // 0x00B7A734: B #0xb7a740                |  goto label_7;                          
            goto label_7;
            label_2:
            // 0x00B7A738: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_7 = 0;
            // 0x00B7A73C: MOVZ w22, #0x4c            | W22 = 76 (0x4C);//ML01                  
            val_8 = 76;
            label_7:
            // 0x00B7A740: LDR x8, [x20, #0x30]       | X8 = X2 + 48;                           
            // 0x00B7A744: LDR x20, [x8, #0x38]       | X20 = X2 + 48 + 56;                     
            // 0x00B7A748: MOV x0, x20                | X0 = X2 + 48 + 56;//m1                  
            // 0x00B7A74C: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 48 + 56, ????);
            // 0x00B7A750: LDR x9, [sp, #0x40]        | X9 = val_1;                             
            // 0x00B7A754: LDR q0, [sp, #0x30]        | Q0 = val_2;                             
            // 0x00B7A758: ADRP x10, #0x35df000       | X10 = 56487936 (0x35DF000);             
            // 0x00B7A75C: STR x20, [sp, #8]          | val_2 = X2 + 48 + 56;                    //  dest_result_addr=1152921513963018424
            val_2 = X2 + 48 + 56;
            // 0x00B7A760: LDR x10, [x10, #0x7a8]     | X10 = 1152921504608124928;              
            // 0x00B7A764: MOVN x8, #0                | X8 = 0 (0x0);//ML01                     
            // 0x00B7A768: STR x8, [sp, #0x10]        | stack[1152921513963018432] = 0x0;        //  dest_result_addr=1152921513963018432
            // 0x00B7A76C: STR x9, [sp, #0x28]        | stack[1152921513963018456] = val_1;      //  dest_result_addr=1152921513963018456
            // 0x00B7A770: STUR q0, [sp, #0x18]       | val_1 = val_2;                           //  dest_result_addr=1152921513963018440
            val_1 = val_2;
            // 0x00B7A774: LDR x1, [x10]              | X1 = typeof(System.IDisposable);        
            // 0x00B7A778: LDRH w8, [x20, #0x102]     | W8 = X2 + 48 + 56 + 258;                
            // 0x00B7A77C: ADD x9, sp, #8             | X9 = (1152921513963018416 + 8) = 1152921513963018424 (0x100000022DABD8B8);
            // 0x00B7A780: ADD x23, x9, #0x10         | X23 = (1152921513963018424 + 16) = 1152921513963018440 (0x100000022DABD8C8);
            // 0x00B7A784: CBZ x8, #0xb7a7b0          | if (X2 + 48 + 56 + 258 == 0) goto label_8;
            if((X2 + 48 + 56 + 258) == 0)
            {
                goto label_8;
            }
            // 0x00B7A788: LDR x9, [x20, #0x98]       | X9 = X2 + 48 + 56 + 152;                
            var val_6 = X2 + 48 + 56 + 152;
            // 0x00B7A78C: MOV x10, xzr               | X10 = 0 (0x0);//ML01                    
            var val_7 = 0;
            // 0x00B7A790: ADD x9, x9, #8             | X9 = (X2 + 48 + 56 + 152 + 8);          
            val_6 = val_6 + 8;
            label_10:
            // 0x00B7A794: LDUR x11, [x9, #-8]        | X11 = (X2 + 48 + 56 + 152 + 8) + -8;    
            // 0x00B7A798: CMP x11, x1                | STATE = COMPARE((X2 + 48 + 56 + 152 + 8) + -8, typeof(System.IDisposable))
            // 0x00B7A79C: B.EQ #0xb7a7c0             | if ((X2 + 48 + 56 + 152 + 8) + -8 == null) goto label_9;
            if(((X2 + 48 + 56 + 152 + 8) + -8) == null)
            {
                goto label_9;
            }
            // 0x00B7A7A0: ADD x10, x10, #1           | X10 = (0 + 1);                          
            val_7 = val_7 + 1;
            // 0x00B7A7A4: ADD x9, x9, #0x10          | X9 = ((X2 + 48 + 56 + 152 + 8) + 16);   
            val_6 = val_6 + 16;
            // 0x00B7A7A8: CMP x10, x8                | STATE = COMPARE((0 + 1), X2 + 48 + 56 + 258)
            // 0x00B7A7AC: B.LO #0xb7a794             | if (0 < X2 + 48 + 56 + 258) goto label_10;
            if(val_7 < (X2 + 48 + 56 + 258))
            {
                goto label_10;
            }
            label_8:
            // 0x00B7A7B0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B7A7B4: ADD x0, sp, #8             | X0 = (1152921513963018416 + 8) = 1152921513963018424 (0x100000022DABD8B8);
            // 0x00B7A7B8: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x100000022DABD8B8, ????);
            // 0x00B7A7BC: B #0xb7a7cc                |  goto label_11;                         
            goto label_11;
            label_9:
            // 0x00B7A7C0: LDR w8, [x9]               | W8 = (X2 + 48 + 56 + 152 + 8);          
            // 0x00B7A7C4: ADD x8, x20, x8, lsl #4    | X8 = (X2 + 48 + 56 + ((X2 + 48 + 56 + 152 + 8)) << 4);
            var val_5 = (X2 + 48 + 56) + (((X2 + 48 + 56 + 152 + 8)) << 4);
            // 0x00B7A7C8: ADD x0, x8, #0x110         | X0 = ((X2 + 48 + 56 + ((X2 + 48 + 56 + 152 + 8)) << 4) + 272);
            val_9 = val_5 + 272;
            label_11:
            // 0x00B7A7CC: LDP x8, x1, [x0]           | X8 = ((X2 + 48 + 56 + ((X2 + 48 + 56 + 152 + 8)) << 4) + 272); X1 = ((X2 + 48 + 56 + ((X2 + 48 + 56 + 152 + 8)) << 4) + 272) + 8; //  | 
            // 0x00B7A7D0: ADD x0, sp, #8             | X0 = (1152921513963018416 + 8) = 1152921513963018424 (0x100000022DABD8B8);
            // 0x00B7A7D4: BLR x8                     | X0 = ((X2 + 48 + 56 + ((X2 + 48 + 56 + 152 + 8)) << 4) + 272)();
            // 0x00B7A7D8: LDR x8, [x23, #0x10]       | X8 = val_1;                             
            // 0x00B7A7DC: LDR q0, [x23]              | Q0 = val_2;                             
            // 0x00B7A7E0: CMP w22, #0x4c             | STATE = COMPARE(0x4C, 0x4C)             
            // 0x00B7A7E4: STR x8, [sp, #0x40]        | stack[1152921513963018480] = val_1;      //  dest_result_addr=1152921513963018480
            // 0x00B7A7E8: STR q0, [sp, #0x30]        | stack[1152921513963018464] = val_2;      //  dest_result_addr=1152921513963018464
            // 0x00B7A7EC: B.EQ #0xb7a800             | if (0x4C == 0x4C) goto label_13;        
            if(76 == 76)
            {
                goto label_13;
            }
            // 0x00B7A7F0: CBZ x21, #0xb7a800         | if (0x0 == 0) goto label_13;            
            if(val_7 == 0)
            {
                goto label_13;
            }
            // 0x00B7A7F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B7A7F8: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00B7A7FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_13:
            // 0x00B7A800: MOV x0, x19                | X0 = X2 + 48;//m1                       
            // 0x00B7A804: SUB sp, x29, #0x30         | SP = (1152921513963018544 - 48) = 1152921513963018496 (0x100000022DABD900);
            // 0x00B7A808: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00B7A80C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00B7A810: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00B7A814: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00B7A818: RET                        |  return (System.Collections.Generic.List<T>)X2 + 48;
            return (System.Collections.Generic.List<T>)X2 + 48;
            //  |  // // {name=val_0, type=System.Collections.Generic.List<T>, size=8, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x00B7A268 VirtAddr: 0x00B7A268 -RVA: 0x00B7A268 
        // -CollectionUtils.Flatten<object>
        //
        //
        // Offset in libil2cpp.so: 0x00B7A268 (12034664), len: 224  VirtAddr: 0x00B7A268 RVA: 0x00B7A268 token: 100686556 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static System.Collections.Generic.List<System.Collections.Generic.List<T>> Flatten<T>(System.Collections.Generic.IList<T>[] lists)
        {
            //
            // Disasemble & Code
            // 0x00B7A268: STP x24, x23, [sp, #-0x40]! | stack[1152921513963175552] = ???;  stack[1152921513963175560] = ???;  //  dest_result_addr=1152921513963175552 |  dest_result_addr=1152921513963175560
            // 0x00B7A26C: STP x22, x21, [sp, #0x10]  | stack[1152921513963175568] = ???;  stack[1152921513963175576] = ???;  //  dest_result_addr=1152921513963175568 |  dest_result_addr=1152921513963175576
            // 0x00B7A270: STP x20, x19, [sp, #0x20]  | stack[1152921513963175584] = ???;  stack[1152921513963175592] = ???;  //  dest_result_addr=1152921513963175584 |  dest_result_addr=1152921513963175592
            // 0x00B7A274: STP x29, x30, [sp, #0x30]  | stack[1152921513963175600] = ???;  stack[1152921513963175608] = ???;  //  dest_result_addr=1152921513963175600 |  dest_result_addr=1152921513963175608
            // 0x00B7A278: ADD x29, sp, #0x30         | X29 = (1152921513963175552 + 48) = 1152921513963175600 (0x100000022DAE3EB0);
            // 0x00B7A27C: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00B7A280: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
            // 0x00B7A284: MOV x21, x1                | X21 = __RuntimeMethodHiddenParam;//m1   
            // 0x00B7A288: LDR x20, [x8]              | X20 = X2 + 48;                          
            // 0x00B7A28C: MOV x0, x20                | X0 = X2 + 48;//m1                       
            // 0x00B7A290: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 48, ????);    
            // 0x00B7A294: MOV x0, x20                | X0 = X2 + 48;//m1                       
            // 0x00B7A298: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X2 + 48, ????);
            // 0x00B7A29C: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
            // 0x00B7A2A0: MOV x20, x0                | X20 = X2 + 48;//m1                      
            // 0x00B7A2A4: LDR x1, [x8, #8]           | X1 = X2 + 48 + 8;                       
            // 0x00B7A2A8: LDR x8, [x1]               | X8 = X2 + 48 + 8;                       
            // 0x00B7A2AC: BLR x8                     | X0 = X2 + 48 + 8();                     
            // 0x00B7A2B0: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
            // 0x00B7A2B4: LDR x22, [x8, #0x10]       | X22 = X2 + 48 + 16;                     
            // 0x00B7A2B8: MOV x0, x22                | X0 = X2 + 48 + 16;//m1                  
            // 0x00B7A2BC: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 48 + 16, ????);
            // 0x00B7A2C0: MOV x0, x22                | X0 = X2 + 48 + 16;//m1                  
            // 0x00B7A2C4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X2 + 48 + 16, ????);
            // 0x00B7A2C8: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
            // 0x00B7A2CC: MOV x22, x0                | X22 = X2 + 48 + 16;//m1                 
            // 0x00B7A2D0: LDR x1, [x8, #0x18]        | X1 = X2 + 48 + 24;                      
            // 0x00B7A2D4: LDR x8, [x1]               | X8 = X2 + 48 + 24;                      
            // 0x00B7A2D8: BLR x8                     | X0 = X2 + 48 + 24();                    
            // 0x00B7A2DC: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
            // 0x00B7A2E0: LDR x23, [x8, #0x20]       | X23 = X2 + 48 + 32;                     
            // 0x00B7A2E4: MOV x0, x23                | X0 = X2 + 48 + 32;//m1                  
            // 0x00B7A2E8: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 48 + 32, ????);
            // 0x00B7A2EC: MOV x0, x23                | X0 = X2 + 48 + 32;//m1                  
            // 0x00B7A2F0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X2 + 48 + 32, ????);
            // 0x00B7A2F4: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
            // 0x00B7A2F8: MOV x1, x21                | X1 = __RuntimeMethodHiddenParam;//m1    
            // 0x00B7A2FC: MOV x23, x0                | X23 = X2 + 48 + 32;//m1                 
            // 0x00B7A300: LDR x2, [x8, #0x28]        | X2 = X2 + 48 + 40;                      
            // 0x00B7A304: LDR x8, [x2]               | X8 = X2 + 48 + 40;                      
            // 0x00B7A308: BLR x8                     | X0 = X2 + 48 + 40();                    
            // 0x00B7A30C: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
            // 0x00B7A310: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B7A314: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B7A318: MOV x1, x23                | X1 = X2 + 48 + 32;//m1                  
            // 0x00B7A31C: LDR x5, [x8, #0x30]        | X5 = X2 + 48 + 48;                      
            // 0x00B7A320: MOV x3, x22                | X3 = X2 + 48 + 16;//m1                  
            // 0x00B7A324: MOV x4, x20                | X4 = X2 + 48;//m1                       
            // 0x00B7A328: LDR x8, [x5]               | X8 = X2 + 48 + 48;                      
            // 0x00B7A32C: BLR x8                     | X0 = X2 + 48 + 48();                    
            // 0x00B7A330: MOV x0, x20                | X0 = X2 + 48;//m1                       
            // 0x00B7A334: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00B7A338: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00B7A33C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00B7A340: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00B7A344: RET                        |  return (System.Collections.Generic.List<System.Collections.Generic.List<T>>)X2 + 48;
            return (System.Collections.Generic.List<System.Collections.Generic.List<T>>)X2 + 48;
            //  |  // // {name=val_0, type=System.Collections.Generic.List<System.Collections.Generic.List<T>>, size=8, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x010D6BD8 VirtAddr: 0x010D6BD8 -RVA: 0x010D6BD8 
        // -CollectionUtils.Recurse<object>
        //
        //
        // Offset in libil2cpp.so: 0x010D6BD8 (17656792), len: 900  VirtAddr: 0x010D6BD8 RVA: 0x010D6BD8 token: 100686557 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private static void Recurse<T>(System.Collections.Generic.IList<System.Collections.Generic.IList<T>> global, int current, System.Collections.Generic.Dictionary<int, T> currentSet, System.Collections.Generic.List<System.Collections.Generic.List<T>> flattenedResult)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            // 0x010D6BD8: STP x28, x27, [sp, #-0x60]! | stack[1152921513963336672] = ???;  stack[1152921513963336680] = ???;  //  dest_result_addr=1152921513963336672 |  dest_result_addr=1152921513963336680
            // 0x010D6BDC: STP x26, x25, [sp, #0x10]  | stack[1152921513963336688] = ???;  stack[1152921513963336696] = ???;  //  dest_result_addr=1152921513963336688 |  dest_result_addr=1152921513963336696
            // 0x010D6BE0: STP x24, x23, [sp, #0x20]  | stack[1152921513963336704] = ???;  stack[1152921513963336712] = ???;  //  dest_result_addr=1152921513963336704 |  dest_result_addr=1152921513963336712
            // 0x010D6BE4: STP x22, x21, [sp, #0x30]  | stack[1152921513963336720] = ???;  stack[1152921513963336728] = ???;  //  dest_result_addr=1152921513963336720 |  dest_result_addr=1152921513963336728
            // 0x010D6BE8: STP x20, x19, [sp, #0x40]  | stack[1152921513963336736] = ???;  stack[1152921513963336744] = ???;  //  dest_result_addr=1152921513963336736 |  dest_result_addr=1152921513963336744
            // 0x010D6BEC: STP x29, x30, [sp, #0x50]  | stack[1152921513963336752] = ???;  stack[1152921513963336760] = ???;  //  dest_result_addr=1152921513963336752 |  dest_result_addr=1152921513963336760
            // 0x010D6BF0: ADD x29, sp, #0x50         | X29 = (1152921513963336672 + 80) = 1152921513963336752 (0x100000022DB0B430);
            // 0x010D6BF4: SUB sp, sp, #0x10          | SP = (1152921513963336672 - 16) = 1152921513963336656 (0x100000022DB0B3D0);
            // 0x010D6BF8: MOV x19, x5                | X19 = X5;//m1                           
            // 0x010D6BFC: MOV x20, x4                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x010D6C00: MOV x21, x3                | X21 = flattenedResult;//m1              
            // 0x010D6C04: MOV w22, w2                | W22 = currentSet;//m1                   
            // 0x010D6C08: MOV x23, x1                | X23 = current;//m1                      
            // 0x010D6C0C: CBNZ x23, #0x10d6c14       | if (current != 0) goto label_0;         
            if(current != 0)
            {
                goto label_0;
            }
            // 0x010D6C10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? global, ????);     
            label_0:
            // 0x010D6C14: LDR x8, [x19, #0x30]       | X8 = X5 + 48;                           
            // 0x010D6C18: LDR x24, [x8]              | X24 = X5 + 48;                          
            // 0x010D6C1C: MOV x0, x24                | X0 = X5 + 48;//m1                       
            // 0x010D6C20: BL #0x277461c              | X0 = sub_277461C( ?? X5 + 48, ????);    
            // 0x010D6C24: LDR x8, [x23]              | X8 = current;                           
            var val_6 = current;
            // 0x010D6C28: LDRH w9, [x8, #0x102]      | W9 = current + 258;                     
            // 0x010D6C2C: CBZ x9, #0x10d6c58         | if (current + 258 == 0) goto label_1;   
            if((current + 258) == 0)
            {
                goto label_1;
            }
            // 0x010D6C30: LDR x10, [x8, #0x98]       | X10 = current + 152;                    
            var val_3 = current + 152;
            // 0x010D6C34: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_4 = 0;
            // 0x010D6C38: ADD x10, x10, #8           | X10 = (current + 152 + 8);              
            val_3 = val_3 + 8;
            label_3:
            // 0x010D6C3C: LDUR x12, [x10, #-8]       | X12 = (current + 152 + 8) + -8;         
            // 0x010D6C40: CMP x12, x24               | STATE = COMPARE((current + 152 + 8) + -8, X5 + 48)
            // 0x010D6C44: B.EQ #0x10d6c6c            | if ((current + 152 + 8) + -8 == X5 + 48) goto label_2;
            if(((current + 152 + 8) + -8) == (X5 + 48))
            {
                goto label_2;
            }
            // 0x010D6C48: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_4 = val_4 + 1;
            // 0x010D6C4C: ADD x10, x10, #0x10        | X10 = ((current + 152 + 8) + 16);       
            val_3 = val_3 + 16;
            // 0x010D6C50: CMP x11, x9                | STATE = COMPARE((0 + 1), current + 258) 
            // 0x010D6C54: B.LO #0x10d6c3c            | if (0 < current + 258) goto label_3;    
            if(val_4 < (current + 258))
            {
                goto label_3;
            }
            label_1:
            // 0x010D6C58: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x010D6C5C: MOV x0, x23                | X0 = current;//m1                       
            val_7 = current;
            // 0x010D6C60: MOV x1, x24                | X1 = X5 + 48;//m1                       
            // 0x010D6C64: BL #0x2776c24              | X0 = sub_2776C24( ?? current, ????);    
            // 0x010D6C68: B #0x10d6c7c               |  goto label_4;                          
            goto label_4;
            label_2:
            // 0x010D6C6C: LDR w9, [x10]              | W9 = (current + 152 + 8);               
            var val_5 = val_3;
            // 0x010D6C70: ADD w9, w9, #3             | W9 = ((current + 152 + 8) + 3);         
            val_5 = val_5 + 3;
            // 0x010D6C74: ADD x8, x8, w9, uxtw #4    | X8 = (current + ((current + 152 + 8) + 3));
            val_6 = val_6 + val_5;
            // 0x010D6C78: ADD x0, x8, #0x110         | X0 = ((current + ((current + 152 + 8) + 3)) + 272);
            val_7 = val_6 + 272;
            label_4:
            // 0x010D6C7C: LDP x8, x2, [x0]           | X8 = ((current + ((current + 152 + 8) + 3)) + 272); X2 = ((current + ((current + 152 + 8) + 3)) + 272) + 8; //  | 
            val_8 = mem[((current + ((current + 152 + 8) + 3)) + 272) + 8];
            val_8 = ((current + ((current + 152 + 8) + 3)) + 272) + 8;
            // 0x010D6C80: MOV x0, x23                | X0 = current;//m1                       
            // 0x010D6C84: MOV w1, w22                | W1 = currentSet;//m1                    
            val_9 = currentSet;
            // 0x010D6C88: BLR x8                     | X0 = ((current + ((current + 152 + 8) + 3)) + 272)();
            // 0x010D6C8C: ADD w8, w22, #1            | W8 = (currentSet + 1);                  
            System.Collections.Generic.Dictionary<System.Int32, T> val_1 = currentSet + 1;
            // 0x010D6C90: MOV x24, x0                | X24 = current;//m1                      
            // 0x010D6C94: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x010D6C98: STR w8, [sp, #0xc]         | stack[1152921513963336668] = (currentSet + 1);  //  dest_result_addr=1152921513963336668
            // 0x010D6C9C: B #0x10d6ca4               |  goto label_5;                          
            goto label_5;
            label_32:
            // 0x010D6CA0: ADD w25, w25, #1           | W25 = (val_10 + 1) = val_10 (0x00000001);
            val_10 = 1;
            label_5:
            // 0x010D6CA4: CBNZ x24, #0x10d6cac       | if (current != 0) goto label_6;         
            if(current != 0)
            {
                goto label_6;
            }
            // 0x010D6CA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? current, ????);    
            label_6:
            // 0x010D6CAC: LDR x8, [x19, #0x30]       | X8 = X5 + 48;                           
            // 0x010D6CB0: LDR x27, [x8, #0x58]       | X27 = X5 + 48 + 88;                     
            // 0x010D6CB4: MOV x0, x27                | X0 = X5 + 48 + 88;//m1                  
            // 0x010D6CB8: BL #0x277461c              | X0 = sub_277461C( ?? X5 + 48 + 88, ????);
            // 0x010D6CBC: LDR x8, [x24]              | X8 = current;                           
            var val_9 = current;
            // 0x010D6CC0: LDRH w9, [x8, #0x102]      | W9 = current + 258;                     
            // 0x010D6CC4: CBZ x9, #0x10d6cf0         | if (current + 258 == 0) goto label_7;   
            if((current + 258) == 0)
            {
                goto label_7;
            }
            // 0x010D6CC8: LDR x10, [x8, #0x98]       | X10 = current + 152;                    
            var val_7 = current + 152;
            // 0x010D6CCC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_8 = 0;
            // 0x010D6CD0: ADD x10, x10, #8           | X10 = (current + 152 + 8);              
            val_7 = val_7 + 8;
            label_9:
            // 0x010D6CD4: LDUR x12, [x10, #-8]       | X12 = (current + 152 + 8) + -8;         
            // 0x010D6CD8: CMP x12, x27               | STATE = COMPARE((current + 152 + 8) + -8, X5 + 48 + 88)
            // 0x010D6CDC: B.EQ #0x10d6d04            | if ((current + 152 + 8) + -8 == X5 + 48 + 88) goto label_8;
            if(((current + 152 + 8) + -8) == (X5 + 48 + 88))
            {
                goto label_8;
            }
            // 0x010D6CE0: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x010D6CE4: ADD x10, x10, #0x10        | X10 = ((current + 152 + 8) + 16);       
            val_7 = val_7 + 16;
            // 0x010D6CE8: CMP x11, x9                | STATE = COMPARE((0 + 1), current + 258) 
            // 0x010D6CEC: B.LO #0x10d6cd4            | if (0 < current + 258) goto label_9;    
            if(val_8 < (current + 258))
            {
                goto label_9;
            }
            label_7:
            // 0x010D6CF0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            val_8 = 0;
            // 0x010D6CF4: MOV x0, x24                | X0 = current;//m1                       
            val_11 = current;
            // 0x010D6CF8: MOV x1, x27                | X1 = X5 + 48 + 88;//m1                  
            val_9 = X5 + 48 + 88;
            // 0x010D6CFC: BL #0x2776c24              | X0 = sub_2776C24( ?? current, ????);    
            // 0x010D6D00: B #0x10d6d10               |  goto label_10;                         
            goto label_10;
            label_8:
            // 0x010D6D04: LDR w9, [x10]              | W9 = (current + 152 + 8);               
            // 0x010D6D08: ADD x8, x8, x9, lsl #4     | X8 = (current + ((current + 152 + 8)) << 4);
            val_9 = val_9 + (((current + 152 + 8)) << 4);
            // 0x010D6D0C: ADD x0, x8, #0x110         | X0 = ((current + ((current + 152 + 8)) << 4) + 272);
            val_11 = val_9 + 272;
            label_10:
            // 0x010D6D10: LDP x8, x1, [x0]           | X8 = ((current + ((current + 152 + 8)) << 4) + 272); X1 = ((current + ((current + 152 + 8)) << 4) + 272) + 8; //  | 
            // 0x010D6D14: MOV x0, x24                | X0 = current;//m1                       
            // 0x010D6D18: BLR x8                     | X0 = ((current + ((current + 152 + 8)) << 4) + 272)();
            // 0x010D6D1C: CMP w25, w0                | STATE = COMPARE(0x1, current)           
            // 0x010D6D20: B.GE #0x10d6f3c            | if (val_10 >= current) goto label_11;   
            if(val_10 >= current)
            {
                goto label_11;
            }
            // 0x010D6D24: CBNZ x24, #0x10d6d2c       | if (current != 0) goto label_12;        
            if(current != 0)
            {
                goto label_12;
            }
            // 0x010D6D28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? current, ????);    
            label_12:
            // 0x010D6D2C: LDR x8, [x19, #0x30]       | X8 = X5 + 48;                           
            // 0x010D6D30: LDR x27, [x8, #8]          | X27 = X5 + 48 + 8;                      
            // 0x010D6D34: MOV x0, x27                | X0 = X5 + 48 + 8;//m1                   
            // 0x010D6D38: BL #0x277461c              | X0 = sub_277461C( ?? X5 + 48 + 8, ????);
            // 0x010D6D3C: LDR x8, [x24]              | X8 = current;                           
            var val_13 = current;
            // 0x010D6D40: LDRH w9, [x8, #0x102]      | W9 = current + 258;                     
            // 0x010D6D44: CBZ x9, #0x10d6d70         | if (current + 258 == 0) goto label_13;  
            if((current + 258) == 0)
            {
                goto label_13;
            }
            // 0x010D6D48: LDR x10, [x8, #0x98]       | X10 = current + 152;                    
            var val_10 = current + 152;
            // 0x010D6D4C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_11 = 0;
            // 0x010D6D50: ADD x10, x10, #8           | X10 = (current + 152 + 8);              
            val_10 = val_10 + 8;
            label_15:
            // 0x010D6D54: LDUR x12, [x10, #-8]       | X12 = (current + 152 + 8) + -8;         
            // 0x010D6D58: CMP x12, x27               | STATE = COMPARE((current + 152 + 8) + -8, X5 + 48 + 8)
            // 0x010D6D5C: B.EQ #0x10d6d84            | if ((current + 152 + 8) + -8 == X5 + 48 + 8) goto label_14;
            if(((current + 152 + 8) + -8) == (X5 + 48 + 8))
            {
                goto label_14;
            }
            // 0x010D6D60: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_11 = val_11 + 1;
            // 0x010D6D64: ADD x10, x10, #0x10        | X10 = ((current + 152 + 8) + 16);       
            val_10 = val_10 + 16;
            // 0x010D6D68: CMP x11, x9                | STATE = COMPARE((0 + 1), current + 258) 
            // 0x010D6D6C: B.LO #0x10d6d54            | if (0 < current + 258) goto label_15;   
            if(val_11 < (current + 258))
            {
                goto label_15;
            }
            label_13:
            // 0x010D6D70: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            val_8 = 3;
            // 0x010D6D74: MOV x0, x24                | X0 = current;//m1                       
            val_12 = current;
            // 0x010D6D78: MOV x1, x27                | X1 = X5 + 48 + 8;//m1                   
            // 0x010D6D7C: BL #0x2776c24              | X0 = sub_2776C24( ?? current, ????);    
            // 0x010D6D80: B #0x10d6d94               |  goto label_16;                         
            goto label_16;
            label_14:
            // 0x010D6D84: LDR w9, [x10]              | W9 = (current + 152 + 8);               
            var val_12 = val_10;
            // 0x010D6D88: ADD w9, w9, #3             | W9 = ((current + 152 + 8) + 3);         
            val_12 = val_12 + 3;
            // 0x010D6D8C: ADD x8, x8, w9, uxtw #4    | X8 = (current + ((current + 152 + 8) + 3));
            val_13 = val_13 + val_12;
            // 0x010D6D90: ADD x0, x8, #0x110         | X0 = ((current + ((current + 152 + 8) + 3)) + 272);
            val_12 = val_13 + 272;
            label_16:
            // 0x010D6D94: LDP x8, x2, [x0]           | X8 = ((current + ((current + 152 + 8) + 3)) + 272); X2 = ((current + ((current + 152 + 8) + 3)) + 272) + 8; //  | 
            // 0x010D6D98: MOV x0, x24                | X0 = current;//m1                       
            // 0x010D6D9C: MOV w1, w25                | W1 = 1 (0x1);//ML01                     
            // 0x010D6DA0: BLR x8                     | X0 = ((current + ((current + 152 + 8) + 3)) + 272)();
            // 0x010D6DA4: MOV x27, x0                | X27 = current;//m1                      
            // 0x010D6DA8: CBNZ x21, #0x10d6db0       | if (flattenedResult != null) goto label_17;
            if(flattenedResult != null)
            {
                goto label_17;
            }
            // 0x010D6DAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? current, ????);    
            label_17:
            // 0x010D6DB0: LDR x8, [x19, #0x30]       | X8 = X5 + 48;                           
            // 0x010D6DB4: MOV x0, x21                | X0 = flattenedResult;//m1               
            // 0x010D6DB8: MOV w1, w22                | W1 = currentSet;//m1                    
            val_13 = currentSet;
            // 0x010D6DBC: MOV x2, x27                | X2 = current;//m1                       
            // 0x010D6DC0: LDR x3, [x8, #0x10]        | X3 = X5 + 48 + 16;                      
            // 0x010D6DC4: LDR x8, [x3]               | X8 = X5 + 48 + 16;                      
            // 0x010D6DC8: BLR x8                     | X0 = X5 + 48 + 16();                    
            // 0x010D6DCC: CBNZ x23, #0x10d6dd4       | if (current != 0) goto label_18;        
            if(current != 0)
            {
                goto label_18;
            }
            // 0x010D6DD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? flattenedResult, ????);
            label_18:
            // 0x010D6DD4: LDR x8, [x19, #0x30]       | X8 = X5 + 48;                           
            // 0x010D6DD8: LDR x27, [x8, #0x18]       | X27 = X5 + 48 + 24;                     
            // 0x010D6DDC: MOV x0, x27                | X0 = X5 + 48 + 24;//m1                  
            // 0x010D6DE0: BL #0x277461c              | X0 = sub_277461C( ?? X5 + 48 + 24, ????);
            // 0x010D6DE4: LDR x8, [x23]              | X8 = current;                           
            var val_16 = current;
            // 0x010D6DE8: LDRH w9, [x8, #0x102]      | W9 = current + 258;                     
            // 0x010D6DEC: CBZ x9, #0x10d6e18         | if (current + 258 == 0) goto label_19;  
            if((current + 258) == 0)
            {
                goto label_19;
            }
            // 0x010D6DF0: LDR x10, [x8, #0x98]       | X10 = current + 152;                    
            var val_14 = current + 152;
            // 0x010D6DF4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_15 = 0;
            // 0x010D6DF8: ADD x10, x10, #8           | X10 = (current + 152 + 8);              
            val_14 = val_14 + 8;
            label_21:
            // 0x010D6DFC: LDUR x12, [x10, #-8]       | X12 = (current + 152 + 8) + -8;         
            // 0x010D6E00: CMP x12, x27               | STATE = COMPARE((current + 152 + 8) + -8, X5 + 48 + 24)
            // 0x010D6E04: B.EQ #0x10d6e2c            | if ((current + 152 + 8) + -8 == X5 + 48 + 24) goto label_20;
            if(((current + 152 + 8) + -8) == (X5 + 48 + 24))
            {
                goto label_20;
            }
            // 0x010D6E08: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_15 = val_15 + 1;
            // 0x010D6E0C: ADD x10, x10, #0x10        | X10 = ((current + 152 + 8) + 16);       
            val_14 = val_14 + 16;
            // 0x010D6E10: CMP x11, x9                | STATE = COMPARE((0 + 1), current + 258) 
            // 0x010D6E14: B.LO #0x10d6dfc            | if (0 < current + 258) goto label_21;   
            if(val_15 < (current + 258))
            {
                goto label_21;
            }
            label_19:
            // 0x010D6E18: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x010D6E1C: MOV x0, x23                | X0 = current;//m1                       
            val_14 = current;
            // 0x010D6E20: MOV x1, x27                | X1 = X5 + 48 + 24;//m1                  
            val_13 = X5 + 48 + 24;
            // 0x010D6E24: BL #0x2776c24              | X0 = sub_2776C24( ?? current, ????);    
            // 0x010D6E28: B #0x10d6e38               |  goto label_22;                         
            goto label_22;
            label_20:
            // 0x010D6E2C: LDR w9, [x10]              | W9 = (current + 152 + 8);               
            // 0x010D6E30: ADD x8, x8, x9, lsl #4     | X8 = (current + ((current + 152 + 8)) << 4);
            val_16 = val_16 + (((current + 152 + 8)) << 4);
            // 0x010D6E34: ADD x0, x8, #0x110         | X0 = ((current + ((current + 152 + 8)) << 4) + 272);
            val_14 = val_16 + 272;
            label_22:
            // 0x010D6E38: LDP x8, x1, [x0]           | X8 = ((current + ((current + 152 + 8)) << 4) + 272); X1 = ((current + ((current + 152 + 8)) << 4) + 272) + 8; //  | 
            // 0x010D6E3C: MOV x0, x23                | X0 = current;//m1                       
            // 0x010D6E40: BLR x8                     | X0 = ((current + ((current + 152 + 8)) << 4) + 272)();
            // 0x010D6E44: LDR x8, [x19, #0x30]       | X8 = X5 + 48;                           
            // 0x010D6E48: SUB w9, w0, #1             | W9 = (current - 1);                     
            int val_2 = current - 1;
            // 0x010D6E4C: CMP w9, w22                | STATE = COMPARE((current - 1), currentSet)
            // 0x010D6E50: B.NE #0x10d6ef4            | if (val_2 != currentSet) goto label_23; 
            if(val_2 != currentSet)
            {
                goto label_23;
            }
            // 0x010D6E54: LDR x26, [x8, #0x20]       | X26 = X5 + 48 + 32;                     
            // 0x010D6E58: MOV x0, x26                | X0 = X5 + 48 + 32;//m1                  
            // 0x010D6E5C: BL #0x277461c              | X0 = sub_277461C( ?? X5 + 48 + 32, ????);
            // 0x010D6E60: MOV x0, x26                | X0 = X5 + 48 + 32;//m1                  
            // 0x010D6E64: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X5 + 48 + 32, ????);
            // 0x010D6E68: LDR x8, [x19, #0x30]       | X8 = X5 + 48;                           
            // 0x010D6E6C: MOV x27, x0                | X27 = X5 + 48 + 32;//m1                 
            // 0x010D6E70: LDR x1, [x8, #0x28]        | X1 = X5 + 48 + 40;                      
            // 0x010D6E74: LDR x8, [x1]               | X8 = X5 + 48 + 40;                      
            // 0x010D6E78: BLR x8                     | X0 = X5 + 48 + 40();                    
            // 0x010D6E7C: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x010D6E80: B #0x10d6ea0               |  goto label_24;                         
            goto label_24;
            label_29:
            // 0x010D6E84: LDR x8, [x19, #0x30]       | X8 = X5 + 48;                           
            // 0x010D6E88: MOV x0, x27                | X0 = X5 + 48 + 32;//m1                  
            // 0x010D6E8C: MOV x1, x26                | X1 = X5 + 48 + 32;//m1                  
            // 0x010D6E90: LDR x2, [x8, #0x38]        | X2 = X5 + 48 + 56;                      
            // 0x010D6E94: LDR x8, [x2]               | X8 = X5 + 48 + 56;                      
            // 0x010D6E98: BLR x8                     | X0 = X5 + 48 + 56();                    
            // 0x010D6E9C: ADD w28, w28, #1           | W28 = (val_15 + 1) = val_15 (0x00000001);
            val_15 = 1;
            label_24:
            // 0x010D6EA0: CBNZ x21, #0x10d6ea8       | if (flattenedResult != null) goto label_25;
            if(flattenedResult != null)
            {
                goto label_25;
            }
            // 0x010D6EA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X5 + 48 + 32, ????);
            label_25:
            // 0x010D6EA8: LDR x8, [x19, #0x30]       | X8 = X5 + 48;                           
            // 0x010D6EAC: MOV x0, x21                | X0 = flattenedResult;//m1               
            // 0x010D6EB0: LDR x1, [x8, #0x40]        | X1 = X5 + 48 + 64;                      
            // 0x010D6EB4: LDR x8, [x1]               | X8 = X5 + 48 + 64;                      
            // 0x010D6EB8: BLR x8                     | X0 = X5 + 48 + 64();                    
            // 0x010D6EBC: CMP w28, w0                | STATE = COMPARE(0x1, flattenedResult)   
            // 0x010D6EC0: B.GE #0x10d6f18            | if (val_15 >= flattenedResult) goto label_26;
            if(val_15 >= flattenedResult)
            {
                goto label_26;
            }
            // 0x010D6EC4: CBNZ x21, #0x10d6ecc       | if (flattenedResult != null) goto label_27;
            if(flattenedResult != null)
            {
                goto label_27;
            }
            // 0x010D6EC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? flattenedResult, ????);
            label_27:
            // 0x010D6ECC: LDR x8, [x19, #0x30]       | X8 = X5 + 48;                           
            // 0x010D6ED0: MOV x0, x21                | X0 = flattenedResult;//m1               
            // 0x010D6ED4: MOV w1, w28                | W1 = 1 (0x1);//ML01                     
            // 0x010D6ED8: LDR x2, [x8, #0x30]        | X2 = X5 + 48 + 48;                      
            // 0x010D6EDC: LDR x8, [x2]               | X8 = X5 + 48 + 48;                      
            // 0x010D6EE0: BLR x8                     | X0 = X5 + 48 + 48();                    
            // 0x010D6EE4: MOV x26, x0                | X26 = flattenedResult;//m1              
            // 0x010D6EE8: CBNZ x27, #0x10d6e84       | if (X5 + 48 + 32 != 0) goto label_29;   
            if((X5 + 48 + 32) != 0)
            {
                goto label_29;
            }
            // 0x010D6EEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? flattenedResult, ????);
            // 0x010D6EF0: B #0x10d6e84               |  goto label_29;                         
            goto label_29;
            label_23:
            // 0x010D6EF4: LDR x5, [x8, #0x50]        | X5 = X5 + 48 + 80;                      
            // 0x010D6EF8: LDR w2, [sp, #0xc]         | W2 = (currentSet + 1);                  
            // 0x010D6EFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010D6F00: MOV x1, x23                | X1 = current;//m1                       
            // 0x010D6F04: LDR x8, [x5]               | X8 = X5 + 48 + 80;                      
            // 0x010D6F08: MOV x3, x21                | X3 = flattenedResult;//m1               
            // 0x010D6F0C: MOV x4, x20                | X4 = __RuntimeMethodHiddenParam;//m1    
            // 0x010D6F10: BLR x8                     | X0 = X5 + 48 + 80();                    
            // 0x010D6F14: B #0x10d6ca0               |  goto label_32;                         
            goto label_32;
            label_26:
            // 0x010D6F18: CBNZ x20, #0x10d6f20       | if (__RuntimeMethodHiddenParam != 0) goto label_31;
            if(__RuntimeMethodHiddenParam != 0)
            {
                goto label_31;
            }
            // 0x010D6F1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? flattenedResult, ????);
            label_31:
            // 0x010D6F20: LDR x8, [x19, #0x30]       | X8 = X5 + 48;                           
            // 0x010D6F24: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam;//m1    
            // 0x010D6F28: MOV x1, x27                | X1 = X5 + 48 + 32;//m1                  
            // 0x010D6F2C: LDR x2, [x8, #0x48]        | X2 = X5 + 48 + 72;                      
            // 0x010D6F30: LDR x8, [x2]               | X8 = X5 + 48 + 72;                      
            // 0x010D6F34: BLR x8                     | X0 = X5 + 48 + 72();                    
            // 0x010D6F38: B #0x10d6ca0               |  goto label_32;                         
            goto label_32;
            label_11:
            // 0x010D6F3C: SUB sp, x29, #0x50         | SP = (1152921513963336752 - 80) = 1152921513963336672 (0x100000022DB0B3E0);
            // 0x010D6F40: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x010D6F44: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x010D6F48: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x010D6F4C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x010D6F50: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x010D6F54: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x010D6F58: RET                        |  return;                                
            return;
        
        }
        // Generic instance method:
        //
        // file offset: 0x00B7A3DC VirtAddr: 0x00B7A3DC -RVA: 0x00B7A3DC 
        // -CollectionUtils.CreateList<object>
        //
        //
        // Offset in libil2cpp.so: 0x00B7A3DC (12035036), len: 460  VirtAddr: 0x00B7A3DC RVA: 0x00B7A3DC token: 100686558 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static System.Collections.Generic.List<T> CreateList<T>(System.Collections.ICollection collection)
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            var val_6;
            // 0x00B7A3DC: STP x24, x23, [sp, #-0x40]! | stack[1152921513963470304] = ???;  stack[1152921513963470312] = ???;  //  dest_result_addr=1152921513963470304 |  dest_result_addr=1152921513963470312
            // 0x00B7A3E0: STP x22, x21, [sp, #0x10]  | stack[1152921513963470320] = ???;  stack[1152921513963470328] = ???;  //  dest_result_addr=1152921513963470320 |  dest_result_addr=1152921513963470328
            // 0x00B7A3E4: STP x20, x19, [sp, #0x20]  | stack[1152921513963470336] = ???;  stack[1152921513963470344] = ???;  //  dest_result_addr=1152921513963470336 |  dest_result_addr=1152921513963470344
            // 0x00B7A3E8: STP x29, x30, [sp, #0x30]  | stack[1152921513963470352] = ???;  stack[1152921513963470360] = ???;  //  dest_result_addr=1152921513963470352 |  dest_result_addr=1152921513963470360
            // 0x00B7A3EC: ADD x29, sp, #0x30         | X29 = (1152921513963470304 + 48) = 1152921513963470352 (0x100000022DB2BE10);
            // 0x00B7A3F0: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00B7A3F4: LDRB w8, [x21, #0x9c0]     | W8 = (bool)static_value_037339C0;       
            // 0x00B7A3F8: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00B7A3FC: MOV x20, x1                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x00B7A400: TBNZ w8, #0, #0xb7a41c     | if (static_value_037339C0 == true) goto label_0;
            // 0x00B7A404: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
            // 0x00B7A408: LDR x8, [x8, #0xf70]       | X8 = 0x2B915F8;                         
            // 0x00B7A40C: LDR w0, [x8]               | W0 = 0x1C42;                            
            // 0x00B7A410: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C42, ????);     
            // 0x00B7A414: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00B7A418: STRB w8, [x21, #0x9c0]     | static_value_037339C0 = true;            //  dest_result_addr=57883072
            label_0:
            // 0x00B7A41C: CBZ x20, #0xb7a568         | if (__RuntimeMethodHiddenParam == 0) goto label_1;
            if(__RuntimeMethodHiddenParam == 0)
            {
                goto label_1;
            }
            // 0x00B7A420: ADRP x23, #0x35db000       | X23 = 56471552 (0x35DB000);             
            // 0x00B7A424: LDR x8, [x20]              | X8 = __RuntimeMethodHiddenParam;        
            var val_5 = __RuntimeMethodHiddenParam;
            // 0x00B7A428: LDR x23, [x23, #0xd0]      | X23 = 1152921504609296384;              
            // 0x00B7A42C: LDRH w9, [x8, #0x102]      | W9 = __RuntimeMethodHiddenParam + 258;  
            // 0x00B7A430: LDR x1, [x23]              | X1 = typeof(System.Collections.ICollection);
            // 0x00B7A434: CBZ x9, #0xb7a460          | if (__RuntimeMethodHiddenParam + 258 == 0) goto label_2;
            if((__RuntimeMethodHiddenParam + 258) == 0)
            {
                goto label_2;
            }
            // 0x00B7A438: LDR x10, [x8, #0x98]       | X10 = __RuntimeMethodHiddenParam + 152; 
            var val_3 = __RuntimeMethodHiddenParam + 152;
            // 0x00B7A43C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_4 = 0;
            // 0x00B7A440: ADD x10, x10, #8           | X10 = (__RuntimeMethodHiddenParam + 152 + 8);
            val_3 = val_3 + 8;
            label_4:
            // 0x00B7A444: LDUR x12, [x10, #-8]       | X12 = (__RuntimeMethodHiddenParam + 152 + 8) + -8;
            // 0x00B7A448: CMP x12, x1                | STATE = COMPARE((__RuntimeMethodHiddenParam + 152 + 8) + -8, typeof(System.Collections.ICollection))
            // 0x00B7A44C: B.EQ #0xb7a470             | if ((__RuntimeMethodHiddenParam + 152 + 8) + -8 == null) goto label_3;
            if(((__RuntimeMethodHiddenParam + 152 + 8) + -8) == null)
            {
                goto label_3;
            }
            // 0x00B7A450: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_4 = val_4 + 1;
            // 0x00B7A454: ADD x10, x10, #0x10        | X10 = ((__RuntimeMethodHiddenParam + 152 + 8) + 16);
            val_3 = val_3 + 16;
            // 0x00B7A458: CMP x11, x9                | STATE = COMPARE((0 + 1), __RuntimeMethodHiddenParam + 258)
            // 0x00B7A45C: B.LO #0xb7a444             | if (0 < __RuntimeMethodHiddenParam + 258) goto label_4;
            if(val_4 < (__RuntimeMethodHiddenParam + 258))
            {
                goto label_4;
            }
            label_2:
            // 0x00B7A460: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B7A464: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam;//m1    
            val_5 = __RuntimeMethodHiddenParam;
            // 0x00B7A468: BL #0x2776c24              | X0 = sub_2776C24( ?? __RuntimeMethodHiddenParam, ????);
            // 0x00B7A46C: B #0xb7a47c                |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x00B7A470: LDR w9, [x10]              | W9 = (__RuntimeMethodHiddenParam + 152 + 8);
            // 0x00B7A474: ADD x8, x8, x9, lsl #4     | X8 = (__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4);
            val_5 = val_5 + (((__RuntimeMethodHiddenParam + 152 + 8)) << 4);
            // 0x00B7A478: ADD x0, x8, #0x110         | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272);
            val_5 = val_5 + 272;
            label_5:
            // 0x00B7A47C: LDP x8, x1, [x0]           | X8 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272); X1 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272) + 8; //  | 
            // 0x00B7A480: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam;//m1    
            // 0x00B7A484: BLR x8                     | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272)();
            // 0x00B7A488: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
            // 0x00B7A48C: MOV w22, w0                | W22 = __RuntimeMethodHiddenParam;//m1   
            // 0x00B7A490: LDR x21, [x8]              | X21 = X2 + 48;                          
            // 0x00B7A494: MOV x0, x21                | X0 = X2 + 48;//m1                       
            // 0x00B7A498: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 48, ????);    
            // 0x00B7A49C: MOV x0, x21                | X0 = X2 + 48;//m1                       
            // 0x00B7A4A0: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 48, ????);    
            // 0x00B7A4A4: MOV w1, w22                | W1 = __RuntimeMethodHiddenParam;//m1    
            // 0x00B7A4A8: MOV x0, x21                | X0 = X2 + 48;//m1                       
            // 0x00B7A4AC: BL #0x27c1608              | X0 = sub_27C1608( ?? X2 + 48, ????);    
            // 0x00B7A4B0: LDR x8, [x20]              | X8 = __RuntimeMethodHiddenParam;        
            var val_9 = __RuntimeMethodHiddenParam;
            // 0x00B7A4B4: LDR x1, [x23]              | X1 = typeof(System.Collections.ICollection);
            // 0x00B7A4B8: MOV x21, x0                | X21 = X2 + 48;//m1                      
            // 0x00B7A4BC: LDRH w9, [x8, #0x102]      | W9 = __RuntimeMethodHiddenParam + 258;  
            // 0x00B7A4C0: CBZ x9, #0xb7a4ec          | if (__RuntimeMethodHiddenParam + 258 == 0) goto label_6;
            if((__RuntimeMethodHiddenParam + 258) == 0)
            {
                goto label_6;
            }
            // 0x00B7A4C4: LDR x10, [x8, #0x98]       | X10 = __RuntimeMethodHiddenParam + 152; 
            var val_6 = __RuntimeMethodHiddenParam + 152;
            // 0x00B7A4C8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_7 = 0;
            // 0x00B7A4CC: ADD x10, x10, #8           | X10 = (__RuntimeMethodHiddenParam + 152 + 8);
            val_6 = val_6 + 8;
            label_8:
            // 0x00B7A4D0: LDUR x12, [x10, #-8]       | X12 = (__RuntimeMethodHiddenParam + 152 + 8) + -8;
            // 0x00B7A4D4: CMP x12, x1                | STATE = COMPARE((__RuntimeMethodHiddenParam + 152 + 8) + -8, typeof(System.Collections.ICollection))
            // 0x00B7A4D8: B.EQ #0xb7a4fc             | if ((__RuntimeMethodHiddenParam + 152 + 8) + -8 == null) goto label_7;
            if(((__RuntimeMethodHiddenParam + 152 + 8) + -8) == null)
            {
                goto label_7;
            }
            // 0x00B7A4DC: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_7 = val_7 + 1;
            // 0x00B7A4E0: ADD x10, x10, #0x10        | X10 = ((__RuntimeMethodHiddenParam + 152 + 8) + 16);
            val_6 = val_6 + 16;
            // 0x00B7A4E4: CMP x11, x9                | STATE = COMPARE((0 + 1), __RuntimeMethodHiddenParam + 258)
            // 0x00B7A4E8: B.LO #0xb7a4d0             | if (0 < __RuntimeMethodHiddenParam + 258) goto label_8;
            if(val_7 < (__RuntimeMethodHiddenParam + 258))
            {
                goto label_8;
            }
            label_6:
            // 0x00B7A4EC: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00B7A4F0: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam;//m1    
            val_6 = __RuntimeMethodHiddenParam;
            // 0x00B7A4F4: BL #0x2776c24              | X0 = sub_2776C24( ?? __RuntimeMethodHiddenParam, ????);
            // 0x00B7A4F8: B #0xb7a50c                |  goto label_9;                          
            goto label_9;
            label_7:
            // 0x00B7A4FC: LDR w9, [x10]              | W9 = (__RuntimeMethodHiddenParam + 152 + 8);
            var val_8 = val_6;
            // 0x00B7A500: ADD w9, w9, #3             | W9 = ((__RuntimeMethodHiddenParam + 152 + 8) + 3);
            val_8 = val_8 + 3;
            // 0x00B7A504: ADD x8, x8, w9, uxtw #4    | X8 = (__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 3));
            val_9 = val_9 + val_8;
            // 0x00B7A508: ADD x0, x8, #0x110         | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 3)) + 272);
            val_6 = val_9 + 272;
            label_9:
            // 0x00B7A50C: LDP x8, x3, [x0]           | X8 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 3)) + 272); X3 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 3)) + 272) + 8; //  | 
            // 0x00B7A510: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B7A514: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam;//m1    
            // 0x00B7A518: MOV x1, x21                | X1 = X2 + 48;//m1                       
            // 0x00B7A51C: BLR x8                     | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 3)) + 272)();
            // 0x00B7A520: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
            // 0x00B7A524: LDR x20, [x8, #8]          | X20 = X2 + 48 + 8;                      
            // 0x00B7A528: MOV x0, x20                | X0 = X2 + 48 + 8;//m1                   
            // 0x00B7A52C: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 48 + 8, ????);
            // 0x00B7A530: MOV x0, x20                | X0 = X2 + 48 + 8;//m1                   
            // 0x00B7A534: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X2 + 48 + 8, ????);
            // 0x00B7A538: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
            // 0x00B7A53C: MOV x1, x21                | X1 = X2 + 48;//m1                       
            // 0x00B7A540: MOV x19, x0                | X19 = X2 + 48 + 8;//m1                  
            // 0x00B7A544: LDR x2, [x8, #0x10]        | X2 = X2 + 48 + 16;                      
            // 0x00B7A548: LDR x8, [x2]               | X8 = X2 + 48 + 16;                      
            // 0x00B7A54C: BLR x8                     | X0 = X2 + 48 + 16();                    
            // 0x00B7A550: MOV x0, x19                | X0 = X2 + 48 + 8;//m1                   
            // 0x00B7A554: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00B7A558: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00B7A55C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00B7A560: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00B7A564: RET                        |  return (System.Collections.Generic.List<T>)X2 + 48 + 8;
            return (System.Collections.Generic.List<T>)X2 + 48 + 8;
            //  |  // // {name=val_0, type=System.Collections.Generic.List<T>, size=8, nGRN=0 }
            label_1:
            // 0x00B7A568: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00B7A56C: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x00B7A570: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            System.ArgumentNullException val_1 = null;
            // 0x00B7A574: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x00B7A578: ADRP x8, #0x35e4000        | X8 = 56508416 (0x35E4000);              
            // 0x00B7A57C: LDR x8, [x8, #0x458]       | X8 = (string**)(1152921513963453152)("collection");
            // 0x00B7A580: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00B7A584: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x00B7A588: LDR x1, [x8]               | X1 = "collection";                      
            // 0x00B7A58C: BL #0x18b3df0              | .ctor(paramName:  "collection");        
            val_1 = new System.ArgumentNullException(paramName:  "collection");
            // 0x00B7A590: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00B7A594: LDR x8, [x8, #0x5f0]       | X8 = 1152921513963453248;               
            // 0x00B7A598: MOV x0, x19                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x00B7A59C: LDR x1, [x8]               | X1 = public static System.Collections.Generic.List<T> Newtonsoft.Json.Utilities.CollectionUtils::CreateList<System.Object>(System.Collections.ICollection collection);
            // 0x00B7A5A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentNullException), ????);
            // 0x00B7A5A4: BL #0xb693a0               | X0 = Newtonsoft.Json.Utilities.CollectionUtils.CreateList<System.Object>(collection:  val_1);
            System.Collections.Generic.List<T> val_2 = Newtonsoft.Json.Utilities.CollectionUtils.CreateList<System.Object>(collection:  val_1);
        
        }
        // Generic instance method:
        //
        // file offset: 0x012F9F34 VirtAddr: 0x012F9F34 -RVA: 0x012F9F34 
        // -CollectionUtils.ListEquals<object>
        //
        //
        // Offset in libil2cpp.so: 0x012F9F34 (19898164), len: 864  VirtAddr: 0x012F9F34 RVA: 0x012F9F34 token: 100686559 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool ListEquals<T>(System.Collections.Generic.IList<T> a, System.Collections.Generic.IList<T> b)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            // 0x012F9F34: STP x26, x25, [sp, #-0x50]! | stack[1152921513963598672] = ???;  stack[1152921513963598680] = ???;  //  dest_result_addr=1152921513963598672 |  dest_result_addr=1152921513963598680
            // 0x012F9F38: STP x24, x23, [sp, #0x10]  | stack[1152921513963598688] = ???;  stack[1152921513963598696] = ???;  //  dest_result_addr=1152921513963598688 |  dest_result_addr=1152921513963598696
            // 0x012F9F3C: STP x22, x21, [sp, #0x20]  | stack[1152921513963598704] = ???;  stack[1152921513963598712] = ???;  //  dest_result_addr=1152921513963598704 |  dest_result_addr=1152921513963598712
            // 0x012F9F40: STP x20, x19, [sp, #0x30]  | stack[1152921513963598720] = ???;  stack[1152921513963598728] = ???;  //  dest_result_addr=1152921513963598720 |  dest_result_addr=1152921513963598728
            // 0x012F9F44: STP x29, x30, [sp, #0x40]  | stack[1152921513963598736] = ???;  stack[1152921513963598744] = ???;  //  dest_result_addr=1152921513963598736 |  dest_result_addr=1152921513963598744
            // 0x012F9F48: ADD x29, sp, #0x40         | X29 = (1152921513963598672 + 64) = 1152921513963598736 (0x100000022DB4B390);
            // 0x012F9F4C: MOV x20, x3                | X20 = X3;//m1                           
            // 0x012F9F50: MOV x19, x2                | X19 = __RuntimeMethodHiddenParam;//m1   
            // 0x012F9F54: MOV x21, x1                | X21 = b;//m1                            
            // 0x012F9F58: CBZ x19, #0x12f9fc0        | if (__RuntimeMethodHiddenParam == 0) goto label_1;
            if(__RuntimeMethodHiddenParam == 0)
            {
                goto label_1;
            }
            // 0x012F9F5C: CBZ x21, #0x12f9fc0        | if (b == null) goto label_1;            
            if(b == null)
            {
                goto label_1;
            }
            // 0x012F9F60: CBNZ x21, #0x12f9f68       | if (b != null) goto label_2;            
            if(b != null)
            {
                goto label_2;
            }
            // 0x012F9F64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? a, ????);          
            label_2:
            // 0x012F9F68: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x012F9F6C: LDR x22, [x8]              | X22 = X3 + 48;                          
            // 0x012F9F70: MOV x0, x22                | X0 = X3 + 48;//m1                       
            // 0x012F9F74: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48, ????);    
            // 0x012F9F78: LDR x8, [x21]              | X8 = typeof(System.Collections.Generic.IList<T>);
            // 0x012F9F7C: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x012F9F80: CBZ x9, #0x12f9fac         | if (System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_3;
            // 0x012F9F84: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IList<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x012F9F88: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_6 = 0;
            // 0x012F9F8C: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IList<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504609439752 (0x1000000000279008);
            label_5:
            // 0x012F9F90: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x012F9F94: CMP x12, x22               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X3 + 48)
            // 0x012F9F98: B.EQ #0x12f9fd0            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X3 + 48) goto label_4;
            // 0x012F9F9C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_6 = val_6 + 1;
            // 0x012F9FA0: ADD x10, x10, #0x10        | X10 = (1152921504609439752 + 16) = 1152921504609439768 (0x1000000000279018);
            // 0x012F9FA4: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x012F9FA8: B.LO #0x12f9f90            | if (0 < System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count) goto label_5;
            label_3:
            // 0x012F9FAC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            val_8 = 0;
            // 0x012F9FB0: MOV x0, x21                | X0 = b;//m1                             
            val_9 = b;
            // 0x012F9FB4: MOV x1, x22                | X1 = X3 + 48;//m1                       
            // 0x012F9FB8: BL #0x2776c24              | X0 = sub_2776C24( ?? b, ????);          
            // 0x012F9FBC: B #0x12f9fdc               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x012F9FC0: ORR x8, x19, x21           | X8 = (__RuntimeMethodHiddenParam | b);  
            System.Collections.Generic.IList<T> val_1 = __RuntimeMethodHiddenParam | b;
            // 0x012F9FC4: CMP x8, #0                 | STATE = COMPARE((__RuntimeMethodHiddenParam | b), 0x0)
            // 0x012F9FC8: CSET w0, eq                | W0 = val_1 == null ? 1 : 0;             
            var val_2 = (val_1 == 0) ? 1 : 0;
            // 0x012F9FCC: B #0x12fa27c               |  goto label_32;                         
            goto label_32;
            label_4:
            // 0x012F9FD0: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x012F9FD4: ADD x8, x8, x9, lsl #4     | X8 = (1152921504609402880 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x012F9FD8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504609402880 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_6:
            // 0x012F9FDC: LDP x8, x1, [x0]           | X8 = X3 + 48; X1 = X3 + 48 + 8;          //  | 
            val_11 = mem[X3 + 48 + 8];
            val_11 = X3 + 48 + 8;
            // 0x012F9FE0: MOV x0, x21                | X0 = b;//m1                             
            // 0x012F9FE4: BLR x8                     | X0 = X3 + 48();                         
            // 0x012F9FE8: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x012F9FEC: MOV w22, w0                | W22 = b;//m1                            
            // 0x012F9FF0: LDR x23, [x8]              | X23 = X3 + 48;                          
            val_12 = mem[X3 + 48];
            val_12 = X3 + 48;
            // 0x012F9FF4: MOV x0, x23                | X0 = X3 + 48;//m1                       
            // 0x012F9FF8: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48, ????);    
            // 0x012F9FFC: LDR x8, [x19]              | X8 = __RuntimeMethodHiddenParam;        
            var val_9 = __RuntimeMethodHiddenParam;
            // 0x012FA000: LDRH w9, [x8, #0x102]      | W9 = __RuntimeMethodHiddenParam + 258;  
            // 0x012FA004: CBZ x9, #0x12fa030         | if (__RuntimeMethodHiddenParam + 258 == 0) goto label_8;
            if((__RuntimeMethodHiddenParam + 258) == 0)
            {
                goto label_8;
            }
            // 0x012FA008: LDR x10, [x8, #0x98]       | X10 = __RuntimeMethodHiddenParam + 152; 
            var val_7 = __RuntimeMethodHiddenParam + 152;
            // 0x012FA00C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_8 = 0;
            // 0x012FA010: ADD x10, x10, #8           | X10 = (__RuntimeMethodHiddenParam + 152 + 8);
            val_7 = val_7 + 8;
            label_10:
            // 0x012FA014: LDUR x12, [x10, #-8]       | X12 = (__RuntimeMethodHiddenParam + 152 + 8) + -8;
            // 0x012FA018: CMP x12, x23               | STATE = COMPARE((__RuntimeMethodHiddenParam + 152 + 8) + -8, X3 + 48)
            // 0x012FA01C: B.EQ #0x12fa044            | if ((__RuntimeMethodHiddenParam + 152 + 8) + -8 == val_12) goto label_9;
            if(((__RuntimeMethodHiddenParam + 152 + 8) + -8) == val_12)
            {
                goto label_9;
            }
            // 0x012FA020: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x012FA024: ADD x10, x10, #0x10        | X10 = ((__RuntimeMethodHiddenParam + 152 + 8) + 16);
            val_7 = val_7 + 16;
            // 0x012FA028: CMP x11, x9                | STATE = COMPARE((0 + 1), __RuntimeMethodHiddenParam + 258)
            // 0x012FA02C: B.LO #0x12fa014            | if (0 < __RuntimeMethodHiddenParam + 258) goto label_10;
            if(val_8 < (__RuntimeMethodHiddenParam + 258))
            {
                goto label_10;
            }
            label_8:
            // 0x012FA030: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            val_8 = 0;
            // 0x012FA034: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam;//m1    
            val_13 = __RuntimeMethodHiddenParam;
            // 0x012FA038: MOV x1, x23                | X1 = X3 + 48;//m1                       
            val_11 = val_12;
            // 0x012FA03C: BL #0x2776c24              | X0 = sub_2776C24( ?? __RuntimeMethodHiddenParam, ????);
            // 0x012FA040: B #0x12fa050               |  goto label_11;                         
            goto label_11;
            label_9:
            // 0x012FA044: LDR w9, [x10]              | W9 = (__RuntimeMethodHiddenParam + 152 + 8);
            // 0x012FA048: ADD x8, x8, x9, lsl #4     | X8 = (__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4);
            val_9 = val_9 + (((__RuntimeMethodHiddenParam + 152 + 8)) << 4);
            // 0x012FA04C: ADD x0, x8, #0x110         | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272);
            val_13 = val_9 + 272;
            label_11:
            // 0x012FA050: LDP x8, x1, [x0]           | X8 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272); X1 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272) + 8; //  | 
            // 0x012FA054: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam;//m1    
            // 0x012FA058: BLR x8                     | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272)();
            // 0x012FA05C: CMP w22, w0                | STATE = COMPARE(b, __RuntimeMethodHiddenParam)
            // 0x012FA060: B.NE #0x12fa270            | if (b != __RuntimeMethodHiddenParam) goto label_12;
            if(b != __RuntimeMethodHiddenParam)
            {
                goto label_12;
            }
            // 0x012FA064: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x012FA068: LDR x22, [x8, #0x10]       | X22 = X3 + 48 + 16;                     
            // 0x012FA06C: MOV x0, x22                | X0 = X3 + 48 + 16;//m1                  
            // 0x012FA070: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 16, ????);
            // 0x012FA074: LDRB w8, [x22, #0x10a]     | W8 = X3 + 48 + 16 + 266;                
            // 0x012FA078: TBZ w8, #0, #0x12fa0ac     | if ((X3 + 48 + 16 + 266 & 0x1) == 0) goto label_14;
            if(((X3 + 48 + 16 + 266) & 1) == 0)
            {
                goto label_14;
            }
            // 0x012FA07C: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x012FA080: LDR x22, [x8, #0x10]       | X22 = X3 + 48 + 16;                     
            // 0x012FA084: MOV x0, x22                | X0 = X3 + 48 + 16;//m1                  
            // 0x012FA088: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 16, ????);
            // 0x012FA08C: LDR w8, [x22, #0xbc]       | W8 = X3 + 48 + 16 + 188;                
            // 0x012FA090: CBNZ w8, #0x12fa0ac        | if (X3 + 48 + 16 + 188 != 0) goto label_14;
            if((X3 + 48 + 16 + 188) != 0)
            {
                goto label_14;
            }
            // 0x012FA094: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x012FA098: LDR x22, [x8, #0x10]       | X22 = X3 + 48 + 16;                     
            // 0x012FA09C: MOV x0, x22                | X0 = X3 + 48 + 16;//m1                  
            // 0x012FA0A0: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 16, ????);
            // 0x012FA0A4: MOV x0, x22                | X0 = X3 + 48 + 16;//m1                  
            // 0x012FA0A8: BL #0x27977a4              | X0 = sub_27977A4( ?? X3 + 48 + 16, ????);
            label_14:
            // 0x012FA0AC: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x012FA0B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x012FA0B4: LDR x1, [x8, #8]           | X1 = X3 + 48 + 8;                       
            val_14 = mem[X3 + 48 + 8];
            val_14 = X3 + 48 + 8;
            // 0x012FA0B8: LDR x8, [x1]               | X8 = X3 + 48 + 8;                       
            // 0x012FA0BC: BLR x8                     | X0 = X3 + 48 + 8();                     
            // 0x012FA0C0: MOV x22, x0                | X22 = 0 (0x0);//ML01                    
            // 0x012FA0C4: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_12 = 0;
            label_31:
            // 0x012FA0C8: CBNZ x21, #0x12fa0d0       | if (b != null) goto label_15;           
            if(b != null)
            {
                goto label_15;
            }
            // 0x012FA0CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_15:
            // 0x012FA0D0: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x012FA0D4: LDR x24, [x8]              | X24 = X3 + 48;                          
            // 0x012FA0D8: MOV x0, x24                | X0 = X3 + 48;//m1                       
            // 0x012FA0DC: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48, ????);    
            // 0x012FA0E0: LDR x8, [x21]              | X8 = typeof(System.Collections.Generic.IList<T>);
            // 0x012FA0E4: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x012FA0E8: CBZ x9, #0x12fa114         | if (System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_16;
            // 0x012FA0EC: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IList<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x012FA0F0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_10 = 0;
            // 0x012FA0F4: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IList<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504609439752 (0x1000000000279008);
            label_18:
            // 0x012FA0F8: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x012FA0FC: CMP x12, x24               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X3 + 48)
            // 0x012FA100: B.EQ #0x12fa128            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X3 + 48) goto label_17;
            // 0x012FA104: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_10 = val_10 + 1;
            // 0x012FA108: ADD x10, x10, #0x10        | X10 = (1152921504609439752 + 16) = 1152921504609439768 (0x1000000000279018);
            // 0x012FA10C: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x012FA110: B.LO #0x12fa0f8            | if (0 < System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count) goto label_18;
            label_16:
            // 0x012FA114: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            val_8 = 0;
            // 0x012FA118: MOV x0, x21                | X0 = b;//m1                             
            val_15 = b;
            // 0x012FA11C: MOV x1, x24                | X1 = X3 + 48;//m1                       
            val_14 = X3 + 48;
            // 0x012FA120: BL #0x2776c24              | X0 = sub_2776C24( ?? b, ????);          
            // 0x012FA124: B #0x12fa134               |  goto label_19;                         
            goto label_19;
            label_17:
            // 0x012FA128: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x012FA12C: ADD x8, x8, x9, lsl #4     | X8 = (1152921504609402880 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x012FA130: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504609402880 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_19:
            // 0x012FA134: LDP x8, x1, [x0]           | X8 = X3 + 48; X1 = X3 + 48 + 8;          //  | 
            // 0x012FA138: MOV x0, x21                | X0 = b;//m1                             
            // 0x012FA13C: BLR x8                     | X0 = X3 + 48();                         
            // 0x012FA140: CMP w23, w0                | STATE = COMPARE(0x0, b)                 
            // 0x012FA144: B.GE #0x12fa278            | if (val_12 >= b) goto label_20;         
            if(val_12 >= b)
            {
                goto label_20;
            }
            // 0x012FA148: CBNZ x21, #0x12fa150       | if (b != null) goto label_21;           
            if(b != null)
            {
                goto label_21;
            }
            // 0x012FA14C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? b, ????);          
            label_21:
            // 0x012FA150: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x012FA154: LDR x24, [x8, #0x18]       | X24 = X3 + 48 + 24;                     
            // 0x012FA158: MOV x0, x24                | X0 = X3 + 48 + 24;//m1                  
            // 0x012FA15C: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 24, ????);
            // 0x012FA160: LDR x8, [x21]              | X8 = typeof(System.Collections.Generic.IList<T>);
            // 0x012FA164: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x012FA168: CBZ x9, #0x12fa194         | if (System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_22;
            // 0x012FA16C: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IList<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x012FA170: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_11 = 0;
            // 0x012FA174: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IList<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504609439752 (0x1000000000279008);
            label_24:
            // 0x012FA178: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x012FA17C: CMP x12, x24               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X3 + 48 + 24)
            // 0x012FA180: B.EQ #0x12fa1a8            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X3 + 48 + 24) goto label_23;
            // 0x012FA184: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_11 = val_11 + 1;
            // 0x012FA188: ADD x10, x10, #0x10        | X10 = (1152921504609439752 + 16) = 1152921504609439768 (0x1000000000279018);
            // 0x012FA18C: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x012FA190: B.LO #0x12fa178            | if (0 < System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count) goto label_24;
            label_22:
            // 0x012FA194: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            val_8 = 3;
            // 0x012FA198: MOV x0, x21                | X0 = b;//m1                             
            val_16 = b;
            // 0x012FA19C: MOV x1, x24                | X1 = X3 + 48 + 24;//m1                  
            // 0x012FA1A0: BL #0x2776c24              | X0 = sub_2776C24( ?? b, ????);          
            // 0x012FA1A4: B #0x12fa1b8               |  goto label_25;                         
            goto label_25;
            label_23:
            // 0x012FA1A8: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x012FA1AC: ADD w9, w9, #3             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3);
            // 0x012FA1B0: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504609402880 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3));
            // 0x012FA1B4: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504609402880 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3)).272
            label_25:
            // 0x012FA1B8: LDP x8, x2, [x0]           | X8 = X3 + 48 + 24; X2 = X3 + 48 + 24 + 8; //  | 
            val_17 = mem[X3 + 48 + 24 + 8];
            val_17 = X3 + 48 + 24 + 8;
            // 0x012FA1BC: MOV x0, x21                | X0 = b;//m1                             
            // 0x012FA1C0: MOV w1, w23                | W1 = 0 (0x0);//ML01                     
            // 0x012FA1C4: BLR x8                     | X0 = X3 + 48 + 24();                    
            // 0x012FA1C8: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x012FA1CC: MOV x24, x0                | X24 = b;//m1                            
            // 0x012FA1D0: LDR x25, [x8, #0x18]       | X25 = X3 + 48 + 24;                     
            // 0x012FA1D4: MOV x0, x25                | X0 = X3 + 48 + 24;//m1                  
            // 0x012FA1D8: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 24, ????);
            // 0x012FA1DC: LDR x8, [x19]              | X8 = __RuntimeMethodHiddenParam;        
            var val_15 = __RuntimeMethodHiddenParam;
            // 0x012FA1E0: LDRH w9, [x8, #0x102]      | W9 = __RuntimeMethodHiddenParam + 258;  
            // 0x012FA1E4: CBZ x9, #0x12fa210         | if (__RuntimeMethodHiddenParam + 258 == 0) goto label_26;
            if((__RuntimeMethodHiddenParam + 258) == 0)
            {
                goto label_26;
            }
            // 0x012FA1E8: LDR x10, [x8, #0x98]       | X10 = __RuntimeMethodHiddenParam + 152; 
            var val_12 = __RuntimeMethodHiddenParam + 152;
            // 0x012FA1EC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_13 = 0;
            // 0x012FA1F0: ADD x10, x10, #8           | X10 = (__RuntimeMethodHiddenParam + 152 + 8);
            val_12 = val_12 + 8;
            label_28:
            // 0x012FA1F4: LDUR x12, [x10, #-8]       | X12 = (__RuntimeMethodHiddenParam + 152 + 8) + -8;
            // 0x012FA1F8: CMP x12, x25               | STATE = COMPARE((__RuntimeMethodHiddenParam + 152 + 8) + -8, X3 + 48 + 24)
            // 0x012FA1FC: B.EQ #0x12fa224            | if ((__RuntimeMethodHiddenParam + 152 + 8) + -8 == X3 + 48 + 24) goto label_27;
            if(((__RuntimeMethodHiddenParam + 152 + 8) + -8) == (X3 + 48 + 24))
            {
                goto label_27;
            }
            // 0x012FA200: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_13 = val_13 + 1;
            // 0x012FA204: ADD x10, x10, #0x10        | X10 = ((__RuntimeMethodHiddenParam + 152 + 8) + 16);
            val_12 = val_12 + 16;
            // 0x012FA208: CMP x11, x9                | STATE = COMPARE((0 + 1), __RuntimeMethodHiddenParam + 258)
            // 0x012FA20C: B.LO #0x12fa1f4            | if (0 < __RuntimeMethodHiddenParam + 258) goto label_28;
            if(val_13 < (__RuntimeMethodHiddenParam + 258))
            {
                goto label_28;
            }
            label_26:
            // 0x012FA210: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            val_17 = 3;
            // 0x012FA214: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam;//m1    
            val_18 = __RuntimeMethodHiddenParam;
            // 0x012FA218: MOV x1, x25                | X1 = X3 + 48 + 24;//m1                  
            // 0x012FA21C: BL #0x2776c24              | X0 = sub_2776C24( ?? __RuntimeMethodHiddenParam, ????);
            // 0x012FA220: B #0x12fa234               |  goto label_29;                         
            goto label_29;
            label_27:
            // 0x012FA224: LDR w9, [x10]              | W9 = (__RuntimeMethodHiddenParam + 152 + 8);
            var val_14 = val_12;
            // 0x012FA228: ADD w9, w9, #3             | W9 = ((__RuntimeMethodHiddenParam + 152 + 8) + 3);
            val_14 = val_14 + 3;
            // 0x012FA22C: ADD x8, x8, w9, uxtw #4    | X8 = (__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 3));
            val_15 = val_15 + val_14;
            // 0x012FA230: ADD x0, x8, #0x110         | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 3)) + 272);
            val_18 = val_15 + 272;
            label_29:
            // 0x012FA234: LDP x8, x2, [x0]           | X8 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 3)) + 272); X2 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 3)) + 272) + 8; //  | 
            // 0x012FA238: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam;//m1    
            // 0x012FA23C: MOV w1, w23                | W1 = 0 (0x0);//ML01                     
            // 0x012FA240: BLR x8                     | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 3)) + 272)();
            // 0x012FA244: MOV x25, x0                | X25 = __RuntimeMethodHiddenParam;//m1   
            // 0x012FA248: CBNZ x22, #0x12fa250       | if (0x0 != 0) goto label_30;            
            if(0 != 0)
            {
                goto label_30;
            }
            // 0x012FA24C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? __RuntimeMethodHiddenParam, ????);
            label_30:
            // 0x012FA250: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            // 0x012FA254: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x012FA258: MOV x1, x24                | X1 = b;//m1                             
            // 0x012FA25C: MOV x2, x25                | X2 = __RuntimeMethodHiddenParam;//m1    
            // 0x012FA260: LDP x9, x3, [x8, #0x1a0]   | X9 = mem[282584257677087]; X3 = mem[282584257677095]; //  | 
            // 0x012FA264: BLR x9                     | X0 = mem[282584257677087]();            
            // 0x012FA268: ADD w23, w23, #1           | W23 = (val_12 + 1);                     
            val_12 = val_12 + 1;
            // 0x012FA26C: TBNZ w0, #0, #0x12fa0c8    | if ((0x0 & 0x1) != 0) goto label_31;    
            if((0 & 1) != 0)
            {
                goto label_31;
            }
            label_12:
            // 0x012FA270: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_10 = 0;
            // 0x012FA274: B #0x12fa27c               |  goto label_32;                         
            goto label_32;
            label_20:
            // 0x012FA278: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_10 = 1;
            label_32:
            // 0x012FA27C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x012FA280: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x012FA284: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x012FA288: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x012FA28C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x012FA290: RET                        |  return (System.Boolean)true;           
            return (bool)val_10;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x012FA368 VirtAddr: 0x012FA368 -RVA: 0x012FA368 
        // -CollectionUtils.TryGetSingleItem<object>
        //
        //
        // Offset in libil2cpp.so: 0x012FA368 (19899240), len: 32  VirtAddr: 0x012FA368 RVA: 0x012FA368 token: 100686560 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool TryGetSingleItem<T>(System.Collections.Generic.IList<T> list, out T value)
        {
            //
            // Disasemble & Code
            // 0x012FA368: LDR x8, [x3, #0x30]        | X8 = X3 + 48;                           
            // 0x012FA36C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x012FA370: LDR x4, [x8]               | X4 = X3 + 48;                           
            // 0x012FA374: MOV x8, x2                 | X8 = __RuntimeMethodHiddenParam;//m1    
            // 0x012FA378: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x012FA37C: MOV x3, x8                 | X3 = __RuntimeMethodHiddenParam;//m1    
            // 0x012FA380: LDR x5, [x4]               | X5 = X3 + 48;                           
            // 0x012FA384: BR x5                      | goto X3 + 48;                           
            goto X3 + 48;
        
        }
        // Generic instance method:
        //
        // file offset: 0x012FA294 VirtAddr: 0x012FA294 -RVA: 0x012FA294 
        // -CollectionUtils.TryGetSingleItem<object>
        //
        //
        // Offset in libil2cpp.so: 0x012FA294 (19899028), len: 212  VirtAddr: 0x012FA294 RVA: 0x012FA294 token: 100686561 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool TryGetSingleItem<T>(System.Collections.Generic.IList<T> list, bool returnDefaultIfEmpty, out T value)
        {
            //
            // Disasemble & Code
            // 0x012FA294: STP x24, x23, [sp, #-0x40]! | stack[1152921513963855264] = ???;  stack[1152921513963855272] = ???;  //  dest_result_addr=1152921513963855264 |  dest_result_addr=1152921513963855272
            // 0x012FA298: STP x22, x21, [sp, #0x10]  | stack[1152921513963855280] = ???;  stack[1152921513963855288] = ???;  //  dest_result_addr=1152921513963855280 |  dest_result_addr=1152921513963855288
            // 0x012FA29C: STP x20, x19, [sp, #0x20]  | stack[1152921513963855296] = ???;  stack[1152921513963855304] = ???;  //  dest_result_addr=1152921513963855296 |  dest_result_addr=1152921513963855304
            // 0x012FA2A0: STP x29, x30, [sp, #0x30]  | stack[1152921513963855312] = ???;  stack[1152921513963855320] = ???;  //  dest_result_addr=1152921513963855312 |  dest_result_addr=1152921513963855320
            // 0x012FA2A4: ADD x29, sp, #0x30         | X29 = (1152921513963855264 + 48) = 1152921513963855312 (0x100000022DB89DD0);
            // 0x012FA2A8: MOV x20, x4                | X20 = X4;//m1                           
            // 0x012FA2AC: LDR x8, [x20, #0x30]       | X8 = X4 + 48;                           
            // 0x012FA2B0: MOV x19, x3                | X19 = __RuntimeMethodHiddenParam;//m1   
            // 0x012FA2B4: MOV w22, w2                | W22 = 1152921513963903424 (0x100000022DB959C0);//ML01
            // 0x012FA2B8: MOV x23, x1                | X23 = returnDefaultIfEmpty;//m1         
            // 0x012FA2BC: LDR x21, [x8]              | X21 = X4 + 48;                          
            // 0x012FA2C0: MOV x0, x21                | X0 = X4 + 48;//m1                       
            // 0x012FA2C4: BL #0x277461c              | X0 = sub_277461C( ?? X4 + 48, ????);    
            // 0x012FA2C8: MOV x0, x21                | X0 = X4 + 48;//m1                       
            // 0x012FA2CC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X4 + 48, ????);
            // 0x012FA2D0: LDR x8, [x20, #0x30]       | X8 = X4 + 48;                           
            // 0x012FA2D4: MOV x21, x0                | X21 = X4 + 48;//m1                      
            // 0x012FA2D8: LDR x1, [x8, #8]           | X1 = X4 + 48 + 8;                       
            // 0x012FA2DC: LDR x8, [x1]               | X8 = X4 + 48 + 8;                       
            // 0x012FA2E0: BLR x8                     | X0 = X4 + 48 + 8();                     
            // 0x012FA2E4: CBZ x21, #0x12fa2f0        | if (X4 + 48 == 0) goto label_0;         
            if((X4 + 48) == 0)
            {
                goto label_0;
            }
            // 0x012FA2E8: STR x23, [x21, #0x10]      | mem2[0] = returnDefaultIfEmpty;          //  dest_result_addr=0
            mem2[0] = returnDefaultIfEmpty;
            // 0x012FA2EC: B #0x12fa300               |  goto label_1;                          
            goto label_1;
            label_0:
            // 0x012FA2F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X4 + 48, ????);    
            // 0x012FA2F4: ORR w8, wzr, #0x10         | W8 = 16(0x10);                          
            // 0x012FA2F8: STR x23, [x8]              | mem[16] = returnDefaultIfEmpty;          //  dest_result_addr=16
            mem[16] = returnDefaultIfEmpty;
            // 0x012FA2FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X4 + 48, ????);    
            label_1:
            // 0x012FA300: AND w8, w22, #1            | W8 = (value & 1) = 0 (0x00000000);      
            // 0x012FA304: STRB w8, [x21, #0x18]      | mem2[0] = 0x0;                           //  dest_result_addr=0
            mem2[0] = 0;
            // 0x012FA308: LDR x8, [x20, #0x30]       | X8 = X4 + 48;                           
            // 0x012FA30C: LDP x22, x23, [x8, #0x10]  | X22 = X4 + 48 + 16; X23 = X4 + 48 + 16 + 8; //  | 
            // 0x012FA310: MOV x0, x23                | X0 = X4 + 48 + 16 + 8;//m1              
            // 0x012FA314: BL #0x277461c              | X0 = sub_277461C( ?? X4 + 48 + 16 + 8, ????);
            // 0x012FA318: MOV x0, x23                | X0 = X4 + 48 + 16 + 8;//m1              
            // 0x012FA31C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X4 + 48 + 16 + 8, ????);
            // 0x012FA320: LDR x8, [x20, #0x30]       | X8 = X4 + 48;                           
            // 0x012FA324: MOV x1, x21                | X1 = X4 + 48;//m1                       
            // 0x012FA328: MOV x2, x22                | X2 = X4 + 48 + 16;//m1                  
            // 0x012FA32C: MOV x23, x0                | X23 = X4 + 48 + 16 + 8;//m1             
            // 0x012FA330: LDR x3, [x8, #0x20]        | X3 = X4 + 48 + 32;                      
            // 0x012FA334: LDR x8, [x3]               | X8 = X4 + 48 + 32;                      
            // 0x012FA338: BLR x8                     | X0 = X4 + 48 + 32();                    
            // 0x012FA33C: LDR x8, [x20, #0x30]       | X8 = X4 + 48;                           
            // 0x012FA340: MOV x2, x19                | X2 = __RuntimeMethodHiddenParam;//m1    
            // 0x012FA344: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x012FA348: MOV x1, x23                | X1 = X4 + 48 + 16 + 8;//m1              
            // 0x012FA34C: LDR x3, [x8, #0x28]        | X3 = X4 + 48 + 40;                      
            // 0x012FA350: LDR x4, [x3]               | X4 = X4 + 48 + 40;                      
            // 0x012FA354: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x012FA358: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x012FA35C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x012FA360: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x012FA364: BR x4                      | goto X4 + 48 + 40;                      
            goto X4 + 48 + 40;
        
        }
        // Generic instance method:
        //
        // file offset: 0x00FDD224 VirtAddr: 0x00FDD224 -RVA: 0x00FDD224 
        // -CollectionUtils.GetSingleItem<object>
        //
        //
        // Offset in libil2cpp.so: 0x00FDD224 (16634404), len: 24  VirtAddr: 0x00FDD224 RVA: 0x00FDD224 token: 100686562 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static T GetSingleItem<T>(System.Collections.Generic.IList<T> list)
        {
            //
            // Disasemble & Code
            // 0x00FDD224: LDR x8, [x2, #0x30]        | X8 = X2 + 48;                           
            // 0x00FDD228: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FDD22C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00FDD230: LDR x3, [x8]               | X3 = X2 + 48;                           
            // 0x00FDD234: LDR x4, [x3]               | X4 = X2 + 48;                           
            // 0x00FDD238: BR x4                      | goto X2 + 48;                           
            goto X2 + 48;
        
        }
        // Generic instance method:
        //
        // file offset: 0x00FDD23C VirtAddr: 0x00FDD23C -RVA: 0x00FDD23C 
        // -CollectionUtils.GetSingleItem<object>
        //
        //
        // Offset in libil2cpp.so: 0x00FDD23C (16634428), len: 1040  VirtAddr: 0x00FDD23C RVA: 0x00FDD23C token: 100686563 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static T GetSingleItem<T>(System.Collections.Generic.IList<T> list, bool returnDefaultIfEmpty)
        {
            //
            // Disasemble & Code
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            int val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            System.Object[] val_20;
            //  | 
            var val_21;
            //  | 
            System.Type val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            // 0x00FDD23C: STP x24, x23, [sp, #-0x40]! | stack[1152921513964117248] = ???;  stack[1152921513964117256] = ???;  //  dest_result_addr=1152921513964117248 |  dest_result_addr=1152921513964117256
            // 0x00FDD240: STP x22, x21, [sp, #0x10]  | stack[1152921513964117264] = ???;  stack[1152921513964117272] = ???;  //  dest_result_addr=1152921513964117264 |  dest_result_addr=1152921513964117272
            // 0x00FDD244: STP x20, x19, [sp, #0x20]  | stack[1152921513964117280] = ???;  stack[1152921513964117288] = ???;  //  dest_result_addr=1152921513964117280 |  dest_result_addr=1152921513964117288
            // 0x00FDD248: STP x29, x30, [sp, #0x30]  | stack[1152921513964117296] = ???;  stack[1152921513964117304] = ???;  //  dest_result_addr=1152921513964117296 |  dest_result_addr=1152921513964117304
            // 0x00FDD24C: ADD x29, sp, #0x30         | X29 = (1152921513964117248 + 48) = 1152921513964117296 (0x100000022DBC9D30);
            // 0x00FDD250: SUB sp, sp, #0x10          | SP = (1152921513964117248 - 16) = 1152921513964117232 (0x100000022DBC9CF0);
            // 0x00FDD254: ADRP x22, #0x3735000       | X22 = 57888768 (0x3735000);             
            // 0x00FDD258: LDRB w8, [x22, #0x42d]     | W8 = (bool)static_value_0373542D;       
            // 0x00FDD25C: MOV x20, x3                | X20 = X3;//m1                           
            val_12 = X3;
            // 0x00FDD260: MOV w21, w2                | W21 = __RuntimeMethodHiddenParam;//m1   
            // 0x00FDD264: MOV x19, x1                | X19 = returnDefaultIfEmpty;//m1         
            val_13 = returnDefaultIfEmpty;
            // 0x00FDD268: TBNZ w8, #0, #0xfdd284     | if (static_value_0373542D == true) goto label_0;
            // 0x00FDD26C: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
            // 0x00FDD270: LDR x8, [x8, #0xf08]       | X8 = 0x2B91604;                         
            // 0x00FDD274: LDR w0, [x8]               | W0 = 0x1C45;                            
            // 0x00FDD278: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C45, ????);     
            // 0x00FDD27C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00FDD280: STRB w8, [x22, #0x42d]     | static_value_0373542D = true;            //  dest_result_addr=57889837
            label_0:
            // 0x00FDD284: CBNZ x19, #0xfdd28c        | if (returnDefaultIfEmpty == true) goto label_1;
            if(val_13 == true)
            {
                goto label_1;
            }
            // 0x00FDD288: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C45, ????);     
            label_1:
            // 0x00FDD28C: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x00FDD290: LDR x22, [x8]              | X22 = X3 + 48;                          
            // 0x00FDD294: MOV x0, x22                | X0 = X3 + 48;//m1                       
            // 0x00FDD298: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48, ????);    
            // 0x00FDD29C: LDR x8, [x19]              | X8 = returnDefaultIfEmpty;              
            var val_7 = val_13;
            // 0x00FDD2A0: LDRH w9, [x8, #0x102]      | W9 = returnDefaultIfEmpty + 258;        
            // 0x00FDD2A4: CBZ x9, #0xfdd2d0          | if (returnDefaultIfEmpty + 258 == 0) goto label_2;
            if((returnDefaultIfEmpty + 258) == 0)
            {
                goto label_2;
            }
            // 0x00FDD2A8: LDR x10, [x8, #0x98]       | X10 = returnDefaultIfEmpty + 152;       
            // 0x00FDD2AC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_6 = 0;
            // 0x00FDD2B0: ADD x10, x10, #8           | X10 = (returnDefaultIfEmpty + 152 + 8); 
            val_14 = (returnDefaultIfEmpty + 152) + 8;
            label_4:
            // 0x00FDD2B4: LDUR x12, [x10, #-8]       | X12 = (returnDefaultIfEmpty + 152 + 8) + -8;
            // 0x00FDD2B8: CMP x12, x22               | STATE = COMPARE((returnDefaultIfEmpty + 152 + 8) + -8, X3 + 48)
            // 0x00FDD2BC: B.EQ #0xfdd2e4             | if ((returnDefaultIfEmpty + 152 + 8) + -8 == X3 + 48) goto label_3;
            if(((returnDefaultIfEmpty + 152 + 8) + -8) == (X3 + 48))
            {
                goto label_3;
            }
            // 0x00FDD2C0: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_6 = val_6 + 1;
            // 0x00FDD2C4: ADD x10, x10, #0x10        | X10 = ((returnDefaultIfEmpty + 152 + 8) + 16);
            val_14 = val_14 + 16;
            // 0x00FDD2C8: CMP x11, x9                | STATE = COMPARE((0 + 1), returnDefaultIfEmpty + 258)
            // 0x00FDD2CC: B.LO #0xfdd2b4             | if (0 < returnDefaultIfEmpty + 258) goto label_4;
            if(val_6 < (returnDefaultIfEmpty + 258))
            {
                goto label_4;
            }
            label_2:
            // 0x00FDD2D0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            val_15 = 0;
            // 0x00FDD2D4: MOV x0, x19                | X0 = returnDefaultIfEmpty;//m1          
            val_16 = val_13;
            // 0x00FDD2D8: MOV x1, x22                | X1 = X3 + 48;//m1                       
            // 0x00FDD2DC: BL #0x2776c24              | X0 = sub_2776C24( ?? returnDefaultIfEmpty, ????);
            // 0x00FDD2E0: B #0xfdd2f0                |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x00FDD2E4: LDR w9, [x10]              | W9 = (returnDefaultIfEmpty + 152 + 8);  
            // 0x00FDD2E8: ADD x8, x8, x9, lsl #4     | X8 = (returnDefaultIfEmpty + ((returnDefaultIfEmpty + 152 + 8)) << 4);
            val_7 = val_7 + (((returnDefaultIfEmpty + 152 + 8)) << 4);
            // 0x00FDD2EC: ADD x0, x8, #0x110         | X0 = ((returnDefaultIfEmpty + ((returnDefaultIfEmpty + 152 + 8)) << 4) + 272);
            val_16 = val_7 + 272;
            label_5:
            // 0x00FDD2F0: LDP x8, x1, [x0]           | X8 = ((returnDefaultIfEmpty + ((returnDefaultIfEmpty + 152 + 8)) << 4) + 272); X1 = ((returnDefaultIfEmpty + ((returnDefaultIfEmpty + 152 + 8)) << 4) + 272) + 8; //  | 
            val_17 = mem[((returnDefaultIfEmpty + ((returnDefaultIfEmpty + 152 + 8)) << 4) + 272) + 8];
            val_17 = ((returnDefaultIfEmpty + ((returnDefaultIfEmpty + 152 + 8)) << 4) + 272) + 8;
            // 0x00FDD2F4: MOV x0, x19                | X0 = returnDefaultIfEmpty;//m1          
            // 0x00FDD2F8: BLR x8                     | X0 = ((returnDefaultIfEmpty + ((returnDefaultIfEmpty + 152 + 8)) << 4) + 272)();
            // 0x00FDD2FC: CMP w0, #1                 | STATE = COMPARE(returnDefaultIfEmpty, 0x1)
            // 0x00FDD300: B.NE #0xfdd364             | if (val_13 != true) goto label_6;       
            if(val_13 != true)
            {
                goto label_6;
            }
            // 0x00FDD304: CBNZ x19, #0xfdd30c        | if (returnDefaultIfEmpty == true) goto label_7;
            if(val_13 == true)
            {
                goto label_7;
            }
            // 0x00FDD308: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? returnDefaultIfEmpty, ????);
            label_7:
            // 0x00FDD30C: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x00FDD310: LDR x20, [x8, #8]          | X20 = X3 + 48 + 8;                      
            // 0x00FDD314: MOV x0, x20                | X0 = X3 + 48 + 8;//m1                   
            // 0x00FDD318: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 8, ????);
            // 0x00FDD31C: LDR x8, [x19]              | X8 = returnDefaultIfEmpty;              
            val_18 = mem[returnDefaultIfEmpty];
            val_18 = val_13;
            // 0x00FDD320: LDRH w9, [x8, #0x102]      | W9 = returnDefaultIfEmpty + 258;        
            // 0x00FDD324: CBZ x9, #0xfdd350          | if (returnDefaultIfEmpty + 258 == 0) goto label_8;
            if((returnDefaultIfEmpty + 258) == 0)
            {
                goto label_8;
            }
            // 0x00FDD328: LDR x10, [x8, #0x98]       | X10 = returnDefaultIfEmpty + 152;       
            // 0x00FDD32C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_8 = 0;
            // 0x00FDD330: ADD x10, x10, #8           | X10 = (returnDefaultIfEmpty + 152 + 8); 
            val_14 = (returnDefaultIfEmpty + 152) + 8;
            label_10:
            // 0x00FDD334: LDUR x12, [x10, #-8]       | X12 = (returnDefaultIfEmpty + 152 + 8) + -8;
            // 0x00FDD338: CMP x12, x20               | STATE = COMPARE((returnDefaultIfEmpty + 152 + 8) + -8, X3 + 48 + 8)
            // 0x00FDD33C: B.EQ #0xfdd3c8             | if ((returnDefaultIfEmpty + 152 + 8) + -8 == X3 + 48 + 8) goto label_9;
            if(((returnDefaultIfEmpty + 152 + 8) + -8) == (X3 + 48 + 8))
            {
                goto label_9;
            }
            // 0x00FDD340: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x00FDD344: ADD x10, x10, #0x10        | X10 = ((returnDefaultIfEmpty + 152 + 8) + 16);
            val_14 = val_14 + 16;
            // 0x00FDD348: CMP x11, x9                | STATE = COMPARE((0 + 1), returnDefaultIfEmpty + 258)
            // 0x00FDD34C: B.LO #0xfdd334             | if (0 < returnDefaultIfEmpty + 258) goto label_10;
            if(val_8 < (returnDefaultIfEmpty + 258))
            {
                goto label_10;
            }
            label_8:
            // 0x00FDD350: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            val_15 = 3;
            // 0x00FDD354: MOV x0, x19                | X0 = returnDefaultIfEmpty;//m1          
            val_19 = val_13;
            // 0x00FDD358: MOV x1, x20                | X1 = X3 + 48 + 8;//m1                   
            // 0x00FDD35C: BL #0x2776c24              | X0 = sub_2776C24( ?? returnDefaultIfEmpty, ????);
            // 0x00FDD360: B #0xfdd3d8                |  goto label_11;                         
            goto label_11;
            label_6:
            // 0x00FDD364: TBZ w21, #0, #0xfdd418     | if ((__RuntimeMethodHiddenParam & 0x1) == 0) goto label_12;
            if((__RuntimeMethodHiddenParam & 1) == 0)
            {
                goto label_12;
            }
            // 0x00FDD368: CBNZ x19, #0xfdd370        | if (returnDefaultIfEmpty == true) goto label_13;
            if(val_13 == true)
            {
                goto label_13;
            }
            // 0x00FDD36C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? returnDefaultIfEmpty, ????);
            label_13:
            // 0x00FDD370: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x00FDD374: LDR x21, [x8]              | X21 = X3 + 48;                          
            val_20 = mem[X3 + 48];
            val_20 = X3 + 48;
            // 0x00FDD378: MOV x0, x21                | X0 = X3 + 48;//m1                       
            // 0x00FDD37C: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48, ????);    
            // 0x00FDD380: LDR x8, [x19]              | X8 = returnDefaultIfEmpty;              
            val_18 = mem[returnDefaultIfEmpty];
            val_18 = val_13;
            // 0x00FDD384: LDRH w9, [x8, #0x102]      | W9 = returnDefaultIfEmpty + 258;        
            // 0x00FDD388: CBZ x9, #0xfdd3b4          | if (returnDefaultIfEmpty + 258 == 0) goto label_14;
            if((returnDefaultIfEmpty + 258) == 0)
            {
                goto label_14;
            }
            // 0x00FDD38C: LDR x10, [x8, #0x98]       | X10 = returnDefaultIfEmpty + 152;       
            // 0x00FDD390: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_9 = 0;
            // 0x00FDD394: ADD x10, x10, #8           | X10 = (returnDefaultIfEmpty + 152 + 8); 
            val_14 = (returnDefaultIfEmpty + 152) + 8;
            label_16:
            // 0x00FDD398: LDUR x12, [x10, #-8]       | X12 = (returnDefaultIfEmpty + 152 + 8) + -8;
            // 0x00FDD39C: CMP x12, x21               | STATE = COMPARE((returnDefaultIfEmpty + 152 + 8) + -8, X3 + 48)
            // 0x00FDD3A0: B.EQ #0xfdd3fc             | if ((returnDefaultIfEmpty + 152 + 8) + -8 == val_20) goto label_15;
            if(((returnDefaultIfEmpty + 152 + 8) + -8) == val_20)
            {
                goto label_15;
            }
            // 0x00FDD3A4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_9 = val_9 + 1;
            // 0x00FDD3A8: ADD x10, x10, #0x10        | X10 = ((returnDefaultIfEmpty + 152 + 8) + 16);
            val_14 = val_14 + 16;
            // 0x00FDD3AC: CMP x11, x9                | STATE = COMPARE((0 + 1), returnDefaultIfEmpty + 258)
            // 0x00FDD3B0: B.LO #0xfdd398             | if (0 < returnDefaultIfEmpty + 258) goto label_16;
            if(val_9 < (returnDefaultIfEmpty + 258))
            {
                goto label_16;
            }
            label_14:
            // 0x00FDD3B4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00FDD3B8: MOV x0, x19                | X0 = returnDefaultIfEmpty;//m1          
            val_21 = val_13;
            // 0x00FDD3BC: MOV x1, x21                | X1 = X3 + 48;//m1                       
            val_17 = val_20;
            // 0x00FDD3C0: BL #0x2776c24              | X0 = sub_2776C24( ?? returnDefaultIfEmpty, ????);
            // 0x00FDD3C4: B #0xfdd408                |  goto label_17;                         
            goto label_17;
            label_9:
            // 0x00FDD3C8: LDR w9, [x10]              | W9 = (returnDefaultIfEmpty + 152 + 8);  
            var val_10 = val_14;
            // 0x00FDD3CC: ADD w9, w9, #3             | W9 = ((returnDefaultIfEmpty + 152 + 8) + 3);
            val_10 = val_10 + 3;
            // 0x00FDD3D0: ADD x8, x8, w9, uxtw #4    | X8 = (returnDefaultIfEmpty + ((returnDefaultIfEmpty + 152 + 8) + 3));
            val_18 = val_18 + val_10;
            // 0x00FDD3D4: ADD x0, x8, #0x110         | X0 = ((returnDefaultIfEmpty + ((returnDefaultIfEmpty + 152 + 8) + 3)) + 272);
            val_19 = val_18 + 272;
            label_11:
            // 0x00FDD3D8: LDP x3, x2, [x0]           | X3 = ((returnDefaultIfEmpty + ((returnDefaultIfEmpty + 152 + 8) + 3)) + 272); X2 = ((returnDefaultIfEmpty + ((returnDefaultIfEmpty + 152 + 8) + 3)) + 272) + 8; //  | 
            // 0x00FDD3DC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            val_17 = 0;
            // 0x00FDD3E0: MOV x0, x19                | X0 = returnDefaultIfEmpty;//m1          
            // 0x00FDD3E4: SUB sp, x29, #0x30         | SP = (1152921513964117296 - 48) = 1152921513964117248 (0x100000022DBC9D00);
            // 0x00FDD3E8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            val_10 = ???;
            // 0x00FDD3EC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            val_12 = ???;
            val_13 = ???;
            // 0x00FDD3F0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            val_20 = ???;
            // 0x00FDD3F4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            val_22 = ???;
            // 0x00FDD3F8: BR x3                      | goto ((returnDefaultIfEmpty + ((returnDefaultIfEmpty + 152 + 8) + 3)) + 272);
            goto ((returnDefaultIfEmpty + ((returnDefaultIfEmpty + 152 + 8) + 3)) + 272);
            label_15:
            // 0x00FDD3FC: LDR w9, [x10]              | W9 = (returnDefaultIfEmpty + 152 + 8);  
            // 0x00FDD400: ADD x8, x8, x9, lsl #4     | X8 = ((returnDefaultIfEmpty + ((returnDefaultIfEmpty + 152 + 8) + 3)) + ((returnDefaultIfEmpty + 152
            val_18 = val_18 + (((returnDefaultIfEmpty + 152 + 8)) << 4);
            // 0x00FDD404: ADD x0, x8, #0x110         | X0 = (((returnDefaultIfEmpty + ((returnDefaultIfEmpty + 152 + 8) + 3)) + ((returnDefaultIfEmpty + 15
            val_21 = val_18 + 272;
            label_17:
            // 0x00FDD408: LDP x8, x1, [x0]           | X8 = (((returnDefaultIfEmpty + ((returnDefaultIfEmpty + 152 + 8) + 3)) + ((returnDefaultIfEmpty + 152 + 8)) << 4) + 272); X1 = (((returnDefaultIfEmpty + ((returnDefaultIfEmpty + 152 + 8) + 3)) + ((returnDefaultIfEmpty + 152 + 8)) << 4) + 272) + 8; //  | 
            // 0x00FDD40C: MOV x0, x19                | X0 = X19;//m1                           
            // 0x00FDD410: BLR x8                     | X0 = (((returnDefaultIfEmpty + ((returnDefaultIfEmpty + 152 + 8) + 3)) + ((returnDefaultIfEmpty + 152 + 8)) << 4) + 272)();
            // 0x00FDD414: CBZ w0, #0xfdd630          | if ( == 0) goto label_18;               
            if(val_13 == 0)
            {
                goto label_18;
            }
            label_12:
            // 0x00FDD418: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x00FDD41C: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x00FDD420: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x00FDD424: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x00FDD428: TBZ w8, #0, #0xfdd438      | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_20;
            // 0x00FDD42C: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x00FDD430: CBNZ w8, #0xfdd438         | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
            // 0x00FDD434: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_20:
            // 0x00FDD438: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FDD43C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00FDD440: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_1 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x00FDD444: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00FDD448: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x00FDD44C: MOV x21, x0                | X21 = val_1;//m1                        
            val_20 = val_1;
            // 0x00FDD450: LDR x22, [x8]              | X22 = typeof(System.Object[]);          
            // 0x00FDD454: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00FDD458: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00FDD45C: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00FDD460: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00FDD464: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00FDD468: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00FDD46C: LDR x9, [x20, #0x30]       | X9 = val_12 + 48;                       
            // 0x00FDD470: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00FDD474: MOV x22, x0                | X22 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00FDD478: LDR x23, [x9, #0x10]       | X23 = val_12 + 48 + 16;                 
            // 0x00FDD47C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00FDD480: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00FDD484: TBZ w9, #0, #0xfdd498      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_22;
            // 0x00FDD488: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00FDD48C: CBNZ w9, #0xfdd498         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_22;
            // 0x00FDD490: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00FDD494: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_22:
            // 0x00FDD498: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FDD49C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00FDD4A0: MOV x1, x23                | X1 = val_12 + 48 + 16;//m1              
            val_23 = val_12 + 48 + 16;
            // 0x00FDD4A4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_2 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00FDD4A8: MOV x23, x0                | X23 = val_2;//m1                        
            val_22 = val_2;
            // 0x00FDD4AC: CBNZ x22, #0xfdd4b4        | if ( != null) goto label_23;            
            if(null != null)
            {
                goto label_23;
            }
            // 0x00FDD4B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_23:
            // 0x00FDD4B4: CBZ x23, #0xfdd4d8         | if (val_2 == null) goto label_25;       
            if(val_22 == null)
            {
                goto label_25;
            }
            // 0x00FDD4B8: LDR x8, [x22]              | X8 = ;                                  
            // 0x00FDD4BC: MOV x0, x23                | X0 = val_2;//m1                         
            // 0x00FDD4C0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            val_23 = mem[null + 48];
            // 0x00FDD4C4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x00FDD4C8: CBNZ x0, #0xfdd4d8         | if (val_2 != null) goto label_25;       
            if(val_22 != null)
            {
                goto label_25;
            }
            // 0x00FDD4CC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
            // 0x00FDD4D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_23 = 0;
            // 0x00FDD4D4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_25:
            // 0x00FDD4D8: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00FDD4DC: CBNZ w8, #0xfdd4ec         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_26;
            // 0x00FDD4E0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x00FDD4E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_23 = 0;
            // 0x00FDD4E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_26:
            // 0x00FDD4EC: STR x23, [x22, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = val_22;
            // 0x00FDD4F0: CBNZ x19, #0xfdd4f8        | if ( != 0) goto label_27;               
            if(val_13 != 0)
            {
                goto label_27;
            }
            // 0x00FDD4F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_27:
            // 0x00FDD4F8: LDR x8, [x20, #0x30]       | X8 = val_12 + 48;                       
            // 0x00FDD4FC: LDR x20, [x8]              | X20 = val_12 + 48;                      
            // 0x00FDD500: MOV x0, x20                | X0 = val_12 + 48;//m1                   
            // 0x00FDD504: BL #0x277461c              | X0 = sub_277461C( ?? val_12 + 48, ????);
            // 0x00FDD508: LDR x8, [x19]              | X8 = ;                                  
            var val_13 = val_13;
            // 0x00FDD50C: LDRH w9, [x8, #0x102]      | W9 = val_13 + 258;                      
            // 0x00FDD510: CBZ x9, #0xfdd53c          | if (val_13 + 258 == 0) goto label_28;   
            if((val_13 + 258) == 0)
            {
                goto label_28;
            }
            // 0x00FDD514: LDR x10, [x8, #0x98]       | X10 = val_13 + 152;                     
            var val_11 = val_13 + 152;
            // 0x00FDD518: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_12 = 0;
            // 0x00FDD51C: ADD x10, x10, #8           | X10 = (val_13 + 152 + 8);               
            val_11 = val_11 + 8;
            label_30:
            // 0x00FDD520: LDUR x12, [x10, #-8]       | X12 = (val_13 + 152 + 8) + -8;          
            // 0x00FDD524: CMP x12, x20               | STATE = COMPARE((val_13 + 152 + 8) + -8, val_12 + 48)
            // 0x00FDD528: B.EQ #0xfdd550             | if ((val_13 + 152 + 8) + -8 == val_12 + 48) goto label_29;
            if(((val_13 + 152 + 8) + -8) == (val_12 + 48))
            {
                goto label_29;
            }
            // 0x00FDD52C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_12 = val_12 + 1;
            // 0x00FDD530: ADD x10, x10, #0x10        | X10 = ((val_13 + 152 + 8) + 16);        
            val_11 = val_11 + 16;
            // 0x00FDD534: CMP x11, x9                | STATE = COMPARE((0 + 1), val_13 + 258)  
            // 0x00FDD538: B.LO #0xfdd520             | if (0 < val_13 + 258) goto label_30;    
            if(val_12 < (val_13 + 258))
            {
                goto label_30;
            }
            label_28:
            // 0x00FDD53C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00FDD540: MOV x0, x19                | X0 = X19;//m1                           
            val_24 = val_13;
            // 0x00FDD544: MOV x1, x20                | X1 = val_12 + 48;//m1                   
            val_23 = val_12 + 48;
            // 0x00FDD548: BL #0x2776c24              | X0 = sub_2776C24( ?? , ????);           
            // 0x00FDD54C: B #0xfdd55c                |  goto label_31;                         
            goto label_31;
            label_29:
            // 0x00FDD550: LDR w9, [x10]              | W9 = (val_13 + 152 + 8);                
            // 0x00FDD554: ADD x8, x8, x9, lsl #4     | X8 = (val_13 + ((val_13 + 152 + 8)) << 4);
            val_13 = val_13 + (((val_13 + 152 + 8)) << 4);
            // 0x00FDD558: ADD x0, x8, #0x110         | X0 = ((val_13 + ((val_13 + 152 + 8)) << 4) + 272);
            val_24 = val_13 + 272;
            label_31:
            // 0x00FDD55C: LDP x8, x1, [x0]           | X8 = ((val_13 + ((val_13 + 152 + 8)) << 4) + 272); X1 = ((val_13 + ((val_13 + 152 + 8)) << 4) + 272) + 8; //  | 
            // 0x00FDD560: MOV x0, x19                | X0 = X19;//m1                           
            // 0x00FDD564: BLR x8                     | X0 = ((val_13 + ((val_13 + 152 + 8)) << 4) + 272)();
            // 0x00FDD568: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00FDD56C: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x00FDD570: STR w0, [sp, #0xc]         | stack[1152921513964117324] = ;           //  dest_result_addr=1152921513964117324
            // 0x00FDD574: ADD x1, sp, #0xc           | X1 = (1152921513964117312 + 12) = 1152921513964117324 (0x100000022DBC9D4C);
            // 0x00FDD578: LDR x8, [x8]               | X8 = typeof(System.Int32);              
            // 0x00FDD57C: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x00FDD580: BL #0x27bc028              | X0 = 1152921513964173600 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), );
            // 0x00FDD584: MOV x19, x0                | X19 = 1152921513964173600 (0x100000022DBD7920);//ML01
            // 0x00FDD588: CBNZ x22, #0xfdd590        | if ( != null) goto label_32;            
            if(null != null)
            {
                goto label_32;
            }
            // 0x00FDD58C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_32:
            // 0x00FDD590: CBZ x19, #0xfdd5b4         | if (val_13 == 0) goto label_34;         
            if(val_13 == 0)
            {
                goto label_34;
            }
            // 0x00FDD594: LDR x8, [x22]              | X8 = ;                                  
            // 0x00FDD598: MOV x0, x19                | X0 = 1152921513964173600 (0x100000022DBD7920);//ML01
            // 0x00FDD59C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00FDD5A0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_13, ????);     
            // 0x00FDD5A4: CBNZ x0, #0xfdd5b4         | if (val_13 != 0) goto label_34;         
            if(val_13 != 0)
            {
                goto label_34;
            }
            // 0x00FDD5A8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_13, ????);     
            // 0x00FDD5AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00FDD5B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            label_34:
            // 0x00FDD5B4: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00FDD5B8: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00FDD5BC: B.HI #0xfdd5cc             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_35;
            // 0x00FDD5C0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_13, ????);     
            // 0x00FDD5C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00FDD5C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            label_35:
            // 0x00FDD5CC: STR x19, [x22, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = 767392032; typeof(System.Object[]).__il2cppRuntimeField_2C = 0x10000002;  //  dest_result_addr=1152921504954501304 dest_result_addr=1152921504954501308
            typeof(System.Object[]).__il2cppRuntimeField_28 = val_13;
            typeof(System.Object[]).__il2cppRuntimeField_2C = 268435458;
            // 0x00FDD5D0: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x00FDD5D4: LDR x8, [x8, #0x5f8]       | X8 = (string**)(1152921513964100032)("Expected single {0} in list but got {1}.");
            // 0x00FDD5D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FDD5DC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00FDD5E0: MOV x2, x21                | X2 = val_1;//m1                         
            // 0x00FDD5E4: LDR x1, [x8]               | X1 = "Expected single {0} in list but got {1}.";
            // 0x00FDD5E8: MOV x3, x22                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00FDD5EC: BL #0x2900ac4              | X0 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  0, provider:  "Expected single {0} in list but got {1}.", args:  val_20);
            string val_3 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  0, provider:  "Expected single {0} in list but got {1}.", args:  val_20);
            // 0x00FDD5F0: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x00FDD5F4: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x00FDD5F8: MOV x19, x0                | X19 = val_3;//m1                        
            val_13 = val_3;
            // 0x00FDD5FC: LDR x8, [x8]               | X8 = typeof(System.Exception);          
            // 0x00FDD600: MOV x0, x8                 | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_4 = null;
            // 0x00FDD604: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x00FDD608: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00FDD60C: MOV x1, x19                | X1 = val_3;//m1                         
            // 0x00FDD610: MOV x20, x0                | X20 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x00FDD614: BL #0x1c32b48              | .ctor(message:  val_13);                
            val_4 = new System.Exception(message:  val_13);
            // 0x00FDD618: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x00FDD61C: LDR x8, [x8, #0x280]       | X8 = 1152921513964104288;               
            // 0x00FDD620: MOV x0, x20                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x00FDD624: LDR x1, [x8]               | X1 = public static System.Object Newtonsoft.Json.Utilities.CollectionUtils::GetSingleItem<System.Object>(System.Collections.Generic.IList<T> list, bool returnDefaultIfEmpty);
            // 0x00FDD628: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x00FDD62C: BL #0xfbeacc               | Do_ICollectionCopyTo<System.Object>(array:  public static System.Object Newtonsoft.Json.Utilities.CollectionUtils::GetSingleItem<System.Object>(System.Collections.Generic.IList<T> list, bool returnDefaultIfEmpty), index:  0, transform:  null);
            Do_ICollectionCopyTo<System.Object>(array:  public static System.Object Newtonsoft.Json.Utilities.CollectionUtils::GetSingleItem<System.Object>(System.Collections.Generic.IList<T> list, bool returnDefaultIfEmpty), index:  0, transform:  null);
            label_18:
            // 0x00FDD630: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FDD634: SUB sp, x29, #0x30         | SP = (val_10 - 48);                     
            var val_5 = val_10 - 48;
            // 0x00FDD638: LDP x29, x30, [sp, #0x30]  | X29 = (val_10 - 48) + 48; X30 = (val_10 - 48) + 48 + 8; //  | 
            // 0x00FDD63C: LDP x20, x19, [sp, #0x20]  | X20 = (val_10 - 48) + 32; X19 = (val_10 - 48) + 32 + 8; //  | 
            // 0x00FDD640: LDP x22, x21, [sp, #0x10]  | X22 = (val_10 - 48) + 16; X21 = (val_10 - 48) + 16 + 8; //  | 
            // 0x00FDD644: LDP x24, x23, [sp], #0x40  | X24 = (val_10 - 48); X23 = (val_10 - 48) + 8; //  | 
            // 0x00FDD648: RET                        |  return (System.Object)null;            
            return (object)0;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x00B79054 VirtAddr: 0x00B79054 -RVA: 0x00B79054 
        // -CollectionUtils.Minus<object>
        //
        //
        // Offset in libil2cpp.so: 0x00B79054 (12030036), len: 1000  VirtAddr: 0x00B79054 RVA: 0x00B79054 token: 100686564 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static System.Collections.Generic.IList<T> Minus<T>(System.Collections.Generic.IList<T> list, System.Collections.Generic.IList<T> minus)
        {
            //
            // Disasemble & Code
            //  | 
            string val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            // 0x00B79054: STP x26, x25, [sp, #-0x50]! | stack[1152921513964257904] = ???;  stack[1152921513964257912] = ???;  //  dest_result_addr=1152921513964257904 |  dest_result_addr=1152921513964257912
            // 0x00B79058: STP x24, x23, [sp, #0x10]  | stack[1152921513964257920] = ???;  stack[1152921513964257928] = ???;  //  dest_result_addr=1152921513964257920 |  dest_result_addr=1152921513964257928
            // 0x00B7905C: STP x22, x21, [sp, #0x20]  | stack[1152921513964257936] = ???;  stack[1152921513964257944] = ???;  //  dest_result_addr=1152921513964257936 |  dest_result_addr=1152921513964257944
            // 0x00B79060: STP x20, x19, [sp, #0x30]  | stack[1152921513964257952] = ???;  stack[1152921513964257960] = ???;  //  dest_result_addr=1152921513964257952 |  dest_result_addr=1152921513964257960
            // 0x00B79064: STP x29, x30, [sp, #0x40]  | stack[1152921513964257968] = ???;  stack[1152921513964257976] = ???;  //  dest_result_addr=1152921513964257968 |  dest_result_addr=1152921513964257976
            // 0x00B79068: ADD x29, sp, #0x40         | X29 = (1152921513964257904 + 64) = 1152921513964257968 (0x100000022DBEC2B0);
            // 0x00B7906C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00B79070: LDRB w8, [x21, #0x9bb]     | W8 = (bool)static_value_037339BB;       
            // 0x00B79074: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00B79078: MOV x20, x2                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x00B7907C: MOV x22, x1                | X22 = minus;//m1                        
            // 0x00B79080: TBNZ w8, #0, #0xb7909c     | if (static_value_037339BB == true) goto label_0;
            // 0x00B79084: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x00B79088: LDR x8, [x8, #0x130]       | X8 = 0x2B91624;                         
            // 0x00B7908C: LDR w0, [x8]               | W0 = 0x1C4D;                            
            // 0x00B79090: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C4D, ????);     
            // 0x00B79094: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00B79098: STRB w8, [x21, #0x9bb]     | static_value_037339BB = true;            //  dest_result_addr=57883067
            label_0:
            // 0x00B7909C: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x00B790A0: LDR x8, [x8, #0x958]       | X8 = (string**)(1152921511169504192)("list");
            // 0x00B790A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B790A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00B790AC: MOV x1, x22                | X1 = minus;//m1                         
            val_9 = minus;
            // 0x00B790B0: LDR x2, [x8]               | X2 = "list";                            
            // 0x00B790B4: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  0, parameterName:  val_9 = minus);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  0, parameterName:  val_9);
            // 0x00B790B8: CBNZ x22, #0xb790c0        | if (minus != null) goto label_1;        
            if(minus != null)
            {
                goto label_1;
            }
            // 0x00B790BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_1:
            // 0x00B790C0: LDR x8, [x19, #0x30]       | X8 = X3 + 48;                           
            // 0x00B790C4: LDR x21, [x8]              | X21 = X3 + 48;                          
            // 0x00B790C8: MOV x0, x21                | X0 = X3 + 48;//m1                       
            // 0x00B790CC: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48, ????);    
            // 0x00B790D0: LDR x8, [x22]              | X8 = typeof(System.Collections.Generic.IList<T>);
            // 0x00B790D4: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00B790D8: CBZ x9, #0xb79104          | if (System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x00B790DC: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IList<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00B790E0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_8 = 0;
            // 0x00B790E4: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IList<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504609439752 (0x1000000000279008);
            label_4:
            // 0x00B790E8: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00B790EC: CMP x12, x21               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X3 + 48)
            // 0x00B790F0: B.EQ #0xb79118             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X3 + 48) goto label_3;
            // 0x00B790F4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x00B790F8: ADD x10, x10, #0x10        | X10 = (1152921504609439752 + 16) = 1152921504609439768 (0x1000000000279018);
            // 0x00B790FC: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00B79100: B.LO #0xb790e8             | if (0 < System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x00B79104: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B79108: MOV x0, x22                | X0 = minus;//m1                         
            val_10 = minus;
            // 0x00B7910C: MOV x1, x21                | X1 = X3 + 48;//m1                       
            val_9 = X3 + 48;
            // 0x00B79110: BL #0x2776c24              | X0 = sub_2776C24( ?? minus, ????);      
            // 0x00B79114: B #0xb79124                |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x00B79118: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00B7911C: ADD x8, x8, x9, lsl #4     | X8 = (1152921504609402880 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00B79120: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504609402880 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_5:
            // 0x00B79124: LDP x8, x1, [x0]           | X8 = X3 + 48; X1 = X3 + 48 + 8;          //  | 
            // 0x00B79128: MOV x0, x22                | X0 = minus;//m1                         
            // 0x00B7912C: BLR x8                     | X0 = X3 + 48();                         
            // 0x00B79130: LDR x8, [x19, #0x30]       | X8 = X3 + 48;                           
            // 0x00B79134: MOV w23, w0                | W23 = minus;//m1                        
            // 0x00B79138: LDR x21, [x8, #8]          | X21 = X3 + 48 + 8;                      
            // 0x00B7913C: MOV x0, x21                | X0 = X3 + 48 + 8;//m1                   
            // 0x00B79140: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 8, ????);
            // 0x00B79144: MOV x0, x21                | X0 = X3 + 48 + 8;//m1                   
            // 0x00B79148: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X3 + 48 + 8, ????);
            // 0x00B7914C: LDR x8, [x19, #0x30]       | X8 = X3 + 48;                           
            // 0x00B79150: MOV w1, w23                | W1 = minus;//m1                         
            val_11 = minus;
            // 0x00B79154: MOV x21, x0                | X21 = X3 + 48 + 8;//m1                  
            // 0x00B79158: LDR x2, [x8, #0x10]        | X2 = X3 + 48 + 16;                      
            val_12 = mem[X3 + 48 + 16];
            val_12 = X3 + 48 + 16;
            // 0x00B7915C: LDR x8, [x2]               | X8 = X3 + 48 + 16;                      
            // 0x00B79160: BLR x8                     | X0 = X3 + 48 + 16();                    
            // 0x00B79164: CBNZ x22, #0xb7916c        | if (minus != null) goto label_6;        
            if(minus != null)
            {
                goto label_6;
            }
            // 0x00B79168: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X3 + 48 + 8, ????);
            label_6:
            // 0x00B7916C: LDR x8, [x19, #0x30]       | X8 = X3 + 48;                           
            // 0x00B79170: LDR x23, [x8, #0x18]       | X23 = X3 + 48 + 24;                     
            // 0x00B79174: MOV x0, x23                | X0 = X3 + 48 + 24;//m1                  
            // 0x00B79178: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 24, ????);
            // 0x00B7917C: LDR x8, [x22]              | X8 = typeof(System.Collections.Generic.IList<T>);
            // 0x00B79180: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00B79184: CBZ x9, #0xb791b0          | if (System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_7;
            // 0x00B79188: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IList<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00B7918C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_9 = 0;
            // 0x00B79190: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IList<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504609439752 (0x1000000000279008);
            label_9:
            // 0x00B79194: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00B79198: CMP x12, x23               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X3 + 48 + 24)
            // 0x00B7919C: B.EQ #0xb791c4             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X3 + 48 + 24) goto label_8;
            // 0x00B791A0: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_9 = val_9 + 1;
            // 0x00B791A4: ADD x10, x10, #0x10        | X10 = (1152921504609439752 + 16) = 1152921504609439768 (0x1000000000279018);
            // 0x00B791A8: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00B791AC: B.LO #0xb79194             | if (0 < System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count) goto label_9;
            label_7:
            // 0x00B791B0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            val_12 = 0;
            // 0x00B791B4: MOV x0, x22                | X0 = minus;//m1                         
            val_13 = minus;
            // 0x00B791B8: MOV x1, x23                | X1 = X3 + 48 + 24;//m1                  
            val_11 = X3 + 48 + 24;
            // 0x00B791BC: BL #0x2776c24              | X0 = sub_2776C24( ?? minus, ????);      
            // 0x00B791C0: B #0xb791d0                |  goto label_10;                         
            goto label_10;
            label_8:
            // 0x00B791C4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00B791C8: ADD x8, x8, x9, lsl #4     | X8 = (1152921504609402880 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00B791CC: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504609402880 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_10:
            // 0x00B791D0: LDP x8, x1, [x0]           | X8 = X3 + 48 + 24; X1 = X3 + 48 + 24 + 8; //  | 
            // 0x00B791D4: MOV x0, x22                | X0 = minus;//m1                         
            // 0x00B791D8: BLR x8                     | X0 = X3 + 48 + 24();                    
            // 0x00B791DC: ADRP x25, #0x361c000       | X25 = 56737792 (0x361C000);             
            // 0x00B791E0: LDR x25, [x25, #0x358]     | X25 = 1152921504608018432;              
            // 0x00B791E4: MOV x22, x0                | X22 = minus;//m1                        
            label_29:
            // 0x00B791E8: CBNZ x22, #0xb791f0        | if (minus != null) goto label_11;       
            if(minus != null)
            {
                goto label_11;
            }
            // 0x00B791EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? minus, ????);      
            label_11:
            // 0x00B791F0: LDR x8, [x22]              | X8 = typeof(System.Collections.Generic.IList<T>);
            // 0x00B791F4: LDR x1, [x25]              | X1 = typeof(System.Collections.IEnumerator);
            // 0x00B791F8: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00B791FC: CBZ x9, #0xb79228          | if (System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_12;
            // 0x00B79200: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IList<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00B79204: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_10 = 0;
            // 0x00B79208: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IList<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504609439752 (0x1000000000279008);
            label_14:
            // 0x00B7920C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00B79210: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IEnumerator))
            // 0x00B79214: B.EQ #0xb79238             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_13;
            // 0x00B79218: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_10 = val_10 + 1;
            // 0x00B7921C: ADD x10, x10, #0x10        | X10 = (1152921504609439752 + 16) = 1152921504609439768 (0x1000000000279018);
            // 0x00B79220: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00B79224: B.LO #0xb7920c             | if (0 < System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count) goto label_14;
            label_12:
            // 0x00B79228: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            val_12 = 1;
            // 0x00B7922C: MOV x0, x22                | X0 = minus;//m1                         
            val_14 = minus;
            // 0x00B79230: BL #0x2776c24              | X0 = sub_2776C24( ?? minus, ????);      
            // 0x00B79234: B #0xb79248                |  goto label_15;                         
            goto label_15;
            label_13:
            // 0x00B79238: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00B7923C: ADD w9, w9, #1             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1);
            // 0x00B79240: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504609402880 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1));
            // 0x00B79244: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504609402880 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1)).272
            label_15:
            // 0x00B79248: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.Generic.IList<T>);  //  | 
            // 0x00B7924C: MOV x0, x22                | X0 = minus;//m1                         
            // 0x00B79250: BLR x8                     | X0 = sub_1000000000270000( ?? minus, ????);
            // 0x00B79254: AND w8, w0, #1             | W8 = (minus & 1);                       
            System.Collections.Generic.IList<T> val_4 = minus & 1;
            // 0x00B79258: TBZ w8, #0, #0xb79430      | if (((minus & 1) & 0x1) == 0) goto label_16;
            if((val_4 & 1) == 0)
            {
                goto label_16;
            }
            // 0x00B7925C: CBNZ x22, #0xb79264        | if (minus != null) goto label_17;       
            if(minus != null)
            {
                goto label_17;
            }
            // 0x00B79260: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? minus, ????);      
            label_17:
            // 0x00B79264: LDR x8, [x19, #0x30]       | X8 = X3 + 48;                           
            // 0x00B79268: LDR x23, [x8, #0x20]       | X23 = X3 + 48 + 32;                     
            // 0x00B7926C: MOV x0, x23                | X0 = X3 + 48 + 32;//m1                  
            // 0x00B79270: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 32, ????);
            // 0x00B79274: LDR x8, [x22]              | X8 = typeof(System.Collections.Generic.IList<T>);
            // 0x00B79278: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00B7927C: CBZ x9, #0xb792a8          | if (System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_18;
            // 0x00B79280: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IList<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00B79284: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_11 = 0;
            // 0x00B79288: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IList<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504609439752 (0x1000000000279008);
            label_20:
            // 0x00B7928C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00B79290: CMP x12, x23               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X3 + 48 + 32)
            // 0x00B79294: B.EQ #0xb792bc             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X3 + 48 + 32) goto label_19;
            // 0x00B79298: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_11 = val_11 + 1;
            // 0x00B7929C: ADD x10, x10, #0x10        | X10 = (1152921504609439752 + 16) = 1152921504609439768 (0x1000000000279018);
            // 0x00B792A0: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00B792A4: B.LO #0xb7928c             | if (0 < System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count) goto label_20;
            label_18:
            // 0x00B792A8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            val_12 = 0;
            // 0x00B792AC: MOV x0, x22                | X0 = minus;//m1                         
            val_16 = minus;
            // 0x00B792B0: MOV x1, x23                | X1 = X3 + 48 + 32;//m1                  
            val_15 = X3 + 48 + 32;
            // 0x00B792B4: BL #0x2776c24              | X0 = sub_2776C24( ?? minus, ????);      
            // 0x00B792B8: B #0xb792c8                |  goto label_21;                         
            goto label_21;
            label_19:
            // 0x00B792BC: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00B792C0: ADD x8, x8, x9, lsl #4     | X8 = (1152921504609402880 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00B792C4: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504609402880 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_21:
            // 0x00B792C8: LDP x8, x1, [x0]           | X8 = X3 + 48 + 32; X1 = X3 + 48 + 32 + 8; //  | 
            // 0x00B792CC: MOV x0, x22                | X0 = minus;//m1                         
            // 0x00B792D0: BLR x8                     | X0 = X3 + 48 + 32();                    
            // 0x00B792D4: MOV x23, x0                | X23 = minus;//m1                        
            // 0x00B792D8: CBZ x20, #0xb7935c         | if (__RuntimeMethodHiddenParam == 0) goto label_22;
            if(__RuntimeMethodHiddenParam == 0)
            {
                goto label_22;
            }
            // 0x00B792DC: LDR x8, [x19, #0x30]       | X8 = X3 + 48;                           
            // 0x00B792E0: LDR x24, [x8]              | X24 = X3 + 48;                          
            // 0x00B792E4: MOV x0, x24                | X0 = X3 + 48;//m1                       
            // 0x00B792E8: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48, ????);    
            // 0x00B792EC: LDR x8, [x20]              | X8 = __RuntimeMethodHiddenParam;        
            var val_15 = __RuntimeMethodHiddenParam;
            // 0x00B792F0: LDRH w9, [x8, #0x102]      | W9 = __RuntimeMethodHiddenParam + 258;  
            // 0x00B792F4: CBZ x9, #0xb79320          | if (__RuntimeMethodHiddenParam + 258 == 0) goto label_23;
            if((__RuntimeMethodHiddenParam + 258) == 0)
            {
                goto label_23;
            }
            // 0x00B792F8: LDR x10, [x8, #0x98]       | X10 = __RuntimeMethodHiddenParam + 152; 
            var val_12 = __RuntimeMethodHiddenParam + 152;
            // 0x00B792FC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_13 = 0;
            // 0x00B79300: ADD x10, x10, #8           | X10 = (__RuntimeMethodHiddenParam + 152 + 8);
            val_12 = val_12 + 8;
            label_25:
            // 0x00B79304: LDUR x12, [x10, #-8]       | X12 = (__RuntimeMethodHiddenParam + 152 + 8) + -8;
            // 0x00B79308: CMP x12, x24               | STATE = COMPARE((__RuntimeMethodHiddenParam + 152 + 8) + -8, X3 + 48)
            // 0x00B7930C: B.EQ #0xb79334             | if ((__RuntimeMethodHiddenParam + 152 + 8) + -8 == X3 + 48) goto label_24;
            if(((__RuntimeMethodHiddenParam + 152 + 8) + -8) == (X3 + 48))
            {
                goto label_24;
            }
            // 0x00B79310: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_13 = val_13 + 1;
            // 0x00B79314: ADD x10, x10, #0x10        | X10 = ((__RuntimeMethodHiddenParam + 152 + 8) + 16);
            val_12 = val_12 + 16;
            // 0x00B79318: CMP x11, x9                | STATE = COMPARE((0 + 1), __RuntimeMethodHiddenParam + 258)
            // 0x00B7931C: B.LO #0xb79304             | if (0 < __RuntimeMethodHiddenParam + 258) goto label_25;
            if(val_13 < (__RuntimeMethodHiddenParam + 258))
            {
                goto label_25;
            }
            label_23:
            // 0x00B79320: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            val_12 = 4;
            // 0x00B79324: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam;//m1    
            val_17 = __RuntimeMethodHiddenParam;
            // 0x00B79328: MOV x1, x24                | X1 = X3 + 48;//m1                       
            // 0x00B7932C: BL #0x2776c24              | X0 = sub_2776C24( ?? __RuntimeMethodHiddenParam, ????);
            // 0x00B79330: B #0xb79344                |  goto label_26;                         
            goto label_26;
            label_24:
            // 0x00B79334: LDR w9, [x10]              | W9 = (__RuntimeMethodHiddenParam + 152 + 8);
            var val_14 = val_12;
            // 0x00B79338: ADD w9, w9, #4             | W9 = ((__RuntimeMethodHiddenParam + 152 + 8) + 4);
            val_14 = val_14 + 4;
            // 0x00B7933C: ADD x8, x8, w9, uxtw #4    | X8 = (__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 4));
            val_15 = val_15 + val_14;
            // 0x00B79340: ADD x0, x8, #0x110         | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 4)) + 272);
            val_17 = val_15 + 272;
            label_26:
            // 0x00B79344: LDP x8, x2, [x0]           | X8 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 4)) + 272); X2 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 4)) + 272) + 8; //  | 
            // 0x00B79348: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam;//m1    
            // 0x00B7934C: MOV x1, x23                | X1 = minus;//m1                         
            // 0x00B79350: BLR x8                     | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8) + 4)) + 272)();
            // 0x00B79354: AND w8, w0, #1             | W8 = (__RuntimeMethodHiddenParam & 1);  
            var val_6 = __RuntimeMethodHiddenParam & 1;
            // 0x00B79358: TBNZ w8, #0, #0xb791e8     | if (((__RuntimeMethodHiddenParam & 1) & 0x1) != 0) goto label_29;
            if((val_6 & 1) != 0)
            {
                goto label_29;
            }
            label_22:
            // 0x00B7935C: CBNZ x21, #0xb79364        | if (X3 + 48 + 8 != 0) goto label_28;    
            if((X3 + 48 + 8) != 0)
            {
                goto label_28;
            }
            // 0x00B79360: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? __RuntimeMethodHiddenParam, ????);
            label_28:
            // 0x00B79364: LDR x8, [x19, #0x30]       | X8 = X3 + 48;                           
            // 0x00B79368: LDR x2, [x8, #0x28]        | X2 = X3 + 48 + 40;                      
            // 0x00B7936C: LDR x8, [x2]               | X8 = X3 + 48 + 40;                      
            // 0x00B79370: MOV x0, x21                | X0 = X3 + 48 + 8;//m1                   
            // 0x00B79374: MOV x1, x23                | X1 = minus;//m1                         
            // 0x00B79378: BLR x8                     | X0 = X3 + 48 + 40();                    
            // 0x00B7937C: B #0xb791e8                |  goto label_29;                         
            goto label_29;
            // 0x00B79380: BL #0x981060               | X0 = sub_981060( ?? X3 + 48 + 8, ????); 
            // 0x00B79384: LDR x19, [x0]              | X19 = X3 + 48 + 8;                      
            // 0x00B79388: BL #0x980920               | X0 = sub_980920( ?? X3 + 48 + 8, ????); 
            // 0x00B7938C: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            label_37:
            // 0x00B79390: CBZ x22, #0xb793fc         | if (minus == null) goto label_30;       
            if(minus == null)
            {
                goto label_30;
            }
            // 0x00B79394: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x00B79398: LDR x8, [x22]              | X8 = typeof(System.Collections.Generic.IList<T>);
            // 0x00B7939C: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x00B793A0: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x00B793A4: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00B793A8: CBZ x9, #0xb793d4          | if (System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_31;
            // 0x00B793AC: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IList<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00B793B0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_16 = 0;
            // 0x00B793B4: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IList<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504609439752 (0x1000000000279008);
            label_33:
            // 0x00B793B8: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00B793BC: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
            // 0x00B793C0: B.EQ #0xb793e4             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_32;
            // 0x00B793C4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_16 = val_16 + 1;
            // 0x00B793C8: ADD x10, x10, #0x10        | X10 = (1152921504609439752 + 16) = 1152921504609439768 (0x1000000000279018);
            // 0x00B793CC: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00B793D0: B.LO #0xb793b8             | if (0 < System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count) goto label_33;
            label_31:
            // 0x00B793D4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B793D8: MOV x0, x22                | X0 = minus;//m1                         
            val_18 = minus;
            // 0x00B793DC: BL #0x2776c24              | X0 = sub_2776C24( ?? minus, ????);      
            // 0x00B793E0: B #0xb793f0                |  goto label_34;                         
            goto label_34;
            label_32:
            // 0x00B793E4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00B793E8: ADD x8, x8, x9, lsl #4     | X8 = (1152921504609402880 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00B793EC: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504609402880 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_34:
            // 0x00B793F0: LDP x8, x1, [x0]           | X8 = X3 + 48 + 8; X1 = X3 + 48 + 8 + 8;  //  | 
            // 0x00B793F4: MOV x0, x22                | X0 = minus;//m1                         
            // 0x00B793F8: BLR x8                     | X0 = X3 + 48 + 8();                     
            label_30:
            // 0x00B793FC: CMP w20, #0x60             | STATE = COMPARE(0x0, 0x60)              
            // 0x00B79400: B.EQ #0xb79414             | if (0 == 0x60) goto label_36;           
            if(0 == 96)
            {
                goto label_36;
            }
            // 0x00B79404: CBZ x19, #0xb79414         | if (X3 + 48 + 8 == 0) goto label_36;    
            if((X3 + 48 + 8) == 0)
            {
                goto label_36;
            }
            // 0x00B79408: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B7940C: MOV x0, x19                | X0 = X3 + 48 + 8;//m1                   
            // 0x00B79410: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X3 + 48 + 8, ????);
            label_36:
            // 0x00B79414: MOV x0, x21                | X0 = X3 + 48 + 8;//m1                   
            // 0x00B79418: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00B7941C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00B79420: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00B79424: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00B79428: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00B7942C: RET                        |  return (System.Collections.Generic.IList<T>)X3 + 48 + 8;
            return (System.Collections.Generic.IList<T>)X3 + 48 + 8;
            //  |  // // {name=val_0, type=System.Collections.Generic.IList<T>, size=8, nGRN=0 }
            label_16:
            // 0x00B79430: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            // 0x00B79434: ORR w20, wzr, #0x60        | W20 = 96(0x60);                         
            // 0x00B79438: B #0xb79390                |  goto label_37;                         
            goto label_37;
        
        }
        //
        // Offset in libil2cpp.so: 0x02911E40 (43064896), len: 320  VirtAddr: 0x02911E40 RVA: 0x02911E40 token: 100686565 methodIndex: 49118 delegateWrapperIndex: 0 methodInvoker: 0
        public static System.Collections.IList CreateGenericList(System.Type listType)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            //  | 
            var val_4;
            // 0x02911E40: STP x22, x21, [sp, #-0x30]! | stack[1152921513964390512] = ???;  stack[1152921513964390520] = ???;  //  dest_result_addr=1152921513964390512 |  dest_result_addr=1152921513964390520
            // 0x02911E44: STP x20, x19, [sp, #0x10]  | stack[1152921513964390528] = ???;  stack[1152921513964390536] = ???;  //  dest_result_addr=1152921513964390528 |  dest_result_addr=1152921513964390536
            // 0x02911E48: STP x29, x30, [sp, #0x20]  | stack[1152921513964390544] = ???;  stack[1152921513964390552] = ???;  //  dest_result_addr=1152921513964390544 |  dest_result_addr=1152921513964390552
            // 0x02911E4C: ADD x29, sp, #0x20         | X29 = (1152921513964390512 + 32) = 1152921513964390544 (0x100000022DC0C890);
            // 0x02911E50: SUB sp, sp, #0x10          | SP = (1152921513964390512 - 16) = 1152921513964390496 (0x100000022DC0C860);
            // 0x02911E54: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x02911E58: LDRB w8, [x20, #0xaee]     | W8 = (bool)static_value_037B8AEE;       
            // 0x02911E5C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x02911E60: TBNZ w8, #0, #0x2911e7c    | if (static_value_037B8AEE == true) goto label_0;
            // 0x02911E64: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
            // 0x02911E68: LDR x8, [x8, #0x5e8]       | X8 = 0x2B915F4;                         
            // 0x02911E6C: LDR w0, [x8]               | W0 = 0x1C41;                            
            // 0x02911E70: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C41, ????);     
            // 0x02911E74: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02911E78: STRB w8, [x20, #0xaee]     | static_value_037B8AEE = true;            //  dest_result_addr=58428142
            label_0:
            // 0x02911E7C: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x02911E80: LDR x8, [x8, #0xd98]       | X8 = (string**)(1152921513964370272)("listType");
            // 0x02911E84: MOV x1, x19                | X1 = X1;//m1                            
            // 0x02911E88: LDR x2, [x8]               | X2 = "listType";                        
            // 0x02911E8C: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  7233, parameterName:  X1);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  7233, parameterName:  X1);
            // 0x02911E90: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x02911E94: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x02911E98: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x02911E9C: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
            // 0x02911EA0: LDR x8, [x8, #0xbd8]       | X8 = 1152921504616644608;               
            // 0x02911EA4: LDR x20, [x8]              | X20 = typeof(System.Collections.Generic.List<T>);
            // 0x02911EA8: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x02911EAC: TBZ w8, #0, #0x2911ebc     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x02911EB0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02911EB4: CBNZ w8, #0x2911ebc        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x02911EB8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x02911EBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02911EC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02911EC4: MOV x1, x20                | X1 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x02911EC8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x02911ECC: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x02911ED0: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x02911ED4: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x02911ED8: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
            // 0x02911EDC: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02911EE0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x02911EE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02911EE8: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02911EEC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x02911EF0: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x02911EF4: MOV x2, x19                | X2 = X1;//m1                            
            // 0x02911EF8: MOV x3, x0                 | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02911EFC: BL #0x2911f80              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.CreateGeneric(genericTypeDefinition:  null, innerType:  val_1, args:  X1);
            object val_2 = Newtonsoft.Json.Utilities.ReflectionUtils.CreateGeneric(genericTypeDefinition:  null, innerType:  val_1, args:  X1);
            // 0x02911F00: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x02911F04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_4 = 0;
            // 0x02911F08: CBZ x19, #0x2911f58        | if (val_2 == null) goto label_4;        
            if(val_2 == null)
            {
                goto label_4;
            }
            // 0x02911F0C: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x02911F10: LDR x8, [x8, #0x308]       | X8 = 1152921504609349632;               
            // 0x02911F14: MOV x0, x19                | X0 = val_2;//m1                         
            val_4 = val_2;
            // 0x02911F18: LDR x20, [x8]              | X20 = typeof(System.Collections.IList); 
            // 0x02911F1C: MOV x1, x20                | X1 = 1152921504609349632 (0x1000000000263000);//ML01
            // 0x02911F20: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x02911F24: CBNZ x0, #0x2911f58        | if (val_2 != null) goto label_4;        
            if(val_4 != null)
            {
                goto label_4;
            }
            // 0x02911F28: LDR x8, [x19]              | X8 = typeof(System.Object);             
            // 0x02911F2C: MOV x1, x20                | X1 = 1152921504609349632 (0x1000000000263000);//ML01
            // 0x02911F30: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x02911F34: ADD x8, sp, #8             | X8 = (1152921513964390496 + 8) = 1152921513964390504 (0x100000022DC0C868);
            // 0x02911F38: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x02911F3C: LDR x0, [sp, #8]           | X0 = val_3;                              //  find_add[1152921513964378560]
            // 0x02911F40: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
            // 0x02911F44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02911F48: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            // 0x02911F4C: ADD x0, sp, #8             | X0 = (1152921513964390496 + 8) = 1152921513964390504 (0x100000022DC0C868);
            // 0x02911F50: BL #0x299a140              | 
            // 0x02911F54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_4 = 0;
            label_4:
            // 0x02911F58: SUB sp, x29, #0x20         | SP = (1152921513964390544 - 32) = 1152921513964390512 (0x100000022DC0C870);
            // 0x02911F5C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x02911F60: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x02911F64: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x02911F68: RET                        |  return (System.Collections.IList)null; 
            return (System.Collections.IList)val_4;
            //  |  // // {name=val_0, type=System.Collections.IList, size=8, nGRN=0 }
            // 0x02911F6C: MOV x19, x0                | 
            // 0x02911F70: ADD x0, sp, #8             | 
            // 0x02911F74: BL #0x299a140              | 
            // 0x02911F78: MOV x0, x19                | 
            // 0x02911F7C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x02912044 (43065412), len: 412  VirtAddr: 0x02912044 RVA: 0x02912044 token: 100686566 methodIndex: 49119 delegateWrapperIndex: 0 methodInvoker: 0
        public static System.Collections.IDictionary CreateGenericDictionary(System.Type keyType, System.Type valueType)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            //  | 
            string val_4;
            //  | 
            System.Type val_5;
            //  | 
            var val_6;
            // 0x02912044: STP x22, x21, [sp, #-0x30]! | stack[1152921513964531280] = ???;  stack[1152921513964531288] = ???;  //  dest_result_addr=1152921513964531280 |  dest_result_addr=1152921513964531288
            // 0x02912048: STP x20, x19, [sp, #0x10]  | stack[1152921513964531296] = ???;  stack[1152921513964531304] = ???;  //  dest_result_addr=1152921513964531296 |  dest_result_addr=1152921513964531304
            // 0x0291204C: STP x29, x30, [sp, #0x20]  | stack[1152921513964531312] = ???;  stack[1152921513964531320] = ???;  //  dest_result_addr=1152921513964531312 |  dest_result_addr=1152921513964531320
            // 0x02912050: ADD x29, sp, #0x20         | X29 = (1152921513964531280 + 32) = 1152921513964531312 (0x100000022DC2EE70);
            // 0x02912054: SUB sp, sp, #0x10          | SP = (1152921513964531280 - 16) = 1152921513964531264 (0x100000022DC2EE40);
            // 0x02912058: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x0291205C: LDRB w8, [x21, #0xaef]     | W8 = (bool)static_value_037B8AEF;       
            // 0x02912060: MOV x19, x2                | X19 = X2;//m1                           
            val_4 = X2;
            // 0x02912064: MOV x20, x1                | X20 = valueType;//m1                    
            // 0x02912068: TBNZ w8, #0, #0x2912084    | if (static_value_037B8AEF == true) goto label_0;
            // 0x0291206C: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x02912070: LDR x8, [x8, #0xdf0]       | X8 = 0x2B915F0;                         
            // 0x02912074: LDR w0, [x8]               | W0 = 0x1C40;                            
            // 0x02912078: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C40, ????);     
            // 0x0291207C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02912080: STRB w8, [x21, #0xaef]     | static_value_037B8AEF = true;            //  dest_result_addr=58428143
            label_0:
            // 0x02912084: ADRP x8, #0x3681000        | X8 = 57151488 (0x3681000);              
            // 0x02912088: LDR x8, [x8, #0xaf8]       | X8 = (string**)(1152921513964511040)("keyType");
            // 0x0291208C: MOV x1, x20                | X1 = valueType;//m1                     
            // 0x02912090: LDR x2, [x8]               | X2 = "keyType";                         
            // 0x02912094: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  7232, parameterName:  valueType);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  7232, parameterName:  valueType);
            // 0x02912098: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x0291209C: LDR x8, [x8, #0x230]       | X8 = (string**)(1152921513863960336)("valueType");
            // 0x029120A0: MOV x1, x19                | X1 = X2;//m1                            
            // 0x029120A4: LDR x2, [x8]               | X2 = "valueType";                       
            // 0x029120A8: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  7232, parameterName:  val_4);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  7232, parameterName:  val_4);
            // 0x029120AC: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x029120B0: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x029120B4: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x029120B8: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x029120BC: LDR x8, [x8, #0xa10]       | X8 = 1152921504615792640;               
            // 0x029120C0: LDR x21, [x8]              | X21 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            // 0x029120C4: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x029120C8: TBZ w8, #0, #0x29120d8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x029120CC: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x029120D0: CBNZ w8, #0x29120d8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x029120D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x029120D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x029120DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x029120E0: MOV x1, x21                | X1 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x029120E4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x029120E8: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x029120EC: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x029120F0: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x029120F4: LDR x22, [x8]              | X22 = typeof(System.Object[]);          
            // 0x029120F8: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x029120FC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x02912100: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x02912104: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            val_5 = null;
            // 0x02912108: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x0291210C: MOV x22, x0                | X22 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02912110: CBNZ x22, #0x2912118       | if ( != null) goto label_3;             
            if(null != null)
            {
                goto label_3;
            }
            // 0x02912114: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_3:
            // 0x02912118: CBZ x19, #0x291213c        | if (X2 == 0) goto label_5;              
            if(val_4 == 0)
            {
                goto label_5;
            }
            // 0x0291211C: LDR x8, [x22]              | X8 = ;                                  
            // 0x02912120: MOV x0, x19                | X0 = X2;//m1                            
            val_5 = val_4;
            // 0x02912124: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x02912128: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X2, ????);         
            // 0x0291212C: CBNZ x0, #0x291213c        | if (X2 != 0) goto label_5;              
            if(val_5 != 0)
            {
                goto label_5;
            }
            // 0x02912130: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? X2, ????);         
            // 0x02912134: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02912138: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X2, ????);         
            label_5:
            // 0x0291213C: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x02912140: CBNZ w8, #0x2912150        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_6;
            // 0x02912144: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X2, ????);         
            // 0x02912148: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0291214C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X2, ????);         
            label_6:
            // 0x02912150: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x02912154: MOV x2, x20                | X2 = valueType;//m1                     
            // 0x02912158: MOV x3, x22                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x0291215C: STR x19, [x22, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = X2;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = val_4;
            // 0x02912160: BL #0x2911f80              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.CreateGeneric(genericTypeDefinition:  val_5 = val_4, innerType:  val_1, args:  valueType);
            object val_2 = Newtonsoft.Json.Utilities.ReflectionUtils.CreateGeneric(genericTypeDefinition:  val_5, innerType:  val_1, args:  valueType);
            // 0x02912164: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x02912168: CBZ x20, #0x29121b4        | if (val_2 == null) goto label_7;        
            if(val_2 == null)
            {
                goto label_7;
            }
            // 0x0291216C: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
            // 0x02912170: LDR x8, [x8, #0xa88]       | X8 = 1152921504618135552;               
            // 0x02912174: MOV x0, x20                | X0 = val_2;//m1                         
            val_6 = val_2;
            // 0x02912178: LDR x19, [x8]              | X19 = typeof(System.Collections.IDictionary);
            val_4 = null;
            // 0x0291217C: MOV x1, x19                | X1 = 1152921504618135552 (0x1000000000AC4000);//ML01
            // 0x02912180: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x02912184: CBNZ x0, #0x29121b8        | if (val_2 != null) goto label_8;        
            if(val_6 != null)
            {
                goto label_8;
            }
            // 0x02912188: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x0291218C: MOV x1, x19                | X1 = 1152921504618135552 (0x1000000000AC4000);//ML01
            // 0x02912190: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x02912194: ADD x8, sp, #8             | X8 = (1152921513964531264 + 8) = 1152921513964531272 (0x100000022DC2EE48);
            // 0x02912198: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0291219C: LDR x0, [sp, #8]           | X0 = val_3;                              //  find_add[1152921513964519328]
            // 0x029121A0: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
            // 0x029121A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029121A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            // 0x029121AC: ADD x0, sp, #8             | X0 = (1152921513964531264 + 8) = 1152921513964531272 (0x100000022DC2EE48);
            // 0x029121B0: BL #0x299a140              | 
            label_7:
            // 0x029121B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_6 = 0;
            label_8:
            // 0x029121B8: SUB sp, x29, #0x20         | SP = (1152921513964531312 - 32) = 1152921513964531280 (0x100000022DC2EE50);
            // 0x029121BC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x029121C0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x029121C4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x029121C8: RET                        |  return (System.Collections.IDictionary)null;
            return (System.Collections.IDictionary)val_6;
            //  |  // // {name=val_0, type=System.Collections.IDictionary, size=8, nGRN=0 }
            // 0x029121CC: MOV x19, x0                | 
            // 0x029121D0: ADD x0, sp, #8             | 
            // 0x029121D4: BL #0x299a140              | 
            // 0x029121D8: MOV x0, x19                | 
            // 0x029121DC: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x029121E0 (43065824), len: 316  VirtAddr: 0x029121E0 RVA: 0x029121E0 token: 100686567 methodIndex: 49120 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool IsListType(System.Type type)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            // 0x029121E0: STP x22, x21, [sp, #-0x30]! | stack[1152921513964671952] = ???;  stack[1152921513964671960] = ???;  //  dest_result_addr=1152921513964671952 |  dest_result_addr=1152921513964671960
            // 0x029121E4: STP x20, x19, [sp, #0x10]  | stack[1152921513964671968] = ???;  stack[1152921513964671976] = ???;  //  dest_result_addr=1152921513964671968 |  dest_result_addr=1152921513964671976
            // 0x029121E8: STP x29, x30, [sp, #0x20]  | stack[1152921513964671984] = ???;  stack[1152921513964671992] = ???;  //  dest_result_addr=1152921513964671984 |  dest_result_addr=1152921513964671992
            // 0x029121EC: ADD x29, sp, #0x20         | X29 = (1152921513964671952 + 32) = 1152921513964671984 (0x100000022DC513F0);
            // 0x029121F0: SUB sp, sp, #0x10          | SP = (1152921513964671952 - 16) = 1152921513964671936 (0x100000022DC513C0);
            // 0x029121F4: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x029121F8: LDRB w8, [x20, #0xaf0]     | W8 = (bool)static_value_037B8AF0;       
            // 0x029121FC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x02912200: TBNZ w8, #0, #0x291221c    | if (static_value_037B8AF0 == true) goto label_0;
            // 0x02912204: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x02912208: LDR x8, [x8, #0x438]       | X8 = 0x2B9161C;                         
            // 0x0291220C: LDR w0, [x8]               | W0 = 0x1C4B;                            
            // 0x02912210: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C4B, ????);     
            // 0x02912214: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02912218: STRB w8, [x20, #0xaf0]     | static_value_037B8AF0 = true;            //  dest_result_addr=58428144
            label_0:
            // 0x0291221C: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x02912220: LDR x8, [x8, #0xb90]       | X8 = (string**)(1152921510122301360)("type");
            // 0x02912224: MOV x1, x19                | X1 = X1;//m1                            
            // 0x02912228: LDR x2, [x8]               | X2 = "type";                            
            // 0x0291222C: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  7243, parameterName:  X1);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  7243, parameterName:  X1);
            // 0x02912230: CBNZ x19, #0x2912238       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x02912234: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C4B, ????);     
            label_1:
            // 0x02912238: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0291223C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x02912240: BL #0x1b6d1cc              | X0 = X1.get_IsArray();                  
            bool val_1 = X1.IsArray;
            // 0x02912244: AND w8, w0, #1             | W8 = (val_1 & 1);                       
            bool val_2 = val_1;
            // 0x02912248: TBNZ w8, #0, #0x29122b4    | if ((val_1 & 1) == true) goto label_2;  
            if(val_2 == true)
            {
                goto label_2;
            }
            // 0x0291224C: ADRP x21, #0x3620000       | X21 = 56754176 (0x3620000);             
            // 0x02912250: LDR x21, [x21, #0x340]     | X21 = 1152921504609562624;              
            // 0x02912254: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x02912258: LDR x0, [x21]              | X0 = typeof(System.Type);               
            // 0x0291225C: LDR x8, [x8, #0x9a0]       | X8 = 1152921504609349632;               
            // 0x02912260: LDR x20, [x8]              | X20 = typeof(System.Collections.IList); 
            // 0x02912264: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x02912268: TBZ w8, #0, #0x2912278     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x0291226C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02912270: CBNZ w8, #0x2912278        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x02912274: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x02912278: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0291227C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02912280: MOV x1, x20                | X1 = 1152921504609349632 (0x1000000000263000);//ML01
            // 0x02912284: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x02912288: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x0291228C: CBNZ x20, #0x2912294       | if (val_3 != null) goto label_5;        
            if(val_3 != null)
            {
                goto label_5;
            }
            // 0x02912290: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_5:
            // 0x02912294: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x02912298: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x0291229C: MOV x1, x19                | X1 = X1;//m1                            
            // 0x029122A0: LDR x9, [x8, #0x3e0]       | X9 = typeof(System.Type).__il2cppRuntimeField_3E0;
            // 0x029122A4: LDR x2, [x8, #0x3e8]       | X2 = typeof(System.Type).__il2cppRuntimeField_3E8;
            // 0x029122A8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_3E0();
            // 0x029122AC: AND w8, w0, #1             | W8 = (val_3 & 1);                       
            System.Type val_4 = val_3 & 1;
            // 0x029122B0: TBZ w8, #0, #0x29122bc     | if (((val_3 & 1) & 0x1) == 0) goto label_6;
            if((val_4 & 1) == 0)
            {
                goto label_6;
            }
            label_2:
            // 0x029122B4: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_9 = 1;
            // 0x029122B8: B #0x2912308               |  goto label_7;                          
            goto label_7;
            label_6:
            // 0x029122BC: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x029122C0: LDR x0, [x21]              | X0 = typeof(System.Type);               
            // 0x029122C4: LDR x8, [x8, #0xe48]       | X8 = 1152921504609402880;               
            // 0x029122C8: LDR x20, [x8]              | X20 = typeof(System.Collections.Generic.IList<T>);
            // 0x029122CC: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x029122D0: TBZ w8, #0, #0x29122e0     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x029122D4: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x029122D8: CBNZ w8, #0x29122e0        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x029122DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_9:
            // 0x029122E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x029122E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x029122E8: MOV x1, x20                | X1 = 1152921504609402880 (0x1000000000270000);//ML01
            // 0x029122EC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x029122F0: ADD x3, sp, #8             | X3 = (1152921513964671936 + 8) = 1152921513964671944 (0x100000022DC513C8);
            // 0x029122F4: MOV x1, x19                | X1 = X1;//m1                            
            // 0x029122F8: MOV x2, x0                 | X2 = val_5;//m1                         
            System.Type val_6 = val_5;
            // 0x029122FC: STR xzr, [sp, #8]          | stack[1152921513964671944] = 0x0;        //  dest_result_addr=1152921513964671944
            // 0x02912300: BL #0x28fdaec              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle()), genericInterfaceDefinition:  X1, implementingType: out  System.Type val_6 = val_5);
            bool val_7 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  val_5, genericInterfaceDefinition:  X1, implementingType: out  val_6);
            // 0x02912304: AND w0, w0, #1             | W0 = (val_7 & 1);                       
            val_9 = val_7;
            label_7:
            // 0x02912308: SUB sp, x29, #0x20         | SP = (1152921513964671984 - 32) = 1152921513964671952 (0x100000022DC513D0);
            // 0x0291230C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x02912310: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x02912314: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x02912318: RET                        |  return (System.Boolean)(val_7 & 1);    
            return (bool)val_9;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x02912344 (43066180), len: 316  VirtAddr: 0x02912344 RVA: 0x02912344 token: 100686568 methodIndex: 49121 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool IsCollectionType(System.Type type)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            // 0x02912344: STP x22, x21, [sp, #-0x30]! | stack[1152921513964808528] = ???;  stack[1152921513964808536] = ???;  //  dest_result_addr=1152921513964808528 |  dest_result_addr=1152921513964808536
            // 0x02912348: STP x20, x19, [sp, #0x10]  | stack[1152921513964808544] = ???;  stack[1152921513964808552] = ???;  //  dest_result_addr=1152921513964808544 |  dest_result_addr=1152921513964808552
            // 0x0291234C: STP x29, x30, [sp, #0x20]  | stack[1152921513964808560] = ???;  stack[1152921513964808568] = ???;  //  dest_result_addr=1152921513964808560 |  dest_result_addr=1152921513964808568
            // 0x02912350: ADD x29, sp, #0x20         | X29 = (1152921513964808528 + 32) = 1152921513964808560 (0x100000022DC72970);
            // 0x02912354: SUB sp, sp, #0x10          | SP = (1152921513964808528 - 16) = 1152921513964808512 (0x100000022DC72940);
            // 0x02912358: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x0291235C: LDRB w8, [x20, #0xaf1]     | W8 = (bool)static_value_037B8AF1;       
            // 0x02912360: MOV x19, x1                | X19 = X1;//m1                           
            // 0x02912364: TBNZ w8, #0, #0x2912380    | if (static_value_037B8AF1 == true) goto label_0;
            // 0x02912368: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
            // 0x0291236C: LDR x8, [x8, #0xa08]       | X8 = 0x2B91614;                         
            // 0x02912370: LDR w0, [x8]               | W0 = 0x1C49;                            
            // 0x02912374: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C49, ????);     
            // 0x02912378: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0291237C: STRB w8, [x20, #0xaf1]     | static_value_037B8AF1 = true;            //  dest_result_addr=58428145
            label_0:
            // 0x02912380: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x02912384: LDR x8, [x8, #0xb90]       | X8 = (string**)(1152921510122301360)("type");
            // 0x02912388: MOV x1, x19                | X1 = X1;//m1                            
            // 0x0291238C: LDR x2, [x8]               | X2 = "type";                            
            // 0x02912390: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  7241, parameterName:  X1);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  7241, parameterName:  X1);
            // 0x02912394: CBNZ x19, #0x291239c       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x02912398: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C49, ????);     
            label_1:
            // 0x0291239C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029123A0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x029123A4: BL #0x1b6d1cc              | X0 = X1.get_IsArray();                  
            bool val_1 = X1.IsArray;
            // 0x029123A8: AND w8, w0, #1             | W8 = (val_1 & 1);                       
            bool val_2 = val_1;
            // 0x029123AC: TBNZ w8, #0, #0x2912418    | if ((val_1 & 1) == true) goto label_2;  
            if(val_2 == true)
            {
                goto label_2;
            }
            // 0x029123B0: ADRP x21, #0x3620000       | X21 = 56754176 (0x3620000);             
            // 0x029123B4: LDR x21, [x21, #0x340]     | X21 = 1152921504609562624;              
            // 0x029123B8: ADRP x8, #0x3678000        | X8 = 57114624 (0x3678000);              
            // 0x029123BC: LDR x0, [x21]              | X0 = typeof(System.Type);               
            // 0x029123C0: LDR x8, [x8, #0x400]       | X8 = 1152921504609296384;               
            // 0x029123C4: LDR x20, [x8]              | X20 = typeof(System.Collections.ICollection);
            // 0x029123C8: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x029123CC: TBZ w8, #0, #0x29123dc     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x029123D0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x029123D4: CBNZ w8, #0x29123dc        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x029123D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x029123DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x029123E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x029123E4: MOV x1, x20                | X1 = 1152921504609296384 (0x1000000000256000);//ML01
            // 0x029123E8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x029123EC: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x029123F0: CBNZ x20, #0x29123f8       | if (val_3 != null) goto label_5;        
            if(val_3 != null)
            {
                goto label_5;
            }
            // 0x029123F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_5:
            // 0x029123F8: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x029123FC: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x02912400: MOV x1, x19                | X1 = X1;//m1                            
            // 0x02912404: LDR x9, [x8, #0x3e0]       | X9 = typeof(System.Type).__il2cppRuntimeField_3E0;
            // 0x02912408: LDR x2, [x8, #0x3e8]       | X2 = typeof(System.Type).__il2cppRuntimeField_3E8;
            // 0x0291240C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_3E0();
            // 0x02912410: AND w8, w0, #1             | W8 = (val_3 & 1);                       
            System.Type val_4 = val_3 & 1;
            // 0x02912414: TBZ w8, #0, #0x2912420     | if (((val_3 & 1) & 0x1) == 0) goto label_6;
            if((val_4 & 1) == 0)
            {
                goto label_6;
            }
            label_2:
            // 0x02912418: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_9 = 1;
            // 0x0291241C: B #0x291246c               |  goto label_7;                          
            goto label_7;
            label_6:
            // 0x02912420: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x02912424: LDR x0, [x21]              | X0 = typeof(System.Type);               
            // 0x02912428: LDR x8, [x8, #0x790]       | X8 = 1152921504609456128;               
            // 0x0291242C: LDR x20, [x8]              | X20 = typeof(System.Collections.Generic.ICollection<T>);
            // 0x02912430: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x02912434: TBZ w8, #0, #0x2912444     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x02912438: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0291243C: CBNZ w8, #0x2912444        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x02912440: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_9:
            // 0x02912444: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02912448: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0291244C: MOV x1, x20                | X1 = 1152921504609456128 (0x100000000027D000);//ML01
            // 0x02912450: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x02912454: ADD x3, sp, #8             | X3 = (1152921513964808512 + 8) = 1152921513964808520 (0x100000022DC72948);
            // 0x02912458: MOV x1, x19                | X1 = X1;//m1                            
            // 0x0291245C: MOV x2, x0                 | X2 = val_5;//m1                         
            System.Type val_6 = val_5;
            // 0x02912460: STR xzr, [sp, #8]          | stack[1152921513964808520] = 0x0;        //  dest_result_addr=1152921513964808520
            // 0x02912464: BL #0x28fdaec              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle()), genericInterfaceDefinition:  X1, implementingType: out  System.Type val_6 = val_5);
            bool val_7 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  val_5, genericInterfaceDefinition:  X1, implementingType: out  val_6);
            // 0x02912468: AND w0, w0, #1             | W0 = (val_7 & 1);                       
            val_9 = val_7;
            label_7:
            // 0x0291246C: SUB sp, x29, #0x20         | SP = (1152921513964808560 - 32) = 1152921513964808528 (0x100000022DC72950);
            // 0x02912470: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x02912474: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x02912478: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0291247C: RET                        |  return (System.Boolean)(val_7 & 1);    
            return (bool)val_9;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x02912480 (43066496), len: 288  VirtAddr: 0x02912480 RVA: 0x02912480 token: 100686569 methodIndex: 49122 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool IsDictionaryType(System.Type type)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            // 0x02912480: STP x22, x21, [sp, #-0x30]! | stack[1152921513964945104] = ???;  stack[1152921513964945112] = ???;  //  dest_result_addr=1152921513964945104 |  dest_result_addr=1152921513964945112
            // 0x02912484: STP x20, x19, [sp, #0x10]  | stack[1152921513964945120] = ???;  stack[1152921513964945128] = ???;  //  dest_result_addr=1152921513964945120 |  dest_result_addr=1152921513964945128
            // 0x02912488: STP x29, x30, [sp, #0x20]  | stack[1152921513964945136] = ???;  stack[1152921513964945144] = ???;  //  dest_result_addr=1152921513964945136 |  dest_result_addr=1152921513964945144
            // 0x0291248C: ADD x29, sp, #0x20         | X29 = (1152921513964945104 + 32) = 1152921513964945136 (0x100000022DC93EF0);
            // 0x02912490: SUB sp, sp, #0x10          | SP = (1152921513964945104 - 16) = 1152921513964945088 (0x100000022DC93EC0);
            // 0x02912494: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x02912498: LDRB w8, [x20, #0xaf2]     | W8 = (bool)static_value_037B8AF2;       
            // 0x0291249C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x029124A0: TBNZ w8, #0, #0x29124bc    | if (static_value_037B8AF2 == true) goto label_0;
            // 0x029124A4: ADRP x8, #0x3681000        | X8 = 57151488 (0x3681000);              
            // 0x029124A8: LDR x8, [x8, #0xc20]       | X8 = 0x2B91618;                         
            // 0x029124AC: LDR w0, [x8]               | W0 = 0x1C4A;                            
            // 0x029124B0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C4A, ????);     
            // 0x029124B4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x029124B8: STRB w8, [x20, #0xaf2]     | static_value_037B8AF2 = true;            //  dest_result_addr=58428146
            label_0:
            // 0x029124BC: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x029124C0: LDR x8, [x8, #0xb90]       | X8 = (string**)(1152921510122301360)("type");
            // 0x029124C4: MOV x1, x19                | X1 = X1;//m1                            
            // 0x029124C8: LDR x2, [x8]               | X2 = "type";                            
            // 0x029124CC: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  7242, parameterName:  X1);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  7242, parameterName:  X1);
            // 0x029124D0: ADRP x21, #0x3620000       | X21 = 56754176 (0x3620000);             
            // 0x029124D4: LDR x21, [x21, #0x340]     | X21 = 1152921504609562624;              
            // 0x029124D8: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
            // 0x029124DC: LDR x0, [x21]              | X0 = typeof(System.Type);               
            // 0x029124E0: LDR x8, [x8, #0x950]       | X8 = 1152921504618135552;               
            // 0x029124E4: LDR x20, [x8]              | X20 = typeof(System.Collections.IDictionary);
            // 0x029124E8: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x029124EC: TBZ w8, #0, #0x29124fc     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x029124F0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x029124F4: CBNZ w8, #0x29124fc        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x029124F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x029124FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02912500: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02912504: MOV x1, x20                | X1 = 1152921504618135552 (0x1000000000AC4000);//ML01
            // 0x02912508: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0291250C: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x02912510: CBNZ x20, #0x2912518       | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x02912514: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x02912518: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x0291251C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x02912520: MOV x1, x19                | X1 = X1;//m1                            
            // 0x02912524: LDR x9, [x8, #0x3e0]       | X9 = typeof(System.Type).__il2cppRuntimeField_3E0;
            // 0x02912528: LDR x2, [x8, #0x3e8]       | X2 = typeof(System.Type).__il2cppRuntimeField_3E8;
            // 0x0291252C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_3E0();
            // 0x02912530: AND w8, w0, #1             | W8 = (val_1 & 1);                       
            System.Type val_2 = val_1 & 1;
            // 0x02912534: TBZ w8, #0, #0x2912540     | if (((val_1 & 1) & 0x1) == 0) goto label_4;
            if((val_2 & 1) == 0)
            {
                goto label_4;
            }
            // 0x02912538: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_7 = 1;
            // 0x0291253C: B #0x291258c               |  goto label_5;                          
            goto label_5;
            label_4:
            // 0x02912540: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
            // 0x02912544: LDR x0, [x21]              | X0 = typeof(System.Type);               
            // 0x02912548: LDR x8, [x8, #0xed8]       | X8 = 1152921504616431616;               
            // 0x0291254C: LDR x20, [x8]              | X20 = typeof(System.Collections.Generic.IDictionary<TKey, TValue>);
            // 0x02912550: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x02912554: TBZ w8, #0, #0x2912564     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x02912558: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0291255C: CBNZ w8, #0x2912564        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x02912560: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_7:
            // 0x02912564: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02912568: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0291256C: MOV x1, x20                | X1 = 1152921504616431616 (0x1000000000924000);//ML01
            // 0x02912570: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x02912574: ADD x3, sp, #8             | X3 = (1152921513964945088 + 8) = 1152921513964945096 (0x100000022DC93EC8);
            // 0x02912578: MOV x1, x19                | X1 = X1;//m1                            
            // 0x0291257C: MOV x2, x0                 | X2 = val_3;//m1                         
            System.Type val_4 = val_3;
            // 0x02912580: STR xzr, [sp, #8]          | stack[1152921513964945096] = 0x0;        //  dest_result_addr=1152921513964945096
            // 0x02912584: BL #0x28fdaec              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle()), genericInterfaceDefinition:  X1, implementingType: out  System.Type val_4 = val_3);
            bool val_5 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  val_3, genericInterfaceDefinition:  X1, implementingType: out  val_4);
            // 0x02912588: AND w0, w0, #1             | W0 = (val_5 & 1);                       
            val_7 = val_5;
            label_5:
            // 0x0291258C: SUB sp, x29, #0x20         | SP = (1152921513964945136 - 32) = 1152921513964945104 (0x100000022DC93ED0);
            // 0x02912590: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x02912594: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x02912598: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0291259C: RET                        |  return (System.Boolean)(val_5 & 1);    
            return (bool)val_7;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x02901914 (42998036), len: 1292  VirtAddr: 0x02901914 RVA: 0x02901914 token: 100686570 methodIndex: 49123 delegateWrapperIndex: 0 methodInvoker: 0
        public static Newtonsoft.Json.Utilities.IWrappedCollection CreateCollectionWrapper(object list)
        {
            //
            // Disasemble & Code
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_21;
            //  | 
            var val_22;
            //  | 
            System.Type val_23;
            //  | 
            var val_24;
            //  | 
            Newtonsoft.Json.Utilities.CollectionWrapper<System.Object> val_25;
            //  | 
            System.Collections.IList val_26;
            //  | 
            string val_27;
            //  | 
            var val_28;
            //  | 
            var val_29;
            // 0x02901914: STP x26, x25, [sp, #-0x50]! | stack[1152921513965113552] = ???;  stack[1152921513965113560] = ???;  //  dest_result_addr=1152921513965113552 |  dest_result_addr=1152921513965113560
            // 0x02901918: STP x24, x23, [sp, #0x10]  | stack[1152921513965113568] = ???;  stack[1152921513965113576] = ???;  //  dest_result_addr=1152921513965113568 |  dest_result_addr=1152921513965113576
            // 0x0290191C: STP x22, x21, [sp, #0x20]  | stack[1152921513965113584] = ???;  stack[1152921513965113592] = ???;  //  dest_result_addr=1152921513965113584 |  dest_result_addr=1152921513965113592
            // 0x02901920: STP x20, x19, [sp, #0x30]  | stack[1152921513965113600] = ???;  stack[1152921513965113608] = ???;  //  dest_result_addr=1152921513965113600 |  dest_result_addr=1152921513965113608
            // 0x02901924: STP x29, x30, [sp, #0x40]  | stack[1152921513965113616] = ???;  stack[1152921513965113624] = ???;  //  dest_result_addr=1152921513965113616 |  dest_result_addr=1152921513965113624
            // 0x02901928: ADD x29, sp, #0x40         | X29 = (1152921513965113552 + 64) = 1152921513965113616 (0x100000022DCBD110);
            // 0x0290192C: SUB sp, sp, #0x10          | SP = (1152921513965113552 - 16) = 1152921513965113536 (0x100000022DCBD0C0);
            // 0x02901930: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x02901934: LDRB w8, [x19, #0xaf3]     | W8 = (bool)static_value_037B8AF3;       
            // 0x02901938: MOV x20, x1                | X20 = X1;//m1                           
            // 0x0290193C: TBNZ w8, #0, #0x2901958    | if (static_value_037B8AF3 == true) goto label_0;
            // 0x02901940: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
            // 0x02901944: LDR x8, [x8, #0xdb0]       | X8 = 0x2B915E8;                         
            // 0x02901948: LDR w0, [x8]               | W0 = 0x1C3E;                            
            // 0x0290194C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C3E, ????);     
            // 0x02901950: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02901954: STRB w8, [x19, #0xaf3]     | static_value_037B8AF3 = true;            //  dest_result_addr=58428147
            label_0:
            // 0x02901958: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x0290195C: LDR x8, [x8, #0xb90]       | X8 = 1152921504866803712;               
            // 0x02901960: LDR x0, [x8]               | X0 = typeof(CollectionUtils.<CreateCollectionWrapper>c__AnonStorey1);
            object val_1 = null;
            // 0x02901964: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CollectionUtils.<CreateCollectionWrapper>c__AnonStorey1), ????);
            // 0x02901968: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0290196C: MOV x19, x0                | X19 = 1152921504866803712 (0x100000000F7EA000);//ML01
            // 0x02901970: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x02901974: CBZ x19, #0x2901998        | if ( == 0) goto label_1;                
            if(null == 0)
            {
                goto label_1;
            }
            // 0x02901978: MOV x24, x19               | X24 = 1152921504866803712 (0x100000000F7EA000);//ML01
            val_21 = val_1;
            // 0x0290197C: STR x20, [x24, #0x18]!     | typeof(CollectionUtils.<CreateCollectionWrapper>c__AnonStorey1).__il2cppRuntimeField_18 = X1;  //  dest_result_addr=1152921504866803736
            typeof(CollectionUtils.<CreateCollectionWrapper>c__AnonStorey1).__il2cppRuntimeField_18 = X1;
            // 0x02901980: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x02901984: LDR x8, [x8, #0x958]       | X8 = (string**)(1152921511169504192)("list");
            // 0x02901988: MOV x1, x20                | X1 = X1;//m1                            
            // 0x0290198C: LDR x2, [x8]               | X2 = "list";                            
            // 0x02901990: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  val_1 = new System.Object(), parameterName:  X1);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  val_1, parameterName:  X1);
            // 0x02901994: B #0x29019c0               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x02901998: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x0290199C: ORR w24, wzr, #0x18        | W24 = 24(0x18);                         
            val_21 = 24;
            // 0x029019A0: STR x20, [x24]             | mem[24] = X1;                            //  dest_result_addr=24
            mem[24] = X1;
            // 0x029019A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x029019A8: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x029019AC: LDR x1, [x24]              | X1 = X1;                                
            // 0x029019B0: LDR x8, [x8, #0x958]       | X8 = (string**)(1152921511169504192)("list");
            // 0x029019B4: LDR x2, [x8]               | X2 = "list";                            
            // 0x029019B8: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  val_1, parameterName:  mem[24]);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  val_1, parameterName:  mem[24]);
            // 0x029019BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_2:
            // 0x029019C0: LDR x20, [x24]             | X20 = X1;                               
            // 0x029019C4: CBNZ x20, #0x29019cc       | if (X1 != 0) goto label_3;              
            if(val_21 != 0)
            {
                goto label_3;
            }
            // 0x029019C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_3:
            // 0x029019CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029019D0: MOV x0, x20                | X0 = X1;//m1                            
            // 0x029019D4: BL #0x16fb28c              | X0 = X1.GetType();                      
            System.Type val_2 = val_21.GetType();
            // 0x029019D8: ADRP x25, #0x3620000       | X25 = 56754176 (0x3620000);             
            // 0x029019DC: LDR x25, [x25, #0x340]     | X25 = 1152921504609562624;              
            // 0x029019E0: ADRP x9, #0x367b000        | X9 = 57126912 (0x367B000);              
            // 0x029019E4: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x029019E8: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x029019EC: LDR x9, [x9, #0x790]       | X9 = 1152921504609456128;               
            // 0x029019F0: LDR x21, [x9]              | X21 = typeof(System.Collections.Generic.ICollection<T>);
            // 0x029019F4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x029019F8: TBZ w9, #0, #0x2901a0c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x029019FC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02901A00: CBNZ w9, #0x2901a0c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x02901A04: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x02901A08: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_5:
            // 0x02901A0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02901A10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02901A14: MOV x1, x21                | X1 = 1152921504609456128 (0x100000000027D000);//ML01
            // 0x02901A18: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x02901A1C: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x02901A20: CBZ x19, #0x2901a44        | if ( == 0) goto label_6;                
            if(null == 0)
            {
                goto label_6;
            }
            // 0x02901A24: ADD x21, x19, #0x10        | X21 = (val_1 + 16) = val_22 (0x100000000F7EA010);
            val_22 = 1152921504866803728;
            // 0x02901A28: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x02901A2C: MOV x2, x22                | X2 = val_3;//m1                         
            System.Type val_4 = val_3;
            // 0x02901A30: MOV x3, x21                | X3 = 1152921504866803728 (0x100000000F7EA010);//ML01
            // 0x02901A34: BL #0x28fdaec              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle()), genericInterfaceDefinition:  val_2, implementingType: out  System.Type val_4 = val_3);
            bool val_5 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  val_3, genericInterfaceDefinition:  val_2, implementingType: out  val_4);
            // 0x02901A38: AND w8, w0, #1             | W8 = (val_5 & 1);                       
            bool val_6 = val_5;
            // 0x02901A3C: TBNZ w8, #0, #0x2901a68    | if ((val_5 & 1) == true) goto label_7;  
            if(val_6 == true)
            {
                goto label_7;
            }
            // 0x02901A40: B #0x2901c34               |  goto label_9;                          
            goto label_9;
            label_6:
            // 0x02901A44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            // 0x02901A48: ORR w3, wzr, #0x10         | W3 = 16(0x10);                          
            // 0x02901A4C: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x02901A50: MOV x2, x22                | X2 = val_3;//m1                         
            System.Type val_7 = val_3;
            // 0x02901A54: ORR w21, wzr, #0x10        | W21 = 16(0x10);                         
            val_22 = 16;
            // 0x02901A58: BL #0x28fdaec              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  val_3, genericInterfaceDefinition:  val_2, implementingType: out  System.Type val_7 = val_3);
            bool val_8 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  val_3, genericInterfaceDefinition:  val_2, implementingType: out  val_7);
            // 0x02901A5C: MOV w20, w0                | W20 = val_8;//m1                        
            // 0x02901A60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            // 0x02901A64: TBZ w20, #0, #0x2901c34    | if (val_8 == false) goto label_9;       
            if(val_8 == false)
            {
                goto label_9;
            }
            label_7:
            // 0x02901A68: LDR x1, [x21]              | X1 = 0x100B70003;                       
            // 0x02901A6C: BL #0x28fddb8              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.GetCollectionItemType(type:  bool val_8 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  val_3, genericInterfaceDefinition:  val_2, implementingType: out  val_7));
            System.Type val_9 = Newtonsoft.Json.Utilities.ReflectionUtils.GetCollectionItemType(type:  val_8);
            // 0x02901A70: ADRP x8, #0x3603000        | X8 = 56635392 (0x3603000);              
            // 0x02901A74: ADRP x9, #0x363e000        | X9 = 56877056 (0x363E000);              
            // 0x02901A78: LDR x8, [x8, #0x1c8]       | X8 = 1152921513965073824;               
            // 0x02901A7C: LDR x9, [x9, #0x210]       | X9 = 1152921504688156672;               
            // 0x02901A80: MOV x23, x0                | X23 = val_9;//m1                        
            // 0x02901A84: LDR x21, [x8]              | X21 = System.Object CollectionUtils.<CreateCollectionWrapper>c__AnonStorey1::<>m__0(System.Type t, System.Collections.Generic.IList<object> a);
            // 0x02901A88: LDR x8, [x9]               | X8 = typeof(System.Func<T1, T2, TResult>);
            // 0x02901A8C: MOV x0, x8                 | X0 = 1152921504688156672 (0x1000000004D8B000);//ML01
            System.Func<System.Type, System.Collections.Generic.IList<System.Object>, System.Object> val_10 = null;
            // 0x02901A90: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Func<T1, T2, TResult>), ????);
            // 0x02901A94: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x02901A98: LDR x8, [x8, #0xf00]       | X8 = 1152921513965074848;               
            // 0x02901A9C: MOV x1, x19                | X1 = 1152921504866803712 (0x100000000F7EA000);//ML01
            // 0x02901AA0: MOV x2, x21                | X2 = 1152921513965073824 (0x100000022DCB35A0);//ML01
            // 0x02901AA4: MOV x20, x0                | X20 = 1152921504688156672 (0x1000000004D8B000);//ML01
            // 0x02901AA8: LDR x3, [x8]               | X3 = public System.Void System.Func<System.Type, System.Collections.Generic.IList<System.Object>, System.Object>::.ctor(object object, IntPtr method);
            // 0x02901AAC: BL #0x21d5d94              | .ctor(object:  val_1, method:  System.Object CollectionUtils.<CreateCollectionWrapper>c__AnonStorey1::<>m__0(System.Type t, System.Collections.Generic.IList<object> a));
            val_10 = new System.Func<System.Type, System.Collections.Generic.IList<System.Object>, System.Object>(object:  val_1, method:  System.Object CollectionUtils.<CreateCollectionWrapper>c__AnonStorey1::<>m__0(System.Type t, System.Collections.Generic.IList<object> a));
            // 0x02901AB0: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x02901AB4: LDR x0, [x25]              | X0 = typeof(System.Type);               
            // 0x02901AB8: LDR x8, [x8, #0x970]       | X8 = 1152921504867016704;               
            // 0x02901ABC: LDR x21, [x8]              | X21 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>);
            // 0x02901AC0: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x02901AC4: TBZ w8, #0, #0x2901ad4     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x02901AC8: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02901ACC: CBNZ w8, #0x2901ad4        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x02901AD0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_11:
            // 0x02901AD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02901AD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02901ADC: MOV x1, x21                | X1 = 1152921504867016704 (0x100000000F81E000);//ML01
            // 0x02901AE0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_11 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x02901AE4: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x02901AE8: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x02901AEC: MOV x21, x0                | X21 = val_11;//m1                       
            // 0x02901AF0: LDR x22, [x8]              | X22 = typeof(System.Type[]);            
            // 0x02901AF4: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x02901AF8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x02901AFC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x02901B00: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x02901B04: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x02901B08: MOV x22, x0                | X22 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x02901B0C: CBNZ x22, #0x2901b14       | if ( != null) goto label_12;            
            if(null != null)
            {
                goto label_12;
            }
            // 0x02901B10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_12:
            // 0x02901B14: CBZ x23, #0x2901b38        | if (val_9 == null) goto label_14;       
            if(val_9 == null)
            {
                goto label_14;
            }
            // 0x02901B18: LDR x8, [x22]              | X8 = ;                                  
            // 0x02901B1C: MOV x0, x23                | X0 = val_9;//m1                         
            // 0x02901B20: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x02901B24: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x02901B28: CBNZ x0, #0x2901b38        | if (val_9 != null) goto label_14;       
            if(val_9 != null)
            {
                goto label_14;
            }
            // 0x02901B2C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_9, ????);      
            // 0x02901B30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02901B34: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_14:
            // 0x02901B38: LDR w8, [x22, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x02901B3C: CBNZ w8, #0x2901b4c        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_15;
            // 0x02901B40: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_9, ????);      
            // 0x02901B44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02901B48: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_15:
            // 0x02901B4C: STR x23, [x22, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_9;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_9;
            // 0x02901B50: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x02901B54: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x02901B58: LDR x23, [x8]              | X23 = typeof(System.Object[]);          
            // 0x02901B5C: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02901B60: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x02901B64: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x02901B68: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            val_23 = null;
            // 0x02901B6C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x02901B70: MOV x23, x0                | X23 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02901B74: CBNZ x19, #0x2901b7c       | if ( != 0) goto label_16;               
            if(null != 0)
            {
                goto label_16;
            }
            // 0x02901B78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_16:
            // 0x02901B7C: LDR x19, [x24]             | X19 = X1;                               
            // 0x02901B80: CBNZ x23, #0x2901b88       | if ( != null) goto label_17;            
            if(null != null)
            {
                goto label_17;
            }
            // 0x02901B84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_17:
            // 0x02901B88: CBZ x19, #0x2901bac        | if (X1 == 0) goto label_19;             
            if(mem[24] == 0)
            {
                goto label_19;
            }
            // 0x02901B8C: LDR x8, [x23]              | X8 = ;                                  
            // 0x02901B90: MOV x0, x19                | X0 = X1;//m1                            
            val_23 = mem[24];
            // 0x02901B94: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x02901B98: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X1, ????);         
            // 0x02901B9C: CBNZ x0, #0x2901bac        | if (X1 != 0) goto label_19;             
            if(val_23 != 0)
            {
                goto label_19;
            }
            // 0x02901BA0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? X1, ????);         
            // 0x02901BA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02901BA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
            label_19:
            // 0x02901BAC: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x02901BB0: CBNZ w8, #0x2901bc0        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_20;
            // 0x02901BB4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1, ????);         
            // 0x02901BB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02901BBC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
            label_20:
            // 0x02901BC0: MOV x1, x21                | X1 = val_11;//m1                        
            // 0x02901BC4: MOV x2, x22                | X2 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x02901BC8: MOV x3, x20                | X3 = 1152921504688156672 (0x1000000004D8B000);//ML01
            // 0x02901BCC: MOV x4, x23                | X4 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02901BD0: STR x19, [x23, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = X1;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = mem[24];
            // 0x02901BD4: BL #0x29125a8              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.CreateGeneric(genericTypeDefinition:  val_23 = mem[24], innerTypes:  val_11, instanceCreator:  null, args:  val_10);
            object val_12 = Newtonsoft.Json.Utilities.ReflectionUtils.CreateGeneric(genericTypeDefinition:  val_23, innerTypes:  val_11, instanceCreator:  null, args:  val_10);
            // 0x02901BD8: MOV x21, x0                | X21 = val_12;//m1                       
            val_24 = val_12;
            // 0x02901BDC: CBZ x21, #0x2901c2c        | if (val_12 == null) goto label_21;      
            if(val_24 == null)
            {
                goto label_21;
            }
            // 0x02901BE0: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
            // 0x02901BE4: LDR x8, [x8, #0xe78]       | X8 = 1152921504866963456;               
            // 0x02901BE8: MOV x0, x21                | X0 = val_12;//m1                        
            // 0x02901BEC: LDR x20, [x8]              | X20 = typeof(Newtonsoft.Json.Utilities.IWrappedCollection);
            // 0x02901BF0: MOV x1, x20                | X1 = 1152921504866963456 (0x100000000F811000);//ML01
            // 0x02901BF4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_12, ????);     
            // 0x02901BF8: MOV x19, x0                | X19 = val_12;//m1                       
            val_25 = val_24;
            // 0x02901BFC: CBNZ x19, #0x2901ccc       | if (val_12 != null) goto label_23;      
            if(val_25 != null)
            {
                goto label_23;
            }
            // 0x02901C00: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x02901C04: MOV x1, x20                | X1 = 1152921504866963456 (0x100000000F811000);//ML01
            // 0x02901C08: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x02901C0C: MOV x8, sp                 | X8 = 1152921513965113536 (0x100000022DCBD0C0);//ML01
            // 0x02901C10: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x02901C14: LDR x0, [sp]               | X0 = val_13;                             //  find_add[1152921513965101632]
            // 0x02901C18: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x02901C1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02901C20: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x02901C24: MOV x0, sp                 | X0 = 1152921513965113536 (0x100000022DCBD0C0);//ML01
            // 0x02901C28: BL #0x299a140              | 
            label_21:
            // 0x02901C2C: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_25 = 0;
            // 0x02901C30: B #0x2901ccc               |  goto label_23;                         
            goto label_23;
            label_9:
            // 0x02901C34: ADRP x21, #0x3605000       | X21 = 56643584 (0x3605000);             
            // 0x02901C38: LDR x0, [x24]              | X0 = X1;                                
            // 0x02901C3C: LDR x21, [x21, #0x308]     | X21 = 1152921504609349632;              
            val_24 = 1152921504609349632;
            // 0x02901C40: LDR x1, [x21]              | X1 = typeof(System.Collections.IList);  
            // 0x02901C44: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X1, ????);         
            // 0x02901C48: CBZ x0, #0x2901cec         | if (X1 == 0) goto label_24;             
            if(mem[24] == 0)
            {
                goto label_24;
            }
            // 0x02901C4C: CBNZ x19, #0x2901c54       | if ( != 0) goto label_25;               
            if(null != 0)
            {
                goto label_25;
            }
            // 0x02901C50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_25:
            // 0x02901C54: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
            // 0x02901C58: LDR x20, [x24]             | X20 = X1;                               
            // 0x02901C5C: LDR x8, [x8, #0x840]       | X8 = 1152921504867016704;               
            // 0x02901C60: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>);
            // 0x02901C64: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>), ????);
            // 0x02901C68: MOV x19, x0                | X19 = 1152921504867016704 (0x100000000F81E000);//ML01
            val_25 = null;
            // 0x02901C6C: CBZ x20, #0x2901cb4        | if (X1 == 0) goto label_26;             
            if(mem[24] == 0)
            {
                goto label_26;
            }
            // 0x02901C70: LDR x21, [x21]             | X21 = typeof(System.Collections.IList); 
            val_24 = null;
            // 0x02901C74: MOV x0, x20                | X0 = X1;//m1                            
            // 0x02901C78: MOV x1, x21                | X1 = 1152921504609349632 (0x1000000000263000);//ML01
            // 0x02901C7C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X1, ????);         
            // 0x02901C80: MOV x1, x0                 | X1 = X1;//m1                            
            val_26 = mem[24];
            // 0x02901C84: CBNZ x1, #0x2901cb8        | if (X1 != 0) goto label_27;             
            if(val_26 != 0)
            {
                goto label_27;
            }
            // 0x02901C88: LDR x8, [x20]              | X8 = X1;                                
            // 0x02901C8C: MOV x1, x21                | X1 = 1152921504609349632 (0x1000000000263000);//ML01
            // 0x02901C90: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x02901C94: ADD x8, sp, #8             | X8 = (1152921513965113536 + 8) = 1152921513965113544 (0x100000022DCBD0C8);
            // 0x02901C98: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x02901C9C: LDR x0, [sp, #8]           | X0 = val_14;                             //  find_add[1152921513965101632]
            // 0x02901CA0: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x02901CA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02901CA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x02901CAC: ADD x0, sp, #8             | X0 = (1152921513965113536 + 8) = 1152921513965113544 (0x100000022DCBD0C8);
            // 0x02901CB0: BL #0x299a140              | 
            label_26:
            // 0x02901CB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_26 = 0;
            label_27:
            // 0x02901CB8: ADRP x8, #0x3678000        | X8 = 57114624 (0x3678000);              
            // 0x02901CBC: LDR x8, [x8, #0xb0]        | X8 = 1152921513919963056;               
            // 0x02901CC0: MOV x0, x19                | X0 = 1152921504867016704 (0x100000000F81E000);//ML01
            Newtonsoft.Json.Utilities.CollectionWrapper<System.Object> val_15 = val_25;
            // 0x02901CC4: LDR x2, [x8]               | X2 = public System.Void Newtonsoft.Json.Utilities.CollectionWrapper<System.Object>::.ctor(System.Collections.IList list);
            // 0x02901CC8: BL #0x19e88b4              | .ctor(list:  val_26 = 0);               
            val_15 = new Newtonsoft.Json.Utilities.CollectionWrapper<System.Object>(list:  val_26);
            label_23:
            // 0x02901CCC: MOV x0, x19                | X0 = 1152921504867016704 (0x100000000F81E000);//ML01
            // 0x02901CD0: SUB sp, x29, #0x40         | SP = (1152921513965113616 - 64) = 1152921513965113552 (0x100000022DCBD0D0);
            // 0x02901CD4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x02901CD8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x02901CDC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x02901CE0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x02901CE4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x02901CE8: RET                        |  return (Newtonsoft.Json.Utilities.IWrappedCollection)typeof(Newtonsoft.Json.Utilities.CollectionWrapper<T>);
            return (Newtonsoft.Json.Utilities.IWrappedCollection)val_25;
            //  |  // // {name=val_0, type=Newtonsoft.Json.Utilities.IWrappedCollection, size=8, nGRN=0 }
            label_24:
            // 0x02901CEC: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x02901CF0: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x02901CF4: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x02901CF8: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x02901CFC: TBZ w8, #0, #0x2901d0c     | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_29;
            // 0x02901D00: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x02901D04: CBNZ w8, #0x2901d0c        | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_29;
            // 0x02901D08: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_29:
            // 0x02901D0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02901D10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02901D14: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_16 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x02901D18: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x02901D1C: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x02901D20: MOV x20, x0                | X20 = val_16;//m1                       
            // 0x02901D24: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
            // 0x02901D28: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02901D2C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x02901D30: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x02901D34: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02901D38: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x02901D3C: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02901D40: CBNZ x19, #0x2901d48       | if ( != 0) goto label_30;               
            if(null != 0)
            {
                goto label_30;
            }
            // 0x02901D44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_30:
            // 0x02901D48: LDR x19, [x24]             | X19 = X1;                               
            // 0x02901D4C: CBNZ x19, #0x2901d54       | if (X1 != 0) goto label_31;             
            if(mem[24] != 0)
            {
                goto label_31;
            }
            // 0x02901D50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_31:
            // 0x02901D54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02901D58: MOV x0, x19                | X0 = X1;//m1                            
            // 0x02901D5C: BL #0x16fb28c              | X0 = X1.GetType();                      
            System.Type val_17 = mem[24].GetType();
            // 0x02901D60: MOV x19, x0                | X19 = val_17;//m1                       
            // 0x02901D64: CBNZ x21, #0x2901d6c       | if ( != null) goto label_32;            
            if(null != null)
            {
                goto label_32;
            }
            // 0x02901D68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_32:
            // 0x02901D6C: CBZ x19, #0x2901d90        | if (val_17 == null) goto label_34;      
            if(val_17 == null)
            {
                goto label_34;
            }
            // 0x02901D70: LDR x8, [x21]              | X8 = ;                                  
            // 0x02901D74: MOV x0, x19                | X0 = val_17;//m1                        
            val_27 = val_17;
            // 0x02901D78: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x02901D7C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_17, ????);     
            // 0x02901D80: CBNZ x0, #0x2901d90        | if (val_17 != null) goto label_34;      
            if(val_27 != null)
            {
                goto label_34;
            }
            // 0x02901D84: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_17, ????);     
            // 0x02901D88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02901D8C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            label_34:
            // 0x02901D90: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x02901D94: CBNZ w8, #0x2901da4        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_35;
            // 0x02901D98: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_17, ????);     
            // 0x02901D9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02901DA0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            label_35:
            // 0x02901DA4: STR x19, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_17;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = val_17;
            // 0x02901DA8: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
            // 0x02901DAC: LDR x8, [x8, #0xf90]       | X8 = (string**)(1152921513965092256)("Can not create ListWrapper for type {0}.");
            // 0x02901DB0: MOV x2, x20                | X2 = val_16;//m1                        
            // 0x02901DB4: MOV x3, x21                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02901DB8: LDR x1, [x8]               | X1 = "Can not create ListWrapper for type {0}.";
            // 0x02901DBC: BL #0x2900ac4              | X0 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  val_27 = val_17, provider:  "Can not create ListWrapper for type {0}.", args:  val_16);
            string val_18 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  val_27, provider:  "Can not create ListWrapper for type {0}.", args:  val_16);
            // 0x02901DC0: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x02901DC4: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x02901DC8: MOV x19, x0                | X19 = val_18;//m1                       
            // 0x02901DCC: LDR x8, [x8]               | X8 = typeof(System.Exception);          
            // 0x02901DD0: MOV x0, x8                 | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_19 = null;
            // 0x02901DD4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x02901DD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02901DDC: MOV x1, x19                | X1 = val_18;//m1                        
            // 0x02901DE0: MOV x20, x0                | X20 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x02901DE4: BL #0x1c32b48              | .ctor(message:  val_18);                
            val_19 = new System.Exception(message:  val_18);
            // 0x02901DE8: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
            // 0x02901DEC: LDR x8, [x8, #0x6c0]       | X8 = 1152921513965096512;               
            // 0x02901DF0: MOV x0, x20                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x02901DF4: LDR x1, [x8]               | X1 = public static Newtonsoft.Json.Utilities.IWrappedCollection Newtonsoft.Json.Utilities.CollectionUtils::CreateCollectionWrapper(object list);
            // 0x02901DF8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x02901DFC: BL #0x28fffbc              | X0 = Convert(value:  public static Newtonsoft.Json.Utilities.IWrappedCollection Newtonsoft.Json.Utilities.CollectionUtils::CreateCollectionWrapper(object list), typeCode:  0);
            object val_20 = Convert(value:  public static Newtonsoft.Json.Utilities.IWrappedCollection Newtonsoft.Json.Utilities.CollectionUtils::CreateCollectionWrapper(object list), typeCode:  0);
            // 0x02901E00: MOV x19, x0                | X19 = val_20;//m1                       
            val_28 = val_20;
            // 0x02901E04: MOV x0, sp                 | X0 = 1152921513965113536 (0x100000022DCBD0C0);//ML01
            val_29;
            // 0x02901E08: B #0x2901e14               |  goto label_36;                         
            goto label_36;
            // 0x02901E0C: MOV x19, x0                | X19 = 1152921513965113536 (0x100000022DCBD0C0);//ML01
            val_28 = val_29;
            // 0x02901E10: ADD x0, sp, #8             | X0 = (1152921513965113536 + 8) = 1152921513965113544 (0x100000022DCBD0C8);
            label_36:
            // 0x02901E14: BL #0x299a140              | 
            // 0x02901E18: MOV x0, x19                | X0 = 1152921513965113536 (0x100000022DCBD0C0);//ML01
            // 0x02901E1C: BL #0x980800               | X0 = sub_980800( ?? 0x100000022DCBD0C0, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x02912698 (43067032), len: 1292  VirtAddr: 0x02912698 RVA: 0x02912698 token: 100686571 methodIndex: 49124 delegateWrapperIndex: 0 methodInvoker: 0
        public static Newtonsoft.Json.Utilities.IWrappedList CreateListWrapper(object list)
        {
            //
            // Disasemble & Code
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_21;
            //  | 
            var val_22;
            //  | 
            System.Type val_23;
            //  | 
            var val_24;
            //  | 
            Newtonsoft.Json.Utilities.ListWrapper<System.Object> val_25;
            //  | 
            System.Collections.IList val_26;
            //  | 
            string val_27;
            //  | 
            var val_28;
            //  | 
            var val_29;
            // 0x02912698: STP x26, x25, [sp, #-0x50]! | stack[1152921513965309520] = ???;  stack[1152921513965309528] = ???;  //  dest_result_addr=1152921513965309520 |  dest_result_addr=1152921513965309528
            // 0x0291269C: STP x24, x23, [sp, #0x10]  | stack[1152921513965309536] = ???;  stack[1152921513965309544] = ???;  //  dest_result_addr=1152921513965309536 |  dest_result_addr=1152921513965309544
            // 0x029126A0: STP x22, x21, [sp, #0x20]  | stack[1152921513965309552] = ???;  stack[1152921513965309560] = ???;  //  dest_result_addr=1152921513965309552 |  dest_result_addr=1152921513965309560
            // 0x029126A4: STP x20, x19, [sp, #0x30]  | stack[1152921513965309568] = ???;  stack[1152921513965309576] = ???;  //  dest_result_addr=1152921513965309568 |  dest_result_addr=1152921513965309576
            // 0x029126A8: STP x29, x30, [sp, #0x40]  | stack[1152921513965309584] = ???;  stack[1152921513965309592] = ???;  //  dest_result_addr=1152921513965309584 |  dest_result_addr=1152921513965309592
            // 0x029126AC: ADD x29, sp, #0x40         | X29 = (1152921513965309520 + 64) = 1152921513965309584 (0x100000022DCECE90);
            // 0x029126B0: SUB sp, sp, #0x10          | SP = (1152921513965309520 - 16) = 1152921513965309504 (0x100000022DCECE40);
            // 0x029126B4: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x029126B8: LDRB w8, [x19, #0xaf4]     | W8 = (bool)static_value_037B8AF4;       
            // 0x029126BC: MOV x20, x1                | X20 = X1;//m1                           
            // 0x029126C0: TBNZ w8, #0, #0x29126dc    | if (static_value_037B8AF4 == true) goto label_0;
            // 0x029126C4: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
            // 0x029126C8: LDR x8, [x8, #0xc00]       | X8 = 0x2B915FC;                         
            // 0x029126CC: LDR w0, [x8]               | W0 = 0x1C43;                            
            // 0x029126D0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C43, ????);     
            // 0x029126D4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x029126D8: STRB w8, [x19, #0xaf4]     | static_value_037B8AF4 = true;            //  dest_result_addr=58428148
            label_0:
            // 0x029126DC: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x029126E0: LDR x8, [x8, #0x268]       | X8 = 1152921504866856960;               
            // 0x029126E4: LDR x0, [x8]               | X0 = typeof(CollectionUtils.<CreateListWrapper>c__AnonStorey2);
            object val_1 = null;
            // 0x029126E8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CollectionUtils.<CreateListWrapper>c__AnonStorey2), ????);
            // 0x029126EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029126F0: MOV x19, x0                | X19 = 1152921504866856960 (0x100000000F7F7000);//ML01
            // 0x029126F4: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x029126F8: CBZ x19, #0x291271c        | if ( == 0) goto label_1;                
            if(null == 0)
            {
                goto label_1;
            }
            // 0x029126FC: MOV x24, x19               | X24 = 1152921504866856960 (0x100000000F7F7000);//ML01
            val_21 = val_1;
            // 0x02912700: STR x20, [x24, #0x18]!     | typeof(CollectionUtils.<CreateListWrapper>c__AnonStorey2).__il2cppRuntimeField_18 = X1;  //  dest_result_addr=1152921504866856984
            typeof(CollectionUtils.<CreateListWrapper>c__AnonStorey2).__il2cppRuntimeField_18 = X1;
            // 0x02912704: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x02912708: LDR x8, [x8, #0x958]       | X8 = (string**)(1152921511169504192)("list");
            // 0x0291270C: MOV x1, x20                | X1 = X1;//m1                            
            // 0x02912710: LDR x2, [x8]               | X2 = "list";                            
            // 0x02912714: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  val_1 = new System.Object(), parameterName:  X1);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  val_1, parameterName:  X1);
            // 0x02912718: B #0x2912744               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x0291271C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x02912720: ORR w24, wzr, #0x18        | W24 = 24(0x18);                         
            val_21 = 24;
            // 0x02912724: STR x20, [x24]             | mem[24] = X1;                            //  dest_result_addr=24
            mem[24] = X1;
            // 0x02912728: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x0291272C: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x02912730: LDR x1, [x24]              | X1 = X1;                                
            // 0x02912734: LDR x8, [x8, #0x958]       | X8 = (string**)(1152921511169504192)("list");
            // 0x02912738: LDR x2, [x8]               | X2 = "list";                            
            // 0x0291273C: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  val_1, parameterName:  mem[24]);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  val_1, parameterName:  mem[24]);
            // 0x02912740: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_2:
            // 0x02912744: LDR x20, [x24]             | X20 = X1;                               
            // 0x02912748: CBNZ x20, #0x2912750       | if (X1 != 0) goto label_3;              
            if(val_21 != 0)
            {
                goto label_3;
            }
            // 0x0291274C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_3:
            // 0x02912750: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02912754: MOV x0, x20                | X0 = X1;//m1                            
            // 0x02912758: BL #0x16fb28c              | X0 = X1.GetType();                      
            System.Type val_2 = val_21.GetType();
            // 0x0291275C: ADRP x25, #0x3620000       | X25 = 56754176 (0x3620000);             
            // 0x02912760: LDR x25, [x25, #0x340]     | X25 = 1152921504609562624;              
            // 0x02912764: ADRP x9, #0x35f2000        | X9 = 56565760 (0x35F2000);              
            // 0x02912768: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x0291276C: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x02912770: LDR x9, [x9, #0xe48]       | X9 = 1152921504609402880;               
            // 0x02912774: LDR x21, [x9]              | X21 = typeof(System.Collections.Generic.IList<T>);
            // 0x02912778: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0291277C: TBZ w9, #0, #0x2912790     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x02912780: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02912784: CBNZ w9, #0x2912790        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x02912788: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0291278C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_5:
            // 0x02912790: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02912794: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02912798: MOV x1, x21                | X1 = 1152921504609402880 (0x1000000000270000);//ML01
            // 0x0291279C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x029127A0: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x029127A4: CBZ x19, #0x29127c8        | if ( == 0) goto label_6;                
            if(null == 0)
            {
                goto label_6;
            }
            // 0x029127A8: ADD x21, x19, #0x10        | X21 = (val_1 + 16) = val_22 (0x100000000F7F7010);
            val_22 = 1152921504866856976;
            // 0x029127AC: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x029127B0: MOV x2, x22                | X2 = val_3;//m1                         
            System.Type val_4 = val_3;
            // 0x029127B4: MOV x3, x21                | X3 = 1152921504866856976 (0x100000000F7F7010);//ML01
            // 0x029127B8: BL #0x28fdaec              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle()), genericInterfaceDefinition:  val_2, implementingType: out  System.Type val_4 = val_3);
            bool val_5 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  val_3, genericInterfaceDefinition:  val_2, implementingType: out  val_4);
            // 0x029127BC: AND w8, w0, #1             | W8 = (val_5 & 1);                       
            bool val_6 = val_5;
            // 0x029127C0: TBNZ w8, #0, #0x29127ec    | if ((val_5 & 1) == true) goto label_7;  
            if(val_6 == true)
            {
                goto label_7;
            }
            // 0x029127C4: B #0x29129b8               |  goto label_9;                          
            goto label_9;
            label_6:
            // 0x029127C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            // 0x029127CC: ORR w3, wzr, #0x10         | W3 = 16(0x10);                          
            // 0x029127D0: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x029127D4: MOV x2, x22                | X2 = val_3;//m1                         
            System.Type val_7 = val_3;
            // 0x029127D8: ORR w21, wzr, #0x10        | W21 = 16(0x10);                         
            val_22 = 16;
            // 0x029127DC: BL #0x28fdaec              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  val_3, genericInterfaceDefinition:  val_2, implementingType: out  System.Type val_7 = val_3);
            bool val_8 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  val_3, genericInterfaceDefinition:  val_2, implementingType: out  val_7);
            // 0x029127E0: MOV w20, w0                | W20 = val_8;//m1                        
            // 0x029127E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            // 0x029127E8: TBZ w20, #0, #0x29129b8    | if (val_8 == false) goto label_9;       
            if(val_8 == false)
            {
                goto label_9;
            }
            label_7:
            // 0x029127EC: LDR x1, [x21]              | X1 = 0x100B70003;                       
            // 0x029127F0: BL #0x28fddb8              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.GetCollectionItemType(type:  bool val_8 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  val_3, genericInterfaceDefinition:  val_2, implementingType: out  val_7));
            System.Type val_9 = Newtonsoft.Json.Utilities.ReflectionUtils.GetCollectionItemType(type:  val_8);
            // 0x029127F4: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x029127F8: ADRP x9, #0x363e000        | X9 = 56877056 (0x363E000);              
            // 0x029127FC: LDR x8, [x8, #0x910]       | X8 = 1152921513965270976;               
            // 0x02912800: LDR x9, [x9, #0x210]       | X9 = 1152921504688156672;               
            // 0x02912804: MOV x23, x0                | X23 = val_9;//m1                        
            // 0x02912808: LDR x21, [x8]              | X21 = System.Object CollectionUtils.<CreateListWrapper>c__AnonStorey2::<>m__0(System.Type t, System.Collections.Generic.IList<object> a);
            // 0x0291280C: LDR x8, [x9]               | X8 = typeof(System.Func<T1, T2, TResult>);
            // 0x02912810: MOV x0, x8                 | X0 = 1152921504688156672 (0x1000000004D8B000);//ML01
            System.Func<System.Type, System.Collections.Generic.IList<System.Object>, System.Object> val_10 = null;
            // 0x02912814: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Func<T1, T2, TResult>), ????);
            // 0x02912818: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x0291281C: LDR x8, [x8, #0xf00]       | X8 = 1152921513965074848;               
            // 0x02912820: MOV x1, x19                | X1 = 1152921504866856960 (0x100000000F7F7000);//ML01
            // 0x02912824: MOV x2, x21                | X2 = 1152921513965270976 (0x100000022DCE37C0);//ML01
            // 0x02912828: MOV x20, x0                | X20 = 1152921504688156672 (0x1000000004D8B000);//ML01
            // 0x0291282C: LDR x3, [x8]               | X3 = public System.Void System.Func<System.Type, System.Collections.Generic.IList<System.Object>, System.Object>::.ctor(object object, IntPtr method);
            // 0x02912830: BL #0x21d5d94              | .ctor(object:  val_1, method:  System.Object CollectionUtils.<CreateListWrapper>c__AnonStorey2::<>m__0(System.Type t, System.Collections.Generic.IList<object> a));
            val_10 = new System.Func<System.Type, System.Collections.Generic.IList<System.Object>, System.Object>(object:  val_1, method:  System.Object CollectionUtils.<CreateListWrapper>c__AnonStorey2::<>m__0(System.Type t, System.Collections.Generic.IList<object> a));
            // 0x02912834: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
            // 0x02912838: LDR x0, [x25]              | X0 = typeof(System.Type);               
            // 0x0291283C: LDR x8, [x8, #0x170]       | X8 = 1152921504868827136;               
            // 0x02912840: LDR x21, [x8]              | X21 = typeof(Newtonsoft.Json.Utilities.ListWrapper<T>);
            // 0x02912844: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x02912848: TBZ w8, #0, #0x2912858     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x0291284C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02912850: CBNZ w8, #0x2912858        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x02912854: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_11:
            // 0x02912858: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0291285C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02912860: MOV x1, x21                | X1 = 1152921504868827136 (0x100000000F9D8000);//ML01
            // 0x02912864: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_11 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x02912868: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x0291286C: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x02912870: MOV x21, x0                | X21 = val_11;//m1                       
            // 0x02912874: LDR x22, [x8]              | X22 = typeof(System.Type[]);            
            // 0x02912878: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0291287C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x02912880: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x02912884: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x02912888: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0291288C: MOV x22, x0                | X22 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x02912890: CBNZ x22, #0x2912898       | if ( != null) goto label_12;            
            if(null != null)
            {
                goto label_12;
            }
            // 0x02912894: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_12:
            // 0x02912898: CBZ x23, #0x29128bc        | if (val_9 == null) goto label_14;       
            if(val_9 == null)
            {
                goto label_14;
            }
            // 0x0291289C: LDR x8, [x22]              | X8 = ;                                  
            // 0x029128A0: MOV x0, x23                | X0 = val_9;//m1                         
            // 0x029128A4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x029128A8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x029128AC: CBNZ x0, #0x29128bc        | if (val_9 != null) goto label_14;       
            if(val_9 != null)
            {
                goto label_14;
            }
            // 0x029128B0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_9, ????);      
            // 0x029128B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029128B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_14:
            // 0x029128BC: LDR w8, [x22, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x029128C0: CBNZ w8, #0x29128d0        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_15;
            // 0x029128C4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_9, ????);      
            // 0x029128C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029128CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_15:
            // 0x029128D0: STR x23, [x22, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_9;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_9;
            // 0x029128D4: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x029128D8: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x029128DC: LDR x23, [x8]              | X23 = typeof(System.Object[]);          
            // 0x029128E0: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x029128E4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x029128E8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x029128EC: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            val_23 = null;
            // 0x029128F0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x029128F4: MOV x23, x0                | X23 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x029128F8: CBNZ x19, #0x2912900       | if ( != 0) goto label_16;               
            if(null != 0)
            {
                goto label_16;
            }
            // 0x029128FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_16:
            // 0x02912900: LDR x19, [x24]             | X19 = X1;                               
            // 0x02912904: CBNZ x23, #0x291290c       | if ( != null) goto label_17;            
            if(null != null)
            {
                goto label_17;
            }
            // 0x02912908: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_17:
            // 0x0291290C: CBZ x19, #0x2912930        | if (X1 == 0) goto label_19;             
            if(mem[24] == 0)
            {
                goto label_19;
            }
            // 0x02912910: LDR x8, [x23]              | X8 = ;                                  
            // 0x02912914: MOV x0, x19                | X0 = X1;//m1                            
            val_23 = mem[24];
            // 0x02912918: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0291291C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X1, ????);         
            // 0x02912920: CBNZ x0, #0x2912930        | if (X1 != 0) goto label_19;             
            if(val_23 != 0)
            {
                goto label_19;
            }
            // 0x02912924: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? X1, ????);         
            // 0x02912928: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0291292C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
            label_19:
            // 0x02912930: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x02912934: CBNZ w8, #0x2912944        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_20;
            // 0x02912938: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1, ????);         
            // 0x0291293C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02912940: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
            label_20:
            // 0x02912944: MOV x1, x21                | X1 = val_11;//m1                        
            // 0x02912948: MOV x2, x22                | X2 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0291294C: MOV x3, x20                | X3 = 1152921504688156672 (0x1000000004D8B000);//ML01
            // 0x02912950: MOV x4, x23                | X4 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02912954: STR x19, [x23, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = X1;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = mem[24];
            // 0x02912958: BL #0x29125a8              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.CreateGeneric(genericTypeDefinition:  val_23 = mem[24], innerTypes:  val_11, instanceCreator:  null, args:  val_10);
            object val_12 = Newtonsoft.Json.Utilities.ReflectionUtils.CreateGeneric(genericTypeDefinition:  val_23, innerTypes:  val_11, instanceCreator:  null, args:  val_10);
            // 0x0291295C: MOV x21, x0                | X21 = val_12;//m1                       
            val_24 = val_12;
            // 0x02912960: CBZ x21, #0x29129b0        | if (val_12 == null) goto label_21;      
            if(val_24 == null)
            {
                goto label_21;
            }
            // 0x02912964: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
            // 0x02912968: LDR x8, [x8, #0xa10]       | X8 = 1152921504868773888;               
            // 0x0291296C: MOV x0, x21                | X0 = val_12;//m1                        
            // 0x02912970: LDR x20, [x8]              | X20 = typeof(Newtonsoft.Json.Utilities.IWrappedList);
            // 0x02912974: MOV x1, x20                | X1 = 1152921504868773888 (0x100000000F9CB000);//ML01
            // 0x02912978: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_12, ????);     
            // 0x0291297C: MOV x19, x0                | X19 = val_12;//m1                       
            val_25 = val_24;
            // 0x02912980: CBNZ x19, #0x2912a50       | if (val_12 != null) goto label_23;      
            if(val_25 != null)
            {
                goto label_23;
            }
            // 0x02912984: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x02912988: MOV x1, x20                | X1 = 1152921504868773888 (0x100000000F9CB000);//ML01
            // 0x0291298C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x02912990: MOV x8, sp                 | X8 = 1152921513965309504 (0x100000022DCECE40);//ML01
            // 0x02912994: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x02912998: LDR x0, [sp]               | X0 = val_13;                             //  find_add[1152921513965297600]
            // 0x0291299C: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x029129A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029129A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x029129A8: MOV x0, sp                 | X0 = 1152921513965309504 (0x100000022DCECE40);//ML01
            // 0x029129AC: BL #0x299a140              | 
            label_21:
            // 0x029129B0: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_25 = 0;
            // 0x029129B4: B #0x2912a50               |  goto label_23;                         
            goto label_23;
            label_9:
            // 0x029129B8: ADRP x21, #0x3605000       | X21 = 56643584 (0x3605000);             
            // 0x029129BC: LDR x0, [x24]              | X0 = X1;                                
            // 0x029129C0: LDR x21, [x21, #0x308]     | X21 = 1152921504609349632;              
            val_24 = 1152921504609349632;
            // 0x029129C4: LDR x1, [x21]              | X1 = typeof(System.Collections.IList);  
            // 0x029129C8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X1, ????);         
            // 0x029129CC: CBZ x0, #0x2912a70         | if (X1 == 0) goto label_24;             
            if(mem[24] == 0)
            {
                goto label_24;
            }
            // 0x029129D0: CBNZ x19, #0x29129d8       | if ( != 0) goto label_25;               
            if(null != 0)
            {
                goto label_25;
            }
            // 0x029129D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_25:
            // 0x029129D8: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
            // 0x029129DC: LDR x20, [x24]             | X20 = X1;                               
            // 0x029129E0: LDR x8, [x8, #0x880]       | X8 = 1152921504868827136;               
            // 0x029129E4: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Utilities.ListWrapper<T>);
            // 0x029129E8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Utilities.ListWrapper<T>), ????);
            // 0x029129EC: MOV x19, x0                | X19 = 1152921504868827136 (0x100000000F9D8000);//ML01
            val_25 = null;
            // 0x029129F0: CBZ x20, #0x2912a38        | if (X1 == 0) goto label_26;             
            if(mem[24] == 0)
            {
                goto label_26;
            }
            // 0x029129F4: LDR x21, [x21]             | X21 = typeof(System.Collections.IList); 
            val_24 = null;
            // 0x029129F8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x029129FC: MOV x1, x21                | X1 = 1152921504609349632 (0x1000000000263000);//ML01
            // 0x02912A00: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X1, ????);         
            // 0x02912A04: MOV x1, x0                 | X1 = X1;//m1                            
            val_26 = mem[24];
            // 0x02912A08: CBNZ x1, #0x2912a3c        | if (X1 != 0) goto label_27;             
            if(val_26 != 0)
            {
                goto label_27;
            }
            // 0x02912A0C: LDR x8, [x20]              | X8 = X1;                                
            // 0x02912A10: MOV x1, x21                | X1 = 1152921504609349632 (0x1000000000263000);//ML01
            // 0x02912A14: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x02912A18: ADD x8, sp, #8             | X8 = (1152921513965309504 + 8) = 1152921513965309512 (0x100000022DCECE48);
            // 0x02912A1C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x02912A20: LDR x0, [sp, #8]           | X0 = val_14;                             //  find_add[1152921513965297600]
            // 0x02912A24: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x02912A28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02912A2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x02912A30: ADD x0, sp, #8             | X0 = (1152921513965309504 + 8) = 1152921513965309512 (0x100000022DCECE48);
            // 0x02912A34: BL #0x299a140              | 
            label_26:
            // 0x02912A38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_26 = 0;
            label_27:
            // 0x02912A3C: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x02912A40: LDR x8, [x8, #0x758]       | X8 = 1152921513962868960;               
            // 0x02912A44: MOV x0, x19                | X0 = 1152921504868827136 (0x100000000F9D8000);//ML01
            Newtonsoft.Json.Utilities.ListWrapper<System.Object> val_15 = val_25;
            // 0x02912A48: LDR x2, [x8]               | X2 = public System.Void Newtonsoft.Json.Utilities.ListWrapper<System.Object>::.ctor(System.Collections.IList list);
            // 0x02912A4C: BL #0x19eeb68              | .ctor(list:  val_26 = 0);               
            val_15 = new Newtonsoft.Json.Utilities.ListWrapper<System.Object>(list:  val_26);
            label_23:
            // 0x02912A50: MOV x0, x19                | X0 = 1152921504868827136 (0x100000000F9D8000);//ML01
            // 0x02912A54: SUB sp, x29, #0x40         | SP = (1152921513965309584 - 64) = 1152921513965309520 (0x100000022DCECE50);
            // 0x02912A58: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x02912A5C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x02912A60: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x02912A64: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x02912A68: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x02912A6C: RET                        |  return (Newtonsoft.Json.Utilities.IWrappedList)typeof(Newtonsoft.Json.Utilities.ListWrapper<T>);
            return (Newtonsoft.Json.Utilities.IWrappedList)val_25;
            //  |  // // {name=val_0, type=Newtonsoft.Json.Utilities.IWrappedList, size=8, nGRN=0 }
            label_24:
            // 0x02912A70: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x02912A74: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x02912A78: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x02912A7C: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x02912A80: TBZ w8, #0, #0x2912a90     | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_29;
            // 0x02912A84: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x02912A88: CBNZ w8, #0x2912a90        | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_29;
            // 0x02912A8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_29:
            // 0x02912A90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02912A94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02912A98: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_16 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x02912A9C: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x02912AA0: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x02912AA4: MOV x20, x0                | X20 = val_16;//m1                       
            // 0x02912AA8: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
            // 0x02912AAC: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02912AB0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x02912AB4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x02912AB8: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02912ABC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x02912AC0: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02912AC4: CBNZ x19, #0x2912acc       | if ( != 0) goto label_30;               
            if(null != 0)
            {
                goto label_30;
            }
            // 0x02912AC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_30:
            // 0x02912ACC: LDR x19, [x24]             | X19 = X1;                               
            // 0x02912AD0: CBNZ x19, #0x2912ad8       | if (X1 != 0) goto label_31;             
            if(mem[24] != 0)
            {
                goto label_31;
            }
            // 0x02912AD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_31:
            // 0x02912AD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02912ADC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x02912AE0: BL #0x16fb28c              | X0 = X1.GetType();                      
            System.Type val_17 = mem[24].GetType();
            // 0x02912AE4: MOV x19, x0                | X19 = val_17;//m1                       
            // 0x02912AE8: CBNZ x21, #0x2912af0       | if ( != null) goto label_32;            
            if(null != null)
            {
                goto label_32;
            }
            // 0x02912AEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_32:
            // 0x02912AF0: CBZ x19, #0x2912b14        | if (val_17 == null) goto label_34;      
            if(val_17 == null)
            {
                goto label_34;
            }
            // 0x02912AF4: LDR x8, [x21]              | X8 = ;                                  
            // 0x02912AF8: MOV x0, x19                | X0 = val_17;//m1                        
            val_27 = val_17;
            // 0x02912AFC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x02912B00: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_17, ????);     
            // 0x02912B04: CBNZ x0, #0x2912b14        | if (val_17 != null) goto label_34;      
            if(val_27 != null)
            {
                goto label_34;
            }
            // 0x02912B08: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_17, ????);     
            // 0x02912B0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02912B10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            label_34:
            // 0x02912B14: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x02912B18: CBNZ w8, #0x2912b28        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_35;
            // 0x02912B1C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_17, ????);     
            // 0x02912B20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02912B24: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            label_35:
            // 0x02912B28: STR x19, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_17;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = val_17;
            // 0x02912B2C: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
            // 0x02912B30: LDR x8, [x8, #0xf90]       | X8 = (string**)(1152921513965092256)("Can not create ListWrapper for type {0}.");
            // 0x02912B34: MOV x2, x20                | X2 = val_16;//m1                        
            // 0x02912B38: MOV x3, x21                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02912B3C: LDR x1, [x8]               | X1 = "Can not create ListWrapper for type {0}.";
            // 0x02912B40: BL #0x2900ac4              | X0 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  val_27 = val_17, provider:  "Can not create ListWrapper for type {0}.", args:  val_16);
            string val_18 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  val_27, provider:  "Can not create ListWrapper for type {0}.", args:  val_16);
            // 0x02912B44: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x02912B48: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x02912B4C: MOV x19, x0                | X19 = val_18;//m1                       
            // 0x02912B50: LDR x8, [x8]               | X8 = typeof(System.Exception);          
            // 0x02912B54: MOV x0, x8                 | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_19 = null;
            // 0x02912B58: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x02912B5C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02912B60: MOV x1, x19                | X1 = val_18;//m1                        
            // 0x02912B64: MOV x20, x0                | X20 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x02912B68: BL #0x1c32b48              | .ctor(message:  val_18);                
            val_19 = new System.Exception(message:  val_18);
            // 0x02912B6C: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
            // 0x02912B70: LDR x8, [x8, #0x788]       | X8 = 1152921513965292480;               
            // 0x02912B74: MOV x0, x20                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x02912B78: LDR x1, [x8]               | X1 = public static Newtonsoft.Json.Utilities.IWrappedList Newtonsoft.Json.Utilities.CollectionUtils::CreateListWrapper(object list);
            // 0x02912B7C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x02912B80: BL #0x28fffbc              | X0 = Convert(value:  public static Newtonsoft.Json.Utilities.IWrappedList Newtonsoft.Json.Utilities.CollectionUtils::CreateListWrapper(object list), typeCode:  0);
            object val_20 = Convert(value:  public static Newtonsoft.Json.Utilities.IWrappedList Newtonsoft.Json.Utilities.CollectionUtils::CreateListWrapper(object list), typeCode:  0);
            // 0x02912B84: MOV x19, x0                | X19 = val_20;//m1                       
            val_28 = val_20;
            // 0x02912B88: MOV x0, sp                 | X0 = 1152921513965309504 (0x100000022DCECE40);//ML01
            val_29;
            // 0x02912B8C: B #0x2912b98               |  goto label_36;                         
            goto label_36;
            // 0x02912B90: MOV x19, x0                | X19 = 1152921513965309504 (0x100000022DCECE40);//ML01
            val_28 = val_29;
            // 0x02912B94: ADD x0, sp, #8             | X0 = (1152921513965309504 + 8) = 1152921513965309512 (0x100000022DCECE48);
            label_36:
            // 0x02912B98: BL #0x299a140              | 
            // 0x02912B9C: MOV x0, x19                | X0 = 1152921513965309504 (0x100000022DCECE40);//ML01
            // 0x02912BA0: BL #0x980800               | X0 = sub_980800( ?? 0x100000022DCECE40, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x029024F0 (43001072), len: 1396  VirtAddr: 0x029024F0 RVA: 0x029024F0 token: 100686572 methodIndex: 49125 delegateWrapperIndex: 0 methodInvoker: 0
        public static Newtonsoft.Json.Utilities.IWrappedDictionary CreateDictionaryWrapper(object dictionary)
        {
            //
            // Disasemble & Code
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_24;
            //  | 
            System.Type val_25;
            //  | 
            System.Type val_26;
            //  | 
            var val_27;
            //  | 
            Newtonsoft.Json.Utilities.DictionaryWrapper<System.Object, System.Object> val_28;
            //  | 
            System.Collections.IDictionary val_29;
            //  | 
            string val_30;
            //  | 
            var val_31;
            //  | 
            var val_32;
            // 0x029024F0: STP x26, x25, [sp, #-0x50]! | stack[1152921513965501648] = ???;  stack[1152921513965501656] = ???;  //  dest_result_addr=1152921513965501648 |  dest_result_addr=1152921513965501656
            // 0x029024F4: STP x24, x23, [sp, #0x10]  | stack[1152921513965501664] = ???;  stack[1152921513965501672] = ???;  //  dest_result_addr=1152921513965501664 |  dest_result_addr=1152921513965501672
            // 0x029024F8: STP x22, x21, [sp, #0x20]  | stack[1152921513965501680] = ???;  stack[1152921513965501688] = ???;  //  dest_result_addr=1152921513965501680 |  dest_result_addr=1152921513965501688
            // 0x029024FC: STP x20, x19, [sp, #0x30]  | stack[1152921513965501696] = ???;  stack[1152921513965501704] = ???;  //  dest_result_addr=1152921513965501696 |  dest_result_addr=1152921513965501704
            // 0x02902500: STP x29, x30, [sp, #0x40]  | stack[1152921513965501712] = ???;  stack[1152921513965501720] = ???;  //  dest_result_addr=1152921513965501712 |  dest_result_addr=1152921513965501720
            // 0x02902504: ADD x29, sp, #0x40         | X29 = (1152921513965501648 + 64) = 1152921513965501712 (0x100000022DD1BD10);
            // 0x02902508: SUB sp, sp, #0x20          | SP = (1152921513965501648 - 32) = 1152921513965501616 (0x100000022DD1BCB0);
            // 0x0290250C: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x02902510: LDRB w8, [x19, #0xaf5]     | W8 = (bool)static_value_037B8AF5;       
            // 0x02902514: MOV x20, x1                | X20 = X1;//m1                           
            // 0x02902518: TBNZ w8, #0, #0x2902534    | if (static_value_037B8AF5 == true) goto label_0;
            // 0x0290251C: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x02902520: LDR x8, [x8, #0x560]       | X8 = 0x2B915EC;                         
            // 0x02902524: LDR w0, [x8]               | W0 = 0x1C3F;                            
            // 0x02902528: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C3F, ????);     
            // 0x0290252C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02902530: STRB w8, [x19, #0xaf5]     | static_value_037B8AF5 = true;            //  dest_result_addr=58428149
            label_0:
            // 0x02902534: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
            // 0x02902538: LDR x8, [x8, #0x3a0]       | X8 = 1152921504866910208;               
            // 0x0290253C: LDR x0, [x8]               | X0 = typeof(CollectionUtils.<CreateDictionaryWrapper>c__AnonStorey3);
            object val_1 = null;
            // 0x02902540: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CollectionUtils.<CreateDictionaryWrapper>c__AnonStorey3), ????);
            // 0x02902544: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02902548: MOV x19, x0                | X19 = 1152921504866910208 (0x100000000F804000);//ML01
            // 0x0290254C: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x02902550: CBZ x19, #0x2902574        | if ( == 0) goto label_1;                
            if(null == 0)
            {
                goto label_1;
            }
            // 0x02902554: MOV x25, x19               | X25 = 1152921504866910208 (0x100000000F804000);//ML01
            val_24 = val_1;
            // 0x02902558: STR x20, [x25, #0x18]!     | typeof(CollectionUtils.<CreateDictionaryWrapper>c__AnonStorey3).__il2cppRuntimeField_18 = X1;  //  dest_result_addr=1152921504866910232
            typeof(CollectionUtils.<CreateDictionaryWrapper>c__AnonStorey3).__il2cppRuntimeField_18 = X1;
            // 0x0290255C: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x02902560: LDR x8, [x8, #0xd00]       | X8 = (string**)(1152921513965454656)("dictionary");
            // 0x02902564: MOV x1, x20                | X1 = X1;//m1                            
            // 0x02902568: LDR x2, [x8]               | X2 = "dictionary";                      
            // 0x0290256C: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  val_1 = new System.Object(), parameterName:  X1);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  val_1, parameterName:  X1);
            // 0x02902570: B #0x290259c               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x02902574: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x02902578: ORR w25, wzr, #0x18        | W25 = 24(0x18);                         
            val_24 = 24;
            // 0x0290257C: STR x20, [x25]             | mem[24] = X1;                            //  dest_result_addr=24
            mem[24] = X1;
            // 0x02902580: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x02902584: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x02902588: LDR x1, [x25]              | X1 = X1;                                
            // 0x0290258C: LDR x8, [x8, #0xd00]       | X8 = (string**)(1152921513965454656)("dictionary");
            // 0x02902590: LDR x2, [x8]               | X2 = "dictionary";                      
            // 0x02902594: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  val_1, parameterName:  mem[24]);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  val_1, parameterName:  mem[24]);
            // 0x02902598: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_2:
            // 0x0290259C: LDR x20, [x25]             | X20 = X1;                               
            // 0x029025A0: CBNZ x20, #0x29025a8       | if (X1 != 0) goto label_3;              
            if(val_24 != 0)
            {
                goto label_3;
            }
            // 0x029025A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_3:
            // 0x029025A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029025AC: MOV x0, x20                | X0 = X1;//m1                            
            // 0x029025B0: BL #0x16fb28c              | X0 = X1.GetType();                      
            System.Type val_2 = val_24.GetType();
            // 0x029025B4: ADRP x26, #0x3620000       | X26 = 56754176 (0x3620000);             
            // 0x029025B8: LDR x26, [x26, #0x340]     | X26 = 1152921504609562624;              
            // 0x029025BC: ADRP x9, #0x35c6000        | X9 = 56385536 (0x35C6000);              
            // 0x029025C0: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x029025C4: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x029025C8: LDR x9, [x9, #0xed8]       | X9 = 1152921504616431616;               
            // 0x029025CC: LDR x20, [x9]              | X20 = typeof(System.Collections.Generic.IDictionary<TKey, TValue>);
            // 0x029025D0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x029025D4: TBZ w9, #0, #0x29025e8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x029025D8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x029025DC: CBNZ w9, #0x29025e8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x029025E0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x029025E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_5:
            // 0x029025E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x029025EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x029025F0: MOV x1, x20                | X1 = 1152921504616431616 (0x1000000000924000);//ML01
            // 0x029025F4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x029025F8: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x029025FC: CBZ x19, #0x2902620        | if ( == 0) goto label_6;                
            if(null == 0)
            {
                goto label_6;
            }
            // 0x02902600: ADD x20, x19, #0x10        | X20 = (val_1 + 16) = val_25 (0x100000000F804010);
            val_25 = 1152921504866910224;
            // 0x02902604: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x02902608: MOV x2, x22                | X2 = val_3;//m1                         
            System.Type val_4 = val_3;
            // 0x0290260C: MOV x3, x20                | X3 = 1152921504866910224 (0x100000000F804010);//ML01
            // 0x02902610: BL #0x28fdaec              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle()), genericInterfaceDefinition:  val_2, implementingType: out  System.Type val_4 = val_3);
            bool val_5 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  val_3, genericInterfaceDefinition:  val_2, implementingType: out  val_4);
            // 0x02902614: AND w8, w0, #1             | W8 = (val_5 & 1);                       
            bool val_6 = val_5;
            // 0x02902618: TBNZ w8, #0, #0x2902644    | if ((val_5 & 1) == true) goto label_7;  
            if(val_6 == true)
            {
                goto label_7;
            }
            // 0x0290261C: B #0x2902878               |  goto label_9;                          
            goto label_9;
            label_6:
            // 0x02902620: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            // 0x02902624: ORR w3, wzr, #0x10         | W3 = 16(0x10);                          
            // 0x02902628: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x0290262C: MOV x2, x22                | X2 = val_3;//m1                         
            System.Type val_7 = val_3;
            // 0x02902630: ORR w20, wzr, #0x10        | W20 = 16(0x10);                         
            val_25 = 16;
            // 0x02902634: BL #0x28fdaec              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  val_3, genericInterfaceDefinition:  val_2, implementingType: out  System.Type val_7 = val_3);
            bool val_8 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  val_3, genericInterfaceDefinition:  val_2, implementingType: out  val_7);
            // 0x02902638: MOV w21, w0                | W21 = val_8;//m1                        
            // 0x0290263C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            // 0x02902640: TBZ w21, #0, #0x2902878    | if (val_8 == false) goto label_9;       
            if(val_8 == false)
            {
                goto label_9;
            }
            label_7:
            // 0x02902644: LDR x1, [x20]              | X1 = 0x100B70003;                       
            // 0x02902648: ADD x2, sp, #8             | X2 = (1152921513965501616 + 8) = 1152921513965501624 (0x100000022DD1BCB8);
            // 0x0290264C: MOV x3, sp                 | X3 = 1152921513965501616 (0x100000022DD1BCB0);//ML01
            // 0x02902650: STP xzr, xzr, [sp]         | stack[1152921513965501616] = 0x0;  stack[1152921513965501624] = 0x0;  //  dest_result_addr=1152921513965501616 |  dest_result_addr=1152921513965501624
            System.Type val_9 = 0;
            // 0x02902654: BL #0x28ff698              | Newtonsoft.Json.Utilities.ReflectionUtils.GetDictionaryKeyValueTypes(dictionaryType:  bool val_8 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  val_3, genericInterfaceDefinition:  val_2, implementingType: out  val_7), keyType: out  val_25 = 16, valueType: out  System.Type val_9 = 0);
            Newtonsoft.Json.Utilities.ReflectionUtils.GetDictionaryKeyValueTypes(dictionaryType:  val_8, keyType: out  val_25, valueType: out  val_9);
            // 0x02902658: LDR x24, [sp, #8]          | X24 = 0x0;                              
            // 0x0290265C: CBNZ x19, #0x2902664       | if ( != 0) goto label_10;               
            if(null != 0)
            {
                goto label_10;
            }
            // 0x02902660: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_10:
            // 0x02902664: LDR x1, [x20]              | X1 = 0x100B70003;                       
            System.Type val_10 = 11993091;
            // 0x02902668: ADD x2, sp, #8             | X2 = (1152921513965501616 + 8) = 1152921513965501624 (0x100000022DD1BCB8);
            // 0x0290266C: MOV x3, sp                 | X3 = 1152921513965501616 (0x100000022DD1BCB0);//ML01
            // 0x02902670: STP xzr, xzr, [sp]         | stack[1152921513965501616] = 0x0;  stack[1152921513965501624] = 0x0;  //  dest_result_addr=1152921513965501616 |  dest_result_addr=1152921513965501624
            System.Type val_11 = 0;
            // 0x02902674: BL #0x28ff698              | Newtonsoft.Json.Utilities.ReflectionUtils.GetDictionaryKeyValueTypes(dictionaryType:  val_8, keyType: out  System.Type val_10 = 11993091, valueType: out  System.Type val_11 = 0);
            Newtonsoft.Json.Utilities.ReflectionUtils.GetDictionaryKeyValueTypes(dictionaryType:  val_8, keyType: out  val_10, valueType: out  val_11);
            // 0x02902678: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x0290267C: ADRP x9, #0x363e000        | X9 = 56877056 (0x363E000);              
            // 0x02902680: LDR x23, [sp]              | X23 = 0x0;                              
            // 0x02902684: LDR x8, [x8, #0x7a8]       | X8 = 1152921513965462944;               
            // 0x02902688: LDR x9, [x9, #0x210]       | X9 = 1152921504688156672;               
            // 0x0290268C: LDR x21, [x8]              | X21 = System.Object CollectionUtils.<CreateDictionaryWrapper>c__AnonStorey3::<>m__0(System.Type t, System.Collections.Generic.IList<object> a);
            // 0x02902690: LDR x0, [x9]               | X0 = typeof(System.Func<T1, T2, TResult>);
            System.Func<System.Type, System.Collections.Generic.IList<System.Object>, System.Object> val_12 = null;
            // 0x02902694: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Func<T1, T2, TResult>), ????);
            // 0x02902698: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x0290269C: LDR x8, [x8, #0xf00]       | X8 = 1152921513965074848;               
            // 0x029026A0: MOV x1, x19                | X1 = 1152921504866910208 (0x100000000F804000);//ML01
            // 0x029026A4: MOV x2, x21                | X2 = 1152921513965462944 (0x100000022DD125A0);//ML01
            // 0x029026A8: MOV x20, x0                | X20 = 1152921504688156672 (0x1000000004D8B000);//ML01
            // 0x029026AC: LDR x3, [x8]               | X3 = public System.Void System.Func<System.Type, System.Collections.Generic.IList<System.Object>, System.Object>::.ctor(object object, IntPtr method);
            // 0x029026B0: BL #0x21d5d94              | .ctor(object:  val_1, method:  System.Object CollectionUtils.<CreateDictionaryWrapper>c__AnonStorey3::<>m__0(System.Type t, System.Collections.Generic.IList<object> a));
            val_12 = new System.Func<System.Type, System.Collections.Generic.IList<System.Object>, System.Object>(object:  val_1, method:  System.Object CollectionUtils.<CreateDictionaryWrapper>c__AnonStorey3::<>m__0(System.Type t, System.Collections.Generic.IList<object> a));
            // 0x029026B4: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
            // 0x029026B8: LDR x0, [x26]              | X0 = typeof(System.Type);               
            // 0x029026BC: LDR x8, [x8, #0x4a8]       | X8 = 1152921504867549184;               
            // 0x029026C0: LDR x21, [x8]              | X21 = typeof(Newtonsoft.Json.Utilities.DictionaryWrapper<TKey, TValue>);
            // 0x029026C4: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x029026C8: TBZ w8, #0, #0x29026d8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x029026CC: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x029026D0: CBNZ w8, #0x29026d8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x029026D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_12:
            // 0x029026D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x029026DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x029026E0: MOV x1, x21                | X1 = 1152921504867549184 (0x100000000F8A0000);//ML01
            // 0x029026E4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_13 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x029026E8: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x029026EC: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x029026F0: MOV x21, x0                | X21 = val_13;//m1                       
            // 0x029026F4: LDR x22, [x8]              | X22 = typeof(System.Type[]);            
            // 0x029026F8: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x029026FC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x02902700: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x02902704: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x02902708: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0290270C: MOV x22, x0                | X22 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x02902710: CBNZ x22, #0x2902718       | if ( != null) goto label_13;            
            if(null != null)
            {
                goto label_13;
            }
            // 0x02902714: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_13:
            // 0x02902718: CBZ x24, #0x290273c        | if (0x0 == 0) goto label_15;            
            if(val_9 == 0)
            {
                goto label_15;
            }
            // 0x0290271C: LDR x8, [x22]              | X8 = ;                                  
            // 0x02902720: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            // 0x02902724: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x02902728: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x0, ????);        
            // 0x0290272C: CBNZ x0, #0x290273c        | if (0x0 != 0) goto label_15;            
            if(val_9 != 0)
            {
                goto label_15;
            }
            // 0x02902730: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 0x0, ????);        
            // 0x02902734: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02902738: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_15:
            // 0x0290273C: LDR w8, [x22, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x02902740: CBNZ w8, #0x2902750        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_16;
            // 0x02902744: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x02902748: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0290274C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_16:
            // 0x02902750: STR x24, [x22, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = 0x0;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_9;
            // 0x02902754: CBZ x23, #0x2902778        | if (0x0 == 0) goto label_18;            
            if(0 == 0)
            {
                goto label_18;
            }
            // 0x02902758: LDR x8, [x22]              | X8 = ;                                  
            // 0x0290275C: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x02902760: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x02902764: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x0, ????);        
            // 0x02902768: CBNZ x0, #0x2902778        | if (0x0 != 0) goto label_18;            
            if(0 != 0)
            {
                goto label_18;
            }
            // 0x0290276C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 0x0, ????);        
            // 0x02902770: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02902774: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_18:
            // 0x02902778: LDR w8, [x22, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0290277C: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x02902780: B.HI #0x2902790            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_19;
            // 0x02902784: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x02902788: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0290278C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_19:
            // 0x02902790: STR x23, [x22, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = 0x0;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = 0;
            // 0x02902794: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x02902798: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x0290279C: LDR x23, [x8]              | X23 = typeof(System.Object[]);          
            // 0x029027A0: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x029027A4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x029027A8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x029027AC: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            val_26 = null;
            // 0x029027B0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x029027B4: MOV x23, x0                | X23 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x029027B8: CBNZ x19, #0x29027c0       | if ( != 0) goto label_20;               
            if(null != 0)
            {
                goto label_20;
            }
            // 0x029027BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_20:
            // 0x029027C0: LDR x19, [x25]             | X19 = X1;                               
            // 0x029027C4: CBNZ x23, #0x29027cc       | if ( != null) goto label_21;            
            if(null != null)
            {
                goto label_21;
            }
            // 0x029027C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_21:
            // 0x029027CC: CBZ x19, #0x29027f0        | if (X1 == 0) goto label_23;             
            if(mem[24] == 0)
            {
                goto label_23;
            }
            // 0x029027D0: LDR x8, [x23]              | X8 = ;                                  
            // 0x029027D4: MOV x0, x19                | X0 = X1;//m1                            
            val_26 = mem[24];
            // 0x029027D8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x029027DC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X1, ????);         
            // 0x029027E0: CBNZ x0, #0x29027f0        | if (X1 != 0) goto label_23;             
            if(val_26 != 0)
            {
                goto label_23;
            }
            // 0x029027E4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? X1, ????);         
            // 0x029027E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029027EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
            label_23:
            // 0x029027F0: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x029027F4: CBNZ w8, #0x2902804        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_24;
            // 0x029027F8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1, ????);         
            // 0x029027FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02902800: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
            label_24:
            // 0x02902804: MOV x1, x21                | X1 = val_13;//m1                        
            // 0x02902808: MOV x2, x22                | X2 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0290280C: MOV x3, x20                | X3 = 1152921504688156672 (0x1000000004D8B000);//ML01
            // 0x02902810: MOV x4, x23                | X4 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02902814: STR x19, [x23, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = X1;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = mem[24];
            // 0x02902818: BL #0x29125a8              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.CreateGeneric(genericTypeDefinition:  val_26 = mem[24], innerTypes:  val_13, instanceCreator:  null, args:  val_12);
            object val_14 = Newtonsoft.Json.Utilities.ReflectionUtils.CreateGeneric(genericTypeDefinition:  val_26, innerTypes:  val_13, instanceCreator:  null, args:  val_12);
            // 0x0290281C: MOV x21, x0                | X21 = val_14;//m1                       
            val_27 = val_14;
            // 0x02902820: CBZ x21, #0x2902870        | if (val_14 == null) goto label_25;      
            if(val_27 == null)
            {
                goto label_25;
            }
            // 0x02902824: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x02902828: LDR x8, [x8, #0x410]       | X8 = 1152921504867495936;               
            // 0x0290282C: MOV x0, x21                | X0 = val_14;//m1                        
            // 0x02902830: LDR x20, [x8]              | X20 = typeof(Newtonsoft.Json.Utilities.IWrappedDictionary);
            // 0x02902834: MOV x1, x20                | X1 = 1152921504867495936 (0x100000000F893000);//ML01
            // 0x02902838: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_14, ????);     
            // 0x0290283C: MOV x19, x0                | X19 = val_14;//m1                       
            val_28 = val_27;
            // 0x02902840: CBNZ x19, #0x2902910       | if (val_14 != null) goto label_27;      
            if(val_28 != null)
            {
                goto label_27;
            }
            // 0x02902844: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x02902848: MOV x1, x20                | X1 = 1152921504867495936 (0x100000000F893000);//ML01
            // 0x0290284C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x02902850: ADD x8, sp, #0x10          | X8 = (1152921513965501616 + 16) = 1152921513965501632 (0x100000022DD1BCC0);
            // 0x02902854: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x02902858: LDR x0, [sp, #0x10]        | X0 = val_15;                             //  find_add[1152921513965489728]
            // 0x0290285C: BL #0x27af090              | X0 = sub_27AF090( ?? val_15, ????);     
            // 0x02902860: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02902864: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            // 0x02902868: ADD x0, sp, #0x10          | X0 = (1152921513965501616 + 16) = 1152921513965501632 (0x100000022DD1BCC0);
            // 0x0290286C: BL #0x299a140              | 
            label_25:
            // 0x02902870: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_28 = 0;
            // 0x02902874: B #0x2902910               |  goto label_27;                         
            goto label_27;
            label_9:
            // 0x02902878: ADRP x21, #0x3639000       | X21 = 56856576 (0x3639000);             
            // 0x0290287C: LDR x0, [x25]              | X0 = X1;                                
            // 0x02902880: LDR x21, [x21, #0xa88]     | X21 = 1152921504618135552;              
            val_27 = 1152921504618135552;
            // 0x02902884: LDR x1, [x21]              | X1 = typeof(System.Collections.IDictionary);
            // 0x02902888: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X1, ????);         
            // 0x0290288C: CBZ x0, #0x2902930         | if (X1 == 0) goto label_28;             
            if(mem[24] == 0)
            {
                goto label_28;
            }
            // 0x02902890: CBNZ x19, #0x2902898       | if ( != 0) goto label_29;               
            if(null != 0)
            {
                goto label_29;
            }
            // 0x02902894: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_29:
            // 0x02902898: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
            // 0x0290289C: LDR x20, [x25]             | X20 = X1;                               
            // 0x029028A0: LDR x8, [x8, #0x380]       | X8 = 1152921504867549184;               
            // 0x029028A4: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Utilities.DictionaryWrapper<TKey, TValue>);
            // 0x029028A8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Utilities.DictionaryWrapper<TKey, TValue>), ????);
            // 0x029028AC: MOV x19, x0                | X19 = 1152921504867549184 (0x100000000F8A0000);//ML01
            val_28 = null;
            // 0x029028B0: CBZ x20, #0x29028f8        | if (X1 == 0) goto label_30;             
            if(mem[24] == 0)
            {
                goto label_30;
            }
            // 0x029028B4: LDR x21, [x21]             | X21 = typeof(System.Collections.IDictionary);
            val_27 = null;
            // 0x029028B8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x029028BC: MOV x1, x21                | X1 = 1152921504618135552 (0x1000000000AC4000);//ML01
            // 0x029028C0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X1, ????);         
            // 0x029028C4: MOV x1, x0                 | X1 = X1;//m1                            
            val_29 = mem[24];
            // 0x029028C8: CBNZ x1, #0x29028fc        | if (X1 != 0) goto label_31;             
            if(val_29 != 0)
            {
                goto label_31;
            }
            // 0x029028CC: LDR x8, [x20]              | X8 = X1;                                
            // 0x029028D0: MOV x1, x21                | X1 = 1152921504618135552 (0x1000000000AC4000);//ML01
            // 0x029028D4: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x029028D8: ADD x8, sp, #0x18          | X8 = (1152921513965501616 + 24) = 1152921513965501640 (0x100000022DD1BCC8);
            // 0x029028DC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x029028E0: LDR x0, [sp, #0x18]        | X0 = val_16;                             //  find_add[1152921513965489728]
            // 0x029028E4: BL #0x27af090              | X0 = sub_27AF090( ?? val_16, ????);     
            // 0x029028E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029028EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            // 0x029028F0: ADD x0, sp, #0x18          | X0 = (1152921513965501616 + 24) = 1152921513965501640 (0x100000022DD1BCC8);
            // 0x029028F4: BL #0x299a140              | 
            label_30:
            // 0x029028F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_29 = 0;
            label_31:
            // 0x029028FC: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
            // 0x02902900: LDR x8, [x8, #0x808]       | X8 = 1152921513925136400;               
            // 0x02902904: MOV x0, x19                | X0 = 1152921504867549184 (0x100000000F8A0000);//ML01
            Newtonsoft.Json.Utilities.DictionaryWrapper<System.Object, System.Object> val_17 = val_28;
            // 0x02902908: LDR x2, [x8]               | X2 = public System.Void Newtonsoft.Json.Utilities.DictionaryWrapper<System.Object, System.Object>::.ctor(System.Collections.IDictionary dictionary);
            // 0x0290290C: BL #0x19eb0a8              | .ctor(dictionary:  val_29 = 0);         
            val_17 = new Newtonsoft.Json.Utilities.DictionaryWrapper<System.Object, System.Object>(dictionary:  val_29);
            label_27:
            // 0x02902910: MOV x0, x19                | X0 = 1152921504867549184 (0x100000000F8A0000);//ML01
            // 0x02902914: SUB sp, x29, #0x40         | SP = (1152921513965501712 - 64) = 1152921513965501648 (0x100000022DD1BCD0);
            // 0x02902918: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0290291C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x02902920: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x02902924: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x02902928: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0290292C: RET                        |  return (Newtonsoft.Json.Utilities.IWrappedDictionary)typeof(Newtonsoft.Json.Utilities.DictionaryWrapper<TKey, TValue>);
            return (Newtonsoft.Json.Utilities.IWrappedDictionary)val_28;
            //  |  // // {name=val_0, type=Newtonsoft.Json.Utilities.IWrappedDictionary, size=8, nGRN=0 }
            label_28:
            // 0x02902930: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x02902934: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x02902938: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x0290293C: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x02902940: TBZ w8, #0, #0x2902950     | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_33;
            // 0x02902944: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x02902948: CBNZ w8, #0x2902950        | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_33;
            // 0x0290294C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_33:
            // 0x02902950: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02902954: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02902958: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_18 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x0290295C: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x02902960: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x02902964: MOV x20, x0                | X20 = val_18;//m1                       
            // 0x02902968: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
            // 0x0290296C: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02902970: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x02902974: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x02902978: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x0290297C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x02902980: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02902984: CBNZ x19, #0x290298c       | if ( != 0) goto label_34;               
            if(null != 0)
            {
                goto label_34;
            }
            // 0x02902988: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_34:
            // 0x0290298C: LDR x19, [x25]             | X19 = X1;                               
            // 0x02902990: CBNZ x19, #0x2902998       | if (X1 != 0) goto label_35;             
            if(mem[24] != 0)
            {
                goto label_35;
            }
            // 0x02902994: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_35:
            // 0x02902998: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0290299C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x029029A0: BL #0x16fb28c              | X0 = X1.GetType();                      
            System.Type val_19 = mem[24].GetType();
            // 0x029029A4: MOV x19, x0                | X19 = val_19;//m1                       
            // 0x029029A8: CBNZ x21, #0x29029b0       | if ( != null) goto label_36;            
            if(null != null)
            {
                goto label_36;
            }
            // 0x029029AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
            label_36:
            // 0x029029B0: CBZ x19, #0x29029d4        | if (val_19 == null) goto label_38;      
            if(val_19 == null)
            {
                goto label_38;
            }
            // 0x029029B4: LDR x8, [x21]              | X8 = ;                                  
            // 0x029029B8: MOV x0, x19                | X0 = val_19;//m1                        
            val_30 = val_19;
            // 0x029029BC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x029029C0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_19, ????);     
            // 0x029029C4: CBNZ x0, #0x29029d4        | if (val_19 != null) goto label_38;      
            if(val_30 != null)
            {
                goto label_38;
            }
            // 0x029029C8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_19, ????);     
            // 0x029029CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029029D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            label_38:
            // 0x029029D4: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x029029D8: CBNZ w8, #0x29029e8        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_39;
            // 0x029029DC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_19, ????);     
            // 0x029029E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029029E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            label_39:
            // 0x029029E8: STR x19, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_19;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = val_19;
            // 0x029029EC: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
            // 0x029029F0: LDR x8, [x8, #0xc68]       | X8 = (string**)(1152921513965480352)("Can not create DictionaryWrapper for type {0}.");
            // 0x029029F4: MOV x2, x20                | X2 = val_18;//m1                        
            // 0x029029F8: MOV x3, x21                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x029029FC: LDR x1, [x8]               | X1 = "Can not create DictionaryWrapper for type {0}.";
            // 0x02902A00: BL #0x2900ac4              | X0 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  val_30 = val_19, provider:  "Can not create DictionaryWrapper for type {0}.", args:  val_18);
            string val_20 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  val_30, provider:  "Can not create DictionaryWrapper for type {0}.", args:  val_18);
            // 0x02902A04: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x02902A08: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x02902A0C: MOV x19, x0                | X19 = val_20;//m1                       
            // 0x02902A10: LDR x8, [x8]               | X8 = typeof(System.Exception);          
            // 0x02902A14: MOV x0, x8                 | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_21 = null;
            // 0x02902A18: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x02902A1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02902A20: MOV x1, x19                | X1 = val_20;//m1                        
            // 0x02902A24: MOV x20, x0                | X20 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x02902A28: BL #0x1c32b48              | .ctor(message:  val_20);                
            val_21 = new System.Exception(message:  val_20);
            // 0x02902A2C: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
            // 0x02902A30: LDR x8, [x8, #0xcf0]       | X8 = 1152921513965484608;               
            // 0x02902A34: MOV x0, x20                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x02902A38: LDR x1, [x8]               | X1 = public static Newtonsoft.Json.Utilities.IWrappedDictionary Newtonsoft.Json.Utilities.CollectionUtils::CreateDictionaryWrapper(object dictionary);
            // 0x02902A3C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x02902A40: BL #0x28fffbc              | X0 = Convert(value:  public static Newtonsoft.Json.Utilities.IWrappedDictionary Newtonsoft.Json.Utilities.CollectionUtils::CreateDictionaryWrapper(object dictionary), typeCode:  0);
            object val_22 = Convert(value:  public static Newtonsoft.Json.Utilities.IWrappedDictionary Newtonsoft.Json.Utilities.CollectionUtils::CreateDictionaryWrapper(object dictionary), typeCode:  0);
            // 0x02902A44: MOV x19, x0                | X19 = val_22;//m1                       
            val_31 = val_22;
            // 0x02902A48: ADD x0, sp, #0x10          | X0 = (1152921513965501616 + 16) = 1152921513965501632 (0x100000022DD1BCC0);
            // 0x02902A4C: B #0x2902a58               |  goto label_40;                         
            goto label_40;
            // 0x02902A50: MOV x19, x0                | X19 = 1152921513965501632 (0x100000022DD1BCC0);//ML01
            val_31;
            // 0x02902A54: ADD x0, sp, #0x18          | X0 = (1152921513965501616 + 24) = 1152921513965501640 (0x100000022DD1BCC8);
            label_40:
            // 0x02902A58: BL #0x299a140              | 
            // 0x02902A5C: MOV x0, x19                | X0 = 1152921513965501632 (0x100000022DD1BCC0);//ML01
            // 0x02902A60: BL #0x980800               | X0 = sub_980800( ?? 0x100000022DD1BCC0, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x029080C8 (43024584), len: 2832  VirtAddr: 0x029080C8 RVA: 0x029080C8 token: 100686573 methodIndex: 49126 delegateWrapperIndex: 0 methodInvoker: 0
        public static object CreateAndPopulateList(System.Type listType, System.Action<System.Collections.IList, bool> populateList)
        {
            //
            // Disasemble & Code
            //  | 
            var val_26;
            //  | 
            var val_28;
            //  | 
            var val_32;
            //  | 
            var val_33;
            //  | 
            var val_38;
            //  | 
            var val_43;
            //  | 
            string val_46;
            //  | 
            System.Collections.IList val_47;
            //  | 
            var val_48;
            //  | 
            System.Type val_49;
            //  | 
            var val_50;
            //  | 
            var val_51;
            //  | 
            var val_52;
            //  | 
            var val_53;
            //  | 
            var val_54;
            //  | 
            var val_55;
            //  | 
            var val_56;
            //  | 
            var val_57;
            //  | 
            var val_58;
            //  | 
            var val_59;
            //  | 
            System.Type val_60;
            //  | 
            var val_61;
            //  | 
            string val_62;
            //  | 
            var val_63;
            //  | 
            var val_64;
            // 0x029080C8: STP x28, x27, [sp, #-0x60]! | stack[1152921513965812800] = ???;  stack[1152921513965812808] = ???;  //  dest_result_addr=1152921513965812800 |  dest_result_addr=1152921513965812808
            // 0x029080CC: STP x26, x25, [sp, #0x10]  | stack[1152921513965812816] = ???;  stack[1152921513965812824] = ???;  //  dest_result_addr=1152921513965812816 |  dest_result_addr=1152921513965812824
            // 0x029080D0: STP x24, x23, [sp, #0x20]  | stack[1152921513965812832] = ???;  stack[1152921513965812840] = ???;  //  dest_result_addr=1152921513965812832 |  dest_result_addr=1152921513965812840
            // 0x029080D4: STP x22, x21, [sp, #0x30]  | stack[1152921513965812848] = ???;  stack[1152921513965812856] = ???;  //  dest_result_addr=1152921513965812848 |  dest_result_addr=1152921513965812856
            // 0x029080D8: STP x20, x19, [sp, #0x40]  | stack[1152921513965812864] = ???;  stack[1152921513965812872] = ???;  //  dest_result_addr=1152921513965812864 |  dest_result_addr=1152921513965812872
            // 0x029080DC: STP x29, x30, [sp, #0x50]  | stack[1152921513965812880] = ???;  stack[1152921513965812888] = ???;  //  dest_result_addr=1152921513965812880 |  dest_result_addr=1152921513965812888
            // 0x029080E0: ADD x29, sp, #0x50         | X29 = (1152921513965812800 + 80) = 1152921513965812880 (0x100000022DD67C90);
            // 0x029080E4: SUB sp, sp, #0x40          | SP = (1152921513965812800 - 64) = 1152921513965812736 (0x100000022DD67C00);
            // 0x029080E8: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x029080EC: LDRB w8, [x21, #0xaf6]     | W8 = (bool)static_value_037B8AF6;       
            // 0x029080F0: MOV x20, x2                | X20 = X2;//m1                           
            // 0x029080F4: MOV x19, x1                | X19 = populateList;//m1                 
            val_46 = populateList;
            // 0x029080F8: TBNZ w8, #0, #0x2908114    | if (static_value_037B8AF6 == true) goto label_0;
            // 0x029080FC: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
            // 0x02908100: LDR x8, [x8, #0xe98]       | X8 = 0x2B915E4;                         
            // 0x02908104: LDR w0, [x8]               | W0 = 0x1C3D;                            
            // 0x02908108: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C3D, ????);     
            // 0x0290810C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02908110: STRB w8, [x21, #0xaf6]     | static_value_037B8AF6 = true;            //  dest_result_addr=58428150
            label_0:
            // 0x02908114: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x02908118: LDR x8, [x8, #0xd98]       | X8 = (string**)(1152921513964370272)("listType");
            // 0x0290811C: MOV x1, x19                | X1 = populateList;//m1                  
            // 0x02908120: STR xzr, [sp]              | stack[1152921513965812736] = 0x0;        //  dest_result_addr=1152921513965812736
            // 0x02908124: LDR x2, [x8]               | X2 = "listType";                        
            // 0x02908128: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  7229, parameterName:  val_46);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  7229, parameterName:  val_46);
            // 0x0290812C: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
            // 0x02908130: LDR x8, [x8, #0x4e8]       | X8 = (string**)(1152921513965646784)("populateList");
            // 0x02908134: MOV x1, x20                | X1 = X2;//m1                            
            // 0x02908138: LDR x2, [x8]               | X2 = "populateList";                    
            // 0x0290813C: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  7229, parameterName:  X2);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  7229, parameterName:  X2);
            // 0x02908140: CBNZ x19, #0x2908148       | if (populateList != null) goto label_1; 
            if(val_46 != null)
            {
                goto label_1;
            }
            // 0x02908144: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C3D, ????);     
            label_1:
            // 0x02908148: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0290814C: MOV x0, x19                | X0 = populateList;//m1                  
            // 0x02908150: BL #0x1b6d1cc              | X0 = populateList.get_IsArray();        
            bool val_1 = val_46.IsArray;
            // 0x02908154: TBZ w0, #0, #0x2908184     | if (val_1 == false) goto label_2;       
            if(val_1 == false)
            {
                goto label_2;
            }
            // 0x02908158: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x0290815C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504616644608;               
            // 0x02908160: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.Object> val_2 = null;
            // 0x02908164: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x02908168: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
            // 0x0290816C: LDR x8, [x8, #0xca0]       | X8 = 1152921509744601424;               
            // 0x02908170: MOV x21, x0                | X21 = 1152921504616644608 (0x1000000000958000);//ML01
            val_47 = val_2;
            // 0x02908174: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.Object>::.ctor();
            // 0x02908178: BL #0x25e9474              | .ctor();                                
            val_2 = new System.Collections.Generic.List<System.Object>();
            // 0x0290817C: ORR w22, wzr, #1           | W22 = 1(0x1);                           
            val_48 = 1;
            // 0x02908180: B #0x2908608               |  goto label_36;                         
            goto label_36;
            label_2:
            // 0x02908184: ADRP x22, #0x3620000       | X22 = 56754176 (0x3620000);             
            // 0x02908188: LDR x22, [x22, #0x340]     | X22 = 1152921504609562624;              
            // 0x0290818C: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x02908190: LDR x0, [x22]              | X0 = typeof(System.Type);               
            // 0x02908194: LDR x8, [x8, #0x570]       | X8 = 1152921504616857600;               
            // 0x02908198: LDR x21, [x8]              | X21 = typeof(System.Collections.ObjectModel.ReadOnlyCollection<T>);
            // 0x0290819C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x029081A0: TBZ w8, #0, #0x29081b0     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x029081A4: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x029081A8: CBNZ w8, #0x29081b0        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x029081AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_5:
            // 0x029081B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x029081B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x029081B8: MOV x1, x21                | X1 = 1152921504616857600 (0x100000000098C000);//ML01
            // 0x029081BC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x029081C0: MOV x3, sp                 | X3 = 1152921513965812736 (0x100000022DD67C00);//ML01
            // 0x029081C4: MOV x1, x19                | X1 = populateList;//m1                  
            // 0x029081C8: MOV x2, x0                 | X2 = val_3;//m1                         
            System.Type val_4 = val_3;
            // 0x029081CC: BL #0x2912c04              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.InheritsGenericDefinition(type:  System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle()), genericClassDefinition:  val_46, implementingType: out  System.Type val_4 = val_3);
            bool val_5 = Newtonsoft.Json.Utilities.ReflectionUtils.InheritsGenericDefinition(type:  val_3, genericClassDefinition:  val_46, implementingType: out  val_4);
            // 0x029081D0: TBZ w0, #0, #0x290848c     | if (val_5 == false) goto label_6;       
            if(val_5 == false)
            {
                goto label_6;
            }
            // 0x029081D4: LDR x21, [sp]              | X21 = 0x0;                              
            // 0x029081D8: CBNZ x21, #0x29081e0       | if (0x0 != 0) goto label_7;             
            if(0 != 0)
            {
                goto label_7;
            }
            // 0x029081DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_7:
            // 0x029081E0: LDR x8, [x21]              | X8 = 0x10102464C457F;                   
            // 0x029081E4: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x029081E8: LDR x9, [x8, #0x720]       | X9 = mem[282584257678495];              
            // 0x029081EC: LDR x1, [x8, #0x728]       | X1 = mem[282584257678503];              
            // 0x029081F0: BLR x9                     | X0 = mem[282584257678495]();            
            // 0x029081F4: MOV x21, x0                | X21 = 0 (0x0);//ML01                    
            // 0x029081F8: CBNZ x21, #0x2908200       | if (0x0 != 0) goto label_8;             
            if(0 != 0)
            {
                goto label_8;
            }
            // 0x029081FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_8:
            // 0x02908200: LDR w8, [x21, #0x18]       | W8 = 0x9814C0;                          
            // 0x02908204: CBNZ w8, #0x2908214        | if (0x9814C0 != 0) goto label_9;        
            if(9966784 != 0)
            {
                goto label_9;
            }
            // 0x02908208: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x0290820C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02908210: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_9:
            // 0x02908214: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
            // 0x02908218: LDR x0, [x22]              | X0 = typeof(System.Type);               
            // 0x0290821C: LDR x22, [x21, #0x20]      | X22 = 0x40;                             
            // 0x02908220: LDR x8, [x8, #0xb08]       | X8 = 1152921504608391168;               
            // 0x02908224: LDR x21, [x8]              | X21 = typeof(System.Collections.Generic.IEnumerable<T>);
            // 0x02908228: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0290822C: TBZ w8, #0, #0x290823c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x02908230: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02908234: CBNZ w8, #0x290823c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x02908238: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_11:
            // 0x0290823C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02908240: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02908244: MOV x1, x21                | X1 = 1152921504608391168 (0x1000000000179000);//ML01
            // 0x02908248: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0290824C: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x02908250: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x02908254: MOV x21, x0                | X21 = val_6;//m1                        
            // 0x02908258: LDR x23, [x8]              | X23 = typeof(System.Type[]);            
            // 0x0290825C: MOV x0, x23                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x02908260: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x02908264: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x02908268: MOV x0, x23                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            val_49 = null;
            // 0x0290826C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x02908270: MOV x23, x0                | X23 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x02908274: CBNZ x23, #0x290827c       | if ( != null) goto label_12;            
            if(null != null)
            {
                goto label_12;
            }
            // 0x02908278: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_12:
            // 0x0290827C: CBZ x22, #0x29082a0        | if (0x40 == 0) goto label_14;           
            if(64 == 0)
            {
                goto label_14;
            }
            // 0x02908280: LDR x8, [x23]              | X8 = ;                                  
            // 0x02908284: MOV x0, x22                | X0 = 64 (0x40);//ML01                   
            val_49 = 64;
            // 0x02908288: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0290828C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x40, ????);       
            // 0x02908290: CBNZ x0, #0x29082a0        | if (0x40 != 0) goto label_14;           
            if(val_49 != 0)
            {
                goto label_14;
            }
            // 0x02908294: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 0x40, ????);       
            // 0x02908298: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0290829C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x40, ????);       
            label_14:
            // 0x029082A0: LDR w8, [x23, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x029082A4: CBNZ w8, #0x29082b4        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_15;
            // 0x029082A8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x40, ????);       
            // 0x029082AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029082B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x40, ????);       
            label_15:
            // 0x029082B4: MOV x1, x21                | X1 = val_6;//m1                         
            // 0x029082B8: MOV x2, x23                | X2 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            val_50 = val_49;
            // 0x029082BC: STR x22, [x23, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = 0x40;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = 64;
            // 0x029082C0: BL #0x28fe290              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.MakeGenericType(genericTypeDefinition:  val_49 = 64, innerTypes:  val_6);
            System.Type val_7 = Newtonsoft.Json.Utilities.ReflectionUtils.MakeGenericType(genericTypeDefinition:  val_49, innerTypes:  val_6);
            // 0x029082C4: MOV x21, x0                | X21 = val_7;//m1                        
            // 0x029082C8: CBNZ x19, #0x29082d0       | if (populateList != null) goto label_16;
            if(val_46 != null)
            {
                goto label_16;
            }
            // 0x029082CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_16:
            // 0x029082D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029082D4: MOV x0, x19                | X0 = populateList;//m1                  
            // 0x029082D8: BL #0x1b6ea28              | X0 = populateList.GetConstructors();    
            System.Reflection.ConstructorInfo[] val_8 = val_46.GetConstructors();
            // 0x029082DC: ADRP x26, #0x367f000       | X26 = 57143296 (0x367F000);             
            // 0x029082E0: ADRP x27, #0x3634000       | X27 = 56836096 (0x3634000);             
            // 0x029082E4: LDR x26, [x26, #0x400]     | X26 = 1152921504609456128;              
            // 0x029082E8: LDR x27, [x27, #0x110]     | X27 = 1152921504609402880;              
            // 0x029082EC: MOV x23, x0                | X23 = val_8;//m1                        
            val_51 = val_8;
            // 0x029082F0: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            val_52 = 0;
            // 0x029082F4: B #0x29082fc               |  goto label_17;                         
            goto label_17;
            label_35:
            // 0x029082F8: ADD w25, w25, #1           | W25 = (val_52 + 1) = val_52 (0x00000001);
            val_52 = 1;
            label_17:
            // 0x029082FC: CBNZ x23, #0x2908304       | if (val_8 != null) goto label_18;       
            if(val_51 != null)
            {
                goto label_18;
            }
            // 0x02908300: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_18:
            // 0x02908304: LDR w8, [x23, #0x18]       | W8 = val_8.Length; //P2                 
            // 0x02908308: CMP w25, w8                | STATE = COMPARE(0x1, val_8.Length)      
            // 0x0290830C: B.GE #0x290897c            | if (val_52 >= val_8.Length) goto label_19;
            if(val_52 >= val_8.Length)
            {
                goto label_19;
            }
            // 0x02908310: SXTW x24, w25              | X24 = 1 (0x00000001);                   
            // 0x02908314: CMP w25, w8                | STATE = COMPARE(0x1, val_8.Length)      
            // 0x02908318: B.LO #0x2908328            | if (val_52 < val_8.Length) goto label_20;
            if(val_52 < val_8.Length)
            {
                goto label_20;
            }
            // 0x0290831C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_8, ????);      
            // 0x02908320: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02908324: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            label_20:
            // 0x02908328: ADD x8, x23, x24, lsl #3   | X8 = val_8[0x1]; //PARR1                
            // 0x0290832C: LDR x24, [x8, #0x20]       | X24 = val_8[0x1][0]                     
            System.Reflection.ConstructorInfo val_45 = val_51[1];
            // 0x02908330: CBNZ x24, #0x2908338       | if (val_8[0x1][0] != null) goto label_21;
            if(val_45 != null)
            {
                goto label_21;
            }
            // 0x02908334: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_21:
            // 0x02908338: LDR x8, [x24]              | X8 = typeof(System.Reflection.ConstructorInfo);
            // 0x0290833C: MOV x0, x24                | X0 = val_8[0x1][0];//m1                 
            // 0x02908340: LDR x9, [x8, #0x200]       | X9 = typeof(System.Reflection.ConstructorInfo).__il2cppRuntimeField_200;
            // 0x02908344: LDR x1, [x8, #0x208]       | X1 = typeof(System.Reflection.ConstructorInfo).__il2cppRuntimeField_208;
            // 0x02908348: BLR x9                     | X0 = typeof(System.Reflection.ConstructorInfo).__il2cppRuntimeField_200();
            // 0x0290834C: MOV x24, x0                | X24 = val_8[0x1][0];//m1                
            // 0x02908350: CBNZ x24, #0x2908358       | if (val_8[0x1][0] != null) goto label_22;
            if(val_45 != null)
            {
                goto label_22;
            }
            // 0x02908354: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8[0x1][0], ????);
            label_22:
            // 0x02908358: LDR x8, [x24]              | X8 = typeof(System.Reflection.ConstructorInfo);
            // 0x0290835C: LDR x1, [x26]              | X1 = typeof(System.Collections.Generic.ICollection<T>);
            // 0x02908360: LDRH w9, [x8, #0x102]      | W9 = System.Reflection.ConstructorInfo.__il2cppRuntimeField_interface_offsets_count;
            // 0x02908364: CBZ x9, #0x2908390         | if (System.Reflection.ConstructorInfo.__il2cppRuntimeField_interface_offsets_count == 0) goto label_23;
            // 0x02908368: LDR x10, [x8, #0x98]       | X10 = System.Reflection.ConstructorInfo.__il2cppRuntimeField_interfaceOffsets;
            // 0x0290836C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_46 = 0;
            // 0x02908370: ADD x10, x10, #8           | X10 = (System.Reflection.ConstructorInfo.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504626638856 (0x10000000012E0008);
            label_25:
            // 0x02908374: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x02908378: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.Generic.ICollection<T>))
            // 0x0290837C: B.EQ #0x29083a0            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_24;
            // 0x02908380: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_46 = val_46 + 1;
            // 0x02908384: ADD x10, x10, #0x10        | X10 = (1152921504626638856 + 16) = 1152921504626638872 (0x10000000012E0018);
            // 0x02908388: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Reflection.ConstructorInfo.__il2cppRuntimeField_interface_offsets_count)
            // 0x0290838C: B.LO #0x2908374            | if (0 < System.Reflection.ConstructorInfo.__il2cppRuntimeField_interface_offsets_count) goto label_25;
            label_23:
            // 0x02908390: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            val_50 = 0;
            // 0x02908394: MOV x0, x24                | X0 = val_8[0x1][0];//m1                 
            val_53 = val_45;
            // 0x02908398: BL #0x2776c24              | X0 = sub_2776C24( ?? val_8[0x1][0], ????);
            // 0x0290839C: B #0x29083ac               |  goto label_26;                         
            goto label_26;
            label_24:
            // 0x029083A0: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x029083A4: ADD x8, x8, x9, lsl #4     | X8 = (1152921504626601984 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x029083A8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504626601984 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_26:
            // 0x029083AC: LDP x8, x1, [x0]           | X8 = typeof(System.Reflection.ConstructorInfo);  //  | 
            // 0x029083B0: MOV x0, x24                | X0 = val_8[0x1][0];//m1                 
            // 0x029083B4: BLR x8                     | X0 = sub_10000000012D7000( ?? val_8[0x1][0], ????);
            // 0x029083B8: CMP w0, #1                 | STATE = COMPARE(val_8[0x1][0], 0x1)     
            // 0x029083BC: B.NE #0x29082f8            | if (val_51[1] != 0x1) goto label_35;    
            if(val_45 != 1)
            {
                goto label_35;
            }
            // 0x029083C0: CBNZ x24, #0x29083c8       | if (val_8[0x1][0] != null) goto label_28;
            if(val_45 != null)
            {
                goto label_28;
            }
            // 0x029083C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8[0x1][0], ????);
            label_28:
            // 0x029083C8: LDR x8, [x24]              | X8 = typeof(System.Reflection.ConstructorInfo);
            // 0x029083CC: LDR x1, [x27]              | X1 = typeof(System.Collections.Generic.IList<T>);
            // 0x029083D0: LDRH w9, [x8, #0x102]      | W9 = System.Reflection.ConstructorInfo.__il2cppRuntimeField_interface_offsets_count;
            // 0x029083D4: CBZ x9, #0x2908400         | if (System.Reflection.ConstructorInfo.__il2cppRuntimeField_interface_offsets_count == 0) goto label_29;
            // 0x029083D8: LDR x10, [x8, #0x98]       | X10 = System.Reflection.ConstructorInfo.__il2cppRuntimeField_interfaceOffsets;
            // 0x029083DC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_47 = 0;
            // 0x029083E0: ADD x10, x10, #8           | X10 = (System.Reflection.ConstructorInfo.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504626638856 (0x10000000012E0008);
            label_31:
            // 0x029083E4: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x029083E8: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.Generic.IList<T>))
            // 0x029083EC: B.EQ #0x2908410            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_30;
            // 0x029083F0: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_47 = val_47 + 1;
            // 0x029083F4: ADD x10, x10, #0x10        | X10 = (1152921504626638856 + 16) = 1152921504626638872 (0x10000000012E0018);
            // 0x029083F8: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Reflection.ConstructorInfo.__il2cppRuntimeField_interface_offsets_count)
            // 0x029083FC: B.LO #0x29083e4            | if (0 < System.Reflection.ConstructorInfo.__il2cppRuntimeField_interface_offsets_count) goto label_31;
            label_29:
            // 0x02908400: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            val_50 = 3;
            // 0x02908404: MOV x0, x24                | X0 = val_8[0x1][0];//m1                 
            val_54 = val_45;
            // 0x02908408: BL #0x2776c24              | X0 = sub_2776C24( ?? val_8[0x1][0], ????);
            // 0x0290840C: B #0x2908420               |  goto label_32;                         
            goto label_32;
            label_30:
            // 0x02908410: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x02908414: ADD w9, w9, #3             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3);
            // 0x02908418: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504626601984 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3));
            // 0x0290841C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504626601984 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3)).272
            label_32:
            // 0x02908420: LDP x8, x2, [x0]           | X8 = typeof(System.Reflection.ConstructorInfo);  //  | 
            // 0x02908424: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x02908428: MOV x0, x24                | X0 = val_8[0x1][0];//m1                 
            // 0x0290842C: BLR x8                     | X0 = sub_10000000012D7000( ?? val_8[0x1][0], ????);
            // 0x02908430: MOV x24, x0                | X24 = val_8[0x1][0];//m1                
            // 0x02908434: CBNZ x24, #0x290843c       | if (val_8[0x1][0] != null) goto label_33;
            if(val_45 != null)
            {
                goto label_33;
            }
            // 0x02908438: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8[0x1][0], ????);
            label_33:
            // 0x0290843C: LDR x8, [x24]              | X8 = typeof(System.Reflection.ConstructorInfo);
            // 0x02908440: MOV x0, x24                | X0 = val_8[0x1][0];//m1                 
            // 0x02908444: LDP x9, x1, [x8, #0x170]   | X9 = typeof(System.Reflection.ConstructorInfo).__il2cppRuntimeField_170; X1 = typeof(System.Reflection.ConstructorInfo).__il2cppRuntimeField_178; //  | 
            // 0x02908448: BLR x9                     | X0 = typeof(System.Reflection.ConstructorInfo).__il2cppRuntimeField_170();
            // 0x0290844C: MOV x24, x0                | X24 = val_8[0x1][0];//m1                
            // 0x02908450: CBNZ x21, #0x2908458       | if (val_7 != null) goto label_34;       
            if(val_7 != null)
            {
                goto label_34;
            }
            // 0x02908454: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8[0x1][0], ????);
            label_34:
            // 0x02908458: LDR x8, [x21]              | X8 = typeof(System.Type);               
            // 0x0290845C: MOV x0, x21                | X0 = val_7;//m1                         
            // 0x02908460: MOV x1, x24                | X1 = val_8[0x1][0];//m1                 
            // 0x02908464: LDR x9, [x8, #0x3e0]       | X9 = typeof(System.Type).__il2cppRuntimeField_3E0;
            // 0x02908468: LDR x2, [x8, #0x3e8]       | X2 = typeof(System.Type).__il2cppRuntimeField_3E8;
            // 0x0290846C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_3E0();
            // 0x02908470: AND w8, w0, #1             | W8 = (val_7 & 1);                       
            System.Type val_11 = val_7 & 1;
            // 0x02908474: TBZ w8, #0, #0x29082f8     | if (((val_7 & 1) & 0x1) == 0) goto label_35;
            if((val_11 & 1) == 0)
            {
                goto label_35;
            }
            // 0x02908478: MOV x1, x22                | X1 = 64 (0x40);//ML01                   
            // 0x0290847C: BL #0x2911e40              | X0 = Newtonsoft.Json.Utilities.CollectionUtils.CreateGenericList(listType:  val_7);
            System.Collections.IList val_12 = Newtonsoft.Json.Utilities.CollectionUtils.CreateGenericList(listType:  val_7);
            // 0x02908480: MOV x21, x0                | X21 = val_12;//m1                       
            val_47 = val_12;
            // 0x02908484: ORR w22, wzr, #1           | W22 = 1(0x1);                           
            val_48 = 1;
            // 0x02908488: B #0x2908608               |  goto label_36;                         
            goto label_36;
            label_6:
            // 0x0290848C: ADRP x23, #0x3657000       | X23 = 56979456 (0x3657000);             
            // 0x02908490: LDR x0, [x22]              | X0 = typeof(System.Type);               
            // 0x02908494: LDR x23, [x23, #0x9a0]     | X23 = 1152921504609349632;              
            val_51 = 1152921504609349632;
            // 0x02908498: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0290849C: LDR x21, [x23]             | X21 = typeof(System.Collections.IList); 
            // 0x029084A0: TBZ w8, #0, #0x29084b0     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_38;
            // 0x029084A4: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x029084A8: CBNZ w8, #0x29084b0        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_38;
            // 0x029084AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_38:
            // 0x029084B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x029084B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x029084B8: MOV x1, x21                | X1 = 1152921504609349632 (0x1000000000263000);//ML01
            // 0x029084BC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_13 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x029084C0: MOV x21, x0                | X21 = val_13;//m1                       
            // 0x029084C4: CBNZ x21, #0x29084cc       | if (val_13 != null) goto label_39;      
            if(val_13 != null)
            {
                goto label_39;
            }
            // 0x029084C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_39:
            // 0x029084CC: LDR x8, [x21]              | X8 = typeof(System.Type);               
            // 0x029084D0: MOV x0, x21                | X0 = val_13;//m1                        
            // 0x029084D4: MOV x1, x19                | X1 = populateList;//m1                  
            // 0x029084D8: LDR x9, [x8, #0x3e0]       | X9 = typeof(System.Type).__il2cppRuntimeField_3E0;
            // 0x029084DC: LDR x2, [x8, #0x3e8]       | X2 = typeof(System.Type).__il2cppRuntimeField_3E8;
            // 0x029084E0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_3E0();
            // 0x029084E4: TBZ w0, #0, #0x2908534     | if ((val_13 & 0x1) == 0) goto label_40; 
            if((val_13 & 1) == 0)
            {
                goto label_40;
            }
            // 0x029084E8: MOV x1, x19                | X1 = populateList;//m1                  
            // 0x029084EC: BL #0x2912db4              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.IsInstantiatableType(t:  val_13);
            bool val_14 = Newtonsoft.Json.Utilities.ReflectionUtils.IsInstantiatableType(t:  val_13);
            // 0x029084F0: TBZ w0, #0, #0x29085ac     | if (val_14 == false) goto label_41;     
            if(val_14 == false)
            {
                goto label_41;
            }
            // 0x029084F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x029084F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x029084FC: MOV x1, x19                | X1 = populateList;//m1                  
            // 0x02908500: BL #0x18c8eb0              | X0 = System.Activator.CreateInstance(type:  0);
            object val_15 = System.Activator.CreateInstance(type:  0);
            // 0x02908504: MOV x22, x0                | X22 = val_15;//m1                       
            // 0x02908508: CBZ x22, #0x2908b08        | if (val_15 == null) goto label_53;      
            if(val_15 == null)
            {
                goto label_53;
            }
            // 0x0290850C: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x02908510: LDR x8, [x8, #0x308]       | X8 = 1152921504609349632;               
            // 0x02908514: MOV x0, x22                | X0 = val_15;//m1                        
            // 0x02908518: LDR x23, [x8]              | X23 = typeof(System.Collections.IList); 
            val_51 = null;
            // 0x0290851C: MOV x1, x23                | X1 = 1152921504609349632 (0x1000000000263000);//ML01
            // 0x02908520: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_15, ????);     
            // 0x02908524: MOV x21, x0                | X21 = val_15;//m1                       
            val_47 = val_15;
            // 0x02908528: CBZ x21, #0x2908adc        | if (val_15 == null) goto label_43;      
            if(val_47 == null)
            {
                goto label_43;
            }
            // 0x0290852C: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_48 = 0;
            // 0x02908530: B #0x290860c               |  goto label_44;                         
            goto label_44;
            label_40:
            // 0x02908534: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x02908538: LDR x0, [x22]              | X0 = typeof(System.Type);               
            // 0x0290853C: LDR x8, [x8, #0x790]       | X8 = 1152921504609456128;               
            // 0x02908540: LDR x21, [x8]              | X21 = typeof(System.Collections.Generic.ICollection<T>);
            // 0x02908544: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x02908548: TBZ w8, #0, #0x2908558     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_46;
            // 0x0290854C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02908550: CBNZ w8, #0x2908558        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_46;
            // 0x02908554: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_46:
            // 0x02908558: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0290855C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02908560: MOV x1, x21                | X1 = 1152921504609456128 (0x100000000027D000);//ML01
            // 0x02908564: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_16 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x02908568: ADD x3, sp, #0x20          | X3 = (1152921513965812736 + 32) = 1152921513965812768 (0x100000022DD67C20);
            // 0x0290856C: MOV x1, x19                | X1 = populateList;//m1                  
            // 0x02908570: MOV x2, x0                 | X2 = val_16;//m1                        
            System.Type val_17 = val_16;
            // 0x02908574: STR xzr, [sp, #0x20]       | stack[1152921513965812768] = 0x0;        //  dest_result_addr=1152921513965812768
            // 0x02908578: BL #0x28fdaec              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  System.Type val_16 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle()), genericInterfaceDefinition:  val_46, implementingType: out  System.Type val_17 = val_16);
            bool val_18 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  val_16, genericInterfaceDefinition:  val_46, implementingType: out  val_17);
            // 0x0290857C: TBZ w0, #0, #0x2908b08     | if (val_18 == false) goto label_53;     
            if(val_18 == false)
            {
                goto label_53;
            }
            // 0x02908580: MOV x1, x19                | X1 = populateList;//m1                  
            // 0x02908584: BL #0x2912db4              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.IsInstantiatableType(t:  bool val_18 = Newtonsoft.Json.Utilities.ReflectionUtils.ImplementsGenericDefinition(type:  val_16, genericInterfaceDefinition:  val_46, implementingType: out  val_17));
            bool val_19 = Newtonsoft.Json.Utilities.ReflectionUtils.IsInstantiatableType(t:  val_18);
            // 0x02908588: TBZ w0, #0, #0x2908b08     | if (val_19 == false) goto label_53;     
            if(val_19 == false)
            {
                goto label_53;
            }
            // 0x0290858C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02908590: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02908594: MOV x1, x19                | X1 = populateList;//m1                  
            // 0x02908598: BL #0x18c8eb0              | X0 = System.Activator.CreateInstance(type:  0);
            object val_20 = System.Activator.CreateInstance(type:  0);
            // 0x0290859C: MOV x1, x0                 | X1 = val_20;//m1                        
            // 0x029085A0: BL #0x2901914              | X0 = Newtonsoft.Json.Utilities.CollectionUtils.CreateCollectionWrapper(list:  object val_20 = System.Activator.CreateInstance(type:  0));
            Newtonsoft.Json.Utilities.IWrappedCollection val_21 = Newtonsoft.Json.Utilities.CollectionUtils.CreateCollectionWrapper(list:  val_20);
            // 0x029085A4: MOV x21, x0                | X21 = val_21;//m1                       
            val_47 = val_21;
            // 0x029085A8: B #0x2908604               |  goto label_49;                         
            goto label_49;
            label_41:
            // 0x029085AC: LDR x0, [x22]              | X0 = typeof(System.Type);               
            // 0x029085B0: LDR x21, [x23]             | X21 = typeof(System.Collections.IList); 
            // 0x029085B4: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x029085B8: TBZ w8, #0, #0x29085c8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_51;
            // 0x029085BC: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x029085C0: CBNZ w8, #0x29085c8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_51;
            // 0x029085C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_51:
            // 0x029085C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x029085CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x029085D0: MOV x1, x21                | X1 = 1152921504609349632 (0x1000000000263000);//ML01
            // 0x029085D4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_22 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x029085D8: CMP x0, x19                | STATE = COMPARE(val_22, populateList)   
            // 0x029085DC: B.NE #0x2908b08            | if (val_22 != val_46) goto label_53;    
            if(val_22 != val_46)
            {
                goto label_53;
            }
            // 0x029085E0: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x029085E4: LDR x8, [x8, #0x7a0]       | X8 = 1152921504616644608;               
            // 0x029085E8: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.Object> val_23 = null;
            // 0x029085EC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x029085F0: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
            // 0x029085F4: LDR x8, [x8, #0xca0]       | X8 = 1152921509744601424;               
            // 0x029085F8: MOV x21, x0                | X21 = 1152921504616644608 (0x1000000000958000);//ML01
            val_47 = val_23;
            // 0x029085FC: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.Object>::.ctor();
            // 0x02908600: BL #0x25e9474              | .ctor();                                
            val_23 = new System.Collections.Generic.List<System.Object>();
            label_49:
            // 0x02908604: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_48 = 0;
            label_36:
            // 0x02908608: CBZ x21, #0x2908b08        | if ( == 0) goto label_53;               
            if(null == 0)
            {
                goto label_53;
            }
            label_44:
            // 0x0290860C: CBNZ x20, #0x2908614       | if (X2 != 0) goto label_54;             
            if(X2 != 0)
            {
                goto label_54;
            }
            // 0x02908610: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_54:
            // 0x02908614: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x02908618: LDR x8, [x8, #0xc18]       | X8 = 1152921513965728800;               
            // 0x0290861C: MOV x0, x20                | X0 = X2;//m1                            
            // 0x02908620: MOV x1, x21                | X1 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x02908624: MOV w2, w22                | W2 = 0 (0x0);//ML01                     
            // 0x02908628: LDR x3, [x8]               | X3 = public System.Void System.Action<System.Collections.IList, System.Boolean>::Invoke(System.Collections.IList arg1, System.Boolean arg2);
            // 0x0290862C: BL #0x12a27dc              | X2.Invoke(arg1:  val_47, arg2:  false); 
            X2.Invoke(arg1:  val_47, arg2:  false);
            // 0x02908630: CBZ w22, #0x290872c        | if (0x0 == 0) goto label_55;            
            if(val_48 == 0)
            {
                goto label_55;
            }
            // 0x02908634: CBNZ x19, #0x290863c       | if (populateList != null) goto label_56;
            if(val_46 != null)
            {
                goto label_56;
            }
            // 0x02908638: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X2, ????);         
            label_56:
            // 0x0290863C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02908640: MOV x0, x19                | X0 = populateList;//m1                  
            // 0x02908644: BL #0x1b6d1cc              | X0 = populateList.get_IsArray();        
            bool val_24 = val_46.IsArray;
            // 0x02908648: TBZ w0, #0, #0x2908818     | if (val_24 == false) goto label_57;     
            if(val_24 == false)
            {
                goto label_57;
            }
            // 0x0290864C: ADRP x20, #0x35c4000       | X20 = 56377344 (0x35C4000);             
            // 0x02908650: LDR x20, [x20, #0x7a0]     | X20 = 1152921504616644608;              
            // 0x02908654: LDR x8, [x21]              | X8 = ;                                  
            // 0x02908658: LDR x1, [x20]              | X1 = typeof(System.Collections.Generic.List<T>);
            // 0x0290865C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x02908660: LDRB w9, [x1, #0x104]      | W9 = System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x02908664: CMP w10, w9                | STATE = COMPARE(mem[null + 260], System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x02908668: B.LO #0x2908680            | if (mem[null + 260] < System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth) goto label_58;
            // 0x0290866C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x02908670: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x02908674: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x02908678: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Collections.Generic.List<T>))
            // 0x0290867C: B.EQ #0x29086a8            | if ((mem[null + 176] + (System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_59;
            label_58:
            // 0x02908680: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x02908684: ADD x8, sp, #0x10          | X8 = (1152921513965812736 + 16) = 1152921513965812752 (0x100000022DD67C10);
            // 0x02908688: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x0290868C: LDR x0, [sp, #0x10]        | X0 = val_26;                             //  find_add[1152921513965800896]
            // 0x02908690: BL #0x27af090              | X0 = sub_27AF090( ?? val_26, ????);     
            // 0x02908694: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02908698: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_26, ????);     
            // 0x0290869C: ADD x0, sp, #0x10          | X0 = (1152921513965812736 + 16) = 1152921513965812752 (0x100000022DD67C10);
            // 0x029086A0: BL #0x299a140              | 
            // 0x029086A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000022DD67C10, ????);
            label_59:
            // 0x029086A8: LDR x8, [x21]              | X8 = ;                                  
            // 0x029086AC: LDR x1, [x20]              | X1 = typeof(System.Collections.Generic.List<T>);
            // 0x029086B0: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x029086B4: LDRB w9, [x1, #0x104]      | W9 = System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x029086B8: CMP w10, w9                | STATE = COMPARE(mem[null + 260], System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x029086BC: B.LO #0x29086d4            | if (mem[null + 260] < System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth) goto label_60;
            // 0x029086C0: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x029086C4: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x029086C8: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x029086CC: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Collections.Generic.List<T>))
            // 0x029086D0: B.EQ #0x29086fc            | if ((mem[null + 176] + (System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_61;
            label_60:
            // 0x029086D4: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x029086D8: ADD x8, sp, #0x18          | X8 = (1152921513965812736 + 24) = 1152921513965812760 (0x100000022DD67C18);
            // 0x029086DC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x029086E0: LDR x0, [sp, #0x18]        | X0 = val_28;                             //  find_add[1152921513965800896]
            // 0x029086E4: BL #0x27af090              | X0 = sub_27AF090( ?? val_28, ????);     
            // 0x029086E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029086EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_28, ????);     
            // 0x029086F0: ADD x0, sp, #0x18          | X0 = (1152921513965812736 + 24) = 1152921513965812760 (0x100000022DD67C18);
            // 0x029086F4: BL #0x299a140              | 
            // 0x029086F8: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_55 = 0;
            label_61:
            // 0x029086FC: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
            // 0x02908700: LDR x8, [x8, #0x270]       | X8 = 1152921509746127168;               
            // 0x02908704: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x02908708: LDR x1, [x8]               | X1 = public T[] System.Collections.Generic.List<System.Object>::ToArray();
            // 0x0290870C: BL #0x25ed474              | X0 = val_55.ToArray();                  
            T[] val_29 = val_55.ToArray();
            // 0x02908710: MOV x1, x19                | X1 = populateList;//m1                  
            // 0x02908714: MOV x20, x0                | X20 = val_29;//m1                       
            // 0x02908718: BL #0x28fddb8              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.GetCollectionItemType(type:  T[] val_29 = val_55.ToArray());
            System.Type val_30 = Newtonsoft.Json.Utilities.ReflectionUtils.GetCollectionItemType(type:  val_29);
            // 0x0290871C: MOV x1, x20                | X1 = val_29;//m1                        
            // 0x02908720: MOV x2, x0                 | X2 = val_30;//m1                        
            // 0x02908724: BL #0x2912edc              | X0 = Newtonsoft.Json.Utilities.CollectionUtils.ToArray(initial:  System.Type val_30 = Newtonsoft.Json.Utilities.ReflectionUtils.GetCollectionItemType(type:  val_29), type:  val_29);
            System.Array val_31 = Newtonsoft.Json.Utilities.CollectionUtils.ToArray(initial:  val_30, type:  val_29);
            // 0x02908728: B #0x2908954               |  goto label_62;                         
            goto label_62;
            label_55:
            // 0x0290872C: ADRP x20, #0x367d000       | X20 = 57135104 (0x367D000);             
            // 0x02908730: LDR x20, [x20, #0xe78]     | X20 = 1152921504866963456;              
            // 0x02908734: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x02908738: LDR x1, [x20]              | X1 = typeof(Newtonsoft.Json.Utilities.IWrappedCollection);
            // 0x0290873C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x02908740: CBZ x0, #0x2908958         | if ( == 0) goto label_79;               
            if(null == 0)
            {
                goto label_79;
            }
            // 0x02908744: LDR x19, [x20]             | X19 = typeof(Newtonsoft.Json.Utilities.IWrappedCollection);
            // 0x02908748: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x0290874C: MOV x1, x19                | X1 = 1152921504866963456 (0x100000000F811000);//ML01
            // 0x02908750: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x02908754: CBNZ x0, #0x2908788        | if ( != 0) goto label_64;               
            if(null != 0)
            {
                goto label_64;
            }
            // 0x02908758: LDR x8, [x21]              | X8 = ;                                  
            // 0x0290875C: MOV x1, x19                | X1 = 1152921504866963456 (0x100000000F811000);//ML01
            // 0x02908760: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x02908764: ADD x8, sp, #0x30          | X8 = (1152921513965812736 + 48) = 1152921513965812784 (0x100000022DD67C30);
            // 0x02908768: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x0290876C: LDR x0, [sp, #0x30]        | X0 = val_32;                             //  find_add[1152921513965800896]
            // 0x02908770: BL #0x27af090              | X0 = sub_27AF090( ?? val_32, ????);     
            // 0x02908774: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02908778: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_32, ????);     
            // 0x0290877C: ADD x0, sp, #0x30          | X0 = (1152921513965812736 + 48) = 1152921513965812784 (0x100000022DD67C30);
            // 0x02908780: BL #0x299a140              | 
            // 0x02908784: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000022DD67C30, ????);
            label_64:
            // 0x02908788: LDR x19, [x20]             | X19 = typeof(Newtonsoft.Json.Utilities.IWrappedCollection);
            val_46 = null;
            // 0x0290878C: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x02908790: MOV x1, x19                | X1 = 1152921504866963456 (0x100000000F811000);//ML01
            val_57 = val_46;
            // 0x02908794: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x02908798: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
            val_58 = val_47;
            // 0x0290879C: CBNZ x20, #0x29087d0       | if ( != 0) goto label_65;               
            if(null != 0)
            {
                goto label_65;
            }
            // 0x029087A0: LDR x8, [x21]              | X8 = ;                                  
            // 0x029087A4: MOV x1, x19                | X1 = 1152921504866963456 (0x100000000F811000);//ML01
            // 0x029087A8: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x029087AC: ADD x8, sp, #0x38          | X8 = (1152921513965812736 + 56) = 1152921513965812792 (0x100000022DD67C38);
            // 0x029087B0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x029087B4: LDR x0, [sp, #0x38]        | X0 = val_33;                             //  find_add[1152921513965800896]
            // 0x029087B8: BL #0x27af090              | X0 = sub_27AF090( ?? val_33, ????);     
            // 0x029087BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_57 = 0;
            // 0x029087C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_33, ????);     
            // 0x029087C4: ADD x0, sp, #0x38          | X0 = (1152921513965812736 + 56) = 1152921513965812792 (0x100000022DD67C38);
            // 0x029087C8: BL #0x299a140              | 
            // 0x029087CC: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_58 = 0;
            label_65:
            // 0x029087D0: LDR x8, [x20]              | X8 = 0x10102464C457F;                   
            // 0x029087D4: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x029087D8: CBZ x9, #0x2908804         | if (mem[282584257676929] == 0) goto label_66;
            if(mem[282584257676929] == 0)
            {
                goto label_66;
            }
            // 0x029087DC: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_48 = mem[282584257676823];
            // 0x029087E0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_49 = 0;
            // 0x029087E4: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_48 = val_48 + 8;
            label_68:
            // 0x029087E8: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x029087EC: CMP x12, x19               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(Newtonsoft.Json.Utilities.IWrappedCollection))
            // 0x029087F0: B.EQ #0x290893c            | if ((mem[282584257676823] + 8) + -8 == val_46) goto label_67;
            if(((mem[282584257676823] + 8) + -8) == val_46)
            {
                goto label_67;
            }
            // 0x029087F4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_49 = val_49 + 1;
            // 0x029087F8: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_48 = val_48 + 16;
            // 0x029087FC: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x02908800: B.LO #0x29087e8            | if (0 < mem[282584257676929]) goto label_68;
            if(val_49 < mem[282584257676929])
            {
                goto label_68;
            }
            label_66:
            // 0x02908804: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x02908808: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            val_59 = val_58;
            // 0x0290880C: MOV x1, x19                | X1 = 1152921504866963456 (0x100000000F811000);//ML01
            val_57 = val_46;
            // 0x02908810: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x02908814: B #0x2908948               |  goto label_69;                         
            goto label_69;
            label_57:
            // 0x02908818: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0290881C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x02908820: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x02908824: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x02908828: LDR x8, [x8, #0x570]       | X8 = 1152921504616857600;               
            // 0x0290882C: LDR x20, [x8]              | X20 = typeof(System.Collections.ObjectModel.ReadOnlyCollection<T>);
            // 0x02908830: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x02908834: TBZ w8, #0, #0x2908844     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_71;
            // 0x02908838: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0290883C: CBNZ w8, #0x2908844        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_71;
            // 0x02908840: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_71:
            // 0x02908844: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02908848: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0290884C: MOV x1, x20                | X1 = 1152921504616857600 (0x100000000098C000);//ML01
            // 0x02908850: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_34 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x02908854: ADD x3, sp, #0x20          | X3 = (1152921513965812736 + 32) = 1152921513965812768 (0x100000022DD67C20);
            // 0x02908858: MOV x1, x19                | X1 = populateList;//m1                  
            // 0x0290885C: MOV x2, x0                 | X2 = val_34;//m1                        
            System.Type val_35 = val_34;
            // 0x02908860: STR xzr, [sp, #0x20]       | stack[1152921513965812768] = 0x0;        //  dest_result_addr=1152921513965812768
            // 0x02908864: BL #0x2912c04              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.InheritsGenericDefinition(type:  System.Type val_34 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle()), genericClassDefinition:  val_46, implementingType: out  System.Type val_35 = val_34);
            bool val_36 = Newtonsoft.Json.Utilities.ReflectionUtils.InheritsGenericDefinition(type:  val_34, genericClassDefinition:  val_46, implementingType: out  val_35);
            // 0x02908868: TBZ w0, #0, #0x2908958     | if (val_36 == false) goto label_79;     
            if(val_36 == false)
            {
                goto label_79;
            }
            // 0x0290886C: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x02908870: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x02908874: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
            // 0x02908878: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x0290887C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x02908880: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x02908884: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            val_60 = null;
            // 0x02908888: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x0290888C: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02908890: CBNZ x20, #0x2908898       | if ( != null) goto label_73;            
            if(null != null)
            {
                goto label_73;
            }
            // 0x02908894: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_73:
            // 0x02908898: CBZ x21, #0x29088bc        | if ( == 0) goto label_75;               
            if(null == 0)
            {
                goto label_75;
            }
            // 0x0290889C: LDR x8, [x20]              | X8 = ;                                  
            // 0x029088A0: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            val_60 = val_47;
            // 0x029088A4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x029088A8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x029088AC: CBNZ x0, #0x29088bc        | if ( != 0) goto label_75;               
            if(null != 0)
            {
                goto label_75;
            }
            // 0x029088B0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x029088B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029088B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Collections.Generic.List<T>), ????);
            label_75:
            // 0x029088BC: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x029088C0: CBNZ w8, #0x29088d0        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_76;
            // 0x029088C4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x029088C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029088CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Collections.Generic.List<T>), ????);
            label_76:
            // 0x029088D0: MOV x1, x19                | X1 = populateList;//m1                  
            // 0x029088D4: MOV x2, x20                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x029088D8: STR x21, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = val_47;
            // 0x029088DC: BL #0x2912fd0              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.CreateInstance(type:  val_60 = val_47, args:  val_46);
            object val_37 = Newtonsoft.Json.Utilities.ReflectionUtils.CreateInstance(type:  val_60, args:  val_46);
            // 0x029088E0: MOV x20, x0                | X20 = val_37;//m1                       
            // 0x029088E4: CBZ x20, #0x2908934        | if (val_37 == null) goto label_77;      
            if(val_37 == null)
            {
                goto label_77;
            }
            // 0x029088E8: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x029088EC: LDR x8, [x8, #0x308]       | X8 = 1152921504609349632;               
            // 0x029088F0: MOV x0, x20                | X0 = val_37;//m1                        
            // 0x029088F4: LDR x19, [x8]              | X19 = typeof(System.Collections.IList); 
            val_46 = null;
            // 0x029088F8: MOV x1, x19                | X1 = 1152921504609349632 (0x1000000000263000);//ML01
            // 0x029088FC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_37, ????);     
            // 0x02908900: MOV x21, x0                | X21 = val_37;//m1                       
            val_61 = val_37;
            // 0x02908904: CBNZ x21, #0x2908958       | if (val_37 != null) goto label_79;      
            if(val_61 != null)
            {
                goto label_79;
            }
            // 0x02908908: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x0290890C: MOV x1, x19                | X1 = 1152921504609349632 (0x1000000000263000);//ML01
            // 0x02908910: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x02908914: ADD x8, sp, #0x28          | X8 = (1152921513965812736 + 40) = 1152921513965812776 (0x100000022DD67C28);
            // 0x02908918: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0290891C: LDR x0, [sp, #0x28]        | X0 = val_38;                             //  find_add[1152921513965800896]
            // 0x02908920: BL #0x27af090              | X0 = sub_27AF090( ?? val_38, ????);     
            // 0x02908924: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02908928: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_38, ????);     
            // 0x0290892C: ADD x0, sp, #0x28          | X0 = (1152921513965812736 + 40) = 1152921513965812776 (0x100000022DD67C28);
            // 0x02908930: BL #0x299a140              | 
            label_77:
            // 0x02908934: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_61 = 0;
            // 0x02908938: B #0x2908958               |  goto label_79;                         
            goto label_79;
            label_67:
            // 0x0290893C: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            // 0x02908940: ADD x8, x8, x9, lsl #4     | X8 = (val_58 + ((mem[282584257676823] + 8)) << 4);
            val_58 = val_58 + (((mem[282584257676823] + 8)) << 4);
            // 0x02908944: ADD x0, x8, #0x110         | X0 = ((val_58 + ((mem[282584257676823] + 8)) << 4) + 272);
            val_59 = val_58 + 272;
            label_69:
            // 0x02908948: LDP x8, x1, [x0]           | X8 = ((val_58 + ((mem[282584257676823] + 8)) << 4) + 272); X1 = ((val_58 + ((mem[282584257676823] + 8)) << 4) + 272) + 8; //  | 
            // 0x0290894C: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            val_56 = val_58;
            // 0x02908950: BLR x8                     | X0 = ((val_58 + ((mem[282584257676823] + 8)) << 4) + 272)();
            label_62:
            // 0x02908954: MOV x21, x0                | X21 = 0 (0x0);//ML01                    
            val_61 = val_56;
            label_79:
            // 0x02908958: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x0290895C: SUB sp, x29, #0x50         | SP = (1152921513965812880 - 80) = 1152921513965812800 (0x100000022DD67C40);
            // 0x02908960: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x02908964: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x02908968: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x0290896C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x02908970: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x02908974: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x02908978: RET                        |  return (System.Object)null;            
            return (object)val_61;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_19:
            // 0x0290897C: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x02908980: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x02908984: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x02908988: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x0290898C: TBZ w8, #0, #0x290899c     | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_81;
            // 0x02908990: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x02908994: CBNZ w8, #0x290899c        | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_81;
            // 0x02908998: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_81:
            // 0x0290899C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x029089A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029089A4: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_39 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x029089A8: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x029089AC: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x029089B0: MOV x20, x0                | X20 = val_39;//m1                       
            // 0x029089B4: LDR x22, [x8]              | X22 = typeof(System.Object[]);          
            // 0x029089B8: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x029089BC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x029089C0: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x029089C4: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            val_62 = null;
            // 0x029089C8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x029089CC: MOV x22, x0                | X22 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x029089D0: CBNZ x22, #0x29089d8       | if ( != null) goto label_82;            
            if(null != null)
            {
                goto label_82;
            }
            // 0x029089D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_82:
            // 0x029089D8: CBZ x19, #0x29089fc        | if (populateList == null) goto label_84;
            if(val_46 == null)
            {
                goto label_84;
            }
            // 0x029089DC: LDR x8, [x22]              | X8 = ;                                  
            // 0x029089E0: MOV x0, x19                | X0 = populateList;//m1                  
            val_62 = val_46;
            // 0x029089E4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x029089E8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? populateList, ????);
            // 0x029089EC: CBNZ x0, #0x29089fc        | if (populateList != null) goto label_84;
            if(val_62 != null)
            {
                goto label_84;
            }
            // 0x029089F0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? populateList, ????);
            // 0x029089F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029089F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? populateList, ????);
            label_84:
            // 0x029089FC: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x02908A00: CBNZ w8, #0x2908a10        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_85;
            // 0x02908A04: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? populateList, ????);
            // 0x02908A08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02908A0C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? populateList, ????);
            label_85:
            // 0x02908A10: STR x19, [x22, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = populateList;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = val_46;
            // 0x02908A14: CBZ x21, #0x2908a38        | if (val_7 == null) goto label_87;       
            if(val_7 == null)
            {
                goto label_87;
            }
            // 0x02908A18: LDR x8, [x22]              | X8 = ;                                  
            // 0x02908A1C: MOV x0, x21                | X0 = val_7;//m1                         
            val_62 = val_7;
            // 0x02908A20: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x02908A24: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_7, ????);      
            // 0x02908A28: CBNZ x0, #0x2908a38        | if (val_7 != null) goto label_87;       
            if(val_62 != null)
            {
                goto label_87;
            }
            // 0x02908A2C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_7, ????);      
            // 0x02908A30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02908A34: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_87:
            // 0x02908A38: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x02908A3C: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x02908A40: B.HI #0x2908a50            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_88;
            // 0x02908A44: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_7, ????);      
            // 0x02908A48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02908A4C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_88:
            // 0x02908A50: STR x21, [x22, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_7;  //  dest_result_addr=1152921504954501304
            typeof(System.Object[]).__il2cppRuntimeField_28 = val_7;
            // 0x02908A54: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
            // 0x02908A58: LDR x8, [x8, #0x4e8]       | X8 = (string**)(1152921513965787168)("Read-only type {0} does not have a public constructor that takes a type that implements {1}.");
            // 0x02908A5C: MOV x2, x20                | X2 = val_39;//m1                        
            // 0x02908A60: MOV x3, x22                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02908A64: LDR x1, [x8]               | X1 = "Read-only type {0} does not have a public constructor that takes a type that implements {1}.";
            label_99:
            // 0x02908A68: BL #0x2900ac4              | X0 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  val_62 = val_7, provider:  "Read-only type {0} does not have a public constructor that takes a type that implements {1}.", args:  val_39);
            string val_40 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  val_62, provider:  "Read-only type {0} does not have a public constructor that takes a type that implements {1}.", args:  val_39);
            // 0x02908A6C: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x02908A70: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x02908A74: MOV x19, x0                | X19 = val_40;//m1                       
            // 0x02908A78: LDR x8, [x8]               | X8 = typeof(System.Exception);          
            // 0x02908A7C: MOV x0, x8                 | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_41 = null;
            // 0x02908A80: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x02908A84: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02908A88: MOV x1, x19                | X1 = val_40;//m1                        
            // 0x02908A8C: MOV x20, x0                | X20 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x02908A90: BL #0x1c32b48              | .ctor(message:  val_40);                
            val_41 = new System.Exception(message:  val_40);
            // 0x02908A94: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x02908A98: LDR x8, [x8, #0x608]       | X8 = 1152921513965791520;               
            // 0x02908A9C: MOV x0, x20                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x02908AA0: LDR x1, [x8]               | X1 = public static System.Object Newtonsoft.Json.Utilities.CollectionUtils::CreateAndPopulateList(System.Type listType, System.Action<System.Collections.IList, bool> populateList);
            // 0x02908AA4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x02908AA8: BL #0x28fffbc              | X0 = Convert(value:  public static System.Object Newtonsoft.Json.Utilities.CollectionUtils::CreateAndPopulateList(System.Type listType, System.Action<System.Collections.IList, bool> populateList), typeCode:  0);
            object val_42 = Convert(value:  public static System.Object Newtonsoft.Json.Utilities.CollectionUtils::CreateAndPopulateList(System.Type listType, System.Action<System.Collections.IList, bool> populateList), typeCode:  0);
            // 0x02908AAC: MOV x19, x0                | X19 = val_42;//m1                       
            val_63 = val_42;
            // 0x02908AB0: ADD x0, sp, #0x10          | X0 = (1152921513965812736 + 16) = 1152921513965812752 (0x100000022DD67C10);
            // 0x02908AB4: B #0x2908bc0               |  goto label_100;                        
            goto label_100;
            // 0x02908AB8: MOV x19, x0                | X19 = 1152921513965812752 (0x100000022DD67C10);//ML01
            val_63;
            // 0x02908ABC: ADD x0, sp, #0x18          | X0 = (1152921513965812736 + 24) = 1152921513965812760 (0x100000022DD67C18);
            // 0x02908AC0: B #0x2908bc0               |  goto label_100;                        
            goto label_100;
            // 0x02908AC4: MOV x19, x0                | X19 = 1152921513965812760 (0x100000022DD67C18);//ML01
            val_63;
            // 0x02908AC8: ADD x0, sp, #0x30          | X0 = (1152921513965812736 + 48) = 1152921513965812784 (0x100000022DD67C30);
            // 0x02908ACC: B #0x2908bc0               |  goto label_100;                        
            goto label_100;
            // 0x02908AD0: MOV x19, x0                | X19 = 1152921513965812784 (0x100000022DD67C30);//ML01
            val_63;
            // 0x02908AD4: ADD x0, sp, #0x38          | X0 = (1152921513965812736 + 56) = 1152921513965812792 (0x100000022DD67C38);
            // 0x02908AD8: B #0x2908bc0               |  goto label_100;                        
            goto label_100;
            label_43:
            // 0x02908ADC: LDR x8, [x22]              | X8 = typeof(System.Object);             
            // 0x02908AE0: MOV x1, x23                | X1 = 1152921504609349632 (0x1000000000263000);//ML01
            // 0x02908AE4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x02908AE8: ADD x8, sp, #8             | X8 = (1152921513965812736 + 8) = 1152921513965812744 (0x100000022DD67C08);
            // 0x02908AEC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x02908AF0: LDR x0, [sp, #8]           | X0 = val_43;                             //  find_add[1152921513965800896]
            // 0x02908AF4: BL #0x27af090              | X0 = sub_27AF090( ?? val_43, ????);     
            // 0x02908AF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02908AFC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_43, ????);     
            // 0x02908B00: ADD x0, sp, #8             | X0 = (1152921513965812736 + 8) = 1152921513965812744 (0x100000022DD67C08);
            // 0x02908B04: BL #0x299a140              | 
            label_53:
            // 0x02908B08: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x02908B0C: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x02908B10: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x02908B14: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x02908B18: TBZ w8, #0, #0x2908b28     | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_94;
            // 0x02908B1C: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x02908B20: CBNZ w8, #0x2908b28        | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_94;
            // 0x02908B24: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_94:
            // 0x02908B28: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02908B2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02908B30: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_44 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x02908B34: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x02908B38: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x02908B3C: MOV x20, x0                | X20 = val_44;//m1                       
            // 0x02908B40: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
            // 0x02908B44: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02908B48: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x02908B4C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x02908B50: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02908B54: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x02908B58: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02908B5C: CBNZ x21, #0x2908b64       | if ( != null) goto label_95;            
            if(null != null)
            {
                goto label_95;
            }
            // 0x02908B60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_95:
            // 0x02908B64: CBZ x19, #0x2908b88        | if (populateList == null) goto label_97;
            if(val_46 == null)
            {
                goto label_97;
            }
            // 0x02908B68: LDR x8, [x21]              | X8 = ;                                  
            // 0x02908B6C: MOV x0, x19                | X0 = populateList;//m1                  
            // 0x02908B70: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x02908B74: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? populateList, ????);
            // 0x02908B78: CBNZ x0, #0x2908b88        | if (populateList != null) goto label_97;
            if(val_46 != null)
            {
                goto label_97;
            }
            // 0x02908B7C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? populateList, ????);
            // 0x02908B80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02908B84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? populateList, ????);
            label_97:
            // 0x02908B88: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x02908B8C: CBNZ w8, #0x2908b9c        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_98;
            // 0x02908B90: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? populateList, ????);
            // 0x02908B94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02908B98: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? populateList, ????);
            label_98:
            // 0x02908B9C: STR x19, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = populateList;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = val_46;
            // 0x02908BA0: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x02908BA4: LDR x8, [x8, #0xc18]       | X8 = (string**)(1152921513965800736)("Cannot create and populate list type {0}.");
            // 0x02908BA8: MOV x2, x20                | X2 = val_44;//m1                        
            // 0x02908BAC: MOV x3, x21                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02908BB0: LDR x1, [x8]               | X1 = "Cannot create and populate list type {0}.";
            // 0x02908BB4: B #0x2908a68               |  goto label_99;                         
            goto label_99;
            // 0x02908BB8: MOV x19, x0                | X19 = populateList;//m1                 
            val_63 = val_46;
            // 0x02908BBC: ADD x0, sp, #0x28          | X0 = (1152921513965812736 + 40) = 1152921513965812776 (0x100000022DD67C28);
            label_100:
            // 0x02908BC0: BL #0x299a140              | 
            // 0x02908BC4: MOV x0, x19                | X0 = populateList;//m1                  
            // 0x02908BC8: BL #0x980800               | X0 = sub_980800( ?? populateList, ????);
            // 0x02908BCC: MOV x19, x0                | X19 = populateList;//m1                 
            // 0x02908BD0: ADD x0, sp, #8             | X0 = (1152921513965812736 + 8) = 1152921513965812744 (0x100000022DD67C08);
            // 0x02908BD4: B #0x2908bc0               |  goto label_100;                        
            goto label_100;
        
        }
        //
        // Offset in libil2cpp.so: 0x02912EDC (43069148), len: 244  VirtAddr: 0x02912EDC RVA: 0x02912EDC token: 100686574 methodIndex: 49127 delegateWrapperIndex: 0 methodInvoker: 0
        public static System.Array ToArray(System.Array initial, System.Type type)
        {
            //
            // Disasemble & Code
            // 0x02912EDC: STP x22, x21, [sp, #-0x30]! | stack[1152921513966102000] = ???;  stack[1152921513966102008] = ???;  //  dest_result_addr=1152921513966102000 |  dest_result_addr=1152921513966102008
            // 0x02912EE0: STP x20, x19, [sp, #0x10]  | stack[1152921513966102016] = ???;  stack[1152921513966102024] = ???;  //  dest_result_addr=1152921513966102016 |  dest_result_addr=1152921513966102024
            // 0x02912EE4: STP x29, x30, [sp, #0x20]  | stack[1152921513966102032] = ???;  stack[1152921513966102040] = ???;  //  dest_result_addr=1152921513966102032 |  dest_result_addr=1152921513966102040
            // 0x02912EE8: ADD x29, sp, #0x20         | X29 = (1152921513966102000 + 32) = 1152921513966102032 (0x100000022DDAE610);
            // 0x02912EEC: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x02912EF0: LDRB w8, [x21, #0xaf7]     | W8 = (bool)static_value_037B8AF7;       
            // 0x02912EF4: MOV x20, x2                | X20 = X2;//m1                           
            // 0x02912EF8: MOV x19, x1                | X19 = type;//m1                         
            // 0x02912EFC: TBNZ w8, #0, #0x2912f18    | if (static_value_037B8AF7 == true) goto label_0;
            // 0x02912F00: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x02912F04: LDR x8, [x8, #0x890]       | X8 = 0x2B9162C;                         
            // 0x02912F08: LDR w0, [x8]               | W0 = 0x1C4F;                            
            // 0x02912F0C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C4F, ????);     
            // 0x02912F10: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02912F14: STRB w8, [x21, #0xaf7]     | static_value_037B8AF7 = true;            //  dest_result_addr=58428151
            label_0:
            // 0x02912F18: CBZ x20, #0x2912f90        | if (X2 == 0) goto label_1;              
            if(X2 == 0)
            {
                goto label_1;
            }
            // 0x02912F1C: CBNZ x19, #0x2912f24       | if (type != null) goto label_2;         
            if(type != null)
            {
                goto label_2;
            }
            // 0x02912F20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C4F, ????);     
            label_2:
            // 0x02912F24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02912F28: MOV x0, x19                | X0 = type;//m1                          
            // 0x02912F2C: BL #0x18cbcf0              | X0 = type.get_Length();                 
            int val_1 = type.Length;
            // 0x02912F30: MOV w2, w0                 | W2 = val_1;//m1                         
            // 0x02912F34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02912F38: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x02912F3C: MOV x1, x20                | X1 = X2;//m1                            
            // 0x02912F40: BL #0x18cd230              | X0 = System.Array.CreateInstance(elementType:  0, length:  X2);
            System.Array val_2 = System.Array.CreateInstance(elementType:  0, length:  X2);
            // 0x02912F44: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x02912F48: CBNZ x19, #0x2912f50       | if (type != null) goto label_3;         
            if(type != null)
            {
                goto label_3;
            }
            // 0x02912F4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_3:
            // 0x02912F50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02912F54: MOV x0, x19                | X0 = type;//m1                          
            // 0x02912F58: BL #0x18cbcf0              | X0 = type.get_Length();                 
            int val_3 = type.Length;
            // 0x02912F5C: MOV w5, w0                 | W5 = val_3;//m1                         
            // 0x02912F60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02912F64: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x02912F68: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x02912F6C: MOV x1, x19                | X1 = type;//m1                          
            // 0x02912F70: MOV x3, x20                | X3 = val_2;//m1                         
            // 0x02912F74: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x02912F78: BL #0x18ce87c              | System.Array.Copy(sourceArray:  0, sourceIndex:  type, destinationArray:  0, destinationIndex:  val_2, length:  0);
            System.Array.Copy(sourceArray:  0, sourceIndex:  type, destinationArray:  0, destinationIndex:  val_2, length:  0);
            // 0x02912F7C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x02912F80: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x02912F84: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x02912F88: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x02912F8C: RET                        |  return (System.Array)val_2;            
            return (System.Array)val_2;
            //  |  // // {name=val_0, type=System.Array, size=8, nGRN=0 }
            label_1:
            // 0x02912F90: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x02912F94: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x02912F98: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            System.ArgumentNullException val_4 = null;
            // 0x02912F9C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x02912FA0: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x02912FA4: LDR x8, [x8, #0xb90]       | X8 = (string**)(1152921510122301360)("type");
            // 0x02912FA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02912FAC: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x02912FB0: LDR x1, [x8]               | X1 = "type";                            
            // 0x02912FB4: BL #0x18b3df0              | .ctor(paramName:  "type");              
            val_4 = new System.ArgumentNullException(paramName:  "type");
            // 0x02912FB8: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
            // 0x02912FBC: LDR x8, [x8, #0x9f0]       | X8 = 1152921513966084928;               
            // 0x02912FC0: MOV x0, x19                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x02912FC4: LDR x1, [x8]               | X1 = public static System.Array Newtonsoft.Json.Utilities.CollectionUtils::ToArray(System.Array initial, System.Type type);
            // 0x02912FC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentNullException), ????);
            // 0x02912FCC: BL #0x28fffbc              | X0 = Convert(value:  public static System.Array Newtonsoft.Json.Utilities.CollectionUtils::ToArray(System.Array initial, System.Type type), typeCode:  0);
            object val_5 = Convert(value:  public static System.Array Newtonsoft.Json.Utilities.CollectionUtils::ToArray(System.Array initial, System.Type type), typeCode:  0);
        
        }
        // Generic instance method:
        //
        // file offset: 0x012F95A8 VirtAddr: 0x012F95A8 -RVA: 0x012F95A8 
        // -CollectionUtils.AddDistinct<object>
        // -CollectionUtils.AddDistinct<string>
        //
        //
        // Offset in libil2cpp.so: 0x012F95A8 (19895720), len: 164  VirtAddr: 0x012F95A8 RVA: 0x012F95A8 token: 100686575 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x28632F8
        public static bool AddDistinct<T>(System.Collections.Generic.IList<T> list, T value)
        {
            //
            // Disasemble & Code
            // 0x012F95A8: STP x22, x21, [sp, #-0x30]! | stack[1152921513966238576] = ???;  stack[1152921513966238584] = ???;  //  dest_result_addr=1152921513966238576 |  dest_result_addr=1152921513966238584
            // 0x012F95AC: STP x20, x19, [sp, #0x10]  | stack[1152921513966238592] = ???;  stack[1152921513966238600] = ???;  //  dest_result_addr=1152921513966238592 |  dest_result_addr=1152921513966238600
            // 0x012F95B0: STP x29, x30, [sp, #0x20]  | stack[1152921513966238608] = ???;  stack[1152921513966238616] = ???;  //  dest_result_addr=1152921513966238608 |  dest_result_addr=1152921513966238616
            // 0x012F95B4: ADD x29, sp, #0x20         | X29 = (1152921513966238576 + 32) = 1152921513966238608 (0x100000022DDCFB90);
            // 0x012F95B8: MOV x20, x3                | X20 = X3;//m1                           
            // 0x012F95BC: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x012F95C0: MOV x19, x2                | X19 = __RuntimeMethodHiddenParam;//m1   
            // 0x012F95C4: MOV x21, x1                | X21 = value;//m1                        
            // 0x012F95C8: LDR x22, [x8, #8]          | X22 = X3 + 48 + 8;                      
            // 0x012F95CC: MOV x0, x22                | X0 = X3 + 48 + 8;//m1                   
            // 0x012F95D0: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 8, ????);
            // 0x012F95D4: LDRB w8, [x22, #0x10a]     | W8 = X3 + 48 + 8 + 266;                 
            // 0x012F95D8: TBZ w8, #0, #0x12f960c     | if ((X3 + 48 + 8 + 266 & 0x1) == 0) goto label_1;
            if(((X3 + 48 + 8 + 266) & 1) == 0)
            {
                goto label_1;
            }
            // 0x012F95DC: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x012F95E0: LDR x22, [x8, #8]          | X22 = X3 + 48 + 8;                      
            // 0x012F95E4: MOV x0, x22                | X0 = X3 + 48 + 8;//m1                   
            // 0x012F95E8: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 8, ????);
            // 0x012F95EC: LDR w8, [x22, #0xbc]       | W8 = X3 + 48 + 8 + 188;                 
            // 0x012F95F0: CBNZ w8, #0x12f960c        | if (X3 + 48 + 8 + 188 != 0) goto label_1;
            if((X3 + 48 + 8 + 188) != 0)
            {
                goto label_1;
            }
            // 0x012F95F4: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x012F95F8: LDR x22, [x8, #8]          | X22 = X3 + 48 + 8;                      
            // 0x012F95FC: MOV x0, x22                | X0 = X3 + 48 + 8;//m1                   
            // 0x012F9600: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 8, ????);
            // 0x012F9604: MOV x0, x22                | X0 = X3 + 48 + 8;//m1                   
            // 0x012F9608: BL #0x27977a4              | X0 = sub_27977A4( ?? X3 + 48 + 8, ????);
            label_1:
            // 0x012F960C: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x012F9610: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x012F9614: LDR x1, [x8]               | X1 = X3 + 48;                           
            // 0x012F9618: LDR x8, [x1]               | X8 = X3 + 48;                           
            // 0x012F961C: BLR x8                     | X0 = X3 + 48();                         
            // 0x012F9620: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x012F9624: MOV x2, x19                | X2 = __RuntimeMethodHiddenParam;//m1    
            // 0x012F9628: MOV x3, x0                 | X3 = 0 (0x0);//ML01                     
            // 0x012F962C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x012F9630: LDR x4, [x8, #0x10]        | X4 = X3 + 48 + 16;                      
            // 0x012F9634: MOV x1, x21                | X1 = value;//m1                         
            // 0x012F9638: LDR x5, [x4]               | X5 = X3 + 48 + 16;                      
            // 0x012F963C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x012F9640: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x012F9644: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x012F9648: BR x5                      | goto X3 + 48 + 16;                      
            goto X3 + 48 + 16;
        
        }
        // Generic instance method:
        //
        // file offset: 0x012F964C VirtAddr: 0x012F964C -RVA: 0x012F964C 
        // -CollectionUtils.AddDistinct<object>
        //
        //
        // Offset in libil2cpp.so: 0x012F964C (19895884), len: 212  VirtAddr: 0x012F964C RVA: 0x012F964C token: 100686576 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x2863308
        public static bool AddDistinct<T>(System.Collections.Generic.IList<T> list, T value, System.Collections.Generic.IEqualityComparer<T> comparer)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            // 0x012F964C: STP x22, x21, [sp, #-0x30]! | stack[1152921513966371056] = ???;  stack[1152921513966371064] = ???;  //  dest_result_addr=1152921513966371056 |  dest_result_addr=1152921513966371064
            // 0x012F9650: STP x20, x19, [sp, #0x10]  | stack[1152921513966371072] = ???;  stack[1152921513966371080] = ???;  //  dest_result_addr=1152921513966371072 |  dest_result_addr=1152921513966371080
            // 0x012F9654: STP x29, x30, [sp, #0x20]  | stack[1152921513966371088] = ???;  stack[1152921513966371096] = ???;  //  dest_result_addr=1152921513966371088 |  dest_result_addr=1152921513966371096
            // 0x012F9658: ADD x29, sp, #0x20         | X29 = (1152921513966371056 + 32) = 1152921513966371088 (0x100000022DDF0110);
            // 0x012F965C: MOV x21, x4                | X21 = X4;//m1                           
            val_2 = X4;
            // 0x012F9660: LDR x8, [x21, #0x30]       | X8 = X4 + 48;                           
            // 0x012F9664: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x012F9668: MOV x19, x2                | X19 = comparer;//m1                     
            // 0x012F966C: MOV x20, x1                | X20 = value;//m1                        
            // 0x012F9670: LDR x4, [x8]               | X4 = X4 + 48;                           
            // 0x012F9674: LDR x8, [x4]               | X8 = X4 + 48;                           
            // 0x012F9678: BLR x8                     | X0 = X4 + 48();                         
            // 0x012F967C: AND w8, w0, #1             | W8 = (0 & 1) = 0 (0x00000000);          
            // 0x012F9680: TBZ w8, #0, #0x12f968c     | if ((0x0 & 0x1) == 0) goto label_0;     
            if((0 & 1) == 0)
            {
                goto label_0;
            }
            // 0x012F9684: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_3 = 0;
            // 0x012F9688: B #0x12f9710               |  goto label_1;                          
            goto label_1;
            label_0:
            // 0x012F968C: CBNZ x20, #0x12f9694       | if (value != null) goto label_2;        
            if(value != null)
            {
                goto label_2;
            }
            // 0x012F9690: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_2:
            // 0x012F9694: LDR x8, [x21, #0x30]       | X8 = X4 + 48;                           
            // 0x012F9698: LDR x21, [x8, #8]          | X21 = X4 + 48 + 8;                      
            val_2 = mem[X4 + 48 + 8];
            val_2 = X4 + 48 + 8;
            // 0x012F969C: MOV x0, x21                | X0 = X4 + 48 + 8;//m1                   
            // 0x012F96A0: BL #0x277461c              | X0 = sub_277461C( ?? X4 + 48 + 8, ????);
            // 0x012F96A4: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x012F96A8: LDRH w9, [x8, #0x102]      | W9 = System.Object.__il2cppRuntimeField_interface_offsets_count;
            // 0x012F96AC: CBZ x9, #0x12f96d8         | if (System.Object.__il2cppRuntimeField_interface_offsets_count == 0) goto label_3;
            // 0x012F96B0: LDR x10, [x8, #0x98]       | X10 = System.Object.__il2cppRuntimeField_interfaceOffsets;
            // 0x012F96B4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x012F96B8: ADD x10, x10, #8           | X10 = (System.Object.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504606937096 (0x1000000000016008);
            label_5:
            // 0x012F96BC: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x012F96C0: CMP x12, x21               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X4 + 48 + 8)
            // 0x012F96C4: B.EQ #0x12f96ec            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == val_2) goto label_4;
            // 0x012F96C8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x012F96CC: ADD x10, x10, #0x10        | X10 = (1152921504606937096 + 16) = 1152921504606937112 (0x1000000000016018);
            // 0x012F96D0: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Object.__il2cppRuntimeField_interface_offsets_count)
            // 0x012F96D4: B.LO #0x12f96bc            | if (0 < System.Object.__il2cppRuntimeField_interface_offsets_count) goto label_5;
            label_3:
            // 0x012F96D8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x012F96DC: MOV x0, x20                | X0 = value;//m1                         
            val_4 = value;
            // 0x012F96E0: MOV x1, x21                | X1 = X4 + 48 + 8;//m1                   
            // 0x012F96E4: BL #0x2776c24              | X0 = sub_2776C24( ?? value, ????);      
            // 0x012F96E8: B #0x12f96fc               |  goto label_6;                          
            goto label_6;
            label_4:
            // 0x012F96EC: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x012F96F0: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x012F96F4: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x012F96F8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_6:
            // 0x012F96FC: LDP x8, x2, [x0]           | X8 = X4 + 48 + 8; X2 = X4 + 48 + 8 + 8;  //  | 
            // 0x012F9700: MOV x0, x20                | X0 = value;//m1                         
            // 0x012F9704: MOV x1, x19                | X1 = comparer;//m1                      
            // 0x012F9708: BLR x8                     | X0 = X4 + 48 + 8();                     
            // 0x012F970C: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_3 = 1;
            label_1:
            // 0x012F9710: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x012F9714: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x012F9718: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x012F971C: RET                        |  return (System.Boolean)true;           
            return (bool)val_3;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x012F9A6C VirtAddr: 0x012F9A6C -RVA: 0x012F9A6C 
        // -CollectionUtils.ContainsValue<object>
        // -CollectionUtils.ContainsValue<Newtonsoft.Json.Linq.JToken>
        //
        //
        // Offset in libil2cpp.so: 0x012F9A6C (19896940), len: 968  VirtAddr: 0x012F9A6C RVA: 0x012F9A6C token: 100686577 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x2863318
        public static bool ContainsValue<TSource>(System.Collections.Generic.IEnumerable<TSource> source, TSource value, System.Collections.Generic.IEqualityComparer<TSource> comparer)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            // 0x012F9A6C: STP x26, x25, [sp, #-0x50]! | stack[1152921513966508624] = ???;  stack[1152921513966508632] = ???;  //  dest_result_addr=1152921513966508624 |  dest_result_addr=1152921513966508632
            // 0x012F9A70: STP x24, x23, [sp, #0x10]  | stack[1152921513966508640] = ???;  stack[1152921513966508648] = ???;  //  dest_result_addr=1152921513966508640 |  dest_result_addr=1152921513966508648
            // 0x012F9A74: STP x22, x21, [sp, #0x20]  | stack[1152921513966508656] = ???;  stack[1152921513966508664] = ???;  //  dest_result_addr=1152921513966508656 |  dest_result_addr=1152921513966508664
            // 0x012F9A78: STP x20, x19, [sp, #0x30]  | stack[1152921513966508672] = ???;  stack[1152921513966508680] = ???;  //  dest_result_addr=1152921513966508672 |  dest_result_addr=1152921513966508680
            // 0x012F9A7C: STP x29, x30, [sp, #0x40]  | stack[1152921513966508688] = ???;  stack[1152921513966508696] = ???;  //  dest_result_addr=1152921513966508688 |  dest_result_addr=1152921513966508696
            // 0x012F9A80: ADD x29, sp, #0x40         | X29 = (1152921513966508624 + 64) = 1152921513966508688 (0x100000022DE11A90);
            // 0x012F9A84: ADRP x23, #0x3736000       | X23 = 57892864 (0x3736000);             
            // 0x012F9A88: LDRB w8, [x23, #0x8b0]     | W8 = (bool)static_value_037368B0;       
            // 0x012F9A8C: MOV x19, x4                | X19 = X4;//m1                           
            // 0x012F9A90: MOV x22, x3                | X22 = __RuntimeMethodHiddenParam;//m1   
            val_9 = __RuntimeMethodHiddenParam;
            // 0x012F9A94: MOV x20, x2                | X20 = comparer;//m1                     
            // 0x012F9A98: MOV x21, x1                | X21 = value;//m1                        
            // 0x012F9A9C: TBNZ w8, #0, #0x12f9ab8    | if (static_value_037368B0 == true) goto label_0;
            // 0x012F9AA0: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x012F9AA4: LDR x8, [x8, #0xa98]       | X8 = 0x2B915E0;                         
            // 0x012F9AA8: LDR w0, [x8]               | W0 = 0x1C3C;                            
            // 0x012F9AAC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C3C, ????);     
            // 0x012F9AB0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x012F9AB4: STRB w8, [x23, #0x8b0]     | static_value_037368B0 = true;            //  dest_result_addr=57895088
            label_0:
            // 0x012F9AB8: CBNZ x22, #0x12f9b1c       | if (__RuntimeMethodHiddenParam != 0) goto label_1;
            if(val_9 != 0)
            {
                goto label_1;
            }
            // 0x012F9ABC: LDR x8, [x19, #0x30]       | X8 = X4 + 48;                           
            // 0x012F9AC0: LDR x22, [x8, #8]          | X22 = X4 + 48 + 8;                      
            // 0x012F9AC4: MOV x0, x22                | X0 = X4 + 48 + 8;//m1                   
            // 0x012F9AC8: BL #0x277461c              | X0 = sub_277461C( ?? X4 + 48 + 8, ????);
            // 0x012F9ACC: LDRB w8, [x22, #0x10a]     | W8 = X4 + 48 + 8 + 266;                 
            // 0x012F9AD0: TBZ w8, #0, #0x12f9b04     | if ((X4 + 48 + 8 + 266 & 0x1) == 0) goto label_3;
            if(((X4 + 48 + 8 + 266) & 1) == 0)
            {
                goto label_3;
            }
            // 0x012F9AD4: LDR x8, [x19, #0x30]       | X8 = X4 + 48;                           
            // 0x012F9AD8: LDR x22, [x8, #8]          | X22 = X4 + 48 + 8;                      
            // 0x012F9ADC: MOV x0, x22                | X0 = X4 + 48 + 8;//m1                   
            // 0x012F9AE0: BL #0x277461c              | X0 = sub_277461C( ?? X4 + 48 + 8, ????);
            // 0x012F9AE4: LDR w8, [x22, #0xbc]       | W8 = X4 + 48 + 8 + 188;                 
            // 0x012F9AE8: CBNZ w8, #0x12f9b04        | if (X4 + 48 + 8 + 188 != 0) goto label_3;
            if((X4 + 48 + 8 + 188) != 0)
            {
                goto label_3;
            }
            // 0x012F9AEC: LDR x8, [x19, #0x30]       | X8 = X4 + 48;                           
            // 0x012F9AF0: LDR x22, [x8, #8]          | X22 = X4 + 48 + 8;                      
            // 0x012F9AF4: MOV x0, x22                | X0 = X4 + 48 + 8;//m1                   
            // 0x012F9AF8: BL #0x277461c              | X0 = sub_277461C( ?? X4 + 48 + 8, ????);
            // 0x012F9AFC: MOV x0, x22                | X0 = X4 + 48 + 8;//m1                   
            // 0x012F9B00: BL #0x27977a4              | X0 = sub_27977A4( ?? X4 + 48 + 8, ????);
            label_3:
            // 0x012F9B04: LDR x8, [x19, #0x30]       | X8 = X4 + 48;                           
            // 0x012F9B08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x012F9B0C: LDR x1, [x8]               | X1 = X4 + 48;                           
            val_10 = mem[X4 + 48];
            val_10 = X4 + 48;
            // 0x012F9B10: LDR x8, [x1]               | X8 = X4 + 48;                           
            // 0x012F9B14: BLR x8                     | X0 = X4 + 48();                         
            // 0x012F9B18: MOV x22, x0                | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_1:
            // 0x012F9B1C: CBZ x21, #0x12f9df4        | if (value == null) goto label_4;        
            if(value == null)
            {
                goto label_4;
            }
            // 0x012F9B20: LDR x8, [x19, #0x30]       | X8 = X4 + 48;                           
            // 0x012F9B24: LDR x23, [x8, #0x10]       | X23 = X4 + 48 + 16;                     
            // 0x012F9B28: MOV x0, x23                | X0 = X4 + 48 + 16;//m1                  
            // 0x012F9B2C: BL #0x277461c              | X0 = sub_277461C( ?? X4 + 48 + 16, ????);
            // 0x012F9B30: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x012F9B34: LDRH w9, [x8, #0x102]      | W9 = System.Object.__il2cppRuntimeField_interface_offsets_count;
            // 0x012F9B38: CBZ x9, #0x12f9b64         | if (System.Object.__il2cppRuntimeField_interface_offsets_count == 0) goto label_5;
            // 0x012F9B3C: LDR x10, [x8, #0x98]       | X10 = System.Object.__il2cppRuntimeField_interfaceOffsets;
            // 0x012F9B40: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_8 = 0;
            // 0x012F9B44: ADD x10, x10, #8           | X10 = (System.Object.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504606937096 (0x1000000000016008);
            label_7:
            // 0x012F9B48: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x012F9B4C: CMP x12, x23               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X4 + 48 + 16)
            // 0x012F9B50: B.EQ #0x12f9b78            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X4 + 48 + 16) goto label_6;
            // 0x012F9B54: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x012F9B58: ADD x10, x10, #0x10        | X10 = (1152921504606937096 + 16) = 1152921504606937112 (0x1000000000016018);
            // 0x012F9B5C: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Object.__il2cppRuntimeField_interface_offsets_count)
            // 0x012F9B60: B.LO #0x12f9b48            | if (0 < System.Object.__il2cppRuntimeField_interface_offsets_count) goto label_7;
            label_5:
            // 0x012F9B64: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x012F9B68: MOV x0, x21                | X0 = value;//m1                         
            val_11 = value;
            // 0x012F9B6C: MOV x1, x23                | X1 = X4 + 48 + 16;//m1                  
            val_10 = X4 + 48 + 16;
            // 0x012F9B70: BL #0x2776c24              | X0 = sub_2776C24( ?? value, ????);      
            // 0x012F9B74: B #0x12f9b84               |  goto label_8;                          
            goto label_8;
            label_6:
            // 0x012F9B78: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x012F9B7C: ADD x8, x8, x9, lsl #4     | X8 = (1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x012F9B80: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_8:
            // 0x012F9B84: LDP x8, x1, [x0]           | X8 = X4 + 48 + 16; X1 = X4 + 48 + 16 + 8; //  | 
            // 0x012F9B88: MOV x0, x21                | X0 = value;//m1                         
            // 0x012F9B8C: BLR x8                     | X0 = X4 + 48 + 16();                    
            // 0x012F9B90: ADRP x25, #0x361c000       | X25 = 56737792 (0x361C000);             
            // 0x012F9B94: LDR x25, [x25, #0x358]     | X25 = 1152921504608018432;              
            // 0x012F9B98: MOV x21, x0                | X21 = value;//m1                        
            label_25:
            // 0x012F9B9C: CBNZ x21, #0x12f9ba4       | if (value != null) goto label_9;        
            if(value != null)
            {
                goto label_9;
            }
            // 0x012F9BA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? value, ????);      
            label_9:
            // 0x012F9BA4: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x012F9BA8: LDR x1, [x25]              | X1 = typeof(System.Collections.IEnumerator);
            // 0x012F9BAC: LDRH w9, [x8, #0x102]      | W9 = System.Object.__il2cppRuntimeField_interface_offsets_count;
            // 0x012F9BB0: CBZ x9, #0x12f9bdc         | if (System.Object.__il2cppRuntimeField_interface_offsets_count == 0) goto label_10;
            // 0x012F9BB4: LDR x10, [x8, #0x98]       | X10 = System.Object.__il2cppRuntimeField_interfaceOffsets;
            // 0x012F9BB8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_9 = 0;
            // 0x012F9BBC: ADD x10, x10, #8           | X10 = (System.Object.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504606937096 (0x1000000000016008);
            label_12:
            // 0x012F9BC0: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x012F9BC4: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IEnumerator))
            // 0x012F9BC8: B.EQ #0x12f9bec            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_11;
            // 0x012F9BCC: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_9 = val_9 + 1;
            // 0x012F9BD0: ADD x10, x10, #0x10        | X10 = (1152921504606937096 + 16) = 1152921504606937112 (0x1000000000016018);
            // 0x012F9BD4: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Object.__il2cppRuntimeField_interface_offsets_count)
            // 0x012F9BD8: B.LO #0x12f9bc0            | if (0 < System.Object.__il2cppRuntimeField_interface_offsets_count) goto label_12;
            label_10:
            // 0x012F9BDC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x012F9BE0: MOV x0, x21                | X0 = value;//m1                         
            val_12 = value;
            // 0x012F9BE4: BL #0x2776c24              | X0 = sub_2776C24( ?? value, ????);      
            // 0x012F9BE8: B #0x12f9bfc               |  goto label_13;                         
            goto label_13;
            label_11:
            // 0x012F9BEC: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x012F9BF0: ADD w9, w9, #1             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1);
            // 0x012F9BF4: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1));
            // 0x012F9BF8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1)).272
            label_13:
            // 0x012F9BFC: LDP x8, x1, [x0]           | X8 = typeof(System.Object);              //  | 
            // 0x012F9C00: MOV x0, x21                | X0 = value;//m1                         
            // 0x012F9C04: BLR x8                     | X0 = sub_100000000000D000( ?? value, ????);
            // 0x012F9C08: AND w8, w0, #1             | W8 = (value & 1);                       
            object val_3 = value & 1;
            // 0x012F9C0C: TBZ w8, #0, #0x12f9de4     | if (((value & 1) & 0x1) == 0) goto label_14;
            if((val_3 & 1) == 0)
            {
                goto label_14;
            }
            // 0x012F9C10: CBNZ x21, #0x12f9c18       | if (value != null) goto label_15;       
            if(value != null)
            {
                goto label_15;
            }
            // 0x012F9C14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? value, ????);      
            label_15:
            // 0x012F9C18: LDR x8, [x19, #0x30]       | X8 = X4 + 48;                           
            // 0x012F9C1C: LDR x23, [x8, #0x18]       | X23 = X4 + 48 + 24;                     
            // 0x012F9C20: MOV x0, x23                | X0 = X4 + 48 + 24;//m1                  
            // 0x012F9C24: BL #0x277461c              | X0 = sub_277461C( ?? X4 + 48 + 24, ????);
            // 0x012F9C28: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x012F9C2C: LDRH w9, [x8, #0x102]      | W9 = System.Object.__il2cppRuntimeField_interface_offsets_count;
            // 0x012F9C30: CBZ x9, #0x12f9c5c         | if (System.Object.__il2cppRuntimeField_interface_offsets_count == 0) goto label_16;
            // 0x012F9C34: LDR x10, [x8, #0x98]       | X10 = System.Object.__il2cppRuntimeField_interfaceOffsets;
            // 0x012F9C38: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_10 = 0;
            // 0x012F9C3C: ADD x10, x10, #8           | X10 = (System.Object.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504606937096 (0x1000000000016008);
            label_18:
            // 0x012F9C40: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x012F9C44: CMP x12, x23               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X4 + 48 + 24)
            // 0x012F9C48: B.EQ #0x12f9c70            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X4 + 48 + 24) goto label_17;
            // 0x012F9C4C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_10 = val_10 + 1;
            // 0x012F9C50: ADD x10, x10, #0x10        | X10 = (1152921504606937096 + 16) = 1152921504606937112 (0x1000000000016018);
            // 0x012F9C54: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Object.__il2cppRuntimeField_interface_offsets_count)
            // 0x012F9C58: B.LO #0x12f9c40            | if (0 < System.Object.__il2cppRuntimeField_interface_offsets_count) goto label_18;
            label_16:
            // 0x012F9C5C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x012F9C60: MOV x0, x21                | X0 = value;//m1                         
            val_14 = value;
            // 0x012F9C64: MOV x1, x23                | X1 = X4 + 48 + 24;//m1                  
            val_13 = X4 + 48 + 24;
            // 0x012F9C68: BL #0x2776c24              | X0 = sub_2776C24( ?? value, ????);      
            // 0x012F9C6C: B #0x12f9c7c               |  goto label_19;                         
            goto label_19;
            label_17:
            // 0x012F9C70: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x012F9C74: ADD x8, x8, x9, lsl #4     | X8 = (1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x012F9C78: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_19:
            // 0x012F9C7C: LDP x8, x1, [x0]           | X8 = X4 + 48 + 24; X1 = X4 + 48 + 24 + 8; //  | 
            // 0x012F9C80: MOV x0, x21                | X0 = value;//m1                         
            // 0x012F9C84: BLR x8                     | X0 = X4 + 48 + 24();                    
            // 0x012F9C88: MOV x23, x0                | X23 = value;//m1                        
            // 0x012F9C8C: CBNZ x22, #0x12f9c94       | if (0x0 != 0) goto label_20;            
            if(val_9 != 0)
            {
                goto label_20;
            }
            // 0x012F9C90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? value, ????);      
            label_20:
            // 0x012F9C94: LDR x8, [x19, #0x30]       | X8 = X4 + 48;                           
            // 0x012F9C98: LDR x24, [x8, #0x20]       | X24 = X4 + 48 + 32;                     
            // 0x012F9C9C: MOV x0, x24                | X0 = X4 + 48 + 32;//m1                  
            // 0x012F9CA0: BL #0x277461c              | X0 = sub_277461C( ?? X4 + 48 + 32, ????);
            // 0x012F9CA4: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            var val_13 = 1179403647;
            // 0x012F9CA8: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x012F9CAC: CBZ x9, #0x12f9cd8         | if (mem[282584257676929] == 0) goto label_21;
            if(mem[282584257676929] == 0)
            {
                goto label_21;
            }
            // 0x012F9CB0: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_11 = mem[282584257676823];
            // 0x012F9CB4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_12 = 0;
            // 0x012F9CB8: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_11 = val_11 + 8;
            label_23:
            // 0x012F9CBC: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x012F9CC0: CMP x12, x24               | STATE = COMPARE((mem[282584257676823] + 8) + -8, X4 + 48 + 32)
            // 0x012F9CC4: B.EQ #0x12f9cec            | if ((mem[282584257676823] + 8) + -8 == X4 + 48 + 32) goto label_22;
            if(((mem[282584257676823] + 8) + -8) == (X4 + 48 + 32))
            {
                goto label_22;
            }
            // 0x012F9CC8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_12 = val_12 + 1;
            // 0x012F9CCC: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_11 = val_11 + 16;
            // 0x012F9CD0: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x012F9CD4: B.LO #0x12f9cbc            | if (0 < mem[282584257676929]) goto label_23;
            if(val_12 < mem[282584257676929])
            {
                goto label_23;
            }
            label_21:
            // 0x012F9CD8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x012F9CDC: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            val_15 = val_9;
            // 0x012F9CE0: MOV x1, x24                | X1 = X4 + 48 + 32;//m1                  
            // 0x012F9CE4: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x012F9CE8: B #0x12f9cf8               |  goto label_24;                         
            goto label_24;
            label_22:
            // 0x012F9CEC: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            // 0x012F9CF0: ADD x8, x8, x9, lsl #4     | X8 = (1179403647 + ((mem[282584257676823] + 8)) << 4);
            val_13 = val_13 + (((mem[282584257676823] + 8)) << 4);
            // 0x012F9CF4: ADD x0, x8, #0x110         | X0 = ((1179403647 + ((mem[282584257676823] + 8)) << 4) + 272);
            val_15 = val_13 + 272;
            label_24:
            // 0x012F9CF8: LDP x8, x3, [x0]           | X8 = ((1179403647 + ((mem[282584257676823] + 8)) << 4) + 272); X3 = ((1179403647 + ((mem[282584257676823] + 8)) << 4) + 272) + 8; //  | 
            // 0x012F9CFC: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x012F9D00: MOV x1, x23                | X1 = value;//m1                         
            // 0x012F9D04: MOV x2, x20                | X2 = comparer;//m1                      
            // 0x012F9D08: BLR x8                     | X0 = ((1179403647 + ((mem[282584257676823] + 8)) << 4) + 272)();
            // 0x012F9D0C: AND w8, w0, #1             | W8 = (val_9 & 1) = 0 (0x00000000);      
            // 0x012F9D10: TBZ w8, #0, #0x12f9b9c     | if ((0x0 & 0x1) == 0) goto label_25;    
            if((0 & 1) == 0)
            {
                goto label_25;
            }
            // 0x012F9D14: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x012F9D18: ORR w20, wzr, #1           | W20 = 1(0x1);                           
            val_17 = 1;
            // 0x012F9D1C: MOVZ w22, #0x64            | W22 = 100 (0x64);//ML01                 
            val_18 = 100;
            // 0x012F9D20: B #0x12f9d38               |  goto label_35;                         
            goto label_35;
            // 0x012F9D24: BL #0x981060               | X0 = sub_981060( ?? 0x0, ????);         
            // 0x012F9D28: LDR x19, [x0]              | X19 = 0x10102464C457F;                  
            val_16 = 1179403647;
            // 0x012F9D2C: BL #0x980920               | X0 = sub_980920( ?? 0x0, ????);         
            // 0x012F9D30: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_18 = 0;
            // 0x012F9D34: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_17 = 0;
            label_35:
            // 0x012F9D38: CBZ x21, #0x12f9da4        | if (value == null) goto label_27;       
            if(value == null)
            {
                goto label_27;
            }
            // 0x012F9D3C: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x012F9D40: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x012F9D44: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x012F9D48: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x012F9D4C: LDRH w9, [x8, #0x102]      | W9 = System.Object.__il2cppRuntimeField_interface_offsets_count;
            // 0x012F9D50: CBZ x9, #0x12f9d7c         | if (System.Object.__il2cppRuntimeField_interface_offsets_count == 0) goto label_28;
            // 0x012F9D54: LDR x10, [x8, #0x98]       | X10 = System.Object.__il2cppRuntimeField_interfaceOffsets;
            // 0x012F9D58: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_14 = 0;
            // 0x012F9D5C: ADD x10, x10, #8           | X10 = (System.Object.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504606937096 (0x1000000000016008);
            label_30:
            // 0x012F9D60: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x012F9D64: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
            // 0x012F9D68: B.EQ #0x12f9d8c            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_29;
            // 0x012F9D6C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_14 = val_14 + 1;
            // 0x012F9D70: ADD x10, x10, #0x10        | X10 = (1152921504606937096 + 16) = 1152921504606937112 (0x1000000000016018);
            // 0x012F9D74: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Object.__il2cppRuntimeField_interface_offsets_count)
            // 0x012F9D78: B.LO #0x12f9d60            | if (0 < System.Object.__il2cppRuntimeField_interface_offsets_count) goto label_30;
            label_28:
            // 0x012F9D7C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x012F9D80: MOV x0, x21                | X0 = value;//m1                         
            val_19 = value;
            // 0x012F9D84: BL #0x2776c24              | X0 = sub_2776C24( ?? value, ????);      
            // 0x012F9D88: B #0x12f9d98               |  goto label_31;                         
            goto label_31;
            label_29:
            // 0x012F9D8C: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x012F9D90: ADD x8, x8, x9, lsl #4     | X8 = (1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x012F9D94: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_31:
            // 0x012F9D98: LDP x8, x1, [x0]           | X8 = 0x10102464C457F; X1 = 0x0;          //  | 
            // 0x012F9D9C: MOV x0, x21                | X0 = value;//m1                         
            // 0x012F9DA0: BLR x8                     | X0 = sub_10102464C457F( ?? value, ????);
            label_27:
            // 0x012F9DA4: CMP w22, #0x62             | STATE = COMPARE(0x0, 0x62)              
            // 0x012F9DA8: B.EQ #0x12f9dc4            | if (val_18 == 0x62) goto label_34;      
            if(val_18 == 98)
            {
                goto label_34;
            }
            // 0x012F9DAC: CMP w22, #0x64             | STATE = COMPARE(0x0, 0x64)              
            // 0x012F9DB0: B.EQ #0x12f9dc8            | if (val_18 == 0x64) goto label_33;      
            if(val_18 == 100)
            {
                goto label_33;
            }
            // 0x012F9DB4: CBZ x19, #0x12f9dc4        | if (0x10102464C457F == 0) goto label_34;
            if(val_16 == 0)
            {
                goto label_34;
            }
            // 0x012F9DB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x012F9DBC: MOV x0, x19                | X0 = 282584257676671 (0x10102464C457F);//ML01
            // 0x012F9DC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x10102464C457F, ????);
            label_34:
            // 0x012F9DC4: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_17 = 0;
            label_33:
            // 0x012F9DC8: MOV w0, w20                | W0 = 0 (0x0);//ML01                     
            // 0x012F9DCC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x012F9DD0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x012F9DD4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x012F9DD8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x012F9DDC: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x012F9DE0: RET                        |  return (System.Boolean)false;          
            return (bool)val_17;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_14:
            // 0x012F9DE4: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            // 0x012F9DE8: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            // 0x012F9DEC: MOVZ w22, #0x62            | W22 = 98 (0x62);//ML01                  
            // 0x012F9DF0: B #0x12f9d38               |  goto label_35;                         
            goto label_35;
            label_4:
            // 0x012F9DF4: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x012F9DF8: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x012F9DFC: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            System.ArgumentNullException val_6 = null;
            // 0x012F9E00: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x012F9E04: ADRP x8, #0x3634000        | X8 = 56836096 (0x3634000);              
            // 0x012F9E08: LDR x8, [x8, #0x7a8]       | X8 = (string**)(1152921510648639888)("source");
            // 0x012F9E0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x012F9E10: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x012F9E14: LDR x1, [x8]               | X1 = "source";                          
            // 0x012F9E18: BL #0x18b3df0              | .ctor(paramName:  "source");            
            val_6 = new System.ArgumentNullException(paramName:  "source");
            // 0x012F9E1C: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
            // 0x012F9E20: LDR x8, [x8, #0x298]       | X8 = 1152921513966495680;               
            // 0x012F9E24: MOV x0, x19                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x012F9E28: LDR x1, [x8]               | X1 = public static System.Boolean Newtonsoft.Json.Utilities.CollectionUtils::ContainsValue<System.Object>(System.Collections.Generic.IEnumerable<TSource> source, System.Object value, System.Collections.Generic.IEqualityComparer<TSource> comparer);
            // 0x012F9E2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentNullException), ????);
            // 0x012F9E30: BL #0x12db37c              | X0 = Newtonsoft.Json.Utilities.CollectionUtils.ContainsValue<System.Object>(source:  val_6, value:  public static System.Boolean Newtonsoft.Json.Utilities.CollectionUtils::ContainsValue<System.Object>(System.Collections.Generic.IEnumerable<TSource> source, System.Object value, System.Collections.Generic.IEqualityComparer<TSource> comparer), comparer:  0);
            bool val_7 = Newtonsoft.Json.Utilities.CollectionUtils.ContainsValue<System.Object>(source:  val_6, value:  public static System.Boolean Newtonsoft.Json.Utilities.CollectionUtils::ContainsValue<System.Object>(System.Collections.Generic.IEnumerable<TSource> source, System.Object value, System.Collections.Generic.IEqualityComparer<TSource> comparer), comparer:  0);
        
        }
        // Generic instance method:
        //
        // file offset: 0x012F9720 VirtAddr: 0x012F9720 -RVA: 0x012F9720 
        // -CollectionUtils.AddRangeDistinct<object>
        //
        //
        // Offset in libil2cpp.so: 0x012F9720 (19896096), len: 164  VirtAddr: 0x012F9720 RVA: 0x012F9720 token: 100686578 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x2863328
        public static bool AddRangeDistinct<T>(System.Collections.Generic.IList<T> list, System.Collections.Generic.IEnumerable<T> values)
        {
            //
            // Disasemble & Code
            // 0x012F9720: STP x22, x21, [sp, #-0x30]! | stack[1152921513966641136] = ???;  stack[1152921513966641144] = ???;  //  dest_result_addr=1152921513966641136 |  dest_result_addr=1152921513966641144
            // 0x012F9724: STP x20, x19, [sp, #0x10]  | stack[1152921513966641152] = ???;  stack[1152921513966641160] = ???;  //  dest_result_addr=1152921513966641152 |  dest_result_addr=1152921513966641160
            // 0x012F9728: STP x29, x30, [sp, #0x20]  | stack[1152921513966641168] = ???;  stack[1152921513966641176] = ???;  //  dest_result_addr=1152921513966641168 |  dest_result_addr=1152921513966641176
            // 0x012F972C: ADD x29, sp, #0x20         | X29 = (1152921513966641136 + 32) = 1152921513966641168 (0x100000022DE32010);
            // 0x012F9730: MOV x20, x3                | X20 = X3;//m1                           
            // 0x012F9734: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x012F9738: MOV x19, x2                | X19 = __RuntimeMethodHiddenParam;//m1   
            // 0x012F973C: MOV x21, x1                | X21 = values;//m1                       
            // 0x012F9740: LDR x22, [x8, #8]          | X22 = X3 + 48 + 8;                      
            // 0x012F9744: MOV x0, x22                | X0 = X3 + 48 + 8;//m1                   
            // 0x012F9748: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 8, ????);
            // 0x012F974C: LDRB w8, [x22, #0x10a]     | W8 = X3 + 48 + 8 + 266;                 
            // 0x012F9750: TBZ w8, #0, #0x12f9784     | if ((X3 + 48 + 8 + 266 & 0x1) == 0) goto label_1;
            if(((X3 + 48 + 8 + 266) & 1) == 0)
            {
                goto label_1;
            }
            // 0x012F9754: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x012F9758: LDR x22, [x8, #8]          | X22 = X3 + 48 + 8;                      
            // 0x012F975C: MOV x0, x22                | X0 = X3 + 48 + 8;//m1                   
            // 0x012F9760: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 8, ????);
            // 0x012F9764: LDR w8, [x22, #0xbc]       | W8 = X3 + 48 + 8 + 188;                 
            // 0x012F9768: CBNZ w8, #0x12f9784        | if (X3 + 48 + 8 + 188 != 0) goto label_1;
            if((X3 + 48 + 8 + 188) != 0)
            {
                goto label_1;
            }
            // 0x012F976C: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x012F9770: LDR x22, [x8, #8]          | X22 = X3 + 48 + 8;                      
            // 0x012F9774: MOV x0, x22                | X0 = X3 + 48 + 8;//m1                   
            // 0x012F9778: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 8, ????);
            // 0x012F977C: MOV x0, x22                | X0 = X3 + 48 + 8;//m1                   
            // 0x012F9780: BL #0x27977a4              | X0 = sub_27977A4( ?? X3 + 48 + 8, ????);
            label_1:
            // 0x012F9784: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x012F9788: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x012F978C: LDR x1, [x8]               | X1 = X3 + 48;                           
            // 0x012F9790: LDR x8, [x1]               | X8 = X3 + 48;                           
            // 0x012F9794: BLR x8                     | X0 = X3 + 48();                         
            // 0x012F9798: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x012F979C: MOV x2, x19                | X2 = __RuntimeMethodHiddenParam;//m1    
            // 0x012F97A0: MOV x3, x0                 | X3 = 0 (0x0);//ML01                     
            // 0x012F97A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x012F97A8: LDR x4, [x8, #0x10]        | X4 = X3 + 48 + 16;                      
            // 0x012F97AC: MOV x1, x21                | X1 = values;//m1                        
            // 0x012F97B0: LDR x5, [x4]               | X5 = X3 + 48 + 16;                      
            // 0x012F97B4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x012F97B8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x012F97BC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x012F97C0: BR x5                      | goto X3 + 48 + 16;                      
            goto X3 + 48 + 16;
        
        }
        // Generic instance method:
        //
        // file offset: 0x012F97C4 VirtAddr: 0x012F97C4 -RVA: 0x012F97C4 
        // -CollectionUtils.AddRangeDistinct<object>
        // -CollectionUtils.AddRangeDistinct<Newtonsoft.Json.Linq.JToken>
        //
        //
        // Offset in libil2cpp.so: 0x012F97C4 (19896260), len: 680  VirtAddr: 0x012F97C4 RVA: 0x012F97C4 token: 100686579 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x2863338
        public static bool AddRangeDistinct<T>(System.Collections.Generic.IList<T> list, System.Collections.Generic.IEnumerable<T> values, System.Collections.Generic.IEqualityComparer<T> comparer)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            // 0x012F97C4: STP x26, x25, [sp, #-0x50]! | stack[1152921513966773584] = ???;  stack[1152921513966773592] = ???;  //  dest_result_addr=1152921513966773584 |  dest_result_addr=1152921513966773592
            // 0x012F97C8: STP x24, x23, [sp, #0x10]  | stack[1152921513966773600] = ???;  stack[1152921513966773608] = ???;  //  dest_result_addr=1152921513966773600 |  dest_result_addr=1152921513966773608
            // 0x012F97CC: STP x22, x21, [sp, #0x20]  | stack[1152921513966773616] = ???;  stack[1152921513966773624] = ???;  //  dest_result_addr=1152921513966773616 |  dest_result_addr=1152921513966773624
            // 0x012F97D0: STP x20, x19, [sp, #0x30]  | stack[1152921513966773632] = ???;  stack[1152921513966773640] = ???;  //  dest_result_addr=1152921513966773632 |  dest_result_addr=1152921513966773640
            // 0x012F97D4: STP x29, x30, [sp, #0x40]  | stack[1152921513966773648] = ???;  stack[1152921513966773656] = ???;  //  dest_result_addr=1152921513966773648 |  dest_result_addr=1152921513966773656
            // 0x012F97D8: ADD x29, sp, #0x40         | X29 = (1152921513966773584 + 64) = 1152921513966773648 (0x100000022DE52590);
            // 0x012F97DC: ADRP x23, #0x3736000       | X23 = 57892864 (0x3736000);             
            // 0x012F97E0: LDRB w8, [x23, #0x8af]     | W8 = (bool)static_value_037368AF;       
            // 0x012F97E4: MOV x19, x4                | X19 = X4;//m1                           
            // 0x012F97E8: MOV x21, x3                | X21 = __RuntimeMethodHiddenParam;//m1   
            // 0x012F97EC: MOV x20, x2                | X20 = comparer;//m1                     
            // 0x012F97F0: MOV x22, x1                | X22 = values;//m1                       
            // 0x012F97F4: TBNZ w8, #0, #0x12f9810    | if (static_value_037368AF == true) goto label_0;
            // 0x012F97F8: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
            // 0x012F97FC: LDR x8, [x8, #0xb58]       | X8 = 0x2B915D8;                         
            // 0x012F9800: LDR w0, [x8]               | W0 = 0x1C3A;                            
            // 0x012F9804: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C3A, ????);     
            // 0x012F9808: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x012F980C: STRB w8, [x23, #0x8af]     | static_value_037368AF = true;            //  dest_result_addr=57895087
            label_0:
            // 0x012F9810: CBNZ x20, #0x12f9818       | if (comparer != null) goto label_1;     
            if(comparer != null)
            {
                goto label_1;
            }
            // 0x012F9814: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C3A, ????);     
            label_1:
            // 0x012F9818: LDR x8, [x19, #0x30]       | X8 = X4 + 48;                           
            // 0x012F981C: LDR x23, [x8]              | X23 = X4 + 48;                          
            // 0x012F9820: MOV x0, x23                | X0 = X4 + 48;//m1                       
            // 0x012F9824: BL #0x277461c              | X0 = sub_277461C( ?? X4 + 48, ????);    
            // 0x012F9828: LDR x8, [x20]              | X8 = typeof(System.Collections.Generic.IEqualityComparer<T>);
            // 0x012F982C: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x012F9830: CBZ x9, #0x12f985c         | if (System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x012F9834: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x012F9838: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_7 = 0;
            // 0x012F983C: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504616521736 (0x100000000093A008);
            label_4:
            // 0x012F9840: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x012F9844: CMP x12, x23               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X4 + 48)
            // 0x012F9848: B.EQ #0x12f9870            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X4 + 48) goto label_3;
            // 0x012F984C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_7 = val_7 + 1;
            // 0x012F9850: ADD x10, x10, #0x10        | X10 = (1152921504616521736 + 16) = 1152921504616521752 (0x100000000093A018);
            // 0x012F9854: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x012F9858: B.LO #0x12f9840            | if (0 < System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x012F985C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x012F9860: MOV x0, x20                | X0 = comparer;//m1                      
            val_7 = comparer;
            // 0x012F9864: MOV x1, x23                | X1 = X4 + 48;//m1                       
            // 0x012F9868: BL #0x2776c24              | X0 = sub_2776C24( ?? comparer, ????);   
            // 0x012F986C: B #0x12f987c               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x012F9870: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x012F9874: ADD x8, x8, x9, lsl #4     | X8 = (1152921504616484864 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x012F9878: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504616484864 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_5:
            // 0x012F987C: LDP x8, x1, [x0]           | X8 = X4 + 48; X1 = X4 + 48 + 8;          //  | 
            // 0x012F9880: MOV x0, x20                | X0 = comparer;//m1                      
            // 0x012F9884: BLR x8                     | X0 = X4 + 48();                         
            // 0x012F9888: ADRP x25, #0x361c000       | X25 = 56737792 (0x361C000);             
            // 0x012F988C: LDR x25, [x25, #0x358]     | X25 = 1152921504608018432;              
            // 0x012F9890: MOV x20, x0                | X20 = comparer;//m1                     
            // 0x012F9894: ORR w24, wzr, #1           | W24 = 1(0x1);                           
            var val_8 = 1;
            // 0x012F9898: B #0x12f98a0               |  goto label_6;                          
            goto label_6;
            label_18:
            // 0x012F989C: AND w24, w24, w0           | W24 = (1 & comparer);                   
            val_8 = val_8 & comparer;
            label_6:
            // 0x012F98A0: CBNZ x20, #0x12f98a8       | if (comparer != null) goto label_7;     
            if(comparer != null)
            {
                goto label_7;
            }
            // 0x012F98A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? comparer, ????);   
            label_7:
            // 0x012F98A8: LDR x8, [x20]              | X8 = typeof(System.Collections.Generic.IEqualityComparer<T>);
            // 0x012F98AC: LDR x1, [x25]              | X1 = typeof(System.Collections.IEnumerator);
            // 0x012F98B0: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x012F98B4: CBZ x9, #0x12f98e0         | if (System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_8;
            // 0x012F98B8: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x012F98BC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_9 = 0;
            // 0x012F98C0: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504616521736 (0x100000000093A008);
            label_10:
            // 0x012F98C4: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x012F98C8: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IEnumerator))
            // 0x012F98CC: B.EQ #0x12f98f0            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_9;
            // 0x012F98D0: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_9 = val_9 + 1;
            // 0x012F98D4: ADD x10, x10, #0x10        | X10 = (1152921504616521736 + 16) = 1152921504616521752 (0x100000000093A018);
            // 0x012F98D8: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x012F98DC: B.LO #0x12f98c4            | if (0 < System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interface_offsets_count) goto label_10;
            label_8:
            // 0x012F98E0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x012F98E4: MOV x0, x20                | X0 = comparer;//m1                      
            val_8 = comparer;
            // 0x012F98E8: BL #0x2776c24              | X0 = sub_2776C24( ?? comparer, ????);   
            // 0x012F98EC: B #0x12f9900               |  goto label_11;                         
            goto label_11;
            label_9:
            // 0x012F98F0: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x012F98F4: ADD w9, w9, #1             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1);
            // 0x012F98F8: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504616484864 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1));
            // 0x012F98FC: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504616484864 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1)).272
            label_11:
            // 0x012F9900: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.Generic.IEqualityComparer<T>);  //  | 
            // 0x012F9904: MOV x0, x20                | X0 = comparer;//m1                      
            // 0x012F9908: BLR x8                     | X0 = sub_1000000000931000( ?? comparer, ????);
            // 0x012F990C: AND w8, w0, #1             | W8 = (comparer & 1);                    
            System.Collections.Generic.IEqualityComparer<T> val_3 = comparer & 1;
            // 0x012F9910: TBZ w8, #0, #0x12f9a60     | if (((comparer & 1) & 0x1) == 0) goto label_12;
            if((val_3 & 1) == 0)
            {
                goto label_12;
            }
            // 0x012F9914: CBNZ x20, #0x12f991c       | if (comparer != null) goto label_13;    
            if(comparer != null)
            {
                goto label_13;
            }
            // 0x012F9918: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? comparer, ????);   
            label_13:
            // 0x012F991C: LDR x8, [x19, #0x30]       | X8 = X4 + 48;                           
            // 0x012F9920: LDR x23, [x8, #8]          | X23 = X4 + 48 + 8;                      
            // 0x012F9924: MOV x0, x23                | X0 = X4 + 48 + 8;//m1                   
            // 0x012F9928: BL #0x277461c              | X0 = sub_277461C( ?? X4 + 48 + 8, ????);
            // 0x012F992C: LDR x8, [x20]              | X8 = typeof(System.Collections.Generic.IEqualityComparer<T>);
            // 0x012F9930: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x012F9934: CBZ x9, #0x12f9960         | if (System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_14;
            // 0x012F9938: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x012F993C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_10 = 0;
            // 0x012F9940: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504616521736 (0x100000000093A008);
            label_16:
            // 0x012F9944: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x012F9948: CMP x12, x23               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X4 + 48 + 8)
            // 0x012F994C: B.EQ #0x12f9974            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X4 + 48 + 8) goto label_15;
            // 0x012F9950: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_10 = val_10 + 1;
            // 0x012F9954: ADD x10, x10, #0x10        | X10 = (1152921504616521736 + 16) = 1152921504616521752 (0x100000000093A018);
            // 0x012F9958: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x012F995C: B.LO #0x12f9944            | if (0 < System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interface_offsets_count) goto label_16;
            label_14:
            // 0x012F9960: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x012F9964: MOV x0, x20                | X0 = comparer;//m1                      
            val_10 = comparer;
            // 0x012F9968: MOV x1, x23                | X1 = X4 + 48 + 8;//m1                   
            val_9 = X4 + 48 + 8;
            // 0x012F996C: BL #0x2776c24              | X0 = sub_2776C24( ?? comparer, ????);   
            // 0x012F9970: B #0x12f9980               |  goto label_17;                         
            goto label_17;
            label_15:
            // 0x012F9974: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x012F9978: ADD x8, x8, x9, lsl #4     | X8 = (1152921504616484864 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x012F997C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504616484864 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_17:
            // 0x012F9980: LDP x8, x1, [x0]           | X8 = X4 + 48 + 8; X1 = X4 + 48 + 8 + 8;  //  | 
            // 0x012F9984: MOV x0, x20                | X0 = comparer;//m1                      
            // 0x012F9988: BLR x8                     | X0 = X4 + 48 + 8();                     
            // 0x012F998C: MOV x2, x0                 | X2 = comparer;//m1                      
            // 0x012F9990: LDR x8, [x19, #0x30]       | X8 = X4 + 48;                           
            // 0x012F9994: LDR x4, [x8, #0x10]        | X4 = X4 + 48 + 16;                      
            // 0x012F9998: LDR x8, [x4]               | X8 = X4 + 48 + 16;                      
            // 0x012F999C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x012F99A0: MOV x1, x22                | X1 = values;//m1                        
            // 0x012F99A4: MOV x3, x21                | X3 = __RuntimeMethodHiddenParam;//m1    
            // 0x012F99A8: BLR x8                     | X0 = X4 + 48 + 16();                    
            // 0x012F99AC: B #0x12f989c               |  goto label_18;                         
            goto label_18;
            // 0x012F99B0: BL #0x981060               | X0 = sub_981060( ?? 0x0, ????);         
            // 0x012F99B4: LDR x19, [x0]              | X19 = 0x10102464C457F;                  
            // 0x012F99B8: BL #0x980920               | X0 = sub_980920( ?? 0x0, ????);         
            // 0x012F99BC: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            label_26:
            // 0x012F99C0: CBZ x20, #0x12f9a2c        | if (comparer == null) goto label_19;    
            if(comparer == null)
            {
                goto label_19;
            }
            // 0x012F99C4: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x012F99C8: LDR x8, [x20]              | X8 = typeof(System.Collections.Generic.IEqualityComparer<T>);
            // 0x012F99CC: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x012F99D0: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x012F99D4: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x012F99D8: CBZ x9, #0x12f9a04         | if (System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_20;
            // 0x012F99DC: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x012F99E0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_11 = 0;
            // 0x012F99E4: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504616521736 (0x100000000093A008);
            label_22:
            // 0x012F99E8: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x012F99EC: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
            // 0x012F99F0: B.EQ #0x12f9a14            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_21;
            // 0x012F99F4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_11 = val_11 + 1;
            // 0x012F99F8: ADD x10, x10, #0x10        | X10 = (1152921504616521736 + 16) = 1152921504616521752 (0x100000000093A018);
            // 0x012F99FC: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x012F9A00: B.LO #0x12f99e8            | if (0 < System.Collections.Generic.IEqualityComparer<T>.__il2cppRuntimeField_interface_offsets_count) goto label_22;
            label_20:
            // 0x012F9A04: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x012F9A08: MOV x0, x20                | X0 = comparer;//m1                      
            val_11 = comparer;
            // 0x012F9A0C: BL #0x2776c24              | X0 = sub_2776C24( ?? comparer, ????);   
            // 0x012F9A10: B #0x12f9a20               |  goto label_23;                         
            goto label_23;
            label_21:
            // 0x012F9A14: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x012F9A18: ADD x8, x8, x9, lsl #4     | X8 = (1152921504616484864 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x012F9A1C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504616484864 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_23:
            // 0x012F9A20: LDP x8, x1, [x0]           | X8 = 0x10102464C457F; X1 = 0x0;          //  | 
            // 0x012F9A24: MOV x0, x20                | X0 = comparer;//m1                      
            // 0x012F9A28: BLR x8                     | X0 = sub_10102464C457F( ?? comparer, ????);
            label_19:
            // 0x012F9A2C: CMP w21, #0x41             | STATE = COMPARE(0x0, 0x41)              
            // 0x012F9A30: B.EQ #0x12f9a44            | if (0 == 0x41) goto label_25;           
            if(0 == 65)
            {
                goto label_25;
            }
            // 0x012F9A34: CBZ x19, #0x12f9a44        | if (0x10102464C457F == 0) goto label_25;
            if(1179403647 == 0)
            {
                goto label_25;
            }
            // 0x012F9A38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x012F9A3C: MOV x0, x19                | X0 = 282584257676671 (0x10102464C457F);//ML01
            // 0x012F9A40: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x10102464C457F, ????);
            label_25:
            // 0x012F9A44: AND w0, w24, #1            | W0 = ((1 & comparer) & 1);              
            System.Collections.Generic.IEqualityComparer<T> val_6 = val_8 & 1;
            // 0x012F9A48: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x012F9A4C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x012F9A50: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x012F9A54: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x012F9A58: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x012F9A5C: RET                        |  return (System.Boolean)((1 & comparer) & 1);
            return (bool)val_6;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_12:
            // 0x012F9A60: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            // 0x012F9A64: MOVZ w21, #0x41            | W21 = 65 (0x41);//ML01                  
            // 0x012F9A68: B #0x12f99c0               |  goto label_26;                         
            goto label_26;
        
        }
        // Generic instance method:
        //
        // file offset: 0x00B7D61C VirtAddr: 0x00B7D61C -RVA: 0x00B7D61C 
        // -CollectionUtils.IndexOf<object>
        // -CollectionUtils.IndexOf<System.Reflection.PropertyInfo>
        //
        //
        // Offset in libil2cpp.so: 0x00B7D61C (12047900), len: 708  VirtAddr: 0x00B7D61C RVA: 0x00B7D61C token: 100686580 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x2863348
        public static int IndexOf<T>(System.Collections.Generic.IEnumerable<T> collection, System.Func<T, bool> predicate)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            // 0x00B7D61C: STP x24, x23, [sp, #-0x40]! | stack[1152921513966906080] = ???;  stack[1152921513966906088] = ???;  //  dest_result_addr=1152921513966906080 |  dest_result_addr=1152921513966906088
            // 0x00B7D620: STP x22, x21, [sp, #0x10]  | stack[1152921513966906096] = ???;  stack[1152921513966906104] = ???;  //  dest_result_addr=1152921513966906096 |  dest_result_addr=1152921513966906104
            // 0x00B7D624: STP x20, x19, [sp, #0x20]  | stack[1152921513966906112] = ???;  stack[1152921513966906120] = ???;  //  dest_result_addr=1152921513966906112 |  dest_result_addr=1152921513966906120
            // 0x00B7D628: STP x29, x30, [sp, #0x30]  | stack[1152921513966906128] = ???;  stack[1152921513966906136] = ???;  //  dest_result_addr=1152921513966906128 |  dest_result_addr=1152921513966906136
            // 0x00B7D62C: ADD x29, sp, #0x30         | X29 = (1152921513966906080 + 48) = 1152921513966906128 (0x100000022DE72B10);
            // 0x00B7D630: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00B7D634: LDRB w8, [x22, #0x9cf]     | W8 = (bool)static_value_037339CF;       
            // 0x00B7D638: MOV x20, x3                | X20 = X3;//m1                           
            // 0x00B7D63C: MOV x21, x2                | X21 = __RuntimeMethodHiddenParam;//m1   
            // 0x00B7D640: MOV x19, x1                | X19 = predicate;//m1                    
            // 0x00B7D644: TBNZ w8, #0, #0xb7d660     | if (static_value_037339CF == true) goto label_0;
            // 0x00B7D648: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x00B7D64C: LDR x8, [x8, #0x618]       | X8 = 0x2B91610;                         
            // 0x00B7D650: LDR w0, [x8]               | W0 = 0x1C48;                            
            // 0x00B7D654: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C48, ????);     
            // 0x00B7D658: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00B7D65C: STRB w8, [x22, #0x9cf]     | static_value_037339CF = true;            //  dest_result_addr=57883087
            label_0:
            // 0x00B7D660: CBNZ x19, #0xb7d668        | if (predicate != null) goto label_1;    
            if(predicate != null)
            {
                goto label_1;
            }
            // 0x00B7D664: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C48, ????);     
            label_1:
            // 0x00B7D668: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x00B7D66C: LDR x22, [x8]              | X22 = X3 + 48;                          
            // 0x00B7D670: MOV x0, x22                | X0 = X3 + 48;//m1                       
            // 0x00B7D674: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48, ????);    
            // 0x00B7D678: LDR x8, [x19]              | X8 = typeof(System.Func<T, System.Boolean>);
            // 0x00B7D67C: LDRH w9, [x8, #0x102]      | W9 = System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00B7D680: CBZ x9, #0xb7d6ac          | if (System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x00B7D684: LDR x10, [x8, #0x98]       | X10 = System.Func<T, TResult>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00B7D688: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_7 = 0;
            // 0x00B7D68C: ADD x10, x10, #8           | X10 = (System.Func<T, TResult>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504688140296 (0x1000000004D87008);
            label_4:
            // 0x00B7D690: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00B7D694: CMP x12, x22               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X3 + 48)
            // 0x00B7D698: B.EQ #0xb7d6c0             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X3 + 48) goto label_3;
            // 0x00B7D69C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_7 = val_7 + 1;
            // 0x00B7D6A0: ADD x10, x10, #0x10        | X10 = (1152921504688140296 + 16) = 1152921504688140312 (0x1000000004D87018);
            // 0x00B7D6A4: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00B7D6A8: B.LO #0xb7d690             | if (0 < System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x00B7D6AC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B7D6B0: MOV x0, x19                | X0 = predicate;//m1                     
            val_7 = predicate;
            // 0x00B7D6B4: MOV x1, x22                | X1 = X3 + 48;//m1                       
            // 0x00B7D6B8: BL #0x2776c24              | X0 = sub_2776C24( ?? predicate, ????);  
            // 0x00B7D6BC: B #0xb7d6cc                |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x00B7D6C0: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00B7D6C4: ADD x8, x8, x9, lsl #4     | X8 = (1152921504688103424 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00B7D6C8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504688103424 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_5:
            // 0x00B7D6CC: LDP x8, x1, [x0]           | X8 = X3 + 48; X1 = X3 + 48 + 8;          //  | 
            // 0x00B7D6D0: MOV x0, x19                | X0 = predicate;//m1                     
            // 0x00B7D6D4: BLR x8                     | X0 = X3 + 48();                         
            // 0x00B7D6D8: ADRP x24, #0x361c000       | X24 = 56737792 (0x361C000);             
            // 0x00B7D6DC: LDR x24, [x24, #0x358]     | X24 = 1152921504608018432;              
            // 0x00B7D6E0: MOV x19, x0                | X19 = predicate;//m1                    
            // 0x00B7D6E4: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_8 = 0;
            // 0x00B7D6E8: B #0xb7d6f0                |  goto label_6;                          
            goto label_6;
            label_19:
            // 0x00B7D6EC: ADD w22, w22, #1           | W22 = (val_8 + 1) = val_8 (0x00000001); 
            val_8 = 1;
            label_6:
            // 0x00B7D6F0: CBNZ x19, #0xb7d6f8        | if (predicate != null) goto label_7;    
            if(predicate != null)
            {
                goto label_7;
            }
            // 0x00B7D6F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? predicate, ????);  
            label_7:
            // 0x00B7D6F8: LDR x8, [x19]              | X8 = typeof(System.Func<T, System.Boolean>);
            // 0x00B7D6FC: LDR x1, [x24]              | X1 = typeof(System.Collections.IEnumerator);
            // 0x00B7D700: LDRH w9, [x8, #0x102]      | W9 = System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00B7D704: CBZ x9, #0xb7d730          | if (System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_8;
            // 0x00B7D708: LDR x10, [x8, #0x98]       | X10 = System.Func<T, TResult>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00B7D70C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_8 = 0;
            // 0x00B7D710: ADD x10, x10, #8           | X10 = (System.Func<T, TResult>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504688140296 (0x1000000004D87008);
            label_10:
            // 0x00B7D714: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00B7D718: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IEnumerator))
            // 0x00B7D71C: B.EQ #0xb7d740             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_9;
            // 0x00B7D720: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x00B7D724: ADD x10, x10, #0x10        | X10 = (1152921504688140296 + 16) = 1152921504688140312 (0x1000000004D87018);
            // 0x00B7D728: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00B7D72C: B.LO #0xb7d714             | if (0 < System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count) goto label_10;
            label_8:
            // 0x00B7D730: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00B7D734: MOV x0, x19                | X0 = predicate;//m1                     
            val_9 = predicate;
            // 0x00B7D738: BL #0x2776c24              | X0 = sub_2776C24( ?? predicate, ????);  
            // 0x00B7D73C: B #0xb7d750                |  goto label_11;                         
            goto label_11;
            label_9:
            // 0x00B7D740: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00B7D744: ADD w9, w9, #1             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1);
            // 0x00B7D748: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504688103424 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1));
            // 0x00B7D74C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504688103424 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1)).272
            label_11:
            // 0x00B7D750: LDP x8, x1, [x0]           | X8 = typeof(System.Func<T, System.Boolean>);  //  | 
            // 0x00B7D754: MOV x0, x19                | X0 = predicate;//m1                     
            // 0x00B7D758: BLR x8                     | X0 = sub_1000000004D7E000( ?? predicate, ????);
            // 0x00B7D75C: AND w8, w0, #1             | W8 = (predicate & 1);                   
            System.Func<T, System.Boolean> val_3 = predicate & 1;
            // 0x00B7D760: TBZ w8, #0, #0xb7d8d0      | if (((predicate & 1) & 0x1) == 0) goto label_12;
            if((val_3 & 1) == 0)
            {
                goto label_12;
            }
            // 0x00B7D764: CBNZ x19, #0xb7d76c        | if (predicate != null) goto label_13;   
            if(predicate != null)
            {
                goto label_13;
            }
            // 0x00B7D768: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? predicate, ????);  
            label_13:
            // 0x00B7D76C: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x00B7D770: LDR x23, [x8, #8]          | X23 = X3 + 48 + 8;                      
            // 0x00B7D774: MOV x0, x23                | X0 = X3 + 48 + 8;//m1                   
            // 0x00B7D778: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 8, ????);
            // 0x00B7D77C: LDR x8, [x19]              | X8 = typeof(System.Func<T, System.Boolean>);
            // 0x00B7D780: LDRH w9, [x8, #0x102]      | W9 = System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00B7D784: CBZ x9, #0xb7d7b0          | if (System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_14;
            // 0x00B7D788: LDR x10, [x8, #0x98]       | X10 = System.Func<T, TResult>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00B7D78C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_9 = 0;
            // 0x00B7D790: ADD x10, x10, #8           | X10 = (System.Func<T, TResult>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504688140296 (0x1000000004D87008);
            label_16:
            // 0x00B7D794: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00B7D798: CMP x12, x23               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X3 + 48 + 8)
            // 0x00B7D79C: B.EQ #0xb7d7c4             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X3 + 48 + 8) goto label_15;
            // 0x00B7D7A0: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_9 = val_9 + 1;
            // 0x00B7D7A4: ADD x10, x10, #0x10        | X10 = (1152921504688140296 + 16) = 1152921504688140312 (0x1000000004D87018);
            // 0x00B7D7A8: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00B7D7AC: B.LO #0xb7d794             | if (0 < System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count) goto label_16;
            label_14:
            // 0x00B7D7B0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B7D7B4: MOV x0, x19                | X0 = predicate;//m1                     
            val_11 = predicate;
            // 0x00B7D7B8: MOV x1, x23                | X1 = X3 + 48 + 8;//m1                   
            val_10 = X3 + 48 + 8;
            // 0x00B7D7BC: BL #0x2776c24              | X0 = sub_2776C24( ?? predicate, ????);  
            // 0x00B7D7C0: B #0xb7d7d0                |  goto label_17;                         
            goto label_17;
            label_15:
            // 0x00B7D7C4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00B7D7C8: ADD x8, x8, x9, lsl #4     | X8 = (1152921504688103424 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00B7D7CC: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504688103424 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_17:
            // 0x00B7D7D0: LDP x8, x1, [x0]           | X8 = X3 + 48 + 8; X1 = X3 + 48 + 8 + 8;  //  | 
            // 0x00B7D7D4: MOV x0, x19                | X0 = predicate;//m1                     
            // 0x00B7D7D8: BLR x8                     | X0 = X3 + 48 + 8();                     
            // 0x00B7D7DC: MOV x23, x0                | X23 = predicate;//m1                    
            // 0x00B7D7E0: CBNZ x21, #0xb7d7e8        | if (__RuntimeMethodHiddenParam != 0) goto label_18;
            if(__RuntimeMethodHiddenParam != 0)
            {
                goto label_18;
            }
            // 0x00B7D7E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? predicate, ????);  
            label_18:
            // 0x00B7D7E8: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x00B7D7EC: LDR x2, [x8, #0x10]        | X2 = X3 + 48 + 16;                      
            // 0x00B7D7F0: LDR x8, [x2]               | X8 = X3 + 48 + 16;                      
            // 0x00B7D7F4: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam;//m1    
            // 0x00B7D7F8: MOV x1, x23                | X1 = predicate;//m1                     
            // 0x00B7D7FC: BLR x8                     | X0 = X3 + 48 + 16();                    
            // 0x00B7D800: AND w8, w0, #1             | W8 = (__RuntimeMethodHiddenParam & 1);  
            var val_5 = __RuntimeMethodHiddenParam & 1;
            // 0x00B7D804: TBZ w8, #0, #0xb7d6ec      | if (((__RuntimeMethodHiddenParam & 1) & 0x1) == 0) goto label_19;
            if((val_5 & 1) == 0)
            {
                goto label_19;
            }
            // 0x00B7D808: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_12 = 0;
            // 0x00B7D80C: MOVZ w21, #0x4b            | W21 = 75 (0x4B);//ML01                  
            val_13 = 75;
            // 0x00B7D810: B #0xb7d828                |  goto label_29;                         
            goto label_29;
            // 0x00B7D814: BL #0x981060               | X0 = sub_981060( ?? __RuntimeMethodHiddenParam, ????);
            // 0x00B7D818: LDR x20, [x0]              | X20 = __RuntimeMethodHiddenParam;       
            val_12 = mem[__RuntimeMethodHiddenParam];
            val_12 = __RuntimeMethodHiddenParam;
            // 0x00B7D81C: BL #0x980920               | X0 = sub_980920( ?? __RuntimeMethodHiddenParam, ????);
            // 0x00B7D820: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x00B7D824: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_29:
            // 0x00B7D828: CBZ x19, #0xb7d894         | if (predicate == null) goto label_21;   
            if(predicate == null)
            {
                goto label_21;
            }
            // 0x00B7D82C: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x00B7D830: LDR x8, [x19]              | X8 = typeof(System.Func<T, System.Boolean>);
            // 0x00B7D834: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x00B7D838: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x00B7D83C: LDRH w9, [x8, #0x102]      | W9 = System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00B7D840: CBZ x9, #0xb7d86c          | if (System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_22;
            // 0x00B7D844: LDR x10, [x8, #0x98]       | X10 = System.Func<T, TResult>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00B7D848: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_10 = 0;
            // 0x00B7D84C: ADD x10, x10, #8           | X10 = (System.Func<T, TResult>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504688140296 (0x1000000004D87008);
            label_24:
            // 0x00B7D850: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00B7D854: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
            // 0x00B7D858: B.EQ #0xb7d87c             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_23;
            // 0x00B7D85C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_10 = val_10 + 1;
            // 0x00B7D860: ADD x10, x10, #0x10        | X10 = (1152921504688140296 + 16) = 1152921504688140312 (0x1000000004D87018);
            // 0x00B7D864: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00B7D868: B.LO #0xb7d850             | if (0 < System.Func<T, TResult>.__il2cppRuntimeField_interface_offsets_count) goto label_24;
            label_22:
            // 0x00B7D86C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B7D870: MOV x0, x19                | X0 = predicate;//m1                     
            val_14 = predicate;
            // 0x00B7D874: BL #0x2776c24              | X0 = sub_2776C24( ?? predicate, ????);  
            // 0x00B7D878: B #0xb7d888                |  goto label_25;                         
            goto label_25;
            label_23:
            // 0x00B7D87C: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00B7D880: ADD x8, x8, x9, lsl #4     | X8 = (1152921504688103424 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00B7D884: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504688103424 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_25:
            // 0x00B7D888: LDP x8, x1, [x0]           | X8 = __RuntimeMethodHiddenParam; X1 = __RuntimeMethodHiddenParam + 8; //  | 
            // 0x00B7D88C: MOV x0, x19                | X0 = predicate;//m1                     
            // 0x00B7D890: BLR x8                     | X0 = __RuntimeMethodHiddenParam();      
            label_21:
            // 0x00B7D894: CMP w21, #0x49             | STATE = COMPARE(0x0, 0x49)              
            // 0x00B7D898: B.EQ #0xb7d8b4             | if (val_13 == 0x49) goto label_28;      
            if(val_13 == 73)
            {
                goto label_28;
            }
            // 0x00B7D89C: CMP w21, #0x4b             | STATE = COMPARE(0x0, 0x4B)              
            // 0x00B7D8A0: B.EQ #0xb7d8b8             | if (val_13 == 0x4B) goto label_27;      
            if(val_13 == 75)
            {
                goto label_27;
            }
            // 0x00B7D8A4: CBZ x20, #0xb7d8b4         | if (__RuntimeMethodHiddenParam == 0) goto label_28;
            if(val_12 == 0)
            {
                goto label_28;
            }
            // 0x00B7D8A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B7D8AC: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam;//m1    
            // 0x00B7D8B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? __RuntimeMethodHiddenParam, ????);
            label_28:
            // 0x00B7D8B4: MOVN w22, #0               | W22 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_27:
            // 0x00B7D8B8: MOV w0, w22                | W0 = 0 (0x0);//ML01                     
            // 0x00B7D8BC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00B7D8C0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00B7D8C4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00B7D8C8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00B7D8CC: RET                        |  return (System.Int32)0;                
            return (int)val_8;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
            label_12:
            // 0x00B7D8D0: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            // 0x00B7D8D4: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            // 0x00B7D8D8: MOVZ w21, #0x49            | W21 = 73 (0x49);//ML01                  
            // 0x00B7D8DC: B #0xb7d828                |  goto label_29;                         
            goto label_29;
        
        }
        // Generic instance method:
        //
        // file offset: 0x00B7D8E0 VirtAddr: 0x00B7D8E0 -RVA: 0x00B7D8E0 
        // -CollectionUtils.IndexOf<object>
        //
        //
        // Offset in libil2cpp.so: 0x00B7D8E0 (12048608), len: 164  VirtAddr: 0x00B7D8E0 RVA: 0x00B7D8E0 token: 100686581 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x2863358
        public static int IndexOf<TSource>(System.Collections.Generic.IEnumerable<TSource> list, TSource value)
        {
            //
            // Disasemble & Code
            // 0x00B7D8E0: STP x22, x21, [sp, #-0x30]! | stack[1152921513967034480] = ???;  stack[1152921513967034488] = ???;  //  dest_result_addr=1152921513967034480 |  dest_result_addr=1152921513967034488
            // 0x00B7D8E4: STP x20, x19, [sp, #0x10]  | stack[1152921513967034496] = ???;  stack[1152921513967034504] = ???;  //  dest_result_addr=1152921513967034496 |  dest_result_addr=1152921513967034504
            // 0x00B7D8E8: STP x29, x30, [sp, #0x20]  | stack[1152921513967034512] = ???;  stack[1152921513967034520] = ???;  //  dest_result_addr=1152921513967034512 |  dest_result_addr=1152921513967034520
            // 0x00B7D8EC: ADD x29, sp, #0x20         | X29 = (1152921513967034480 + 32) = 1152921513967034512 (0x100000022DE92090);
            // 0x00B7D8F0: MOV x20, x3                | X20 = X3;//m1                           
            // 0x00B7D8F4: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x00B7D8F8: MOV x19, x2                | X19 = __RuntimeMethodHiddenParam;//m1   
            // 0x00B7D8FC: MOV x21, x1                | X21 = value;//m1                        
            // 0x00B7D900: LDR x22, [x8, #8]          | X22 = X3 + 48 + 8;                      
            // 0x00B7D904: MOV x0, x22                | X0 = X3 + 48 + 8;//m1                   
            // 0x00B7D908: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 8, ????);
            // 0x00B7D90C: LDRB w8, [x22, #0x10a]     | W8 = X3 + 48 + 8 + 266;                 
            // 0x00B7D910: TBZ w8, #0, #0xb7d944      | if ((X3 + 48 + 8 + 266 & 0x1) == 0) goto label_1;
            if(((X3 + 48 + 8 + 266) & 1) == 0)
            {
                goto label_1;
            }
            // 0x00B7D914: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x00B7D918: LDR x22, [x8, #8]          | X22 = X3 + 48 + 8;                      
            // 0x00B7D91C: MOV x0, x22                | X0 = X3 + 48 + 8;//m1                   
            // 0x00B7D920: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 8, ????);
            // 0x00B7D924: LDR w8, [x22, #0xbc]       | W8 = X3 + 48 + 8 + 188;                 
            // 0x00B7D928: CBNZ w8, #0xb7d944         | if (X3 + 48 + 8 + 188 != 0) goto label_1;
            if((X3 + 48 + 8 + 188) != 0)
            {
                goto label_1;
            }
            // 0x00B7D92C: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x00B7D930: LDR x22, [x8, #8]          | X22 = X3 + 48 + 8;                      
            // 0x00B7D934: MOV x0, x22                | X0 = X3 + 48 + 8;//m1                   
            // 0x00B7D938: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 8, ????);
            // 0x00B7D93C: MOV x0, x22                | X0 = X3 + 48 + 8;//m1                   
            // 0x00B7D940: BL #0x27977a4              | X0 = sub_27977A4( ?? X3 + 48 + 8, ????);
            label_1:
            // 0x00B7D944: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x00B7D948: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B7D94C: LDR x1, [x8]               | X1 = X3 + 48;                           
            // 0x00B7D950: LDR x8, [x1]               | X8 = X3 + 48;                           
            // 0x00B7D954: BLR x8                     | X0 = X3 + 48();                         
            // 0x00B7D958: LDR x8, [x20, #0x30]       | X8 = X3 + 48;                           
            // 0x00B7D95C: MOV x2, x19                | X2 = __RuntimeMethodHiddenParam;//m1    
            // 0x00B7D960: MOV x3, x0                 | X3 = 0 (0x0);//ML01                     
            // 0x00B7D964: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B7D968: LDR x4, [x8, #0x10]        | X4 = X3 + 48 + 16;                      
            // 0x00B7D96C: MOV x1, x21                | X1 = value;//m1                         
            // 0x00B7D970: LDR x5, [x4]               | X5 = X3 + 48 + 16;                      
            // 0x00B7D974: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00B7D978: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00B7D97C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00B7D980: BR x5                      | goto X3 + 48 + 16;                      
            goto X3 + 48 + 16;
        
        }
        // Generic instance method:
        //
        // file offset: 0x00B7D984 VirtAddr: 0x00B7D984 -RVA: 0x00B7D984 
        // -CollectionUtils.IndexOf<object>
        // -CollectionUtils.IndexOf<Newtonsoft.Json.Linq.JToken>
        //
        //
        // Offset in libil2cpp.so: 0x00B7D984 (12048772), len: 816  VirtAddr: 0x00B7D984 RVA: 0x00B7D984 token: 100686582 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x2863368
        public static int IndexOf<TSource>(System.Collections.Generic.IEnumerable<TSource> list, TSource value, System.Collections.Generic.IEqualityComparer<TSource> comparer)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            // 0x00B7D984: STP x26, x25, [sp, #-0x50]! | stack[1152921513967166928] = ???;  stack[1152921513967166936] = ???;  //  dest_result_addr=1152921513967166928 |  dest_result_addr=1152921513967166936
            // 0x00B7D988: STP x24, x23, [sp, #0x10]  | stack[1152921513967166944] = ???;  stack[1152921513967166952] = ???;  //  dest_result_addr=1152921513967166944 |  dest_result_addr=1152921513967166952
            // 0x00B7D98C: STP x22, x21, [sp, #0x20]  | stack[1152921513967166960] = ???;  stack[1152921513967166968] = ???;  //  dest_result_addr=1152921513967166960 |  dest_result_addr=1152921513967166968
            // 0x00B7D990: STP x20, x19, [sp, #0x30]  | stack[1152921513967166976] = ???;  stack[1152921513967166984] = ???;  //  dest_result_addr=1152921513967166976 |  dest_result_addr=1152921513967166984
            // 0x00B7D994: STP x29, x30, [sp, #0x40]  | stack[1152921513967166992] = ???;  stack[1152921513967167000] = ???;  //  dest_result_addr=1152921513967166992 |  dest_result_addr=1152921513967167000
            // 0x00B7D998: ADD x29, sp, #0x40         | X29 = (1152921513967166928 + 64) = 1152921513967166992 (0x100000022DEB2610);
            // 0x00B7D99C: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00B7D9A0: LDRB w8, [x22, #0x9d0]     | W8 = (bool)static_value_037339D0;       
            // 0x00B7D9A4: MOV x20, x4                | X20 = X4;//m1                           
            // 0x00B7D9A8: MOV x21, x3                | X21 = __RuntimeMethodHiddenParam;//m1   
            // 0x00B7D9AC: MOV x23, x2                | X23 = comparer;//m1                     
            // 0x00B7D9B0: MOV x19, x1                | X19 = value;//m1                        
            // 0x00B7D9B4: TBNZ w8, #0, #0xb7d9d0     | if (static_value_037339D0 == true) goto label_0;
            // 0x00B7D9B8: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
            // 0x00B7D9BC: LDR x8, [x8, #0x7f0]       | X8 = 0x2B9160C;                         
            // 0x00B7D9C0: LDR w0, [x8]               | W0 = 0x1C47;                            
            // 0x00B7D9C4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C47, ????);     
            // 0x00B7D9C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00B7D9CC: STRB w8, [x22, #0x9d0]     | static_value_037339D0 = true;            //  dest_result_addr=57883088
            label_0:
            // 0x00B7D9D0: CBNZ x19, #0xb7d9d8        | if (value != null) goto label_1;        
            if(value != null)
            {
                goto label_1;
            }
            // 0x00B7D9D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C47, ????);     
            label_1:
            // 0x00B7D9D8: LDR x8, [x20, #0x30]       | X8 = X4 + 48;                           
            // 0x00B7D9DC: LDR x22, [x8]              | X22 = X4 + 48;                          
            // 0x00B7D9E0: MOV x0, x22                | X0 = X4 + 48;//m1                       
            // 0x00B7D9E4: BL #0x277461c              | X0 = sub_277461C( ?? X4 + 48, ????);    
            // 0x00B7D9E8: LDR x8, [x19]              | X8 = typeof(System.Object);             
            // 0x00B7D9EC: LDRH w9, [x8, #0x102]      | W9 = System.Object.__il2cppRuntimeField_interface_offsets_count;
            // 0x00B7D9F0: CBZ x9, #0xb7da1c          | if (System.Object.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x00B7D9F4: LDR x10, [x8, #0x98]       | X10 = System.Object.__il2cppRuntimeField_interfaceOffsets;
            // 0x00B7D9F8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_7 = 0;
            // 0x00B7D9FC: ADD x10, x10, #8           | X10 = (System.Object.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504606937096 (0x1000000000016008);
            label_4:
            // 0x00B7DA00: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00B7DA04: CMP x12, x22               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X4 + 48)
            // 0x00B7DA08: B.EQ #0xb7da30             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X4 + 48) goto label_3;
            // 0x00B7DA0C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_7 = val_7 + 1;
            // 0x00B7DA10: ADD x10, x10, #0x10        | X10 = (1152921504606937096 + 16) = 1152921504606937112 (0x1000000000016018);
            // 0x00B7DA14: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Object.__il2cppRuntimeField_interface_offsets_count)
            // 0x00B7DA18: B.LO #0xb7da00             | if (0 < System.Object.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x00B7DA1C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B7DA20: MOV x0, x19                | X0 = value;//m1                         
            val_8 = value;
            // 0x00B7DA24: MOV x1, x22                | X1 = X4 + 48;//m1                       
            // 0x00B7DA28: BL #0x2776c24              | X0 = sub_2776C24( ?? value, ????);      
            // 0x00B7DA2C: B #0xb7da3c                |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x00B7DA30: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00B7DA34: ADD x8, x8, x9, lsl #4     | X8 = (1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00B7DA38: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_5:
            // 0x00B7DA3C: LDP x8, x1, [x0]           | X8 = X4 + 48; X1 = X4 + 48 + 8;          //  | 
            // 0x00B7DA40: MOV x0, x19                | X0 = value;//m1                         
            // 0x00B7DA44: BLR x8                     | X0 = X4 + 48();                         
            // 0x00B7DA48: ADRP x26, #0x361c000       | X26 = 56737792 (0x361C000);             
            // 0x00B7DA4C: LDR x26, [x26, #0x358]     | X26 = 1152921504608018432;              
            // 0x00B7DA50: MOV x19, x0                | X19 = value;//m1                        
            // 0x00B7DA54: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x00B7DA58: B #0xb7da60                |  goto label_6;                          
            goto label_6;
            label_23:
            // 0x00B7DA5C: ADD w22, w22, #1           | W22 = (val_9 + 1) = val_9 (0x00000001); 
            val_9 = 1;
            label_6:
            // 0x00B7DA60: CBNZ x19, #0xb7da68        | if (value != null) goto label_7;        
            if(value != null)
            {
                goto label_7;
            }
            // 0x00B7DA64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? value, ????);      
            label_7:
            // 0x00B7DA68: LDR x8, [x19]              | X8 = typeof(System.Object);             
            // 0x00B7DA6C: LDR x1, [x26]              | X1 = typeof(System.Collections.IEnumerator);
            // 0x00B7DA70: LDRH w9, [x8, #0x102]      | W9 = System.Object.__il2cppRuntimeField_interface_offsets_count;
            // 0x00B7DA74: CBZ x9, #0xb7daa0          | if (System.Object.__il2cppRuntimeField_interface_offsets_count == 0) goto label_8;
            // 0x00B7DA78: LDR x10, [x8, #0x98]       | X10 = System.Object.__il2cppRuntimeField_interfaceOffsets;
            // 0x00B7DA7C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_8 = 0;
            // 0x00B7DA80: ADD x10, x10, #8           | X10 = (System.Object.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504606937096 (0x1000000000016008);
            label_10:
            // 0x00B7DA84: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00B7DA88: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IEnumerator))
            // 0x00B7DA8C: B.EQ #0xb7dab0             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_9;
            // 0x00B7DA90: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x00B7DA94: ADD x10, x10, #0x10        | X10 = (1152921504606937096 + 16) = 1152921504606937112 (0x1000000000016018);
            // 0x00B7DA98: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Object.__il2cppRuntimeField_interface_offsets_count)
            // 0x00B7DA9C: B.LO #0xb7da84             | if (0 < System.Object.__il2cppRuntimeField_interface_offsets_count) goto label_10;
            label_8:
            // 0x00B7DAA0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00B7DAA4: MOV x0, x19                | X0 = value;//m1                         
            val_10 = value;
            // 0x00B7DAA8: BL #0x2776c24              | X0 = sub_2776C24( ?? value, ????);      
            // 0x00B7DAAC: B #0xb7dac0                |  goto label_11;                         
            goto label_11;
            label_9:
            // 0x00B7DAB0: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00B7DAB4: ADD w9, w9, #1             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1);
            // 0x00B7DAB8: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1));
            // 0x00B7DABC: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1)).272
            label_11:
            // 0x00B7DAC0: LDP x8, x1, [x0]           | X8 = typeof(System.Object);              //  | 
            // 0x00B7DAC4: MOV x0, x19                | X0 = value;//m1                         
            // 0x00B7DAC8: BLR x8                     | X0 = sub_100000000000D000( ?? value, ????);
            // 0x00B7DACC: AND w8, w0, #1             | W8 = (value & 1);                       
            object val_3 = value & 1;
            // 0x00B7DAD0: TBZ w8, #0, #0xb7dca4      | if (((value & 1) & 0x1) == 0) goto label_12;
            if((val_3 & 1) == 0)
            {
                goto label_12;
            }
            // 0x00B7DAD4: CBNZ x19, #0xb7dadc        | if (value != null) goto label_13;       
            if(value != null)
            {
                goto label_13;
            }
            // 0x00B7DAD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? value, ????);      
            label_13:
            // 0x00B7DADC: LDR x8, [x20, #0x30]       | X8 = X4 + 48;                           
            // 0x00B7DAE0: LDR x24, [x8, #8]          | X24 = X4 + 48 + 8;                      
            // 0x00B7DAE4: MOV x0, x24                | X0 = X4 + 48 + 8;//m1                   
            // 0x00B7DAE8: BL #0x277461c              | X0 = sub_277461C( ?? X4 + 48 + 8, ????);
            // 0x00B7DAEC: LDR x8, [x19]              | X8 = typeof(System.Object);             
            // 0x00B7DAF0: LDRH w9, [x8, #0x102]      | W9 = System.Object.__il2cppRuntimeField_interface_offsets_count;
            // 0x00B7DAF4: CBZ x9, #0xb7db20          | if (System.Object.__il2cppRuntimeField_interface_offsets_count == 0) goto label_14;
            // 0x00B7DAF8: LDR x10, [x8, #0x98]       | X10 = System.Object.__il2cppRuntimeField_interfaceOffsets;
            // 0x00B7DAFC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_9 = 0;
            // 0x00B7DB00: ADD x10, x10, #8           | X10 = (System.Object.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504606937096 (0x1000000000016008);
            label_16:
            // 0x00B7DB04: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00B7DB08: CMP x12, x24               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X4 + 48 + 8)
            // 0x00B7DB0C: B.EQ #0xb7db34             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X4 + 48 + 8) goto label_15;
            // 0x00B7DB10: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_9 = val_9 + 1;
            // 0x00B7DB14: ADD x10, x10, #0x10        | X10 = (1152921504606937096 + 16) = 1152921504606937112 (0x1000000000016018);
            // 0x00B7DB18: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Object.__il2cppRuntimeField_interface_offsets_count)
            // 0x00B7DB1C: B.LO #0xb7db04             | if (0 < System.Object.__il2cppRuntimeField_interface_offsets_count) goto label_16;
            label_14:
            // 0x00B7DB20: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B7DB24: MOV x0, x19                | X0 = value;//m1                         
            val_12 = value;
            // 0x00B7DB28: MOV x1, x24                | X1 = X4 + 48 + 8;//m1                   
            val_11 = X4 + 48 + 8;
            // 0x00B7DB2C: BL #0x2776c24              | X0 = sub_2776C24( ?? value, ????);      
            // 0x00B7DB30: B #0xb7db40                |  goto label_17;                         
            goto label_17;
            label_15:
            // 0x00B7DB34: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00B7DB38: ADD x8, x8, x9, lsl #4     | X8 = (1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00B7DB3C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_17:
            // 0x00B7DB40: LDP x8, x1, [x0]           | X8 = X4 + 48 + 8; X1 = X4 + 48 + 8 + 8;  //  | 
            // 0x00B7DB44: MOV x0, x19                | X0 = value;//m1                         
            // 0x00B7DB48: BLR x8                     | X0 = X4 + 48 + 8();                     
            // 0x00B7DB4C: MOV x24, x0                | X24 = value;//m1                        
            // 0x00B7DB50: CBNZ x21, #0xb7db58        | if (__RuntimeMethodHiddenParam != 0) goto label_18;
            if(__RuntimeMethodHiddenParam != 0)
            {
                goto label_18;
            }
            // 0x00B7DB54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? value, ????);      
            label_18:
            // 0x00B7DB58: LDR x8, [x20, #0x30]       | X8 = X4 + 48;                           
            // 0x00B7DB5C: LDR x25, [x8, #0x10]       | X25 = X4 + 48 + 16;                     
            // 0x00B7DB60: MOV x0, x25                | X0 = X4 + 48 + 16;//m1                  
            // 0x00B7DB64: BL #0x277461c              | X0 = sub_277461C( ?? X4 + 48 + 16, ????);
            // 0x00B7DB68: LDR x8, [x21]              | X8 = __RuntimeMethodHiddenParam;        
            var val_12 = __RuntimeMethodHiddenParam;
            // 0x00B7DB6C: LDRH w9, [x8, #0x102]      | W9 = __RuntimeMethodHiddenParam + 258;  
            // 0x00B7DB70: CBZ x9, #0xb7db9c          | if (__RuntimeMethodHiddenParam + 258 == 0) goto label_19;
            if((__RuntimeMethodHiddenParam + 258) == 0)
            {
                goto label_19;
            }
            // 0x00B7DB74: LDR x10, [x8, #0x98]       | X10 = __RuntimeMethodHiddenParam + 152; 
            var val_10 = __RuntimeMethodHiddenParam + 152;
            // 0x00B7DB78: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_11 = 0;
            // 0x00B7DB7C: ADD x10, x10, #8           | X10 = (__RuntimeMethodHiddenParam + 152 + 8);
            val_10 = val_10 + 8;
            label_21:
            // 0x00B7DB80: LDUR x12, [x10, #-8]       | X12 = (__RuntimeMethodHiddenParam + 152 + 8) + -8;
            // 0x00B7DB84: CMP x12, x25               | STATE = COMPARE((__RuntimeMethodHiddenParam + 152 + 8) + -8, X4 + 48 + 16)
            // 0x00B7DB88: B.EQ #0xb7dbb0             | if ((__RuntimeMethodHiddenParam + 152 + 8) + -8 == X4 + 48 + 16) goto label_20;
            if(((__RuntimeMethodHiddenParam + 152 + 8) + -8) == (X4 + 48 + 16))
            {
                goto label_20;
            }
            // 0x00B7DB8C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_11 = val_11 + 1;
            // 0x00B7DB90: ADD x10, x10, #0x10        | X10 = ((__RuntimeMethodHiddenParam + 152 + 8) + 16);
            val_10 = val_10 + 16;
            // 0x00B7DB94: CMP x11, x9                | STATE = COMPARE((0 + 1), __RuntimeMethodHiddenParam + 258)
            // 0x00B7DB98: B.LO #0xb7db80             | if (0 < __RuntimeMethodHiddenParam + 258) goto label_21;
            if(val_11 < (__RuntimeMethodHiddenParam + 258))
            {
                goto label_21;
            }
            label_19:
            // 0x00B7DB9C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B7DBA0: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam;//m1    
            val_13 = __RuntimeMethodHiddenParam;
            // 0x00B7DBA4: MOV x1, x25                | X1 = X4 + 48 + 16;//m1                  
            // 0x00B7DBA8: BL #0x2776c24              | X0 = sub_2776C24( ?? __RuntimeMethodHiddenParam, ????);
            // 0x00B7DBAC: B #0xb7dbbc                |  goto label_22;                         
            goto label_22;
            label_20:
            // 0x00B7DBB0: LDR w9, [x10]              | W9 = (__RuntimeMethodHiddenParam + 152 + 8);
            // 0x00B7DBB4: ADD x8, x8, x9, lsl #4     | X8 = (__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4);
            val_12 = val_12 + (((__RuntimeMethodHiddenParam + 152 + 8)) << 4);
            // 0x00B7DBB8: ADD x0, x8, #0x110         | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272);
            val_13 = val_12 + 272;
            label_22:
            // 0x00B7DBBC: LDP x8, x3, [x0]           | X8 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272); X3 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272) + 8; //  | 
            // 0x00B7DBC0: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam;//m1    
            // 0x00B7DBC4: MOV x1, x24                | X1 = value;//m1                         
            // 0x00B7DBC8: MOV x2, x23                | X2 = comparer;//m1                      
            // 0x00B7DBCC: BLR x8                     | X0 = ((__RuntimeMethodHiddenParam + ((__RuntimeMethodHiddenParam + 152 + 8)) << 4) + 272)();
            // 0x00B7DBD0: AND w8, w0, #1             | W8 = (__RuntimeMethodHiddenParam & 1);  
            var val_5 = __RuntimeMethodHiddenParam & 1;
            // 0x00B7DBD4: TBZ w8, #0, #0xb7da5c      | if (((__RuntimeMethodHiddenParam & 1) & 0x1) == 0) goto label_23;
            if((val_5 & 1) == 0)
            {
                goto label_23;
            }
            // 0x00B7DBD8: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_14 = 0;
            // 0x00B7DBDC: MOVZ w21, #0x4c            | W21 = 76 (0x4C);//ML01                  
            val_15 = 76;
            // 0x00B7DBE0: B #0xb7dbf8                |  goto label_33;                         
            goto label_33;
            // 0x00B7DBE4: BL #0x981060               | X0 = sub_981060( ?? __RuntimeMethodHiddenParam, ????);
            // 0x00B7DBE8: LDR x20, [x0]              | X20 = __RuntimeMethodHiddenParam;       
            val_14 = mem[__RuntimeMethodHiddenParam];
            val_14 = __RuntimeMethodHiddenParam;
            // 0x00B7DBEC: BL #0x980920               | X0 = sub_980920( ?? __RuntimeMethodHiddenParam, ????);
            // 0x00B7DBF0: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x00B7DBF4: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_33:
            // 0x00B7DBF8: CBZ x19, #0xb7dc64         | if (value == null) goto label_25;       
            if(value == null)
            {
                goto label_25;
            }
            // 0x00B7DBFC: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x00B7DC00: LDR x8, [x19]              | X8 = typeof(System.Object);             
            // 0x00B7DC04: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x00B7DC08: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x00B7DC0C: LDRH w9, [x8, #0x102]      | W9 = System.Object.__il2cppRuntimeField_interface_offsets_count;
            // 0x00B7DC10: CBZ x9, #0xb7dc3c          | if (System.Object.__il2cppRuntimeField_interface_offsets_count == 0) goto label_26;
            // 0x00B7DC14: LDR x10, [x8, #0x98]       | X10 = System.Object.__il2cppRuntimeField_interfaceOffsets;
            // 0x00B7DC18: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_13 = 0;
            // 0x00B7DC1C: ADD x10, x10, #8           | X10 = (System.Object.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504606937096 (0x1000000000016008);
            label_28:
            // 0x00B7DC20: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00B7DC24: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
            // 0x00B7DC28: B.EQ #0xb7dc4c             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_27;
            // 0x00B7DC2C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_13 = val_13 + 1;
            // 0x00B7DC30: ADD x10, x10, #0x10        | X10 = (1152921504606937096 + 16) = 1152921504606937112 (0x1000000000016018);
            // 0x00B7DC34: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Object.__il2cppRuntimeField_interface_offsets_count)
            // 0x00B7DC38: B.LO #0xb7dc20             | if (0 < System.Object.__il2cppRuntimeField_interface_offsets_count) goto label_28;
            label_26:
            // 0x00B7DC3C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00B7DC40: MOV x0, x19                | X0 = value;//m1                         
            val_16 = value;
            // 0x00B7DC44: BL #0x2776c24              | X0 = sub_2776C24( ?? value, ????);      
            // 0x00B7DC48: B #0xb7dc58                |  goto label_29;                         
            goto label_29;
            label_27:
            // 0x00B7DC4C: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00B7DC50: ADD x8, x8, x9, lsl #4     | X8 = (1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00B7DC54: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_29:
            // 0x00B7DC58: LDP x8, x1, [x0]           | X8 = __RuntimeMethodHiddenParam; X1 = __RuntimeMethodHiddenParam + 8; //  | 
            // 0x00B7DC5C: MOV x0, x19                | X0 = value;//m1                         
            // 0x00B7DC60: BLR x8                     | X0 = __RuntimeMethodHiddenParam();      
            label_25:
            // 0x00B7DC64: CMP w21, #0x4a             | STATE = COMPARE(0x0, 0x4A)              
            // 0x00B7DC68: B.EQ #0xb7dc84             | if (val_15 == 0x4A) goto label_32;      
            if(val_15 == 74)
            {
                goto label_32;
            }
            // 0x00B7DC6C: CMP w21, #0x4c             | STATE = COMPARE(0x0, 0x4C)              
            // 0x00B7DC70: B.EQ #0xb7dc88             | if (val_15 == 0x4C) goto label_31;      
            if(val_15 == 76)
            {
                goto label_31;
            }
            // 0x00B7DC74: CBZ x20, #0xb7dc84         | if (__RuntimeMethodHiddenParam == 0) goto label_32;
            if(val_14 == 0)
            {
                goto label_32;
            }
            // 0x00B7DC78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B7DC7C: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam;//m1    
            // 0x00B7DC80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? __RuntimeMethodHiddenParam, ????);
            label_32:
            // 0x00B7DC84: MOVN w22, #0               | W22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_31:
            // 0x00B7DC88: MOV w0, w22                | W0 = 0 (0x0);//ML01                     
            // 0x00B7DC8C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00B7DC90: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00B7DC94: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00B7DC98: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00B7DC9C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00B7DCA0: RET                        |  return (System.Int32)0;                
            return (int)val_9;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
            label_12:
            // 0x00B7DCA4: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            // 0x00B7DCA8: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            // 0x00B7DCAC: MOVZ w21, #0x4a            | W21 = 74 (0x4A);//ML01                  
            // 0x00B7DCB0: B #0xb7dbf8                |  goto label_33;                         
            goto label_33;
        
        }
        // Generic instance method:
        //
        // file offset: 0x012F9568 VirtAddr: 0x012F9568 -RVA: 0x012F9568 
        // -CollectionUtils.<CastValid`1>m__0<object>
        //
        //
        // Offset in libil2cpp.so: 0x012F9568 (19895656), len: 64  VirtAddr: 0x012F9568 RVA: 0x012F9568 token: 100686583 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private static bool <CastValid`1>m__0<T>(object o)
        {
            //
            // Disasemble & Code
            // 0x012F9568: STP x20, x19, [sp, #-0x20]! | stack[1152921513967295360] = ???;  stack[1152921513967295368] = ???;  //  dest_result_addr=1152921513967295360 |  dest_result_addr=1152921513967295368
            // 0x012F956C: STP x29, x30, [sp, #0x10]  | stack[1152921513967295376] = ???;  stack[1152921513967295384] = ???;  //  dest_result_addr=1152921513967295376 |  dest_result_addr=1152921513967295384
            // 0x012F9570: ADD x29, sp, #0x10         | X29 = (1152921513967295360 + 16) = 1152921513967295376 (0x100000022DED1B90);
            // 0x012F9574: LDR x8, [x2, #0x30]        | X8 = X2 + 48;                           
            // 0x012F9578: MOV x20, x1                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x012F957C: LDR x19, [x8]              | X19 = X2 + 48;                          
            // 0x012F9580: MOV x0, x19                | X0 = X2 + 48;//m1                       
            // 0x012F9584: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 48, ????);    
            // 0x012F9588: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam;//m1    
            // 0x012F958C: MOV x1, x19                | X1 = X2 + 48;//m1                       
            // 0x012F9590: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? __RuntimeMethodHiddenParam, ????);
            // 0x012F9594: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x012F9598: CMP x0, #0                 | STATE = COMPARE(__RuntimeMethodHiddenParam, 0x0)
            // 0x012F959C: CSET w0, ne                | W0 = __RuntimeMethodHiddenParam != 0x0 ? 1 : 0;
            var val_1 = (__RuntimeMethodHiddenParam != 0) ? 1 : 0;
            // 0x012F95A0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x012F95A4: RET                        |  return (System.Boolean)__RuntimeMethodHiddenParam != 0x0 ? 1 : 0;
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
    
    }

}
