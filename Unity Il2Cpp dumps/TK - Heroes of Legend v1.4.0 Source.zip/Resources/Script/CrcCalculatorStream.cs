using UnityEngine;

namespace Pathfinding.Ionic.Crc
{
    public class CrcCalculatorStream : Stream, IDisposable
    {
        // Fields
        private static readonly long UnsetLengthLimit; // static_offset: 0x00000000
        internal System.IO.Stream _innerStream; //  0x00000010
        private Pathfinding.Ionic.Crc.CRC32 _Crc32; //  0x00000018
        private long _lengthLimit; //  0x00000020
        private bool _leaveOpen; //  0x00000028
        
        // Properties
        public long TotalBytesSlurped { get; }
        public int Crc { get; }
        public override bool CanRead { get; }
        public override bool CanSeek { get; }
        public override bool CanWrite { get; }
        public override long Length { get; }
        public override long Position { get; set; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x0196FA24 (26671652), len: 136  VirtAddr: 0x0196FA24 RVA: 0x0196FA24 token: 100663909 methodIndex: 20831 delegateWrapperIndex: 0 methodInvoker: 0
        public CrcCalculatorStream(System.IO.Stream stream)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x0196FA24: STP x22, x21, [sp, #-0x30]! | stack[1152921509740215712] = ???;  stack[1152921509740215720] = ???;  //  dest_result_addr=1152921509740215712 |  dest_result_addr=1152921509740215720
            // 0x0196FA28: STP x20, x19, [sp, #0x10]  | stack[1152921509740215728] = ???;  stack[1152921509740215736] = ???;  //  dest_result_addr=1152921509740215728 |  dest_result_addr=1152921509740215736
            // 0x0196FA2C: STP x29, x30, [sp, #0x20]  | stack[1152921509740215744] = ???;  stack[1152921509740215752] = ???;  //  dest_result_addr=1152921509740215744 |  dest_result_addr=1152921509740215752
            // 0x0196FA30: ADD x29, sp, #0x20         | X29 = (1152921509740215712 + 32) = 1152921509740215744 (0x1000000131F8FDC0);
            // 0x0196FA34: ADRP x21, #0x3739000       | X21 = 57905152 (0x3739000);             
            // 0x0196FA38: LDRB w8, [x21, #0x3d7]     | W8 = (bool)static_value_037393D7;       
            // 0x0196FA3C: MOV x19, x1                | X19 = stream;//m1                       
            // 0x0196FA40: MOV x20, x0                | X20 = 1152921509740227760 (0x1000000131F92CB0);//ML01
            // 0x0196FA44: TBNZ w8, #0, #0x196fa60    | if (static_value_037393D7 == true) goto label_0;
            // 0x0196FA48: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
            // 0x0196FA4C: LDR x8, [x8, #0x408]       | X8 = 0x2B92DB0;                         
            // 0x0196FA50: LDR w0, [x8]               | W0 = 0x2231;                            
            // 0x0196FA54: BL #0x2782188              | X0 = sub_2782188( ?? 0x2231, ????);     
            // 0x0196FA58: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0196FA5C: STRB w8, [x21, #0x3d7]     | static_value_037393D7 = true;            //  dest_result_addr=57906135
            label_0:
            // 0x0196FA60: ADRP x21, #0x362d000       | X21 = 56807424 (0x362D000);             
            // 0x0196FA64: LDR x21, [x21, #0xb58]     | X21 = 1152921504754024448;              
            // 0x0196FA68: LDR x0, [x21]              | X0 = typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream);
            val_1 = null;
            // 0x0196FA6C: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Ionic.Crc.CrcCalculatorStream.__il2cppRuntimeField_10A;
            // 0x0196FA70: TBZ w8, #0, #0x196fa84     | if (Pathfinding.Ionic.Crc.CrcCalculatorStream.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0196FA74: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Ionic.Crc.CrcCalculatorStream.__il2cppRuntimeField_cctor_finished;
            // 0x0196FA78: CBNZ w8, #0x196fa84        | if (Pathfinding.Ionic.Crc.CrcCalculatorStream.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0196FA7C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream), ????);
            // 0x0196FA80: LDR x0, [x21]              | X0 = typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream);
            val_1 = null;
            label_2:
            // 0x0196FA84: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.Ionic.Crc.CrcCalculatorStream.__il2cppRuntimeField_static_fields;
            // 0x0196FA88: MOV x0, x20                | X0 = 1152921509740227760 (0x1000000131F92CB0);//ML01
            // 0x0196FA8C: MOV x3, x19                | X3 = stream;//m1                        
            // 0x0196FA90: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0196FA94: LDR x2, [x8]               | X2 = Pathfinding.Ionic.Crc.CrcCalculatorStream.UnsetLengthLimit;
            // 0x0196FA98: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0196FA9C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0196FAA0: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x0196FAA4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0196FAA8: B #0x196faac               | this..ctor(leaveOpen:  true, length:  Pathfinding.Ionic.Crc.CrcCalculatorStream.UnsetLengthLimit, stream:  stream, crc32:  0); return;
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0196FB90 (26672016), len: 140  VirtAddr: 0x0196FB90 RVA: 0x0196FB90 token: 100663910 methodIndex: 20832 delegateWrapperIndex: 0 methodInvoker: 0
        public CrcCalculatorStream(System.IO.Stream stream, bool leaveOpen)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x0196FB90: STP x22, x21, [sp, #-0x30]! | stack[1152921509740335904] = ???;  stack[1152921509740335912] = ???;  //  dest_result_addr=1152921509740335904 |  dest_result_addr=1152921509740335912
            // 0x0196FB94: STP x20, x19, [sp, #0x10]  | stack[1152921509740335920] = ???;  stack[1152921509740335928] = ???;  //  dest_result_addr=1152921509740335920 |  dest_result_addr=1152921509740335928
            // 0x0196FB98: STP x29, x30, [sp, #0x20]  | stack[1152921509740335936] = ???;  stack[1152921509740335944] = ???;  //  dest_result_addr=1152921509740335936 |  dest_result_addr=1152921509740335944
            // 0x0196FB9C: ADD x29, sp, #0x20         | X29 = (1152921509740335904 + 32) = 1152921509740335936 (0x1000000131FAD340);
            // 0x0196FBA0: ADRP x22, #0x3739000       | X22 = 57905152 (0x3739000);             
            // 0x0196FBA4: LDRB w8, [x22, #0x3d8]     | W8 = (bool)static_value_037393D8;       
            // 0x0196FBA8: MOV w20, w2                | W20 = leaveOpen;//m1                    
            // 0x0196FBAC: MOV x19, x1                | X19 = stream;//m1                       
            // 0x0196FBB0: MOV x21, x0                | X21 = 1152921509740347952 (0x1000000131FB0230);//ML01
            // 0x0196FBB4: TBNZ w8, #0, #0x196fbd0    | if (static_value_037393D8 == true) goto label_0;
            // 0x0196FBB8: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x0196FBBC: LDR x8, [x8, #0x8a0]       | X8 = 0x2B92DB8;                         
            // 0x0196FBC0: LDR w0, [x8]               | W0 = 0x2233;                            
            // 0x0196FBC4: BL #0x2782188              | X0 = sub_2782188( ?? 0x2233, ????);     
            // 0x0196FBC8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0196FBCC: STRB w8, [x22, #0x3d8]     | static_value_037393D8 = true;            //  dest_result_addr=57906136
            label_0:
            // 0x0196FBD0: ADRP x22, #0x362d000       | X22 = 56807424 (0x362D000);             
            // 0x0196FBD4: LDR x22, [x22, #0xb58]     | X22 = 1152921504754024448;              
            // 0x0196FBD8: LDR x0, [x22]              | X0 = typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream);
            val_2 = null;
            // 0x0196FBDC: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Ionic.Crc.CrcCalculatorStream.__il2cppRuntimeField_10A;
            // 0x0196FBE0: TBZ w8, #0, #0x196fbf4     | if (Pathfinding.Ionic.Crc.CrcCalculatorStream.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0196FBE4: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Ionic.Crc.CrcCalculatorStream.__il2cppRuntimeField_cctor_finished;
            // 0x0196FBE8: CBNZ w8, #0x196fbf4        | if (Pathfinding.Ionic.Crc.CrcCalculatorStream.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0196FBEC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream), ????);
            // 0x0196FBF0: LDR x0, [x22]              | X0 = typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream);
            val_2 = null;
            label_2:
            // 0x0196FBF4: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.Ionic.Crc.CrcCalculatorStream.__il2cppRuntimeField_static_fields;
            // 0x0196FBF8: AND w1, w20, #1            | W1 = (leaveOpen & 1);                   
            bool val_1 = leaveOpen;
            // 0x0196FBFC: MOV x3, x19                | X3 = stream;//m1                        
            // 0x0196FC00: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0196FC04: LDR x2, [x8]               | X2 = Pathfinding.Ionic.Crc.CrcCalculatorStream.UnsetLengthLimit;
            // 0x0196FC08: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0196FC0C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0196FC10: MOV x0, x21                | X0 = 1152921509740347952 (0x1000000131FB0230);//ML01
            // 0x0196FC14: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0196FC18: B #0x196faac               | this..ctor(leaveOpen:  bool val_1 = leaveOpen, length:  Pathfinding.Ionic.Crc.CrcCalculatorStream.UnsetLengthLimit, stream:  stream, crc32:  0); return;
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0196FC1C (26672156), len: 172  VirtAddr: 0x0196FC1C RVA: 0x0196FC1C token: 100663911 methodIndex: 20833 delegateWrapperIndex: 0 methodInvoker: 0
        public CrcCalculatorStream(System.IO.Stream stream, long length)
        {
            //
            // Disasemble & Code
            // 0x0196FC1C: STP x22, x21, [sp, #-0x30]! | stack[1152921509740457120] = ???;  stack[1152921509740457128] = ???;  //  dest_result_addr=1152921509740457120 |  dest_result_addr=1152921509740457128
            // 0x0196FC20: STP x20, x19, [sp, #0x10]  | stack[1152921509740457136] = ???;  stack[1152921509740457144] = ???;  //  dest_result_addr=1152921509740457136 |  dest_result_addr=1152921509740457144
            // 0x0196FC24: STP x29, x30, [sp, #0x20]  | stack[1152921509740457152] = ???;  stack[1152921509740457160] = ???;  //  dest_result_addr=1152921509740457152 |  dest_result_addr=1152921509740457160
            // 0x0196FC28: ADD x29, sp, #0x20         | X29 = (1152921509740457120 + 32) = 1152921509740457152 (0x1000000131FCACC0);
            // 0x0196FC2C: ADRP x22, #0x3739000       | X22 = 57905152 (0x3739000);             
            // 0x0196FC30: LDRB w8, [x22, #0x3d9]     | W8 = (bool)static_value_037393D9;       
            // 0x0196FC34: MOV x19, x2                | X19 = length;//m1                       
            // 0x0196FC38: MOV x20, x1                | X20 = stream;//m1                       
            // 0x0196FC3C: MOV x21, x0                | X21 = 1152921509740469168 (0x1000000131FCDBB0);//ML01
            // 0x0196FC40: TBNZ w8, #0, #0x196fc5c    | if (static_value_037393D9 == true) goto label_0;
            // 0x0196FC44: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x0196FC48: LDR x8, [x8, #0xb40]       | X8 = 0x2B92DB4;                         
            // 0x0196FC4C: LDR w0, [x8]               | W0 = 0x2232;                            
            // 0x0196FC50: BL #0x2782188              | X0 = sub_2782188( ?? 0x2232, ????);     
            // 0x0196FC54: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0196FC58: STRB w8, [x22, #0x3d9]     | static_value_037393D9 = true;            //  dest_result_addr=57906137
            label_0:
            // 0x0196FC5C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0196FC60: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x0196FC64: MOV x0, x21                | X0 = 1152921509740469168 (0x1000000131FCDBB0);//ML01
            // 0x0196FC68: MOV x2, x19                | X2 = length;//m1                        
            // 0x0196FC6C: MOV x3, x20                | X3 = stream;//m1                        
            // 0x0196FC70: BL #0x196faac              | this..ctor(leaveOpen:  true, length:  length, stream:  stream, crc32:  0);
            // 0x0196FC74: TBNZ x19, #0x3f, #0x196fc88 | if ((length & 0x8000000000000000) != 0) goto label_1;
            if((length & 9223372036854775808) != 0)
            {
                goto label_1;
            }
            // 0x0196FC78: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0196FC7C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0196FC80: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0196FC84: RET                        |  return;                                
            return;
            label_1:
            // 0x0196FC88: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x0196FC8C: LDR x8, [x8, #0x1b8]       | X8 = 1152921504651841536;               
            // 0x0196FC90: LDR x0, [x8]               | X0 = typeof(System.ArgumentException);  
            System.ArgumentException val_1 = null;
            // 0x0196FC94: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentException), ????);
            // 0x0196FC98: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x0196FC9C: LDR x8, [x8, #0x520]       | X8 = (string**)(1152921509637911408)("length");
            // 0x0196FCA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0196FCA4: MOV x19, x0                | X19 = 1152921504651841536 (0x1000000002AE9000);//ML01
            // 0x0196FCA8: LDR x1, [x8]               | X1 = "length";                          
            // 0x0196FCAC: BL #0x18b5590              | .ctor(message:  "length");              
            val_1 = new System.ArgumentException(message:  "length");
            // 0x0196FCB0: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x0196FCB4: LDR x8, [x8, #0x600]       | X8 = 1152921509740444144;               
            // 0x0196FCB8: MOV x0, x19                | X0 = 1152921504651841536 (0x1000000002AE9000);//ML01
            // 0x0196FCBC: LDR x1, [x8]               | X1 = public System.Void Pathfinding.Ionic.Crc.CrcCalculatorStream::.ctor(System.IO.Stream stream, long length);
            // 0x0196FCC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentException), ????);
            // 0x0196FCC4: BL #0x196f408              | SlurpBlock(block:  public System.Void Pathfinding.Ionic.Crc.CrcCalculatorStream::.ctor(System.IO.Stream stream, long length), offset:  0, count:  stream);
            SlurpBlock(block:  public System.Void Pathfinding.Ionic.Crc.CrcCalculatorStream::.ctor(System.IO.Stream stream, long length), offset:  0, count:  stream);
        
        }
        //
        // Offset in libil2cpp.so: 0x0196FAAC (26671788), len: 228  VirtAddr: 0x0196FAAC RVA: 0x0196FAAC token: 100663912 methodIndex: 20834 delegateWrapperIndex: 0 methodInvoker: 0
        private CrcCalculatorStream(bool leaveOpen, long length, System.IO.Stream stream, Pathfinding.Ionic.Crc.CRC32 crc32)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.Ionic.Crc.CRC32 val_4;
            // 0x0196FAAC: STP x24, x23, [sp, #-0x40]! | stack[1152921509740581392] = ???;  stack[1152921509740581400] = ???;  //  dest_result_addr=1152921509740581392 |  dest_result_addr=1152921509740581400
            // 0x0196FAB0: STP x22, x21, [sp, #0x10]  | stack[1152921509740581408] = ???;  stack[1152921509740581416] = ???;  //  dest_result_addr=1152921509740581408 |  dest_result_addr=1152921509740581416
            // 0x0196FAB4: STP x20, x19, [sp, #0x20]  | stack[1152921509740581424] = ???;  stack[1152921509740581432] = ???;  //  dest_result_addr=1152921509740581424 |  dest_result_addr=1152921509740581432
            // 0x0196FAB8: STP x29, x30, [sp, #0x30]  | stack[1152921509740581440] = ???;  stack[1152921509740581448] = ???;  //  dest_result_addr=1152921509740581440 |  dest_result_addr=1152921509740581448
            // 0x0196FABC: ADD x29, sp, #0x30         | X29 = (1152921509740581392 + 48) = 1152921509740581440 (0x1000000131FE9240);
            // 0x0196FAC0: ADRP x24, #0x3739000       | X24 = 57905152 (0x3739000);             
            // 0x0196FAC4: LDRB w8, [x24, #0x3da]     | W8 = (bool)static_value_037393DA;       
            // 0x0196FAC8: MOV x22, x4                | X22 = crc32;//m1                        
            val_4 = crc32;
            // 0x0196FACC: MOV x23, x3                | X23 = stream;//m1                       
            // 0x0196FAD0: MOV x21, x2                | X21 = length;//m1                       
            // 0x0196FAD4: MOV w20, w1                | W20 = leaveOpen;//m1                    
            // 0x0196FAD8: MOV x19, x0                | X19 = 1152921509740593456 (0x1000000131FEC130);//ML01
            // 0x0196FADC: TBNZ w8, #0, #0x196faf8    | if (static_value_037393DA == true) goto label_0;
            // 0x0196FAE0: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
            // 0x0196FAE4: LDR x8, [x8, #0xe38]       | X8 = 0x2B92DBC;                         
            // 0x0196FAE8: LDR w0, [x8]               | W0 = 0x2234;                            
            // 0x0196FAEC: BL #0x2782188              | X0 = sub_2782188( ?? 0x2234, ????);     
            // 0x0196FAF0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0196FAF4: STRB w8, [x24, #0x3da]     | static_value_037393DA = true;            //  dest_result_addr=57906138
            label_0:
            // 0x0196FAF8: MOVN x8, #0x62             | X8 = 98 (0x62);//ML01                   
            // 0x0196FAFC: STR x8, [x19, #0x20]       | this._lengthLimit = 98;                  //  dest_result_addr=1152921509740593488
            this._lengthLimit = 98;
            // 0x0196FB00: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
            // 0x0196FB04: LDR x8, [x8, #0x898]       | X8 = 1152921504622342144;               
            // 0x0196FB08: LDR x0, [x8]               | X0 = typeof(System.IO.Stream);          
            // 0x0196FB0C: LDRB w8, [x0, #0x10a]      | W8 = System.IO.Stream.__il2cppRuntimeField_10A;
            // 0x0196FB10: TBZ w8, #0, #0x196fb20     | if (System.IO.Stream.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0196FB14: LDR w8, [x0, #0xbc]        | W8 = System.IO.Stream.__il2cppRuntimeField_cctor_finished;
            // 0x0196FB18: CBNZ w8, #0x196fb20        | if (System.IO.Stream.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0196FB1C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Stream), ????);
            label_2:
            // 0x0196FB20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0196FB24: MOV x0, x19                | X0 = 1152921509740593456 (0x1000000131FEC130);//ML01
            // 0x0196FB28: BL #0x1e73764              | stream..ctor();                         
            val_1 = new System.IO.Stream();
            // 0x0196FB2C: STR x23, [x19, #0x10]      | this._innerStream = stream;              //  dest_result_addr=1152921509740593472
            this._innerStream = val_1;
            // 0x0196FB30: CBNZ x22, #0x196fb70       | if (crc32 != null) goto label_3;        
            if(val_4 != null)
            {
                goto label_3;
            }
            // 0x0196FB34: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
            // 0x0196FB38: LDR x8, [x8, #0xb90]       | X8 = 1152921504753971200;               
            // 0x0196FB3C: LDR x0, [x8]               | X0 = typeof(Pathfinding.Ionic.Crc.CRC32);
            object val_2 = null;
            // 0x0196FB40: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Ionic.Crc.CRC32), ????);
            // 0x0196FB44: MOV x22, x0                | X22 = 1152921504753971200 (0x1000000008C4F000);//ML01
            val_4 = val_2;
            // 0x0196FB48: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
            // 0x0196FB4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0196FB50: STR w8, [x22, #0x30]       | typeof(Pathfinding.Ionic.Crc.CRC32).__il2cppRuntimeField_30 = 0x0;  //  dest_result_addr=1152921504753971248
            typeof(Pathfinding.Ionic.Crc.CRC32).__il2cppRuntimeField_30 = 0;
            // 0x0196FB54: BL #0x16f59f0              | .ctor();                                
            val_2 = new System.Object();
            // 0x0196FB58: MOVZ w8, #0xedb8, lsl #16  | W8 = 3988258816 (0xEDB80000);//ML01     
            // 0x0196FB5C: MOVK w8, #0x8320           | W8 = 3988292384 (0xEDB88320);           
            // 0x0196FB60: MOV x0, x22                | X0 = 1152921504753971200 (0x1000000008C4F000);//ML01
            // 0x0196FB64: STRB wzr, [x22, #0x20]     | typeof(Pathfinding.Ionic.Crc.CRC32).__il2cppRuntimeField_20 = 0x0;  //  dest_result_addr=1152921504753971232
            typeof(Pathfinding.Ionic.Crc.CRC32).__il2cppRuntimeField_20 = 0;
            // 0x0196FB68: STR w8, [x22, #0x10]       | typeof(Pathfinding.Ionic.Crc.CRC32).__il2cppRuntimeField_10 = 0xEDB88320;  //  dest_result_addr=1152921504753971216
            typeof(Pathfinding.Ionic.Crc.CRC32).__il2cppRuntimeField_10 = -306674912;
            // 0x0196FB6C: BL #0x196efa4              | GenerateLookupTable();                  
            GenerateLookupTable();
            label_3:
            // 0x0196FB70: AND w8, w20, #1            | W8 = (leaveOpen & 1);                   
            bool val_3 = leaveOpen;
            // 0x0196FB74: STP x22, x21, [x19, #0x18] | this._Crc32 = typeof(Pathfinding.Ionic.Crc.CRC32);  this._lengthLimit = length;  //  dest_result_addr=1152921509740593480 |  dest_result_addr=1152921509740593488
            this._Crc32 = val_4;
            this._lengthLimit = length;
            // 0x0196FB78: STRB w8, [x19, #0x28]      | this._leaveOpen = (leaveOpen & 1);       //  dest_result_addr=1152921509740593496
            this._leaveOpen = val_3;
            // 0x0196FB7C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0196FB80: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0196FB84: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0196FB88: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0196FB8C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0196FCC8 (26672328), len: 84  VirtAddr: 0x0196FCC8 RVA: 0x0196FCC8 token: 100663913 methodIndex: 20835 delegateWrapperIndex: 0 methodInvoker: 0
        private static CrcCalculatorStream()
        {
            //
            // Disasemble & Code
            // 0x0196FCC8: STP x20, x19, [sp, #-0x20]! | stack[1152921509740701616] = ???;  stack[1152921509740701624] = ???;  //  dest_result_addr=1152921509740701616 |  dest_result_addr=1152921509740701624
            // 0x0196FCCC: STP x29, x30, [sp, #0x10]  | stack[1152921509740701632] = ???;  stack[1152921509740701640] = ???;  //  dest_result_addr=1152921509740701632 |  dest_result_addr=1152921509740701640
            // 0x0196FCD0: ADD x29, sp, #0x10         | X29 = (1152921509740701616 + 16) = 1152921509740701632 (0x10000001320067C0);
            // 0x0196FCD4: ADRP x19, #0x3739000       | X19 = 57905152 (0x3739000);             
            // 0x0196FCD8: LDRB w8, [x19, #0x3db]     | W8 = (bool)static_value_037393DB;       
            // 0x0196FCDC: TBNZ w8, #0, #0x196fcf8    | if (static_value_037393DB == true) goto label_0;
            // 0x0196FCE0: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x0196FCE4: LDR x8, [x8, #0xa68]       | X8 = 0x2B92DAC;                         
            // 0x0196FCE8: LDR w0, [x8]               | W0 = 0x2230;                            
            // 0x0196FCEC: BL #0x2782188              | X0 = sub_2782188( ?? 0x2230, ????);     
            // 0x0196FCF0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0196FCF4: STRB w8, [x19, #0x3db]     | static_value_037393DB = true;            //  dest_result_addr=57906139
            label_0:
            // 0x0196FCF8: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x0196FCFC: LDR x8, [x8, #0xb58]       | X8 = 1152921504754024448;               
            // 0x0196FD00: MOVN x9, #0x62             | X9 = 98 (0x62);//ML01                   
            // 0x0196FD04: LDR x8, [x8]               | X8 = typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream);
            // 0x0196FD08: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.Ionic.Crc.CrcCalculatorStream.__il2cppRuntimeField_static_fields;
            // 0x0196FD0C: STR x9, [x8]               | Pathfinding.Ionic.Crc.CrcCalculatorStream.UnsetLengthLimit = 98;  //  dest_result_addr=1152921504754028544
            Pathfinding.Ionic.Crc.CrcCalculatorStream.UnsetLengthLimit = 98;
            // 0x0196FD10: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0196FD14: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0196FD18: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0196FD1C (26672412), len: 12  VirtAddr: 0x0196FD1C RVA: 0x0196FD1C token: 100663914 methodIndex: 20836 delegateWrapperIndex: 0 methodInvoker: 0
        private void System.IDisposable.Dispose()
        {
            //
            // Disasemble & Code
            // 0x0196FD1C: LDR x8, [x0]               | X8 = typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream);
            // 0x0196FD20: LDP x2, x1, [x8, #0x1d0]   | X2 = typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream).__il2cppRuntimeField_1D0; X1 = typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream).__il2cppRuntimeField_1D8; //  | 
            // 0x0196FD24: BR x2                      | goto typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream).__il2cppRuntimeField_1D0;
            goto typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream).__il2cppRuntimeField_1D0;
        
        }
        //
        // Offset in libil2cpp.so: 0x0196FD28 (26672424), len: 40  VirtAddr: 0x0196FD28 RVA: 0x0196FD28 token: 100663915 methodIndex: 20837 delegateWrapperIndex: 0 methodInvoker: 0
        public long get_TotalBytesSlurped()
        {
            //
            // Disasemble & Code
            // 0x0196FD28: STP x20, x19, [sp, #-0x20]! | stack[1152921509740929712] = ???;  stack[1152921509740929720] = ???;  //  dest_result_addr=1152921509740929712 |  dest_result_addr=1152921509740929720
            // 0x0196FD2C: STP x29, x30, [sp, #0x10]  | stack[1152921509740929728] = ???;  stack[1152921509740929736] = ???;  //  dest_result_addr=1152921509740929728 |  dest_result_addr=1152921509740929736
            // 0x0196FD30: ADD x29, sp, #0x10         | X29 = (1152921509740929712 + 16) = 1152921509740929728 (0x100000013203E2C0);
            // 0x0196FD34: LDR x19, [x0, #0x18]       | X19 = this._Crc32; //P2                 
            // 0x0196FD38: CBNZ x19, #0x196fd40       | if (this._Crc32 != null) goto label_0;  
            if(this._Crc32 != null)
            {
                goto label_0;
            }
            // 0x0196FD3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x0196FD40: LDR x0, [x19, #0x18]       | X0 = this._Crc32._TotalBytesRead; //P2  
            // 0x0196FD44: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0196FD48: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0196FD4C: RET                        |  return (System.Int64)this._Crc32._TotalBytesRead;
            return this._Crc32._TotalBytesRead;
            //  |  // // {name=val_0, type=System.Int64, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0196FD50 (26672464), len: 44  VirtAddr: 0x0196FD50 RVA: 0x0196FD50 token: 100663916 methodIndex: 20838 delegateWrapperIndex: 0 methodInvoker: 0
        public int get_Crc()
        {
            //
            // Disasemble & Code
            // 0x0196FD50: STP x20, x19, [sp, #-0x20]! | stack[1152921509741049904] = ???;  stack[1152921509741049912] = ???;  //  dest_result_addr=1152921509741049904 |  dest_result_addr=1152921509741049912
            // 0x0196FD54: STP x29, x30, [sp, #0x10]  | stack[1152921509741049920] = ???;  stack[1152921509741049928] = ???;  //  dest_result_addr=1152921509741049920 |  dest_result_addr=1152921509741049928
            // 0x0196FD58: ADD x29, sp, #0x10         | X29 = (1152921509741049904 + 16) = 1152921509741049920 (0x100000013205B840);
            // 0x0196FD5C: LDR x19, [x0, #0x18]       | X19 = this._Crc32; //P2                 
            // 0x0196FD60: CBNZ x19, #0x196fd68       | if (this._Crc32 != null) goto label_0;  
            if(this._Crc32 != null)
            {
                goto label_0;
            }
            // 0x0196FD64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x0196FD68: LDR w8, [x19, #0x30]       | W8 = this._Crc32._register; //P2        
            // 0x0196FD6C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0196FD70: MVN w0, w8                 | W0 = ~(this._Crc32._register);          
            // 0x0196FD74: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0196FD78: RET                        |  return (System.Int32)~(this._Crc32._register);
            return (int)~this._Crc32._register;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0196FD7C (26672508), len: 304  VirtAddr: 0x0196FD7C RVA: 0x0196FD7C token: 100663917 methodIndex: 20839 delegateWrapperIndex: 0 methodInvoker: 0
        public override int Read(byte[] buffer, int offset, int count)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            Pathfinding.Ionic.Crc.CRC32 val_3;
            //  | 
            var val_4;
            //  | 
            long val_5;
            //  | 
            int val_6;
            // 0x0196FD7C: STP x24, x23, [sp, #-0x40]! | stack[1152921509741219216] = ???;  stack[1152921509741219224] = ???;  //  dest_result_addr=1152921509741219216 |  dest_result_addr=1152921509741219224
            // 0x0196FD80: STP x22, x21, [sp, #0x10]  | stack[1152921509741219232] = ???;  stack[1152921509741219240] = ???;  //  dest_result_addr=1152921509741219232 |  dest_result_addr=1152921509741219240
            // 0x0196FD84: STP x20, x19, [sp, #0x20]  | stack[1152921509741219248] = ???;  stack[1152921509741219256] = ???;  //  dest_result_addr=1152921509741219248 |  dest_result_addr=1152921509741219256
            // 0x0196FD88: STP x29, x30, [sp, #0x30]  | stack[1152921509741219264] = ???;  stack[1152921509741219272] = ???;  //  dest_result_addr=1152921509741219264 |  dest_result_addr=1152921509741219272
            // 0x0196FD8C: ADD x29, sp, #0x30         | X29 = (1152921509741219216 + 48) = 1152921509741219264 (0x1000000132084DC0);
            // 0x0196FD90: ADRP x23, #0x3739000       | X23 = 57905152 (0x3739000);             
            // 0x0196FD94: LDRB w8, [x23, #0x3dc]     | W8 = (bool)static_value_037393DC;       
            // 0x0196FD98: MOV w22, w3                | W22 = count;//m1                        
            val_2 = count;
            // 0x0196FD9C: MOV w19, w2                | W19 = offset;//m1                       
            // 0x0196FDA0: MOV x20, x1                | X20 = buffer;//m1                       
            // 0x0196FDA4: MOV x21, x0                | X21 = 1152921509741231280 (0x1000000132087CB0);//ML01
            val_3 = this;
            // 0x0196FDA8: TBNZ w8, #0, #0x196fdc4    | if (static_value_037393DC == true) goto label_0;
            // 0x0196FDAC: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
            // 0x0196FDB0: LDR x8, [x8, #0x898]       | X8 = 0x2B92DC4;                         
            // 0x0196FDB4: LDR w0, [x8]               | W0 = 0x2236;                            
            // 0x0196FDB8: BL #0x2782188              | X0 = sub_2782188( ?? 0x2236, ????);     
            // 0x0196FDBC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0196FDC0: STRB w8, [x23, #0x3dc]     | static_value_037393DC = true;            //  dest_result_addr=57906140
            label_0:
            // 0x0196FDC4: ADRP x24, #0x362d000       | X24 = 56807424 (0x362D000);             
            // 0x0196FDC8: LDR x24, [x24, #0xb58]     | X24 = 1152921504754024448;              
            // 0x0196FDCC: LDR x23, [x21, #0x20]      | X23 = this._lengthLimit; //P2           
            // 0x0196FDD0: LDR x0, [x24]              | X0 = typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream);
            val_4 = null;
            // 0x0196FDD4: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Ionic.Crc.CrcCalculatorStream.__il2cppRuntimeField_10A;
            // 0x0196FDD8: TBZ w8, #0, #0x196fdec     | if (Pathfinding.Ionic.Crc.CrcCalculatorStream.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0196FDDC: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Ionic.Crc.CrcCalculatorStream.__il2cppRuntimeField_cctor_finished;
            // 0x0196FDE0: CBNZ w8, #0x196fdec        | if (Pathfinding.Ionic.Crc.CrcCalculatorStream.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0196FDE4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream), ????);
            // 0x0196FDE8: LDR x0, [x24]              | X0 = typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream);
            val_4 = null;
            label_2:
            // 0x0196FDEC: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.Ionic.Crc.CrcCalculatorStream.__il2cppRuntimeField_static_fields;
            // 0x0196FDF0: LDR x8, [x8]               | X8 = Pathfinding.Ionic.Crc.CrcCalculatorStream.UnsetLengthLimit;
            // 0x0196FDF4: CMP x23, x8                | STATE = COMPARE(this._lengthLimit, Pathfinding.Ionic.Crc.CrcCalculatorStream.UnsetLengthLimit)
            // 0x0196FDF8: B.EQ #0x196fe34            | if (this._lengthLimit == Pathfinding.Ionic.Crc.CrcCalculatorStream.UnsetLengthLimit) goto label_3;
            if(this._lengthLimit == Pathfinding.Ionic.Crc.CrcCalculatorStream.UnsetLengthLimit)
            {
                goto label_3;
            }
            // 0x0196FDFC: LDR x23, [x21, #0x18]      | X23 = this._Crc32; //P2                 
            // 0x0196FE00: CBNZ x23, #0x196fe08       | if (this._Crc32 != null) goto label_4;  
            if(this._Crc32 != null)
            {
                goto label_4;
            }
            // 0x0196FE04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream), ????);
            label_4:
            // 0x0196FE08: LDR x8, [x23, #0x18]       | X8 = this._Crc32._TotalBytesRead; //P2  
            // 0x0196FE0C: LDR x23, [x21, #0x20]      | X23 = this._lengthLimit; //P2           
            val_5 = this._lengthLimit;
            // 0x0196FE10: CMP x8, x23                | STATE = COMPARE(this._Crc32._TotalBytesRead, this._lengthLimit)
            // 0x0196FE14: B.GE #0x196fe90            | if (this._Crc32._TotalBytesRead >= val_5) goto label_5;
            if(this._Crc32._TotalBytesRead >= val_5)
            {
                goto label_5;
            }
            // 0x0196FE18: LDR x24, [x21, #0x18]      | X24 = this._Crc32; //P2                 
            // 0x0196FE1C: CBNZ x24, #0x196fe24       | if (this._Crc32 != null) goto label_6;  
            if(this._Crc32 != null)
            {
                goto label_6;
            }
            // 0x0196FE20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream), ????);
            label_6:
            // 0x0196FE24: LDR x8, [x24, #0x18]       | X8 = this._Crc32._TotalBytesRead; //P2  
            long val_2 = this._Crc32._TotalBytesRead;
            // 0x0196FE28: SUB x8, x23, x8            | X8 = (this._lengthLimit - this._Crc32._TotalBytesRead);
            val_2 = val_5 - val_2;
            // 0x0196FE2C: CMP x8, w22, sxtw          | STATE = COMPARE((this._lengthLimit - this._Crc32._TotalBytesRead), (count) << )
            // 0x0196FE30: CSEL w22, w8, w22, lt      | W22 = this._Crc32._TotalBytesRead < val_2 <<  ? (this._lengthLimit - this._Crc32._TotalBytesRead) : count;
            var val_1 = (val_2 < (val_2 << )) ? (val_2) : (val_2);
            label_3:
            // 0x0196FE34: LDR x23, [x21, #0x10]      | X23 = this._innerStream; //P2           
            val_5 = this._innerStream;
            // 0x0196FE38: CBNZ x23, #0x196fe40       | if (this._innerStream != null) goto label_7;
            if(val_5 != null)
            {
                goto label_7;
            }
            // 0x0196FE3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream), ????);
            label_7:
            // 0x0196FE40: LDR x8, [x23]              | X8 = typeof(System.IO.Stream);          
            // 0x0196FE44: MOV x0, x23                | X0 = this._innerStream;//m1             
            // 0x0196FE48: MOV x1, x20                | X1 = buffer;//m1                        
            // 0x0196FE4C: MOV w2, w19                | W2 = offset;//m1                        
            // 0x0196FE50: LDR x9, [x8, #0x220]       | X9 = typeof(System.IO.Stream).__il2cppRuntimeField_220;
            // 0x0196FE54: LDR x4, [x8, #0x228]       | X4 = typeof(System.IO.Stream).__il2cppRuntimeField_228;
            // 0x0196FE58: MOV w3, w22                | W3 = this._Crc32._TotalBytesRead < val_2 <<  ? (this._lengthLimit - this._Crc32._TotalBytesRead) : count;//m1
            // 0x0196FE5C: BLR x9                     | X0 = typeof(System.IO.Stream).__il2cppRuntimeField_220();
            // 0x0196FE60: MOV w22, w0                | W22 = this._innerStream;//m1            
            val_6 = val_5;
            // 0x0196FE64: CMP w22, #1                | STATE = COMPARE(this._innerStream, 0x1) 
            // 0x0196FE68: B.LT #0x196fe94            | if (val_6 < 0x1) goto label_10;         
            if(val_6 < 1)
            {
                goto label_10;
            }
            // 0x0196FE6C: LDR x21, [x21, #0x18]      | X21 = this._Crc32; //P2                 
            val_3 = this._Crc32;
            // 0x0196FE70: CBNZ x21, #0x196fe78       | if (this._Crc32 != null) goto label_9;  
            if(val_3 != null)
            {
                goto label_9;
            }
            // 0x0196FE74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._innerStream, ????);
            label_9:
            // 0x0196FE78: MOV x0, x21                | X0 = this._Crc32;//m1                   
            // 0x0196FE7C: MOV x1, x20                | X1 = buffer;//m1                        
            // 0x0196FE80: MOV w2, w19                | W2 = offset;//m1                        
            // 0x0196FE84: MOV w3, w22                | W3 = this._innerStream;//m1             
            // 0x0196FE88: BL #0x196f408              | this._Crc32.SlurpBlock(block:  buffer, offset:  offset, count:  val_6);
            val_3.SlurpBlock(block:  buffer, offset:  offset, count:  val_6);
            // 0x0196FE8C: B #0x196fe94               |  goto label_10;                         
            goto label_10;
            label_5:
            // 0x0196FE90: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_10:
            // 0x0196FE94: MOV w0, w22                | W0 = 0 (0x0);//ML01                     
            // 0x0196FE98: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0196FE9C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0196FEA0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0196FEA4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0196FEA8: RET                        |  return (System.Int32)0;                
            return (int)val_6;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0196FEAC (26672812), len: 136  VirtAddr: 0x0196FEAC RVA: 0x0196FEAC token: 100663918 methodIndex: 20840 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Write(byte[] buffer, int offset, int count)
        {
            //
            // Disasemble & Code
            // 0x0196FEAC: STP x24, x23, [sp, #-0x40]! | stack[1152921509741429520] = ???;  stack[1152921509741429528] = ???;  //  dest_result_addr=1152921509741429520 |  dest_result_addr=1152921509741429528
            // 0x0196FEB0: STP x22, x21, [sp, #0x10]  | stack[1152921509741429536] = ???;  stack[1152921509741429544] = ???;  //  dest_result_addr=1152921509741429536 |  dest_result_addr=1152921509741429544
            // 0x0196FEB4: STP x20, x19, [sp, #0x20]  | stack[1152921509741429552] = ???;  stack[1152921509741429560] = ???;  //  dest_result_addr=1152921509741429552 |  dest_result_addr=1152921509741429560
            // 0x0196FEB8: STP x29, x30, [sp, #0x30]  | stack[1152921509741429568] = ???;  stack[1152921509741429576] = ???;  //  dest_result_addr=1152921509741429568 |  dest_result_addr=1152921509741429576
            // 0x0196FEBC: ADD x29, sp, #0x30         | X29 = (1152921509741429520 + 48) = 1152921509741429568 (0x10000001320B8340);
            // 0x0196FEC0: MOV w19, w3                | W19 = count;//m1                        
            // 0x0196FEC4: MOV w20, w2                | W20 = offset;//m1                       
            // 0x0196FEC8: MOV x21, x1                | X21 = buffer;//m1                       
            // 0x0196FECC: MOV x22, x0                | X22 = 1152921509741441584 (0x10000001320BB230);//ML01
            // 0x0196FED0: CMP w19, #1                | STATE = COMPARE(count, 0x1)             
            // 0x0196FED4: B.LT #0x196fef8            | if (count < 1) goto label_0;            
            if(count < 1)
            {
                goto label_0;
            }
            // 0x0196FED8: LDR x23, [x22, #0x18]      | X23 = this._Crc32; //P2                 
            // 0x0196FEDC: CBNZ x23, #0x196fee4       | if (this._Crc32 != null) goto label_1;  
            if(this._Crc32 != null)
            {
                goto label_1;
            }
            // 0x0196FEE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x0196FEE4: MOV x0, x23                | X0 = this._Crc32;//m1                   
            // 0x0196FEE8: MOV x1, x21                | X1 = buffer;//m1                        
            // 0x0196FEEC: MOV w2, w20                | W2 = offset;//m1                        
            // 0x0196FEF0: MOV w3, w19                | W3 = count;//m1                         
            // 0x0196FEF4: BL #0x196f408              | this._Crc32.SlurpBlock(block:  buffer, offset:  offset, count:  count);
            this._Crc32.SlurpBlock(block:  buffer, offset:  offset, count:  count);
            label_0:
            // 0x0196FEF8: LDR x22, [x22, #0x10]      | X22 = this._innerStream; //P2           
            // 0x0196FEFC: CBNZ x22, #0x196ff04       | if (this._innerStream != null) goto label_2;
            if(this._innerStream != null)
            {
                goto label_2;
            }
            // 0x0196FF00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._Crc32, ????);
            label_2:
            // 0x0196FF04: LDR x8, [x22]              | X8 = typeof(System.IO.Stream);          
            // 0x0196FF08: MOV x0, x22                | X0 = this._innerStream;//m1             
            // 0x0196FF0C: MOV x1, x21                | X1 = buffer;//m1                        
            // 0x0196FF10: MOV w2, w20                | W2 = offset;//m1                        
            // 0x0196FF14: LDR x5, [x8, #0x260]       | X5 = typeof(System.IO.Stream).__il2cppRuntimeField_260;
            // 0x0196FF18: LDR x4, [x8, #0x268]       | X4 = typeof(System.IO.Stream).__il2cppRuntimeField_268;
            // 0x0196FF1C: MOV w3, w19                | W3 = count;//m1                         
            // 0x0196FF20: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0196FF24: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0196FF28: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0196FF2C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0196FF30: BR x5                      | goto typeof(System.IO.Stream).__il2cppRuntimeField_260;
            goto typeof(System.IO.Stream).__il2cppRuntimeField_260;
        
        }
        //
        // Offset in libil2cpp.so: 0x0196FF34 (26672948), len: 48  VirtAddr: 0x0196FF34 RVA: 0x0196FF34 token: 100663919 methodIndex: 20841 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool get_CanRead()
        {
            //
            // Disasemble & Code
            // 0x0196FF34: STP x20, x19, [sp, #-0x20]! | stack[1152921509741590704] = ???;  stack[1152921509741590712] = ???;  //  dest_result_addr=1152921509741590704 |  dest_result_addr=1152921509741590712
            // 0x0196FF38: STP x29, x30, [sp, #0x10]  | stack[1152921509741590720] = ???;  stack[1152921509741590728] = ???;  //  dest_result_addr=1152921509741590720 |  dest_result_addr=1152921509741590728
            // 0x0196FF3C: ADD x29, sp, #0x10         | X29 = (1152921509741590704 + 16) = 1152921509741590720 (0x10000001320DF8C0);
            // 0x0196FF40: LDR x19, [x0, #0x10]       | X19 = this._innerStream; //P2           
            // 0x0196FF44: CBNZ x19, #0x196ff4c       | if (this._innerStream != null) goto label_0;
            if(this._innerStream != null)
            {
                goto label_0;
            }
            // 0x0196FF48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x0196FF4C: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
            // 0x0196FF50: MOV x0, x19                | X0 = this._innerStream;//m1             
            // 0x0196FF54: LDP x2, x1, [x8, #0x160]   | X2 = typeof(System.IO.Stream).__il2cppRuntimeField_160; X1 = typeof(System.IO.Stream).__il2cppRuntimeField_168; //  | 
            // 0x0196FF58: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0196FF5C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0196FF60: BR x2                      | goto typeof(System.IO.Stream).__il2cppRuntimeField_160;
            goto typeof(System.IO.Stream).__il2cppRuntimeField_160;
        
        }
        //
        // Offset in libil2cpp.so: 0x0196FF64 (26672996), len: 8  VirtAddr: 0x0196FF64 RVA: 0x0196FF64 token: 100663920 methodIndex: 20842 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool get_CanSeek()
        {
            //
            // Disasemble & Code
            // 0x0196FF64: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x0196FF68: RET                        |  return (System.Boolean)false;          
            return (bool)0;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0196FF6C (26673004), len: 48  VirtAddr: 0x0196FF6C RVA: 0x0196FF6C token: 100663921 methodIndex: 20843 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool get_CanWrite()
        {
            //
            // Disasemble & Code
            // 0x0196FF6C: STP x20, x19, [sp, #-0x20]! | stack[1152921509741822896] = ???;  stack[1152921509741822904] = ???;  //  dest_result_addr=1152921509741822896 |  dest_result_addr=1152921509741822904
            // 0x0196FF70: STP x29, x30, [sp, #0x10]  | stack[1152921509741822912] = ???;  stack[1152921509741822920] = ???;  //  dest_result_addr=1152921509741822912 |  dest_result_addr=1152921509741822920
            // 0x0196FF74: ADD x29, sp, #0x10         | X29 = (1152921509741822896 + 16) = 1152921509741822912 (0x10000001321183C0);
            // 0x0196FF78: LDR x19, [x0, #0x10]       | X19 = this._innerStream; //P2           
            // 0x0196FF7C: CBNZ x19, #0x196ff84       | if (this._innerStream != null) goto label_0;
            if(this._innerStream != null)
            {
                goto label_0;
            }
            // 0x0196FF80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x0196FF84: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
            // 0x0196FF88: MOV x0, x19                | X0 = this._innerStream;//m1             
            // 0x0196FF8C: LDP x2, x1, [x8, #0x180]   | X2 = typeof(System.IO.Stream).__il2cppRuntimeField_180; X1 = typeof(System.IO.Stream).__il2cppRuntimeField_188; //  | 
            // 0x0196FF90: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0196FF94: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0196FF98: BR x2                      | goto typeof(System.IO.Stream).__il2cppRuntimeField_180;
            goto typeof(System.IO.Stream).__il2cppRuntimeField_180;
        
        }
        //
        // Offset in libil2cpp.so: 0x0196FF9C (26673052), len: 52  VirtAddr: 0x0196FF9C RVA: 0x0196FF9C token: 100663922 methodIndex: 20844 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Flush()
        {
            //
            // Disasemble & Code
            // 0x0196FF9C: STP x20, x19, [sp, #-0x20]! | stack[1152921509741943088] = ???;  stack[1152921509741943096] = ???;  //  dest_result_addr=1152921509741943088 |  dest_result_addr=1152921509741943096
            // 0x0196FFA0: STP x29, x30, [sp, #0x10]  | stack[1152921509741943104] = ???;  stack[1152921509741943112] = ???;  //  dest_result_addr=1152921509741943104 |  dest_result_addr=1152921509741943112
            // 0x0196FFA4: ADD x29, sp, #0x10         | X29 = (1152921509741943088 + 16) = 1152921509741943104 (0x1000000132135940);
            // 0x0196FFA8: LDR x19, [x0, #0x10]       | X19 = this._innerStream; //P2           
            // 0x0196FFAC: CBNZ x19, #0x196ffb4       | if (this._innerStream != null) goto label_0;
            if(this._innerStream != null)
            {
                goto label_0;
            }
            // 0x0196FFB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x0196FFB4: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
            // 0x0196FFB8: MOV x0, x19                | X0 = this._innerStream;//m1             
            // 0x0196FFBC: LDR x2, [x8, #0x210]       | X2 = typeof(System.IO.Stream).__il2cppRuntimeField_210;
            // 0x0196FFC0: LDR x1, [x8, #0x218]       | X1 = typeof(System.IO.Stream).__il2cppRuntimeField_218;
            // 0x0196FFC4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0196FFC8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0196FFCC: BR x2                      | goto typeof(System.IO.Stream).__il2cppRuntimeField_210;
            goto typeof(System.IO.Stream).__il2cppRuntimeField_210;
        
        }
        //
        // Offset in libil2cpp.so: 0x0196FFD0 (26673104), len: 172  VirtAddr: 0x0196FFD0 RVA: 0x0196FFD0 token: 100663923 methodIndex: 20845 delegateWrapperIndex: 0 methodInvoker: 0
        public override long get_Length()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x0196FFD0: STP x22, x21, [sp, #-0x30]! | stack[1152921509742063264] = ???;  stack[1152921509742063272] = ???;  //  dest_result_addr=1152921509742063264 |  dest_result_addr=1152921509742063272
            // 0x0196FFD4: STP x20, x19, [sp, #0x10]  | stack[1152921509742063280] = ???;  stack[1152921509742063288] = ???;  //  dest_result_addr=1152921509742063280 |  dest_result_addr=1152921509742063288
            // 0x0196FFD8: STP x29, x30, [sp, #0x20]  | stack[1152921509742063296] = ???;  stack[1152921509742063304] = ???;  //  dest_result_addr=1152921509742063296 |  dest_result_addr=1152921509742063304
            // 0x0196FFDC: ADD x29, sp, #0x20         | X29 = (1152921509742063264 + 32) = 1152921509742063296 (0x1000000132152EC0);
            // 0x0196FFE0: ADRP x20, #0x3739000       | X20 = 57905152 (0x3739000);             
            // 0x0196FFE4: LDRB w8, [x20, #0x3dd]     | W8 = (bool)static_value_037393DD;       
            // 0x0196FFE8: MOV x19, x0                | X19 = 1152921509742075312 (0x1000000132155DB0);//ML01
            val_7 = this;
            // 0x0196FFEC: TBNZ w8, #0, #0x1970008    | if (static_value_037393DD == true) goto label_0;
            // 0x0196FFF0: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
            // 0x0196FFF4: LDR x8, [x8, #0xbf0]       | X8 = 0x2B92DC0;                         
            // 0x0196FFF8: LDR w0, [x8]               | W0 = 0x2235;                            
            // 0x0196FFFC: BL #0x2782188              | X0 = sub_2782188( ?? 0x2235, ????);     
            // 0x01970000: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01970004: STRB w8, [x20, #0x3dd]     | static_value_037393DD = true;            //  dest_result_addr=57906141
            label_0:
            // 0x01970008: ADRP x21, #0x362d000       | X21 = 56807424 (0x362D000);             
            // 0x0197000C: LDR x21, [x21, #0xb58]     | X21 = 1152921504754024448;              
            val_8 = 1152921504754024448;
            // 0x01970010: LDR x20, [x19, #0x20]      | X20 = this._lengthLimit; //P2           
            // 0x01970014: LDR x0, [x21]              | X0 = typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream);
            val_9 = null;
            // 0x01970018: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Ionic.Crc.CrcCalculatorStream.__il2cppRuntimeField_10A;
            // 0x0197001C: TBZ w8, #0, #0x1970030     | if (Pathfinding.Ionic.Crc.CrcCalculatorStream.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01970020: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Ionic.Crc.CrcCalculatorStream.__il2cppRuntimeField_cctor_finished;
            // 0x01970024: CBNZ w8, #0x1970030        | if (Pathfinding.Ionic.Crc.CrcCalculatorStream.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01970028: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream), ????);
            // 0x0197002C: LDR x0, [x21]              | X0 = typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream);
            val_9 = null;
            label_2:
            // 0x01970030: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.Ionic.Crc.CrcCalculatorStream.__il2cppRuntimeField_static_fields;
            // 0x01970034: LDR x8, [x8]               | X8 = Pathfinding.Ionic.Crc.CrcCalculatorStream.UnsetLengthLimit;
            // 0x01970038: CMP x20, x8                | STATE = COMPARE(this._lengthLimit, Pathfinding.Ionic.Crc.CrcCalculatorStream.UnsetLengthLimit)
            // 0x0197003C: B.NE #0x1970068            | if (this._lengthLimit != Pathfinding.Ionic.Crc.CrcCalculatorStream.UnsetLengthLimit) goto label_3;
            if(this._lengthLimit != Pathfinding.Ionic.Crc.CrcCalculatorStream.UnsetLengthLimit)
            {
                goto label_3;
            }
            // 0x01970040: LDR x19, [x19, #0x10]      | X19 = this._innerStream; //P2           
            // 0x01970044: CBNZ x19, #0x197004c       | if (this._innerStream != null) goto label_4;
            if(this._innerStream != null)
            {
                goto label_4;
            }
            // 0x01970048: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.Ionic.Crc.CrcCalculatorStream), ????);
            label_4:
            // 0x0197004C: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
            // 0x01970050: MOV x0, x19                | X0 = this._innerStream;//m1             
            // 0x01970054: LDP x2, x1, [x8, #0x190]   | X2 = typeof(System.IO.Stream).__il2cppRuntimeField_190; X1 = typeof(System.IO.Stream).__il2cppRuntimeField_198; //  | 
            // 0x01970058: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0197005C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            val_7 = ???;
            // 0x01970060: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            val_8 = ???;
            // 0x01970064: BR x2                      | goto typeof(System.IO.Stream).__il2cppRuntimeField_190;
            goto typeof(System.IO.Stream).__il2cppRuntimeField_190;
            label_3:
            // 0x01970068: LDR x0, [x19, #0x20]       | X0 = val_7 + 32;                        
            // 0x0197006C: LDP x29, x30, [sp, #0x20]  | X29 = val_1; X30 = val_2;                //  find_add[1152921509742051312] |  find_add[1152921509742051312]
            // 0x01970070: LDP x20, x19, [sp, #0x10]  | X20 = val_3; X19 = val_4;                //  find_add[1152921509742051312] |  find_add[1152921509742051312]
            // 0x01970074: LDP x22, x21, [sp], #0x30  | X22 = val_5; X21 = val_6;                //  find_add[1152921509742051312] |  find_add[1152921509742051312]
            // 0x01970078: RET                        |  return (System.Int64)val_7 + 32;       
            return (long)val_7 + 32;
            //  |  // // {name=val_0, type=System.Int64, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0197007C (26673276), len: 40  VirtAddr: 0x0197007C RVA: 0x0197007C token: 100663924 methodIndex: 20846 delegateWrapperIndex: 0 methodInvoker: 0
        public override long get_Position()
        {
            //
            // Disasemble & Code
            // 0x0197007C: STP x20, x19, [sp, #-0x20]! | stack[1152921509742183472] = ???;  stack[1152921509742183480] = ???;  //  dest_result_addr=1152921509742183472 |  dest_result_addr=1152921509742183480
            // 0x01970080: STP x29, x30, [sp, #0x10]  | stack[1152921509742183488] = ???;  stack[1152921509742183496] = ???;  //  dest_result_addr=1152921509742183488 |  dest_result_addr=1152921509742183496
            // 0x01970084: ADD x29, sp, #0x10         | X29 = (1152921509742183472 + 16) = 1152921509742183488 (0x1000000132170440);
            // 0x01970088: LDR x19, [x0, #0x18]       | X19 = this._Crc32; //P2                 
            // 0x0197008C: CBNZ x19, #0x1970094       | if (this._Crc32 != null) goto label_0;  
            if(this._Crc32 != null)
            {
                goto label_0;
            }
            // 0x01970090: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01970094: LDR x0, [x19, #0x18]       | X0 = this._Crc32._TotalBytesRead; //P2  
            // 0x01970098: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0197009C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x019700A0: RET                        |  return (System.Int64)this._Crc32._TotalBytesRead;
            return this._Crc32._TotalBytesRead;
            //  |  // // {name=val_0, type=System.Int64, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x019700A4 (26673316), len: 100  VirtAddr: 0x019700A4 RVA: 0x019700A4 token: 100663925 methodIndex: 20847 delegateWrapperIndex: 0 methodInvoker: 0
        public override void set_Position(long value)
        {
            //
            // Disasemble & Code
            // 0x019700A4: STP x20, x19, [sp, #-0x20]! | stack[1152921509742300592] = ???;  stack[1152921509742300600] = ???;  //  dest_result_addr=1152921509742300592 |  dest_result_addr=1152921509742300600
            // 0x019700A8: STP x29, x30, [sp, #0x10]  | stack[1152921509742300608] = ???;  stack[1152921509742300616] = ???;  //  dest_result_addr=1152921509742300608 |  dest_result_addr=1152921509742300616
            // 0x019700AC: ADD x29, sp, #0x10         | X29 = (1152921509742300592 + 16) = 1152921509742300608 (0x100000013218CDC0);
            // 0x019700B0: ADRP x19, #0x3739000       | X19 = 57905152 (0x3739000);             
            // 0x019700B4: LDRB w8, [x19, #0x3de]     | W8 = (bool)static_value_037393DE;       
            // 0x019700B8: TBNZ w8, #0, #0x19700d4    | if (static_value_037393DE == true) goto label_0;
            // 0x019700BC: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
            // 0x019700C0: LDR x8, [x8, #0x5b0]       | X8 = 0x2B92DCC;                         
            // 0x019700C4: LDR w0, [x8]               | W0 = 0x2238;                            
            // 0x019700C8: BL #0x2782188              | X0 = sub_2782188( ?? 0x2238, ????);     
            // 0x019700CC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019700D0: STRB w8, [x19, #0x3de]     | static_value_037393DE = true;            //  dest_result_addr=57906142
            label_0:
            // 0x019700D4: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x019700D8: LDR x8, [x8, #0x838]       | X8 = 1152921504655409152;               
            // 0x019700DC: LDR x0, [x8]               | X0 = typeof(System.NotSupportedException);
            System.NotSupportedException val_1 = null;
            // 0x019700E0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotSupportedException), ????);
            // 0x019700E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019700E8: MOV x19, x0                | X19 = 1152921504655409152 (0x1000000002E50000);//ML01
            // 0x019700EC: BL #0x1701574              | .ctor();                                
            val_1 = new System.NotSupportedException();
            // 0x019700F0: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
            // 0x019700F4: LDR x8, [x8, #0x6e8]       | X8 = 1152921509742287600;               
            // 0x019700F8: MOV x0, x19                | X0 = 1152921504655409152 (0x1000000002E50000);//ML01
            // 0x019700FC: LDR x1, [x8]               | X1 = public System.Void Pathfinding.Ionic.Crc.CrcCalculatorStream::set_Position(long value);
            // 0x01970100: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotSupportedException), ????);
            // 0x01970104: BL #0x196f408              | SlurpBlock(block:  public System.Void Pathfinding.Ionic.Crc.CrcCalculatorStream::set_Position(long value), offset:  0, count:  0);
            SlurpBlock(block:  public System.Void Pathfinding.Ionic.Crc.CrcCalculatorStream::set_Position(long value), offset:  0, count:  0);
        
        }
        //
        // Offset in libil2cpp.so: 0x01970108 (26673416), len: 100  VirtAddr: 0x01970108 RVA: 0x01970108 token: 100663926 methodIndex: 20848 delegateWrapperIndex: 0 methodInvoker: 0
        public override long Seek(long offset, System.IO.SeekOrigin origin)
        {
            //
            // Disasemble & Code
            // 0x01970108: STP x20, x19, [sp, #-0x20]! | stack[1152921509742417712] = ???;  stack[1152921509742417720] = ???;  //  dest_result_addr=1152921509742417712 |  dest_result_addr=1152921509742417720
            // 0x0197010C: STP x29, x30, [sp, #0x10]  | stack[1152921509742417728] = ???;  stack[1152921509742417736] = ???;  //  dest_result_addr=1152921509742417728 |  dest_result_addr=1152921509742417736
            // 0x01970110: ADD x29, sp, #0x10         | X29 = (1152921509742417712 + 16) = 1152921509742417728 (0x10000001321A9740);
            // 0x01970114: ADRP x19, #0x3739000       | X19 = 57905152 (0x3739000);             
            // 0x01970118: LDRB w8, [x19, #0x3df]     | W8 = (bool)static_value_037393DF;       
            // 0x0197011C: TBNZ w8, #0, #0x1970138    | if (static_value_037393DF == true) goto label_0;
            // 0x01970120: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
            // 0x01970124: LDR x8, [x8, #0x300]       | X8 = 0x2B92DC8;                         
            // 0x01970128: LDR w0, [x8]               | W0 = 0x2237;                            
            // 0x0197012C: BL #0x2782188              | X0 = sub_2782188( ?? 0x2237, ????);     
            // 0x01970130: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01970134: STRB w8, [x19, #0x3df]     | static_value_037393DF = true;            //  dest_result_addr=57906143
            label_0:
            // 0x01970138: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x0197013C: LDR x8, [x8, #0x838]       | X8 = 1152921504655409152;               
            // 0x01970140: LDR x0, [x8]               | X0 = typeof(System.NotSupportedException);
            System.NotSupportedException val_1 = null;
            // 0x01970144: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotSupportedException), ????);
            // 0x01970148: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0197014C: MOV x19, x0                | X19 = 1152921504655409152 (0x1000000002E50000);//ML01
            // 0x01970150: BL #0x1701574              | .ctor();                                
            val_1 = new System.NotSupportedException();
            // 0x01970154: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x01970158: LDR x8, [x8, #0xeb8]       | X8 = 1152921509742404720;               
            // 0x0197015C: MOV x0, x19                | X0 = 1152921504655409152 (0x1000000002E50000);//ML01
            // 0x01970160: LDR x1, [x8]               | X1 = public System.Int64 Pathfinding.Ionic.Crc.CrcCalculatorStream::Seek(long offset, System.IO.SeekOrigin origin);
            // 0x01970164: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotSupportedException), ????);
            // 0x01970168: BL #0x196f408              | SlurpBlock(block:  public System.Int64 Pathfinding.Ionic.Crc.CrcCalculatorStream::Seek(long offset, System.IO.SeekOrigin origin), offset:  origin, count:  0);
            SlurpBlock(block:  public System.Int64 Pathfinding.Ionic.Crc.CrcCalculatorStream::Seek(long offset, System.IO.SeekOrigin origin), offset:  origin, count:  0);
        
        }
        //
        // Offset in libil2cpp.so: 0x0197016C (26673516), len: 100  VirtAddr: 0x0197016C RVA: 0x0197016C token: 100663927 methodIndex: 20849 delegateWrapperIndex: 0 methodInvoker: 0
        public override void SetLength(long value)
        {
            //
            // Disasemble & Code
            // 0x0197016C: STP x20, x19, [sp, #-0x20]! | stack[1152921509742534832] = ???;  stack[1152921509742534840] = ???;  //  dest_result_addr=1152921509742534832 |  dest_result_addr=1152921509742534840
            // 0x01970170: STP x29, x30, [sp, #0x10]  | stack[1152921509742534848] = ???;  stack[1152921509742534856] = ???;  //  dest_result_addr=1152921509742534848 |  dest_result_addr=1152921509742534856
            // 0x01970174: ADD x29, sp, #0x10         | X29 = (1152921509742534832 + 16) = 1152921509742534848 (0x10000001321C60C0);
            // 0x01970178: ADRP x19, #0x3739000       | X19 = 57905152 (0x3739000);             
            // 0x0197017C: LDRB w8, [x19, #0x3e0]     | W8 = (bool)static_value_037393E0;       
            // 0x01970180: TBNZ w8, #0, #0x197019c    | if (static_value_037393E0 == true) goto label_0;
            // 0x01970184: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x01970188: LDR x8, [x8, #0x4f8]       | X8 = 0x2B92DD0;                         
            // 0x0197018C: LDR w0, [x8]               | W0 = 0x2239;                            
            // 0x01970190: BL #0x2782188              | X0 = sub_2782188( ?? 0x2239, ????);     
            // 0x01970194: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01970198: STRB w8, [x19, #0x3e0]     | static_value_037393E0 = true;            //  dest_result_addr=57906144
            label_0:
            // 0x0197019C: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x019701A0: LDR x8, [x8, #0x838]       | X8 = 1152921504655409152;               
            // 0x019701A4: LDR x0, [x8]               | X0 = typeof(System.NotSupportedException);
            System.NotSupportedException val_1 = null;
            // 0x019701A8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotSupportedException), ????);
            // 0x019701AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019701B0: MOV x19, x0                | X19 = 1152921504655409152 (0x1000000002E50000);//ML01
            // 0x019701B4: BL #0x1701574              | .ctor();                                
            val_1 = new System.NotSupportedException();
            // 0x019701B8: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x019701BC: LDR x8, [x8, #0x380]       | X8 = 1152921509742521840;               
            // 0x019701C0: MOV x0, x19                | X0 = 1152921504655409152 (0x1000000002E50000);//ML01
            // 0x019701C4: LDR x1, [x8]               | X1 = public System.Void Pathfinding.Ionic.Crc.CrcCalculatorStream::SetLength(long value);
            // 0x019701C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotSupportedException), ????);
            // 0x019701CC: BL #0x196f408              | SlurpBlock(block:  public System.Void Pathfinding.Ionic.Crc.CrcCalculatorStream::SetLength(long value), offset:  0, count:  0);
            SlurpBlock(block:  public System.Void Pathfinding.Ionic.Crc.CrcCalculatorStream::SetLength(long value), offset:  0, count:  0);
        
        }
        //
        // Offset in libil2cpp.so: 0x019701D0 (26673616), len: 80  VirtAddr: 0x019701D0 RVA: 0x019701D0 token: 100663928 methodIndex: 20850 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Close()
        {
            //
            // Disasemble & Code
            // 0x019701D0: STP x20, x19, [sp, #-0x20]! | stack[1152921509742650928] = ???;  stack[1152921509742650936] = ???;  //  dest_result_addr=1152921509742650928 |  dest_result_addr=1152921509742650936
            // 0x019701D4: STP x29, x30, [sp, #0x10]  | stack[1152921509742650944] = ???;  stack[1152921509742650952] = ???;  //  dest_result_addr=1152921509742650944 |  dest_result_addr=1152921509742650952
            // 0x019701D8: ADD x29, sp, #0x10         | X29 = (1152921509742650928 + 16) = 1152921509742650944 (0x10000001321E2640);
            // 0x019701DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019701E0: MOV x19, x0                | X19 = 1152921509742662960 (0x10000001321E5530);//ML01
            // 0x019701E4: BL #0x1e7cf5c              | this.Close();                           
            this.Close();
            // 0x019701E8: LDRB w8, [x19, #0x28]      | W8 = this._leaveOpen; //P2              
            // 0x019701EC: CBZ w8, #0x19701fc         | if (this._leaveOpen == false) goto label_0;
            if(this._leaveOpen == false)
            {
                goto label_0;
            }
            // 0x019701F0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x019701F4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x019701F8: RET                        |  return;                                
            return;
            label_0:
            // 0x019701FC: LDR x19, [x19, #0x10]      | X19 = this._innerStream; //P2           
            // 0x01970200: CBNZ x19, #0x1970208       | if (this._innerStream != null) goto label_1;
            if(this._innerStream != null)
            {
                goto label_1;
            }
            // 0x01970204: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x01970208: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
            // 0x0197020C: MOV x0, x19                | X0 = this._innerStream;//m1             
            // 0x01970210: LDP x2, x1, [x8, #0x1d0]   | X2 = typeof(System.IO.Stream).__il2cppRuntimeField_1D0; X1 = typeof(System.IO.Stream).__il2cppRuntimeField_1D8; //  | 
            // 0x01970214: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01970218: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0197021C: BR x2                      | goto typeof(System.IO.Stream).__il2cppRuntimeField_1D0;
            goto typeof(System.IO.Stream).__il2cppRuntimeField_1D0;
        
        }
    
    }

}
