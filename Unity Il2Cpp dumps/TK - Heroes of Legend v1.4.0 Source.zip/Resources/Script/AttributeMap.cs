using UnityEngine;

namespace ProtoBuf.Meta
{
    internal abstract class AttributeMap
    {
        // Properties
        public abstract System.Type AttributeType { get; }
        public abstract object Target { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00C7E5AC (13100460), len: 8  VirtAddr: 0x00C7E5AC RVA: 0x00C7E5AC token: 100689200 methodIndex: 53420 delegateWrapperIndex: 0 methodInvoker: 0
        protected AttributeMap()
        {
            //
            // Disasemble & Code
            // 0x00C7E5AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7E5B0: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        public abstract bool TryGet(string key, bool publicOnly, out object value); // 0
        //
        // Offset in libil2cpp.so: 0x00C7E5B4 (13100468), len: 24  VirtAddr: 0x00C7E5B4 RVA: 0x00C7E5B4 token: 100689202 methodIndex: 53421 delegateWrapperIndex: 0 methodInvoker: 0
        public bool TryGet(string key, out object value)
        {
            //
            // Disasemble & Code
            // 0x00C7E5B4: LDR x8, [x0]               | X8 = typeof(ProtoBuf.Meta.AttributeMap);
            // 0x00C7E5B8: LDP x5, x4, [x8, #0x150]   | X5 = typeof(ProtoBuf.Meta.AttributeMap).__il2cppRuntimeField_150; X4 = typeof(ProtoBuf.Meta.AttributeMap).__il2cppRuntimeField_158; //  | 
            // 0x00C7E5BC: MOV x8, x2                 | X8 = 1152921514346152752 (0x1000000244820330);//ML01
            // 0x00C7E5C0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00C7E5C4: MOV x3, x8                 | X3 = 1152921514346152752 (0x1000000244820330);//ML01
            // 0x00C7E5C8: BR x5                      | goto typeof(ProtoBuf.Meta.AttributeMap).__il2cppRuntimeField_150;
            goto typeof(ProtoBuf.Meta.AttributeMap).__il2cppRuntimeField_150;
        
        }
        public abstract System.Type get_AttributeType(); // 0
        //
        // Offset in libil2cpp.so: 0x00C7E5CC (13100492), len: 476  VirtAddr: 0x00C7E5CC RVA: 0x00C7E5CC token: 100689204 methodIndex: 53422 delegateWrapperIndex: 0 methodInvoker: 0
        public static ProtoBuf.Meta.AttributeMap[] Create(ProtoBuf.Meta.TypeModel model, System.Type type, bool inherit)
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00C7E5CC: STP x26, x25, [sp, #-0x50]! | stack[1152921514346232880] = ???;  stack[1152921514346232888] = ???;  //  dest_result_addr=1152921514346232880 |  dest_result_addr=1152921514346232888
            // 0x00C7E5D0: STP x24, x23, [sp, #0x10]  | stack[1152921514346232896] = ???;  stack[1152921514346232904] = ???;  //  dest_result_addr=1152921514346232896 |  dest_result_addr=1152921514346232904
            // 0x00C7E5D4: STP x22, x21, [sp, #0x20]  | stack[1152921514346232912] = ???;  stack[1152921514346232920] = ???;  //  dest_result_addr=1152921514346232912 |  dest_result_addr=1152921514346232920
            // 0x00C7E5D8: STP x20, x19, [sp, #0x30]  | stack[1152921514346232928] = ???;  stack[1152921514346232936] = ???;  //  dest_result_addr=1152921514346232928 |  dest_result_addr=1152921514346232936
            // 0x00C7E5DC: STP x29, x30, [sp, #0x40]  | stack[1152921514346232944] = ???;  stack[1152921514346232952] = ???;  //  dest_result_addr=1152921514346232944 |  dest_result_addr=1152921514346232952
            // 0x00C7E5E0: ADD x29, sp, #0x40         | X29 = (1152921514346232880 + 64) = 1152921514346232944 (0x1000000244833C70);
            // 0x00C7E5E4: SUB sp, sp, #0x10          | SP = (1152921514346232880 - 16) = 1152921514346232864 (0x1000000244833C20);
            // 0x00C7E5E8: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00C7E5EC: LDRB w8, [x21, #0xf9a]     | W8 = (bool)static_value_03733F9A;       
            // 0x00C7E5F0: MOV w19, w3                | W19 = W3;//m1                           
            // 0x00C7E5F4: MOV x20, x2                | X20 = inherit;//m1                      
            // 0x00C7E5F8: TBNZ w8, #0, #0xc7e614     | if (static_value_03733F9A == true) goto label_0;
            // 0x00C7E5FC: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
            // 0x00C7E600: LDR x8, [x8, #0x838]       | X8 = 0x2B8EEA8;                         
            // 0x00C7E604: LDR w0, [x8]               | W0 = 0x126C;                            
            // 0x00C7E608: BL #0x2782188              | X0 = sub_2782188( ?? 0x126C, ????);     
            // 0x00C7E60C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7E610: STRB w8, [x21, #0xf9a]     | static_value_03733F9A = true;            //  dest_result_addr=57884570
            label_0:
            // 0x00C7E614: CBNZ x20, #0xc7e61c        | if (inherit == true) goto label_1;      
            if(inherit == true)
            {
                goto label_1;
            }
            // 0x00C7E618: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x126C, ????);     
            label_1:
            // 0x00C7E61C: LDR x8, [x20]              | X8 = inherit;                           
            // 0x00C7E620: AND w1, w19, #1            | W1 = (W3 & 1);                          
            var val_1 = W3 & 1;
            // 0x00C7E624: MOV x0, x20                | X0 = inherit;//m1                       
            // 0x00C7E628: LDP x9, x2, [x8, #0x1d0]   | X9 = inherit + 464; X2 = inherit + 464 + 8; //  | 
            // 0x00C7E62C: BLR x9                     | X0 = inherit + 464();                   
            // 0x00C7E630: MOV x19, x0                | X19 = inherit;//m1                      
            // 0x00C7E634: CBNZ x19, #0xc7e63c        | if (inherit == true) goto label_2;      
            if(inherit == true)
            {
                goto label_2;
            }
            // 0x00C7E638: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? inherit, ????);    
            label_2:
            // 0x00C7E63C: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x00C7E640: LDR x8, [x8, #0x878]       | X8 = 1152921507849406400;               
            // 0x00C7E644: LDR w21, [x19, #0x18]      | W21 = inherit + 24;                     
            // 0x00C7E648: LDR x20, [x8]              | X20 = typeof(ProtoBuf.Meta.AttributeMap[]);
            // 0x00C7E64C: MOV x0, x20                | X0 = 1152921507849406400 (0x10000000C14587C0);//ML01
            // 0x00C7E650: BL #0x277461c              | X0 = sub_277461C( ?? typeof(ProtoBuf.Meta.AttributeMap[]), ????);
            // 0x00C7E654: MOV x0, x20                | X0 = 1152921507849406400 (0x10000000C14587C0);//ML01
            // 0x00C7E658: MOV x1, x21                | X1 = inherit + 24;//m1                  
            // 0x00C7E65C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(ProtoBuf.Meta.AttributeMap[]), ????);
            // 0x00C7E660: ADRP x23, #0x3607000       | X23 = 56651776 (0x3607000);             
            // 0x00C7E664: ADRP x24, #0x35cc000       | X24 = 56410112 (0x35CC000);             
            // 0x00C7E668: LDR x23, [x23, #0x7a8]     | X23 = 1152921504882298880;              
            // 0x00C7E66C: LDR x24, [x24, #0x510]     | X24 = 1152921504607006720;              
            // 0x00C7E670: MOV x20, x0                | X20 = 1152921507849406400 (0x10000000C14587C0);//ML01
            // 0x00C7E674: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_7 = 0;
            // 0x00C7E678: B #0xc7e688                |  goto label_3;                          
            goto label_3;
            label_13:
            // 0x00C7E67C: ADD x8, x20, x25, lsl #3   | X8 = (null + (X25) << 3);               
            var val_2 = null + ((X25) << 3);
            // 0x00C7E680: ADD w22, w22, #1           | W22 = (val_7 + 1) = val_7 (0x00000001); 
            val_7 = 1;
            // 0x00C7E684: STR x21, [x8, #0x20]       | mem2[0] = inherit + 24;                  //  dest_result_addr=0
            mem2[0] = inherit + 24;
            label_3:
            // 0x00C7E688: CBNZ x19, #0xc7e690        | if (inherit == true) goto label_4;      
            if(inherit == true)
            {
                goto label_4;
            }
            // 0x00C7E68C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ProtoBuf.Meta.AttributeMap[]), ????);
            label_4:
            // 0x00C7E690: LDR w8, [x19, #0x18]       | W8 = inherit + 24;                      
            // 0x00C7E694: CMP w22, w8                | STATE = COMPARE(0x1, inherit + 24)      
            // 0x00C7E698: B.GE #0xc7e774             | if (val_7 >= inherit + 24) goto label_5;
            if(val_7 >= (inherit + 24))
            {
                goto label_5;
            }
            // 0x00C7E69C: SXTW x25, w22              | X25 = 1 (0x00000001);                   
            // 0x00C7E6A0: CMP w22, w8                | STATE = COMPARE(0x1, inherit + 24)      
            // 0x00C7E6A4: B.LO #0xc7e6b4             | if (val_7 < inherit + 24) goto label_6; 
            if(val_7 < (inherit + 24))
            {
                goto label_6;
            }
            // 0x00C7E6A8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(ProtoBuf.Meta.AttributeMap[]), ????);
            // 0x00C7E6AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7E6B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(ProtoBuf.Meta.AttributeMap[]), ????);
            label_6:
            // 0x00C7E6B4: ADD x8, x19, x25, lsl #3   | X8 = (inherit + 8);                     
            bool val_3 = inherit + 8;
            // 0x00C7E6B8: LDR x0, [x23]              | X0 = typeof(AttributeMap.ReflectionAttributeMap);
            // 0x00C7E6BC: LDR x26, [x8, #0x20]       | X26 = (inherit + 8) + 32;               
            val_8 = mem[(inherit + 8) + 32];
            val_8 = (inherit + 8) + 32;
            // 0x00C7E6C0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AttributeMap.ReflectionAttributeMap), ????);
            // 0x00C7E6C4: MOV x21, x0                | X21 = 1152921504882298880 (0x10000000106B1000);//ML01
            // 0x00C7E6C8: CBZ x26, #0xc7e71c         | if ((inherit + 8) + 32 == 0) goto label_7;
            if(val_8 == 0)
            {
                goto label_7;
            }
            // 0x00C7E6CC: LDR x8, [x26]              | X8 = (inherit + 8) + 32;                
            // 0x00C7E6D0: LDR x1, [x24]              | X1 = typeof(System.Attribute);          
            // 0x00C7E6D4: LDRB w10, [x8, #0x104]     | W10 = (inherit + 8) + 32 + 260;         
            // 0x00C7E6D8: LDRB w9, [x1, #0x104]      | W9 = System.Attribute.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00C7E6DC: CMP w10, w9                | STATE = COMPARE((inherit + 8) + 32 + 260, System.Attribute.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00C7E6E0: B.LO #0xc7e6f8             | if ((inherit + 8) + 32 + 260 < System.Attribute.__il2cppRuntimeField_typeHierarchyDepth) goto label_8;
            // 0x00C7E6E4: LDR x10, [x8, #0xb0]       | X10 = (inherit + 8) + 32 + 176;         
            // 0x00C7E6E8: ADD x9, x10, x9, lsl #3    | X9 = ((inherit + 8) + 32 + 176 + (System.Attribute.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00C7E6EC: LDUR x9, [x9, #-8]         | X9 = ((inherit + 8) + 32 + 176 + (System.Attribute.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00C7E6F0: CMP x9, x1                 | STATE = COMPARE(((inherit + 8) + 32 + 176 + (System.Attribute.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Attribute))
            // 0x00C7E6F4: B.EQ #0xc7e720             | if (((inherit + 8) + 32 + 176 + (System.Attribute.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_9;
            label_8:
            // 0x00C7E6F8: LDR x0, [x8, #0x30]        | X0 = (inherit + 8) + 32 + 48;           
            // 0x00C7E6FC: ADD x8, sp, #8             | X8 = (1152921514346232864 + 8) = 1152921514346232872 (0x1000000244833C28);
            // 0x00C7E700: BL #0x27d96d4              | X0 = sub_27D96D4( ?? (inherit + 8) + 32 + 48, ????);
            // 0x00C7E704: LDR x0, [sp, #8]           | X0 = val_5;                              //  find_add[1152921514346220960]
            // 0x00C7E708: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00C7E70C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7E710: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00C7E714: ADD x0, sp, #8             | X0 = (1152921514346232864 + 8) = 1152921514346232872 (0x1000000244833C28);
            // 0x00C7E718: BL #0x299a140              | 
            label_7:
            // 0x00C7E71C: MOV x26, xzr               | X26 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_9:
            // 0x00C7E720: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7E724: MOV x0, x21                | X0 = 1152921504882298880 (0x10000000106B1000);//ML01
            object val_6 = null;
            // 0x00C7E728: BL #0x16f59f0              | .ctor();                                
            val_6 = new System.Object();
            // 0x00C7E72C: STR x26, [x21, #0x10]      | typeof(AttributeMap.ReflectionAttributeMap).__il2cppRuntimeField_10 = 0x0;  //  dest_result_addr=1152921504882298896
            typeof(AttributeMap.ReflectionAttributeMap).__il2cppRuntimeField_10 = val_8;
            // 0x00C7E730: CBNZ x20, #0xc7e738        | if ( != null) goto label_10;            
            if(null != null)
            {
                goto label_10;
            }
            // 0x00C7E734: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_10:
            // 0x00C7E738: LDR x8, [x20]              | X8 = ;                                  
            // 0x00C7E73C: MOV x0, x21                | X0 = 1152921504882298880 (0x10000000106B1000);//ML01
            // 0x00C7E740: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00C7E744: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(AttributeMap.ReflectionAttributeMap), ????);
            // 0x00C7E748: CBNZ x0, #0xc7e758         | if ( != 0) goto label_11;               
            if(null != 0)
            {
                goto label_11;
            }
            // 0x00C7E74C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(AttributeMap.ReflectionAttributeMap), ????);
            // 0x00C7E750: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7E754: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(AttributeMap.ReflectionAttributeMap), ????);
            label_11:
            // 0x00C7E758: LDR w8, [x20, #0x18]       | W8 = ProtoBuf.Meta.AttributeMap[].__il2cppRuntimeField_namespaze;
            // 0x00C7E75C: CMP w22, w8                | STATE = COMPARE(0x1, ProtoBuf.Meta.AttributeMap[].__il2cppRuntimeField_namespaze)
            // 0x00C7E760: B.LO #0xc7e67c             | if (val_7 < ProtoBuf.Meta.AttributeMap[].__il2cppRuntimeField_namespaze) goto label_13;
            // 0x00C7E764: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(AttributeMap.ReflectionAttributeMap), ????);
            // 0x00C7E768: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7E76C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(AttributeMap.ReflectionAttributeMap), ????);
            // 0x00C7E770: B #0xc7e67c                |  goto label_13;                         
            goto label_13;
            label_5:
            // 0x00C7E774: MOV x0, x20                | X0 = 1152921507849406400 (0x10000000C14587C0);//ML01
            // 0x00C7E778: SUB sp, x29, #0x40         | SP = (1152921514346232944 - 64) = 1152921514346232880 (0x1000000244833C30);
            // 0x00C7E77C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7E780: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7E784: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00C7E788: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00C7E78C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00C7E790: RET                        |  return (ProtoBuf.Meta.AttributeMap[])typeof(ProtoBuf.Meta.AttributeMap[]);
            return (ProtoBuf.Meta.AttributeMap[])null;
            //  |  // // {name=val_0, type=ProtoBuf.Meta.AttributeMap[], size=8, nGRN=0 }
            // 0x00C7E794: MOV x19, x0                | 
            // 0x00C7E798: ADD x0, sp, #8             | 
            // 0x00C7E79C: BL #0x299a140              | 
            // 0x00C7E7A0: MOV x0, x19                | 
            // 0x00C7E7A4: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7E7D4 (13101012), len: 476  VirtAddr: 0x00C7E7D4 RVA: 0x00C7E7D4 token: 100689205 methodIndex: 53423 delegateWrapperIndex: 0 methodInvoker: 0
        public static ProtoBuf.Meta.AttributeMap[] Create(ProtoBuf.Meta.TypeModel model, System.Reflection.MemberInfo member, bool inherit)
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00C7E7D4: STP x26, x25, [sp, #-0x50]! | stack[1152921514346361264] = ???;  stack[1152921514346361272] = ???;  //  dest_result_addr=1152921514346361264 |  dest_result_addr=1152921514346361272
            // 0x00C7E7D8: STP x24, x23, [sp, #0x10]  | stack[1152921514346361280] = ???;  stack[1152921514346361288] = ???;  //  dest_result_addr=1152921514346361280 |  dest_result_addr=1152921514346361288
            // 0x00C7E7DC: STP x22, x21, [sp, #0x20]  | stack[1152921514346361296] = ???;  stack[1152921514346361304] = ???;  //  dest_result_addr=1152921514346361296 |  dest_result_addr=1152921514346361304
            // 0x00C7E7E0: STP x20, x19, [sp, #0x30]  | stack[1152921514346361312] = ???;  stack[1152921514346361320] = ???;  //  dest_result_addr=1152921514346361312 |  dest_result_addr=1152921514346361320
            // 0x00C7E7E4: STP x29, x30, [sp, #0x40]  | stack[1152921514346361328] = ???;  stack[1152921514346361336] = ???;  //  dest_result_addr=1152921514346361328 |  dest_result_addr=1152921514346361336
            // 0x00C7E7E8: ADD x29, sp, #0x40         | X29 = (1152921514346361264 + 64) = 1152921514346361328 (0x10000002448531F0);
            // 0x00C7E7EC: SUB sp, sp, #0x10          | SP = (1152921514346361264 - 16) = 1152921514346361248 (0x10000002448531A0);
            // 0x00C7E7F0: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00C7E7F4: LDRB w8, [x21, #0xf9b]     | W8 = (bool)static_value_03733F9B;       
            // 0x00C7E7F8: MOV w19, w3                | W19 = W3;//m1                           
            // 0x00C7E7FC: MOV x20, x2                | X20 = inherit;//m1                      
            // 0x00C7E800: TBNZ w8, #0, #0xc7e81c     | if (static_value_03733F9B == true) goto label_0;
            // 0x00C7E804: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
            // 0x00C7E808: LDR x8, [x8, #0xc88]       | X8 = 0x2B8EEAC;                         
            // 0x00C7E80C: LDR w0, [x8]               | W0 = 0x126D;                            
            // 0x00C7E810: BL #0x2782188              | X0 = sub_2782188( ?? 0x126D, ????);     
            // 0x00C7E814: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7E818: STRB w8, [x21, #0xf9b]     | static_value_03733F9B = true;            //  dest_result_addr=57884571
            label_0:
            // 0x00C7E81C: CBNZ x20, #0xc7e824        | if (inherit == true) goto label_1;      
            if(inherit == true)
            {
                goto label_1;
            }
            // 0x00C7E820: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x126D, ????);     
            label_1:
            // 0x00C7E824: LDR x8, [x20]              | X8 = inherit;                           
            // 0x00C7E828: AND w1, w19, #1            | W1 = (W3 & 1);                          
            var val_1 = W3 & 1;
            // 0x00C7E82C: MOV x0, x20                | X0 = inherit;//m1                       
            // 0x00C7E830: LDP x9, x2, [x8, #0x1d0]   | X9 = inherit + 464; X2 = inherit + 464 + 8; //  | 
            // 0x00C7E834: BLR x9                     | X0 = inherit + 464();                   
            // 0x00C7E838: MOV x19, x0                | X19 = inherit;//m1                      
            // 0x00C7E83C: CBNZ x19, #0xc7e844        | if (inherit == true) goto label_2;      
            if(inherit == true)
            {
                goto label_2;
            }
            // 0x00C7E840: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? inherit, ????);    
            label_2:
            // 0x00C7E844: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x00C7E848: LDR x8, [x8, #0x878]       | X8 = 1152921507849406400;               
            // 0x00C7E84C: LDR w21, [x19, #0x18]      | W21 = inherit + 24;                     
            // 0x00C7E850: LDR x20, [x8]              | X20 = typeof(ProtoBuf.Meta.AttributeMap[]);
            // 0x00C7E854: MOV x0, x20                | X0 = 1152921507849406400 (0x10000000C14587C0);//ML01
            // 0x00C7E858: BL #0x277461c              | X0 = sub_277461C( ?? typeof(ProtoBuf.Meta.AttributeMap[]), ????);
            // 0x00C7E85C: MOV x0, x20                | X0 = 1152921507849406400 (0x10000000C14587C0);//ML01
            // 0x00C7E860: MOV x1, x21                | X1 = inherit + 24;//m1                  
            // 0x00C7E864: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(ProtoBuf.Meta.AttributeMap[]), ????);
            // 0x00C7E868: ADRP x23, #0x3607000       | X23 = 56651776 (0x3607000);             
            // 0x00C7E86C: ADRP x24, #0x35cc000       | X24 = 56410112 (0x35CC000);             
            // 0x00C7E870: LDR x23, [x23, #0x7a8]     | X23 = 1152921504882298880;              
            // 0x00C7E874: LDR x24, [x24, #0x510]     | X24 = 1152921504607006720;              
            // 0x00C7E878: MOV x20, x0                | X20 = 1152921507849406400 (0x10000000C14587C0);//ML01
            // 0x00C7E87C: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_7 = 0;
            // 0x00C7E880: B #0xc7e890                |  goto label_3;                          
            goto label_3;
            label_13:
            // 0x00C7E884: ADD x8, x20, x25, lsl #3   | X8 = (null + (X25) << 3);               
            var val_2 = null + ((X25) << 3);
            // 0x00C7E888: ADD w22, w22, #1           | W22 = (val_7 + 1) = val_7 (0x00000001); 
            val_7 = 1;
            // 0x00C7E88C: STR x21, [x8, #0x20]       | mem2[0] = inherit + 24;                  //  dest_result_addr=0
            mem2[0] = inherit + 24;
            label_3:
            // 0x00C7E890: CBNZ x19, #0xc7e898        | if (inherit == true) goto label_4;      
            if(inherit == true)
            {
                goto label_4;
            }
            // 0x00C7E894: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ProtoBuf.Meta.AttributeMap[]), ????);
            label_4:
            // 0x00C7E898: LDR w8, [x19, #0x18]       | W8 = inherit + 24;                      
            // 0x00C7E89C: CMP w22, w8                | STATE = COMPARE(0x1, inherit + 24)      
            // 0x00C7E8A0: B.GE #0xc7e97c             | if (val_7 >= inherit + 24) goto label_5;
            if(val_7 >= (inherit + 24))
            {
                goto label_5;
            }
            // 0x00C7E8A4: SXTW x25, w22              | X25 = 1 (0x00000001);                   
            // 0x00C7E8A8: CMP w22, w8                | STATE = COMPARE(0x1, inherit + 24)      
            // 0x00C7E8AC: B.LO #0xc7e8bc             | if (val_7 < inherit + 24) goto label_6; 
            if(val_7 < (inherit + 24))
            {
                goto label_6;
            }
            // 0x00C7E8B0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(ProtoBuf.Meta.AttributeMap[]), ????);
            // 0x00C7E8B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7E8B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(ProtoBuf.Meta.AttributeMap[]), ????);
            label_6:
            // 0x00C7E8BC: ADD x8, x19, x25, lsl #3   | X8 = (inherit + 8);                     
            bool val_3 = inherit + 8;
            // 0x00C7E8C0: LDR x0, [x23]              | X0 = typeof(AttributeMap.ReflectionAttributeMap);
            // 0x00C7E8C4: LDR x26, [x8, #0x20]       | X26 = (inherit + 8) + 32;               
            val_8 = mem[(inherit + 8) + 32];
            val_8 = (inherit + 8) + 32;
            // 0x00C7E8C8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AttributeMap.ReflectionAttributeMap), ????);
            // 0x00C7E8CC: MOV x21, x0                | X21 = 1152921504882298880 (0x10000000106B1000);//ML01
            // 0x00C7E8D0: CBZ x26, #0xc7e924         | if ((inherit + 8) + 32 == 0) goto label_7;
            if(val_8 == 0)
            {
                goto label_7;
            }
            // 0x00C7E8D4: LDR x8, [x26]              | X8 = (inherit + 8) + 32;                
            // 0x00C7E8D8: LDR x1, [x24]              | X1 = typeof(System.Attribute);          
            // 0x00C7E8DC: LDRB w10, [x8, #0x104]     | W10 = (inherit + 8) + 32 + 260;         
            // 0x00C7E8E0: LDRB w9, [x1, #0x104]      | W9 = System.Attribute.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00C7E8E4: CMP w10, w9                | STATE = COMPARE((inherit + 8) + 32 + 260, System.Attribute.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00C7E8E8: B.LO #0xc7e900             | if ((inherit + 8) + 32 + 260 < System.Attribute.__il2cppRuntimeField_typeHierarchyDepth) goto label_8;
            // 0x00C7E8EC: LDR x10, [x8, #0xb0]       | X10 = (inherit + 8) + 32 + 176;         
            // 0x00C7E8F0: ADD x9, x10, x9, lsl #3    | X9 = ((inherit + 8) + 32 + 176 + (System.Attribute.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00C7E8F4: LDUR x9, [x9, #-8]         | X9 = ((inherit + 8) + 32 + 176 + (System.Attribute.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00C7E8F8: CMP x9, x1                 | STATE = COMPARE(((inherit + 8) + 32 + 176 + (System.Attribute.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Attribute))
            // 0x00C7E8FC: B.EQ #0xc7e928             | if (((inherit + 8) + 32 + 176 + (System.Attribute.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_9;
            label_8:
            // 0x00C7E900: LDR x0, [x8, #0x30]        | X0 = (inherit + 8) + 32 + 48;           
            // 0x00C7E904: ADD x8, sp, #8             | X8 = (1152921514346361248 + 8) = 1152921514346361256 (0x10000002448531A8);
            // 0x00C7E908: BL #0x27d96d4              | X0 = sub_27D96D4( ?? (inherit + 8) + 32 + 48, ????);
            // 0x00C7E90C: LDR x0, [sp, #8]           | X0 = val_5;                              //  find_add[1152921514346349344]
            // 0x00C7E910: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00C7E914: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7E918: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00C7E91C: ADD x0, sp, #8             | X0 = (1152921514346361248 + 8) = 1152921514346361256 (0x10000002448531A8);
            // 0x00C7E920: BL #0x299a140              | 
            label_7:
            // 0x00C7E924: MOV x26, xzr               | X26 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_9:
            // 0x00C7E928: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7E92C: MOV x0, x21                | X0 = 1152921504882298880 (0x10000000106B1000);//ML01
            object val_6 = null;
            // 0x00C7E930: BL #0x16f59f0              | .ctor();                                
            val_6 = new System.Object();
            // 0x00C7E934: STR x26, [x21, #0x10]      | typeof(AttributeMap.ReflectionAttributeMap).__il2cppRuntimeField_10 = 0x0;  //  dest_result_addr=1152921504882298896
            typeof(AttributeMap.ReflectionAttributeMap).__il2cppRuntimeField_10 = val_8;
            // 0x00C7E938: CBNZ x20, #0xc7e940        | if ( != null) goto label_10;            
            if(null != null)
            {
                goto label_10;
            }
            // 0x00C7E93C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_10:
            // 0x00C7E940: LDR x8, [x20]              | X8 = ;                                  
            // 0x00C7E944: MOV x0, x21                | X0 = 1152921504882298880 (0x10000000106B1000);//ML01
            // 0x00C7E948: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00C7E94C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(AttributeMap.ReflectionAttributeMap), ????);
            // 0x00C7E950: CBNZ x0, #0xc7e960         | if ( != 0) goto label_11;               
            if(null != 0)
            {
                goto label_11;
            }
            // 0x00C7E954: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(AttributeMap.ReflectionAttributeMap), ????);
            // 0x00C7E958: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7E95C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(AttributeMap.ReflectionAttributeMap), ????);
            label_11:
            // 0x00C7E960: LDR w8, [x20, #0x18]       | W8 = ProtoBuf.Meta.AttributeMap[].__il2cppRuntimeField_namespaze;
            // 0x00C7E964: CMP w22, w8                | STATE = COMPARE(0x1, ProtoBuf.Meta.AttributeMap[].__il2cppRuntimeField_namespaze)
            // 0x00C7E968: B.LO #0xc7e884             | if (val_7 < ProtoBuf.Meta.AttributeMap[].__il2cppRuntimeField_namespaze) goto label_13;
            // 0x00C7E96C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(AttributeMap.ReflectionAttributeMap), ????);
            // 0x00C7E970: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7E974: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(AttributeMap.ReflectionAttributeMap), ????);
            // 0x00C7E978: B #0xc7e884                |  goto label_13;                         
            goto label_13;
            label_5:
            // 0x00C7E97C: MOV x0, x20                | X0 = 1152921507849406400 (0x10000000C14587C0);//ML01
            // 0x00C7E980: SUB sp, x29, #0x40         | SP = (1152921514346361328 - 64) = 1152921514346361264 (0x10000002448531B0);
            // 0x00C7E984: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7E988: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7E98C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00C7E990: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00C7E994: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00C7E998: RET                        |  return (ProtoBuf.Meta.AttributeMap[])typeof(ProtoBuf.Meta.AttributeMap[]);
            return (ProtoBuf.Meta.AttributeMap[])null;
            //  |  // // {name=val_0, type=ProtoBuf.Meta.AttributeMap[], size=8, nGRN=0 }
            // 0x00C7E99C: MOV x19, x0                | 
            // 0x00C7E9A0: ADD x0, sp, #8             | 
            // 0x00C7E9A4: BL #0x299a140              | 
            // 0x00C7E9A8: MOV x0, x19                | 
            // 0x00C7E9AC: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7E9B0 (13101488), len: 472  VirtAddr: 0x00C7E9B0 RVA: 0x00C7E9B0 token: 100689206 methodIndex: 53424 delegateWrapperIndex: 0 methodInvoker: 0
        public static ProtoBuf.Meta.AttributeMap[] Create(ProtoBuf.Meta.TypeModel model, System.Reflection.Assembly assembly)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_6;
            //  | 
            var val_7;
            // 0x00C7E9B0: STP x26, x25, [sp, #-0x50]! | stack[1152921514346489648] = ???;  stack[1152921514346489656] = ???;  //  dest_result_addr=1152921514346489648 |  dest_result_addr=1152921514346489656
            // 0x00C7E9B4: STP x24, x23, [sp, #0x10]  | stack[1152921514346489664] = ???;  stack[1152921514346489672] = ???;  //  dest_result_addr=1152921514346489664 |  dest_result_addr=1152921514346489672
            // 0x00C7E9B8: STP x22, x21, [sp, #0x20]  | stack[1152921514346489680] = ???;  stack[1152921514346489688] = ???;  //  dest_result_addr=1152921514346489680 |  dest_result_addr=1152921514346489688
            // 0x00C7E9BC: STP x20, x19, [sp, #0x30]  | stack[1152921514346489696] = ???;  stack[1152921514346489704] = ???;  //  dest_result_addr=1152921514346489696 |  dest_result_addr=1152921514346489704
            // 0x00C7E9C0: STP x29, x30, [sp, #0x40]  | stack[1152921514346489712] = ???;  stack[1152921514346489720] = ???;  //  dest_result_addr=1152921514346489712 |  dest_result_addr=1152921514346489720
            // 0x00C7E9C4: ADD x29, sp, #0x40         | X29 = (1152921514346489648 + 64) = 1152921514346489712 (0x1000000244872770);
            // 0x00C7E9C8: SUB sp, sp, #0x10          | SP = (1152921514346489648 - 16) = 1152921514346489632 (0x1000000244872720);
            // 0x00C7E9CC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00C7E9D0: LDRB w8, [x20, #0xf9c]     | W8 = (bool)static_value_03733F9C;       
            // 0x00C7E9D4: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00C7E9D8: TBNZ w8, #0, #0xc7e9f4     | if (static_value_03733F9C == true) goto label_0;
            // 0x00C7E9DC: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
            // 0x00C7E9E0: LDR x8, [x8, #0x490]       | X8 = 0x2B8EEA4;                         
            // 0x00C7E9E4: LDR w0, [x8]               | W0 = 0x126B;                            
            // 0x00C7E9E8: BL #0x2782188              | X0 = sub_2782188( ?? 0x126B, ????);     
            // 0x00C7E9EC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7E9F0: STRB w8, [x20, #0xf9c]     | static_value_03733F9C = true;            //  dest_result_addr=57884572
            label_0:
            // 0x00C7E9F4: CBNZ x19, #0xc7e9fc        | if (X2 != 0) goto label_1;              
            if(X2 != 0)
            {
                goto label_1;
            }
            // 0x00C7E9F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x126B, ????);     
            label_1:
            // 0x00C7E9FC: LDR x8, [x19]              | X8 = X2;                                
            // 0x00C7EA00: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x00C7EA04: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00C7EA08: LDP x9, x2, [x8, #0x1a0]   | X9 = X2 + 416; X2 = X2 + 416 + 8;        //  | 
            // 0x00C7EA0C: BLR x9                     | X0 = X2 + 416();                        
            // 0x00C7EA10: MOV x19, x0                | X19 = X2;//m1                           
            // 0x00C7EA14: CBNZ x19, #0xc7ea1c        | if (X2 != 0) goto label_2;              
            if(X2 != 0)
            {
                goto label_2;
            }
            // 0x00C7EA18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X2, ????);         
            label_2:
            // 0x00C7EA1C: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x00C7EA20: LDR x8, [x8, #0x878]       | X8 = 1152921507849406400;               
            // 0x00C7EA24: LDR w21, [x19, #0x18]      | W21 = X2 + 24;                          
            // 0x00C7EA28: LDR x20, [x8]              | X20 = typeof(ProtoBuf.Meta.AttributeMap[]);
            // 0x00C7EA2C: MOV x0, x20                | X0 = 1152921507849406400 (0x10000000C14587C0);//ML01
            // 0x00C7EA30: BL #0x277461c              | X0 = sub_277461C( ?? typeof(ProtoBuf.Meta.AttributeMap[]), ????);
            // 0x00C7EA34: MOV x0, x20                | X0 = 1152921507849406400 (0x10000000C14587C0);//ML01
            // 0x00C7EA38: MOV x1, x21                | X1 = X2 + 24;//m1                       
            // 0x00C7EA3C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(ProtoBuf.Meta.AttributeMap[]), ????);
            // 0x00C7EA40: ADRP x23, #0x3607000       | X23 = 56651776 (0x3607000);             
            // 0x00C7EA44: ADRP x24, #0x35cc000       | X24 = 56410112 (0x35CC000);             
            // 0x00C7EA48: LDR x23, [x23, #0x7a8]     | X23 = 1152921504882298880;              
            // 0x00C7EA4C: LDR x24, [x24, #0x510]     | X24 = 1152921504607006720;              
            // 0x00C7EA50: MOV x20, x0                | X20 = 1152921507849406400 (0x10000000C14587C0);//ML01
            // 0x00C7EA54: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_6 = 0;
            // 0x00C7EA58: B #0xc7ea68                |  goto label_3;                          
            goto label_3;
            label_13:
            // 0x00C7EA5C: ADD x8, x20, x25, lsl #3   | X8 = (null + (X25) << 3);               
            var val_1 = null + ((X25) << 3);
            // 0x00C7EA60: ADD w22, w22, #1           | W22 = (val_6 + 1) = val_6 (0x00000001); 
            val_6 = 1;
            // 0x00C7EA64: STR x21, [x8, #0x20]       | mem2[0] = X2 + 24;                       //  dest_result_addr=0
            mem2[0] = X2 + 24;
            label_3:
            // 0x00C7EA68: CBNZ x19, #0xc7ea70        | if (X2 != 0) goto label_4;              
            if(X2 != 0)
            {
                goto label_4;
            }
            // 0x00C7EA6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ProtoBuf.Meta.AttributeMap[]), ????);
            label_4:
            // 0x00C7EA70: LDR w8, [x19, #0x18]       | W8 = X2 + 24;                           
            // 0x00C7EA74: CMP w22, w8                | STATE = COMPARE(0x1, X2 + 24)           
            // 0x00C7EA78: B.GE #0xc7eb54             | if (val_6 >= X2 + 24) goto label_5;     
            if(val_6 >= (X2 + 24))
            {
                goto label_5;
            }
            // 0x00C7EA7C: SXTW x25, w22              | X25 = 1 (0x00000001);                   
            // 0x00C7EA80: CMP w22, w8                | STATE = COMPARE(0x1, X2 + 24)           
            // 0x00C7EA84: B.LO #0xc7ea94             | if (val_6 < X2 + 24) goto label_6;      
            if(val_6 < (X2 + 24))
            {
                goto label_6;
            }
            // 0x00C7EA88: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(ProtoBuf.Meta.AttributeMap[]), ????);
            // 0x00C7EA8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7EA90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(ProtoBuf.Meta.AttributeMap[]), ????);
            label_6:
            // 0x00C7EA94: ADD x8, x19, x25, lsl #3   | X8 = (X2 + 8);                          
            var val_2 = X2 + 8;
            // 0x00C7EA98: LDR x0, [x23]              | X0 = typeof(AttributeMap.ReflectionAttributeMap);
            // 0x00C7EA9C: LDR x26, [x8, #0x20]       | X26 = (X2 + 8) + 32;                    
            val_7 = mem[(X2 + 8) + 32];
            val_7 = (X2 + 8) + 32;
            // 0x00C7EAA0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AttributeMap.ReflectionAttributeMap), ????);
            // 0x00C7EAA4: MOV x21, x0                | X21 = 1152921504882298880 (0x10000000106B1000);//ML01
            // 0x00C7EAA8: CBZ x26, #0xc7eafc         | if ((X2 + 8) + 32 == 0) goto label_7;   
            if(val_7 == 0)
            {
                goto label_7;
            }
            // 0x00C7EAAC: LDR x8, [x26]              | X8 = (X2 + 8) + 32;                     
            // 0x00C7EAB0: LDR x1, [x24]              | X1 = typeof(System.Attribute);          
            // 0x00C7EAB4: LDRB w10, [x8, #0x104]     | W10 = (X2 + 8) + 32 + 260;              
            // 0x00C7EAB8: LDRB w9, [x1, #0x104]      | W9 = System.Attribute.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00C7EABC: CMP w10, w9                | STATE = COMPARE((X2 + 8) + 32 + 260, System.Attribute.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00C7EAC0: B.LO #0xc7ead8             | if ((X2 + 8) + 32 + 260 < System.Attribute.__il2cppRuntimeField_typeHierarchyDepth) goto label_8;
            // 0x00C7EAC4: LDR x10, [x8, #0xb0]       | X10 = (X2 + 8) + 32 + 176;              
            // 0x00C7EAC8: ADD x9, x10, x9, lsl #3    | X9 = ((X2 + 8) + 32 + 176 + (System.Attribute.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00C7EACC: LDUR x9, [x9, #-8]         | X9 = ((X2 + 8) + 32 + 176 + (System.Attribute.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00C7EAD0: CMP x9, x1                 | STATE = COMPARE(((X2 + 8) + 32 + 176 + (System.Attribute.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Attribute))
            // 0x00C7EAD4: B.EQ #0xc7eb00             | if (((X2 + 8) + 32 + 176 + (System.Attribute.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_9;
            label_8:
            // 0x00C7EAD8: LDR x0, [x8, #0x30]        | X0 = (X2 + 8) + 32 + 48;                
            // 0x00C7EADC: ADD x8, sp, #8             | X8 = (1152921514346489632 + 8) = 1152921514346489640 (0x1000000244872728);
            // 0x00C7EAE0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? (X2 + 8) + 32 + 48, ????);
            // 0x00C7EAE4: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921514346477728]
            // 0x00C7EAE8: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00C7EAEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7EAF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00C7EAF4: ADD x0, sp, #8             | X0 = (1152921514346489632 + 8) = 1152921514346489640 (0x1000000244872728);
            // 0x00C7EAF8: BL #0x299a140              | 
            label_7:
            // 0x00C7EAFC: MOV x26, xzr               | X26 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_9:
            // 0x00C7EB00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7EB04: MOV x0, x21                | X0 = 1152921504882298880 (0x10000000106B1000);//ML01
            object val_5 = null;
            // 0x00C7EB08: BL #0x16f59f0              | .ctor();                                
            val_5 = new System.Object();
            // 0x00C7EB0C: STR x26, [x21, #0x10]      | typeof(AttributeMap.ReflectionAttributeMap).__il2cppRuntimeField_10 = 0x0;  //  dest_result_addr=1152921504882298896
            typeof(AttributeMap.ReflectionAttributeMap).__il2cppRuntimeField_10 = val_7;
            // 0x00C7EB10: CBNZ x20, #0xc7eb18        | if ( != null) goto label_10;            
            if(null != null)
            {
                goto label_10;
            }
            // 0x00C7EB14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_10:
            // 0x00C7EB18: LDR x8, [x20]              | X8 = ;                                  
            // 0x00C7EB1C: MOV x0, x21                | X0 = 1152921504882298880 (0x10000000106B1000);//ML01
            // 0x00C7EB20: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00C7EB24: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(AttributeMap.ReflectionAttributeMap), ????);
            // 0x00C7EB28: CBNZ x0, #0xc7eb38         | if ( != 0) goto label_11;               
            if(null != 0)
            {
                goto label_11;
            }
            // 0x00C7EB2C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(AttributeMap.ReflectionAttributeMap), ????);
            // 0x00C7EB30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7EB34: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(AttributeMap.ReflectionAttributeMap), ????);
            label_11:
            // 0x00C7EB38: LDR w8, [x20, #0x18]       | W8 = ProtoBuf.Meta.AttributeMap[].__il2cppRuntimeField_namespaze;
            // 0x00C7EB3C: CMP w22, w8                | STATE = COMPARE(0x1, ProtoBuf.Meta.AttributeMap[].__il2cppRuntimeField_namespaze)
            // 0x00C7EB40: B.LO #0xc7ea5c             | if (val_6 < ProtoBuf.Meta.AttributeMap[].__il2cppRuntimeField_namespaze) goto label_13;
            // 0x00C7EB44: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(AttributeMap.ReflectionAttributeMap), ????);
            // 0x00C7EB48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7EB4C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(AttributeMap.ReflectionAttributeMap), ????);
            // 0x00C7EB50: B #0xc7ea5c                |  goto label_13;                         
            goto label_13;
            label_5:
            // 0x00C7EB54: MOV x0, x20                | X0 = 1152921507849406400 (0x10000000C14587C0);//ML01
            // 0x00C7EB58: SUB sp, x29, #0x40         | SP = (1152921514346489712 - 64) = 1152921514346489648 (0x1000000244872730);
            // 0x00C7EB5C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7EB60: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7EB64: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00C7EB68: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00C7EB6C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00C7EB70: RET                        |  return (ProtoBuf.Meta.AttributeMap[])typeof(ProtoBuf.Meta.AttributeMap[]);
            return (ProtoBuf.Meta.AttributeMap[])null;
            //  |  // // {name=val_0, type=ProtoBuf.Meta.AttributeMap[], size=8, nGRN=0 }
            // 0x00C7EB74: MOV x19, x0                | 
            // 0x00C7EB78: ADD x0, sp, #8             | 
            // 0x00C7EB7C: BL #0x299a140              | 
            // 0x00C7EB80: MOV x0, x19                | 
            // 0x00C7EB84: BL #0x980800               | 
        
        }
        public abstract object get_Target(); // 0
    
    }

}
