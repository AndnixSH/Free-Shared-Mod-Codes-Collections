using UnityEngine;

namespace ILRuntime.Mono.Cecil
{
    public sealed class CallSite : IMethodSignature, IMetadataTokenProvider
    {
        // Fields
        private readonly ILRuntime.Mono.Cecil.MethodReference signature; //  0x00000010
        
        // Properties
        set; }
        public bool ExplicitThis { set; }
        public ILRuntime.Mono.Cecil.MethodCallingConvention CallingConvention { set; }
        public bool HasParameters { get; }
        public ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ParameterDefinition> Parameters { get; }
        public ILRuntime.Mono.Cecil.TypeReference ReturnType { get; }
        public ILRuntime.Mono.Cecil.MethodReturnType MethodReturnType { get; }
        public ILRuntime.Mono.Cecil.MetadataToken MetadataToken { get; set; }
        public string FullName { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E58AE4 (15043300), len: 60  VirtAddr: 0x00E58AE4 RVA: 0x00E58AE4 token: 100663748 methodIndex: 19347 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_HasThis(bool value)
        {
            //
            // Disasemble & Code
            // 0x00E58AE4: STP x20, x19, [sp, #-0x20]! | stack[1152921509465180992] = ???;  stack[1152921509465181000] = ???;  //  dest_result_addr=1152921509465180992 |  dest_result_addr=1152921509465181000
            // 0x00E58AE8: STP x29, x30, [sp, #0x10]  | stack[1152921509465181008] = ???;  stack[1152921509465181016] = ???;  //  dest_result_addr=1152921509465181008 |  dest_result_addr=1152921509465181016
            // 0x00E58AEC: ADD x29, sp, #0x10         | X29 = (1152921509465180992 + 16) = 1152921509465181008 (0x1000000121944B50);
            // 0x00E58AF0: LDR x19, [x0, #0x10]       | X19 = this.signature; //P2              
            // 0x00E58AF4: MOV w20, w1                | W20 = value;//m1                        
            // 0x00E58AF8: CBNZ x19, #0xe58b00        | if (this.signature != null) goto label_0;
            if(this.signature != null)
            {
                goto label_0;
            }
            // 0x00E58AFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E58B00: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.MethodReference);
            // 0x00E58B04: AND w1, w20, #1            | W1 = (value & 1);                       
            value = value;
            // 0x00E58B08: MOV x0, x19                | X0 = this.signature;//m1                
            // 0x00E58B0C: LDR x3, [x8, #0x2d0]       | X3 = typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_2D0;
            // 0x00E58B10: LDR x2, [x8, #0x2d8]       | X2 = typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_2D8;
            // 0x00E58B14: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E58B18: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E58B1C: BR x3                      | goto typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_2D0;
            goto typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_2D0;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E58B20 (15043360), len: 60  VirtAddr: 0x00E58B20 RVA: 0x00E58B20 token: 100663749 methodIndex: 19348 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_ExplicitThis(bool value)
        {
            //
            // Disasemble & Code
            // 0x00E58B20: STP x20, x19, [sp, #-0x20]! | stack[1152921509465301184] = ???;  stack[1152921509465301192] = ???;  //  dest_result_addr=1152921509465301184 |  dest_result_addr=1152921509465301192
            // 0x00E58B24: STP x29, x30, [sp, #0x10]  | stack[1152921509465301200] = ???;  stack[1152921509465301208] = ???;  //  dest_result_addr=1152921509465301200 |  dest_result_addr=1152921509465301208
            // 0x00E58B28: ADD x29, sp, #0x10         | X29 = (1152921509465301184 + 16) = 1152921509465301200 (0x10000001219620D0);
            // 0x00E58B2C: LDR x19, [x0, #0x10]       | X19 = this.signature; //P2              
            // 0x00E58B30: MOV w20, w1                | W20 = value;//m1                        
            // 0x00E58B34: CBNZ x19, #0xe58b3c        | if (this.signature != null) goto label_0;
            if(this.signature != null)
            {
                goto label_0;
            }
            // 0x00E58B38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E58B3C: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.MethodReference);
            // 0x00E58B40: AND w1, w20, #1            | W1 = (value & 1);                       
            value = value;
            // 0x00E58B44: MOV x0, x19                | X0 = this.signature;//m1                
            // 0x00E58B48: LDR x3, [x8, #0x2e0]       | X3 = typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_2E0;
            // 0x00E58B4C: LDR x2, [x8, #0x2e8]       | X2 = typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_2E8;
            // 0x00E58B50: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E58B54: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E58B58: BR x3                      | goto typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_2E0;
            goto typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_2E0;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E58B5C (15043420), len: 60  VirtAddr: 0x00E58B5C RVA: 0x00E58B5C token: 100663750 methodIndex: 19349 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_CallingConvention(ILRuntime.Mono.Cecil.MethodCallingConvention value)
        {
            //
            // Disasemble & Code
            // 0x00E58B5C: STP x20, x19, [sp, #-0x20]! | stack[1152921509465425472] = ???;  stack[1152921509465425480] = ???;  //  dest_result_addr=1152921509465425472 |  dest_result_addr=1152921509465425480
            // 0x00E58B60: STP x29, x30, [sp, #0x10]  | stack[1152921509465425488] = ???;  stack[1152921509465425496] = ???;  //  dest_result_addr=1152921509465425488 |  dest_result_addr=1152921509465425496
            // 0x00E58B64: ADD x29, sp, #0x10         | X29 = (1152921509465425472 + 16) = 1152921509465425488 (0x1000000121980650);
            // 0x00E58B68: LDR x20, [x0, #0x10]       | X20 = this.signature; //P2              
            // 0x00E58B6C: MOV w19, w1                | W19 = value;//m1                        
            // 0x00E58B70: CBNZ x20, #0xe58b78        | if (this.signature != null) goto label_0;
            if(this.signature != null)
            {
                goto label_0;
            }
            // 0x00E58B74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E58B78: LDR x8, [x20]              | X8 = typeof(ILRuntime.Mono.Cecil.MethodReference);
            // 0x00E58B7C: MOV x0, x20                | X0 = this.signature;//m1                
            // 0x00E58B80: MOV w1, w19                | W1 = value;//m1                         
            // 0x00E58B84: LDR x3, [x8, #0x2f0]       | X3 = typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_2F0;
            // 0x00E58B88: LDR x2, [x8, #0x2f8]       | X2 = typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_2F8;
            // 0x00E58B8C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E58B90: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E58B94: BR x3                      | goto typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_2F0;
            goto typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_2F0;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E58B98 (15043480), len: 52  VirtAddr: 0x00E58B98 RVA: 0x00E58B98 token: 100663751 methodIndex: 19350 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_HasParameters()
        {
            //
            // Disasemble & Code
            // 0x00E58B98: STP x20, x19, [sp, #-0x20]! | stack[1152921509465549760] = ???;  stack[1152921509465549768] = ???;  //  dest_result_addr=1152921509465549760 |  dest_result_addr=1152921509465549768
            // 0x00E58B9C: STP x29, x30, [sp, #0x10]  | stack[1152921509465549776] = ???;  stack[1152921509465549784] = ???;  //  dest_result_addr=1152921509465549776 |  dest_result_addr=1152921509465549784
            // 0x00E58BA0: ADD x29, sp, #0x10         | X29 = (1152921509465549760 + 16) = 1152921509465549776 (0x100000012199EBD0);
            // 0x00E58BA4: LDR x19, [x0, #0x10]       | X19 = this.signature; //P2              
            // 0x00E58BA8: CBNZ x19, #0xe58bb0        | if (this.signature != null) goto label_0;
            if(this.signature != null)
            {
                goto label_0;
            }
            // 0x00E58BAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E58BB0: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.MethodReference);
            // 0x00E58BB4: MOV x0, x19                | X0 = this.signature;//m1                
            // 0x00E58BB8: LDR x2, [x8, #0x300]       | X2 = typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_300;
            // 0x00E58BBC: LDR x1, [x8, #0x308]       | X1 = typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_308;
            // 0x00E58BC0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E58BC4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E58BC8: BR x2                      | goto typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_300;
            goto typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_300;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E58BCC (15043532), len: 52  VirtAddr: 0x00E58BCC RVA: 0x00E58BCC token: 100663752 methodIndex: 19351 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ParameterDefinition> get_Parameters()
        {
            //
            // Disasemble & Code
            // 0x00E58BCC: STP x20, x19, [sp, #-0x20]! | stack[1152921509465669952] = ???;  stack[1152921509465669960] = ???;  //  dest_result_addr=1152921509465669952 |  dest_result_addr=1152921509465669960
            // 0x00E58BD0: STP x29, x30, [sp, #0x10]  | stack[1152921509465669968] = ???;  stack[1152921509465669976] = ???;  //  dest_result_addr=1152921509465669968 |  dest_result_addr=1152921509465669976
            // 0x00E58BD4: ADD x29, sp, #0x10         | X29 = (1152921509465669952 + 16) = 1152921509465669968 (0x10000001219BC150);
            // 0x00E58BD8: LDR x19, [x0, #0x10]       | X19 = this.signature; //P2              
            // 0x00E58BDC: CBNZ x19, #0xe58be4        | if (this.signature != null) goto label_0;
            if(this.signature != null)
            {
                goto label_0;
            }
            // 0x00E58BE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E58BE4: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.MethodReference);
            // 0x00E58BE8: MOV x0, x19                | X0 = this.signature;//m1                
            // 0x00E58BEC: LDR x2, [x8, #0x310]       | X2 = typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_310;
            // 0x00E58BF0: LDR x1, [x8, #0x318]       | X1 = typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_318;
            // 0x00E58BF4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E58BF8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E58BFC: BR x2                      | goto typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_310;
            goto typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_310;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E58C00 (15043584), len: 76  VirtAddr: 0x00E58C00 RVA: 0x00E58C00 token: 100663753 methodIndex: 19352 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Mono.Cecil.TypeReference get_ReturnType()
        {
            //
            // Disasemble & Code
            // 0x00E58C00: STP x20, x19, [sp, #-0x20]! | stack[1152921509465790144] = ???;  stack[1152921509465790152] = ???;  //  dest_result_addr=1152921509465790144 |  dest_result_addr=1152921509465790152
            // 0x00E58C04: STP x29, x30, [sp, #0x10]  | stack[1152921509465790160] = ???;  stack[1152921509465790168] = ???;  //  dest_result_addr=1152921509465790160 |  dest_result_addr=1152921509465790168
            // 0x00E58C08: ADD x29, sp, #0x10         | X29 = (1152921509465790144 + 16) = 1152921509465790160 (0x10000001219D96D0);
            // 0x00E58C0C: LDR x19, [x0, #0x10]       | X19 = this.signature; //P2              
            // 0x00E58C10: CBNZ x19, #0xe58c18        | if (this.signature != null) goto label_0;
            if(this.signature != null)
            {
                goto label_0;
            }
            // 0x00E58C14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E58C18: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.MethodReference);
            // 0x00E58C1C: MOV x0, x19                | X0 = this.signature;//m1                
            // 0x00E58C20: LDR x9, [x8, #0x350]       | X9 = typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_350;
            // 0x00E58C24: LDR x1, [x8, #0x358]       | X1 = typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_358;
            // 0x00E58C28: BLR x9                     | X0 = typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_350();
            // 0x00E58C2C: MOV x19, x0                | X19 = this.signature;//m1               
            // 0x00E58C30: CBNZ x19, #0xe58c38        | if (this.signature != null) goto label_1;
            if(this.signature != null)
            {
                goto label_1;
            }
            // 0x00E58C34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.signature, ????);
            label_1:
            // 0x00E58C38: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E58C3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E58C40: MOV x0, x19                | X0 = this.signature;//m1                
            // 0x00E58C44: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E58C48: B #0x11d7ac4               | return this.signature.get_ReturnType(); 
            return this.signature.ReturnType;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E58C4C (15043660), len: 52  VirtAddr: 0x00E58C4C RVA: 0x00E58C4C token: 100663754 methodIndex: 19353 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Mono.Cecil.MethodReturnType get_MethodReturnType()
        {
            //
            // Disasemble & Code
            // 0x00E58C4C: STP x20, x19, [sp, #-0x20]! | stack[1152921509465910336] = ???;  stack[1152921509465910344] = ???;  //  dest_result_addr=1152921509465910336 |  dest_result_addr=1152921509465910344
            // 0x00E58C50: STP x29, x30, [sp, #0x10]  | stack[1152921509465910352] = ???;  stack[1152921509465910360] = ???;  //  dest_result_addr=1152921509465910352 |  dest_result_addr=1152921509465910360
            // 0x00E58C54: ADD x29, sp, #0x10         | X29 = (1152921509465910336 + 16) = 1152921509465910352 (0x10000001219F6C50);
            // 0x00E58C58: LDR x19, [x0, #0x10]       | X19 = this.signature; //P2              
            // 0x00E58C5C: CBNZ x19, #0xe58c64        | if (this.signature != null) goto label_0;
            if(this.signature != null)
            {
                goto label_0;
            }
            // 0x00E58C60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E58C64: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.MethodReference);
            // 0x00E58C68: MOV x0, x19                | X0 = this.signature;//m1                
            // 0x00E58C6C: LDR x2, [x8, #0x350]       | X2 = typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_350;
            // 0x00E58C70: LDR x1, [x8, #0x358]       | X1 = typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_358;
            // 0x00E58C74: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E58C78: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E58C7C: BR x2                      | goto typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_350;
            goto typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_350;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E58C80 (15043712), len: 40  VirtAddr: 0x00E58C80 RVA: 0x00E58C80 token: 100663755 methodIndex: 19354 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Mono.Cecil.MetadataToken get_MetadataToken()
        {
            //
            // Disasemble & Code
            // 0x00E58C80: STP x20, x19, [sp, #-0x20]! | stack[1152921509466030528] = ???;  stack[1152921509466030536] = ???;  //  dest_result_addr=1152921509466030528 |  dest_result_addr=1152921509466030536
            // 0x00E58C84: STP x29, x30, [sp, #0x10]  | stack[1152921509466030544] = ???;  stack[1152921509466030552] = ???;  //  dest_result_addr=1152921509466030544 |  dest_result_addr=1152921509466030552
            // 0x00E58C88: ADD x29, sp, #0x10         | X29 = (1152921509466030528 + 16) = 1152921509466030544 (0x1000000121A141D0);
            // 0x00E58C8C: LDR x19, [x0, #0x10]       | X19 = this.signature; //P2              
            // 0x00E58C90: CBNZ x19, #0xe58c98        | if (this.signature != null) goto label_0;
            if(this.signature != null)
            {
                goto label_0;
            }
            // 0x00E58C94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E58C98: LDR w0, [x19, #0x20]       | 
            // 0x00E58C9C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E58CA0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E58CA4: RET                        |  return (ILRuntime.Mono.Cecil.MetadataToken)this;
            return (ILRuntime.Mono.Cecil.MetadataToken)this;
            //  |  // // {name=val_0.token, type=System.UInt32, size=4, nGRN=0 offset=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E58CA8 (15043752), len: 44  VirtAddr: 0x00E58CA8 RVA: 0x00E58CA8 token: 100663756 methodIndex: 19355 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_MetadataToken(ILRuntime.Mono.Cecil.MetadataToken value)
        {
            //
            // Disasemble & Code
            // 0x00E58CA8: STP x20, x19, [sp, #-0x20]! | stack[1152921509466150720] = ???;  stack[1152921509466150728] = ???;  //  dest_result_addr=1152921509466150720 |  dest_result_addr=1152921509466150728
            // 0x00E58CAC: STP x29, x30, [sp, #0x10]  | stack[1152921509466150736] = ???;  stack[1152921509466150744] = ???;  //  dest_result_addr=1152921509466150736 |  dest_result_addr=1152921509466150744
            // 0x00E58CB0: ADD x29, sp, #0x10         | X29 = (1152921509466150720 + 16) = 1152921509466150736 (0x1000000121A31750);
            // 0x00E58CB4: LDR x20, [x0, #0x10]       | X20 = this.signature; //P2              
            // 0x00E58CB8: MOV x19, x1                | X19 = value.token;//m1                  
            // 0x00E58CBC: CBNZ x20, #0xe58cc4        | if (this.signature != null) goto label_0;
            if(this.signature != null)
            {
                goto label_0;
            }
            // 0x00E58CC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E58CC4: STR w19, [x20, #0x20]      | mem2[0] = value.token;                   //  dest_result_addr=0
            mem2[0] = value.token;
            // 0x00E58CC8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E58CCC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E58CD0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E58CD4 (15043796), len: 236  VirtAddr: 0x00E58CD4 RVA: 0x00E58CD4 token: 100663757 methodIndex: 19356 delegateWrapperIndex: 0 methodInvoker: 0
        public string get_FullName()
        {
            //
            // Disasemble & Code
            // 0x00E58CD4: STP x22, x21, [sp, #-0x30]! | stack[1152921509466274992] = ???;  stack[1152921509466275000] = ???;  //  dest_result_addr=1152921509466274992 |  dest_result_addr=1152921509466275000
            // 0x00E58CD8: STP x20, x19, [sp, #0x10]  | stack[1152921509466275008] = ???;  stack[1152921509466275016] = ???;  //  dest_result_addr=1152921509466275008 |  dest_result_addr=1152921509466275016
            // 0x00E58CDC: STP x29, x30, [sp, #0x20]  | stack[1152921509466275024] = ???;  stack[1152921509466275032] = ???;  //  dest_result_addr=1152921509466275024 |  dest_result_addr=1152921509466275032
            // 0x00E58CE0: ADD x29, sp, #0x20         | X29 = (1152921509466274992 + 32) = 1152921509466275024 (0x1000000121A4FCD0);
            // 0x00E58CE4: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E58CE8: LDRB w8, [x20, #0xad7]     | W8 = (bool)static_value_03734AD7;       
            // 0x00E58CEC: MOV x19, x0                | X19 = 1152921509466287040 (0x1000000121A52BC0);//ML01
            // 0x00E58CF0: TBNZ w8, #0, #0xe58d0c     | if (static_value_03734AD7 == true) goto label_0;
            // 0x00E58CF4: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x00E58CF8: LDR x8, [x8, #0x878]       | X8 = 0x2B90110;                         
            // 0x00E58CFC: LDR w0, [x8]               | W0 = 0x1708;                            
            // 0x00E58D00: BL #0x2782188              | X0 = sub_2782188( ?? 0x1708, ????);     
            // 0x00E58D04: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E58D08: STRB w8, [x20, #0xad7]     | static_value_03734AD7 = true;            //  dest_result_addr=57887447
            label_0:
            // 0x00E58D0C: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x00E58D10: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
            // 0x00E58D14: LDR x0, [x8]               | X0 = typeof(System.Text.StringBuilder); 
            System.Text.StringBuilder val_1 = null;
            // 0x00E58D18: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
            // 0x00E58D1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E58D20: MOV x20, x0                | X20 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E58D24: BL #0x1b5a30c              | .ctor();                                
            val_1 = new System.Text.StringBuilder();
            // 0x00E58D28: MOV x0, x19                | X0 = 1152921509466287040 (0x1000000121A52BC0);//ML01
            // 0x00E58D2C: BL #0xe58c00               | X0 = this.get_ReturnType();             
            ILRuntime.Mono.Cecil.TypeReference val_2 = this.ReturnType;
            // 0x00E58D30: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00E58D34: CBNZ x21, #0xe58d3c        | if (val_2 != null) goto label_1;        
            if(val_2 != null)
            {
                goto label_1;
            }
            // 0x00E58D38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_1:
            // 0x00E58D3C: LDR x8, [x21]              | X8 = typeof(ILRuntime.Mono.Cecil.TypeReference);
            // 0x00E58D40: MOV x0, x21                | X0 = val_2;//m1                         
            // 0x00E58D44: LDP x9, x1, [x8, #0x180]   | X9 = typeof(ILRuntime.Mono.Cecil.TypeReference).__il2cppRuntimeField_180; X1 = typeof(ILRuntime.Mono.Cecil.TypeReference).__il2cppRuntimeField_188; //  | 
            // 0x00E58D48: BLR x9                     | X0 = typeof(ILRuntime.Mono.Cecil.TypeReference).__il2cppRuntimeField_180();
            // 0x00E58D4C: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00E58D50: CBNZ x20, #0xe58d58        | if ( != 0) goto label_2;                
            if(null != 0)
            {
                goto label_2;
            }
            // 0x00E58D54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_2:
            // 0x00E58D58: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E58D5C: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E58D60: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x00E58D64: BL #0x1b5b818              | X0 = Append(value:  val_2);             
            System.Text.StringBuilder val_3 = Append(value:  val_2);
            // 0x00E58D68: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E58D6C: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x00E58D70: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E58D74: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E58D78: TBZ w8, #0, #0xe58d88      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00E58D7C: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E58D80: CBNZ w8, #0xe58d88         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00E58D84: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_4:
            // 0x00E58D88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E58D8C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E58D90: MOV x1, x19                | X1 = 1152921509466287040 (0x1000000121A52BC0);//ML01
            // 0x00E58D94: MOV x2, x20                | X2 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E58D98: BL #0x11d7c18              | ILRuntime.Mono.Cecil.Mixin.MethodSignatureFullName(self:  0, builder:  this);
            ILRuntime.Mono.Cecil.Mixin.MethodSignatureFullName(self:  0, builder:  this);
            // 0x00E58D9C: CBNZ x20, #0xe58da4        | if ( != 0) goto label_5;                
            if(null != 0)
            {
                goto label_5;
            }
            // 0x00E58DA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_5:
            // 0x00E58DA4: LDR x8, [x20]              | X8 = ;                                  
            // 0x00E58DA8: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E58DAC: LDP x2, x1, [x8, #0x140]   |                                          //  not_find_field!1:320 |  not_find_field!1:328
            // 0x00E58DB0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E58DB4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E58DB8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E58DBC: BR x2                      | goto mem[null + 320];                   
            goto mem[null + 320];
        
        }
        //
        // Offset in libil2cpp.so: 0x00E58DC0 (15044032), len: 156  VirtAddr: 0x00E58DC0 RVA: 0x00E58DC0 token: 100663758 methodIndex: 19357 delegateWrapperIndex: 0 methodInvoker: 0
        internal CallSite()
        {
            //
            // Disasemble & Code
            // 0x00E58DC0: STP x20, x19, [sp, #-0x20]! | stack[1152921509466395200] = ???;  stack[1152921509466395208] = ???;  //  dest_result_addr=1152921509466395200 |  dest_result_addr=1152921509466395208
            // 0x00E58DC4: STP x29, x30, [sp, #0x10]  | stack[1152921509466395216] = ???;  stack[1152921509466395224] = ???;  //  dest_result_addr=1152921509466395216 |  dest_result_addr=1152921509466395224
            // 0x00E58DC8: ADD x29, sp, #0x10         | X29 = (1152921509466395200 + 16) = 1152921509466395216 (0x1000000121A6D250);
            // 0x00E58DCC: SUB sp, sp, #0x10          | SP = (1152921509466395200 - 16) = 1152921509466395184 (0x1000000121A6D230);
            // 0x00E58DD0: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E58DD4: LDRB w8, [x20, #0xad8]     | W8 = (bool)static_value_03734AD8;       
            // 0x00E58DD8: MOV x19, x0                | X19 = 1152921509466407232 (0x1000000121A70140);//ML01
            // 0x00E58DDC: TBNZ w8, #0, #0xe58df8     | if (static_value_03734AD8 == true) goto label_0;
            // 0x00E58DE0: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x00E58DE4: LDR x8, [x8, #0xba0]       | X8 = 0x2B9010C;                         
            // 0x00E58DE8: LDR w0, [x8]               | W0 = 0x1707;                            
            // 0x00E58DEC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1707, ????);     
            // 0x00E58DF0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E58DF4: STRB w8, [x20, #0xad8]     | static_value_03734AD8 = true;            //  dest_result_addr=57887448
            label_0:
            // 0x00E58DF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E58DFC: MOV x0, x19                | X0 = 1152921509466407232 (0x1000000121A70140);//ML01
            // 0x00E58E00: BL #0x16f59f0              | this..ctor();                           
            // 0x00E58E04: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00E58E08: LDR x8, [x8, #0x708]       | X8 = 1152921504741244928;               
            // 0x00E58E0C: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.MethodReference);
            ILRuntime.Mono.Cecil.MethodReference val_1 = null;
            // 0x00E58E10: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Mono.Cecil.MethodReference), ????);
            // 0x00E58E14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E58E18: MOV x20, x0                | X20 = 1152921504741244928 (0x100000000802C000);//ML01
            // 0x00E58E1C: BL #0x11d7554              | .ctor();                                
            val_1 = new ILRuntime.Mono.Cecil.MethodReference();
            // 0x00E58E20: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00E58E24: ADD x0, sp, #8             | X0 = (1152921509466395184 + 8) = 1152921509466395192 (0x1000000121A6D238);
            // 0x00E58E28: MOVZ w1, #0x1100, lsl #16  | W1 = 285212672 (0x11000000);//ML01      
            // 0x00E58E2C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E58E30: STR x20, [x19, #0x10]      | this.signature = typeof(ILRuntime.Mono.Cecil.MethodReference);  //  dest_result_addr=1152921509466407248
            this.signature = val_1;
            // 0x00E58E34: STR wzr, [sp, #8]          | stack[1152921509466395192] = 0x0;        //  dest_result_addr=1152921509466395192
            // 0x00E58E38: BL #0x11d58ec              | null..ctor(type:  0, rid:  0);          
            ILRuntime.Mono.Cecil.MetadataToken val_2 = new ILRuntime.Mono.Cecil.MetadataToken(type:  0, rid:  0);
            // 0x00E58E3C: CBNZ x20, #0xe58e44        | if ( != 0) goto label_1;                
            if(null != 0)
            {
                goto label_1;
            }
            // 0x00E58E40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? null..ctor(type:  0, rid:  0), ????);
            label_1:
            // 0x00E58E44: LDR w8, [sp, #8]           | W8 = val_2.token;                       
            // 0x00E58E48: STR w8, [x20, #0x20]       | typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_20 = val_2.token;  //  dest_result_addr=1152921504741244960
            typeof(ILRuntime.Mono.Cecil.MethodReference).__il2cppRuntimeField_20 = val_2.token;
            // 0x00E58E4C: SUB sp, x29, #0x10         | SP = (1152921509466395216 - 16) = 1152921509466395200 (0x1000000121A6D240);
            // 0x00E58E50: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E58E54: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E58E58: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E58E5C (15044188), len: 4  VirtAddr: 0x00E58E5C RVA: 0x00E58E5C token: 100663759 methodIndex: 19358 delegateWrapperIndex: 0 methodInvoker: 0
        public override string ToString()
        {
            //
            // Disasemble & Code
            // 0x00E58E5C: B #0xe58cd4                | return this.get_FullName();             
            return this.FullName;
        
        }
    
    }

}
