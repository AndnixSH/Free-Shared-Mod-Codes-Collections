using UnityEngine;
public static class CfgProtobuf
{
    // Fields
    private static Pomelo.Protobuf.MsgDecoder decoder; // static_offset: 0x00000000
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00D81FCC (14163916), len: 116  VirtAddr: 0x00D81FCC RVA: 0x00D81FCC token: 100690771 methodIndex: 25960 delegateWrapperIndex: 0 methodInvoker: 0
    public static void InitDecoder(Newtonsoft.Json.Linq.JObject decodeProtos)
    {
        //
        // Disasemble & Code
        // 0x00D81FCC: STP x20, x19, [sp, #-0x20]! | stack[1152921514572705616] = ???;  stack[1152921514572705624] = ???;  //  dest_result_addr=1152921514572705616 |  dest_result_addr=1152921514572705624
        // 0x00D81FD0: STP x29, x30, [sp, #0x10]  | stack[1152921514572705632] = ???;  stack[1152921514572705640] = ???;  //  dest_result_addr=1152921514572705632 |  dest_result_addr=1152921514572705640
        // 0x00D81FD4: ADD x29, sp, #0x10         | X29 = (1152921514572705616 + 16) = 1152921514572705632 (0x100000025202EF60);
        // 0x00D81FD8: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D81FDC: LDRB w8, [x20, #0x428]     | W8 = (bool)static_value_03734428;       
        // 0x00D81FE0: MOV x19, x1                | X19 = X1;//m1                           
        // 0x00D81FE4: TBNZ w8, #0, #0xd82000     | if (static_value_03734428 == true) goto label_0;
        // 0x00D81FE8: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
        // 0x00D81FEC: LDR x8, [x8, #0x4c0]       | X8 = 0x2B90528;                         
        // 0x00D81FF0: LDR w0, [x8]               | W0 = 0x180E;                            
        // 0x00D81FF4: BL #0x2782188              | X0 = sub_2782188( ?? 0x180E, ????);     
        // 0x00D81FF8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D81FFC: STRB w8, [x20, #0x428]     | static_value_03734428 = true;            //  dest_result_addr=57885736
        label_0:
        // 0x00D82000: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
        // 0x00D82004: LDR x8, [x8, #0xd80]       | X8 = 1152921504913022976;               
        // 0x00D82008: LDR x0, [x8]               | X0 = typeof(Pomelo.Protobuf.MsgDecoder);
        Pomelo.Protobuf.MsgDecoder val_1 = null;
        // 0x00D8200C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pomelo.Protobuf.MsgDecoder), ????);
        // 0x00D82010: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82014: MOV x1, x19                | X1 = X1;//m1                            
        // 0x00D82018: MOV x20, x0                | X20 = 1152921504913022976 (0x10000000123FE000);//ML01
        // 0x00D8201C: BL #0xc6c5b4               | .ctor(protos:  X1);                     
        val_1 = new Pomelo.Protobuf.MsgDecoder(protos:  X1);
        // 0x00D82020: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
        // 0x00D82024: LDR x8, [x8, #0xb58]       | X8 = 1152921504891670528;               
        // 0x00D82028: LDR x8, [x8]               | X8 = typeof(CfgProtobuf);               
        // 0x00D8202C: LDR x8, [x8, #0xa0]        | X8 = CfgProtobuf.__il2cppRuntimeField_static_fields;
        // 0x00D82030: STR x20, [x8]              | CfgProtobuf.decoder = typeof(Pomelo.Protobuf.MsgDecoder);  //  dest_result_addr=1152921504891674624
        CfgProtobuf.decoder = val_1;
        // 0x00D82034: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D82038: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D8203C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D82040 (14164032), len: 120  VirtAddr: 0x00D82040 RVA: 0x00D82040 token: 100690772 methodIndex: 25961 delegateWrapperIndex: 0 methodInvoker: 0
    public static Newtonsoft.Json.Linq.JObject decode(string route, byte[] buffer)
    {
        //
        // Disasemble & Code
        // 0x00D82040: STP x22, x21, [sp, #-0x30]! | stack[1152921514572862656] = ???;  stack[1152921514572862664] = ???;  //  dest_result_addr=1152921514572862656 |  dest_result_addr=1152921514572862664
        // 0x00D82044: STP x20, x19, [sp, #0x10]  | stack[1152921514572862672] = ???;  stack[1152921514572862680] = ???;  //  dest_result_addr=1152921514572862672 |  dest_result_addr=1152921514572862680
        // 0x00D82048: STP x29, x30, [sp, #0x20]  | stack[1152921514572862688] = ???;  stack[1152921514572862696] = ???;  //  dest_result_addr=1152921514572862688 |  dest_result_addr=1152921514572862696
        // 0x00D8204C: ADD x29, sp, #0x20         | X29 = (1152921514572862656 + 32) = 1152921514572862688 (0x10000002520554E0);
        // 0x00D82050: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D82054: LDRB w8, [x21, #0x429]     | W8 = (bool)static_value_03734429;       
        // 0x00D82058: MOV x19, x2                | X19 = X2;//m1                           
        // 0x00D8205C: MOV x20, x1                | X20 = buffer;//m1                       
        // 0x00D82060: TBNZ w8, #0, #0xd8207c     | if (static_value_03734429 == true) goto label_0;
        // 0x00D82064: ADRP x8, #0x367e000        | X8 = 57139200 (0x367E000);              
        // 0x00D82068: LDR x8, [x8, #0x460]       | X8 = 0x2B90524;                         
        // 0x00D8206C: LDR w0, [x8]               | W0 = 0x180D;                            
        // 0x00D82070: BL #0x2782188              | X0 = sub_2782188( ?? 0x180D, ????);     
        // 0x00D82074: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D82078: STRB w8, [x21, #0x429]     | static_value_03734429 = true;            //  dest_result_addr=57885737
        label_0:
        // 0x00D8207C: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
        // 0x00D82080: LDR x8, [x8, #0xb58]       | X8 = 1152921504891670528;               
        // 0x00D82084: LDR x8, [x8]               | X8 = typeof(CfgProtobuf);               
        // 0x00D82088: LDR x8, [x8, #0xa0]        | X8 = CfgProtobuf.__il2cppRuntimeField_static_fields;
        // 0x00D8208C: LDR x21, [x8]              | X21 = CfgProtobuf.decoder;              
        // 0x00D82090: CBNZ x21, #0xd82098        | if (CfgProtobuf.decoder != null) goto label_1;
        if(CfgProtobuf.decoder != null)
        {
            goto label_1;
        }
        // 0x00D82094: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x180D, ????);     
        label_1:
        // 0x00D82098: MOV x1, x20                | X1 = buffer;//m1                        
        // 0x00D8209C: MOV x2, x19                | X2 = X2;//m1                            
        // 0x00D820A0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D820A4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D820A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D820AC: MOV x0, x21                | X0 = CfgProtobuf.decoder;//m1           
        // 0x00D820B0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D820B4: B #0xc6c928                | return CfgProtobuf.decoder.decode(route:  buffer, buf:  X2);
        return CfgProtobuf.decoder.decode(route:  buffer, buf:  X2);
    
    }

}
