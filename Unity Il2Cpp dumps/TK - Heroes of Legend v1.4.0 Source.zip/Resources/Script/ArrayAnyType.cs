using UnityEngine;

namespace wxb
{
    internal class ArrayAnyType : IListAnyType
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2B8A0 (14858400), len: 72  VirtAddr: 0x00E2B8A0 RVA: 0x00E2B8A0 token: 100681101 methodIndex: 57191 delegateWrapperIndex: 0 methodInvoker: 0
        public ArrayAnyType(System.Type arrayType)
        {
            //
            // Disasemble & Code
            // 0x00E2B8A0: STP x20, x19, [sp, #-0x20]! | stack[1152921513014800832] = ???;  stack[1152921513014800840] = ???;  //  dest_result_addr=1152921513014800832 |  dest_result_addr=1152921513014800840
            // 0x00E2B8A4: STP x29, x30, [sp, #0x10]  | stack[1152921513014800848] = ???;  stack[1152921513014800856] = ???;  //  dest_result_addr=1152921513014800848 |  dest_result_addr=1152921513014800856
            // 0x00E2B8A8: ADD x29, sp, #0x10         | X29 = (1152921513014800832 + 16) = 1152921513014800848 (0x10000001F52731D0);
            // 0x00E2B8AC: MOV x19, x1                | X19 = arrayType;//m1                    
            // 0x00E2B8B0: MOV x20, x0                | X20 = 1152921513014812864 (0x10000001F52760C0);//ML01
            // 0x00E2B8B4: CBNZ x19, #0xe2b8bc        | if (arrayType != null) goto label_0;    
            if(arrayType != null)
            {
                goto label_0;
            }
            // 0x00E2B8B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2B8BC: LDR x8, [x19]              | X8 = typeof(System.Type);               
            // 0x00E2B8C0: MOV x0, x19                | X0 = arrayType;//m1                     
            // 0x00E2B8C4: LDR x9, [x8, #0x410]       | X9 = typeof(System.Type).__il2cppRuntimeField_410;
            // 0x00E2B8C8: LDR x1, [x8, #0x418]       | X1 = typeof(System.Type).__il2cppRuntimeField_418;
            // 0x00E2B8CC: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_410();
            // 0x00E2B8D0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2B8D4: MOV x2, x0                 | X2 = arrayType;//m1                     
            // 0x00E2B8D8: MOV x0, x20                | X0 = 1152921513014812864 (0x10000001F52760C0);//ML01
            // 0x00E2B8DC: MOV x1, x19                | X1 = arrayType;//m1                     
            // 0x00E2B8E0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2B8E4: B #0xe2b8e8                | this..ctor(arrayType:  arrayType, elementType:  arrayType); return;
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2B97C (14858620), len: 28  VirtAddr: 0x00E2B97C RVA: 0x00E2B97C token: 100681102 methodIndex: 57192 delegateWrapperIndex: 0 methodInvoker: 0
        protected override System.Collections.IList Create(int lenght)
        {
            //
            // Disasemble & Code
            // 0x00E2B97C: LDR x8, [x0, #0x18]        | 
            // 0x00E2B980: MOV w9, w1                 | W9 = lenght;//m1                        
            // 0x00E2B984: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E2B988: MOV w2, w9                 | W2 = lenght;//m1                        
            // 0x00E2B98C: MOV x1, x8                 | X1 = X8;//m1                            
            // 0x00E2B990: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E2B994: B #0x18cd230               | return System.Array.CreateInstance(elementType:  0, length:  X8);
            return System.Array.CreateInstance(elementType:  0, length:  X8);
        
        }
    
    }

}
