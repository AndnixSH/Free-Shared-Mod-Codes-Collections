using UnityEngine;
internal class ActionUpdate : IZUpdate
{
    // Fields
    private static readonly ActionUpdate s_instance; // static_offset: 0x00000000
    private System.Action actions; //  0x00000010
    private static System.Action <>f__am$cache0; // static_offset: 0x00000008
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B1C140 (11649344), len: 300  VirtAddr: 0x00B1C140 RVA: 0x00B1C140 token: 100696476 methodIndex: 24663 delegateWrapperIndex: 0 methodInvoker: 0
    private ActionUpdate()
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        //  | 
        var val_3;
        // 0x00B1C140: STP x22, x21, [sp, #-0x30]! | stack[1152921515537240896] = ???;  stack[1152921515537240904] = ???;  //  dest_result_addr=1152921515537240896 |  dest_result_addr=1152921515537240904
        // 0x00B1C144: STP x20, x19, [sp, #0x10]  | stack[1152921515537240912] = ???;  stack[1152921515537240920] = ???;  //  dest_result_addr=1152921515537240912 |  dest_result_addr=1152921515537240920
        // 0x00B1C148: STP x29, x30, [sp, #0x20]  | stack[1152921515537240928] = ???;  stack[1152921515537240936] = ???;  //  dest_result_addr=1152921515537240928 |  dest_result_addr=1152921515537240936
        // 0x00B1C14C: ADD x29, sp, #0x20         | X29 = (1152921515537240896 + 32) = 1152921515537240928 (0x100000028B809360);
        // 0x00B1C150: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1C154: LDRB w8, [x20, #0x702]     | W8 = (bool)static_value_03733702;       
        // 0x00B1C158: MOV x19, x0                | X19 = 1152921515537252944 (0x100000028B80C250);//ML01
        // 0x00B1C15C: TBNZ w8, #0, #0xb1c178     | if (static_value_03733702 == true) goto label_0;
        // 0x00B1C160: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
        // 0x00B1C164: LDR x8, [x8, #0x298]       | X8 = 0x2B8A8E8;                         
        // 0x00B1C168: LDR w0, [x8]               | W0 = 0xF8;                              
        // 0x00B1C16C: BL #0x2782188              | X0 = sub_2782188( ?? 0xF8, ????);       
        // 0x00B1C170: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1C174: STRB w8, [x20, #0x702]     | static_value_03733702 = true;            //  dest_result_addr=57882370
        label_0:
        // 0x00B1C178: ADRP x22, #0x363d000       | X22 = 56872960 (0x363D000);             
        // 0x00B1C17C: LDR x22, [x22, #0x300]     | X22 = 1152921504921968640;              
        // 0x00B1C180: LDR x0, [x22]              | X0 = typeof(ActionUpdate);              
        val_2 = null;
        // 0x00B1C184: LDRB w8, [x0, #0x10a]      | W8 = ActionUpdate.__il2cppRuntimeField_10A;
        // 0x00B1C188: TBZ w8, #0, #0xb1c19c      | if (ActionUpdate.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B1C18C: LDR w8, [x0, #0xbc]        | W8 = ActionUpdate.__il2cppRuntimeField_cctor_finished;
        // 0x00B1C190: CBNZ w8, #0xb1c19c         | if (ActionUpdate.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B1C194: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ActionUpdate), ????);
        // 0x00B1C198: LDR x0, [x22]              | X0 = typeof(ActionUpdate);              
        val_2 = null;
        label_2:
        // 0x00B1C19C: LDR x8, [x0, #0xa0]        | X8 = ActionUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B1C1A0: LDR x8, [x8, #8]           | X8 = ActionUpdate.<>f__am$cache0;       
        // 0x00B1C1A4: CBNZ x8, #0xb1c200         | if (ActionUpdate.<>f__am$cache0 != null) goto label_3;
        if((ActionUpdate.<>f__am$cache0) != null)
        {
            goto label_3;
        }
        // 0x00B1C1A8: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
        // 0x00B1C1AC: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
        // 0x00B1C1B0: LDR x8, [x8, #0xac0]       | X8 = 1152921515537227920;               
        // 0x00B1C1B4: LDR x9, [x9, #0xbe0]       | X9 = 1152921504687837184;               
        // 0x00B1C1B8: LDR x21, [x8]              | X21 = static System.Void ActionUpdate::<actions>m__0();
        // 0x00B1C1BC: LDR x0, [x9]               | X0 = typeof(System.Action);             
        System.Action val_1 = null;
        // 0x00B1C1C0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00B1C1C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C1C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1C1CC: MOV x2, x21                | X2 = 1152921515537227920 (0x100000028B806090);//ML01
        // 0x00B1C1D0: MOV x20, x0                | X20 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B1C1D4: BL #0x26e30f0              | .ctor(object:  0, method:  static System.Void ActionUpdate::<actions>m__0());
        val_1 = new System.Action(object:  0, method:  static System.Void ActionUpdate::<actions>m__0());
        // 0x00B1C1D8: LDR x0, [x22]              | X0 = typeof(ActionUpdate);              
        val_3 = null;
        // 0x00B1C1DC: LDRB w8, [x0, #0x10a]      | W8 = ActionUpdate.__il2cppRuntimeField_10A;
        // 0x00B1C1E0: TBZ w8, #0, #0xb1c1f4      | if (ActionUpdate.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00B1C1E4: LDR w8, [x0, #0xbc]        | W8 = ActionUpdate.__il2cppRuntimeField_cctor_finished;
        // 0x00B1C1E8: CBNZ w8, #0xb1c1f4         | if (ActionUpdate.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00B1C1EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ActionUpdate), ????);
        // 0x00B1C1F0: LDR x0, [x22]              | X0 = typeof(ActionUpdate);              
        val_3 = null;
        label_5:
        // 0x00B1C1F4: LDR x8, [x0, #0xa0]        | X8 = ActionUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B1C1F8: STR x20, [x8, #8]          | ActionUpdate.<>f__am$cache0 = typeof(System.Action);  //  dest_result_addr=1152921504921972744
        ActionUpdate.<>f__am$cache0 = val_1;
        // 0x00B1C1FC: LDR x0, [x22]              | X0 = typeof(ActionUpdate);              
        val_2 = null;
        label_3:
        // 0x00B1C200: LDRB w8, [x0, #0x10a]      | W8 = ActionUpdate.__il2cppRuntimeField_10A;
        // 0x00B1C204: TBZ w8, #0, #0xb1c218      | if (ActionUpdate.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x00B1C208: LDR w8, [x0, #0xbc]        | W8 = ActionUpdate.__il2cppRuntimeField_cctor_finished;
        // 0x00B1C20C: CBNZ w8, #0xb1c218         | if (ActionUpdate.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x00B1C210: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ActionUpdate), ????);
        // 0x00B1C214: LDR x0, [x22]              | X0 = typeof(ActionUpdate);              
        val_2 = null;
        label_7:
        // 0x00B1C218: LDR x8, [x0, #0xa0]        | X8 = ActionUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B1C21C: LDR x20, [x8, #8]          | X20 = typeof(System.Action);            
        // 0x00B1C220: CBNZ x19, #0xb1c228        | if (this != null) goto label_8;         
        if(this != null)
        {
            goto label_8;
        }
        // 0x00B1C224: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ActionUpdate), ????);
        label_8:
        // 0x00B1C228: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C22C: MOV x0, x19                | X0 = 1152921515537252944 (0x100000028B80C250);//ML01
        // 0x00B1C230: STR x20, [x19, #0x10]      | this.actions = typeof(System.Action);    //  dest_result_addr=1152921515537252960
        this.actions = ActionUpdate.<>f__am$cache0;
        // 0x00B1C234: BL #0x16f59f0              | this..ctor();                           
        // 0x00B1C238: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
        // 0x00B1C23C: LDR x8, [x8, #0xf38]       | X8 = 1152921504922128384;               
        // 0x00B1C240: LDR x0, [x8]               | X0 = typeof(AllUpdate);                 
        // 0x00B1C244: LDRB w8, [x0, #0x10a]      | W8 = AllUpdate.__il2cppRuntimeField_10A;
        // 0x00B1C248: TBZ w8, #0, #0xb1c258      | if (AllUpdate.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x00B1C24C: LDR w8, [x0, #0xbc]        | W8 = AllUpdate.__il2cppRuntimeField_cctor_finished;
        // 0x00B1C250: CBNZ w8, #0xb1c258         | if (AllUpdate.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x00B1C254: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AllUpdate), ????);
        label_10:
        // 0x00B1C258: MOV x1, x19                | X1 = 1152921515537252944 (0x100000028B80C250);//ML01
        // 0x00B1C25C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1C260: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1C264: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B1C268: B #0xb14d7c                | AllUpdate.AddUpdate(update:  null); return;
        AllUpdate.AddUpdate(update:  null);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1C26C (11649644), len: 248  VirtAddr: 0x00B1C26C RVA: 0x00B1C26C token: 100696477 methodIndex: 24664 delegateWrapperIndex: 0 methodInvoker: 0
    public static void AddAction(System.Action action)
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        //  | 
        var val_3;
        //  | 
        System.Action val_4;
        // 0x00B1C26C: STP x20, x19, [sp, #-0x20]! | stack[1152921515537361104] = ???;  stack[1152921515537361112] = ???;  //  dest_result_addr=1152921515537361104 |  dest_result_addr=1152921515537361112
        // 0x00B1C270: STP x29, x30, [sp, #0x10]  | stack[1152921515537361120] = ???;  stack[1152921515537361128] = ???;  //  dest_result_addr=1152921515537361120 |  dest_result_addr=1152921515537361128
        // 0x00B1C274: ADD x29, sp, #0x10         | X29 = (1152921515537361104 + 16) = 1152921515537361120 (0x100000028B8268E0);
        // 0x00B1C278: SUB sp, sp, #0x10          | SP = (1152921515537361104 - 16) = 1152921515537361088 (0x100000028B8268C0);
        // 0x00B1C27C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1C280: LDRB w8, [x20, #0x703]     | W8 = (bool)static_value_03733703;       
        // 0x00B1C284: MOV x19, x1                | X19 = X1;//m1                           
        // 0x00B1C288: TBNZ w8, #0, #0xb1c2a4     | if (static_value_03733703 == true) goto label_0;
        // 0x00B1C28C: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
        // 0x00B1C290: LDR x8, [x8, #0xc40]       | X8 = 0x2B8A8EC;                         
        // 0x00B1C294: LDR w0, [x8]               | W0 = 0xF9;                              
        // 0x00B1C298: BL #0x2782188              | X0 = sub_2782188( ?? 0xF9, ????);       
        // 0x00B1C29C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1C2A0: STRB w8, [x20, #0x703]     | static_value_03733703 = true;            //  dest_result_addr=57882371
        label_0:
        // 0x00B1C2A4: ADRP x20, #0x363d000       | X20 = 56872960 (0x363D000);             
        // 0x00B1C2A8: LDR x20, [x20, #0x300]     | X20 = 1152921504921968640;              
        // 0x00B1C2AC: LDR x0, [x20]              | X0 = typeof(ActionUpdate);              
        val_3 = null;
        // 0x00B1C2B0: LDRB w8, [x0, #0x10a]      | W8 = ActionUpdate.__il2cppRuntimeField_10A;
        // 0x00B1C2B4: TBZ w8, #0, #0xb1c2c8      | if (ActionUpdate.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B1C2B8: LDR w8, [x0, #0xbc]        | W8 = ActionUpdate.__il2cppRuntimeField_cctor_finished;
        // 0x00B1C2BC: CBNZ w8, #0xb1c2c8         | if (ActionUpdate.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B1C2C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ActionUpdate), ????);
        // 0x00B1C2C4: LDR x0, [x20]              | X0 = typeof(ActionUpdate);              
        val_3 = null;
        label_2:
        // 0x00B1C2C8: LDR x8, [x0, #0xa0]        | X8 = ActionUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B1C2CC: LDR x20, [x8]              | X20 = ActionUpdate.s_instance;          
        // 0x00B1C2D0: CBNZ x20, #0xb1c2d8        | if (ActionUpdate.s_instance != null) goto label_3;
        if(ActionUpdate.s_instance != null)
        {
            goto label_3;
        }
        // 0x00B1C2D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ActionUpdate), ????);
        label_3:
        // 0x00B1C2D8: LDR x1, [x20, #0x10]       | X1 = ActionUpdate.s_instance.actions;   
        // 0x00B1C2DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1C2E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1C2E4: MOV x2, x19                | X2 = X1;//m1                            
        // 0x00B1C2E8: BL #0x1c34bb4              | X0 = System.Delegate.Combine(a:  0, b:  ActionUpdate.s_instance.actions);
        System.Delegate val_1 = System.Delegate.Combine(a:  0, b:  ActionUpdate.s_instance.actions);
        // 0x00B1C2EC: MOV x19, x0                | X19 = val_1;//m1                        
        val_4 = val_1;
        // 0x00B1C2F0: CBNZ x20, #0xb1c2f8        | if (ActionUpdate.s_instance != null) goto label_4;
        if(ActionUpdate.s_instance != null)
        {
            goto label_4;
        }
        // 0x00B1C2F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B1C2F8: CBZ x19, #0xb1c338         | if (val_1 == null) goto label_5;        
        if(val_4 == null)
        {
            goto label_5;
        }
        // 0x00B1C2FC: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
        // 0x00B1C300: LDR x8, [x8, #0xbe0]       | X8 = 1152921504687837184;               
        // 0x00B1C304: LDR x1, [x8]               | X1 = typeof(System.Action);             
        // 0x00B1C308: LDR x8, [x19]              | X8 = typeof(System.Delegate);           
        // 0x00B1C30C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Delegate), typeof(System.Action))
        // 0x00B1C310: B.EQ #0xb1c33c             | if (typeof(System.Delegate) == null) goto label_6;
        if(null == null)
        {
            goto label_6;
        }
        // 0x00B1C314: LDR x0, [x8, #0x30]        | X0 = System.Delegate.__il2cppRuntimeField_element_class;
        // 0x00B1C318: ADD x8, sp, #8             | X8 = (1152921515537361088 + 8) = 1152921515537361096 (0x100000028B8268C8);
        // 0x00B1C31C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Delegate.__il2cppRuntimeField_element_class, ????);
        // 0x00B1C320: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921515537349136]
        // 0x00B1C324: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
        // 0x00B1C328: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C32C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        // 0x00B1C330: ADD x0, sp, #8             | X0 = (1152921515537361088 + 8) = 1152921515537361096 (0x100000028B8268C8);
        // 0x00B1C334: BL #0x299a140              | 
        label_5:
        // 0x00B1C338: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
        val_4 = 0;
        label_6:
        // 0x00B1C33C: STR x19, [x20, #0x10]      | ActionUpdate.s_instance.actions = null;  //  dest_result_addr=0
        ActionUpdate.s_instance.actions = val_4;
        // 0x00B1C340: SUB sp, x29, #0x10         | SP = (1152921515537361120 - 16) = 1152921515537361104 (0x100000028B8268D0);
        // 0x00B1C344: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1C348: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B1C34C: RET                        |  return;                                
        return;
        // 0x00B1C350: MOV x19, x0                | 
        // 0x00B1C354: ADD x0, sp, #8             | 
        // 0x00B1C358: BL #0x299a140              | 
        // 0x00B1C35C: MOV x0, x19                | 
        // 0x00B1C360: BL #0x980800               | 
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1C364 (11649892), len: 248  VirtAddr: 0x00B1C364 RVA: 0x00B1C364 token: 100696478 methodIndex: 24665 delegateWrapperIndex: 0 methodInvoker: 0
    public static void RemoveAction(System.Action action)
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        //  | 
        var val_3;
        //  | 
        System.Action val_4;
        // 0x00B1C364: STP x20, x19, [sp, #-0x20]! | stack[1152921515537489488] = ???;  stack[1152921515537489496] = ???;  //  dest_result_addr=1152921515537489488 |  dest_result_addr=1152921515537489496
        // 0x00B1C368: STP x29, x30, [sp, #0x10]  | stack[1152921515537489504] = ???;  stack[1152921515537489512] = ???;  //  dest_result_addr=1152921515537489504 |  dest_result_addr=1152921515537489512
        // 0x00B1C36C: ADD x29, sp, #0x10         | X29 = (1152921515537489488 + 16) = 1152921515537489504 (0x100000028B845E60);
        // 0x00B1C370: SUB sp, sp, #0x10          | SP = (1152921515537489488 - 16) = 1152921515537489472 (0x100000028B845E40);
        // 0x00B1C374: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1C378: LDRB w8, [x20, #0x704]     | W8 = (bool)static_value_03733704;       
        // 0x00B1C37C: MOV x19, x1                | X19 = X1;//m1                           
        // 0x00B1C380: TBNZ w8, #0, #0xb1c39c     | if (static_value_03733704 == true) goto label_0;
        // 0x00B1C384: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
        // 0x00B1C388: LDR x8, [x8, #0xe20]       | X8 = 0x2B8A8F0;                         
        // 0x00B1C38C: LDR w0, [x8]               | W0 = 0xFA;                              
        // 0x00B1C390: BL #0x2782188              | X0 = sub_2782188( ?? 0xFA, ????);       
        // 0x00B1C394: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1C398: STRB w8, [x20, #0x704]     | static_value_03733704 = true;            //  dest_result_addr=57882372
        label_0:
        // 0x00B1C39C: ADRP x20, #0x363d000       | X20 = 56872960 (0x363D000);             
        // 0x00B1C3A0: LDR x20, [x20, #0x300]     | X20 = 1152921504921968640;              
        // 0x00B1C3A4: LDR x0, [x20]              | X0 = typeof(ActionUpdate);              
        val_3 = null;
        // 0x00B1C3A8: LDRB w8, [x0, #0x10a]      | W8 = ActionUpdate.__il2cppRuntimeField_10A;
        // 0x00B1C3AC: TBZ w8, #0, #0xb1c3c0      | if (ActionUpdate.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B1C3B0: LDR w8, [x0, #0xbc]        | W8 = ActionUpdate.__il2cppRuntimeField_cctor_finished;
        // 0x00B1C3B4: CBNZ w8, #0xb1c3c0         | if (ActionUpdate.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B1C3B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ActionUpdate), ????);
        // 0x00B1C3BC: LDR x0, [x20]              | X0 = typeof(ActionUpdate);              
        val_3 = null;
        label_2:
        // 0x00B1C3C0: LDR x8, [x0, #0xa0]        | X8 = ActionUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B1C3C4: LDR x20, [x8]              | X20 = ActionUpdate.s_instance;          
        // 0x00B1C3C8: CBNZ x20, #0xb1c3d0        | if (ActionUpdate.s_instance != null) goto label_3;
        if(ActionUpdate.s_instance != null)
        {
            goto label_3;
        }
        // 0x00B1C3CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ActionUpdate), ????);
        label_3:
        // 0x00B1C3D0: LDR x1, [x20, #0x10]       | X1 = ActionUpdate.s_instance.actions;   
        // 0x00B1C3D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1C3D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1C3DC: MOV x2, x19                | X2 = X1;//m1                            
        // 0x00B1C3E0: BL #0x1c34dc4              | X0 = System.Delegate.Remove(source:  0, value:  ActionUpdate.s_instance.actions);
        System.Delegate val_1 = System.Delegate.Remove(source:  0, value:  ActionUpdate.s_instance.actions);
        // 0x00B1C3E4: MOV x19, x0                | X19 = val_1;//m1                        
        val_4 = val_1;
        // 0x00B1C3E8: CBNZ x20, #0xb1c3f0        | if (ActionUpdate.s_instance != null) goto label_4;
        if(ActionUpdate.s_instance != null)
        {
            goto label_4;
        }
        // 0x00B1C3EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B1C3F0: CBZ x19, #0xb1c430         | if (val_1 == null) goto label_5;        
        if(val_4 == null)
        {
            goto label_5;
        }
        // 0x00B1C3F4: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
        // 0x00B1C3F8: LDR x8, [x8, #0xbe0]       | X8 = 1152921504687837184;               
        // 0x00B1C3FC: LDR x1, [x8]               | X1 = typeof(System.Action);             
        // 0x00B1C400: LDR x8, [x19]              | X8 = typeof(System.Delegate);           
        // 0x00B1C404: CMP x8, x1                 | STATE = COMPARE(typeof(System.Delegate), typeof(System.Action))
        // 0x00B1C408: B.EQ #0xb1c434             | if (typeof(System.Delegate) == null) goto label_6;
        if(null == null)
        {
            goto label_6;
        }
        // 0x00B1C40C: LDR x0, [x8, #0x30]        | X0 = System.Delegate.__il2cppRuntimeField_element_class;
        // 0x00B1C410: ADD x8, sp, #8             | X8 = (1152921515537489472 + 8) = 1152921515537489480 (0x100000028B845E48);
        // 0x00B1C414: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Delegate.__il2cppRuntimeField_element_class, ????);
        // 0x00B1C418: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921515537477520]
        // 0x00B1C41C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
        // 0x00B1C420: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C424: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        // 0x00B1C428: ADD x0, sp, #8             | X0 = (1152921515537489472 + 8) = 1152921515537489480 (0x100000028B845E48);
        // 0x00B1C42C: BL #0x299a140              | 
        label_5:
        // 0x00B1C430: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
        val_4 = 0;
        label_6:
        // 0x00B1C434: STR x19, [x20, #0x10]      | ActionUpdate.s_instance.actions = null;  //  dest_result_addr=0
        ActionUpdate.s_instance.actions = val_4;
        // 0x00B1C438: SUB sp, x29, #0x10         | SP = (1152921515537489504 - 16) = 1152921515537489488 (0x100000028B845E50);
        // 0x00B1C43C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1C440: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B1C444: RET                        |  return;                                
        return;
        // 0x00B1C448: MOV x19, x0                | 
        // 0x00B1C44C: ADD x0, sp, #8             | 
        // 0x00B1C450: BL #0x299a140              | 
        // 0x00B1C454: MOV x0, x19                | 
        // 0x00B1C458: BL #0x980800               | 
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1C45C (11650140), len: 44  VirtAddr: 0x00B1C45C RVA: 0x00B1C45C token: 100696479 methodIndex: 24666 delegateWrapperIndex: 0 methodInvoker: 0
    private void IZUpdate.ZUpdate()
    {
        //
        // Disasemble & Code
        // 0x00B1C45C: STP x20, x19, [sp, #-0x20]! | stack[1152921515537613776] = ???;  stack[1152921515537613784] = ???;  //  dest_result_addr=1152921515537613776 |  dest_result_addr=1152921515537613784
        // 0x00B1C460: STP x29, x30, [sp, #0x10]  | stack[1152921515537613792] = ???;  stack[1152921515537613800] = ???;  //  dest_result_addr=1152921515537613792 |  dest_result_addr=1152921515537613800
        // 0x00B1C464: ADD x29, sp, #0x10         | X29 = (1152921515537613776 + 16) = 1152921515537613792 (0x100000028B8643E0);
        // 0x00B1C468: LDR x19, [x0, #0x10]       | X19 = this.actions; //P2                
        // 0x00B1C46C: CBNZ x19, #0xb1c474        | if (this.actions != null) goto label_0; 
        if(this.actions != null)
        {
            goto label_0;
        }
        // 0x00B1C470: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00B1C474: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1C478: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C47C: MOV x0, x19                | X0 = this.actions;//m1                  
        // 0x00B1C480: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B1C484: B #0x26e3100               | this.actions.Invoke(); return;          
        this.actions.Invoke();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1C488 (11650184), len: 96  VirtAddr: 0x00B1C488 RVA: 0x00B1C488 token: 100696480 methodIndex: 24667 delegateWrapperIndex: 0 methodInvoker: 0
    private static ActionUpdate()
    {
        //
        // Disasemble & Code
        // 0x00B1C488: STP x20, x19, [sp, #-0x20]! | stack[1152921515537729872] = ???;  stack[1152921515537729880] = ???;  //  dest_result_addr=1152921515537729872 |  dest_result_addr=1152921515537729880
        // 0x00B1C48C: STP x29, x30, [sp, #0x10]  | stack[1152921515537729888] = ???;  stack[1152921515537729896] = ???;  //  dest_result_addr=1152921515537729888 |  dest_result_addr=1152921515537729896
        // 0x00B1C490: ADD x29, sp, #0x10         | X29 = (1152921515537729872 + 16) = 1152921515537729888 (0x100000028B880960);
        // 0x00B1C494: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B1C498: LDRB w8, [x19, #0x705]     | W8 = (bool)static_value_03733705;       
        // 0x00B1C49C: TBNZ w8, #0, #0xb1c4b8     | if (static_value_03733705 == true) goto label_0;
        // 0x00B1C4A0: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
        // 0x00B1C4A4: LDR x8, [x8, #0x1d8]       | X8 = 0x2B8A8E4;                         
        // 0x00B1C4A8: LDR w0, [x8]               | W0 = 0xF7;                              
        // 0x00B1C4AC: BL #0x2782188              | X0 = sub_2782188( ?? 0xF7, ????);       
        // 0x00B1C4B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1C4B4: STRB w8, [x19, #0x705]     | static_value_03733705 = true;            //  dest_result_addr=57882373
        label_0:
        // 0x00B1C4B8: ADRP x20, #0x363d000       | X20 = 56872960 (0x363D000);             
        // 0x00B1C4BC: LDR x20, [x20, #0x300]     | X20 = 1152921504921968640;              
        // 0x00B1C4C0: LDR x0, [x20]              | X0 = typeof(ActionUpdate);              
        ActionUpdate val_1 = null;
        // 0x00B1C4C4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ActionUpdate), ????);
        // 0x00B1C4C8: MOV x19, x0                | X19 = 1152921504921968640 (0x1000000012C86000);//ML01
        // 0x00B1C4CC: BL #0xb1c140               | .ctor();                                
        val_1 = new ActionUpdate();
        // 0x00B1C4D0: LDR x8, [x20]              | X8 = typeof(ActionUpdate);              
        // 0x00B1C4D4: LDR x8, [x8, #0xa0]        | X8 = ActionUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B1C4D8: STR x19, [x8]              | ActionUpdate.s_instance = typeof(ActionUpdate);  //  dest_result_addr=1152921504921972736
        ActionUpdate.s_instance = val_1;
        // 0x00B1C4DC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1C4E0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B1C4E4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1C4E8 (11650280), len: 4  VirtAddr: 0x00B1C4E8 RVA: 0x00B1C4E8 token: 100696481 methodIndex: 24668 delegateWrapperIndex: 0 methodInvoker: 0
    private static void <actions>m__0()
    {
        //
        // Disasemble & Code
        // 0x00B1C4E8: RET                        |  return;                                
        return;
    
    }

}
