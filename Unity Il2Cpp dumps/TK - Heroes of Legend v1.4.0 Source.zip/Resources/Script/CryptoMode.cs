using UnityEngine;

namespace Pathfinding.Ionic.Zip
{
    internal enum CryptoMode
    {
        // Fields
        Encrypt = 0
        ,Decrypt = 1
        
    
    }

}
