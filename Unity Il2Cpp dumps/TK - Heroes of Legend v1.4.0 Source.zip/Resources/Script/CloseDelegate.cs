using UnityEngine;

namespace Pathfinding.Ionic.Zip
{
    public sealed class CloseDelegate : MulticastDelegate
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x01970394 (26674068), len: 16  VirtAddr: 0x01970394 RVA: 0x01970394 token: 100663305 methodIndex: 20859 delegateWrapperIndex: 0 methodInvoker: 0
        public CloseDelegate(object object, IntPtr method)
        {
            //
            // Disasemble & Code
            // 0x01970394: LDR x8, [x2]               | X8 = method;                            
            // 0x01970398: STP x1, x2, [x0, #0x20]    | mem[1152921509624816080] = object;  mem[1152921509624816088] = method;  //  dest_result_addr=1152921509624816080 |  dest_result_addr=1152921509624816088
            mem[1152921509624816080] = object;
            mem[1152921509624816088] = method;
            // 0x0197039C: STR x8, [x0, #0x10]        | mem[1152921509624816064] = method;       //  dest_result_addr=1152921509624816064
            mem[1152921509624816064] = method;
            // 0x019703A0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x019703A4 (26674084), len: 968  VirtAddr: 0x019703A4 RVA: 0x019703A4 token: 100663306 methodIndex: 20860 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual void Invoke(string entryName, System.IO.Stream stream)
        {
            //
            // Disasemble & Code
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            label_1:
            // 0x019703A4: STP x24, x23, [sp, #-0x40]! | stack[1152921509624944656] = ???;  stack[1152921509624944664] = ???;  //  dest_result_addr=1152921509624944656 |  dest_result_addr=1152921509624944664
            // 0x019703A8: STP x22, x21, [sp, #0x10]  | stack[1152921509624944672] = ???;  stack[1152921509624944680] = ???;  //  dest_result_addr=1152921509624944672 |  dest_result_addr=1152921509624944680
            // 0x019703AC: STP x20, x19, [sp, #0x20]  | stack[1152921509624944688] = ???;  stack[1152921509624944696] = ???;  //  dest_result_addr=1152921509624944688 |  dest_result_addr=1152921509624944696
            // 0x019703B0: STP x29, x30, [sp, #0x30]  | stack[1152921509624944704] = ???;  stack[1152921509624944712] = ???;  //  dest_result_addr=1152921509624944704 |  dest_result_addr=1152921509624944712
            // 0x019703B4: ADD x29, sp, #0x30         | X29 = (1152921509624944656 + 48) = 1152921509624944704 (0x100000012B1A1840);
            // 0x019703B8: SUB sp, sp, #0x10          | SP = (1152921509624944656 - 16) = 1152921509624944640 (0x100000012B1A1800);
            // 0x019703BC: MOV x23, x0                | X23 = 1152921509624956720 (0x100000012B1A4730);//ML01
            // 0x019703C0: LDR x0, [x23, #0x58]       | 
            // 0x019703C4: MOV x19, x2                | X19 = stream;//m1                       
            // 0x019703C8: MOV x20, x1                | X20 = entryName;//m1                    
            // 0x019703CC: CBZ x0, #0x19703dc         | if (this == null) goto label_0;         
            if(this == null)
            {
                goto label_0;
            }
            // 0x019703D0: MOV x1, x20                | X1 = entryName;//m1                     
            // 0x019703D4: MOV x2, x19                | X2 = stream;//m1                        
            val_13 = stream;
            // 0x019703D8: BL #0x19703a4              |  R0 = label_1();                        
            label_0:
            // 0x019703DC: LDR x0, [x23, #0x10]       | 
            // 0x019703E0: STR x0, [sp, #8]           | stack[1152921509624944648] = this;       //  dest_result_addr=1152921509624944648
            // 0x019703E4: LDP x22, x21, [x23, #0x20] |                                          //  | 
            // 0x019703E8: MOV x0, x21                | X0 = X21;//m1                           
            // 0x019703EC: BL #0x2796f94              | X0 = sub_2796F94( ?? X21, ????);        
            // 0x019703F0: MOV x0, x21                | X0 = X21;//m1                           
            // 0x019703F4: BL #0x27c09a4              | X0 = sub_27C09A4( ?? X21, ????);        
            // 0x019703F8: LDRB w9, [x21, #0x4e]      | W9 = X21 + 78;                          
            // 0x019703FC: AND w8, w0, #1             | W8 = (X21 & 1);                         
            var val_1 = X21 & 1;
            // 0x01970400: TBZ w8, #0, #0x197049c     | if (((X21 & 1) & 0x1) == 0) goto label_2;
            if((val_1 & 1) == 0)
            {
                goto label_2;
            }
            // 0x01970404: LDRH w8, [x21, #0x4c]      | W8 = X21 + 76;                          
            // 0x01970408: CMP w9, #2                 | STATE = COMPARE(X21 + 78, 0x2)          
            // 0x0197040C: B.NE #0x19704ac            | if (X21 + 78 != 0x2) goto label_3;      
            if((X21 + 78) != 2)
            {
                goto label_3;
            }
            // 0x01970410: ORR w9, wzr, #0xffff       | W9 = 65535(0xFFFF);                     
            // 0x01970414: CMP w8, w9                 | STATE = COMPARE(X21 + 76, 0xFFFF)       
            // 0x01970418: B.EQ #0x1970568            | if (X21 + 76 == 65535) goto label_7;    
            if((X21 + 76) == 65535)
            {
                goto label_7;
            }
            // 0x0197041C: CBZ x22, #0x197042c        | if (X22 == 0) goto label_5;             
            if(X22 == 0)
            {
                goto label_5;
            }
            // 0x01970420: LDR x8, [x22]              | X8 = X22;                               
            // 0x01970424: LDRB w8, [x8, #0xed]       | W8 = X22 + 237;                         
            // 0x01970428: TBNZ w8, #0, #0x1970568    | if ((X22 + 237 & 0x1) != 0) goto label_7;
            if(((X22 + 237) & 1) != 0)
            {
                goto label_7;
            }
            label_5:
            // 0x0197042C: LDR x8, [x23, #0x18]       | 
            // 0x01970430: CBZ x8, #0x1970568         | if (X22 + 237 == 0) goto label_7;       
            if((X22 + 237) == 0)
            {
                goto label_7;
            }
            // 0x01970434: MOV x0, x21                | X0 = X21;//m1                           
            // 0x01970438: BL #0x27c0990              | X0 = sub_27C0990( ?? X21, ????);        
            // 0x0197043C: MOV w23, w0                | W23 = X21;//m1                          
            // 0x01970440: MOV x0, x21                | X0 = X21;//m1                           
            // 0x01970444: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
            UnityEngine.Sprite val_2 = X21.pressedSprite;
            // 0x01970448: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_2, ????);      
            // 0x0197044C: TBZ w23, #0, #0x19705bc    | if ((X21 & 0x1) == 0) goto label_8;     
            if((X21 & 1) == 0)
            {
                goto label_8;
            }
            // 0x01970450: TBZ w0, #0, #0x1970674     | if ((val_2 & 0x1) == 0) goto label_9;   
            if((val_2 & 1) == 0)
            {
                goto label_9;
            }
            // 0x01970454: LDR x8, [x22]              | X8 = X22;                               
            var val_19 = X22;
            // 0x01970458: LDR x1, [x21, #0x18]       | X1 = X21 + 24;                          
            // 0x0197045C: LDRH w2, [x21, #0x4c]      | W2 = X21 + 76;                          
            // 0x01970460: LDRH w9, [x8, #0x102]      | W9 = X22 + 258;                         
            // 0x01970464: CBZ x9, #0x1970490         | if (X22 + 258 == 0) goto label_10;      
            if((X22 + 258) == 0)
            {
                goto label_10;
            }
            // 0x01970468: LDR x10, [x8, #0x98]       | X10 = X22 + 152;                        
            var val_11 = X22 + 152;
            // 0x0197046C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_12 = 0;
            // 0x01970470: ADD x10, x10, #8           | X10 = (X22 + 152 + 8);                  
            val_11 = val_11 + 8;
            label_12:
            // 0x01970474: LDUR x12, [x10, #-8]       | X12 = (X22 + 152 + 8) + -8;             
            // 0x01970478: CMP x12, x1                | STATE = COMPARE((X22 + 152 + 8) + -8, X21 + 24)
            // 0x0197047C: B.EQ #0x19706bc            | if ((X22 + 152 + 8) + -8 == X21 + 24) goto label_11;
            if(((X22 + 152 + 8) + -8) == (X21 + 24))
            {
                goto label_11;
            }
            // 0x01970480: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_12 = val_12 + 1;
            // 0x01970484: ADD x10, x10, #0x10        | X10 = ((X22 + 152 + 8) + 16);           
            val_11 = val_11 + 16;
            // 0x01970488: CMP x11, x9                | STATE = COMPARE((0 + 1), X22 + 258)     
            // 0x0197048C: B.LO #0x1970474            | if (0 < X22 + 258) goto label_12;       
            if(val_12 < (X22 + 258))
            {
                goto label_12;
            }
            label_10:
            // 0x01970490: MOV x0, x22                | X0 = X22;//m1                           
            val_14 = X22;
            // 0x01970494: BL #0x2776c24              | X0 = sub_2776C24( ?? X22, ????);        
            // 0x01970498: B #0x19706cc               |  goto label_13;                         
            goto label_13;
            label_2:
            // 0x0197049C: CMP w9, #2                 | STATE = COMPARE(X21 + 78, 0x2)          
            // 0x019704A0: B.NE #0x1970538            | if (X21 + 78 != 0x2) goto label_14;     
            if((X21 + 78) != 2)
            {
                goto label_14;
            }
            // 0x019704A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x019704A8: B #0x197056c               |  goto label_15;                         
            goto label_15;
            label_3:
            // 0x019704AC: ORR w9, wzr, #0xffff       | W9 = 65535(0xFFFF);                     
            // 0x019704B0: CMP w8, w9                 | STATE = COMPARE(X21 + 76, 0xFFFF)       
            // 0x019704B4: B.EQ #0x1970594            | if (X21 + 76 == 65535) goto label_19;   
            if((X21 + 76) == 65535)
            {
                goto label_19;
            }
            // 0x019704B8: CBZ x22, #0x19704c8        | if (X22 == 0) goto label_17;            
            if(X22 == 0)
            {
                goto label_17;
            }
            // 0x019704BC: LDR x8, [x22]              | X8 = X22;                               
            // 0x019704C0: LDRB w8, [x8, #0xed]       | W8 = X22 + 237;                         
            // 0x019704C4: TBNZ w8, #0, #0x1970594    | if ((X22 + 237 & 0x1) != 0) goto label_19;
            if(((X22 + 237) & 1) != 0)
            {
                goto label_19;
            }
            label_17:
            // 0x019704C8: LDR x8, [x23, #0x18]       | 
            // 0x019704CC: CBZ x8, #0x1970594         | if (X22 + 237 == 0) goto label_19;      
            if((X22 + 237) == 0)
            {
                goto label_19;
            }
            // 0x019704D0: MOV x0, x21                | X0 = X21;//m1                           
            // 0x019704D4: BL #0x27c0990              | X0 = sub_27C0990( ?? X21, ????);        
            // 0x019704D8: MOV w22, w0                | W22 = X21;//m1                          
            // 0x019704DC: MOV x0, x21                | X0 = X21;//m1                           
            // 0x019704E0: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
            UnityEngine.Sprite val_3 = X21.pressedSprite;
            // 0x019704E4: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_3, ????);      
            // 0x019704E8: TBZ w22, #0, #0x1970618    | if ((X21 & 0x1) == 0) goto label_20;    
            if((X21 & 1) == 0)
            {
                goto label_20;
            }
            // 0x019704EC: TBZ w0, #0, #0x1970688     | if ((val_3 & 0x1) == 0) goto label_21;  
            if((val_3 & 1) == 0)
            {
                goto label_21;
            }
            // 0x019704F0: LDR x8, [x20]              | X8 = typeof(System.String);             
            // 0x019704F4: LDR x1, [x21, #0x18]       | X1 = X21 + 24;                          
            // 0x019704F8: LDRH w2, [x21, #0x4c]      | W2 = X21 + 76;                          
            // 0x019704FC: LDRH w9, [x8, #0x102]      | W9 = System.String.__il2cppRuntimeField_interface_offsets_count;
            // 0x01970500: CBZ x9, #0x197052c         | if (System.String.__il2cppRuntimeField_interface_offsets_count == 0) goto label_22;
            // 0x01970504: LDR x10, [x8, #0x98]       | X10 = System.String.__il2cppRuntimeField_interfaceOffsets;
            // 0x01970508: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_13 = 0;
            // 0x0197050C: ADD x10, x10, #8           | X10 = (System.String.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608321544 (0x1000000000168008);
            label_24:
            // 0x01970510: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x01970514: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X21 + 24)
            // 0x01970518: B.EQ #0x19706f4            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X21 + 24) goto label_23;
            // 0x0197051C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_13 = val_13 + 1;
            // 0x01970520: ADD x10, x10, #0x10        | X10 = (1152921504608321544 + 16) = 1152921504608321560 (0x1000000000168018);
            // 0x01970524: CMP x11, x9                | STATE = COMPARE((0 + 1), System.String.__il2cppRuntimeField_interface_offsets_count)
            // 0x01970528: B.LO #0x1970510            | if (0 < System.String.__il2cppRuntimeField_interface_offsets_count) goto label_24;
            label_22:
            // 0x0197052C: MOV x0, x20                | X0 = entryName;//m1                     
            val_15 = entryName;
            // 0x01970530: BL #0x2776c24              | X0 = sub_2776C24( ?? entryName, ????);  
            // 0x01970534: B #0x1970704               |  goto label_25;                         
            goto label_25;
            label_14:
            // 0x01970538: LDR x5, [sp, #8]           | X5 = this;                              
            // 0x0197053C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01970540: MOV x1, x22                | X1 = X22;//m1                           
            // 0x01970544: MOV x2, x20                | X2 = entryName;//m1                     
            // 0x01970548: MOV x3, x19                | X3 = stream;//m1                        
            // 0x0197054C: MOV x4, x21                | X4 = X21;//m1                           
            // 0x01970550: SUB sp, x29, #0x30         | SP = (1152921509624944704 - 48) = 1152921509624944656 (0x100000012B1A1810);
            // 0x01970554: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01970558: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0197055C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01970560: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01970564: BR x5                      | X0 = this( ?? 0x0, ????);               
            label_7:
            // 0x01970568: MOV x0, x22                | X0 = X22;//m1                           
            label_15:
            // 0x0197056C: LDR x4, [sp, #8]           | X4 = this;                              
            // 0x01970570: MOV x1, x20                | X1 = entryName;//m1                     
            // 0x01970574: MOV x2, x19                | X2 = stream;//m1                        
            // 0x01970578: MOV x3, x21                | X3 = X21;//m1                           
            label_42:
            // 0x0197057C: SUB sp, x29, #0x30         | SP = (1152921509624944704 - 48) = 1152921509624944656 (0x100000012B1A1810);
            // 0x01970580: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01970584: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01970588: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0197058C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01970590: BR x4                      | X0 = this( ?? X22, ????);               
            label_19:
            // 0x01970594: LDR x3, [sp, #8]           | X3 = this;                              
            // 0x01970598: MOV x0, x20                | X0 = entryName;//m1                     
            // 0x0197059C: MOV x1, x19                | X1 = stream;//m1                        
            // 0x019705A0: MOV x2, x21                | X2 = X21;//m1                           
            label_43:
            // 0x019705A4: SUB sp, x29, #0x30         | SP = (1152921509624944704 - 48) = 1152921509624944656 (0x100000012B1A1810);
            // 0x019705A8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x019705AC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x019705B0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x019705B4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x019705B8: BR x3                      | X0 = this( ?? entryName, ????);         
            label_8:
            // 0x019705BC: LDRH w23, [x21, #0x4c]     | W23 = X21 + 76;                         
            // 0x019705C0: TBZ w0, #0, #0x197069c     | if ((val_2 & 0x1) == 0) goto label_26;  
            if((val_2 & 1) == 0)
            {
                goto label_26;
            }
            // 0x019705C4: MOV x0, x21                | X0 = X21;//m1                           
            // 0x019705C8: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
            UnityEngine.Sprite val_4 = X21.pressedSprite;
            // 0x019705CC: LDR x9, [x22]              | X9 = X22;                               
            // 0x019705D0: MOV x8, x0                 | X8 = val_4;//m1                         
            // 0x019705D4: LDRH w10, [x9, #0x102]     | W10 = X22 + 258;                        
            // 0x019705D8: CBZ x10, #0x1970604        | if (X22 + 258 == 0) goto label_27;      
            if((X22 + 258) == 0)
            {
                goto label_27;
            }
            // 0x019705DC: LDR x11, [x9, #0x98]       | X11 = X22 + 152;                        
            var val_14 = X22 + 152;
            // 0x019705E0: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
            var val_15 = 0;
            // 0x019705E4: ADD x11, x11, #8           | X11 = (X22 + 152 + 8);                  
            val_14 = val_14 + 8;
            label_29:
            // 0x019705E8: LDUR x13, [x11, #-8]       | X13 = (X22 + 152 + 8) + -8;             
            // 0x019705EC: CMP x13, x8                | STATE = COMPARE((X22 + 152 + 8) + -8, val_4)
            // 0x019705F0: B.EQ #0x1970728            | if ((X22 + 152 + 8) + -8 == val_4) goto label_28;
            if(((X22 + 152 + 8) + -8) == val_4)
            {
                goto label_28;
            }
            // 0x019705F4: ADD x12, x12, #1           | X12 = (0 + 1);                          
            val_15 = val_15 + 1;
            // 0x019705F8: ADD x11, x11, #0x10        | X11 = ((X22 + 152 + 8) + 16);           
            val_14 = val_14 + 16;
            // 0x019705FC: CMP x12, x10               | STATE = COMPARE((0 + 1), X22 + 258)     
            // 0x01970600: B.LO #0x19705e8            | if (0 < X22 + 258) goto label_29;       
            if(val_15 < (X22 + 258))
            {
                goto label_29;
            }
            label_27:
            // 0x01970604: MOV x0, x22                | X0 = X22;//m1                           
            val_16 = X22;
            // 0x01970608: MOV x1, x8                 | X1 = val_4;//m1                         
            // 0x0197060C: MOV w2, w23                | W2 = X21 + 76;//m1                      
            // 0x01970610: BL #0x2776c24              | X0 = sub_2776C24( ?? X22, ????);        
            // 0x01970614: B #0x1970738               |  goto label_30;                         
            goto label_30;
            label_20:
            // 0x01970618: LDRH w22, [x21, #0x4c]     | W22 = X21 + 76;                         
            // 0x0197061C: TBZ w0, #0, #0x19706ac     | if ((val_3 & 0x1) == 0) goto label_31;  
            if((val_3 & 1) == 0)
            {
                goto label_31;
            }
            // 0x01970620: MOV x0, x21                | X0 = X21;//m1                           
            // 0x01970624: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
            UnityEngine.Sprite val_5 = X21.pressedSprite;
            // 0x01970628: LDR x9, [x20]              | X9 = typeof(System.String);             
            // 0x0197062C: MOV x8, x0                 | X8 = val_5;//m1                         
            // 0x01970630: LDRH w10, [x9, #0x102]     | W10 = System.String.__il2cppRuntimeField_interface_offsets_count;
            // 0x01970634: CBZ x10, #0x1970660        | if (System.String.__il2cppRuntimeField_interface_offsets_count == 0) goto label_32;
            // 0x01970638: LDR x11, [x9, #0x98]       | X11 = System.String.__il2cppRuntimeField_interfaceOffsets;
            // 0x0197063C: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
            var val_16 = 0;
            // 0x01970640: ADD x11, x11, #8           | X11 = (System.String.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608321544 (0x1000000000168008);
            label_34:
            // 0x01970644: LDUR x13, [x11, #-8]       | X13 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x01970648: CMP x13, x8                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, val_5)
            // 0x0197064C: B.EQ #0x197074c            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == val_5) goto label_33;
            // 0x01970650: ADD x12, x12, #1           | X12 = (0 + 1);                          
            val_16 = val_16 + 1;
            // 0x01970654: ADD x11, x11, #0x10        | X11 = (1152921504608321544 + 16) = 1152921504608321560 (0x1000000000168018);
            // 0x01970658: CMP x12, x10               | STATE = COMPARE((0 + 1), System.String.__il2cppRuntimeField_interface_offsets_count)
            // 0x0197065C: B.LO #0x1970644            | if (0 < System.String.__il2cppRuntimeField_interface_offsets_count) goto label_34;
            label_32:
            // 0x01970660: MOV x0, x20                | X0 = entryName;//m1                     
            val_17 = entryName;
            // 0x01970664: MOV x1, x8                 | X1 = val_5;//m1                         
            // 0x01970668: MOV w2, w22                | W2 = X21 + 76;//m1                      
            val_13 = X21 + 76;
            // 0x0197066C: BL #0x2776c24              | X0 = sub_2776C24( ?? entryName, ????);  
            // 0x01970670: B #0x197075c               |  goto label_35;                         
            goto label_35;
            label_9:
            // 0x01970674: LDRH w8, [x21, #0x4c]      | W8 = X21 + 76;                          
            // 0x01970678: LDR x9, [x22]              | X9 = X22;                               
            // 0x0197067C: ADD x8, x9, x8, lsl #4     | X8 = (X22 + (X21 + 76) << 4);           
            var val_6 = X22 + ((X21 + 76) << 4);
            // 0x01970680: LDR x0, [x8, #0x118]       | X0 = (X22 + (X21 + 76) << 4) + 280;     
            val_18 = mem[(X22 + (X21 + 76) << 4) + 280];
            val_18 = (X22 + (X21 + 76) << 4) + 280;
            // 0x01970684: B #0x19706d0               |  goto label_36;                         
            goto label_36;
            label_21:
            // 0x01970688: LDRH w8, [x21, #0x4c]      | W8 = X21 + 76;                          
            // 0x0197068C: LDR x9, [x20]              | X9 = typeof(System.String);             
            // 0x01970690: ADD x8, x9, x8, lsl #4     | X8 = (1152921504608284672 + (X21 + 76) << 4);
            string val_7 = 1152921504608284672 + ((X21 + 76) << 4);
            // 0x01970694: LDR x0, [x8, #0x118]       |  //  not_find_field!1:280
            val_19 = mem[(1152921504608284672 + (X21 + 76) << 4) + 280];
            // 0x01970698: B #0x1970708               |  goto label_37;                         
            goto label_37;
            label_26:
            // 0x0197069C: LDR x8, [x22]              | X8 = X22;                               
            var val_17 = X22;
            // 0x019706A0: ADD x8, x8, w23, uxtw #4   | X8 = (X22 + X21 + 76);                  
            val_17 = val_17 + (X21 + 76);
            // 0x019706A4: LDP x4, x3, [x8, #0x110]   | X4 = (X22 + X21 + 76) + 272; X3 = (X22 + X21 + 76) + 272 + 8; //  | 
            // 0x019706A8: B #0x197073c               |  goto label_38;                         
            goto label_38;
            label_31:
            // 0x019706AC: LDR x8, [x20]              | X8 = typeof(System.String);             
            // 0x019706B0: ADD x8, x8, w22, uxtw #4   | X8 = (1152921504608284672 + X21 + 76);  
            string val_8 = 1152921504608284672 + (X21 + 76);
            // 0x019706B4: LDP x3, x2, [x8, #0x110]   |                                          //  not_find_field!1:272 |  not_find_field!1:280
            // 0x019706B8: B #0x1970760               |  goto label_39;                         
            goto label_39;
            label_11:
            // 0x019706BC: LDR w9, [x10]              | W9 = (X22 + 152 + 8);                   
            var val_18 = val_11;
            // 0x019706C0: ADD w9, w9, w2             | W9 = ((X22 + 152 + 8) + X21 + 76);      
            val_18 = val_18 + (X21 + 76);
            // 0x019706C4: ADD x8, x8, w9, uxtw #4    | X8 = (X22 + ((X22 + 152 + 8) + X21 + 76));
            val_19 = val_19 + val_18;
            // 0x019706C8: ADD x0, x8, #0x110         | X0 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272);
            val_14 = val_19 + 272;
            label_13:
            // 0x019706CC: LDR x0, [x0, #8]           | X0 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;
            val_18 = mem[((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8];
            val_18 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;
            label_36:
            // 0x019706D0: MOV x1, x21                | X1 = X21;//m1                           
            // 0x019706D4: BL #0x2796ec8              | X0 = sub_2796EC8( ?? ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8, ????);
            // 0x019706D8: MOV x8, x0                 | X8 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;//m1
            // 0x019706DC: LDR x4, [x8]               | X4 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;
            // 0x019706E0: MOV x0, x22                | X0 = X22;//m1                           
            // 0x019706E4: MOV x1, x20                | X1 = entryName;//m1                     
            // 0x019706E8: MOV x2, x19                | X2 = stream;//m1                        
            // 0x019706EC: MOV x3, x8                 | X3 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;//m1
            // 0x019706F0: B #0x197057c               |  goto label_42;                         
            goto label_42;
            label_23:
            // 0x019706F4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x019706F8: ADD w9, w9, w2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76);
            // 0x019706FC: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504608284672 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76));
            // 0x01970700: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608284672 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76)).272
            label_25:
            // 0x01970704: LDR x0, [x0, #8]           | 
            label_37:
            // 0x01970708: MOV x1, x21                | X1 = X21;//m1                           
            // 0x0197070C: BL #0x2796ec8              | X0 = sub_2796EC8( ?? val_3, ????);      
            // 0x01970710: MOV x8, x0                 | X8 = val_3;//m1                         
            // 0x01970714: LDR x3, [x8]               | X3 = typeof(UnityEngine.Sprite);        
            // 0x01970718: MOV x0, x20                | X0 = entryName;//m1                     
            // 0x0197071C: MOV x1, x19                | X1 = stream;//m1                        
            // 0x01970720: MOV x2, x8                 | X2 = val_3;//m1                         
            // 0x01970724: B #0x19705a4               |  goto label_43;                         
            goto label_43;
            label_28:
            // 0x01970728: LDR w8, [x11]              | W8 = (X22 + 152 + 8);                   
            var val_20 = val_14;
            // 0x0197072C: ADD w8, w8, w23            | W8 = ((X22 + 152 + 8) + X21 + 76);      
            val_20 = val_20 + (X21 + 76);
            // 0x01970730: ADD x8, x9, w8, uxtw #4    | X8 = (X22 + ((X22 + 152 + 8) + X21 + 76));
            val_20 = X22 + val_20;
            // 0x01970734: ADD x0, x8, #0x110         | X0 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272);
            val_16 = val_20 + 272;
            label_30:
            // 0x01970738: LDP x4, x3, [x0]           | X4 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272); X3 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8; //  | 
            label_38:
            // 0x0197073C: MOV x0, x22                | X0 = X22;//m1                           
            // 0x01970740: MOV x1, x20                | X1 = entryName;//m1                     
            // 0x01970744: MOV x2, x19                | X2 = stream;//m1                        
            // 0x01970748: B #0x197057c               |  goto label_42;                         
            goto label_42;
            label_33:
            // 0x0197074C: LDR w8, [x11]              | W8 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x01970750: ADD w8, w8, w22            | W8 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76);
            // 0x01970754: ADD x8, x9, w8, uxtw #4    | X8 = (1152921504608284672 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76));
            // 0x01970758: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608284672 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76)).272
            label_35:
            // 0x0197075C: LDP x3, x2, [x0]           | X3 = typeof(UnityEngine.Sprite);         //  | 
            label_39:
            // 0x01970760: MOV x0, x20                | X0 = entryName;//m1                     
            // 0x01970764: MOV x1, x19                | X1 = stream;//m1                        
            // 0x01970768: B #0x19705a4               |  goto label_43;                         
            goto label_43;
        
        }
        //
        // Offset in libil2cpp.so: 0x0197076C (26675052), len: 52  VirtAddr: 0x0197076C RVA: 0x0197076C token: 100663307 methodIndex: 20861 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual System.IAsyncResult BeginInvoke(string entryName, System.IO.Stream stream, System.AsyncCallback callback, object object)
        {
            //
            // Disasemble & Code
            // 0x0197076C: STP x29, x30, [sp, #-0x10]! | stack[1152921509625097664] = ???;  stack[1152921509625097672] = ???;  //  dest_result_addr=1152921509625097664 |  dest_result_addr=1152921509625097672
            // 0x01970770: MOV x29, sp                | X29 = 1152921509625097664 (0x100000012B1C6DC0);//ML01
            // 0x01970774: SUB sp, sp, #0x20          | SP = (1152921509625097664 - 32) = 1152921509625097632 (0x100000012B1C6DA0);
            // 0x01970778: STP xzr, xzr, [sp, #0x10]  | stack[1152921509625097648] = 0x0;  stack[1152921509625097656] = 0x0;  //  dest_result_addr=1152921509625097648 |  dest_result_addr=1152921509625097656
            // 0x0197077C: STP xzr, x2, [sp, #8]      | stack[1152921509625097640] = 0x0;  stack[1152921509625097648] = stream;  //  dest_result_addr=1152921509625097640 |  dest_result_addr=1152921509625097648
            // 0x01970780: STR x1, [sp, #8]           | stack[1152921509625097640] = entryName;  //  dest_result_addr=1152921509625097640
            // 0x01970784: ADD x1, sp, #8             | X1 = (1152921509625097632 + 8) = 1152921509625097640 (0x100000012B1C6DA8);
            // 0x01970788: MOV x2, x3                 | X2 = callback;//m1                      
            // 0x0197078C: MOV x3, x4                 | X3 = object;//m1                        
            // 0x01970790: BL #0x278fb00              | X0 = sub_278FB00( ?? this, ????);       
            // 0x01970794: MOV sp, x29                | SP = 1152921509625097664 (0x100000012B1C6DC0);//ML01
            // 0x01970798: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x0197079C: RET                        |  return (System.IAsyncResult)this;      
            return (System.IAsyncResult)this;
            //  |  // // {name=val_0, type=System.IAsyncResult, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x019707A0 (26675104), len: 16  VirtAddr: 0x019707A0 RVA: 0x019707A0 token: 100663308 methodIndex: 20862 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual void EndInvoke(System.IAsyncResult result)
        {
            //
            // Disasemble & Code
            // 0x019707A0: MOV x8, x1                 | X8 = result;//m1                        
            // 0x019707A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019707A8: MOV x0, x8                 | X0 = result;//m1                        
            // 0x019707AC: B #0x278fde8               | X0 = sub_278FDE8( ?? result, ????);     
        
        }
    
    }

}
