using UnityEngine;
private class LzmaBench.CrcOutStream : Stream
{
    // Fields
    public SevenZip.CRC CRC; //  0x00000010
    
    // Properties
    public override bool CanRead { get; }
    public override bool CanSeek { get; }
    public override bool CanWrite { get; }
    public override long Length { get; }
    public override long Position { get; set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00ADB6EC (11384556), len: 144  VirtAddr: 0x00ADB6EC RVA: 0x00ADB6EC token: 100681619 methodIndex: 54795 delegateWrapperIndex: 0 methodInvoker: 0
    public LzmaBench.CrcOutStream()
    {
        //
        // Disasemble & Code
        // 0x00ADB6EC: STP x20, x19, [sp, #-0x20]! | stack[1152921513103001392] = ???;  stack[1152921513103001400] = ???;  //  dest_result_addr=1152921513103001392 |  dest_result_addr=1152921513103001400
        // 0x00ADB6F0: STP x29, x30, [sp, #0x10]  | stack[1152921513103001408] = ???;  stack[1152921513103001416] = ???;  //  dest_result_addr=1152921513103001408 |  dest_result_addr=1152921513103001416
        // 0x00ADB6F4: ADD x29, sp, #0x10         | X29 = (1152921513103001392 + 16) = 1152921513103001408 (0x10000001FA690740);
        // 0x00ADB6F8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00ADB6FC: LDRB w8, [x20, #0x521]     | W8 = (bool)static_value_03733521;       
        // 0x00ADB700: MOV x19, x0                | X19 = 1152921513103013424 (0x10000001FA693630);//ML01
        // 0x00ADB704: TBNZ w8, #0, #0xadb720     | if (static_value_03733521 == true) goto label_0;
        // 0x00ADB708: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
        // 0x00ADB70C: LDR x8, [x8, #0x7c8]       | X8 = 0x2B92DD4;                         
        // 0x00ADB710: LDR w0, [x8]               | W0 = 0x223A;                            
        // 0x00ADB714: BL #0x2782188              | X0 = sub_2782188( ?? 0x223A, ????);     
        // 0x00ADB718: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00ADB71C: STRB w8, [x20, #0x521]     | static_value_03733521 = true;            //  dest_result_addr=57881889
        label_0:
        // 0x00ADB720: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
        // 0x00ADB724: LDR x8, [x8, #0x988]       | X8 = 1152921504832512000;               
        // 0x00ADB728: LDR x0, [x8]               | X0 = typeof(SevenZip.CRC);              
        object val_1 = null;
        // 0x00ADB72C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(SevenZip.CRC), ????);
        // 0x00ADB730: MOV x20, x0                | X20 = 1152921504832512000 (0x100000000D736000);//ML01
        // 0x00ADB734: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
        // 0x00ADB738: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00ADB73C: STR w8, [x20, #0x10]       | typeof(SevenZip.CRC).__il2cppRuntimeField_10 = 0x0;  //  dest_result_addr=1152921504832512016
        typeof(SevenZip.CRC).__il2cppRuntimeField_10 = 0;
        // 0x00ADB740: BL #0x16f59f0              | .ctor();                                
        val_1 = new System.Object();
        // 0x00ADB744: STR x20, [x19, #0x10]      | this.CRC = typeof(SevenZip.CRC);         //  dest_result_addr=1152921513103013440
        this.CRC = val_1;
        // 0x00ADB748: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
        // 0x00ADB74C: LDR x8, [x8, #0x898]       | X8 = 1152921504622342144;               
        // 0x00ADB750: LDR x0, [x8]               | X0 = typeof(System.IO.Stream);          
        // 0x00ADB754: LDRB w8, [x0, #0x10a]      | W8 = System.IO.Stream.__il2cppRuntimeField_10A;
        // 0x00ADB758: TBZ w8, #0, #0xadb768      | if (System.IO.Stream.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00ADB75C: LDR w8, [x0, #0xbc]        | W8 = System.IO.Stream.__il2cppRuntimeField_cctor_finished;
        // 0x00ADB760: CBNZ w8, #0xadb768         | if (System.IO.Stream.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00ADB764: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Stream), ????);
        label_2:
        // 0x00ADB768: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00ADB76C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00ADB770: MOV x0, x19                | X0 = 1152921513103013424 (0x10000001FA693630);//ML01
        // 0x00ADB774: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00ADB778: B #0x1e73764               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADB784 (11384708), len: 44  VirtAddr: 0x00ADB784 RVA: 0x00ADB784 token: 100681620 methodIndex: 54796 delegateWrapperIndex: 0 methodInvoker: 0
    public void Init()
    {
        //
        // Disasemble & Code
        // 0x00ADB784: STP x20, x19, [sp, #-0x20]! | stack[1152921513103117488] = ???;  stack[1152921513103117496] = ???;  //  dest_result_addr=1152921513103117488 |  dest_result_addr=1152921513103117496
        // 0x00ADB788: STP x29, x30, [sp, #0x10]  | stack[1152921513103117504] = ???;  stack[1152921513103117512] = ???;  //  dest_result_addr=1152921513103117504 |  dest_result_addr=1152921513103117512
        // 0x00ADB78C: ADD x29, sp, #0x10         | X29 = (1152921513103117488 + 16) = 1152921513103117504 (0x10000001FA6ACCC0);
        // 0x00ADB790: LDR x19, [x0, #0x10]       | X19 = this.CRC; //P2                    
        // 0x00ADB794: CBNZ x19, #0xadb79c        | if (this.CRC != null) goto label_0;     
        if(this.CRC != null)
        {
            goto label_0;
        }
        // 0x00ADB798: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00ADB79C: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
        // 0x00ADB7A0: STR w8, [x19, #0x10]       | this.CRC._value = null;                  //  dest_result_addr=0
        this.CRC._value = 0;
        // 0x00ADB7A4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00ADB7A8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00ADB7AC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADB7B0 (11384752), len: 44  VirtAddr: 0x00ADB7B0 RVA: 0x00ADB7B0 token: 100681621 methodIndex: 54797 delegateWrapperIndex: 0 methodInvoker: 0
    public uint GetDigest()
    {
        //
        // Disasemble & Code
        // 0x00ADB7B0: STP x20, x19, [sp, #-0x20]! | stack[1152921513103237680] = ???;  stack[1152921513103237688] = ???;  //  dest_result_addr=1152921513103237680 |  dest_result_addr=1152921513103237688
        // 0x00ADB7B4: STP x29, x30, [sp, #0x10]  | stack[1152921513103237696] = ???;  stack[1152921513103237704] = ???;  //  dest_result_addr=1152921513103237696 |  dest_result_addr=1152921513103237704
        // 0x00ADB7B8: ADD x29, sp, #0x10         | X29 = (1152921513103237680 + 16) = 1152921513103237696 (0x10000001FA6CA240);
        // 0x00ADB7BC: LDR x19, [x0, #0x10]       | X19 = this.CRC; //P2                    
        // 0x00ADB7C0: CBNZ x19, #0xadb7c8        | if (this.CRC != null) goto label_0;     
        if(this.CRC != null)
        {
            goto label_0;
        }
        // 0x00ADB7C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00ADB7C8: LDR w8, [x19, #0x10]       | W8 = this.CRC._value; //P2              
        // 0x00ADB7CC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00ADB7D0: MVN w0, w8                 | W0 = ~(this.CRC._value);                
        // 0x00ADB7D4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00ADB7D8: RET                        |  return (System.UInt32)~(this.CRC._value);
        return (uint)~this.CRC._value;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADBBD8 (11385816), len: 8  VirtAddr: 0x00ADBBD8 RVA: 0x00ADBBD8 token: 100681622 methodIndex: 54798 delegateWrapperIndex: 0 methodInvoker: 0
    public override bool get_CanRead()
    {
        //
        // Disasemble & Code
        // 0x00ADBBD8: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        // 0x00ADBBDC: RET                        |  return (System.Boolean)false;          
        return (bool)0;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADBBE0 (11385824), len: 8  VirtAddr: 0x00ADBBE0 RVA: 0x00ADBBE0 token: 100681623 methodIndex: 54799 delegateWrapperIndex: 0 methodInvoker: 0
    public override bool get_CanSeek()
    {
        //
        // Disasemble & Code
        // 0x00ADBBE0: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        // 0x00ADBBE4: RET                        |  return (System.Boolean)false;          
        return (bool)0;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADBBE8 (11385832), len: 8  VirtAddr: 0x00ADBBE8 RVA: 0x00ADBBE8 token: 100681624 methodIndex: 54800 delegateWrapperIndex: 0 methodInvoker: 0
    public override bool get_CanWrite()
    {
        //
        // Disasemble & Code
        // 0x00ADBBE8: ORR w0, wzr, #1            | W0 = 1(0x1);                            
        // 0x00ADBBEC: RET                        |  return (System.Boolean)true;           
        return (bool)1;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADBBF0 (11385840), len: 8  VirtAddr: 0x00ADBBF0 RVA: 0x00ADBBF0 token: 100681625 methodIndex: 54801 delegateWrapperIndex: 0 methodInvoker: 0
    public override long get_Length()
    {
        //
        // Disasemble & Code
        // 0x00ADBBF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00ADBBF4: RET                        |  return (System.Int64)0;                
        return (long)0;
        //  |  // // {name=val_0, type=System.Int64, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADBBF8 (11385848), len: 8  VirtAddr: 0x00ADBBF8 RVA: 0x00ADBBF8 token: 100681626 methodIndex: 54802 delegateWrapperIndex: 0 methodInvoker: 0
    public override long get_Position()
    {
        //
        // Disasemble & Code
        // 0x00ADBBF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00ADBBFC: RET                        |  return (System.Int64)0;                
        return (long)0;
        //  |  // // {name=val_0, type=System.Int64, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADBC00 (11385856), len: 4  VirtAddr: 0x00ADBC00 RVA: 0x00ADBC00 token: 100681627 methodIndex: 54803 delegateWrapperIndex: 0 methodInvoker: 0
    public override void set_Position(long value)
    {
        //
        // Disasemble & Code
        // 0x00ADBC00: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADBC04 (11385860), len: 4  VirtAddr: 0x00ADBC04 RVA: 0x00ADBC04 token: 100681628 methodIndex: 54804 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Flush()
    {
        //
        // Disasemble & Code
        // 0x00ADBC04: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADBC08 (11385864), len: 8  VirtAddr: 0x00ADBC08 RVA: 0x00ADBC08 token: 100681629 methodIndex: 54805 delegateWrapperIndex: 0 methodInvoker: 0
    public override long Seek(long offset, System.IO.SeekOrigin origin)
    {
        //
        // Disasemble & Code
        // 0x00ADBC08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00ADBC0C: RET                        |  return (System.Int64)0;                
        return (long)0;
        //  |  // // {name=val_0, type=System.Int64, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADBC10 (11385872), len: 4  VirtAddr: 0x00ADBC10 RVA: 0x00ADBC10 token: 100681630 methodIndex: 54806 delegateWrapperIndex: 0 methodInvoker: 0
    public override void SetLength(long value)
    {
        //
        // Disasemble & Code
        // 0x00ADBC10: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADBC14 (11385876), len: 8  VirtAddr: 0x00ADBC14 RVA: 0x00ADBC14 token: 100681631 methodIndex: 54807 delegateWrapperIndex: 0 methodInvoker: 0
    public override int Read(byte[] buffer, int offset, int count)
    {
        //
        // Disasemble & Code
        // 0x00ADBC14: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        // 0x00ADBC18: RET                        |  return (System.Int32)0;                
        return (int)0;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADBC1C (11385884), len: 48  VirtAddr: 0x00ADBC1C RVA: 0x00ADBC1C token: 100681632 methodIndex: 54808 delegateWrapperIndex: 0 methodInvoker: 0
    public override void WriteByte(byte b)
    {
        //
        // Disasemble & Code
        // 0x00ADBC1C: STP x20, x19, [sp, #-0x20]! | stack[1152921513104559792] = ???;  stack[1152921513104559800] = ???;  //  dest_result_addr=1152921513104559792 |  dest_result_addr=1152921513104559800
        // 0x00ADBC20: STP x29, x30, [sp, #0x10]  | stack[1152921513104559808] = ???;  stack[1152921513104559816] = ???;  //  dest_result_addr=1152921513104559808 |  dest_result_addr=1152921513104559816
        // 0x00ADBC24: ADD x29, sp, #0x10         | X29 = (1152921513104559792 + 16) = 1152921513104559808 (0x10000001FA80CEC0);
        // 0x00ADBC28: LDR x20, [x0, #0x10]       | X20 = this.CRC; //P2                    
        // 0x00ADBC2C: MOV w19, w1                | W19 = b;//m1                            
        // 0x00ADBC30: CBNZ x20, #0xadbc38        | if (this.CRC != null) goto label_0;     
        if(this.CRC != null)
        {
            goto label_0;
        }
        // 0x00ADBC34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00ADBC38: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00ADBC3C: MOV x0, x20                | X0 = this.CRC;//m1                      
        // 0x00ADBC40: MOV w1, w19                | W1 = b;//m1                             
        // 0x00ADBC44: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00ADBC48: B #0xad882c                | this.CRC.UpdateByte(b:  b); return;     
        this.CRC.UpdateByte(b:  b);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADBC4C (11385932), len: 72  VirtAddr: 0x00ADBC4C RVA: 0x00ADBC4C token: 100681633 methodIndex: 54809 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Write(byte[] buffer, int offset, int count)
    {
        //
        // Disasemble & Code
        // 0x00ADBC4C: STP x22, x21, [sp, #-0x30]! | stack[1152921513104716832] = ???;  stack[1152921513104716840] = ???;  //  dest_result_addr=1152921513104716832 |  dest_result_addr=1152921513104716840
        // 0x00ADBC50: STP x20, x19, [sp, #0x10]  | stack[1152921513104716848] = ???;  stack[1152921513104716856] = ???;  //  dest_result_addr=1152921513104716848 |  dest_result_addr=1152921513104716856
        // 0x00ADBC54: STP x29, x30, [sp, #0x20]  | stack[1152921513104716864] = ???;  stack[1152921513104716872] = ???;  //  dest_result_addr=1152921513104716864 |  dest_result_addr=1152921513104716872
        // 0x00ADBC58: ADD x29, sp, #0x20         | X29 = (1152921513104716832 + 32) = 1152921513104716864 (0x10000001FA833440);
        // 0x00ADBC5C: LDR x21, [x0, #0x10]       | X21 = this.CRC; //P2                    
        // 0x00ADBC60: MOV w19, w3                | W19 = count;//m1                        
        // 0x00ADBC64: MOV w20, w2                | W20 = offset;//m1                       
        // 0x00ADBC68: MOV x22, x1                | X22 = buffer;//m1                       
        // 0x00ADBC6C: CBNZ x21, #0xadbc74        | if (this.CRC != null) goto label_0;     
        if(this.CRC != null)
        {
            goto label_0;
        }
        // 0x00ADBC70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00ADBC74: MOV w2, w20                | W2 = offset;//m1                        
        // 0x00ADBC78: MOV w3, w19                | W3 = count;//m1                         
        // 0x00ADBC7C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00ADBC80: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00ADBC84: MOV x0, x21                | X0 = this.CRC;//m1                      
        // 0x00ADBC88: MOV x1, x22                | X1 = buffer;//m1                        
        // 0x00ADBC8C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00ADBC90: B #0xad88e4                | this.CRC.Update(data:  buffer, offset:  offset, size:  count); return;
        this.CRC.Update(data:  buffer, offset:  offset, size:  count);
        return;
    
    }

}
