using UnityEngine;
public class Client
{
    // Fields
    public const string LOGIN_SERVER = "LOGIN_SERVER";
    public const string CONNECT_SERVER = "CONNECT_SERVER";
    public static readonly Client instance; // static_offset: 0x00000000
    private static Newtonsoft.Json.Linq.JObject handShakeData; // static_offset: 0x00000008
    private Pomelo.DotNetClient.PomeloClient pc; //  0x00000010
    private Pomelo.DotNetClient.NetWorkState state; //  0x00000018
    private static System.Action <>f__am$cache0; // static_offset: 0x00000010
    
    // Properties
    public bool IsNetConnected { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00D84608 (14173704), len: 8  VirtAddr: 0x00D84608 RVA: 0x00D84608 token: 100694569 methodIndex: 25972 delegateWrapperIndex: 0 methodInvoker: 0
    public Client()
    {
        //
        // Disasemble & Code
        // 0x00D84608: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8460C: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D84610 (14173712), len: 20  VirtAddr: 0x00D84610 RVA: 0x00D84610 token: 100694570 methodIndex: 25973 delegateWrapperIndex: 0 methodInvoker: 0
    public bool get_IsNetConnected()
    {
        //
        // Disasemble & Code
        // 0x00D84610: LDR w8, [x0, #0x18]        | W8 = this.state; //P2                   
        Pomelo.DotNetClient.NetWorkState val_2 = this.state;
        // 0x00D84614: SUB w8, w8, #1             | W8 = (this.state - 1);                  
        val_2 = val_2 - 1;
        // 0x00D84618: CMP w8, #2                 | STATE = COMPARE((this.state - 1), 0x2)  
        // 0x00D8461C: CSET w0, lo                | W0 = this.state < 0x2 ? 1 : 0;          
        var val_1 = (val_2 < 2) ? 1 : 0;
        // 0x00D84620: RET                        |  return (System.Boolean)this.state < 0x2 ? 1 : 0;
        return (bool)val_1;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D84624 (14173732), len: 52  VirtAddr: 0x00D84624 RVA: 0x00D84624 token: 100694571 methodIndex: 25974 delegateWrapperIndex: 0 methodInvoker: 0
    public void CloseNetState()
    {
        //
        // Disasemble & Code
        // 0x00D84624: STP x20, x19, [sp, #-0x20]! | stack[1152921515201418464] = ???;  stack[1152921515201418472] = ???;  //  dest_result_addr=1152921515201418464 |  dest_result_addr=1152921515201418472
        // 0x00D84628: STP x29, x30, [sp, #0x10]  | stack[1152921515201418480] = ???;  stack[1152921515201418488] = ???;  //  dest_result_addr=1152921515201418480 |  dest_result_addr=1152921515201418488
        // 0x00D8462C: ADD x29, sp, #0x10         | X29 = (1152921515201418464 + 16) = 1152921515201418480 (0x10000002777C54F0);
        // 0x00D84630: LDR x19, [x0, #0x10]       | X19 = this.pc; //P2                     
        // 0x00D84634: ORR w8, wzr, #4            | W8 = 4(0x4);                            
        // 0x00D84638: STR w8, [x0, #0x18]        | this.state = 0x4;                        //  dest_result_addr=1152921515201430520
        this.state = 4;
        // 0x00D8463C: CBNZ x19, #0xd84644        | if (this.pc != null) goto label_0;      
        if(this.pc != null)
        {
            goto label_0;
        }
        // 0x00D84640: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00D84644: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D84648: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8464C: MOV x0, x19                | X0 = this.pc;//m1                       
        // 0x00D84650: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D84654: B #0xc68974                | this.pc.Dispose(); return;              
        this.pc.Dispose();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D84658 (14173784), len: 1068  VirtAddr: 0x00D84658 RVA: 0x00D84658 token: 100694572 methodIndex: 25975 delegateWrapperIndex: 0 methodInvoker: 0
    public void Run(string host, int port, Client.ResponseCallBack responseFun, Client.PushCallBack pushFun)
    {
        //
        // Disasemble & Code
        //  | 
        var val_7;
        //  | 
        var val_8;
        //  | 
        var val_9;
        // 0x00D84658: STP x28, x27, [sp, #-0x60]! | stack[1152921515201562240] = ???;  stack[1152921515201562248] = ???;  //  dest_result_addr=1152921515201562240 |  dest_result_addr=1152921515201562248
        // 0x00D8465C: STP x26, x25, [sp, #0x10]  | stack[1152921515201562256] = ???;  stack[1152921515201562264] = ???;  //  dest_result_addr=1152921515201562256 |  dest_result_addr=1152921515201562264
        // 0x00D84660: STP x24, x23, [sp, #0x20]  | stack[1152921515201562272] = ???;  stack[1152921515201562280] = ???;  //  dest_result_addr=1152921515201562272 |  dest_result_addr=1152921515201562280
        // 0x00D84664: STP x22, x21, [sp, #0x30]  | stack[1152921515201562288] = ???;  stack[1152921515201562296] = ???;  //  dest_result_addr=1152921515201562288 |  dest_result_addr=1152921515201562296
        // 0x00D84668: STP x20, x19, [sp, #0x40]  | stack[1152921515201562304] = ???;  stack[1152921515201562312] = ???;  //  dest_result_addr=1152921515201562304 |  dest_result_addr=1152921515201562312
        // 0x00D8466C: STP x29, x30, [sp, #0x50]  | stack[1152921515201562320] = ???;  stack[1152921515201562328] = ???;  //  dest_result_addr=1152921515201562320 |  dest_result_addr=1152921515201562328
        // 0x00D84670: ADD x29, sp, #0x50         | X29 = (1152921515201562240 + 80) = 1152921515201562320 (0x10000002777E86D0);
        // 0x00D84674: ADRP x23, #0x3734000       | X23 = 57884672 (0x3734000);             
        // 0x00D84678: LDRB w8, [x23, #0x431]     | W8 = (bool)static_value_03734431;       
        // 0x00D8467C: MOV x19, x4                | X19 = pushFun;//m1                      
        // 0x00D84680: MOV x20, x3                | X20 = responseFun;//m1                  
        // 0x00D84684: MOV w21, w2                | W21 = port;//m1                         
        // 0x00D84688: MOV x22, x1                | X22 = host;//m1                         
        // 0x00D8468C: MOV x24, x0                | X24 = 1152921515201574336 (0x10000002777EB5C0);//ML01
        // 0x00D84690: TBNZ w8, #0, #0xd846ac     | if (static_value_03734431 == true) goto label_0;
        // 0x00D84694: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
        // 0x00D84698: LDR x8, [x8, #0xe18]       | X8 = 0x2B90B64;                         
        // 0x00D8469C: LDR w0, [x8]               | W0 = 0x199D;                            
        // 0x00D846A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x199D, ????);     
        // 0x00D846A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D846A8: STRB w8, [x23, #0x431]     | static_value_03734431 = true;            //  dest_result_addr=57885745
        label_0:
        // 0x00D846AC: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
        // 0x00D846B0: LDR x8, [x8, #0x348]       | X8 = 1152921504912437248;               
        // 0x00D846B4: LDR x0, [x8]               | X0 = typeof(Client.<Run>c__AnonStorey0);
        object val_1 = null;
        // 0x00D846B8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Client.<Run>c__AnonStorey0), ????);
        // 0x00D846BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D846C0: MOV x23, x0                | X23 = 1152921504912437248 (0x100000001236F000);//ML01
        // 0x00D846C4: BL #0x16f59f0              | .ctor();                                
        val_1 = new System.Object();
        // 0x00D846C8: CBNZ x23, #0xd846d0        | if ( != 0) goto label_1;                
        if(null != 0)
        {
            goto label_1;
        }
        // 0x00D846CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_1:
        // 0x00D846D0: STR x24, [x23, #0x20]      | typeof(Client.<Run>c__AnonStorey0).__il2cppRuntimeField_20 = this;  //  dest_result_addr=1152921504912437280
        typeof(Client.<Run>c__AnonStorey0).__il2cppRuntimeField_20 = this;
        // 0x00D846D4: LDR w8, [x24, #0x18]       | W8 = this.state; //P2                   
        Pomelo.DotNetClient.NetWorkState val_7 = this.state;
        // 0x00D846D8: SUB w8, w8, #1             | W8 = (this.state - 1);                  
        val_7 = val_7 - 1;
        // 0x00D846DC: CMP w8, #2                 | STATE = COMPARE((this.state - 1), 0x2)  
        // 0x00D846E0: B.LO #0xd848b8             | if (this.state < 0x2) goto label_2;     
        if(val_7 < 2)
        {
            goto label_2;
        }
        // 0x00D846E4: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
        // 0x00D846E8: LDR x8, [x8, #0xe98]       | X8 = 1152921504912703488;               
        // 0x00D846EC: LDR x0, [x8]               | X0 = typeof(Pomelo.DotNetClient.PomeloClient);
        Pomelo.DotNetClient.PomeloClient val_2 = null;
        // 0x00D846F0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pomelo.DotNetClient.PomeloClient), ????);
        // 0x00D846F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D846F8: MOV x25, x0                | X25 = 1152921504912703488 (0x10000000123B0000);//ML01
        // 0x00D846FC: BL #0xc67de4               | .ctor();                                
        val_2 = new Pomelo.DotNetClient.PomeloClient();
        // 0x00D84700: STR x25, [x24, #0x10]      | this.pc = typeof(Pomelo.DotNetClient.PomeloClient);  //  dest_result_addr=1152921515201574352
        this.pc = val_2;
        // 0x00D84704: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
        // 0x00D84708: ADRP x9, #0x366a000        | X9 = 57057280 (0x366A000);              
        // 0x00D8470C: LDR x8, [x8, #0xf28]       | X8 = 1152921515201538976;               
        // 0x00D84710: LDR x9, [x9, #0xcb0]       | X9 = 1152921504657965056;               
        // 0x00D84714: LDR x27, [x8]              | X27 = System.Void Client::OnStateChanged(Pomelo.DotNetClient.NetWorkState state);
        // 0x00D84718: LDR x0, [x9]               | X0 = typeof(System.Action<T>);          
        System.Action<Pomelo.DotNetClient.NetWorkState> val_3 = null;
        // 0x00D8471C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action<T>), ????);
        // 0x00D84720: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
        // 0x00D84724: LDR x8, [x8, #0xf98]       | X8 = 1152921515201540000;               
        // 0x00D84728: MOV x1, x24                | X1 = 1152921515201574336 (0x10000002777EB5C0);//ML01
        // 0x00D8472C: MOV x2, x27                | X2 = 1152921515201538976 (0x10000002777E2BA0);//ML01
        // 0x00D84730: MOV x26, x0                | X26 = 1152921504657965056 (0x10000000030C0000);//ML01
        // 0x00D84734: LDR x3, [x8]               | X3 = public System.Void System.Action<Pomelo.DotNetClient.NetWorkState>::.ctor(object object, IntPtr method);
        // 0x00D84738: BL #0x1a07c04              | .ctor(object:  this, method:  System.Void Client::OnStateChanged(Pomelo.DotNetClient.NetWorkState state));
        val_3 = new System.Action<Pomelo.DotNetClient.NetWorkState>(object:  this, method:  System.Void Client::OnStateChanged(Pomelo.DotNetClient.NetWorkState state));
        // 0x00D8473C: CBNZ x25, #0xd84744        | if ( != 0) goto label_3;                
        if(null != 0)
        {
            goto label_3;
        }
        // 0x00D84740: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  this, method:  System.Void Client::OnStateChanged(Pomelo.DotNetClient.NetWorkState state)), ????);
        label_3:
        // 0x00D84744: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D84748: MOV x0, x25                | X0 = 1152921504912703488 (0x10000000123B0000);//ML01
        // 0x00D8474C: MOV x1, x26                | X1 = 1152921504657965056 (0x10000000030C0000);//ML01
        // 0x00D84750: BL #0xc67e78               | add_NetWorkStateChangedEvent(value:  val_3);
        add_NetWorkStateChangedEvent(value:  val_3);
        // 0x00D84754: ADRP x25, #0x35d6000       | X25 = 56451072 (0x35D6000);             
        // 0x00D84758: LDR x25, [x25, #0xe38]     | X25 = 1152921504608284672;              
        // 0x00D8475C: LDR x0, [x25]              | X0 = typeof(System.String);             
        val_7 = null;
        // 0x00D84760: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00D84764: TBZ w8, #0, #0xd84778      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00D84768: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00D8476C: CBNZ w8, #0xd84778         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00D84770: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00D84774: LDR x0, [x25]              | X0 = typeof(System.String);             
        val_7 = null;
        label_5:
        // 0x00D84778: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00D8477C: LDR x25, [x8]              | X25 = System.String.Empty;              
        // 0x00D84780: CBNZ x23, #0xd84788        | if ( != 0) goto label_6;                
        if(null != 0)
        {
            goto label_6;
        }
        // 0x00D84784: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String), ????);
        label_6:
        // 0x00D84788: STR x25, [x23, #0x18]      | typeof(Client.<Run>c__AnonStorey0).__il2cppRuntimeField_18 = System.String.Empty;  //  dest_result_addr=1152921504912437272
        typeof(Client.<Run>c__AnonStorey0).__il2cppRuntimeField_18 = System.String.Empty;
        // 0x00D8478C: ADRP x25, #0x3631000       | X25 = 56823808 (0x3631000);             
        // 0x00D84790: LDR x25, [x25, #0x370]     | X25 = 1152921504912277504;              
        // 0x00D84794: LDR x0, [x25]              | X0 = typeof(Client);                    
        val_8 = null;
        // 0x00D84798: LDRB w8, [x0, #0x10a]      | W8 = Client.__il2cppRuntimeField_10A;   
        // 0x00D8479C: TBZ w8, #0, #0xd847b0      | if (Client.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00D847A0: LDR w8, [x0, #0xbc]        | W8 = Client.__il2cppRuntimeField_cctor_finished;
        // 0x00D847A4: CBNZ w8, #0xd847b0         | if (Client.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00D847A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Client), ????);
        // 0x00D847AC: LDR x0, [x25]              | X0 = typeof(Client);                    
        val_8 = null;
        label_8:
        // 0x00D847B0: LDR x8, [x0, #0xa0]        | X8 = Client.__il2cppRuntimeField_static_fields;
        // 0x00D847B4: LDR x8, [x8, #8]           | X8 = Client.handShakeData;              
        // 0x00D847B8: CBNZ x8, #0xd84804         | if (Client.handShakeData != null) goto label_9;
        if(Client.handShakeData != null)
        {
            goto label_9;
        }
        // 0x00D847BC: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
        // 0x00D847C0: LDR x8, [x8, #0x638]       | X8 = 1152921504924684288;               
        // 0x00D847C4: LDR x0, [x8]               | X0 = typeof(ReadFileTool);              
        // 0x00D847C8: LDRB w8, [x0, #0x10a]      | W8 = ReadFileTool.__il2cppRuntimeField_10A;
        // 0x00D847CC: TBZ w8, #0, #0xd847dc      | if (ReadFileTool.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00D847D0: LDR w8, [x0, #0xbc]        | W8 = ReadFileTool.__il2cppRuntimeField_cctor_finished;
        // 0x00D847D4: CBNZ w8, #0xd847dc         | if (ReadFileTool.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00D847D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ReadFileTool), ????);
        label_11:
        // 0x00D847DC: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
        // 0x00D847E0: LDR x8, [x8, #0xd78]       | X8 = (string**)(1152921515201541024)("Data/handshake");
        // 0x00D847E4: LDR x1, [x8]               | X1 = "Data/handshake";                  
        // 0x00D847E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D847EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D847F0: BL #0xc93b58               | X0 = ReadFileTool.GetTextAsset(txtAddress:  0);
        string val_4 = ReadFileTool.GetTextAsset(txtAddress:  0);
        // 0x00D847F4: MOV x25, x0                | X25 = val_4;//m1                        
        // 0x00D847F8: CBNZ x23, #0xd84800        | if ( != 0) goto label_12;               
        if(null != 0)
        {
            goto label_12;
        }
        // 0x00D847FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_12:
        // 0x00D84800: STR x25, [x23, #0x18]      | typeof(Client.<Run>c__AnonStorey0).__il2cppRuntimeField_18 = val_4;  //  dest_result_addr=1152921504912437272
        typeof(Client.<Run>c__AnonStorey0).__il2cppRuntimeField_18 = val_4;
        label_9:
        // 0x00D84804: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
        // 0x00D84808: LDR x8, [x8, #0xf28]       | X8 = 1152921504673247232;               
        // 0x00D8480C: LDR x0, [x8]               | X0 = typeof(System.Diagnostics.Stopwatch);
        System.Diagnostics.Stopwatch val_5 = null;
        // 0x00D84810: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Diagnostics.Stopwatch), ????);
        // 0x00D84814: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D84818: MOV x25, x0                | X25 = 1152921504673247232 (0x1000000003F53000);//ML01
        // 0x00D8481C: BL #0x14ff724              | .ctor();                                
        val_5 = new System.Diagnostics.Stopwatch();
        // 0x00D84820: CBZ x23, #0xd84830         | if ( == 0) goto label_13;               
        if(null == 0)
        {
            goto label_13;
        }
        // 0x00D84824: MOV x26, x23               | X26 = 1152921504912437248 (0x100000001236F000);//ML01
        val_9 = val_1;
        // 0x00D84828: STR x25, [x26, #0x10]!     | typeof(Client.<Run>c__AnonStorey0).__il2cppRuntimeField_10 = typeof(System.Diagnostics.Stopwatch);  //  dest_result_addr=1152921504912437264
        typeof(Client.<Run>c__AnonStorey0).__il2cppRuntimeField_10 = val_5;
        // 0x00D8482C: B #0xd84840                |  goto label_14;                         
        goto label_14;
        label_13:
        // 0x00D84830: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        // 0x00D84834: ORR w26, wzr, #0x10        | W26 = 16(0x10);                         
        val_9 = 16;
        // 0x00D84838: STR x25, [x26]             | mem[16] = typeof(System.Diagnostics.Stopwatch);  //  dest_result_addr=16
        mem[16] = val_5;
        // 0x00D8483C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_14:
        // 0x00D84840: LDR x25, [x26]             | X25 = typeof(System.Diagnostics.Stopwatch);
        // 0x00D84844: CBNZ x25, #0xd8484c        | if ( != 0) goto label_15;               
        if(null != 0)
        {
            goto label_15;
        }
        // 0x00D84848: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_15:
        // 0x00D8484C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D84850: MOV x0, x25                | X0 = 1152921504673247232 (0x1000000003F53000);//ML01
        // 0x00D84854: BL #0x14ff804              | Start();                                
        Start();
        // 0x00D84858: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
        // 0x00D8485C: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
        // 0x00D84860: LDR x24, [x24, #0x10]      | X24 = this.pc; //P2                     
        // 0x00D84864: LDR x8, [x8, #0xa40]       | X8 = 1152921515201549312;               
        // 0x00D84868: LDR x9, [x9, #0xbe0]       | X9 = 1152921504687837184;               
        // 0x00D8486C: LDR x26, [x8]              | X26 = System.Void Client.<Run>c__AnonStorey0::<>m__0();
        // 0x00D84870: LDR x0, [x9]               | X0 = typeof(System.Action);             
        // 0x00D84874: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00D84878: MOV x25, x0                | X25 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00D8487C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D84880: MOV x0, x25                | X0 = 1152921504687837184 (0x1000000004D3D000);//ML01
        System.Action val_6 = null;
        // 0x00D84884: MOV x1, x23                | X1 = 1152921504912437248 (0x100000001236F000);//ML01
        // 0x00D84888: MOV x2, x26                | X2 = 1152921515201549312 (0x10000002777E5400);//ML01
        // 0x00D8488C: BL #0x26e30f0              | .ctor(object:  val_1, method:  System.Void Client.<Run>c__AnonStorey0::<>m__0());
        val_6 = new System.Action(object:  val_1, method:  System.Void Client.<Run>c__AnonStorey0::<>m__0());
        // 0x00D84890: CBNZ x24, #0xd84898        | if (this.pc != null) goto label_16;     
        if(this.pc != null)
        {
            goto label_16;
        }
        // 0x00D84894: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  val_1, method:  System.Void Client.<Run>c__AnonStorey0::<>m__0()), ????);
        label_16:
        // 0x00D84898: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
        // 0x00D8489C: MOV x0, x24                | X0 = this.pc;//m1                       
        // 0x00D848A0: MOV x1, x22                | X1 = host;//m1                          
        // 0x00D848A4: MOV w2, w21                | W2 = port;//m1                          
        // 0x00D848A8: MOV x3, x25                | X3 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00D848AC: MOV x4, x20                | X4 = responseFun;//m1                   
        // 0x00D848B0: MOV x5, x19                | X5 = pushFun;//m1                       
        // 0x00D848B4: BL #0xc68048               | this.pc.initClient(host:  host, port:  port, callback:  null, responseFun:  responseFun, pushFun:  pushFun);
        this.pc.initClient(host:  host, port:  port, callback:  null, responseFun:  responseFun, pushFun:  pushFun);
        label_2:
        // 0x00D848B8: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00D848BC: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00D848C0: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00D848C4: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00D848C8: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00D848CC: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00D848D0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D84A8C (14174860), len: 256  VirtAddr: 0x00D84A8C RVA: 0x00D84A8C token: 100694573 methodIndex: 25976 delegateWrapperIndex: 0 methodInvoker: 0
    public void Request(string route, Newtonsoft.Json.Linq.JObject msg)
    {
        //
        // Disasemble & Code
        // 0x00D84A8C: STP x22, x21, [sp, #-0x30]! | stack[1152921515201723552] = ???;  stack[1152921515201723560] = ???;  //  dest_result_addr=1152921515201723552 |  dest_result_addr=1152921515201723560
        // 0x00D84A90: STP x20, x19, [sp, #0x10]  | stack[1152921515201723568] = ???;  stack[1152921515201723576] = ???;  //  dest_result_addr=1152921515201723568 |  dest_result_addr=1152921515201723576
        // 0x00D84A94: STP x29, x30, [sp, #0x20]  | stack[1152921515201723584] = ???;  stack[1152921515201723592] = ???;  //  dest_result_addr=1152921515201723584 |  dest_result_addr=1152921515201723592
        // 0x00D84A98: ADD x29, sp, #0x20         | X29 = (1152921515201723552 + 32) = 1152921515201723584 (0x100000027780FCC0);
        // 0x00D84A9C: SUB sp, sp, #0x10          | SP = (1152921515201723552 - 16) = 1152921515201723536 (0x100000027780FC90);
        // 0x00D84AA0: ADRP x22, #0x3734000       | X22 = 57884672 (0x3734000);             
        // 0x00D84AA4: LDRB w8, [x22, #0x432]     | W8 = (bool)static_value_03734432;       
        // 0x00D84AA8: MOV x19, x2                | X19 = msg;//m1                          
        // 0x00D84AAC: MOV x20, x1                | X20 = route;//m1                        
        // 0x00D84AB0: MOV x21, x0                | X21 = 1152921515201735600 (0x1000000277812BB0);//ML01
        // 0x00D84AB4: TBNZ w8, #0, #0xd84ad0     | if (static_value_03734432 == true) goto label_0;
        // 0x00D84AB8: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
        // 0x00D84ABC: LDR x8, [x8, #0xb68]       | X8 = 0x2B90B5C;                         
        // 0x00D84AC0: LDR w0, [x8]               | W0 = 0x199B;                            
        // 0x00D84AC4: BL #0x2782188              | X0 = sub_2782188( ?? 0x199B, ????);     
        // 0x00D84AC8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D84ACC: STRB w8, [x22, #0x432]     | static_value_03734432 = true;            //  dest_result_addr=57885746
        label_0:
        // 0x00D84AD0: LDR w8, [x21, #0x18]       | W8 = this.state; //P2                   
        // 0x00D84AD4: CMP w8, #2                 | STATE = COMPARE(this.state, 0x2)        
        // 0x00D84AD8: B.NE #0xd84b0c             | if (this.state != 0x2) goto label_1;    
        if(this.state != 2)
        {
            goto label_1;
        }
        // 0x00D84ADC: LDR x21, [x21, #0x10]      | X21 = this.pc; //P2                     
        // 0x00D84AE0: CBNZ x21, #0xd84ae8        | if (this.pc != null) goto label_2;      
        if(this.pc != null)
        {
            goto label_2;
        }
        // 0x00D84AE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x199B, ????);     
        label_2:
        // 0x00D84AE8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D84AEC: MOV x0, x21                | X0 = this.pc;//m1                       
        // 0x00D84AF0: MOV x1, x20                | X1 = route;//m1                         
        // 0x00D84AF4: MOV x2, x19                | X2 = msg;//m1                           
        // 0x00D84AF8: SUB sp, x29, #0x20         | SP = (1152921515201723584 - 32) = 1152921515201723552 (0x100000027780FCA0);
        // 0x00D84AFC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D84B00: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D84B04: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D84B08: B #0xc68d4c                | X0 = this.pc.request(route:  route, msg:  msg); return;
        uint val_1 = this.pc.request(route:  route, msg:  msg);
        return;
        label_1:
        // 0x00D84B0C: ADRP x9, #0x365a000        | X9 = 56991744 (0x365A000);              
        // 0x00D84B10: LDR x9, [x9, #0x800]       | X9 = 1152921504912650240;               
        // 0x00D84B14: ADD x1, sp, #0xc           | X1 = (1152921515201723536 + 12) = 1152921515201723548 (0x100000027780FC9C);
        // 0x00D84B18: STR w8, [sp, #0xc]         | stack[1152921515201723548] = this.state;  //  dest_result_addr=1152921515201723548
        // 0x00D84B1C: LDR x0, [x9]               | X0 = typeof(Pomelo.DotNetClient.NetWorkState);
        // 0x00D84B20: BL #0x27bc028              | X0 = 1152921515201783984 = (Il2CppObject*)Box((RuntimeClass*)typeof(Pomelo.DotNetClient.NetWorkState), this.state);
        // 0x00D84B24: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
        // 0x00D84B28: LDR x8, [x8, #0x48]        | X8 = (string**)(1152921515201707392)("网络连接状态不对 state：{0}");
        // 0x00D84B2C: MOV x2, x0                 | X2 = 1152921515201783984 (0x100000027781E8B0);//ML01
        // 0x00D84B30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D84B34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D84B38: LDR x1, [x8]               | X1 = "网络连接状态不对 state：{0}";              
        // 0x00D84B3C: BL #0x279525c              | X0 = EString.EFormat(format:  0, arg0:  "网络连接状态不对 state：{0}");
        string val_2 = EString.EFormat(format:  0, arg0:  "网络连接状态不对 state：{0}");
        // 0x00D84B40: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
        // 0x00D84B44: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
        // 0x00D84B48: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x00D84B4C: LDR x8, [x8]               | X8 = typeof(UnityEngine.Debug);         
        // 0x00D84B50: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Debug.__il2cppRuntimeField_10A;
        // 0x00D84B54: TBZ w9, #0, #0xd84b68      | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00D84B58: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
        // 0x00D84B5C: CBNZ w9, #0xd84b68         | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00D84B60: MOV x0, x8                 | X0 = 1152921504692469760 (0x10000000051A8000);//ML01
        // 0x00D84B64: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
        label_4:
        // 0x00D84B68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D84B6C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D84B70: MOV x1, x19                | X1 = val_2;//m1                         
        // 0x00D84B74: BL #0x1a5d154              | UnityEngine.Debug.Log(message:  0);     
        UnityEngine.Debug.Log(message:  0);
        // 0x00D84B78: SUB sp, x29, #0x20         | SP = (1152921515201723584 - 32) = 1152921515201723552 (0x100000027780FCA0);
        // 0x00D84B7C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D84B80: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D84B84: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D84B88: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D84B8C (14175116), len: 320  VirtAddr: 0x00D84B8C RVA: 0x00D84B8C token: 100694574 methodIndex: 25977 delegateWrapperIndex: 0 methodInvoker: 0
    public uint Request(string route, string msg)
    {
        //
        // Disasemble & Code
        // 0x00D84B8C: STP x22, x21, [sp, #-0x30]! | stack[1152921515201922592] = ???;  stack[1152921515201922600] = ???;  //  dest_result_addr=1152921515201922592 |  dest_result_addr=1152921515201922600
        // 0x00D84B90: STP x20, x19, [sp, #0x10]  | stack[1152921515201922608] = ???;  stack[1152921515201922616] = ???;  //  dest_result_addr=1152921515201922608 |  dest_result_addr=1152921515201922616
        // 0x00D84B94: STP x29, x30, [sp, #0x20]  | stack[1152921515201922624] = ???;  stack[1152921515201922632] = ???;  //  dest_result_addr=1152921515201922624 |  dest_result_addr=1152921515201922632
        // 0x00D84B98: ADD x29, sp, #0x20         | X29 = (1152921515201922592 + 32) = 1152921515201922624 (0x1000000277840640);
        // 0x00D84B9C: SUB sp, sp, #0x10          | SP = (1152921515201922592 - 16) = 1152921515201922576 (0x1000000277840610);
        // 0x00D84BA0: ADRP x22, #0x3734000       | X22 = 57884672 (0x3734000);             
        // 0x00D84BA4: LDRB w8, [x22, #0x433]     | W8 = (bool)static_value_03734433;       
        // 0x00D84BA8: MOV x21, x2                | X21 = msg;//m1                          
        // 0x00D84BAC: MOV x19, x1                | X19 = route;//m1                        
        // 0x00D84BB0: MOV x20, x0                | X20 = 1152921515201934640 (0x1000000277843530);//ML01
        // 0x00D84BB4: TBNZ w8, #0, #0xd84bd0     | if (static_value_03734433 == true) goto label_0;
        // 0x00D84BB8: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
        // 0x00D84BBC: LDR x8, [x8, #0xc50]       | X8 = 0x2B90B60;                         
        // 0x00D84BC0: LDR w0, [x8]               | W0 = 0x199C;                            
        // 0x00D84BC4: BL #0x2782188              | X0 = sub_2782188( ?? 0x199C, ????);     
        // 0x00D84BC8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D84BCC: STRB w8, [x22, #0x433]     | static_value_03734433 = true;            //  dest_result_addr=57885747
        label_0:
        // 0x00D84BD0: LDR w8, [x20, #0x18]       | W8 = this.state; //P2                   
        // 0x00D84BD4: CMP w8, #2                 | STATE = COMPARE(this.state, 0x2)        
        // 0x00D84BD8: B.NE #0xd84c48             | if (this.state != 0x2) goto label_1;    
        if(this.state != 2)
        {
            goto label_1;
        }
        // 0x00D84BDC: ADRP x8, #0x365c000        | X8 = 56999936 (0x365C000);              
        // 0x00D84BE0: LDR x8, [x8, #0x9c8]       | X8 = 1152921504859615232;               
        // 0x00D84BE4: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.JsonConvert);
        // 0x00D84BE8: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_10A;
        // 0x00D84BEC: TBZ w8, #0, #0xd84bfc      | if (Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00D84BF0: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_cctor_finished;
        // 0x00D84BF4: CBNZ w8, #0xd84bfc         | if (Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00D84BF8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.JsonConvert), ????);
        label_3:
        // 0x00D84BFC: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
        // 0x00D84C00: LDR x8, [x8, #0x578]       | X8 = 1152921515201860464;               
        // 0x00D84C04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D84C08: MOV x1, x21                | X1 = msg;//m1                           
        // 0x00D84C0C: LDR x2, [x8]               | X2 = public static Newtonsoft.Json.Linq.JObject Newtonsoft.Json.JsonConvert::DeserializeObject<Newtonsoft.Json.Linq.JObject>(string value);
        // 0x00D84C10: BL #0xfd9184               | X0 = Newtonsoft.Json.JsonConvert.DeserializeObject<VersionInfo[]>(value:  0);
        VersionInfo[] val_1 = Newtonsoft.Json.JsonConvert.DeserializeObject<VersionInfo[]>(value:  0);
        // 0x00D84C14: LDR x21, [x20, #0x10]      | X21 = this.pc; //P2                     
        // 0x00D84C18: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00D84C1C: CBNZ x21, #0xd84c24        | if (this.pc != null) goto label_4;      
        if(this.pc != null)
        {
            goto label_4;
        }
        // 0x00D84C20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00D84C24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D84C28: MOV x0, x21                | X0 = this.pc;//m1                       
        // 0x00D84C2C: MOV x1, x19                | X1 = route;//m1                         
        // 0x00D84C30: MOV x2, x20                | X2 = val_1;//m1                         
        // 0x00D84C34: SUB sp, x29, #0x20         | SP = (1152921515201922624 - 32) = 1152921515201922592 (0x1000000277840620);
        // 0x00D84C38: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D84C3C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D84C40: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D84C44: B #0xc68d4c                | return this.pc.request(route:  route, msg:  val_1);
        return this.pc.request(route:  route, msg:  val_1);
        label_1:
        // 0x00D84C48: ADRP x9, #0x365a000        | X9 = 56991744 (0x365A000);              
        // 0x00D84C4C: LDR x9, [x9, #0x800]       | X9 = 1152921504912650240;               
        // 0x00D84C50: ADD x1, sp, #0xc           | X1 = (1152921515201922576 + 12) = 1152921515201922588 (0x100000027784061C);
        // 0x00D84C54: STR w8, [sp, #0xc]         | stack[1152921515201922588] = this.state;  //  dest_result_addr=1152921515201922588
        // 0x00D84C58: LDR x0, [x9]               | X0 = typeof(Pomelo.DotNetClient.NetWorkState);
        // 0x00D84C5C: BL #0x27bc028              | X0 = 1152921515202019888 = (Il2CppObject*)Box((RuntimeClass*)typeof(Pomelo.DotNetClient.NetWorkState), this.state);
        // 0x00D84C60: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
        // 0x00D84C64: LDR x8, [x8, #0x48]        | X8 = (string**)(1152921515201707392)("网络连接状态不对 state：{0}");
        // 0x00D84C68: MOV x2, x0                 | X2 = 1152921515202019888 (0x1000000277858230);//ML01
        // 0x00D84C6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D84C70: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D84C74: LDR x1, [x8]               | X1 = "网络连接状态不对 state：{0}";              
        // 0x00D84C78: BL #0x279525c              | X0 = EString.EFormat(format:  0, arg0:  "网络连接状态不对 state：{0}");
        string val_2 = EString.EFormat(format:  0, arg0:  "网络连接状态不对 state：{0}");
        // 0x00D84C7C: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
        // 0x00D84C80: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
        // 0x00D84C84: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x00D84C88: LDR x8, [x8]               | X8 = typeof(UnityEngine.Debug);         
        // 0x00D84C8C: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Debug.__il2cppRuntimeField_10A;
        // 0x00D84C90: TBZ w9, #0, #0xd84ca4      | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00D84C94: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
        // 0x00D84C98: CBNZ w9, #0xd84ca4         | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00D84C9C: MOV x0, x8                 | X0 = 1152921504692469760 (0x10000000051A8000);//ML01
        // 0x00D84CA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
        label_6:
        // 0x00D84CA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D84CA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D84CAC: MOV x1, x19                | X1 = val_2;//m1                         
        // 0x00D84CB0: BL #0x1a5d154              | UnityEngine.Debug.Log(message:  0);     
        UnityEngine.Debug.Log(message:  0);
        // 0x00D84CB4: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        // 0x00D84CB8: SUB sp, x29, #0x20         | SP = (1152921515201922624 - 32) = 1152921515201922592 (0x1000000277840620);
        // 0x00D84CBC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D84CC0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D84CC4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D84CC8: RET                        |  return (System.UInt32)null;            
        return (uint)0;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D84CCC (14175436), len: 168  VirtAddr: 0x00D84CCC RVA: 0x00D84CCC token: 100694575 methodIndex: 25978 delegateWrapperIndex: 0 methodInvoker: 0
    public void Notify(string route, string msg)
    {
        //
        // Disasemble & Code
        // 0x00D84CCC: STP x22, x21, [sp, #-0x30]! | stack[1152921515202145184] = ???;  stack[1152921515202145192] = ???;  //  dest_result_addr=1152921515202145184 |  dest_result_addr=1152921515202145192
        // 0x00D84CD0: STP x20, x19, [sp, #0x10]  | stack[1152921515202145200] = ???;  stack[1152921515202145208] = ???;  //  dest_result_addr=1152921515202145200 |  dest_result_addr=1152921515202145208
        // 0x00D84CD4: STP x29, x30, [sp, #0x20]  | stack[1152921515202145216] = ???;  stack[1152921515202145224] = ???;  //  dest_result_addr=1152921515202145216 |  dest_result_addr=1152921515202145224
        // 0x00D84CD8: ADD x29, sp, #0x20         | X29 = (1152921515202145184 + 32) = 1152921515202145216 (0x1000000277876BC0);
        // 0x00D84CDC: ADRP x22, #0x3734000       | X22 = 57884672 (0x3734000);             
        // 0x00D84CE0: LDRB w8, [x22, #0x434]     | W8 = (bool)static_value_03734434;       
        // 0x00D84CE4: MOV x21, x2                | X21 = msg;//m1                          
        // 0x00D84CE8: MOV x19, x1                | X19 = route;//m1                        
        // 0x00D84CEC: MOV x20, x0                | X20 = 1152921515202157232 (0x1000000277879AB0);//ML01
        // 0x00D84CF0: TBNZ w8, #0, #0xd84d0c     | if (static_value_03734434 == true) goto label_0;
        // 0x00D84CF4: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
        // 0x00D84CF8: LDR x8, [x8, #0xb70]       | X8 = 0x2B90B50;                         
        // 0x00D84CFC: LDR w0, [x8]               | W0 = 0x1998;                            
        // 0x00D84D00: BL #0x2782188              | X0 = sub_2782188( ?? 0x1998, ????);     
        // 0x00D84D04: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D84D08: STRB w8, [x22, #0x434]     | static_value_03734434 = true;            //  dest_result_addr=57885748
        label_0:
        // 0x00D84D0C: ADRP x8, #0x365c000        | X8 = 56999936 (0x365C000);              
        // 0x00D84D10: LDR x8, [x8, #0x9c8]       | X8 = 1152921504859615232;               
        // 0x00D84D14: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.JsonConvert);
        // 0x00D84D18: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_10A;
        // 0x00D84D1C: TBZ w8, #0, #0xd84d2c      | if (Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D84D20: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_cctor_finished;
        // 0x00D84D24: CBNZ w8, #0xd84d2c         | if (Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D84D28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.JsonConvert), ????);
        label_2:
        // 0x00D84D2C: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
        // 0x00D84D30: LDR x8, [x8, #0x578]       | X8 = 1152921515201860464;               
        // 0x00D84D34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D84D38: MOV x1, x21                | X1 = msg;//m1                           
        // 0x00D84D3C: LDR x2, [x8]               | X2 = public static Newtonsoft.Json.Linq.JObject Newtonsoft.Json.JsonConvert::DeserializeObject<Newtonsoft.Json.Linq.JObject>(string value);
        // 0x00D84D40: BL #0xfd9184               | X0 = Newtonsoft.Json.JsonConvert.DeserializeObject<VersionInfo[]>(value:  0);
        VersionInfo[] val_1 = Newtonsoft.Json.JsonConvert.DeserializeObject<VersionInfo[]>(value:  0);
        // 0x00D84D44: LDR x21, [x20, #0x10]      | X21 = this.pc; //P2                     
        // 0x00D84D48: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00D84D4C: CBNZ x21, #0xd84d54        | if (this.pc != null) goto label_3;      
        if(this.pc != null)
        {
            goto label_3;
        }
        // 0x00D84D50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00D84D54: MOV x1, x19                | X1 = route;//m1                         
        // 0x00D84D58: MOV x2, x20                | X2 = val_1;//m1                         
        // 0x00D84D5C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D84D60: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D84D64: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D84D68: MOV x0, x21                | X0 = this.pc;//m1                       
        // 0x00D84D6C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D84D70: B #0xc6918c                | this.pc.notify(route:  route, msg:  val_1); return;
        this.pc.notify(route:  route, msg:  val_1);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D84D74 (14175604), len: 68  VirtAddr: 0x00D84D74 RVA: 0x00D84D74 token: 100694576 methodIndex: 25979 delegateWrapperIndex: 0 methodInvoker: 0
    public void Notify(string route, Newtonsoft.Json.Linq.JObject msg)
    {
        //
        // Disasemble & Code
        // 0x00D84D74: STP x22, x21, [sp, #-0x30]! | stack[1152921515202318624] = ???;  stack[1152921515202318632] = ???;  //  dest_result_addr=1152921515202318624 |  dest_result_addr=1152921515202318632
        // 0x00D84D78: STP x20, x19, [sp, #0x10]  | stack[1152921515202318640] = ???;  stack[1152921515202318648] = ???;  //  dest_result_addr=1152921515202318640 |  dest_result_addr=1152921515202318648
        // 0x00D84D7C: STP x29, x30, [sp, #0x20]  | stack[1152921515202318656] = ???;  stack[1152921515202318664] = ???;  //  dest_result_addr=1152921515202318656 |  dest_result_addr=1152921515202318664
        // 0x00D84D80: ADD x29, sp, #0x20         | X29 = (1152921515202318624 + 32) = 1152921515202318656 (0x10000002778A1140);
        // 0x00D84D84: LDR x21, [x0, #0x10]       | X21 = this.pc; //P2                     
        // 0x00D84D88: MOV x19, x2                | X19 = msg;//m1                          
        // 0x00D84D8C: MOV x20, x1                | X20 = route;//m1                        
        // 0x00D84D90: CBNZ x21, #0xd84d98        | if (this.pc != null) goto label_0;      
        if(this.pc != null)
        {
            goto label_0;
        }
        // 0x00D84D94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00D84D98: MOV x1, x20                | X1 = route;//m1                         
        // 0x00D84D9C: MOV x2, x19                | X2 = msg;//m1                           
        // 0x00D84DA0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D84DA4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D84DA8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D84DAC: MOV x0, x21                | X0 = this.pc;//m1                       
        // 0x00D84DB0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D84DB4: B #0xc6918c                | this.pc.notify(route:  route, msg:  msg); return;
        this.pc.notify(route:  route, msg:  msg);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D84DB8 (14175672), len: 784  VirtAddr: 0x00D84DB8 RVA: 0x00D84DB8 token: 100694577 methodIndex: 25980 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnStateChanged(Pomelo.DotNetClient.NetWorkState state)
    {
        //
        // Disasemble & Code
        //  | 
        var val_5;
        //  | 
        var val_6;
        //  | 
        var val_7;
        //  | 
        var val_8;
        //  | 
        var val_9;
        // 0x00D84DB8: STP x24, x23, [sp, #-0x40]! | stack[1152921515202467696] = ???;  stack[1152921515202467704] = ???;  //  dest_result_addr=1152921515202467696 |  dest_result_addr=1152921515202467704
        // 0x00D84DBC: STP x22, x21, [sp, #0x10]  | stack[1152921515202467712] = ???;  stack[1152921515202467720] = ???;  //  dest_result_addr=1152921515202467712 |  dest_result_addr=1152921515202467720
        // 0x00D84DC0: STP x20, x19, [sp, #0x20]  | stack[1152921515202467728] = ???;  stack[1152921515202467736] = ???;  //  dest_result_addr=1152921515202467728 |  dest_result_addr=1152921515202467736
        // 0x00D84DC4: STP x29, x30, [sp, #0x30]  | stack[1152921515202467744] = ???;  stack[1152921515202467752] = ???;  //  dest_result_addr=1152921515202467744 |  dest_result_addr=1152921515202467752
        // 0x00D84DC8: ADD x29, sp, #0x30         | X29 = (1152921515202467696 + 48) = 1152921515202467744 (0x10000002778C57A0);
        // 0x00D84DCC: SUB sp, sp, #0x10          | SP = (1152921515202467696 - 16) = 1152921515202467680 (0x10000002778C5760);
        // 0x00D84DD0: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D84DD4: LDRB w8, [x21, #0x435]     | W8 = (bool)static_value_03734435;       
        // 0x00D84DD8: MOV w19, w1                | W19 = state;//m1                        
        // 0x00D84DDC: MOV x20, x0                | X20 = 1152921515202479760 (0x10000002778C8690);//ML01
        // 0x00D84DE0: TBNZ w8, #0, #0xd84dfc     | if (static_value_03734435 == true) goto label_0;
        // 0x00D84DE4: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
        // 0x00D84DE8: LDR x8, [x8, #0x518]       | X8 = 0x2B90B58;                         
        // 0x00D84DEC: LDR w0, [x8]               | W0 = 0x199A;                            
        // 0x00D84DF0: BL #0x2782188              | X0 = sub_2782188( ?? 0x199A, ????);     
        // 0x00D84DF4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D84DF8: STRB w8, [x21, #0x435]     | static_value_03734435 = true;            //  dest_result_addr=57885749
        label_0:
        // 0x00D84DFC: ADRP x21, #0x3665000       | X21 = 57036800 (0x3665000);             
        // 0x00D84E00: LDR x21, [x21, #0xe98]     | X21 = 1152921504912703488;              
        // 0x00D84E04: LDR x0, [x21]              | X0 = typeof(Pomelo.DotNetClient.PomeloClient);
        val_5 = null;
        // 0x00D84E08: LDRB w8, [x0, #0x10a]      | W8 = Pomelo.DotNetClient.PomeloClient.__il2cppRuntimeField_10A;
        // 0x00D84E0C: TBZ w8, #0, #0xd84e20      | if (Pomelo.DotNetClient.PomeloClient.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D84E10: LDR w8, [x0, #0xbc]        | W8 = Pomelo.DotNetClient.PomeloClient.__il2cppRuntimeField_cctor_finished;
        // 0x00D84E14: CBNZ w8, #0xd84e20         | if (Pomelo.DotNetClient.PomeloClient.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D84E18: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pomelo.DotNetClient.PomeloClient), ????);
        // 0x00D84E1C: LDR x0, [x21]              | X0 = typeof(Pomelo.DotNetClient.PomeloClient);
        val_5 = null;
        label_2:
        // 0x00D84E20: ADRP x22, #0x35c3000       | X22 = 56373248 (0x35C3000);             
        // 0x00D84E24: LDR x8, [x0, #0xa0]        | X8 = Pomelo.DotNetClient.PomeloClient.__il2cppRuntimeField_static_fields;
        // 0x00D84E28: LDR x22, [x22, #0x258]     | X22 = 1152921504913874944;              
        // 0x00D84E2C: LDR w23, [x8]              | W23 = Pomelo.DotNetClient.PomeloClient.curSocketID;
        // 0x00D84E30: LDR x0, [x22]              | X0 = typeof(Pomelo.DotNetClient.Transporter);
        val_6 = null;
        // 0x00D84E34: LDRB w8, [x0, #0x10a]      | W8 = Pomelo.DotNetClient.Transporter.__il2cppRuntimeField_10A;
        // 0x00D84E38: TBZ w8, #0, #0xd84e4c      | if (Pomelo.DotNetClient.Transporter.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00D84E3C: LDR w8, [x0, #0xbc]        | W8 = Pomelo.DotNetClient.Transporter.__il2cppRuntimeField_cctor_finished;
        // 0x00D84E40: CBNZ w8, #0xd84e4c         | if (Pomelo.DotNetClient.Transporter.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00D84E44: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pomelo.DotNetClient.Transporter), ????);
        // 0x00D84E48: LDR x0, [x22]              | X0 = typeof(Pomelo.DotNetClient.Transporter);
        val_6 = null;
        label_4:
        // 0x00D84E4C: LDR x8, [x0, #0xa0]        | X8 = Pomelo.DotNetClient.Transporter.__il2cppRuntimeField_static_fields;
        // 0x00D84E50: LDR w8, [x8]               | W8 = Pomelo.DotNetClient.Transporter.currentSocketID;
        // 0x00D84E54: CMP w23, w8                | STATE = COMPARE(Pomelo.DotNetClient.PomeloClient.curSocketID, Pomelo.DotNetClient.Transporter.currentSocketID)
        // 0x00D84E58: B.EQ #0xd84e88             | if (Pomelo.DotNetClient.PomeloClient.curSocketID == Pomelo.DotNetClient.Transporter.currentSocketID) goto label_5;
        if(Pomelo.DotNetClient.PomeloClient.curSocketID == Pomelo.DotNetClient.Transporter.currentSocketID)
        {
            goto label_5;
        }
        // 0x00D84E5C: LDR x0, [x21]              | X0 = typeof(Pomelo.DotNetClient.PomeloClient);
        val_7 = null;
        // 0x00D84E60: LDRB w8, [x0, #0x10a]      | W8 = Pomelo.DotNetClient.PomeloClient.__il2cppRuntimeField_10A;
        // 0x00D84E64: TBZ w8, #0, #0xd84e78      | if (Pomelo.DotNetClient.PomeloClient.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x00D84E68: LDR w8, [x0, #0xbc]        | W8 = Pomelo.DotNetClient.PomeloClient.__il2cppRuntimeField_cctor_finished;
        // 0x00D84E6C: CBNZ w8, #0xd84e78         | if (Pomelo.DotNetClient.PomeloClient.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x00D84E70: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pomelo.DotNetClient.PomeloClient), ????);
        // 0x00D84E74: LDR x0, [x21]              | X0 = typeof(Pomelo.DotNetClient.PomeloClient);
        val_7 = null;
        label_7:
        // 0x00D84E78: LDR x8, [x0, #0xa0]        | X8 = Pomelo.DotNetClient.PomeloClient.__il2cppRuntimeField_static_fields;
        // 0x00D84E7C: LDP w9, w8, [x8]           | W9 = Pomelo.DotNetClient.PomeloClient.curSocketID; W8 = Pomelo.DotNetClient.PomeloClient.timeoutID; //  | 
        // 0x00D84E80: CMP w9, w8                 | STATE = COMPARE(Pomelo.DotNetClient.PomeloClient.curSocketID, Pomelo.DotNetClient.PomeloClient.timeoutID)
        // 0x00D84E84: B.NE #0xd84f24             | if (Pomelo.DotNetClient.PomeloClient.curSocketID != Pomelo.DotNetClient.PomeloClient.timeoutID) goto label_8;
        if(Pomelo.DotNetClient.PomeloClient.curSocketID != Pomelo.DotNetClient.PomeloClient.timeoutID)
        {
            goto label_8;
        }
        label_5:
        // 0x00D84E88: SUB w8, w19, #3            | W8 = (state - 3);                       
        Pomelo.DotNetClient.NetWorkState val_1 = state - 3;
        // 0x00D84E8C: STR w19, [x20, #0x18]      | this.state = state;                      //  dest_result_addr=1152921515202479784
        this.state = state;
        // 0x00D84E90: CMP w8, #2                 | STATE = COMPARE((state - 3), 0x2)       
        // 0x00D84E94: B.HI #0xd84e9c             | if (val_1 > 0x2) goto label_9;          
        if(val_1 > 2)
        {
            goto label_9;
        }
        // 0x00D84E98: BL #0xd850c8               | OnDisconnect();                         
        OnDisconnect();
        label_9:
        // 0x00D84E9C: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
        // 0x00D84EA0: LDR x8, [x8, #0x800]       | X8 = 1152921504912650240;               
        // 0x00D84EA4: ADD x1, sp, #0xc           | X1 = (1152921515202467680 + 12) = 1152921515202467692 (0x10000002778C576C);
        // 0x00D84EA8: STR w19, [sp, #0xc]        | stack[1152921515202467692] = state;      //  dest_result_addr=1152921515202467692
        // 0x00D84EAC: LDR x0, [x8]               | X0 = typeof(Pomelo.DotNetClient.NetWorkState);
        // 0x00D84EB0: BL #0x27bc028              | X0 = 1152921515202515856 = (Il2CppObject*)Box((RuntimeClass*)typeof(Pomelo.DotNetClient.NetWorkState), state);
        // 0x00D84EB4: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
        // 0x00D84EB8: LDR x8, [x8, #0x640]       | X8 = (string**)(1152921515202439152)("网络连接状态变更为：{0}");
        // 0x00D84EBC: MOV x2, x0                 | X2 = 1152921515202515856 (0x10000002778D1390);//ML01
        // 0x00D84EC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D84EC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D84EC8: LDR x1, [x8]               | X1 = "网络连接状态变更为：{0}";                   
        // 0x00D84ECC: BL #0x279525c              | X0 = EString.EFormat(format:  0, arg0:  "网络连接状态变更为：{0}");
        string val_2 = EString.EFormat(format:  0, arg0:  "网络连接状态变更为：{0}");
        // 0x00D84ED0: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00D84ED4: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00D84ED8: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x00D84EDC: LDR x8, [x8]               | X8 = typeof(EDebug);                    
        // 0x00D84EE0: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00D84EE4: TBZ w9, #0, #0xd84ef8      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00D84EE8: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00D84EEC: CBNZ w9, #0xd84ef8         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00D84EF0: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00D84EF4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_11:
        // 0x00D84EF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D84EFC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D84F00: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D84F04: MOV x1, x19                | X1 = val_2;//m1                         
        // 0x00D84F08: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_2);
        EDebug.Log(message:  0, isShowStack:  val_2);
        label_27:
        // 0x00D84F0C: SUB sp, x29, #0x30         | SP = (1152921515202467744 - 48) = 1152921515202467696 (0x10000002778C5770);
        // 0x00D84F10: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00D84F14: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00D84F18: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00D84F1C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00D84F20: RET                        |  return;                                
        return;
        label_8:
        // 0x00D84F24: CMP w19, #3                | STATE = COMPARE(state, 0x3)             
        // 0x00D84F28: B.NE #0xd84f0c             | if (state != 0x3) goto label_27;        
        if(state != 3)
        {
            goto label_27;
        }
        // 0x00D84F2C: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00D84F30: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00D84F34: LDR x19, [x8]              | X19 = typeof(System.Object[]);          
        // 0x00D84F38: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D84F3C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00D84F40: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00D84F44: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D84F48: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00D84F4C: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
        // 0x00D84F50: LDR x8, [x8, #0x800]       | X8 = 1152921504912650240;               
        // 0x00D84F54: MOV x19, x0                | X19 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D84F58: ORR w9, wzr, #3            | W9 = 3(0x3);                            
        // 0x00D84F5C: ADD x1, sp, #8             | X1 = (1152921515202467680 + 8) = 1152921515202467688 (0x10000002778C5768);
        // 0x00D84F60: LDR x8, [x8]               | X8 = typeof(Pomelo.DotNetClient.NetWorkState);
        // 0x00D84F64: STR w9, [sp, #8]           | stack[1152921515202467688] = 0x3;        //  dest_result_addr=1152921515202467688
        // 0x00D84F68: MOV x0, x8                 | X0 = 1152921504912650240 (0x10000000123A3000);//ML01
        // 0x00D84F6C: BL #0x27bc028              | X0 = 1152921515202524048 = (Il2CppObject*)Box((RuntimeClass*)typeof(Pomelo.DotNetClient.NetWorkState), 0x3);
        // 0x00D84F70: MOV x20, x0                | X20 = 1152921515202524048 (0x10000002778D3390);//ML01
        // 0x00D84F74: CBNZ x19, #0xd84f7c        | if ( != null) goto label_13;            
        if(null != null)
        {
            goto label_13;
        }
        // 0x00D84F78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3, ????);        
        label_13:
        // 0x00D84F7C: CBZ x20, #0xd84fa0         | if (0x3 == 0) goto label_15;            
        if(3 == 0)
        {
            goto label_15;
        }
        // 0x00D84F80: LDR x8, [x19]              | X8 = ;                                  
        // 0x00D84F84: MOV x0, x20                | X0 = 1152921515202524048 (0x10000002778D3390);//ML01
        // 0x00D84F88: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D84F8C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x3, ????);        
        // 0x00D84F90: CBNZ x0, #0xd84fa0         | if (0x3 != 0) goto label_15;            
        if(3 != 0)
        {
            goto label_15;
        }
        // 0x00D84F94: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 0x3, ????);        
        // 0x00D84F98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D84F9C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x3, ????);        
        label_15:
        // 0x00D84FA0: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00D84FA4: CBNZ w8, #0xd84fb4         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_16;
        // 0x00D84FA8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x3, ????);        
        // 0x00D84FAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D84FB0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x3, ????);        
        label_16:
        // 0x00D84FB4: STR x20, [x19, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = 0x3;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = 3;
        // 0x00D84FB8: LDR x0, [x21]              | X0 = typeof(Pomelo.DotNetClient.PomeloClient);
        val_8 = null;
        // 0x00D84FBC: LDRB w8, [x0, #0x10a]      | W8 = Pomelo.DotNetClient.PomeloClient.__il2cppRuntimeField_10A;
        // 0x00D84FC0: TBZ w8, #0, #0xd84fd4      | if (Pomelo.DotNetClient.PomeloClient.__il2cppRuntimeField_has_cctor == 0) goto label_18;
        // 0x00D84FC4: LDR w8, [x0, #0xbc]        | W8 = Pomelo.DotNetClient.PomeloClient.__il2cppRuntimeField_cctor_finished;
        // 0x00D84FC8: CBNZ w8, #0xd84fd4         | if (Pomelo.DotNetClient.PomeloClient.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
        // 0x00D84FCC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pomelo.DotNetClient.PomeloClient), ????);
        // 0x00D84FD0: LDR x0, [x21]              | X0 = typeof(Pomelo.DotNetClient.PomeloClient);
        val_8 = null;
        label_18:
        // 0x00D84FD4: LDR x8, [x0, #0xa0]        | X8 = Pomelo.DotNetClient.PomeloClient.__il2cppRuntimeField_static_fields;
        // 0x00D84FD8: LDR x0, [x22]              | X0 = typeof(Pomelo.DotNetClient.Transporter);
        val_9 = null;
        // 0x00D84FDC: LDR w20, [x8]              | W20 = Pomelo.DotNetClient.PomeloClient.curSocketID;
        // 0x00D84FE0: LDRB w8, [x0, #0x10a]      | W8 = Pomelo.DotNetClient.Transporter.__il2cppRuntimeField_10A;
        // 0x00D84FE4: TBZ w8, #0, #0xd84ff8      | if (Pomelo.DotNetClient.Transporter.__il2cppRuntimeField_has_cctor == 0) goto label_20;
        // 0x00D84FE8: LDR w8, [x0, #0xbc]        | W8 = Pomelo.DotNetClient.Transporter.__il2cppRuntimeField_cctor_finished;
        // 0x00D84FEC: CBNZ w8, #0xd84ff8         | if (Pomelo.DotNetClient.Transporter.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
        // 0x00D84FF0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pomelo.DotNetClient.Transporter), ????);
        // 0x00D84FF4: LDR x0, [x22]              | X0 = typeof(Pomelo.DotNetClient.Transporter);
        val_9 = null;
        label_20:
        // 0x00D84FF8: LDR x8, [x0, #0xa0]        | X8 = Pomelo.DotNetClient.Transporter.__il2cppRuntimeField_static_fields;
        // 0x00D84FFC: ADRP x9, #0x3626000        | X9 = 56778752 (0x3626000);              
        // 0x00D85000: ADD x1, sp, #7             | X1 = (1152921515202467680 + 7) = 1152921515202467687 (0x10000002778C5767);
        // 0x00D85004: LDR w8, [x8]               | W8 = Pomelo.DotNetClient.Transporter.currentSocketID;
        // 0x00D85008: LDR x9, [x9, #0x7d8]       | X9 = 1152921504608604160;               
        // 0x00D8500C: CMP w20, w8                | STATE = COMPARE(Pomelo.DotNetClient.PomeloClient.curSocketID, Pomelo.DotNetClient.Transporter.currentSocketID)
        // 0x00D85010: LDR x0, [x9]               | X0 = typeof(System.Boolean);            
        // 0x00D85014: CSET w8, eq                | W8 = Pomelo.DotNetClient.PomeloClient.curSocketID == Pomelo.DotNetClient.Transporter.currentSocketID ? 1 : 0;
        bool val_3 = (Pomelo.DotNetClient.PomeloClient.curSocketID == Pomelo.DotNetClient.Transporter.currentSocketID) ? 1 : 0;
        // 0x00D85018: STRB w8, [sp, #7]          | stack[1152921515202467687] = Pomelo.DotNetClient.PomeloClient.curSocketID == Pomelo.DotNetClient.Transporter.currentSocketID ? 1 : 0;  //  dest_result_addr=1152921515202467687
        // 0x00D8501C: BL #0x27bc028              | X0 = 1152921515202528144 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Boolean), Pomelo.DotNetClient.PomeloClient.curSocketID == Pomelo.DotNetClient.Transporter.currentSocketID ? 1 : 0);
        // 0x00D85020: MOV x20, x0                | X20 = 1152921515202528144 (0x10000002778D4390);//ML01
        // 0x00D85024: CBNZ x19, #0xd8502c        | if ( != null) goto label_21;            
        if(null != null)
        {
            goto label_21;
        }
        // 0x00D85028: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Pomelo.DotNetClient.PomeloClient.curSocketID == Pomelo.DotNetClient.Transporter.currentSocketID ? 1 : 0, ????);
        label_21:
        // 0x00D8502C: CBZ x20, #0xd85050         | if (Pomelo.DotNetClient.PomeloClient.curSocketID == Pomelo.DotNetClient.Transporter.currentSocketID ? 1 : 0 == false) goto label_23;
        if(val_3 == false)
        {
            goto label_23;
        }
        // 0x00D85030: LDR x8, [x19]              | X8 = ;                                  
        // 0x00D85034: MOV x0, x20                | X0 = 1152921515202528144 (0x10000002778D4390);//ML01
        // 0x00D85038: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D8503C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? Pomelo.DotNetClient.PomeloClient.curSocketID == Pomelo.DotNetClient.Transporter.currentSocketID ? 1 : 0, ????);
        // 0x00D85040: CBNZ x0, #0xd85050         | if (Pomelo.DotNetClient.PomeloClient.curSocketID == Pomelo.DotNetClient.Transporter.currentSocketID ? 1 : 0 == true) goto label_23;
        if(val_3 == true)
        {
            goto label_23;
        }
        // 0x00D85044: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? Pomelo.DotNetClient.PomeloClient.curSocketID == Pomelo.DotNetClient.Transporter.currentSocketID ? 1 : 0, ????);
        // 0x00D85048: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8504C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? Pomelo.DotNetClient.PomeloClient.curSocketID == Pomelo.DotNetClient.Transporter.currentSocketID ? 1 : 0, ????);
        label_23:
        // 0x00D85050: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00D85054: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00D85058: B.HI #0xd85068             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_24;
        // 0x00D8505C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? Pomelo.DotNetClient.PomeloClient.curSocketID == Pomelo.DotNetClient.Transporter.currentSocketID ? 1 : 0, ????);
        // 0x00D85060: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D85064: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? Pomelo.DotNetClient.PomeloClient.curSocketID == Pomelo.DotNetClient.Transporter.currentSocketID ? 1 : 0, ????);
        label_24:
        // 0x00D85068: STR x20, [x19, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = Pomelo.DotNetClient.PomeloClient.curSocketID == Pomelo.DotNetClient.Transporter.currentSocketID ? 1 : 0; typeof(System.Object[]).__il2cppRuntimeField_29 = 0x10000002778D43;  //  dest_result_addr=1152921504954501304 dest_result_addr=1152921504954501305
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_3;
        typeof(System.Object[]).__il2cppRuntimeField_29 = 41389379;
        // 0x00D8506C: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
        // 0x00D85070: LDR x8, [x8, #0x2b8]       | X8 = (string**)(1152921515202451536)("网络连接状态变更为：{0} isnew：{1}");
        // 0x00D85074: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D85078: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D8507C: MOV x2, x19                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D85080: LDR x1, [x8]               | X1 = "网络连接状态变更为：{0} isnew：{1}";         
        // 0x00D85084: BL #0x27952d8              | X0 = EString.EFormat(format:  0, args:  "网络连接状态变更为：{0} isnew：{1}");
        string val_4 = EString.EFormat(format:  0, args:  "网络连接状态变更为：{0} isnew：{1}");
        // 0x00D85088: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00D8508C: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00D85090: MOV x19, x0                | X19 = val_4;//m1                        
        // 0x00D85094: LDR x8, [x8]               | X8 = typeof(EDebug);                    
        // 0x00D85098: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00D8509C: TBZ w9, #0, #0xd850b0      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_26;
        // 0x00D850A0: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00D850A4: CBNZ w9, #0xd850b0         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_26;
        // 0x00D850A8: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00D850AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_26:
        // 0x00D850B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D850B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D850B8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D850BC: MOV x1, x19                | X1 = val_4;//m1                         
        // 0x00D850C0: BL #0xb5b538               | EDebug.LogError(message:  0, isShowStack:  val_4);
        EDebug.LogError(message:  0, isShowStack:  val_4);
        // 0x00D850C4: B #0xd84f0c                |  goto label_27;                         
        goto label_27;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D850C8 (14176456), len: 340  VirtAddr: 0x00D850C8 RVA: 0x00D850C8 token: 100694578 methodIndex: 25981 delegateWrapperIndex: 0 methodInvoker: 0
    public void OnDisconnect()
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        //  | 
        var val_3;
        // 0x00D850C8: STP x22, x21, [sp, #-0x30]! | stack[1152921515202605440] = ???;  stack[1152921515202605448] = ???;  //  dest_result_addr=1152921515202605440 |  dest_result_addr=1152921515202605448
        // 0x00D850CC: STP x20, x19, [sp, #0x10]  | stack[1152921515202605456] = ???;  stack[1152921515202605464] = ???;  //  dest_result_addr=1152921515202605456 |  dest_result_addr=1152921515202605464
        // 0x00D850D0: STP x29, x30, [sp, #0x20]  | stack[1152921515202605472] = ???;  stack[1152921515202605480] = ???;  //  dest_result_addr=1152921515202605472 |  dest_result_addr=1152921515202605480
        // 0x00D850D4: ADD x29, sp, #0x20         | X29 = (1152921515202605440 + 32) = 1152921515202605472 (0x10000002778E71A0);
        // 0x00D850D8: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
        // 0x00D850DC: LDRB w8, [x19, #0x436]     | W8 = (bool)static_value_03734436;       
        // 0x00D850E0: TBNZ w8, #0, #0xd850fc     | if (static_value_03734436 == true) goto label_0;
        // 0x00D850E4: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
        // 0x00D850E8: LDR x8, [x8, #0x410]       | X8 = 0x2B90B54;                         
        // 0x00D850EC: LDR w0, [x8]               | W0 = 0x1999;                            
        // 0x00D850F0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1999, ????);     
        // 0x00D850F4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D850F8: STRB w8, [x19, #0x436]     | static_value_03734436 = true;            //  dest_result_addr=57885750
        label_0:
        // 0x00D850FC: ADRP x21, #0x3631000       | X21 = 56823808 (0x3631000);             
        // 0x00D85100: LDR x21, [x21, #0x370]     | X21 = 1152921504912277504;              
        // 0x00D85104: LDR x0, [x21]              | X0 = typeof(Client);                    
        val_2 = null;
        // 0x00D85108: LDRB w8, [x0, #0x10a]      | W8 = Client.__il2cppRuntimeField_10A;   
        // 0x00D8510C: TBZ w8, #0, #0xd85120      | if (Client.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D85110: LDR w8, [x0, #0xbc]        | W8 = Client.__il2cppRuntimeField_cctor_finished;
        // 0x00D85114: CBNZ w8, #0xd85120         | if (Client.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D85118: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Client), ????);
        // 0x00D8511C: LDR x0, [x21]              | X0 = typeof(Client);                    
        val_2 = null;
        label_2:
        // 0x00D85120: LDR x8, [x0, #0xa0]        | X8 = Client.__il2cppRuntimeField_static_fields;
        // 0x00D85124: LDR x8, [x8, #0x10]        | X8 = Client.<>f__am$cache0;             
        // 0x00D85128: CBNZ x8, #0xd85184         | if (Client.<>f__am$cache0 != null) goto label_3;
        if((Client.<>f__am$cache0) != null)
        {
            goto label_3;
        }
        // 0x00D8512C: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
        // 0x00D85130: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
        // 0x00D85134: LDR x8, [x8, #0x158]       | X8 = 1152921515202592336;               
        // 0x00D85138: LDR x9, [x9, #0xbe0]       | X9 = 1152921504687837184;               
        // 0x00D8513C: LDR x20, [x8]              | X20 = static System.Void Client::<OnDisconnect>m__0();
        // 0x00D85140: LDR x0, [x9]               | X0 = typeof(System.Action);             
        System.Action val_1 = null;
        // 0x00D85144: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00D85148: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8514C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D85150: MOV x2, x20                | X2 = 1152921515202592336 (0x10000002778E3E50);//ML01
        // 0x00D85154: MOV x19, x0                | X19 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00D85158: BL #0x26e30f0              | .ctor(object:  0, method:  static System.Void Client::<OnDisconnect>m__0());
        val_1 = new System.Action(object:  0, method:  static System.Void Client::<OnDisconnect>m__0());
        // 0x00D8515C: LDR x0, [x21]              | X0 = typeof(Client);                    
        val_3 = null;
        // 0x00D85160: LDRB w8, [x0, #0x10a]      | W8 = Client.__il2cppRuntimeField_10A;   
        // 0x00D85164: TBZ w8, #0, #0xd85178      | if (Client.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00D85168: LDR w8, [x0, #0xbc]        | W8 = Client.__il2cppRuntimeField_cctor_finished;
        // 0x00D8516C: CBNZ w8, #0xd85178         | if (Client.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00D85170: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Client), ????);
        // 0x00D85174: LDR x0, [x21]              | X0 = typeof(Client);                    
        val_3 = null;
        label_5:
        // 0x00D85178: LDR x8, [x0, #0xa0]        | X8 = Client.__il2cppRuntimeField_static_fields;
        // 0x00D8517C: STR x19, [x8, #0x10]       | Client.<>f__am$cache0 = typeof(System.Action);  //  dest_result_addr=1152921504912281616
        Client.<>f__am$cache0 = val_1;
        // 0x00D85180: LDR x0, [x21]              | X0 = typeof(Client);                    
        val_2 = null;
        label_3:
        // 0x00D85184: LDRB w8, [x0, #0x10a]      | W8 = Client.__il2cppRuntimeField_10A;   
        // 0x00D85188: TBZ w8, #0, #0xd8519c      | if (Client.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x00D8518C: LDR w8, [x0, #0xbc]        | W8 = Client.__il2cppRuntimeField_cctor_finished;
        // 0x00D85190: CBNZ w8, #0xd8519c         | if (Client.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x00D85194: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Client), ????);
        // 0x00D85198: LDR x0, [x21]              | X0 = typeof(Client);                    
        val_2 = null;
        label_7:
        // 0x00D8519C: ADRP x9, #0x35c5000        | X9 = 56381440 (0x35C5000);              
        // 0x00D851A0: LDR x8, [x0, #0xa0]        | X8 = Client.__il2cppRuntimeField_static_fields;
        // 0x00D851A4: LDR x9, [x9, #0xa8]        | X9 = 1152921504922021888;               
        // 0x00D851A8: LDR x19, [x8, #0x10]       | X19 = typeof(System.Action);            
        // 0x00D851AC: LDR x0, [x9]               | X0 = typeof(WaitMainThread);            
        // 0x00D851B0: LDRB w8, [x0, #0x10a]      | W8 = WaitMainThread.__il2cppRuntimeField_10A;
        // 0x00D851B4: TBZ w8, #0, #0xd851c4      | if (WaitMainThread.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x00D851B8: LDR w8, [x0, #0xbc]        | W8 = WaitMainThread.__il2cppRuntimeField_cctor_finished;
        // 0x00D851BC: CBNZ w8, #0xd851c4         | if (WaitMainThread.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x00D851C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(WaitMainThread), ????);
        label_9:
        // 0x00D851C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D851C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D851CC: MOV x1, x19                | X1 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00D851D0: BL #0xe15e48               | WaitMainThread.Wait(waitCallBack:  0);  
        WaitMainThread.Wait(waitCallBack:  0);
        // 0x00D851D4: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00D851D8: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00D851DC: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00D851E0: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00D851E4: TBZ w8, #0, #0xd851f4      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00D851E8: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00D851EC: CBNZ w8, #0xd851f4         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00D851F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_11:
        // 0x00D851F4: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
        // 0x00D851F8: LDR x8, [x8, #0x7c0]       | X8 = (string**)(1152921515202593360)("与服务器连接断开,可能是网络状态不好或账号在别处登陆");
        // 0x00D851FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D85200: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D85204: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D85208: LDR x1, [x8]               | X1 = "与服务器连接断开,可能是网络状态不好或账号在别处登陆";      
        // 0x00D8520C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D85210: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D85214: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D85218: B #0xb45c10                | EDebug.Log(message:  0, isShowStack:  true); return;
        EDebug.Log(message:  0, isShowStack:  true);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D8521C (14176796), len: 64  VirtAddr: 0x00D8521C RVA: 0x00D8521C token: 100694579 methodIndex: 25982 delegateWrapperIndex: 0 methodInvoker: 0
    public void Logout()
    {
        //
        // Disasemble & Code
        // 0x00D8521C: LDR w8, [x0, #0x18]        | W8 = this.state; //P2                   
        Pomelo.DotNetClient.NetWorkState val_1 = this.state;
        // 0x00D85220: SUB w8, w8, #1             | W8 = (this.state - 1);                  
        val_1 = val_1 - 1;
        // 0x00D85224: CMP w8, #1                 | STATE = COMPARE((this.state - 1), 0x1)  
        // 0x00D85228: B.HI #0xd85258             | if (this.state > 0x1) goto label_0;     
        if(val_1 > 1)
        {
            goto label_0;
        }
        // 0x00D8522C: STP x20, x19, [sp, #-0x20]! | stack[1152921515202725648] = ???;  stack[1152921515202725656] = ???;  //  dest_result_addr=1152921515202725648 |  dest_result_addr=1152921515202725656
        // 0x00D85230: STP x29, x30, [sp, #0x10]  | stack[1152921515202725664] = ???;  stack[1152921515202725672] = ???;  //  dest_result_addr=1152921515202725664 |  dest_result_addr=1152921515202725672
        // 0x00D85234: ADD x29, sp, #0x10         | X29 = (1152921515202725648 + 16) = 1152921515202725664 (0x1000000277904720);
        // 0x00D85238: LDR x19, [x0, #0x10]       | X19 = this.pc; //P2                     
        // 0x00D8523C: CBNZ x19, #0xd85244        | if (this.pc != null) goto label_1;      
        if(this.pc != null)
        {
            goto label_1;
        }
        // 0x00D85240: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_1:
        // 0x00D85244: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D85248: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8524C: MOV x0, x19                | X0 = this.pc;//m1                       
        // 0x00D85250: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D85254: B #0xc69880                | this.pc.Logout(); return;               
        this.pc.Logout();
        return;
        label_0:
        // 0x00D85258: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D8525C (14176860), len: 100  VirtAddr: 0x00D8525C RVA: 0x00D8525C token: 100694580 methodIndex: 25983 delegateWrapperIndex: 0 methodInvoker: 0
    private static Client()
    {
        //
        // Disasemble & Code
        // 0x00D8525C: STP x20, x19, [sp, #-0x20]! | stack[1152921515202845840] = ???;  stack[1152921515202845848] = ???;  //  dest_result_addr=1152921515202845840 |  dest_result_addr=1152921515202845848
        // 0x00D85260: STP x29, x30, [sp, #0x10]  | stack[1152921515202845856] = ???;  stack[1152921515202845864] = ???;  //  dest_result_addr=1152921515202845856 |  dest_result_addr=1152921515202845864
        // 0x00D85264: ADD x29, sp, #0x10         | X29 = (1152921515202845840 + 16) = 1152921515202845856 (0x1000000277921CA0);
        // 0x00D85268: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
        // 0x00D8526C: LDRB w8, [x19, #0x437]     | W8 = (bool)static_value_03734437;       
        // 0x00D85270: TBNZ w8, #0, #0xd8528c     | if (static_value_03734437 == true) goto label_0;
        // 0x00D85274: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
        // 0x00D85278: LDR x8, [x8, #0x9f0]       | X8 = 0x2B90B18;                         
        // 0x00D8527C: LDR w0, [x8]               | W0 = 0x198A;                            
        // 0x00D85280: BL #0x2782188              | X0 = sub_2782188( ?? 0x198A, ????);     
        // 0x00D85284: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D85288: STRB w8, [x19, #0x437]     | static_value_03734437 = true;            //  dest_result_addr=57885751
        label_0:
        // 0x00D8528C: ADRP x20, #0x3631000       | X20 = 56823808 (0x3631000);             
        // 0x00D85290: LDR x20, [x20, #0x370]     | X20 = 1152921504912277504;              
        // 0x00D85294: LDR x0, [x20]              | X0 = typeof(Client);                    
        object val_1 = null;
        // 0x00D85298: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Client), ????);
        // 0x00D8529C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D852A0: MOV x19, x0                | X19 = 1152921504912277504 (0x1000000012348000);//ML01
        // 0x00D852A4: BL #0x16f59f0              | .ctor();                                
        val_1 = new System.Object();
        // 0x00D852A8: LDR x8, [x20]              | X8 = typeof(Client);                    
        // 0x00D852AC: LDR x8, [x8, #0xa0]        | X8 = Client.__il2cppRuntimeField_static_fields;
        // 0x00D852B0: STR x19, [x8]              | Client.instance = typeof(Client);        //  dest_result_addr=1152921504912281600
        Client.instance = val_1;
        // 0x00D852B4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D852B8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D852BC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D852C0 (14176960), len: 140  VirtAddr: 0x00D852C0 RVA: 0x00D852C0 token: 100694581 methodIndex: 25984 delegateWrapperIndex: 0 methodInvoker: 0
    private static void <OnDisconnect>m__0()
    {
        //
        // Disasemble & Code
        // 0x00D852C0: STP x20, x19, [sp, #-0x20]! | stack[1152921515202957840] = ???;  stack[1152921515202957848] = ???;  //  dest_result_addr=1152921515202957840 |  dest_result_addr=1152921515202957848
        // 0x00D852C4: STP x29, x30, [sp, #0x10]  | stack[1152921515202957856] = ???;  stack[1152921515202957864] = ???;  //  dest_result_addr=1152921515202957856 |  dest_result_addr=1152921515202957864
        // 0x00D852C8: ADD x29, sp, #0x10         | X29 = (1152921515202957840 + 16) = 1152921515202957856 (0x100000027793D220);
        // 0x00D852CC: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
        // 0x00D852D0: LDRB w8, [x19, #0x438]     | W8 = (bool)static_value_03734438;       
        // 0x00D852D4: TBNZ w8, #0, #0xd852f0     | if (static_value_03734438 == true) goto label_0;
        // 0x00D852D8: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
        // 0x00D852DC: LDR x8, [x8, #0x7a0]       | X8 = 0x2B90B68;                         
        // 0x00D852E0: LDR w0, [x8]               | W0 = 0x199E;                            
        // 0x00D852E4: BL #0x2782188              | X0 = sub_2782188( ?? 0x199E, ????);     
        // 0x00D852E8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D852EC: STRB w8, [x19, #0x438]     | static_value_03734438 = true;            //  dest_result_addr=57885752
        label_0:
        // 0x00D852F0: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00D852F4: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
        // 0x00D852F8: LDR x0, [x8]               | X0 = typeof(CEvent.ZEvent);             
        object val_1 = null;
        // 0x00D852FC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
        // 0x00D85300: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00D85304: LDR x8, [x8, #0xa80]       | X8 = (string**)(1152921510322321104)("NetWork_DISCONNECTED");
        // 0x00D85308: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8530C: MOV x19, x0                | X19 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00D85310: LDR x20, [x8]              | X20 = "NetWork_DISCONNECTED";           
        // 0x00D85314: BL #0x16f59f0              | .ctor();                                
        val_1 = new System.Object();
        // 0x00D85318: STR x20, [x19, #0x10]      | typeof(CEvent.ZEvent).__il2cppRuntimeField_10 = "NetWork_DISCONNECTED";  //  dest_result_addr=1152921504898326544
        typeof(CEvent.ZEvent).__il2cppRuntimeField_10 = "NetWork_DISCONNECTED";
        // 0x00D8531C: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00D85320: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00D85324: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00D85328: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00D8532C: TBZ w8, #0, #0xd8533c      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D85330: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00D85334: CBNZ w8, #0xd8533c         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D85338: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_2:
        // 0x00D8533C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D85340: MOV x1, x19                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00D85344: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D85348: B #0xd7de90                | CEvent.ZEventCenter.DispatchEvent(ev:  null); return;
        CEvent.ZEventCenter.DispatchEvent(ev:  null);
        return;
    
    }

}
