using UnityEngine;

namespace Pathfinding.Ionic.Zip
{
    public enum CompressionMethod
    {
        // Fields
        None = 0
        ,Deflate = 8
        
    
    }

}
