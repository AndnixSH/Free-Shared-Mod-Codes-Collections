using UnityEngine;
public class AIEventInfo
{
    // Fields
    public AIObject aiObj; //  0x00000010
    public npcAIConditionCfg condition; //  0x00000018
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B21260 (11670112), len: 8  VirtAddr: 0x00B21260 RVA: 0x00B21260 token: 100691848 methodIndex: 24718 delegateWrapperIndex: 0 methodInvoker: 0
    public AIEventInfo()
    {
        //
        // Disasemble & Code
        // 0x00B21260: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B21264: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }

}
