using UnityEngine;

namespace ILRuntime.Mono.Cecil.Cil
{
    public sealed class ConstantDebugInformation : DebugInformation
    {
        // Fields
        private string name; //  0x00000020
        private ILRuntime.Mono.Cecil.TypeReference constant_type; //  0x00000028
        private object value; //  0x00000030
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E5BE44 (15056452), len: 216  VirtAddr: 0x00E5BE44 RVA: 0x00E5BE44 token: 100664761 methodIndex: 19395 delegateWrapperIndex: 0 methodInvoker: 0
        public ConstantDebugInformation(string name, ILRuntime.Mono.Cecil.TypeReference constant_type, object value)
        {
            //
            // Disasemble & Code
            // 0x00E5BE44: STP x24, x23, [sp, #-0x40]! | stack[1152921509594088336] = ???;  stack[1152921509594088344] = ???;  //  dest_result_addr=1152921509594088336 |  dest_result_addr=1152921509594088344
            // 0x00E5BE48: STP x22, x21, [sp, #0x10]  | stack[1152921509594088352] = ???;  stack[1152921509594088360] = ???;  //  dest_result_addr=1152921509594088352 |  dest_result_addr=1152921509594088360
            // 0x00E5BE4C: STP x20, x19, [sp, #0x20]  | stack[1152921509594088368] = ???;  stack[1152921509594088376] = ???;  //  dest_result_addr=1152921509594088368 |  dest_result_addr=1152921509594088376
            // 0x00E5BE50: STP x29, x30, [sp, #0x30]  | stack[1152921509594088384] = ???;  stack[1152921509594088392] = ???;  //  dest_result_addr=1152921509594088384 |  dest_result_addr=1152921509594088392
            // 0x00E5BE54: ADD x29, sp, #0x30         | X29 = (1152921509594088336 + 48) = 1152921509594088384 (0x10000001294343C0);
            // 0x00E5BE58: SUB sp, sp, #0x10          | SP = (1152921509594088336 - 16) = 1152921509594088320 (0x1000000129434380);
            // 0x00E5BE5C: ADRP x23, #0x3734000       | X23 = 57884672 (0x3734000);             
            // 0x00E5BE60: LDRB w8, [x23, #0xaed]     | W8 = (bool)static_value_03734AED;       
            // 0x00E5BE64: MOV x20, x3                | X20 = value;//m1                        
            // 0x00E5BE68: MOV x21, x2                | X21 = constant_type;//m1                
            // 0x00E5BE6C: MOV x22, x1                | X22 = name;//m1                         
            // 0x00E5BE70: MOV x19, x0                | X19 = 1152921509594100400 (0x10000001294372B0);//ML01
            // 0x00E5BE74: TBNZ w8, #0, #0xe5be90     | if (static_value_03734AED == true) goto label_0;
            // 0x00E5BE78: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x00E5BE7C: LDR x8, [x8, #0x9d8]       | X8 = 0x2B92800;                         
            // 0x00E5BE80: LDR w0, [x8]               | W0 = 0x20C5;                            
            // 0x00E5BE84: BL #0x2782188              | X0 = sub_2782188( ?? 0x20C5, ????);     
            // 0x00E5BE88: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5BE8C: STRB w8, [x23, #0xaed]     | static_value_03734AED = true;            //  dest_result_addr=57887469
            label_0:
            // 0x00E5BE90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E5BE94: MOV x0, x19                | X0 = 1152921509594100400 (0x10000001294372B0);//ML01
            // 0x00E5BE98: BL #0x16f59f0              | constant_type..ctor();                  
            val_1 = new System.Object();
            // 0x00E5BE9C: CBZ x22, #0xe5bedc         | if (name == null) goto label_1;         
            if(name == null)
            {
                goto label_1;
            }
            // 0x00E5BEA0: ADD x0, sp, #8             | X0 = (1152921509594088320 + 8) = 1152921509594088328 (0x1000000129434388);
            // 0x00E5BEA4: MOVZ w1, #0x3400, lsl #16  | W1 = 872415232 (0x34000000);//ML01      
            // 0x00E5BEA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E5BEAC: STP x22, x21, [x19, #0x20] | this.name = name;  this.constant_type = constant_type;  //  dest_result_addr=1152921509594100432 |  dest_result_addr=1152921509594100440
            this.name = name;
            this.constant_type = val_1;
            // 0x00E5BEB0: STR x20, [x19, #0x30]      | this.value = value;                      //  dest_result_addr=1152921509594100448
            this.value = value;
            // 0x00E5BEB4: STR wzr, [sp, #8]          | stack[1152921509594088328] = 0x0;        //  dest_result_addr=1152921509594088328
            // 0x00E5BEB8: BL #0x11d58e4              | null..ctor(value:  0);                  
            ProtoBuf.SubItemToken val_2 = new ProtoBuf.SubItemToken(value:  0);
            // 0x00E5BEBC: LDR w8, [sp, #8]           | W8 = val_2.value;                       
            // 0x00E5BEC0: STR w8, [x19, #0x10]       | mem[1152921509594100416] = val_2.value;  //  dest_result_addr=1152921509594100416
            mem[1152921509594100416] = val_2.value;
            // 0x00E5BEC4: SUB sp, x29, #0x30         | SP = (1152921509594088384 - 48) = 1152921509594088336 (0x1000000129434390);
            // 0x00E5BEC8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5BECC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5BED0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00E5BED4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00E5BED8: RET                        |  return;                                
            return;
            label_1:
            // 0x00E5BEDC: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00E5BEE0: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x00E5BEE4: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            System.ArgumentNullException val_3 = null;
            // 0x00E5BEE8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x00E5BEEC: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
            // 0x00E5BEF0: LDR x8, [x8, #0x5f0]       | X8 = (string**)(1152921509593945888)("name");
            // 0x00E5BEF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E5BEF8: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x00E5BEFC: LDR x1, [x8]               | X1 = "name";                            
            // 0x00E5BF00: BL #0x18b3df0              | .ctor(paramName:  "name");              
            val_3 = new System.ArgumentNullException(paramName:  "name");
            // 0x00E5BF04: ADRP x8, #0x35d0000        | X8 = 56426496 (0x35D0000);              
            // 0x00E5BF08: LDR x8, [x8, #0x148]       | X8 = 1152921509594075376;               
            // 0x00E5BF0C: MOV x0, x19                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x00E5BF10: LDR x1, [x8]               | X1 = public System.Void ILRuntime.Mono.Cecil.Cil.ConstantDebugInformation::.ctor(string name, ILRuntime.Mono.Cecil.TypeReference constant_type, object value);
            // 0x00E5BF14: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentNullException), ????);
            // 0x00E5BF18: BL #0xe53e30               | X0 = sub_E53E30( ?? typeof(System.ArgumentNullException), ????);
        
        }
    
    }

}
