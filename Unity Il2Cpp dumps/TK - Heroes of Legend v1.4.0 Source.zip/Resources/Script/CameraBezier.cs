using UnityEngine;
public class CameraBezier : MonoBehaviour
{
    // Fields
    public const string CAMERASHOT_MOVE_COMPLETE = "CAMERASHOT_MOVE_COMPLETE";
    public System.Collections.Generic.List<UnityEngine.Vector3> points; //  0x00000018
    public System.Collections.Generic.List<UnityEngine.Vector3> rotations; //  0x00000020
    public System.Collections.Generic.List<float> rotSpeed; //  0x00000028
    public System.Collections.Generic.List<int> isClockWise; //  0x00000030
    public System.Collections.Generic.List<float> speed; //  0x00000038
    public System.Collections.Generic.List<UnityEngine.GameObject> focus; //  0x00000040
    public System.Collections.Generic.List<int> isHero; //  0x00000048
    public System.Collections.Generic.List<float> smooth; //  0x00000050
    public System.Collections.Generic.List<float> view; //  0x00000058
    public System.Collections.Generic.List<float> bright; //  0x00000060
    public System.Collections.Generic.List<float> orthographic; //  0x00000068
    public System.Collections.Generic.List<int> isConstant; //  0x00000070
    public int cameraShotDoneId; //  0x00000078
    private UnityEngine.Vector3 rot_Temp; //  0x0000007C
    public bool isStopCameraShot; //  0x00000088
    public bool isLerp; //  0x00000089
    public float overageSpeed; //  0x0000008C
    public float lerpInterval; //  0x00000090
    private float currentMoveSpeed; //  0x00000094
    private UnityEngine.Vector3 currentEulerAngleSpeed; //  0x00000098
    private bool isCurrentIntervalDown; //  0x000000A4
    public bool isAllDown; //  0x000000A5
    private float defaultSpeed; //  0x000000A8
    private float defaultfocus; //  0x000000AC
    private float defaultIsHero; //  0x000000B0
    private float defaultSmooth; //  0x000000B4
    private float defaultView; //  0x000000B8
    private float defaultBright; //  0x000000BC
    private float defaultOrthographic; //  0x000000C0
    private int pt; //  0x000000C4
    private float time; //  0x000000C8
    private int timeInt; //  0x000000CC
    private float newTime; //  0x000000D0
    private float t; //  0x000000D4
    private bool isRoted; //  0x000000D8
    private float time2; //  0x000000DC
    private int time_I; //  0x000000E0
    private float time_F; //  0x000000E4
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BA7804 (12220420), len: 496  VirtAddr: 0x00BA7804 RVA: 0x00BA7804 token: 100682705 methodIndex: 25667 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraBezier()
    {
        //
        // Disasemble & Code
        // 0x00BA7804: STP x24, x23, [sp, #-0x40]! | stack[1152921513302159696] = ???;  stack[1152921513302159704] = ???;  //  dest_result_addr=1152921513302159696 |  dest_result_addr=1152921513302159704
        // 0x00BA7808: STP x22, x21, [sp, #0x10]  | stack[1152921513302159712] = ???;  stack[1152921513302159720] = ???;  //  dest_result_addr=1152921513302159712 |  dest_result_addr=1152921513302159720
        // 0x00BA780C: STP x20, x19, [sp, #0x20]  | stack[1152921513302159728] = ???;  stack[1152921513302159736] = ???;  //  dest_result_addr=1152921513302159728 |  dest_result_addr=1152921513302159736
        // 0x00BA7810: STP x29, x30, [sp, #0x30]  | stack[1152921513302159744] = ???;  stack[1152921513302159752] = ???;  //  dest_result_addr=1152921513302159744 |  dest_result_addr=1152921513302159752
        // 0x00BA7814: ADD x29, sp, #0x30         | X29 = (1152921513302159696 + 48) = 1152921513302159744 (0x100000020647F180);
        // 0x00BA7818: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA781C: LDRB w8, [x20, #0xaeb]     | W8 = (bool)static_value_03733AEB;       
        // 0x00BA7820: MOV x19, x0                | X19 = 1152921513302171760 (0x1000000206482070);//ML01
        // 0x00BA7824: TBNZ w8, #0, #0xba7840     | if (static_value_03733AEB == true) goto label_0;
        // 0x00BA7828: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
        // 0x00BA782C: LDR x8, [x8, #0xf0]        | X8 = 0x2B90160;                         
        // 0x00BA7830: LDR w0, [x8]               | W0 = 0x171C;                            
        // 0x00BA7834: BL #0x2782188              | X0 = sub_2782188( ?? 0x171C, ????);     
        // 0x00BA7838: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA783C: STRB w8, [x20, #0xaeb]     | static_value_03733AEB = true;            //  dest_result_addr=57883371
        label_0:
        // 0x00BA7840: ADRP x21, #0x3641000       | X21 = 56889344 (0x3641000);             
        // 0x00BA7844: LDR x21, [x21, #0x968]     | X21 = 1152921504616644608;              
        // 0x00BA7848: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<UnityEngine.Vector3> val_1 = null;
        // 0x00BA784C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00BA7850: ADRP x22, #0x35c2000       | X22 = 56369152 (0x35C2000);             
        // 0x00BA7854: LDR x22, [x22, #0xe90]     | X22 = 1152921510909820656;              
        // 0x00BA7858: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00BA785C: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<UnityEngine.Vector3>::.ctor();
        // 0x00BA7860: BL #0x263edc8              | .ctor();                                
        val_1 = new System.Collections.Generic.List<UnityEngine.Vector3>();
        // 0x00BA7864: STR x20, [x19, #0x18]      | this.points = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513302171784
        this.points = val_1;
        // 0x00BA7868: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<UnityEngine.Vector3> val_2 = null;
        // 0x00BA786C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00BA7870: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<UnityEngine.Vector3>::.ctor();
        // 0x00BA7874: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00BA7878: BL #0x263edc8              | .ctor();                                
        val_2 = new System.Collections.Generic.List<UnityEngine.Vector3>();
        // 0x00BA787C: STR x20, [x19, #0x20]      | this.rotations = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513302171792
        this.rotations = val_2;
        // 0x00BA7880: ADRP x21, #0x35ba000       | X21 = 56336384 (0x35BA000);             
        // 0x00BA7884: LDR x21, [x21, #0x590]     | X21 = 1152921504616644608;              
        // 0x00BA7888: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<System.Single> val_3 = null;
        // 0x00BA788C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00BA7890: ADRP x22, #0x3639000       | X22 = 56856576 (0x3639000);             
        // 0x00BA7894: LDR x22, [x22, #0x6d0]     | X22 = 1152921510889998672;              
        // 0x00BA7898: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00BA789C: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<System.Single>::.ctor();
        // 0x00BA78A0: BL #0x25f69e4              | .ctor();                                
        val_3 = new System.Collections.Generic.List<System.Single>();
        // 0x00BA78A4: STR x20, [x19, #0x28]      | this.rotSpeed = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513302171800
        this.rotSpeed = val_3;
        // 0x00BA78A8: ADRP x23, #0x365a000       | X23 = 56991744 (0x365A000);             
        // 0x00BA78AC: LDR x23, [x23, #0x1c0]     | X23 = 1152921504616644608;              
        // 0x00BA78B0: LDR x0, [x23]              | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<System.Int32> val_4 = null;
        // 0x00BA78B4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00BA78B8: ADRP x24, #0x360c000       | X24 = 56672256 (0x360C000);             
        // 0x00BA78BC: LDR x24, [x24, #0x268]     | X24 = 1152921510015557168;              
        // 0x00BA78C0: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00BA78C4: LDR x1, [x24]              | X1 = public System.Void System.Collections.Generic.List<System.Int32>::.ctor();
        // 0x00BA78C8: BL #0x25e0ae0              | .ctor();                                
        val_4 = new System.Collections.Generic.List<System.Int32>();
        // 0x00BA78CC: STR x20, [x19, #0x30]      | this.isClockWise = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513302171808
        this.isClockWise = val_4;
        // 0x00BA78D0: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<System.Single> val_5 = null;
        // 0x00BA78D4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00BA78D8: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<System.Single>::.ctor();
        // 0x00BA78DC: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00BA78E0: BL #0x25f69e4              | .ctor();                                
        val_5 = new System.Collections.Generic.List<System.Single>();
        // 0x00BA78E4: STR x20, [x19, #0x38]      | this.speed = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513302171816
        this.speed = val_5;
        // 0x00BA78E8: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
        // 0x00BA78EC: LDR x8, [x8, #0x458]       | X8 = 1152921504616644608;               
        // 0x00BA78F0: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<UnityEngine.GameObject> val_6 = null;
        // 0x00BA78F4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00BA78F8: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
        // 0x00BA78FC: LDR x8, [x8, #0x710]       | X8 = 1152921510861577776;               
        // 0x00BA7900: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00BA7904: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<UnityEngine.GameObject>::.ctor();
        // 0x00BA7908: BL #0x25e9474              | .ctor();                                
        val_6 = new System.Collections.Generic.List<UnityEngine.GameObject>();
        // 0x00BA790C: STR x20, [x19, #0x40]      | this.focus = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513302171824
        this.focus = val_6;
        // 0x00BA7910: LDR x0, [x23]              | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<System.Int32> val_7 = null;
        // 0x00BA7914: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00BA7918: LDR x1, [x24]              | X1 = public System.Void System.Collections.Generic.List<System.Int32>::.ctor();
        // 0x00BA791C: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00BA7920: BL #0x25e0ae0              | .ctor();                                
        val_7 = new System.Collections.Generic.List<System.Int32>();
        // 0x00BA7924: STR x20, [x19, #0x48]      | this.isHero = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513302171832
        this.isHero = val_7;
        // 0x00BA7928: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<System.Single> val_8 = null;
        // 0x00BA792C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00BA7930: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<System.Single>::.ctor();
        // 0x00BA7934: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00BA7938: BL #0x25f69e4              | .ctor();                                
        val_8 = new System.Collections.Generic.List<System.Single>();
        // 0x00BA793C: STR x20, [x19, #0x50]      | this.smooth = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513302171840
        this.smooth = val_8;
        // 0x00BA7940: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<System.Single> val_9 = null;
        // 0x00BA7944: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00BA7948: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<System.Single>::.ctor();
        // 0x00BA794C: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00BA7950: BL #0x25f69e4              | .ctor();                                
        val_9 = new System.Collections.Generic.List<System.Single>();
        // 0x00BA7954: STR x20, [x19, #0x58]      | this.view = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513302171848
        this.view = val_9;
        // 0x00BA7958: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<System.Single> val_10 = null;
        // 0x00BA795C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00BA7960: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<System.Single>::.ctor();
        // 0x00BA7964: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00BA7968: BL #0x25f69e4              | .ctor();                                
        val_10 = new System.Collections.Generic.List<System.Single>();
        // 0x00BA796C: STR x20, [x19, #0x60]      | this.bright = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513302171856
        this.bright = val_10;
        // 0x00BA7970: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<System.Single> val_11 = null;
        // 0x00BA7974: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00BA7978: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<System.Single>::.ctor();
        // 0x00BA797C: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00BA7980: BL #0x25f69e4              | .ctor();                                
        val_11 = new System.Collections.Generic.List<System.Single>();
        // 0x00BA7984: STR x20, [x19, #0x68]      | this.orthographic = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513302171864
        this.orthographic = val_11;
        // 0x00BA7988: LDR x0, [x23]              | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<System.Int32> val_12 = null;
        // 0x00BA798C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00BA7990: LDR x1, [x24]              | X1 = public System.Void System.Collections.Generic.List<System.Int32>::.ctor();
        // 0x00BA7994: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00BA7998: BL #0x25e0ae0              | .ctor();                                
        val_12 = new System.Collections.Generic.List<System.Int32>();
        // 0x00BA799C: ADRP x8, #0x2a93000        | X8 = 44642304 (0x2A93000);              
        // 0x00BA79A0: LDR q0, [x8, #0x20]        | Q0 = ;                                  
        // 0x00BA79A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA79A8: STRB w8, [x19, #0x89]      | this.isLerp = true;                      //  dest_result_addr=1152921513302171897
        this.isLerp = true;
        // 0x00BA79AC: MOVZ w8, #0x41f0, lsl #16  | W8 = 1106247680 (0x41F00000);//ML01     
        // 0x00BA79B0: STR w8, [x19, #0x8c]       | this.overageSpeed = 30;                  //  dest_result_addr=1152921513302171900
        this.overageSpeed = 30f;
        // 0x00BA79B4: MOVZ w8, #0x3da3, lsl #16  | W8 = 1034092544 (0x3DA30000);//ML01     
        // 0x00BA79B8: MOVK w8, #0xd70a           | W8 = 1034147594 (0x3DA3D70A);           
        // 0x00BA79BC: STR w8, [x19, #0x90]       | this.lerpInterval = 0.08;                //  dest_result_addr=1152921513302171904
        this.lerpInterval = 0.08f;
        // 0x00BA79C0: MOVZ w8, #0x447a, lsl #16  | W8 = 1148846080 (0x447A0000);//ML01     
        // 0x00BA79C4: STR w8, [x19, #0xa8]       | this.defaultSpeed = 1000;                //  dest_result_addr=1152921513302171928
        this.defaultSpeed = 1000f;
        // 0x00BA79C8: MOVZ w8, #0xbf80, lsl #16  | W8 = 3212836864 (0xBF800000);//ML01     
        // 0x00BA79CC: STR w8, [x19, #0xc0]       | this.defaultOrthographic = -1;           //  dest_result_addr=1152921513302171952
        this.defaultOrthographic = -1f;
        // 0x00BA79D0: STR x20, [x19, #0x70]      | this.isConstant = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513302171872
        this.isConstant = val_12;
        // 0x00BA79D4: STUR q0, [x19, #0xac]      | this.defaultfocus = ; this.defaultIsHero = ; this.defaultSmooth = 1; this.defaultView = 51.2;  //  dest_result_addr=1152921513302171932 dest_result_addr=1152921513302171936 dest_result_addr=1152921513302171940 dest_result_addr=1152921513302171944
        this.defaultfocus = ;
        this.defaultIsHero = ;
        this.defaultSmooth = 1f;
        this.defaultView = 51.2f;
        // 0x00BA79D8: MOV x0, x19                | X0 = 1152921513302171760 (0x1000000206482070);//ML01
        // 0x00BA79DC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA79E0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA79E4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA79E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA79EC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00BA79F0: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA79F4 (12220916), len: 248  VirtAddr: 0x00BA79F4 RVA: 0x00BA79F4 token: 100682706 methodIndex: 25668 delegateWrapperIndex: 0 methodInvoker: 0
    private void Start()
    {
        //
        // Disasemble & Code
        // 0x00BA79F4: STP d11, d10, [sp, #-0x40]! | stack[1152921513302279888] = ???;  stack[1152921513302279896] = ???;  //  dest_result_addr=1152921513302279888 |  dest_result_addr=1152921513302279896
        // 0x00BA79F8: STP d9, d8, [sp, #0x10]    | stack[1152921513302279904] = ???;  stack[1152921513302279912] = ???;  //  dest_result_addr=1152921513302279904 |  dest_result_addr=1152921513302279912
        // 0x00BA79FC: STP x20, x19, [sp, #0x20]  | stack[1152921513302279920] = ???;  stack[1152921513302279928] = ???;  //  dest_result_addr=1152921513302279920 |  dest_result_addr=1152921513302279928
        // 0x00BA7A00: STP x29, x30, [sp, #0x30]  | stack[1152921513302279936] = ???;  stack[1152921513302279944] = ???;  //  dest_result_addr=1152921513302279936 |  dest_result_addr=1152921513302279944
        // 0x00BA7A04: ADD x29, sp, #0x30         | X29 = (1152921513302279888 + 48) = 1152921513302279936 (0x100000020649C700);
        // 0x00BA7A08: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA7A0C: LDRB w8, [x20, #0xaec]     | W8 = (bool)static_value_03733AEC;       
        // 0x00BA7A10: MOV x19, x0                | X19 = 1152921513302291952 (0x100000020649F5F0);//ML01
        // 0x00BA7A14: TBNZ w8, #0, #0xba7a30     | if (static_value_03733AEC == true) goto label_0;
        // 0x00BA7A18: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x00BA7A1C: LDR x8, [x8, #0x370]       | X8 = 0x2B90178;                         
        // 0x00BA7A20: LDR w0, [x8]               | W0 = 0x1722;                            
        // 0x00BA7A24: BL #0x2782188              | X0 = sub_2782188( ?? 0x1722, ????);     
        // 0x00BA7A28: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA7A2C: STRB w8, [x20, #0xaec]     | static_value_03733AEC = true;            //  dest_result_addr=57883372
        label_0:
        // 0x00BA7A30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA7A34: MOV x0, x19                | X0 = 1152921513302291952 (0x100000020649F5F0);//ML01
        // 0x00BA7A38: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_1 = this.transform;
        // 0x00BA7A3C: LDR x20, [x19, #0x20]      | X20 = this.rotations; //P2              
        // 0x00BA7A40: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00BA7A44: CBNZ x20, #0xba7a4c        | if (this.rotations != null) goto label_1;
        if(this.rotations != null)
        {
            goto label_1;
        }
        // 0x00BA7A48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x00BA7A4C: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
        // 0x00BA7A50: LDR x8, [x8, #0x1f0]       | X8 = 1152921510909481968;               
        // 0x00BA7A54: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BA7A58: MOV x0, x20                | X0 = this.rotations;//m1                
        // 0x00BA7A5C: LDR x2, [x8]               | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA7A60: BL #0x264334c              | X0 = this.rotations.get_Item(index:  0);
        UnityEngine.Vector3 val_2 = this.rotations.Item[0];
        // 0x00BA7A64: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00BA7A68: LDR x8, [x8, #0xd78]       | X8 = 1152921504695132160;               
        // 0x00BA7A6C: MOV v8.16b, v0.16b         | V8 = val_2.x;//m1                       
        // 0x00BA7A70: MOV v9.16b, v1.16b         | V9 = val_2.y;//m1                       
        // 0x00BA7A74: MOV v10.16b, v2.16b        | V10 = val_2.z;//m1                      
        // 0x00BA7A78: LDR x0, [x8]               | X0 = typeof(UnityEngine.Quaternion);    
        // 0x00BA7A7C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_10A;
        // 0x00BA7A80: TBZ w8, #0, #0xba7a90      | if (UnityEngine.Quaternion.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00BA7A84: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00BA7A88: CBNZ w8, #0xba7a90         | if (UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00BA7A8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Quaternion), ????);
        label_3:
        // 0x00BA7A90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA7A94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA7A98: MOV v0.16b, v8.16b         | V0 = val_2.x;//m1                       
        // 0x00BA7A9C: MOV v1.16b, v9.16b         | V1 = val_2.y;//m1                       
        // 0x00BA7AA0: MOV v2.16b, v10.16b        | V2 = val_2.z;//m1                       
        // 0x00BA7AA4: BL #0x1b7f628              | X0 = UnityEngine.Quaternion.Euler(euler:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z});
        UnityEngine.Quaternion val_3 = UnityEngine.Quaternion.Euler(euler:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z});
        // 0x00BA7AA8: MOV v8.16b, v0.16b         | V8 = val_3.x;//m1                       
        // 0x00BA7AAC: MOV v9.16b, v1.16b         | V9 = val_3.y;//m1                       
        // 0x00BA7AB0: MOV v10.16b, v2.16b        | V10 = val_3.z;//m1                      
        // 0x00BA7AB4: MOV v11.16b, v3.16b        | V11 = val_3.w;//m1                      
        // 0x00BA7AB8: CBNZ x19, #0xba7ac0        | if (val_1 != null) goto label_4;        
        if(val_1 != null)
        {
            goto label_4;
        }
        // 0x00BA7ABC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_4:
        // 0x00BA7AC0: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x00BA7AC4: MOV v0.16b, v8.16b         | V0 = val_3.x;//m1                       
        // 0x00BA7AC8: MOV v1.16b, v9.16b         | V1 = val_3.y;//m1                       
        // 0x00BA7ACC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA7AD0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA7AD4: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00BA7AD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA7ADC: MOV v2.16b, v10.16b        | V2 = val_3.z;//m1                       
        // 0x00BA7AE0: MOV v3.16b, v11.16b        | V3 = val_3.w;//m1                       
        // 0x00BA7AE4: LDP d11, d10, [sp], #0x40  | D11 = ; D10 = ;                          //  | 
        // 0x00BA7AE8: B #0x26938b0               | val_1.set_rotation(value:  new UnityEngine.Quaternion() {x = val_3.x, y = val_3.y, z = val_3.z, w = val_3.w}); return;
        val_1.rotation = new UnityEngine.Quaternion() {x = val_3.x, y = val_3.y, z = val_3.z, w = val_3.w};
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA7AEC (12221164), len: 236  VirtAddr: 0x00BA7AEC RVA: 0x00BA7AEC token: 100682707 methodIndex: 25669 delegateWrapperIndex: 0 methodInvoker: 0
    private void FixedUpdate()
    {
        //
        // Disasemble & Code
        // 0x00BA7AEC: STP x20, x19, [sp, #-0x20]! | stack[1152921513302404336] = ???;  stack[1152921513302404344] = ???;  //  dest_result_addr=1152921513302404336 |  dest_result_addr=1152921513302404344
        // 0x00BA7AF0: STP x29, x30, [sp, #0x10]  | stack[1152921513302404352] = ???;  stack[1152921513302404360] = ???;  //  dest_result_addr=1152921513302404352 |  dest_result_addr=1152921513302404360
        // 0x00BA7AF4: ADD x29, sp, #0x10         | X29 = (1152921513302404336 + 16) = 1152921513302404352 (0x10000002064BAD00);
        // 0x00BA7AF8: SUB sp, sp, #0x10          | SP = (1152921513302404336 - 16) = 1152921513302404320 (0x10000002064BACE0);
        // 0x00BA7AFC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA7B00: LDRB w8, [x20, #0xaed]     | W8 = (bool)static_value_03733AED;       
        // 0x00BA7B04: MOV x19, x0                | X19 = 1152921513302416368 (0x10000002064BDBF0);//ML01
        // 0x00BA7B08: TBNZ w8, #0, #0xba7b24     | if (static_value_03733AED == true) goto label_0;
        // 0x00BA7B0C: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
        // 0x00BA7B10: LDR x8, [x8, #0x638]       | X8 = 0x2B9016C;                         
        // 0x00BA7B14: LDR w0, [x8]               | W0 = 0x171F;                            
        // 0x00BA7B18: BL #0x2782188              | X0 = sub_2782188( ?? 0x171F, ????);     
        // 0x00BA7B1C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA7B20: STRB w8, [x20, #0xaed]     | static_value_03733AED = true;            //  dest_result_addr=57883373
        label_0:
        // 0x00BA7B24: LDRB w8, [x19, #0xa5]      | W8 = this.isAllDown; //P2               
        // 0x00BA7B28: CBNZ w8, #0xba7b34         | if (this.isAllDown == true) goto label_1;
        if(this.isAllDown == true)
        {
            goto label_1;
        }
        // 0x00BA7B2C: LDRB w8, [x19, #0x88]      | W8 = this.isStopCameraShot; //P2        
        // 0x00BA7B30: CBZ w8, #0xba7bc4          | if (this.isStopCameraShot == false) goto label_2;
        if(this.isStopCameraShot == false)
        {
            goto label_2;
        }
        label_1:
        // 0x00BA7B34: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
        // 0x00BA7B38: LDR w8, [x19, #0x78]       | W8 = this.cameraShotDoneId; //P2        
        // 0x00BA7B3C: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
        // 0x00BA7B40: ADD x1, sp, #0xc           | X1 = (1152921513302404320 + 12) = 1152921513302404332 (0x10000002064BACEC);
        // 0x00BA7B44: STR w8, [sp, #0xc]         | stack[1152921513302404332] = this.cameraShotDoneId;  //  dest_result_addr=1152921513302404332
        // 0x00BA7B48: LDR x0, [x9]               | X0 = typeof(System.Int32);              
        // 0x00BA7B4C: BL #0x27bc028              | X0 = 1152921513302448368 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), this.cameraShotDoneId);
        // 0x00BA7B50: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00BA7B54: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
        // 0x00BA7B58: MOV x20, x0                | X20 = 1152921513302448368 (0x10000002064C58F0);//ML01
        // 0x00BA7B5C: LDR x8, [x8]               | X8 = typeof(CEvent.ZEvent);             
        // 0x00BA7B60: MOV x0, x8                 | X0 = 1152921504898326528 (0x10000000115FA000);//ML01
        CEvent.ZEvent val_1 = null;
        // 0x00BA7B64: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
        // 0x00BA7B68: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
        // 0x00BA7B6C: LDR x8, [x8, #0x560]       | X8 = (string**)(1152921513302392240)("CAMERASHOT_MOVE_COMPLETE");
        // 0x00BA7B70: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA7B74: MOV x2, x20                | X2 = 1152921513302448368 (0x10000002064C58F0);//ML01
        // 0x00BA7B78: MOV x19, x0                | X19 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00BA7B7C: LDR x1, [x8]               | X1 = "CAMERASHOT_MOVE_COMPLETE";        
        // 0x00BA7B80: BL #0xd7de54               | .ctor(name:  "CAMERASHOT_MOVE_COMPLETE", arg:  this.cameraShotDoneId);
        val_1 = new CEvent.ZEvent(name:  "CAMERASHOT_MOVE_COMPLETE", arg:  this.cameraShotDoneId);
        // 0x00BA7B84: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00BA7B88: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00BA7B8C: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00BA7B90: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00BA7B94: TBZ w8, #0, #0xba7ba4      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00BA7B98: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00BA7B9C: CBNZ w8, #0xba7ba4         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00BA7BA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_4:
        // 0x00BA7BA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA7BA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA7BAC: MOV x1, x19                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00BA7BB0: BL #0xd7de90               | CEvent.ZEventCenter.DispatchEvent(ev:  0);
        CEvent.ZEventCenter.DispatchEvent(ev:  0);
        // 0x00BA7BB4: SUB sp, x29, #0x10         | SP = (1152921513302404352 - 16) = 1152921513302404336 (0x10000002064BACF0);
        // 0x00BA7BB8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA7BBC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA7BC0: RET                        |  return;                                
        return;
        label_2:
        // 0x00BA7BC4: MOV x0, x19                | X0 = 1152921513302416368 (0x10000002064BDBF0);//ML01
        // 0x00BA7BC8: SUB sp, x29, #0x10         | SP = (1152921513302404352 - 16) = 1152921513302404336 (0x10000002064BACF0);
        // 0x00BA7BCC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA7BD0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA7BD4: B #0xba7bd8                | this.Move(); return;                    
        this.Move();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA7BD8 (12221400), len: 3304  VirtAddr: 0x00BA7BD8 RVA: 0x00BA7BD8 token: 100682708 methodIndex: 25670 delegateWrapperIndex: 0 methodInvoker: 0
    private void Move()
    {
        //
        // Disasemble & Code
        //  | 
        var val_87;
        //  | 
        var val_88;
        //  | 
        var val_89;
        //  | 
        var val_93;
        //  | 
        float val_94;
        //  | 
        var val_95;
        //  | 
        float val_96;
        //  | 
        float val_97;
        //  | 
        var val_98;
        //  | 
        var val_99;
        //  | 
        float val_100;
        //  | 
        float val_101;
        //  | 
        float val_102;
        //  | 
        float val_103;
        //  | 
        float val_104;
        //  | 
        float val_105;
        //  | 
        var val_106;
        //  | 
        int val_107;
        //  | 
        float val_108;
        //  | 
        var val_109;
        //  | 
        var val_110;
        //  | 
        var val_111;
        //  | 
        var val_112;
        //  | 
        float val_113;
        //  | 
        float val_114;
        //  | 
        var val_115;
        //  | 
        var val_116;
        // 0x00BA7BD8: STP d15, d14, [sp, #-0x90]! | stack[1152921513302729216] = ???;  stack[1152921513302729224] = ???;  //  dest_result_addr=1152921513302729216 |  dest_result_addr=1152921513302729224
        // 0x00BA7BDC: STP d13, d12, [sp, #0x10]  | stack[1152921513302729232] = ???;  stack[1152921513302729240] = ???;  //  dest_result_addr=1152921513302729232 |  dest_result_addr=1152921513302729240
        // 0x00BA7BE0: STP d11, d10, [sp, #0x20]  | stack[1152921513302729248] = ???;  stack[1152921513302729256] = ???;  //  dest_result_addr=1152921513302729248 |  dest_result_addr=1152921513302729256
        // 0x00BA7BE4: STP d9, d8, [sp, #0x30]    | stack[1152921513302729264] = ???;  stack[1152921513302729272] = ???;  //  dest_result_addr=1152921513302729264 |  dest_result_addr=1152921513302729272
        // 0x00BA7BE8: STP x26, x25, [sp, #0x40]  | stack[1152921513302729280] = ???;  stack[1152921513302729288] = ???;  //  dest_result_addr=1152921513302729280 |  dest_result_addr=1152921513302729288
        // 0x00BA7BEC: STP x24, x23, [sp, #0x50]  | stack[1152921513302729296] = ???;  stack[1152921513302729304] = ???;  //  dest_result_addr=1152921513302729296 |  dest_result_addr=1152921513302729304
        // 0x00BA7BF0: STP x22, x21, [sp, #0x60]  | stack[1152921513302729312] = ???;  stack[1152921513302729320] = ???;  //  dest_result_addr=1152921513302729312 |  dest_result_addr=1152921513302729320
        // 0x00BA7BF4: STP x20, x19, [sp, #0x70]  | stack[1152921513302729328] = ???;  stack[1152921513302729336] = ???;  //  dest_result_addr=1152921513302729328 |  dest_result_addr=1152921513302729336
        // 0x00BA7BF8: STP x29, x30, [sp, #0x80]  | stack[1152921513302729344] = ???;  stack[1152921513302729352] = ???;  //  dest_result_addr=1152921513302729344 |  dest_result_addr=1152921513302729352
        // 0x00BA7BFC: ADD x29, sp, #0x80         | X29 = (1152921513302729216 + 128) = 1152921513302729344 (0x100000020650A280);
        // 0x00BA7C00: SUB sp, sp, #0x30          | SP = (1152921513302729216 - 48) = 1152921513302729168 (0x100000020650A1D0);
        // 0x00BA7C04: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA7C08: LDRB w8, [x20, #0xaee]     | W8 = (bool)static_value_03733AEE;       
        // 0x00BA7C0C: MOV x19, x0                | X19 = 1152921513302741360 (0x100000020650D170);//ML01
        val_93 = this;
        // 0x00BA7C10: TBNZ w8, #0, #0xba7c2c     | if (static_value_03733AEE == true) goto label_0;
        // 0x00BA7C14: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
        // 0x00BA7C18: LDR x8, [x8, #0xa58]       | X8 = 0x2B90170;                         
        // 0x00BA7C1C: LDR w0, [x8]               | W0 = 0x1720;                            
        // 0x00BA7C20: BL #0x2782188              | X0 = sub_2782188( ?? 0x1720, ????);     
        // 0x00BA7C24: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA7C28: STRB w8, [x20, #0xaee]     | static_value_03733AEE = true;            //  dest_result_addr=57883374
        label_0:
        // 0x00BA7C2C: MOV x0, x19                | X0 = 1152921513302741360 (0x100000020650D170);//ML01
        // 0x00BA7C30: BL #0xba88c0               | this.CheckProcess();                    
        this.CheckProcess();
        // 0x00BA7C34: LDR s8, [x19, #0xc8]       | S8 = this.time; //P2                    
        // 0x00BA7C38: LDR w9, [x19, #0xcc]       | W9 = this.timeInt; //P2                 
        // 0x00BA7C3C: FCVTZS w8, s8              | W8 = (int)(this.time);                  
        // 0x00BA7C40: CMP w8, w9                 | STATE = COMPARE(this.time, this.timeInt)
        // 0x00BA7C44: B.EQ #0xba7c50             | if ((int)this.time == this.timeInt) goto label_1;
        if((int)this.time == this.timeInt)
        {
            goto label_1;
        }
        // 0x00BA7C48: STP w8, wzr, [x19, #0xcc]  | this.timeInt = this.time;  this.newTime = 0;  //  dest_result_addr=1152921513302741564 |  dest_result_addr=1152921513302741568
        this.timeInt = (int)this.time;
        this.newTime = 0f;
        // 0x00BA7C4C: STRB wzr, [x19, #0xd8]     | this.isRoted = false;                    //  dest_result_addr=1152921513302741576
        this.isRoted = false;
        label_1:
        // 0x00BA7C50: LDR x20, [x19, #0x68]      | X20 = this.orthographic; //P2           
        // 0x00BA7C54: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA7C58: CBNZ x21, #0xba7c60        | if (this.points != null) goto label_2;  
        if(this.points != null)
        {
            goto label_2;
        }
        // 0x00BA7C5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_2:
        // 0x00BA7C60: ADRP x23, #0x35fc000       | X23 = 56606720 (0x35FC000);             
        // 0x00BA7C64: LDR x23, [x23, #0x5e0]     | X23 = 1152921510909311600;              
        // 0x00BA7C68: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA7C6C: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00BA7C70: BL #0x2643344              | X0 = this.points.get_Count();           
        int val_1 = this.points.Count;
        // 0x00BA7C74: MOV w21, w0                | W21 = val_1;//m1                        
        // 0x00BA7C78: CBNZ x20, #0xba7c80        | if (this.orthographic != null) goto label_3;
        if(this.orthographic != null)
        {
            goto label_3;
        }
        // 0x00BA7C7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00BA7C80: FMOV s10, #1.00000000      | S10 = 1;                                
        val_94 = 1f;
        // 0x00BA7C84: FADD s0, s8, s10           | S0 = (this.time + val_94);              
        float val_2 = this.time + val_94;
        // 0x00BA7C88: SCVTF s1, w21              | S1 = (float)(val_1);                    
        // 0x00BA7C8C: BL #0x9803a0               | X0 = sub_9803A0( ?? val_1, ????);       
        // 0x00BA7C90: ADRP x24, #0x35e2000       | X24 = 56500224 (0x35E2000);             
        // 0x00BA7C94: LDR x24, [x24, #0xbb0]     | X24 = 1152921510888574288;              
        // 0x00BA7C98: FCVTZS w1, s0              | W1 = (int)((this.time + val_94));       
        // 0x00BA7C9C: MOV x0, x20                | X0 = this.orthographic;//m1             
        // 0x00BA7CA0: LDR x2, [x24]              | X2 = public System.Single System.Collections.Generic.List<System.Single>::get_Item(int index);
        // 0x00BA7CA4: BL #0x25fad28              | X0 = this.orthographic.get_Item(index:  (int)val_2);
        float val_3 = this.orthographic.Item[(int)val_2];
        // 0x00BA7CA8: ADRP x25, #0x35e6000       | X25 = 56516608 (0x35E6000);             
        // 0x00BA7CAC: LDR x25, [x25, #0xce8]     | X25 = 1152921504608444416;              
        // 0x00BA7CB0: ADD x1, sp, #0x14          | X1 = (1152921513302729168 + 20) = 1152921513302729188 (0x100000020650A1E4);
        // 0x00BA7CB4: STR s0, [sp, #0x14]        | stack[1152921513302729188] = val_3;      //  dest_result_addr=1152921513302729188
        // 0x00BA7CB8: LDR x0, [x25]              | X0 = typeof(System.Single);             
        // 0x00BA7CBC: BL #0x27bc028              | X0 = 1152921513302781552 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_3);
        // 0x00BA7CC0: MOV x1, x0                 | X1 = 1152921513302781552 (0x1000000206516E70);//ML01
        // 0x00BA7CC4: ORR w2, wzr, #7            | W2 = 7(0x7);                            
        // 0x00BA7CC8: MOV x0, x19                | X0 = 1152921513302741360 (0x100000020650D170);//ML01
        // 0x00BA7CCC: BL #0xba8cf0               | X0 = this.CheckDefault(obj:  val_3, str:  7);
        object val_4 = this.CheckDefault(obj:  val_3, str:  7);
        // 0x00BA7CD0: LDR x20, [x25]             | X20 = typeof(System.Single);            
        // 0x00BA7CD4: MOV x21, x0                | X21 = val_4;//m1                        
        // 0x00BA7CD8: CBNZ x21, #0xba7ce0        | if (val_4 != null) goto label_4;        
        if(val_4 != null)
        {
            goto label_4;
        }
        // 0x00BA7CDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_4:
        // 0x00BA7CE0: LDR x8, [x21]              | X8 = typeof(System.Object);             
        // 0x00BA7CE4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00BA7CE8: LDR x8, [x20, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
        // 0x00BA7CEC: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Single.__il2cppRuntimeField_element_class)
        // 0x00BA7CF0: B.NE #0xba8828             | if (System.Object.__il2cppRuntimeField_element_class != System.Single.__il2cppRuntimeField_element_class) goto label_5;
        // 0x00BA7CF4: MOV x0, x21                | X0 = val_4;//m1                         
        // 0x00BA7CF8: BL #0x27bc4e8              | val_4.System.IDisposable.Dispose();     
        val_4.System.IDisposable.Dispose();
        // 0x00BA7CFC: LDR s8, [x0]               | S8 = typeof(System.Object);             
        // 0x00BA7D00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA7D04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA7D08: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_5 = UnityEngine.Camera.main;
        // 0x00BA7D0C: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00BA7D10: CBNZ x20, #0xba7d18        | if (val_5 != null) goto label_6;        
        if(val_5 != null)
        {
            goto label_6;
        }
        // 0x00BA7D14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_6:
        // 0x00BA7D18: FMOV s0, #-1.00000000      | S0 = -1;                                
        // 0x00BA7D1C: FCMP s8, s0                | STATE = COMPARE(typeof(System.Object), -1)
        // 0x00BA7D20: B.NE #0xba7e68             | if (typeof(System.Object) != -1f) goto label_7;
        if(null != (-1f))
        {
            goto label_7;
        }
        // 0x00BA7D24: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BA7D28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA7D2C: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00BA7D30: BL #0x20cf0d4              | val_5.set_orthographic(value:  false);  
        val_5.orthographic = false;
        // 0x00BA7D34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA7D38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA7D3C: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_6 = UnityEngine.Camera.main;
        // 0x00BA7D40: MOV x20, x0                | X20 = val_6;//m1                        
        // 0x00BA7D44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA7D48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA7D4C: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_7 = UnityEngine.Camera.main;
        // 0x00BA7D50: MOV x21, x0                | X21 = val_7;//m1                        
        // 0x00BA7D54: CBNZ x21, #0xba7d5c        | if (val_7 != null) goto label_8;        
        if(val_7 != null)
        {
            goto label_8;
        }
        // 0x00BA7D58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_8:
        // 0x00BA7D5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA7D60: MOV x0, x21                | X0 = val_7;//m1                         
        // 0x00BA7D64: BL #0x20ce7bc              | X0 = val_7.get_fieldOfView();           
        float val_8 = val_7.fieldOfView;
        // 0x00BA7D68: LDR x21, [x19, #0x58]      | X21 = this.view; //P2                   
        // 0x00BA7D6C: LDR s9, [x19, #0xc8]       | S9 = this.time; //P2                    
        // 0x00BA7D70: LDR x22, [x19, #0x18]      | X22 = this.points; //P2                 
        // 0x00BA7D74: MOV v8.16b, v0.16b         | V8 = val_8;//m1                         
        // 0x00BA7D78: CBNZ x22, #0xba7d80        | if (this.points != null) goto label_9;  
        if(this.points != null)
        {
            goto label_9;
        }
        // 0x00BA7D7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_9:
        // 0x00BA7D80: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00BA7D84: MOV x0, x22                | X0 = this.points;//m1                   
        // 0x00BA7D88: BL #0x2643344              | X0 = this.points.get_Count();           
        int val_9 = this.points.Count;
        // 0x00BA7D8C: MOV w22, w0                | W22 = val_9;//m1                        
        // 0x00BA7D90: CBNZ x21, #0xba7d98        | if (this.view != null) goto label_10;   
        if(this.view != null)
        {
            goto label_10;
        }
        // 0x00BA7D94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_10:
        // 0x00BA7D98: FADD s0, s9, s10           | S0 = (this.time + val_94);              
        float val_10 = this.time + val_94;
        // 0x00BA7D9C: SCVTF s1, w22              | S1 = (float)(val_9);                    
        // 0x00BA7DA0: BL #0x9803a0               | X0 = sub_9803A0( ?? val_9, ????);       
        // 0x00BA7DA4: LDR x2, [x24]              | X2 = public System.Single System.Collections.Generic.List<System.Single>::get_Item(int index);
        // 0x00BA7DA8: FCVTZS w1, s0              | W1 = (int)((this.time + val_94));       
        // 0x00BA7DAC: MOV x0, x21                | X0 = this.view;//m1                     
        // 0x00BA7DB0: BL #0x25fad28              | X0 = this.view.get_Item(index:  (int)val_10);
        float val_11 = this.view.Item[(int)val_10];
        // 0x00BA7DB4: LDR x0, [x25]              | X0 = typeof(System.Single);             
        // 0x00BA7DB8: ADD x1, sp, #0xc           | X1 = (1152921513302729168 + 12) = 1152921513302729180 (0x100000020650A1DC);
        // 0x00BA7DBC: STR s0, [sp, #0xc]         | stack[1152921513302729180] = val_11;     //  dest_result_addr=1152921513302729180
        // 0x00BA7DC0: BL #0x27bc028              | X0 = 1152921513302810224 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_11);
        // 0x00BA7DC4: MOV x1, x0                 | X1 = 1152921513302810224 (0x100000020651DE70);//ML01
        // 0x00BA7DC8: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
        // 0x00BA7DCC: MOV x0, x19                | X0 = 1152921513302741360 (0x100000020650D170);//ML01
        // 0x00BA7DD0: BL #0xba8cf0               | X0 = this.CheckDefault(obj:  val_11, str:  5);
        object val_12 = this.CheckDefault(obj:  val_11, str:  5);
        // 0x00BA7DD4: MOV x21, x0                | X21 = val_12;//m1                       
        // 0x00BA7DD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA7DDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA7DE0: BL #0x2690de0              | X0 = UnityEngine.Time.get_fixedDeltaTime();
        float val_13 = UnityEngine.Time.fixedDeltaTime;
        // 0x00BA7DE4: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00BA7DE8: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00BA7DEC: MOV v9.16b, v0.16b         | V9 = val_13;//m1                        
        // 0x00BA7DF0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00BA7DF4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00BA7DF8: TBZ w8, #0, #0xba7e08      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00BA7DFC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00BA7E00: CBNZ w8, #0xba7e08         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00BA7E04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_12:
        // 0x00BA7E08: LDR x22, [x25]             | X22 = typeof(System.Single);            
        val_95 = null;
        // 0x00BA7E0C: CBNZ x21, #0xba7e14        | if (val_12 != null) goto label_13;      
        if(val_12 != null)
        {
            goto label_13;
        }
        // 0x00BA7E10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Mathf), ????);
        label_13:
        // 0x00BA7E14: LDR x8, [x21]              | X8 = typeof(System.Object);             
        // 0x00BA7E18: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00BA7E1C: LDR x8, [x22, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
        // 0x00BA7E20: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Single.__il2cppRuntimeField_element_class)
        // 0x00BA7E24: B.NE #0xba884c             | if (System.Object.__il2cppRuntimeField_element_class != System.Single.__il2cppRuntimeField_element_class) goto label_14;
        // 0x00BA7E28: MOV x0, x21                | X0 = val_12;//m1                        
        // 0x00BA7E2C: BL #0x27bc4e8              | val_12.System.IDisposable.Dispose();    
        val_12.System.IDisposable.Dispose();
        // 0x00BA7E30: LDR s1, [x0]               | S1 = typeof(System.Object);             
        // 0x00BA7E34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA7E38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA7E3C: MOV v0.16b, v8.16b         | V0 = val_8;//m1                         
        // 0x00BA7E40: MOV v2.16b, v9.16b         | V2 = val_13;//m1                        
        val_96 = val_13;
        // 0x00BA7E44: BL #0x1a7dd1c              | X0 = UnityEngine.Mathf.Lerp(a:  val_8, b:  7.461634E-41f, t:  val_96 = val_13);
        float val_14 = UnityEngine.Mathf.Lerp(a:  val_8, b:  7.461634E-41f, t:  val_96);
        // 0x00BA7E48: MOV v8.16b, v0.16b         | V8 = val_14;//m1                        
        // 0x00BA7E4C: CBNZ x20, #0xba7e54        | if (val_6 != null) goto label_15;       
        if(val_6 != null)
        {
            goto label_15;
        }
        // 0x00BA7E50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_15:
        // 0x00BA7E54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA7E58: MOV x0, x20                | X0 = val_6;//m1                         
        // 0x00BA7E5C: MOV v0.16b, v8.16b         | V0 = val_14;//m1                        
        // 0x00BA7E60: BL #0x20ce824              | val_6.set_fieldOfView(value:  val_14);  
        val_6.fieldOfView = val_14;
        // 0x00BA7E64: B #0xba7fa8                |  goto label_16;                         
        goto label_16;
        label_7:
        // 0x00BA7E68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA7E6C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BA7E70: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00BA7E74: BL #0x20cf0d4              | val_5.set_orthographic(value:  true);   
        val_5.orthographic = true;
        // 0x00BA7E78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA7E7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA7E80: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_15 = UnityEngine.Camera.main;
        // 0x00BA7E84: MOV x20, x0                | X20 = val_15;//m1                       
        // 0x00BA7E88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA7E8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA7E90: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_16 = UnityEngine.Camera.main;
        // 0x00BA7E94: MOV x21, x0                | X21 = val_16;//m1                       
        // 0x00BA7E98: CBNZ x21, #0xba7ea0        | if (val_16 != null) goto label_17;      
        if(val_16 != null)
        {
            goto label_17;
        }
        // 0x00BA7E9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_17:
        // 0x00BA7EA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA7EA4: MOV x0, x21                | X0 = val_16;//m1                        
        // 0x00BA7EA8: BL #0x20cef8c              | X0 = val_16.get_orthographicSize();     
        float val_17 = val_16.orthographicSize;
        // 0x00BA7EAC: LDR x21, [x19, #0x68]      | X21 = this.orthographic; //P2           
        // 0x00BA7EB0: LDR s9, [x19, #0xc8]       | S9 = this.time; //P2                    
        // 0x00BA7EB4: LDR x22, [x19, #0x18]      | X22 = this.points; //P2                 
        // 0x00BA7EB8: MOV v8.16b, v0.16b         | V8 = val_17;//m1                        
        // 0x00BA7EBC: CBNZ x22, #0xba7ec4        | if (this.points != null) goto label_18; 
        if(this.points != null)
        {
            goto label_18;
        }
        // 0x00BA7EC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_18:
        // 0x00BA7EC4: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00BA7EC8: MOV x0, x22                | X0 = this.points;//m1                   
        // 0x00BA7ECC: BL #0x2643344              | X0 = this.points.get_Count();           
        int val_18 = this.points.Count;
        // 0x00BA7ED0: MOV w22, w0                | W22 = val_18;//m1                       
        // 0x00BA7ED4: CBNZ x21, #0xba7edc        | if (this.orthographic != null) goto label_19;
        if(this.orthographic != null)
        {
            goto label_19;
        }
        // 0x00BA7ED8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_19:
        // 0x00BA7EDC: FADD s0, s9, s10           | S0 = (this.time + val_94);              
        float val_19 = this.time + val_94;
        // 0x00BA7EE0: SCVTF s1, w22              | S1 = (float)(val_18);                   
        // 0x00BA7EE4: BL #0x9803a0               | X0 = sub_9803A0( ?? val_18, ????);      
        // 0x00BA7EE8: LDR x2, [x24]              | X2 = public System.Single System.Collections.Generic.List<System.Single>::get_Item(int index);
        // 0x00BA7EEC: FCVTZS w1, s0              | W1 = (int)((this.time + val_94));       
        // 0x00BA7EF0: MOV x0, x21                | X0 = this.orthographic;//m1             
        // 0x00BA7EF4: BL #0x25fad28              | X0 = this.orthographic.get_Item(index:  (int)val_19);
        float val_20 = this.orthographic.Item[(int)val_19];
        // 0x00BA7EF8: LDR x0, [x25]              | X0 = typeof(System.Single);             
        // 0x00BA7EFC: ADD x1, sp, #0x10          | X1 = (1152921513302729168 + 16) = 1152921513302729184 (0x100000020650A1E0);
        // 0x00BA7F00: STR s0, [sp, #0x10]        | stack[1152921513302729184] = val_20;     //  dest_result_addr=1152921513302729184
        // 0x00BA7F04: BL #0x27bc028              | X0 = 1152921513302834800 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_20);
        // 0x00BA7F08: MOV x1, x0                 | X1 = 1152921513302834800 (0x1000000206523E70);//ML01
        // 0x00BA7F0C: ORR w2, wzr, #7            | W2 = 7(0x7);                            
        // 0x00BA7F10: MOV x0, x19                | X0 = 1152921513302741360 (0x100000020650D170);//ML01
        // 0x00BA7F14: BL #0xba8cf0               | X0 = this.CheckDefault(obj:  val_20, str:  7);
        object val_21 = this.CheckDefault(obj:  val_20, str:  7);
        // 0x00BA7F18: MOV x21, x0                | X21 = val_21;//m1                       
        // 0x00BA7F1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA7F20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA7F24: BL #0x2690de0              | X0 = UnityEngine.Time.get_fixedDeltaTime();
        float val_22 = UnityEngine.Time.fixedDeltaTime;
        // 0x00BA7F28: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00BA7F2C: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00BA7F30: MOV v9.16b, v0.16b         | V9 = val_22;//m1                        
        // 0x00BA7F34: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00BA7F38: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00BA7F3C: TBZ w8, #0, #0xba7f4c      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_21;
        // 0x00BA7F40: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00BA7F44: CBNZ w8, #0xba7f4c         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
        // 0x00BA7F48: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_21:
        // 0x00BA7F4C: LDR x22, [x25]             | X22 = typeof(System.Single);            
        val_95 = null;
        // 0x00BA7F50: CBNZ x21, #0xba7f58        | if (val_21 != null) goto label_22;      
        if(val_21 != null)
        {
            goto label_22;
        }
        // 0x00BA7F54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Mathf), ????);
        label_22:
        // 0x00BA7F58: LDR x8, [x21]              | X8 = typeof(System.Object);             
        // 0x00BA7F5C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00BA7F60: LDR x8, [x22, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
        // 0x00BA7F64: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Single.__il2cppRuntimeField_element_class)
        // 0x00BA7F68: B.NE #0xba8870             | if (System.Object.__il2cppRuntimeField_element_class != System.Single.__il2cppRuntimeField_element_class) goto label_23;
        // 0x00BA7F6C: MOV x0, x21                | X0 = val_21;//m1                        
        // 0x00BA7F70: BL #0x27bc4e8              | val_21.System.IDisposable.Dispose();    
        val_21.System.IDisposable.Dispose();
        // 0x00BA7F74: LDR s1, [x0]               | S1 = typeof(System.Object);             
        // 0x00BA7F78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA7F7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA7F80: MOV v0.16b, v8.16b         | V0 = val_17;//m1                        
        // 0x00BA7F84: MOV v2.16b, v9.16b         | V2 = val_22;//m1                        
        val_96 = val_22;
        // 0x00BA7F88: BL #0x1a7dd1c              | X0 = UnityEngine.Mathf.Lerp(a:  val_17, b:  7.461634E-41f, t:  val_96 = val_22);
        float val_23 = UnityEngine.Mathf.Lerp(a:  val_17, b:  7.461634E-41f, t:  val_96);
        // 0x00BA7F8C: MOV v8.16b, v0.16b         | V8 = val_23;//m1                        
        // 0x00BA7F90: CBNZ x20, #0xba7f98        | if (val_15 != null) goto label_24;      
        if(val_15 != null)
        {
            goto label_24;
        }
        // 0x00BA7F94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_24:
        // 0x00BA7F98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA7F9C: MOV x0, x20                | X0 = val_15;//m1                        
        // 0x00BA7FA0: MOV v0.16b, v8.16b         | V0 = val_23;//m1                        
        // 0x00BA7FA4: BL #0x20ceff4              | val_15.set_orthographicSize(value:  val_23);
        val_15.orthographicSize = val_23;
        label_16:
        // 0x00BA7FA8: LDR x20, [x19, #0x40]      | X20 = this.focus; //P2                  
        // 0x00BA7FAC: LDR s8, [x19, #0xc8]       | S8 = this.time; //P2                    
        val_97 = this.time;
        // 0x00BA7FB0: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA7FB4: CBNZ x21, #0xba7fbc        | if (this.points != null) goto label_25; 
        if(this.points != null)
        {
            goto label_25;
        }
        // 0x00BA7FB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_25:
        // 0x00BA7FBC: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00BA7FC0: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA7FC4: BL #0x2643344              | X0 = this.points.get_Count();           
        int val_24 = this.points.Count;
        // 0x00BA7FC8: MOV w21, w0                | W21 = val_24;//m1                       
        val_98 = val_24;
        // 0x00BA7FCC: CBNZ x20, #0xba7fd4        | if (this.focus != null) goto label_26;  
        if(this.focus != null)
        {
            goto label_26;
        }
        // 0x00BA7FD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_26:
        // 0x00BA7FD4: FADD s0, s8, s10           | S0 = (this.time + val_94);              
        float val_25 = val_97 + val_94;
        // 0x00BA7FD8: SCVTF s1, w21              | S1 = (float)(val_24);                   
        // 0x00BA7FDC: BL #0x9803a0               | X0 = sub_9803A0( ?? val_24, ????);      
        // 0x00BA7FE0: ADRP x22, #0x3644000       | X22 = 56901632 (0x3644000);             
        // 0x00BA7FE4: LDR x22, [x22, #0x318]     | X22 = 1152921510860112432;              
        // 0x00BA7FE8: FCVTZS w1, s0              | W1 = (int)((this.time + val_94));       
        // 0x00BA7FEC: MOV x0, x20                | X0 = this.focus;//m1                    
        // 0x00BA7FF0: LDR x2, [x22]              | X2 = public UnityEngine.GameObject System.Collections.Generic.List<UnityEngine.GameObject>::get_Item(int index);
        // 0x00BA7FF4: BL #0x25ed734              | X0 = this.focus.get_Item(index:  (int)val_25);
        UnityEngine.GameObject val_26 = this.focus.Item[(int)val_25];
        // 0x00BA7FF8: MOV x1, x0                 | X1 = val_26;//m1                        
        // 0x00BA7FFC: ORR w2, wzr, #3            | W2 = 3(0x3);                            
        // 0x00BA8000: MOV x0, x19                | X0 = 1152921513302741360 (0x100000020650D170);//ML01
        // 0x00BA8004: BL #0xba8cf0               | X0 = this.CheckDefault(obj:  val_26, str:  3);
        object val_27 = this.CheckDefault(obj:  val_26, str:  3);
        // 0x00BA8008: CBZ x0, #0xba8084          | if (val_27 == null) goto label_27;      
        if(val_27 == null)
        {
            goto label_27;
        }
        // 0x00BA800C: LDR x20, [x19, #0x40]      | X20 = this.focus; //P2                  
        System.Collections.Generic.List<UnityEngine.GameObject> val_90 = this.focus;
        // 0x00BA8010: LDR s8, [x19, #0xc8]       | S8 = this.time; //P2                    
        // 0x00BA8014: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA8018: CBNZ x21, #0xba8020        | if (this.points != null) goto label_28; 
        if(this.points != null)
        {
            goto label_28;
        }
        // 0x00BA801C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
        label_28:
        // 0x00BA8020: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00BA8024: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA8028: BL #0x2643344              | X0 = this.points.get_Count();           
        int val_28 = this.points.Count;
        // 0x00BA802C: MOV w21, w0                | W21 = val_28;//m1                       
        // 0x00BA8030: CBNZ x20, #0xba8038        | if (this.focus != null) goto label_29;  
        if(val_90 != null)
        {
            goto label_29;
        }
        // 0x00BA8034: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
        label_29:
        // 0x00BA8038: FADD s0, s8, s10           | S0 = (this.time + val_94);              
        float val_29 = this.time + val_94;
        // 0x00BA803C: SCVTF s1, w21              | S1 = (float)(val_28);                   
        // 0x00BA8040: BL #0x9803a0               | X0 = sub_9803A0( ?? val_28, ????);      
        // 0x00BA8044: LDR x2, [x22]              | X2 = public UnityEngine.GameObject System.Collections.Generic.List<UnityEngine.GameObject>::get_Item(int index);
        // 0x00BA8048: FCVTZS w1, s0              | W1 = (int)((this.time + val_94));       
        // 0x00BA804C: MOV x0, x20                | X0 = this.focus;//m1                    
        // 0x00BA8050: BL #0x25ed734              | X0 = this.focus.get_Item(index:  (int)val_29);
        UnityEngine.GameObject val_30 = val_90.Item[(int)val_29];
        // 0x00BA8054: MOV x1, x0                 | X1 = val_30;//m1                        
        // 0x00BA8058: ORR w2, wzr, #3            | W2 = 3(0x3);                            
        // 0x00BA805C: MOV x0, x19                | X0 = 1152921513302741360 (0x100000020650D170);//ML01
        // 0x00BA8060: BL #0xba8cf0               | X0 = this.CheckDefault(obj:  val_30, str:  3);
        object val_31 = this.CheckDefault(obj:  val_30, str:  3);
        // 0x00BA8064: CBZ x0, #0xba8270          | if (val_31 == null) goto label_30;      
        if(val_31 == null)
        {
            goto label_30;
        }
        // 0x00BA8068: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00BA806C: LDR x8, [x8, #0x30]        | X8 = 1152921504692629504;               
        // 0x00BA8070: LDR x9, [x0]               | X9 = typeof(System.Object);             
        // 0x00BA8074: LDR x8, [x8]               | X8 = typeof(UnityEngine.GameObject);    
        // 0x00BA8078: CMP x9, x8                 | STATE = COMPARE(typeof(System.Object), typeof(UnityEngine.GameObject))
        // 0x00BA807C: CSEL x20, x0, xzr, eq      | X20 = typeof(System.Object) == null ? val_31 : 0;
        val_90 = (null == null) ? (val_31) : 0;
        // 0x00BA8080: B #0xba8274                |  goto label_31;                         
        goto label_31;
        label_27:
        // 0x00BA8084: LDRB w8, [x19, #0xd8]      | W8 = this.isRoted; //P2                 
        // 0x00BA8088: CBNZ w8, #0xba85e8         | if (this.isRoted == true) goto label_74;
        if(this.isRoted == true)
        {
            goto label_74;
        }
        // 0x00BA808C: LDR x20, [x19, #0x70]      | X20 = this.isConstant; //P2             
        // 0x00BA8090: CBNZ x20, #0xba8098        | if (this.isConstant != null) goto label_33;
        if(this.isConstant != null)
        {
            goto label_33;
        }
        // 0x00BA8094: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
        label_33:
        // 0x00BA8098: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
        // 0x00BA809C: LDR x8, [x8, #0x408]       | X8 = 1152921510876430768;               
        // 0x00BA80A0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BA80A4: MOV x0, x20                | X0 = this.isConstant;//m1               
        // 0x00BA80A8: LDR x2, [x8]               | X2 = public System.Int32 System.Collections.Generic.List<System.Int32>::get_Item(int index);
        // 0x00BA80AC: BL #0x25e4de4              | X0 = this.isConstant.get_Item(index:  0);
        int val_32 = this.isConstant.Item[0];
        // 0x00BA80B0: LDR s8, [x19, #0xd0]       | S8 = this.newTime; //P2                 
        // 0x00BA80B4: MOV w21, w0                | W21 = val_32;//m1                       
        // 0x00BA80B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA80BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA80C0: BL #0x2690de0              | X0 = UnityEngine.Time.get_fixedDeltaTime();
        float val_33 = UnityEngine.Time.fixedDeltaTime;
        // 0x00BA80C4: LDR x20, [x19, #0x28]      | X20 = this.rotSpeed; //P2               
        // 0x00BA80C8: FADD s0, s8, s0            | S0 = (this.newTime + val_33);           
        val_33 = this.newTime + val_33;
        // 0x00BA80CC: STR s0, [x19, #0xd0]       | this.newTime = (this.newTime + val_33);  //  dest_result_addr=1152921513302741568
        this.newTime = val_33;
        // 0x00BA80D0: CMP w21, #1                | STATE = COMPARE(val_32, 0x1)            
        // 0x00BA80D4: B.NE #0xba8614             | if (val_32 != 1) goto label_34;         
        if(val_32 != 1)
        {
            goto label_34;
        }
        // 0x00BA80D8: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA80DC: CBNZ x21, #0xba80e4        | if (this.points != null) goto label_35; 
        if(this.points != null)
        {
            goto label_35;
        }
        // 0x00BA80E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_35:
        // 0x00BA80E4: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00BA80E8: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA80EC: BL #0x2643344              | X0 = this.points.get_Count();           
        int val_34 = this.points.Count;
        // 0x00BA80F0: MOV w21, w0                | W21 = val_34;//m1                       
        // 0x00BA80F4: CBNZ x20, #0xba80fc        | if (this.rotSpeed != null) goto label_36;
        if(this.rotSpeed != null)
        {
            goto label_36;
        }
        // 0x00BA80F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_34, ????);     
        label_36:
        // 0x00BA80FC: LDR x2, [x24]              | X2 = public System.Single System.Collections.Generic.List<System.Single>::get_Item(int index);
        // 0x00BA8100: SUB w1, w21, #1            | W1 = (val_34 - 1);                      
        int val_35 = val_34 - 1;
        // 0x00BA8104: MOV x0, x20                | X0 = this.rotSpeed;//m1                 
        // 0x00BA8108: BL #0x25fad28              | X0 = this.rotSpeed.get_Item(index:  int val_35 = val_34 - 1);
        float val_36 = this.rotSpeed.Item[val_35];
        // 0x00BA810C: LDP x21, x20, [x19, #0x18] | X21 = this.points; //P2  X20 = this.rotations; //P2  //  | 
        // 0x00BA8110: MOV v11.16b, v0.16b        | V11 = val_36;//m1                       
        // 0x00BA8114: CBNZ x21, #0xba811c        | if (this.points != null) goto label_37; 
        if(this.points != null)
        {
            goto label_37;
        }
        // 0x00BA8118: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.rotSpeed, ????);
        label_37:
        // 0x00BA811C: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00BA8120: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA8124: BL #0x2643344              | X0 = this.points.get_Count();           
        int val_37 = this.points.Count;
        // 0x00BA8128: MOV w21, w0                | W21 = val_37;//m1                       
        val_98 = val_37;
        // 0x00BA812C: CBNZ x20, #0xba8134        | if (this.rotations != null) goto label_38;
        if(this.rotations != null)
        {
            goto label_38;
        }
        // 0x00BA8130: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
        label_38:
        // 0x00BA8134: ADRP x24, #0x363e000       | X24 = 56877056 (0x363E000);             
        // 0x00BA8138: LDR x24, [x24, #0x1f0]     | X24 = 1152921510909481968;              
        // 0x00BA813C: SUB w1, w21, #1            | W1 = (val_37 - 1);                      
        int val_38 = val_98 - 1;
        // 0x00BA8140: MOV x0, x20                | X0 = this.rotations;//m1                
        // 0x00BA8144: LDR x2, [x24]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA8148: BL #0x264334c              | X0 = this.rotations.get_Item(index:  int val_38 = val_98 - 1);
        UnityEngine.Vector3 val_39 = this.rotations.Item[val_38];
        // 0x00BA814C: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BA8150: MOV v8.16b, v0.16b         | V8 = val_39.x;//m1                      
        val_97 = val_39.x;
        // 0x00BA8154: LDR s0, [x8, #0x944]       | S0 = 1000;                              
        // 0x00BA8158: MOV v9.16b, v1.16b         | V9 = val_39.y;//m1                      
        // 0x00BA815C: LDR s1, [x19, #0xd0]       | S1 = this.newTime; //P2                 
        // 0x00BA8160: MOV v10.16b, v2.16b        | V10 = val_39.z;//m1                     
        val_94 = val_39.z;
        // 0x00BA8164: FDIV s14, s11, s0          | S14 = (val_36 / 1000f);                 
        float val_40 = val_36 / 1000f;
        // 0x00BA8168: FCMP s1, s14               | STATE = COMPARE(this.newTime, (val_36 / 1000f))
        // 0x00BA816C: B.PL #0xba85e8             | if (this.newTime >= 0) goto label_74;   
        if(this.newTime >= 0)
        {
            goto label_74;
        }
        // 0x00BA8170: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8174: MOV x0, x19                | X0 = 1152921513302741360 (0x100000020650D170);//ML01
        // 0x00BA8178: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_41 = this.transform;
        // 0x00BA817C: LDR s15, [x19, #0xd0]      | S15 = this.newTime; //P2                
        // 0x00BA8180: LDP x22, x21, [x19, #0x18] | X22 = this.points; //P2  X21 = this.rotations; //P2  //  | 
        // 0x00BA8184: MOV x20, x0                | X20 = val_41;//m1                       
        // 0x00BA8188: CBNZ x22, #0xba8190        | if (this.points != null) goto label_40; 
        if(this.points != null)
        {
            goto label_40;
        }
        // 0x00BA818C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_41, ????);     
        label_40:
        // 0x00BA8190: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00BA8194: MOV x0, x22                | X0 = this.points;//m1                   
        // 0x00BA8198: BL #0x2643344              | X0 = this.points.get_Count();           
        int val_42 = this.points.Count;
        // 0x00BA819C: MOV w22, w0                | W22 = val_42;//m1                       
        // 0x00BA81A0: CBNZ x21, #0xba81a8        | if (this.rotations != null) goto label_41;
        if(this.rotations != null)
        {
            goto label_41;
        }
        // 0x00BA81A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
        label_41:
        // 0x00BA81A8: LDR x2, [x24]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA81AC: SUB w1, w22, #1            | W1 = (val_42 - 1);                      
        int val_43 = val_42 - 1;
        // 0x00BA81B0: MOV x0, x21                | X0 = this.rotations;//m1                
        // 0x00BA81B4: BL #0x264334c              | X0 = this.rotations.get_Item(index:  int val_43 = val_42 - 1);
        UnityEngine.Vector3 val_44 = this.rotations.Item[val_43];
        // 0x00BA81B8: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BA81BC: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BA81C0: MOV v11.16b, v0.16b        | V11 = val_44.x;//m1                     
        // 0x00BA81C4: MOV v12.16b, v1.16b        | V12 = val_44.y;//m1                     
        // 0x00BA81C8: MOV v13.16b, v2.16b        | V13 = val_44.z;//m1                     
        // 0x00BA81CC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BA81D0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BA81D4: TBZ w8, #0, #0xba81e4      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_43;
        // 0x00BA81D8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BA81DC: CBNZ w8, #0xba81e4         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_43;
        // 0x00BA81E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_43:
        // 0x00BA81E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA81E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA81EC: MOV v0.16b, v8.16b         | V0 = val_39.x;//m1                      
        // 0x00BA81F0: MOV v1.16b, v9.16b         | V1 = val_39.y;//m1                      
        // 0x00BA81F4: MOV v2.16b, v10.16b        | V2 = val_39.z;//m1                      
        // 0x00BA81F8: MOV v3.16b, v11.16b        | V3 = val_44.x;//m1                      
        // 0x00BA81FC: MOV v4.16b, v12.16b        | V4 = val_44.y;//m1                      
        // 0x00BA8200: MOV v5.16b, v13.16b        | V5 = val_44.z;//m1                      
        // 0x00BA8204: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_97, y = val_39.y, z = val_94}, b:  new UnityEngine.Vector3() {x = val_44.x, y = val_44.y, z = val_44.z});
        UnityEngine.Vector3 val_45 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_97, y = val_39.y, z = val_94}, b:  new UnityEngine.Vector3() {x = val_44.x, y = val_44.y, z = val_44.z});
        // 0x00BA8208: MOV v3.16b, v0.16b         | V3 = val_45.x;//m1                      
        // 0x00BA820C: MOV v4.16b, v1.16b         | V4 = val_45.y;//m1                      
        // 0x00BA8210: MOV v5.16b, v2.16b         | V5 = val_45.z;//m1                      
        // 0x00BA8214: FDIV s0, s15, s14          | S0 = (this.newTime / (val_36 / 1000f)); 
        val_100 = this.newTime / val_40;
        // 0x00BA8218: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA821C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8220: MOV v1.16b, v3.16b         | V1 = val_45.x;//m1                      
        val_101 = val_45.x;
        // 0x00BA8224: MOV v2.16b, v4.16b         | V2 = val_45.y;//m1                      
        val_102 = val_45.y;
        // 0x00BA8228: MOV v3.16b, v5.16b         | V3 = val_45.z;//m1                      
        // 0x00BA822C: BL #0x2699650              | X0 = UnityEngine.Vector3.op_Multiply(d:  val_100 = this.newTime / val_40, a:  new UnityEngine.Vector3() {x = val_101, y = val_102, z = val_45.z});
        UnityEngine.Vector3 val_46 = UnityEngine.Vector3.op_Multiply(d:  val_100, a:  new UnityEngine.Vector3() {x = val_101, y = val_102, z = val_45.z});
        // 0x00BA8230: LDP x21, x19, [x19, #0x18] | X21 = this.points; //P2  X19 = this.rotations; //P2  //  | 
        // 0x00BA8234: MOV v8.16b, v0.16b         | V8 = val_46.x;//m1                      
        val_103 = val_46.x;
        // 0x00BA8238: MOV v9.16b, v1.16b         | V9 = val_46.y;//m1                      
        val_104 = val_46.y;
        // 0x00BA823C: MOV v10.16b, v2.16b        | V10 = val_46.z;//m1                     
        val_105 = val_46.z;
        // 0x00BA8240: CBNZ x21, #0xba8248        | if (this.points != null) goto label_44; 
        if(this.points != null)
        {
            goto label_44;
        }
        // 0x00BA8244: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_44:
        // 0x00BA8248: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00BA824C: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA8250: BL #0x2643344              | X0 = this.points.get_Count();           
        int val_47 = this.points.Count;
        // 0x00BA8254: MOV w21, w0                | W21 = val_47;//m1                       
        // 0x00BA8258: CBNZ x19, #0xba8260        | if (this.rotations != null) goto label_45;
        if(this.rotations != null)
        {
            goto label_45;
        }
        // 0x00BA825C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_47, ????);     
        label_45:
        // 0x00BA8260: LDR x2, [x24]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        val_106 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA8264: SUB w1, w21, #1            | W1 = (val_47 - 1);                      
        val_107 = val_47 - 1;
        // 0x00BA8268: MOV x0, x19                | X0 = this.rotations;//m1                
        // 0x00BA826C: B #0xba87b8                |  goto label_46;                         
        goto label_46;
        label_30:
        // 0x00BA8270: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
        val_99 = 0;
        label_31:
        // 0x00BA8274: LDRB w8, [x19, #0x89]      | W8 = this.isLerp; //P2                  
        // 0x00BA8278: CBZ w8, #0xba83f8          | if (this.isLerp == false) goto label_47;
        if(this.isLerp == false)
        {
            goto label_47;
        }
        // 0x00BA827C: CBNZ x20, #0xba8284        | if (0x0 != 0) goto label_48;            
        if(val_99 != 0)
        {
            goto label_48;
        }
        // 0x00BA8280: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
        label_48:
        // 0x00BA8284: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8288: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
        // 0x00BA828C: BL #0x1a62c1c              | X0 = val_99.get_transform();            
        UnityEngine.Transform val_48 = val_99.transform;
        // 0x00BA8290: MOV x20, x0                | X20 = val_48;//m1                       
        // 0x00BA8294: CBNZ x20, #0xba829c        | if (val_48 != null) goto label_49;      
        if(val_48 != null)
        {
            goto label_49;
        }
        // 0x00BA8298: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_48, ????);     
        label_49:
        // 0x00BA829C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA82A0: MOV x0, x20                | X0 = val_48;//m1                        
        // 0x00BA82A4: BL #0x2693510              | X0 = val_48.get_position();             
        UnityEngine.Vector3 val_49 = val_48.position;
        // 0x00BA82A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA82AC: MOV x0, x19                | X0 = 1152921513302741360 (0x100000020650D170);//ML01
        // 0x00BA82B0: MOV v8.16b, v0.16b         | V8 = val_49.x;//m1                      
        // 0x00BA82B4: MOV v9.16b, v1.16b         | V9 = val_49.y;//m1                      
        // 0x00BA82B8: MOV v10.16b, v2.16b        | V10 = val_49.z;//m1                     
        // 0x00BA82BC: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_50 = this.transform;
        // 0x00BA82C0: MOV x20, x0                | X20 = val_50;//m1                       
        // 0x00BA82C4: CBNZ x20, #0xba82cc        | if (val_50 != null) goto label_50;      
        if(val_50 != null)
        {
            goto label_50;
        }
        // 0x00BA82C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_50, ????);     
        label_50:
        // 0x00BA82CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA82D0: MOV x0, x20                | X0 = val_50;//m1                        
        // 0x00BA82D4: BL #0x2693510              | X0 = val_50.get_position();             
        UnityEngine.Vector3 val_51 = val_50.position;
        // 0x00BA82D8: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BA82DC: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BA82E0: MOV v11.16b, v0.16b        | V11 = val_51.x;//m1                     
        // 0x00BA82E4: MOV v12.16b, v1.16b        | V12 = val_51.y;//m1                     
        val_108 = val_51.y;
        // 0x00BA82E8: MOV v13.16b, v2.16b        | V13 = val_51.z;//m1                     
        // 0x00BA82EC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BA82F0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BA82F4: TBZ w8, #0, #0xba8304      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_52;
        // 0x00BA82F8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BA82FC: CBNZ w8, #0xba8304         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_52;
        // 0x00BA8300: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_52:
        // 0x00BA8304: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA8308: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA830C: MOV v0.16b, v8.16b         | V0 = val_49.x;//m1                      
        // 0x00BA8310: MOV v1.16b, v9.16b         | V1 = val_49.y;//m1                      
        // 0x00BA8314: MOV v2.16b, v10.16b        | V2 = val_49.z;//m1                      
        // 0x00BA8318: MOV v3.16b, v11.16b        | V3 = val_51.x;//m1                      
        // 0x00BA831C: MOV v4.16b, v12.16b        | V4 = val_51.y;//m1                      
        // 0x00BA8320: MOV v5.16b, v13.16b        | V5 = val_51.z;//m1                      
        // 0x00BA8324: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_49.x, y = val_49.y, z = val_49.z}, b:  new UnityEngine.Vector3() {x = val_51.x, y = val_108, z = val_51.z});
        UnityEngine.Vector3 val_52 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_49.x, y = val_49.y, z = val_49.z}, b:  new UnityEngine.Vector3() {x = val_51.x, y = val_108, z = val_51.z});
        // 0x00BA8328: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00BA832C: LDR x8, [x8, #0xd78]       | X8 = 1152921504695132160;               
        // 0x00BA8330: MOV v8.16b, v0.16b         | V8 = val_52.x;//m1                      
        // 0x00BA8334: MOV v9.16b, v1.16b         | V9 = val_52.y;//m1                      
        // 0x00BA8338: MOV v10.16b, v2.16b        | V10 = val_52.z;//m1                     
        // 0x00BA833C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Quaternion);    
        // 0x00BA8340: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_10A;
        // 0x00BA8344: TBZ w8, #0, #0xba8354      | if (UnityEngine.Quaternion.__il2cppRuntimeField_has_cctor == 0) goto label_54;
        // 0x00BA8348: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00BA834C: CBNZ w8, #0xba8354         | if (UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished != 0) goto label_54;
        // 0x00BA8350: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Quaternion), ????);
        label_54:
        // 0x00BA8354: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA8358: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA835C: MOV v0.16b, v8.16b         | V0 = val_52.x;//m1                      
        // 0x00BA8360: MOV v1.16b, v9.16b         | V1 = val_52.y;//m1                      
        // 0x00BA8364: MOV v2.16b, v10.16b        | V2 = val_52.z;//m1                      
        // 0x00BA8368: BL #0x1b7e8c4              | X0 = UnityEngine.Quaternion.LookRotation(forward:  new UnityEngine.Vector3() {x = val_52.x, y = val_52.y, z = val_52.z});
        UnityEngine.Quaternion val_53 = UnityEngine.Quaternion.LookRotation(forward:  new UnityEngine.Vector3() {x = val_52.x, y = val_52.y, z = val_52.z});
        // 0x00BA836C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8370: MOV x0, x19                | X0 = 1152921513302741360 (0x100000020650D170);//ML01
        // 0x00BA8374: MOV v8.16b, v0.16b         | V8 = val_53.x;//m1                      
        // 0x00BA8378: MOV v9.16b, v1.16b         | V9 = val_53.y;//m1                      
        // 0x00BA837C: MOV v10.16b, v2.16b        | V10 = val_53.z;//m1                     
        // 0x00BA8380: MOV v11.16b, v3.16b        | V11 = val_53.w;//m1                     
        // 0x00BA8384: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_54 = this.transform;
        // 0x00BA8388: MOV x20, x0                | X20 = val_54;//m1                       
        // 0x00BA838C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8390: MOV x0, x19                | X0 = 1152921513302741360 (0x100000020650D170);//ML01
        // 0x00BA8394: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_55 = this.transform;
        // 0x00BA8398: MOV x21, x0                | X21 = val_55;//m1                       
        val_98 = val_55;
        // 0x00BA839C: CBNZ x21, #0xba83a4        | if (val_55 != null) goto label_55;      
        if(val_98 != null)
        {
            goto label_55;
        }
        // 0x00BA83A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_55, ????);     
        label_55:
        // 0x00BA83A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA83A8: MOV x0, x21                | X0 = val_55;//m1                        
        // 0x00BA83AC: BL #0x26937d8              | X0 = val_55.get_rotation();             
        UnityEngine.Quaternion val_56 = val_98.rotation;
        // 0x00BA83B0: LDR s4, [x19, #0x90]       | S4 = this.lerpInterval; //P2            
        // 0x00BA83B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA83B8: MOV v5.16b, v9.16b         | V5 = val_53.y;//m1                      
        // 0x00BA83BC: MOV v6.16b, v10.16b        | V6 = val_53.z;//m1                      
        // 0x00BA83C0: STR s4, [sp]               | stack[1152921513302729168] = this.lerpInterval;  //  dest_result_addr=1152921513302729168
        // 0x00BA83C4: MOV v4.16b, v8.16b         | V4 = val_53.x;//m1                      
        // 0x00BA83C8: MOV v7.16b, v11.16b        | V7 = val_53.w;//m1                      
        // 0x00BA83CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA83D0: BL #0x1b7ebf0              | X0 = UnityEngine.Quaternion.Lerp(a:  new UnityEngine.Quaternion() {x = val_56.x, y = val_56.y, z = val_56.z, w = val_56.w}, b:  new UnityEngine.Quaternion() {x = val_53.x, y = val_53.y, z = val_53.z, w = val_53.w}, t:  this.lerpInterval);
        UnityEngine.Quaternion val_57 = UnityEngine.Quaternion.Lerp(a:  new UnityEngine.Quaternion() {x = val_56.x, y = val_56.y, z = val_56.z, w = val_56.w}, b:  new UnityEngine.Quaternion() {x = val_53.x, y = val_53.y, z = val_53.z, w = val_53.w}, t:  this.lerpInterval);
        label_81:
        // 0x00BA83D4: MOV v8.16b, v0.16b         | V8 = val_57.x;//m1                      
        val_97 = val_57.x;
        // 0x00BA83D8: MOV v9.16b, v1.16b         | V9 = val_57.y;//m1                      
        val_113 = val_57.y;
        // 0x00BA83DC: MOV v10.16b, v2.16b        | V10 = val_57.z;//m1                     
        val_94 = val_57.z;
        // 0x00BA83E0: MOV v11.16b, v3.16b        | V11 = val_57.w;//m1                     
        val_114 = val_57.w;
        // 0x00BA83E4: CBNZ x20, #0xba83ec        | if (val_54 != null) goto label_56;      
        if(val_54 != null)
        {
            goto label_56;
        }
        // 0x00BA83E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_56:
        // 0x00BA83EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA83F0: MOV x0, x20                | X0 = val_54;//m1                        
        // 0x00BA83F4: B #0xba85d4                |  goto label_57;                         
        goto label_57;
        label_47:
        // 0x00BA83F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA83FC: MOV x0, x19                | X0 = 1152921513302741360 (0x100000020650D170);//ML01
        // 0x00BA8400: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_58 = this.transform;
        // 0x00BA8404: MOV x21, x0                | X21 = val_58;//m1                       
        // 0x00BA8408: CBNZ x21, #0xba8410        | if (val_58 != null) goto label_58;      
        if(val_58 != null)
        {
            goto label_58;
        }
        // 0x00BA840C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_58, ????);     
        label_58:
        // 0x00BA8410: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8414: MOV x0, x21                | X0 = val_58;//m1                        
        // 0x00BA8418: BL #0x2693510              | X0 = val_58.get_position();             
        UnityEngine.Vector3 val_59 = val_58.position;
        // 0x00BA841C: MOV v8.16b, v0.16b         | V8 = val_59.x;//m1                      
        // 0x00BA8420: MOV v9.16b, v1.16b         | V9 = val_59.y;//m1                      
        // 0x00BA8424: MOV v10.16b, v2.16b        | V10 = val_59.z;//m1                     
        // 0x00BA8428: CBNZ x20, #0xba8430        | if (0x0 != 0) goto label_59;            
        if(val_99 != 0)
        {
            goto label_59;
        }
        // 0x00BA842C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_58, ????);     
        label_59:
        // 0x00BA8430: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8434: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
        // 0x00BA8438: BL #0x1a62c1c              | X0 = val_99.get_transform();            
        UnityEngine.Transform val_60 = val_99.transform;
        // 0x00BA843C: MOV x21, x0                | X21 = val_60;//m1                       
        // 0x00BA8440: CBNZ x21, #0xba8448        | if (val_60 != null) goto label_60;      
        if(val_60 != null)
        {
            goto label_60;
        }
        // 0x00BA8444: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_60, ????);     
        label_60:
        // 0x00BA8448: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA844C: MOV x0, x21                | X0 = val_60;//m1                        
        // 0x00BA8450: BL #0x2693510              | X0 = val_60.get_position();             
        UnityEngine.Vector3 val_61 = val_60.position;
        // 0x00BA8454: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00BA8458: LDR x8, [x8, #0xd78]       | X8 = 1152921504695132160;               
        // 0x00BA845C: MOV v11.16b, v0.16b        | V11 = val_61.x;//m1                     
        // 0x00BA8460: MOV v12.16b, v1.16b        | V12 = val_61.y;//m1                     
        // 0x00BA8464: MOV v13.16b, v2.16b        | V13 = val_61.z;//m1                     
        // 0x00BA8468: LDR x0, [x8]               | X0 = typeof(UnityEngine.Quaternion);    
        // 0x00BA846C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_10A;
        // 0x00BA8470: TBZ w8, #0, #0xba8480      | if (UnityEngine.Quaternion.__il2cppRuntimeField_has_cctor == 0) goto label_62;
        // 0x00BA8474: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00BA8478: CBNZ w8, #0xba8480         | if (UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished != 0) goto label_62;
        // 0x00BA847C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Quaternion), ????);
        label_62:
        // 0x00BA8480: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA8484: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8488: MOV v0.16b, v8.16b         | V0 = val_59.x;//m1                      
        // 0x00BA848C: MOV v1.16b, v9.16b         | V1 = val_59.y;//m1                      
        // 0x00BA8490: MOV v2.16b, v10.16b        | V2 = val_59.z;//m1                      
        // 0x00BA8494: MOV v3.16b, v11.16b        | V3 = val_61.x;//m1                      
        // 0x00BA8498: MOV v4.16b, v12.16b        | V4 = val_61.y;//m1                      
        // 0x00BA849C: MOV v5.16b, v13.16b        | V5 = val_61.z;//m1                      
        // 0x00BA84A0: BL #0x1b7e5e8              | X0 = UnityEngine.Quaternion.FromToRotation(fromDirection:  new UnityEngine.Vector3() {x = val_59.x, y = val_59.y, z = val_59.z}, toDirection:  new UnityEngine.Vector3() {x = val_61.x, y = val_61.y, z = val_61.z});
        UnityEngine.Quaternion val_62 = UnityEngine.Quaternion.FromToRotation(fromDirection:  new UnityEngine.Vector3() {x = val_59.x, y = val_59.y, z = val_59.z}, toDirection:  new UnityEngine.Vector3() {x = val_61.x, y = val_61.y, z = val_61.z});
        // 0x00BA84A4: LDR s13, [x19, #0x8c]      | S13 = this.overageSpeed; //P2           
        float val_91 = this.overageSpeed;
        // 0x00BA84A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA84AC: MOV x0, x19                | X0 = 1152921513302741360 (0x100000020650D170);//ML01
        // 0x00BA84B0: MOV v8.16b, v0.16b         | V8 = val_62.x;//m1                      
        // 0x00BA84B4: MOV v9.16b, v1.16b         | V9 = val_62.y;//m1                      
        // 0x00BA84B8: MOV v11.16b, v2.16b        | V11 = val_62.z;//m1                     
        // 0x00BA84BC: MOV v10.16b, v3.16b        | V10 = val_62.w;//m1                     
        // 0x00BA84C0: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_63 = this.transform;
        // 0x00BA84C4: MOV x21, x0                | X21 = val_63;//m1                       
        // 0x00BA84C8: CBNZ x21, #0xba84d0        | if (val_63 != null) goto label_63;      
        if(val_63 != null)
        {
            goto label_63;
        }
        // 0x00BA84CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_63, ????);     
        label_63:
        // 0x00BA84D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA84D4: MOV x0, x21                | X0 = val_63;//m1                        
        // 0x00BA84D8: BL #0x26937d8              | X0 = val_63.get_rotation();             
        UnityEngine.Quaternion val_64 = val_63.rotation;
        // 0x00BA84DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA84E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA84E4: MOV v4.16b, v8.16b         | V4 = val_62.x;//m1                      
        // 0x00BA84E8: MOV v5.16b, v9.16b         | V5 = val_62.y;//m1                      
        // 0x00BA84EC: MOV v6.16b, v11.16b        | V6 = val_62.z;//m1                      
        // 0x00BA84F0: MOV v7.16b, v10.16b        | V7 = val_62.w;//m1                      
        // 0x00BA84F4: BL #0x1b7efcc              | X0 = UnityEngine.Quaternion.Angle(a:  new UnityEngine.Quaternion() {x = val_64.x, y = val_64.y, z = val_64.z, w = val_64.w}, b:  new UnityEngine.Quaternion() {x = val_62.x, y = val_62.y, z = val_62.z, w = val_62.w});
        float val_65 = UnityEngine.Quaternion.Angle(a:  new UnityEngine.Quaternion() {x = val_64.x, y = val_64.y, z = val_64.z, w = val_64.w}, b:  new UnityEngine.Quaternion() {x = val_62.x, y = val_62.y, z = val_62.z, w = val_62.w});
        // 0x00BA84F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA84FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8500: MOV v8.16b, v0.16b         | V8 = val_65;//m1                        
        // 0x00BA8504: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_66 = UnityEngine.Time.deltaTime;
        // 0x00BA8508: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA850C: MOV x0, x19                | X0 = 1152921513302741360 (0x100000020650D170);//ML01
        // 0x00BA8510: MOV v12.16b, v0.16b        | V12 = val_66;//m1                       
        // 0x00BA8514: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_67 = this.transform;
        // 0x00BA8518: MOV x21, x0                | X21 = val_67;//m1                       
        val_98 = val_67;
        // 0x00BA851C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8520: MOV x0, x19                | X0 = 1152921513302741360 (0x100000020650D170);//ML01
        // 0x00BA8524: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_68 = this.transform;
        // 0x00BA8528: MOV x19, x0                | X19 = val_68;//m1                       
        // 0x00BA852C: CBNZ x19, #0xba8534        | if (val_68 != null) goto label_64;      
        if(val_68 != null)
        {
            goto label_64;
        }
        // 0x00BA8530: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_68, ????);     
        label_64:
        // 0x00BA8534: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8538: MOV x0, x19                | X0 = val_68;//m1                        
        // 0x00BA853C: FDIV s13, s13, s8          | S13 = (this.overageSpeed / val_65);     
        val_91 = val_91 / val_65;
        // 0x00BA8540: BL #0x26937d8              | X0 = val_68.get_rotation();             
        UnityEngine.Quaternion val_69 = val_68.rotation;
        // 0x00BA8544: MOV v8.16b, v0.16b         | V8 = val_69.x;//m1                      
        // 0x00BA8548: MOV v9.16b, v1.16b         | V9 = val_69.y;//m1                      
        // 0x00BA854C: MOV v10.16b, v2.16b        | V10 = val_69.z;//m1                     
        // 0x00BA8550: MOV v11.16b, v3.16b        | V11 = val_69.w;//m1                     
        // 0x00BA8554: CBNZ x20, #0xba855c        | if (0x0 != 0) goto label_65;            
        if(val_99 != 0)
        {
            goto label_65;
        }
        // 0x00BA8558: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_68, ????);     
        label_65:
        // 0x00BA855C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8560: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
        // 0x00BA8564: FMUL s12, s13, s12         | S12 = ((this.overageSpeed / val_65) * val_66);
        val_108 = val_91 * val_66;
        // 0x00BA8568: BL #0x1a62c1c              | X0 = val_99.get_transform();            
        UnityEngine.Transform val_70 = val_99.transform;
        // 0x00BA856C: MOV x19, x0                | X19 = val_70;//m1                       
        val_93 = val_70;
        // 0x00BA8570: CBNZ x19, #0xba8578        | if (val_70 != null) goto label_66;      
        if(val_93 != null)
        {
            goto label_66;
        }
        // 0x00BA8574: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_70, ????);     
        label_66:
        // 0x00BA8578: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA857C: MOV x0, x19                | X0 = val_70;//m1                        
        // 0x00BA8580: BL #0x26937d8              | X0 = val_70.get_rotation();             
        UnityEngine.Quaternion val_71 = val_93.rotation;
        // 0x00BA8584: MOV v4.16b, v0.16b         | V4 = val_71.x;//m1                      
        // 0x00BA8588: MOV v5.16b, v1.16b         | V5 = val_71.y;//m1                      
        // 0x00BA858C: MOV v6.16b, v2.16b         | V6 = val_71.z;//m1                      
        // 0x00BA8590: MOV v7.16b, v3.16b         | V7 = val_71.w;//m1                      
        // 0x00BA8594: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA8598: MOV v0.16b, v8.16b         | V0 = val_69.x;//m1                      
        // 0x00BA859C: MOV v1.16b, v9.16b         | V1 = val_69.y;//m1                      
        // 0x00BA85A0: MOV v2.16b, v10.16b        | V2 = val_69.z;//m1                      
        // 0x00BA85A4: MOV v3.16b, v11.16b        | V3 = val_69.w;//m1                      
        // 0x00BA85A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA85AC: STR s12, [sp]              | stack[1152921513302729168] = ((this.overageSpeed / val_65) * val_66);  //  dest_result_addr=1152921513302729168
        // 0x00BA85B0: BL #0x1b7e988              | X0 = UnityEngine.Quaternion.Slerp(a:  new UnityEngine.Quaternion() {x = val_69.x, y = val_69.y, z = val_69.z, w = val_69.w}, b:  new UnityEngine.Quaternion() {x = val_71.x, y = val_71.y, z = val_71.z, w = val_71.w}, t:  val_108);
        UnityEngine.Quaternion val_72 = UnityEngine.Quaternion.Slerp(a:  new UnityEngine.Quaternion() {x = val_69.x, y = val_69.y, z = val_69.z, w = val_69.w}, b:  new UnityEngine.Quaternion() {x = val_71.x, y = val_71.y, z = val_71.z, w = val_71.w}, t:  val_108);
        // 0x00BA85B4: MOV v8.16b, v0.16b         | V8 = val_72.x;//m1                      
        val_97 = val_72.x;
        // 0x00BA85B8: MOV v9.16b, v1.16b         | V9 = val_72.y;//m1                      
        val_113 = val_72.y;
        // 0x00BA85BC: MOV v10.16b, v2.16b        | V10 = val_72.z;//m1                     
        val_94 = val_72.z;
        // 0x00BA85C0: MOV v11.16b, v3.16b        | V11 = val_72.w;//m1                     
        val_114 = val_72.w;
        // 0x00BA85C4: CBNZ x21, #0xba85cc        | if (val_67 != null) goto label_67;      
        if(val_98 != null)
        {
            goto label_67;
        }
        // 0x00BA85C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_67:
        // 0x00BA85CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA85D0: MOV x0, x21                | X0 = val_67;//m1                        
        label_57:
        // 0x00BA85D4: MOV v0.16b, v8.16b         | V0 = val_72.x;//m1                      
        // 0x00BA85D8: MOV v1.16b, v9.16b         | V1 = val_72.y;//m1                      
        // 0x00BA85DC: MOV v2.16b, v10.16b        | V2 = val_72.z;//m1                      
        // 0x00BA85E0: MOV v3.16b, v11.16b        | V3 = val_72.w;//m1                      
        // 0x00BA85E4: BL #0x26938b0              | val_67.set_rotation(value:  new UnityEngine.Quaternion() {x = val_97, y = val_113, z = val_94, w = val_114});
        val_98.rotation = new UnityEngine.Quaternion() {x = val_97, y = val_113, z = val_94, w = val_114};
        label_74:
        // 0x00BA85E8: SUB sp, x29, #0x80         | SP = (1152921513302729344 - 128) = 1152921513302729216 (0x100000020650A200);
        // 0x00BA85EC: LDP x29, x30, [sp, #0x80]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA85F0: LDP x20, x19, [sp, #0x70]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA85F4: LDP x22, x21, [sp, #0x60]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA85F8: LDP x24, x23, [sp, #0x50]  | X24 = ; X23 = ;                          //  | 
        // 0x00BA85FC: LDP x26, x25, [sp, #0x40]  | X26 = ; X25 = ;                          //  | 
        // 0x00BA8600: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00BA8604: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00BA8608: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00BA860C: LDP d15, d14, [sp], #0x90  | D15 = ; D14 = ;                          //  | 
        // 0x00BA8610: RET                        |  return;                                
        return;
        label_34:
        // 0x00BA8614: LDR s8, [x19, #0xc8]       | S8 = this.time; //P2                    
        // 0x00BA8618: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA861C: CBNZ x21, #0xba8624        | if (this.points != null) goto label_68; 
        if(this.points != null)
        {
            goto label_68;
        }
        // 0x00BA8620: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_68:
        // 0x00BA8624: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00BA8628: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA862C: BL #0x2643344              | X0 = this.points.get_Count();           
        int val_73 = this.points.Count;
        // 0x00BA8630: MOV w21, w0                | W21 = val_73;//m1                       
        // 0x00BA8634: CBNZ x20, #0xba863c        | if (this.rotSpeed != null) goto label_69;
        if(this.rotSpeed != null)
        {
            goto label_69;
        }
        // 0x00BA8638: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_73, ????);     
        label_69:
        // 0x00BA863C: FADD s0, s8, s10           | S0 = (this.time + val_94);              
        float val_74 = this.time + val_94;
        // 0x00BA8640: SCVTF s1, w21              | S1 = (float)(val_73);                   
        // 0x00BA8644: BL #0x9803a0               | X0 = sub_9803A0( ?? val_73, ????);      
        // 0x00BA8648: LDR x2, [x24]              | X2 = public System.Single System.Collections.Generic.List<System.Single>::get_Item(int index);
        // 0x00BA864C: FCVTZS w1, s0              | W1 = (int)((this.time + val_94));       
        // 0x00BA8650: MOV x0, x20                | X0 = this.rotSpeed;//m1                 
        // 0x00BA8654: BL #0x25fad28              | X0 = this.rotSpeed.get_Item(index:  (int)val_74);
        float val_75 = this.rotSpeed.Item[(int)val_74];
        // 0x00BA8658: LDP x21, x20, [x19, #0x18] | X21 = this.points; //P2  X20 = this.rotations; //P2  //  | 
        // 0x00BA865C: LDR s8, [x19, #0xc8]       | S8 = this.time; //P2                    
        // 0x00BA8660: MOV v11.16b, v0.16b        | V11 = val_75;//m1                       
        // 0x00BA8664: CBNZ x21, #0xba866c        | if (this.points != null) goto label_70; 
        if(this.points != null)
        {
            goto label_70;
        }
        // 0x00BA8668: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.rotSpeed, ????);
        label_70:
        // 0x00BA866C: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00BA8670: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA8674: BL #0x2643344              | X0 = this.points.get_Count();           
        int val_76 = this.points.Count;
        // 0x00BA8678: MOV w21, w0                | W21 = val_76;//m1                       
        // 0x00BA867C: CBNZ x20, #0xba8684        | if (this.rotations != null) goto label_71;
        if(this.rotations != null)
        {
            goto label_71;
        }
        // 0x00BA8680: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_76, ????);     
        label_71:
        // 0x00BA8684: FADD s0, s8, s10           | S0 = (this.time + val_94);              
        float val_77 = this.time + val_94;
        // 0x00BA8688: SCVTF s1, w21              | S1 = (float)(val_76);                   
        // 0x00BA868C: BL #0x9803a0               | X0 = sub_9803A0( ?? val_76, ????);      
        // 0x00BA8690: ADRP x22, #0x363e000       | X22 = 56877056 (0x363E000);             
        // 0x00BA8694: LDR x22, [x22, #0x1f0]     | X22 = 1152921510909481968;              
        // 0x00BA8698: FCVTZS w1, s0              | W1 = (int)((this.time + val_94));       
        // 0x00BA869C: MOV x0, x20                | X0 = this.rotations;//m1                
        // 0x00BA86A0: LDR x2, [x22]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA86A4: BL #0x264334c              | X0 = this.rotations.get_Item(index:  (int)val_77);
        UnityEngine.Vector3 val_78 = this.rotations.Item[(int)val_77];
        // 0x00BA86A8: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BA86AC: MOV v8.16b, v0.16b         | V8 = val_78.x;//m1                      
        // 0x00BA86B0: LDR s0, [x8, #0x944]       | S0 = 1000;                              
        // 0x00BA86B4: MOV v9.16b, v1.16b         | V9 = val_78.y;//m1                      
        // 0x00BA86B8: LDR s1, [x19, #0xd0]       | S1 = this.newTime; //P2                 
        // 0x00BA86BC: MOV v10.16b, v2.16b        | V10 = val_78.z;//m1                     
        // 0x00BA86C0: FDIV s14, s11, s0          | S14 = (val_75 / 1000f);                 
        float val_79 = val_75 / 1000f;
        // 0x00BA86C4: FCMP s1, s14               | STATE = COMPARE(this.newTime, (val_75 / 1000f))
        // 0x00BA86C8: B.PL #0xba86d4             | if (this.newTime >= 0) goto label_72;   
        if(this.newTime >= 0)
        {
            goto label_72;
        }
        // 0x00BA86CC: LDRB w8, [x19, #0xd8]      | W8 = this.isRoted; //P2                 
        // 0x00BA86D0: CBZ w8, #0xba86e4          | if (this.isRoted == false) goto label_73;
        if(this.isRoted == false)
        {
            goto label_73;
        }
        label_72:
        // 0x00BA86D4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA86D8: STR wzr, [x19, #0xd0]      | this.newTime = 0;                        //  dest_result_addr=1152921513302741568
        this.newTime = 0f;
        // 0x00BA86DC: STRB w8, [x19, #0xd8]      | this.isRoted = true;                     //  dest_result_addr=1152921513302741576
        this.isRoted = true;
        // 0x00BA86E0: B #0xba85e8                |  goto label_74;                         
        goto label_74;
        label_73:
        // 0x00BA86E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA86E8: MOV x0, x19                | X0 = 1152921513302741360 (0x100000020650D170);//ML01
        // 0x00BA86EC: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_80 = this.transform;
        // 0x00BA86F0: LDR s15, [x19, #0xd0]      | S15 = this.newTime; //P2                
        // 0x00BA86F4: LDR x21, [x19, #0x20]      | X21 = this.rotations; //P2              
        // 0x00BA86F8: LDR s11, [x19, #0xc8]      | S11 = this.time; //P2                   
        // 0x00BA86FC: MOV x20, x0                | X20 = val_80;//m1                       
        // 0x00BA8700: CBNZ x21, #0xba8708        | if (this.rotations != null) goto label_75;
        if(this.rotations != null)
        {
            goto label_75;
        }
        // 0x00BA8704: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_80, ????);     
        label_75:
        // 0x00BA8708: LDR x2, [x22]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA870C: FCVTZS w1, s11             | W1 = (int)(this.time);                  
        // 0x00BA8710: MOV x0, x21                | X0 = this.rotations;//m1                
        // 0x00BA8714: BL #0x264334c              | X0 = this.rotations.get_Item(index:  (int)this.time);
        UnityEngine.Vector3 val_81 = this.rotations.Item[(int)this.time];
        // 0x00BA8718: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BA871C: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BA8720: MOV v11.16b, v0.16b        | V11 = val_81.x;//m1                     
        // 0x00BA8724: MOV v12.16b, v1.16b        | V12 = val_81.y;//m1                     
        // 0x00BA8728: MOV v13.16b, v2.16b        | V13 = val_81.z;//m1                     
        // 0x00BA872C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BA8730: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BA8734: TBZ w8, #0, #0xba8744      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_77;
        // 0x00BA8738: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BA873C: CBNZ w8, #0xba8744         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_77;
        // 0x00BA8740: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_77:
        // 0x00BA8744: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA8748: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA874C: MOV v0.16b, v8.16b         | V0 = val_78.x;//m1                      
        // 0x00BA8750: MOV v1.16b, v9.16b         | V1 = val_78.y;//m1                      
        // 0x00BA8754: MOV v2.16b, v10.16b        | V2 = val_78.z;//m1                      
        // 0x00BA8758: MOV v3.16b, v11.16b        | V3 = val_81.x;//m1                      
        // 0x00BA875C: MOV v4.16b, v12.16b        | V4 = val_81.y;//m1                      
        // 0x00BA8760: MOV v5.16b, v13.16b        | V5 = val_81.z;//m1                      
        // 0x00BA8764: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_78.x, y = val_78.y, z = val_78.z}, b:  new UnityEngine.Vector3() {x = val_81.x, y = val_81.y, z = val_81.z});
        UnityEngine.Vector3 val_82 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_78.x, y = val_78.y, z = val_78.z}, b:  new UnityEngine.Vector3() {x = val_81.x, y = val_81.y, z = val_81.z});
        // 0x00BA8768: MOV v3.16b, v0.16b         | V3 = val_82.x;//m1                      
        // 0x00BA876C: MOV v4.16b, v1.16b         | V4 = val_82.y;//m1                      
        // 0x00BA8770: MOV v5.16b, v2.16b         | V5 = val_82.z;//m1                      
        // 0x00BA8774: FDIV s0, s15, s14          | S0 = (this.newTime / (val_75 / 1000f)); 
        val_100 = this.newTime / val_79;
        // 0x00BA8778: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA877C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8780: MOV v1.16b, v3.16b         | V1 = val_82.x;//m1                      
        val_101 = val_82.x;
        // 0x00BA8784: MOV v2.16b, v4.16b         | V2 = val_82.y;//m1                      
        val_102 = val_82.y;
        // 0x00BA8788: MOV v3.16b, v5.16b         | V3 = val_82.z;//m1                      
        // 0x00BA878C: BL #0x2699650              | X0 = UnityEngine.Vector3.op_Multiply(d:  val_100 = this.newTime / val_79, a:  new UnityEngine.Vector3() {x = val_101, y = val_102, z = val_82.z});
        UnityEngine.Vector3 val_83 = UnityEngine.Vector3.op_Multiply(d:  val_100, a:  new UnityEngine.Vector3() {x = val_101, y = val_102, z = val_82.z});
        // 0x00BA8790: LDR x21, [x19, #0x20]      | X21 = this.rotations; //P2              
        // 0x00BA8794: LDR s11, [x19, #0xc8]      | S11 = this.time; //P2                   
        // 0x00BA8798: MOV v8.16b, v0.16b         | V8 = val_83.x;//m1                      
        val_103 = val_83.x;
        // 0x00BA879C: MOV v9.16b, v1.16b         | V9 = val_83.y;//m1                      
        val_104 = val_83.y;
        // 0x00BA87A0: MOV v10.16b, v2.16b        | V10 = val_83.z;//m1                     
        val_105 = val_83.z;
        // 0x00BA87A4: CBNZ x21, #0xba87ac        | if (this.rotations != null) goto label_78;
        if(this.rotations != null)
        {
            goto label_78;
        }
        // 0x00BA87A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_78:
        // 0x00BA87AC: LDR x2, [x22]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        val_106 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA87B0: FCVTZS w1, s11             | W1 = (int)(this.time);                  
        val_107 = (int)this.time;
        // 0x00BA87B4: MOV x0, x21                | X0 = this.rotations;//m1                
        label_46:
        // 0x00BA87B8: BL #0x264334c              | X0 = this.rotations.get_Item(index:  val_107 = (int)this.time);
        UnityEngine.Vector3 val_84 = this.rotations.Item[val_107];
        // 0x00BA87BC: MOV v3.16b, v0.16b         | V3 = val_84.x;//m1                      
        // 0x00BA87C0: MOV v4.16b, v1.16b         | V4 = val_84.y;//m1                      
        // 0x00BA87C4: MOV v5.16b, v2.16b         | V5 = val_84.z;//m1                      
        // 0x00BA87C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA87CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA87D0: MOV v0.16b, v8.16b         | V0 = val_83.x;//m1                      
        // 0x00BA87D4: MOV v1.16b, v9.16b         | V1 = val_83.y;//m1                      
        // 0x00BA87D8: MOV v2.16b, v10.16b        | V2 = val_83.z;//m1                      
        // 0x00BA87DC: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_103, y = val_104, z = val_105}, b:  new UnityEngine.Vector3() {x = val_84.x, y = val_84.y, z = val_84.z});
        UnityEngine.Vector3 val_85 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_103, y = val_104, z = val_105}, b:  new UnityEngine.Vector3() {x = val_84.x, y = val_84.y, z = val_84.z});
        // 0x00BA87E0: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00BA87E4: LDR x8, [x8, #0xd78]       | X8 = 1152921504695132160;               
        // 0x00BA87E8: MOV v8.16b, v0.16b         | V8 = val_85.x;//m1                      
        // 0x00BA87EC: MOV v9.16b, v1.16b         | V9 = val_85.y;//m1                      
        // 0x00BA87F0: MOV v10.16b, v2.16b        | V10 = val_85.z;//m1                     
        // 0x00BA87F4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Quaternion);    
        // 0x00BA87F8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_10A;
        // 0x00BA87FC: TBZ w8, #0, #0xba880c      | if (UnityEngine.Quaternion.__il2cppRuntimeField_has_cctor == 0) goto label_80;
        // 0x00BA8800: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00BA8804: CBNZ w8, #0xba880c         | if (UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished != 0) goto label_80;
        // 0x00BA8808: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Quaternion), ????);
        label_80:
        // 0x00BA880C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA8810: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8814: MOV v0.16b, v8.16b         | V0 = val_85.x;//m1                      
        // 0x00BA8818: MOV v1.16b, v9.16b         | V1 = val_85.y;//m1                      
        // 0x00BA881C: MOV v2.16b, v10.16b        | V2 = val_85.z;//m1                      
        // 0x00BA8820: BL #0x1b7f628              | X0 = UnityEngine.Quaternion.Euler(euler:  new UnityEngine.Vector3() {x = val_85.x, y = val_85.y, z = val_85.z});
        UnityEngine.Quaternion val_86 = UnityEngine.Quaternion.Euler(euler:  new UnityEngine.Vector3() {x = val_85.x, y = val_85.y, z = val_85.z});
        // 0x00BA8824: B #0xba83d4                |  goto label_81;                         
        goto label_81;
        label_5:
        // 0x00BA8828: ADD x8, sp, #0x18          | X8 = (1152921513302729168 + 24) = 1152921513302729192 (0x100000020650A1E8);
        // 0x00BA882C: MOV x1, x20                | X1 = 1152921504608444416 (0x1000000000186000);//ML01
        // 0x00BA8830: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
        // 0x00BA8834: LDR x0, [sp, #0x18]        | X0 = val_87;                             //  find_add[1152921513302717360]
        // 0x00BA8838: BL #0x27af090              | X0 = sub_27AF090( ?? val_87, ????);     
        // 0x00BA883C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8840: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_87, ????);     
        // 0x00BA8844: ADD x0, sp, #0x18          | X0 = (1152921513302729168 + 24) = 1152921513302729192 (0x100000020650A1E8);
        // 0x00BA8848: BL #0x299a140              | 
        label_14:
        // 0x00BA884C: ADD x8, sp, #0x28          | X8 = (1152921513302729168 + 40) = 1152921513302729208 (0x100000020650A1F8);
        // 0x00BA8850: MOV x1, x22                | X1 = X22;//m1                           
        // 0x00BA8854: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x100000020650A1E8, ????);
        // 0x00BA8858: LDR x0, [sp, #0x28]        | X0 = val_88;                             //  find_add[1152921513302717360]
        // 0x00BA885C: BL #0x27af090              | X0 = sub_27AF090( ?? val_88, ????);     
        // 0x00BA8860: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8864: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_88, ????);     
        // 0x00BA8868: ADD x0, sp, #0x28          | X0 = (1152921513302729168 + 40) = 1152921513302729208 (0x100000020650A1F8);
        // 0x00BA886C: BL #0x299a140              | 
        label_23:
        // 0x00BA8870: ADD x8, sp, #0x20          | X8 = (1152921513302729168 + 32) = 1152921513302729200 (0x100000020650A1F0);
        // 0x00BA8874: MOV x1, x22                | X1 = X22;//m1                           
        // 0x00BA8878: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x100000020650A1F8, ????);
        // 0x00BA887C: LDR x0, [sp, #0x20]        | X0 = val_89;                             //  find_add[1152921513302717360]
        // 0x00BA8880: BL #0x27af090              | X0 = sub_27AF090( ?? val_89, ????);     
        // 0x00BA8884: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8888: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_89, ????);     
        // 0x00BA888C: ADD x0, sp, #0x20          | X0 = (1152921513302729168 + 32) = 1152921513302729200 (0x100000020650A1F0);
        // 0x00BA8890: BL #0x299a140              | 
        // 0x00BA8894: MOV x19, x0                | X19 = 1152921513302729200 (0x100000020650A1F0);//ML01
        val_115;
        // 0x00BA8898: ADD x0, sp, #0x18          | X0 = (1152921513302729168 + 24) = 1152921513302729192 (0x100000020650A1E8);
        // 0x00BA889C: B #0xba88b4                |  goto label_83;                         
        goto label_83;
        // 0x00BA88A0: MOV x19, x0                | X19 = 1152921513302729192 (0x100000020650A1E8);//ML01
        val_115;
        // 0x00BA88A4: ADD x0, sp, #0x28          | X0 = (1152921513302729168 + 40) = 1152921513302729208 (0x100000020650A1F8);
        // 0x00BA88A8: B #0xba88b4                |  goto label_83;                         
        goto label_83;
        // 0x00BA88AC: MOV x19, x0                | X19 = 1152921513302729208 (0x100000020650A1F8);//ML01
        val_115;
        // 0x00BA88B0: ADD x0, sp, #0x20          | X0 = (1152921513302729168 + 32) = 1152921513302729200 (0x100000020650A1F0);
        label_83:
        // 0x00BA88B4: BL #0x299a140              | 
        // 0x00BA88B8: MOV x0, x19                | X0 = 1152921513302729208 (0x100000020650A1F8);//ML01
        // 0x00BA88BC: BL #0x980800               | X0 = sub_980800( ?? 0x100000020650A1F8, ????);
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA88C0 (12224704), len: 1072  VirtAddr: 0x00BA88C0 RVA: 0x00BA88C0 token: 100682709 methodIndex: 25671 delegateWrapperIndex: 0 methodInvoker: 0
    private void CheckProcess()
    {
        //
        // Disasemble & Code
        //  | 
        var val_23;
        //  | 
        var val_24;
        //  | 
        var val_25;
        //  | 
        var val_26;
        //  | 
        var val_27;
        //  | 
        var val_28;
        //  | 
        var val_29;
        //  | 
        float val_30;
        //  | 
        float val_31;
        //  | 
        int val_32;
        //  | 
        float val_33;
        //  | 
        var val_34;
        //  | 
        var val_35;
        // 0x00BA88C0: STP d13, d12, [sp, #-0x70]! | stack[1152921513303111584] = ???;  stack[1152921513303111592] = ???;  //  dest_result_addr=1152921513303111584 |  dest_result_addr=1152921513303111592
        // 0x00BA88C4: STP d11, d10, [sp, #0x10]  | stack[1152921513303111600] = ???;  stack[1152921513303111608] = ???;  //  dest_result_addr=1152921513303111600 |  dest_result_addr=1152921513303111608
        // 0x00BA88C8: STP d9, d8, [sp, #0x20]    | stack[1152921513303111616] = ???;  stack[1152921513303111624] = ???;  //  dest_result_addr=1152921513303111616 |  dest_result_addr=1152921513303111624
        // 0x00BA88CC: STP x24, x23, [sp, #0x30]  | stack[1152921513303111632] = ???;  stack[1152921513303111640] = ???;  //  dest_result_addr=1152921513303111632 |  dest_result_addr=1152921513303111640
        // 0x00BA88D0: STP x22, x21, [sp, #0x40]  | stack[1152921513303111648] = ???;  stack[1152921513303111656] = ???;  //  dest_result_addr=1152921513303111648 |  dest_result_addr=1152921513303111656
        // 0x00BA88D4: STP x20, x19, [sp, #0x50]  | stack[1152921513303111664] = ???;  stack[1152921513303111672] = ???;  //  dest_result_addr=1152921513303111664 |  dest_result_addr=1152921513303111672
        // 0x00BA88D8: STP x29, x30, [sp, #0x60]  | stack[1152921513303111680] = ???;  stack[1152921513303111688] = ???;  //  dest_result_addr=1152921513303111680 |  dest_result_addr=1152921513303111688
        // 0x00BA88DC: ADD x29, sp, #0x60         | X29 = (1152921513303111584 + 96) = 1152921513303111680 (0x1000000206567800);
        // 0x00BA88E0: SUB sp, sp, #0x30          | SP = (1152921513303111584 - 48) = 1152921513303111536 (0x1000000206567770);
        // 0x00BA88E4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA88E8: LDRB w8, [x20, #0xaef]     | W8 = (bool)static_value_03733AEF;       
        // 0x00BA88EC: MOV x19, x0                | X19 = 1152921513303123696 (0x100000020656A6F0);//ML01
        // 0x00BA88F0: TBNZ w8, #0, #0xba890c     | if (static_value_03733AEF == true) goto label_0;
        // 0x00BA88F4: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00BA88F8: LDR x8, [x8, #0x1c0]       | X8 = 0x2B90168;                         
        // 0x00BA88FC: LDR w0, [x8]               | W0 = 0x171E;                            
        // 0x00BA8900: BL #0x2782188              | X0 = sub_2782188( ?? 0x171E, ????);     
        // 0x00BA8904: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA8908: STRB w8, [x20, #0xaef]     | static_value_03733AEF = true;            //  dest_result_addr=57883375
        label_0:
        // 0x00BA890C: LDR s8, [x19, #0xc8]       | S8 = this.time; //P2                    
        // 0x00BA8910: LDR x20, [x19, #0x18]      | X20 = this.points; //P2                 
        // 0x00BA8914: CBNZ x20, #0xba891c        | if (this.points != null) goto label_1;  
        if(this.points != null)
        {
            goto label_1;
        }
        // 0x00BA8918: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x171E, ????);     
        label_1:
        // 0x00BA891C: ADRP x22, #0x35fc000       | X22 = 56606720 (0x35FC000);             
        // 0x00BA8920: LDR x22, [x22, #0x5e0]     | X22 = 1152921510909311600;              
        // 0x00BA8924: MOV x0, x20                | X0 = this.points;//m1                   
        // 0x00BA8928: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00BA892C: BL #0x2643344              | X0 = this.points.get_Count();           
        int val_1 = this.points.Count;
        // 0x00BA8930: SUB w8, w0, #1             | W8 = (val_1 - 1);                       
        int val_2 = val_1 - 1;
        // 0x00BA8934: SCVTF s0, w8               | S0 = (float)((val_1 - 1));              
        // 0x00BA8938: FCMP s8, s0                | STATE = COMPARE(this.time, (val_1 - 1)) 
        // 0x00BA893C: B.LT #0xba8948             | if (this.time < (float)val_2) goto label_2;
        if(this.time < (float)val_2)
        {
            goto label_2;
        }
        // 0x00BA8940: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA8944: STRB w8, [x19, #0xa5]      | this.isAllDown = true;                   //  dest_result_addr=1152921513303123861
        this.isAllDown = true;
        label_2:
        // 0x00BA8948: LDR x20, [x19, #0x70]      | X20 = this.isConstant; //P2             
        // 0x00BA894C: CBNZ x20, #0xba8954        | if (this.isConstant != null) goto label_3;
        if(this.isConstant != null)
        {
            goto label_3;
        }
        // 0x00BA8950: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00BA8954: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
        // 0x00BA8958: LDR x8, [x8, #0x408]       | X8 = 1152921510876430768;               
        // 0x00BA895C: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BA8960: MOV x0, x20                | X0 = this.isConstant;//m1               
        // 0x00BA8964: LDR x2, [x8]               | X2 = public System.Int32 System.Collections.Generic.List<System.Int32>::get_Item(int index);
        // 0x00BA8968: BL #0x25e4de4              | X0 = this.isConstant.get_Item(index:  0);
        int val_3 = this.isConstant.Item[0];
        // 0x00BA896C: LDR s8, [x19, #0xdc]       | S8 = this.time2; //P2                   
        float val_26 = this.time2;
        // 0x00BA8970: MOV w21, w0                | W21 = val_3;//m1                        
        // 0x00BA8974: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA8978: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA897C: BL #0x2690de0              | X0 = UnityEngine.Time.get_fixedDeltaTime();
        float val_4 = UnityEngine.Time.fixedDeltaTime;
        // 0x00BA8980: LDR x20, [x19, #0x38]      | X20 = this.speed; //P2                  
        // 0x00BA8984: FADD s8, s8, s0            | S8 = (this.time2 + val_4);              
        val_26 = val_26 + val_4;
        // 0x00BA8988: STR s8, [x19, #0xdc]       | this.time2 = (this.time2 + val_4);       //  dest_result_addr=1152921513303123916
        this.time2 = val_26;
        // 0x00BA898C: CMP w21, #1                | STATE = COMPARE(val_3, 0x1)             
        // 0x00BA8990: B.NE #0xba8a60             | if (val_3 != 1) goto label_4;           
        if(val_3 != 1)
        {
            goto label_4;
        }
        // 0x00BA8994: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA8998: CBNZ x21, #0xba89a0        | if (this.points != null) goto label_5;  
        if(this.points != null)
        {
            goto label_5;
        }
        // 0x00BA899C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_5:
        // 0x00BA89A0: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00BA89A4: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA89A8: BL #0x2643344              | X0 = this.points.get_Count();           
        int val_5 = this.points.Count;
        // 0x00BA89AC: MOV w21, w0                | W21 = val_5;//m1                        
        // 0x00BA89B0: CBNZ x20, #0xba89b8        | if (this.speed != null) goto label_6;   
        if(this.speed != null)
        {
            goto label_6;
        }
        // 0x00BA89B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_6:
        // 0x00BA89B8: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
        // 0x00BA89BC: LDR x8, [x8, #0xbb0]       | X8 = 1152921510888574288;               
        // 0x00BA89C0: SUB w1, w21, #1            | W1 = (val_5 - 1);                       
        int val_6 = val_5 - 1;
        // 0x00BA89C4: MOV x0, x20                | X0 = this.speed;//m1                    
        // 0x00BA89C8: LDR x2, [x8]               | X2 = public System.Single System.Collections.Generic.List<System.Single>::get_Item(int index);
        // 0x00BA89CC: BL #0x25fad28              | X0 = this.speed.get_Item(index:  int val_6 = val_5 - 1);
        float val_7 = this.speed.Item[val_6];
        // 0x00BA89D0: ADRP x23, #0x35e6000       | X23 = 56516608 (0x35E6000);             
        // 0x00BA89D4: LDR x23, [x23, #0xce8]     | X23 = 1152921504608444416;              
        val_27 = 1152921504608444416;
        // 0x00BA89D8: ADD x1, sp, #0xc           | X1 = (1152921513303111536 + 12) = 1152921513303111548 (0x100000020656777C);
        // 0x00BA89DC: STR s0, [sp, #0xc]         | stack[1152921513303111548] = val_7;      //  dest_result_addr=1152921513303111548
        // 0x00BA89E0: LDR x0, [x23]              | X0 = typeof(System.Single);             
        // 0x00BA89E4: BL #0x27bc028              | X0 = 1152921513303172080 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_7);
        // 0x00BA89E8: MOV x1, x0                 | X1 = 1152921513303172080 (0x10000002065763F0);//ML01
        // 0x00BA89EC: ORR w2, wzr, #2            | W2 = 2(0x2);                            
        // 0x00BA89F0: MOV x0, x19                | X0 = 1152921513303123696 (0x100000020656A6F0);//ML01
        // 0x00BA89F4: BL #0xba8cf0               | X0 = this.CheckDefault(obj:  val_7, str:  2);
        object val_8 = this.CheckDefault(obj:  val_7, str:  2);
        // 0x00BA89F8: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA89FC: MOV x20, x0                | X20 = val_8;//m1                        
        val_28 = val_8;
        // 0x00BA8A00: CBNZ x21, #0xba8a08        | if (this.points != null) goto label_7;  
        if(this.points != null)
        {
            goto label_7;
        }
        // 0x00BA8A04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_7:
        // 0x00BA8A08: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00BA8A0C: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA8A10: BL #0x2643344              | X0 = this.points.get_Count();           
        int val_9 = this.points.Count;
        // 0x00BA8A14: LDR x22, [x23]             | X22 = typeof(System.Single);            
        // 0x00BA8A18: MOV w21, w0                | W21 = val_9;//m1                        
        val_29 = val_9;
        // 0x00BA8A1C: CBNZ x20, #0xba8a24        | if (val_8 != null) goto label_8;        
        if(val_28 != null)
        {
            goto label_8;
        }
        // 0x00BA8A20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_8:
        // 0x00BA8A24: LDR x8, [x20]              | X8 = typeof(System.Object);             
        // 0x00BA8A28: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00BA8A2C: LDR x8, [x22, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
        // 0x00BA8A30: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Single.__il2cppRuntimeField_element_class)
        // 0x00BA8A34: B.NE #0xba8c58             | if (System.Object.__il2cppRuntimeField_element_class != System.Single.__il2cppRuntimeField_element_class) goto label_9;
        // 0x00BA8A38: MOV x0, x20                | X0 = val_8;//m1                         
        // 0x00BA8A3C: BL #0x27bc4e8              | val_8.System.IDisposable.Dispose();     
        val_28.System.IDisposable.Dispose();
        // 0x00BA8A40: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BA8A44: LDR s0, [x0]               | S0 = typeof(System.Object);             
        // 0x00BA8A48: LDR s1, [x8, #0x944]       | S1 = 1000;                              
        // 0x00BA8A4C: FDIV s0, s0, s1            | S0 = (1152921504606900224 / 1000f);     
        float val_10 = null / 1000f;
        // 0x00BA8A50: FDIV s0, s8, s0            | S0 = ((this.time2 + val_4) / (1152921504606900224 / 1000f));
        val_10 = val_26 / val_10;
        // 0x00BA8A54: SCVTF s1, w21              | S1 = (float)(val_9);                    
        val_30 = (float)val_29;
        // 0x00BA8A58: FMUL s0, s1, s0            | S0 = (val_9 * ((this.time2 + val_4) / (1152921504606900224 / 1000f)));
        val_31 = val_30 * val_10;
        // 0x00BA8A5C: B #0xba8bec                |  goto label_10;                         
        goto label_10;
        label_4:
        // 0x00BA8A60: LDR s10, [x19, #0xc8]      | S10 = this.time; //P2                   
        // 0x00BA8A64: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA8A68: CBNZ x21, #0xba8a70        | if (this.points != null) goto label_11; 
        if(this.points != null)
        {
            goto label_11;
        }
        // 0x00BA8A6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_11:
        // 0x00BA8A70: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00BA8A74: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA8A78: BL #0x2643344              | X0 = this.points.get_Count();           
        int val_11 = this.points.Count;
        // 0x00BA8A7C: MOV w21, w0                | W21 = val_11;//m1                       
        // 0x00BA8A80: CBNZ x20, #0xba8a88        | if (this.speed != null) goto label_12;  
        if(this.speed != null)
        {
            goto label_12;
        }
        // 0x00BA8A84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_12:
        // 0x00BA8A88: FMOV s9, #1.00000000       | S9 = 1;                                 
        // 0x00BA8A8C: FADD s0, s10, s9           | S0 = (this.time + 1f);                  
        float val_12 = this.time + 1f;
        // 0x00BA8A90: SCVTF s1, w21              | S1 = (float)(val_11);                   
        // 0x00BA8A94: BL #0x9803a0               | X0 = sub_9803A0( ?? val_11, ????);      
        // 0x00BA8A98: ADRP x24, #0x35e2000       | X24 = 56500224 (0x35E2000);             
        // 0x00BA8A9C: LDR x24, [x24, #0xbb0]     | X24 = 1152921510888574288;              
        // 0x00BA8AA0: FCVTZS w1, s0              | W1 = (int)((this.time + 1f));           
        // 0x00BA8AA4: MOV x0, x20                | X0 = this.speed;//m1                    
        // 0x00BA8AA8: LDR x2, [x24]              | X2 = public System.Single System.Collections.Generic.List<System.Single>::get_Item(int index);
        // 0x00BA8AAC: BL #0x25fad28              | X0 = this.speed.get_Item(index:  (int)val_12);
        float val_13 = this.speed.Item[(int)val_12];
        // 0x00BA8AB0: ADRP x23, #0x35e6000       | X23 = 56516608 (0x35E6000);             
        // 0x00BA8AB4: LDR x23, [x23, #0xce8]     | X23 = 1152921504608444416;              
        val_27 = 1152921504608444416;
        // 0x00BA8AB8: ADD x1, sp, #0x14          | X1 = (1152921513303111536 + 20) = 1152921513303111556 (0x1000000206567784);
        // 0x00BA8ABC: STR s0, [sp, #0x14]        | stack[1152921513303111556] = val_13;     //  dest_result_addr=1152921513303111556
        // 0x00BA8AC0: LDR x0, [x23]              | X0 = typeof(System.Single);             
        // 0x00BA8AC4: BL #0x27bc028              | X0 = 1152921513303188464 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_13);
        // 0x00BA8AC8: MOV x1, x0                 | X1 = 1152921513303188464 (0x100000020657A3F0);//ML01
        // 0x00BA8ACC: ORR w2, wzr, #2            | W2 = 2(0x2);                            
        // 0x00BA8AD0: MOV x0, x19                | X0 = 1152921513303123696 (0x100000020656A6F0);//ML01
        // 0x00BA8AD4: BL #0xba8cf0               | X0 = this.CheckDefault(obj:  val_13, str:  2);
        object val_14 = this.CheckDefault(obj:  val_13, str:  2);
        // 0x00BA8AD8: LDR x20, [x23]             | X20 = typeof(System.Single);            
        val_28 = null;
        // 0x00BA8ADC: MOV x21, x0                | X21 = val_14;//m1                       
        // 0x00BA8AE0: CBNZ x21, #0xba8ae8        | if (val_14 != null) goto label_13;      
        if(val_14 != null)
        {
            goto label_13;
        }
        // 0x00BA8AE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_13:
        // 0x00BA8AE8: LDR x8, [x21]              | X8 = typeof(System.Object);             
        // 0x00BA8AEC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00BA8AF0: LDR x8, [x20, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
        // 0x00BA8AF4: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Single.__il2cppRuntimeField_element_class)
        // 0x00BA8AF8: B.NE #0xba8c7c             | if (System.Object.__il2cppRuntimeField_element_class != System.Single.__il2cppRuntimeField_element_class) goto label_14;
        // 0x00BA8AFC: MOV x0, x21                | X0 = val_14;//m1                        
        // 0x00BA8B00: BL #0x27bc4e8              | val_14.System.IDisposable.Dispose();    
        val_14.System.IDisposable.Dispose();
        // 0x00BA8B04: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00BA8B08: LDR s0, [x0]               | S0 = typeof(System.Object);             
        // 0x00BA8B0C: LDR s10, [x8, #0x944]      | S10 = 1000;                             
        // 0x00BA8B10: LDR s11, [x19, #0xdc]      | S11 = this.time2; //P2                  
        // 0x00BA8B14: LDR x20, [x19, #0x38]      | X20 = this.speed; //P2                  
        // 0x00BA8B18: LDR s12, [x19, #0xc8]      | S12 = this.time; //P2                   
        // 0x00BA8B1C: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA8B20: FDIV s0, s0, s10           | S0 = (1152921504606900224 / 1000f);     
        float val_15 = null / 1000f;
        // 0x00BA8B24: FDIV s0, s8, s0            | S0 = ((this.time2 + val_4) / (1152921504606900224 / 1000f));
        val_15 = val_26 / val_15;
        // 0x00BA8B28: STR s0, [x19, #0xe4]       | this.time_F = ((this.time2 + val_4) / (1152921504606900224 / 1000f));  //  dest_result_addr=1152921513303123924
        this.time_F = val_15;
        // 0x00BA8B2C: CBNZ x21, #0xba8b34        | if (this.points != null) goto label_15; 
        if(this.points != null)
        {
            goto label_15;
        }
        // 0x00BA8B30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_15:
        // 0x00BA8B34: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00BA8B38: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA8B3C: BL #0x2643344              | X0 = this.points.get_Count();           
        int val_16 = this.points.Count;
        // 0x00BA8B40: MOV w21, w0                | W21 = val_16;//m1                       
        // 0x00BA8B44: CBNZ x20, #0xba8b4c        | if (this.speed != null) goto label_16;  
        if(this.speed != null)
        {
            goto label_16;
        }
        // 0x00BA8B48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_16:
        // 0x00BA8B4C: FADD s0, s12, s9           | S0 = (this.time + 1f);                  
        float val_17 = this.time + 1f;
        // 0x00BA8B50: SCVTF s1, w21              | S1 = (float)(val_16);                   
        // 0x00BA8B54: BL #0x9803a0               | X0 = sub_9803A0( ?? val_16, ????);      
        // 0x00BA8B58: LDR x2, [x24]              | X2 = public System.Single System.Collections.Generic.List<System.Single>::get_Item(int index);
        // 0x00BA8B5C: FCVTZS w1, s0              | W1 = (int)((this.time + 1f));           
        // 0x00BA8B60: MOV x0, x20                | X0 = this.speed;//m1                    
        // 0x00BA8B64: BL #0x25fad28              | X0 = this.speed.get_Item(index:  (int)val_17);
        float val_18 = this.speed.Item[(int)val_17];
        // 0x00BA8B68: LDR x0, [x23]              | X0 = typeof(System.Single);             
        // 0x00BA8B6C: ADD x1, sp, #0x10          | X1 = (1152921513303111536 + 16) = 1152921513303111552 (0x1000000206567780);
        // 0x00BA8B70: STR s0, [sp, #0x10]        | stack[1152921513303111552] = val_18;     //  dest_result_addr=1152921513303111552
        // 0x00BA8B74: BL #0x27bc028              | X0 = 1152921513303204848 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_18);
        // 0x00BA8B78: MOV x1, x0                 | X1 = 1152921513303204848 (0x100000020657E3F0);//ML01
        // 0x00BA8B7C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
        // 0x00BA8B80: MOV x0, x19                | X0 = 1152921513303123696 (0x100000020656A6F0);//ML01
        // 0x00BA8B84: BL #0xba8cf0               | X0 = this.CheckDefault(obj:  val_18, str:  2);
        object val_19 = this.CheckDefault(obj:  val_18, str:  2);
        // 0x00BA8B88: LDR x20, [x23]             | X20 = typeof(System.Single);            
        val_28 = null;
        // 0x00BA8B8C: MOV x21, x0                | X21 = val_19;//m1                       
        val_29 = val_19;
        // 0x00BA8B90: CBNZ x21, #0xba8b98        | if (val_19 != null) goto label_17;      
        if(val_29 != null)
        {
            goto label_17;
        }
        // 0x00BA8B94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_17:
        // 0x00BA8B98: LDR x8, [x21]              | X8 = typeof(System.Object);             
        // 0x00BA8B9C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00BA8BA0: LDR x8, [x20, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
        // 0x00BA8BA4: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Single.__il2cppRuntimeField_element_class)
        // 0x00BA8BA8: B.NE #0xba8ca0             | if (System.Object.__il2cppRuntimeField_element_class != System.Single.__il2cppRuntimeField_element_class) goto label_18;
        // 0x00BA8BAC: MOV x0, x21                | X0 = val_19;//m1                        
        // 0x00BA8BB0: BL #0x27bc4e8              | val_19.System.IDisposable.Dispose();    
        val_29.System.IDisposable.Dispose();
        // 0x00BA8BB4: LDR s0, [x0]               | S0 = typeof(System.Object);             
        // 0x00BA8BB8: FDIV s0, s0, s10           | S0 = (1152921504606900224 / 1000f);     
        float val_20 = null / 1000f;
        // 0x00BA8BBC: FCMP s11, s0               | STATE = COMPARE(this.time2, (1152921504606900224 / 1000f))
        // 0x00BA8BC0: B.GE #0xba8bd0             | if (this.time2 >= val_20) goto label_19;
        if(this.time2 >= val_20)
        {
            goto label_19;
        }
        // 0x00BA8BC4: LDR w8, [x19, #0xe0]       | W8 = this.time_I; //P2                  
        val_32 = this.time_I;
        // 0x00BA8BC8: LDR s0, [x19, #0xe4]       | S0 = this.time_F; //P2                  
        val_33 = this.time_F;
        // 0x00BA8BCC: B #0xba8be4                |  goto label_20;                         
        goto label_20;
        label_19:
        // 0x00BA8BD0: LDR w8, [x19, #0xe0]       | W8 = this.time_I; //P2                  
        // 0x00BA8BD4: FMOV s0, wzr               | S0 = 0f;                                
        val_33 = 0f;
        // 0x00BA8BD8: STR wzr, [x19, #0xe4]      | this.time_F = 0;                         //  dest_result_addr=1152921513303123924
        this.time_F = 0f;
        // 0x00BA8BDC: ADD w8, w8, #1             | W8 = (this.time_I + 1);                 
        val_32 = this.time_I + 1;
        // 0x00BA8BE0: STP wzr, w8, [x19, #0xdc]  | this.time2 = 0;  this.time_I = (this.time_I + 1);  //  dest_result_addr=1152921513303123916 |  dest_result_addr=1152921513303123920
        this.time2 = 0f;
        this.time_I = val_32;
        label_20:
        // 0x00BA8BE4: SCVTF s1, w8               | S1 = (float)((this.time_I + 1));        
        val_30 = (float)val_32;
        // 0x00BA8BE8: FADD s0, s1, s0            | S0 = ((this.time_I + 1) + val_33);      
        val_31 = val_30 + val_33;
        label_10:
        // 0x00BA8BEC: MOV x0, x19                | X0 = 1152921513303123696 (0x100000020656A6F0);//ML01
        // 0x00BA8BF0: STR s0, [x19, #0xc8]       | this.time = ((this.time_I + 1) + val_33);  //  dest_result_addr=1152921513303123896
        this.time = val_31;
        // 0x00BA8BF4: BL #0xba8f6c               | X0 = this.Plot(t:  val_31 = val_30 + val_33);
        UnityEngine.Vector3 val_21 = this.Plot(t:  val_31);
        // 0x00BA8BF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8BFC: MOV x0, x19                | X0 = 1152921513303123696 (0x100000020656A6F0);//ML01
        // 0x00BA8C00: MOV v8.16b, v0.16b         | V8 = val_21.x;//m1                      
        // 0x00BA8C04: MOV v9.16b, v1.16b         | V9 = val_21.y;//m1                      
        // 0x00BA8C08: MOV v10.16b, v2.16b        | V10 = val_21.z;//m1                     
        // 0x00BA8C0C: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_22 = this.transform;
        // 0x00BA8C10: MOV x19, x0                | X19 = val_22;//m1                       
        // 0x00BA8C14: CBNZ x19, #0xba8c1c        | if (val_22 != null) goto label_21;      
        if(val_22 != null)
        {
            goto label_21;
        }
        // 0x00BA8C18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_21:
        // 0x00BA8C1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8C20: MOV x0, x19                | X0 = val_22;//m1                        
        // 0x00BA8C24: MOV v0.16b, v8.16b         | V0 = val_21.x;//m1                      
        // 0x00BA8C28: MOV v1.16b, v9.16b         | V1 = val_21.y;//m1                      
        // 0x00BA8C2C: MOV v2.16b, v10.16b        | V2 = val_21.z;//m1                      
        // 0x00BA8C30: BL #0x26935b8              | val_22.set_position(value:  new UnityEngine.Vector3() {x = val_21.x, y = val_21.y, z = val_21.z});
        val_22.position = new UnityEngine.Vector3() {x = val_21.x, y = val_21.y, z = val_21.z};
        // 0x00BA8C34: SUB sp, x29, #0x60         | SP = (1152921513303111680 - 96) = 1152921513303111584 (0x10000002065677A0);
        // 0x00BA8C38: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA8C3C: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA8C40: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA8C44: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
        // 0x00BA8C48: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x00BA8C4C: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x00BA8C50: LDP d13, d12, [sp], #0x70  | D13 = ; D12 = ;                          //  | 
        // 0x00BA8C54: RET                        |  return;                                
        return;
        label_9:
        // 0x00BA8C58: ADD x8, sp, #0x18          | X8 = (1152921513303111536 + 24) = 1152921513303111560 (0x1000000206567788);
        // 0x00BA8C5C: MOV x1, x22                | X1 = 1152921504608444416 (0x1000000000186000);//ML01
        // 0x00BA8C60: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
        // 0x00BA8C64: LDR x0, [sp, #0x18]        | X0 = val_23;                             //  find_add[1152921513303099696]
        // 0x00BA8C68: BL #0x27af090              | X0 = sub_27AF090( ?? val_23, ????);     
        // 0x00BA8C6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8C70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
        // 0x00BA8C74: ADD x0, sp, #0x18          | X0 = (1152921513303111536 + 24) = 1152921513303111560 (0x1000000206567788);
        // 0x00BA8C78: BL #0x299a140              | 
        label_14:
        // 0x00BA8C7C: ADD x8, sp, #0x20          | X8 = (1152921513303111536 + 32) = 1152921513303111568 (0x1000000206567790);
        // 0x00BA8C80: MOV x1, x20                | X1 = val_8;//m1                         
        // 0x00BA8C84: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000206567788, ????);
        // 0x00BA8C88: LDR x0, [sp, #0x20]        | X0 = val_24;                             //  find_add[1152921513303099696]
        // 0x00BA8C8C: BL #0x27af090              | X0 = sub_27AF090( ?? val_24, ????);     
        // 0x00BA8C90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8C94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_24, ????);     
        // 0x00BA8C98: ADD x0, sp, #0x20          | X0 = (1152921513303111536 + 32) = 1152921513303111568 (0x1000000206567790);
        // 0x00BA8C9C: BL #0x299a140              | 
        label_18:
        // 0x00BA8CA0: ADD x8, sp, #0x28          | X8 = (1152921513303111536 + 40) = 1152921513303111576 (0x1000000206567798);
        // 0x00BA8CA4: MOV x1, x20                | X1 = val_8;//m1                         
        // 0x00BA8CA8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000206567790, ????);
        // 0x00BA8CAC: LDR x0, [sp, #0x28]        | X0 = val_25;                             //  find_add[1152921513303099696]
        // 0x00BA8CB0: BL #0x27af090              | X0 = sub_27AF090( ?? val_25, ????);     
        // 0x00BA8CB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA8CB8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_25, ????);     
        // 0x00BA8CBC: ADD x0, sp, #0x28          | X0 = (1152921513303111536 + 40) = 1152921513303111576 (0x1000000206567798);
        // 0x00BA8CC0: BL #0x299a140              | 
        // 0x00BA8CC4: MOV x19, x0                | X19 = 1152921513303111576 (0x1000000206567798);//ML01
        val_34;
        // 0x00BA8CC8: ADD x0, sp, #0x18          | X0 = (1152921513303111536 + 24) = 1152921513303111560 (0x1000000206567788);
        // 0x00BA8CCC: B #0xba8ce4                |  goto label_23;                         
        goto label_23;
        // 0x00BA8CD0: MOV x19, x0                | X19 = 1152921513303111560 (0x1000000206567788);//ML01
        val_34;
        // 0x00BA8CD4: ADD x0, sp, #0x20          | X0 = (1152921513303111536 + 32) = 1152921513303111568 (0x1000000206567790);
        // 0x00BA8CD8: B #0xba8ce4                |  goto label_23;                         
        goto label_23;
        // 0x00BA8CDC: MOV x19, x0                | X19 = 1152921513303111568 (0x1000000206567790);//ML01
        val_34;
        // 0x00BA8CE0: ADD x0, sp, #0x28          | X0 = (1152921513303111536 + 40) = 1152921513303111576 (0x1000000206567798);
        label_23:
        // 0x00BA8CE4: BL #0x299a140              | 
        // 0x00BA8CE8: MOV x0, x19                | X0 = 1152921513303111568 (0x1000000206567790);//ML01
        // 0x00BA8CEC: BL #0x980800               | X0 = sub_980800( ?? 0x1000000206567790, ????);
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA8F6C (12226412), len: 2808  VirtAddr: 0x00BA8F6C RVA: 0x00BA8F6C token: 100682710 methodIndex: 25672 delegateWrapperIndex: 0 methodInvoker: 0
    private UnityEngine.Vector3 Plot(float t)
    {
        //
        // Disasemble & Code
        //  | 
        var val_93;
        //  | 
        var val_94;
        //  | 
        var val_95;
        //  | 
        var val_96;
        //  | 
        var val_97;
        //  | 
        var val_98;
        //  | 
        var val_99;
        // 0x00BA8F6C: STP d15, d14, [sp, #-0xa0]! | stack[1152921513303420144] = ???;  stack[1152921513303420152] = ???;  //  dest_result_addr=1152921513303420144 |  dest_result_addr=1152921513303420152
        // 0x00BA8F70: STP d13, d12, [sp, #0x10]  | stack[1152921513303420160] = ???;  stack[1152921513303420168] = ???;  //  dest_result_addr=1152921513303420160 |  dest_result_addr=1152921513303420168
        // 0x00BA8F74: STP d11, d10, [sp, #0x20]  | stack[1152921513303420176] = ???;  stack[1152921513303420184] = ???;  //  dest_result_addr=1152921513303420176 |  dest_result_addr=1152921513303420184
        // 0x00BA8F78: STP d9, d8, [sp, #0x30]    | stack[1152921513303420192] = ???;  stack[1152921513303420200] = ???;  //  dest_result_addr=1152921513303420192 |  dest_result_addr=1152921513303420200
        // 0x00BA8F7C: STP x28, x27, [sp, #0x40]  | stack[1152921513303420208] = ???;  stack[1152921513303420216] = ???;  //  dest_result_addr=1152921513303420208 |  dest_result_addr=1152921513303420216
        // 0x00BA8F80: STP x26, x25, [sp, #0x50]  | stack[1152921513303420224] = ???;  stack[1152921513303420232] = ???;  //  dest_result_addr=1152921513303420224 |  dest_result_addr=1152921513303420232
        // 0x00BA8F84: STP x24, x23, [sp, #0x60]  | stack[1152921513303420240] = ???;  stack[1152921513303420248] = ???;  //  dest_result_addr=1152921513303420240 |  dest_result_addr=1152921513303420248
        // 0x00BA8F88: STP x22, x21, [sp, #0x70]  | stack[1152921513303420256] = ???;  stack[1152921513303420264] = ???;  //  dest_result_addr=1152921513303420256 |  dest_result_addr=1152921513303420264
        // 0x00BA8F8C: STP x20, x19, [sp, #0x80]  | stack[1152921513303420272] = ???;  stack[1152921513303420280] = ???;  //  dest_result_addr=1152921513303420272 |  dest_result_addr=1152921513303420280
        // 0x00BA8F90: STP x29, x30, [sp, #0x90]  | stack[1152921513303420288] = ???;  stack[1152921513303420296] = ???;  //  dest_result_addr=1152921513303420288 |  dest_result_addr=1152921513303420296
        // 0x00BA8F94: ADD x29, sp, #0x90         | X29 = (1152921513303420144 + 144) = 1152921513303420288 (0x10000002065B2D80);
        // 0x00BA8F98: SUB sp, sp, #0xe0          | SP = (1152921513303420144 - 224) = 1152921513303419920 (0x10000002065B2C10);
        // 0x00BA8F9C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA8FA0: LDRB w8, [x20, #0xaf0]     | W8 = (bool)static_value_03733AF0;       
        // 0x00BA8FA4: MOV v8.16b, v0.16b         | V8 = t;//m1                             
        // 0x00BA8FA8: MOV x19, x0                | X19 = 1152921513303432304 (0x10000002065B5C70);//ML01
        // 0x00BA8FAC: TBNZ w8, #0, #0xba8fc8     | if (static_value_03733AF0 == true) goto label_0;
        // 0x00BA8FB0: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
        // 0x00BA8FB4: LDR x8, [x8, #0xa40]       | X8 = 0x2B90174;                         
        // 0x00BA8FB8: LDR w0, [x8]               | W0 = 0x1721;                            
        // 0x00BA8FBC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1721, ????);     
        // 0x00BA8FC0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA8FC4: STRB w8, [x20, #0xaf0]     | static_value_03733AF0 = true;            //  dest_result_addr=57883376
        label_0:
        // 0x00BA8FC8: STR wzr, [sp, #0xb8]       | stack[1152921513303420104] = 0x0;        //  dest_result_addr=1152921513303420104
        // 0x00BA8FCC: STR xzr, [sp, #0xb0]       | stack[1152921513303420096] = 0x0;        //  dest_result_addr=1152921513303420096
        // 0x00BA8FD0: STR wzr, [sp, #0xa8]       | stack[1152921513303420088] = 0x0;        //  dest_result_addr=1152921513303420088
        // 0x00BA8FD4: STR xzr, [sp, #0xa0]       | stack[1152921513303420080] = 0x0;        //  dest_result_addr=1152921513303420080
        // 0x00BA8FD8: STR wzr, [sp, #0x98]       | stack[1152921513303420072] = 0x0;        //  dest_result_addr=1152921513303420072
        // 0x00BA8FDC: STR xzr, [sp, #0x90]       | stack[1152921513303420064] = 0x0;        //  dest_result_addr=1152921513303420064
        // 0x00BA8FE0: STR wzr, [sp, #0x88]       | stack[1152921513303420056] = 0x0;        //  dest_result_addr=1152921513303420056
        // 0x00BA8FE4: STR xzr, [sp, #0x80]       | stack[1152921513303420048] = 0x0;        //  dest_result_addr=1152921513303420048
        // 0x00BA8FE8: STR wzr, [sp, #0x78]       | stack[1152921513303420040] = 0x0;        //  dest_result_addr=1152921513303420040
        // 0x00BA8FEC: STR xzr, [sp, #0x70]       | stack[1152921513303420032] = 0x0;        //  dest_result_addr=1152921513303420032
        // 0x00BA8FF0: STR wzr, [sp, #0x68]       | stack[1152921513303420024] = 0x0;        //  dest_result_addr=1152921513303420024
        // 0x00BA8FF4: STR xzr, [sp, #0x60]       | stack[1152921513303420016] = 0x0;        //  dest_result_addr=1152921513303420016
        // 0x00BA8FF8: LDR x20, [x19, #0x18]      | X20 = this.points; //P2                 
        // 0x00BA8FFC: CBNZ x20, #0xba9004        | if (this.points != null) goto label_1;  
        if(this.points != null)
        {
            goto label_1;
        }
        // 0x00BA9000: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1721, ????);     
        label_1:
        // 0x00BA9004: ADRP x24, #0x35fc000       | X24 = 56606720 (0x35FC000);             
        // 0x00BA9008: LDR x24, [x24, #0x5e0]     | X24 = 1152921510909311600;              
        // 0x00BA900C: MOV x0, x20                | X0 = this.points;//m1                   
        // 0x00BA9010: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00BA9014: BL #0x2643344              | X0 = this.points.get_Count();           
        int val_1 = this.points.Count;
        // 0x00BA9018: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00BA901C: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00BA9020: MOV w20, w0                | W20 = val_1;//m1                        
        // 0x00BA9024: LDR x8, [x8]               | X8 = typeof(UnityEngine.Mathf);         
        // 0x00BA9028: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00BA902C: TBZ w9, #0, #0xba9040      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00BA9030: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00BA9034: CBNZ w9, #0xba9040         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00BA9038: MOV x0, x8                 | X0 = 1152921504695345152 (0x1000000005466000);//ML01
        // 0x00BA903C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_3:
        // 0x00BA9040: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA9044: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9048: MOV v0.16b, v8.16b         | V0 = t;//m1                             
        // 0x00BA904C: STR s8, [sp, #0x2c]        | stack[1152921513303419964] = t;          //  dest_result_addr=1152921513303419964
        // 0x00BA9050: BL #0x1a7dc18              | X0 = UnityEngine.Mathf.FloorToInt(f:  t);
        int val_2 = UnityEngine.Mathf.FloorToInt(f:  t);
        // 0x00BA9054: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA9058: MOV w22, w0                | W22 = val_2;//m1                        
        // 0x00BA905C: STR w22, [x19, #0xc4]      | this.pt = val_2;                         //  dest_result_addr=1152921513303432500
        this.pt = val_2;
        // 0x00BA9060: CBNZ x21, #0xba9068        | if (this.points != null) goto label_4;  
        if(this.points != null)
        {
            goto label_4;
        }
        // 0x00BA9064: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00BA9068: ADRP x23, #0x363e000       | X23 = 56877056 (0x363E000);             
        // 0x00BA906C: LDR x23, [x23, #0x1f0]     | X23 = 1152921510909481968;              
        // 0x00BA9070: ADD w8, w22, #1            | W8 = (val_2 + 1);                       
        int val_3 = val_2 + 1;
        // 0x00BA9074: SDIV w9, w8, w20           | W9 = ((val_2 + 1) / val_1);             
        int val_4 = val_3 / val_1;
        // 0x00BA9078: MSUB w1, w9, w20, w8       | W1 = (val_2 + 1) - (((val_2 + 1) / val_1) * val_1);
        int val_5 = val_3 - (val_4 * val_1);
        // 0x00BA907C: LDR x2, [x23]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA9080: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA9084: BL #0x264334c              | X0 = this.points.get_Item(index:  int val_5 = val_3 - (val_4 * val_1));
        UnityEngine.Vector3 val_6 = this.points.Item[val_5];
        // 0x00BA9088: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA908C: LDR w22, [x19, #0xc4]      | W22 = this.pt; //P2                     
        // 0x00BA9090: MOV v8.16b, v0.16b         | V8 = val_6.x;//m1                       
        // 0x00BA9094: MOV v9.16b, v1.16b         | V9 = val_6.y;//m1                       
        // 0x00BA9098: MOV v10.16b, v2.16b        | V10 = val_6.z;//m1                      
        // 0x00BA909C: CBNZ x21, #0xba90a4        | if (this.points != null) goto label_5;  
        if(this.points != null)
        {
            goto label_5;
        }
        // 0x00BA90A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points, ????);
        label_5:
        // 0x00BA90A4: LDR x2, [x23]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA90A8: SDIV w8, w22, w20          | W8 = (this.pt / val_1);                 
        int val_7 = this.pt / val_1;
        // 0x00BA90AC: MSUB w1, w8, w20, w22      | W1 = this.pt - ((this.pt / val_1) * val_1);
        int val_8 = this.pt - (val_7 * val_1);
        // 0x00BA90B0: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA90B4: BL #0x264334c              | X0 = this.points.get_Item(index:  int val_8 = this.pt - (val_7 * val_1));
        UnityEngine.Vector3 val_9 = this.points.Item[val_8];
        // 0x00BA90B8: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BA90BC: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BA90C0: MOV v11.16b, v0.16b        | V11 = val_9.x;//m1                      
        // 0x00BA90C4: MOV v12.16b, v1.16b        | V12 = val_9.y;//m1                      
        // 0x00BA90C8: MOV v13.16b, v2.16b        | V13 = val_9.z;//m1                      
        // 0x00BA90CC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BA90D0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BA90D4: TBZ w8, #0, #0xba90e4      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x00BA90D8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BA90DC: CBNZ w8, #0xba90e4         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x00BA90E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_7:
        // 0x00BA90E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA90E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA90EC: MOV v0.16b, v8.16b         | V0 = val_6.x;//m1                       
        // 0x00BA90F0: MOV v1.16b, v9.16b         | V1 = val_6.y;//m1                       
        // 0x00BA90F4: MOV v2.16b, v10.16b        | V2 = val_6.z;//m1                       
        // 0x00BA90F8: MOV v3.16b, v11.16b        | V3 = val_9.x;//m1                       
        // 0x00BA90FC: MOV v4.16b, v12.16b        | V4 = val_9.y;//m1                       
        // 0x00BA9100: MOV v5.16b, v13.16b        | V5 = val_9.z;//m1                       
        // 0x00BA9104: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z}, b:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z});
        UnityEngine.Vector3 val_10 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z}, b:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z});
        // 0x00BA9108: ADD x0, sp, #0xb0          | X0 = (1152921513303419920 + 176) = 1152921513303420096 (0x10000002065B2CC0);
        // 0x00BA910C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9110: STP s0, s1, [sp, #0xb0]    | stack[1152921513303420096] = val_10.x;  stack[1152921513303420100] = val_10.y;  //  dest_result_addr=1152921513303420096 |  dest_result_addr=1152921513303420100
        // 0x00BA9114: STR s2, [sp, #0xb8]        | stack[1152921513303420104] = val_10.z;   //  dest_result_addr=1152921513303420104
        // 0x00BA9118: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00BA911C: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA9120: LDR w22, [x19, #0xc4]      | W22 = this.pt; //P2                     
        // 0x00BA9124: MOV v8.16b, v0.16b         | V8 = val_10.x;//m1                      
        // 0x00BA9128: MOV v9.16b, v1.16b         | V9 = val_10.y;//m1                      
        // 0x00BA912C: MOV v10.16b, v2.16b        | V10 = val_10.z;//m1                     
        // 0x00BA9130: CBNZ x21, #0xba9138        | if (this.points != null) goto label_8;  
        if(this.points != null)
        {
            goto label_8;
        }
        // 0x00BA9134: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002065B2CC0, ????);
        label_8:
        // 0x00BA9138: ADD w8, w20, w22           | W8 = (val_1 + this.pt);                 
        int val_11 = val_1 + this.pt;
        // 0x00BA913C: LDR x2, [x23]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA9140: SUB w8, w8, #1             | W8 = ((val_1 + this.pt) - 1);           
        val_11 = val_11 - 1;
        // 0x00BA9144: SDIV w9, w8, w20           | W9 = (((val_1 + this.pt) - 1) / val_1); 
        int val_12 = val_11 / val_1;
        // 0x00BA9148: MSUB w1, w9, w20, w8       | W1 = ((val_1 + this.pt) - 1) - ((((val_1 + this.pt) - 1) / val_1) * val_1);
        int val_13 = val_11 - (val_12 * val_1);
        // 0x00BA914C: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA9150: BL #0x264334c              | X0 = this.points.get_Item(index:  int val_13 = val_11 - (val_12 * val_1));
        UnityEngine.Vector3 val_14 = this.points.Item[val_13];
        // 0x00BA9154: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA9158: LDR w22, [x19, #0xc4]      | W22 = this.pt; //P2                     
        // 0x00BA915C: MOV v11.16b, v0.16b        | V11 = val_14.x;//m1                     
        // 0x00BA9160: MOV v12.16b, v1.16b        | V12 = val_14.y;//m1                     
        // 0x00BA9164: MOV v13.16b, v2.16b        | V13 = val_14.z;//m1                     
        // 0x00BA9168: CBNZ x21, #0xba9170        | if (this.points != null) goto label_9;  
        if(this.points != null)
        {
            goto label_9;
        }
        // 0x00BA916C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points, ????);
        label_9:
        // 0x00BA9170: LDR x2, [x23]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA9174: SDIV w8, w22, w20          | W8 = (this.pt / val_1);                 
        int val_15 = this.pt / val_1;
        // 0x00BA9178: MSUB w1, w8, w20, w22      | W1 = this.pt - ((this.pt / val_1) * val_1);
        int val_16 = this.pt - (val_15 * val_1);
        // 0x00BA917C: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA9180: BL #0x264334c              | X0 = this.points.get_Item(index:  int val_16 = this.pt - (val_15 * val_1));
        UnityEngine.Vector3 val_17 = this.points.Item[val_16];
        // 0x00BA9184: MOV v3.16b, v0.16b         | V3 = val_17.x;//m1                      
        // 0x00BA9188: MOV v4.16b, v1.16b         | V4 = val_17.y;//m1                      
        // 0x00BA918C: MOV v5.16b, v2.16b         | V5 = val_17.z;//m1                      
        // 0x00BA9190: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA9194: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9198: MOV v0.16b, v11.16b        | V0 = val_14.x;//m1                      
        // 0x00BA919C: MOV v1.16b, v12.16b        | V1 = val_14.y;//m1                      
        // 0x00BA91A0: MOV v2.16b, v13.16b        | V2 = val_14.z;//m1                      
        // 0x00BA91A4: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_14.x, y = val_14.y, z = val_14.z}, b:  new UnityEngine.Vector3() {x = val_17.x, y = val_17.y, z = val_17.z});
        UnityEngine.Vector3 val_18 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_14.x, y = val_14.y, z = val_14.z}, b:  new UnityEngine.Vector3() {x = val_17.x, y = val_17.y, z = val_17.z});
        // 0x00BA91A8: ADD x0, sp, #0xa0          | X0 = (1152921513303419920 + 160) = 1152921513303420080 (0x10000002065B2CB0);
        // 0x00BA91AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA91B0: STP s0, s1, [sp, #0xa0]    | stack[1152921513303420080] = val_18.x;  stack[1152921513303420084] = val_18.y;  //  dest_result_addr=1152921513303420080 |  dest_result_addr=1152921513303420084
        // 0x00BA91B4: STR s2, [sp, #0xa8]        | stack[1152921513303420088] = val_18.z;   //  dest_result_addr=1152921513303420088
        // 0x00BA91B8: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00BA91BC: MOV v3.16b, v0.16b         | V3 = val_18.x;//m1                      
        // 0x00BA91C0: MOV v4.16b, v1.16b         | V4 = val_18.y;//m1                      
        // 0x00BA91C4: MOV v5.16b, v2.16b         | V5 = val_18.z;//m1                      
        // 0x00BA91C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA91CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA91D0: MOV v0.16b, v8.16b         | V0 = val_10.x;//m1                      
        // 0x00BA91D4: MOV v1.16b, v9.16b         | V1 = val_10.y;//m1                      
        // 0x00BA91D8: MOV v2.16b, v10.16b        | V2 = val_10.z;//m1                      
        // 0x00BA91DC: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z}, b:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z});
        UnityEngine.Vector3 val_19 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z}, b:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z});
        // 0x00BA91E0: ADD x0, sp, #0x90          | X0 = (1152921513303419920 + 144) = 1152921513303420064 (0x10000002065B2CA0);
        // 0x00BA91E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA91E8: STP s0, s1, [sp, #0x90]    | stack[1152921513303420064] = val_19.x;  stack[1152921513303420068] = val_19.y;  //  dest_result_addr=1152921513303420064 |  dest_result_addr=1152921513303420068
        // 0x00BA91EC: STR s2, [sp, #0x98]        | stack[1152921513303420072] = val_19.z;   //  dest_result_addr=1152921513303420072
        // 0x00BA91F0: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00BA91F4: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA91F8: LDR w22, [x19, #0xc4]      | W22 = this.pt; //P2                     
        // 0x00BA91FC: MOV v14.16b, v0.16b        | V14 = val_19.x;//m1                     
        // 0x00BA9200: STR s1, [sp, #0x4c]        | stack[1152921513303419996] = val_19.y;   //  dest_result_addr=1152921513303419996
        // 0x00BA9204: STR s2, [sp, #0x48]        | stack[1152921513303419992] = val_19.z;   //  dest_result_addr=1152921513303419992
        // 0x00BA9208: CBNZ x21, #0xba9210        | if (this.points != null) goto label_10; 
        if(this.points != null)
        {
            goto label_10;
        }
        // 0x00BA920C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002065B2CA0, ????);
        label_10:
        // 0x00BA9210: LDR x2, [x23]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA9214: ADD w8, w22, #2            | W8 = (this.pt + 2);                     
        int val_20 = this.pt + 2;
        // 0x00BA9218: SDIV w9, w8, w20           | W9 = ((this.pt + 2) / val_1);           
        int val_21 = val_20 / val_1;
        // 0x00BA921C: MSUB w1, w9, w20, w8       | W1 = (this.pt + 2) - (((this.pt + 2) / val_1) * val_1);
        int val_22 = val_20 - (val_21 * val_1);
        // 0x00BA9220: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA9224: BL #0x264334c              | X0 = this.points.get_Item(index:  int val_22 = val_20 - (val_21 * val_1));
        UnityEngine.Vector3 val_23 = this.points.Item[val_22];
        // 0x00BA9228: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA922C: LDR w22, [x19, #0xc4]      | W22 = this.pt; //P2                     
        // 0x00BA9230: MOV v8.16b, v0.16b         | V8 = val_23.x;//m1                      
        // 0x00BA9234: MOV v9.16b, v1.16b         | V9 = val_23.y;//m1                      
        // 0x00BA9238: MOV v10.16b, v2.16b        | V10 = val_23.z;//m1                     
        // 0x00BA923C: CBNZ x21, #0xba9244        | if (this.points != null) goto label_11; 
        if(this.points != null)
        {
            goto label_11;
        }
        // 0x00BA9240: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points, ????);
        label_11:
        // 0x00BA9244: LDR x2, [x23]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA9248: ADD w8, w22, #1            | W8 = (this.pt + 1);                     
        int val_24 = this.pt + 1;
        // 0x00BA924C: SDIV w9, w8, w20           | W9 = ((this.pt + 1) / val_1);           
        int val_25 = val_24 / val_1;
        // 0x00BA9250: MSUB w1, w9, w20, w8       | W1 = (this.pt + 1) - (((this.pt + 1) / val_1) * val_1);
        int val_26 = val_24 - (val_25 * val_1);
        // 0x00BA9254: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA9258: BL #0x264334c              | X0 = this.points.get_Item(index:  int val_26 = val_24 - (val_25 * val_1));
        UnityEngine.Vector3 val_27 = this.points.Item[val_26];
        // 0x00BA925C: MOV v3.16b, v0.16b         | V3 = val_27.x;//m1                      
        // 0x00BA9260: MOV v4.16b, v1.16b         | V4 = val_27.y;//m1                      
        // 0x00BA9264: MOV v5.16b, v2.16b         | V5 = val_27.z;//m1                      
        // 0x00BA9268: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA926C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9270: MOV v0.16b, v8.16b         | V0 = val_23.x;//m1                      
        // 0x00BA9274: MOV v1.16b, v9.16b         | V1 = val_23.y;//m1                      
        // 0x00BA9278: MOV v2.16b, v10.16b        | V2 = val_23.z;//m1                      
        // 0x00BA927C: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_23.x, y = val_23.y, z = val_23.z}, b:  new UnityEngine.Vector3() {x = val_27.x, y = val_27.y, z = val_27.z});
        UnityEngine.Vector3 val_28 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_23.x, y = val_23.y, z = val_23.z}, b:  new UnityEngine.Vector3() {x = val_27.x, y = val_27.y, z = val_27.z});
        // 0x00BA9280: ADD x0, sp, #0x80          | X0 = (1152921513303419920 + 128) = 1152921513303420048 (0x10000002065B2C90);
        // 0x00BA9284: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9288: STP s0, s1, [sp, #0x80]    | stack[1152921513303420048] = val_28.x;  stack[1152921513303420052] = val_28.y;  //  dest_result_addr=1152921513303420048 |  dest_result_addr=1152921513303420052
        // 0x00BA928C: STR s2, [sp, #0x88]        | stack[1152921513303420056] = val_28.z;   //  dest_result_addr=1152921513303420056
        // 0x00BA9290: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00BA9294: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA9298: LDR w22, [x19, #0xc4]      | W22 = this.pt; //P2                     
        // 0x00BA929C: MOV v8.16b, v0.16b         | V8 = val_28.x;//m1                      
        // 0x00BA92A0: MOV v9.16b, v1.16b         | V9 = val_28.y;//m1                      
        // 0x00BA92A4: MOV v10.16b, v2.16b        | V10 = val_28.z;//m1                     
        // 0x00BA92A8: CBNZ x21, #0xba92b0        | if (this.points != null) goto label_12; 
        if(this.points != null)
        {
            goto label_12;
        }
        // 0x00BA92AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002065B2C90, ????);
        label_12:
        // 0x00BA92B0: LDR x2, [x23]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA92B4: ADD w8, w22, w20           | W8 = (this.pt + val_1);                 
        int val_29 = this.pt + val_1;
        // 0x00BA92B8: SDIV w9, w8, w20           | W9 = ((this.pt + val_1) / val_1);       
        int val_30 = val_29 / val_1;
        // 0x00BA92BC: MSUB w1, w9, w20, w8       | W1 = (this.pt + val_1) - (((this.pt + val_1) / val_1) * val_1);
        int val_31 = val_29 - (val_30 * val_1);
        // 0x00BA92C0: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA92C4: BL #0x264334c              | X0 = this.points.get_Item(index:  int val_31 = val_29 - (val_30 * val_1));
        UnityEngine.Vector3 val_32 = this.points.Item[val_31];
        // 0x00BA92C8: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA92CC: LDR w22, [x19, #0xc4]      | W22 = this.pt; //P2                     
        // 0x00BA92D0: MOV v12.16b, v0.16b        | V12 = val_32.x;//m1                     
        // 0x00BA92D4: MOV v13.16b, v1.16b        | V13 = val_32.y;//m1                     
        // 0x00BA92D8: MOV v11.16b, v2.16b        | V11 = val_32.z;//m1                     
        // 0x00BA92DC: CBNZ x21, #0xba92e4        | if (this.points != null) goto label_13; 
        if(this.points != null)
        {
            goto label_13;
        }
        // 0x00BA92E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points, ????);
        label_13:
        // 0x00BA92E4: LDR x2, [x23]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA92E8: ADD w8, w22, #1            | W8 = (this.pt + 1);                     
        int val_33 = this.pt + 1;
        // 0x00BA92EC: SDIV w9, w8, w20           | W9 = ((this.pt + 1) / val_1);           
        int val_34 = val_33 / val_1;
        // 0x00BA92F0: MSUB w1, w9, w20, w8       | W1 = (this.pt + 1) - (((this.pt + 1) / val_1) * val_1);
        int val_35 = val_33 - (val_34 * val_1);
        // 0x00BA92F4: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA92F8: BL #0x264334c              | X0 = this.points.get_Item(index:  int val_35 = val_33 - (val_34 * val_1));
        UnityEngine.Vector3 val_36 = this.points.Item[val_35];
        // 0x00BA92FC: MOV v3.16b, v0.16b         | V3 = val_36.x;//m1                      
        // 0x00BA9300: MOV v4.16b, v1.16b         | V4 = val_36.y;//m1                      
        // 0x00BA9304: MOV v5.16b, v2.16b         | V5 = val_36.z;//m1                      
        // 0x00BA9308: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA930C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9310: MOV v0.16b, v12.16b        | V0 = val_32.x;//m1                      
        // 0x00BA9314: MOV v1.16b, v13.16b        | V1 = val_32.y;//m1                      
        // 0x00BA9318: MOV v2.16b, v11.16b        | V2 = val_32.z;//m1                      
        // 0x00BA931C: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_32.x, y = val_32.y, z = val_32.z}, b:  new UnityEngine.Vector3() {x = val_36.x, y = val_36.y, z = val_36.z});
        UnityEngine.Vector3 val_37 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_32.x, y = val_32.y, z = val_32.z}, b:  new UnityEngine.Vector3() {x = val_36.x, y = val_36.y, z = val_36.z});
        // 0x00BA9320: ADD x0, sp, #0x70          | X0 = (1152921513303419920 + 112) = 1152921513303420032 (0x10000002065B2C80);
        // 0x00BA9324: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9328: STP s0, s1, [sp, #0x70]    | stack[1152921513303420032] = val_37.x;  stack[1152921513303420036] = val_37.y;  //  dest_result_addr=1152921513303420032 |  dest_result_addr=1152921513303420036
        // 0x00BA932C: STR s2, [sp, #0x78]        | stack[1152921513303420040] = val_37.z;   //  dest_result_addr=1152921513303420040
        // 0x00BA9330: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00BA9334: MOV v3.16b, v0.16b         | V3 = val_37.x;//m1                      
        // 0x00BA9338: MOV v4.16b, v1.16b         | V4 = val_37.y;//m1                      
        // 0x00BA933C: MOV v5.16b, v2.16b         | V5 = val_37.z;//m1                      
        // 0x00BA9340: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA9344: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9348: MOV v0.16b, v8.16b         | V0 = val_28.x;//m1                      
        // 0x00BA934C: MOV v1.16b, v9.16b         | V1 = val_28.y;//m1                      
        // 0x00BA9350: MOV v2.16b, v10.16b        | V2 = val_28.z;//m1                      
        // 0x00BA9354: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_28.x, y = val_28.y, z = val_28.z}, b:  new UnityEngine.Vector3() {x = val_37.x, y = val_37.y, z = val_37.z});
        UnityEngine.Vector3 val_38 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_28.x, y = val_28.y, z = val_28.z}, b:  new UnityEngine.Vector3() {x = val_37.x, y = val_37.y, z = val_37.z});
        // 0x00BA9358: ADD x0, sp, #0x60          | X0 = (1152921513303419920 + 96) = 1152921513303420016 (0x10000002065B2C70);
        // 0x00BA935C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9360: STP s0, s1, [sp, #0x60]    | stack[1152921513303420016] = val_38.x;  stack[1152921513303420020] = val_38.y;  //  dest_result_addr=1152921513303420016 |  dest_result_addr=1152921513303420020
        // 0x00BA9364: STR s2, [sp, #0x68]        | stack[1152921513303420024] = val_38.z;   //  dest_result_addr=1152921513303420024
        // 0x00BA9368: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00BA936C: STP s1, s0, [sp, #0x40]    | stack[1152921513303419984] = val_38.y;  stack[1152921513303419988] = val_38.x;  //  dest_result_addr=1152921513303419984 |  dest_result_addr=1152921513303419988
        // 0x00BA9370: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA9374: LDR w22, [x19, #0xc4]      | W22 = this.pt; //P2                     
        // 0x00BA9378: STR s2, [sp, #0x3c]        | stack[1152921513303419980] = val_38.z;   //  dest_result_addr=1152921513303419980
        // 0x00BA937C: CBNZ x21, #0xba9384        | if (this.points != null) goto label_14; 
        if(this.points != null)
        {
            goto label_14;
        }
        // 0x00BA9380: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002065B2C70, ????);
        label_14:
        // 0x00BA9384: LDR x2, [x23]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA9388: SDIV w8, w22, w20          | W8 = (this.pt / val_1);                 
        int val_39 = this.pt / val_1;
        // 0x00BA938C: MSUB w1, w8, w20, w22      | W1 = this.pt - ((this.pt / val_1) * val_1);
        int val_40 = this.pt - (val_39 * val_1);
        // 0x00BA9390: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA9394: BL #0x264334c              | X0 = this.points.get_Item(index:  int val_40 = this.pt - (val_39 * val_1));
        UnityEngine.Vector3 val_41 = this.points.Item[val_40];
        // 0x00BA9398: STP s1, s0, [sp, #0x34]    | stack[1152921513303419972] = val_41.y;  stack[1152921513303419976] = val_41.x;  //  dest_result_addr=1152921513303419972 |  dest_result_addr=1152921513303419976
        // 0x00BA939C: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA93A0: LDR w22, [x19, #0xc4]      | W22 = this.pt; //P2                     
        // 0x00BA93A4: STR s2, [sp, #0x30]        | stack[1152921513303419968] = val_41.z;   //  dest_result_addr=1152921513303419968
        // 0x00BA93A8: CBNZ x21, #0xba93b0        | if (this.points != null) goto label_15; 
        if(this.points != null)
        {
            goto label_15;
        }
        // 0x00BA93AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points, ????);
        label_15:
        // 0x00BA93B0: LDR x2, [x23]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA93B4: SDIV w8, w22, w20          | W8 = (this.pt / val_1);                 
        int val_42 = this.pt / val_1;
        // 0x00BA93B8: MSUB w1, w8, w20, w22      | W1 = this.pt - ((this.pt / val_1) * val_1);
        int val_43 = this.pt - (val_42 * val_1);
        // 0x00BA93BC: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA93C0: BL #0x264334c              | X0 = this.points.get_Item(index:  int val_43 = this.pt - (val_42 * val_1));
        UnityEngine.Vector3 val_44 = this.points.Item[val_43];
        // 0x00BA93C4: LDR x21, [x19, #0x50]      | X21 = this.smooth; //P2                 
        // 0x00BA93C8: LDR s8, [x19, #0xc8]       | S8 = this.time; //P2                    
        // 0x00BA93CC: LDR x22, [x19, #0x18]      | X22 = this.points; //P2                 
        // 0x00BA93D0: MOV v15.16b, v0.16b        | V15 = val_44.x;//m1                     
        // 0x00BA93D4: MOV v10.16b, v1.16b        | V10 = val_44.y;//m1                     
        // 0x00BA93D8: MOV v13.16b, v2.16b        | V13 = val_44.z;//m1                     
        // 0x00BA93DC: CBNZ x22, #0xba93e4        | if (this.points != null) goto label_16; 
        if(this.points != null)
        {
            goto label_16;
        }
        // 0x00BA93E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points, ????);
        label_16:
        // 0x00BA93E4: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00BA93E8: MOV x0, x22                | X0 = this.points;//m1                   
        // 0x00BA93EC: BL #0x2643344              | X0 = this.points.get_Count();           
        int val_45 = this.points.Count;
        // 0x00BA93F0: MOV w22, w0                | W22 = val_45;//m1                       
        // 0x00BA93F4: CBNZ x21, #0xba93fc        | if (this.smooth != null) goto label_17; 
        if(this.smooth != null)
        {
            goto label_17;
        }
        // 0x00BA93F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_45, ????);     
        label_17:
        // 0x00BA93FC: FMOV s0, #1.00000000       | S0 = 1;                                 
        float val_97 = 1f;
        // 0x00BA9400: FADD s0, s8, s0            | S0 = (this.time + 1f);                  
        val_97 = this.time + val_97;
        // 0x00BA9404: SCVTF s1, w22              | S1 = (float)(val_45);                   
        // 0x00BA9408: BL #0x9803a0               | X0 = sub_9803A0( ?? val_45, ????);      
        // 0x00BA940C: ADRP x26, #0x35e2000       | X26 = 56500224 (0x35E2000);             
        // 0x00BA9410: LDR x26, [x26, #0xbb0]     | X26 = 1152921510888574288;              
        // 0x00BA9414: FCVTZS w1, s0              | W1 = (int)((this.time + 1f));           
        // 0x00BA9418: MOV x0, x21                | X0 = this.smooth;//m1                   
        // 0x00BA941C: LDR x2, [x26]              | X2 = public System.Single System.Collections.Generic.List<System.Single>::get_Item(int index);
        // 0x00BA9420: BL #0x25fad28              | X0 = this.smooth.get_Item(index:  (int)1f);
        float val_46 = this.smooth.Item[(int)val_97];
        // 0x00BA9424: ADRP x25, #0x35e6000       | X25 = 56516608 (0x35E6000);             
        // 0x00BA9428: LDR x25, [x25, #0xce8]     | X25 = 1152921504608444416;              
        // 0x00BA942C: ADD x1, sp, #0x5c          | X1 = (1152921513303419920 + 92) = 1152921513303420012 (0x10000002065B2C6C);
        // 0x00BA9430: STR s0, [sp, #0x5c]        | stack[1152921513303420012] = val_46;     //  dest_result_addr=1152921513303420012
        // 0x00BA9434: LDR x0, [x25]              | X0 = typeof(System.Single);             
        // 0x00BA9438: BL #0x27bc028              | X0 = 1152921513303517552 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_46);
        // 0x00BA943C: MOV x1, x0                 | X1 = 1152921513303517552 (0x10000002065CA970);//ML01
        // 0x00BA9440: ORR w2, wzr, #4            | W2 = 4(0x4);                            
        // 0x00BA9444: MOV x0, x19                | X0 = 1152921513303432304 (0x10000002065B5C70);//ML01
        // 0x00BA9448: BL #0xba8cf0               | X0 = this.CheckDefault(obj:  val_46, str:  4);
        object val_47 = this.CheckDefault(obj:  val_46, str:  4);
        // 0x00BA944C: LDR x22, [x25]             | X22 = typeof(System.Single);            
        val_97 = null;
        // 0x00BA9450: MOV x21, x0                | X21 = val_47;//m1                       
        // 0x00BA9454: CBNZ x21, #0xba945c        | if (val_47 != null) goto label_18;      
        if(val_47 != null)
        {
            goto label_18;
        }
        // 0x00BA9458: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_47, ????);     
        label_18:
        // 0x00BA945C: LDR x8, [x21]              | X8 = typeof(System.Object);             
        // 0x00BA9460: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00BA9464: LDR x8, [x22, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
        // 0x00BA9468: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Single.__il2cppRuntimeField_element_class)
        // 0x00BA946C: B.NE #0xba999c             | if (System.Object.__il2cppRuntimeField_element_class != System.Single.__il2cppRuntimeField_element_class) goto label_19;
        // 0x00BA9470: MOV x0, x21                | X0 = val_47;//m1                        
        // 0x00BA9474: BL #0x27bc4e8              | val_47.System.IDisposable.Dispose();    
        val_47.System.IDisposable.Dispose();
        // 0x00BA9478: LDR s3, [x0]               | S3 = typeof(System.Object);             
        // 0x00BA947C: LDP s2, s1, [sp, #0x48]    | S2 = val_19.z; S1 = val_19.y;            //  | 
        // 0x00BA9480: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA9484: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9488: MOV v0.16b, v14.16b        | V0 = val_19.x;//m1                      
        // 0x00BA948C: MOV v12.16b, v14.16b       | V12 = val_19.x;//m1                     
        // 0x00BA9490: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_19.x, y = val_19.y, z = val_19.z}, d:  7.461634E-41f);
        UnityEngine.Vector3 val_48 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_19.x, y = val_19.y, z = val_19.z}, d:  7.461634E-41f);
        // 0x00BA9494: MOV v3.16b, v0.16b         | V3 = val_48.x;//m1                      
        // 0x00BA9498: MOV v4.16b, v1.16b         | V4 = val_48.y;//m1                      
        // 0x00BA949C: MOV v5.16b, v2.16b         | V5 = val_48.z;//m1                      
        // 0x00BA94A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA94A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA94A8: MOV v0.16b, v15.16b        | V0 = val_44.x;//m1                      
        // 0x00BA94AC: MOV v1.16b, v10.16b        | V1 = val_44.y;//m1                      
        // 0x00BA94B0: MOV v2.16b, v13.16b        | V2 = val_44.z;//m1                      
        // 0x00BA94B4: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_44.x, y = val_44.y, z = val_44.z}, b:  new UnityEngine.Vector3() {x = val_48.x, y = val_48.y, z = val_48.z});
        UnityEngine.Vector3 val_49 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_44.x, y = val_44.y, z = val_44.z}, b:  new UnityEngine.Vector3() {x = val_48.x, y = val_48.y, z = val_48.z});
        // 0x00BA94B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA94BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA94C0: MOV v10.16b, v0.16b        | V10 = val_49.x;//m1                     
        // 0x00BA94C4: MOV v13.16b, v1.16b        | V13 = val_49.y;//m1                     
        // 0x00BA94C8: MOV v14.16b, v2.16b        | V14 = val_49.z;//m1                     
        // 0x00BA94CC: BL #0x20d3ba8              | X0 = UnityEngine.Color.get_red();       
        UnityEngine.Color val_50 = UnityEngine.Color.red;
        // 0x00BA94D0: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
        // 0x00BA94D4: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
        // 0x00BA94D8: MOV v15.16b, v0.16b        | V15 = val_50.r;//m1                     
        // 0x00BA94DC: MOV v11.16b, v1.16b        | V11 = val_50.g;//m1                     
        // 0x00BA94E0: MOV v8.16b, v2.16b         | V8 = val_50.b;//m1                      
        // 0x00BA94E4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Debug);         
        // 0x00BA94E8: MOV v9.16b, v3.16b         | V9 = val_50.a;//m1                      
        // 0x00BA94EC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
        // 0x00BA94F0: TBZ w8, #0, #0xba9500      | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_21;
        // 0x00BA94F4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
        // 0x00BA94F8: CBNZ w8, #0xba9500         | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
        // 0x00BA94FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
        label_21:
        // 0x00BA9500: STP s8, s9, [sp, #8]       | stack[1152921513303419928] = val_50.b;  stack[1152921513303419932] = val_50.a;  //  dest_result_addr=1152921513303419928 |  dest_result_addr=1152921513303419932
        // 0x00BA9504: STP s15, s11, [sp]         | stack[1152921513303419920] = val_50.r;  stack[1152921513303419924] = val_50.g;  //  dest_result_addr=1152921513303419920 |  dest_result_addr=1152921513303419924
        // 0x00BA9508: LDP s1, s0, [sp, #0x34]    | S1 = val_41.y; S0 = val_41.x;            //  | 
        // 0x00BA950C: LDR s2, [sp, #0x30]        | S2 = val_41.z;                          
        // 0x00BA9510: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA9514: MOV v3.16b, v10.16b        | V3 = val_49.x;//m1                      
        // 0x00BA9518: MOV v4.16b, v13.16b        | V4 = val_49.y;//m1                      
        // 0x00BA951C: MOV v5.16b, v14.16b        | V5 = val_49.z;//m1                      
        // 0x00BA9520: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9524: BL #0x1a5cb54              | UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_41.x, y = val_41.y, z = val_41.z}, end:  new UnityEngine.Vector3() {x = val_49.x, y = val_49.y, z = val_49.z}, color:  new UnityEngine.Color() {r = val_50.r, g = val_50.b});
        UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_41.x, y = val_41.y, z = val_41.z}, end:  new UnityEngine.Vector3() {x = val_49.x, y = val_49.y, z = val_49.z}, color:  new UnityEngine.Color() {r = val_50.r, g = val_50.b});
        // 0x00BA9528: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA952C: LDR w22, [x19, #0xc4]      | W22 = this.pt; //P2                     
        // 0x00BA9530: CBNZ x21, #0xba9538        | if (this.points != null) goto label_22; 
        if(this.points != null)
        {
            goto label_22;
        }
        // 0x00BA9534: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_22:
        // 0x00BA9538: LDR x2, [x23]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA953C: ADD w8, w22, #1            | W8 = (this.pt + 1);                     
        int val_51 = this.pt + 1;
        // 0x00BA9540: SDIV w9, w8, w20           | W9 = ((this.pt + 1) / val_1);           
        int val_52 = val_51 / val_1;
        // 0x00BA9544: MSUB w1, w9, w20, w8       | W1 = (this.pt + 1) - (((this.pt + 1) / val_1) * val_1);
        int val_53 = val_51 - (val_52 * val_1);
        // 0x00BA9548: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA954C: BL #0x264334c              | X0 = this.points.get_Item(index:  int val_53 = val_51 - (val_52 * val_1));
        UnityEngine.Vector3 val_54 = this.points.Item[val_53];
        // 0x00BA9550: LDR x21, [x19, #0x50]      | X21 = this.smooth; //P2                 
        // 0x00BA9554: LDR s11, [x19, #0xc8]      | S11 = this.time; //P2                   
        // 0x00BA9558: LDR x22, [x19, #0x18]      | X22 = this.points; //P2                 
        // 0x00BA955C: MOV v8.16b, v0.16b         | V8 = val_54.x;//m1                      
        // 0x00BA9560: MOV v9.16b, v1.16b         | V9 = val_54.y;//m1                      
        // 0x00BA9564: MOV v10.16b, v2.16b        | V10 = val_54.z;//m1                     
        // 0x00BA9568: MOV v14.16b, v12.16b       | V14 = val_19.x;//m1                     
        // 0x00BA956C: FMOV s15, #1.00000000      | S15 = 1;                                
        // 0x00BA9570: CBNZ x22, #0xba9578        | if (this.points != null) goto label_23; 
        if(this.points != null)
        {
            goto label_23;
        }
        // 0x00BA9574: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points, ????);
        label_23:
        // 0x00BA9578: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00BA957C: MOV x0, x22                | X0 = this.points;//m1                   
        // 0x00BA9580: BL #0x2643344              | X0 = this.points.get_Count();           
        int val_55 = this.points.Count;
        // 0x00BA9584: MOV w22, w0                | W22 = val_55;//m1                       
        // 0x00BA9588: CBNZ x21, #0xba9590        | if (this.smooth != null) goto label_24; 
        if(this.smooth != null)
        {
            goto label_24;
        }
        // 0x00BA958C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_55, ????);     
        label_24:
        // 0x00BA9590: FADD s0, s11, s15          | S0 = (this.time + 1f);                  
        float val_56 = this.time + 1f;
        // 0x00BA9594: SCVTF s1, w22              | S1 = (float)(val_55);                   
        // 0x00BA9598: BL #0x9803a0               | X0 = sub_9803A0( ?? val_55, ????);      
        // 0x00BA959C: LDR x2, [x26]              | X2 = public System.Single System.Collections.Generic.List<System.Single>::get_Item(int index);
        // 0x00BA95A0: FCVTZS w1, s0              | W1 = (int)((this.time + 1f));           
        // 0x00BA95A4: MOV x0, x21                | X0 = this.smooth;//m1                   
        // 0x00BA95A8: BL #0x25fad28              | X0 = this.smooth.get_Item(index:  (int)val_56);
        float val_57 = this.smooth.Item[(int)val_56];
        // 0x00BA95AC: LDR x0, [x25]              | X0 = typeof(System.Single);             
        // 0x00BA95B0: ADD x1, sp, #0x58          | X1 = (1152921513303419920 + 88) = 1152921513303420008 (0x10000002065B2C68);
        // 0x00BA95B4: STR s0, [sp, #0x58]        | stack[1152921513303420008] = val_57;     //  dest_result_addr=1152921513303420008
        // 0x00BA95B8: BL #0x27bc028              | X0 = 1152921513303538032 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_57);
        // 0x00BA95BC: MOV x1, x0                 | X1 = 1152921513303538032 (0x10000002065CF970);//ML01
        // 0x00BA95C0: ORR w2, wzr, #4            | W2 = 4(0x4);                            
        // 0x00BA95C4: MOV x0, x19                | X0 = 1152921513303432304 (0x10000002065B5C70);//ML01
        // 0x00BA95C8: BL #0xba8cf0               | X0 = this.CheckDefault(obj:  val_57, str:  4);
        object val_58 = this.CheckDefault(obj:  val_57, str:  4);
        // 0x00BA95CC: LDR x22, [x25]             | X22 = typeof(System.Single);            
        val_97 = null;
        // 0x00BA95D0: MOV x21, x0                | X21 = val_58;//m1                       
        // 0x00BA95D4: CBNZ x21, #0xba95dc        | if (val_58 != null) goto label_25;      
        if(val_58 != null)
        {
            goto label_25;
        }
        // 0x00BA95D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_58, ????);     
        label_25:
        // 0x00BA95DC: LDR x8, [x21]              | X8 = typeof(System.Object);             
        // 0x00BA95E0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00BA95E4: LDR x8, [x22, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
        // 0x00BA95E8: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Single.__il2cppRuntimeField_element_class)
        // 0x00BA95EC: B.NE #0xba99c0             | if (System.Object.__il2cppRuntimeField_element_class != System.Single.__il2cppRuntimeField_element_class) goto label_26;
        // 0x00BA95F0: MOV x0, x21                | X0 = val_58;//m1                        
        // 0x00BA95F4: BL #0x27bc4e8              | val_58.System.IDisposable.Dispose();    
        val_58.System.IDisposable.Dispose();
        // 0x00BA95F8: LDR s3, [x0]               | S3 = typeof(System.Object);             
        // 0x00BA95FC: LDP s1, s0, [sp, #0x40]    | S1 = val_38.y; S0 = val_38.x;            //  | 
        // 0x00BA9600: LDR s2, [sp, #0x3c]        | S2 = val_38.z;                          
        // 0x00BA9604: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA9608: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA960C: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_38.x, y = val_38.y, z = val_38.z}, d:  7.461634E-41f);
        UnityEngine.Vector3 val_59 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_38.x, y = val_38.y, z = val_38.z}, d:  7.461634E-41f);
        // 0x00BA9610: MOV v3.16b, v0.16b         | V3 = val_59.x;//m1                      
        // 0x00BA9614: MOV v4.16b, v1.16b         | V4 = val_59.y;//m1                      
        // 0x00BA9618: MOV v5.16b, v2.16b         | V5 = val_59.z;//m1                      
        // 0x00BA961C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA9620: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9624: MOV v0.16b, v8.16b         | V0 = val_54.x;//m1                      
        // 0x00BA9628: MOV v1.16b, v9.16b         | V1 = val_54.y;//m1                      
        // 0x00BA962C: MOV v2.16b, v10.16b        | V2 = val_54.z;//m1                      
        // 0x00BA9630: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_54.x, y = val_54.y, z = val_54.z}, b:  new UnityEngine.Vector3() {x = val_59.x, y = val_59.y, z = val_59.z});
        UnityEngine.Vector3 val_60 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_54.x, y = val_54.y, z = val_54.z}, b:  new UnityEngine.Vector3() {x = val_59.x, y = val_59.y, z = val_59.z});
        // 0x00BA9634: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA9638: LDR w22, [x19, #0xc4]      | W22 = this.pt; //P2                     
        // 0x00BA963C: MOV v8.16b, v0.16b         | V8 = val_60.x;//m1                      
        // 0x00BA9640: MOV v9.16b, v1.16b         | V9 = val_60.y;//m1                      
        // 0x00BA9644: MOV v10.16b, v2.16b        | V10 = val_60.z;//m1                     
        // 0x00BA9648: CBNZ x21, #0xba9650        | if (this.points != null) goto label_27; 
        if(this.points != null)
        {
            goto label_27;
        }
        // 0x00BA964C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_27:
        // 0x00BA9650: LDR x2, [x23]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA9654: ADD w8, w22, #1            | W8 = (this.pt + 1);                     
        int val_61 = this.pt + 1;
        // 0x00BA9658: SDIV w9, w8, w20           | W9 = ((this.pt + 1) / val_1);           
        int val_62 = val_61 / val_1;
        // 0x00BA965C: MSUB w1, w9, w20, w8       | W1 = (this.pt + 1) - (((this.pt + 1) / val_1) * val_1);
        int val_63 = val_61 - (val_62 * val_1);
        // 0x00BA9660: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA9664: BL #0x264334c              | X0 = this.points.get_Item(index:  int val_63 = val_61 - (val_62 * val_1));
        UnityEngine.Vector3 val_64 = this.points.Item[val_63];
        // 0x00BA9668: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA966C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9670: MOV v11.16b, v0.16b        | V11 = val_64.x;//m1                     
        // 0x00BA9674: MOV v12.16b, v1.16b        | V12 = val_64.y;//m1                     
        // 0x00BA9678: MOV v13.16b, v2.16b        | V13 = val_64.z;//m1                     
        // 0x00BA967C: BL #0x20d3bbc              | X0 = UnityEngine.Color.get_green();     
        UnityEngine.Color val_65 = UnityEngine.Color.green;
        // 0x00BA9680: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA9684: STP s2, s3, [sp, #8]       | stack[1152921513303419928] = val_65.b;  stack[1152921513303419932] = val_65.a;  //  dest_result_addr=1152921513303419928 |  dest_result_addr=1152921513303419932
        // 0x00BA9688: STP s0, s1, [sp]           | stack[1152921513303419920] = val_65.r;  stack[1152921513303419924] = val_65.g;  //  dest_result_addr=1152921513303419920 |  dest_result_addr=1152921513303419924
        // 0x00BA968C: MOV v0.16b, v8.16b         | V0 = val_60.x;//m1                      
        // 0x00BA9690: MOV v1.16b, v9.16b         | V1 = val_60.y;//m1                      
        // 0x00BA9694: MOV v2.16b, v10.16b        | V2 = val_60.z;//m1                      
        // 0x00BA9698: MOV v3.16b, v11.16b        | V3 = val_64.x;//m1                      
        // 0x00BA969C: MOV v4.16b, v12.16b        | V4 = val_64.y;//m1                      
        // 0x00BA96A0: MOV v5.16b, v13.16b        | V5 = val_64.z;//m1                      
        // 0x00BA96A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA96A8: BL #0x1a5cb54              | UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_60.x, y = val_60.y, z = val_60.z}, end:  new UnityEngine.Vector3() {x = val_64.x, y = val_64.y, z = val_64.z}, color:  new UnityEngine.Color() {r = val_65.r, g = val_65.b});
        UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_60.x, y = val_60.y, z = val_60.z}, end:  new UnityEngine.Vector3() {x = val_64.x, y = val_64.y, z = val_64.z}, color:  new UnityEngine.Color() {r = val_65.r, g = val_65.b});
        // 0x00BA96AC: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA96B0: LDR w22, [x19, #0xc4]      | W22 = this.pt; //P2                     
        // 0x00BA96B4: CBNZ x21, #0xba96bc        | if (this.points != null) goto label_28; 
        if(this.points != null)
        {
            goto label_28;
        }
        // 0x00BA96B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_28:
        // 0x00BA96BC: LDR x2, [x23]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA96C0: SDIV w8, w22, w20          | W8 = (this.pt / val_1);                 
        int val_66 = this.pt / val_1;
        // 0x00BA96C4: MSUB w1, w8, w20, w22      | W1 = this.pt - ((this.pt / val_1) * val_1);
        int val_67 = this.pt - (val_66 * val_1);
        // 0x00BA96C8: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA96CC: BL #0x264334c              | X0 = this.points.get_Item(index:  int val_67 = this.pt - (val_66 * val_1));
        UnityEngine.Vector3 val_68 = this.points.Item[val_67];
        // 0x00BA96D0: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA96D4: LDR w22, [x19, #0xc4]      | W22 = this.pt; //P2                     
        // 0x00BA96D8: MOV v9.16b, v0.16b         | V9 = val_68.x;//m1                      
        // 0x00BA96DC: MOV v13.16b, v1.16b        | V13 = val_68.y;//m1                     
        // 0x00BA96E0: STR s2, [sp, #0x38]        | stack[1152921513303419976] = val_68.z;   //  dest_result_addr=1152921513303419976
        // 0x00BA96E4: CBNZ x21, #0xba96ec        | if (this.points != null) goto label_29; 
        if(this.points != null)
        {
            goto label_29;
        }
        // 0x00BA96E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points, ????);
        label_29:
        // 0x00BA96EC: LDR x2, [x23]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA96F0: SDIV w8, w22, w20          | W8 = (this.pt / val_1);                 
        int val_69 = this.pt / val_1;
        // 0x00BA96F4: MSUB w1, w8, w20, w22      | W1 = this.pt - ((this.pt / val_1) * val_1);
        int val_70 = this.pt - (val_69 * val_1);
        // 0x00BA96F8: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA96FC: BL #0x264334c              | X0 = this.points.get_Item(index:  int val_70 = this.pt - (val_69 * val_1));
        UnityEngine.Vector3 val_71 = this.points.Item[val_70];
        // 0x00BA9700: LDR x21, [x19, #0x50]      | X21 = this.smooth; //P2                 
        // 0x00BA9704: LDR s11, [x19, #0xc8]      | S11 = this.time; //P2                   
        // 0x00BA9708: LDR x22, [x19, #0x18]      | X22 = this.points; //P2                 
        // 0x00BA970C: MOV v8.16b, v0.16b         | V8 = val_71.x;//m1                      
        // 0x00BA9710: MOV v10.16b, v1.16b        | V10 = val_71.y;//m1                     
        // 0x00BA9714: MOV v12.16b, v2.16b        | V12 = val_71.z;//m1                     
        // 0x00BA9718: CBNZ x22, #0xba9720        | if (this.points != null) goto label_30; 
        if(this.points != null)
        {
            goto label_30;
        }
        // 0x00BA971C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points, ????);
        label_30:
        // 0x00BA9720: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00BA9724: MOV x0, x22                | X0 = this.points;//m1                   
        // 0x00BA9728: BL #0x2643344              | X0 = this.points.get_Count();           
        int val_72 = this.points.Count;
        // 0x00BA972C: MOV w22, w0                | W22 = val_72;//m1                       
        // 0x00BA9730: CBNZ x21, #0xba9738        | if (this.smooth != null) goto label_31; 
        if(this.smooth != null)
        {
            goto label_31;
        }
        // 0x00BA9734: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_72, ????);     
        label_31:
        // 0x00BA9738: FADD s0, s11, s15          | S0 = (this.time + 1f);                  
        float val_73 = this.time + 1f;
        // 0x00BA973C: SCVTF s1, w22              | S1 = (float)(val_72);                   
        // 0x00BA9740: BL #0x9803a0               | X0 = sub_9803A0( ?? val_72, ????);      
        // 0x00BA9744: LDR x2, [x26]              | X2 = public System.Single System.Collections.Generic.List<System.Single>::get_Item(int index);
        // 0x00BA9748: FCVTZS w1, s0              | W1 = (int)((this.time + 1f));           
        // 0x00BA974C: MOV x0, x21                | X0 = this.smooth;//m1                   
        // 0x00BA9750: BL #0x25fad28              | X0 = this.smooth.get_Item(index:  (int)val_73);
        float val_74 = this.smooth.Item[(int)val_73];
        // 0x00BA9754: LDR x0, [x25]              | X0 = typeof(System.Single);             
        // 0x00BA9758: ADD x1, sp, #0x54          | X1 = (1152921513303419920 + 84) = 1152921513303420004 (0x10000002065B2C64);
        // 0x00BA975C: STR s0, [sp, #0x54]        | stack[1152921513303420004] = val_74;     //  dest_result_addr=1152921513303420004
        // 0x00BA9760: BL #0x27bc028              | X0 = 1152921513303566704 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_74);
        // 0x00BA9764: MOV x1, x0                 | X1 = 1152921513303566704 (0x10000002065D6970);//ML01
        // 0x00BA9768: ORR w2, wzr, #4            | W2 = 4(0x4);                            
        // 0x00BA976C: MOV x0, x19                | X0 = 1152921513303432304 (0x10000002065B5C70);//ML01
        // 0x00BA9770: BL #0xba8cf0               | X0 = this.CheckDefault(obj:  val_74, str:  4);
        object val_75 = this.CheckDefault(obj:  val_74, str:  4);
        // 0x00BA9774: LDR x22, [x25]             | X22 = typeof(System.Single);            
        val_97 = null;
        // 0x00BA9778: MOV x21, x0                | X21 = val_75;//m1                       
        // 0x00BA977C: CBNZ x21, #0xba9784        | if (val_75 != null) goto label_32;      
        if(val_75 != null)
        {
            goto label_32;
        }
        // 0x00BA9780: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_75, ????);     
        label_32:
        // 0x00BA9784: LDR x8, [x21]              | X8 = typeof(System.Object);             
        // 0x00BA9788: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00BA978C: LDR x8, [x22, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
        // 0x00BA9790: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Single.__il2cppRuntimeField_element_class)
        // 0x00BA9794: B.NE #0xba99e4             | if (System.Object.__il2cppRuntimeField_element_class != System.Single.__il2cppRuntimeField_element_class) goto label_33;
        // 0x00BA9798: MOV x0, x21                | X0 = val_75;//m1                        
        // 0x00BA979C: STP s13, s9, [sp, #0x30]   | stack[1152921513303419968] = val_68.y;  stack[1152921513303419972] = val_68.x;  //  dest_result_addr=1152921513303419968 |  dest_result_addr=1152921513303419972
        // 0x00BA97A0: MOV v9.16b, v15.16b        | V9 = 1;//m1                             
        // 0x00BA97A4: BL #0x27bc4e8              | val_75.System.IDisposable.Dispose();    
        val_75.System.IDisposable.Dispose();
        // 0x00BA97A8: LDR s3, [x0]               | S3 = typeof(System.Object);             
        // 0x00BA97AC: LDP s2, s1, [sp, #0x48]    | S2 = val_19.z; S1 = val_19.y;            //  | 
        // 0x00BA97B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA97B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA97B8: MOV v0.16b, v14.16b        | V0 = val_19.x;//m1                      
        // 0x00BA97BC: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_19.x, y = val_19.y, z = val_19.z}, d:  7.461634E-41f);
        UnityEngine.Vector3 val_76 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_19.x, y = val_19.y, z = val_19.z}, d:  7.461634E-41f);
        // 0x00BA97C0: MOV v3.16b, v0.16b         | V3 = val_76.x;//m1                      
        // 0x00BA97C4: MOV v4.16b, v1.16b         | V4 = val_76.y;//m1                      
        // 0x00BA97C8: MOV v5.16b, v2.16b         | V5 = val_76.z;//m1                      
        // 0x00BA97CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA97D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA97D4: MOV v0.16b, v8.16b         | V0 = val_71.x;//m1                      
        // 0x00BA97D8: MOV v1.16b, v10.16b        | V1 = val_71.y;//m1                      
        // 0x00BA97DC: MOV v2.16b, v12.16b        | V2 = val_71.z;//m1                      
        // 0x00BA97E0: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_71.x, y = val_71.y, z = val_71.z}, b:  new UnityEngine.Vector3() {x = val_76.x, y = val_76.y, z = val_76.z});
        UnityEngine.Vector3 val_77 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_71.x, y = val_71.y, z = val_71.z}, b:  new UnityEngine.Vector3() {x = val_76.x, y = val_76.y, z = val_76.z});
        // 0x00BA97E4: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA97E8: LDR w22, [x19, #0xc4]      | W22 = this.pt; //P2                     
        // 0x00BA97EC: MOV v10.16b, v0.16b        | V10 = val_77.x;//m1                     
        // 0x00BA97F0: MOV v11.16b, v1.16b        | V11 = val_77.y;//m1                     
        // 0x00BA97F4: MOV v12.16b, v2.16b        | V12 = val_77.z;//m1                     
        // 0x00BA97F8: CBNZ x21, #0xba9800        | if (this.points != null) goto label_34; 
        if(this.points != null)
        {
            goto label_34;
        }
        // 0x00BA97FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_34:
        // 0x00BA9800: LDR x2, [x23]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA9804: ADD w8, w22, #1            | W8 = (this.pt + 1);                     
        int val_78 = this.pt + 1;
        // 0x00BA9808: SDIV w9, w8, w20           | W9 = ((this.pt + 1) / val_1);           
        int val_79 = val_78 / val_1;
        // 0x00BA980C: MSUB w1, w9, w20, w8       | W1 = (this.pt + 1) - (((this.pt + 1) / val_1) * val_1);
        int val_80 = val_78 - (val_79 * val_1);
        // 0x00BA9810: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA9814: BL #0x264334c              | X0 = this.points.get_Item(index:  int val_80 = val_78 - (val_79 * val_1));
        UnityEngine.Vector3 val_81 = this.points.Item[val_80];
        // 0x00BA9818: LDR x21, [x19, #0x50]      | X21 = this.smooth; //P2                 
        // 0x00BA981C: LDR s15, [x19, #0xc8]      | S15 = this.time; //P2                   
        // 0x00BA9820: LDR x22, [x19, #0x18]      | X22 = this.points; //P2                 
        // 0x00BA9824: MOV v13.16b, v0.16b        | V13 = val_81.x;//m1                     
        // 0x00BA9828: MOV v14.16b, v1.16b        | V14 = val_81.y;//m1                     
        // 0x00BA982C: MOV v8.16b, v2.16b         | V8 = val_81.z;//m1                      
        // 0x00BA9830: CBNZ x22, #0xba9838        | if (this.points != null) goto label_35; 
        if(this.points != null)
        {
            goto label_35;
        }
        // 0x00BA9834: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points, ????);
        label_35:
        // 0x00BA9838: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00BA983C: MOV x0, x22                | X0 = this.points;//m1                   
        // 0x00BA9840: BL #0x2643344              | X0 = this.points.get_Count();           
        int val_82 = this.points.Count;
        // 0x00BA9844: MOV w22, w0                | W22 = val_82;//m1                       
        // 0x00BA9848: CBNZ x21, #0xba9850        | if (this.smooth != null) goto label_36; 
        if(this.smooth != null)
        {
            goto label_36;
        }
        // 0x00BA984C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_82, ????);     
        label_36:
        // 0x00BA9850: FADD s0, s15, s9           | S0 = (this.time + 1f);                  
        float val_83 = this.time + 1f;
        // 0x00BA9854: SCVTF s1, w22              | S1 = (float)(val_82);                   
        // 0x00BA9858: BL #0x9803a0               | X0 = sub_9803A0( ?? val_82, ????);      
        // 0x00BA985C: LDR x2, [x26]              | X2 = public System.Single System.Collections.Generic.List<System.Single>::get_Item(int index);
        // 0x00BA9860: FCVTZS w1, s0              | W1 = (int)((this.time + 1f));           
        // 0x00BA9864: MOV x0, x21                | X0 = this.smooth;//m1                   
        // 0x00BA9868: BL #0x25fad28              | X0 = this.smooth.get_Item(index:  (int)val_83);
        float val_84 = this.smooth.Item[(int)val_83];
        // 0x00BA986C: LDR x0, [x25]              | X0 = typeof(System.Single);             
        // 0x00BA9870: ADD x1, sp, #0x50          | X1 = (1152921513303419920 + 80) = 1152921513303420000 (0x10000002065B2C60);
        // 0x00BA9874: STR s0, [sp, #0x50]        | stack[1152921513303420000] = val_84;     //  dest_result_addr=1152921513303420000
        // 0x00BA9878: BL #0x27bc028              | X0 = 1152921513303587184 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_84);
        // 0x00BA987C: MOV x1, x0                 | X1 = 1152921513303587184 (0x10000002065DB970);//ML01
        // 0x00BA9880: ORR w2, wzr, #4            | W2 = 4(0x4);                            
        // 0x00BA9884: MOV x0, x19                | X0 = 1152921513303432304 (0x10000002065B5C70);//ML01
        // 0x00BA9888: BL #0xba8cf0               | X0 = this.CheckDefault(obj:  val_84, str:  4);
        object val_85 = this.CheckDefault(obj:  val_84, str:  4);
        // 0x00BA988C: LDR x22, [x25]             | X22 = typeof(System.Single);            
        val_97 = null;
        // 0x00BA9890: MOV x21, x0                | X21 = val_85;//m1                       
        // 0x00BA9894: CBNZ x21, #0xba989c        | if (val_85 != null) goto label_37;      
        if(val_85 != null)
        {
            goto label_37;
        }
        // 0x00BA9898: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_85, ????);     
        label_37:
        // 0x00BA989C: LDR x8, [x21]              | X8 = typeof(System.Object);             
        // 0x00BA98A0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00BA98A4: LDR x8, [x22, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
        // 0x00BA98A8: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Single.__il2cppRuntimeField_element_class)
        // 0x00BA98AC: B.NE #0xba9a08             | if (System.Object.__il2cppRuntimeField_element_class != System.Single.__il2cppRuntimeField_element_class) goto label_38;
        // 0x00BA98B0: MOV x0, x21                | X0 = val_85;//m1                        
        // 0x00BA98B4: BL #0x27bc4e8              | val_85.System.IDisposable.Dispose();    
        val_85.System.IDisposable.Dispose();
        // 0x00BA98B8: LDR s3, [x0]               | S3 = typeof(System.Object);             
        // 0x00BA98BC: LDP s1, s0, [sp, #0x40]    | S1 = val_38.y; S0 = val_38.x;            //  | 
        // 0x00BA98C0: LDR s2, [sp, #0x3c]        | S2 = val_38.z;                          
        // 0x00BA98C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA98C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA98CC: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_38.x, y = val_38.y, z = val_38.z}, d:  7.461634E-41f);
        UnityEngine.Vector3 val_86 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_38.x, y = val_38.y, z = val_38.z}, d:  7.461634E-41f);
        // 0x00BA98D0: MOV v3.16b, v0.16b         | V3 = val_86.x;//m1                      
        // 0x00BA98D4: MOV v4.16b, v1.16b         | V4 = val_86.y;//m1                      
        // 0x00BA98D8: MOV v5.16b, v2.16b         | V5 = val_86.z;//m1                      
        // 0x00BA98DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA98E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA98E4: MOV v0.16b, v13.16b        | V0 = val_81.x;//m1                      
        // 0x00BA98E8: MOV v1.16b, v14.16b        | V1 = val_81.y;//m1                      
        // 0x00BA98EC: MOV v2.16b, v8.16b         | V2 = val_81.z;//m1                      
        // 0x00BA98F0: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_81.x, y = val_81.y, z = val_81.z}, b:  new UnityEngine.Vector3() {x = val_86.x, y = val_86.y, z = val_86.z});
        UnityEngine.Vector3 val_87 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_81.x, y = val_81.y, z = val_81.z}, b:  new UnityEngine.Vector3() {x = val_86.x, y = val_86.y, z = val_86.z});
        // 0x00BA98F4: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00BA98F8: LDR w22, [x19, #0xc4]      | W22 = this.pt; //P2                     
        // 0x00BA98FC: MOV v8.16b, v0.16b         | V8 = val_87.x;//m1                      
        // 0x00BA9900: MOV v13.16b, v1.16b        | V13 = val_87.y;//m1                     
        // 0x00BA9904: MOV v14.16b, v2.16b        | V14 = val_87.z;//m1                     
        // 0x00BA9908: CBNZ x21, #0xba9910        | if (this.points != null) goto label_39; 
        if(this.points != null)
        {
            goto label_39;
        }
        // 0x00BA990C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_39:
        // 0x00BA9910: LDR x2, [x23]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00BA9914: ADD w8, w22, #1            | W8 = (this.pt + 1);                     
        int val_88 = this.pt + 1;
        // 0x00BA9918: SDIV w9, w8, w20           | W9 = ((this.pt + 1) / val_1);           
        int val_89 = val_88 / val_1;
        // 0x00BA991C: MSUB w1, w9, w20, w8       | W1 = (this.pt + 1) - (((this.pt + 1) / val_1) * val_1);
        int val_90 = val_88 - (val_89 * val_1);
        // 0x00BA9920: MOV x0, x21                | X0 = this.points;//m1                   
        // 0x00BA9924: BL #0x264334c              | X0 = this.points.get_Item(index:  int val_90 = val_88 - (val_89 * val_1));
        UnityEngine.Vector3 val_91 = this.points.Item[val_90];
        // 0x00BA9928: LDR s3, [x19, #0xc4]       | S3 = this.pt; //P2                      
        // 0x00BA992C: LDR s4, [sp, #0x2c]        | S4 = t;                                 
        // 0x00BA9930: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA9934: MOV v5.16b, v12.16b        | V5 = val_77.z;//m1                      
        // 0x00BA9938: SCVTF s3, s3               | S3 = (float)(this.pt);                  
        float val_98 = (float)this.pt;
        // 0x00BA993C: FSUB s3, s4, s3            | S3 = (t - this.pt);                     
        val_98 = t - val_98;
        // 0x00BA9940: STR s3, [sp, #0x20]        | stack[1152921513303419952] = (t - this.pt);  //  dest_result_addr=1152921513303419952
        // 0x00BA9944: STP s1, s2, [sp, #0x14]    | stack[1152921513303419940] = val_91.y;  stack[1152921513303419944] = val_91.z;  //  dest_result_addr=1152921513303419940 |  dest_result_addr=1152921513303419944
        // 0x00BA9948: STR s0, [sp, #0x10]        | stack[1152921513303419936] = val_91.x;   //  dest_result_addr=1152921513303419936
        // 0x00BA994C: STP s13, s14, [sp, #4]     | stack[1152921513303419924] = val_87.y;  stack[1152921513303419928] = val_87.z;  //  dest_result_addr=1152921513303419924 |  dest_result_addr=1152921513303419928
        // 0x00BA9950: STR s8, [sp]               | stack[1152921513303419920] = val_87.x;   //  dest_result_addr=1152921513303419920
        // 0x00BA9954: LDP s1, s0, [sp, #0x30]    | S1 = val_68.y; S0 = val_68.x;            //  | 
        // 0x00BA9958: LDR s2, [sp, #0x38]        | S2 = val_68.z;                          
        // 0x00BA995C: MOV v3.16b, v10.16b        | V3 = val_77.x;//m1                      
        // 0x00BA9960: MOV v4.16b, v11.16b        | V4 = val_77.y;//m1                      
        // 0x00BA9964: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9968: BL #0x16842f4              | X0 = Pathfinding.AstarMath.CubicBezier(p0:  new UnityEngine.Vector3() {x = val_68.x, y = val_68.y, z = val_68.z}, p1:  new UnityEngine.Vector3() {x = val_77.x, y = val_77.y, z = val_77.z}, p2:  new UnityEngine.Vector3() {x = val_87.x, y = val_87.z, z = val_91.x}, p3:  new UnityEngine.Vector3() {x = val_91.z, y = (float)this.pt}, t:  val_68.y);
        UnityEngine.Vector3 val_92 = Pathfinding.AstarMath.CubicBezier(p0:  new UnityEngine.Vector3() {x = val_68.x, y = val_68.y, z = val_68.z}, p1:  new UnityEngine.Vector3() {x = val_77.x, y = val_77.y, z = val_77.z}, p2:  new UnityEngine.Vector3() {x = val_87.x, y = val_87.z, z = val_91.x}, p3:  new UnityEngine.Vector3() {x = val_91.z, y = val_98}, t:  val_68.y);
        // 0x00BA996C: SUB sp, x29, #0x90         | SP = (1152921513303420288 - 144) = 1152921513303420144 (0x10000002065B2CF0);
        // 0x00BA9970: LDP x29, x30, [sp, #0x90]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA9974: LDP x20, x19, [sp, #0x80]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA9978: LDP x22, x21, [sp, #0x70]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA997C: LDP x24, x23, [sp, #0x60]  | X24 = ; X23 = ;                          //  | 
        // 0x00BA9980: LDP x26, x25, [sp, #0x50]  | X26 = ; X25 = ;                          //  | 
        // 0x00BA9984: LDP x28, x27, [sp, #0x40]  | X28 = ; X27 = ;                          //  | 
        // 0x00BA9988: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00BA998C: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00BA9990: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00BA9994: LDP d15, d14, [sp], #0xa0  | D15 = ; D14 = ;                          //  | 
        // 0x00BA9998: RET                        |  return new UnityEngine.Vector3() {x = val_92.x, y = val_92.y, z = val_92.z};
        return new UnityEngine.Vector3() {x = val_92.x, y = val_92.y, z = val_92.z};
        //  |  // // {name=val_0.x, type=System.Single, size=4, nSRN=0 }
        //  |  // // {name=val_0.y, type=System.Single, size=4, nSRN=1 }
        //  |  // // {name=val_0.z, type=System.Single, size=4, nSRN=2 }
        label_19:
        // 0x00BA999C: SUB x8, x29, #0x98         | X8 = (1152921513303420288 - 152) = 1152921513303420136 (0x10000002065B2CE8);
        // 0x00BA99A0: MOV x1, x22                | X1 = 1152921504608444416 (0x1000000000186000);//ML01
        // 0x00BA99A4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
        // 0x00BA99A8: LDUR x0, [x29, #-0x98]     | X0 = val_93;                             //  find_add[1152921513303408304]
        // 0x00BA99AC: BL #0x27af090              | X0 = sub_27AF090( ?? val_93, ????);     
        // 0x00BA99B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA99B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_93, ????);     
        // 0x00BA99B8: SUB x0, x29, #0x98         | X0 = (1152921513303420288 - 152) = 1152921513303420136 (0x10000002065B2CE8);
        // 0x00BA99BC: BL #0x299a140              | 
        label_26:
        // 0x00BA99C0: SUB x8, x29, #0xa0         | X8 = (1152921513303420288 - 160) = 1152921513303420128 (0x10000002065B2CE0);
        // 0x00BA99C4: MOV x1, x22                | X1 = 1152921504608444416 (0x1000000000186000);//ML01
        // 0x00BA99C8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000002065B2CE8, ????);
        // 0x00BA99CC: LDUR x0, [x29, #-0xa0]     | X0 = val_94;                             //  find_add[1152921513303408304]
        // 0x00BA99D0: BL #0x27af090              | X0 = sub_27AF090( ?? val_94, ????);     
        // 0x00BA99D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA99D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_94, ????);     
        // 0x00BA99DC: SUB x0, x29, #0xa0         | X0 = (1152921513303420288 - 160) = 1152921513303420128 (0x10000002065B2CE0);
        // 0x00BA99E0: BL #0x299a140              | 
        label_33:
        // 0x00BA99E4: SUB x8, x29, #0xa8         | X8 = (1152921513303420288 - 168) = 1152921513303420120 (0x10000002065B2CD8);
        // 0x00BA99E8: MOV x1, x22                | X1 = 1152921504608444416 (0x1000000000186000);//ML01
        // 0x00BA99EC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000002065B2CE0, ????);
        // 0x00BA99F0: LDUR x0, [x29, #-0xa8]     | X0 = val_95;                             //  find_add[1152921513303408304]
        // 0x00BA99F4: BL #0x27af090              | X0 = sub_27AF090( ?? val_95, ????);     
        // 0x00BA99F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA99FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_95, ????);     
        // 0x00BA9A00: SUB x0, x29, #0xa8         | X0 = (1152921513303420288 - 168) = 1152921513303420120 (0x10000002065B2CD8);
        // 0x00BA9A04: BL #0x299a140              | 
        label_38:
        // 0x00BA9A08: SUB x8, x29, #0xb0         | X8 = (1152921513303420288 - 176) = 1152921513303420112 (0x10000002065B2CD0);
        // 0x00BA9A0C: MOV x1, x22                | X1 = 1152921504608444416 (0x1000000000186000);//ML01
        // 0x00BA9A10: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000002065B2CD8, ????);
        // 0x00BA9A14: LDUR x0, [x29, #-0xb0]     | X0 = val_96;                             //  find_add[1152921513303408304]
        // 0x00BA9A18: BL #0x27af090              | X0 = sub_27AF090( ?? val_96, ????);     
        // 0x00BA9A1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA9A20: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_96, ????);     
        // 0x00BA9A24: SUB x0, x29, #0xb0         | X0 = (1152921513303420288 - 176) = 1152921513303420112 (0x10000002065B2CD0);
        // 0x00BA9A28: BL #0x299a140              | 
        // 0x00BA9A2C: MOV x19, x0                | X19 = 1152921513303420112 (0x10000002065B2CD0);//ML01
        val_98;
        // 0x00BA9A30: SUB x0, x29, #0x98         | X0 = (1152921513303420288 - 152) = 1152921513303420136 (0x10000002065B2CE8);
        // 0x00BA9A34: B #0xba9a58                |  goto label_42;                         
        goto label_42;
        // 0x00BA9A38: MOV x19, x0                | X19 = 1152921513303420136 (0x10000002065B2CE8);//ML01
        val_98;
        // 0x00BA9A3C: SUB x0, x29, #0xa0         | X0 = (1152921513303420288 - 160) = 1152921513303420128 (0x10000002065B2CE0);
        // 0x00BA9A40: B #0xba9a58                |  goto label_42;                         
        goto label_42;
        // 0x00BA9A44: MOV x19, x0                | X19 = 1152921513303420128 (0x10000002065B2CE0);//ML01
        val_98;
        // 0x00BA9A48: SUB x0, x29, #0xa8         | X0 = (1152921513303420288 - 168) = 1152921513303420120 (0x10000002065B2CD8);
        // 0x00BA9A4C: B #0xba9a58                |  goto label_42;                         
        goto label_42;
        // 0x00BA9A50: MOV x19, x0                | X19 = 1152921513303420120 (0x10000002065B2CD8);//ML01
        val_98;
        // 0x00BA9A54: SUB x0, x29, #0xb0         | X0 = (1152921513303420288 - 176) = 1152921513303420112 (0x10000002065B2CD0);
        label_42:
        // 0x00BA9A58: BL #0x299a140              | 
        // 0x00BA9A5C: MOV x0, x19                | X0 = 1152921513303420120 (0x10000002065B2CD8);//ML01
        // 0x00BA9A60: BL #0x980800               | X0 = sub_980800( ?? 0x10000002065B2CD8, ????);
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA8CF0 (12225776), len: 636  VirtAddr: 0x00BA8CF0 RVA: 0x00BA8CF0 token: 100682711 methodIndex: 25673 delegateWrapperIndex: 0 methodInvoker: 0
    private object CheckDefault(object obj, SetType str)
    {
        //
        // Disasemble & Code
        //  | 
        var val_11;
        //  | 
        float val_12;
        // 0x00BA8CF0: STP x22, x21, [sp, #-0x30]! | stack[1152921513303679712] = ???;  stack[1152921513303679720] = ???;  //  dest_result_addr=1152921513303679712 |  dest_result_addr=1152921513303679720
        // 0x00BA8CF4: STP x20, x19, [sp, #0x10]  | stack[1152921513303679728] = ???;  stack[1152921513303679736] = ???;  //  dest_result_addr=1152921513303679728 |  dest_result_addr=1152921513303679736
        // 0x00BA8CF8: STP x29, x30, [sp, #0x20]  | stack[1152921513303679744] = ???;  stack[1152921513303679752] = ???;  //  dest_result_addr=1152921513303679744 |  dest_result_addr=1152921513303679752
        // 0x00BA8CFC: ADD x29, sp, #0x20         | X29 = (1152921513303679712 + 32) = 1152921513303679744 (0x10000002065F2300);
        // 0x00BA8D00: SUB sp, sp, #0x10          | SP = (1152921513303679712 - 16) = 1152921513303679696 (0x10000002065F22D0);
        // 0x00BA8D04: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00BA8D08: LDRB w8, [x22, #0xaf1]     | W8 = (bool)static_value_03733AF1;       
        // 0x00BA8D0C: MOV w21, w2                | W21 = str;//m1                          
        // 0x00BA8D10: MOV x19, x1                | X19 = obj;//m1                          
        val_11 = obj;
        // 0x00BA8D14: MOV x20, x0                | X20 = 1152921513303691760 (0x10000002065F51F0);//ML01
        // 0x00BA8D18: TBNZ w8, #0, #0xba8d34     | if (static_value_03733AF1 == true) goto label_0;
        // 0x00BA8D1C: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
        // 0x00BA8D20: LDR x8, [x8, #0xf48]       | X8 = 0x2B90164;                         
        // 0x00BA8D24: LDR w0, [x8]               | W0 = 0x171D;                            
        // 0x00BA8D28: BL #0x2782188              | X0 = sub_2782188( ?? 0x171D, ????);     
        // 0x00BA8D2C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA8D30: STRB w8, [x22, #0xaf1]     | static_value_03733AF1 = true;            //  dest_result_addr=57883377
        label_0:
        // 0x00BA8D34: ADD w8, w21, #3            | W8 = (str + 3);                         
        SetType val_1 = str + 3;
        // 0x00BA8D38: CMP w21, #9                | STATE = COMPARE(str, 0x9)               
        // 0x00BA8D3C: CSEL w8, w8, wzr, lo       | W8 = str < 0x9 ? (str + 3) : 0;         
        var val_2 = (str < 9) ? (val_1) : 0;
        // 0x00BA8D40: SUB w8, w8, #5             | W8 = (str < 0x9 ? (str + 3) : 0 - 5);   
        val_2 = val_2 - 5;
        // 0x00BA8D44: CMP w8, #6                 | STATE = COMPARE((str < 0x9 ? (str + 3) : 0 - 5), 0x6)
        // 0x00BA8D48: B.HI #0xba8edc             | if (val_2 > 0x6) goto label_21;         
        if(val_2 > 6)
        {
            goto label_21;
        }
        // 0x00BA8D4C: ADRP x9, #0x2a93000        | X9 = 44642304 (0x2A93000);              
        // 0x00BA8D50: ADD x9, x9, #0x30          | X9 = (44642304 + 48) = 44642352 (0x02A93030);
        // 0x00BA8D54: LDRSW x8, [x9, x8, lsl #2] | X8 = 44642352 + ((str < 0x9 ? (str + 3) : 0 - 5)) << 2;
        var val_11 = 44642352 + ((str < 0x9 ? (str + 3) : 0 - 5)) << 2;
        // 0x00BA8D58: ADD x8, x8, x9             | X8 = (44642352 + ((str < 0x9 ? (str + 3) : 0 - 5)) << 2 + 44642352);
        val_11 = val_11 + 44642352;
        // 0x00BA8D5C: BR x8                      | goto (44642352 + ((str < 0x9 ? (str + 3) : 0 - 5)) << 2 + 44642352);
        goto (44642352 + ((str < 0x9 ? (str + 3) : 0 - 5)) << 2 + 44642352);
        // 0x00BA8D60: CBNZ x19, #0xba8d68        | if (obj != null) goto label_2;          
        if(val_11 != null)
        {
            goto label_2;
        }
        // 0x00BA8D64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x171D, ????);     
        label_2:
        // 0x00BA8D68: LDR x8, [x19]              | X8 = typeof(System.Object);             
        // 0x00BA8D6C: MOV x0, x19                | X0 = obj;//m1                           
        // 0x00BA8D70: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Object).__il2cppRuntimeField_140; X1 = typeof(System.Object).__il2cppRuntimeField_148; //  | 
        // 0x00BA8D74: BLR x9                     | X0 = typeof(System.Object).__il2cppRuntimeField_140();
        // 0x00BA8D78: MOV x1, x0                 | X1 = obj;//m1                           
        // 0x00BA8D7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA8D80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA8D84: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_3 = System.Single.Parse(s:  0);
        // 0x00BA8D88: FMOV s1, #-1.00000000      | S1 = -1;                                
        // 0x00BA8D8C: FCMP s0, s1                | STATE = COMPARE(val_3, -1)              
        // 0x00BA8D90: B.NE #0xba8edc             | if (val_3 != -1f) goto label_21;        
        if(val_3 != (-1f))
        {
            goto label_21;
        }
        // 0x00BA8D94: LDR w8, [x20, #0xa8]       | W8 = this.defaultSpeed; //P2            
        val_12 = this.defaultSpeed;
        // 0x00BA8D98: B #0xba8ec0                |  goto label_16;                         
        goto label_16;
        // 0x00BA8D9C: CBNZ x19, #0xba8da4        | if (obj != null) goto label_5;          
        if(val_11 != null)
        {
            goto label_5;
        }
        // 0x00BA8DA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_5:
        // 0x00BA8DA4: LDR x8, [x19]              | X8 = typeof(System.Object);             
        // 0x00BA8DA8: MOV x0, x19                | X0 = obj;//m1                           
        // 0x00BA8DAC: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Object).__il2cppRuntimeField_140; X1 = typeof(System.Object).__il2cppRuntimeField_148; //  | 
        // 0x00BA8DB0: BLR x9                     | X0 = typeof(System.Object).__il2cppRuntimeField_140();
        // 0x00BA8DB4: MOV x1, x0                 | X1 = obj;//m1                           
        // 0x00BA8DB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA8DBC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA8DC0: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_4 = System.Single.Parse(s:  0);
        // 0x00BA8DC4: FMOV s1, #-1.00000000      | S1 = -1;                                
        // 0x00BA8DC8: FCMP s0, s1                | STATE = COMPARE(val_4, -1)              
        // 0x00BA8DCC: B.NE #0xba8edc             | if (val_4 != -1f) goto label_21;        
        if(val_4 != (-1f))
        {
            goto label_21;
        }
        // 0x00BA8DD0: LDR w8, [x20, #0xb4]       | W8 = this.defaultSmooth; //P2           
        val_12 = this.defaultSmooth;
        // 0x00BA8DD4: B #0xba8ec0                |  goto label_16;                         
        goto label_16;
        // 0x00BA8DD8: CBNZ x19, #0xba8de0        | if (obj != null) goto label_8;          
        if(val_11 != null)
        {
            goto label_8;
        }
        // 0x00BA8DDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_8:
        // 0x00BA8DE0: LDR x8, [x19]              | X8 = typeof(System.Object);             
        // 0x00BA8DE4: MOV x0, x19                | X0 = obj;//m1                           
        // 0x00BA8DE8: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Object).__il2cppRuntimeField_140; X1 = typeof(System.Object).__il2cppRuntimeField_148; //  | 
        // 0x00BA8DEC: BLR x9                     | X0 = typeof(System.Object).__il2cppRuntimeField_140();
        // 0x00BA8DF0: MOV x1, x0                 | X1 = obj;//m1                           
        // 0x00BA8DF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA8DF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA8DFC: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_5 = System.Single.Parse(s:  0);
        // 0x00BA8E00: FMOV s1, #-1.00000000      | S1 = -1;                                
        // 0x00BA8E04: FCMP s0, s1                | STATE = COMPARE(val_5, -1)              
        // 0x00BA8E08: B.NE #0xba8edc             | if (val_5 != -1f) goto label_21;        
        if(val_5 != (-1f))
        {
            goto label_21;
        }
        // 0x00BA8E0C: LDR w8, [x20, #0xb8]       | W8 = this.defaultView; //P2             
        val_12 = this.defaultView;
        // 0x00BA8E10: B #0xba8ec0                |  goto label_16;                         
        goto label_16;
        // 0x00BA8E14: CBNZ x19, #0xba8e1c        | if (obj != null) goto label_11;         
        if(val_11 != null)
        {
            goto label_11;
        }
        // 0x00BA8E18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_11:
        // 0x00BA8E1C: LDR x8, [x19]              | X8 = typeof(System.Object);             
        // 0x00BA8E20: MOV x0, x19                | X0 = obj;//m1                           
        // 0x00BA8E24: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Object).__il2cppRuntimeField_140; X1 = typeof(System.Object).__il2cppRuntimeField_148; //  | 
        // 0x00BA8E28: BLR x9                     | X0 = typeof(System.Object).__il2cppRuntimeField_140();
        // 0x00BA8E2C: MOV x1, x0                 | X1 = obj;//m1                           
        // 0x00BA8E30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA8E34: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA8E38: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_6 = System.Single.Parse(s:  0);
        // 0x00BA8E3C: FMOV s1, #-1.00000000      | S1 = -1;                                
        // 0x00BA8E40: FCMP s0, s1                | STATE = COMPARE(val_6, -1)              
        // 0x00BA8E44: B.NE #0xba8ef4             | if (val_6 != -1f) goto label_12;        
        if(val_6 != (-1f))
        {
            goto label_12;
        }
        // 0x00BA8E48: LDR w8, [x20, #0xbc]       | W8 = this.defaultBright; //P2           
        val_12 = this.defaultBright;
        // 0x00BA8E4C: B #0xba8ec0                |  goto label_16;                         
        goto label_16;
        // 0x00BA8E50: CBNZ x19, #0xba8e58        | if (obj != null) goto label_14;         
        if(val_11 != null)
        {
            goto label_14;
        }
        // 0x00BA8E54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_14:
        // 0x00BA8E58: LDR x8, [x19]              | X8 = typeof(System.Object);             
        // 0x00BA8E5C: MOV x0, x19                | X0 = obj;//m1                           
        // 0x00BA8E60: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Object).__il2cppRuntimeField_140; X1 = typeof(System.Object).__il2cppRuntimeField_148; //  | 
        // 0x00BA8E64: BLR x9                     | X0 = typeof(System.Object).__il2cppRuntimeField_140();
        // 0x00BA8E68: MOV x1, x0                 | X1 = obj;//m1                           
        // 0x00BA8E6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA8E70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA8E74: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_7 = System.Single.Parse(s:  0);
        // 0x00BA8E78: FMOV s1, #-1.00000000      | S1 = -1;                                
        // 0x00BA8E7C: FCMP s0, s1                | STATE = COMPARE(val_7, -1)              
        // 0x00BA8E80: B.NE #0xba8edc             | if (val_7 != -1f) goto label_21;        
        if(val_7 != (-1f))
        {
            goto label_21;
        }
        // 0x00BA8E84: LDR w8, [x20, #0xc0]       | W8 = this.defaultOrthographic; //P2     
        val_12 = this.defaultOrthographic;
        // 0x00BA8E88: B #0xba8ec0                |  goto label_16;                         
        goto label_16;
        // 0x00BA8E8C: CBNZ x19, #0xba8e94        | if (obj != null) goto label_17;         
        if(val_11 != null)
        {
            goto label_17;
        }
        // 0x00BA8E90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_17:
        // 0x00BA8E94: LDR x8, [x19]              | X8 = typeof(System.Object);             
        // 0x00BA8E98: MOV x0, x19                | X0 = obj;//m1                           
        // 0x00BA8E9C: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Object).__il2cppRuntimeField_140; X1 = typeof(System.Object).__il2cppRuntimeField_148; //  | 
        // 0x00BA8EA0: BLR x9                     | X0 = typeof(System.Object).__il2cppRuntimeField_140();
        // 0x00BA8EA4: MOV x1, x0                 | X1 = obj;//m1                           
        // 0x00BA8EA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA8EAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA8EB0: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_8 = System.Int32.Parse(s:  0);
        // 0x00BA8EB4: CMN w0, #1                 | STATE = COMPARE(val_8, 0x1)             
        // 0x00BA8EB8: B.NE #0xba8edc             | if (val_8 != 1) goto label_21;          
        if(val_8 != 1)
        {
            goto label_21;
        }
        // 0x00BA8EBC: LDR w8, [x20, #0xb0]       | W8 = this.defaultIsHero; //P2           
        val_12 = this.defaultIsHero;
        label_16:
        // 0x00BA8EC0: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
        // 0x00BA8EC4: LDR x9, [x9, #0xce8]       | X9 = 1152921504608444416;               
        // 0x00BA8EC8: LDR x0, [x9]               | X0 = typeof(System.Single);             
        label_22:
        // 0x00BA8ECC: ADD x1, sp, #0xc           | X1 = (1152921513303679696 + 12) = 1152921513303679708 (0x10000002065F22DC);
        // 0x00BA8ED0: STR w8, [sp, #0xc]         | stack[1152921513303679708] = this.defaultIsHero;  //  dest_result_addr=1152921513303679708
        // 0x00BA8ED4: BL #0x27bc028              | X0 = 1152921513303731952 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), this.defaultIsHero);
        // 0x00BA8ED8: MOV x19, x0                | X19 = 1152921513303731952 (0x10000002065FEEF0);//ML01
        val_11 = val_12;
        label_21:
        // 0x00BA8EDC: MOV x0, x19                | X0 = 1152921513303731952 (0x10000002065FEEF0);//ML01
        // 0x00BA8EE0: SUB sp, x29, #0x20         | SP = (1152921513303679744 - 32) = 1152921513303679712 (0x10000002065F22E0);
        // 0x00BA8EE4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA8EE8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA8EEC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA8EF0: RET                        |  return (System.Object)this.defaultIsHero;
        return (object)val_11;
        //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        label_12:
        // 0x00BA8EF4: LDR x8, [x19]              | X8 = typeof(System.Object);             
        // 0x00BA8EF8: MOV x0, x19                | X0 = obj;//m1                           
        // 0x00BA8EFC: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Object).__il2cppRuntimeField_140; X1 = typeof(System.Object).__il2cppRuntimeField_148; //  | 
        // 0x00BA8F00: BLR x9                     | X0 = typeof(System.Object).__il2cppRuntimeField_140();
        // 0x00BA8F04: MOV x1, x0                 | X1 = obj;//m1                           
        // 0x00BA8F08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA8F0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA8F10: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_9 = System.Single.Parse(s:  0);
        // 0x00BA8F14: FCMP s0, #0.0              | STATE = COMPARE(val_9, 0)               
        // 0x00BA8F18: B.NE #0xba8f30             | if (val_9 != 0) goto label_19;          
        if(val_9 != 0f)
        {
            goto label_19;
        }
        // 0x00BA8F1C: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x00BA8F20: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
        // 0x00BA8F24: LDR x0, [x8]               | X0 = typeof(System.Single);             
        // 0x00BA8F28: MOVZ w8, #0xbf80, lsl #16  | W8 = 3212836864 (0xBF800000);//ML01     
        // 0x00BA8F2C: B #0xba8ecc                |  goto label_22;                         
        goto label_22;
        label_19:
        // 0x00BA8F30: LDR x8, [x19]              | X8 = typeof(System.Object);             
        // 0x00BA8F34: MOV x0, x19                | X0 = obj;//m1                           
        // 0x00BA8F38: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Object).__il2cppRuntimeField_140; X1 = typeof(System.Object).__il2cppRuntimeField_148; //  | 
        // 0x00BA8F3C: BLR x9                     | X0 = typeof(System.Object).__il2cppRuntimeField_140();
        // 0x00BA8F40: MOV x1, x0                 | X1 = obj;//m1                           
        // 0x00BA8F44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA8F48: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA8F4C: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_10 = System.Single.Parse(s:  0);
        // 0x00BA8F50: FCMP s0, #0.0              | STATE = COMPARE(val_10, 0)              
        // 0x00BA8F54: B.NE #0xba8edc             | if (val_10 != 0) goto label_21;         
        if(val_10 != 0f)
        {
            goto label_21;
        }
        // 0x00BA8F58: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x00BA8F5C: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
        // 0x00BA8F60: LDR x0, [x8]               | X0 = typeof(System.Single);             
        // 0x00BA8F64: ORR w8, wzr, #0x3f800000   | W8 = 1065353216(0x3F800000);            
        // 0x00BA8F68: B #0xba8ecc                |  goto label_22;                         
        goto label_22;
    
    }

}
