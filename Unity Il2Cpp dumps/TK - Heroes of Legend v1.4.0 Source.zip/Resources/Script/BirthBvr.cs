using UnityEngine;

namespace Entity.Behavior
{
    public class BirthBvr : IBehavior
    {
        // Fields
        private const float BIRTH_WAIT_TIME = 1.5;
        private float birth_time; //  0x0000001C
        private float time; //  0x00000020
        
        // Properties
        public override Entity.Behavior.EBehaviorID id { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00B68D28 (11963688), len: 8  VirtAddr: 0x00B68D28 RVA: 0x00B68D28 token: 100691427 methodIndex: 27233 delegateWrapperIndex: 0 methodInvoker: 0
        public BirthBvr()
        {
            //
            // Disasemble & Code
            // 0x00B68D28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68D2C: B #0xeb3a54                | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00B690C8 (11964616), len: 8  VirtAddr: 0x00B690C8 RVA: 0x00B690C8 token: 100691428 methodIndex: 27234 delegateWrapperIndex: 0 methodInvoker: 0
        public override Entity.Behavior.EBehaviorID get_id()
        {
            //
            // Disasemble & Code
            // 0x00B690C8: ORR w0, wzr, #8            | W0 = 8(0x8);                            
            // 0x00B690CC: RET                        |  return (Entity.Behavior.EBehaviorID)0x8;
            return (Entity.Behavior.EBehaviorID)8;
            //  |  // // {name=val_0, type=Entity.Behavior.EBehaviorID, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00B690D0 (11964624), len: 288  VirtAddr: 0x00B690D0 RVA: 0x00B690D0 token: 100691429 methodIndex: 27235 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Reason()
        {
            //
            // Disasemble & Code
            // 0x00B690D0: STP d9, d8, [sp, #-0x40]!  | stack[1152921514659143072] = ???;  stack[1152921514659143080] = ???;  //  dest_result_addr=1152921514659143072 |  dest_result_addr=1152921514659143080
            // 0x00B690D4: STP x22, x21, [sp, #0x10]  | stack[1152921514659143088] = ???;  stack[1152921514659143096] = ???;  //  dest_result_addr=1152921514659143088 |  dest_result_addr=1152921514659143096
            // 0x00B690D8: STP x20, x19, [sp, #0x20]  | stack[1152921514659143104] = ???;  stack[1152921514659143112] = ???;  //  dest_result_addr=1152921514659143104 |  dest_result_addr=1152921514659143112
            // 0x00B690DC: STP x29, x30, [sp, #0x30]  | stack[1152921514659143120] = ???;  stack[1152921514659143128] = ???;  //  dest_result_addr=1152921514659143120 |  dest_result_addr=1152921514659143128
            // 0x00B690E0: ADD x29, sp, #0x30         | X29 = (1152921514659143072 + 48) = 1152921514659143120 (0x100000025729DDD0);
            // 0x00B690E4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00B690E8: LDRB w8, [x20, #0x96d]     | W8 = (bool)static_value_0373396D;       
            // 0x00B690EC: MOV x19, x0                | X19 = 1152921514659155136 (0x10000002572A0CC0);//ML01
            // 0x00B690F0: TBNZ w8, #0, #0xb6910c     | if (static_value_0373396D == true) goto label_0;
            // 0x00B690F4: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
            // 0x00B690F8: LDR x8, [x8, #0xf60]       | X8 = 0x2B8F578;                         
            // 0x00B690FC: LDR w0, [x8]               | W0 = 0x1420;                            
            // 0x00B69100: BL #0x2782188              | X0 = sub_2782188( ?? 0x1420, ????);     
            // 0x00B69104: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00B69108: STRB w8, [x20, #0x96d]     | static_value_0373396D = true;            //  dest_result_addr=57882989
            label_0:
            // 0x00B6910C: LDRB w8, [x19, #0x18]      | 
            // 0x00B69110: CBNZ w8, #0xb69138         | if (0x1 != 0) goto label_1;             
            if(true != 0)
            {
                goto label_1;
            }
            // 0x00B69114: LDR s8, [x19, #0x20]       | S8 = this.time; //P2                    
            // 0x00B69118: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B6911C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B69120: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
            float val_1 = UnityEngine.Time.deltaTime;
            // 0x00B69124: LDR s1, [x19, #0x1c]       | S1 = this.birth_time; //P2              
            // 0x00B69128: FADD s0, s8, s0            | S0 = (this.time + val_1);               
            val_1 = this.time + val_1;
            // 0x00B6912C: STR s0, [x19, #0x20]       | this.time = (this.time + val_1);         //  dest_result_addr=1152921514659155168
            this.time = val_1;
            // 0x00B69130: FCMP s0, s1                | STATE = COMPARE((this.time + val_1), this.birth_time)
            // 0x00B69134: B.GE #0xb6914c             | if (val_1 >= this.birth_time) goto label_2;
            if(val_1 >= this.birth_time)
            {
                goto label_2;
            }
            label_1:
            // 0x00B69138: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00B6913C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00B69140: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00B69144: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
            // 0x00B69148: RET                        |  return;                                
            return;
            label_2:
            // 0x00B6914C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B69150: MOV x0, x19                | X0 = 1152921514659155136 (0x10000002572A0CC0);//ML01
            // 0x00B69154: STR wzr, [x19, #0x20]      | this.time = 0;                           //  dest_result_addr=1152921514659155168
            this.time = 0f;
            // 0x00B69158: BL #0xeb3e0c               | X0 = this.get_entity();                 
            CombatEntity val_2 = this.entity;
            // 0x00B6915C: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00B69160: CBNZ x20, #0xb69168        | if (val_2 != null) goto label_3;        
            if(val_2 != null)
            {
                goto label_3;
            }
            // 0x00B69164: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_3:
            // 0x00B69168: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B6916C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00B69170: BL #0xd7dd80               | X0 = val_2.get_bvrCtrl();               
            Entity.Behavior.IBehaviorCtrl val_3 = val_2.bvrCtrl;
            // 0x00B69174: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x00B69178: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B6917C: MOV x0, x19                | X0 = 1152921514659155136 (0x10000002572A0CC0);//ML01
            // 0x00B69180: BL #0xeb3e0c               | X0 = this.get_entity();                 
            CombatEntity val_4 = this.entity;
            // 0x00B69184: MOV x19, x0                | X19 = val_4;//m1                        
            // 0x00B69188: CBNZ x19, #0xb69190        | if (val_4 != null) goto label_4;        
            if(val_4 != null)
            {
                goto label_4;
            }
            // 0x00B6918C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_4:
            // 0x00B69190: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B69194: MOV x0, x19                | X0 = val_4;//m1                         
            // 0x00B69198: BL #0xd89f0c               | X0 = val_4.get_initBehavior();          
            int val_5 = val_4.initBehavior;
            // 0x00B6919C: MOV w19, w0                | W19 = val_5;//m1                        
            // 0x00B691A0: CBNZ x20, #0xb691a8        | if (val_3 != null) goto label_5;        
            if(val_3 != null)
            {
                goto label_5;
            }
            // 0x00B691A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_5:
            // 0x00B691A8: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00B691AC: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x00B691B0: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
            // 0x00B691B4: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00B691B8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00B691BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B691C0: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00B691C4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00B691C8: LDR x8, [x20]              | X8 = typeof(Entity.Behavior.IBehaviorCtrl);
            // 0x00B691CC: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00B691D0: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x00B691D4: MOV w1, w19                | W1 = val_5;//m1                         
            // 0x00B691D8: LDP x4, x3, [x8, #0x180]   | X4 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180; X3 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_188; //  | 
            // 0x00B691DC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00B691E0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00B691E4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00B691E8: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
            // 0x00B691EC: BR x4                      | goto typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180;
            goto typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180;
        
        }
        //
        // Offset in libil2cpp.so: 0x00B691F0 (11964912), len: 4  VirtAddr: 0x00B691F0 RVA: 0x00B691F0 token: 100691430 methodIndex: 27236 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Action()
        {
            //
            // Disasemble & Code
            // 0x00B691F0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00B691F4 (11964916), len: 312  VirtAddr: 0x00B691F4 RVA: 0x00B691F4 token: 100691431 methodIndex: 27237 delegateWrapperIndex: 0 methodInvoker: 0
        public override void DoEntering()
        {
            //
            // Disasemble & Code
            // 0x00B691F4: STP x22, x21, [sp, #-0x30]! | stack[1152921514659395760] = ???;  stack[1152921514659395768] = ???;  //  dest_result_addr=1152921514659395760 |  dest_result_addr=1152921514659395768
            // 0x00B691F8: STP x20, x19, [sp, #0x10]  | stack[1152921514659395776] = ???;  stack[1152921514659395784] = ???;  //  dest_result_addr=1152921514659395776 |  dest_result_addr=1152921514659395784
            // 0x00B691FC: STP x29, x30, [sp, #0x20]  | stack[1152921514659395792] = ???;  stack[1152921514659395800] = ???;  //  dest_result_addr=1152921514659395792 |  dest_result_addr=1152921514659395800
            // 0x00B69200: ADD x29, sp, #0x20         | X29 = (1152921514659395760 + 32) = 1152921514659395792 (0x10000002572DB8D0);
            // 0x00B69204: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00B69208: LDRB w8, [x20, #0x96e]     | W8 = (bool)static_value_0373396E;       
            // 0x00B6920C: MOV x19, x0                | X19 = 1152921514659407808 (0x10000002572DE7C0);//ML01
            // 0x00B69210: TBNZ w8, #0, #0xb6922c     | if (static_value_0373396E == true) goto label_0;
            // 0x00B69214: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00B69218: LDR x8, [x8, #0x9d8]       | X8 = 0x2B8F574;                         
            // 0x00B6921C: LDR w0, [x8]               | W0 = 0x141F;                            
            // 0x00B69220: BL #0x2782188              | X0 = sub_2782188( ?? 0x141F, ????);     
            // 0x00B69224: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00B69228: STRB w8, [x20, #0x96e]     | static_value_0373396E = true;            //  dest_result_addr=57882990
            label_0:
            // 0x00B6922C: STR wzr, [x19, #0x20]      | this.time = 0;                           //  dest_result_addr=1152921514659407840
            this.time = 0f;
            // 0x00B69230: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x00B69234: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
            // 0x00B69238: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
            // 0x00B6923C: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
            // 0x00B69240: LDR x20, [x8]              | X20 = GameMgr.UPDATEOnOffEffect;        
            // 0x00B69244: CBNZ x20, #0xb6924c        | if (GameMgr.UPDATEOnOffEffect != null) goto label_1;
            if(GameMgr.UPDATEOnOffEffect != null)
            {
                goto label_1;
            }
            // 0x00B69248: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x141F, ????);     
            label_1:
            // 0x00B6924C: LDR w8, [x20, #0x60]       | W8 = GameMgr.UPDATEOnOffEffect + 96;     //  not_find_field!2:96
            // 0x00B69250: CMP w8, #0xe               | STATE = COMPARE(GameMgr.UPDATEOnOffEffect + 96, 0xE)
            // 0x00B69254: B.NE #0xb69318             | if (GameMgr.UPDATEOnOffEffect + 96 != 0xE) goto label_2;
            if((GameMgr.UPDATEOnOffEffect + 96) != 14)
            {
                goto label_2;
            }
            // 0x00B69258: ORR w8, wzr, #0x3fc00000   | W8 = 1069547520(0x3FC00000);            
            // 0x00B6925C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B69260: MOV x0, x19                | X0 = 1152921514659407808 (0x10000002572DE7C0);//ML01
            // 0x00B69264: STR w8, [x19, #0x1c]       | this.birth_time = 1.5;                   //  dest_result_addr=1152921514659407836
            this.birth_time = 1.5f;
            // 0x00B69268: BL #0xeb3e0c               | X0 = this.get_entity();                 
            CombatEntity val_1 = this.entity;
            // 0x00B6926C: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00B69270: CBNZ x20, #0xb69278        | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x00B69274: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x00B69278: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B6927C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00B69280: BL #0xd89c48               | X0 = val_1.get_appeareffect();          
            int val_2 = val_1.appeareffect;
            // 0x00B69284: CMP w0, #1                 | STATE = COMPARE(val_2, 0x1)             
            // 0x00B69288: B.LT #0xb6931c             | if (val_2 < 1) goto label_4;            
            if(val_2 < 1)
            {
                goto label_4;
            }
            // 0x00B6928C: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
            // 0x00B69290: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
            // 0x00B69294: LDR x0, [x8]               | X0 = typeof(ZMG);                       
            // 0x00B69298: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
            // 0x00B6929C: TBZ w8, #0, #0xb692ac      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00B692A0: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
            // 0x00B692A4: CBNZ w8, #0xb692ac         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00B692A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
            label_6:
            // 0x00B692AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B692B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B692B4: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
            EffectMgr val_3 = ZMG.EffectMgr;
            // 0x00B692B8: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x00B692BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B692C0: MOV x0, x19                | X0 = 1152921514659407808 (0x10000002572DE7C0);//ML01
            // 0x00B692C4: BL #0xeb3e0c               | X0 = this.get_entity();                 
            CombatEntity val_4 = this.entity;
            // 0x00B692C8: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x00B692CC: CBNZ x21, #0xb692d4        | if (val_4 != null) goto label_7;        
            if(val_4 != null)
            {
                goto label_7;
            }
            // 0x00B692D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_7:
            // 0x00B692D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B692D8: MOV x0, x21                | X0 = val_4;//m1                         
            // 0x00B692DC: BL #0xd89c48               | X0 = val_4.get_appeareffect();          
            int val_5 = val_4.appeareffect;
            // 0x00B692E0: MOV w21, w0                | W21 = val_5;//m1                        
            // 0x00B692E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B692E8: MOV x0, x19                | X0 = 1152921514659407808 (0x10000002572DE7C0);//ML01
            // 0x00B692EC: BL #0xeb3e0c               | X0 = this.get_entity();                 
            CombatEntity val_6 = this.entity;
            // 0x00B692F0: MOV x19, x0                | X19 = val_6;//m1                        
            // 0x00B692F4: CBNZ x20, #0xb692fc        | if (val_3 != null) goto label_8;        
            if(val_3 != null)
            {
                goto label_8;
            }
            // 0x00B692F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_8:
            // 0x00B692FC: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x00B69300: MOV x2, x19                | X2 = val_6;//m1                         
            // 0x00B69304: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00B69308: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00B6930C: MOV w1, w21                | W1 = val_5;//m1                         
            // 0x00B69310: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00B69314: B #0xb617dc                | val_3.PlayEffect(id:  val_5, srcTf:  val_6); return;
            val_3.PlayEffect(id:  val_5, srcTf:  val_6);
            return;
            label_2:
            // 0x00B69318: STR wzr, [x19, #0x1c]      | this.birth_time = 0;                     //  dest_result_addr=1152921514659407836
            this.birth_time = 0f;
            label_4:
            // 0x00B6931C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00B69320: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00B69324: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00B69328: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00B6932C (11965228), len: 4  VirtAddr: 0x00B6932C RVA: 0x00B6932C token: 100691432 methodIndex: 27238 delegateWrapperIndex: 0 methodInvoker: 0
        public override void DoLeaving()
        {
            //
            // Disasemble & Code
            // 0x00B6932C: RET                        |  return;                                
            return;
        
        }
    
    }

}
