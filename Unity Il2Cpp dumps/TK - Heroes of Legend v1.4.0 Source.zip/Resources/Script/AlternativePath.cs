using UnityEngine;

namespace Pathfinding
{
    [UnityEngine.AddComponentMenu] // 0x285C3EC
    [Serializable]
    public class AlternativePath : MonoModifier
    {
        // Fields
        public int penalty; //  0x00000024
        public int randomStep; //  0x00000028
        private Pathfinding.GraphNode[] prevNodes; //  0x00000030
        private int prevSeed; //  0x00000038
        private int prevPenalty; //  0x0000003C
        private bool waitingForApply; //  0x00000040
        private object lockObject; //  0x00000048
        private System.Random rnd; //  0x00000050
        private System.Random seedGenerator; //  0x00000058
        private bool destroyed; //  0x00000060
        private Pathfinding.GraphNode[] toBeApplied; //  0x00000068
        
        // Properties
        public override Pathfinding.ModifierData input { get; }
        public override Pathfinding.ModifierData output { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x0167D5E8 (23582184), len: 180  VirtAddr: 0x0167D5E8 RVA: 0x0167D5E8 token: 100683441 methodIndex: 49742 delegateWrapperIndex: 0 methodInvoker: 0
        public AlternativePath()
        {
            //
            // Disasemble & Code
            // 0x0167D5E8: STP x22, x21, [sp, #-0x30]! | stack[1152921513483584656] = ???;  stack[1152921513483584664] = ???;  //  dest_result_addr=1152921513483584656 |  dest_result_addr=1152921513483584664
            // 0x0167D5EC: STP x20, x19, [sp, #0x10]  | stack[1152921513483584672] = ???;  stack[1152921513483584680] = ???;  //  dest_result_addr=1152921513483584672 |  dest_result_addr=1152921513483584680
            // 0x0167D5F0: STP x29, x30, [sp, #0x20]  | stack[1152921513483584688] = ???;  stack[1152921513483584696] = ???;  //  dest_result_addr=1152921513483584688 |  dest_result_addr=1152921513483584696
            // 0x0167D5F4: ADD x29, sp, #0x20         | X29 = (1152921513483584656 + 32) = 1152921513483584688 (0x10000002111844B0);
            // 0x0167D5F8: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x0167D5FC: LDRB w8, [x20, #0xa6]      | W8 = (bool)static_value_037380A6;       
            // 0x0167D600: MOV x19, x0                | X19 = 1152921513483596704 (0x10000002111873A0);//ML01
            // 0x0167D604: TBNZ w8, #0, #0x167d620    | if (static_value_037380A6 == true) goto label_0;
            // 0x0167D608: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x0167D60C: LDR x8, [x8, #0xf38]       | X8 = 0x2B8AC24;                         
            // 0x0167D610: LDR w0, [x8]               | W0 = 0x1C7;                             
            // 0x0167D614: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C7, ????);      
            // 0x0167D618: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0167D61C: STRB w8, [x20, #0xa6]      | static_value_037380A6 = true;            //  dest_result_addr=57901222
            label_0:
            // 0x0167D620: MOVZ x8, #0xa, lsl #32     | X8 = 42949672960 (0xA00000000);//ML01   
            // 0x0167D624: MOVK x8, #0x3e8            | X8 = 42949673960 (0xA000003E8);         
            // 0x0167D628: STUR x8, [x19, #0x24]      | this.penalty = 1000; this.randomStep = 10;  //  dest_result_addr=1152921513483596740 dest_result_addr=1152921513483596744
            this.penalty = 1000;
            this.randomStep = 10;
            // 0x0167D62C: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x0167D630: LDR x8, [x8, #0xf90]       | X8 = 1152921504606900224;               
            // 0x0167D634: LDR x0, [x8]               | X0 = typeof(System.Object);             
            object val_1 = null;
            // 0x0167D638: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Object), ????);
            // 0x0167D63C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167D640: MOV x20, x0                | X20 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x0167D644: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x0167D648: STR x20, [x19, #0x48]      | this.lockObject = typeof(System.Object);  //  dest_result_addr=1152921513483596776
            this.lockObject = val_1;
            // 0x0167D64C: ADRP x21, #0x3646000       | X21 = 56909824 (0x3646000);             
            // 0x0167D650: LDR x21, [x21, #0x618]     | X21 = 1152921504655994880;              
            // 0x0167D654: LDR x0, [x21]              | X0 = typeof(System.Random);             
            System.Random val_2 = null;
            // 0x0167D658: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Random), ????);
            // 0x0167D65C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167D660: MOV x20, x0                | X20 = 1152921504655994880 (0x1000000002EDF000);//ML01
            // 0x0167D664: BL #0x170989c              | .ctor();                                
            val_2 = new System.Random();
            // 0x0167D668: STR x20, [x19, #0x50]      | this.rnd = typeof(System.Random);        //  dest_result_addr=1152921513483596784
            this.rnd = val_2;
            // 0x0167D66C: LDR x0, [x21]              | X0 = typeof(System.Random);             
            System.Random val_3 = null;
            // 0x0167D670: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Random), ????);
            // 0x0167D674: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167D678: MOV x20, x0                | X20 = 1152921504655994880 (0x1000000002EDF000);//ML01
            // 0x0167D67C: BL #0x170989c              | .ctor();                                
            val_3 = new System.Random();
            // 0x0167D680: STR x20, [x19, #0x58]      | this.seedGenerator = typeof(System.Random);  //  dest_result_addr=1152921513483596792
            this.seedGenerator = val_3;
            // 0x0167D684: MOV x0, x19                | X0 = 1152921513483596704 (0x10000002111873A0);//ML01
            // 0x0167D688: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0167D68C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0167D690: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167D694: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0167D698: B #0x155916c               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0167D69C (23582364), len: 8  VirtAddr: 0x0167D69C RVA: 0x0167D69C token: 100683442 methodIndex: 49743 delegateWrapperIndex: 0 methodInvoker: 0
        public override Pathfinding.ModifierData get_input()
        {
            //
            // Disasemble & Code
            // 0x0167D69C: ORR w0, wzr, #0x10         | W0 = 16(0x10);                          
            // 0x0167D6A0: RET                        |  return (Pathfinding.ModifierData)0x10; 
            return (Pathfinding.ModifierData)16;
            //  |  // // {name=val_0, type=Pathfinding.ModifierData, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0167D6A4 (23582372), len: 8  VirtAddr: 0x0167D6A4 RVA: 0x0167D6A4 token: 100683443 methodIndex: 49744 delegateWrapperIndex: 0 methodInvoker: 0
        public override Pathfinding.ModifierData get_output()
        {
            //
            // Disasemble & Code
            // 0x0167D6A4: MOVN w0, #0                | W0 = 0 (0x0);//ML01                     
            // 0x0167D6A8: RET                        |  return (Pathfinding.ModifierData)null; 
            return (Pathfinding.ModifierData)0;
            //  |  // // {name=val_0, type=Pathfinding.ModifierData, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0167D6AC (23582380), len: 536  VirtAddr: 0x0167D6AC RVA: 0x0167D6AC token: 100683444 methodIndex: 49745 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Apply(Pathfinding.Path p, Pathfinding.ModifierData source)
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            //  | 
            object val_7;
            //  | 
            System.Collections.Generic.List<Pathfinding.GraphNode> val_8;
            //  | 
            var val_9;
            //  | 
            OnPathDelegate val_10;
            // 0x0167D6AC: STP x26, x25, [sp, #-0x50]! | stack[1152921513483978992] = ???;  stack[1152921513483979000] = ???;  //  dest_result_addr=1152921513483978992 |  dest_result_addr=1152921513483979000
            // 0x0167D6B0: STP x24, x23, [sp, #0x10]  | stack[1152921513483979008] = ???;  stack[1152921513483979016] = ???;  //  dest_result_addr=1152921513483979008 |  dest_result_addr=1152921513483979016
            // 0x0167D6B4: STP x22, x21, [sp, #0x20]  | stack[1152921513483979024] = ???;  stack[1152921513483979032] = ???;  //  dest_result_addr=1152921513483979024 |  dest_result_addr=1152921513483979032
            // 0x0167D6B8: STP x20, x19, [sp, #0x30]  | stack[1152921513483979040] = ???;  stack[1152921513483979048] = ???;  //  dest_result_addr=1152921513483979040 |  dest_result_addr=1152921513483979048
            // 0x0167D6BC: STP x29, x30, [sp, #0x40]  | stack[1152921513483979056] = ???;  stack[1152921513483979064] = ???;  //  dest_result_addr=1152921513483979056 |  dest_result_addr=1152921513483979064
            // 0x0167D6C0: ADD x29, sp, #0x40         | X29 = (1152921513483978992 + 64) = 1152921513483979056 (0x10000002111E4930);
            // 0x0167D6C4: SUB sp, sp, #0x10          | SP = (1152921513483978992 - 16) = 1152921513483978976 (0x10000002111E48E0);
            // 0x0167D6C8: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x0167D6CC: LDRB w8, [x19, #0xa7]      | W8 = (bool)static_value_037380A7;       
            // 0x0167D6D0: MOV x21, x1                | X21 = p;//m1                            
            val_8 = p;
            // 0x0167D6D4: MOV x20, x0                | X20 = 1152921513483991072 (0x10000002111E7820);//ML01
            // 0x0167D6D8: TBNZ w8, #0, #0x167d6f4    | if (static_value_037380A7 == true) goto label_0;
            // 0x0167D6DC: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
            // 0x0167D6E0: LDR x8, [x8, #0x460]       | X8 = 0x2B8AC28;                         
            // 0x0167D6E4: LDR w0, [x8]               | W0 = 0x1C8;                             
            // 0x0167D6E8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C8, ????);      
            // 0x0167D6EC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0167D6F0: STRB w8, [x19, #0xa7]      | static_value_037380A7 = true;            //  dest_result_addr=57901223
            label_0:
            // 0x0167D6F4: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x0167D6F8: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
            // 0x0167D6FC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
            // 0x0167D700: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
            // 0x0167D704: TBZ w8, #0, #0x167d714     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0167D708: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
            // 0x0167D70C: CBNZ w8, #0x167d714        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0167D710: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
            label_2:
            // 0x0167D714: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167D718: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167D71C: MOV x1, x20                | X1 = 1152921513483991072 (0x10000002111E7820);//ML01
            // 0x0167D720: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0167D724: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  this);
            bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  this);
            // 0x0167D728: AND w8, w0, #1             | W8 = (val_1 & 1);                       
            bool val_2 = val_1;
            // 0x0167D72C: TBNZ w8, #0, #0x167d84c    | if ((val_1 & 1) == true) goto label_3;  
            if(val_2 == true)
            {
                goto label_3;
            }
            // 0x0167D730: LDR x19, [x20, #0x48]      | X19 = this.lockObject; //P2             
            val_7 = this.lockObject;
            // 0x0167D734: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167D738: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167D73C: MOV x1, x19                | X1 = this.lockObject;//m1               
            // 0x0167D740: BL #0x1b557bc              | System.Threading.Monitor.Enter(obj:  0);
            System.Threading.Monitor.Enter(obj:  0);
            // 0x0167D744: CBNZ x21, #0x167d74c       | if (p != null) goto label_4;            
            if(val_8 != null)
            {
                goto label_4;
            }
            // 0x0167D748: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_4:
            // 0x0167D74C: LDR x21, [x21, #0x60]      | X21 = p.path; //P2                      
            val_8 = p.path;
            // 0x0167D750: CBNZ x21, #0x167d758       | if (p.path != null) goto label_5;       
            if(val_8 != null)
            {
                goto label_5;
            }
            // 0x0167D754: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_5:
            // 0x0167D758: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
            // 0x0167D75C: LDR x8, [x8, #0x670]       | X8 = 1152921513382498144;               
            // 0x0167D760: LDR x1, [x8]               | X1 = public T[] System.Collections.Generic.List<Pathfinding.GraphNode>::ToArray();
            // 0x0167D764: MOV x0, x21                | X0 = p.path;//m1                        
            // 0x0167D768: BL #0x25ed474              | X0 = p.path.ToArray();                  
            T[] val_3 = val_8.ToArray();
            // 0x0167D76C: LDRB w8, [x20, #0x40]      | W8 = this.waitingForApply; //P2         
            // 0x0167D770: STR x0, [x20, #0x68]       | this.toBeApplied = val_3;                //  dest_result_addr=1152921513483991176
            this.toBeApplied = val_3;
            // 0x0167D774: CBNZ w8, #0x167d83c        | if (this.waitingForApply == true) goto label_6;
            if(this.waitingForApply == true)
            {
                goto label_6;
            }
            // 0x0167D778: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0167D77C: STRB w8, [x20, #0x40]      | this.waitingForApply = true;             //  dest_result_addr=1152921513483991136
            this.waitingForApply = true;
            // 0x0167D780: ADRP x24, #0x362c000       | X24 = 56803328 (0x362C000);             
            // 0x0167D784: LDR x24, [x24, #0xe80]     | X24 = 1152921504837996544;              
            // 0x0167D788: LDR x0, [x24]              | X0 = typeof(AstarPath);                 
            val_9 = null;
            // 0x0167D78C: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
            // 0x0167D790: TBZ w8, #0, #0x167d7a4     | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x0167D794: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
            // 0x0167D798: CBNZ w8, #0x167d7a4        | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x0167D79C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
            // 0x0167D7A0: LDR x0, [x24]              | X0 = typeof(AstarPath);                 
            val_9 = null;
            label_8:
            // 0x0167D7A4: ADRP x9, #0x3654000        | X9 = 56967168 (0x3654000);              
            // 0x0167D7A8: ADRP x25, #0x35fa000       | X25 = 56598528 (0x35FA000);             
            // 0x0167D7AC: LDR x8, [x0, #0xa0]        | X8 = AstarPath.__il2cppRuntimeField_static_fields;
            // 0x0167D7B0: LDR x9, [x9, #0xe50]       | X9 = 1152921513483961952;               
            // 0x0167D7B4: LDR x25, [x25, #0x288]     | X25 = 1152921504836718592;              
            // 0x0167D7B8: LDR x21, [x8, #0x40]       | X21 = AstarPath.OnPathPreSearch;        
            val_8 = AstarPath.OnPathPreSearch;
            // 0x0167D7BC: LDR x23, [x9]              | X23 = System.Void Pathfinding.AlternativePath::ApplyNow(Pathfinding.Path somePath);
            // 0x0167D7C0: LDR x0, [x25]              | X0 = typeof(OnPathDelegate);            
            // 0x0167D7C4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(OnPathDelegate), ????);
            // 0x0167D7C8: MOV x22, x0                | X22 = 1152921504836718592 (0x100000000DB39000);//ML01
            // 0x0167D7CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0167D7D0: MOV x0, x22                | X0 = 1152921504836718592 (0x100000000DB39000);//ML01
            OnPathDelegate val_4 = null;
            // 0x0167D7D4: MOV x1, x20                | X1 = 1152921513483991072 (0x10000002111E7820);//ML01
            // 0x0167D7D8: MOV x2, x23                | X2 = 1152921513483961952 (0x10000002111E0660);//ML01
            // 0x0167D7DC: BL #0xd1b25c               | .ctor(object:  this, method:  System.Void Pathfinding.AlternativePath::ApplyNow(Pathfinding.Path somePath));
            val_4 = new OnPathDelegate(object:  this, method:  System.Void Pathfinding.AlternativePath::ApplyNow(Pathfinding.Path somePath));
            // 0x0167D7E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167D7E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0167D7E8: MOV x1, x21                | X1 = AstarPath.OnPathPreSearch;//m1     
            // 0x0167D7EC: MOV x2, x22                | X2 = 1152921504836718592 (0x100000000DB39000);//ML01
            // 0x0167D7F0: BL #0x1c34bb4              | X0 = System.Delegate.Combine(a:  0, b:  val_8);
            System.Delegate val_5 = System.Delegate.Combine(a:  0, b:  val_8);
            // 0x0167D7F4: LDR x8, [x24]              | X8 = typeof(AstarPath);                 
            // 0x0167D7F8: LDR x20, [x8, #0xa0]       | X20 = AstarPath.__il2cppRuntimeField_static_fields;
            // 0x0167D7FC: CBZ x0, #0x167d834         | if (val_5 == null) goto label_9;        
            if(val_5 == null)
            {
                goto label_9;
            }
            // 0x0167D800: LDR x1, [x25]              | X1 = typeof(OnPathDelegate);            
            // 0x0167D804: LDR x8, [x0]               | X8 = typeof(System.Delegate);           
            // 0x0167D808: CMP x8, x1                 | STATE = COMPARE(typeof(System.Delegate), typeof(OnPathDelegate))
            // 0x0167D80C: B.EQ #0x167d838            | if (typeof(System.Delegate) == null) goto label_10;
            if(null == null)
            {
                goto label_10;
            }
            // 0x0167D810: LDR x0, [x8, #0x30]        | X0 = System.Delegate.__il2cppRuntimeField_element_class;
            // 0x0167D814: ADD x8, sp, #8             | X8 = (1152921513483978976 + 8) = 1152921513483978984 (0x10000002111E48E8);
            // 0x0167D818: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Delegate.__il2cppRuntimeField_element_class, ????);
            // 0x0167D81C: LDR x0, [sp, #8]           | X0 = val_6;                              //  find_add[1152921513483967072]
            // 0x0167D820: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x0167D824: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167D828: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x0167D82C: ADD x0, sp, #8             | X0 = (1152921513483978976 + 8) = 1152921513483978984 (0x10000002111E48E8);
            // 0x0167D830: BL #0x299a140              | 
            label_9:
            // 0x0167D834: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_10 = 0;
            label_10:
            // 0x0167D838: STR x0, [x20, #0x40]       | AstarPath.OnPathPreSearch = null;        //  dest_result_addr=1152921504838000704
            AstarPath.OnPathPreSearch = val_10;
            label_6:
            // 0x0167D83C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167D840: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167D844: MOV x1, x19                | X1 = this.lockObject;//m1               
            // 0x0167D848: BL #0x1b557c4              | System.Threading.Monitor.Exit(obj:  0); 
            System.Threading.Monitor.Exit(obj:  0);
            label_3:
            // 0x0167D84C: SUB sp, x29, #0x40         | SP = (1152921513483979056 - 64) = 1152921513483978992 (0x10000002111E48F0);
            // 0x0167D850: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0167D854: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0167D858: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0167D85C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0167D860: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0167D864: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0167D8C4 (23582916), len: 444  VirtAddr: 0x0167D8C4 RVA: 0x0167D8C4 token: 100683445 methodIndex: 49746 delegateWrapperIndex: 0 methodInvoker: 0
        public void OnDestroy()
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            //  | 
            bool val_4;
            //  | 
            var val_5;
            //  | 
            OnPathDelegate val_6;
            // 0x0167D8C4: STP x26, x25, [sp, #-0x50]! | stack[1152921513484157552] = ???;  stack[1152921513484157560] = ???;  //  dest_result_addr=1152921513484157552 |  dest_result_addr=1152921513484157560
            // 0x0167D8C8: STP x24, x23, [sp, #0x10]  | stack[1152921513484157568] = ???;  stack[1152921513484157576] = ???;  //  dest_result_addr=1152921513484157568 |  dest_result_addr=1152921513484157576
            // 0x0167D8CC: STP x22, x21, [sp, #0x20]  | stack[1152921513484157584] = ???;  stack[1152921513484157592] = ???;  //  dest_result_addr=1152921513484157584 |  dest_result_addr=1152921513484157592
            // 0x0167D8D0: STP x20, x19, [sp, #0x30]  | stack[1152921513484157600] = ???;  stack[1152921513484157608] = ???;  //  dest_result_addr=1152921513484157600 |  dest_result_addr=1152921513484157608
            // 0x0167D8D4: STP x29, x30, [sp, #0x40]  | stack[1152921513484157616] = ???;  stack[1152921513484157624] = ???;  //  dest_result_addr=1152921513484157616 |  dest_result_addr=1152921513484157624
            // 0x0167D8D8: ADD x29, sp, #0x40         | X29 = (1152921513484157552 + 64) = 1152921513484157616 (0x10000002112102B0);
            // 0x0167D8DC: SUB sp, sp, #0x10          | SP = (1152921513484157552 - 16) = 1152921513484157536 (0x1000000211210260);
            // 0x0167D8E0: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x0167D8E4: LDRB w8, [x20, #0xa8]      | W8 = (bool)static_value_037380A8;       
            // 0x0167D8E8: MOV x19, x0                | X19 = 1152921513484169632 (0x10000002112131A0);//ML01
            // 0x0167D8EC: TBNZ w8, #0, #0x167d908    | if (static_value_037380A8 == true) goto label_0;
            // 0x0167D8F0: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x0167D8F4: LDR x8, [x8, #0x880]       | X8 = 0x2B8AC38;                         
            // 0x0167D8F8: LDR w0, [x8]               | W0 = 0x1CC;                             
            // 0x0167D8FC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1CC, ????);      
            // 0x0167D900: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0167D904: STRB w8, [x20, #0xa8]      | static_value_037380A8 = true;            //  dest_result_addr=57901224
            label_0:
            // 0x0167D908: LDR x20, [x19, #0x48]      | X20 = this.lockObject; //P2             
            // 0x0167D90C: ORR w21, wzr, #1           | W21 = 1(0x1);                           
            val_4 = true;
            // 0x0167D910: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167D914: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167D918: MOV x1, x20                | X1 = this.lockObject;//m1               
            // 0x0167D91C: STRB w21, [x19, #0x60]     | this.destroyed = true;                   //  dest_result_addr=1152921513484169728
            this.destroyed = val_4;
            // 0x0167D920: BL #0x1b557bc              | System.Threading.Monitor.Enter(obj:  0);
            System.Threading.Monitor.Enter(obj:  0);
            // 0x0167D924: LDRB w8, [x19, #0x40]      | W8 = this.waitingForApply; //P2         
            // 0x0167D928: CBNZ w8, #0x167d9ec        | if (this.waitingForApply == true) goto label_1;
            if(this.waitingForApply == true)
            {
                goto label_1;
            }
            // 0x0167D92C: STRB w21, [x19, #0x40]     | this.waitingForApply = true;             //  dest_result_addr=1152921513484169696
            this.waitingForApply = val_4;
            // 0x0167D930: ADRP x24, #0x362c000       | X24 = 56803328 (0x362C000);             
            // 0x0167D934: LDR x24, [x24, #0xe80]     | X24 = 1152921504837996544;              
            // 0x0167D938: LDR x0, [x24]              | X0 = typeof(AstarPath);                 
            val_5 = null;
            // 0x0167D93C: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
            // 0x0167D940: TBZ w8, #0, #0x167d954     | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0167D944: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
            // 0x0167D948: CBNZ w8, #0x167d954        | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0167D94C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
            // 0x0167D950: LDR x0, [x24]              | X0 = typeof(AstarPath);                 
            val_5 = null;
            label_3:
            // 0x0167D954: ADRP x9, #0x362f000        | X9 = 56815616 (0x362F000);              
            // 0x0167D958: ADRP x25, #0x35fa000       | X25 = 56598528 (0x35FA000);             
            // 0x0167D95C: LDR x8, [x0, #0xa0]        | X8 = AstarPath.__il2cppRuntimeField_static_fields;
            // 0x0167D960: LDR x9, [x9, #0x4d0]       | X9 = 1152921513484140512;               
            // 0x0167D964: LDR x25, [x25, #0x288]     | X25 = 1152921504836718592;              
            // 0x0167D968: LDR x21, [x8, #0x40]       | X21 = AstarPath.OnPathPreSearch;        
            // 0x0167D96C: LDR x23, [x9]              | X23 = System.Void Pathfinding.AlternativePath::ClearOnDestroy(Pathfinding.Path p);
            // 0x0167D970: LDR x0, [x25]              | X0 = typeof(OnPathDelegate);            
            // 0x0167D974: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(OnPathDelegate), ????);
            // 0x0167D978: MOV x22, x0                | X22 = 1152921504836718592 (0x100000000DB39000);//ML01
            // 0x0167D97C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0167D980: MOV x0, x22                | X0 = 1152921504836718592 (0x100000000DB39000);//ML01
            OnPathDelegate val_1 = null;
            // 0x0167D984: MOV x1, x19                | X1 = 1152921513484169632 (0x10000002112131A0);//ML01
            // 0x0167D988: MOV x2, x23                | X2 = 1152921513484140512 (0x100000021120BFE0);//ML01
            // 0x0167D98C: BL #0xd1b25c               | .ctor(object:  this, method:  System.Void Pathfinding.AlternativePath::ClearOnDestroy(Pathfinding.Path p));
            val_1 = new OnPathDelegate(object:  this, method:  System.Void Pathfinding.AlternativePath::ClearOnDestroy(Pathfinding.Path p));
            // 0x0167D990: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167D994: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0167D998: MOV x1, x21                | X1 = AstarPath.OnPathPreSearch;//m1     
            // 0x0167D99C: MOV x2, x22                | X2 = 1152921504836718592 (0x100000000DB39000);//ML01
            // 0x0167D9A0: BL #0x1c34bb4              | X0 = System.Delegate.Combine(a:  0, b:  AstarPath.OnPathPreSearch);
            System.Delegate val_2 = System.Delegate.Combine(a:  0, b:  AstarPath.OnPathPreSearch);
            // 0x0167D9A4: LDR x8, [x24]              | X8 = typeof(AstarPath);                 
            // 0x0167D9A8: LDR x21, [x8, #0xa0]       | X21 = AstarPath.__il2cppRuntimeField_static_fields;
            // 0x0167D9AC: CBZ x0, #0x167d9e4         | if (val_2 == null) goto label_4;        
            if(val_2 == null)
            {
                goto label_4;
            }
            // 0x0167D9B0: LDR x1, [x25]              | X1 = typeof(OnPathDelegate);            
            // 0x0167D9B4: LDR x8, [x0]               | X8 = typeof(System.Delegate);           
            // 0x0167D9B8: CMP x8, x1                 | STATE = COMPARE(typeof(System.Delegate), typeof(OnPathDelegate))
            // 0x0167D9BC: B.EQ #0x167d9e8            | if (typeof(System.Delegate) == null) goto label_5;
            if(null == null)
            {
                goto label_5;
            }
            // 0x0167D9C0: LDR x0, [x8, #0x30]        | X0 = System.Delegate.__il2cppRuntimeField_element_class;
            // 0x0167D9C4: ADD x8, sp, #8             | X8 = (1152921513484157536 + 8) = 1152921513484157544 (0x1000000211210268);
            // 0x0167D9C8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Delegate.__il2cppRuntimeField_element_class, ????);
            // 0x0167D9CC: LDR x0, [sp, #8]           | X0 = val_3;                              //  find_add[1152921513484145632]
            // 0x0167D9D0: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
            // 0x0167D9D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167D9D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            // 0x0167D9DC: ADD x0, sp, #8             | X0 = (1152921513484157536 + 8) = 1152921513484157544 (0x1000000211210268);
            // 0x0167D9E0: BL #0x299a140              | 
            label_4:
            // 0x0167D9E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_6 = 0;
            label_5:
            // 0x0167D9E8: STR x0, [x21, #0x40]       | AstarPath.OnPathPreSearch = null;        //  dest_result_addr=1152921504838000704
            AstarPath.OnPathPreSearch = val_6;
            label_1:
            // 0x0167D9EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167D9F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167D9F4: MOV x1, x20                | X1 = this.lockObject;//m1               
            // 0x0167D9F8: BL #0x1b557c4              | System.Threading.Monitor.Exit(obj:  0); 
            System.Threading.Monitor.Exit(obj:  0);
            // 0x0167D9FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167DA00: MOV x0, x19                | X0 = 1152921513484169632 (0x10000002112131A0);//ML01
            // 0x0167DA04: BL #0x1559244              | this.OnDestroy();                       
            this.OnDestroy();
            // 0x0167DA08: SUB sp, x29, #0x40         | SP = (1152921513484157616 - 64) = 1152921513484157552 (0x1000000211210270);
            // 0x0167DA0C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0167DA10: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0167DA14: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0167DA18: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0167DA1C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0167DA20: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0167DA80 (23583360), len: 424  VirtAddr: 0x0167DA80 RVA: 0x0167DA80 token: 100683446 methodIndex: 49747 delegateWrapperIndex: 0 methodInvoker: 0
        private void ClearOnDestroy(Pathfinding.Path p)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            OnPathDelegate val_5;
            // 0x0167DA80: STP x26, x25, [sp, #-0x50]! | stack[1152921513484290032] = ???;  stack[1152921513484290040] = ???;  //  dest_result_addr=1152921513484290032 |  dest_result_addr=1152921513484290040
            // 0x0167DA84: STP x24, x23, [sp, #0x10]  | stack[1152921513484290048] = ???;  stack[1152921513484290056] = ???;  //  dest_result_addr=1152921513484290048 |  dest_result_addr=1152921513484290056
            // 0x0167DA88: STP x22, x21, [sp, #0x20]  | stack[1152921513484290064] = ???;  stack[1152921513484290072] = ???;  //  dest_result_addr=1152921513484290064 |  dest_result_addr=1152921513484290072
            // 0x0167DA8C: STP x20, x19, [sp, #0x30]  | stack[1152921513484290080] = ???;  stack[1152921513484290088] = ???;  //  dest_result_addr=1152921513484290080 |  dest_result_addr=1152921513484290088
            // 0x0167DA90: STP x29, x30, [sp, #0x40]  | stack[1152921513484290096] = ???;  stack[1152921513484290104] = ???;  //  dest_result_addr=1152921513484290096 |  dest_result_addr=1152921513484290104
            // 0x0167DA94: ADD x29, sp, #0x40         | X29 = (1152921513484290032 + 64) = 1152921513484290096 (0x1000000211230830);
            // 0x0167DA98: SUB sp, sp, #0x10          | SP = (1152921513484290032 - 16) = 1152921513484290016 (0x10000002112307E0);
            // 0x0167DA9C: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x0167DAA0: LDRB w8, [x19, #0xa9]      | W8 = (bool)static_value_037380A9;       
            // 0x0167DAA4: MOV x20, x0                | X20 = 1152921513484302112 (0x1000000211233720);//ML01
            // 0x0167DAA8: TBNZ w8, #0, #0x167dac4    | if (static_value_037380A9 == true) goto label_0;
            // 0x0167DAAC: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
            // 0x0167DAB0: LDR x8, [x8, #0x1b8]       | X8 = 0x2B8AC30;                         
            // 0x0167DAB4: LDR w0, [x8]               | W0 = 0x1CA;                             
            // 0x0167DAB8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1CA, ????);      
            // 0x0167DABC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0167DAC0: STRB w8, [x19, #0xa9]      | static_value_037380A9 = true;            //  dest_result_addr=57901225
            label_0:
            // 0x0167DAC4: LDR x19, [x20, #0x48]      | X19 = this.lockObject; //P2             
            // 0x0167DAC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167DACC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167DAD0: MOV x1, x19                | X1 = this.lockObject;//m1               
            // 0x0167DAD4: BL #0x1b557bc              | System.Threading.Monitor.Enter(obj:  0);
            System.Threading.Monitor.Enter(obj:  0);
            // 0x0167DAD8: ADRP x24, #0x362c000       | X24 = 56803328 (0x362C000);             
            // 0x0167DADC: LDR x24, [x24, #0xe80]     | X24 = 1152921504837996544;              
            // 0x0167DAE0: LDR x0, [x24]              | X0 = typeof(AstarPath);                 
            val_4 = null;
            // 0x0167DAE4: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
            // 0x0167DAE8: TBZ w8, #0, #0x167dafc     | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0167DAEC: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
            // 0x0167DAF0: CBNZ w8, #0x167dafc        | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0167DAF4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
            // 0x0167DAF8: LDR x0, [x24]              | X0 = typeof(AstarPath);                 
            val_4 = null;
            label_2:
            // 0x0167DAFC: ADRP x9, #0x362f000        | X9 = 56815616 (0x362F000);              
            // 0x0167DB00: ADRP x25, #0x35fa000       | X25 = 56598528 (0x35FA000);             
            // 0x0167DB04: LDR x8, [x0, #0xa0]        | X8 = AstarPath.__il2cppRuntimeField_static_fields;
            // 0x0167DB08: LDR x9, [x9, #0x4d0]       | X9 = 1152921513484140512;               
            // 0x0167DB0C: LDR x25, [x25, #0x288]     | X25 = 1152921504836718592;              
            // 0x0167DB10: LDR x21, [x8, #0x40]       | X21 = AstarPath.OnPathPreSearch;        
            // 0x0167DB14: LDR x23, [x9]              | X23 = System.Void Pathfinding.AlternativePath::ClearOnDestroy(Pathfinding.Path p);
            // 0x0167DB18: LDR x0, [x25]              | X0 = typeof(OnPathDelegate);            
            // 0x0167DB1C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(OnPathDelegate), ????);
            // 0x0167DB20: MOV x22, x0                | X22 = 1152921504836718592 (0x100000000DB39000);//ML01
            // 0x0167DB24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0167DB28: MOV x0, x22                | X0 = 1152921504836718592 (0x100000000DB39000);//ML01
            OnPathDelegate val_1 = null;
            // 0x0167DB2C: MOV x1, x20                | X1 = 1152921513484302112 (0x1000000211233720);//ML01
            // 0x0167DB30: MOV x2, x23                | X2 = 1152921513484140512 (0x100000021120BFE0);//ML01
            // 0x0167DB34: BL #0xd1b25c               | .ctor(object:  this, method:  System.Void Pathfinding.AlternativePath::ClearOnDestroy(Pathfinding.Path p));
            val_1 = new OnPathDelegate(object:  this, method:  System.Void Pathfinding.AlternativePath::ClearOnDestroy(Pathfinding.Path p));
            // 0x0167DB38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167DB3C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0167DB40: MOV x1, x21                | X1 = AstarPath.OnPathPreSearch;//m1     
            // 0x0167DB44: MOV x2, x22                | X2 = 1152921504836718592 (0x100000000DB39000);//ML01
            // 0x0167DB48: BL #0x1c34dc4              | X0 = System.Delegate.Remove(source:  0, value:  AstarPath.OnPathPreSearch);
            System.Delegate val_2 = System.Delegate.Remove(source:  0, value:  AstarPath.OnPathPreSearch);
            // 0x0167DB4C: LDR x8, [x24]              | X8 = typeof(AstarPath);                 
            // 0x0167DB50: LDR x21, [x8, #0xa0]       | X21 = AstarPath.__il2cppRuntimeField_static_fields;
            // 0x0167DB54: CBZ x0, #0x167db8c         | if (val_2 == null) goto label_3;        
            if(val_2 == null)
            {
                goto label_3;
            }
            // 0x0167DB58: LDR x1, [x25]              | X1 = typeof(OnPathDelegate);            
            // 0x0167DB5C: LDR x8, [x0]               | X8 = typeof(System.Delegate);           
            // 0x0167DB60: CMP x8, x1                 | STATE = COMPARE(typeof(System.Delegate), typeof(OnPathDelegate))
            // 0x0167DB64: B.EQ #0x167db90            | if (typeof(System.Delegate) == null) goto label_4;
            if(null == null)
            {
                goto label_4;
            }
            // 0x0167DB68: LDR x0, [x8, #0x30]        | X0 = System.Delegate.__il2cppRuntimeField_element_class;
            // 0x0167DB6C: ADD x8, sp, #8             | X8 = (1152921513484290016 + 8) = 1152921513484290024 (0x10000002112307E8);
            // 0x0167DB70: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Delegate.__il2cppRuntimeField_element_class, ????);
            // 0x0167DB74: LDR x0, [sp, #8]           | X0 = val_3;                              //  find_add[1152921513484278112]
            // 0x0167DB78: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
            // 0x0167DB7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167DB80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            // 0x0167DB84: ADD x0, sp, #8             | X0 = (1152921513484290016 + 8) = 1152921513484290024 (0x10000002112307E8);
            // 0x0167DB88: BL #0x299a140              | 
            label_3:
            // 0x0167DB8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_5 = 0;
            label_4:
            // 0x0167DB90: STR x0, [x21, #0x40]       | AstarPath.OnPathPreSearch = null;        //  dest_result_addr=1152921504838000704
            AstarPath.OnPathPreSearch = val_5;
            // 0x0167DB94: STRB wzr, [x20, #0x40]     | this.waitingForApply = false;            //  dest_result_addr=1152921513484302176
            this.waitingForApply = false;
            // 0x0167DB98: MOV x0, x20                | X0 = 1152921513484302112 (0x1000000211233720);//ML01
            // 0x0167DB9C: BL #0x167dc28              | this.InversePrevious();                 
            this.InversePrevious();
            // 0x0167DBA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167DBA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167DBA8: MOV x1, x19                | X1 = this.lockObject;//m1               
            // 0x0167DBAC: BL #0x1b557c4              | System.Threading.Monitor.Exit(obj:  0); 
            System.Threading.Monitor.Exit(obj:  0);
            // 0x0167DBB0: SUB sp, x29, #0x40         | SP = (1152921513484290096 - 64) = 1152921513484290032 (0x10000002112307F0);
            // 0x0167DBB4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0167DBB8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0167DBBC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0167DBC0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0167DBC4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0167DBC8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0167DC28 (23583784), len: 532  VirtAddr: 0x0167DC28 RVA: 0x0167DC28 token: 100683447 methodIndex: 49748 delegateWrapperIndex: 0 methodInvoker: 0
        private void InversePrevious()
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            // 0x0167DC28: STP x26, x25, [sp, #-0x50]! | stack[1152921513484615312] = ???;  stack[1152921513484615320] = ???;  //  dest_result_addr=1152921513484615312 |  dest_result_addr=1152921513484615320
            // 0x0167DC2C: STP x24, x23, [sp, #0x10]  | stack[1152921513484615328] = ???;  stack[1152921513484615336] = ???;  //  dest_result_addr=1152921513484615328 |  dest_result_addr=1152921513484615336
            // 0x0167DC30: STP x22, x21, [sp, #0x20]  | stack[1152921513484615344] = ???;  stack[1152921513484615352] = ???;  //  dest_result_addr=1152921513484615344 |  dest_result_addr=1152921513484615352
            // 0x0167DC34: STP x20, x19, [sp, #0x30]  | stack[1152921513484615360] = ???;  stack[1152921513484615368] = ???;  //  dest_result_addr=1152921513484615360 |  dest_result_addr=1152921513484615368
            // 0x0167DC38: STP x29, x30, [sp, #0x40]  | stack[1152921513484615376] = ???;  stack[1152921513484615384] = ???;  //  dest_result_addr=1152921513484615376 |  dest_result_addr=1152921513484615384
            // 0x0167DC3C: ADD x29, sp, #0x40         | X29 = (1152921513484615312 + 64) = 1152921513484615376 (0x100000021127FED0);
            // 0x0167DC40: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x0167DC44: LDRB w8, [x20, #0xaa]      | W8 = (bool)static_value_037380AA;       
            // 0x0167DC48: MOV x19, x0                | X19 = 1152921513484627392 (0x1000000211282DC0);//ML01
            // 0x0167DC4C: TBNZ w8, #0, #0x167dc68    | if (static_value_037380AA == true) goto label_0;
            // 0x0167DC50: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
            // 0x0167DC54: LDR x8, [x8, #0x488]       | X8 = 0x2B8AC34;                         
            // 0x0167DC58: LDR w0, [x8]               | W0 = 0x1CB;                             
            // 0x0167DC5C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1CB, ????);      
            // 0x0167DC60: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0167DC64: STRB w8, [x20, #0xaa]      | static_value_037380AA = true;            //  dest_result_addr=57901226
            label_0:
            // 0x0167DC68: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
            // 0x0167DC6C: LDR w21, [x19, #0x38]      | W21 = this.prevSeed; //P2               
            // 0x0167DC70: LDR x8, [x8, #0x618]       | X8 = 1152921504655994880;               
            // 0x0167DC74: LDR x0, [x8]               | X0 = typeof(System.Random);             
            System.Random val_1 = null;
            // 0x0167DC78: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Random), ????);
            // 0x0167DC7C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167DC80: MOV w1, w21                | W1 = this.prevSeed;//m1                 
            // 0x0167DC84: MOV x20, x0                | X20 = 1152921504655994880 (0x1000000002EDF000);//ML01
            // 0x0167DC88: BL #0x17098cc              | .ctor(Seed:  this.prevSeed);            
            val_1 = new System.Random(Seed:  this.prevSeed);
            // 0x0167DC8C: LDR x8, [x19, #0x30]       | X8 = this.prevNodes; //P2               
            // 0x0167DC90: STR x20, [x19, #0x50]      | this.rnd = typeof(System.Random);        //  dest_result_addr=1152921513484627472
            this.rnd = val_1;
            // 0x0167DC94: CBZ x8, #0x167de24         | if (this.prevNodes == null) goto label_17;
            if(this.prevNodes == null)
            {
                goto label_17;
            }
            // 0x0167DC98: LDR w21, [x19, #0x28]      | W21 = this.randomStep; //P2             
            // 0x0167DC9C: CBNZ x20, #0x167dca4       | if ( != 0) goto label_2;                
            if(null != 0)
            {
                goto label_2;
            }
            // 0x0167DCA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(Seed:  this.prevSeed), ????);
            label_2:
            // 0x0167DCA4: LDR x8, [x20]              | X8 = ;                                  
            // 0x0167DCA8: MOV x0, x20                | X0 = 1152921504655994880 (0x1000000002EDF000);//ML01
            // 0x0167DCAC: MOV w1, w21                | W1 = this.randomStep;//m1               
            // 0x0167DCB0: LDP x9, x2, [x8, #0x170]   |                                          //  not_find_field!1:368 |  not_find_field!1:376
            // 0x0167DCB4: BLR x9                     | X0 = mem[null + 368]();                 
            // 0x0167DCB8: MOV w20, w0                | W20 = 1152921504655994880 (0x1000000002EDF000);//ML01
            val_4 = val_1;
            // 0x0167DCBC: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            var val_7 = 0;
            // 0x0167DCC0: B #0x167dce0               |  goto label_3;                          
            goto label_3;
            label_16:
            // 0x0167DCC4: LDR x8, [x21]              | X8 = this.randomStep;                   
            // 0x0167DCC8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x0167DCCC: MOV x0, x21                | X0 = this.randomStep;//m1               
            // 0x0167DCD0: MOV w2, w22                | W2 = W22;//m1                           
            // 0x0167DCD4: LDP x9, x3, [x8, #0x180]   | X9 = this.randomStep + 384; X3 = this.randomStep + 384 + 8; //  | 
            // 0x0167DCD8: BLR x9                     | X0 = this.randomStep + 384();           
            // 0x0167DCDC: ADD w20, w0, w20           | W20 = (this.randomStep + val_4);        
            val_4 = this.randomStep + val_4;
            label_3:
            // 0x0167DCE0: LDR x21, [x19, #0x30]      | X21 = this.prevNodes; //P2              
            // 0x0167DCE4: CBNZ x21, #0x167dcec       | if (this.prevNodes != null) goto label_4;
            if(this.prevNodes != null)
            {
                goto label_4;
            }
            // 0x0167DCE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.randomStep, ????);
            label_4:
            // 0x0167DCEC: LDR w8, [x21, #0x18]       | W8 = this.prevNodes.Length; //P2        
            // 0x0167DCF0: CMP w20, w8                | STATE = COMPARE((this.randomStep + val_4), this.prevNodes.Length)
            // 0x0167DCF4: B.GE #0x167ddd4            | if (val_4 >= this.prevNodes.Length) goto label_5;
            if(val_4 >= this.prevNodes.Length)
            {
                goto label_5;
            }
            // 0x0167DCF8: LDR x21, [x19, #0x30]      | X21 = this.prevNodes; //P2              
            // 0x0167DCFC: CBNZ x21, #0x167dd04       | if (this.prevNodes != null) goto label_6;
            if(this.prevNodes != null)
            {
                goto label_6;
            }
            // 0x0167DD00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.randomStep, ????);
            label_6:
            // 0x0167DD04: LDR w8, [x21, #0x18]       | W8 = this.prevNodes.Length; //P2        
            // 0x0167DD08: SXTW x22, w20              | X22 = (long)(int)((this.randomStep + val_4));
            // 0x0167DD0C: CMP w20, w8                | STATE = COMPARE((this.randomStep + val_4), this.prevNodes.Length)
            // 0x0167DD10: B.LO #0x167dd20            | if (val_4 < this.prevNodes.Length) goto label_7;
            if(val_4 < this.prevNodes.Length)
            {
                goto label_7;
            }
            // 0x0167DD14: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.randomStep, ????);
            // 0x0167DD18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167DD1C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.randomStep, ????);
            label_7:
            // 0x0167DD20: ADD x8, x21, x22, lsl #3   | X8 = this.prevNodes[(long)(int)((this.randomStep + val_4))]; //PARR1 
            // 0x0167DD24: LDR x21, [x8, #0x20]       | X21 = this.prevNodes[(long)(int)((this.randomStep + val_4))][0]
            Pathfinding.GraphNode val_4 = this.prevNodes[(long)val_4];
            // 0x0167DD28: CBNZ x21, #0x167dd30       | if (this.prevNodes[(long)(int)((this.randomStep + val_4))][0] != null) goto label_8;
            if(val_4 != null)
            {
                goto label_8;
            }
            // 0x0167DD2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.randomStep, ????);
            label_8:
            // 0x0167DD30: LDR w8, [x21, #0x18]       | W8 = this.prevNodes[(long)(int)((this.randomStep + val_4))][0].penalty; //P2 
            // 0x0167DD34: LDRSW x9, [x19, #0x3c]     | X9 = this.prevPenalty; //P2             
            // 0x0167DD38: LDR x21, [x19, #0x30]      | X21 = this.prevNodes; //P2              
            // 0x0167DD3C: CMP x8, x9                 | STATE = COMPARE(this.prevNodes[(long)(int)((this.randomStep + val_4))][0].penalty, this.prevPenalty)
            // 0x0167DD40: CSET w24, lt               | W24 = this.prevNodes[(long)(int)((this.randomStep + val_4))][0].penalty < this.prevPenalty ? 1 : 0;
            var val_2 = ((this.prevNodes[(long)(int)((this.randomStep + val_4))][0].penalty) < this.prevPenalty) ? 1 : 0;
            // 0x0167DD44: CBNZ x21, #0x167dd4c       | if (this.prevNodes != null) goto label_9;
            if(this.prevNodes != null)
            {
                goto label_9;
            }
            // 0x0167DD48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.randomStep, ????);
            label_9:
            // 0x0167DD4C: LDR w8, [x21, #0x18]       | W8 = this.prevNodes.Length; //P2        
            // 0x0167DD50: CMP w20, w8                | STATE = COMPARE((this.randomStep + val_4), this.prevNodes.Length)
            // 0x0167DD54: B.LO #0x167dd64            | if (val_4 < this.prevNodes.Length) goto label_10;
            if(val_4 < this.prevNodes.Length)
            {
                goto label_10;
            }
            // 0x0167DD58: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.randomStep, ????);
            // 0x0167DD5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167DD60: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.randomStep, ????);
            label_10:
            // 0x0167DD64: ADD x8, x21, x22, lsl #3   | X8 = this.prevNodes[(long)(int)((this.randomStep + val_4))]; //PARR1 
            // 0x0167DD68: LDR x21, [x8, #0x20]       | X21 = this.prevNodes[(long)(int)((this.randomStep + val_4))][0]
            Pathfinding.GraphNode val_5 = this.prevNodes[(long)val_4];
            // 0x0167DD6C: LDR x25, [x19, #0x30]      | X25 = this.prevNodes; //P2              
            // 0x0167DD70: CBNZ x25, #0x167dd78       | if (this.prevNodes != null) goto label_11;
            if(this.prevNodes != null)
            {
                goto label_11;
            }
            // 0x0167DD74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.randomStep, ????);
            label_11:
            // 0x0167DD78: LDR w8, [x25, #0x18]       | W8 = this.prevNodes.Length; //P2        
            // 0x0167DD7C: CMP w20, w8                | STATE = COMPARE((this.randomStep + val_4), this.prevNodes.Length)
            // 0x0167DD80: B.LO #0x167dd90            | if (val_4 < this.prevNodes.Length) goto label_12;
            if(val_4 < this.prevNodes.Length)
            {
                goto label_12;
            }
            // 0x0167DD84: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.randomStep, ????);
            // 0x0167DD88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167DD8C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.randomStep, ????);
            label_12:
            // 0x0167DD90: ADD x8, x25, x22, lsl #3   | X8 = this.prevNodes[(long)(int)((this.randomStep + val_4))]; //PARR1 
            // 0x0167DD94: LDR x22, [x8, #0x20]       | X22 = this.prevNodes[(long)(int)((this.randomStep + val_4))][0]
            Pathfinding.GraphNode val_6 = this.prevNodes[(long)val_4];
            // 0x0167DD98: CBNZ x22, #0x167dda0       | if (this.prevNodes[(long)(int)((this.randomStep + val_4))][0] != null) goto label_13;
            if(val_6 != null)
            {
                goto label_13;
            }
            // 0x0167DD9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.randomStep, ????);
            label_13:
            // 0x0167DDA0: LDR w22, [x22, #0x18]      | W22 = this.prevNodes[(long)(int)((this.randomStep + val_4))][0].penalty; //P2 
            // 0x0167DDA4: LDR w25, [x19, #0x3c]      | W25 = this.prevPenalty; //P2            
            // 0x0167DDA8: CBNZ x21, #0x167ddb0       | if (this.prevNodes[(long)(int)((this.randomStep + val_4))][0] != null) goto label_14;
            if(val_5 != null)
            {
                goto label_14;
            }
            // 0x0167DDAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.randomStep, ????);
            label_14:
            // 0x0167DDB0: SUB w1, w22, w25           | W1 = (this.prevNodes[(long)(int)((this.randomStep + val_4))][0].penalty - this.prevPenalty);
            uint val_3 = (this.prevNodes[(long)(int)((this.randomStep + val_4))][0].penalty) - this.prevPenalty;
            // 0x0167DDB4: MOV x0, x21                | X0 = this.prevNodes[(long)(int)((this.randomStep + val_4))][0];//m1
            // 0x0167DDB8: ORR w23, w23, w24          | W23 = (0 | this.prevNodes[(long)(int)((this.randomStep + val_4))][0].penalty < this.prevPenalty ? 1 
            val_7 = val_7 | val_2;
            // 0x0167DDBC: BL #0x167de44              | this.prevNodes[(long)(int)((this.randomStep + val_4))][0].set_Penalty(value:  uint val_3 = (this.prevNodes[(long)(int)((this.randomStep + val_4))][0].penalty) - this.prevPenalty);
            val_5.Penalty = val_3;
            // 0x0167DDC0: LDR x21, [x19, #0x50]      | X21 = this.rnd; //P2                    
            // 0x0167DDC4: LDR w22, [x19, #0x28]      | W22 = this.randomStep; //P2             
            // 0x0167DDC8: CBNZ x21, #0x167dcc4       | if (this.rnd != null) goto label_16;    
            if(this.rnd != null)
            {
                goto label_16;
            }
            // 0x0167DDCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.prevNodes[(long)(int)((this.randomStep + val_4))][0], ????);
            // 0x0167DDD0: B #0x167dcc4               |  goto label_16;                         
            goto label_16;
            label_5:
            // 0x0167DDD4: TBZ w23, #0, #0x167de24    | if ((0x0 & 0x1) == 0) goto label_17;    
            if((val_7 & 1) == 0)
            {
                goto label_17;
            }
            // 0x0167DDD8: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x0167DDDC: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
            // 0x0167DDE0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Debug);         
            // 0x0167DDE4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x0167DDE8: TBZ w8, #0, #0x167ddf8     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_19;
            // 0x0167DDEC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x0167DDF0: CBNZ w8, #0x167ddf8        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
            // 0x0167DDF4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_19:
            // 0x0167DDF8: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x0167DDFC: LDR x8, [x8, #0xc90]       | X8 = (string**)(1152921513484603104)("Penalty for some nodes has been reset while this modifier was active. Penalties might not be correctly set.");
            // 0x0167DE00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167DE04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167DE08: LDR x1, [x8]               | X1 = "Penalty for some nodes has been reset while this modifier was active. Penalties might not be correctly set.";
            // 0x0167DE0C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0167DE10: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0167DE14: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0167DE18: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0167DE1C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0167DE20: B #0x1a5dba0               | UnityEngine.Debug.LogWarning(message:  0); return;
            UnityEngine.Debug.LogWarning(message:  0);
            return;
            label_17:
            // 0x0167DE24: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0167DE28: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0167DE2C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0167DE30: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0167DE34: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0167DE38: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0167DF38 (23584568), len: 772  VirtAddr: 0x0167DF38 RVA: 0x0167DF38 token: 100683448 methodIndex: 49749 delegateWrapperIndex: 0 methodInvoker: 0
        private void ApplyNow(Pathfinding.Path somePath)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            //  | 
            var val_6;
            //  | 
            IntPtr val_7;
            //  | 
            System.Delegate val_8;
            //  | 
            OnPathDelegate val_9;
            //  | 
            int val_10;
            //  | 
            Pathfinding.GraphNode[] val_11;
            //  | 
            var val_12;
            // 0x0167DF38: STP x26, x25, [sp, #-0x50]! | stack[1152921513485141008] = ???;  stack[1152921513485141016] = ???;  //  dest_result_addr=1152921513485141008 |  dest_result_addr=1152921513485141016
            // 0x0167DF3C: STP x24, x23, [sp, #0x10]  | stack[1152921513485141024] = ???;  stack[1152921513485141032] = ???;  //  dest_result_addr=1152921513485141024 |  dest_result_addr=1152921513485141032
            // 0x0167DF40: STP x22, x21, [sp, #0x20]  | stack[1152921513485141040] = ???;  stack[1152921513485141048] = ???;  //  dest_result_addr=1152921513485141040 |  dest_result_addr=1152921513485141048
            // 0x0167DF44: STP x20, x19, [sp, #0x30]  | stack[1152921513485141056] = ???;  stack[1152921513485141064] = ???;  //  dest_result_addr=1152921513485141056 |  dest_result_addr=1152921513485141064
            // 0x0167DF48: STP x29, x30, [sp, #0x40]  | stack[1152921513485141072] = ???;  stack[1152921513485141080] = ???;  //  dest_result_addr=1152921513485141072 |  dest_result_addr=1152921513485141080
            // 0x0167DF4C: ADD x29, sp, #0x40         | X29 = (1152921513485141008 + 64) = 1152921513485141072 (0x1000000211300450);
            // 0x0167DF50: SUB sp, sp, #0x10          | SP = (1152921513485141008 - 16) = 1152921513485140992 (0x1000000211300400);
            // 0x0167DF54: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x0167DF58: LDRB w8, [x19, #0xab]      | W8 = (bool)static_value_037380AB;       
            // 0x0167DF5C: MOV x20, x0                | X20 = 1152921513485153088 (0x1000000211303340);//ML01
            // 0x0167DF60: TBNZ w8, #0, #0x167df7c    | if (static_value_037380AB == true) goto label_0;
            // 0x0167DF64: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x0167DF68: LDR x8, [x8, #0x430]       | X8 = 0x2B8AC2C;                         
            // 0x0167DF6C: LDR w0, [x8]               | W0 = 0x1C9;                             
            // 0x0167DF70: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C9, ????);      
            // 0x0167DF74: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0167DF78: STRB w8, [x19, #0xab]      | static_value_037380AB = true;            //  dest_result_addr=57901227
            label_0:
            // 0x0167DF7C: LDR x19, [x20, #0x48]      | X19 = this.lockObject; //P2             
            // 0x0167DF80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167DF84: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167DF88: MOV x1, x19                | X1 = this.lockObject;//m1               
            // 0x0167DF8C: BL #0x1b557bc              | System.Threading.Monitor.Enter(obj:  0);
            System.Threading.Monitor.Enter(obj:  0);
            // 0x0167DF90: STRB wzr, [x20, #0x40]     | this.waitingForApply = false;            //  dest_result_addr=1152921513485153152
            this.waitingForApply = false;
            // 0x0167DF94: ADRP x24, #0x362c000       | X24 = 56803328 (0x362C000);             
            // 0x0167DF98: LDR x24, [x24, #0xe80]     | X24 = 1152921504837996544;              
            // 0x0167DF9C: LDR x0, [x24]              | X0 = typeof(AstarPath);                 
            val_6 = null;
            // 0x0167DFA0: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
            // 0x0167DFA4: TBZ w8, #0, #0x167dfb8     | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0167DFA8: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
            // 0x0167DFAC: CBNZ w8, #0x167dfb8        | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0167DFB0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
            // 0x0167DFB4: LDR x0, [x24]              | X0 = typeof(AstarPath);                 
            val_6 = null;
            label_2:
            // 0x0167DFB8: ADRP x9, #0x3654000        | X9 = 56967168 (0x3654000);              
            // 0x0167DFBC: ADRP x25, #0x35fa000       | X25 = 56598528 (0x35FA000);             
            // 0x0167DFC0: LDR x8, [x0, #0xa0]        | X8 = AstarPath.__il2cppRuntimeField_static_fields;
            // 0x0167DFC4: LDR x9, [x9, #0xe50]       | X9 = 1152921513483961952;               
            // 0x0167DFC8: LDR x25, [x25, #0x288]     | X25 = 1152921504836718592;              
            // 0x0167DFCC: LDR x21, [x8, #0x40]       | X21 = AstarPath.OnPathPreSearch;        
            // 0x0167DFD0: LDR x23, [x9]              | X23 = System.Void Pathfinding.AlternativePath::ApplyNow(Pathfinding.Path somePath);
            val_7 = System.Void Pathfinding.AlternativePath::ApplyNow(Pathfinding.Path somePath);
            // 0x0167DFD4: LDR x0, [x25]              | X0 = typeof(OnPathDelegate);            
            // 0x0167DFD8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(OnPathDelegate), ????);
            // 0x0167DFDC: MOV x22, x0                | X22 = 1152921504836718592 (0x100000000DB39000);//ML01
            // 0x0167DFE0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0167DFE4: MOV x0, x22                | X0 = 1152921504836718592 (0x100000000DB39000);//ML01
            OnPathDelegate val_1 = null;
            // 0x0167DFE8: MOV x1, x20                | X1 = 1152921513485153088 (0x1000000211303340);//ML01
            // 0x0167DFEC: MOV x2, x23                | X2 = 1152921513483961952 (0x10000002111E0660);//ML01
            // 0x0167DFF0: BL #0xd1b25c               | .ctor(object:  this, method:  val_7);   
            val_1 = new OnPathDelegate(object:  this, method:  val_7);
            // 0x0167DFF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167DFF8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0167DFFC: MOV x1, x21                | X1 = AstarPath.OnPathPreSearch;//m1     
            val_8 = AstarPath.OnPathPreSearch;
            // 0x0167E000: MOV x2, x22                | X2 = 1152921504836718592 (0x100000000DB39000);//ML01
            // 0x0167E004: BL #0x1c34dc4              | X0 = System.Delegate.Remove(source:  0, value:  val_8 = AstarPath.OnPathPreSearch);
            System.Delegate val_2 = System.Delegate.Remove(source:  0, value:  val_8);
            // 0x0167E008: LDR x8, [x24]              | X8 = typeof(AstarPath);                 
            // 0x0167E00C: LDR x21, [x8, #0xa0]       | X21 = AstarPath.__il2cppRuntimeField_static_fields;
            // 0x0167E010: CBZ x0, #0x167e048         | if (val_2 == null) goto label_3;        
            if(val_2 == null)
            {
                goto label_3;
            }
            // 0x0167E014: LDR x1, [x25]              | X1 = typeof(OnPathDelegate);            
            val_8 = null;
            // 0x0167E018: LDR x8, [x0]               | X8 = typeof(System.Delegate);           
            // 0x0167E01C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Delegate), typeof(OnPathDelegate))
            // 0x0167E020: B.EQ #0x167e04c            | if (typeof(System.Delegate) == val_8) goto label_4;
            if(null == val_8)
            {
                goto label_4;
            }
            // 0x0167E024: LDR x0, [x8, #0x30]        | X0 = System.Delegate.__il2cppRuntimeField_element_class;
            // 0x0167E028: ADD x8, sp, #8             | X8 = (1152921513485140992 + 8) = 1152921513485141000 (0x1000000211300408);
            // 0x0167E02C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Delegate.__il2cppRuntimeField_element_class, ????);
            // 0x0167E030: LDR x0, [sp, #8]           | X0 = val_3;                              //  find_add[1152921513485129088]
            // 0x0167E034: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
            // 0x0167E038: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_8 = 0;
            // 0x0167E03C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            // 0x0167E040: ADD x0, sp, #8             | X0 = (1152921513485140992 + 8) = 1152921513485141000 (0x1000000211300408);
            // 0x0167E044: BL #0x299a140              | 
            label_3:
            // 0x0167E048: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_9 = 0;
            label_4:
            // 0x0167E04C: STR x0, [x21, #0x40]       | AstarPath.OnPathPreSearch = null;        //  dest_result_addr=1152921504838000704
            AstarPath.OnPathPreSearch = val_9;
            // 0x0167E050: MOV x0, x20                | X0 = 1152921513485153088 (0x1000000211303340);//ML01
            // 0x0167E054: BL #0x167dc28              | this.InversePrevious();                 
            this.InversePrevious();
            // 0x0167E058: LDRB w8, [x20, #0x60]      | W8 = this.destroyed; //P2               
            // 0x0167E05C: CBNZ w8, #0x167e1f8        | if (this.destroyed == true) goto label_5;
            if(this.destroyed == true)
            {
                goto label_5;
            }
            // 0x0167E060: LDR x21, [x20, #0x58]      | X21 = this.seedGenerator; //P2          
            // 0x0167E064: CBNZ x21, #0x167e06c       | if (this.seedGenerator != null) goto label_6;
            if(this.seedGenerator != null)
            {
                goto label_6;
            }
            // 0x0167E068: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_6:
            // 0x0167E06C: LDR x8, [x21]              | X8 = typeof(System.Random);             
            // 0x0167E070: LDP x9, x1, [x8, #0x160]   | X9 = typeof(System.Random).__il2cppRuntimeField_160; X1 = typeof(System.Random).__il2cppRuntimeField_168; //  | 
            // 0x0167E074: MOV x0, x21                | X0 = this.seedGenerator;//m1            
            // 0x0167E078: BLR x9                     | X0 = typeof(System.Random).__il2cppRuntimeField_160();
            // 0x0167E07C: MOV w21, w0                | W21 = this.seedGenerator;//m1           
            val_10 = this.seedGenerator;
            // 0x0167E080: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
            // 0x0167E084: LDR x8, [x8, #0x618]       | X8 = 1152921504655994880;               
            // 0x0167E088: LDR x0, [x8]               | X0 = typeof(System.Random);             
            // 0x0167E08C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Random), ????);
            // 0x0167E090: MOV x22, x0                | X22 = 1152921504655994880 (0x1000000002EDF000);//ML01
            // 0x0167E094: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167E098: MOV x0, x22                | X0 = 1152921504655994880 (0x1000000002EDF000);//ML01
            System.Random val_4 = null;
            // 0x0167E09C: MOV w1, w21                | W1 = this.seedGenerator;//m1            
            // 0x0167E0A0: BL #0x17098cc              | .ctor(Seed:  val_10);                   
            val_4 = new System.Random(Seed:  val_10);
            // 0x0167E0A4: LDR x8, [x20, #0x68]       | X8 = this.toBeApplied; //P2             
            val_11 = this.toBeApplied;
            // 0x0167E0A8: STR x22, [x20, #0x50]      | this.rnd = typeof(System.Random);        //  dest_result_addr=1152921513485153168
            this.rnd = null;
            // 0x0167E0AC: CBZ x8, #0x167e1ec         | if (this.toBeApplied == null) goto label_7;
            if(val_11 == null)
            {
                goto label_7;
            }
            // 0x0167E0B0: LDR w23, [x20, #0x28]      | W23 = this.randomStep; //P2             
            // 0x0167E0B4: CBNZ x22, #0x167e0bc       | if ( != 0) goto label_8;                
            if(null != 0)
            {
                goto label_8;
            }
            // 0x0167E0B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(Seed:  val_10), ????);
            label_8:
            // 0x0167E0BC: LDR x8, [x22]              | X8 = ;                                  
            // 0x0167E0C0: LDP x9, x2, [x8, #0x170]   |                                          //  not_find_field!1:368 |  not_find_field!1:376
            // 0x0167E0C4: MOV x0, x22                | X0 = 1152921504655994880 (0x1000000002EDF000);//ML01
            // 0x0167E0C8: MOV w1, w23                | W1 = this.randomStep;//m1               
            // 0x0167E0CC: BLR x9                     | X0 = mem[null + 368]();                 
            // 0x0167E0D0: MOV w22, w0                | W22 = 1152921504655994880 (0x1000000002EDF000);//ML01
            val_12 = null;
            // 0x0167E0D4: B #0x167e0e0               |  goto label_9;                          
            goto label_9;
            // 0x0167E0D8: B #0x167e1a4               |  goto label_10;                         
            goto label_10;
            label_20:
            // 0x0167E0DC: ADD w22, w0, w22           | W22 = (null + val_12) = val_12 (0x2000000005DBE000);
            val_12 = 2305843009311989760;
            label_9:
            // 0x0167E0E0: LDR x23, [x20, #0x68]      | X23 = this.toBeApplied; //P2            
            val_7 = this.toBeApplied;
            // 0x0167E0E4: CBNZ x23, #0x167e0ec       | if (this.toBeApplied != null) goto label_11;
            if(val_7 != null)
            {
                goto label_11;
            }
            // 0x0167E0E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Random), ????);
            label_11:
            // 0x0167E0EC: LDR w8, [x23, #0x18]       | W8 = this.toBeApplied.Length; //P2      
            // 0x0167E0F0: CMP w22, w8                | STATE = COMPARE(0x2000000005DBE000, this.toBeApplied.Length)
            // 0x0167E0F4: B.GE #0x167e1e8            | if (val_12 >= this.toBeApplied.Length) goto label_12;
            if(val_12 >= this.toBeApplied.Length)
            {
                goto label_12;
            }
            // 0x0167E0F8: LDR x23, [x20, #0x68]      | X23 = this.toBeApplied; //P2            
            // 0x0167E0FC: CBNZ x23, #0x167e104       | if (this.toBeApplied != null) goto label_13;
            if(this.toBeApplied != null)
            {
                goto label_13;
            }
            // 0x0167E100: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Random), ????);
            label_13:
            // 0x0167E104: LDR w8, [x23, #0x18]       | W8 = this.toBeApplied.Length; //P2      
            // 0x0167E108: CMP w22, w8                | STATE = COMPARE(0x2000000005DBE000, this.toBeApplied.Length)
            // 0x0167E10C: B.LO #0x167e11c            | if (val_12 < this.toBeApplied.Length) goto label_14;
            if(val_12 < this.toBeApplied.Length)
            {
                goto label_14;
            }
            // 0x0167E110: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Random), ????);
            // 0x0167E114: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E118: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Random), ????);
            label_14:
            // 0x0167E11C: SXTW x24, w22              | X24 = 98295808 (0x05DBE000);            
            // 0x0167E120: ADD x8, x23, x24, lsl #3   | X8 = this.toBeApplied[0x5DBE000]; //PARR1 
            // 0x0167E124: LDR x23, [x8, #0x20]       | X23 = this.toBeApplied[0x5DBE000][0]    
            Pathfinding.GraphNode val_6 = this.toBeApplied[98295808];
            // 0x0167E128: LDR x25, [x20, #0x68]      | X25 = this.toBeApplied; //P2            
            // 0x0167E12C: CBNZ x25, #0x167e134       | if (this.toBeApplied != null) goto label_15;
            if(this.toBeApplied != null)
            {
                goto label_15;
            }
            // 0x0167E130: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Random), ????);
            label_15:
            // 0x0167E134: LDR w8, [x25, #0x18]       | W8 = this.toBeApplied.Length; //P2      
            // 0x0167E138: CMP w22, w8                | STATE = COMPARE(0x2000000005DBE000, this.toBeApplied.Length)
            // 0x0167E13C: B.LO #0x167e14c            | if (val_12 < this.toBeApplied.Length) goto label_16;
            if(val_12 < this.toBeApplied.Length)
            {
                goto label_16;
            }
            // 0x0167E140: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Random), ????);
            // 0x0167E144: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E148: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Random), ????);
            label_16:
            // 0x0167E14C: ADD x8, x25, x24, lsl #3   | X8 = this.toBeApplied[0x5DBE000]; //PARR1 
            // 0x0167E150: LDR x24, [x8, #0x20]       | X24 = this.toBeApplied[0x5DBE000][0]    
            Pathfinding.GraphNode val_7 = this.toBeApplied[98295808];
            // 0x0167E154: CBNZ x24, #0x167e15c       | if (this.toBeApplied[0x5DBE000][0] != null) goto label_17;
            if(val_7 != null)
            {
                goto label_17;
            }
            // 0x0167E158: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Random), ????);
            label_17:
            // 0x0167E15C: LDR w24, [x24, #0x18]      | W24 = this.toBeApplied[0x5DBE000][0].penalty; //P2 
            // 0x0167E160: LDR w25, [x20, #0x24]      | W25 = this.penalty; //P2                
            // 0x0167E164: CBNZ x23, #0x167e16c       | if (this.toBeApplied[0x5DBE000][0] != null) goto label_18;
            if(val_6 != null)
            {
                goto label_18;
            }
            // 0x0167E168: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Random), ????);
            label_18:
            // 0x0167E16C: ADD w1, w25, w24           | W1 = (this.penalty + this.toBeApplied[0x5DBE000][0].penalty);
            int val_5 = this.penalty + this.toBeApplied[0x5DBE000][0].penalty;
            // 0x0167E170: MOV x0, x23                | X0 = this.toBeApplied[0x5DBE000][0];//m1
            // 0x0167E174: BL #0x167de44              | this.toBeApplied[0x5DBE000][0].set_Penalty(value:  int val_5 = this.penalty + this.toBeApplied[0x5DBE000][0].penalty);
            val_6.Penalty = val_5;
            // 0x0167E178: LDR x24, [x20, #0x50]      | X24 = this.rnd; //P2                    
            // 0x0167E17C: LDR w23, [x20, #0x28]      | W23 = this.randomStep; //P2             
            // 0x0167E180: CBNZ x24, #0x167e188       | if (this.rnd != null) goto label_19;    
            if(this.rnd != null)
            {
                goto label_19;
            }
            // 0x0167E184: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.toBeApplied[0x5DBE000][0], ????);
            label_19:
            // 0x0167E188: LDR x8, [x24]              | X8 = typeof(System.Random);             
            // 0x0167E18C: LDP x9, x3, [x8, #0x180]   | X9 = typeof(System.Random).__il2cppRuntimeField_180; X3 = typeof(System.Random).__il2cppRuntimeField_188; //  | 
            // 0x0167E190: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x0167E194: MOV x0, x24                | X0 = this.rnd;//m1                      
            // 0x0167E198: MOV w2, w23                | W2 = this.randomStep;//m1               
            // 0x0167E19C: BLR x9                     | X0 = typeof(System.Random).__il2cppRuntimeField_180();
            // 0x0167E1A0: B #0x167e0dc               |  goto label_20;                         
            goto label_20;
            label_10:
            // 0x0167E1A4: MOV x21, x1                | X21 = this.randomStep;//m1              
            val_10 = this.randomStep;
            // 0x0167E1A8: MOV x20, x0                | X20 = 1152921504655994880 (0x1000000002EDF000);//ML01
            label_24:
            // 0x0167E1AC: MOV x0, x20                | X0 = 1152921504655994880 (0x1000000002EDF000);//ML01
            // 0x0167E1B0: CMP w21, #1                | STATE = COMPARE(this.randomStep, 0x1)   
            // 0x0167E1B4: B.NE #0x167e238            | if (val_10 != 1) goto label_21;         
            if(val_10 != 1)
            {
                goto label_21;
            }
            // 0x0167E1B8: BL #0x981060               | X0 = sub_981060( ?? typeof(System.Random), ????);
            // 0x0167E1BC: LDR x20, [x0]              | X20 = ;                                 
            // 0x0167E1C0: BL #0x980920               | X0 = sub_980920( ?? typeof(System.Random), ????);
            // 0x0167E1C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167E1C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167E1CC: MOV x1, x19                | X1 = this.lockObject;//m1               
            // 0x0167E1D0: BL #0x1b557c4              | System.Threading.Monitor.Exit(obj:  0); 
            System.Threading.Monitor.Exit(obj:  0);
            // 0x0167E1D4: CBZ x20, #0x167e208        | if ( == 0) goto label_23;               
            if(null == 0)
            {
                goto label_23;
            }
            // 0x0167E1D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E1DC: MOV x0, x20                | X0 = X20;//m1                           
            // 0x0167E1E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? , ????);           
            // 0x0167E1E4: B #0x167e208               |  goto label_23;                         
            goto label_23;
            label_12:
            // 0x0167E1E8: LDR x8, [x20, #0x68]       | X8 = this.toBeApplied; //P2             
            val_11 = this.toBeApplied;
            label_7:
            // 0x0167E1EC: LDR w9, [x20, #0x24]       | W9 = this.penalty; //P2                 
            // 0x0167E1F0: STP w21, w9, [x20, #0x38]  | this.prevSeed = this.seedGenerator;  this.prevPenalty = this.penalty;  //  dest_result_addr=1152921513485153144 |  dest_result_addr=1152921513485153148
            this.prevSeed = val_10;
            this.prevPenalty = this.penalty;
            // 0x0167E1F4: STR x8, [x20, #0x30]       | this.prevNodes = this.toBeApplied;       //  dest_result_addr=1152921513485153136
            this.prevNodes = val_11;
            label_5:
            // 0x0167E1F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167E1FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167E200: MOV x1, x19                | X1 = this.lockObject;//m1               
            // 0x0167E204: BL #0x1b557c4              | System.Threading.Monitor.Exit(obj:  0); 
            System.Threading.Monitor.Exit(obj:  0);
            label_23:
            // 0x0167E208: SUB sp, x29, #0x40         | SP = (1152921513485141072 - 64) = 1152921513485141008 (0x1000000211300410);
            // 0x0167E20C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0167E210: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0167E214: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0167E218: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0167E21C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0167E220: RET                        |  return;                                
            return;
            // 0x0167E224: MOV x20, x0                | X20 = 0 (0x0);//ML01                    
            // 0x0167E228: ADD x0, sp, #8             | X0 = (1152921513485141088 + 8) = 1152921513485141096 (0x1000000211300468);
            // 0x0167E22C: MOV x21, x1                | X21 = this.lockObject;//m1              
            // 0x0167E230: BL #0x299a140              | 
            // 0x0167E234: B #0x167e1ac               |  goto label_24;                         
            goto label_24;
            label_21:
            // 0x0167E238: BL #0x980800               | X0 = sub_980800( ?? typeof(System.Random), ????);
        
        }
    
    }

}
