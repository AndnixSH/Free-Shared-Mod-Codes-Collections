using UnityEngine;
[ProtoBuf.ProtoContractAttribute] // 0x286D4BC
[Serializable]
public class CameraShotGameSpeedCfg : IExtensible
{
    // Fields
    private int _id; //  0x00000010
    private float _speed; //  0x00000014
    private ProtoBuf.IExtension extensionObject; //  0x00000018
    
    // Properties
    [ProtoBuf.ProtoMemberAttribute] // 0x286D500
    [System.ComponentModel.DefaultValueAttribute] // 0x286D500
    public int id { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286D580
    [System.ComponentModel.DefaultValueAttribute] // 0x286D580
    public float speed { get; set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BADD74 (12246388), len: 8  VirtAddr: 0x00BADD74 RVA: 0x00BADD74 token: 100690414 methodIndex: 25774 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraShotGameSpeedCfg()
    {
        //
        // Disasemble & Code
        // 0x00BADD74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BADD78: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADD7C (12246396), len: 8  VirtAddr: 0x00BADD7C RVA: 0x00BADD7C token: 100690415 methodIndex: 25775 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_id()
    {
        //
        // Disasemble & Code
        // 0x00BADD7C: LDR w0, [x0, #0x10]        | W0 = this._id; //P2                     
        // 0x00BADD80: RET                        |  return (System.Int32)this._id;         
        return this._id;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADD84 (12246404), len: 8  VirtAddr: 0x00BADD84 RVA: 0x00BADD84 token: 100690416 methodIndex: 25776 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_id(int value)
    {
        //
        // Disasemble & Code
        // 0x00BADD84: STR w1, [x0, #0x10]        | this._id = value;                        //  dest_result_addr=1152921514518717360
        this._id = value;
        // 0x00BADD88: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADD8C (12246412), len: 8  VirtAddr: 0x00BADD8C RVA: 0x00BADD8C token: 100690417 methodIndex: 25777 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_speed()
    {
        //
        // Disasemble & Code
        // 0x00BADD8C: LDR s0, [x0, #0x14]        | S0 = this._speed; //P2                  
        // 0x00BADD90: RET                        |  return (System.Single)this._speed;     
        return this._speed;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADD94 (12246420), len: 8  VirtAddr: 0x00BADD94 RVA: 0x00BADD94 token: 100690418 methodIndex: 25778 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_speed(float value)
    {
        //
        // Disasemble & Code
        // 0x00BADD94: STR s0, [x0, #0x14]        | this._speed = value;                     //  dest_result_addr=1152921514518941364
        this._speed = value;
        // 0x00BADD98: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADD9C (12246428), len: 24  VirtAddr: 0x00BADD9C RVA: 0x00BADD9C token: 100690419 methodIndex: 25779 delegateWrapperIndex: 0 methodInvoker: 0
    private ProtoBuf.IExtension ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
    {
        //
        // Disasemble & Code
        // 0x00BADD9C: ADD x8, x0, #0x18          | X8 = this.extensionObject;//AP2 res_addr=1152921514519053368
        // 0x00BADDA0: AND w2, w1, #1             | W2 = (createIfMissing & 1);             
        bool val_1 = createIfMissing;
        // 0x00BADDA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        ProtoBuf.IExtension val_2 = 0;
        // 0x00BADDA8: MOV x1, x8                 | X1 = this.extensionObject;//m1          
        // 0x00BADDAC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BADDB0: B #0xc7c9f0                | return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  ProtoBuf.IExtension val_2 = 0, createIfMissing:  this.extensionObject);
        return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  val_2, createIfMissing:  this.extensionObject);
    
    }

}
