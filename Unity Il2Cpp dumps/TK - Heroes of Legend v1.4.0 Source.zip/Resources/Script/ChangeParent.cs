using UnityEngine;
public class ChangeParent : MonoBehaviour
{
    // Fields
    private uint delayID; //  0x00000018
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00D820B8 (14164152), len: 8  VirtAddr: 0x00D820B8 RVA: 0x00D820B8 token: 100696563 methodIndex: 25962 delegateWrapperIndex: 0 methodInvoker: 0
    public ChangeParent()
    {
        //
        // Disasemble & Code
        // 0x00D820B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D820BC: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D820C0 (14164160), len: 188  VirtAddr: 0x00D820C0 RVA: 0x00D820C0 token: 100696564 methodIndex: 25963 delegateWrapperIndex: 0 methodInvoker: 0
    public void Init(float delayTime)
    {
        //
        // Disasemble & Code
        // 0x00D820C0: STP d9, d8, [sp, #-0x40]!  | stack[1152921515554641648] = ???;  stack[1152921515554641656] = ???;  //  dest_result_addr=1152921515554641648 |  dest_result_addr=1152921515554641656
        // 0x00D820C4: STP x22, x21, [sp, #0x10]  | stack[1152921515554641664] = ???;  stack[1152921515554641672] = ???;  //  dest_result_addr=1152921515554641664 |  dest_result_addr=1152921515554641672
        // 0x00D820C8: STP x20, x19, [sp, #0x20]  | stack[1152921515554641680] = ???;  stack[1152921515554641688] = ???;  //  dest_result_addr=1152921515554641680 |  dest_result_addr=1152921515554641688
        // 0x00D820CC: STP x29, x30, [sp, #0x30]  | stack[1152921515554641696] = ???;  stack[1152921515554641704] = ???;  //  dest_result_addr=1152921515554641696 |  dest_result_addr=1152921515554641704
        // 0x00D820D0: ADD x29, sp, #0x30         | X29 = (1152921515554641648 + 48) = 1152921515554641696 (0x100000028C8A1720);
        // 0x00D820D4: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D820D8: LDRB w8, [x20, #0x42a]     | W8 = (bool)static_value_0373442A;       
        // 0x00D820DC: MOV v8.16b, v0.16b         | V8 = delayTime;//m1                     
        // 0x00D820E0: MOV x19, x0                | X19 = 1152921515554653712 (0x100000028C8A4610);//ML01
        // 0x00D820E4: TBNZ w8, #0, #0xd82100     | if (static_value_0373442A == true) goto label_0;
        // 0x00D820E8: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
        // 0x00D820EC: LDR x8, [x8, #0x568]       | X8 = 0x2B90548;                         
        // 0x00D820F0: LDR w0, [x8]               | W0 = 0x1816;                            
        // 0x00D820F4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1816, ????);     
        // 0x00D820F8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D820FC: STRB w8, [x20, #0x42a]     | static_value_0373442A = true;            //  dest_result_addr=57885738
        label_0:
        // 0x00D82100: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
        // 0x00D82104: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
        // 0x00D82108: LDR x8, [x8, #0x1d8]       | X8 = 1152921515554628688;               
        // 0x00D8210C: LDR x9, [x9, #0xbe0]       | X9 = 1152921504687837184;               
        // 0x00D82110: LDR x21, [x8]              | X21 = System.Void ChangeParent::OnChange();
        // 0x00D82114: LDR x0, [x9]               | X0 = typeof(System.Action);             
        System.Action val_1 = null;
        // 0x00D82118: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00D8211C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D82120: MOV x1, x19                | X1 = 1152921515554653712 (0x100000028C8A4610);//ML01
        // 0x00D82124: MOV x2, x21                | X2 = 1152921515554628688 (0x100000028C89E450);//ML01
        // 0x00D82128: MOV x20, x0                | X20 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00D8212C: BL #0x26e30f0              | .ctor(object:  this, method:  System.Void ChangeParent::OnChange());
        val_1 = new System.Action(object:  this, method:  System.Void ChangeParent::OnChange());
        // 0x00D82130: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
        // 0x00D82134: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
        // 0x00D82138: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
        // 0x00D8213C: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00D82140: TBZ w8, #0, #0xd82150      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D82144: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00D82148: CBNZ w8, #0xd82150         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D8214C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        label_2:
        // 0x00D82150: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82154: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D82158: MOV v0.16b, v8.16b         | V0 = delayTime;//m1                     
        // 0x00D8215C: MOV x1, x20                | X1 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00D82160: BL #0xb8e194               | X0 = BehaviourUtil.DelayCall(delaytime:  delayTime, act:  0);
        uint val_2 = BehaviourUtil.DelayCall(delaytime:  delayTime, act:  0);
        // 0x00D82164: STR w0, [x19, #0x18]       | this.delayID = val_2;                    //  dest_result_addr=1152921515554653736
        this.delayID = val_2;
        // 0x00D82168: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00D8216C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00D82170: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00D82174: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00D82178: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D8217C (14164348), len: 124  VirtAddr: 0x00D8217C RVA: 0x00D8217C token: 100696565 methodIndex: 25964 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnChange()
    {
        //
        // Disasemble & Code
        // 0x00D8217C: STP x20, x19, [sp, #-0x20]! | stack[1152921515554761872] = ???;  stack[1152921515554761880] = ???;  //  dest_result_addr=1152921515554761872 |  dest_result_addr=1152921515554761880
        // 0x00D82180: STP x29, x30, [sp, #0x10]  | stack[1152921515554761888] = ???;  stack[1152921515554761896] = ???;  //  dest_result_addr=1152921515554761888 |  dest_result_addr=1152921515554761896
        // 0x00D82184: ADD x29, sp, #0x10         | X29 = (1152921515554761872 + 16) = 1152921515554761888 (0x100000028C8BECA0);
        // 0x00D82188: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D8218C: LDRB w8, [x20, #0x42b]     | W8 = (bool)static_value_0373442B;       
        // 0x00D82190: MOV x19, x0                | X19 = 1152921515554773904 (0x100000028C8C1B90);//ML01
        // 0x00D82194: TBNZ w8, #0, #0xd821b0     | if (static_value_0373442B == true) goto label_0;
        // 0x00D82198: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
        // 0x00D8219C: LDR x8, [x8, #0xdf0]       | X8 = 0x2B9054C;                         
        // 0x00D821A0: LDR w0, [x8]               | W0 = 0x1817;                            
        // 0x00D821A4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1817, ????);     
        // 0x00D821A8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D821AC: STRB w8, [x20, #0x42b]     | static_value_0373442B = true;            //  dest_result_addr=57885739
        label_0:
        // 0x00D821B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D821B4: MOV x0, x19                | X0 = 1152921515554773904 (0x100000028C8C1B90);//ML01
        // 0x00D821B8: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_1 = this.gameObject;
        // 0x00D821BC: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
        // 0x00D821C0: LDR x8, [x8, #0xd70]       | X8 = (string**)(1152921514895359872)("Effects");
        // 0x00D821C4: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00D821C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D821CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D821D0: LDR x1, [x8]               | X1 = "Effects";                         
        // 0x00D821D4: BL #0x1a634b4              | X0 = UnityEngine.GameObject.Find(name:  0);
        UnityEngine.GameObject val_2 = UnityEngine.GameObject.Find(name:  0);
        // 0x00D821D8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D821DC: MOV x2, x0                 | X2 = val_2;//m1                         
        // 0x00D821E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D821E4: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00D821E8: MOV x1, x19                | X1 = val_1;//m1                         
        // 0x00D821EC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00D821F0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D821F4: B #0xbf7570                | GameObject_Hierarchy.ChangeParent(_this:  0, parent:  val_1, resetMat:  val_2); return;
        GameObject_Hierarchy.ChangeParent(_this:  0, parent:  val_1, resetMat:  val_2);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D821F8 (14164472), len: 112  VirtAddr: 0x00D821F8 RVA: 0x00D821F8 token: 100696566 methodIndex: 25965 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnDestroy()
    {
        //
        // Disasemble & Code
        // 0x00D821F8: STP x20, x19, [sp, #-0x20]! | stack[1152921515554882064] = ???;  stack[1152921515554882072] = ???;  //  dest_result_addr=1152921515554882064 |  dest_result_addr=1152921515554882072
        // 0x00D821FC: STP x29, x30, [sp, #0x10]  | stack[1152921515554882080] = ???;  stack[1152921515554882088] = ???;  //  dest_result_addr=1152921515554882080 |  dest_result_addr=1152921515554882088
        // 0x00D82200: ADD x29, sp, #0x10         | X29 = (1152921515554882064 + 16) = 1152921515554882080 (0x100000028C8DC220);
        // 0x00D82204: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D82208: LDRB w8, [x20, #0x42c]     | W8 = (bool)static_value_0373442C;       
        // 0x00D8220C: MOV x19, x0                | X19 = 1152921515554894096 (0x100000028C8DF110);//ML01
        // 0x00D82210: TBNZ w8, #0, #0xd8222c     | if (static_value_0373442C == true) goto label_0;
        // 0x00D82214: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
        // 0x00D82218: LDR x8, [x8, #0x2f8]       | X8 = 0x2B90550;                         
        // 0x00D8221C: LDR w0, [x8]               | W0 = 0x1818;                            
        // 0x00D82220: BL #0x2782188              | X0 = sub_2782188( ?? 0x1818, ????);     
        // 0x00D82224: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D82228: STRB w8, [x20, #0x42c]     | static_value_0373442C = true;            //  dest_result_addr=57885740
        label_0:
        // 0x00D8222C: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
        // 0x00D82230: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
        // 0x00D82234: LDR w19, [x19, #0x18]      | W19 = this.delayID; //P2                
        // 0x00D82238: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
        // 0x00D8223C: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00D82240: TBZ w8, #0, #0xd82250      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D82244: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00D82248: CBNZ w8, #0xd82250         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D8224C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        label_2:
        // 0x00D82250: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D82254: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D82258: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D8225C: MOV w1, w19                | W1 = this.delayID;//m1                  
        // 0x00D82260: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D82264: B #0xb8dc54                | BehaviourUtil.StopCoroutine(id:  0); return;
        BehaviourUtil.StopCoroutine(id:  0);
        return;
    
    }

}
