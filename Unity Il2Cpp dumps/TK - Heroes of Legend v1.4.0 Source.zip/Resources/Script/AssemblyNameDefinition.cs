using UnityEngine;

namespace ILRuntime.Mono.Cecil
{
    public sealed class AssemblyNameDefinition : AssemblyNameReference
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E55318 (15029016), len: 72  VirtAddr: 0x00E55318 RVA: 0x00E55318 token: 100663463 methodIndex: 19291 delegateWrapperIndex: 0 methodInvoker: 0
        internal AssemblyNameDefinition()
        {
            //
            // Disasemble & Code
            // 0x00E55318: STP x20, x19, [sp, #-0x20]! | stack[1152921509422022400] = ???;  stack[1152921509422022408] = ???;  //  dest_result_addr=1152921509422022400 |  dest_result_addr=1152921509422022408
            // 0x00E5531C: STP x29, x30, [sp, #0x10]  | stack[1152921509422022416] = ???;  stack[1152921509422022424] = ???;  //  dest_result_addr=1152921509422022416 |  dest_result_addr=1152921509422022424
            // 0x00E55320: ADD x29, sp, #0x10         | X29 = (1152921509422022400 + 16) = 1152921509422022416 (0x100000011F01BF10);
            // 0x00E55324: SUB sp, sp, #0x10          | SP = (1152921509422022400 - 16) = 1152921509422022384 (0x100000011F01BEF0);
            // 0x00E55328: MOV x19, x0                | X19 = 1152921509422034432 (0x100000011F01EE00);//ML01
            // 0x00E5532C: BL #0xe55360               | this..ctor();                           
            // 0x00E55330: ADD x0, sp, #8             | X0 = (1152921509422022384 + 8) = 1152921509422022392 (0x100000011F01BEF8);
            // 0x00E55334: ORR w1, wzr, #0x20000000   | W1 = 536870912(0x20000000);             
            // 0x00E55338: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00E5533C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E55340: STR wzr, [sp, #8]          | stack[1152921509422022392] = 0x0;        //  dest_result_addr=1152921509422022392
            // 0x00E55344: BL #0x11d58ec              | null..ctor(type:  536870912, rid:  1);  
            ILRuntime.Mono.Cecil.MetadataToken val_1 = new ILRuntime.Mono.Cecil.MetadataToken(type:  536870912, rid:  1);
            // 0x00E55348: LDR w8, [sp, #8]           | W8 = val_1.token;                       
            // 0x00E5534C: STR w8, [x19, #0x50]       | mem[1152921509422034512] = val_1.token;  //  dest_result_addr=1152921509422034512
            mem[1152921509422034512] = val_1.token;
            // 0x00E55350: SUB sp, x29, #0x10         | SP = (1152921509422022416 - 16) = 1152921509422022400 (0x100000011F01BF00);
            // 0x00E55354: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E55358: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E5535C: RET                        |  return;                                
            return;
        
        }
    
    }

}
