using UnityEngine;

namespace wxb
{
    public class AutoILMono : Attribute
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2CA34 (14862900), len: 8  VirtAddr: 0x00E2CA34 RVA: 0x00E2CA34 token: 100681235 methodIndex: 57245 delegateWrapperIndex: 0 methodInvoker: 0
        public AutoILMono()
        {
            //
            // Disasemble & Code
            // 0x00E2CA34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2CA38: B #0x18d1dd4               | this..ctor(); return;                   
            return;
        
        }
    
    }

}
