using UnityEngine;
public enum UIRoot.Constraint
{
    // Fields
    Fit = 0
    ,Fill = 1
    ,FitWidth = 2
    ,FitHeight = 3
    

}
