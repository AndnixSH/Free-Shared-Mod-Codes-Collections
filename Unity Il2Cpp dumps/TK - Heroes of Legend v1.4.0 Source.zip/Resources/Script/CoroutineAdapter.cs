using UnityEngine;

namespace Mihua.Assets.ILR.MHAdapter
{
    public class CoroutineAdapter : CrossBindingAdaptor
    {
        // Properties
        public override System.Type BaseCLRType { get; }
        public override System.Type[] BaseCLRTypes { get; }
        public override System.Type AdaptorType { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AB8014 (11239444), len: 8  VirtAddr: 0x00AB8014 RVA: 0x00AB8014 token: 100680720 methodIndex: 47016 delegateWrapperIndex: 0 methodInvoker: 0
        public CoroutineAdapter()
        {
            //
            // Disasemble & Code
            // 0x00AB8014: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB8018: B #0x28ef918               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB801C (11239452), len: 8  VirtAddr: 0x00AB801C RVA: 0x00AB801C token: 100680721 methodIndex: 47017 delegateWrapperIndex: 0 methodInvoker: 0
        public override System.Type get_BaseCLRType()
        {
            //
            // Disasemble & Code
            // 0x00AB801C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB8020: RET                        |  return (System.Type)null;              
            return (System.Type)0;
            //  |  // // {name=val_0, type=System.Type, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB8024 (11239460), len: 420  VirtAddr: 0x00AB8024 RVA: 0x00AB8024 token: 100680722 methodIndex: 47018 delegateWrapperIndex: 0 methodInvoker: 0
        public override System.Type[] get_BaseCLRTypes()
        {
            //
            // Disasemble & Code
            // 0x00AB8024: STP x20, x19, [sp, #-0x20]! | stack[1152921512956148384] = ???;  stack[1152921512956148392] = ???;  //  dest_result_addr=1152921512956148384 |  dest_result_addr=1152921512956148392
            // 0x00AB8028: STP x29, x30, [sp, #0x10]  | stack[1152921512956148400] = ???;  stack[1152921512956148408] = ???;  //  dest_result_addr=1152921512956148400 |  dest_result_addr=1152921512956148408
            // 0x00AB802C: ADD x29, sp, #0x10         | X29 = (1152921512956148384 + 16) = 1152921512956148400 (0x10000001F1A83AB0);
            // 0x00AB8030: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AB8034: LDRB w8, [x19, #0x41a]     | W8 = (bool)static_value_0373341A;       
            // 0x00AB8038: TBNZ w8, #0, #0xab8054     | if (static_value_0373341A == true) goto label_0;
            // 0x00AB803C: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
            // 0x00AB8040: LDR x8, [x8, #0x2f8]       | X8 = 0x2B92D4C;                         
            // 0x00AB8044: LDR w0, [x8]               | W0 = 0x2218;                            
            // 0x00AB8048: BL #0x2782188              | X0 = sub_2782188( ?? 0x2218, ????);     
            // 0x00AB804C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB8050: STRB w8, [x19, #0x41a]     | static_value_0373341A = true;            //  dest_result_addr=57881626
            label_0:
            // 0x00AB8054: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x00AB8058: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x00AB805C: LDR x19, [x8]              | X19 = typeof(System.Type[]);            
            // 0x00AB8060: MOV x0, x19                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00AB8064: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00AB8068: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x00AB806C: MOV x0, x19                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00AB8070: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00AB8074: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00AB8078: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00AB807C: ADRP x9, #0x366f000        | X9 = 57077760 (0x366F000);              
            // 0x00AB8080: MOV x19, x0                | X19 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00AB8084: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00AB8088: LDR x9, [x9, #0x78]        | X9 = 1152921504608178176;               
            // 0x00AB808C: LDR x20, [x9]              | X20 = typeof(System.Collections.Generic.IEnumerator<T>);
            // 0x00AB8090: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00AB8094: TBZ w9, #0, #0xab80a8      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB8098: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00AB809C: CBNZ w9, #0xab80a8         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB80A0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00AB80A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00AB80A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB80AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB80B0: MOV x1, x20                | X1 = 1152921504608178176 (0x1000000000145000);//ML01
            // 0x00AB80B4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00AB80B8: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00AB80BC: CBNZ x19, #0xab80c4        | if ( != null) goto label_3;             
            if(null != null)
            {
                goto label_3;
            }
            // 0x00AB80C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x00AB80C4: CBZ x20, #0xab80e8         | if (val_1 == null) goto label_5;        
            if(val_1 == null)
            {
                goto label_5;
            }
            // 0x00AB80C8: LDR x8, [x19]              | X8 = ;                                  
            // 0x00AB80CC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00AB80D0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AB80D4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_1, ????);      
            // 0x00AB80D8: CBNZ x0, #0xab80e8         | if (val_1 != null) goto label_5;        
            if(val_1 != null)
            {
                goto label_5;
            }
            // 0x00AB80DC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_1, ????);      
            // 0x00AB80E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB80E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            label_5:
            // 0x00AB80E8: LDR w8, [x19, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00AB80EC: CBNZ w8, #0xab80fc         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_6;
            // 0x00AB80F0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x00AB80F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB80F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            label_6:
            // 0x00AB80FC: STR x20, [x19, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_1;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_1;
            // 0x00AB8100: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
            // 0x00AB8104: LDR x8, [x8, #0x458]       | X8 = 1152921504608018432;               
            // 0x00AB8108: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB810C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB8110: LDR x1, [x8]               | X1 = typeof(System.Collections.IEnumerator);
            // 0x00AB8114: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_2 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00AB8118: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00AB811C: CBZ x20, #0xab8140         | if (val_2 == null) goto label_8;        
            if(val_2 == null)
            {
                goto label_8;
            }
            // 0x00AB8120: LDR x8, [x19]              | X8 = ;                                  
            // 0x00AB8124: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00AB8128: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AB812C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x00AB8130: CBNZ x0, #0xab8140         | if (val_2 != null) goto label_8;        
            if(val_2 != null)
            {
                goto label_8;
            }
            // 0x00AB8134: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
            // 0x00AB8138: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB813C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_8:
            // 0x00AB8140: LDR w8, [x19, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00AB8144: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00AB8148: B.HI #0xab8158             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_9;
            // 0x00AB814C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x00AB8150: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB8154: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_9:
            // 0x00AB8158: STR x20, [x19, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_2;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_2;
            // 0x00AB815C: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
            // 0x00AB8160: LDR x8, [x8, #0x6f8]       | X8 = 1152921504608124928;               
            // 0x00AB8164: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB8168: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB816C: LDR x1, [x8]               | X1 = typeof(System.IDisposable);        
            // 0x00AB8170: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00AB8174: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x00AB8178: CBZ x20, #0xab819c         | if (val_3 == null) goto label_11;       
            if(val_3 == null)
            {
                goto label_11;
            }
            // 0x00AB817C: LDR x8, [x19]              | X8 = ;                                  
            // 0x00AB8180: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x00AB8184: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AB8188: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x00AB818C: CBNZ x0, #0xab819c         | if (val_3 != null) goto label_11;       
            if(val_3 != null)
            {
                goto label_11;
            }
            // 0x00AB8190: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_3, ????);      
            // 0x00AB8194: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB8198: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_11:
            // 0x00AB819C: LDR w8, [x19, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00AB81A0: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x00AB81A4: B.HI #0xab81b4             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_12;
            // 0x00AB81A8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
            // 0x00AB81AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB81B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_12:
            // 0x00AB81B4: STR x20, [x19, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_3;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_3;
            // 0x00AB81B8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB81BC: MOV x0, x19                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00AB81C0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB81C4: RET                        |  return (System.Type[])typeof(System.Type[]);
            return (System.Type[])null;
            //  |  // // {name=val_0, type=System.Type[], size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB81C8 (11239880), len: 116  VirtAddr: 0x00AB81C8 RVA: 0x00AB81C8 token: 100680723 methodIndex: 47019 delegateWrapperIndex: 0 methodInvoker: 0
        public override System.Type get_AdaptorType()
        {
            //
            // Disasemble & Code
            // 0x00AB81C8: STP x20, x19, [sp, #-0x20]! | stack[1152921512956272672] = ???;  stack[1152921512956272680] = ???;  //  dest_result_addr=1152921512956272672 |  dest_result_addr=1152921512956272680
            // 0x00AB81CC: STP x29, x30, [sp, #0x10]  | stack[1152921512956272688] = ???;  stack[1152921512956272696] = ???;  //  dest_result_addr=1152921512956272688 |  dest_result_addr=1152921512956272696
            // 0x00AB81D0: ADD x29, sp, #0x10         | X29 = (1152921512956272672 + 16) = 1152921512956272688 (0x10000001F1AA2030);
            // 0x00AB81D4: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AB81D8: LDRB w8, [x19, #0x41b]     | W8 = (bool)static_value_0373341B;       
            // 0x00AB81DC: TBNZ w8, #0, #0xab81f8     | if (static_value_0373341B == true) goto label_0;
            // 0x00AB81E0: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x00AB81E4: LDR x8, [x8, #0x518]       | X8 = 0x2B92D44;                         
            // 0x00AB81E8: LDR w0, [x8]               | W0 = 0x2216;                            
            // 0x00AB81EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x2216, ????);     
            // 0x00AB81F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB81F4: STRB w8, [x19, #0x41b]     | static_value_0373341B = true;            //  dest_result_addr=57881627
            label_0:
            // 0x00AB81F8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00AB81FC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00AB8200: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x00AB8204: ADRP x8, #0x3645000        | X8 = 56905728 (0x3645000);              
            // 0x00AB8208: LDR x8, [x8, #0x678]       | X8 = 1152921504827559936;               
            // 0x00AB820C: LDR x19, [x8]              | X19 = typeof(CoroutineAdapter.Adaptor); 
            // 0x00AB8210: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00AB8214: TBZ w8, #0, #0xab8224      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB8218: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00AB821C: CBNZ w8, #0xab8224         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB8220: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00AB8224: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB8228: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB822C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB8230: MOV x1, x19                | X1 = 1152921504827559936 (0x100000000D27D000);//ML01
            // 0x00AB8234: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB8238: B #0x1b6d31c               | return System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            return System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB823C (11239996), len: 112  VirtAddr: 0x00AB823C RVA: 0x00AB823C token: 100680724 methodIndex: 47020 delegateWrapperIndex: 0 methodInvoker: 0
        public override object CreateCLRInstance(ILRuntime.Runtime.Enviorment.AppDomain appdomain, ILRuntime.Runtime.Intepreter.ILTypeInstance instance)
        {
            //
            // Disasemble & Code
            // 0x00AB823C: STP x22, x21, [sp, #-0x30]! | stack[1152921512956392848] = ???;  stack[1152921512956392856] = ???;  //  dest_result_addr=1152921512956392848 |  dest_result_addr=1152921512956392856
            // 0x00AB8240: STP x20, x19, [sp, #0x10]  | stack[1152921512956392864] = ???;  stack[1152921512956392872] = ???;  //  dest_result_addr=1152921512956392864 |  dest_result_addr=1152921512956392872
            // 0x00AB8244: STP x29, x30, [sp, #0x20]  | stack[1152921512956392880] = ???;  stack[1152921512956392888] = ???;  //  dest_result_addr=1152921512956392880 |  dest_result_addr=1152921512956392888
            // 0x00AB8248: ADD x29, sp, #0x20         | X29 = (1152921512956392848 + 32) = 1152921512956392880 (0x10000001F1ABF5B0);
            // 0x00AB824C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AB8250: LDRB w8, [x21, #0x41c]     | W8 = (bool)static_value_0373341C;       
            // 0x00AB8254: MOV x19, x2                | X19 = instance;//m1                     
            // 0x00AB8258: MOV x20, x1                | X20 = appdomain;//m1                    
            // 0x00AB825C: TBNZ w8, #0, #0xab8278     | if (static_value_0373341C == true) goto label_0;
            // 0x00AB8260: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x00AB8264: LDR x8, [x8, #0x7b0]       | X8 = 0x2B92D3C;                         
            // 0x00AB8268: LDR w0, [x8]               | W0 = 0x2214;                            
            // 0x00AB826C: BL #0x2782188              | X0 = sub_2782188( ?? 0x2214, ????);     
            // 0x00AB8270: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB8274: STRB w8, [x21, #0x41c]     | static_value_0373341C = true;            //  dest_result_addr=57881628
            label_0:
            // 0x00AB8278: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
            // 0x00AB827C: LDR x8, [x8, #0x448]       | X8 = 1152921504827559936;               
            // 0x00AB8280: LDR x0, [x8]               | X0 = typeof(CoroutineAdapter.Adaptor);  
            object val_1 = null;
            // 0x00AB8284: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CoroutineAdapter.Adaptor), ????);
            // 0x00AB8288: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB828C: MOV x21, x0                | X21 = 1152921504827559936 (0x100000000D27D000);//ML01
            // 0x00AB8290: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x00AB8294: STP x19, x20, [x21, #0x10] | typeof(CoroutineAdapter.Adaptor).__il2cppRuntimeField_10 = instance;  typeof(CoroutineAdapter.Adaptor).__il2cppRuntimeField_18 = appdomain;  //  dest_result_addr=1152921504827559952 |  dest_result_addr=1152921504827559960
            typeof(CoroutineAdapter.Adaptor).__il2cppRuntimeField_10 = instance;
            typeof(CoroutineAdapter.Adaptor).__il2cppRuntimeField_18 = appdomain;
            // 0x00AB8298: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB829C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB82A0: MOV x0, x21                | X0 = 1152921504827559936 (0x100000000D27D000);//ML01
            // 0x00AB82A4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AB82A8: RET                        |  return (System.Object)typeof(CoroutineAdapter.Adaptor);
            return (object)val_1;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
    
    }

}
