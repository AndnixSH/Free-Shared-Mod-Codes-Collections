using UnityEngine;

namespace Pathfinding.ClipperLib
{
    internal class ClipperException : Exception
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x02701D5C (40901980), len: 8  VirtAddr: 0x02701D5C RVA: 0x02701D5C token: 100663452 methodIndex: 20780 delegateWrapperIndex: 0 methodInvoker: 0
        public ClipperException(string description)
        {
            //
            // Disasemble & Code
            // 0x02701D5C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02701D60: B #0x1c32b48               | this..ctor(message:  description); return;
            return;
        
        }
    
    }

}
