using UnityEngine;

namespace wxb
{
    internal class ArrayULongType : ArraySerialize<ulong>
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2C8C4 (14862532), len: 80  VirtAddr: 0x00E2C8C4 RVA: 0x00E2C8C4 token: 100681217 methodIndex: 57237 delegateWrapperIndex: 0 methodInvoker: 0
        public ArrayULongType()
        {
            //
            // Disasemble & Code
            // 0x00E2C8C4: STP x20, x19, [sp, #-0x20]! | stack[1152921513027717024] = ???;  stack[1152921513027717032] = ???;  //  dest_result_addr=1152921513027717024 |  dest_result_addr=1152921513027717032
            // 0x00E2C8C8: STP x29, x30, [sp, #0x10]  | stack[1152921513027717040] = ???;  stack[1152921513027717048] = ???;  //  dest_result_addr=1152921513027717040 |  dest_result_addr=1152921513027717048
            // 0x00E2C8CC: ADD x29, sp, #0x10         | X29 = (1152921513027717024 + 16) = 1152921513027717040 (0x10000001F5EC47B0);
            // 0x00E2C8D0: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2C8D4: LDRB w8, [x20, #0x8f9]     | W8 = (bool)static_value_037348F9;       
            // 0x00E2C8D8: MOV x19, x0                | X19 = 1152921513027729056 (0x10000001F5EC76A0);//ML01
            // 0x00E2C8DC: TBNZ w8, #0, #0xe2c8f8     | if (static_value_037348F9 == true) goto label_0;
            // 0x00E2C8E0: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
            // 0x00E2C8E4: LDR x8, [x8, #0x8b0]       | X8 = 0x2B8E870;                         
            // 0x00E2C8E8: LDR w0, [x8]               | W0 = 0x10DA;                            
            // 0x00E2C8EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x10DA, ????);     
            // 0x00E2C8F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2C8F4: STRB w8, [x20, #0x8f9]     | static_value_037348F9 = true;            //  dest_result_addr=57886969
            label_0:
            // 0x00E2C8F8: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
            // 0x00E2C8FC: LDR x8, [x8, #0xf40]       | X8 = 1152921513027704032;               
            // 0x00E2C900: MOV x0, x19                | X0 = 1152921513027729056 (0x10000001F5EC76A0);//ML01
            // 0x00E2C904: LDR x1, [x8]               | X1 = System.Void wxb.ArraySerialize<System.UInt64>::.ctor();
            // 0x00E2C908: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2C90C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2C910: B #0x1d873d8               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2C914 (14862612), len: 8  VirtAddr: 0x00E2C914 RVA: 0x00E2C914 token: 100681218 methodIndex: 57238 delegateWrapperIndex: 0 methodInvoker: 0
        protected override int GetElementSize()
        {
            //
            // Disasemble & Code
            // 0x00E2C914: ORR w0, wzr, #8            | W0 = 8(0x8);                            
            // 0x00E2C918: RET                        |  return (System.Int32)8;                
            return (int)8;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2C91C (14862620), len: 52  VirtAddr: 0x00E2C91C RVA: 0x00E2C91C token: 100681219 methodIndex: 57239 delegateWrapperIndex: 0 methodInvoker: 0
        protected override void Write(wxb.WRStream stream, ulong value)
        {
            //
            // Disasemble & Code
            // 0x00E2C91C: STP x20, x19, [sp, #-0x20]! | stack[1152921513027945120] = ???;  stack[1152921513027945128] = ???;  //  dest_result_addr=1152921513027945120 |  dest_result_addr=1152921513027945128
            // 0x00E2C920: STP x29, x30, [sp, #0x10]  | stack[1152921513027945136] = ???;  stack[1152921513027945144] = ???;  //  dest_result_addr=1152921513027945136 |  dest_result_addr=1152921513027945144
            // 0x00E2C924: ADD x29, sp, #0x10         | X29 = (1152921513027945120 + 16) = 1152921513027945136 (0x10000001F5EFC2B0);
            // 0x00E2C928: MOV x19, x2                | X19 = value;//m1                        
            // 0x00E2C92C: MOV x20, x1                | X20 = stream;//m1                       
            // 0x00E2C930: CBNZ x20, #0xe2c938        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2C934: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2C938: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2C93C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2C940: MOV x0, x20                | X0 = stream;//m1                        
            // 0x00E2C944: MOV x1, x19                | X1 = value;//m1                         
            // 0x00E2C948: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2C94C: B #0x26a4300               | stream.WriteInt64(value:  value); return;
            stream.WriteInt64(value:  value);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2C950 (14862672), len: 44  VirtAddr: 0x00E2C950 RVA: 0x00E2C950 token: 100681220 methodIndex: 57240 delegateWrapperIndex: 0 methodInvoker: 0
        protected override ulong Read(wxb.WRStream stream)
        {
            //
            // Disasemble & Code
            // 0x00E2C950: STP x20, x19, [sp, #-0x20]! | stack[1152921513028065312] = ???;  stack[1152921513028065320] = ???;  //  dest_result_addr=1152921513028065312 |  dest_result_addr=1152921513028065320
            // 0x00E2C954: STP x29, x30, [sp, #0x10]  | stack[1152921513028065328] = ???;  stack[1152921513028065336] = ???;  //  dest_result_addr=1152921513028065328 |  dest_result_addr=1152921513028065336
            // 0x00E2C958: ADD x29, sp, #0x10         | X29 = (1152921513028065312 + 16) = 1152921513028065328 (0x10000001F5F19830);
            // 0x00E2C95C: MOV x19, x1                | X19 = stream;//m1                       
            // 0x00E2C960: CBNZ x19, #0xe2c968        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2C964: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2C968: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2C96C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2C970: MOV x0, x19                | X0 = stream;//m1                        
            // 0x00E2C974: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2C978: B #0x26a4534               | return stream.ReadUInt64();             
            return stream.ReadUInt64();
        
        }
    
    }

}
