using UnityEngine;

namespace wxb
{
    internal class ByteType : Serialize<byte>
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2E118 (14868760), len: 80  VirtAddr: 0x00E2E118 RVA: 0x00E2E118 token: 100681123 methodIndex: 57302 delegateWrapperIndex: 0 methodInvoker: 0
        public ByteType()
        {
            //
            // Disasemble & Code
            // 0x00E2E118: STP x20, x19, [sp, #-0x20]! | stack[1152921513017124288] = ???;  stack[1152921513017124296] = ???;  //  dest_result_addr=1152921513017124288 |  dest_result_addr=1152921513017124296
            // 0x00E2E11C: STP x29, x30, [sp, #0x10]  | stack[1152921513017124304] = ???;  stack[1152921513017124312] = ???;  //  dest_result_addr=1152921513017124304 |  dest_result_addr=1152921513017124312
            // 0x00E2E120: ADD x29, sp, #0x10         | X29 = (1152921513017124288 + 16) = 1152921513017124304 (0x10000001F54AA5D0);
            // 0x00E2E124: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2E128: LDRB w8, [x20, #0x931]     | W8 = (bool)static_value_03734931;       
            // 0x00E2E12C: MOV x19, x0                | X19 = 1152921513017136320 (0x10000001F54AD4C0);//ML01
            // 0x00E2E130: TBNZ w8, #0, #0xe2e14c     | if (static_value_03734931 == true) goto label_0;
            // 0x00E2E134: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
            // 0x00E2E138: LDR x8, [x8, #0x2a8]       | X8 = 0x2B90018;                         
            // 0x00E2E13C: LDR w0, [x8]               | W0 = 0x16CA;                            
            // 0x00E2E140: BL #0x2782188              | X0 = sub_2782188( ?? 0x16CA, ????);     
            // 0x00E2E144: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2E148: STRB w8, [x20, #0x931]     | static_value_03734931 = true;            //  dest_result_addr=57887025
            label_0:
            // 0x00E2E14C: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x00E2E150: LDR x8, [x8, #0xec0]       | X8 = 1152921513017111296;               
            // 0x00E2E154: MOV x0, x19                | X0 = 1152921513017136320 (0x10000001F54AD4C0);//ML01
            // 0x00E2E158: LDR x1, [x8]               | X1 = System.Void wxb.Serialize<System.Byte>::.ctor();
            // 0x00E2E15C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2E160: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2E164: B #0x1d8ba04               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2E168 (14868840), len: 8  VirtAddr: 0x00E2E168 RVA: 0x00E2E168 token: 100681124 methodIndex: 57303 delegateWrapperIndex: 0 methodInvoker: 0
        protected override int CalculateSize(byte value)
        {
            //
            // Disasemble & Code
            // 0x00E2E168: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            // 0x00E2E16C: RET                        |  return (System.Int32)1;                
            return (int)1;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2E170 (14868848), len: 52  VirtAddr: 0x00E2E170 RVA: 0x00E2E170 token: 100681125 methodIndex: 57304 delegateWrapperIndex: 0 methodInvoker: 0
        protected override void Write(wxb.WRStream stream, byte value)
        {
            //
            // Disasemble & Code
            // 0x00E2E170: STP x20, x19, [sp, #-0x20]! | stack[1152921513017352384] = ???;  stack[1152921513017352392] = ???;  //  dest_result_addr=1152921513017352384 |  dest_result_addr=1152921513017352392
            // 0x00E2E174: STP x29, x30, [sp, #0x10]  | stack[1152921513017352400] = ???;  stack[1152921513017352408] = ???;  //  dest_result_addr=1152921513017352400 |  dest_result_addr=1152921513017352408
            // 0x00E2E178: ADD x29, sp, #0x10         | X29 = (1152921513017352384 + 16) = 1152921513017352400 (0x10000001F54E20D0);
            // 0x00E2E17C: MOV w19, w2                | W19 = value;//m1                        
            // 0x00E2E180: MOV x20, x1                | X20 = stream;//m1                       
            // 0x00E2E184: CBNZ x20, #0xe2e18c        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2E188: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2E18C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2E190: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2E194: MOV x0, x20                | X0 = stream;//m1                        
            // 0x00E2E198: MOV w1, w19                | W1 = value;//m1                         
            // 0x00E2E19C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2E1A0: B #0x26a5270               | stream.WriteByte(value:  value); return;
            stream.WriteByte(value:  value);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2E1A4 (14868900), len: 44  VirtAddr: 0x00E2E1A4 RVA: 0x00E2E1A4 token: 100681126 methodIndex: 57305 delegateWrapperIndex: 0 methodInvoker: 0
        protected override byte Read(wxb.WRStream stream)
        {
            //
            // Disasemble & Code
            // 0x00E2E1A4: STP x20, x19, [sp, #-0x20]! | stack[1152921513017472576] = ???;  stack[1152921513017472584] = ???;  //  dest_result_addr=1152921513017472576 |  dest_result_addr=1152921513017472584
            // 0x00E2E1A8: STP x29, x30, [sp, #0x10]  | stack[1152921513017472592] = ???;  stack[1152921513017472600] = ???;  //  dest_result_addr=1152921513017472592 |  dest_result_addr=1152921513017472600
            // 0x00E2E1AC: ADD x29, sp, #0x10         | X29 = (1152921513017472576 + 16) = 1152921513017472592 (0x10000001F54FF650);
            // 0x00E2E1B0: MOV x19, x1                | X19 = stream;//m1                       
            // 0x00E2E1B4: CBNZ x19, #0xe2e1bc        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2E1B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2E1BC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2E1C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2E1C4: MOV x0, x19                | X0 = stream;//m1                        
            // 0x00E2E1C8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2E1CC: B #0x26a52d8               | return stream.ReadByte();               
            return stream.ReadByte();
        
        }
    
    }

}
